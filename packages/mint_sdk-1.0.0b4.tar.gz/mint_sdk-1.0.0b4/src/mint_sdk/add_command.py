"""Code-generation helpers for the ``mint add`` CLI group."""

from __future__ import annotations

import re
import sys
import textwrap
from enum import StrEnum
from pathlib import Path

from mint_sdk._discover import DiscoveredPlugin, discover_plugin


class SettingType(StrEnum):
    string = "string"
    number = "number"
    integer = "integer"
    boolean = "boolean"


class HttpMethod(StrEnum):
    get = "get"
    post = "post"
    put = "put"
    patch = "patch"
    delete = "delete"


class HookKind(StrEnum):
    before_save = "before-save"
    after_save = "after-save"
    status_change = "status-change"


class DataTemplateKind(StrEnum):
    plate_map = "plate-map"
    sample_sheet = "sample-sheet"
    sample_prep = "sample-prep"
    dose_response = "dose-response"
    calibration_curve = "calibration-curve"
    time_course = "time-course"
    protocol_steps = "protocol-steps"
    assay_matrix = "assay-matrix"
    reagent_list = "reagent-list"
    flow_cytometry_panel = "flow-cytometry-panel"
    instrument_run = "instrument-run"
    qpcr_plate = "qpcr-plate"


class DataTemplatePackKind(StrEnum):
    cell_culture_screen = "cell-culture-screen"
    omics_assay = "omics-assay"
    longitudinal_study = "longitudinal-study"
    molecular_assay = "molecular-assay"


class DataTemplatePresetKind(StrEnum):
    wellplate_screen = "wellplate-screen"
    qpcr_expression = "qpcr-expression"
    lcms_batch = "lcms-batch"
    elisa_assay = "elisa-assay"
    flow_cytometry_assay = "flow-cytometry-assay"
    western_blot_assay = "western-blot-assay"


DEFAULT_PAGE_ICON_PATH = (
    "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z "
    "M14 2v6h6"
)
ANALYSIS_PAGE_ICON_PATH = "M4 19h16M7 16V8m5 8V4m5 12v-6"
TEMPLATE_PAGE_ICON_PATH = "M4 4h16v16H4V4zm4 0v16m8-16v16M4 10h16M4 16h16"
PRESET_PAGE_ICON_PATH = (
    "M12 3l2.09 6.26L21 9.27l-5.59 4.06L17.45 20 12 15.89 "
    "6.55 20l2.04-6.67L3 9.27l6.91-.01L12 3z"
)


def _data_template_pack_entry(pack: DataTemplatePackKind):
    from mint_sdk.templates import require_template_pack_info

    return require_template_pack_info(pack.value)


def _data_template_pack_templates(pack: DataTemplatePackKind) -> tuple[DataTemplateKind, ...]:
    entry = _data_template_pack_entry(pack)
    return tuple(DataTemplateKind(template) for template in entry.templates)


def list_data_template_packs() -> tuple[dict[str, object], ...]:
    """Return discoverable built-in data-template packs."""
    from mint_sdk.templates import list_template_packs

    return tuple(entry.model_dump(mode="json") for entry in list_template_packs())


def get_data_template_pack_info(name: str) -> dict[str, object] | None:
    """Find a built-in data-template pack by id, display label, or alias."""
    from mint_sdk.templates import get_template_pack_info

    entry = get_template_pack_info(name)
    return None if entry is None else entry.model_dump(mode="json")


def list_data_template_presets() -> tuple[dict[str, object], ...]:
    """Return discoverable ready-to-save data-template presets."""
    from mint_sdk.templates import list_template_presets

    return tuple(
        {
            **entry.model_dump(mode="json"),
            "add_command": f"mint add data-template-preset {entry.name} --page",
        }
        for entry in list_template_presets()
    )


def get_data_template_preset_info(name: str) -> dict[str, object] | None:
    """Find a built-in data-template preset by id, display label, or alias."""
    from mint_sdk.templates import get_template_preset_info

    entry = get_template_preset_info(name)
    if entry is None:
        return None
    for info in list_data_template_presets():
        if str(info["name"]) == entry.name:
            return info
    return None


def cmd_add_setting(
    *,
    path: str = ".",
    name: str,
    field_type: SettingType = SettingType.string,
    default: str | None = None,
    description: str = "",
    required: bool = False,
    generate: bool = False,
) -> None:
    """Add a Pydantic settings field and wire it into the plugin class."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    source = _plugin_source(project_dir, plugin)
    content = source.read_text()

    content = _ensure_import(content, "from pydantic import BaseModel, Field")

    settings_class = _settings_class_name(plugin.class_name)
    field_line = _settings_field_line(
        name=name,
        field_type=field_type,
        default=default,
        description=description,
        required=required,
    )

    if f"class {settings_class}(BaseModel):" not in content:
        content = _insert_before_plugin_class(
            content,
            plugin.class_name,
            f"\n\nclass {settings_class}(BaseModel):\n{field_line}\n",
        )
    elif re.search(rf"^\s+{re.escape(name)}\s*:", content, flags=re.MULTILINE):
        print(f"Setting '{name}' already exists in {settings_class}.")
        return
    else:
        content = _insert_into_class(content, settings_class, field_line)

    content = _ensure_class_attribute(
        content,
        plugin.class_name,
        f"settings_model = {settings_class}",
    )
    source.write_text(content)
    print(f"Added setting '{name}' to {source.relative_to(project_dir)}")
    _handle_generate_contract(project_dir, generate=generate)


def cmd_add_endpoint(
    *,
    path: str = ".",
    name: str,
    route_path: str | None = None,
    method: HttpMethod = HttpMethod.get,
    router: str = "analysis",
    create_router: bool = False,
    request_model: str | None = None,
    response_model: str | None = None,
    generate: bool = False,
) -> None:
    """Append a simple FastAPI endpoint to an existing router module."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    router_name = _snake(router)
    router_file = _module_root(project_dir, plugin) / "routers" / f"{router_name}.py"
    if not router_file.exists():
        if create_router:
            cmd_add_router(path=path, name=router_name)
        else:
            print(
                f"Error: router not found: {router_file}. "
                "Re-run with --create-router or add the router first.",
                file=sys.stderr,
            )
            sys.exit(1)

    fn_name = _snake(name)
    route = route_path or f"/{fn_name.replace('_', '-')}"
    if not route.startswith("/"):
        route = f"/{route}"

    content = router_file.read_text()
    if re.search(rf"async def {re.escape(fn_name)}\(", content):
        print(f"Endpoint function '{fn_name}' already exists.")
        return

    package = _module_package(plugin.module_path)
    if request_model:
        content = _ensure_import(content, f"from {package}.schemas.requests import {request_model}")
    if response_model:
        content = _ensure_import(content, f"from {package}.schemas.responses import {response_model}")

    decorator_args = [f'"{route}"']
    if response_model:
        decorator_args.append(f"response_model={response_model}")
    params = f"request: {request_model}" if request_model else ""
    request_echo = ', "request": request.model_dump()' if request_model else ""

    content = content.rstrip() + f"""


@router.{method.value}({', '.join(decorator_args)})
async def {fn_name}({params}):
    return {{"status": "ok", "endpoint": "{fn_name}"{request_echo}}}
"""
    router_file.write_text(content)
    print(f"Added {method.value.upper()} {route} to {router_file.relative_to(project_dir)}")
    _handle_generate_contract(project_dir, generate=generate)


def cmd_add_router(
    *,
    path: str = ".",
    name: str,
    prefix: str | None = None,
    tag: str | None = None,
) -> None:
    """Create and register a FastAPI router module."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    router_name = _snake(name)
    module_root = _module_root(project_dir, plugin)
    router_file = module_root / "routers" / f"{router_name}.py"
    sub_prefix = prefix or f"/{router_name.replace('_', '-')}"
    if not sub_prefix.startswith("/"):
        sub_prefix = f"/{sub_prefix}"
    tag_name = tag or router_name.replace("_", "-")

    _write_if_missing(
        router_file,
        f'''"""Endpoints for the {tag_name} surface."""

from fastapi import APIRouter

router = APIRouter(tags=["{tag_name}"])


@router.get("/health")
async def health():
    return {{"status": "healthy", "router": "{router_name}"}}
''',
    )
    _register_router(project_dir, plugin, router_name, sub_prefix)
    print(f"Added router {router_file.relative_to(project_dir)} at {sub_prefix}")


def cmd_add_migration(*, path: str = ".", name: str) -> None:
    """Create a plugin migration package and wire get_migrations_package()."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    migrations_dir = module_root / "migrations"
    migrations_dir.mkdir(exist_ok=True)
    (migrations_dir / "__init__.py").touch()

    existing = sorted(migrations_dir.glob("v*.py"))
    next_num = len([p for p in existing if p.name.startswith("v")]) + 1
    file_name = f"v{next_num:03d}_{_snake(name)}.py"
    migration_file = migrations_dir / file_name
    if migration_file.exists():
        print(f"Migration already exists: {migration_file.relative_to(project_dir)}")
        return

    migration_file.write_text(
        f'''"""Plugin migration: {name}."""

from mint_sdk.migrations import MigrationOps, PluginMigration


class Migration(PluginMigration):
    version = "{next_num:03d}"
    description = "{name}"

    async def upgrade(self, ops: MigrationOps) -> None:
        # Add portable DDL operations here, for example:
        # await ops.add_column("my_table", sa.Column("new_column", sa.String(), nullable=True))
        pass
'''
    )

    source = _plugin_source(project_dir, plugin)
    content = source.read_text()
    package = f"{_module_package(plugin.module_path)}.migrations"
    if "def get_migrations_package" not in content:
        content = _insert_before_method(
            content,
            plugin.class_name,
            "async def check_health",
            f'    def get_migrations_package(self) -> str:\n        return "{package}"\n\n',
        )
        source.write_text(content)

    print(f"Added migration {migration_file.relative_to(project_dir)}")


def cmd_add_schema(
    *,
    path: str = ".",
    name: str,
    file: str = "requests",
    fields: list[str] | None = None,
    generate: bool = False,
) -> None:
    """Add a Pydantic schema class to schemas/<file>.py."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    schema_file = module_root / "schemas" / f"{_snake(file)}.py"
    schema_file.parent.mkdir(parents=True, exist_ok=True)
    (schema_file.parent / "__init__.py").touch()

    class_name = _pascal(name)
    content = schema_file.read_text() if schema_file.exists() else "from pydantic import BaseModel, Field\n"

    content = _ensure_import(content, "from pydantic import BaseModel, Field")
    parsed_fields = [_schema_field_line(spec) for spec in fields or []]

    if re.search(rf"^class {re.escape(class_name)}\(BaseModel\):", content, flags=re.MULTILINE):
        print(f"Schema '{class_name}' already exists in {schema_file.relative_to(project_dir)}.")
        return

    body = "\n".join(parsed_fields) if parsed_fields else "    pass"
    content = content.rstrip() + f"\n\n\nclass {class_name}(BaseModel):\n{body}\n"
    schema_file.write_text(content)
    print(f"Added schema {class_name} to {schema_file.relative_to(project_dir)}")
    _handle_generate_contract(project_dir, generate=generate)


def cmd_add_service(
    *,
    path: str = ".",
    name: str,
    method: str = "run",
) -> None:
    """Add a singleton service module with one async method."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    service_name = _snake(name)
    method_name = _snake(method)
    class_name = f"{_pascal(name)}Service"
    getter_name = f"get_{service_name}_service"
    service_file = module_root / "services" / f"{service_name}_service.py"

    _write_if_missing(
        service_file,
        f'''"""Business logic for {service_name.replace("_", " ")}."""

_instance: "{class_name} | None" = None


class {class_name}:

    async def {method_name}(self, payload: dict | None = None) -> dict:
        return {{
            "status": "not_implemented",
            "service": "{service_name}",
            "payload": payload or {{}},
        }}


def {getter_name}() -> {class_name}:
    global _instance
    if _instance is None:
        _instance = {class_name}()
    return _instance
''',
    )
    print(f"Added service {service_file.relative_to(project_dir)}")


def cmd_add_job(*, path: str = ".", name: str = "analysis") -> None:
    """Add an in-memory job service and registered jobs router."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    service_file = module_root / "services" / "jobs.py"
    router_file = module_root / "routers" / "jobs.py"

    _write_if_missing(
        service_file,
        '''"""Simple in-memory job tracking for development."""

from dataclasses import dataclass
from datetime import UTC, datetime
from uuid import uuid4


@dataclass(slots=True)
class JobState:
    id: str
    name: str
    status: str = "queued"
    progress: float = 0.0
    message: str = ""
    created_at: datetime = datetime.now(UTC)


class JobRegistry:
    def __init__(self) -> None:
        self._jobs: dict[str, JobState] = {}

    def create(self, name: str) -> JobState:
        job = JobState(id=str(uuid4()), name=name)
        self._jobs[job.id] = job
        return job

    def get(self, job_id: str) -> JobState | None:
        return self._jobs.get(job_id)


jobs = JobRegistry()
''',
    )

    _write_if_missing(
        router_file,
        f'''"""Job endpoints."""

from fastapi import APIRouter, HTTPException

from {_module_package(plugin.module_path)}.services.jobs import jobs

router = APIRouter(tags=["jobs"])


@router.post("/")
async def create_job():
    job = jobs.create("{_snake(name)}")
    return job


@router.get("/{{job_id}}")
async def get_job(job_id: str):
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
''',
    )
    _register_router(project_dir, plugin, "jobs", "/jobs")
    print("Added job service and /jobs router")


def cmd_add_artifact(*, path: str = ".") -> None:
    """Add a local artifact helper and registered artifacts router."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    service_file = module_root / "services" / "artifacts.py"
    router_file = module_root / "routers" / "artifacts.py"

    _write_if_missing(
        service_file,
        '''"""Local artifact helpers for development.

Integrated artifact storage will eventually be provided by the platform SDK.
This helper gives plugins a predictable place to write generated reports,
tables, and plots while developing.
"""

from pathlib import Path


class ArtifactStore:
    def __init__(self, root: Path = Path(".mint/artifacts")) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def path_for(self, name: str) -> Path:
        safe = name.replace("/", "_").replace("..", "_")
        return self.root / safe


artifacts = ArtifactStore()
''',
    )

    _write_if_missing(
        router_file,
        f'''"""Artifact endpoints."""

from fastapi import APIRouter

from {_module_package(plugin.module_path)}.services.artifacts import artifacts

router = APIRouter(tags=["artifacts"])


@router.get("/")
async def list_artifacts():
    return {{
        "artifacts": [
            {{"name": path.name, "size": path.stat().st_size}}
            for path in artifacts.root.glob("*")
            if path.is_file()
        ]
    }}
''',
    )
    _register_router(project_dir, plugin, "artifacts", "/artifacts")
    print("Added artifact helper and /artifacts router")


def cmd_add_hook(*, path: str = ".", hook: HookKind) -> None:
    """Insert a plugin lifecycle hook method."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    source = _plugin_source(project_dir, plugin)
    content = source.read_text()

    if hook is HookKind.before_save:
        method_name = "on_before_experiment_save"
        content = _ensure_mint_sdk_symbol(content, "LifecycleHookResult")
        block = (
            "    async def on_before_experiment_save(\n"
            "        self,\n"
            "        experiment_id: int,\n"
            "        data: dict,\n"
            "    ) -> LifecycleHookResult:\n"
            "        return LifecycleHookResult(success=True)\n\n"
        )
    elif hook is HookKind.after_save:
        method_name = "on_after_experiment_save"
        block = (
            "    async def on_after_experiment_save(self, experiment_id: int, data: dict) -> None:\n"
            "        return None\n\n"
        )
    else:
        method_name = "on_experiment_status_change"
        block = (
            "    async def on_experiment_status_change(\n"
            "        self,\n"
            "        experiment_id: int,\n"
            "        old_status: str,\n"
            "        new_status: str,\n"
            "    ) -> None:\n"
            "        return None\n\n"
        )

    if re.search(rf"async def {method_name}\(", content):
        print(f"Lifecycle hook '{method_name}' already exists.")
        return

    content = _insert_before_method(content, plugin.class_name, "async def check_health", block)
    source.write_text(content)
    print(f"Added lifecycle hook {method_name} to {source.relative_to(project_dir)}")


def cmd_add_frontend_page(*, path: str = ".", name: str) -> None:
    """Create a Vue view and register it in the scaffolded router."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    frontend_src = project_dir / "frontend" / "src"
    if not frontend_src.exists():
        print("Error: frontend/src not found. This plugin was likely scaffolded with --no-frontend.", file=sys.stderr)
        sys.exit(1)

    title = name.replace("-", " ").replace("_", " ").title()
    pascal = _pascal(name)
    route_name = _snake(name)
    route_path = f"/{route_name.replace('_', '-')}"
    view_file = frontend_src / "views" / f"{pascal}View.vue"
    page_description = "Build this page with SDK components."
    _register_plugin_nav_item(
        project_dir,
        plugin,
        route_path=route_path,
        label=title,
        icon=DEFAULT_PAGE_ICON_PATH,
        description=page_description,
    )
    _write_if_missing(
        view_file,
        f'''<script setup lang="ts">
import {{ EmptyState }} from '@morscherlab/mint-sdk'
</script>

<template>
  <EmptyState
    title="{title}"
    description="Build this page with SDK components."
    size="sm"
  />
</template>
''',
    )

    main_ts = frontend_src / "main.ts"
    if main_ts.exists():
        content = main_ts.read_text()
        route_entry = f"""  {{
    path: '{route_path}',
    name: '{route_name}',
    component: () => import('./views/{pascal}View.vue'),
  }},"""
        if f"name: '{route_name}'" not in content:
            content = content.replace("]\n\nconst router", f"{route_entry}\n]\n\nconst router")
            main_ts.write_text(content)

    app_vue = frontend_src / "App.vue"
    if app_vue.exists():
        content = app_vue.read_text()
        page_entry = (
            f"  {{ id: '{route_name}', label: '{title}', to: '{route_path}', "
            f"icon: '{DEFAULT_PAGE_ICON_PATH}', description: '{page_description}' }},"
        )
        if f"id: '{route_name}'" not in content:
            content = content.replace("]\n\nconst currentPageId", f"{page_entry}\n]\n\nconst currentPageId")
            app_vue.write_text(content)

    _handle_generate_contract(project_dir, generate=True)
    print(f"Added frontend page {view_file.relative_to(project_dir)}")


def cmd_add_frontend_composable(
    *,
    path: str = ".",
    name: str,
    endpoint: str | None = None,
) -> None:
    """Create a Vue composable wired to the plugin API prefix."""
    project_dir = Path(path).resolve()
    discover_plugin(project_dir)
    frontend_src = project_dir / "frontend" / "src"
    if not frontend_src.exists():
        print("Error: frontend/src not found. This plugin was likely scaffolded with --no-frontend.", file=sys.stderr)
        sys.exit(1)

    composable_name = f"use{_pascal(name)}"
    file_name = f"{composable_name}.ts"
    endpoint_path = endpoint or f"/{_snake(name).replace('_', '-')}"
    if not endpoint_path.startswith("/"):
        endpoint_path = f"/{endpoint_path}"
    endpoint_name = _camel(name)

    composable_file = frontend_src / "composables" / file_name
    _write_if_missing(
        composable_file,
        f'''import {{ useGeneratedPluginClient }} from '../generated/mint-plugin'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const endpointName = '{endpoint_name}' satisfies keyof PluginClient
const endpointPath = '{endpoint_path}'

export function {composable_name}() {{
  const pluginClient = useGeneratedPluginClient()

  async function call(
    ...args: Parameters<PluginClient[typeof endpointName]>
  ): ReturnType<PluginClient[typeof endpointName]> {{
    return pluginClient[endpointName](...args)
  }}

  return {{
    endpointName,
    endpointPath,
    call,
  }}
}}
''',
    )
    _handle_generate_contract(project_dir, generate=False)
    print(f"Added frontend composable {composable_file.relative_to(project_dir)}")


def cmd_add_r_analysis(
    *,
    path: str = ".",
    name: str,
    script: str | None = None,
    emit_guidance: bool = True,
    generate: bool = False,
    page: bool = False,
) -> None:
    """Create an R-backed analysis service and endpoint scaffold."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    package = _module_package(plugin.module_path)
    analysis_name = _snake(name)
    pascal = _pascal(name)

    schema_file = module_root / "schemas" / f"{analysis_name}_r.py"
    service_file = module_root / "services" / f"{analysis_name}_r.py"
    router_file = module_root / "routers" / f"{analysis_name}_r.py"

    if script is None:
        script_path = module_root / "r_scripts" / f"{analysis_name}.R"
        script_ref = f"r_scripts/{analysis_name}.R"
        _write_if_missing(module_root / "r_scripts" / "mint_bridge.R", _r_bridge_helper_template())
        _write_if_missing(script_path, _r_script_template(pascal))
    else:
        script_ref = script
        _write_if_missing(module_root / "r_scripts" / "mint_bridge.R", _r_bridge_helper_template())

    _write_if_missing(project_dir / "r-requirements.txt", "jsonlite\n")

    _write_if_missing(
        schema_file,
        f'''"""Schemas for the {analysis_name} R analysis."""

from typing import Any

from pydantic import BaseModel, Field


class {pascal}RRequest(BaseModel):
    parameters: dict[str, Any] = Field(default_factory=dict)


class {pascal}RResponse(BaseModel):
    status: str
    experiment_id: int | None = None
    result: dict[str, Any] = Field(default_factory=dict)
''',
    )

    _write_if_missing(
        service_file,
        f'''"""R-backed analysis bridge for {analysis_name}."""

from pathlib import Path

from mint_sdk import AnalysisPlugin, RAnalysisBridge, RScriptSpec

from {package}.schemas.{analysis_name}_r import {pascal}RRequest, {pascal}RResponse

_bridge: RAnalysisBridge | None = None
_plugin: AnalysisPlugin | None = None


def set_{analysis_name}_r_plugin(plugin: AnalysisPlugin) -> None:
    global _plugin
    _plugin = plugin


def get_{analysis_name}_r_plugin() -> AnalysisPlugin:
    if _plugin is None:
        raise RuntimeError("Plugin instance is not initialized yet.")
    return _plugin


def get_{analysis_name}_bridge() -> RAnalysisBridge:
    global _bridge
    if _bridge is None:
        package_root = Path(__file__).resolve().parents[1]
        _bridge = RAnalysisBridge(
            RScriptSpec(
                script="{script_ref}",
                working_dir=str(package_root),
                input_schema={pascal}RRequest,
                output_schema={pascal}RResponse,
                artifact_dir=str(Path.cwd() / ".mint" / "r-artifacts" / "{analysis_name}"),
            )
        )
    return _bridge
''',
    )

    _write_if_missing(
        router_file,
        f'''"""R analysis endpoints for {analysis_name}."""

from fastapi import APIRouter, HTTPException

from {package}.schemas.{analysis_name}_r import {pascal}RRequest, {pascal}RResponse
from {package}.services.{analysis_name}_r import get_{analysis_name}_bridge, get_{analysis_name}_r_plugin

router = APIRouter(tags=["r-analysis"])


@router.post("/run/{{experiment_id}}", response_model={pascal}RResponse)
async def run_{analysis_name}(experiment_id: int, request: {pascal}RRequest) -> {pascal}RResponse:
    plugin = _get_plugin()
    bridge = get_{analysis_name}_bridge()
    response = await bridge.run(payload=request, experiment_id=experiment_id)
    await plugin.save_analysis(experiment_id, response.result)
    return response


def _get_plugin():
    try:
        return get_{analysis_name}_r_plugin()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
''',
    )

    _register_router(project_dir, plugin, f"{analysis_name}_r", f"/r/{analysis_name.replace('_', '-')}")
    _register_template_service(project_dir, plugin, f"{analysis_name}_r")
    print(f"Added R analysis '{analysis_name}'")

    frontend_src = project_dir / "frontend" / "src"
    if frontend_src.exists():
        composable_file = frontend_src / "composables" / f"use{pascal}RAnalysis.ts"
        _write_if_missing(composable_file, _r_analysis_frontend_template(analysis_name, pascal))
        print(f"Added frontend R composable {composable_file.relative_to(project_dir)}")
        if page:
            view_file = frontend_src / "views" / f"{pascal}RAnalysisView.vue"
            _write_if_missing(view_file, _r_analysis_frontend_view_template(analysis_name, pascal))
            _register_frontend_route(
                project_dir,
                route_name=f"{analysis_name}_r_analysis",
                route_path=f"/r/{analysis_name.replace('_', '-')}",
                view_name=f"{pascal}RAnalysisView",
                label=_r_analysis_display_label(analysis_name),
                icon=ANALYSIS_PAGE_ICON_PATH,
            )
            print(f"Added frontend R analysis page {view_file.relative_to(project_dir)}")
    elif page:
        print("Skipped frontend R analysis page: frontend/src not found.", file=sys.stderr)

    if emit_guidance:
        _handle_generate_contract(project_dir, generate=generate or page)


def _r_analysis_frontend_template(analysis_name: str, pascal: str) -> str:
    endpoint_name = f"run{pascal}"
    return f"""import {{ computed, ref }} from 'vue'
import {{ useCurrentExperiment, useRequestSyncState }} from '@morscherlab/mint-sdk'
import {{ useGeneratedPluginClient }} from '../generated/mint-plugin'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>
const endpointName = '{endpoint_name}' satisfies keyof PluginClient
type RunResponse = Awaited<ReturnType<PluginClient[typeof endpointName]>>

export function use{pascal}RAnalysis() {{
  const pluginClient = useGeneratedPluginClient()
  const {{
    experimentId: currentExperimentId,
    hasExperiment,
    requireExperimentId,
  }} = useCurrentExperiment({{ immediate: false }})
  const parameters = ref<Record<string, unknown>>({{}})
  const result = ref<RunResponse | null>(null)
  const request = useRequestSyncState('R analysis request failed.')
  const loading = computed(() => request.loading.value)
  const error = computed(() => request.error.value)
  const lastRunAt = computed(() => request.lastRunAt.value)

  async function run(experimentId?: number) {{
    return request.run(
      async () => {{
        const response = await pluginClient[endpointName]({{
          ...(experimentId === undefined ? {{}} : {{ experimentId }}),
          body: {{ parameters: parameters.value }},
        }})
        result.value = response
        return response
      }},
      {{ success: 'run' }},
    )
  }}

  async function runCurrent() {{
    return run(requireExperimentId())
  }}

  async function runWithParameters(
    nextParameters: Record<string, unknown>,
    experimentId?: number,
  ) {{
    parameters.value = nextParameters
    return run(experimentId)
  }}

  async function runCurrentWithParameters(nextParameters: Record<string, unknown>) {{
    parameters.value = nextParameters
    return runCurrent()
  }}

  return {{
    currentExperimentId,
    hasExperiment,
    parameters,
    result,
    loading,
    error,
    lastRunAt,
    run,
    runCurrent,
    runWithParameters,
    runCurrentWithParameters,
  }}
}}
"""


def _r_analysis_frontend_view_template(analysis_name: str, pascal: str) -> str:
    label = _r_analysis_display_label(analysis_name)
    return f"""<script setup lang="ts">
import {{ computed, ref }} from 'vue'
import {{
  AlertBox,
  BaseButton,
  ControlWorkspaceView,
  DataFrame,
  defineControlModel,
}} from '@morscherlab/mint-sdk'
import {{ use{pascal}RAnalysis }} from '../composables/use{pascal}RAnalysis'

const workspaceModel = defineControlModel({{
  views: {{
    run: {{
      label: 'Run',
      sections: {{
        parameters: {{
          label: 'Parameters',
          description: 'Edit the JSON-native values sent to the R bridge.',
          icon: 'M4 7h16M4 12h16M4 17h10',
          controls: {{
            threshold: {{
              type: 'number',
              label: 'Threshold',
              default: 0.05,
              min: 0,
            }},
            normalize: {{
              label: 'Normalize',
              default: true,
            }},
          }},
        }},
      }},
    }},
  }},
}}

const formError = ref<string | null>(null)
const analysisValues = ref<Record<string, unknown>>({{}})
const {{
  hasExperiment,
  result,
  loading,
  error,
  lastRunAt,
  runCurrentWithParameters,
}} = use{pascal}RAnalysis()

const errorMessage = computed(() => formError.value ?? (error.value ? String(error.value) : ''))
const resultRows = computed(() =>
  Object.entries(result.value?.result ?? {{}}).map(([key, value]) => ({{
    key,
    value: formatValue(value),
  }}))
)

const resultColumns = [
  {{ key: 'key', label: 'Key', sortable: true }},
  {{ key: 'value', label: 'Value' }},
]

function runCurrentAnalysis(values: Record<string, unknown>) {{
  formError.value = null
  return runCurrentWithParameters({{ ...values }}).catch((err: unknown) => {{
    formError.value = err instanceof Error ? err.message : String(err)
    return undefined
  }})
}}

function formatValue(value: unknown): string {{
  if (value === null || value === undefined) return ''
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}}
</script>

<template>
  <ControlWorkspaceView
    v-model="analysisValues"
    :model="workspaceModel"
    title="{label}"
  >
    <template #default="{{ values }}">
      <div class="flex flex-col gap-4">
        <div class="flex items-center justify-between gap-3">
          <AlertBox type="info">
            {label} runs through the generated R bridge endpoint.
          </AlertBox>
          <BaseButton
            variant="primary"
            :loading="loading"
            :disabled="!hasExperiment"
            @click="runCurrentAnalysis(values)"
          >
            Run
          </BaseButton>
        </div>

        <p class="font-mono text-xs text-text-secondary">
          last run: {{{{ lastRunAt?.toLocaleString() ?? 'not run' }}}}
        </p>

        <AlertBox v-if="errorMessage" type="error">
          {{{{ errorMessage }}}}
        </AlertBox>

        <DataFrame
          v-if="resultRows.length"
          :data="resultRows"
          :columns="resultColumns"
          row-key="key"
          searchable
          sortable
        />
      </div>
    </template>
  </ControlWorkspaceView>
</template>
"""


def _r_analysis_display_label(analysis_name: str) -> str:
    base_label = analysis_name.replace("_", " ").title()
    return "R Analysis" if base_label == "Analysis" else f"{base_label} R Analysis"


def cmd_add_data_template(
    *,
    path: str = ".",
    template: DataTemplateKind,
    generate: bool = False,
    page: bool = False,
    _refresh_contract: bool = True,
) -> None:
    """Add importable biology template helpers to a plugin project."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    package = _module_package(plugin.module_path)
    template_name = template.value
    template_snake = template_name.replace("-", "_")
    template_pascal = _pascal(template_name)
    route_module = f"{template_snake}_template"
    route_prefix = f"/templates/{template_name}"

    template_dir = module_root / "templates"
    (template_dir / "__init__.py").parent.mkdir(parents=True, exist_ok=True)
    (template_dir / "__init__.py").touch()
    backend_file = template_dir / f"{template_snake}.py"
    _write_if_missing(backend_file, _data_template_backend_template(template))

    service_file = module_root / "services" / f"{route_module}.py"
    router_file = module_root / "routers" / f"{route_module}.py"
    _write_if_missing(service_file, _data_template_service_template(template))
    _write_if_missing(router_file, _data_template_router_template(template, package=package))
    _register_router(project_dir, plugin, route_module, route_prefix)
    _register_template_service(project_dir, plugin, route_module)

    print(f"Added data template helper {backend_file.relative_to(project_dir)}")
    print(f"Added data template API {router_file.relative_to(project_dir)} at {route_prefix}")
    print(
        f"Next: from {package}.templates.{template_snake} import "
        f"create_default_{template_snake}"
    )

    frontend_src = project_dir / "frontend" / "src"
    if frontend_src.exists():
        composable_file = frontend_src / "composables" / f"use{template_pascal}Template.ts"
        _write_if_missing(composable_file, _data_template_frontend_template(template))
        print(f"Added frontend template composable {composable_file.relative_to(project_dir)}")
        if page:
            route_name = f"{template_snake}_template"
            route_path = f"/templates/{template_name}"
            view_file = frontend_src / "views" / f"{template_pascal}TemplateView.vue"
            _write_if_missing(view_file, _data_template_frontend_view_template(template))
            _register_frontend_route(
                project_dir,
                route_name=route_name,
                route_path=route_path,
                view_name=f"{template_pascal}TemplateView",
                label=f"{template_name.replace('-', ' ').title()} Template",
                icon=TEMPLATE_PAGE_ICON_PATH,
            )
            print(f"Added frontend template page {view_file.relative_to(project_dir)}")
        if _refresh_contract:
            _handle_generate_contract(project_dir, generate=generate or page)
    elif page:
        print("Skipped frontend page: frontend/src not found.", file=sys.stderr)


def cmd_add_data_template_pack(
    *,
    path: str = ".",
    pack: DataTemplatePackKind,
    generate: bool = False,
    page: bool = False,
    _refresh_contract: bool = True,
) -> None:
    """Add a curated set of biology template helpers to a plugin project."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    package = _module_package(plugin.module_path)
    templates = _data_template_pack_templates(pack)
    pack_snake = pack.value.replace("-", "_")
    pack_pascal = _pascal(pack.value)
    route_module = f"{pack_snake}_template_pack"
    route_prefix = f"/templates/packs/{pack.value}"

    print(f"Adding data template pack '{pack.value}':")
    for template in templates:
        print(f"  - {template.value}")
        cmd_add_data_template(
            path=path,
            template=template,
            generate=False,
            page=page,
            _refresh_contract=False,
        )

    pack_helper = module_root / "templates" / f"{pack_snake}_pack.py"
    service_file = module_root / "services" / f"{route_module}.py"
    router_file = module_root / "routers" / f"{route_module}.py"
    _write_if_missing(pack_helper, _data_template_pack_backend_template(pack))
    _write_if_missing(service_file, _data_template_pack_service_template(pack))
    _write_if_missing(router_file, _data_template_pack_router_template(pack, package=package))
    _register_router(project_dir, plugin, route_module, route_prefix)
    _register_template_service(project_dir, plugin, route_module)

    print(f"Added data template pack helper {pack_helper.relative_to(project_dir)}")
    print(f"Added data template pack API {router_file.relative_to(project_dir)} at {route_prefix}")

    frontend_src = project_dir / "frontend" / "src"
    if frontend_src.exists():
        composable_file = frontend_src / "composables" / f"use{pack_pascal}TemplatePack.ts"
        _write_if_missing(composable_file, _data_template_pack_frontend_template(pack))
        print(f"Added frontend template pack composable {composable_file.relative_to(project_dir)}")
        if page:
            route_name = f"{pack_snake}_template_pack"
            route_path = f"/templates/packs/{pack.value}"
            view_file = frontend_src / "views" / f"{pack_pascal}TemplatePackView.vue"
            _write_if_missing(view_file, _data_template_pack_frontend_view_template(pack))
            _register_frontend_route(
                project_dir,
                route_name=route_name,
                route_path=route_path,
                view_name=f"{pack_pascal}TemplatePackView",
                label=f"{pack.value.replace('-', ' ').title()} Template Pack",
                icon=TEMPLATE_PAGE_ICON_PATH,
            )
            print(f"Added frontend template pack page {view_file.relative_to(project_dir)}")
        if _refresh_contract:
            _handle_generate_contract(project_dir, generate=generate or page)
    elif generate and _refresh_contract:
        _handle_generate_contract(project_dir, generate=True)


def cmd_add_data_template_preset(
    *,
    path: str = ".",
    preset: DataTemplatePresetKind,
    page: bool = False,
) -> None:
    """Add a ready-to-save biology template preset helper to a plugin project."""
    project_dir = Path(path).resolve()
    plugin = discover_plugin(project_dir)
    module_root = _module_root(project_dir, plugin)
    package = _module_package(plugin.module_path)
    preset_snake = preset.value.replace("-", "_")
    preset_pascal = _pascal(preset.value)

    template_dir = module_root / "templates"
    (template_dir / "__init__.py").parent.mkdir(parents=True, exist_ok=True)
    (template_dir / "__init__.py").touch()
    helper_file = template_dir / f"{preset_snake}_preset.py"
    _write_if_missing(helper_file, _data_template_preset_backend_template(preset))

    print(f"Added data-template preset helper {helper_file.relative_to(project_dir)}")
    print(
        f"Next: from {package}.templates.{preset_snake}_preset import "
        f"create_default_{preset_snake}_collection"
    )

    frontend_src = project_dir / "frontend" / "src"
    if frontend_src.exists():
        composable_file = frontend_src / "composables" / f"use{preset_pascal}TemplatePreset.ts"
        _write_if_missing(composable_file, _data_template_preset_frontend_template(preset))
        print(f"Added frontend template preset composable {composable_file.relative_to(project_dir)}")
        if page:
            route_name = f"{preset_snake}_template_preset"
            route_path = f"/templates/presets/{preset.value}"
            view_file = frontend_src / "views" / f"{preset_pascal}TemplatePresetView.vue"
            _write_if_missing(view_file, _data_template_preset_frontend_view_template(preset))
            _register_frontend_route(
                project_dir,
                route_name=route_name,
                route_path=route_path,
                view_name=f"{preset_pascal}TemplatePresetView",
                label=f"{preset.value.replace('-', ' ').title()} Preset",
                icon=PRESET_PAGE_ICON_PATH,
            )
            print(f"Added frontend template preset page {view_file.relative_to(project_dir)}")
            _handle_generate_contract(project_dir, generate=True)
    elif page:
        print("Skipped frontend page: frontend/src not found.", file=sys.stderr)


def _data_template_preset_backend_template(preset: DataTemplatePresetKind) -> str:
    preset_snake = preset.value.replace("-", "_")
    default_fn = f"create_default_{preset_snake}_collection"
    return f'''"""Ready-to-save template-preset helpers for {preset.value}."""

from typing import Any

from mint_sdk.templates import create_template_preset_collection

PRESET_ID = "{preset.value}"


def {default_fn}(
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return create_template_preset_collection(
        PRESET_ID,
        metadata=metadata,
    )
'''


def _data_template_backend_template(template: DataTemplateKind) -> str:
    if template is DataTemplateKind.plate_map:
        return '''"""Plate-map template helpers.

Import this helper when the plugin needs a standard well-plate design payload.
"""

from mint_sdk.templates import PlateMapTemplate


def create_default_plate_map() -> PlateMapTemplate:
    return PlateMapTemplate.create_96_well(
        name="Plate 1",
        samples=["Control", "Treatment"],
    )
'''

    if template is DataTemplateKind.sample_sheet:
        return '''"""Sample-sheet template helpers.

Import this helper when the plugin needs tabular sample metadata.
"""

from mint_sdk.templates import SampleSheetTemplate


def create_default_sample_sheet() -> SampleSheetTemplate:
    return SampleSheetTemplate.from_rows(
        [
            {"sample_id": "S001", "name": "Control 1", "group": "Control"},
            {"sample_id": "S002", "name": "Treatment 1", "group": "Treatment"},
        ]
    )
'''

    if template is DataTemplateKind.sample_prep:
        return '''"""Sample-prep template helpers.

Import this helper when the plugin needs extraction, dilution, or normalization steps.
"""

from mint_sdk.templates import SamplePrepTemplate


def create_default_sample_prep() -> SamplePrepTemplate:
    return SamplePrepTemplate.create(
        ["S001", "S002"],
        prep_type="extraction",
        output_volume=50,
    )
'''

    if template is DataTemplateKind.dose_response:
        return '''"""Dose-response template helpers.

Import this helper when the plugin needs compounds, controls, and concentrations.
"""

from mint_sdk.templates import ControlDefinition, DoseResponseTemplate


def create_default_dose_response() -> DoseResponseTemplate:
    return DoseResponseTemplate.create(
        {"Compound A": [10, 1, 0.1]},
        unit="uM",
        replicates=3,
        controls=[
            ControlDefinition(
                id="vehicle",
                name="Vehicle",
                role="vehicle",
            )
        ],
    )
'''

    if template is DataTemplateKind.calibration_curve:
        return '''"""Calibration-curve template helpers.

Import this helper when the plugin needs standards, QCs, and curve acceptance.
"""

from mint_sdk.templates import CalibrationCurveTemplate


def create_default_calibration_curve() -> CalibrationCurveTemplate:
    return CalibrationCurveTemplate.create(
        [0.1, 1, 10, 100],
        analyte="Analyte",
        unit="uM",
    )
'''

    if template is DataTemplateKind.time_course:
        return '''"""Time-course template helpers.

Import this helper when the plugin needs longitudinal time points and sample schedules.
"""

from mint_sdk.templates import TimeCourseTemplate


def create_default_time_course() -> TimeCourseTemplate:
    return TimeCourseTemplate.create(
        [0, 6, 24],
        unit="hour",
        conditions=["Control", "Treatment"],
        replicates=3,
    )
'''

    if template is DataTemplateKind.reagent_list:
        return '''"""Reagent-list template helpers.

Import this helper when the plugin needs experiment reagents, lots, and stocks.
"""

from mint_sdk.templates import ReagentListTemplate


def create_default_reagent_list() -> ReagentListTemplate:
    return ReagentListTemplate.create(
        [
            {
                "id": "dmso",
                "name": "DMSO",
                "kind": "compound",
                "storageCondition": "RT",
                "stockLevel": 80,
                "stockUnit": "%",
                "supplier": "Sigma-Aldrich",
            },
            {
                "id": "compound-a",
                "name": "Compound A",
                "kind": "compound",
                "concentration": "10 mM",
                "storageCondition": "-20C",
            },
        ]
    )
'''

    if template is DataTemplateKind.flow_cytometry_panel:
        return '''"""Flow-cytometry panel template helpers.

Import this helper when the plugin needs markers, fluorophores, detectors, and controls.
"""

from mint_sdk.templates import FlowCytometryPanelTemplate


def create_default_flow_cytometry_panel() -> FlowCytometryPanelTemplate:
    return FlowCytometryPanelTemplate.create(
        [
            {"id": "cd3", "marker": "CD3", "fluorophore": "FITC", "detector": "B530/30"},
            {"id": "cd4", "marker": "CD4", "fluorophore": "PE", "detector": "B585/42"},
            {"id": "cd8", "marker": "CD8", "fluorophore": "APC", "detector": "R660/20"},
        ],
        instrument="BD LSRFortessa",
    )
'''

    if template is DataTemplateKind.instrument_run:
        return '''"""Instrument-run template helpers.

Import this helper when the plugin needs an ordered instrument sequence table.
"""

from mint_sdk.templates import InstrumentRunTemplate


def create_default_instrument_run() -> InstrumentRunTemplate:
    return InstrumentRunTemplate.create(
        ["S001", "S002"],
        instrument="LC-MS",
        method="Default method",
    )
'''

    if template is DataTemplateKind.qpcr_plate:
        return '''"""qPCR plate template helpers.

Import this helper when the plugin needs qPCR/ddPCR plate layouts, targets, and controls.
"""

from mint_sdk.templates import QpcrPlateTemplate


def create_default_qpcr_plate() -> QpcrPlateTemplate:
    return QpcrPlateTemplate.create(
        samples=["Control", "Treatment"],
        targets=["ACTB", "GAPDH"],
        replicates=3,
        instrument="QuantStudio",
    )
'''

    if template is DataTemplateKind.protocol_steps:
        return '''"""Protocol-steps template helpers.

Import this helper when the plugin needs an ordered experiment run sheet.
"""

from mint_sdk.templates import ProtocolStepsTemplate


def create_default_protocol_steps() -> ProtocolStepsTemplate:
    return ProtocolStepsTemplate.create(
        [
            {
                "id": "seed-cells",
                "type": "addition",
                "name": "Seed cells",
                "description": "Add cells to wells or culture vessels.",
                "duration": 15,
            },
            {
                "id": "incubate-overnight",
                "type": "incubation",
                "name": "Incubate overnight",
                "duration": 960,
                "parameters": {"temperature": "37 C", "co2": "5%"},
            },
            {
                "id": "measure-readout",
                "type": "measurement",
                "name": "Measure readout",
                "duration": 45,
            },
        ]
    )
'''

    return '''"""Assay-matrix template helpers.

Import this helper when the plugin needs sample-by-feature assay readouts.
"""

from mint_sdk.templates import AssayMatrixTemplate


def create_default_assay_matrix() -> AssayMatrixTemplate:
    return AssayMatrixTemplate.create(
        samples=["S001", "S002"],
        features=["Lactate", "Glucose"],
        values={
            "s001": {"lactate": 1.2, "glucose": 5.4},
            "s002": {"lactate": 2.1, "glucose": 4.8},
        },
    )
'''


def _data_template_pack_backend_template(pack: DataTemplatePackKind) -> str:
    pack_snake = pack.value.replace("-", "_")
    default_fn = f"create_default_{pack_snake}_templates"
    collection_fn = f"create_default_{pack_snake}_collection"
    helper_imports = "\n".join(
        f"from .{template.value.replace('-', '_')} import create_default_{template.value.replace('-', '_')}"
        for template in sorted(_data_template_pack_templates(pack), key=lambda item: item.value)
    )
    default_calls = "\n".join(
        f"        create_default_{template.value.replace('-', '_')}(),"
        for template in _data_template_pack_templates(pack)
    )

    return f'''"""Template-pack helpers for {pack.value}."""

from typing import Any

from mint_sdk.templates import BioTemplate, create_template_collection

{helper_imports}


def {default_fn}() -> list[BioTemplate]:
    return [
{default_calls}
    ]


def {collection_fn}(
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return create_template_collection(
        {default_fn}(),
        metadata=metadata,
    )
'''


def _data_template_service_template(template: DataTemplateKind) -> str:
    template_name = template.value.replace("-", " ")
    template_snake = template.value.replace("-", "_")
    return f'''"""Service binding for the {template_name} data-template routes."""

from mint_sdk import AnalysisPlugin

_plugin: AnalysisPlugin | None = None


def set_{template_snake}_template_plugin(plugin: AnalysisPlugin) -> None:
    global _plugin
    _plugin = plugin


def get_{template_snake}_template_plugin() -> AnalysisPlugin:
    if _plugin is None:
        raise RuntimeError("Plugin instance is not initialized yet.")
    return _plugin
'''


def _data_template_pack_service_template(pack: DataTemplatePackKind) -> str:
    pack_name = pack.value.replace("-", " ")
    pack_snake = pack.value.replace("-", "_")
    return f'''"""Service binding for the {pack_name} data-template pack routes."""

from mint_sdk import AnalysisPlugin

_plugin: AnalysisPlugin | None = None


def set_{pack_snake}_template_pack_plugin(plugin: AnalysisPlugin) -> None:
    global _plugin
    _plugin = plugin


def get_{pack_snake}_template_pack_plugin() -> AnalysisPlugin:
    if _plugin is None:
        raise RuntimeError("Plugin instance is not initialized yet.")
    return _plugin
'''


def _python_string_literal(value: str, *, indent: int = 8, width: int = 80) -> str:
    literal = repr(value)
    if indent + len(literal) <= 100:
        return literal

    chunks = textwrap.wrap(value, width=width, break_on_hyphens=False)
    lines = ["("]
    for index, chunk in enumerate(chunks):
        suffix = " " if index < len(chunks) - 1 else ""
        lines.append(f"{' ' * (indent + 4)}{chunk + suffix!r}")
    lines.append(f"{' ' * indent})")
    return "\n".join(lines)


def _python_string_list_literal(values: list[str], *, indent: int = 8) -> str:
    lines = ["["]
    lines.extend(f"{' ' * (indent + 4)}{value!r}," for value in values)
    lines.append(f"{' ' * indent}]")
    return "\n".join(lines)


def _data_template_router_template(template: DataTemplateKind, *, package: str) -> str:
    template_snake = template.value.replace("-", "_")
    template_pascal = _pascal(template.value)
    create_fn = f"create_default_{template_snake}"
    get_plugin_fn = f"get_{template_snake}_template_plugin"
    template_class = {
        DataTemplateKind.plate_map: "PlateMapTemplate",
        DataTemplateKind.sample_sheet: "SampleSheetTemplate",
        DataTemplateKind.sample_prep: "SamplePrepTemplate",
        DataTemplateKind.dose_response: "DoseResponseTemplate",
        DataTemplateKind.calibration_curve: "CalibrationCurveTemplate",
        DataTemplateKind.time_course: "TimeCourseTemplate",
        DataTemplateKind.protocol_steps: "ProtocolStepsTemplate",
        DataTemplateKind.assay_matrix: "AssayMatrixTemplate",
        DataTemplateKind.reagent_list: "ReagentListTemplate",
        DataTemplateKind.flow_cytometry_panel: "FlowCytometryPanelTemplate",
        DataTemplateKind.instrument_run: "InstrumentRunTemplate",
        DataTemplateKind.qpcr_plate: "QpcrPlateTemplate",
    }[template]

    return f'''"""Save and load endpoints for the {template.value} data template."""

from typing import Any, Literal

from fastapi import APIRouter, HTTPException
from mint_sdk.templates import (
    {template_class},
    load_template,
    require_template_info,
    save_template,
)
from pydantic import BaseModel, Field

from {package}.services.{template_snake}_template import (
    {get_plugin_fn},
)
from {package}.templates.{template_snake} import (
    {create_fn},
)

router = APIRouter(tags=["data-template"])


class {template_pascal}TemplateEnvelope(BaseModel):
    template_id: Literal["{template.value}"]
    template_version: str = "1.0"
    kind: str = "experiment-design"
    data: {template_class}
    metadata: dict[str, Any] = Field(default_factory=dict)


class Save{template_pascal}TemplateRequest(BaseModel):
    template: {template_pascal}TemplateEnvelope | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class {template_pascal}TemplateResponse(BaseModel):
    experiment_id: int
    template: {template_pascal}TemplateEnvelope
    persisted: bool


class {template_pascal}TemplateSchemaResponse(BaseModel):
    template_id: str
    template_version: str
    label: str
    purpose: str
    frontend_adapters: list[str]
    components: list[str]
    json_schema: dict[str, Any]
    default_template: {template_pascal}TemplateEnvelope


@router.get("/schema", response_model={template_pascal}TemplateSchemaResponse)
async def get_{template_snake}_template_schema():
    info = require_template_info("{template.value}")
    default_template = {create_fn}()
    return {template_pascal}TemplateSchemaResponse(
        template_id=info.template_id,
        template_version=info.template_version,
        label=info.label,
        purpose=info.purpose,
        frontend_adapters=list(info.frontend_adapters),
        components=list(info.components),
        json_schema={template_class}.model_json_schema(),
        default_template=default_template.to_design_data(),
    )


@router.get("/{{experiment_id}}", response_model={template_pascal}TemplateResponse)
async def get_{template_snake}_template(experiment_id: int):
    plugin = _get_plugin()
    loaded = await load_template(plugin, experiment_id, {template_class})
    template = loaded or {create_fn}()
    return {template_pascal}TemplateResponse(
        experiment_id=experiment_id,
        template=template.to_design_data(),
        persisted=loaded is not None,
    )


@router.post("/{{experiment_id}}", response_model={template_pascal}TemplateResponse)
async def save_{template_snake}_template(
    experiment_id: int,
    request: Save{template_pascal}TemplateRequest,
):
    plugin = _get_plugin()
    request_template = (
        request.template.model_dump(mode="json")
        if request.template is not None
        else None
    )
    template = (
        {template_class}.from_design_data(request_template)
        if request_template is not None
        else {create_fn}()
    )
    saved = await save_template(
        plugin,
        experiment_id,
        template,
        metadata=request.metadata,
        merge=True,
    )
    return {template_pascal}TemplateResponse(
        experiment_id=experiment_id,
        template=template.to_design_data(metadata=request.metadata),
        persisted=saved is not None,
    )


def _get_plugin():
    try:
        return {get_plugin_fn}()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
'''


def _data_template_pack_router_template(pack: DataTemplatePackKind, *, package: str) -> str:
    pack_snake = pack.value.replace("-", "_")
    pack_pascal = _pascal(pack.value)
    info = _data_template_pack_entry(pack)
    template_ids = [template.value for template in _data_template_pack_templates(pack)]
    template_ids_literal = _python_string_list_literal(template_ids)
    label_literal = _python_string_literal(info.label)
    purpose_literal = _python_string_literal(info.purpose)
    default_templates_fn = f"create_default_{pack_snake}_templates"
    default_collection_fn = f"create_default_{pack_snake}_collection"
    get_plugin_fn = f"get_{pack_snake}_template_pack_plugin"

    return f'''"""Save and load endpoints for the {pack.value} data-template pack."""

from typing import Any

from fastapi import APIRouter, HTTPException
from mint_sdk.templates import (
    BioTemplateEnvelope,
    extract_template_collection,
    load_template_collection,
    save_template_collection,
)
from pydantic import BaseModel, Field

from {package}.services.{pack_snake}_template_pack import (
    {get_plugin_fn},
)
from {package}.templates.{pack_snake}_pack import (
    {default_collection_fn},
    {default_templates_fn},
)

router = APIRouter(tags=["data-template-pack"])


class Save{pack_pascal}TemplatePackRequest(BaseModel):
    templates: dict[str, BioTemplateEnvelope] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class {pack_pascal}TemplatePackResponse(BaseModel):
    experiment_id: int
    templates: dict[str, BioTemplateEnvelope]
    metadata: dict[str, Any] = Field(default_factory=dict)
    persisted: bool


class {pack_pascal}TemplatePackSchemaResponse(BaseModel):
    pack_id: str
    label: str
    purpose: str
    template_ids: list[str]
    default_collection: dict[str, Any]


@router.get("/schema", response_model={pack_pascal}TemplatePackSchemaResponse)
async def get_{pack_snake}_template_pack_schema():
    return {pack_pascal}TemplatePackSchemaResponse(
        pack_id="{pack.value}",
        label={label_literal},
        purpose={purpose_literal},
        template_ids={template_ids_literal},
        default_collection={default_collection_fn}(
            metadata={{"pack": "{pack.value}"}},
        ),
    )


@router.get("/{{experiment_id}}", response_model={pack_pascal}TemplatePackResponse)
async def get_{pack_snake}_template_pack(experiment_id: int):
    plugin = _get_plugin()
    templates = extract_template_collection({default_collection_fn}())
    loaded = await load_template_collection(plugin, experiment_id)
    templates.update(loaded)
    return {pack_pascal}TemplatePackResponse(
        experiment_id=experiment_id,
        templates=templates,
        persisted=bool(loaded),
    )


@router.post("/{{experiment_id}}", response_model={pack_pascal}TemplatePackResponse)
async def save_{pack_snake}_template_pack(
    experiment_id: int,
    request: Save{pack_pascal}TemplatePackRequest,
):
    plugin = _get_plugin()
    if request.templates is None:
        templates = {default_templates_fn}()
        response_templates = extract_template_collection(
            {default_collection_fn}(metadata=request.metadata)
        )
    else:
        response_templates = extract_template_collection(request.model_dump(mode="json"))
        templates = list(response_templates.values())

    saved = await save_template_collection(
        plugin,
        experiment_id,
        templates,
        metadata=request.metadata,
    )
    return {pack_pascal}TemplatePackResponse(
        experiment_id=experiment_id,
        templates=response_templates,
        metadata=request.metadata,
        persisted=saved is not None,
    )


def _get_plugin():
    try:
        return {get_plugin_fn}()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
'''


def _data_template_pack_frontend_template(pack: DataTemplatePackKind) -> str:
    pack_pascal = _pascal(pack.value)
    schema_endpoint = f"get{pack_pascal}TemplatePackSchema"
    get_endpoint = f"get{pack_pascal}TemplatePack"
    save_endpoint = f"save{pack_pascal}TemplatePack"
    templates = _data_template_pack_templates(pack)
    template_imports = "\n".join(
        f"  type {_pascal(template.value)}Template,"
        for template in templates
    )
    typed_getters = "\n".join(
        f"  const {_camel(template.value)} = computed(() =>\n"
        f"    ensureTemplateFromCollection<{_pascal(template.value)}Template>(\n"
        "      collection.value,\n"
        f"      '{template.value}',\n"
        "    )\n"
        "  )"
        for template in templates
    )
    returned_getters = "\n".join(f"    {_camel(template.value)}," for template in templates)

    save_request_type = f"Save{pack_pascal}TemplatePackRequest"

    return f"""import {{ computed, ref }} from 'vue'
import {{
  useBioTemplatePackWorkspace,
  useRequestSyncState,
}} from '@morscherlab/mint-sdk'
import {{
  useGeneratedPluginClient,
  type {save_request_type},
}} from '../generated/mint-plugin'
import {{
{template_imports}
  ensureTemplateFromCollection,
  type TemplateCollectionEnvelope,
  type TemplatePackId,
}} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const packId = '{pack.value}' satisfies TemplatePackId
const schemaEndpointName = '{schema_endpoint}' satisfies keyof PluginClient
const getEndpointName = '{get_endpoint}' satisfies keyof PluginClient
const saveEndpointName = '{save_endpoint}' satisfies keyof PluginClient
type SaveTemplateMap = NonNullable<{save_request_type}['templates']>

export function use{pack_pascal}TemplatePack() {{
  const pluginClient = useGeneratedPluginClient()
  const workspace = useBioTemplatePackWorkspace(packId)
  const templates = workspace.collection
  const collection = computed(() => workspace.collection.value)
  const currentExperimentId = computed(() => workspace.currentExperimentId.value)
  const hasExperiment = computed(() => workspace.hasCurrentExperiment.value)
  const request = useRequestSyncState('Template pack request failed.')
  const loading = computed(() => request.loading.value)
  const error = computed(() => request.error.value)
  const lastLoadedAt = computed(() => request.lastLoadedAt.value)
  const lastSavedAt = computed(() => request.lastSavedAt.value)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

{typed_getters}

  function applyTemplateCollection(
    value: unknown,
    metadata: Record<string, unknown> = {{}},
  ): TemplateCollectionEnvelope {{
    return workspace.applyCollection(value, metadata)
  }}

  function createSaveRequest(): {save_request_type} {{
    const saveTemplates = collection.value.templates as SaveTemplateMap
    return {{
      templates: saveTemplates,
      metadata: collection.value.metadata ?? {{}},
    }}
  }}

  async function loadSchema() {{
    return request.run(async () => {{
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    }})
  }}

  async function resetToDefaultTemplates() {{
    const response = schema.value ?? await loadSchema()
    return applyTemplateCollection(
      response.default_collection,
      {{ pack: '{pack.value}' }},
    )
  }}

  async function load(experimentId?: number) {{
    return request.run(async () => {{
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : {{ experimentId }}
      )
      applyTemplateCollection({{
        templates: response.templates,
        metadata: response.metadata,
      }})
      return response
    }}, {{ success: 'load' }})
  }}

  async function loadCurrent() {{
    return load(workspace.requireCurrentExperimentId())
  }}

  async function save(experimentId?: number) {{
    return request.run(async () => {{
      const response = await pluginClient[saveEndpointName]({{
        ...(experimentId === undefined ? {{}} : {{ experimentId }}),
        body: createSaveRequest(),
      }})
      return response
    }}, {{ success: 'save' }})
  }}

  async function saveCurrent() {{
    return save(workspace.requireCurrentExperimentId())
  }}

  return {{
    workspace,
    currentExperimentId,
    hasExperiment,
    templates,
    collection,
    loading,
    error,
    lastLoadedAt,
    lastSavedAt,
    schema,
{returned_getters}
    applyTemplateCollection,
    loadSchema,
    resetToDefaultTemplates,
    load,
    loadCurrent,
    save,
    saveCurrent,
  }}
}}
"""


def _data_template_pack_frontend_view_template(pack: DataTemplatePackKind) -> str:
    pack_pascal = _pascal(pack.value)
    pack_label = pack.value.replace("-", " ").title()
    return f"""<script setup lang="ts">
import {{ watch }} from 'vue'
import {{ BioTemplatePackWorkspaceView }} from '@morscherlab/mint-sdk'
import {{ use{pack_pascal}TemplatePack }} from '../composables/use{pack_pascal}TemplatePack'

const {{
  workspace,
  currentExperimentId,
  hasExperiment,
  loading,
  error,
  lastLoadedAt,
  lastSavedAt,
  resetToDefaultTemplates,
  loadCurrent,
  saveCurrent,
}} = use{pack_pascal}TemplatePack()

watch(
  currentExperimentId,
  (experimentId) => {{
    if (experimentId !== undefined) {{
      void loadCurrent().catch(() => undefined)
    }}
  }},
  {{ immediate: true }},
)
</script>

<template>
  <BioTemplatePackWorkspaceView
    :workspace="workspace"
    label="{pack_label}"
    :status="{{
      loading,
      error,
      hasExperiment,
      currentExperimentId,
      lastLoadedAt,
      lastSavedAt,
    }}"
    :actions="{{
      load: loadCurrent,
      reset: resetToDefaultTemplates,
      save: saveCurrent,
    }}"
    show-template-summary
  />
</template>
"""


def _data_template_preset_frontend_template(preset: DataTemplatePresetKind) -> str:
    preset_pascal = _pascal(preset.value)
    return f"""import {{
  useBioTemplatePresetWorkspace,
  type UseBioTemplatePresetWorkspaceOptions,
}} from '@morscherlab/mint-sdk'
import {{
  type TemplatePresetId,
}} from '@morscherlab/mint-sdk/templates'

const presetId = '{preset.value}' satisfies TemplatePresetId

export function use{preset_pascal}TemplatePreset(options: UseBioTemplatePresetWorkspaceOptions = {{}}) {{
  return useBioTemplatePresetWorkspace(presetId, options)
}}
"""


def _data_template_preset_frontend_view_template(preset: DataTemplatePresetKind) -> str:
    label = preset.value.replace("-", " ").title()
    return f"""<script setup lang="ts">
import {{ BioTemplatePresetWorkspaceView }} from '@morscherlab/mint-sdk'
</script>

<template>
  <BioTemplatePresetWorkspaceView
    preset="{preset.value}"
    label="{label}"
  />
</template>
"""


def _with_current_experiment_template_helpers(source: str) -> str:
    source = (
        source.replace(
            "import { useGeneratedPluginClient } from '../generated/mint-plugin'\n",
            (
                "import { useCurrentExperiment, useRequestSyncState } from '@morscherlab/mint-sdk'\n"
                "import { useGeneratedPluginClient } from '../generated/mint-plugin'\n"
            ),
        )
        .replace(
            "  const pluginClient = useGeneratedPluginClient()\n",
            (
                "  const pluginClient = useGeneratedPluginClient()\n"
                "  const {\n"
                "    experimentId: currentExperimentId,\n"
                "    hasExperiment,\n"
                "    requireExperimentId,\n"
                "  } = useCurrentExperiment({ immediate: false })\n"
            ),
        )
        .replace(
            "\n  async function save(experimentId?: number) {\n",
            (
                "\n  async function loadCurrent() {\n"
                "    const response = await load(requireExperimentId())\n"
                "    return response\n"
                "  }\n"
                "\n  async function save(experimentId?: number) {\n"
            ),
        )
        .replace(
            "  const loading = ref(false)\n",
            (
                "  const request = useRequestSyncState('Template request failed.')\n"
                "  const loading = computed(() => request.loading.value)\n"
                "  const error = computed(() => request.error.value)\n"
                "  const lastLoadedAt = computed(() => request.lastLoadedAt.value)\n"
                "  const lastSavedAt = computed(() => request.lastSavedAt.value)\n"
            ),
        )
        .replace(
            "    loading.value = true\n    try {\n",
            "    return request.run(async () => {\n",
        )
        .replace(
            "    } finally {\n      loading.value = false\n    }\n",
            "    })\n",
        )
        .replace(
            "\n  return {\n    template,\n",
            (
                "\n  async function saveCurrent() {\n"
                "    const response = await save(requireExperimentId())\n"
                "    return response\n"
                "  }\n"
                "\n  return {\n"
                "    currentExperimentId,\n"
                "    hasExperiment,\n"
                "    template,\n"
            ),
        )
        .replace(
            "    loading,\n    schema,\n",
            "    loading,\n    error,\n    lastLoadedAt,\n    lastSavedAt,\n    schema,\n",
        )
        .replace(
            "    load,\n    save,\n",
            "    load,\n    loadCurrent,\n    save,\n    saveCurrent,\n",
        )
    )
    return (
        source
        .replace(
            "      return response\n    })\n  }\n\n  async function loadCurrent()",
            "      request.markLoaded()\n      return response\n    })\n  }\n\n  async function loadCurrent()",
        )
        .replace(
            "      return await pluginClient[saveEndpointName]({",
            "      const response = await pluginClient[saveEndpointName]({",
        )
        .replace(
            "        body: { template: template.value },\n      })\n    })",
            (
                "        body: { template: template.value },\n"
                "      })\n"
                "      request.markSaved()\n"
                "      return response\n"
                "    })"
            ),
        )
    )


def _data_template_frontend_template(template: DataTemplateKind) -> str:
    if template is DataTemplateKind.plate_map:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type PlateMapTemplate,
  createPlateMapTemplate,
  ensureTemplateEnvelope,
  toPlateMapEditorState,
  toWellPlateWells,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getPlateMapTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getPlateMapTemplate' satisfies keyof PluginClient
const saveEndpointName = 'savePlateMapTemplate' satisfies keyof PluginClient

export function usePlateMapTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createPlateMapTemplate({
    name: 'Plate 1',
    samples: ['Control', 'Treatment'],
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const plateEditorState = computed(() => toPlateMapEditorState(template.value))
  const wells = computed(() => toWellPlateWells(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<PlateMapTemplate>(response.default_template, 'plate-map')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<PlateMapTemplate>(response.template, 'plate-map')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    plateEditorState,
    wells,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.sample_sheet:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type SampleSheetTemplate,
  createSampleSheetTemplate,
  ensureTemplateEnvelope,
  toSampleOptions,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getSampleSheetTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getSampleSheetTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveSampleSheetTemplate' satisfies keyof PluginClient

export function useSampleSheetTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createSampleSheetTemplate({
    samples: [
      {
        sampleId: 'S001',
        name: 'Control 1',
        group: 'Control',
      },
      {
        sampleId: 'S002',
        name: 'Treatment 1',
        group: 'Treatment',
      },
    ],
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toTemplateDataFrame(template.value))
  const options = computed(() => toSampleOptions(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<SampleSheetTemplate>(response.default_template, 'sample-sheet')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<SampleSheetTemplate>(response.template, 'sample-sheet')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    options,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.sample_prep:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type SamplePrepTemplate,
  createSamplePrepTemplate,
  ensureTemplateEnvelope,
  toSamplePrepDataFrame,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getSamplePrepTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getSamplePrepTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveSamplePrepTemplate' satisfies keyof PluginClient

export function useSamplePrepTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createSamplePrepTemplate({
    samples: ['S001', 'S002'],
    prepType: 'extraction',
    outputVolume: 50,
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toSamplePrepDataFrame(template.value))
  const genericDataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<SamplePrepTemplate>(response.default_template, 'sample-prep')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<SamplePrepTemplate>(response.template, 'sample-prep')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    genericDataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.dose_response:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type DoseResponseTemplate,
  createDoseResponseTemplate,
  ensureTemplateEnvelope,
  toDoseConditions,
  toDoseLayoutState,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getDoseResponseTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getDoseResponseTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveDoseResponseTemplate' satisfies keyof PluginClient

export function useDoseResponseTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createDoseResponseTemplate({
    compounds: {
      'Compound A': [10, 1, 0.1],
    },
    unit: 'uM',
    replicates: 3,
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const conditions = computed(() => toDoseConditions(template.value))
  const layout = computed(() => toDoseLayoutState(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<DoseResponseTemplate>(response.default_template, 'dose-response')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<DoseResponseTemplate>(response.template, 'dose-response')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    conditions,
    layout,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.calibration_curve:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type CalibrationCurveTemplate,
  createCalibrationCurveTemplate,
  ensureTemplateEnvelope,
  toCalibrationCurveDataFrame,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getCalibrationCurveTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getCalibrationCurveTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveCalibrationCurveTemplate' satisfies keyof PluginClient

export function useCalibrationCurveTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createCalibrationCurveTemplate({
    concentrations: [0.1, 1, 10, 100],
    analyte: 'Analyte',
    unit: 'uM',
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toCalibrationCurveDataFrame(template.value))
  const genericDataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<CalibrationCurveTemplate>(response.default_template, 'calibration-curve')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<CalibrationCurveTemplate>(response.template, 'calibration-curve')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    genericDataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.time_course:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type TimeCourseTemplate,
  createTimeCourseTemplate,
  ensureTemplateEnvelope,
  toTemplateDataFrame,
  toTimeCourseSteps,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getTimeCourseTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getTimeCourseTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveTimeCourseTemplate' satisfies keyof PluginClient

export function useTimeCourseTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createTimeCourseTemplate({
    timepoints: [0, 6, 24],
    unit: 'hour',
    conditions: ['Control', 'Treatment'],
    replicates: 3,
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toTemplateDataFrame(template.value))
  const steps = computed(() => toTimeCourseSteps(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<TimeCourseTemplate>(response.default_template, 'time-course')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<TimeCourseTemplate>(response.template, 'time-course')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    steps,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.reagent_list:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type ReagentListTemplate,
  createReagentListTemplate,
  ensureTemplateEnvelope,
  toReagentListItems,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getReagentListTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getReagentListTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveReagentListTemplate' satisfies keyof PluginClient

export function useReagentListTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createReagentListTemplate({
    reagents: [
      {
        id: 'dmso',
        name: 'DMSO',
        kind: 'compound',
        storageCondition: 'RT',
        stockLevel: 80,
        stockUnit: '%',
        supplier: 'Sigma-Aldrich',
      },
      {
        id: 'compound-a',
        name: 'Compound A',
        kind: 'compound',
        concentration: '10 mM',
        storageCondition: '-20C',
      },
    ],
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const items = computed(() => toReagentListItems(template.value))
  const dataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<ReagentListTemplate>(response.default_template, 'reagent-list')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<ReagentListTemplate>(response.template, 'reagent-list')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    items,
    dataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.flow_cytometry_panel:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type FlowCytometryPanelTemplate,
  createFlowCytometryPanelTemplate,
  ensureTemplateEnvelope,
  toFlowPanelDataFrame,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getFlowCytometryPanelTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getFlowCytometryPanelTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveFlowCytometryPanelTemplate' satisfies keyof PluginClient

export function useFlowCytometryPanelTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createFlowCytometryPanelTemplate({
    markers: [
      { id: 'cd3', marker: 'CD3', fluorophore: 'FITC', detector: 'B530/30' },
      { id: 'cd4', marker: 'CD4', fluorophore: 'PE', detector: 'B585/42' },
      { id: 'cd8', marker: 'CD8', fluorophore: 'APC', detector: 'R660/20' },
    ],
    instrument: 'BD LSRFortessa',
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toFlowPanelDataFrame(template.value))
  const genericDataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<FlowCytometryPanelTemplate>(
      response.default_template,
      'flow-cytometry-panel'
    )
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<FlowCytometryPanelTemplate>(
        response.template,
        'flow-cytometry-panel'
      )
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    genericDataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.instrument_run:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type InstrumentRunTemplate,
  createInstrumentRunTemplate,
  ensureTemplateEnvelope,
  toInstrumentRunDataFrame,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getInstrumentRunTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getInstrumentRunTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveInstrumentRunTemplate' satisfies keyof PluginClient

export function useInstrumentRunTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createInstrumentRunTemplate({
    items: ['S001', 'S002'],
    instrument: 'LC-MS',
    method: 'Default method',
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toInstrumentRunDataFrame(template.value))
  const genericDataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<InstrumentRunTemplate>(response.default_template, 'instrument-run')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<InstrumentRunTemplate>(response.template, 'instrument-run')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    genericDataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.qpcr_plate:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type QpcrPlateTemplate,
  createQpcrPlateTemplate,
  ensureTemplateEnvelope,
  toQpcrDataFrame,
  toQpcrWellPlateWells,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getQpcrPlateTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getQpcrPlateTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveQpcrPlateTemplate' satisfies keyof PluginClient

export function useQpcrPlateTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createQpcrPlateTemplate({
    samples: ['Control', 'Treatment'],
    targets: ['ACTB', 'GAPDH'],
    replicates: 3,
    instrument: 'QuantStudio',
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toQpcrDataFrame(template.value))
  const genericDataFrame = computed(() => toTemplateDataFrame(template.value))
  const wells = computed(() => toQpcrWellPlateWells(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<QpcrPlateTemplate>(response.default_template, 'qpcr-plate')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<QpcrPlateTemplate>(response.template, 'qpcr-plate')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    genericDataFrame,
    wells,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    if template is DataTemplateKind.protocol_steps:
        return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type ProtocolStepsTemplate,
  createProtocolStepsTemplate,
  ensureTemplateEnvelope,
  toProtocolSteps,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getProtocolStepsTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getProtocolStepsTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveProtocolStepsTemplate' satisfies keyof PluginClient

export function useProtocolStepsTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createProtocolStepsTemplate({
    steps: [
      {
        id: 'seed-cells',
        type: 'addition',
        name: 'Seed cells',
        description: 'Add cells to wells or culture vessels.',
        duration: 15,
      },
      {
        id: 'incubate-overnight',
        type: 'incubation',
        name: 'Incubate overnight',
        duration: 960,
        parameters: { temperature: '37 C', co2: '5%' },
      },
      {
        id: 'measure-readout',
        type: 'measurement',
        name: 'Measure readout',
        duration: 45,
      },
    ],
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const steps = computed(() => toProtocolSteps(template.value))
  const dataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<ProtocolStepsTemplate>(response.default_template, 'protocol-steps')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<ProtocolStepsTemplate>(response.template, 'protocol-steps')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    steps,
    dataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

    return _with_current_experiment_template_helpers("""import { computed, ref } from 'vue'
import { useGeneratedPluginClient } from '../generated/mint-plugin'
import {
  type AssayMatrixTemplate,
  createAssayMatrixTemplate,
  ensureTemplateEnvelope,
  toTemplateDataFrame,
} from '@morscherlab/mint-sdk/templates'

type PluginClient = ReturnType<typeof useGeneratedPluginClient>

const schemaEndpointName = 'getAssayMatrixTemplateSchema' satisfies keyof PluginClient
const getEndpointName = 'getAssayMatrixTemplate' satisfies keyof PluginClient
const saveEndpointName = 'saveAssayMatrixTemplate' satisfies keyof PluginClient

export function useAssayMatrixTemplate() {
  const pluginClient = useGeneratedPluginClient()
  const template = ref(createAssayMatrixTemplate({
    samples: ['S001', 'S002'],
    features: ['Lactate', 'Glucose'],
    values: {
      s001: { lactate: 1.2, glucose: 5.4 },
      s002: { lactate: 2.1, glucose: 4.8 },
    },
  }))
  const loading = ref(false)
  const schema = ref<Awaited<ReturnType<PluginClient[typeof schemaEndpointName]>> | null>(null)

  const dataFrame = computed(() => toTemplateDataFrame(template.value))

  async function loadSchema() {
    loading.value = true
    try {
      const response = await pluginClient[schemaEndpointName]()
      schema.value = response
      return response
    } finally {
      loading.value = false
    }
  }

  async function resetToDefaultTemplate() {
    const response = schema.value ?? await loadSchema()
    template.value = ensureTemplateEnvelope<AssayMatrixTemplate>(response.default_template, 'assay-matrix')
    return template.value
  }

  async function load(experimentId?: number) {
    loading.value = true
    try {
      const response = await pluginClient[getEndpointName](
        experimentId === undefined ? undefined : { experimentId }
      )
      template.value = ensureTemplateEnvelope<AssayMatrixTemplate>(response.template, 'assay-matrix')
      return response
    } finally {
      loading.value = false
    }
  }

  async function save(experimentId?: number) {
    loading.value = true
    try {
      return await pluginClient[saveEndpointName]({
        ...(experimentId === undefined ? {} : { experimentId }),
        body: { template: template.value },
      })
    } finally {
      loading.value = false
    }
  }

  return {
    template,
    loading,
    schema,
    dataFrame,
    loadSchema,
    resetToDefaultTemplate,
    load,
    save,
  }
}
""")

def _data_template_frontend_view_template(template: DataTemplateKind) -> str:
    template_pascal = _pascal(template.value)
    template_label = template.value.replace("-", " ").title()
    return f"""<script setup lang="ts">
import {{ watch }} from 'vue'
import {{ BioTemplateExperimentWorkspaceView }} from '@morscherlab/mint-sdk'
import {{ use{template_pascal}Template }} from '../composables/use{template_pascal}Template'

const {{
  currentExperimentId,
  hasExperiment,
  template,
  loading,
  error,
  lastLoadedAt,
  lastSavedAt,
  loadCurrent,
  saveCurrent,
  resetToDefaultTemplate,
}} = use{template_pascal}Template()

watch(
  currentExperimentId,
  (experimentId) => {{
    if (experimentId !== undefined) {{
      void loadCurrent().catch(() => undefined)
    }}
  }},
  {{ immediate: true }},
)
</script>

<template>
  <BioTemplateExperimentWorkspaceView
    :target="template"
    label="{template_label}"
    :status="{{
      loading,
      error,
      hasExperiment,
      currentExperimentId,
      lastLoadedAt,
      lastSavedAt,
    }}"
    :actions="{{
      load: loadCurrent,
      reset: resetToDefaultTemplate,
      save: saveCurrent,
    }}"
  />
</template>
"""

def _plugin_source(project_dir: Path, plugin: DiscoveredPlugin) -> Path:
    parts = plugin.module_path.split(".")
    candidates = [
        project_dir / "src" / Path(*parts).with_suffix(".py"),
        project_dir / Path(*parts).with_suffix(".py"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    print(f"Error: could not find source file for {plugin.module_path}", file=sys.stderr)
    sys.exit(1)


def _module_root(project_dir: Path, plugin: DiscoveredPlugin) -> Path:
    source = _plugin_source(project_dir, plugin)
    return source.parent


def _module_package(module_path: str) -> str:
    return ".".join(module_path.split(".")[:-1])


def _settings_class_name(plugin_class_name: str) -> str:
    base = plugin_class_name.removesuffix("Plugin")
    return f"{base}Settings"


def _ensure_import(content: str, import_line: str) -> str:
    if import_line in content:
        return content
    lines = content.splitlines()

    if _is_third_party_import(import_line):
        for idx, line in enumerate(lines):
            if _is_likely_first_party_import(line):
                insert_at = idx - 1 if idx > 0 and lines[idx - 1] == "" else idx
                lines.insert(insert_at, import_line)
                return "\n".join(lines) + "\n"

    if _is_likely_first_party_import(import_line):
        return _insert_first_party_import(lines, import_line)

    insert_at = 0
    for idx, line in enumerate(lines):
        if line.startswith("from ") or line.startswith("import "):
            insert_at = idx + 1
    lines.insert(insert_at, import_line)
    return "\n".join(lines) + "\n"


def _ensure_grouped_import_member(content: str, module: str, member: str) -> str:
    """Ensure ``from module import (member,)`` style imports without long lines."""
    block_pattern = rf"from {re.escape(module)} import \(\n(?P<body>.*?\n)\)"
    block_match = re.search(block_pattern, content, flags=re.DOTALL)
    if block_match:
        body = block_match.group("body")
        members = {
            line.strip().removesuffix(",")
            for line in body.splitlines()
            if line.strip()
        }
        if member in members:
            return content
        members.add(member)
        rendered = "\n".join(f"    {item}," for item in sorted(members))
        return (
            content[: block_match.start()]
            + f"from {module} import (\n{rendered}\n)"
            + content[block_match.end():]
        )

    single_line_pattern = rf"^from {re.escape(module)} import (?P<member>.+)$"
    single_line_match = re.search(single_line_pattern, content, flags=re.MULTILINE)
    if single_line_match:
        members = {single_line_match.group("member").strip(), member}
        rendered = "\n".join(f"    {item}," for item in sorted(members))
        return (
            content[: single_line_match.start()]
            + f"from {module} import (\n{rendered}\n)"
            + content[single_line_match.end():]
        )

    return _ensure_import(content, f"from {module} import (\n    {member},\n)")


def _ensure_split_grouped_import_member(content: str, module: str, member: str) -> str:
    """Ensure isort-compatible one-member grouped imports for aliased imports."""
    members: set[str] = set()
    spans: list[tuple[int, int]] = []
    first_start: int | None = None

    block_pattern = rf"from {re.escape(module)} import \(\n(?P<body>.*?\n)\)\n?"
    for match in re.finditer(block_pattern, content, flags=re.DOTALL):
        if first_start is None:
            first_start = match.start()
        spans.append((match.start(), match.end()))
        members.update(
            line.strip().removesuffix(",")
            for line in match.group("body").splitlines()
            if line.strip()
        )

    single_line_pattern = rf"^from {re.escape(module)} import (?P<member>[^(].+)\n?"
    for match in re.finditer(single_line_pattern, content, flags=re.MULTILINE):
        if first_start is None:
            first_start = match.start()
        spans.append((match.start(), match.end()))
        members.add(match.group("member").strip())

    if not spans:
        return _ensure_import(content, f"from {module} import (\n    {member},\n)")

    members.add(member)
    rendered = "\n".join(
        f"from {module} import (\n    {item},\n)"
        for item in sorted(members)
    )
    updated = content
    for start, end in sorted(spans, reverse=True):
        updated = updated[:start] + updated[end:]
    assert first_start is not None
    return updated[:first_start] + rendered + "\n\n" + updated[first_start:].lstrip("\n")


def _is_third_party_import(import_line: str) -> bool:
    return import_line.startswith(
        (
            "from fastapi",
            "import fastapi",
            "from mint_sdk",
            "import mint_sdk",
            "from pydantic",
            "import pydantic",
        )
    )


def _is_likely_first_party_import(line: str) -> bool:
    return line.startswith(("from mint_plugin_", "import mint_plugin_", "from .", "import ."))


def _insert_first_party_import(lines: list[str], import_line: str) -> str:
    if "\n" not in import_line:
        first_party_indices = [
            idx
            for idx, line in enumerate(lines)
            if _is_likely_first_party_import(line)
            and "\n" not in line
            and not line.rstrip().endswith("(")
        ]
        if first_party_indices:
            first = first_party_indices[0]
            imports = sorted({*(lines[idx] for idx in first_party_indices), import_line})
            remaining = [line for idx, line in enumerate(lines) if idx not in first_party_indices]
            for offset, line in enumerate(imports):
                remaining.insert(first + offset, line)
            after = first + len(imports)
            if after < len(remaining) and remaining[after] != "":
                remaining.insert(after, "")
            return "\n".join(remaining) + "\n"

    first_party_indices = [idx for idx, line in enumerate(lines) if _is_likely_first_party_import(line)]
    if first_party_indices:
        insert_at = _import_statement_end(lines, first_party_indices[-1])
    else:
        insert_at = 0
        for idx, line in enumerate(lines):
            if line.startswith("from ") or line.startswith("import "):
                insert_at = _import_statement_end(lines, idx)
        if insert_at < len(lines) and lines[insert_at] == "":
            insert_at += 1

    lines.insert(insert_at, import_line)
    if insert_at + 1 < len(lines) and lines[insert_at + 1] != "":
        lines.insert(insert_at + 1, "")
    return "\n".join(lines) + "\n"


def _import_statement_end(lines: list[str], start: int) -> int:
    if not lines[start].rstrip().endswith("("):
        return start + 1
    for idx in range(start + 1, len(lines)):
        if lines[idx].strip() == ")":
            return idx + 1
    return start + 1


def _ensure_mint_sdk_symbol(content: str, symbol: str) -> str:
    if re.search(rf"from mint_sdk import .*{re.escape(symbol)}", content):
        return content

    block_match = re.search(r"from mint_sdk import \(\n(?P<body>.*?\n)\)", content, flags=re.DOTALL)
    if not block_match:
        return _ensure_import(content, f"from mint_sdk import {symbol}")

    body = block_match.group("body")
    if re.search(rf"^\s+{re.escape(symbol)},\s*$", body, flags=re.MULTILINE):
        return content

    names = [
        line.strip().removesuffix(",")
        for line in body.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    names.append(symbol)
    rendered = "".join(f"    {name},\n" for name in sorted(set(names)))
    return content[: block_match.start("body")] + rendered + content[block_match.end("body") :]


def _insert_before_plugin_class(content: str, plugin_class_name: str, block: str) -> str:
    pattern = rf"\nclass {re.escape(plugin_class_name)}\("
    match = re.search(pattern, content)
    if not match:
        print(f"Error: class {plugin_class_name} not found.", file=sys.stderr)
        sys.exit(1)
    return content[: match.start()] + block + content[match.start():]


def _insert_into_class(content: str, class_name: str, line: str) -> str:
    pattern = rf"(class {re.escape(class_name)}\(BaseModel\):\n)"
    match = re.search(pattern, content)
    if not match:
        print(f"Error: class {class_name} not found.", file=sys.stderr)
        sys.exit(1)
    return content[: match.end()] + line + "\n" + content[match.end():]


def _ensure_class_attribute(content: str, class_name: str, attribute_line: str) -> str:
    class_match = re.search(rf"class {re.escape(class_name)}\([^)]*\):\n", content)
    if not class_match:
        print(f"Error: class {class_name} not found.", file=sys.stderr)
        sys.exit(1)
    class_start = class_match.end()
    next_class = re.search(r"\nclass \w+\(", content[class_start:])
    class_body = content[class_start : class_start + next_class.start()] if next_class else content[class_start:]
    attr_name = attribute_line.split("=", 1)[0].strip()
    if re.search(rf"^\s+{re.escape(attr_name)}\s*=", class_body, flags=re.MULTILINE):
        return content
    return content[:class_start] + f"    {attribute_line}\n" + content[class_start:]


def _insert_before_method(content: str, class_name: str, marker: str, block: str) -> str:
    class_match = re.search(rf"class {re.escape(class_name)}\([^)]*\):\n", content)
    if not class_match:
        print(f"Error: class {class_name} not found.", file=sys.stderr)
        sys.exit(1)
    marker_idx = content.find(marker, class_match.end())
    if marker_idx == -1:
        return content.rstrip() + "\n\n" + block
    line_start = content.rfind("\n", 0, marker_idx) + 1
    return content[:line_start] + block + content[line_start:]


def _settings_field_line(
    *,
    name: str,
    field_type: SettingType,
    default: str | None,
    description: str,
    required: bool,
) -> str:
    py_type = {
        SettingType.string: "str",
        SettingType.number: "float",
        SettingType.integer: "int",
        SettingType.boolean: "bool",
    }[field_type]
    default_value = "..." if required else _literal_default(field_type, default)
    args = [f"default={default_value}"]
    if description:
        args.append(f"description={description!r}")
    return f"    {name}: {py_type} = Field({', '.join(args)})"


def _literal_default(field_type: SettingType, value: str | None) -> str:
    if value is None:
        return {
            SettingType.string: '""',
            SettingType.number: "0.0",
            SettingType.integer: "0",
            SettingType.boolean: "False",
        }[field_type]
    if field_type is SettingType.string:
        return repr(value)
    if field_type is SettingType.boolean:
        return "True" if value.lower() in {"1", "true", "yes", "on"} else "False"
    return value


def _schema_field_line(spec: str) -> str:
    name_part, type_part, default = _parse_field_spec(spec)
    py_type = _field_python_type(type_part)
    if default is None:
        default_expr = "..."
    elif py_type == "str":
        default_expr = repr(default)
    elif py_type == "bool":
        default_expr = "True" if default.lower() in {"1", "true", "yes", "on"} else "False"
    elif py_type == "list[str]":
        items = [item.strip() for item in default.split("|") if item.strip()]
        default_expr = repr(items)
    elif py_type == "dict[str, object]":
        default_expr = "{}"
    else:
        default_expr = default
    return f"    {_snake(name_part)}: {py_type} = Field(default={default_expr})"


def _parse_field_spec(spec: str) -> tuple[str, str, str | None]:
    if ":" not in spec:
        print(
            f"Error: field '{spec}' must use name:type or name:type=default.",
            file=sys.stderr,
        )
        sys.exit(1)
    name_part, rest = spec.split(":", 1)
    if not _snake(name_part):
        print(f"Error: field '{spec}' has no valid name.", file=sys.stderr)
        sys.exit(1)
    type_part, _, default = rest.partition("=")
    type_part = type_part.strip().lower()
    if not type_part:
        print(f"Error: field '{spec}' has no type.", file=sys.stderr)
        sys.exit(1)
    return name_part, type_part, default if default else None


def _field_python_type(value: str) -> str:
    aliases = {
        "str": "str",
        "string": "str",
        "float": "float",
        "number": "float",
        "int": "int",
        "integer": "int",
        "bool": "bool",
        "boolean": "bool",
        "dict": "dict[str, object]",
        "object": "dict[str, object]",
        "list": "list[str]",
        "strings": "list[str]",
        "any": "object",
    }
    if value not in aliases:
        valid = ", ".join(sorted(aliases))
        print(f"Error: unknown field type '{value}'. Valid types: {valid}.", file=sys.stderr)
        sys.exit(1)
    return aliases[value]


def _register_router(project_dir: Path, plugin: DiscoveredPlugin, router_name: str, sub_prefix: str) -> None:
    source = _plugin_source(project_dir, plugin)
    package = _module_package(plugin.module_path)
    content = source.read_text()
    content = _ensure_grouped_import_member(content, f"{package}.routers", router_name)
    router_tuple = f"({router_name}.router, \"{sub_prefix}\"),"
    if router_tuple not in content:
        marker = "return ["
        idx = content.find(marker)
        if idx == -1:
            print(f"Warning: could not auto-register {router_name} router.", file=sys.stderr)
        else:
            insert_at = content.find("\n", idx) + 1
            content = content[:insert_at] + f"            {router_tuple}\n" + content[insert_at:]
    source.write_text(content)


def _register_template_service(project_dir: Path, plugin: DiscoveredPlugin, route_module: str) -> None:
    """Wire a generated data-template service to the plugin singleton."""
    source = _plugin_source(project_dir, plugin)
    package = _module_package(plugin.module_path)
    setter = f"set_{route_module}_plugin"
    service_alias = f"{route_module}_service"
    content = source.read_text()
    content = _ensure_split_grouped_import_member(
        content,
        f"{package}.services",
        f"{route_module} as {service_alias}",
    )
    call_line = f"        {service_alias}.{setter}(self)"
    if call_line.strip() in content:
        source.write_text(content)
        return

    context_line = "        self._context = context"
    context_idx = content.find(context_line)
    if context_idx != -1:
        insert_at = content.find("\n", context_idx) + 1
        content = content[:insert_at] + f"{call_line}\n" + content[insert_at:]
        source.write_text(content)
        return

    init_match = re.search(r"^\s+async def initialize\(.*\):\n", content, flags=re.MULTILINE)
    if init_match is None:
        print(
            f"Warning: could not auto-wire {route_module} service; call {setter}(self) in initialize().",
            file=sys.stderr,
        )
        source.write_text(content)
        return

    content = content[: init_match.end()] + f"{call_line}\n" + content[init_match.end():]
    source.write_text(content)


def _register_frontend_route(
    project_dir: Path,
    *,
    route_name: str,
    route_path: str,
    view_name: str,
    label: str,
    icon: str = DEFAULT_PAGE_ICON_PATH,
    description: str | None = None,
) -> None:
    frontend_src = project_dir / "frontend" / "src"
    plugin = discover_plugin(project_dir)
    page_description = description or _plugin_nav_item_description(label)
    _register_plugin_nav_item(
        project_dir,
        plugin,
        route_path=route_path,
        label=label,
        icon=icon,
        description=page_description,
    )

    main_ts = frontend_src / "main.ts"
    if main_ts.exists():
        content = main_ts.read_text()
        route_entry = f"""  {{
    path: '{route_path}',
    name: '{route_name}',
    component: () => import('./views/{view_name}.vue'),
  }},"""
        if f"name: '{route_name}'" not in content:
            content = content.replace("]\n\nconst router", f"{route_entry}\n]\n\nconst router")
            main_ts.write_text(content)

    app_vue = frontend_src / "App.vue"
    if app_vue.exists():
        content = app_vue.read_text()
        page_entry = (
            f"  {{ id: '{route_name}', label: '{label}', to: '{route_path}', "
            f"icon: '{icon}', description: '{page_description}' }},"
        )
        if f"id: '{route_name}'" not in content:
            content = content.replace("]\n\nconst currentPageId", f"{page_entry}\n]\n\nconst currentPageId")
            app_vue.write_text(content)


def _register_plugin_nav_item(
    project_dir: Path,
    plugin: DiscoveredPlugin,
    *,
    route_path: str,
    label: str,
    icon: str = DEFAULT_PAGE_ICON_PATH,
    description: str | None = None,
) -> None:
    source = _plugin_source(project_dir, plugin)
    content = source.read_text()
    if f'path="{route_path}"' in content or f"path='{route_path}'" in content:
        return

    if "PluginNavItem" not in content:
        content = content.replace("    PluginMetadata,\n", "    PluginMetadata,\n    PluginNavItem,\n")

    nav_start = content.find("nav_items=[")
    if nav_start == -1:
        updated = _insert_plugin_nav_items_list(
            content,
            route_path=route_path,
            label=label,
            icon=icon,
            description=description or _plugin_nav_item_description(label),
        )
        if updated is not None:
            source.write_text(updated)
        return

    list_end = content.find("\n            ],", nav_start)
    if list_end == -1:
        return

    item = _format_plugin_nav_item(
        route_path=route_path,
        label=label,
        icon=icon,
        description=description or _plugin_nav_item_description(label),
    )
    content = content[:list_end] + f"\n{item}" + content[list_end:]
    source.write_text(content)


def _insert_plugin_nav_items_list(
    content: str,
    *,
    route_path: str,
    label: str,
    icon: str,
    description: str,
) -> str | None:
    closing_line_start = _find_plugin_metadata_closing_line_start(content)
    if closing_line_start is None:
        return None

    closing_line = content[closing_line_start:]
    closing_indent = re.match(r"\s*", closing_line).group(0)
    argument_indent = f"{closing_indent}    "
    item = _format_plugin_nav_item(
        route_path=route_path,
        label=label,
        icon=icon,
        description=description,
        indent=f"{argument_indent}    ",
    )
    nav_items = f"{argument_indent}nav_items=[\n{item}\n{argument_indent}],\n"
    return content[:closing_line_start] + nav_items + content[closing_line_start:]


def _format_plugin_nav_item(
    *,
    route_path: str,
    label: str,
    icon: str,
    description: str,
    indent: str = "                ",
) -> str:
    return (
        f"{indent}PluginNavItem(\n"
        f"{indent}    path={route_path!r},\n"
        f"{indent}    label={label!r},\n"
        f"{indent}    id={_plugin_nav_item_id(route_path)!r},\n"
        f"{indent}    icon={icon!r},\n"
        f"{indent}    description={description!r},\n"
        f"{indent}),"
    )


def _find_plugin_metadata_closing_line_start(content: str) -> int | None:
    metadata_start = content.find("PluginMetadata(")
    if metadata_start == -1:
        return None

    call_line_start = content.rfind("\n", 0, metadata_start) + 1
    call_line = content[call_line_start:metadata_start]
    call_indent = re.match(r"\s*", call_line).group(0)
    closing_pattern = re.compile(rf"^{re.escape(call_indent)}\)\s*,?\s*$", re.MULTILINE)
    closing_match = closing_pattern.search(content, metadata_start)
    if closing_match is None:
        return None
    return closing_match.start()


def _plugin_nav_item_id(route_path: str) -> str:
    normalized = "/" + route_path.strip().lstrip("/")
    normalized = normalized.rstrip("/") or "/"
    if normalized == "/":
        return "dashboard"
    return normalized.lstrip("/").replace("/", "-") or "dashboard"


def _plugin_nav_item_description(label: str) -> str:
    return f"Open {label}."


def _write_if_missing(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return
    path.write_text(content)


def _handle_generate_contract(project_dir: Path, *, generate: bool) -> None:
    if (project_dir / "frontend" / "package.json").exists():
        if generate:
            from mint_sdk.contract import ContractGenerationError, generate_contract_files

            try:
                result = generate_contract_files(project_dir)
            except ContractGenerationError as exc:
                print(f"Error: could not generate frontend contract: {exc}", file=sys.stderr)
                sys.exit(1)
            print(f"Generated frontend plugin contract: {result.detail}")
        else:
            print("Next: mint sdk generate")


def _r_script_template(name: str) -> str:
    return f'''# {name} R analysis scaffold
source("r_scripts/mint_bridge.R")

payload <- mint_read_input()
parameters <- mint_parameters(payload)
threshold <- mint_parameter("threshold", 0.05, payload)
normalize <- mint_parameter("normalize", TRUE, payload)
experiment_id <- mint_experiment_id()
artifact_dir <- mint_artifact_dir()

result <- list(
  status = "not_implemented",
  experiment_id = experiment_id,
  result = list(
    parameters = parameters,
    threshold = threshold,
    normalize = normalize,
    artifact_dir = artifact_dir
  )
)

mint_write_output(result)
'''


def _r_bridge_helper_template() -> str:
    return '''# Shared helpers for MINT R analysis scripts.

mint_require_jsonlite <- function() {
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("Package 'jsonlite' is required. Add it to renv.lock or r-requirements.txt.")
  }
}

mint_input_path <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  path <- if (length(args) >= 1) args[[1]] else Sys.getenv("MINT_R_INPUT", unset = "")
  if (!nzchar(path)) {
    stop("Expected input JSON path as argv[1] or MINT_R_INPUT.")
  }
  path
}

mint_output_path <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  path <- if (length(args) >= 2) args[[2]] else Sys.getenv("MINT_R_OUTPUT", unset = "")
  if (!nzchar(path)) {
    stop("Expected output JSON path as argv[2] or MINT_R_OUTPUT.")
  }
  path
}

mint_read_input <- function(path = mint_input_path()) {
  mint_require_jsonlite()
  jsonlite::fromJSON(path)
}

mint_parameters <- function(payload = mint_read_input()) {
  if (is.null(payload$parameters)) {
    return(list())
  }
  payload$parameters
}

mint_parameter <- function(name, default = NULL, payload = mint_read_input()) {
  parameters <- mint_parameters(payload)
  value <- parameters[[name]]
  if (is.null(value)) {
    return(default)
  }
  value
}

mint_required_parameter <- function(name, payload = mint_read_input()) {
  value <- mint_parameter(name, NULL, payload)
  if (is.null(value)) {
    stop(paste0("Missing required parameter: ", name))
  }
  value
}

mint_write_output <- function(value, path = mint_output_path()) {
  mint_require_jsonlite()
  jsonlite::write_json(value, path, auto_unbox = TRUE, null = "null")
}

mint_experiment_id <- function() {
  value <- Sys.getenv("MINT_EXPERIMENT_ID", unset = NA_character_)
  if (is.na(value) || !nzchar(value)) {
    return(NULL)
  }
  as.integer(value)
}

mint_artifact_dir <- function(create = TRUE) {
  path <- Sys.getenv("MINT_R_ARTIFACT_DIR", unset = "")
  if (!nzchar(path)) {
    stop("MINT_R_ARTIFACT_DIR is not set. Configure RScriptSpec(artifact_dir = ...).")
  }
  if (isTRUE(create) && !dir.exists(path)) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
  path
}

mint_artifact_path <- function(..., create = TRUE) {
  file.path(mint_artifact_dir(create = create), ...)
}
'''


def _snake(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value)
    return value.lower() or "generated"


def _pascal(value: str) -> str:
    return "".join(part.capitalize() for part in _snake(value).split("_"))


def _camel(value: str) -> str:
    pascal = _pascal(value)
    return pascal[:1].lower() + pascal[1:] if pascal else "generated"
