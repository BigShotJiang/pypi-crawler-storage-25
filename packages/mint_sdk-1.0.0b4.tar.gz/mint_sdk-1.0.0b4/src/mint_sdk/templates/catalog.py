"""Discoverable catalog metadata for built-in biology templates."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .base import normalize_template_lookup_key


class BioTemplateCatalogEntry(BaseModel):
    """Public metadata for one built-in biology data template."""

    model_config = ConfigDict(frozen=True)

    name: str
    template_id: str
    template_version: str = "1.0"
    label: str
    category: str = "bio-data"
    purpose: str
    aliases: tuple[str, ...] = Field(default_factory=tuple)
    python_import: str
    python_example: str
    frontend_import: str
    frontend_adapters: tuple[str, ...]
    components: tuple[str, ...]
    add_command: str


_TEMPLATE_CATALOG: tuple[BioTemplateCatalogEntry, ...] = (
    BioTemplateCatalogEntry(
        name="plate-map",
        template_id="plate-map",
        label="Plate map",
        purpose="Plate layout, wells, sample assignments, and sample legend data.",
        aliases=("wellplate", "well-plate", "plate layout", "plate-map editor"),
        python_import="from mint_sdk.templates import PlateMapTemplate, save_template",
        python_example='PlateMapTemplate.create_96_well(name="Plate 1", samples=["Control", "Treatment"])',
        frontend_import=(
            "import { toPlateMapEditorState, toWellPlateWells } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toPlateMapEditorState", "toWellPlateWells"),
        components=("PlateMapEditor", "WellPlate", "SampleLegend"),
        add_command="mint add data-template plate-map --page",
    ),
    BioTemplateCatalogEntry(
        name="sample-sheet",
        template_id="sample-sheet",
        label="Sample sheet",
        purpose="Tabular sample metadata, display columns, and group definitions.",
        aliases=("sample metadata", "sample table", "metadata sheet", "csv samples"),
        python_import="from mint_sdk.templates import SampleSheetTemplate, save_template",
        python_example=(
            'SampleSheetTemplate.from_rows([{"sample_id": "S001", '
            '"name": "Control 1", "group": "Control"}])'
        ),
        frontend_import=(
            "import { toTemplateDataFrame, toSampleOptions } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toSampleDataFrame",
            "toSampleRows",
            "toSampleColumns",
            "toSampleOptions",
        ),
        components=("DataFrame", "SampleSelector", "AutoGroupModal", "GroupAssigner"),
        add_command="mint add data-template sample-sheet --page",
    ),
    BioTemplateCatalogEntry(
        name="sample-prep",
        template_id="sample-prep",
        label="Sample prep",
        purpose="Extraction, dilution, normalization, transfer, source/destination, volume, reagent, and status steps.",
        aliases=("sample preparation", "extraction", "dilution", "normalization", "prep steps"),
        python_import="from mint_sdk.templates import SamplePrepTemplate, save_template",
        python_example='SamplePrepTemplate.create(["S001", "S002"], prep_type="extraction", output_volume=50)',
        frontend_import=(
            "import { toSamplePrepDataFrame, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toSamplePrepDataFrame",
            "toSamplePrepRows",
            "toSamplePrepColumns",
        ),
        components=("DataFrame", "ProtocolStepEditor", "SampleSelector", "WellPlate"),
        add_command="mint add data-template sample-prep --page",
    ),
    BioTemplateCatalogEntry(
        name="dose-response",
        template_id="dose-response",
        label="Dose response",
        purpose="Compounds, concentration series, controls, replicates, and optional plate layout.",
        aliases=(
            "drug response",
            "concentration series",
            "dose curve",
            "dose design",
            "dose planner",
            "dose calculator",
            "drp",
        ),
        python_import="from mint_sdk.templates import ControlDefinition, DoseResponseTemplate, save_template",
        python_example='DoseResponseTemplate.create({"Compound A": [10, 1, 0.1]}, unit="uM", replicates=3)',
        frontend_import=(
            "import { toDoseConditions, toDoseLayoutState } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toDoseConditions", "toDoseLayoutState"),
        components=("DoseCalculator", "ReagentEditor", "WellPlate"),
        add_command="mint add data-template dose-response --page",
    ),
    BioTemplateCatalogEntry(
        name="calibration-curve",
        template_id="calibration-curve",
        label="Calibration curve",
        purpose="Standard curves, blank/QC points, fitted model settings, and acceptance thresholds.",
        aliases=("standard curve", "calibration", "quantitation", "qc acceptance", "calibrator"),
        python_import="from mint_sdk.templates import CalibrationCurveTemplate, save_template",
        python_example='CalibrationCurveTemplate.create([0.1, 1, 10, 100], analyte="Glucose", unit="uM")',
        frontend_import=(
            "import { toCalibrationCurveDataFrame, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toCalibrationCurveDataFrame",
            "toCalibrationCurveRows",
            "toCalibrationCurveColumns",
        ),
        components=("DataFrame", "FitPanel", "ChartContainer"),
        add_command="mint add data-template calibration-curve --page",
    ),
    BioTemplateCatalogEntry(
        name="time-course",
        template_id="time-course",
        label="Time course",
        purpose="Longitudinal time points, conditions, replicates, and scheduled samples.",
        aliases=("longitudinal", "time series", "sampling schedule", "kinetics"),
        python_import="from mint_sdk.templates import TimeCourseTemplate, save_template",
        python_example=(
            'TimeCourseTemplate.create([0, 6, 24], unit="hour", '
            'conditions=["Control", "Treatment"], replicates=3)'
        ),
        frontend_import=(
            "import { toTemplateDataFrame, toTimeCourseSteps } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toTimeCourseDataFrame",
            "toTimeCourseRows",
            "toTimeCourseSteps",
            "toTimeCourseColumns",
        ),
        components=("ExperimentTimeline", "DataFrame", "ScheduleCalendar"),
        add_command="mint add data-template time-course --page",
    ),
    BioTemplateCatalogEntry(
        name="protocol-steps",
        template_id="protocol-steps",
        label="Protocol steps",
        purpose="Ordered experiment protocol steps, durations, statuses, and run-sheet parameters.",
        aliases=("protocol", "run sheet", "workflow", "method steps", "sop"),
        python_import="from mint_sdk.templates import ProtocolStepsTemplate, save_template",
        python_example='ProtocolStepsTemplate.create(["Seed cells", "Add treatment", "Measure viability"])',
        frontend_import=(
            "import { toProtocolSteps, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toProtocolSteps",
            "toProtocolDataFrame",
        ),
        components=("ExperimentTimeline", "ProtocolStepEditor", "DataFrame"),
        add_command="mint add data-template protocol-steps --page",
    ),
    BioTemplateCatalogEntry(
        name="assay-matrix",
        template_id="assay-matrix",
        label="Assay matrix",
        purpose="Sample-by-feature measurement matrices for omics, plate-reader, and marker assays.",
        aliases=("omics matrix", "measurement matrix", "readout matrix", "feature table"),
        python_import="from mint_sdk.templates import AssayMatrixTemplate, save_template",
        python_example='AssayMatrixTemplate.create(samples=["S001", "S002"], features=["Lactate", "Glucose"])',
        frontend_import=(
            "import { toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toAssayMatrixDataFrame",
            "toAssayMatrixRows",
            "toAssayMatrixColumns",
        ),
        components=("DataFrame", "ChartContainer", "SampleSelector"),
        add_command="mint add data-template assay-matrix --page",
    ),
    BioTemplateCatalogEntry(
        name="reagent-list",
        template_id="reagent-list",
        label="Reagent list",
        purpose="Experiment reagents, catalog numbers, lots, storage, locations, and stock status.",
        aliases=("reagents", "inventory", "antibodies", "primers", "compound stocks"),
        python_import="from mint_sdk.templates import ReagentListTemplate, save_template",
        python_example='ReagentListTemplate.create(["DMSO", "Compound A", "Anti-HA antibody"])',
        frontend_import=(
            "import { toReagentListItems, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toReagentDataFrame",
            "toReagentListItems",
        ),
        components=("ReagentList", "DataFrame", "ReagentEditor"),
        add_command="mint add data-template reagent-list --page",
    ),
    BioTemplateCatalogEntry(
        name="flow-cytometry-panel",
        template_id="flow-cytometry-panel",
        label="Flow cytometry panel",
        purpose="Flow-cytometry markers, fluorophores, detectors, compensation controls, and panel metadata.",
        aliases=("flow panel", "facs panel", "cytometry panel", "antibody panel"),
        python_import="from mint_sdk.templates import FlowCytometryPanelTemplate, save_template",
        python_example=(
            'FlowCytometryPanelTemplate.create(["CD3", "CD4", "CD8"], '
            'instrument="BD LSRFortessa")'
        ),
        frontend_import=(
            "import { toFlowPanelDataFrame, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toFlowPanelDataFrame",
            "toFlowPanelRows",
            "toFlowPanelColumns",
        ),
        components=("DataFrame", "ReagentList", "SampleSelector"),
        add_command="mint add data-template flow-cytometry-panel --page",
    ),
    BioTemplateCatalogEntry(
        name="instrument-run",
        template_id="instrument-run",
        label="Instrument run",
        purpose="Instrument sequence tables, sample queues, methods, QC, blanks, and acquisition status.",
        aliases=("run queue", "sequence table", "sample queue", "lcms run", "instrument sequence", "batch run"),
        python_import="from mint_sdk.templates import InstrumentRunTemplate, save_template",
        python_example='InstrumentRunTemplate.create(["S001", "S002"], instrument="LC-MS")',
        frontend_import=(
            "import { toInstrumentRunDataFrame, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toInstrumentRunDataFrame",
            "toInstrumentRunRows",
            "toInstrumentRunColumns",
        ),
        components=("DataFrame", "ScheduleCalendar", "SampleSelector"),
        add_command="mint add data-template instrument-run --page",
    ),
    BioTemplateCatalogEntry(
        name="qpcr-plate",
        template_id="qpcr-plate",
        label="qPCR plate",
        purpose="qPCR/ddPCR plate layouts, samples, targets, replicate reactions, controls, and Cq fields.",
        aliases=("qpcr", "qPCR", "ddpcr", "rt-qpcr", "gene expression", "primer plate"),
        python_import="from mint_sdk.templates import QpcrPlateTemplate, save_template",
        python_example=(
            'QpcrPlateTemplate.create(samples=["Control", "Treatment"], '
            'targets=["ACTB", "GAPDH"], replicates=3)'
        ),
        frontend_import=(
            "import { toQpcrDataFrame, toQpcrWellPlateWells, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toQpcrDataFrame",
            "toQpcrRows",
            "toQpcrColumns",
            "toQpcrWellPlateWells",
        ),
        components=("DataFrame", "WellPlate", "SampleSelector"),
        add_command="mint add data-template qpcr-plate --page",
    ),
)


def list_template_catalog() -> tuple[BioTemplateCatalogEntry, ...]:
    """Return metadata for all built-in biology data templates."""
    return _TEMPLATE_CATALOG


def get_template_info(name: str) -> BioTemplateCatalogEntry | None:
    """Find a built-in template by id, display name, or alias."""
    query = normalize_template_lookup_key(name)
    for entry in _TEMPLATE_CATALOG:
        identifiers = {
            normalize_template_lookup_key(entry.name),
            normalize_template_lookup_key(entry.template_id),
            normalize_template_lookup_key(entry.label),
            *(normalize_template_lookup_key(alias) for alias in entry.aliases),
        }
        if query in identifiers:
            return entry
    return None


def require_template_info(name: str) -> BioTemplateCatalogEntry:
    """Return template metadata or raise ``KeyError`` for an unknown template."""
    entry = get_template_info(name)
    if entry is None:
        raise KeyError(name)
    return entry
