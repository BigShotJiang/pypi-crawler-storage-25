"""Discoverable catalog metadata for built-in biology template packs."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .base import normalize_template_lookup_key
from .catalog import require_template_info


class BioTemplatePackEntry(BaseModel):
    """Public metadata for one curated biology data-template pack."""

    model_config = ConfigDict(frozen=True)

    name: str
    label: str
    category: str = "bio-template-pack"
    purpose: str
    templates: tuple[str, ...]
    aliases: tuple[str, ...] = Field(default_factory=tuple)
    frontend_adapters: tuple[str, ...]
    components: tuple[str, ...]
    add_command: str
    init_command: str
    docs_command: str


def _pack(
    *,
    name: str,
    label: str,
    purpose: str,
    templates: tuple[str, ...],
    aliases: tuple[str, ...],
) -> BioTemplatePackEntry:
    return BioTemplatePackEntry(
        name=name,
        label=label,
        purpose=purpose,
        templates=templates,
        aliases=aliases,
        frontend_adapters=_collect_template_field(templates, "frontend_adapters"),
        components=_collect_template_field(templates, "components"),
        add_command=f"mint add data-template-pack {name} --page",
        init_command=f"mint init --template {name}",
        docs_command=f"mint docs template-pack {name}",
    )


def _collect_template_field(template_ids: tuple[str, ...], field: str) -> tuple[str, ...]:
    values: list[str] = []
    for template_id in template_ids:
        entry = require_template_info(template_id)
        for value in getattr(entry, field):
            if value not in values:
                values.append(value)
    return tuple(values)


_TEMPLATE_PACKS: tuple[BioTemplatePackEntry, ...] = (
    _pack(
        name="cell-culture-screen",
        label="Cell culture screen",
        purpose=(
            "Plate layout, sample metadata, sample prep, reagents, protocol, "
            "dose-response, and flow-panel setup."
        ),
        templates=(
            "sample-sheet",
            "sample-prep",
            "plate-map",
            "reagent-list",
            "protocol-steps",
            "dose-response",
            "flow-cytometry-panel",
        ),
        aliases=("cell culture", "screen", "drug screen", "plate screen"),
    ),
    _pack(
        name="omics-assay",
        label="Omics assay",
        purpose=(
            "Sample metadata, sample prep, reagents, protocol, instrument run "
            "queue, calibration curve, and measurement matrix."
        ),
        templates=(
            "sample-sheet",
            "sample-prep",
            "reagent-list",
            "protocol-steps",
            "instrument-run",
            "calibration-curve",
            "assay-matrix",
        ),
        aliases=("omics", "metabolomics", "proteomics", "assay matrix", "lcms", "standard curve"),
    ),
    _pack(
        name="longitudinal-study",
        label="Longitudinal study",
        purpose="Sample metadata, time-course schedule, protocol, and measurement matrix.",
        templates=(
            "sample-sheet",
            "time-course",
            "protocol-steps",
            "assay-matrix",
        ),
        aliases=("time series", "time-course study", "kinetics", "longitudinal"),
    ),
    _pack(
        name="molecular-assay",
        label="Molecular assay",
        purpose=(
            "Sample metadata, sample prep, reagents, protocol, instrument run "
            "queue, calibration curve, and qPCR/ddPCR plate setup."
        ),
        templates=(
            "sample-sheet",
            "sample-prep",
            "reagent-list",
            "protocol-steps",
            "instrument-run",
            "calibration-curve",
            "qpcr-plate",
        ),
        aliases=("molecular", "qpcr", "qPCR", "gene expression", "rt-qpcr", "ddpcr"),
    ),
)


def list_template_packs() -> tuple[BioTemplatePackEntry, ...]:
    """Return metadata for built-in curated multi-template packs."""
    return _TEMPLATE_PACKS


def get_template_pack_info(name: str) -> BioTemplatePackEntry | None:
    """Find a built-in template pack by id, label, or alias."""
    query = normalize_template_lookup_key(name)
    for entry in _TEMPLATE_PACKS:
        identifiers = {
            normalize_template_lookup_key(entry.name),
            normalize_template_lookup_key(entry.label),
            *(normalize_template_lookup_key(alias) for alias in entry.aliases),
        }
        if query in identifiers:
            return entry
    return None


def require_template_pack_info(name: str) -> BioTemplatePackEntry:
    """Return pack metadata or raise ``KeyError`` for an unknown pack."""
    entry = get_template_pack_info(name)
    if entry is None:
        raise KeyError(name)
    return entry
