"""Contract generation for frontend plugin clients.

The contract generator inspects a plugin's metadata, FastAPI routers, and
Pydantic models without starting the plugin or calling ``initialize()``.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import re
import sys
from contextlib import contextmanager, suppress
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from types import UnionType
from typing import Annotated, Any, Literal, Union, get_args, get_origin

from mint_sdk._discover import DiscoveredPlugin, discover_plugin

CONTRACT_JSON_NAME = "mint-plugin.contract.json"
CONTRACT_TS_NAME = "mint-plugin.ts"
DEFAULT_OUTPUT_DIR = Path("frontend/src/generated")


@dataclass(slots=True)
class ContractCheckResult:
    """Result of checking generated contract files against current backend code."""

    ok: bool
    detail: str
    explanation: str = ""
    fix_hint: str = ""


class ContractGenerationError(RuntimeError):
    """Raised when a plugin contract cannot be generated."""


def generate_contract_files(
    project_dir: Path,
    *,
    output_dir: Path | None = None,
    check: bool = False,
) -> ContractCheckResult:
    """Generate or check frontend contract files for a plugin project."""
    project_dir = project_dir.resolve()
    discovered = discover_plugin(project_dir)
    if output_dir is None and not discovered.has_frontend:
        return ContractCheckResult(True, "no frontend (nothing generated)")
    target_dir = _resolve_output_dir(project_dir, output_dir)
    contract, ts_content, warnings = build_contract_outputs(project_dir, discovered=discovered)

    json_path = target_dir / CONTRACT_JSON_NAME
    ts_path = target_dir / CONTRACT_TS_NAME
    json_content = _json_dumps(contract) + "\n"

    if check:
        missing = [str(path.relative_to(project_dir)) for path in (json_path, ts_path) if not path.exists()]
        if missing:
            return ContractCheckResult(
                False,
                f"missing {', '.join(missing)}",
                "Frontend plugins should commit generated contract files so backend/frontend drift is visible.",
                "Run `mint sdk generate`.",
            )
        if json_path.read_text() != json_content or ts_path.read_text() != ts_content:
            return ContractCheckResult(
                False,
                "generated files are stale",
                "The backend plugin contract no longer matches the generated frontend client.",
                "Run `mint sdk generate`.",
            )
        detail = "current"
    else:
        target_dir.mkdir(parents=True, exist_ok=True)
        json_path.write_text(json_content)
        ts_path.write_text(ts_content)
        detail = f"wrote {json_path.relative_to(project_dir)} and {ts_path.relative_to(project_dir)}"

    if warnings:
        detail = f"{detail} ({len(warnings)} warning{'s' if len(warnings) != 1 else ''})"
    return ContractCheckResult(True, detail)


def check_contract_files(project_dir: Path, *, output_dir: Path | None = None) -> ContractCheckResult:
    """Check whether generated contract files are present and current."""
    return generate_contract_files(project_dir, output_dir=output_dir, check=True)


def build_contract_outputs(
    project_dir: Path,
    *,
    discovered: DiscoveredPlugin | None = None,
) -> tuple[dict[str, Any], str, list[str]]:
    """Build the normalized JSON contract and TypeScript client content."""
    discovered = discovered or discover_plugin(project_dir)
    plugin = _load_plugin(project_dir, discovered)
    metadata = plugin.metadata
    endpoints, schemas, warnings = _collect_endpoints(plugin)
    settings_schema = _settings_schema(plugin)

    plugin_type = getattr(metadata.plugin_type, "value", metadata.plugin_type)
    if plugin_type == "experiment_design":
        plugin_type = "experiment-design"

    contract: dict[str, Any] = {
        "schemaVersion": 1,
        "plugin": {
            "name": metadata.name,
            "packageName": discovered.project_name,
            "version": metadata.version,
            "description": metadata.description,
            "routesPrefix": metadata.routes_prefix,
            "apiPrefix": f"/api{metadata.routes_prefix}",
            "type": plugin_type,
            "analysisType": metadata.analysis_type,
            "icon": getattr(metadata, "icon", ""),
            "color": getattr(metadata, "color", ""),
            "navItems": _metadata_nav_items(metadata),
            "capabilities": _capabilities_dict(metadata.capabilities),
        },
        "settings": settings_schema,
        "endpoints": endpoints,
        "schemas": schemas,
    }
    contract["hash"] = _contract_hash(contract)
    ts_content = _render_typescript(contract)
    return contract, ts_content, warnings


def _metadata_nav_items(metadata: Any) -> list[dict[str, Any]]:
    """Return plugin page metadata in the frontend contract shape."""
    nav_items = getattr(metadata, "nav_items", []) or []
    result: list[dict[str, Any]] = []
    for item in nav_items:
        if isinstance(item, dict):
            raise ContractGenerationError(
                "PluginMetadata.nav_items must contain PluginNavItem(...) objects, not dict entries"
            )
        result.append(
            {
                "path": item.path,
                "label": item.label,
                **({"id": item.id} if getattr(item, "id", "") else {}),
                **({"icon": item.icon} if item.icon else {}),
                **({"description": item.description} if item.description else {}),
                **({"requiresAuth": item.requires_auth} if item.requires_auth else {}),
                **({"requiresAdmin": item.requires_admin} if item.requires_admin else {}),
                **({"requiresFeature": item.requires_feature} if item.requires_feature else {}),
            }
        )
    return result


def _resolve_output_dir(project_dir: Path, output_dir: Path | None) -> Path:
    if output_dir is None:
        return project_dir / DEFAULT_OUTPUT_DIR
    if output_dir.is_absolute():
        return output_dir
    return project_dir / output_dir


def _json_dumps(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True)


def _contract_hash(contract: dict[str, Any]) -> str:
    payload = {k: v for k, v in contract.items() if k != "hash"}
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _capabilities_dict(capabilities: Any) -> dict[str, Any]:
    try:
        return asdict(capabilities)
    except TypeError:
        return dict(capabilities or {})


@contextmanager
def _project_import_path(project_dir: Path):
    candidates = [str(project_dir / "src"), str(project_dir)]
    inserted: list[str] = []
    for candidate in candidates:
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
            inserted.append(candidate)
    try:
        yield
    finally:
        for candidate in inserted:
            with suppress(ValueError):
                sys.path.remove(candidate)


def _load_plugin(project_dir: Path, discovered: DiscoveredPlugin) -> Any:
    with _project_import_path(project_dir):
        try:
            package_root = discovered.module_path.split(".", 1)[0]
            for module_name in list(sys.modules):
                if module_name == package_root or module_name.startswith(f"{package_root}."):
                    sys.modules.pop(module_name, None)
            module = importlib.import_module(discovered.module_path)
            plugin_class = getattr(module, discovered.class_name)
            return plugin_class()
        except Exception as exc:  # pragma: no cover - message is tested through caller
            raise ContractGenerationError(
                f"Could not import plugin entry point {discovered.module_path}:{discovered.class_name}: {exc}"
            ) from exc


def _collect_endpoints(plugin: Any) -> tuple[list[dict[str, Any]], dict[str, Any], list[str]]:
    try:
        from fastapi.routing import APIRoute
        from pydantic import BaseModel
    except Exception as exc:  # pragma: no cover - hard dependency in SDK
        raise ContractGenerationError(f"FastAPI and Pydantic are required for contract generation: {exc}") from exc

    endpoints: list[dict[str, Any]] = []
    schemas: dict[str, Any] = {}
    warnings: list[str] = []
    used_names: set[str] = set()

    for router, sub_prefix in plugin.get_routers():
        for route in router.routes:
            if not isinstance(route, APIRoute):
                continue
            method = _primary_method(route.methods)
            if method is None:
                continue
            name = _safe_endpoint_name(route.operation_id or route.name)
            if name in used_names:
                raise ContractGenerationError(
                    f"Duplicate generated endpoint name '{name}'. Set a unique FastAPI operation_id."
                )
            used_names.add(name)

            request_annotation = _body_annotation(route, BaseModel)
            response_annotation = _response_annotation(route, BaseModel)
            request_type = _contract_type(request_annotation, BaseModel)
            response_type = _contract_type(response_annotation, BaseModel)

            for annotation in (request_annotation, response_annotation):
                _register_annotation_schemas(schemas, annotation, BaseModel)

            path = _join_paths(str(sub_prefix or ""), route.path)
            endpoints.append(
                {
                    "name": name,
                    "method": method.lower(),
                    "path": path,
                    "operationId": route.operation_id or route.name,
                    "pathParams": _path_params(route),
                    "queryParams": _query_params(route),
                    "requestType": request_type,
                    "responseType": response_type,
                }
            )

    return endpoints, dict(sorted(schemas.items())), warnings


def _primary_method(methods: set[str]) -> str | None:
    visible = sorted(method for method in methods if method not in {"HEAD", "OPTIONS"})
    return visible[0] if visible else None


def _join_paths(prefix: str, path: str) -> str:
    joined = f"/{prefix.strip('/')}/{path.strip('/')}".replace("//", "/")
    return "/" if joined == "/" else joined.rstrip("/")


def _safe_endpoint_name(name: str) -> str:
    parts = re.split(r"[^a-zA-Z0-9]+", name)
    parts = [part for part in parts if part]
    if not parts:
        return "endpoint"
    first, *rest = parts
    result = first[:1].lower() + first[1:] + "".join(part[:1].upper() + part[1:] for part in rest)
    if result[0].isdigit():
        result = f"endpoint{result}"
    return result


def _body_annotation(route: Any, base_model: type) -> Any | None:
    body_field = getattr(route, "body_field", None)
    if body_field is None:
        return None
    candidate = getattr(body_field, "type_", None)
    return candidate if _contract_type(candidate, base_model) is not None else None


def _response_annotation(route: Any, base_model: type) -> Any | None:
    candidate = getattr(route, "response_model", None)
    return candidate if _contract_type(candidate, base_model) is not None else None


def _model_name(model: type | None) -> str | None:
    return model.__name__ if model is not None else None


def _model_schema(model: type) -> dict[str, Any]:
    return model.model_json_schema()


def _register_model_schema(schemas: dict[str, Any], model: type) -> None:
    schema = _model_schema(model)
    schemas[_model_name(model)] = schema
    for name, definition in _schema_definitions(schema).items():
        schemas.setdefault(name, definition)


def _register_annotation_schemas(schemas: dict[str, Any], annotation: Any, base_model: type) -> None:
    if annotation is None:
        return
    if isinstance(annotation, type) and issubclass(annotation, base_model):
        _register_model_schema(schemas, annotation)
        return
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        if args:
            _register_annotation_schemas(schemas, args[0], base_model)
        return
    if origin in (Union, UnionType, list, dict):
        for arg in get_args(annotation):
            if arg is not type(None):
                _register_annotation_schemas(schemas, arg, base_model)


def _contract_type(annotation: Any, base_model: type) -> str | None:
    if annotation is None:
        return None
    if isinstance(annotation, type) and issubclass(annotation, base_model):
        return _model_name(annotation)
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return _contract_type(args[0], base_model) if args else None
    if origin in (Union, UnionType):
        types = []
        for arg in get_args(annotation):
            if arg is type(None):
                types.append("null")
                continue
            types.append(_contract_type(arg, base_model) or _annotation_to_ts(arg))
        return _dedupe_join(types, separator=" | ")
    if origin is list:
        args = get_args(annotation)
        item_type = _contract_type(args[0], base_model) if args else None
        item_type = item_type or (_annotation_to_ts(args[0]) if args else "unknown")
        return f"{_parenthesize_array_item_type(item_type)}[]"
    if origin is dict:
        args = get_args(annotation)
        value_annotation = args[1] if len(args) == 2 else Any
        value_type = _contract_type(value_annotation, base_model) or _annotation_to_ts(value_annotation)
        return f"Record<string, {value_type}>"
    primitive_type = _annotation_to_ts(annotation)
    return primitive_type if primitive_type != "unknown" else None


def _path_params(route: Any) -> list[dict[str, str]]:
    params: list[dict[str, str]] = []
    dependant = getattr(route, "dependant", None)
    for param in getattr(dependant, "path_params", []) or []:
        name = getattr(param, "name", "")
        annotation = getattr(param, "type_", str)
        params.append(
            {
                "name": name,
                "fieldName": _safe_field_name(name),
                "type": _annotation_to_ts(annotation),
            }
        )
    return params


def _query_params(route: Any) -> list[dict[str, Any]]:
    params: list[dict[str, Any]] = []
    dependant = getattr(route, "dependant", None)
    for param in getattr(dependant, "query_params", []) or []:
        name = getattr(param, "name", "")
        annotation = getattr(param, "type_", str)
        required = bool(getattr(param, "required", False))
        params.append(
            {
                "name": name,
                "fieldName": _safe_field_name(name),
                "type": _annotation_to_ts(annotation),
                "required": required,
            }
        )
    return params


def _safe_field_name(name: str) -> str:
    parts = re.split(r"[^a-zA-Z0-9]+", name)
    parts = [part for part in parts if part]
    if not parts:
        return name
    first, *rest = parts
    return first + "".join(part[:1].upper() + part[1:] for part in rest)


def _annotation_to_ts(annotation: Any) -> str:
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return _annotation_to_ts(args[0]) if args else "unknown"
    if origin is Literal:
        return _dedupe_join([_literal_to_ts(arg) for arg in get_args(annotation)], separator=" | ")
    if origin in (Union, UnionType):
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return _annotation_to_ts(args[0])
        return "unknown"
    if isinstance(annotation, type) and issubclass(annotation, Enum):
        return _dedupe_join([_literal_to_ts(member.value) for member in annotation], separator=" | ")
    if annotation is str:
        return "string"
    if annotation in (int, float):
        return "number"
    if annotation is bool:
        return "boolean"
    if origin is list:
        args = get_args(annotation)
        return f"{_annotation_to_ts(args[0])}[]" if args else "unknown[]"
    return "unknown"


def _literal_to_ts(value: Any) -> str:
    if isinstance(value, Enum):
        value = value.value
    if value is None or isinstance(value, str | int | float | bool):
        return json.dumps(value)
    return "unknown"


def _settings_schema(plugin: Any) -> dict[str, Any]:
    model = getattr(plugin, "settings_model", None)
    if model is None:
        return {"modelName": None, "schema": None}
    try:
        schema = model.model_json_schema()
    except Exception:
        schema = None
    return {"modelName": model.__name__, "schema": schema}


def _render_typescript(contract: dict[str, Any]) -> str:
    lines = [
        "/* eslint-disable */",
        "// Generated by `mint sdk generate`. Do not edit by hand.",
        "import {",
        "  buildPluginEndpointUrl,",
        "  createPluginClient,",
        "  getPluginPageSelectorItems,",
        "  usePluginClient,",
        "  usePluginSettings,",
        "  type PluginEndpointDefinition,",
        "  type PluginContract,",
        "  type PluginHttpMethod,",
        "} from '@morscherlab/mint-sdk'",
        "import contractJson from './mint-plugin.contract.json'",
        "",
    ]

    settings_type = _settings_type_name(contract)
    settings_schema = contract.get("settings", {}).get("schema")
    if settings_schema and settings_type != "Record<string, unknown>":
        for name, schema in _schema_definitions(settings_schema).items():
            lines.extend(_schema_interface(name, schema))
            lines.append("")
        lines.extend(_schema_interface(settings_type, settings_schema))
        lines.append("")

    for name, schema in contract.get("schemas", {}).items():
        lines.extend(_schema_interface(name, schema))
        lines.append("")

    client_type = _client_type(contract)
    endpoint_names = [endpoint["name"] for endpoint in contract.get("endpoints", [])]
    lines.extend(
        [
            f"export type GeneratedPluginClient = {client_type}",
            f"export type GeneratedPluginSettings = {settings_type}",
            "",
            "export const pluginContract = contractJson as PluginContract",
            "export const pluginContractHash = pluginContract.hash",
            "export const pluginApiPrefix = pluginContract.plugin.apiPrefix",
            "export const pluginRoutesPrefix = pluginContract.plugin.routesPrefix",
            "export const pluginNavItems = pluginContract.plugin.navItems ?? []",
            "export const pluginIcon = pluginContract.plugin.icon ?? ''",
            "export const pluginColor = pluginContract.plugin.color ?? ''",
            "",
            "export const pluginPageSelectorItems = getPluginPageSelectorItems(pluginContract)",
            "",
            (
                "export const generatedPluginEndpoints = "
                f"{_ts_array(endpoint_names)} as const satisfies readonly (keyof GeneratedPluginClient)[]"
            ),
            "export type GeneratedPluginEndpointName = (typeof generatedPluginEndpoints)[number]",
            "export type GeneratedPluginEndpointPayload<N extends GeneratedPluginEndpointName> =",
            "  Parameters<GeneratedPluginClient[N]> extends []",
            "    ? undefined",
            "    : Parameters<GeneratedPluginClient[N]>[0]",
            "export type GeneratedPluginEndpointDefinition = PluginEndpointDefinition & {",
            "  name: GeneratedPluginEndpointName",
            "  method: PluginHttpMethod",
            "  requestType: string | null",
            "  responseType: string | null",
            "}",
            "",
            "export const generatedPluginEndpointDefinitions = {",
        ]
    )
    for endpoint in contract.get("endpoints", []):
        lines.extend(_typescript_endpoint_metadata(endpoint))
    lines.extend(
        [
            "} satisfies Record<GeneratedPluginEndpointName, GeneratedPluginEndpointDefinition>",
            "",
            "export function getGeneratedPluginEndpoint<N extends GeneratedPluginEndpointName>(",
            "  name: N,",
            "): (typeof generatedPluginEndpointDefinitions)[N] {",
            "  return generatedPluginEndpointDefinitions[name]",
            "}",
            "",
            "export function hasGeneratedPluginEndpoint(",
            "  name: string,",
            "): name is GeneratedPluginEndpointName {",
            "  return Object.prototype.hasOwnProperty.call(",
            "    generatedPluginEndpointDefinitions,",
            "    name,",
            "  )",
            "}",
            "",
            "export function buildGeneratedPluginEndpointUrl<N extends GeneratedPluginEndpointName>(",
            "  name: N,",
            "  payload?: GeneratedPluginEndpointPayload<N>,",
            "): string {",
            "  return buildPluginEndpointUrl(",
            "    pluginContract,",
            "    generatedPluginEndpointDefinitions[name],",
            "    payload,",
            "  )",
            "}",
            "",
            "export function useGeneratedPluginContract() {",
            "  return {",
            "    contract: pluginContract,",
            "    contractHash: pluginContractHash,",
            "    apiPrefix: pluginApiPrefix,",
            "    routesPrefix: pluginRoutesPrefix,",
            "    navItems: pluginNavItems,",
            "    pageSelectorItems: pluginPageSelectorItems,",
            "    icon: pluginIcon,",
            "    color: pluginColor,",
            "    endpoints: generatedPluginEndpoints,",
            "    endpointDefinitions: generatedPluginEndpointDefinitions,",
            "    getEndpoint: getGeneratedPluginEndpoint,",
            "    hasEndpoint: hasGeneratedPluginEndpoint,",
            "    buildEndpointUrl: buildGeneratedPluginEndpointUrl,",
            "  }",
            "}",
            "",
            "export const pluginClient = createPluginClient<GeneratedPluginClient>(",
            "  pluginContract,",
            "  {",
            "    endpoints: {",
        ]
    )
    for endpoint in contract.get("endpoints", []):
        lines.extend(
            [
                f"      {endpoint['name']}: {{",
                f"        method: '{endpoint['method']}',",
                f"        path: '{_typescript_endpoint_path(endpoint)}',",
                f"        pathParams: {_ts_array([p['fieldName'] for p in endpoint.get('pathParams', [])])},",
                f"        queryParams: {_ts_query_params(endpoint.get('queryParams', []))},",
                f"        hasBody: {'true' if endpoint.get('requestType') else 'false'},",
                "      },",
            ]
        )
    lines.extend(
        [
            "    },",
            "  },",
            ")",
            "",
            "export function useGeneratedPluginClient(): GeneratedPluginClient {",
            "  return usePluginClient(pluginClient)",
            "}",
            "",
            "export function useGeneratedPluginSettings() {",
            "  return usePluginSettings<GeneratedPluginSettings>()",
            "}",
            "",
        ]
    )
    return "\n".join(lines)


def _settings_type_name(contract: dict[str, Any]) -> str:
    settings = contract.get("settings", {})
    schema = settings.get("schema")
    model_name = settings.get("modelName")
    if isinstance(schema, dict) and isinstance(model_name, str) and model_name:
        return _safe_type_name(model_name)
    return "Record<string, unknown>"


def _safe_type_name(name: str) -> str:
    parts = re.split(r"[^a-zA-Z0-9]+", name)
    parts = [part for part in parts if part]
    if not parts:
        return "GeneratedPluginSettingsSchema"
    result = "".join(part[:1].upper() + part[1:] for part in parts)
    if result[0].isdigit():
        result = f"Settings{result}"
    return result


def _schema_definitions(schema: dict[str, Any]) -> dict[str, Any]:
    definitions = schema.get("$defs") or schema.get("definitions") or {}
    if not isinstance(definitions, dict):
        return {}
    return {
        _safe_type_name(str(name)): definition
        for name, definition in definitions.items()
        if isinstance(definition, dict)
    }


def _schema_interface(name: str, schema: dict[str, Any]) -> list[str]:
    required = set(schema.get("required", []))
    properties = schema.get("properties", {})
    lines = [f"export interface {name} {{"]
    if not properties:
        lines.append("  [key: string]: unknown")
    for prop_name, prop_schema in properties.items():
        optional = "" if prop_name in required else "?"
        lines.append(f"  {_ts_property_name(str(prop_name))}{optional}: {_schema_to_ts(prop_schema)}")
    lines.append("}")
    return lines


def _schema_to_ts(schema: dict[str, Any]) -> str:
    if "$ref" in schema:
        return _safe_type_name(str(schema["$ref"]).split("/")[-1])
    if "enum" in schema:
        return " | ".join(json.dumps(value) for value in schema["enum"])
    any_of = schema.get("anyOf")
    if isinstance(any_of, list):
        return _dedupe_join([_schema_to_ts(item) for item in any_of], separator=" | ")
    one_of = schema.get("oneOf")
    if isinstance(one_of, list):
        return _dedupe_join([_schema_to_ts(item) for item in one_of], separator=" | ")
    all_of = schema.get("allOf")
    if isinstance(all_of, list):
        return _dedupe_join([_schema_to_ts(item) for item in all_of], separator=" & ")
    schema_type = schema.get("type")
    if isinstance(schema_type, list):
        return _dedupe_join([_schema_to_ts({"type": item}) for item in schema_type], separator=" | ")
    if schema_type == "null":
        return "null"
    if schema_type == "string":
        return "string"
    if schema_type in {"number", "integer"}:
        return "number"
    if schema_type == "boolean":
        return "boolean"
    if schema_type == "array":
        return f"{_array_item_ts(schema.get('items', {}))}[]"
    if schema_type == "object":
        additional = schema.get("additionalProperties")
        if isinstance(additional, dict):
            return f"Record<string, {_schema_to_ts(additional)}>"
        properties = schema.get("properties")
        if isinstance(properties, dict) and properties:
            inner = "; ".join(
                f"{_ts_property_name(str(key))}: {_schema_to_ts(value)}"
                for key, value in properties.items()
            )
            return f"{{ {inner} }}"
        return "Record<string, unknown>"
    return "unknown"


def _dedupe_join(types: list[str], *, separator: str) -> str:
    deduped = list(dict.fromkeys(item for item in types if item))
    return separator.join(deduped) if deduped else "unknown"


def _array_item_ts(schema: dict[str, Any]) -> str:
    return _parenthesize_array_item_type(_schema_to_ts(schema))


def _parenthesize_array_item_type(item_type: str) -> str:
    if (" | " in item_type or " & " in item_type) and not (
        item_type.startswith("(") and item_type.endswith(")")
    ):
        return f"({item_type})"
    return item_type


def _ts_property_name(name: str) -> str:
    if re.fullmatch(r"[A-Za-z_$][A-Za-z0-9_$]*", name):
        return name
    return json.dumps(name)


def _client_type(contract: dict[str, Any]) -> str:
    endpoints = contract.get("endpoints", [])
    if not endpoints:
        return "Record<string, never>"
    lines = ["{"]
    for endpoint in endpoints:
        lines.append(f"  {endpoint['name']}: {_endpoint_signature(endpoint)}")
    lines.append("}")
    return "\n".join(lines)


def _endpoint_signature(endpoint: dict[str, Any]) -> str:
    response = endpoint.get("responseType") or "unknown"
    request = endpoint.get("requestType")
    path_params = endpoint.get("pathParams", [])
    query_params = endpoint.get("queryParams", [])
    has_params = bool(path_params or query_params)
    if request and has_params:
        fields = _param_fields(path_params, query_params)
        return f"(params: {{ {fields}; body: {request} }}) => Promise<{response}>"
    if request:
        return f"(body: {request}) => Promise<{response}>"
    if has_params:
        fields = _param_fields(path_params, query_params)
        required = any(_path_param_required(param) for param in path_params) or any(
            param.get("required", False) for param in query_params
        )
        optional = "" if required else "?"
        return f"(params{optional}: {{ {fields} }}) => Promise<{response}>"
    return f"() => Promise<{response}>"


def _path_param_required(param: dict[str, Any]) -> bool:
    return not _is_inferred_experiment_param(param)


def _is_inferred_experiment_param(param: dict[str, Any]) -> bool:
    return param.get("fieldName") == "experimentId"


def _param_fields(path_params: list[dict[str, Any]], query_params: list[dict[str, Any]]) -> str:
    fields: list[str] = []
    for param in path_params:
        optional = "?" if _is_inferred_experiment_param(param) else ""
        fields.append(f"{param['fieldName']}{optional}: {param['type']}")
    for param in query_params:
        optional = "" if param.get("required") else "?"
        fields.append(f"{param['fieldName']}{optional}: {param['type']}")
    return "; ".join(fields)


def _typescript_endpoint_path(endpoint: dict[str, Any]) -> str:
    path = endpoint["path"]
    for param in endpoint.get("pathParams", []):
        path = path.replace(f"{{{param['name']}}}", f"{{{param['fieldName']}}}")
    return path


def _typescript_endpoint_metadata(endpoint: dict[str, Any]) -> list[str]:
    name = endpoint["name"]
    return [
        f"  {name}: {{",
        f"    name: '{name}',",
        f"    method: '{endpoint['method']}',",
        f"    path: '{_typescript_endpoint_path(endpoint)}',",
        f"    pathParams: {_ts_array([p['fieldName'] for p in endpoint.get('pathParams', [])])},",
        f"    queryParams: {_ts_query_params(endpoint.get('queryParams', []))},",
        f"    hasBody: {'true' if endpoint.get('requestType') else 'false'},",
        f"    requestType: {_ts_nullable_string(endpoint.get('requestType'))},",
        f"    responseType: {_ts_nullable_string(endpoint.get('responseType'))},",
        "  },",
    ]


def _ts_array(values: list[str]) -> str:
    return "[" + ", ".join(json.dumps(value) for value in values) + "]"


def _ts_nullable_string(value: str | None) -> str:
    return json.dumps(value) if value else "null"


def _ts_query_params(params: list[dict[str, Any]]) -> str:
    return "[" + ", ".join(_ts_query_param(param) for param in params) + "]"


def _ts_query_param(param: dict[str, Any]) -> str:
    parts = [
        f"name: {json.dumps(param['name'])}",
        f"fieldName: {json.dumps(param['fieldName'])}",
        f"type: {json.dumps(param['type'])}",
        f"required: {str(bool(param.get('required'))).lower()}",
    ]
    return "{ " + ", ".join(parts) + " }"
