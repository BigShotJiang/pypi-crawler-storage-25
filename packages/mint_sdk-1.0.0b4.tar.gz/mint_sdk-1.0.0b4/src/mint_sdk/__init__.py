"""
MINT Plugin SDK

SDK for building analysis plugins that integrate with the MINT platform.
"""

from __future__ import annotations

from importlib import import_module

try:
    from mint_sdk._version import __version__
except ImportError:
    __version__ = "0.0.0"

_LAZY_EXPORTS = {
    # API Client
    "MINTClient": ("mint_sdk.client", "MINTClient"),
    # Core plugin classes
    "AnalysisPlugin": ("mint_sdk.plugin", "AnalysisPlugin"),
    "PluginMetadata": ("mint_sdk.models", "PluginMetadata"),
    "PluginCapabilities": ("mint_sdk.models", "PluginCapabilities"),
    "PluginNavItem": ("mint_sdk.models", "PluginNavItem"),
    "PluginType": ("mint_sdk.models", "PluginType"),
    "PlatformContext": ("mint_sdk.context", "PlatformContext"),
    # Lifecycle types
    "HealthStatus": ("mint_sdk.plugin", "HealthStatus"),
    "PluginHealth": ("mint_sdk.plugin", "PluginHealth"),
    "LifecycleHookResult": ("mint_sdk.plugin", "LifecycleHookResult"),
    # Exceptions
    "PluginException": ("mint_sdk.exceptions", "PluginException"),
    "ValidationException": ("mint_sdk.exceptions", "ValidationException"),
    "PermissionException": ("mint_sdk.exceptions", "PermissionException"),
    "ConfigurationException": ("mint_sdk.exceptions", "ConfigurationException"),
    "RepositoryException": ("mint_sdk.exceptions", "RepositoryException"),
    "NotFoundException": ("mint_sdk.exceptions", "NotFoundException"),
    "ConflictException": ("mint_sdk.exceptions", "ConflictException"),
    "PluginLifecycleException": ("mint_sdk.exceptions", "PluginLifecycleException"),
    # Local database
    "LocalDatabase": ("mint_sdk.local_database", "LocalDatabase"),
    "LocalDatabaseConfig": ("mint_sdk.local_database", "LocalDatabaseConfig"),
    # Data models
    "Experiment": ("mint_sdk.repositories", "Experiment"),
    "DesignData": ("mint_sdk.repositories", "DesignData"),
    "PluginAnalysisResult": ("mint_sdk.repositories", "PluginAnalysisResult"),
    "User": ("mint_sdk.repositories", "User"),
    "UserPluginRole": ("mint_sdk.repositories", "UserPluginRole"),
    # Repository protocols
    "ExperimentRepository": ("mint_sdk.repositories", "ExperimentRepository"),
    "PluginDataRepository": ("mint_sdk.repositories", "PluginDataRepository"),
    "PluginRoleRepository": ("mint_sdk.repositories", "PluginRoleRepository"),
    "UserRepository": ("mint_sdk.repositories", "UserRepository"),
    "PlatformConfig": ("mint_sdk.repositories", "PlatformConfig"),
    # Export utilities
    "auto_json_to_tree": ("mint_sdk.export", "auto_json_to_tree"),
    "auto_json_to_csv": ("mint_sdk.export", "auto_json_to_csv"),
    "auto_json_to_summary": ("mint_sdk.export", "auto_json_to_summary"),
    # Logging
    "get_plugin_logger": ("mint_sdk.logging", "get_plugin_logger"),
    # Schema conversion
    "settings_model_to_form_fields": ("mint_sdk.schema", "settings_model_to_form_fields"),
    "settings_model_to_settings_schema": ("mint_sdk.schema", "settings_model_to_settings_schema"),
    # R bridge
    "RAnalysisBridge": ("mint_sdk.r", "RAnalysisBridge"),
    "RScriptSpec": ("mint_sdk.r", "RScriptSpec"),
    "RBridgeError": ("mint_sdk.r", "RBridgeError"),
    "RRunProvenance": ("mint_sdk.r", "RRunProvenance"),
    # Bio data templates
    "BioTemplateEnvelope": ("mint_sdk.templates", "BioTemplateEnvelope"),
    "TEMPLATE_COLLECTION_KEY": ("mint_sdk.templates", "TEMPLATE_COLLECTION_KEY"),
    "BioTemplateCatalogEntry": ("mint_sdk.templates", "BioTemplateCatalogEntry"),
    "BioTemplatePackEntry": ("mint_sdk.templates", "BioTemplatePackEntry"),
    "BioTemplatePresetEntry": ("mint_sdk.templates", "BioTemplatePresetEntry"),
    "PlateMapTemplate": ("mint_sdk.templates", "PlateMapTemplate"),
    "SampleSheetTemplate": ("mint_sdk.templates", "SampleSheetTemplate"),
    "SamplePrepTemplate": ("mint_sdk.templates", "SamplePrepTemplate"),
    "CalibrationCurveTemplate": ("mint_sdk.templates", "CalibrationCurveTemplate"),
    "DoseResponseTemplate": ("mint_sdk.templates", "DoseResponseTemplate"),
    "FlowCytometryPanelTemplate": ("mint_sdk.templates", "FlowCytometryPanelTemplate"),
    "InstrumentRunTemplate": ("mint_sdk.templates", "InstrumentRunTemplate"),
    "QpcrPlateTemplate": ("mint_sdk.templates", "QpcrPlateTemplate"),
    "TimeCourseTemplate": ("mint_sdk.templates", "TimeCourseTemplate"),
    "AssayMatrixTemplate": ("mint_sdk.templates", "AssayMatrixTemplate"),
    "ReagentListTemplate": ("mint_sdk.templates", "ReagentListTemplate"),
    "ProtocolStepsTemplate": ("mint_sdk.templates", "ProtocolStepsTemplate"),
    "TemplateValidationError": ("mint_sdk.templates", "TemplateValidationError"),
    "get_template_info": ("mint_sdk.templates", "get_template_info"),
    "list_template_catalog": ("mint_sdk.templates", "list_template_catalog"),
    "require_template_info": ("mint_sdk.templates", "require_template_info"),
    "get_template_pack_info": ("mint_sdk.templates", "get_template_pack_info"),
    "list_template_packs": ("mint_sdk.templates", "list_template_packs"),
    "require_template_pack_info": ("mint_sdk.templates", "require_template_pack_info"),
    "get_template_preset_info": ("mint_sdk.templates", "get_template_preset_info"),
    "list_template_presets": ("mint_sdk.templates", "list_template_presets"),
    "require_template_preset_info": ("mint_sdk.templates", "require_template_preset_info"),
    "save_template_preset_collection": ("mint_sdk.templates", "save_template_preset_collection"),
    "save_template": ("mint_sdk.templates", "save_template"),
    "load_template": ("mint_sdk.templates", "load_template"),
    "create_template_collection": ("mint_sdk.templates", "create_template_collection"),
    "create_template_preset_collection": ("mint_sdk.templates", "create_template_preset_collection"),
    "create_elisa_assay_collection": ("mint_sdk.templates", "create_elisa_assay_collection"),
    "create_flow_cytometry_assay_collection": ("mint_sdk.templates", "create_flow_cytometry_assay_collection"),
    "create_lcms_batch_collection": ("mint_sdk.templates", "create_lcms_batch_collection"),
    "create_qpcr_expression_collection": ("mint_sdk.templates", "create_qpcr_expression_collection"),
    "create_wellplate_screen_collection": ("mint_sdk.templates", "create_wellplate_screen_collection"),
    "create_western_blot_assay_collection": ("mint_sdk.templates", "create_western_blot_assay_collection"),
    "extract_template_collection": ("mint_sdk.templates", "extract_template_collection"),
    "save_template_collection": ("mint_sdk.templates", "save_template_collection"),
    "load_template_collection": ("mint_sdk.templates", "load_template_collection"),
    # Migration framework
    "MigrationOps": ("mint_sdk.migrations", "MigrationOps"),
    "MigrationResult": ("mint_sdk.migrations", "MigrationResult"),
    "MigrationRunner": ("mint_sdk.migrations", "MigrationRunner"),
    "PluginMigration": ("mint_sdk.migrations", "PluginMigration"),
    # App factory and helpers
    "create_standalone_app": ("mint_sdk.app", "create_standalone_app"),
    "SPAStaticFiles": ("mint_sdk.app", "SPAStaticFiles"),
    "PluginDependency": ("mint_sdk.app", "PluginDependency"),
    "require_context": ("mint_sdk.app", "require_context"),
}

__all__ = [
    # API Client
    "MINTClient",
    # Core plugin classes
    "AnalysisPlugin",
    "PluginMetadata",
    "PluginCapabilities",
    "PluginNavItem",
    "PluginType",
    "PlatformContext",
    # Lifecycle types
    "HealthStatus",
    "PluginHealth",
    "LifecycleHookResult",
    # Exceptions
    "PluginException",
    "ValidationException",
    "PermissionException",
    "ConfigurationException",
    "RepositoryException",
    "NotFoundException",
    "ConflictException",
    "PluginLifecycleException",
    # Local database
    "LocalDatabase",
    "LocalDatabaseConfig",
    # Data models
    "Experiment",
    "DesignData",
    "PluginAnalysisResult",
    "User",
    "UserPluginRole",
    # Repository protocols
    "ExperimentRepository",
    "PluginDataRepository",
    "PluginRoleRepository",
    "UserRepository",
    "PlatformConfig",
    # Export utilities
    "auto_json_to_tree",
    "auto_json_to_csv",
    "auto_json_to_summary",
    # Logging
    "get_plugin_logger",
    # Schema conversion
    "settings_model_to_form_fields",
    "settings_model_to_settings_schema",
    # R bridge
    "RAnalysisBridge",
    "RScriptSpec",
    "RBridgeError",
    "RRunProvenance",
    # Bio data templates
    "BioTemplateEnvelope",
    "TEMPLATE_COLLECTION_KEY",
    "BioTemplateCatalogEntry",
    "BioTemplatePackEntry",
    "BioTemplatePresetEntry",
    "PlateMapTemplate",
    "SampleSheetTemplate",
    "SamplePrepTemplate",
    "CalibrationCurveTemplate",
    "DoseResponseTemplate",
    "FlowCytometryPanelTemplate",
    "InstrumentRunTemplate",
    "QpcrPlateTemplate",
    "TimeCourseTemplate",
    "AssayMatrixTemplate",
    "ReagentListTemplate",
    "ProtocolStepsTemplate",
    "TemplateValidationError",
    "get_template_info",
    "list_template_catalog",
    "require_template_info",
    "get_template_pack_info",
    "list_template_packs",
    "require_template_pack_info",
    "get_template_preset_info",
    "list_template_presets",
    "require_template_preset_info",
    "save_template_preset_collection",
    "save_template",
    "load_template",
    "create_template_collection",
    "create_template_preset_collection",
    "create_elisa_assay_collection",
    "create_flow_cytometry_assay_collection",
    "create_lcms_batch_collection",
    "create_qpcr_expression_collection",
    "create_wellplate_screen_collection",
    "create_western_blot_assay_collection",
    "extract_template_collection",
    "save_template_collection",
    "load_template_collection",
    # Migration framework
    "MigrationOps",
    "MigrationResult",
    "MigrationRunner",
    "PluginMigration",
    # App factory and helpers
    "create_standalone_app",
    "SPAStaticFiles",
    "PluginDependency",
    "require_context",
]


def __getattr__(name: str):
    """Load public SDK symbols on first access.

    Keeping package-root exports lazy avoids importing optional-heavy modules
    such as SQLAlchemy and httpx during lightweight submodule imports like the
    CLI entry point.
    """
    try:
        module_name, attr_name = _LAZY_EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc

    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
