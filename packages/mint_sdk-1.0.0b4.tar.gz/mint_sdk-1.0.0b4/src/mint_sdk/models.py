"""
Data models for MINT plugin metadata and capabilities.
"""

from dataclasses import dataclass, field
from enum import Enum


class PluginType(str, Enum):
    """Plugin category determining database access permissions."""

    ANALYSIS = "analysis"
    EXPERIMENT_DESIGN = "experiment_design"


@dataclass(slots=True)
class PluginCapabilities:
    """Declares what platform features a plugin needs."""

    requires_auth: bool = False
    requires_database: bool = False
    requires_experiments: bool = False
    requires_shared_database: bool = False
    # Optional integrations
    supports_experiment_linking: bool = False


@dataclass(slots=True)
class PluginNavItem:
    """Navigation metadata for a plugin page/function; use a stable ``id`` so homepage plugin
    cards, generated contracts, and integrated ``AppTopBar`` page switching stay aligned
    across route changes.
    """

    path: str
    label: str
    icon: str = ""  # SVG path data | data URL (raster) | https:// URL
    description: str = ""
    requires_auth: bool = False
    requires_admin: bool = False
    requires_feature: str | None = None
    id: str = ""


@dataclass(slots=True)
class PluginMetadata:
    """Metadata describing an analysis plugin."""

    name: str
    version: str
    description: str
    analysis_type: str  # "metabolomics", "proteomics", "genomics", etc.
    routes_prefix: str  # "/rfa", "/proteo", etc.
    plugin_type: PluginType = PluginType.ANALYSIS
    capabilities: PluginCapabilities = field(default_factory=PluginCapabilities)

    # Optional metadata
    author: str = ""
    homepage: str = ""
    license: str = ""
    icon: str = ""  # SVG path data | data URL (raster) | https:// URL
    color: str = ""  # Optional brand color as a hex string, e.g. "#0EA5E9"
    nav_items: list[PluginNavItem] = field(default_factory=list)

    # Schema version for plugin data persistence (used by save_design defaults)
    schema_version: str = "1.0"

    # Optional dependency declaration
    # List of plugin names that must be loaded before this plugin.
    dependencies: list[str] = field(default_factory=list)
