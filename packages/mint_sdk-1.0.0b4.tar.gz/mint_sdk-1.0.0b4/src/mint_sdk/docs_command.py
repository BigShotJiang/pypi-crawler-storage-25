"""Handler for the ``mint docs`` CLI command."""

from __future__ import annotations

import difflib
import json
import sys
from pathlib import Path
from typing import Any

from mint_sdk.deprecated_apis import DEPRECATED_API_DOC as _DEPRECATED_API_DOC
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_COMPONENTS as _DEPRECATED_FRONTEND_COMPONENTS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_COMPOSABLES as _DEPRECATED_FRONTEND_COMPOSABLES,
)
from mint_sdk.docs.cache import (
    clear_cache as clear_docs_cache,
)
from mint_sdk.docs.cache import (
    find_platform_root,
    get_cache_dir,
    is_cache_fresh,
    read_cache,
    write_cache,
)
from mint_sdk.docs.formatter import (
    format_category,
    format_component_group,
    format_components_grouped,
    format_composables,
    format_css_overview,
    format_css_section,
    format_frontend_component_chooser,
    format_item_detail,
    format_sdk_overview,
    format_search_results,
    format_toc,
)
from mint_sdk.templates import (
    get_template_info,
    get_template_pack_info,
    get_template_preset_info,
    list_template_catalog,
    list_template_packs,
    list_template_presets,
)

_BUNDLED_DIR = Path(__file__).parent / "docs" / "bundled"

_TEMPLATE_DOCS: dict[str, dict[str, Any]] = {
    entry.name: entry.model_dump(mode="json")
    for entry in list_template_catalog()
}
_TEMPLATE_PACK_DOCS: dict[str, dict[str, Any]] = {
    entry.name: entry.model_dump(mode="json")
    for entry in list_template_packs()
}
_TEMPLATE_PRESET_DOCS: dict[str, dict[str, Any]] = {
    entry.name: entry.model_dump(mode="json")
    for entry in list_template_presets()
}
_R_BRIDGE_DOC: dict[str, Any] = {
    "name": "r-bridge",
    "purpose": "Run R scripts behind typed FastAPI/Pydantic plugin endpoints and save result payloads.",
    "python_exports": [
        "RAnalysisBridge",
        "RScriptSpec",
        "RBridgeError",
        "RRunProvenance",
    ],
    "scaffold_commands": [
        "mint add r-analysis drp-fit --page",
        "mint init --template r-analysis",
    ],
    "diagnostic_commands": [
        "mint doctor --r --explain",
        "MINT_RSCRIPT=/path/to/Rscript mint doctor --r",
    ],
    "diagnostic_checks": [
        "Rscript executable",
        "R dependency lock file",
        "jsonlite package declaration",
        "R bridge helper (r_scripts/mint_bridge.R)",
    ],
    "generated_files": [
        "schemas/<analysis>_r.py",
        "services/<analysis>_r.py",
        "routers/<analysis>_r.py",
        "r_scripts/<analysis>.R",
        "r_scripts/mint_bridge.R",
        "frontend/src/composables/use<Analysis>RAnalysis.ts",
        "frontend/src/views/<Analysis>RAnalysisView.vue",
    ],
    "route_pattern": "POST /r/<analysis>/run/{experiment_id}",
    "generated_client_endpoint": "run<Analysis>()",
    "frontend_composable": "use<Analysis>RAnalysis()",
    "frontend_helpers": [
        "currentExperimentId",
        "hasExperiment",
        "runCurrent()",
        "runCurrentWithParameters(parameters)",
    ],
    "generated_frontend_page": [
        "ControlWorkspaceView",
        "defineControlModel()",
        '<ControlWorkspaceView v-model="values" :model="workspaceModel" />',
    ],
    "r_environment": [
        "MINT_R_INPUT",
        "MINT_R_OUTPUT",
        "MINT_EXPERIMENT_ID",
        "MINT_R_ARTIFACT_DIR",
    ],
    "r_helper_functions": [
        "mint_read_input()",
        "mint_parameters(payload)",
        "mint_parameter(name, default)",
        "mint_required_parameter(name)",
        "mint_write_output(result)",
        "mint_experiment_id()",
        "mint_artifact_dir()",
        "mint_artifact_path(...)",
    ],
    "dependency_files": [
        "renv.lock",
        "r-requirements.txt",
    ],
}
_FRONTEND_API_MIGRATION_DOC: dict[str, Any] = {
    "name": "frontend-api",
    "purpose": (
        "Migrate plugin frontends from hand-written API prefixes to generated "
        "contract clients."
    ),
    "legacy_patterns": [
        "import.meta.env.VITE_API_PREFIX",
        "useApi({ baseUrl })",
        "fetch('/api/<plugin>/...')",
        "axios.get('/api/<plugin>/...')",
        "api.get('/api/<plugin>/...')",
    ],
    "diagnostics": [
        "mint doctor --explain",
        "mint doctor --json",
    ],
    "commands": [
        "mint sdk generate",
        "mint docs contract .",
        "mint sdk generate --check",
    ],
    "generated_import": (
        "import { useGeneratedPluginClient, useGeneratedPluginContract } "
        "from './generated/mint-plugin'"
    ),
    "generated_client": "const pluginClient = useGeneratedPluginClient()",
    "generated_contract": "const pluginContract = useGeneratedPluginContract()",
    "sample_call": "await pluginClient.<endpoint>({ body })",
    "endpoint_lookup": "pluginContract.getEndpoint('<endpoint>')",
    "endpoint_url": "pluginContract.buildEndpointUrl('<endpoint>', { body })",
    "platform_data_helpers": [
        "useCurrentExperiment()",
        "useExperimentData()",
        "useExperimentSelector()",
        "useTemplateCollection()",
    ],
}
_FRONTEND_COMPONENT_CONSOLIDATION_DOC: dict[str, Any] = {
    "name": "frontend-component-consolidation",
    "purpose": (
        "Keep plugin frontends on a small canonical component surface before "
        "dropping down to lower-level primitives, private subpaths, or retired APIs."
    ),
    "command": "mint docs frontend consolidate",
    "diagnostics": [
        "mint docs frontend choose",
        "mint doctor --explain",
        "mint docs deprecated-apis",
    ],
    "principles": [
        "Start from task-level workspace components before assembling layout primitives.",
        (
            "Use PluginWorkspaceView for custom plugin chrome before hand-assembling "
            "AppLayout, AppTopBar, and AppSidebar."
        ),
        (
            "Use PluginWorkspaceView experimentShell for the common AppTopBar "
            "experiment chip, selector, save, and detach flow."
        ),
        (
            "Use PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty when "
            "route or tab children own a LEAF-style sidebar through Teleport."
        ),
        (
            "Use defineControlModel() as the shared data model for forms, "
            "settings, sidebars, and generated component bindings/props."
        ),
        (
            "Put default overrides in controlOptions.initialValues; FormBuilder, "
            "AppSidebar, SettingsModal, and ControlWorkspaceView read the same values."
        ),
        (
            'Treat AppSidebar variant="analysis" as the shared LEAF-style plugin '
            "sidebar design language; override it only for genuinely custom chrome."
        ),
        "Prefer generated plugin contract clients over hand-written frontend API helpers.",
        (
            "Treat retired exports and private package subpaths as migration "
            "targets, not examples for new code."
        ),
    ],
    "layers": [
        {
            "task": "Custom plugin chrome and route navigation",
            "canonical": ["PluginWorkspaceView"],
            "folds": [
                "manual AppLayout + AppTopBar + AppSidebar shell",
                "manual AppTopBar + AppPageSelector composition",
                "manual AppTopBar + AppPillNav composition",
                "manual sidebar active-view synchronization",
            ],
            "drop_down_only_for": [
                "dual sidebars",
                "non-workspace sidebar targets",
                "bespoke topbar experiment chip behavior",
            ],
            "doctor_detection": "Frontend component guidance",
        },
        {
            "task": "Whole analysis/settings page",
            "canonical": ["ControlWorkspaceView", "defineControlModel"],
            "folds": [
                "manual AppLayout + AppTopBar + FormBuilder page",
                "manual AppLayout + AppSidebar + FormBuilder page",
                "manual AppTopBar + AppSidebar + FormBuilder workspace",
                "manual sidebar/form value synchronization",
                "useControlWorkspace(model.controls, model.controlOptions) for default workspace rendering",
            ],
            "drop_down_only_for": [
                "custom page chrome",
                "custom sidebar section rendering",
                "manual access to generated component bindings or props",
            ],
            "doctor_detection": "Frontend component guidance",
        },
        {
            "task": "Schema-driven form or settings modal",
            "canonical": ["FormBuilder", "SettingsModal", "defineControlModel"],
            "folds": [
                "FormSection",
                "FormFieldRenderer",
                "manual SettingsModal tabs for basic fields",
                "raw field renderer loops",
            ],
            "drop_down_only_for": [
                "single custom field overrides",
                "bespoke settings widgets",
            ],
            "doctor_detection": "Deprecated SDK APIs / Frontend component guidance",
        },
        {
            "task": "Biology design_data pages",
            "canonical": [
                "BioTemplatePresetWorkspaceView",
                "BioTemplatePackWorkspaceView",
                "useBioTemplateWorkspace",
            ],
            "folds": [
                "manual PlateMapEditor + WellPlate + SampleLegend wiring",
                "manual DataFrame + SampleSelector + GroupAssigner sample-sheet pages",
                "separate template control forms plus manual component adapters",
            ],
            "drop_down_only_for": [
                "custom template renderer layouts",
                "specialized plate editor interactions",
            ],
            "doctor_detection": "Frontend component guidance",
        },
        {
            "task": "Dose-design controls",
            "canonical": [
                "DoseDesignWorkspaceView",
                "defineDoseDesignControlModel",
                "defineWellPlateDoseComponentBindings",
            ],
            "folds": [
                "hand-wired ControlWorkspaceView dose-design slots",
                "manual WellPlate + DoseCalculator prop mapping",
                "manual componentBindingsById bookkeeping",
                "manual apply-to-wells synchronization",
            ],
            "drop_down_only_for": [
                "custom WellPlate + DoseCalculator layouts",
                "custom low-level prop maps via defineWellPlateDoseControlProps",
                "custom dose calculator algorithm UIs",
            ],
            "doctor_detection": "Frontend component guidance",
        },
        {
            "task": "Feedback and API access",
            "canonical": ["AppToastContainer", "useGeneratedPluginClient"],
            "folds": [
                "ToastNotification",
                "usePluginApi",
                "useApi({ baseUrl })",
                "raw /api fetch or axios calls",
            ],
            "drop_down_only_for": [
                "non-plugin external APIs",
            ],
            "doctor_detection": "Deprecated SDK APIs / Frontend API wiring",
        },
    ],
    "retired_apis": [
        {
            "avoid": "FormSection",
            "prefer": "FormBuilder",
            "reason": "FormBuilder owns section rendering, field slots, validation, and actions from one schema.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "FormFieldRenderer",
            "prefer": "FormBuilder",
            "reason": "Field rendering should stay behind FormBuilder unless a field slot is being customized.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "SettingsButton",
            "prefer": "AppTopBar settingsConfig or SettingsModal",
            "reason": "Settings entry points now live in the page chrome or schema-driven modal.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "AppPageSelector",
            "prefer": "AppTopBar pageSelector",
            "reason": "Route-level page switching belongs in AppTopBar metadata instead of a standalone dropdown.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "AppPillNav",
            "prefer": "AppTopBar pillNav",
            "reason": (
                "Top-level mode switching belongs in AppTopBar pillNav props "
                "instead of a standalone nav primitive."
            ),
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "GroupingModal",
            "prefer": "AutoGroupModal",
            "reason": "AutoGroupModal is the current grouping workflow for CSV/sample metadata.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "ToastNotification",
            "prefer": "AppToastContainer",
            "reason": "Toast lifecycle and stacking belong in one app-level container.",
            "migration_guide": "mint docs deprecated-apis",
        },
        {
            "avoid": "usePluginApi",
            "prefer": "useGeneratedPluginClient",
            "reason": "Generated clients keep frontend calls aligned with backend contracts and plugin routes.",
            "migration_guide": "mint docs frontend-api",
        },
    ],
    "legacy_prop_patterns": [
        {
            "avoid": "manual AppLayout + AppTopBar + AppSidebar shell",
            "prefer": "PluginWorkspaceView",
        },
        {
            "avoid": "AppSidebar items / active-id",
            "prefer": (
                'AppSidebar panels / active-view with variant="analysis" for '
                "LEAF-style analysis chrome"
            ),
        },
        {
            "avoid": "AppTopBar floating / sticky / pages / current-page-id / tabs / current-tab-id",
            "prefer": "AppTopBar variant / pageSelector / current-page-selector-id / pillNav / current-pill-id",
        },
        {
            "avoid": (
                "ControlWorkspaceView/DoseDesignWorkspaceView navigation prop "
                'or ControlWorkspaceView v-bind="workspaceModel"'
            ),
            "prefer": "default pill navigation and :model=\"workspaceModel\"",
        },
    ],
    "next_steps": [
        "Use mint docs frontend choose for task-level component selection.",
        (
            "Run mint doctor --explain in plugin repos to find deprecated "
            "exports, private imports, and hand-wired API calls."
        ),
        "Use mint docs deprecated-apis while removing retired API usage from plugin code.",
        "After plugin repos are clean, keep examples on canonical APIs and delete stale references.",
    ],
}
_FRONTEND_SIDEBAR_LANGUAGE_DOC: dict[str, Any] = {
    "name": "frontend-sidebar-language",
    "purpose": (
        "Treat the LEAF-style plugin sidebar as a shared MINT analysis/design "
        "workbench language instead of per-plugin chrome."
    ),
    "command": "mint docs frontend sidebar",
    "canonical_component": 'AppSidebar variant="analysis"',
    "source_patterns": [
        "MS Designer: 20rem sidebar, route-owned Teleport target, pinned action bar",
        "DRP: AppSidebar panels/slots for dense design tools beside WellPlate",
        "MS Uploader: AppSidebar panels/slots for data and visualization tools",
        "HMDB: AppSidebar search controls bound to the active AppTopBar page",
    ],
    "principles": [
        "Use the sidebar for contextual tools that change with the active page or tab.",
        (
            "Keep primary scientific content in the main pane; keep parameters, "
            "import controls, filters, and run actions in the sidebar."
        ),
        (
            'Default to AppSidebar variant="analysis" so width, static layout, '
            "section cards, collapse behavior, and mobile guidance stay SDK-owned."
        ),
        "Use defineControlModel() or defineControls() when the sidebar is mostly form controls.",
        (
            "Use PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty with "
            "Teleport when route children own a full workspace sidebar; drop to "
            "AppSidebar contentId/showWhenEmpty only inside custom shells."
        ),
        (
            "Put run/save/download actions in the footer slot so they stay "
            "pinned below the scrollable controls."
        ),
    ],
    "recipes": [
        {
            "task": "Model-driven analysis controls",
            "use": "AppSidebar v-model + :model",
            "start": [
                "defineControlModel",
                "AppSidebar",
                "FormBuilder",
            ],
            "snippet": [
                "const sidebarModel = defineControlModel({ views: { run: { sections: "
                "{ parameters: { controls: { threshold: 0.05 } } } } } })",
                '<AppSidebar v-model="values" :model="sidebarModel" variant="analysis" />',
            ],
        },
        {
            "task": "Route-owned or tab-owned tools",
            "use": "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty + Teleport",
            "start": [
                "PluginWorkspaceView",
                "Teleport",
            ],
            "snippet": [
                '<PluginWorkspaceView title="Sequence" sidebar-content-id="seqgen-sidebar" show-sidebar-when-empty>',
                '  <template #footer><BaseButton variant="cta">Generate</BaseButton></template>',
                '<Teleport to="#seqgen-sidebar" defer><SequenceSettings /></Teleport>',
                "</PluginWorkspaceView>",
            ],
        },
        {
            "task": "Custom section rendering with SDK chrome",
            "use": "AppSidebar panels + section slots",
            "start": [
                "SidebarToolSection",
                "AppSidebar",
                "section-* slots",
            ],
            "snippet": [
                '<AppSidebar :panels="sidebarPanels" active-view="layout" variant="analysis">',
                "  <template #section-drugs><DrugEditor /></template>",
                "</AppSidebar>",
            ],
        },
    ],
    "migration_targets": [
        {
            "from": 'manual <div id="...sidebar"> shell',
            "to": "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty",
        },
        {
            "from": "manual width, border, static positioning, collapse chrome",
            "to": 'AppSidebar variant="analysis"',
        },
        {
            "from": "action buttons mixed into scrollable control content",
            "to": "AppSidebar footer slot",
        },
        {
            "from": "manual form/sidebar value synchronization",
            "to": "defineControlModel() shared values",
        },
    ],
    "diagnostics": [
        "mint docs frontend choose",
        "mint docs frontend consolidate",
        "mint doctor --explain",
    ],
}


def cmd_docs(
    *,
    path_args: list[str] | None = None,
    json_output: bool = False,
    no_cache: bool = False,
    clear_cache: bool = False,
) -> None:
    """Execute the ``mint docs`` command."""
    path_args = path_args or []
    as_json: bool = json_output
    do_clear: bool = clear_cache

    # Locate platform root (optional — bundled docs used as fallback)
    try:
        root: Path | None = find_platform_root()
    except FileNotFoundError:
        root = None

    cache_dir = get_cache_dir(root) if root else None

    # Handle --clear-cache
    if do_clear:
        if cache_dir:
            clear_docs_cache(cache_dir)
            print("Cache cleared.")
        else:
            print("No cache to clear (not inside MINT platform tree).")
        return

    # Plugin-local contract docs do not need SDK manifest extraction.
    if path_args and path_args[0] == "contract":
        _route_contract(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] == "template":
        _route_template(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] == "template-pack":
        _route_template_pack(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {"template-preset", "template-presets"}:
        _route_template_preset(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {"r-bridge", "r-analysis"}:
        _route_r_bridge(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {
        "frontend-api",
        "frontend-api-migration",
        "contract-migration",
    }:
        _route_frontend_api_migration(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {"deprecated-apis", "deprecated-api", "legacy-apis"}:
        _route_deprecated_apis(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {
        "component-consolidation",
        "component-consolidate",
        "frontend-consolidation",
    }:
        _route_frontend_component_consolidation(path_args[1:], as_json=as_json)
        return

    if path_args and path_args[0] in {
        "frontend-sidebar",
        "sidebar-language",
        "leaf-sidebar",
        "leaf-style-sidebar",
    }:
        _route_frontend_sidebar_language(path_args[1:], as_json=as_json)
        return

    if len(path_args) >= 2 and path_args[0] == "frontend" and path_args[1] in {
        "consolidate",
        "consolidation",
        "component-consolidation",
        "component-cleanup",
        "simplify",
        "redundancy",
    }:
        _route_frontend_component_consolidation(path_args[2:], as_json=as_json)
        return

    if len(path_args) >= 2 and path_args[0] == "frontend" and path_args[1] in {
        "sidebar",
        "sidebars",
        "sidebar-language",
        "leaf-sidebar",
        "leaf-style-sidebar",
    }:
        _route_frontend_sidebar_language(path_args[2:], as_json=as_json)
        return

    # Load manifests (with caching when in-tree, bundled fallback otherwise)
    python_data = _load_sdk(cache_dir, "python", root, no_cache=no_cache)
    frontend_data = _load_sdk(cache_dir, "frontend", root, no_cache=no_cache)

    # Route based on path_args
    if not path_args:
        print(format_toc(python_data, frontend_data, as_json=as_json))
        return

    first = path_args[0]

    # Search
    if first == "search":
        query = " ".join(path_args[1:])
        if not query:
            print("Usage: mint docs search <query>", file=sys.stderr)
            sys.exit(1)
        from mint_sdk.docs.search import search

        results = search(query, python_data, frontend_data, limit=50)
        results.extend(_search_template_docs(query))
        results.extend(_search_template_pack_docs(query))
        results.extend(_search_template_preset_docs(query))
        results.extend(_search_frontend_component_chooser_docs(query))
        results.extend(_search_r_bridge_docs(query))
        results.extend(_search_frontend_api_migration_docs(query))
        results.extend(_search_deprecated_api_docs(query))
        results.extend(_search_plugin_metadata_docs(query))
        results.extend(_search_frontend_component_consolidation_docs(query))
        results.extend(_search_frontend_sidebar_language_docs(query))
        results.sort(key=lambda r: (-r["score"], r["name"]))
        results = results[:20]
        print(format_search_results(results, query, as_json=as_json))
        return

    # Python SDK
    if first == "python":
        _route_python(python_data, path_args[1:], as_json=as_json)
        return

    # Frontend SDK
    if first == "frontend":
        _route_frontend(frontend_data, path_args[1:], as_json=as_json)
        return

    # Try as a direct item name across both SDKs
    item = _find_item_by_name(first, python_data, frontend_data)
    if item:
        print(format_item_detail(item, as_json=as_json))
        return

    print(f"Unknown argument: {first}", file=sys.stderr)
    print(
        "Usage: mint docs "
        "[python|frontend|contract|frontend-api|frontend-sidebar|deprecated-apis|"
        "template|template-pack|template-preset|r-bridge] "
        "[category|path] [item]",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# SDK routing
# ---------------------------------------------------------------------------


def _route_contract(rest: list[str], *, as_json: bool) -> None:
    """Render generated-client docs for a local plugin contract."""
    project_dir = Path(rest[0]).resolve() if rest else Path.cwd().resolve()
    try:
        from mint_sdk.contract import ContractGenerationError, build_contract_outputs

        contract, _ts_content, warnings = build_contract_outputs(project_dir)
    except ContractGenerationError as exc:
        print(f"Could not build plugin contract: {exc}", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(
            json.dumps(
                {
                    "contract": contract,
                    "warnings": warnings,
                    "frontendUsage": _contract_frontend_usage(contract),
                },
                indent=2,
            )
        )
        return

    print(_format_contract_docs(contract, warnings=warnings))


def _format_contract_docs(contract: dict[str, Any], *, warnings: list[str]) -> str:
    plugin = contract.get("plugin", {})
    endpoints = contract.get("endpoints", [])
    schemas = contract.get("schemas", {})
    api_prefix = plugin.get("apiPrefix") or "/api"

    lines = [
        f"Plugin contract: {plugin.get('name', 'Unknown plugin')}",
        f"Package: {plugin.get('packageName', 'unknown')}",
        f"Routes prefix: {plugin.get('routesPrefix', '-')}",
        f"API base: {api_prefix}",
        f"Hash: {contract.get('hash', '-')}",
        "",
        "Endpoints:",
    ]
    if not endpoints:
        lines.append("  (none)")
    for endpoint in endpoints:
        lines.extend(_format_contract_endpoint(endpoint, api_prefix))

    lines.extend(["", "Generated frontend client:"])
    lines.extend(_format_contract_frontend_usage(contract))

    lines.extend(["", "Settings:"])
    lines.extend(_format_contract_settings(contract.get("settings", {})))

    lines.extend(["", "Schemas:"])
    if schemas:
        for name in sorted(schemas.keys()):
            lines.append(f"  - {name}")
    else:
        lines.append("  (none)")

    if warnings:
        lines.extend(["", "Warnings:"])
        for warning in warnings:
            lines.append(f"  - {warning}")

    lines.extend(
        [
            "",
            "Next:",
            "  mint sdk generate",
            "  mint sdk generate --check",
        ]
    )
    return "\n".join(lines)


def _contract_frontend_usage(contract: dict[str, Any]) -> dict[str, Any]:
    endpoints = contract.get("endpoints", [])
    settings = contract.get("settings", {})
    has_settings = bool(settings.get("modelName") and settings.get("schema"))
    sample_endpoint = next(
        (endpoint for endpoint in endpoints if endpoint.get("name") != "health"),
        endpoints[0] if endpoints else None,
    )
    import_names = [
        "useGeneratedPluginClient",
        "useGeneratedPluginContract",
    ]
    if has_settings:
        import_names.append("useGeneratedPluginSettings")
    usage: dict[str, Any] = {
        "generatedFiles": [
            "frontend/src/generated/mint-plugin.contract.json",
            "frontend/src/generated/mint-plugin.ts",
        ],
        "import": (
            f"import {{ {', '.join(import_names)} }} "
            "from './generated/mint-plugin'"
        ),
        "clientHook": "const pluginClient = useGeneratedPluginClient()",
        "contractHook": "const pluginContract = useGeneratedPluginContract()",
        "contractHash": "const contractHash = pluginContract.contractHash",
        "apiPrefix": "const apiPrefix = pluginContract.apiPrefix",
        "routesPrefix": "const routesPrefix = pluginContract.routesPrefix",
        "pageSelectorItems": "const pageSelector = pluginContract.pageSelectorItems",
        "endpointNames": "const endpointNames = pluginContract.endpoints",
        "endpointDefinitions": "const endpointDefinitions = pluginContract.endpointDefinitions",
        "settingsHook": (
            "const settings = useGeneratedPluginSettings()"
            if has_settings
            else None
        ),
        "sampleCall": None,
    }
    if sample_endpoint is not None:
        endpoint_name = sample_endpoint.get("name", "endpoint")
        usage["sampleCall"] = (
            f"await pluginClient.{endpoint_name}({_client_call_arg(sample_endpoint)})"
        )
        usage["endpointLookup"] = (
            f"const {endpoint_name}Endpoint = pluginContract.getEndpoint('{endpoint_name}')"
        )
        usage["endpointGuard"] = f"pluginContract.hasEndpoint('{endpoint_name}')"
        usage["endpointUrl"] = (
            f"const {endpoint_name}Url = pluginContract.buildEndpointUrl("
            f"'{endpoint_name}', {_client_call_arg(sample_endpoint) or 'undefined'})"
        )
    else:
        usage["endpointLookup"] = None
        usage["endpointGuard"] = None
        usage["endpointUrl"] = None
    return usage


def _format_contract_frontend_usage(contract: dict[str, Any]) -> list[str]:
    usage = _contract_frontend_usage(contract)
    lines = [
        "  files:",
        *[f"    - {path}" for path in usage["generatedFiles"]],
        f"  {usage['import']}",
        f"  {usage['clientHook']}",
        f"  {usage['contractHook']}",
        f"  {usage['contractHash']}",
        f"  {usage['apiPrefix']}",
        f"  {usage['routesPrefix']}",
        f"  {usage['pageSelectorItems']}",
        f"  {usage['endpointNames']}",
        f"  {usage['endpointDefinitions']}",
    ]
    if usage.get("endpointLookup"):
        lines.append(f"  {usage['endpointLookup']}")
    if usage.get("endpointGuard"):
        lines.append(f"  {usage['endpointGuard']}")
    if usage.get("endpointUrl"):
        lines.append(f"  {usage['endpointUrl']}")
    if usage.get("sampleCall"):
        lines.append(f"  {usage['sampleCall']}")
    if usage.get("settingsHook"):
        lines.append(f"  {usage['settingsHook']}")
    return lines


def _format_contract_settings(settings: dict[str, Any]) -> list[str]:
    model_name = settings.get("modelName")
    schema = settings.get("schema")
    if not model_name or not isinstance(schema, dict):
        return ["  (none)"]

    lines = [
        f"  model: {model_name}",
        "  frontend: useGeneratedPluginSettings()",
    ]
    properties = schema.get("properties", {})
    if isinstance(properties, dict) and properties:
        required = set(schema.get("required", []))
        fields = [
            _schema_field(name, prop_schema, required=name in required)
            for name, prop_schema in properties.items()
            if isinstance(prop_schema, dict)
        ]
        if fields:
            lines.append("  fields: " + ", ".join(fields))
    return lines


def _schema_field(name: str, schema: dict[str, Any], *, required: bool) -> str:
    optional = "" if required else "?"
    return f"{name}{optional}: {_schema_doc_type(schema)}"


def _schema_doc_type(schema: dict[str, Any]) -> str:
    if "$ref" in schema:
        return str(schema["$ref"]).split("/")[-1]
    schema_type = schema.get("type")
    if isinstance(schema_type, list):
        non_null_types = [item for item in schema_type if item != "null"]
        schema_type = non_null_types[0] if non_null_types else "unknown"
    if schema_type == "integer":
        return "number"
    if schema_type == "array":
        item_type = _schema_doc_type(schema.get("items", {}))
        return f"{item_type}[]"
    if schema_type == "object":
        return "Record<string, unknown>"
    if isinstance(schema_type, str):
        return schema_type
    return "unknown"


def _format_contract_endpoint(endpoint: dict[str, Any], api_prefix: str) -> list[str]:
    method = str(endpoint.get("method", "get")).upper()
    path = str(endpoint.get("path", ""))
    full_path = f"{api_prefix}{path}"
    name = endpoint.get("name", "endpoint")
    request_type = endpoint.get("requestType")
    response_type = endpoint.get("responseType") or "unknown"
    path_params = endpoint.get("pathParams", [])
    query_params = endpoint.get("queryParams", [])

    lines = [
        f"  {method} {full_path}",
        f"    client: pluginClient.{name}({_client_call_arg(endpoint)})",
    ]
    if path_params:
        lines.append("    path params: " + _param_list(path_params, required_default=True))
        inferred = [
            param.get("fieldName", param.get("name", "param"))
            for param in path_params
            if _is_inferred_experiment_param(param)
        ]
        if inferred:
            lines.append(
                "    inferred params: "
                + ", ".join(inferred)
                + " from current experiment context or route; pass explicitly to override"
            )
    if query_params:
        lines.append("    query params: " + _param_list(query_params, required_default=False))
    if request_type:
        lines.append(f"    body: {request_type}")
    lines.append(f"    returns: {response_type}")
    return lines


def _route_r_bridge(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for the R analysis bridge."""
    if rest:
        print(f"Unknown R bridge topic: {' '.join(rest)}", file=sys.stderr)
        print("Usage: mint docs r-bridge", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_R_BRIDGE_DOC, indent=2))
        return

    print(_format_r_bridge_docs())


def _format_r_bridge_docs() -> str:
    doc = _R_BRIDGE_DOC
    lines = [
        "R analysis bridge",
        str(doc["purpose"]),
        "",
        "Core SDK:",
        "  from mint_sdk import RAnalysisBridge, RScriptSpec",
        "  bridge = RAnalysisBridge(",
        "      RScriptSpec(",
        "          script='r_scripts/analysis.R',",
        "          input_schema=RunRequest,",
        "          output_schema=RunResponse,",
        "          artifact_dir='.mint/r-artifacts/analysis',",
        "      )",
        "  )",
        "  response = await bridge.run(payload=request, experiment_id=experiment_id)",
        "  await plugin.save_analysis(experiment_id, response.result)",
        "",
        "Scaffold:",
        *[f"  {command}" for command in doc["scaffold_commands"]],
        "",
        "Generated contract:",
        f"  route: {doc['route_pattern']}",
        f"  generated client: {doc['generated_client_endpoint']}",
        f"  frontend composable: {doc['frontend_composable']}",
        *[f"  frontend helper: {name}" for name in doc["frontend_helpers"]],
        "",
        "Generated frontend page:",
        *[f"  {name}" for name in doc["generated_frontend_page"]],
        "",
        "Generated files:",
        *[f"  - {path}" for path in doc["generated_files"]],
        "",
        "R script interface:",
        *[f"  - env: {name}" for name in doc["r_environment"]],
        *[f"  - helper: {name}" for name in doc["r_helper_functions"]],
        "",
        "Diagnostics:",
        *[f"  {command}" for command in doc["diagnostic_commands"]],
        *[f"  checks: {name}" for name in doc["diagnostic_checks"]],
        "",
        "Dependencies:",
        *[f"  - {path}" for path in doc["dependency_files"]],
    ]
    return "\n".join(lines)


def _route_frontend_api_migration(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for contract-first frontend API migration."""
    if rest:
        print(f"Unknown frontend API migration topic: {' '.join(rest)}", file=sys.stderr)
        print("Usage: mint docs frontend-api", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_FRONTEND_API_MIGRATION_DOC, indent=2))
        return

    print(_format_frontend_api_migration_docs())


def _format_frontend_api_migration_docs() -> str:
    doc = _FRONTEND_API_MIGRATION_DOC
    lines = [
        "Frontend API migration",
        str(doc["purpose"]),
        "",
        "Doctor flags:",
        *[f"  - {pattern}" for pattern in doc["legacy_patterns"]],
        "",
        "Workflow:",
        *[f"  {command}" for command in doc["commands"]],
        "",
        "Generated client replacement:",
        f"  {doc['generated_import']}",
        f"  {doc['generated_client']}",
        f"  {doc['generated_contract']}",
        f"  {doc['endpoint_lookup']}",
        f"  {doc['endpoint_url']}",
        f"  {doc['sample_call']}",
        "",
        "Platform experiment/design data:",
        *[f"  - {helper}" for helper in doc["platform_data_helpers"]],
        "",
        "Diagnostics:",
        *[f"  {command}" for command in doc["diagnostics"]],
    ]
    return "\n".join(lines)


def _route_deprecated_apis(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for deprecated SDK API migrations."""
    if rest:
        print(f"Unknown deprecated API topic: {' '.join(rest)}", file=sys.stderr)
        print("Usage: mint docs deprecated-apis", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_DEPRECATED_API_DOC, indent=2))
        return

    print(_format_deprecated_api_docs())


def _format_deprecated_api_docs() -> str:
    doc = _DEPRECATED_API_DOC
    lines = [
        "Deprecated SDK APIs",
        str(doc["purpose"]),
        "",
        "Doctor diagnostics:",
        *[f"  {command}" for command in doc["diagnostics"]],
        "",
        "Doctor scans:",
        *[f"  - {item}" for item in doc["coverage"]],
        "",
        "Replacements:",
    ]
    for replacement in doc["replacements"]:
        lines.extend(
            [
                f"  - {replacement['old']} -> {replacement['new']}",
                f"    scope: {replacement['scope']}",
                f"    example: {replacement['example']}",
            ]
        )
    lines.extend(
        [
            "",
            "Follow-up docs:",
            *[f"  {command}" for command in doc["follow_ups"]],
        ]
    )
    return "\n".join(lines)


def _route_frontend_component_consolidation(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for frontend component consolidation strategy."""
    if rest:
        print(f"Unknown frontend component consolidation topic: {' '.join(rest)}", file=sys.stderr)
        print("Usage: mint docs frontend consolidate", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_FRONTEND_COMPONENT_CONSOLIDATION_DOC, indent=2))
        return

    print(_format_frontend_component_consolidation_docs())


def _format_frontend_component_consolidation_docs() -> str:
    doc = _FRONTEND_COMPONENT_CONSOLIDATION_DOC
    lines = [
        "Frontend component consolidation",
        str(doc["purpose"]),
        "",
        "Principles:",
        *[f"  - {item}" for item in doc["principles"]],
        "",
        "Canonical layers:",
    ]
    for layer in doc["layers"]:
        lines.extend(
            [
                f"  - {layer['task']}",
                f"    start: {', '.join(layer['canonical'])}",
                f"    folds: {', '.join(layer['folds'])}",
                f"    drop down only for: {', '.join(layer['drop_down_only_for'])}",
                f"    doctor: {layer['doctor_detection']}",
            ]
        )
    lines.extend(["", "Retired API cleanup:"])
    for item in doc["retired_apis"]:
        lines.extend(
            [
                f"  - avoid {item['avoid']} -> prefer {item['prefer']}",
                f"    why: {item['reason']}",
                f"    guide: {item['migration_guide']}",
            ]
        )
    lines.extend(["", "Legacy prop patterns:"])
    for item in doc["legacy_prop_patterns"]:
        lines.append(f"  - {item['avoid']} -> {item['prefer']}")
    lines.extend(
        [
            "",
            "Diagnostics:",
            *[f"  {command}" for command in doc["diagnostics"]],
            "",
            "Next:",
            *[f"  - {step}" for step in doc["next_steps"]],
        ]
    )
    return "\n".join(lines)


def _route_frontend_sidebar_language(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for the shared LEAF-style sidebar language."""
    if rest:
        print(f"Unknown frontend sidebar topic: {' '.join(rest)}", file=sys.stderr)
        print("Usage: mint docs frontend sidebar", file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_FRONTEND_SIDEBAR_LANGUAGE_DOC, indent=2))
        return

    print(_format_frontend_sidebar_language_docs())


def _format_frontend_sidebar_language_docs() -> str:
    doc = _FRONTEND_SIDEBAR_LANGUAGE_DOC
    lines = [
        "Frontend sidebar language",
        str(doc["purpose"]),
        "",
        f"Canonical component: {doc['canonical_component']}",
        "",
        "Observed plugin patterns:",
        *[f"  - {item}" for item in doc["source_patterns"]],
        "",
        "Principles:",
        *[f"  - {item}" for item in doc["principles"]],
        "",
        "Recipes:",
    ]
    for recipe in doc["recipes"]:
        lines.extend(
            [
                f"  - {recipe['task']}",
                f"    use: {recipe['use']}",
                f"    start: {', '.join(recipe['start'])}",
            ]
        )
        for line in recipe["snippet"]:
            lines.append(f"    {line}")
    lines.extend(["", "Migration targets:"])
    for target in doc["migration_targets"]:
        lines.append(f"  - {target['from']} -> {target['to']}")
    lines.extend(
        [
            "",
            "Diagnostics:",
            *[f"  {command}" for command in doc["diagnostics"]],
        ]
    )
    return "\n".join(lines)


def _route_template(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for built-in biology data templates."""
    if not rest:
        if as_json:
            print(json.dumps({"templates": list(_TEMPLATE_DOCS.values())}, indent=2))
            return
        lines = [
            "Bio data templates:",
            "",
            *[
                f"  - {name}: {doc['purpose']}"
                for name, doc in sorted(_TEMPLATE_DOCS.items())
            ],
            "",
            "Usage:",
            "  mint add data-template --list",
            "  mint add data-template --list --json",
            "  mint add data-template-pack cell-culture-screen --page",
            "  mint add data-template-pack molecular-assay --page",
            "  mint add data-template-preset wellplate-screen --page",
            "  mint add data-template-preset elisa-assay --page",
            "  mint add data-template-preset flow-cytometry-assay --page",
            "  mint add data-template-preset western-blot-assay --page",
            "  mint docs template-preset wellplate-screen",
            "  mint docs template plate-map",
            "  mint add data-template plate-map --page",
        ]
        print("\n".join(lines))
        return

    query = rest[0]
    info = get_template_info(query)
    name = info.name if info is not None else query
    doc = _TEMPLATE_DOCS.get(name)
    if doc is None:
        print(f"Unknown template: {query}", file=sys.stderr)
        _print_did_you_mean(query, list(_TEMPLATE_DOCS.keys()), file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_with_template_usage(doc), indent=2))
        return

    print(_format_template_docs(doc))


def _with_template_usage(doc: dict[str, Any]) -> dict[str, Any]:
    name = str(doc["name"])
    template_pascal = _docs_pascal(name)
    route_prefix = f"/templates/{name}"
    workspace_bindings = _frontend_workspace_bindings(
        "template",
        reset_action="resetToDefaultTemplate",
    )
    return {
        **doc,
        "frontend_composable": f"use{template_pascal}Template",
        "frontend_composable_file": f"frontend/src/composables/use{template_pascal}Template.ts",
        "frontend_current_helpers": [
            "currentExperimentId",
            "hasExperiment",
            "error",
            "lastLoadedAt",
            "lastSavedAt",
            "loadCurrent()",
            "saveCurrent()",
            "resetToDefaultTemplate()",
        ],
        "frontend_workspace_bindings": workspace_bindings,
        "frontend_component_usage_helpers": [
            "toBioTemplateComponentProps",
            "toBioTemplateComponentImports",
            "toBioTemplateComponentSnippets",
            "toBioTemplateComponentUsage",
        ],
        "generated_client_endpoints": [
            f"get{template_pascal}TemplateSchema",
            f"get{template_pascal}Template",
            f"save{template_pascal}Template",
        ],
        "routes": {
            "schema": f"GET {route_prefix}/schema",
            "load": f"GET {route_prefix}/{{experiment_id}}",
            "save": f"POST {route_prefix}/{{experiment_id}}",
        },
    }


def _format_template_docs(doc: dict[str, Any]) -> str:
    usage = _with_template_usage(doc)
    adapters = ", ".join(doc["frontend_adapters"])
    components = ", ".join(doc["components"])
    name = doc["name"]
    lines = [
        f"Template: {name}",
        doc["purpose"],
        "",
        "Python:",
        f"  {doc['python_import']}",
        f"  template = {doc['python_example']}",
        "  await plugin.save_template(experiment_id, template)",
        "  # or, outside an AnalysisPlugin method:",
        "  await save_template(plugin, experiment_id, template)",
        "",
        "Frontend:",
        f"  {doc['frontend_import']}",
        f"  adapters: {adapters}",
        f"  components: {components}",
        f"  composable: {usage['frontend_composable_file']}",
        f"  const template = {usage['frontend_composable']}()",
        "  await template.loadCurrent()",
        "  await template.saveCurrent()",
        "  workspace view bindings:",
        *[f"  {binding}" for binding in usage["frontend_workspace_bindings"]],
        "  generated page auto-loads when currentExperimentId is available",
        "  component usage scaffold:",
        "  import { toBioTemplateComponentUsage } from '@morscherlab/mint-sdk/templates'",
        "  const usage = toBioTemplateComponentUsage(template)",
        "  usage.sfc",
    ]
    if "toTemplateDataFrame" in doc["frontend_adapters"]:
        lines.extend(
            [
                "  const frame = toTemplateDataFrame(template)",
                "  <DataFrame v-bind=\"frame\" />",
            ]
        )
    lines.extend(
        [
            "",
            "Generated client endpoints:",
            *[f"  - {endpoint}" for endpoint in usage["generated_client_endpoints"]],
            "",
            "Generated routes:",
            f"  {usage['routes']['schema']}",
            f"  {usage['routes']['load']}",
            f"  {usage['routes']['save']}",
            "",
            "CLI:",
            f"  {doc['add_command']}",
        ]
    )
    return "\n".join(lines)


def _route_template_pack(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for curated biology data-template packs."""
    if not rest:
        if as_json:
            docs = [_with_template_pack_usage(doc) for doc in _TEMPLATE_PACK_DOCS.values()]
            print(json.dumps({"packs": docs}, indent=2))
            return
        lines = [
            "Bio data template packs:",
            "",
            *[
                f"  - {name}: {doc['purpose']}"
                for name, doc in sorted(_TEMPLATE_PACK_DOCS.items())
            ],
            "",
            "Usage:",
            "  mint add data-template-pack --list",
            "  mint add data-template-pack --list --json",
            "  mint docs template-pack cell-culture-screen",
            "  mint add data-template-pack cell-culture-screen --page",
            "  mint add data-template-pack molecular-assay --page",
        ]
        print("\n".join(lines))
        return

    query = rest[0]
    info = get_template_pack_info(query)
    name = info.name if info is not None else query
    doc = _TEMPLATE_PACK_DOCS.get(name)
    if doc is None:
        print(f"Unknown template pack: {query}", file=sys.stderr)
        _print_did_you_mean(query, list(_TEMPLATE_PACK_DOCS.keys()), file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(_with_template_pack_usage(doc), indent=2))
        return

    print(_format_template_pack_docs(doc))


def _docs_pascal(value: str) -> str:
    return "".join(part[:1].upper() + part[1:] for part in value.replace("_", "-").split("-"))


def _docs_camel(value: str) -> str:
    pascal = _docs_pascal(value)
    return pascal[:1].lower() + pascal[1:]


def _with_template_pack_usage(doc: dict[str, Any]) -> dict[str, Any]:
    name = str(doc["name"])
    pack_pascal = _docs_pascal(name)
    pack_snake = name.replace("-", "_")
    route_prefix = f"/templates/packs/{name}"
    workspace_bindings = _frontend_workspace_bindings(
        "pack",
        reset_action="resetToDefaultTemplates",
    )
    return {
        **doc,
        "backend_helper": f"create_default_{pack_snake}_collection",
        "backend_helper_import": (
            f"from <your_package>.templates.{pack_snake}_pack "
            f"import create_default_{pack_snake}_collection"
        ),
        "route_prefix": route_prefix,
        "routes": {
            "schema": f"GET {route_prefix}/schema",
            "load": f"GET {route_prefix}/{{experiment_id}}",
            "save": f"POST {route_prefix}/{{experiment_id}}",
        },
        "frontend_composable": f"use{pack_pascal}TemplatePack",
        "frontend_composable_file": (
            f"frontend/src/composables/use{pack_pascal}TemplatePack.ts"
        ),
        "frontend_view_file": f"frontend/src/views/{pack_pascal}TemplatePackView.vue",
        "frontend_route": f"/templates/packs/{name}",
        "generated_client_endpoints": [
            f"get{pack_pascal}TemplatePackSchema",
            f"get{pack_pascal}TemplatePack",
            f"save{pack_pascal}TemplatePack",
        ],
        "typed_template_refs": [_docs_camel(str(template)) for template in doc["templates"]],
        "frontend_current_helpers": [
            "currentExperimentId",
            "hasExperiment",
            "error",
            "lastLoadedAt",
            "lastSavedAt",
            "loadCurrent()",
            "saveCurrent()",
            "resetToDefaultTemplates()",
        ],
        "frontend_workspace_bindings": workspace_bindings,
    }


def _format_template_pack_docs(doc: dict[str, Any]) -> str:
    usage = _with_template_pack_usage(doc)
    templates = [str(template) for template in doc["templates"]]
    lines = [
        f"Template pack: {doc['name']}",
        str(doc["purpose"]),
        "",
        "Templates:",
        *[f"  - {template}" for template in templates],
        "",
        "CLI:",
        f"  {doc['add_command']}",
        "",
        "Generated backend:",
        f"  {usage['backend_helper_import']}",
        f"  collection = {usage['backend_helper']}()",
        f"  {usage['routes']['schema']}",
        f"  {usage['routes']['load']}",
        f"  {usage['routes']['save']}",
        "",
        "Generated frontend:",
        f"  composable: {usage['frontend_composable_file']}",
        f"  page: {usage['frontend_view_file']}",
        f"  route: {usage['frontend_route']}",
        f"  import {{ {usage['frontend_composable']} }} from './composables/{usage['frontend_composable']}'",
        f"  const pack = {usage['frontend_composable']}()",
        "  await pack.loadCurrent()",
        "  await pack.saveCurrent()",
        "  workspace view bindings:",
        *[f"  {binding}" for binding in usage["frontend_workspace_bindings"]],
        "  generated page auto-loads when pack.currentExperimentId is available",
        "  pack.applyTemplateCollection(customCollection)",
        "",
        "Typed template refs:",
        *[f"  - pack.{template_ref}" for template_ref in usage["typed_template_refs"]],
        "",
        "Generated client endpoints:",
        *[f"  - {endpoint}" for endpoint in usage["generated_client_endpoints"]],
        "",
        "Inspect included templates:",
        *[f"  mint docs template {template}" for template in templates],
    ]
    return "\n".join(lines)


def _frontend_workspace_bindings(subject: str, *, reset_action: str) -> list[str]:
    return [
        (
            "status: { "
            f"loading: {subject}.loading, "
            f"error: {subject}.error, "
            f"hasExperiment: {subject}.hasExperiment, "
            f"currentExperimentId: {subject}.currentExperimentId, "
            f"lastLoadedAt: {subject}.lastLoadedAt, "
            f"lastSavedAt: {subject}.lastSavedAt "
            "}"
        ),
        (
            "actions: { "
            f"load: {subject}.loadCurrent, "
            f"reset: {subject}.{reset_action}, "
            f"save: {subject}.saveCurrent "
            "}"
        ),
    ]


def _route_template_preset(rest: list[str], *, as_json: bool) -> None:
    """Render offline docs for ready-to-save biology template preset collections."""
    if not rest:
        if as_json:
            print(json.dumps({"presets": list(_TEMPLATE_PRESET_DOCS.values())}, indent=2))
            return
        lines = [
            "Bio data template presets:",
            "",
            *[
                line
                for name, doc in sorted(_TEMPLATE_PRESET_DOCS.items())
                for line in _format_template_preset_list_item(name, doc)
            ],
            "",
            "Usage:",
            "  mint docs template-preset wellplate-screen",
            "  mint add data-template-preset wellplate-screen --page",
            "  mint docs template-preset qpcr-expression",
            "  mint docs template-preset lcms-batch",
            "  mint docs template-preset elisa-assay",
            "  mint docs template-preset flow-cytometry-assay",
            "  mint docs template-preset western-blot-assay",
        ]
        print("\n".join(lines))
        return

    query = rest[0]
    info = get_template_preset_info(query)
    name = info.name if info is not None else query
    doc = _TEMPLATE_PRESET_DOCS.get(name)
    if doc is None:
        print(f"Unknown template preset: {query}", file=sys.stderr)
        _print_did_you_mean(query, list(_TEMPLATE_PRESET_DOCS.keys()), file=sys.stderr)
        sys.exit(1)

    if as_json:
        print(json.dumps(doc, indent=2))
        return

    print(_format_template_preset_docs(doc))


def _format_template_preset_docs(doc: dict[str, Any]) -> str:
    adapters = ", ".join(doc["frontend_adapters"])
    aliases = ", ".join(doc.get("aliases", []))
    components = ", ".join(doc["components"])
    templates = [str(template) for template in doc["templates"]]
    label = str(doc.get("label") or doc["name"]).replace('"', '\\"')
    lines = [
        f"Template preset: {doc['name']}",
        str(doc["purpose"]),
    ]
    if aliases:
        lines.extend(["", f"Aliases: {aliases}"])
    lines.extend([
        "",
        "Templates:",
        *[f"  - {template}" for template in templates],
        "",
        "Python:",
        f'  await plugin.save_template_preset(experiment_id, "{doc["name"]}")',
        "  # or, outside an AnalysisPlugin method:",
        "  from mint_sdk.templates import save_template_preset_collection",
        f'  await save_template_preset_collection(plugin, experiment_id, "{doc["name"]}")',
        "",
        "Scaffold:",
        f"  mint add data-template-preset {doc['name']} --page",
        "",
        "Typed shortcut:",
        f"  {doc['python_import']}",
        f"  collection = {doc['python_example']}",
        "  await plugin.save_template_collection(experiment_id, collection['templates'].values())",
        "",
        "Frontend:",
        "  import { BioTemplatePresetWorkspaceView } from '@morscherlab/mint-sdk'",
        f'  <BioTemplatePresetWorkspaceView preset="{doc["name"]}" label="{label}" />',
        "",
        "Lower-level adapters:",
        f"  {doc['frontend_import']}",
        f"  adapters: {adapters}",
        f"  components: {components}",
        "  templates = extractTemplateCollection(collection)",
        "",
        "Inspect included templates:",
        *[f"  mint docs template {template}" for template in templates],
    ])
    return "\n".join(lines)


def _format_template_preset_list_item(name: str, doc: dict[str, Any]) -> list[str]:
    lines = [f"  - {name}: {doc['purpose']}"]
    aliases = doc.get("aliases", [])
    if aliases:
        lines.append(f"    aliases: {', '.join(str(alias) for alias in aliases)}")
    return lines


def _search_template_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    results: list[dict[str, Any]] = []
    for name, doc in _TEMPLATE_DOCS.items():
        usage = _with_template_usage(doc)
        score = 0
        if q in name:
            score += 3
        if q in doc["purpose"].lower():
            score += 2
        for field in ("python_import", "python_example", "frontend_import"):
            if q in doc[field].lower():
                score += 1
        if any(q in alias.lower() for alias in doc.get("aliases", [])):
            score += 1
        if any(q in adapter.lower() for adapter in doc["frontend_adapters"]):
            score += 1
        if any(q in component.lower() for component in doc["components"]):
            score += 1
        if q in str(usage["frontend_composable"]).lower():
            score += 2
        if any(q in str(helper).lower() for helper in usage["frontend_current_helpers"]):
            score += 2
        if any(q in str(binding).lower() for binding in usage["frontend_workspace_bindings"]):
            score += 2
        if any(q in str(endpoint).lower() for endpoint in usage["generated_client_endpoints"]):
            score += 1
        if any(q in str(route).lower() for route in usage["routes"].values()):
            score += 1
        if score == 0 and _matches_docs_query(q, _template_doc_search_text(name, doc, usage)):
            score += 2
        if "wellplate" in q and _template_name_or_alias_mentions(name, doc, "wellplate"):
            score += 3
        if score > 0:
            results.append(
                {
                    "sdk": "templates",
                    "category": "bio-data",
                    "group": "biology",
                    "name": name,
                    "kind": "template",
                    "description": doc["purpose"],
                    "source": f"mint docs template {name}",
                    "match_context": f"mint docs template {name}",
                    "score": score,
                }
            )
    return results


def _search_template_preset_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    results: list[dict[str, Any]] = []
    for name, doc in _TEMPLATE_PRESET_DOCS.items():
        score = 0
        if q in name:
            score += 3
        if q in str(doc["purpose"]).lower():
            score += 2
        if any(q in str(alias).lower() for alias in doc.get("aliases", [])):
            score += 1
        if any(q in str(template).lower() for template in doc["templates"]):
            score += 1
        for field in ("python_import", "python_example", "frontend_import"):
            if q in str(doc.get(field, "")).lower():
                score += 1
        if any(q in str(component).lower() for component in doc["components"]):
            score += 1
        if any(q in str(adapter).lower() for adapter in doc["frontend_adapters"]):
            score += 1
        if score == 0 and _matches_docs_query(q, _template_preset_search_text(name, doc)):
            score += 2
        if "wellplate" in q and _template_name_or_alias_mentions(name, doc, "wellplate"):
            score += 3
        if "wellplate" in q and name == "wellplate-screen":
            score += 2
        if score > 0:
            results.append(
                {
                    "sdk": "templates",
                    "category": "bio-data",
                    "group": "biology",
                    "name": name,
                    "kind": "template-preset",
                    "description": doc["purpose"],
                    "source": f"mint docs template-preset {name}",
                    "match_context": f"mint docs template-preset {name}",
                    "score": score,
                }
            )
    return results


def _search_template_pack_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    results: list[dict[str, Any]] = []
    for name, doc in _TEMPLATE_PACK_DOCS.items():
        usage = _with_template_pack_usage(doc)
        score = 0
        if q in name:
            score += 3
        if q in str(doc["purpose"]).lower():
            score += 2
        if any(q in str(alias).lower() for alias in doc.get("aliases", [])):
            score += 1
        if any(q in str(template).lower() for template in doc["templates"]):
            score += 1
        if q in str(usage["frontend_composable"]).lower():
            score += 2
        if any(q in str(helper).lower() for helper in usage["frontend_current_helpers"]):
            score += 2
        if any(q in str(binding).lower() for binding in usage["frontend_workspace_bindings"]):
            score += 2
        if any(q in str(endpoint).lower() for endpoint in usage["generated_client_endpoints"]):
            score += 1
        if any(q in str(route).lower() for route in usage["routes"].values()):
            score += 1
        if score == 0 and _matches_docs_query(q, _template_pack_search_text(name, doc, usage)):
            score += 2
        if "wellplate" in q and _template_name_or_alias_mentions(name, doc, "wellplate"):
            score += 3
        if score > 0:
            results.append(
                {
                    "sdk": "templates",
                    "category": "bio-data",
                    "group": "biology",
                    "name": name,
                    "kind": "template-pack",
                    "description": doc["purpose"],
                    "source": f"mint docs template-pack {name}",
                    "match_context": f"mint docs template-pack {name}",
                    "score": score,
                }
            )
    return results


def _matches_docs_query(query: str, haystack: str) -> bool:
    if query in haystack:
        return True
    tokens = [token for token in query.split() if token]
    return bool(tokens) and all(token in haystack for token in tokens)


def _template_doc_search_text(name: str, doc: dict[str, Any], usage: dict[str, Any]) -> str:
    return " ".join(
        [
            name,
            str(doc["purpose"]),
            " ".join(str(alias) for alias in doc.get("aliases", [])),
            " ".join(str(component) for component in doc["components"]),
            " ".join(str(adapter) for adapter in doc["frontend_adapters"]),
            str(doc["python_import"]),
            str(doc["frontend_import"]),
            str(usage["frontend_composable"]),
            " ".join(str(helper) for helper in usage["frontend_current_helpers"]),
            " ".join(str(binding) for binding in usage["frontend_workspace_bindings"]),
            " ".join(str(endpoint) for endpoint in usage["generated_client_endpoints"]),
            " ".join(str(route) for route in usage["routes"].values()),
            "database design_data experiment data current experiment plugin data template collection",
        ]
    ).lower()


def _template_preset_search_text(name: str, doc: dict[str, Any]) -> str:
    return " ".join(
        [
            name,
            str(doc["purpose"]),
            " ".join(str(alias) for alias in doc.get("aliases", [])),
            " ".join(str(template) for template in doc["templates"]),
            " ".join(str(component) for component in doc["components"]),
            " ".join(str(adapter) for adapter in doc["frontend_adapters"]),
            str(doc.get("python_import", "")),
            str(doc.get("frontend_import", "")),
            "database design_data experiment data current experiment plugin data template preset collection",
        ]
    ).lower()


def _template_pack_search_text(name: str, doc: dict[str, Any], usage: dict[str, Any]) -> str:
    return " ".join(
        [
            name,
            str(doc["purpose"]),
            " ".join(str(alias) for alias in doc.get("aliases", [])),
            " ".join(str(template) for template in doc["templates"]),
            str(usage["frontend_composable"]),
            " ".join(str(helper) for helper in usage["frontend_current_helpers"]),
            " ".join(str(binding) for binding in usage["frontend_workspace_bindings"]),
            " ".join(str(endpoint) for endpoint in usage["generated_client_endpoints"]),
            " ".join(str(route) for route in usage["routes"].values()),
            "database design_data experiment data current experiment plugin data template pack collection",
        ]
    ).lower()


def _template_name_or_alias_mentions(name: str, doc: dict[str, Any], token: str) -> bool:
    text = " ".join([name, *[str(alias) for alias in doc.get("aliases", [])]]).lower()
    return token in text


def _search_frontend_api_migration_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    doc = _FRONTEND_API_MIGRATION_DOC
    haystack = " ".join(
        [
            str(doc["name"]),
            str(doc["purpose"]),
            " ".join(str(item) for item in doc["legacy_patterns"]),
            " ".join(str(item) for item in doc["commands"]),
            " ".join(str(item) for item in doc["platform_data_helpers"]),
            str(doc["endpoint_url"]),
            "generated client contract frontend api useApi VITE_API_PREFIX baseUrl "
            "backend frontend relationship typed client typed endpoints typed api "
            "plugin contract contract-first generated plugin client generated contract",
        ]
    ).lower()
    if not _matches_docs_query(q, haystack):
        return []
    score = 4 if q in {"frontend api", "frontend-api", "vite_api_prefix", "useapi"} else 2
    return [
        {
            "sdk": "frontend",
            "category": "workflow",
            "group": "contract",
            "name": "frontend-api",
            "kind": "guide",
            "description": doc["purpose"],
            "source": "mint docs frontend-api",
            "match_context": "mint docs frontend-api",
            "score": score,
        }
    ]


def _search_frontend_component_chooser_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    haystack = (
        "frontend component chooser choose component canonical recommended manual "
        "which component start here simplify redundant redundancy component "
        "controlworkspaceview biotemplatepresetworkspaceview formbuilder "
        "usebiotemplatepackworkspace biotemplateexperimentworkspaceview "
        "template pack wellplate dosecalculator componentpropsbyid "
        "componentbindings componentbindingsbyid definecontrolcomponentbindings "
        "definewellplatedosecomponentbindings controlvaluestocomponentbindings "
        "component binding generated bindings direct slot rendering componentbindingrenderer "
        "plate map sample sheet dataframe sampleselector groupassigner "
        "sidebar form model control values synchronization apply-to-wells "
        "leaf leaf-style analysis sidebar design language plugin sidebar "
        "contentid showwhenempty teleport route-owned route owned pinned footer "
        "controloptions controloptions.initialvalues initialvalues default overrides "
        "shared initial values same values settingsmodal "
        "root import public components composables templates styles "
        "appsidebar apptopbar applayout apptoastcontainer deprecated avoid"
    )
    if q not in haystack and not all(token in haystack for token in q.split()):
        return []
    score = 5 if q in {"component chooser", "frontend component chooser", "choose component"} else 3
    return [
        {
            "sdk": "frontend",
            "category": "workflow",
            "group": "components",
            "name": "frontend-component-chooser",
            "kind": "guide",
            "description": "Pick canonical frontend SDK components by plugin task.",
            "source": "mint docs frontend choose",
            "match_context": "mint docs frontend choose",
            "score": score,
        }
    ]


def _search_deprecated_api_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    doc = _DEPRECATED_API_DOC
    replacements = doc["replacements"]
    haystack = " ".join(
        [
            str(doc["name"]),
            str(doc["purpose"]),
            " ".join(str(item["old"]) for item in replacements),
            " ".join(str(item["new"]) for item in replacements),
            " ".join(str(command) for command in doc["diagnostics"]),
            " ".join(str(item) for item in doc["coverage"]),
            " ".join(str(command) for command in doc["follow_ups"]),
            "deprecated abandoned legacy dynamic component resolveComponent "
            "mld_sdk mld-sdk usePluginApi GroupingModal ToastNotification "
            "BaseTabs PluginWorkspaceView AppSidebar AppTopBar get_frontend_config navItems "
            "PluginMetadata.nav_items PluginNavItem",
        ]
    ).lower()
    if q not in haystack:
        return []
    score = 5 if q in {"deprecated", "deprecated api", "deprecated-apis", "legacy"} else 3
    return [
        {
            "sdk": "frontend",
            "category": "workflow",
            "group": "migration",
            "name": "deprecated-apis",
            "kind": "guide",
            "description": doc["purpose"],
            "source": "mint docs deprecated-apis",
            "match_context": "mint docs deprecated-apis",
            "score": score,
        }
    ]


def _search_plugin_metadata_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    haystack = (
        "plugin metadata pluginmetadata pluginnavitem nav_items navitems "
        "homepage home plugin card plugincard page metadata page icons icon "
        "plugin icon color topbar page switch page selector app topbar "
        "routes_prefix frontend config metadata"
    )
    if q not in haystack and not all(token in haystack for token in q.split()):
        return []
    score = 5 if q in {
        "plugin metadata",
        "pluginmetadata",
        "plugin page metadata",
        "homepage plugincard icon",
    } else 3
    return [
        {
            "sdk": "python",
            "category": "models",
            "group": "metadata",
            "name": "PluginMetadata",
            "kind": "guide",
            "description": (
                "PluginMetadata.icon, color, and nav_items keep homepage "
                "PluginCards, plugin headers, and AppTopBar page switching aligned."
            ),
            "source": "mint docs python PluginMetadata",
            "match_context": "PluginMetadata icon/color/nav_items",
            "score": score,
        }
    ]


def _search_frontend_component_consolidation_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    doc = _FRONTEND_COMPONENT_CONSOLIDATION_DOC
    haystack = " ".join(
        [
            str(doc["name"]),
            str(doc["purpose"]),
            " ".join(str(item) for item in doc["principles"]),
            " ".join(str(command) for command in doc["diagnostics"]),
            " ".join(
                " ".join(str(value) for value in layer.values())
                for layer in doc["layers"]
            ),
            " ".join(str(step) for step in doc["next_steps"]),
            "consolidate consolidation simplify redundant redundancy duplicate "
            "canonical component surface component cleanup settings modal forms "
            "sidebar topbar wellplate dose design data templates componentbindings "
            "componentbindingsbyid definewellplatedosecomponentbindings",
        ]
    ).lower()
    if q not in haystack and not all(token in haystack for token in q.split()):
        return []
    score = 5 if q in {
        "component consolidation",
        "frontend consolidation",
        "redundant components",
        "component cleanup",
    } else 3
    return [
        {
            "sdk": "frontend",
            "category": "workflow",
            "group": "components",
            "name": "frontend-component-consolidation",
            "kind": "guide",
            "description": doc["purpose"],
            "source": "mint docs frontend consolidate",
            "match_context": "mint docs frontend consolidate",
            "score": score,
        }
    ]


def _search_frontend_sidebar_language_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    doc = _FRONTEND_SIDEBAR_LANGUAGE_DOC
    haystack = " ".join(
        [
            str(doc["name"]),
            str(doc["purpose"]),
            str(doc["canonical_component"]),
            " ".join(str(item) for item in doc["source_patterns"]),
            " ".join(str(item) for item in doc["principles"]),
            " ".join(
                " ".join(str(value) for value in recipe.values())
                for recipe in doc["recipes"]
            ),
            " ".join(
                " ".join(str(value) for value in target.values())
                for target in doc["migration_targets"]
            ),
            "leaf leaf-style sidebar language analysis sidebar appsidebar "
            "route-owned route owned tab-owned tab owned teleport contentid "
            "showwhenempty pinned footer action bar seqgen ms designer drp "
            "ms uploader hmdb wellplate control model",
        ]
    ).lower()
    if q not in haystack and not all(token in haystack for token in q.split()):
        return []
    score = 5 if q in {
        "frontend sidebar",
        "sidebar language",
        "leaf sidebar",
        "leaf-style sidebar",
        "analysis sidebar",
    } else 4
    return [
        {
            "sdk": "frontend",
            "category": "workflow",
            "group": "components",
            "name": "frontend-sidebar-language",
            "kind": "guide",
            "description": doc["purpose"],
            "source": "mint docs frontend sidebar",
            "match_context": "mint docs frontend sidebar",
            "score": score,
        }
    ]


def _search_r_bridge_docs(query: str) -> list[dict[str, Any]]:
    q = query.lower()
    haystack = " ".join(
        [
            str(_R_BRIDGE_DOC["name"]),
            str(_R_BRIDGE_DOC["purpose"]),
            " ".join(str(item) for item in _R_BRIDGE_DOC["python_exports"]),
            " ".join(str(item) for item in _R_BRIDGE_DOC["scaffold_commands"]),
            " ".join(str(item) for item in _R_BRIDGE_DOC["generated_files"]),
            " ".join(str(item) for item in _R_BRIDGE_DOC["r_environment"]),
            " ".join(str(item) for item in _R_BRIDGE_DOC["r_helper_functions"]),
            "r analysis Rscript renv artifacts frontend composable generated client "
            "r interface analysis plugin r-analysis endpoint typed pydantic fastapi",
        ]
    ).lower()
    if not _matches_docs_query(q, haystack):
        return []
    score = 4 if q in {"r", "r analysis", "r-analysis", "r bridge", "r-bridge"} else 2
    return [
        {
            "sdk": "python",
            "category": "analysis",
            "group": "R",
            "name": "r-bridge",
            "kind": "guide",
            "description": _R_BRIDGE_DOC["purpose"],
            "source": "mint docs r-bridge",
            "match_context": "mint docs r-bridge",
            "score": score,
        }
    ]


def _client_call_arg(endpoint: dict[str, Any]) -> str:
    path_params = endpoint.get("pathParams", [])
    query_params = endpoint.get("queryParams", [])
    request_type = endpoint.get("requestType")
    method = endpoint.get("method")
    explicit_path_params = [
        param for param in path_params if not _is_inferred_experiment_param(param)
    ]
    if method == "get" and not explicit_path_params and not query_params:
        return ""
    if explicit_path_params or query_params:
        fields = [param["fieldName"] for param in explicit_path_params]
        fields.extend(param["fieldName"] for param in query_params)
        if request_type:
            fields.append("body")
        return "{ " + ", ".join(fields) + " }"
    if path_params and request_type:
        return "{ body }"
    if request_type:
        return "body"
    return ""


def _param_list(params: list[dict[str, Any]], *, required_default: bool) -> str:
    rendered: list[str] = []
    for param in params:
        required = (
            False
            if _is_inferred_experiment_param(param)
            else param.get("required", required_default)
        )
        optional = "" if required else "?"
        field_name = param.get("fieldName", param.get("name", "param"))
        backend_name = param.get("name")
        alias = f" -> {backend_name}" if backend_name and backend_name != field_name else ""
        rendered.append(f"{field_name}{optional}: {param.get('type', 'unknown')}{alias}")
    return ", ".join(rendered)


def _is_inferred_experiment_param(param: dict[str, Any]) -> bool:
    return (
        param.get("fieldName") == "experimentId"
        or param.get("name") == "experiment_id"
    )


def _route_python(data: dict[str, Any] | None, rest: list[str], *, as_json: bool) -> None:
    if data is None:
        print("Python SDK data not available.", file=sys.stderr)
        sys.exit(1)

    categories = data.get("categories", {})

    if not rest:
        print(format_sdk_overview(data, "python", as_json=as_json))
        return

    target = rest[0]

    # Check if target is a category name
    if target in categories:
        print(format_category(categories[target], target, as_json=as_json))
        return

    # Check if target is an item name within any category
    for _cat_name, items in categories.items():
        for item in items:
            if item.get("name") == target:
                print(format_item_detail(item, as_json=as_json))
                return

    print(f"Not found: {target}", file=sys.stderr)
    print(
        f"Available categories: {', '.join(categories.keys())}",
        file=sys.stderr,
    )
    _print_did_you_mean(target, _all_item_names(data), file=sys.stderr)
    sys.exit(1)


def _route_frontend(data: dict[str, Any] | None, rest: list[str], *, as_json: bool) -> None:
    if data is None:
        print("Frontend SDK data not available.", file=sys.stderr)
        sys.exit(1)

    categories = data.get("categories", {})

    if not rest:
        print(format_sdk_overview(data, "frontend", as_json=as_json))
        return

    target = rest[0]

    # Category-level routing
    if target in {"choose", "chooser", "component-chooser", "start", "recommended"}:
        print(format_frontend_component_chooser(data, as_json=as_json))
        return

    if target in {
        "consolidate",
        "consolidation",
        "component-consolidation",
        "component-cleanup",
        "simplify",
        "redundancy",
    }:
        _route_frontend_component_consolidation(rest[1:], as_json=as_json)
        return

    if target in {
        "sidebar",
        "sidebars",
        "sidebar-language",
        "leaf-sidebar",
        "leaf-style-sidebar",
    }:
        _route_frontend_sidebar_language(rest[1:], as_json=as_json)
        return

    if target == "components":
        if len(rest) > 1:
            print(format_component_group(data, rest[1], as_json=as_json))
        else:
            print(format_components_grouped(data, as_json=as_json))
        return

    if target == "composables":
        print(format_composables(data, as_json=as_json))
        return

    if target == "css":
        if len(rest) > 1:
            print(format_css_section(data, rest[1], as_json=as_json))
        else:
            print(format_css_overview(data, as_json=as_json))
        return

    if target in categories:
        items = categories[target]
        if isinstance(items, list):
            print(format_category(items, target, sdk="frontend", as_json=as_json))
        return

    # Item name lookup (component or composable)
    item = _find_in_manifest(target, data)
    if item:
        print(format_item_detail(item, as_json=as_json))
        return

    retired = _find_retired_frontend_api(target)
    if retired:
        print(format_item_detail(retired, as_json=as_json))
        return

    print(f"Not found: {target}", file=sys.stderr)
    _print_did_you_mean(target, _all_item_names(data), file=sys.stderr)
    sys.exit(1)


def _find_retired_frontend_api(target: str) -> dict[str, Any] | None:
    for component in _DEPRECATED_FRONTEND_COMPONENTS:
        if component.name != target:
            continue
        return {
            "name": component.name,
            "kind": "component",
            "group": "retired",
            "source": "removed public SDK export",
            "description": (
                "Retired frontend SDK compatibility component. "
                "mint doctor still detects old usage and reports this migration."
            ),
            "deprecated": True,
            "replacement": component.replacement,
        }

    for composable in _DEPRECATED_FRONTEND_COMPOSABLES:
        if composable.name != target:
            continue
        return {
            "name": composable.name,
            "kind": "composable",
            "source": "removed public SDK export",
            "description": (
                "Retired frontend SDK compatibility composable. "
                "mint doctor still detects old usage and reports this migration."
            ),
            "deprecated": True,
            "replacement": composable.replacement,
        }

    return None


def _all_item_names(data: dict[str, Any]) -> list[str]:
    """Return every item `name` in a manifest (across all list-shaped categories)."""
    names: list[str] = []
    for cat_data in data.get("categories", {}).values():
        if isinstance(cat_data, list):
            for item in cat_data:
                n = item.get("name")
                if n:
                    names.append(n)
    return names


def _print_did_you_mean(target: str, candidates: list[str], *, file: Any) -> None:
    """Suggest the closest 1–3 matches and the search command as a fallback."""
    matches = difflib.get_close_matches(target, candidates, n=3, cutoff=0.5)
    if matches:
        print(f"  Did you mean: {', '.join(matches)}?", file=file)
    print(f'  Or run:        mint docs search "{target}"', file=file)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------


def _load_sdk(
    cache_dir: Path | None,
    sdk: str,
    platform_root: Path | None,
    *,
    no_cache: bool = False,
) -> dict[str, Any] | None:
    """Load an SDK manifest, using cache when available.

    When *platform_root* is ``None`` (running outside the monorepo),
    Python docs use runtime introspection and frontend docs fall back
    to the bundled manifest shipped with the package.
    """
    if cache_dir and platform_root and not no_cache and is_cache_fresh(cache_dir, sdk, platform_root):
        cached = read_cache(cache_dir, sdk)
        if cached is not None:
            return cached

    if sdk == "python":
        from mint_sdk.docs.python_extractor import extract_python_sdk

        data = extract_python_sdk()
    elif sdk == "frontend":
        if platform_root:
            from mint_sdk.docs.frontend_extractor import extract_frontend_sdk

            data = extract_frontend_sdk(platform_root)
        else:
            data = _load_bundled("frontend")
    else:
        return None

    if cache_dir and platform_root:
        write_cache(cache_dir, sdk, data, platform_root)
    return data


def _load_bundled(sdk: str) -> dict[str, Any]:
    """Load a pre-extracted manifest bundled with the package."""
    bundled_file = _BUNDLED_DIR / f"{sdk}.json"
    if bundled_file.exists():
        return json.loads(bundled_file.read_text())
    return {"sdk": sdk, "version": "", "categories": {}}


# ---------------------------------------------------------------------------
# Item lookup
# ---------------------------------------------------------------------------


def _find_item_by_name(
    name: str,
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Search for an item by name across both SDKs."""
    for data in (python_data, frontend_data):
        if data is None:
            continue
        item = _find_in_manifest(name, data)
        if item:
            return item
    return None


def _find_in_manifest(name: str, data: dict[str, Any]) -> dict[str, Any] | None:
    """Search all categories in a manifest for an item by name."""
    for _cat_name, cat_data in data.get("categories", {}).items():
        if isinstance(cat_data, list):
            for item in cat_data:
                if item.get("name") == name:
                    return item
    return None
