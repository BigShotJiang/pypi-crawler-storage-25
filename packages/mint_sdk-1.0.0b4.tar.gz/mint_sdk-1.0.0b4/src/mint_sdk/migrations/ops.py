"""MigrationOps — portable DDL wrapper for SQLite and PostgreSQL."""

from __future__ import annotations

import logging
from typing import Any

import sqlalchemy as sa
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection

from mint_sdk.migrations.errors import DestructiveMigrationError

logger = logging.getLogger(__name__)


class MigrationOps:
    """Portable DDL operations for plugin migrations.

    Wraps an ``AsyncConnection`` and provides safe, idempotent schema
    operations that work on both SQLite and PostgreSQL.

    Args:
        conn: An active async connection inside a transaction.
        dialect: ``"sqlite"`` or ``"postgresql"``.
        destructive_allowed: Whether drop operations are permitted.
            Set from the migration's ``destructive`` flag.
    """

    def __init__(
        self,
        conn: AsyncConnection,
        *,
        dialect: str,
        destructive_allowed: bool = False,
    ) -> None:
        self._conn = conn
        self._dialect = dialect
        self._destructive = destructive_allowed

    # ── helpers ──────────────────────────────────────────────────────

    def _require_destructive(self, operation: str, table: str, target: str = "") -> None:
        if not self._destructive:
            raise DestructiveMigrationError(operation, table, target)

    async def _column_exists(self, table: str, column: str) -> bool:
        if self._dialect == "sqlite":
            result = await self._conn.execute(text(f'PRAGMA table_info("{table}")'))
            return any(row[1] == column for row in result.fetchall())
        else:
            result = await self._conn.execute(
                text(
                    "SELECT 1 FROM information_schema.columns "
                    "WHERE table_name = :table AND column_name = :col"
                ),
                {"table": table, "col": column},
            )
            return result.scalar() is not None

    async def _table_exists(self, table: str) -> bool:
        if self._dialect == "sqlite":
            result = await self._conn.execute(
                text(
                    "SELECT 1 FROM sqlite_master "
                    "WHERE type='table' AND name = :name"
                ),
                {"name": table},
            )
            return result.scalar() is not None
        else:
            result = await self._conn.execute(
                text(
                    "SELECT 1 FROM information_schema.tables "
                    "WHERE table_name = :name"
                ),
                {"name": table},
            )
            return result.scalar() is not None

    async def _index_exists(self, index_name: str) -> bool:
        if self._dialect == "sqlite":
            result = await self._conn.execute(
                text(
                    "SELECT 1 FROM sqlite_master "
                    "WHERE type='index' AND name = :name"
                ),
                {"name": index_name},
            )
            return result.scalar() is not None
        else:
            result = await self._conn.execute(
                text("SELECT 1 FROM pg_indexes WHERE indexname = :name"),
                {"name": index_name},
            )
            return result.scalar() is not None

    # ── additive operations ─────────────────────────────────────────

    async def add_column(self, table: str, column: sa.Column) -> None:
        """Add a column if it does not already exist."""
        if await self._column_exists(table, column.name):
            logger.debug("Column '%s.%s' already exists, skipping", table, column.name)
            return

        col_type = column.type.compile(dialect=self._conn.dialect)
        nullable = "" if column.nullable is not False else " NOT NULL"
        default = ""
        if column.server_default is not None:
            default_val = column.server_default.arg  # type: ignore[union-attr]
            if isinstance(default_val, str):
                default = f" DEFAULT '{default_val}'"
            else:
                default = f" DEFAULT {default_val}"

        sql = f'ALTER TABLE "{table}" ADD COLUMN "{column.name}" {col_type}{nullable}{default}'
        await self._conn.execute(text(sql))
        logger.info("Added column '%s' to table '%s'", column.name, table)

    async def create_index(
        self, name: str, table: str, columns: list[str], *, unique: bool = False
    ) -> None:
        """Create an index if it does not already exist."""
        if await self._index_exists(name):
            logger.debug("Index '%s' already exists, skipping", name)
            return

        unique_kw = "UNIQUE " if unique else ""
        cols = ", ".join(f'"{c}"' for c in columns)
        await self._conn.execute(
            text(f'CREATE {unique_kw}INDEX "{name}" ON "{table}" ({cols})')
        )
        logger.info("Created index '%s' on '%s'", name, table)

    async def create_table(self, name: str, *columns: sa.Column) -> None:
        """Create a table if it does not already exist."""
        if await self._table_exists(name):
            logger.debug("Table '%s' already exists, skipping", name)
            return

        col_defs = []
        for col in columns:
            col_type = col.type.compile(dialect=self._conn.dialect)
            parts = [f'"{col.name}" {col_type}']
            if col.primary_key:
                parts.append("PRIMARY KEY")
            if col.nullable is False and not col.primary_key:
                parts.append("NOT NULL")
            col_defs.append(" ".join(parts))

        sql = f'CREATE TABLE "{name}" ({", ".join(col_defs)})'
        await self._conn.execute(text(sql))
        logger.info("Created table '%s'", name)

    async def backfill(self, table: str, column: str, default: Any) -> None:
        """Set a default value for all NULL entries in a column."""
        if isinstance(default, str):
            val = f"'{default}'"
        else:
            val = str(default)
        sql = f'UPDATE "{table}" SET "{column}" = {val} WHERE "{column}" IS NULL'
        result = await self._conn.execute(text(sql))
        logger.info("Backfilled %d rows in '%s.%s'", result.rowcount, table, column)

    async def execute(self, stmt: Any) -> Any:
        """Execute a raw SQLAlchemy statement (escape hatch).

        This opts out of portability and idempotency guarantees.
        Use only when typed operations above are insufficient.
        """
        return await self._conn.execute(stmt)

    # ── destructive operations ──────────────────────────────────────

    async def drop_column(self, table: str, column: str) -> None:
        """Drop a column.  Requires ``destructive = True`` on the migration."""
        self._require_destructive("drop_column", table, column)
        if self._dialect == "sqlite":
            await self._sqlite_recreate_table(table, drop_columns=[column])
        else:
            await self._conn.execute(
                text(f'ALTER TABLE "{table}" DROP COLUMN "{column}"')
            )
        logger.info("Dropped column '%s' from table '%s'", column, table)

    async def drop_table(self, name: str) -> None:
        """Drop a table.  Requires ``destructive = True`` on the migration."""
        self._require_destructive("drop_table", name)
        await self._conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
        logger.info("Dropped table '%s'", name)

    async def drop_index(self, name: str) -> None:
        """Drop an index.  Requires ``destructive = True`` on the migration."""
        self._require_destructive("drop_index", name, name)
        await self._conn.execute(text(f'DROP INDEX IF EXISTS "{name}"'))
        logger.info("Dropped index '%s'", name)

    async def rename_column(self, table: str, old: str, new: str) -> None:
        """Rename a column.  SQLite uses the recreate-table pattern."""
        if self._dialect == "sqlite":
            await self._sqlite_recreate_table(table, rename_columns={old: new})
        else:
            await self._conn.execute(
                text(f'ALTER TABLE "{table}" RENAME COLUMN "{old}" TO "{new}"')
            )
        logger.info("Renamed column '%s.%s' to '%s'", table, old, new)

    async def alter_column(
        self, table: str, column: str, type_: sa.types.TypeEngine
    ) -> None:
        """Change a column's type.  SQLite uses the recreate-table pattern."""
        if self._dialect == "sqlite":
            await self._sqlite_recreate_table(table, alter_types={column: type_})
        else:
            compiled = type_.compile(dialect=self._conn.dialect)
            await self._conn.execute(
                text(
                    f'ALTER TABLE "{table}" ALTER COLUMN "{column}" '
                    f"TYPE {compiled}"
                )
            )
        logger.info("Altered column '%s.%s' type", table, column)

    # ── SQLite recreate-table ───────────────────────────────────────

    async def _sqlite_recreate_table(
        self,
        table: str,
        *,
        drop_columns: list[str] | None = None,
        rename_columns: dict[str, str] | None = None,
        alter_types: dict[str, sa.types.TypeEngine] | None = None,
    ) -> None:
        """Recreate a SQLite table to apply column changes.

        Preserves data, indexes, and NOT NULL constraints.
        """
        drop_columns = drop_columns or []
        rename_columns = rename_columns or {}
        alter_types = alter_types or {}

        # Read current schema
        result = await self._conn.execute(text(f'PRAGMA table_info("{table}")'))
        columns_info = result.fetchall()
        # columns_info rows: (cid, name, type, notnull, dflt_value, pk)

        # Read existing indexes
        result = await self._conn.execute(text(f'PRAGMA index_list("{table}")'))
        index_list = result.fetchall()
        indexes = []
        for idx_row in index_list:
            idx_name = idx_row[1]
            is_unique = bool(idx_row[2])
            result2 = await self._conn.execute(text(f'PRAGMA index_info("{idx_name}")'))
            idx_cols = [r[2] for r in result2.fetchall()]
            indexes.append((idx_name, idx_cols, is_unique))

        # Build new column definitions
        tmp = f"_mint_tmp_{table}"
        new_cols = []
        old_select = []
        for col in columns_info:
            col_name = col[1]
            if col_name in drop_columns:
                continue

            new_name = rename_columns.get(col_name, col_name)
            if col_name in alter_types:
                col_type = alter_types[col_name].compile(dialect=self._conn.dialect)
            else:
                col_type = col[2]
            not_null = " NOT NULL" if col[3] else ""
            pk = " PRIMARY KEY" if col[5] else ""
            default = f" DEFAULT {col[4]}" if col[4] is not None else ""

            new_cols.append(f'"{new_name}" {col_type}{pk}{not_null}{default}')
            old_select.append(f'"{col_name}"')

        # Create temp table, copy data, swap
        col_defs = ", ".join(new_cols)
        await self._conn.execute(text(f'CREATE TABLE "{tmp}" ({col_defs})'))

        select_cols = ", ".join(old_select)
        await self._conn.execute(
            text(f'INSERT INTO "{tmp}" SELECT {select_cols} FROM "{table}"')
        )

        await self._conn.execute(text(f'DROP TABLE "{table}"'))
        await self._conn.execute(text(f'ALTER TABLE "{tmp}" RENAME TO "{table}"'))

        # Recreate indexes (with renamed columns)
        for idx_name, idx_cols, is_unique in indexes:
            new_idx_cols = [
                rename_columns.get(c, c) for c in idx_cols if c not in drop_columns
            ]
            if not new_idx_cols:
                continue
            unique_kw = "UNIQUE " if is_unique else ""
            cols_sql = ", ".join(f'"{c}"' for c in new_idx_cols)
            await self._conn.execute(
                text(f'CREATE {unique_kw}INDEX "{idx_name}" ON "{table}" ({cols_sql})')
            )
