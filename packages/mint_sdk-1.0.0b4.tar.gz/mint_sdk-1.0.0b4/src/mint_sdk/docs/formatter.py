"""Format extracted SDK documentation as markdown or JSON for terminal output."""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_COMPONENTS,
    DEPRECATED_FRONTEND_COMPOSABLES,
)

# ---------------------------------------------------------------------------
# Color helpers
# ---------------------------------------------------------------------------


def _supports_color() -> bool:
    """Return True if stdout likely supports ANSI color."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    term = os.environ.get("TERM", "")
    return term != "dumb"


def _bold(text: str, color: bool) -> str:
    return f"\033[1m{text}\033[0m" if color else text


def _dim(text: str, color: bool) -> str:
    return f"\033[2m{text}\033[0m" if color else text


def _cyan(text: str, color: bool) -> str:
    return f"\033[36m{text}\033[0m" if color else text


def _green(text: str, color: bool) -> str:
    return f"\033[32m{text}\033[0m" if color else text


def _yellow(text: str, color: bool) -> str:
    return f"\033[33m{text}\033[0m" if color else text


def _red(text: str, color: bool) -> str:
    return f"\033[31m{text}\033[0m" if color else text


def _magenta(text: str, color: bool) -> str:
    return f"\033[35m{text}\033[0m" if color else text


# ---------------------------------------------------------------------------
# Top-level table of contents
# ---------------------------------------------------------------------------


def format_toc(
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
    *,
    as_json: bool = False,
) -> str:
    """Render the top-level table of contents."""
    if as_json:
        toc: dict[str, Any] = {
            "guides": {
                "frontend-choose": "mint docs frontend choose",
                "frontend-consolidation": "mint docs frontend consolidate",
                "frontend-sidebar": "mint docs frontend sidebar",
                "contract": "mint docs contract",
                "deprecated-apis": "mint docs deprecated-apis",
                "frontend-api": "mint docs frontend-api",
                "r-bridge": "mint docs r-bridge",
                "template": "mint docs template <name>",
                "template-pack": "mint docs template-pack <name>",
                "template-preset": "mint docs template-preset <name>",
                "add-template-preset": "mint add data-template-preset <name> --page",
            }
        }
        if python_data:
            toc["python"] = {
                "version": python_data.get("version", ""),
                "categories": {
                    k: len(v) for k, v in python_data.get("categories", {}).items()
                },
            }
        if frontend_data:
            toc["frontend"] = {
                "version": frontend_data.get("version", ""),
                "categories": {
                    k: _frontend_category_count(k, v)
                    for k, v in frontend_data.get("categories", {}).items()
                },
            }
        return json.dumps(toc, indent=2)

    c = _supports_color()
    lines: list[str] = []

    version_parts = []
    if python_data:
        version_parts.append(python_data.get("version", ""))
    lines.append(
        _bold("MINT SDK Reference", c) + "  " + _dim(" ".join(version_parts), c)
    )
    lines.append("")

    if frontend_data:
        lines.append(_cyan("frontend", c))
        for cat_name, cat_data in frontend_data.get("categories", {}).items():
            count = _frontend_category_count(cat_name, cat_data)
            summary = _frontend_category_summary(cat_name, cat_data)
            lines.append(f"  {_green(cat_name, c):30s} {count:>3} items   {_dim(summary, c)}")
        lines.append("")

    if python_data:
        lines.append(_cyan("python", c))
        for cat_name, items in python_data.get("categories", {}).items():
            names = ", ".join(i["name"] for i in items[:4])
            suffix = "..." if len(items) > 4 else ""
            lines.append(
                f"  {_green(cat_name, c):30s} {len(items):>3} items   {_dim(names + suffix, c)}"
            )
        lines.append("")

    lines.append(_bold("Common workflows", c))
    lines.append(_dim("  mint docs frontend choose           # pick canonical UI components by task", c))
    lines.append(_dim("  mint docs frontend consolidate      # component cleanup and consolidation strategy", c))
    lines.append(_dim("  mint docs frontend sidebar          # LEAF-style plugin sidebar language", c))
    lines.append(_dim('  mint docs frontend components       # browse all UI components, grouped', c))
    lines.append(
        _dim(
            '  mint docs search "<concept>"        # search across both SDKs (e.g. "table", "form input")',
            c,
        )
    )
    lines.append(_dim("  mint docs frontend <name>           # reference for one component, composable, or helper", c))
    lines.append(_dim("  mint docs python <ClassName>        # backend SDK class reference", c))
    lines.append(_dim("  mint docs contract                  # local plugin endpoints and generated client calls", c))
    lines.append(_dim("  mint docs frontend-api              # migrate useApi/VITE_API_PREFIX to generated client", c))
    lines.append(
        _dim(
            "  mint docs deprecated-apis           # migrate abandoned SDK imports, props, and components",
            c,
        )
    )
    lines.append(_dim("  mint docs r-bridge                  # R bridge routes, schemas, env vars, helpers", c))
    lines.append(_dim("  mint init --list-templates          # plugin starter templates", c))
    lines.append(_dim("  mint add data-template --list       # biology data template catalog", c))
    lines.append(_dim("  mint add data-template-pack --list  # curated template sets", c))
    lines.append(_dim("  mint add data-template-preset --list  # ready-to-save presets", c))
    lines.append(_dim("  mint docs template plate-map        # template imports/adapters/components", c))
    lines.append(_dim("  mint docs template-pack cell-culture-screen  # pack-level wiring", c))
    lines.append(_dim("  mint docs template-preset wellplate-screen  # ready-to-save design_data", c))
    lines.append("")
    lines.append(_dim("Tip: every command supports --json for machine-readable output.", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# SDK overview
# ---------------------------------------------------------------------------


def format_sdk_overview(
    data: dict[str, Any], sdk: str, *, as_json: bool = False
) -> str:
    """Render category listing for a single SDK."""
    if as_json:
        if sdk == "frontend":
            return json.dumps(
                {
                    k: _frontend_category_count(k, v)
                    for k, v in data.get("categories", {}).items()
                },
                indent=2,
            )
        return json.dumps(
            {k: len(v) for k, v in data.get("categories", {}).items()}, indent=2
        )

    c = _supports_color()
    lines = [_bold(f"{sdk.title()} SDK", c), ""]

    categories = data.get("categories", {})
    for cat_name, cat_data in categories.items():
        if sdk == "frontend":
            count = _frontend_category_count(cat_name, cat_data)
            summary = _frontend_category_summary(cat_name, cat_data)
            lines.append(f"  {_green(cat_name, c):25s} {count:>3} items   {_dim(summary, c)}")
        else:
            items = cat_data
            names = ", ".join(i["name"] for i in items[:5])
            suffix = "..." if len(items) > 5 else ""
            lines.append(
                f"  {_green(cat_name, c):25s} {len(items):>3} items   {_dim(names + suffix, c)}"
            )

    lines.append("")
    if sdk == "python":
        lines.append(_dim("Use: mint docs python <category>  |  mint docs python <ClassName>", c))
    else:
        lines.append(
            _dim(
                "Use: mint docs frontend <category>  |  mint docs frontend <name>",
                c,
            )
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Python: category listing
# ---------------------------------------------------------------------------


def format_category(
    items: list[dict[str, Any]],
    category: str,
    *,
    sdk: str = "python",
    as_json: bool = False,
) -> str:
    """Render all items in a list-shaped SDK category."""
    if as_json:
        return json.dumps(items, indent=2, default=str)

    c = _supports_color()
    lines = [_bold(category.title(), c) + _dim(f"  {len(items)} items", c), ""]

    for item in items:
        kind = item.get("kind", "")
        desc = item.get("description", "")
        if len(desc) > 70:
            desc = desc[:67] + "..."
        lines.append(f"  {_green(item['name'], c):35s} {_dim(kind, c):15s} {desc}")
        aliases = item.get("aliases")
        if isinstance(aliases, list) and aliases:
            lines.append(f"    aliases: {', '.join(str(alias) for alias in aliases)}")

    lines.append("")
    lines.append(_dim(f"Use: mint docs {sdk} <name> for full reference", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Python / Frontend: item detail
# ---------------------------------------------------------------------------


def format_item_detail(
    item: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render full reference for a single item (component, class, etc.)."""
    if as_json:
        return json.dumps(item, indent=2, default=str)

    kind = item.get("kind", "")
    if kind in ("dataclass", "class", "protocol"):
        return _format_class_detail(item)
    if kind == "enum":
        return _format_enum_detail(item)
    if kind == "exception":
        return _format_exception_detail(item)
    if kind == "function":
        return _format_function_detail(item)
    if kind == "alias":
        return _format_alias_detail(item)
    if kind == "component":
        return _format_component_detail(item)
    if kind == "composable":
        return _format_composable_detail(item)
    if kind == "template":
        return _format_frontend_template_detail(item)
    if kind == "template-preset":
        return _format_frontend_template_preset_detail(item)
    # Fallback
    return json.dumps(item, indent=2, default=str)


def _format_class_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    # Properties
    props = item.get("properties", [])
    if props:
        lines.append(_cyan("Properties", c))
        for p in props:
            abstract_tag = _red("abstract", c) + " " if p.get("abstract") else ""
            description = _dim(p.get("description", ""), c)
            lines.append(
                f"  {_green(p['name'], c):30s} "
                f"{_yellow(p.get('type', ''), c):25s} "
                f"{abstract_tag}{description}"
            )
        lines.append("")

    # Fields (dataclass)
    fields = item.get("fields", [])
    if fields:
        lines.append(_cyan("Fields", c))
        for f in fields:
            req = _red("required", c) if f.get("required") else _dim(f"= {f.get('default', '?')}", c)
            lines.append(
                f"  {_green(f['name'], c):30s} {_yellow(f.get('type', ''), c):25s} {req}"
            )
        lines.append("")

    # Abstract methods (ABCs) or regular methods
    method_sections = [("Abstract Methods", "abstract_methods")]
    if item.get("concrete_methods") is not None:
        method_sections.append(("Methods", "concrete_methods"))
    else:
        method_sections.append(("Methods", "methods"))

    for section_name, key in method_sections:
        methods = item.get(key, [])
        if methods:
            lines.append(_cyan(section_name, c))
            for m in methods:
                sig = _format_method_signature(m)
                lines.append(f"  {_green(sig, c)}")
                if m.get("description"):
                    lines.append(f"      {_dim(m['description'], c)}")
                lines.append("")

    return "\n".join(lines)


def _format_enum_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    lines.append(_cyan("Members", c))
    for m in item.get("members", []):
        lines.append(f"  {_green(m['name'], c):25s} = {_yellow(repr(m['value']), c)}")

    return "\n".join(lines)


def _format_exception_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    parents = " > ".join(item.get("parents", []))
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if parents:
        lines.append(_dim(f"Inherits: {parents}", c))
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    params = item.get("init_params", [])
    if params:
        lines.append(_cyan("__init__ Parameters", c))
        for p in params:
            default = f" = {p['default']}" if "default" in p else ""
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}{_dim(default, c)}"
            )

    return "\n".join(lines)


def _format_function_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    ret = item.get("return_type", "")
    if ret:
        lines.append(_dim(f"Returns: {ret}", c))
        lines.append("")

    params = item.get("params", [])
    if params:
        lines.append(_cyan("Parameters", c))
        for p in params:
            default = f" = {p['default']}" if "default" in p else ""
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}{_dim(default, c)}"
            )

    return "\n".join(lines)


def _format_alias_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    target = item.get("target", item.get("type", ""))
    return (
        _bold(item["name"], c)
        + "\n\n"
        + _dim(item.get("description", f"Alias for {target}"), c)
    )


# ---------------------------------------------------------------------------
# Frontend: component detail
# ---------------------------------------------------------------------------


def _format_component_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    group = item.get("group", "")
    source = item.get("source", "")
    lines = [
        _bold(item["name"], c)
        + "  "
        + _dim(f"{group}  •  {source}", c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    if item.get("deprecated"):
        replacement = item.get("replacement")
        lines.append(_yellow("Deprecated", c))
        if replacement:
            lines.append(f"  use: {replacement}")
            lines.append(f"  docs: mint docs frontend {replacement}")
        else:
            lines.append("  check: mint docs deprecated-apis")
        lines.append("")

    usage = _format_component_usage(item)
    if usage:
        lines.append(_cyan("Usage", c))
        lines.extend(f"  {line}" for line in usage)
        lines.append("")

    # Props
    props = item.get("props", [])
    if props:
        lines.append(_cyan("Props", c))
        for p in props:
            req_str = (
                _red("required", c)
                if p.get("required")
                else _dim(f"= {p.get('default', 'undefined')}", c)
            )
            description = _dim(p.get("description", ""), c)
            lines.append(
                f"  {_green(p['name'], c):30s} "
                f"{_yellow(p.get('type', ''), c):25s} "
                f"{req_str}   {description}"
            )
        lines.append("")

    # Emits
    emits = item.get("emits", [])
    if emits:
        lines.append(_cyan("Emits", c))
        for e in emits:
            lines.append(
                f"  {_green(e['name'], c):30s} {_yellow(e.get('type', ''), c)}"
            )
        lines.append("")

    # Slots
    slots = item.get("slots", [])
    if slots:
        lines.append(_cyan("Slots", c))
        for s in slots:
            bindings = s.get("bindings", {})
            binding_str = (
                ", ".join(f"{k}: {v}" for k, v in bindings.items())
                if isinstance(bindings, dict)
                else str(bindings)
            )
            lines.append(
                f"  {_green(s['name'], c):30s} {_dim(binding_str, c)}"
            )

    return "\n".join(lines)


def _format_component_usage(item: dict[str, Any]) -> list[str]:
    """Return short first-path snippets for high-traffic components."""
    match item.get("name"):
        case "FormBuilder":
            return [
                "import { ref } from 'vue'",
                "import { FormBuilder, defineControlModel } from '@morscherlab/mint-sdk'",
                "const formModel = defineControlModel({",
                "  controls: {",
                "    threshold: { type: 'number', default: 0.05, min: 0, max: 1 },",
                "    method: { default: 'linear', options: ['linear', 'logistic'] },",
                "  },",
                "})",
                "const values = ref({})",
                '<FormBuilder v-model="values" :model="formModel" />',
            ]
        case "ControlWorkspaceView":
            return [
                "import { ref } from 'vue'",
                "import { ComponentBindingRenderer, ControlWorkspaceView, defineControlModel } "
                "from '@morscherlab/mint-sdk'",
                "const workspaceModel = defineControlModel({",
                "  views: {",
                "    run: {",
                "      label: 'Run',",
                "      icon: 'M8 5v14l11-7z',",
                "      sections: {",
                "        parameters: {",
                "          label: 'Parameters',",
                "          controls: { threshold: { type: 'number', default: 0.05, min: 0, max: 1 } },",
                "        },",
                "      },",
                "    },",
                "  },",
                "  components: {",
                "    plate: { component: 'WellPlate', props: { modelValue: () => ['A1'], format: () => 96 } },",
                "  },",
                "})",
                "const values = ref({})",
                '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Analysis" '
                'sidebar-title="Run Controls" />',
                '<ControlWorkspaceView v-model="values" :model="workspaceModel" '
                'v-slot="{ componentBindings }">',
                '  <ComponentBindingRenderer :bindings="componentBindings" />',
                '</ControlWorkspaceView>',
                '<ControlWorkspaceView v-model="values" :model="workspaceModel" :form-loading="saving" '
                ':form-enhancements="enhancements" />',
            ]
        case "PluginWorkspaceView":
            return [
                "import { PluginWorkspaceView, useCurrentExperiment } from '@morscherlab/mint-sdk'",
                "import { ref } from 'vue'",
                "import { DoseCalculator, WellPlate, defineDoseDesignControlModel } "
                "from '@morscherlab/mint-sdk'",
                "const pillNav = [{ id: 'data', label: 'Data' }, { id: 'results', label: 'Results' }]",
                "const panels = { data: [{ id: 'import', label: 'Import' }] }",
                "const currentExperiment = useCurrentExperiment()",
                "const doseDesignModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })",
                "const doseValues = ref({})",
                "async function saveCurrent() {",
                "  await saveResultsToExperiment()",
                "  return 'Saved to experiment'",
                "}",
                '<PluginWorkspaceView title="MS Uploader" :pill-nav="pillNav" :panels="panels" '
                'sidebar-title="Tools" experiment-shell :experiment="currentExperiment.experiment" '
                ':experiment-save="saveCurrent" @experiment-select="loadExperiment">',
                '  <template #section-import>',
                "    <FileUploader accept=\".csv\" />",
                "  </template>",
                "  <router-view />",
                "</PluginWorkspaceView>",
                '<PluginWorkspaceView v-model="doseValues" :model="doseDesignModel" '
                'title="Dose Design" v-slot="{ componentBindingsById }">',
                '  <WellPlate v-bind="componentBindingsById.plate.props" />',
                '  <DoseCalculator v-bind="componentBindingsById.dose.props" />',
                '</PluginWorkspaceView>',
                '<PluginWorkspaceView title="Sequence" sidebar-content-id="route-sidebar" '
                'show-sidebar-when-empty>',
                '  <Teleport to="#route-sidebar"><RouteControls /></Teleport>',
                "  <router-view />",
                "</PluginWorkspaceView>",
                "// Drop down to AppLayout/AppTopBar/AppSidebar only for unusual chrome.",
            ]
        case "ComponentBindingRenderer":
            return [
                "import { ComponentBindingRenderer, defineDoseDesignControlModel, useControlWorkspace } "
                "from '@morscherlab/mint-sdk'",
                "const workspaceModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })",
                "const workspace = useControlWorkspace(workspaceModel)",
                '<ComponentBindingRenderer :bindings="workspace.componentBindings.value" />',
                '<ComponentBindingRenderer :binding="workspace.componentBindingsById.value.plate" dense />',
            ]
        case "DoseDesignWorkspaceView":
            return [
                "import { ref } from 'vue'",
                "import { DoseDesignWorkspaceView } from '@morscherlab/mint-sdk'",
                "const values = ref({ selectedWells: ['A1', 'A2'], plateFormat: 96 })",
                '<DoseDesignWorkspaceView v-model="values" title="Dose Design" />',
                '<DoseDesignWorkspaceView',
                '  v-model="values"',
                '  :dose-design-options="{ includeMolecularWeight: true }"',
                '  :well-plate-props="{ heatmap: { enabled: true } }"',
                '/>',
                '<DoseDesignWorkspaceView v-model="values" v-slot="{ wellPlateProps, doseCalculatorProps }">',
                '  <WellPlate v-bind="wellPlateProps" />',
                '  <DoseCalculator v-bind="doseCalculatorProps" />',
                '</DoseDesignWorkspaceView>',
                "// Drop down to defineDoseDesignControlModel + ControlWorkspaceView only for custom layouts.",
            ]
        case "BioTemplatePresetWorkspaceView":
            return [
                "import { ref } from 'vue'",
                "import { BioTemplatePresetWorkspaceView } from '@morscherlab/mint-sdk'",
                "const values = ref({ sampleNames: ['Control', 'Treatment'] })",
                '<BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen" />',
                '<BioTemplatePresetWorkspaceView preset="wellplate-screen" v-slot="{ bindings }">',
                '  <WellPlate v-bind="bindings.componentBindingsById.value[\'plate-map:WellPlate\'].props" />',
                (
                    '  <DoseCalculator v-bind="bindings.componentBindingsById.value'
                    '[\'dose-response:DoseCalculator\'].props" />'
                ),
                '</BioTemplatePresetWorkspaceView>',
                "// Pass :workspace only when you need lower-level save or custom persistence control.",
            ]
        case "BioTemplateExperimentWorkspaceView":
            return [
                "import { BioTemplateExperimentWorkspaceView, createWellPlateScreenCollection } "
                "from '@morscherlab/mint-sdk'",
                "const target = createWellPlateScreenCollection()",
                '<BioTemplateExperimentWorkspaceView :target="target" label="Wellplate Screen" kind="collection" />',
                '<BioTemplateExperimentWorkspaceView :target="template" label="Plate Map" '
                ':status="{ loading, error, hasExperiment }" '
                ':actions="{ load: loadCurrent, save: saveCurrent }" />',
                '<BioTemplateExperimentWorkspaceView :target="target" label="Wellplate Screen" kind="collection" '
                'v-slot="{ bindings }">',
                '  <WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />',
                '  <DoseCalculator v-bind="bindings.componentBindingsById[\'dose-response:DoseCalculator\'].props" />',
                '</BioTemplateExperimentWorkspaceView>',
            ]
        case "BioTemplatePackWorkspaceView":
            return [
                "import { BioTemplatePackWorkspaceView } from '@morscherlab/mint-sdk'",
                '<BioTemplatePackWorkspaceView pack="cell-culture-screen" />',
                '<BioTemplatePackWorkspaceView :workspace="pack.workspace" '
                ':status="{ loading: pack.loading, error: pack.error }" '
                ':actions="{ load: pack.loadCurrent, save: pack.saveCurrent }" />',
                '<BioTemplatePackWorkspaceView pack="cell-culture-screen" v-slot="{ bindings }">',
                '  <WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />',
                '  <DoseCalculator v-bind="bindings.componentBindingsById[\'dose-response:DoseCalculator\'].props" />',
                '</BioTemplatePackWorkspaceView>',
            ]
        case "AppSidebar":
            return [
                "import { ref } from 'vue'",
                "import { AppLayout, AppSidebar, AppTopBar, defineControlModel } from '@morscherlab/mint-sdk'",
                "const sidebarModel = defineControlModel({",
                "  views: {",
                "    run: {",
                "      label: 'Run',",
                "      sections: {",
                "        parameters: {",
                "          label: 'Parameters',",
                "          controls: { threshold: { type: 'number', default: 0.05 } },",
                "        },",
                "      },",
                "    },",
                "  },",
                "})",
                "const values = ref({})",
                '<AppSidebar v-model="values" :model="sidebarModel" />',
                "// LEAF-style analysis sidebar chrome with SDK-owned mobile behavior.",
                '<AppLayout responsive-sidebar sidebar-width="20rem">',
                '  <template #topbar><AppTopBar title="Analysis" /></template>',
                "  <template #sidebar>",
                '    <AppSidebar',
                '      v-model="values"',
                '      variant="analysis"',
                '      title="Peak Picking"',
                '      subtitle="Current experiment"',
                '      :model="sidebarModel"',
                "    />",
                "  </template>",
                "</AppLayout>",
                "// Prefer ControlWorkspaceView when you also need topbar + main form wiring.",
                "// Route-owned sidebar content shell with a pinned action footer.",
                '<AppSidebar variant="analysis" content-id="run-sidebar" show-when-empty>',
                "  <template #footer><BaseButton variant=\"cta\">Run</BaseButton></template>",
                "</AppSidebar>",
                '<Teleport to="#run-sidebar">',
                "  <RunControls />",
                "</Teleport>",
            ]
        case "SettingsModal":
            return [
                "import { ref } from 'vue'",
                "import { SettingsModal, defineControlModel } from '@morscherlab/mint-sdk'",
                "const open = ref(false)",
                "const values = ref({})",
                "const settingsModel = defineControlModel({",
                "  controls: {",
                "    threshold: { type: 'number', default: 0.05, section: 'analysis' },",
                "  },",
                "})",
                '<SettingsModal v-model="open" v-model:values="values" :model="settingsModel" />',
                "// AppTopBar can forward the same model through settingsConfig.model.",
            ]
    return []


def _format_composable_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("source", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    if item.get("deprecated"):
        replacement = item.get("replacement")
        lines.append(_yellow("Deprecated", c))
        if replacement:
            lines.append(f"  use: {replacement}")
        lines.append("  docs: mint docs deprecated-apis")
        lines.append("")

    usage = _format_composable_usage(item)
    if usage:
        lines.append(_cyan("Usage", c))
        lines.extend(f"  {line}" for line in usage)
        lines.append("")

    params = item.get("params", [])
    if params:
        lines.append(_cyan("Parameters", c))
        for p in params:
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}"
            )
        lines.append("")

    return_type = item.get("returnType", "")
    if return_type:
        lines.append(_cyan("Returns", c))
        lines.append(f"  {_yellow(return_type, c)}")
        lines.append("")

    members = item.get("members", [])
    if members:
        lines.append(_cyan("Members", c))
        for member in members:
            member_type = member.get("type", "")
            if len(member_type) > 70:
                member_type = member_type[:67] + "..."
            description = _dim(member.get("description", ""), c)
            lines.append(
                f"  {_green(member['name'], c):25s} {_yellow(member_type, c):35s} {description}"
            )

    return "\n".join(lines)


def _format_composable_usage(item: dict[str, Any]) -> list[str]:
    """Return short first-path snippets for composables where docs should steer usage."""
    if item.get("name") in {"defineControlModel", "defineDoseDesignControlModel"}:
        return [
            "// For standard WellPlate + DoseCalculator pages, prefer DoseDesignWorkspaceView.",
            "// Use this helper when you need a custom ControlWorkspaceView layout.",
            "import { ref } from 'vue'",
            "import { ControlWorkspaceView, DoseCalculator, WellPlate, defineDoseDesignControlModel } "
            "from '@morscherlab/mint-sdk'",
            "const workspaceModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })",
            "const values = ref({})",
            '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Design" '
            'v-slot="{ componentBindingsById }">',
            "  <!-- WellPlate selection updates values.selectedWells through generated v-model props. -->",
            "  <!-- DoseCalculator Apply writes concentration results into values.wells. -->",
            "  <WellPlate v-bind=\"componentBindingsById.plate.props\" />",
            "  <DoseCalculator v-bind=\"componentBindingsById.dose.props\" />",
            "</ControlWorkspaceView>",
        ]

    if item.get("name") == "useAppExperiment":
        return [
            "import { AppTopBar, useAppExperiment, useCurrentExperiment } from '@morscherlab/mint-sdk'",
            "const currentExperiment = useCurrentExperiment()",
            "const appExperiment = useAppExperiment({",
            "  experiment: currentExperiment.experiment,",
            "  onSelect: experiment => {",
            "    // Optional: sync the selected experiment into your route or page state.",
            "    currentExperimentId.value = experiment.id",
            "  },",
            "  onDetach: () => {",
            "    currentExperimentId.value = null",
            "  },",
            "  onSave: async () => {",
            "    await saveCurrent()",
            "    return 'Saved to experiment'",
            "  },",
            "})",
            "",
            "// AppTopBar reads the provided experiment context automatically.",
            '<AppTopBar title="Analysis" :page-selector="pageSelector" />',
            "",
            "// Use these only when composing ExperimentPopover / ExperimentSelectorModal yourself.",
            '<ExperimentPopover v-bind="appExperiment.popover.value" />',
            '<ExperimentSelectorModal v-bind="appExperiment.selectorModal.value" />',
        ]

    if item.get("name") == "useBioTemplatePackWorkspace":
        return [
            "import { AppSidebar, AppTopBar, BioTemplateRenderer, DoseCalculator, WellPlate, "
            "useBioTemplatePackWorkspace } from '@morscherlab/mint-sdk'",
            "const { bindings, saveCurrent } = "
            "useBioTemplatePackWorkspace('cell-culture-screen')",
            '<AppTopBar v-bind="bindings.topBar.value" />',
            '<AppSidebar v-bind="bindings.sidebar" />',
            '<BioTemplateRenderer v-bind="bindings.renderer" />',
            '<WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />',
            '<DoseCalculator v-bind="bindings.componentBindingsById[\'dose-response:DoseCalculator\'].props" />',
            "await saveCurrent()",
        ]

    if item.get("name") != "useControlWorkspace":
        return []

    return [
        "import { ref } from 'vue'",
        "import { AppSidebar, AppTopBar, ControlWorkspaceView, FormBuilder, "
        "defineControlModel, useControlWorkspace } from '@morscherlab/mint-sdk'",
        "const workspaceModel = defineControlModel({",
        "  views: {",
        "    run: {",
        "      label: 'Run',",
        "      icon: 'M8 5v14l11-7z',",
        "      controls: { threshold: { type: 'number', default: 0.05, min: 0, max: 1 } },",
        "    },",
        "  },",
        "})",
        "const values = ref({})",
        '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Analysis" />',
        "// Use useControlWorkspace(...) only when you need manual bindings.",
        "const workspace = useControlWorkspace(workspaceModel)",
        "const { form, sidebar, topBar } = workspace.bindings",
        '<FormBuilder v-bind="form" />',
        '<AppSidebar v-bind="sidebar" />',
        '<AppTopBar v-bind="topBar" />',
        "const componentProps = workspace.getComponentProps({ threshold: 'threshold' })",
        "const componentPropsById = workspace.componentPropsById",
        "const componentBindings = workspace.componentBindings",
        '<YourComponent v-bind="componentProps" />',
        '<WellPlate v-bind="componentPropsById.plate" />',
        '<WellPlate v-bind="componentBindings.value[0].props" />',
    ]


def _format_frontend_template_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c)
        + "  "
        + _dim(f"{item.get('group', '')}  •  {item.get('source', '')}", c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    template_id = item.get("template_id")
    template_version = item.get("template_version")
    if template_id or template_version:
        lines.append(_cyan("Template", c))
        if template_id:
            lines.append(f"  {_green('id', c):18s} {_yellow(str(template_id), c)}")
        if template_version:
            lines.append(f"  {_green('version', c):18s} {_yellow(str(template_version), c)}")
        lines.append("")

    if item.get("frontend_import"):
        lines.append(_cyan("Frontend", c))
        lines.append(f"  {item['frontend_import']}")
        if item.get("frontend_adapters"):
            lines.append(f"  adapters: {', '.join(str(v) for v in item['frontend_adapters'])}")
        if item.get("components"):
            lines.append(f"  components: {', '.join(str(v) for v in item['components'])}")
        lines.append("")

    if item.get("add_command"):
        lines.append(_cyan("Backend data", c))
        lines.append(f"  {item['add_command']}")
        lines.append(f"  mint docs template {item['name']}")

    return "\n".join(lines)


def _format_frontend_template_preset_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c)
        + "  "
        + _dim(f"{item.get('group', '')}  •  {item.get('source', '')}", c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    aliases = item.get("aliases")
    if isinstance(aliases, list) and aliases:
        lines.append(_cyan("Aliases", c))
        lines.append(f"  {', '.join(str(alias) for alias in aliases)}")
        lines.append("")

    templates = [str(value) for value in item.get("templates", [])]
    if templates:
        lines.append(_cyan("Templates", c))
        lines.extend(f"  - {template}" for template in templates)
        lines.append("")

    if item.get("frontend_import"):
        label = str(item["name"]).replace("-", " ").title()
        lines.append(_cyan("Frontend", c))
        lines.append("  import { ref } from 'vue'")
        lines.append(
            "  import { BioTemplatePresetWorkspaceView } from '@morscherlab/mint-sdk'"
        )
        lines.append("  const values = ref({})")
        lines.append(
            f'  <BioTemplatePresetWorkspaceView v-model="values" preset="{item["name"]}" label="{label}" />'
        )
        lines.append("")
        lines.append(_cyan("Lower-level adapters", c))
        lines.append(f"  {item['frontend_import']}")
        if item.get("frontend_adapters"):
            lines.append(f"  adapters: {', '.join(str(v) for v in item['frontend_adapters'])}")
        if item.get("components"):
            lines.append(f"  components: {', '.join(str(v) for v in item['components'])}")
        lines.append("")

    lines.append(_cyan("Backend data", c))
    lines.append(f"  mint add data-template-preset {item['name']} --page")
    lines.append(f"  mint docs template-preset {item['name']}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Frontend: grouped component listing
# ---------------------------------------------------------------------------


def format_components_grouped(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render all components grouped by category."""
    components = data.get("categories", {}).get("components", [])
    if as_json:
        return json.dumps([_component_catalog_json_item(comp) for comp in components], indent=2, default=str)

    canonical_components = [comp for comp in components if not comp.get("deprecated")]
    deprecated_components = [comp for comp in components if comp.get("deprecated")]

    # Build groups from canonical components first so the primary scan path
    # does not put deprecated entries on the same footing as preferred API.
    groups: dict[str, list[dict[str, Any]]] = {}
    for comp in canonical_components:
        g = comp.get("group", "other")
        groups.setdefault(g, []).append(comp)

    c = _supports_color()
    lines = [
        _bold("Frontend Components", c)
        + _dim(
            f"  {len(canonical_components)} canonical components in {len(groups)} groups"
            f"  |  {len(deprecated_components)} deprecated entries",
            c,
        ),
        "",
    ]

    for group_name, group_items in sorted(groups.items()):
        lines.append(_cyan(group_name, c) + _dim(f" ({len(group_items)})", c))
        # Two-column "name — description" layout. When a component has a
        # description, surface it inline so an agent can scan a whole group
        # without drilling into each entry. Falls back gracefully when no
        # JSDoc exists yet.
        for comp in sorted(group_items, key=lambda c: c.get("name", "")):
            name = comp.get("name", "")
            desc = _component_listing_description(comp)
            if desc:
                lines.append(f"  {_green(name, c):28s} {_dim(desc, c)}")
            else:
                lines.append(f"  {_green(name, c)}")
        lines.append("")

    if deprecated_components:
        lines.append(_yellow("Deprecated entries", c) + _dim("  avoid in new code", c))
        for comp in sorted(deprecated_components, key=lambda c: (c.get("group", ""), c.get("name", ""))):
            name = comp.get("name", "")
            desc = _component_listing_description(comp)
            group = comp.get("group", "other")
            lines.append(f"  {_green(name, c):28s} {_dim(f'{group} · {desc}', c)}")
        lines.append("")

    lines.append(
        _dim(
            "Use: mint docs frontend components <group>  |  mint docs frontend <name>",
            c,
        )
    )
    return "\n".join(lines)


def format_frontend_component_chooser(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render a task-oriented chooser that steers developers to canonical components."""
    avoid_in_new_code = [
        *[
            {
                "name": comp.name,
                "replacement": comp.replacement,
                "docs": f"mint docs frontend {comp.replacement}",
                "migration_guide": "mint docs deprecated-apis",
            }
            for comp in DEPRECATED_FRONTEND_COMPONENTS
        ],
        *[
            {
                "name": comp.name,
                "replacement": comp.replacement,
                "docs": "mint docs frontend-api",
                "migration_guide": "mint docs deprecated-apis",
            }
            for comp in DEPRECATED_FRONTEND_COMPOSABLES
        ],
    ]
    doc = {
        "name": "frontend-component-chooser",
        "purpose": (
            "Pick the highest-level SDK component for a plugin task before "
            "falling back to lower-level building blocks."
        ),
        "command": "mint docs frontend choose",
        "paths": [
            {
                "task": "Generated analysis or settings workspace",
                "start": [
                    "DoseDesignWorkspaceView",
                    "ControlWorkspaceView",
                    "ComponentBindingRenderer",
                    "defineControlModel",
                    "defineDoseDesignControlModel",
                ],
                "preferred_import": (
                    "import { DoseDesignWorkspaceView, ControlWorkspaceView, ComponentBindingRenderer, "
                    "defineControlModel, defineDoseDesignControlModel } from '@morscherlab/mint-sdk'"
                ),
                "use_when": (
                    "A compact data model should generate AppTopBar, AppSidebar, and FormBuilder; "
                    "use DoseDesignWorkspaceView for standard WellPlate + DoseCalculator pages, "
                    "or defineDoseDesignControlModel with ControlWorkspaceView for custom dose layouts, "
                    "including WellPlate selection and DoseCalculator apply-to-wells syncing. "
                    "For custom slots, read componentBindingsById[id].props from the workspace "
                    "instead of hand-mapping SDK component props. "
                    "The generated sidebar uses the shared LEAF-style MINT analysis sidebar language. "
                    "If you only need side controls, pass the same defineControlModel() result "
                    "to AppSidebar :model."
                ),
                "prefer_over": [
                    "hand-wired ControlWorkspaceView slots for standard dose-design pages",
                    "hand-wired AppLayout + AppTopBar + FormBuilder pages",
                    "hand-wired AppLayout + AppSidebar + FormBuilder pages",
                    "hand-wired AppTopBar + AppSidebar + FormBuilder pages",
                    "manual WellPlate + DoseCalculator prop mapping",
                    "manual sidebar/form/component value synchronization",
                ],
                "drop_down_to": [
                    "defineControls",
                    "useControlWorkspace",
                    "defineControlComponentBindings",
                    "defineWellPlateDoseComponentBindings",
                    "controlValuesToComponentBindings",
                    "controlValuesToComponentBindingsById",
                    "ComponentBindingRenderer",
                    "getComponentProps",
                    "defineWellPlateDoseControlProps",
                    "controlValuesToComponentProps",
                    "AppTopBar",
                    "AppSidebar",
                    "FormBuilder",
                ],
            },
            {
                "task": "Biology template or ready-to-save design_data page",
                "start": [
                    "BioTemplatePresetWorkspaceView",
                    "BioTemplatePackWorkspaceView",
                ],
                "preferred_import": (
                    "import { BioTemplatePackWorkspaceView, BioTemplatePresetWorkspaceView, "
                    "useBioTemplatePackWorkspace, useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk'"
                ),
                "use_when": (
                    "WellPlate, DoseCalculator, PlateMapEditor, template presets, "
                    "or template packs should stay connected."
                ),
                "prefer_over": [
                    "separate template control forms plus manual component adapters",
                    "manual PlateMapEditor + WellPlate + SampleLegend wiring",
                    "manual DataFrame + SampleSelector + GroupAssigner sample-sheet pages",
                    "raw design_data.templates object plumbing",
                ],
                "drop_down_to": [
                    "useBioTemplatePresetWorkspace",
                    "useBioTemplatePackWorkspace",
                    "BioTemplateExperimentWorkspaceView",
                    "BioTemplateRenderer",
                    "getBioTemplateComponentProps",
                    "WellPlate",
                    "DoseCalculator",
                    "PlateMapEditor",
                ],
            },
            {
                "task": "Schema-driven form or settings modal",
                "start": ["FormBuilder", "SettingsModal", "defineControlModel"],
                "preferred_import": (
                    "import { FormBuilder, SettingsModal, defineControlModel } "
                    "from '@morscherlab/mint-sdk'"
                ),
                "use_when": (
                    "A form or settings modal can be described as one compact "
                    "control model with fields, sections, defaults, and validation."
                ),
                "prefer_over": [
                    "FormSection",
                    "FormFieldRenderer",
                    "manual FormField + NumberInput/DatePicker/BaseToggle rows",
                    "manual SettingsModal tabs for basic fields",
                    "raw field renderer loops",
                ],
                "drop_down_to": [
                    "defineControls",
                    "controlsToFormSchema",
                    "controlsToSettingsSchema",
                    "FormField",
                    "FormActions",
                    "BaseInput",
                    "NumberInput",
                    "DatePicker",
                ],
            },
            {
                "task": "Custom plugin chrome and route navigation",
                "start": ["PluginWorkspaceView", "useAppExperiment"],
                "preferred_import": (
                    "import { PluginWorkspaceView, useAppExperiment, useCurrentExperiment } "
                    "from '@morscherlab/mint-sdk'"
                ),
                "use_when": (
                    "Only when ControlWorkspaceView is not enough and the plugin needs "
                    "custom page chrome, metadata-backed page switching, responsive sidebars, "
                    "route-owned Teleport sidebars with pinned footers, or an AppTopBar "
                    "experiment chip with selector/save/detach wiring. "
                    "PluginWorkspaceView owns the common AppLayout + AppTopBar + AppSidebar shell "
                    "with the shared LEAF-style sidebar language. Use experimentShell for "
                    "the common experiment chip + selector/save flow, and use "
                    "sidebarContentId/showSidebarWhenEmpty when route or tab children own "
                    "the sidebar content. Drop to useAppExperiment only for custom topbar "
                    "composition before writing manual sync code."
                ),
                "prefer_over": [
                    "custom nav shells",
                    "manual AppLayout + AppTopBar + AppSidebar shell",
                    "manual AppTopBar + AppPageSelector composition",
                    "manual AppTopBar + AppPillNav composition",
                    "manual ExperimentPopover + ExperimentSelectorModal state wiring",
                    "legacy AppTopBar pages/tabs props",
                    "hand-coded page switch data outside PluginMetadata.nav_items",
                ],
                "drop_down_to": [
                    "AppLayout + AppTopBar + AppSidebar for unusual multi-sidebar chrome",
                    "AppLayout responsiveSidebar / v-model:sidebarOpen with AppSidebar variant=\"analysis\"",
                    "AppSidebar contentId / showWhenEmpty for non-workspace sidebar targets",
                    "getPluginPageSelectorItems(contract) for raw contract nav metadata",
                    "AppTopBar pillNav / current-pill-id props, with children for dropdown modes",
                    "AppTopBar pageSelector / current-page-selector-id props for custom page pickers",
                    "AppAvatarMenu",
                    "useCurrentExperiment for lower-level guards or non-topbar context",
                ],
            },
            {
                "task": "Feedback and status",
                "start": ["AppToastContainer", "AlertBox", "StatusIndicator"],
                "preferred_import": (
                    "import { AlertBox, AppToastContainer, StatusIndicator } from '@morscherlab/mint-sdk'"
                ),
                "use_when": "The UI needs async feedback, warnings, progress, or persistent state labels.",
                "prefer_over": ["ToastNotification", "ad hoc status banners"],
                "drop_down_to": ["ProgressBar", "LoadingSpinner", "Skeleton"],
            },
        ],
        "avoid_in_new_code": sorted(avoid_in_new_code, key=lambda item: item.get("name", "")),
        "notes": [
            "Prefer the first component in each path for new plugin code.",
            "Import public components and composables from @morscherlab/mint-sdk; "
            "keep @morscherlab/mint-sdk/templates for template helpers and "
            "@morscherlab/mint-sdk/styles for CSS.",
            "Use lower-level components only for custom layouts or field overrides.",
            'Treat AppSidebar variant="analysis" as the shared LEAF-style sidebar '
            "language for plugin workspaces; override it only for product-specific chrome.",
            "Put default overrides in controlOptions.initialValues so FormBuilder, "
            "AppSidebar, SettingsModal, and ControlWorkspaceView start from the same values.",
            "Bind ControlWorkspaceView with v-model when generated component props "
            "should update the same values object.",
            "For custom ControlWorkspaceView slots, prefer componentBindings or "
            "componentBindingsById[id].props when a control model should drive "
            "SDK components.",
            "Run mint docs frontend <name> for component, composable, or helper details.",
        ],
    }

    if as_json:
        return json.dumps(doc, indent=2, default=str)

    c = _supports_color()
    lines = [
        _bold("Frontend Component Chooser", c),
        _dim(doc["purpose"], c),
        "",
    ]

    for path in doc["paths"]:
        lines.append(_cyan(str(path["task"]), c))
        lines.append(f"  start: {_green(', '.join(path['start']), c)}")
        lines.append(f"  import: {_dim(str(path['preferred_import']), c)}")
        lines.append(f"  when: {_dim(str(path['use_when']), c)}")
        lines.append(f"  prefer over: {_dim(', '.join(path['prefer_over']), c)}")
        lines.append(f"  drop down: {_dim(', '.join(path['drop_down_to']), c)}")
        lines.append("")

    if doc["avoid_in_new_code"]:
        lines.append(_yellow("Avoid in new code", c))
        for item in doc["avoid_in_new_code"]:
            replacement = item.get("replacement")
            target = f" -> {replacement}" if replacement else ""
            docs = item.get("docs")
            docs_hint = f"  docs: {docs}" if docs else ""
            lines.append(f"  {_green(str(item.get('name', '')), c)}{_dim(target + docs_hint, c)}")
        lines.append("")

    lines.append(_cyan("Notes", c))
    for note in doc["notes"]:
        lines.append(f"  - {_dim(str(note), c)}")
    lines.append("")

    lines.append(_dim("Use: mint docs frontend <name> for full reference", c))
    lines.append(_dim("Tip: --json returns the same chooser as structured data.", c))
    return "\n".join(lines)


def format_component_group(
    data: dict[str, Any], group: str, *, as_json: bool = False
) -> str:
    """Render components in a single group with descriptions."""
    components = data.get("categories", {}).get("components", [])
    filtered = [comp for comp in components if comp.get("group") == group]

    if as_json:
        return json.dumps([_component_catalog_json_item(comp) for comp in filtered], indent=2, default=str)

    if not filtered:
        return f"No components in group '{group}'."

    canonical_components = [comp for comp in filtered if not comp.get("deprecated")]
    deprecated_components = [comp for comp in filtered if comp.get("deprecated")]

    c = _supports_color()
    lines = [
        _bold(f"{group.title()} Components", c)
        + _dim(
            f"  {len(canonical_components)} canonical components"
            + (
                f"  |  {len(deprecated_components)} deprecated entries"
                if deprecated_components
                else ""
            ),
            c,
        ),
        "",
    ]
    for comp in canonical_components:
        desc = _component_listing_description(comp)
        lines.append(f"  {_green(comp['name'], c):30s} {desc}")

    if deprecated_components:
        lines.append("")
        lines.append(_yellow("Deprecated entries", c) + _dim("  avoid in new code", c))
        for comp in deprecated_components:
            desc = _component_listing_description(comp)
            lines.append(f"  {_green(comp['name'], c):30s} {desc}")

    lines.append("")
    lines.append(_dim("Use: mint docs frontend <name> for full component reference", c))
    return "\n".join(lines)


def _component_listing_description(comp: dict[str, Any]) -> str:
    if comp.get("deprecated"):
        replacement = comp.get("replacement")
        return f"deprecated -> {replacement}" if replacement else "deprecated"

    desc = comp.get("description", "")
    if len(desc) > 60:
        desc = desc[:57] + "..."
    return desc


def _component_catalog_json_item(comp: dict[str, Any]) -> dict[str, Any]:
    """Return machine-friendly component catalog metadata without changing list shape."""
    name = str(comp.get("name", ""))
    deprecated = bool(comp.get("deprecated"))
    item = {
        **comp,
        "status": "compatibility" if deprecated else "canonical",
        "docs": f"mint docs frontend {name}" if name else "",
    }
    if deprecated:
        replacement = comp.get("replacement")
        item["migration_guide"] = "mint docs deprecated-apis"
        item["replacement_docs"] = f"mint docs frontend {replacement}" if replacement else ""
    return item


# ---------------------------------------------------------------------------
# Frontend: CSS reference
# ---------------------------------------------------------------------------


def format_css_overview(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render CSS category overview (variables, tailwind, utilities)."""
    css = data.get("categories", {}).get("css", {})
    if as_json:
        return json.dumps(
            {k: len(v) for k, v in css.items()},
            indent=2,
        )

    c = _supports_color()
    lines = [_bold("CSS Reference", c), ""]
    for section_name, section_data in css.items():
        count = len(section_data) if isinstance(section_data, list) else sum(
            len(v) for v in section_data.values()
        ) if isinstance(section_data, dict) else 0
        lines.append(f"  {_green(section_name, c):25s} {count:>3} items")

    lines.append("")
    lines.append(_dim("Use: mint docs frontend css <section>", c))
    return "\n".join(lines)


def format_css_section(
    data: dict[str, Any], section: str, *, as_json: bool = False
) -> str:
    """Render a specific CSS section (variables, tailwind, utilities)."""
    css = data.get("categories", {}).get("css", {})
    section_data = css.get(section)

    if section_data is None:
        available = ", ".join(css.keys())
        return f"Unknown CSS section '{section}'. Available: {available}"

    if as_json:
        return json.dumps(section_data, indent=2, default=str)

    c = _supports_color()
    lines = [_bold(f"CSS {section.title()}", c), ""]

    if isinstance(section_data, dict):
        # Grouped variables: {"Colors": [{"name": ..., "value": ...}], ...}
        for group_name, variables in section_data.items():
            lines.append(_cyan(group_name, c))
            if isinstance(variables, list):
                for var in variables:
                    name = var.get("name", "")
                    value = var.get("value", "")
                    lines.append(f"  {_green(name, c):35s} {_magenta(value, c)}")
            lines.append("")
    elif isinstance(section_data, list):
        for item in section_data:
            if isinstance(item, dict):
                name = item.get("name", "")
                value = item.get("value", item.get("description", ""))
                lines.append(f"  {_green(name, c):35s} {value}")
            else:
                lines.append(f"  {item}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Frontend: composable listing
# ---------------------------------------------------------------------------


def format_composables(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render composable listing."""
    composables = data.get("categories", {}).get("composables", [])
    if as_json:
        return json.dumps(composables, indent=2, default=str)

    c = _supports_color()
    lines = [
        _bold("Composables", c) + _dim(f"  {len(composables)} items", c),
        "",
    ]
    for comp in composables:
        desc = comp.get("description", "")
        if len(desc) > 55:
            desc = desc[:52] + "..."
        lines.append(f"  {_green(comp['name'], c):35s} {desc}")

    lines.append("")
    lines.append(_dim("Use: mint docs frontend <name> for full composable reference", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Search results
# ---------------------------------------------------------------------------


def format_search_results(
    results: list[dict[str, Any]], query: str, *, as_json: bool = False
) -> str:
    """Render search results."""
    if as_json:
        return json.dumps(results, indent=2, default=str)

    if not results:
        return f"No results for '{query}'."

    c = _supports_color()
    lines = [
        _bold(f"Search: {query}", c) + _dim(f"  {len(results)} results", c),
        "",
    ]
    for r in results:
        sdk = r.get("sdk", "")
        category = r.get("category", "")
        name = r.get("name", "")
        context = r.get("match_context", "")
        lines.append(
            f"  {_dim(sdk, c):12s} {_dim(category, c):20s} {_green(name, c):30s} {context}"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _format_method_signature(m: dict[str, Any]) -> str:
    """Format a method as `name(params) -> return_type`."""
    params = m.get("params", [])
    parts = []
    for p in params:
        s = p["name"]
        if "type" in p:
            s += f": {p['type']}"
        if "default" in p:
            s += f" = {p['default']}"
        parts.append(s)

    sig = f"{m['name']}({', '.join(parts)})"
    ret = m.get("return_type", "")
    if ret:
        sig += f" -> {ret}"
    if m.get("async"):
        sig = "async " + sig
    return sig


def _frontend_category_count(cat_name: str, cat_data: Any) -> int:
    """Count items in a frontend category (handles both lists and dicts)."""
    if isinstance(cat_data, list):
        return len(cat_data)
    if isinstance(cat_data, dict):
        return sum(
            len(v) if isinstance(v, list) else 1 for v in cat_data.values()
        )
    return 0


def _frontend_category_summary(cat_name: str, cat_data: Any) -> str:
    """Generate a brief summary for a frontend category."""
    if isinstance(cat_data, list) and cat_data:
        names = [item.get("name", "") for item in cat_data[:4]]
        suffix = "..." if len(cat_data) > 4 else ""
        return ", ".join(names) + suffix
    if isinstance(cat_data, dict):
        return ", ".join(list(cat_data.keys())[:4])
    return ""
