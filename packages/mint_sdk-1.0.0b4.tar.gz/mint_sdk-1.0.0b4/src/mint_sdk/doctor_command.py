"""Core logic for the ``mint doctor`` command.

Validates plugin project structure, entry points, SDK dependencies,
and source files without executing any plugin code.
"""

from __future__ import annotations

import ast
import json
import re
import sys
from collections.abc import Iterator
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS as _DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS as _DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS as _DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_EXPRESSION_PATTERNS as _DEPRECATED_FRONTEND_EXPRESSION_PATTERNS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_IMPORT_PATTERNS as _DEPRECATED_FRONTEND_IMPORT_PATTERNS,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_FRONTEND_TAG_RULES as _DEPRECATED_FRONTEND_TAG_RULES,
)
from mint_sdk.deprecated_apis import (
    DEPRECATED_TEXT_PATTERNS as _DEPRECATED_TEXT_PATTERNS,
)
from mint_sdk.info_command import _supports_color

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11 fallback
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass(slots=True)
class CheckResult:
    """Result of a single diagnostic check."""

    ok: bool
    label: str
    detail: str = ""
    explanation: str = ""
    fix_hint: str = ""
    fix_id: str | None = None


@dataclass(frozen=True, slots=True)
class DeprecatedApiHit:
    """Source location for a deprecated or abandoned SDK API pattern."""

    path: Path
    line_no: int
    marker: str
    replacement: str


_DEPRECATED_API_DETAIL_LIMIT = 16


@dataclass(frozen=True, slots=True)
class FrontendSdkApiHit:
    """Source location for an SDK frontend import missing from the current catalog."""

    path: Path
    line_no: int
    name: str
    source: str


@dataclass(frozen=True, slots=True)
class FrontendComponentGuidanceHit:
    """Non-blocking suggestion to use a higher-level canonical frontend entrypoint."""

    path: Path
    line_no: int
    marker: str
    recommendation: str


@dataclass(frozen=True, slots=True)
class PluginNavIconHit:
    """Source location for plugin page metadata missing a page icon."""

    path: Path
    line_no: int
    label: str
    nav_path: str


@dataclass(frozen=True, slots=True)
class PluginNavIdHit:
    """Source location for plugin page metadata missing a stable page id."""

    path: Path
    line_no: int
    label: str
    nav_path: str


@dataclass(frozen=True, slots=True)
class PluginMetadataIconHit:
    """Source location for plugin metadata missing the plugin-level icon."""

    path: Path
    line_no: int


@dataclass(frozen=True, slots=True)
class FrontendRouteMetadataGap:
    """Frontend route that is not represented in PluginMetadata.nav_items."""

    path: Path
    line_no: int
    route_path: str


_FRONTEND_SDK_API_DETAIL_LIMIT = 16
_FRONTEND_API_WIRING_DETAIL_LIMIT = 4
_FRONTEND_COMPONENT_GUIDANCE_DETAIL_LIMIT = 8
_PLUGIN_NAV_ICON_DETAIL_LIMIT = 12
_PLUGIN_NAV_ID_DETAIL_LIMIT = 12
_PLUGIN_METADATA_ICON_DETAIL_LIMIT = 8
_PLUGIN_NAV_COVERAGE_DETAIL_LIMIT = 8
_FRONTEND_SDK_IMPORT_RE = re.compile(
    r"import\s+(?P<clause>(?:(?!\n\s*import\b)[\s\S])*?)\s+from\s+"
    r"['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_EXPORT_RE = re.compile(
    r"export\s+(?P<clause>(?:(?!\n\s*(?:import|export)\b)[\s\S])*?)\s+from\s+"
    r"['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_SUBPATH_RE = re.compile(
    r"import\s+(?P<clause>(?:(?!\n\s*import\b)[\s\S])*?)\s+from\s+['\"]"
    r"(?P<source>@morscherlab/mint-sdk/(?P<kind>components|composables)/"
    r"(?P<name>[A-Za-z][\w-]*)(?:\.(?:vue|ts))?)['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_SUBPATH_EXPORT_RE = re.compile(
    r"export\s+(?P<clause>(?:(?!\n\s*(?:import|export)\b)[\s\S])*?)\s+from\s+['\"]"
    r"(?P<source>@morscherlab/mint-sdk/(?P<kind>components|composables)/"
    r"(?P<name>[A-Za-z][\w-]*)(?:\.(?:vue|ts))?)['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_ANY_SUBPATH_RE = re.compile(
    r"import\s+(?P<clause>(?:(?!\n\s*import\b)[\s\S])*?)\s+from\s+['\"]"
    r"(?P<source>@morscherlab/mint-sdk/(?P<subpath>[^'\"]+))['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_ANY_SUBPATH_EXPORT_RE = re.compile(
    r"export\s+(?P<clause>(?:(?!\n\s*(?:import|export)\b)[\s\S])*?)\s+from\s+['\"]"
    r"(?P<source>@morscherlab/mint-sdk/(?P<subpath>[^'\"]+))['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_SIDE_EFFECT_SUBPATH_RE = re.compile(
    r"import\s+['\"](?P<source>@morscherlab/mint-sdk/(?P<subpath>[^'\"]+))['\"]",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_SUBPATH_RE = re.compile(
    r"\bimport\(\s*['\"](?P<source>@morscherlab/mint-sdk/(?P<subpath>[^'\"]+))['\"]\s*\)",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_IMPORT_ASSIGN_RE = re.compile(
    r"\b(?:const|let|var)\s+(?P<alias>[A-Za-z_$][\w$]*)\s*=\s*(?:await\s*)?"
    r"import\(\s*['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]\s*\)",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_IMPORT_DESTRUCTURE_RE = re.compile(
    r"\b(?:const|let|var)\s*\{(?P<body>[^}]*)\}\s*=\s*(?:await\s*)?"
    r"import\(\s*['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]\s*\)",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_IMPORT_MEMBER_RE = re.compile(
    r"(?:\(\s*(?:await\s*)?import\(\s*"
    r"['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]"
    r"\s*\)\s*\)|\bimport\(\s*"
    r"['\"](?P<bare_source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]"
    r"\s*\))\s*\.\s*(?P<name>[A-Za-z]\w*)\b",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_IMPORT_THEN_MEMBER_RE = re.compile(
    r"\bimport\(\s*"
    r"['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]"
    r"\s*\)\s*\.then\(\s*(?:async\s*)?(?P<alias>[A-Za-z_$][\w$]*)\s*=>"
    r"(?P<body>[\s\S]{0,500}?)\)",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_DYNAMIC_IMPORT_THEN_DESTRUCTURE_RE = re.compile(
    r"\bimport\(\s*"
    r"['\"](?P<source>@morscherlab/mint-sdk(?:/(?:components|composables|templates))?)['\"]"
    r"\s*\)\s*\.then\(\s*(?:async\s*)?\(\s*\{(?P<body>[^}]*)\}\s*\)\s*=>",
    flags=re.MULTILINE,
)
_FRONTEND_TAG_NAMED_V_BIND_RE = re.compile(r"\bv-bind\s*=\s*['\"](?P<name>[A-Za-z_$][\w$]*)['\"]")
_FRONTEND_TAG_ATTR_VALUE_RE = re.compile(
    r"(?P<name>\s(?:v-bind|v-bind:[A-Za-z_$][\w$:-]*|[:@#]?[A-Za-z_$][\w$:-]*))"
    r"\s*=\s*(?P<quote>['\"])(?P<value>[\s\S]*?)(?P=quote)",
    flags=re.MULTILINE,
)
_FRONTEND_USE_CONTROL_WORKSPACE_SPLIT_MODEL_RE = re.compile(
    r"\buseControlWorkspace\s*\(\s*"
    r"(?P<model>[A-Za-z_$][\w$]*)\s*\.\s*controls\s*,\s*"
    r"(?P=model)\s*\.\s*controlOptions\s*\)",
    flags=re.MULTILINE,
)
_FRONTEND_MANUAL_SIDEBAR_OPEN_STATE_RE = re.compile(
    r"\b(?:mobileSidebarOpen|sidebarOpen)\b",
    flags=re.MULTILINE,
)
_FRONTEND_MANUAL_ASIDE_RE = re.compile(r"<aside\b", flags=re.IGNORECASE)
_FRONTEND_SIDEBAR_SLOT_RE = re.compile(
    r"<template\s+#sidebar\b[\s\S]*?</template>",
    flags=re.IGNORECASE | re.MULTILINE,
)
_FRONTEND_SIDEBAR_TARGET_ID_RE = re.compile(
    r"\bid\s*=\s*['\"][^'\"]*sidebar[^'\"]*['\"]",
    flags=re.IGNORECASE,
)
_FRONTEND_APP_SIDEBAR_TAG_RE = re.compile(
    r"<(?:AppSidebar|app-sidebar)\b(?P<body>[\s\S]*?)(?:/?>)",
    flags=re.MULTILINE,
)
_FRONTEND_PLUGIN_WORKSPACE_TAG_RE = re.compile(
    r"<(?:PluginWorkspaceView|plugin-workspace-view)\b(?P<body>[\s\S]*?)(?:/?>)",
    flags=re.MULTILINE,
)
_FRONTEND_CONTROL_WORKSPACE_WORKSPACE_BIND_RE = re.compile(
    r"<(?:ControlWorkspaceView|control-workspace-view)\b[\s\S]*?"
    r"(?:(?:v-bind:|:)workspace\s*=|v-bind\s*=\s*['\"][A-Za-z_$][\w$]*['\"])",
    flags=re.MULTILINE,
)
_FRONTEND_SDK_NAMESPACE_RE = re.compile(r"^\*\s+as\s+(\w+)$")
_FRONTEND_TYPE_LIKE_SUFFIX_RE = re.compile(
    r"(?:Options|Return|State|Type|Result|Definition|Contract|Context|Config|Props|Item|"
    r"Event|Slot|Value|Unit|Format|Mode|Size|Variant|Status|Info|Column|Row|Data|Map|"
    r"Entry|Preset|Schema|Palette|Binding|Source|Target)$"
)
_FRONTEND_ROOT_IMPORT_ALLOWLIST = {"MINTSdk", "default"}
_FRONTEND_DYNAMIC_IMPORT_PROMISE_MEMBERS = {"then", "catch", "finally"}
_FRONTEND_PUBLIC_BARE_SUBPATHS = {
    "components",
    "composables",
    "install",
    "stores",
    "styles",
    "tailwind.preset",
    "templates",
    "types",
}
_FRONTEND_DEPRECATED_PROP_SHORTHAND_KEYS = (
    "items",
    "activeId",
    "floating",
    "sticky",
    "pages",
    "currentPageId",
    "tabs",
    "currentTabId",
)
_FRONTEND_COMPONENT_GUIDANCE_RULES: tuple[tuple[tuple[str, ...], tuple[str, ...], str, str], ...] = (
    (
        ("AppLayout", "AppTopBar", "AppSidebar"),
        ("PluginWorkspaceView", "ControlWorkspaceView"),
        "manual AppLayout + AppTopBar + AppSidebar shell",
        "PluginWorkspaceView",
    ),
    (
        ("AppLayout", "AppTopBar", "FormBuilder"),
        ("ControlWorkspaceView",),
        "manual AppLayout + AppTopBar + FormBuilder page",
        "ControlWorkspaceView + defineControlModel",
    ),
    (
        ("AppLayout", "AppSidebar", "FormBuilder"),
        ("ControlWorkspaceView",),
        "manual AppLayout + AppSidebar + FormBuilder page",
        "ControlWorkspaceView + defineControlModel",
    ),
    (
        ("AppTopBar", "AppSidebar", "FormBuilder"),
        ("ControlWorkspaceView",),
        "manual AppTopBar + AppSidebar + FormBuilder workspace",
        "ControlWorkspaceView + defineControlModel",
    ),
    (
        ("AppTopBar", "AppPageSelector"),
        ("ControlWorkspaceView",),
        "manual AppTopBar + AppPageSelector page switcher",
        "AppTopBar pageSelector + pluginPageSelectorItems",
    ),
    (
        ("AppTopBar", "AppPillNav"),
        ("ControlWorkspaceView",),
        "manual AppTopBar + AppPillNav mode switcher",
        "AppTopBar pillNav / current-pill-id props",
    ),
    (
        ("ExperimentPopover", "ExperimentSelectorModal"),
        ("PluginWorkspaceView", "useAppExperiment"),
        "manual ExperimentPopover + ExperimentSelectorModal state wiring",
        "PluginWorkspaceView experiment-shell or useAppExperiment for AppTopBar experiment shell wiring",
    ),
    (
        ("ControlWorkspaceView", "WellPlate", "DoseCalculator", "defineDoseDesignControlModel"),
        (
            "DoseDesignWorkspaceView",
            "BioTemplatePresetWorkspaceView",
            "BioTemplatePackWorkspaceView",
            "BioTemplateExperimentWorkspaceView",
            "useBioTemplatePresetWorkspace",
            "useBioTemplatePackWorkspace",
            "useBioTemplateWorkspace",
        ),
        "hand-wired ControlWorkspaceView dose-design slots",
        "DoseDesignWorkspaceView for standard WellPlate + DoseCalculator pages",
    ),
    (
        ("WellPlate", "DoseCalculator"),
        (
            "DoseDesignWorkspaceView",
            "defineDoseDesignControlModel",
            "BioTemplatePresetWorkspaceView",
            "BioTemplatePackWorkspaceView",
            "BioTemplateExperimentWorkspaceView",
            "useBioTemplatePresetWorkspace",
            "useBioTemplatePackWorkspace",
            "useBioTemplateWorkspace",
        ),
        "manual WellPlate + DoseCalculator dose design",
        "DoseDesignWorkspaceView or BioTemplatePresetWorkspaceView",
    ),
    (
        ("PlateMapEditor", "WellPlate", "SampleLegend"),
        (
            "BioTemplatePresetWorkspaceView",
            "BioTemplatePackWorkspaceView",
            "BioTemplateExperimentWorkspaceView",
            "useBioTemplatePresetWorkspace",
            "useBioTemplatePackWorkspace",
            "useBioTemplateWorkspace",
        ),
        "manual PlateMapEditor + WellPlate + SampleLegend plate map",
        "BioTemplatePresetWorkspaceView or useBioTemplatePresetWorkspace",
    ),
    (
        ("DataFrame", "SampleSelector", "GroupAssigner"),
        (
            "BioTemplateExperimentWorkspaceView",
            "BioTemplatePresetWorkspaceView",
            "BioTemplatePackWorkspaceView",
            "useBioTemplateWorkspace",
            "useBioTemplatePresetWorkspace",
            "useBioTemplatePackWorkspace",
            "useTemplateCollection",
        ),
        "manual DataFrame + SampleSelector + GroupAssigner sample sheet",
        "BioTemplateExperimentWorkspaceView or useBioTemplateWorkspace",
    ),
    (
        ("FormField", "BaseInput", "BaseSelect"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "BaseInput"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "BaseSelect"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "BaseTextarea"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "NumberInput"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "DatePicker"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "BaseCheckbox"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("FormField", "BaseToggle"),
        ("FormBuilder", "SettingsModal", "defineControls", "defineControlModel", "ControlWorkspaceView"),
        "manual FormField + base input form",
        "FormBuilder + defineControlModel",
    ),
    (
        ("SettingsModal", "FormField", "BaseInput"),
        ("defineControlModel", "controlsToSettingsSchema", "schema", "controls"),
        "manual SettingsModal tabs with base form fields",
        "SettingsModal :model + defineControlModel",
    ),
    (
        ("SettingsModal", "FormField", "BaseSelect"),
        ("defineControlModel", "controlsToSettingsSchema", "schema", "controls"),
        "manual SettingsModal tabs with base form fields",
        "SettingsModal :model + defineControlModel",
    ),
    (
        ("SettingsModal", "FormField", "NumberInput"),
        ("defineControlModel", "controlsToSettingsSchema", "schema", "controls"),
        "manual SettingsModal tabs with base form fields",
        "SettingsModal :model + defineControlModel",
    ),
    (
        ("SettingsModal", "FormField", "BaseToggle"),
        ("defineControlModel", "controlsToSettingsSchema", "schema", "controls"),
        "manual SettingsModal tabs with base form fields",
        "SettingsModal :model + defineControlModel",
    ),
)
_DEPRECATED_PYTHON_IMPORT_REPLACEMENTS = {
    "PluginExperimentData": "DesignData",
}
_DEPRECATED_PYTHON_MEMBER_REPLACEMENTS = {
    "local_db": ("AnalysisPlugin.local_db", "AnalysisPlugin.standalone_db"),
    "get_local_models": ("AnalysisPlugin.get_local_models()", "AnalysisPlugin.get_shared_models()"),
    "_setup_local_database": (
        "AnalysisPlugin._setup_local_database()",
        "AnalysisPlugin._setup_standalone_db()",
    ),
    "_teardown_local_database": (
        "AnalysisPlugin._teardown_local_database()",
        "AnalysisPlugin._teardown_standalone_db()",
    ),
}
_DEPRECATED_PYTHON_OVERRIDE_REPLACEMENTS = {
    "get_local_models": ("AnalysisPlugin.get_local_models() override", "AnalysisPlugin.get_shared_models()"),
}
_DEPRECATED_PYTHON_IMPORT_MODULES = {"mint_sdk", "mint_sdk.repositories"}


def _check_pyproject(project_dir: Path) -> tuple[CheckResult, dict | None]:
    """Check that pyproject.toml exists and has a [project] table."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        return CheckResult(
            False,
            "pyproject.toml",
            "not found",
            "Plugin metadata, dependencies, and entry points are read from pyproject.toml.",
            "Run `mint init` or create a pyproject.toml with a [project] table.",
        ), None

    try:
        data = tomllib.loads(path.read_text())
    except Exception as exc:
        return CheckResult(
            False,
            "pyproject.toml",
            f"parse error: {exc}",
            "The SDK cannot inspect or package a plugin when pyproject.toml is invalid.",
            "Fix the TOML syntax error.",
        ), None

    if "project" not in data:
        return CheckResult(
            False,
            "pyproject.toml",
            "missing [project] table",
            "The [project] table declares the package name, dependencies, and entry points.",
            "Add a [project] table or re-run `mint init`.",
        ), None

    name = data["project"].get("name", "")
    return CheckResult(True, "pyproject.toml", name), data


def _check_entry_point(data: dict | None) -> tuple[CheckResult, str | None, str | None, str | None]:
    """Check that a mint.plugins entry point is defined with correct format."""
    if data is None:
        return CheckResult(False, "Entry point", "skipped (no pyproject.toml)"), None, None, None

    eps = data.get("project", {}).get("entry-points", {}).get("mint.plugins", {})
    if not eps:
        return (
            CheckResult(False, "Entry point", 'no [project.entry-points."mint.plugins"] section'),
            None,
            None,
            None,
        )

    if len(eps) > 1:
        names = ", ".join(eps.keys())
        return (
            CheckResult(
                False,
                "Entry point",
                f"multiple entry points found: {names} (expected exactly one)",
                "The current CLI assumes one plugin class per package.",
                "Keep one mint.plugins entry point per plugin package.",
            ),
            None,
            None,
            None,
        )

    ep_name, ep_value = next(iter(eps.items()))

    # Validate format: "module.path:ClassName"
    if ":" not in ep_value:
        return (
            CheckResult(
                False,
                "Entry point",
                f'"{ep_value}" missing colon - expected "module.path:ClassName"',
                "Entry points tell MINT which Python class to load without importing the package blindly.",
                'Use the form: test = "mint_plugin_test.plugin:TestPlugin".',
            ),
            None,
            None,
            None,
        )

    module_path, class_name = ep_value.rsplit(":", 1)
    return (
        CheckResult(True, "Entry point", f'{ep_name} = "{ep_value}"'),
        ep_name,
        module_path,
        class_name,
    )


def _check_source_module(project_dir: Path, module_path: str | None) -> tuple[CheckResult, Path | None]:
    """Check that the source module file exists."""
    if module_path is None:
        return CheckResult(False, "Source module", "skipped (no entry point)"), None

    # Convert module.path to file path: a.b.c -> src/a/b/c.py
    parts = module_path.split(".")
    candidates = [
        project_dir / "src" / "/".join(parts[:-1]) / f"{parts[-1]}.py",
        project_dir / "/".join(parts[:-1]) / f"{parts[-1]}.py",
    ]

    for candidate in candidates:
        if candidate.exists():
            rel = candidate.relative_to(project_dir)
            return CheckResult(True, "Source module", str(rel)), candidate

    expected = " or ".join(str(c.relative_to(project_dir)) for c in candidates)
    return CheckResult(
        False,
        "Source module",
        f"not found at {expected}",
        "The entry point must resolve to a Python source file in the plugin package.",
        "Move the plugin class to the expected module or update the entry point.",
    ), None


def _check_plugin_class(
    source_file: Path | None,
    class_name: str | None,
    source_content: str | None = None,
) -> tuple[CheckResult, str | None]:
    """Check that the plugin class exists. Returns (result, source_content) for reuse."""
    if source_file is None or class_name is None:
        return CheckResult(False, "Plugin class", "skipped (no source module)"), None

    if source_content is None:
        source_content = source_file.read_text()
    pattern = rf"class\s+{re.escape(class_name)}\s*\("
    if re.search(pattern, source_content):
        inherit_pattern = rf"class\s+{re.escape(class_name)}\s*\([^)]*AnalysisPlugin[^)]*\)"
        if re.search(inherit_pattern, source_content):
            return CheckResult(True, "Plugin class", f"{class_name}(AnalysisPlugin)"), source_content
        return CheckResult(
            True,
            "Plugin class",
            f"{class_name} (warning: does not inherit AnalysisPlugin)",
        ), source_content

    return CheckResult(
        False,
        "Plugin class",
        f"class {class_name} not found in source",
        "The entry point class is the plugin object MINT will instantiate.",
        "Rename the class or update the entry point.",
    ), source_content


def _check_routes_prefix(
    source_file: Path | None,
    ep_name: str | None,
    source_content: str | None = None,
) -> CheckResult:
    """Check that a routes prefix is defined or derivable."""
    prefix = None

    if source_file is not None:
        if source_content is None:
            source_content = source_file.read_text()
        match = re.search(r'routes_prefix\s*[=:]\s*["\'](/[^"\']+)["\']', source_content)
        if match:
            prefix = match.group(1)

    if prefix is None and ep_name is not None:
        prefix = f"/{ep_name}"

    if prefix:
        return CheckResult(True, "Routes prefix", prefix)
    return CheckResult(
        False,
        "Routes prefix",
        "could not determine routes prefix",
        "The routes prefix controls where the plugin API and frontend are mounted.",
        'Define PLUGIN_ROUTES_PREFIX = "/your-plugin" in plugin.py.',
    )


def _check_sdk_python(data: dict | None) -> CheckResult:
    """Check that mint-sdk is listed as a Python dependency."""
    if data is None:
        return CheckResult(False, "Python SDK dep", "skipped (no pyproject.toml)")

    deps = data.get("project", {}).get("dependencies", [])
    for dep in deps:
        if dep.strip().startswith("mint-sdk"):
            return CheckResult(True, "Python SDK dep", dep.strip())

    return CheckResult(
        False,
        "Python SDK dep",
        "mint-sdk not in [project.dependencies]",
        explanation="Plugin packages need mint-sdk at runtime for the plugin base classes and CLI helpers.",
        fix_hint="Add `mint-sdk>=1.0.0a8` to [project.dependencies].",
        fix_id="python-sdk-dep",
    )


def _check_sdk_frontend(project_dir: Path) -> CheckResult:
    """Check frontend SDK dependency if frontend exists."""
    pkg_json = project_dir / "frontend" / "package.json"
    if not pkg_json.exists():
        return CheckResult(True, "Frontend SDK dep", "no frontend (ok)")

    try:
        pkg = json.loads(pkg_json.read_text())
    except Exception as exc:
        return CheckResult(False, "Frontend SDK dep", f"package.json parse error: {exc}")

    deps = pkg.get("dependencies", {})
    version = deps.get("@morscherlab/mint-sdk")
    if version:
        return CheckResult(True, "Frontend SDK dep", f"@morscherlab/mint-sdk {version}")

    return CheckResult(
        False,
        "Frontend SDK dep",
        "@morscherlab/mint-sdk not in dependencies",
        explanation="Frontend plugins should consume SDK components, composables, and styles from the package.",
        fix_hint="Add @morscherlab/mint-sdk to frontend/package.json dependencies.",
        fix_id="frontend-sdk-dep",
    )


def _check_tests(project_dir: Path) -> CheckResult:
    """Check that a tests directory exists with test files."""
    tests_dir = project_dir / "tests"
    if not tests_dir.exists():
        return CheckResult(
            False,
            "Tests",
            "tests/ directory not found",
            explanation="At least a smoke test catches broken imports, routers, and packaging early.",
            fix_hint="Create tests/test_plugin.py.",
            fix_id="tests",
        )

    test_files = list(tests_dir.glob("test_*.py"))
    if not test_files:
        return CheckResult(
            False,
            "Tests",
            "tests/ exists but no test_*.py files",
            explanation="Pytest discovers test_*.py files by default.",
            fix_hint="Create tests/test_plugin.py.",
            fix_id="tests",
        )

    return CheckResult(True, "Tests", f"{len(test_files)} test file(s)")


_AI_FILES = ["CLAUDE.md", "AGENTS.md", ".cursorrules", ".windsurfrules"]
_AI_REQUIRED_MARKERS = [
    "mint docs frontend consolidate",
    "mint docs deprecated-apis",
    "mint docs contract .",
    "useGeneratedPluginContract",
    "PluginWorkspaceView",
    "ComponentBindingRenderer",
    "componentBindingsById",
    'AppSidebar variant="analysis"',
    "show-sidebar-when-empty",
    "useBioTemplatePresetWorkspace",
]
_AI_DISCOVERY_BLOCK = """\

---

## MINT SDK Discovery

Before writing custom frontend code, inspect the SDK and generated plugin
contract first:

```bash
mint docs frontend choose
mint docs frontend consolidate
mint docs deprecated-apis
mint docs frontend components
mint docs search "<concept>"
mint docs contract .
mint docs frontend PluginWorkspaceView
mint docs frontend ControlWorkspaceView
mint docs frontend ComponentBindingRenderer
mint docs frontend BioTemplatePresetWorkspaceView
mint docs frontend useBioTemplatePresetWorkspace
mint docs r-bridge
```

Prefer generated `useGeneratedPluginClient()` /
`useGeneratedPluginContract()` helpers over hand-written API prefixes. For
biology design_data pages, start with `BioTemplatePresetWorkspaceView` or
`useBioTemplatePresetWorkspace()` and bind generated components through
`componentBindingsById[id].props` or `ComponentBindingRenderer`; drop to
`useTemplateCollection()` only when you need custom template wiring. For custom
plugin pages that need topbar navigation plus a sidebar, start with
`PluginWorkspaceView` before hand-wiring AppLayout/AppTopBar/AppSidebar. For
custom analysis sidebars, use `AppSidebar variant="analysis"` before restating
width, static positioning, and collapse chrome by hand. For route-owned or
Teleport-driven sidebar content,
use `PluginWorkspaceView sidebar-content-id="..." show-sidebar-when-empty` plus
the `footer` slot for pinned actions; drop to `AppSidebar content-id` only
inside custom shells. Use `mint docs frontend consolidate` and
`mint docs deprecated-apis` before composing low-level components or reusing
older SDK snippets.
"""

_FRONTEND_SOURCE_SUFFIXES = {".js", ".jsx", ".ts", ".tsx", ".vue"}
_FRONTEND_SOURCE_EXCLUDED_DIRS = {
    ".vite",
    "build",
    "coverage",
    "dist",
    "generated",
    "node_modules",
}
_FRONTEND_API_LEGACY_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("VITE_API_PREFIX", re.compile(r"\bVITE_API_PREFIX\b")),
    (
        "useApi({ baseUrl })",
        re.compile(r"\buseApi\s*\(\s*\{(?:(?!\}\s*\)).)*\bbaseUrl\b", flags=re.DOTALL),
    ),
    ("useApi('/api/...')", re.compile(r"\buseApi\s*\(\s*[`'\"]\/api(?:\/|\b)")),
    ("fetch('/api/...')", re.compile(r"\bfetch\s*\(\s*[`'\"]\/api(?:\/|\b)")),
    ("axios('/api/...')", re.compile(r"\baxios(?:\.\w+)?\s*\(\s*[`'\"]\/api(?:\/|\b)")),
    (
        "client.get('/api/...')",
        re.compile(
            r"\b(?!axios\b)[A-Za-z_$][\w$]*\s*\.\s*"
            r"(?:get|post|put|patch|delete)\s*\(\s*[`'\"]\/api(?:\/|\b)"
        ),
    ),
)
_FRONTEND_ROUTE_PATH_RE = re.compile(r"\bpath\s*:\s*['\"](?P<path>/[^'\"]*)['\"]")
_FRONTEND_ROUTE_FILES = (
    Path("frontend/src/main.ts"),
    Path("frontend/src/main.js"),
    Path("frontend/src/router.ts"),
    Path("frontend/src/router.js"),
    Path("frontend/src/router/index.ts"),
    Path("frontend/src/router/index.js"),
)
_PYTHON_SOURCE_EXCLUDED_DIRS = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
}
_DEPRECATED_TEXT_ROOT_FILES = {
    "AGENTS.md",
    "CLAUDE.md",
    "README.md",
    ".github/copilot-instructions.md",
    ".cursorrules",
    ".windsurfrules",
}
_DEPRECATED_TEXT_DOC_SUFFIXES = {".md", ".mdc", ".mdx", ".rst", ".txt"}
_DEPRECATED_TEXT_DOC_DIRS = {"docs", "documentation", ".cursor/rules"}
def _check_ai_instructions(project_dir: Path) -> CheckResult:
    """Check that an AI instructions file exists."""
    for name in _AI_FILES:
        path = project_dir / name
        if path.exists():
            content = path.read_text(errors="ignore")
            missing = [marker for marker in _AI_REQUIRED_MARKERS if marker not in content]
            if not missing:
                return CheckResult(True, "AI instructions", f"{name} found")
            return CheckResult(
                False,
                "AI instructions",
                f"{name} found but missing current SDK guidance: {', '.join(missing)}",
                explanation=(
                    "Older agent instructions often miss contract-first clients, "
                    "template collection helpers, and current discovery commands."
                ),
                fix_hint="Run `mint doctor --fix` to append the current SDK discovery block.",
                fix_id="ai-instructions",
            )
    return CheckResult(
        False,
        "AI instructions",
        "not found (run mint init to generate CLAUDE.md / AGENTS.md / .cursorrules)",
        explanation="Generated instructions keep AI agents aligned with MINT SDK conventions.",
        fix_hint="Create AGENTS.md or re-run `mint init` in a fresh plugin.",
        fix_id="ai-instructions",
    )


def _check_generated_contract(project_dir: Path) -> CheckResult:
    """Check generated frontend plugin contract files when a frontend exists."""
    if not (project_dir / "frontend" / "package.json").exists():
        return CheckResult(True, "Generated contract", "no frontend (ok)")

    try:
        from mint_sdk.contract import ContractGenerationError, check_contract_files

        result = check_contract_files(project_dir)
    except ContractGenerationError as exc:
        return CheckResult(
            False,
            "Generated contract",
            f"could not generate: {exc}",
            "Frontend contract checks import the plugin class and inspect routers without calling initialize().",
            "Fix the import error, then run `mint sdk generate`.",
        )
    except SystemExit:
        return CheckResult(
            False,
            "Generated contract",
            "skipped (plugin discovery failed)",
            "The generated frontend client depends on a valid mint.plugins entry point.",
            "Fix pyproject.toml and the plugin entry point first.",
        )

    return CheckResult(
        result.ok,
        "Generated contract",
        result.detail,
        result.explanation,
        result.fix_hint,
        fix_id="generated-contract" if not result.ok else None,
    )


def _iter_frontend_source_files(project_dir: Path) -> Iterator[Path]:
    """Yield plugin frontend source files that are safe to scan."""
    src_dir = project_dir / "frontend" / "src"
    if not src_dir.exists():
        return

    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix not in _FRONTEND_SOURCE_SUFFIXES:
            continue
        relative_parts = path.relative_to(src_dir).parts
        if any(part in _FRONTEND_SOURCE_EXCLUDED_DIRS for part in relative_parts[:-1]):
            continue
        yield path


def _iter_python_source_files(project_dir: Path) -> Iterator[Path]:
    """Yield plugin Python source files that are safe to scan."""
    src_dir = project_dir / "src"
    if not src_dir.exists():
        return

    for path in src_dir.rglob("*.py"):
        if not path.is_file():
            continue
        relative_parts = path.relative_to(src_dir).parts
        if any(part in _PYTHON_SOURCE_EXCLUDED_DIRS for part in relative_parts[:-1]):
            continue
        yield path


def _check_frontend_api_wiring(project_dir: Path) -> CheckResult:
    """Check that plugin frontends avoid legacy hand-written API prefixes."""
    if not (project_dir / "frontend" / "package.json").exists():
        return CheckResult(True, "Frontend API wiring", "no frontend (ok)")

    hits: list[tuple[Path, int, str]] = []
    for source_file in _iter_frontend_source_files(project_dir):
        try:
            content = source_file.read_text(errors="ignore")
        except OSError:
            continue

        for marker, pattern in _FRONTEND_API_LEGACY_PATTERNS:
            for match in pattern.finditer(content):
                hits.append(
                    (
                        source_file.relative_to(project_dir),
                        _line_no_at(content, match.start()),
                        marker,
                    )
                )

    hits.sort(key=lambda hit: (hit[0].as_posix(), hit[1], hit[2]))

    if not hits:
        return CheckResult(True, "Frontend API wiring", "contract-first patterns")

    shown = [
        f"{path.as_posix()}:{line_no} ({marker})"
        for path, line_no, marker in hits[:_FRONTEND_API_WIRING_DETAIL_LIMIT]
    ]
    remaining = len(hits) - len(shown)
    detail = "legacy API prefix wiring in " + ", ".join(shown)
    if remaining:
        detail += f" and {remaining} more"

    return CheckResult(
        False,
        "Frontend API wiring",
        detail,
        explanation=(
            "Hand-written frontend API prefixes drift from backend routes and "
            "bypass generated contract metadata."
        ),
        fix_hint=(
            "Run `mint docs frontend-api`, then `mint sdk generate` and "
            "`mint docs contract .`; replace `VITE_API_PREFIX` / "
            "`useApi({ baseUrl })` / raw `/api/...` calls with generated "
            "`useGeneratedPluginClient()` calls."
        ),
    )


def _check_deprecated_api_usage(project_dir: Path) -> CheckResult:
    """Check that plugin code does not call abandoned or deprecated SDK APIs."""
    hits: list[DeprecatedApiHit] = []

    for path in _deprecated_api_text_scan_files(project_dir):
        _collect_deprecated_text_hits(project_dir, path, hits)

    for path in _iter_deprecated_project_text_files(project_dir):
        _collect_deprecated_frontend_doc_text_hits(project_dir, path, hits)

    for path in _iter_python_source_files(project_dir):
        _collect_deprecated_python_api_hits(project_dir, path, hits)

    for path in _iter_frontend_source_files(project_dir):
        try:
            content = path.read_text(errors="ignore")
        except OSError:
            continue
        rel_path = path.relative_to(project_dir)
        _collect_deprecated_frontend_import_hits(rel_path, content, hits)
        _collect_deprecated_frontend_tag_hits(rel_path, content, hits)
        _collect_deprecated_frontend_expression_hits(rel_path, content, hits)
        _collect_deprecated_frontend_destructure_hits(rel_path, content, hits)
        _collect_deprecated_frontend_dynamic_component_hits(rel_path, content, hits)

    if not hits:
        return CheckResult(True, "Deprecated SDK APIs", "none found")

    unique_hits: list[DeprecatedApiHit] = []
    seen_hits: set[tuple[Path, str, str]] = set()
    for hit in hits:
        key = (hit.path, hit.marker, hit.replacement)
        if key in seen_hits:
            continue
        seen_hits.add(key)
        unique_hits.append(hit)

    shown = [
        f"{hit.path.as_posix()}:{hit.line_no} ({hit.marker} -> {hit.replacement})"
        for hit in unique_hits[:_DEPRECATED_API_DETAIL_LIMIT]
    ]
    remaining = len(unique_hits) - len(shown)
    detail = "deprecated SDK API usage in " + ", ".join(shown)
    if remaining:
        detail += f" and {remaining} more"

    return CheckResult(
        False,
        "Deprecated SDK APIs",
        detail,
        explanation=(
            "Deprecated SDK APIs are kept only as compatibility shims or have "
            "already been replaced by the contract-first and current component APIs."
        ),
        fix_hint=(
            "Replace the listed APIs with their suggested replacements. Use "
            "`mint docs deprecated-apis`, `mint docs frontend choose`, "
            "`mint docs frontend <name>`, or `mint docs frontend-api` for "
            "migration examples."
        ),
    )


def _check_frontend_sdk_api_catalog(project_dir: Path) -> CheckResult:
    """Check that SDK frontend imports refer to current documented API names."""
    if not (project_dir / "frontend" / "package.json").exists():
        return CheckResult(True, "Frontend SDK API catalog", "no frontend (ok)")

    catalog = _load_frontend_sdk_api_catalog()
    if not catalog["components"] and not catalog["composables"] and not catalog["templates"]:
        return CheckResult(True, "Frontend SDK API catalog", "catalog unavailable (skipped)")

    hits: list[FrontendSdkApiHit] = []
    for path in _iter_frontend_source_files(project_dir):
        try:
            content = path.read_text(errors="ignore")
        except OSError:
            continue
        _collect_frontend_sdk_api_catalog_hits(
            path.relative_to(project_dir),
            content,
            catalog["components"],
            catalog["composables"],
            catalog["templates"],
            catalog["root"],
            hits,
        )

    if not hits:
        return CheckResult(True, "Frontend SDK API catalog", "imports/re-exports match catalog")

    unique_hits: list[FrontendSdkApiHit] = []
    seen_hits: set[tuple[Path, str, str]] = set()
    for hit in hits:
        key = (hit.path, hit.name, hit.source)
        if key in seen_hits:
            continue
        seen_hits.add(key)
        unique_hits.append(hit)

    shown = [
        f"{hit.path.as_posix()}:{hit.line_no} ({hit.name} from {hit.source})"
        for hit in unique_hits[:_FRONTEND_SDK_API_DETAIL_LIMIT]
    ]
    remaining = len(unique_hits) - len(shown)
    detail = "unsupported or unknown frontend SDK APIs in " + ", ".join(shown)
    if remaining:
        detail += f" and {remaining} more"

    return CheckResult(
        False,
        "Frontend SDK API catalog",
        detail,
        explanation=(
            "The imported or re-exported names are not present in the bundled frontend "
            "SDK catalog, or they use SDK package subpaths that are not part of the "
            "public plugin API. They may be removed, misspelled, or private APIs that "
            "were never meant for plugin code."
        ),
        fix_hint=(
            "Replace the listed imports or re-exports with documented SDK APIs. Use "
            "`mint docs frontend choose`, `mint docs frontend <name>`, or "
            "`mint docs search \"<concept>\"` to find the current component "
            "or composable."
        ),
    )


def _check_frontend_component_guidance(project_dir: Path) -> CheckResult:
    """Suggest higher-level frontend SDK entrypoints for obviously hand-wired pages."""
    if not (project_dir / "frontend" / "package.json").exists():
        return CheckResult(True, "Frontend component guidance", "no frontend (ok)")

    hits: list[FrontendComponentGuidanceHit] = []
    for path in _iter_frontend_source_files(project_dir):
        try:
            content = path.read_text(errors="ignore")
        except OSError:
            continue
        _collect_frontend_component_guidance_hits(path.relative_to(project_dir), content, hits)

    if not hits:
        return CheckResult(True, "Frontend component guidance", "canonical component entrypoints")

    unique_hits: list[FrontendComponentGuidanceHit] = []
    seen_hits: set[tuple[Path, str, str]] = set()
    for hit in hits:
        key = (hit.path, hit.marker, hit.recommendation)
        if key in seen_hits:
            continue
        seen_hits.add(key)
        unique_hits.append(hit)

    shown = [
        f"{hit.path.as_posix()}:{hit.line_no} ({hit.marker} -> {hit.recommendation})"
        for hit in unique_hits[:_FRONTEND_COMPONENT_GUIDANCE_DETAIL_LIMIT]
    ]
    remaining = len(unique_hits) - len(shown)
    detail = "non-blocking suggestions in " + ", ".join(shown)
    if remaining:
        detail += f" and {remaining} more"

    return CheckResult(
        True,
        "Frontend component guidance",
        detail,
        explanation=(
            "These pages appear to hand-wire lower-level SDK pieces that now have "
            "higher-level canonical entrypoints or metadata-backed routes."
        ),
        fix_hint=(
            "Run `mint docs frontend choose` and `mint docs frontend consolidate`, "
            "then prefer the first component path before dropping down to lower-level "
            "components. Import public components and composables from "
            "`@morscherlab/mint-sdk`; keep "
            "`@morscherlab/mint-sdk/templates` for template helpers and "
            "`@morscherlab/mint-sdk/styles` for CSS. For plugin pages, define "
            "`PluginMetadata.nav_items`; prefer `PluginWorkspaceView` for the "
            "common AppLayout/AppTopBar/AppSidebar shell, or feed generated "
            "`pluginPageSelectorItems` or `getPluginPageSelectorItems(contract)` "
            "to AppTopBar when dropping down. Use `PluginWorkspaceView "
            "experimentShell` for the common experiment chip, selector, save, "
            "and detach flow. For analysis sidebars, use "
            "`AppSidebar variant=\"analysis\"` for the chrome and let "
            "`AppLayout responsiveSidebar` own the mobile "
            "toggle and backdrop. For route-owned or Teleport-driven sidebar "
            "content, use `PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty` "
            "with the footer slot; drop to `AppSidebar contentId/showWhenEmpty` "
            "only inside custom shells."
        ),
    )


def _check_plugin_nav_item_icons(
    source_file: Path | None,
    source_content: str | None,
    project_dir: Path,
) -> CheckResult:
    """Check that page navigation metadata includes page-level icons."""
    if source_file is None or source_content is None:
        return CheckResult(True, "Plugin page metadata icons", "skipped (no source module)")

    try:
        tree = ast.parse(source_content)
    except SyntaxError:
        return CheckResult(True, "Plugin page metadata icons", "skipped (source parse failed)")

    hits: list[PluginNavIconHit] = []
    rel_path = source_file.relative_to(project_dir)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_plugin_nav_item_call(node):
            continue
        if _call_keyword_has_value(node, "icon"):
            continue
        hits.append(
            PluginNavIconHit(
                rel_path,
                getattr(node, "lineno", 1),
                _call_keyword_constant(node, "label") or "page",
                _call_keyword_constant(node, "path") or "/",
            )
        )

    if not hits:
        return CheckResult(True, "Plugin page metadata icons", "ok")

    shown = hits[:_PLUGIN_NAV_ICON_DETAIL_LIMIT]
    details = ", ".join(
        f"{hit.path}:{hit.line_no} {hit.label} ({hit.nav_path})"
        for hit in shown
    )
    if len(hits) > len(shown):
        details += f", +{len(hits) - len(shown)} more"

    return CheckResult(
        False,
        "Plugin page metadata icons",
        "PluginNavItem entries missing icon: " + details,
        explanation=(
            "Home PluginCard links and the plugin TopBar page switch both read "
            "PluginMetadata.nav_items as canonical page metadata. Page-level "
            "icons keep those surfaces visually aligned."
        ),
        fix_hint=(
            'Add `icon="..."` to each PluginNavItem(...) or create pages with '
            "`mint add frontend-page <name>` / `mint add ... --page` so the SDK "
            "writes page icons for you."
        ),
    )


def _check_plugin_nav_item_ids(
    source_file: Path | None,
    source_content: str | None,
    project_dir: Path,
) -> CheckResult:
    """Check that page navigation metadata includes stable page ids."""
    if source_file is None or source_content is None:
        return CheckResult(True, "Plugin page metadata IDs", "skipped (no source module)")

    try:
        tree = ast.parse(source_content)
    except SyntaxError:
        return CheckResult(True, "Plugin page metadata IDs", "skipped (source parse failed)")

    hits: list[PluginNavIdHit] = []
    rel_path = source_file.relative_to(project_dir)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_plugin_nav_item_call(node):
            continue
        if _call_keyword_has_value(node, "id"):
            continue
        hits.append(
            PluginNavIdHit(
                rel_path,
                getattr(node, "lineno", 1),
                _call_keyword_constant(node, "label") or "page",
                _call_keyword_constant(node, "path") or "/",
            )
        )

    if not hits:
        return CheckResult(True, "Plugin page metadata IDs", "ok")

    shown = hits[:_PLUGIN_NAV_ID_DETAIL_LIMIT]
    details = ", ".join(
        f"{hit.path}:{hit.line_no} {hit.label} ({hit.nav_path})"
        for hit in shown
    )
    if len(hits) > len(shown):
        details += f", +{len(hits) - len(shown)} more"

    return CheckResult(
        False,
        "Plugin page metadata IDs",
        "PluginNavItem entries missing id: " + details,
        explanation=(
            "Home PluginCard links, generated pageSelectorItems, and the plugin "
            "TopBar page switch all use PluginMetadata.nav_items as canonical "
            "page metadata. Stable ids keep current-page selection and tests "
            "from drifting when a route path changes."
        ),
        fix_hint=(
            'Add a stable `id="..."` to each PluginNavItem(...) or create pages '
            "with `mint add frontend-page <name>` / `mint add ... --page` so the "
            "SDK writes page ids for you."
        ),
    )


def _check_plugin_nav_items_cover_frontend_routes(
    source_file: Path | None,
    source_content: str | None,
    project_dir: Path,
) -> CheckResult:
    """Check that concrete frontend routes are discoverable through plugin page metadata."""
    if not (project_dir / "frontend" / "package.json").exists():
        return CheckResult(True, "Plugin page metadata coverage", "no frontend (ok)")
    if source_file is None or source_content is None:
        return CheckResult(True, "Plugin page metadata coverage", "skipped (no source module)")

    routes = _collect_frontend_route_paths(project_dir)
    route_paths = {route.route_path for route in routes if route.route_path != "/"}
    if not route_paths:
        return CheckResult(True, "Plugin page metadata coverage", "no extra frontend routes")

    try:
        tree = ast.parse(source_content)
    except SyntaxError:
        return CheckResult(True, "Plugin page metadata coverage", "skipped (source parse failed)")

    has_nav_items, nav_paths, dynamic_nav_items = _plugin_metadata_nav_paths(tree)
    if dynamic_nav_items:
        return CheckResult(True, "Plugin page metadata coverage", "dynamic nav_items (skipped)")

    if not has_nav_items:
        missing = routes
    else:
        missing = [
            route for route in routes
            if route.route_path != "/" and route.route_path not in nav_paths
        ]

    if not missing:
        return CheckResult(True, "Plugin page metadata coverage", "frontend routes covered")

    shown = missing[:_PLUGIN_NAV_COVERAGE_DETAIL_LIMIT]
    details = ", ".join(
        f"{gap.path}:{gap.line_no} {gap.route_path}"
        for gap in shown
    )
    if len(missing) > len(shown):
        details += f", +{len(missing) - len(shown)} more"

    return CheckResult(
        False,
        "Plugin page metadata coverage",
        "frontend routes missing PluginMetadata.nav_items: " + details,
        explanation=(
            "The platform homepage PluginCard, plugin fallback view, generated "
            "pageSelectorItems, and AppTopBar page switch discover plugin pages "
            "from PluginMetadata.nav_items. Vue routes added only in the frontend "
            "router are reachable directly but disappear from platform navigation."
        ),
        fix_hint=(
            'Add a PluginNavItem(path="/route", label="...", id="...", icon="...") '
            "for each route, or create pages with `mint add frontend-page <name>` "
            "so the SDK updates PluginMetadata.nav_items and regenerates the contract."
        ),
    )


def _check_plugin_metadata_icon(
    source_file: Path | None,
    source_content: str | None,
    project_dir: Path,
) -> CheckResult:
    """Check that plugin metadata includes a plugin-level icon."""
    if source_file is None or source_content is None:
        return CheckResult(True, "Plugin metadata icon", "skipped (no source module)")

    try:
        tree = ast.parse(source_content)
    except SyntaxError:
        return CheckResult(True, "Plugin metadata icon", "skipped (source parse failed)")

    hits: list[PluginMetadataIconHit] = []
    rel_path = source_file.relative_to(project_dir)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_plugin_metadata_call(node):
            continue
        if _call_keyword_has_value(node, "icon"):
            continue
        hits.append(PluginMetadataIconHit(rel_path, getattr(node, "lineno", 1)))

    if not hits:
        return CheckResult(True, "Plugin metadata icon", "ok")

    shown = hits[:_PLUGIN_METADATA_ICON_DETAIL_LIMIT]
    details = ", ".join(f"{hit.path}:{hit.line_no}" for hit in shown)
    if len(hits) > len(shown):
        details += f", +{len(hits) - len(shown)} more"

    return CheckResult(
        False,
        "Plugin metadata icon",
        "PluginMetadata entries missing icon: " + details,
        explanation=(
            "The platform homepage PluginCard, plugin fallback view, topbar brand "
            "icon, generated contract, and plugin page metadata all use "
            "PluginMetadata.icon as the canonical plugin-level visual identity."
        ),
        fix_hint=(
            'Add `icon="..."` to PluginMetadata(...). Use SVG path data, a data URL, '
            "or an https icon URL."
        ),
    )


def _is_plugin_metadata_call(node: ast.Call) -> bool:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id == "PluginMetadata"
    return isinstance(func, ast.Attribute) and func.attr == "PluginMetadata"


def _is_plugin_nav_item_call(node: ast.Call) -> bool:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id == "PluginNavItem"
    return isinstance(func, ast.Attribute) and func.attr == "PluginNavItem"


def _plugin_metadata_nav_paths(tree: ast.AST) -> tuple[bool, set[str], bool]:
    has_nav_items = False
    dynamic_nav_items = False
    nav_paths: set[str] = set()

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_plugin_metadata_call(node):
            continue
        for keyword in node.keywords:
            if keyword.arg != "nav_items":
                continue
            has_nav_items = True
            if not isinstance(keyword.value, ast.List):
                dynamic_nav_items = True
                continue
            for item in keyword.value.elts:
                if not isinstance(item, ast.Call) or not _is_plugin_nav_item_call(item):
                    dynamic_nav_items = True
                    continue
                nav_path = _call_keyword_constant(item, "path")
                if not nav_path:
                    dynamic_nav_items = True
                    continue
                nav_paths.add(_normalize_frontend_route_path(nav_path))

    return has_nav_items, nav_paths, dynamic_nav_items


def _collect_frontend_route_paths(project_dir: Path) -> list[FrontendRouteMetadataGap]:
    routes: list[FrontendRouteMetadataGap] = []
    seen: set[str] = set()

    for rel_path in _FRONTEND_ROUTE_FILES:
        path = project_dir / rel_path
        if not path.is_file():
            continue
        try:
            content = path.read_text(errors="ignore")
        except OSError:
            continue
        for match in _FRONTEND_ROUTE_PATH_RE.finditer(content):
            route_path = _normalize_frontend_route_path(match.group("path"))
            if route_path in seen:
                continue
            seen.add(route_path)
            routes.append(
                FrontendRouteMetadataGap(
                    rel_path,
                    _line_no_at(content, match.start()),
                    route_path,
                )
            )

    return routes


def _normalize_frontend_route_path(path: str) -> str:
    raw = path.strip() or "/"
    prefixed = raw if raw.startswith("/") else f"/{raw}"
    return prefixed.rstrip("/") or "/"


def _call_keyword_constant(node: ast.Call, name: str) -> str:
    for keyword in node.keywords:
        if keyword.arg == name and isinstance(keyword.value, ast.Constant):
            value = keyword.value.value
            return value if isinstance(value, str) else ""
    return ""


def _call_keyword_has_value(node: ast.Call, name: str) -> bool:
    for keyword in node.keywords:
        if keyword.arg != name:
            continue
        if isinstance(keyword.value, ast.Constant):
            value = keyword.value.value
            return not isinstance(value, str) or bool(value.strip())
        return True
    return False


@lru_cache(maxsize=1)
def _load_frontend_sdk_api_catalog() -> dict[str, set[str]]:
    """Load current frontend component/composable names from the bundled docs manifest."""
    manifest_path = Path(__file__).parent / "docs" / "bundled" / "frontend.json"
    try:
        data = json.loads(manifest_path.read_text())
    except Exception:
        return {"components": set(), "composables": set(), "templates": set(), "root": set()}

    categories = data.get("categories", {})
    template_names = _frontend_catalog_names(categories.get("templateExports"))
    return {
        "components": _frontend_catalog_names(categories.get("components")),
        "composables": _frontend_catalog_names(categories.get("composables")),
        "templates": template_names,
        "root": _frontend_catalog_names(data.get("exports")) | template_names,
    }


def _frontend_catalog_names(items: object) -> set[str]:
    if not isinstance(items, list):
        return set()
    names: set[str] = set()
    for item in items:
        if isinstance(item, dict) and isinstance(item.get("name"), str):
            names.add(item["name"])
    return names


def _collect_frontend_sdk_api_catalog_hits(
    rel_path: Path,
    content: str,
    component_names: set[str],
    composable_names: set[str],
    template_names: set[str],
    root_names: set[str],
    hits: list[FrontendSdkApiHit],
) -> None:
    for match in _FRONTEND_SDK_IMPORT_RE.finditer(content):
        source = match.group("source")
        clause = match.group("clause")
        line_no = _line_no_at(content, match.start())

        for name in _iter_frontend_sdk_named_imports(clause):
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(FrontendSdkApiHit(rel_path, line_no, name, source))

        for alias in _iter_frontend_sdk_namespace_aliases(clause):
            for prop_match in re.finditer(rf"\b{re.escape(alias)}\.([A-Za-z]\w*)\b", content):
                name = prop_match.group(1)
                if _is_unknown_frontend_sdk_import(
                    name,
                    source,
                    component_names,
                    composable_names,
                    template_names,
                    root_names,
                ):
                    hits.append(
                        FrontendSdkApiHit(
                            rel_path,
                            _line_no_at(content, prop_match.start()),
                            name,
                            source,
                        )
                    )
            for name, index in _iter_frontend_sdk_namespace_destructures(content, alias):
                if _is_unknown_frontend_sdk_import(
                    name,
                    source,
                    component_names,
                    composable_names,
                    template_names,
                    root_names,
                ):
                    hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, index), name, source))

    for match in _FRONTEND_SDK_EXPORT_RE.finditer(content):
        source = match.group("source")
        clause = match.group("clause")
        line_no = _line_no_at(content, match.start())

        for name in _iter_frontend_sdk_named_imports(clause):
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(FrontendSdkApiHit(rel_path, line_no, name, source))

    for match in _FRONTEND_SDK_SUBPATH_RE.finditer(content):
        source = match.group("source")
        name = _frontend_api_name_from_subpath(match.group("name"))
        kind = match.group("kind")
        if kind == "composables" or name not in component_names:
            hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_SUBPATH_EXPORT_RE.finditer(content):
        source = match.group("source")
        name = _frontend_api_name_from_subpath(match.group("name"))
        kind = match.group("kind")
        if kind == "composables" or name not in component_names:
            hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_ANY_SUBPATH_RE.finditer(content):
        source = match.group("source")
        subpath = match.group("subpath")
        if _is_frontend_sdk_leaf_subpath(subpath) or _is_public_frontend_sdk_subpath(subpath, component_names):
            continue
        name = _frontend_api_name_from_source_path(subpath)
        hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_ANY_SUBPATH_EXPORT_RE.finditer(content):
        source = match.group("source")
        subpath = match.group("subpath")
        if _is_frontend_sdk_leaf_subpath(subpath) or _is_public_frontend_sdk_subpath(subpath, component_names):
            continue
        name = _frontend_api_name_from_source_path(subpath)
        hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_SIDE_EFFECT_SUBPATH_RE.finditer(content):
        source = match.group("source")
        subpath = match.group("subpath")
        if _is_public_frontend_sdk_subpath(subpath, component_names):
            continue
        name = _frontend_api_name_from_source_path(subpath)
        hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_DYNAMIC_SUBPATH_RE.finditer(content):
        source = match.group("source")
        subpath = match.group("subpath")
        if _is_public_frontend_sdk_subpath(subpath, component_names):
            continue
        name = _frontend_api_name_from_source_path(subpath)
        hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start()), name, source))

    for match in _FRONTEND_SDK_DYNAMIC_IMPORT_ASSIGN_RE.finditer(content):
        source = match.group("source")
        alias = match.group("alias")
        for prop_match in re.finditer(rf"\b{re.escape(alias)}\.([A-Za-z]\w*)\b", content):
            name = prop_match.group(1)
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, prop_match.start()), name, source))

    for match in _FRONTEND_SDK_DYNAMIC_IMPORT_DESTRUCTURE_RE.finditer(content):
        source = match.group("source")
        for name, index in _iter_frontend_sdk_destructure_body(match.group("body"), match.start("body")):
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, index), name, source))

    for match in _FRONTEND_SDK_DYNAMIC_IMPORT_THEN_MEMBER_RE.finditer(content):
        source = match.group("source")
        alias = match.group("alias")
        body = match.group("body")
        body_start = match.start("body")
        for prop_match in re.finditer(rf"\b{re.escape(alias)}\.([A-Za-z]\w*)\b", body):
            name = prop_match.group(1)
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(
                    FrontendSdkApiHit(
                        rel_path,
                        _line_no_at(content, body_start + prop_match.start(1)),
                        name,
                        source,
                    )
                )

    for match in _FRONTEND_SDK_DYNAMIC_IMPORT_THEN_DESTRUCTURE_RE.finditer(content):
        source = match.group("source")
        for name, index in _iter_frontend_sdk_destructure_body(match.group("body"), match.start("body")):
            if _is_unknown_frontend_sdk_import(
                name,
                source,
                component_names,
                composable_names,
                template_names,
                root_names,
            ):
                hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, index), name, source))

    for match in _FRONTEND_SDK_DYNAMIC_IMPORT_MEMBER_RE.finditer(content):
        source = match.group("source") or match.group("bare_source")
        name = match.group("name")
        if name in _FRONTEND_DYNAMIC_IMPORT_PROMISE_MEMBERS:
            continue
        if _is_unknown_frontend_sdk_import(
            name,
            source,
            component_names,
            composable_names,
            template_names,
            root_names,
        ):
            hits.append(FrontendSdkApiHit(rel_path, _line_no_at(content, match.start("name")), name, source))


def _iter_frontend_sdk_named_imports(clause: str) -> Iterator[str]:
    clause = clause.strip()
    if clause.startswith("type "):
        clause = clause.removeprefix("type").strip()

    named_match = re.search(r"\{(?P<named>[\s\S]*?)\}", clause)
    if not named_match:
        return

    for item in named_match.group("named").split(","):
        spec = item.strip()
        if not spec:
            continue
        if spec.startswith("type "):
            spec = spec.removeprefix("type").strip()
        imported = re.split(r"\s+as\s+", spec, maxsplit=1)[0].strip()
        if imported == "default" or not re.fullmatch(r"[A-Za-z]\w*", imported):
            continue
        yield imported


def _iter_frontend_sdk_namespace_aliases(clause: str) -> Iterator[str]:
    match = _FRONTEND_SDK_NAMESPACE_RE.match(clause.strip())
    if match:
        yield match.group(1)


def _iter_frontend_sdk_namespace_destructures(content: str, alias: str) -> Iterator[tuple[str, int]]:
    pattern = re.compile(
        rf"\b(?:const|let|var)\s*\{{(?P<body>[^}}]*)\}}\s*=\s*{re.escape(alias)}\b",
        flags=re.MULTILINE,
    )
    for match in pattern.finditer(content):
        yield from _iter_frontend_sdk_destructure_body(match.group("body"), match.start("body"))


def _iter_frontend_sdk_destructure_body(body: str, body_start: int) -> Iterator[tuple[str, int]]:
    for item_match in re.finditer(r"[^,]+", body):
        spec = item_match.group(0).strip()
        if not spec or spec.startswith("..."):
            continue
        imported = re.split(r"\s*:\s*", spec, maxsplit=1)[0].strip()
        imported = imported.strip("'\"")
        if re.fullmatch(r"[A-Za-z]\w*", imported):
            yield imported, body_start + item_match.start()


def _is_unknown_frontend_sdk_import(
    name: str,
    source: str,
    component_names: set[str],
    composable_names: set[str],
    template_names: set[str],
    root_names: set[str],
) -> bool:
    if name in _FRONTEND_ROOT_IMPORT_ALLOWLIST:
        return False
    if source == "@morscherlab/mint-sdk":
        return name not in root_names and not _is_frontend_type_like_name(name)
    if source.endswith("/components"):
        return name not in component_names and not _is_frontend_type_like_name(name)
    if source.endswith("/composables"):
        return _is_frontend_composable_like_name(name) and name not in composable_names
    if source.endswith("/templates"):
        return name not in template_names and not _is_frontend_type_like_name(name)
    if name in component_names or name in composable_names:
        return False
    if _is_frontend_composable_like_name(name):
        return True
    return bool(_is_frontend_component_like_name(name))


def _is_frontend_composable_like_name(name: str) -> bool:
    return bool(re.fullmatch(r"use[A-Z]\w*", name))


def _is_frontend_component_like_name(name: str) -> bool:
    return bool(re.fullmatch(r"[A-Z]\w*", name)) and not _is_frontend_type_like_name(name)


def _is_frontend_type_like_name(name: str) -> bool:
    return bool(_FRONTEND_TYPE_LIKE_SUFFIX_RE.search(name))


def _frontend_api_name_from_subpath(name: str) -> str:
    if "-" not in name and "_" not in name:
        return name
    return "".join(part[:1].upper() + part[1:] for part in re.split(r"[-_]+", name) if part)


def _is_public_frontend_sdk_subpath(subpath: str, component_names: set[str]) -> bool:
    if subpath in _FRONTEND_PUBLIC_BARE_SUBPATHS:
        return True

    component_match = re.fullmatch(
        r"components/(?P<name>[A-Za-z][\w-]*)(?:\.vue)?",
        subpath,
    )
    if component_match:
        return _frontend_api_name_from_subpath(component_match.group("name")) in component_names

    return False


def _is_frontend_sdk_leaf_subpath(subpath: str) -> bool:
    return bool(
        re.fullmatch(
            r"(?:components|composables)/[A-Za-z][\w-]*(?:\.(?:vue|ts))?",
            subpath,
        )
    )


def _frontend_api_name_from_source_path(subpath: str) -> str:
    name = subpath.rsplit("/", 1)[-1]
    name = re.sub(r"\.(?:vue|ts|js|css|mjs|cjs|d\.ts)$", "", name)
    return _frontend_api_name_from_subpath(name)


def _collect_frontend_component_guidance_hits(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    for required, alternatives, marker, recommendation in _FRONTEND_COMPONENT_GUIDANCE_RULES:
        if not all(_frontend_symbol_is_used(content, symbol) for symbol in required):
            continue
        if any(_frontend_symbol_is_used(content, symbol) for symbol in alternatives):
            continue
        if (
            marker
            in {
                "manual AppLayout + AppSidebar + FormBuilder page",
                "manual AppTopBar + AppSidebar + FormBuilder workspace",
            }
            and _frontend_uses_control_workspace_bindings(content)
        ):
            continue
        if (
            marker == "manual AppLayout + AppTopBar + AppSidebar shell"
            and _frontend_uses_route_owned_app_sidebar(content)
        ):
            continue
        first_index = min(
            index
            for symbol in required
            if (index := _frontend_symbol_index(content, symbol)) >= 0
        )
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, first_index),
                marker,
                recommendation,
            )
        )

    _collect_control_workspace_model_guidance_hit(rel_path, content, hits)
    _collect_responsive_sidebar_guidance_hit(rel_path, content, hits)
    _collect_analysis_sidebar_variant_guidance_hit(rel_path, content, hits)
    _collect_route_owned_sidebar_shell_guidance_hit(rel_path, content, hits)
    _collect_plugin_workspace_experiment_shell_guidance_hit(rel_path, content, hits)

    if (
        _frontend_symbol_is_used(content, "AppTopBar")
        and _frontend_uses_page_selector(content)
        and not any(
            _frontend_symbol_is_used(content, symbol)
            for symbol in (
                "pluginPageSelectorItems",
                "pageSelectorItems",
                "getPluginPageSelectorItems",
            )
        )
    ):
        first_index = min(
            index
            for index in (
                _frontend_symbol_index(content, "AppTopBar"),
                content.find("page-selector"),
                content.find("pageSelector"),
            )
            if index >= 0
        )
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, first_index),
                "manual AppTopBar page selector",
                "pluginPageSelectorItems or getPluginPageSelectorItems(contract) from PluginMetadata.nav_items",
            )
        )

    subpath_guidance = {
        "@morscherlab/mint-sdk/components": "component subpath import",
        "@morscherlab/mint-sdk/composables": "composable subpath import",
    }
    for match in (*_FRONTEND_SDK_IMPORT_RE.finditer(content), *_FRONTEND_SDK_EXPORT_RE.finditer(content)):
        marker = subpath_guidance.get(match.group("source"))
        if marker is None:
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                marker,
                "root @morscherlab/mint-sdk import",
            )
        )

    side_effect_subpath_guidance = {
        "@morscherlab/mint-sdk/components": "side-effect component subpath import",
        "@morscherlab/mint-sdk/composables": "side-effect composable subpath import",
    }
    for match in _FRONTEND_SDK_SIDE_EFFECT_SUBPATH_RE.finditer(content):
        marker = side_effect_subpath_guidance.get(match.group("source"))
        if marker is None:
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                marker,
                "root @morscherlab/mint-sdk import",
            )
        )

    for match in (
        *_FRONTEND_SDK_SUBPATH_RE.finditer(content),
        *_FRONTEND_SDK_SUBPATH_EXPORT_RE.finditer(content),
    ):
        if match.group("kind") != "components":
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                f"{match.group('name')} component file import",
                "root @morscherlab/mint-sdk import",
            )
        )

    component_names = _load_frontend_sdk_api_catalog()["components"]
    for match in _FRONTEND_SDK_DYNAMIC_SUBPATH_RE.finditer(content):
        subpath = match.group("subpath")
        marker = ""
        if subpath == "components":
            marker = "dynamic component subpath import"
        elif subpath == "composables":
            marker = "dynamic composable subpath import"
        else:
            component_match = re.fullmatch(
                r"components/(?P<name>[A-Za-z][\w-]*)(?:\.vue)?",
                subpath,
            )
            if component_match is not None:
                name = _frontend_api_name_from_subpath(component_match.group("name"))
                if name in component_names:
                    marker = f"{name} dynamic component file import"
        if not marker:
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                marker,
                "root @morscherlab/mint-sdk import",
            )
        )


def _collect_control_workspace_model_guidance_hit(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    split_match = _FRONTEND_USE_CONTROL_WORKSPACE_SPLIT_MODEL_RE.search(content)
    if split_match is None:
        return
    if _FRONTEND_CONTROL_WORKSPACE_WORKSPACE_BIND_RE.search(content) is None:
        return

    hits.append(
        FrontendComponentGuidanceHit(
            rel_path,
            _line_no_at(content, split_match.start()),
            "manual useControlWorkspace split model binding",
            "ControlWorkspaceView :model + defineControlModel",
        )
    )


def _collect_responsive_sidebar_guidance_hit(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    if _frontend_uses_responsive_sidebar(content):
        return
    if not (
        _frontend_symbol_is_used(content, "AppTopBar")
        and _frontend_has_sidebar_surface(content)
    ):
        return
    if not _frontend_uses_manual_mobile_sidebar_shell(content):
        return

    first_index = min(
        index
        for index in (
            _frontend_symbol_index(content, "AppTopBar"),
            _frontend_manual_sidebar_shell_index(content),
        )
        if index >= 0
    )
    hits.append(
        FrontendComponentGuidanceHit(
            rel_path,
            _line_no_at(content, first_index),
            "manual mobile sidebar behavior",
            "AppLayout responsiveSidebar with AppSidebar variant=\"analysis\"",
        )
    )


def _collect_analysis_sidebar_variant_guidance_hit(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    for match in _FRONTEND_APP_SIDEBAR_TAG_RE.finditer(content):
        tag_content = match.group(0)
        if _app_sidebar_has_analysis_variant(tag_content):
            continue
        if not _app_sidebar_uses_verbose_analysis_chrome(tag_content):
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                "verbose AppSidebar analysis chrome",
                'AppSidebar variant="analysis"',
            )
        )


def _collect_route_owned_sidebar_shell_guidance_hit(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    for match in _FRONTEND_SIDEBAR_SLOT_RE.finditer(content):
        slot_content = match.group(0)
        if _frontend_symbol_is_used(slot_content, "AppSidebar"):
            continue
        if _FRONTEND_SIDEBAR_TARGET_ID_RE.search(slot_content) is None:
            continue
        hits.append(
            FrontendComponentGuidanceHit(
                rel_path,
                _line_no_at(content, match.start()),
                "manual route-owned sidebar shell",
                "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty with footer slot",
            )
        )


def _collect_plugin_workspace_experiment_shell_guidance_hit(
    rel_path: Path,
    content: str,
    hits: list[FrontendComponentGuidanceHit],
) -> None:
    if not _frontend_symbol_is_used(content, "PluginWorkspaceView"):
        return
    if not _frontend_symbol_is_used(content, "useAppExperiment"):
        return
    if _frontend_uses_plugin_workspace_experiment_shell(content):
        return

    first_index = min(
        index
        for index in (
            _frontend_symbol_index(content, "PluginWorkspaceView"),
            _frontend_symbol_index(content, "useAppExperiment"),
        )
        if index >= 0
    )
    hits.append(
        FrontendComponentGuidanceHit(
            rel_path,
            _line_no_at(content, first_index),
            "manual useAppExperiment with PluginWorkspaceView",
            "PluginWorkspaceView experimentShell",
        )
    )


def _frontend_uses_page_selector(content: str) -> bool:
    return "page-selector" in content or "pageSelector" in content


def _frontend_uses_responsive_sidebar(content: str) -> bool:
    return "responsive-sidebar" in content or "responsiveSidebar" in content


def _frontend_has_sidebar_surface(content: str) -> bool:
    return _frontend_symbol_is_used(content, "AppSidebar") or _FRONTEND_MANUAL_ASIDE_RE.search(content) is not None


def _frontend_uses_route_owned_app_sidebar(content: str) -> bool:
    for match in _FRONTEND_APP_SIDEBAR_TAG_RE.finditer(content):
        tag_content = match.group(0)
        if "content-id" in tag_content or "contentId" in tag_content:
            return True
        if "show-when-empty" in tag_content or "showWhenEmpty" in tag_content:
            return True
    return False


def _frontend_uses_manual_mobile_sidebar_shell(content: str) -> bool:
    if _FRONTEND_MANUAL_SIDEBAR_OPEN_STATE_RE.search(content) is None:
        return False

    shell_markers = (
        "Sidebar backdrop",
        "sidebar backdrop",
        "Toggle sidebar",
        "mobile sidebar",
        "Mobile sidebar",
        "aria-expanded",
    )
    return any(marker in content for marker in shell_markers)


def _frontend_manual_sidebar_shell_index(content: str) -> int:
    candidates = [
        match.start()
        for match in (
            _FRONTEND_MANUAL_SIDEBAR_OPEN_STATE_RE.search(content),
        )
        if match is not None
    ]
    candidates.extend(
        index
        for marker in (
            "Sidebar backdrop",
            "sidebar backdrop",
            "Toggle sidebar",
            "mobile sidebar",
            "Mobile sidebar",
        )
        if (index := content.find(marker)) >= 0
    )
    return min(candidates) if candidates else -1


def _app_sidebar_has_analysis_variant(tag_content: str) -> bool:
    for match in _FRONTEND_TAG_ATTR_VALUE_RE.finditer(tag_content):
        name = match.group("name").strip()
        if name not in {"variant", ":variant", "v-bind:variant"}:
            continue
        if "analysis" in match.group("value"):
            return True
    return False


def _app_sidebar_uses_verbose_analysis_chrome(tag_content: str) -> bool:
    return (
        _app_sidebar_has_false_binding(tag_content, "floating")
        and _app_sidebar_has_truthy_attr(tag_content, "collapsible")
    )


def _app_sidebar_has_false_binding(tag_content: str, attr_name: str) -> bool:
    names = {attr_name, f":{attr_name}", f"v-bind:{attr_name}"}
    for match in _FRONTEND_TAG_ATTR_VALUE_RE.finditer(tag_content):
        if match.group("name").strip() not in names:
            continue
        if match.group("value").strip() == "false":
            return True
    return False


def _app_sidebar_has_truthy_attr(tag_content: str, attr_name: str) -> bool:
    if re.search(rf"\s{re.escape(attr_name)}(?:\s|/?>)", tag_content):
        return True
    names = {attr_name, f":{attr_name}", f"v-bind:{attr_name}"}
    for match in _FRONTEND_TAG_ATTR_VALUE_RE.finditer(tag_content):
        if match.group("name").strip() not in names:
            continue
        if match.group("value").strip() != "false":
            return True
    return False


def _frontend_uses_plugin_workspace_experiment_shell(content: str) -> bool:
    for match in _FRONTEND_PLUGIN_WORKSPACE_TAG_RE.finditer(content):
        tag_content = match.group("body")
        if "experiment-shell" in tag_content or "experimentShell" in tag_content:
            return True
    return False


def _frontend_uses_control_workspace_bindings(content: str) -> bool:
    return "workspace.bindings" in content


def _frontend_symbol_is_used(content: str, symbol: str) -> bool:
    return _frontend_symbol_index(content, symbol) >= 0


def _frontend_symbol_index(content: str, symbol: str) -> int:
    kebab = _kebab_case(symbol)
    patterns = (
        rf"\b{re.escape(symbol)}\b",
        rf"<{re.escape(kebab)}\b",
    )
    matches = [
        match.start()
        for pattern in patterns
        if (match := re.search(pattern, content))
    ]
    return min(matches) if matches else -1


def _kebab_case(value: str) -> str:
    return re.sub(r"(?<!^)(?=[A-Z])", "-", value).lower()


def _deprecated_api_text_scan_files(project_dir: Path) -> Iterator[Path]:
    """Yield metadata and source files for package rename/deprecation scans."""
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists():
        yield pyproject

    package_json = project_dir / "frontend" / "package.json"
    if package_json.exists():
        yield package_json

    yield from _iter_deprecated_project_text_files(project_dir)
    yield from _iter_python_source_files(project_dir)
    yield from _iter_frontend_source_files(project_dir)


def _iter_deprecated_project_text_files(project_dir: Path) -> Iterator[Path]:
    """Yield project docs/instructions that can carry stale SDK names or commands."""
    seen: set[Path] = set()

    for name in _DEPRECATED_TEXT_ROOT_FILES:
        path = project_dir / name
        if path.is_file():
            seen.add(path)
            yield path

    frontend_readme = project_dir / "frontend" / "README.md"
    if frontend_readme.is_file() and frontend_readme not in seen:
        seen.add(frontend_readme)
        yield frontend_readme

    for dirname in _DEPRECATED_TEXT_DOC_DIRS:
        docs_dir = project_dir / dirname
        if not docs_dir.is_dir():
            continue
        for path in docs_dir.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in _DEPRECATED_TEXT_DOC_SUFFIXES:
                continue
            if path in seen:
                continue
            seen.add(path)
            yield path


def _collect_deprecated_text_hits(
    project_dir: Path,
    path: Path,
    hits: list[DeprecatedApiHit],
) -> None:
    try:
        lines = path.read_text(errors="ignore").splitlines()
    except OSError:
        return

    for line_no, line in enumerate(lines, start=1):
        for marker, pattern, replacement in _DEPRECATED_TEXT_PATTERNS:
            if pattern.search(line):
                hits.append(DeprecatedApiHit(path.relative_to(project_dir), line_no, marker, replacement))
                break


def _collect_deprecated_frontend_doc_text_hits(
    project_dir: Path,
    path: Path,
    hits: list[DeprecatedApiHit],
) -> None:
    try:
        content = path.read_text(errors="ignore")
    except OSError:
        return

    lines = content.splitlines()
    for line_no, line in enumerate(lines, start=1):
        for marker, pattern, replacement in _DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS:
            if pattern.search(line):
                hits.append(DeprecatedApiHit(path.relative_to(project_dir), line_no, marker, replacement))

    _collect_deprecated_frontend_tag_hits(path.relative_to(project_dir), content, hits)


def _collect_deprecated_python_api_hits(
    project_dir: Path,
    path: Path,
    hits: list[DeprecatedApiHit],
) -> None:
    try:
        content = path.read_text(errors="ignore")
        tree = ast.parse(content)
    except (OSError, SyntaxError):
        return

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module in _DEPRECATED_PYTHON_IMPORT_MODULES:
            for alias in node.names:
                replacement = _DEPRECATED_PYTHON_IMPORT_REPLACEMENTS.get(alias.name)
                if replacement is None:
                    continue
                hits.append(
                    DeprecatedApiHit(
                        path.relative_to(project_dir),
                        getattr(node, "lineno", 1),
                        f"{alias.name} model",
                        replacement,
                    )
                )

        if isinstance(node, ast.Name):
            replacement = _DEPRECATED_PYTHON_IMPORT_REPLACEMENTS.get(node.id)
            if replacement is not None:
                hits.append(
                    DeprecatedApiHit(
                        path.relative_to(project_dir),
                        getattr(node, "lineno", 1),
                        f"{node.id} model",
                        replacement,
                    )
                )

        if isinstance(node, ast.Attribute):
            member_replacement = _DEPRECATED_PYTHON_MEMBER_REPLACEMENTS.get(node.attr)
            if member_replacement is not None:
                marker, replacement = member_replacement
                hits.append(
                    DeprecatedApiHit(
                        path.relative_to(project_dir),
                        getattr(node, "lineno", 1),
                        marker,
                        replacement,
                    )
                )

        if isinstance(node, ast.Call) and _is_plugin_metadata_call(node):
            _collect_deprecated_plugin_metadata_nav_item_shape_hits(project_dir, path, node, hits)

        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        override_replacement = _DEPRECATED_PYTHON_OVERRIDE_REPLACEMENTS.get(node.name)
        if override_replacement is not None:
            marker, replacement = override_replacement
            hits.append(
                DeprecatedApiHit(
                    path.relative_to(project_dir),
                    getattr(node, "lineno", 1),
                    marker,
                    replacement,
                )
            )

        if node.name != "get_frontend_config":
            continue
        for child in ast.walk(node):
            if isinstance(child, ast.Constant) and child.value == "navItems":
                hits.append(
                    DeprecatedApiHit(
                        path.relative_to(project_dir),
                        getattr(child, "lineno", node.lineno),
                        "get_frontend_config navItems",
                        "PluginMetadata.nav_items",
                    )
                )
                break


def _collect_deprecated_plugin_metadata_nav_item_shape_hits(
    project_dir: Path,
    path: Path,
    node: ast.Call,
    hits: list[DeprecatedApiHit],
) -> None:
    for keyword in node.keywords:
        if keyword.arg != "nav_items" or not isinstance(keyword.value, ast.List):
            continue
        for item in keyword.value.elts:
            if not isinstance(item, ast.Dict):
                continue
            hits.append(
                DeprecatedApiHit(
                    path.relative_to(project_dir),
                    getattr(item, "lineno", getattr(node, "lineno", 1)),
                    "PluginMetadata.nav_items dict",
                    "PluginNavItem(...)",
                )
            )


def _collect_deprecated_frontend_import_hits(
    rel_path: Path,
    content: str,
    hits: list[DeprecatedApiHit],
) -> None:
    for marker, pattern, replacement in _DEPRECATED_FRONTEND_IMPORT_PATTERNS:
        for match in pattern.finditer(content):
            hits.append(DeprecatedApiHit(rel_path, _line_no_at(content, match.start()), marker, replacement))


def _collect_deprecated_frontend_tag_hits(
    rel_path: Path,
    content: str,
    hits: list[DeprecatedApiHit],
) -> None:
    for tag_names, rules in _DEPRECATED_FRONTEND_TAG_RULES:
        tag_pattern = re.compile(
            rf"<(?:{'|'.join(re.escape(tag_name) for tag_name in tag_names)})\b[\s\S]*?>",
            flags=re.MULTILINE,
        )
        for tag_match in tag_pattern.finditer(content):
            tag_content = tag_match.group(0)
            searchable_tag_content = _frontend_tag_content_for_deprecated_scan(tag_content)
            tag_line = _line_no_at(content, tag_match.start())
            bound_objects = list(_iter_frontend_tag_bound_object_chunks(content, tag_content))
            for marker, pattern, replacement in rules:
                if pattern.search(searchable_tag_content):
                    hits.append(DeprecatedApiHit(rel_path, tag_line, marker, replacement))
                for object_start, object_content in bound_objects:
                    object_scan_content = f'v-bind="{_expand_frontend_object_shorthand_props(object_content)}"'
                    if pattern.search(object_scan_content):
                        hits.append(
                            DeprecatedApiHit(
                                rel_path,
                                _line_no_at(content, object_start),
                                marker,
                                replacement,
                            )
                        )


def _frontend_tag_content_for_deprecated_scan(tag_content: str) -> str:
    """Keep direct prop names visible while hiding nested values from other props."""

    def replace(match: re.Match[str]) -> str:
        name = match.group("name").strip()
        if name == "v-bind":
            return match.group(0)
        if "{" not in match.group("value"):
            return match.group(0)
        return f'{match.group("name")}=""'

    return _FRONTEND_TAG_ATTR_VALUE_RE.sub(replace, tag_content)


def _collect_deprecated_frontend_expression_hits(
    rel_path: Path,
    content: str,
    hits: list[DeprecatedApiHit],
) -> None:
    for marker, pattern, replacement in _DEPRECATED_FRONTEND_EXPRESSION_PATTERNS:
        for match in pattern.finditer(content):
            hits.append(DeprecatedApiHit(rel_path, _line_no_at(content, match.start()), marker, replacement))


def _collect_deprecated_frontend_destructure_hits(
    rel_path: Path,
    content: str,
    hits: list[DeprecatedApiHit],
) -> None:
    for marker, pattern, replacement in _DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS:
        for match in pattern.finditer(content):
            hits.append(DeprecatedApiHit(rel_path, _line_no_at(content, match.start()), marker, replacement))


def _collect_deprecated_frontend_dynamic_component_hits(
    rel_path: Path,
    content: str,
    hits: list[DeprecatedApiHit],
) -> None:
    for marker, pattern, replacement in _DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS:
        for match in pattern.finditer(content):
            hits.append(DeprecatedApiHit(rel_path, _line_no_at(content, match.start()), marker, replacement))


def _iter_frontend_tag_bound_object_chunks(content: str, tag_content: str) -> Iterator[tuple[int, str]]:
    for match in _FRONTEND_TAG_NAMED_V_BIND_RE.finditer(tag_content):
        yield from _iter_frontend_object_assignments(content, match.group("name"))


def _iter_frontend_object_assignments(content: str, name: str) -> Iterator[tuple[int, str]]:
    assignment_re = re.compile(
        rf"\b(?:const|let|var)\s+{re.escape(name)}\b[^\n=;]*=",
        flags=re.MULTILINE,
    )
    for match in assignment_re.finditer(content):
        object_start = content.find("{", match.end())
        if object_start == -1:
            continue
        prefix = content[match.end():object_start]
        if ";" in prefix or re.search(r"\b(?:const|let|var|function|class)\b|</script>", prefix):
            continue
        object_content = _extract_balanced_brace_chunk(content, object_start)
        if object_content:
            yield object_start, object_content


def _extract_balanced_brace_chunk(content: str, start: int) -> str:
    depth = 0
    quote: str | None = None
    escaped = False

    for index in range(start, len(content)):
        char = content[index]

        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue

        if char in {"'", '"', "`"}:
            quote = char
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return content[start:index + 1]

    return ""


def _expand_frontend_object_shorthand_props(content: str) -> str:
    for key in _FRONTEND_DEPRECATED_PROP_SHORTHAND_KEYS:
        content = re.sub(
            rf"(?<![\w$'\"]){re.escape(key)}(?=\s*[,}}])",
            f"{key}:",
            content,
        )
    return content


def _line_no_at(content: str, index: int) -> int:
    return content.count("\n", 0, index) + 1


def run_checks(project_dir: Path) -> list[CheckResult]:
    """Run all diagnostic checks and return results."""
    results: list[CheckResult] = []

    pyproject_result, data = _check_pyproject(project_dir)
    results.append(pyproject_result)

    ep_result, ep_name, module_path, class_name = _check_entry_point(data)
    results.append(ep_result)

    source_result, source_file = _check_source_module(project_dir, module_path)
    results.append(source_result)

    class_result, source_content = _check_plugin_class(source_file, class_name)
    results.append(class_result)
    results.append(_check_routes_prefix(source_file, ep_name, source_content))
    results.append(_check_sdk_python(data))
    results.append(_check_sdk_frontend(project_dir))
    results.append(_check_tests(project_dir))
    results.append(_check_ai_instructions(project_dir))
    results.append(_check_generated_contract(project_dir))
    results.append(_check_plugin_metadata_icon(source_file, source_content, project_dir))
    results.append(_check_plugin_nav_item_icons(source_file, source_content, project_dir))
    results.append(_check_plugin_nav_item_ids(source_file, source_content, project_dir))
    results.append(_check_plugin_nav_items_cover_frontend_routes(source_file, source_content, project_dir))
    results.append(_check_frontend_api_wiring(project_dir))
    results.append(_check_frontend_sdk_api_catalog(project_dir))
    results.append(_check_frontend_component_guidance(project_dir))
    results.append(_check_deprecated_api_usage(project_dir))

    return results


def apply_fixes(project_dir: Path, results: list[CheckResult]) -> list[str]:
    """Apply safe mechanical fixes for failed checks."""
    applied: list[str] = []
    for result in results:
        if result.ok or result.fix_id is None:
            continue
        if result.fix_id == "tests":
            tests_dir = project_dir / "tests"
            tests_dir.mkdir(exist_ok=True)
            test_file = tests_dir / "test_plugin.py"
            if not test_file.exists():
                test_file.write_text("def test_plugin_smoke():\n    assert True\n")
            applied.append("Created tests/test_plugin.py")
        elif result.fix_id == "ai-instructions":
            fixed = _fix_ai_instructions(project_dir)
            if fixed == "created":
                applied.append("Created AGENTS.md")
            elif fixed == "updated":
                applied.append("Updated AI instructions with current SDK discovery")
        elif result.fix_id == "frontend-sdk-dep":
            if _fix_frontend_sdk_dep(project_dir):
                applied.append("Added @morscherlab/mint-sdk to frontend/package.json")
        elif result.fix_id == "python-sdk-dep":
            if _fix_python_sdk_dep(project_dir):
                applied.append("Added mint-sdk to pyproject.toml dependencies")
        elif result.fix_id == "generated-contract":
            if _fix_generated_contract(project_dir):
                applied.append("Regenerated frontend plugin contract")
    return applied


def _fix_ai_instructions(project_dir: Path) -> str | None:
    target = next((project_dir / name for name in _AI_FILES if (project_dir / name).exists()), None)
    if target is None:
        target = project_dir / "AGENTS.md"
        target.write_text("# AGENTS.md\n" + _AI_DISCOVERY_BLOCK)
        return "created"

    content = target.read_text(errors="ignore")
    if all(marker in content for marker in _AI_REQUIRED_MARKERS):
        return None
    target.write_text(content.rstrip() + "\n" + _AI_DISCOVERY_BLOCK)
    return "updated"


def _fix_generated_contract(project_dir: Path) -> bool:
    try:
        from mint_sdk.contract import generate_contract_files

        result = generate_contract_files(project_dir)
    except Exception:
        return False
    return result.ok


def _fix_frontend_sdk_dep(project_dir: Path) -> bool:
    pkg_path = project_dir / "frontend" / "package.json"
    if not pkg_path.exists():
        return False
    try:
        pkg = json.loads(pkg_path.read_text())
    except Exception:
        return False
    deps = pkg.setdefault("dependencies", {})
    if deps.get("@morscherlab/mint-sdk"):
        return False
    deps["@morscherlab/mint-sdk"] = "^1.0.0-beta.3"
    pkg_path.write_text(json.dumps(pkg, indent=2) + "\n")
    return True


def _fix_python_sdk_dep(project_dir: Path) -> bool:
    path = project_dir / "pyproject.toml"
    if not path.exists():
        return False
    content = path.read_text()
    if re.search(r'"mint-sdk|mint-sdk|mint_sdk', content):
        return False
    dep = '"mint-sdk>=1.0.0a8"'
    match = re.search(r"(dependencies\s*=\s*\[)([^\]]*)(\])", content, flags=re.DOTALL)
    if match:
        body = match.group(2).rstrip()
        sep = ",\n    " if body.strip() else "\n    "
        replacement = f"{match.group(1)}{body}{sep}{dep},\n{match.group(3)}"
        content = content[: match.start()] + replacement + content[match.end():]
    else:
        project_match = re.search(r"^\[project\]\s*$", content, flags=re.MULTILINE)
        if not project_match:
            return False
        insert_at = content.find("\n", project_match.end()) + 1
        content = content[:insert_at] + f"dependencies = [{dep}]\n" + content[insert_at:]
    path.write_text(content)
    return True


def cmd_doctor(*, path: str = ".", explain: bool = False, fix: bool = False, json_output: bool = False) -> None:
    """Execute the ``mint doctor`` command."""
    project_dir = Path(path).resolve()

    color = _supports_color()
    green = "\033[32m" if color else ""
    red = "\033[31m" if color else ""
    bold = "\033[1m" if color else ""
    reset = "\033[0m" if color else ""

    results = run_checks(project_dir)
    applied: list[str] = []
    if fix:
        applied = apply_fixes(project_dir, results)
        if applied and not json_output:
            for item in applied:
                print(f"  fixed: {item}")
            print()
            results = run_checks(project_dir)
        elif applied:
            results = run_checks(project_dir)

    passed = 0
    failed = 0
    for result in results:
        if result.ok:
            passed += 1
        else:
            failed += 1
    total = passed + failed

    if json_output:
        print(
            json.dumps(
                {
                    "ok": failed == 0,
                    "passed": passed,
                    "failed": failed,
                    "total": total,
                    "applied_fixes": applied,
                    "checks": [_check_result_to_dict(result) for result in results],
                },
                indent=2,
            )
        )
        if failed:
            sys.exit(1)
        return

    print(f"\n{bold}Checking plugin health...{reset}\n")

    for r in results:
        icon = f"{green}ok{reset}" if r.ok else f"{red}!!{reset}"
        detail = f"  {r.detail}" if r.detail else ""
        print(f"  [{icon}]  {r.label}{detail}")
        if explain and _should_explain_check(r):
            if r.explanation:
                print(f"        why: {r.explanation}")
            if r.fix_hint:
                print(f"        fix: {r.fix_hint}")

    print()
    if failed == 0:
        print(f"{green}{passed}/{total} checks passed{reset}")
    else:
        print(f"{red}{failed}/{total} checks failed{reset}")
        sys.exit(1)


def _should_explain_check(result: CheckResult) -> bool:
    if not result.ok:
        return True
    return result.detail.startswith("non-blocking suggestions")


def _check_result_to_dict(result: CheckResult) -> dict[str, object]:
    return {
        "ok": result.ok,
        "label": result.label,
        "detail": result.detail,
        "explanation": result.explanation,
        "fix_hint": result.fix_hint,
        "fix_id": result.fix_id,
    }
