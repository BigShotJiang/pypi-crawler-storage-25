from __future__ import annotations

import json
import re
from pathlib import Path

from mint_sdk import docs_command
from mint_sdk.add_command import SettingType, cmd_add_setting
from mint_sdk.docs.cache import is_cache_fresh, read_cache
from mint_sdk.init_command import _build_template_context, derive_names, write_files


def test_clear_cache_option_removes_docs_cache(tmp_path, monkeypatch, capsys):
    cache_dir = tmp_path / ".mint" / "docs-cache"
    cache_dir.mkdir(parents=True)
    (cache_dir / "python.json").write_text("{}")

    monkeypatch.setattr(docs_command, "find_platform_root", lambda: tmp_path)
    monkeypatch.setattr(docs_command, "get_cache_dir", lambda root: cache_dir)

    docs_command.cmd_docs(clear_cache=True)

    assert not cache_dir.exists()
    assert "Cache cleared." in capsys.readouterr().out


def test_docs_cache_ignores_corrupt_json(tmp_path: Path):
    cache_dir = tmp_path / ".mint" / "docs-cache"
    cache_dir.mkdir(parents=True)
    (cache_dir / "fingerprints.json").write_text("not json")
    (cache_dir / "python.json").write_text("not json")

    assert is_cache_fresh(cache_dir, "python", tmp_path) is False
    assert read_cache(cache_dir, "python") is None


def test_docs_toc_lists_workflow_guides(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs()

    output = capsys.readouterr().out
    assert "mint docs frontend choose" in output
    assert "mint docs frontend consolidate" in output
    assert "mint docs frontend sidebar" in output
    assert "mint docs frontend <name>" in output
    assert "mint docs frontend-api" in output
    assert "mint docs deprecated-apis" in output
    assert "mint docs r-bridge" in output
    assert "mint add data-template-preset --list" in output
    assert "mint docs template-pack cell-culture-screen" in output
    assert "mint docs template-preset wellplate-screen" in output


def test_docs_frontend_overview_uses_generic_lookup_hint(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend"])

    output = capsys.readouterr().out
    assert "functions" in output
    assert "mint docs frontend <name>" in output
    assert "mint docs frontend <ComponentName>" not in output


def test_docs_toc_json_lists_guides(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["guides"]["frontend-choose"] == "mint docs frontend choose"
    assert payload["guides"]["frontend-consolidation"] == "mint docs frontend consolidate"
    assert payload["guides"]["frontend-sidebar"] == "mint docs frontend sidebar"
    assert payload["guides"]["frontend-api"] == "mint docs frontend-api"
    assert payload["guides"]["deprecated-apis"] == "mint docs deprecated-apis"
    assert payload["guides"]["r-bridge"] == "mint docs r-bridge"
    assert payload["guides"]["template-pack"] == "mint docs template-pack <name>"
    assert payload["guides"]["template-preset"] == "mint docs template-preset <name>"
    assert payload["guides"]["add-template-preset"] == "mint add data-template-preset <name> --page"


def test_docs_frontend_api_migration_prints_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend-api"])

    output = capsys.readouterr().out
    assert "Frontend API migration" in output
    assert "VITE_API_PREFIX" in output
    assert "useApi({ baseUrl })" in output
    assert "api.get('/api/<plugin>/...')" in output
    assert "mint sdk generate" in output
    assert "mint docs contract ." in output
    assert "useGeneratedPluginClient" in output
    assert "useGeneratedPluginContract" in output
    assert "pluginContract.buildEndpointUrl" in output
    assert "useTemplateCollection()" in output
    assert "mint doctor --explain" in output


def test_skill_docs_prefer_root_imports_and_generated_clients():
    repo_root = Path(__file__).resolve().parents[3]
    skill_dir = repo_root / "skills" / "mint-sdk-plugin"
    skill_docs = [
        skill_dir / "SKILL.md",
        skill_dir / "references" / "frontend-sdk.md",
        skill_dir / "references" / "quick-start-templates.md",
        skill_dir / "references" / "guideline.md",
        skill_dir / "references" / "integration.md",
        skill_dir / "references" / "python-backend.md",
        skill_dir / "references" / "troubleshooting.md",
    ]

    for path in skill_docs:
        content = path.read_text()
        assert "from '@morscherlab/mint-sdk/components'" not in content, path
        assert "from '@morscherlab/mint-sdk/composables'" not in content, path
        assert "const api = useApi({ baseUrl" not in content, path
        assert "import.meta.env.VITE_API_PREFIX || '/api" not in content, path
        for match in re.finditer(r"PluginNavItem\((?P<body>[\s\S]*?)\)", content):
            assert "icon=" in match.group("body"), f"{path}: {match.group(0)}"

    starter_text = "\n".join(path.read_text() for path in skill_docs)
    assert "useGeneratedPluginClient" in starter_text
    assert "defineControlModel" in starter_text
    assert "mint docs frontend consolidate" in starter_text
    assert "config.dev.toml" in starter_text
    assert "homepage cards, plugin view headers" in starter_text
    assert '[[proxy."/my-plugin".nav_items]]' in starter_text
    assert "settings_model = AnalysisSettings" in starter_text
    assert "`settings_model` auto-generates `get_configurable_settings()`" in starter_text
    assert "controlOptions.initialValues" in starter_text


def test_docs_frontend_component_consolidation_prints_strategy(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "consolidate"])

    output = capsys.readouterr().out
    assert "Frontend component consolidation" in output
    assert "PluginWorkspaceView" in output
    assert "experimentShell" in output
    assert "sidebarContentId/showSidebarWhenEmpty" in output
    assert "manual AppLayout + AppTopBar + AppSidebar shell" in output
    assert "ControlWorkspaceView, defineControlModel" in output
    assert "manual AppLayout + AppTopBar + FormBuilder page" in output
    assert "manual AppLayout + AppSidebar + FormBuilder page" in output
    assert "useControlWorkspace(model.controls, model.controlOptions)" in output
    assert "controlOptions.initialValues" in output
    assert "FormBuilder, AppSidebar, SettingsModal, and ControlWorkspaceView read the same values" in output
    assert "shared LEAF-style plugin sidebar design language" in output
    assert "FormBuilder, SettingsModal, defineControlModel" in output
    assert "manual SettingsModal tabs for basic fields" in output
    assert "DoseDesignWorkspaceView, defineDoseDesignControlModel, defineWellPlateDoseComponentBindings" in output
    assert "hand-wired ControlWorkspaceView dose-design slots" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert "manual WellPlate + DoseCalculator prop mapping" in output
    assert "manual componentBindingsById bookkeeping" in output
    assert "custom low-level prop maps via defineWellPlateDoseControlProps" in output
    assert "AppToastContainer, useGeneratedPluginClient" in output
    assert "Retired API cleanup:" in output
    assert "avoid FormSection -> prefer FormBuilder" in output
    assert "avoid FormFieldRenderer -> prefer FormBuilder" in output
    assert "avoid SettingsButton -> prefer AppTopBar settingsConfig or SettingsModal" in output
    assert "avoid AppPageSelector -> prefer AppTopBar pageSelector" in output
    assert "avoid AppPillNav -> prefer AppTopBar pillNav" in output
    assert "avoid GroupingModal -> prefer AutoGroupModal" in output
    assert "avoid ToastNotification -> prefer AppToastContainer" in output
    assert "avoid usePluginApi -> prefer useGeneratedPluginClient" in output
    assert "Legacy prop patterns:" in output
    assert "AppSidebar items / active-id" in output
    assert 'variant="analysis" for LEAF-style analysis chrome' in output
    assert "ControlWorkspaceView/DoseDesignWorkspaceView navigation prop" in output
    assert "mint doctor --explain" in output
    assert "mint docs deprecated-apis" in output


def test_docs_frontend_component_consolidation_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["component-consolidation"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "frontend-component-consolidation"
    assert payload["command"] == "mint docs frontend consolidate"
    assert payload["layers"][0]["canonical"] == ["PluginWorkspaceView"]
    assert "manual AppLayout + AppTopBar + AppSidebar shell" in payload["layers"][0]["folds"]
    assert "dual sidebars" in payload["layers"][0]["drop_down_only_for"]
    assert payload["layers"][1]["canonical"] == ["ControlWorkspaceView", "defineControlModel"]
    assert "manual AppLayout + AppTopBar + FormBuilder page" in payload["layers"][1]["folds"]
    assert "manual AppLayout + AppSidebar + FormBuilder page" in payload["layers"][1]["folds"]
    assert any("controlOptions.initialValues" in item for item in payload["principles"])
    assert any("LEAF-style plugin sidebar design language" in item for item in payload["principles"])
    assert any("PluginWorkspaceView" in item for item in payload["principles"])
    assert any("experimentShell" in item for item in payload["principles"])
    assert any("sidebarContentId/showSidebarWhenEmpty" in item for item in payload["principles"])
    assert "manual access to generated component bindings or props" in payload["layers"][1]["drop_down_only_for"]
    assert "FormSection" in payload["layers"][2]["folds"]
    assert payload["layers"][4]["canonical"] == [
        "DoseDesignWorkspaceView",
        "defineDoseDesignControlModel",
        "defineWellPlateDoseComponentBindings",
    ]
    assert "hand-wired ControlWorkspaceView dose-design slots" in payload["layers"][4]["folds"]
    assert "manual componentBindingsById bookkeeping" in payload["layers"][4]["folds"]
    assert "custom WellPlate + DoseCalculator layouts" in payload["layers"][4]["drop_down_only_for"]
    assert (
        "custom low-level prop maps via defineWellPlateDoseControlProps"
        in payload["layers"][4]["drop_down_only_for"]
    )
    assert "usePluginApi" in payload["layers"][-1]["folds"]
    assert payload["retired_apis"][0]["avoid"] == "FormSection"
    assert {
        item["avoid"]: item["prefer"]
        for item in payload["retired_apis"]
    }["AppPageSelector"] == "AppTopBar pageSelector"
    assert {
        item["avoid"]: item["prefer"]
        for item in payload["retired_apis"]
    }["AppPillNav"] == "AppTopBar pillNav"
    assert {
        item["avoid"]: item["prefer"]
        for item in payload["retired_apis"]
    }["usePluginApi"] == "useGeneratedPluginClient"
    assert payload["legacy_prop_patterns"][0]["prefer"] == "PluginWorkspaceView"
    assert payload["legacy_prop_patterns"][1]["avoid"].startswith("AppSidebar items")


def test_docs_frontend_sidebar_language_prints_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "sidebar"])

    output = capsys.readouterr().out
    assert "Frontend sidebar language" in output
    assert 'AppSidebar variant="analysis"' in output
    assert "MS Designer: 20rem sidebar" in output
    assert "DRP: AppSidebar panels/slots" in output
    assert "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty + Teleport" in output
    assert '<Teleport to="#seqgen-sidebar" defer><SequenceSettings /></Teleport>' in output
    assert "AppSidebar footer slot" in output
    assert "mint doctor --explain" in output


def test_docs_frontend_sidebar_language_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend-sidebar"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["command"] == "mint docs frontend sidebar"
    assert payload["canonical_component"] == 'AppSidebar variant="analysis"'
    assert any("pinned action bar" in item for item in payload["source_patterns"])
    assert any("sidebarContentId/showSidebarWhenEmpty" in item for item in payload["principles"])
    assert {
        item["from"]: item["to"]
        for item in payload["migration_targets"]
    }['manual <div id="...sidebar"> shell'] == "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty"


def test_docs_frontend_api_migration_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["contract-migration"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "frontend-api"
    assert "useApi({ baseUrl })" in payload["legacy_patterns"]
    assert "api.get('/api/<plugin>/...')" in payload["legacy_patterns"]
    assert "mint docs contract ." in payload["commands"]
    assert "buildEndpointUrl" in payload["endpoint_url"]
    assert "useTemplateCollection()" in payload["platform_data_helpers"]


def test_docs_deprecated_apis_prints_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["deprecated-apis"])

    output = capsys.readouterr().out
    assert "Deprecated SDK APIs" in output
    assert "mld_sdk -> mint_sdk" in output
    assert "mld-sdk -> mint-sdk" in output
    assert "@morscherlab/mld-sdk -> @morscherlab/mint-sdk" in output
    assert "mld <command> -> mint <command>" in output
    assert 'get_frontend_config()["navItems"] -> PluginMetadata.nav_items' in output
    assert (
        'PluginNavItem(path="/", label="Dashboard", id="dashboard", icon="M3 13h8", '
        'description="Plugin overview")'
    ) in output
    assert "PluginExperimentData -> DesignData" in output
    assert "AnalysisPlugin.local_db -> AnalysisPlugin.standalone_db" in output
    assert "AnalysisPlugin.get_local_models() -> AnalysisPlugin.get_shared_models()" in output
    assert "AnalysisPlugin._setup_local_database() / _teardown_local_database()" in output
    assert "AppPageSelector -> AppTopBar" in output
    assert "AppPillNav -> AppTopBar" in output
    assert "GroupingModal -> AutoGroupModal" in output
    assert "ToastNotification -> AppToastContainer" in output
    assert "SettingsButton -> AppTopBar" in output
    assert "FormSection -> FormBuilder" in output
    assert "FormFieldRenderer -> FormBuilder" in output
    assert "usePluginApi() -> useGeneratedPluginClient()" in output
    assert "UsePluginApiOptions -> CreatePluginClientOptions / generated client types" in output
    assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in output
    assert "AppSidebar items / active-id" in output
    assert "AppTopBar floating / sticky" in output
    assert "AppTopBar pluginName" in output
    assert "AppTopBar pages / current-page-id / tabs / current-tab-id" in output
    assert "PluginWorkspaceView pages / current-page-id / tabs / current-tab-id" in output
    assert "ControlWorkspaceView navigation prop" in output
    assert "DoseDesignWorkspaceView navigation prop" in output
    assert "controlsToTopBarTabs() / topBarTabs" in output
    assert "controlsToViewItems() / topBar" in output
    assert 'ControlWorkspaceView v-bind="workspaceModel"' in output
    assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" />' in output
    assert "Doctor scans:" in output
    assert "dynamic SDK import destructuring" in output
    assert "dynamic SDK namespace access" in output
    assert "dynamic component references" in output
    assert "mint doctor --explain" in output


def test_docs_deprecated_apis_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["legacy-apis"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "deprecated-apis"
    assert any(item["old"] == "AppPageSelector" and item["new"] == "AppTopBar" for item in payload["replacements"])
    assert any(item["old"] == "AppPillNav" and item["new"] == "AppTopBar" for item in payload["replacements"])
    assert any(item["old"] == "GroupingModal" for item in payload["replacements"])
    assert any(item["old"] == "ToastNotification" for item in payload["replacements"])
    assert any(item["old"] == "SettingsButton" and item["new"] == "AppTopBar" for item in payload["replacements"])
    assert any(item["old"] == "FormSection" and item["new"] == "FormBuilder" for item in payload["replacements"])
    assert any(item["old"] == "FormFieldRenderer" and item["new"] == "FormBuilder" for item in payload["replacements"])
    assert any(item["old"] == "usePluginApi()" for item in payload["replacements"])
    assert any(
        item["old"] == "UsePluginApiOptions"
        and item["new"] == "CreatePluginClientOptions / generated client types"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == 'get_frontend_config()["navItems"]'
        and item["new"] == "PluginMetadata.nav_items"
        and 'id="dashboard"' in item["example"]
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "PluginExperimentData" and item["new"] == "DesignData"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "AnalysisPlugin.local_db"
        and item["new"] == "AnalysisPlugin.standalone_db"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "AnalysisPlugin.get_local_models()"
        and item["new"] == "AnalysisPlugin.get_shared_models()"
        for item in payload["replacements"]
    )
    assert any(item["new"] == "AppTopBar variant" for item in payload["replacements"])
    assert any(
        item["old"] == "AppTopBar pluginName"
        and item["new"] == "AppTopBar title/subtitle or pageSelector"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "AppTopBar pages / current-page-id / tabs / current-tab-id"
        and item["new"] == "AppTopBar pageSelector / current-page-selector-id / pillNav / current-pill-id"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "ControlWorkspaceView navigation prop"
        and item["new"] == "ControlWorkspaceView default pill navigation"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "DoseDesignWorkspaceView navigation prop"
        and item["new"] == "DoseDesignWorkspaceView default pill navigation"
        and item["example"] == '<DoseDesignWorkspaceView v-model="values" title="Dose Design" />'
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == "controlsToTopBarTabs() / topBarTabs"
        and item["new"] == "controlsToViewItems() / topBar"
        for item in payload["replacements"]
    )
    assert any(
        item["old"] == 'ControlWorkspaceView v-bind="workspaceModel"'
        and item["new"] == 'ControlWorkspaceView :model="workspaceModel"'
        and item["example"] == '<ControlWorkspaceView v-model="values" :model="workspaceModel" />'
        for item in payload["replacements"]
    )
    assert any("legacy frontend API helpers" in item for item in payload["coverage"])
    assert any("dynamic SDK import destructuring" in item for item in payload["coverage"])
    assert any("direct dynamic SDK import member access" in item for item in payload["coverage"])
    assert any("dynamic SDK namespace access" in item for item in payload["coverage"])
    assert any("Python compatibility aliases" in item for item in payload["coverage"])
    assert any("dynamic component references" in item for item in payload["coverage"])
    assert any("long-form Vue bindings" in item for item in payload["coverage"])
    assert any("agent instructions" in item for item in payload["coverage"])
    assert "mint docs frontend-api" in payload["follow_ups"]


def test_docs_frontend_deprecated_component_points_to_replacement(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "GroupingModal"])

    output = capsys.readouterr().out
    assert "Deprecated" in output
    assert "use: AutoGroupModal" in output
    assert "mint docs frontend AutoGroupModal" in output

    docs_command.cmd_docs(path_args=["frontend", "ToastNotification"])
    toast_output = capsys.readouterr().out
    assert "Deprecated" in toast_output
    assert "use: AppToastContainer" in toast_output
    assert "mint docs frontend AppToastContainer" in toast_output

    docs_command.cmd_docs(path_args=["frontend", "AppToastContainer"])
    preferred_output = capsys.readouterr().out
    assert "AppToastContainer" in preferred_output
    assert "Preferred toast container" in preferred_output

    docs_command.cmd_docs(path_args=["frontend", "FormSection"])
    form_section_output = capsys.readouterr().out
    assert "Deprecated" in form_section_output
    assert "use: FormBuilder" in form_section_output
    assert "mint docs frontend FormBuilder" in form_section_output

    docs_command.cmd_docs(path_args=["frontend", "SettingsButton"])
    settings_button_output = capsys.readouterr().out
    assert "Deprecated" in settings_button_output
    assert "use: AppTopBar" in settings_button_output
    assert "mint docs frontend AppTopBar" in settings_button_output

    docs_command.cmd_docs(path_args=["frontend", "AppPageSelector"])
    page_selector_output = capsys.readouterr().out
    assert "Deprecated" in page_selector_output
    assert "use: AppTopBar" in page_selector_output
    assert "mint docs frontend AppTopBar" in page_selector_output

    docs_command.cmd_docs(path_args=["frontend", "AppPillNav"])
    pill_nav_output = capsys.readouterr().out
    assert "Deprecated" in pill_nav_output
    assert "use: AppTopBar" in pill_nav_output
    assert "mint docs frontend AppTopBar" in pill_nav_output


def test_docs_frontend_deprecated_composable_points_to_replacement(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "usePluginApi"])

    output = capsys.readouterr().out
    assert "usePluginApi" in output
    assert "Deprecated" in output
    assert "use: useGeneratedPluginClient" in output
    assert "mint docs deprecated-apis" in output


def test_docs_frontend_app_topbar_prefers_page_selector_and_pill_nav(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "AppTopBar"])

    output = capsys.readouterr().out
    assert "Preferred route-level page switch entries" in output
    assert "Integrated plugins read platform plugin.nav_items metadata automatically" in output
    assert "Preferred centered navigation for local modes" in output
    assert "Compatibility page dropdown items. Prefer pageSelector" not in output
    assert "Compatibility center tabs. Prefer pillNav" not in output
    assert "\n  pluginName" not in output
    assert "\n  pages" not in output
    assert "\n  currentPageId" not in output
    assert "\n  tabs" not in output
    assert "\n  currentTabId" not in output


def test_docs_search_finds_app_topbar_plugin_nav_metadata(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "AppTopBar plugin nav_items metadata"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert any(
        result["category"] == "components"
        and result["name"] == "AppTopBar"
        and "plugin.nav_items" in result["match_context"]
        for result in payload
    )


def test_docs_frontend_component_lists_mark_deprecated_replacements(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "components"])

    output = capsys.readouterr().out
    assert "canonical components" in output
    assert "0 deprecated entries" in output
    assert "Deprecated entries" not in output
    assert "GroupingModal" not in output
    assert "ToastNotification" not in output
    assert "mint docs frontend <name>" in output
    assert "mint docs frontend <ComponentName>" not in output

    docs_command.cmd_docs(path_args=["frontend", "components", "sample"])
    group_output = capsys.readouterr().out
    assert "Deprecated entries" not in group_output
    assert "GroupingModal" not in group_output
    assert "Use: mint docs frontend <name> for full component reference" in group_output
    assert "mint docs frontend <ComponentName>" not in group_output

    docs_command.cmd_docs(path_args=["frontend", "components", "feedback"])
    feedback_output = capsys.readouterr().out
    assert "AppToastContainer" in feedback_output
    assert "ToastNotification" not in feedback_output

    docs_command.cmd_docs(path_args=["frontend", "components", "action"])
    action_output = capsys.readouterr().out
    assert "SettingsButton" not in action_output

    docs_command.cmd_docs(path_args=["frontend", "components", "form"])
    form_output = capsys.readouterr().out
    assert "FormBuilder" in form_output
    assert "FormSection" not in form_output
    assert "FormFieldRenderer" not in form_output


def test_docs_frontend_components_json_marks_canonical_status(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "components"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    by_name = {item["name"]: item for item in payload}
    assert by_name["ControlWorkspaceView"]["status"] == "canonical"
    assert by_name["ControlWorkspaceView"]["docs"] == "mint docs frontend ControlWorkspaceView"
    assert "GroupingModal" not in by_name
    assert all(item["status"] == "canonical" for item in payload)

    docs_command.cmd_docs(path_args=["frontend", "components", "sample"], json_output=True)

    group_payload = json.loads(capsys.readouterr().out)
    assert any(
        item["name"] == "SampleSelector" and item["status"] == "canonical"
        for item in group_payload
    )
    assert all(item["name"] != "GroupingModal" for item in group_payload)


def test_docs_frontend_composables_use_generic_lookup_hint(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "composables"])

    output = capsys.readouterr().out
    assert "Use: mint docs frontend <name> for full composable reference" in output
    assert "mint docs frontend <composableName>" not in output


def test_docs_search_finds_deprecated_api_guide(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "deprecated"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert any(result["name"] == "deprecated-apis" for result in payload)


def test_docs_contract_prints_endpoint_summary(tmp_path: Path, monkeypatch, capsys):
    project = _make_scaffold(tmp_path)
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["contract", str(project)])

    output = capsys.readouterr().out
    assert "Plugin contract: my-analyzer" in output
    assert "GET /api/my-analyzer/health" in output
    assert "POST /api/my-analyzer/analyze/{experiment_id}" in output
    assert "client: pluginClient.analyze({ body })" in output
    assert "path params: experimentId?: number" in output
    assert "inferred params: experimentId from current experiment context or route" in output
    assert "body: AnalyzeRequest" in output
    assert "returns: AnalyzeResponse" in output
    assert "Generated frontend client:" in output
    assert "frontend/src/generated/mint-plugin.ts" in output
    assert "useGeneratedPluginClient" in output
    assert "useGeneratedPluginContract" in output
    assert "const pluginClient = useGeneratedPluginClient()" in output
    assert "const pluginContract = useGeneratedPluginContract()" in output
    assert "const contractHash = pluginContract.contractHash" in output
    assert "const apiPrefix = pluginContract.apiPrefix" in output
    assert "const routesPrefix = pluginContract.routesPrefix" in output
    assert "const pageSelector = pluginContract.pageSelectorItems" in output
    assert "const endpointNames = pluginContract.endpoints" in output
    assert "const endpointDefinitions = pluginContract.endpointDefinitions" in output
    assert "const analyzeEndpoint = pluginContract.getEndpoint('analyze')" in output
    assert "pluginContract.hasEndpoint('analyze')" in output
    assert "const analyzeUrl = pluginContract.buildEndpointUrl('analyze', { body })" in output
    assert "await pluginClient.analyze({ body })" in output
    assert "Settings:" in output
    assert "  (none)" in output
    assert "mint sdk generate --check" in output


def test_docs_contract_prints_settings_summary(tmp_path: Path, monkeypatch, capsys):
    project = _make_scaffold(tmp_path)
    cmd_add_setting(
        path=str(project),
        name="threshold",
        field_type=SettingType.number,
        default="0.05",
        description="Significance threshold",
    )
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["contract", str(project)])

    output = capsys.readouterr().out
    assert "Settings:" in output
    assert "model: MyAnalyzerSettings" in output
    assert "frontend: useGeneratedPluginSettings()" in output
    assert "useGeneratedPluginSettings" in output
    assert "useGeneratedPluginContract" in output
    assert "const settings = useGeneratedPluginSettings()" in output
    assert "fields: threshold?: number" in output


def test_docs_frontend_lists_contract_client_helpers(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "buildPluginEndpointUrl"])

    output = capsys.readouterr().out
    assert "buildPluginEndpointUrl" in output
    assert "Build the concrete URL for a generated plugin endpoint" in output
    assert "PluginEndpointDefinition" in output
    assert "BuildPluginEndpointUrlOptions" in output


def test_docs_frontend_lists_control_schema_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useControlSchema"])

    output = capsys.readouterr().out
    assert "useControlSchema" in output
    assert "Prepare FormBuilder, SettingsModal, AppTopBar settings, AppSidebar, and initial values" in output
    assert "ControlSchemaOptions" in output
    assert "sectionSchemas" in output
    assert "settingsSchema" in output
    assert "topBarSettings" in output


def test_docs_frontend_lists_control_model_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "defineControlModel"])

    output = capsys.readouterr().out
    assert "defineControlModel" in output
    assert "Create a complete workspace component binding from a simple controls data model" in output
    assert "prefer DoseDesignWorkspaceView" in output
    assert "custom ControlWorkspaceView layout" in output
    assert "const workspaceModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })" in output
    assert "componentBindingsById" in output
    assert "defineDoseDesignControlModel" in output
    assert "selectedWells" in output
    assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Design"' in output
    assert "WellPlate selection updates values.selectedWells" in output
    assert "DoseCalculator Apply writes concentration results into values.wells" in output
    assert '<WellPlate v-bind="componentBindingsById.plate.props" />' in output
    assert '<DoseCalculator v-bind="componentBindingsById.dose.props" />' in output


def test_docs_frontend_lists_dose_design_control_model_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "defineDoseDesignControlModel"])

    output = capsys.readouterr().out
    assert "defineDoseDesignControlModel" in output
    assert "complete ControlWorkspaceView model for WellPlate + DoseCalculator" in output
    assert "prefer DoseDesignWorkspaceView" in output
    assert "custom ControlWorkspaceView layout" in output
    assert "const workspaceModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })" in output
    assert '<WellPlate v-bind="componentBindingsById.plate.props" />' in output
    assert '<DoseCalculator v-bind="componentBindingsById.dose.props" />' in output


def test_docs_frontend_lists_component_binding_helpers(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "defineControlComponentBindings"])
    output = capsys.readouterr().out
    assert "defineControlComponentBindings" in output
    assert "generated workspace component bindings" in output

    docs_command.cmd_docs(path_args=["frontend", "defineWellPlateDoseComponentBindings"])
    output = capsys.readouterr().out
    assert "defineWellPlateDoseComponentBindings" in output
    assert "WellPlate + DoseCalculator component bindings" in output

    docs_command.cmd_docs(path_args=["frontend", "controlValuesToComponentBindings"])
    output = capsys.readouterr().out
    assert "controlValuesToComponentBindings" in output
    assert "direct slot rendering" in output


def test_docs_frontend_lists_app_experiment_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useAppExperiment"])

    output = capsys.readouterr().out
    assert "useAppExperiment" in output
    assert "Manages the current experiment selection" in output
    assert "Usage" in output
    assert "import { AppTopBar, useAppExperiment, useCurrentExperiment } from '@morscherlab/mint-sdk'" in output
    assert "const currentExperiment = useCurrentExperiment()" in output
    assert "const appExperiment = useAppExperiment({" in output
    assert "experiment: currentExperiment.experiment" in output
    assert "onSelect: experiment =>" in output
    assert "currentExperimentId.value = experiment.id" in output
    assert "onDetach: () =>" in output
    assert "await saveCurrent()" in output
    assert "return 'Saved to experiment'" in output
    assert "AppTopBar reads the provided experiment context automatically." in output
    assert '<AppTopBar title="Analysis" :page-selector="pageSelector" />' in output
    assert '<ExperimentPopover v-bind="appExperiment.popover.value" />' in output
    assert '<ExperimentSelectorModal v-bind="appExperiment.selectorModal.value" />' in output


def test_docs_frontend_lists_control_workspace_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useControlWorkspace"])

    output = capsys.readouterr().out
    assert "useControlWorkspace" in output
    assert "Prepare shared reactive values plus AppTopBar/AppSidebar/FormBuilder bindings" in output
    assert "simple controls data model" in output
    assert "ControlWorkspaceView" in output
    assert "import { ref } from 'vue'" in output
    assert "const values = ref({})" in output
    assert "defineControlModel" in output
    assert "const workspaceModel = defineControlModel({" in output
    assert "icon: 'M8 5v14l11-7z'" in output
    assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Analysis" />' in output
    assert 'navigation="tabs"' not in output
    assert "Use useControlWorkspace(...) only when you need manual bindings." in output
    assert "const workspace = useControlWorkspace(workspaceModel)" in output
    assert "const { form, sidebar, topBar } = workspace.bindings" in output
    assert '<FormBuilder v-bind="form" />' in output
    assert '<AppSidebar v-bind="sidebar" />' in output
    assert '<AppTopBar v-bind="topBar" />' in output
    assert "const componentPropsById = workspace.componentPropsById" in output
    assert "const componentProps = workspace.getComponentProps({ threshold: 'threshold' })" in output
    assert "const componentBindings = workspace.componentBindings" in output
    assert '<YourComponent v-bind="componentProps" />' in output
    assert '<WellPlate v-bind="componentPropsById.plate" />' in output
    assert '<WellPlate v-bind="componentBindings.value[0].props" />' in output
    assert "ControlWorkspaceOptions" in output
    assert "UseControlWorkspaceReturn" in output


def test_docs_frontend_lists_control_workspace_view_v_model(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "ControlWorkspaceView"])

    output = capsys.readouterr().out
    assert "ControlWorkspaceView" in output
    assert "modelValue" in output
    assert "Supports default v-model" in output
    assert "Usage" in output
    assert "import { ComponentBindingRenderer, ControlWorkspaceView, defineControlModel }" in output
    assert "const workspaceModel = defineControlModel({" in output
    assert "icon: 'M8 5v14l11-7z'" in output
    assert (
        '<ControlWorkspaceView v-model="values" :model="workspaceModel" title="Analysis" '
        'sidebar-title="Run Controls" />'
    ) in output
    assert 'navigation="tabs"' not in output
    assert "components: {" in output
    assert "plate: { component: 'WellPlate'" in output
    assert 'v-slot="{ componentBindings }"' in output
    assert '<ComponentBindingRenderer :bindings="componentBindings" />' in output
    assert (
        '<ControlWorkspaceView v-model="values" :model="workspaceModel" :form-loading="saving" '
        ':form-enhancements="enhancements" />'
    ) in output
    assert "update:modelValue" in output
    assert "v-model:values" in output
    assert "submit" in output
    assert "cancel" in output
    assert "sidebarVariant" in output
    assert "`analysis` matches the LEAF-style MINT analysis sidebar design language" in output


def test_docs_frontend_lists_plugin_workspace_view(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "PluginWorkspaceView"])

    output = capsys.readouterr().out
    assert "PluginWorkspaceView" in output
    assert "Standard plugin workspace shell" in output
    assert "import { PluginWorkspaceView, useCurrentExperiment } from '@morscherlab/mint-sdk'" in output
    assert "import { ref } from 'vue'" in output
    assert "DoseCalculator, WellPlate, defineDoseDesignControlModel" in output
    assert "const pillNav = [{ id: 'data', label: 'Data' }, { id: 'results', label: 'Results' }]" in output
    assert "const panels = { data: [{ id: 'import', label: 'Import' }] }" in output
    assert "const doseDesignModel = defineDoseDesignControlModel({ selectedWells: ['A1', 'A2'] })" in output
    assert "const doseValues = ref({})" in output
    assert "async function saveCurrent()" in output
    assert '<PluginWorkspaceView title="MS Uploader" :pill-nav="pillNav" :panels="panels" ' in output
    assert 'sidebar-title="Tools" experiment-shell :experiment="currentExperiment.experiment"' in output
    assert ':experiment-save="saveCurrent" @experiment-select="loadExperiment">' in output
    assert '<template #section-import>' in output
    assert '<FileUploader accept=".csv" />' in output
    assert (
        '<PluginWorkspaceView v-model="doseValues" :model="doseDesignModel" '
        'title="Dose Design" v-slot="{ componentBindingsById }">'
    ) in output
    assert '<WellPlate v-bind="componentBindingsById.plate.props" />' in output
    assert '<DoseCalculator v-bind="componentBindingsById.dose.props" />' in output
    assert 'sidebar-content-id="route-sidebar"' in output
    assert 'show-sidebar-when-empty' in output
    assert '<Teleport to="#route-sidebar"><RouteControls /></Teleport>' in output
    assert "<router-view />" in output
    assert "Drop down to AppLayout/AppTopBar/AppSidebar only for unusual chrome." in output
    assert "activeView" in output
    assert "panels" in output
    assert "sidebarVariant" in output
    assert "Compatibility page dropdown entries" not in output
    assert "Compatibility center tabs" not in output
    assert "\n  pages" not in output
    assert "\n  currentPageId" not in output
    assert "\n  tabs" not in output
    assert "\n  currentTabId" not in output


def test_docs_frontend_lists_dose_design_workspace_view_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "DoseDesignWorkspaceView"])

    output = capsys.readouterr().out
    assert "DoseDesignWorkspaceView" in output
    assert "Complete ControlWorkspaceView page shell for WellPlate + DoseCalculator dose design" in output
    assert "Usage" in output
    assert "import { DoseDesignWorkspaceView } from '@morscherlab/mint-sdk'" in output
    assert "const values = ref({ selectedWells: ['A1', 'A2'], plateFormat: 96 })" in output
    assert '<DoseDesignWorkspaceView v-model="values" title="Dose Design" />' in output
    assert ':dose-design-options="{ includeMolecularWeight: true }"' in output
    assert ':well-plate-props="{ heatmap: { enabled: true } }"' in output
    assert 'v-slot="{ wellPlateProps, doseCalculatorProps }"' in output
    assert '<WellPlate v-bind="wellPlateProps" />' in output
    assert '<DoseCalculator v-bind="doseCalculatorProps" />' in output
    assert "Drop down to defineDoseDesignControlModel + ControlWorkspaceView only for custom layouts." in output
    assert "sidebarVariant" in output
    assert "`analysis` matches the LEAF-style MINT analysis sidebar design language" in output


def test_docs_frontend_component_chooser_lists_canonical_paths(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "choose"])

    output = capsys.readouterr().out
    assert "Frontend Component Chooser" in output
    assert "ControlWorkspaceView" in output
    assert "DoseDesignWorkspaceView" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert "BioTemplatePackWorkspaceView" in output
    assert "useBioTemplatePackWorkspace" in output
    assert "defineControlModel" in output
    assert "defineDoseDesignControlModel" in output
    assert (
        "import { DoseDesignWorkspaceView, ControlWorkspaceView, ComponentBindingRenderer, "
        "defineControlModel, defineDoseDesignControlModel } from '@morscherlab/mint-sdk'"
    ) in output
    assert "ComponentBindingRenderer" in output
    assert "componentBindingsById[id].props" in output
    assert "defineControlComponentBindings" in output
    assert "defineWellPlateDoseComponentBindings" in output
    assert "controlValuesToComponentBindings" in output
    assert "controlValuesToComponentBindingsById" in output
    assert "defineWellPlateDoseControlProps" in output
    assert "defineControls" in output
    assert "getComponentProps" in output
    assert "controlValuesToComponentProps" in output
    assert "getBioTemplateComponentProps" in output
    assert "FormBuilder" in output
    assert "SettingsModal" in output
    assert "controlOptions.initialValues" in output
    assert "FormBuilder, AppSidebar, SettingsModal, and ControlWorkspaceView start from the same values" in output
    assert "shared LEAF-style MINT analysis sidebar language" in output
    assert "hand-wired ControlWorkspaceView slots for standard dose-design pages" in output
    assert "hand-wired AppLayout + AppTopBar + FormBuilder pages" in output
    assert "hand-wired AppLayout + AppSidebar + FormBuilder pages" in output
    assert "hand-wired AppTopBar + AppSidebar + FormBuilder pages" in output
    assert "manual SettingsModal tabs for basic fields" in output
    assert "manual WellPlate + DoseCalculator prop mapping" in output
    assert "separate template control forms plus manual component adapters" in output
    assert "raw design_data.templates object plumbing" in output
    assert "Custom plugin chrome and route navigation" in output
    assert "PluginWorkspaceView" in output
    assert "manual AppLayout + AppTopBar + AppSidebar shell" in output
    assert "Only when ControlWorkspaceView is not enough" in output
    assert "useAppExperiment" in output
    assert "manual ExperimentPopover + ExperimentSelectorModal state wiring" in output
    assert "hand-coded page switch data outside PluginMetadata.nav_items" in output
    assert "legacy AppTopBar pages/tabs props" in output
    assert "Avoid in new code" in output
    assert "ToastNotification" in output
    assert "AppToastContainer" in output
    assert "usePluginApi" in output
    assert "useGeneratedPluginClient" in output
    assert "docs: mint docs frontend-api" in output
    assert "docs: mint docs frontend AppToastContainer" in output
    assert "Use: mint docs frontend <name> for full reference" in output


def test_docs_frontend_component_chooser_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "chooser"], json_output=True)

    output = json.loads(capsys.readouterr().out)
    assert output["command"] == "mint docs frontend choose"
    assert output["paths"][0]["start"] == [
        "DoseDesignWorkspaceView",
        "ControlWorkspaceView",
        "ComponentBindingRenderer",
        "defineControlModel",
        "defineDoseDesignControlModel",
    ]
    assert "defineControls" in output["paths"][0]["drop_down_to"]
    assert "defineControlComponentBindings" in output["paths"][0]["drop_down_to"]
    assert "defineWellPlateDoseComponentBindings" in output["paths"][0]["drop_down_to"]
    assert "controlValuesToComponentBindings" in output["paths"][0]["drop_down_to"]
    assert "controlValuesToComponentBindingsById" in output["paths"][0]["drop_down_to"]
    assert "ComponentBindingRenderer" in output["paths"][0]["drop_down_to"]
    assert "defineWellPlateDoseControlProps" in output["paths"][0]["drop_down_to"]
    assert "getComponentProps" in output["paths"][0]["drop_down_to"]
    assert "controlValuesToComponentProps" in output["paths"][0]["drop_down_to"]
    assert output["paths"][0]["prefer_over"] == [
        "hand-wired ControlWorkspaceView slots for standard dose-design pages",
        "hand-wired AppLayout + AppTopBar + FormBuilder pages",
        "hand-wired AppLayout + AppSidebar + FormBuilder pages",
        "hand-wired AppTopBar + AppSidebar + FormBuilder pages",
        "manual WellPlate + DoseCalculator prop mapping",
        "manual sidebar/form/component value synchronization",
    ]
    assert "DoseCalculator apply-to-wells syncing" in output["paths"][0]["use_when"]
    assert "standard WellPlate + DoseCalculator pages" in output["paths"][0]["use_when"]
    assert "componentBindingsById[id].props" in output["paths"][0]["use_when"]
    assert "AppSidebar :model" in output["paths"][0]["use_when"]
    assert "shared LEAF-style MINT analysis sidebar language" in output["paths"][0]["use_when"]
    assert output["paths"][0]["preferred_import"] == (
        "import { DoseDesignWorkspaceView, ControlWorkspaceView, ComponentBindingRenderer, "
        "defineControlModel, defineDoseDesignControlModel } from '@morscherlab/mint-sdk'"
    )
    assert (
        "Bind ControlWorkspaceView with v-model when generated component props should update the same values object."
        in output["notes"]
    )
    assert any(
        "controlOptions.initialValues" in note
        and "FormBuilder" in note
        and "AppSidebar" in note
        and "SettingsModal" in note
        for note in output["notes"]
    )
    assert any(
        "Import public components and composables from @morscherlab/mint-sdk" in note
        and "@morscherlab/mint-sdk/templates for template helpers" in note
        for note in output["notes"]
    )
    assert any(
        'AppSidebar variant="analysis"' in note
        and "LEAF-style sidebar language" in note
        for note in output["notes"]
    )
    assert any(
        "componentBindingsById[id].props" in note
        and "control model should drive SDK components" in note
        for note in output["notes"]
    )
    assert "BioTemplatePackWorkspaceView" in output["paths"][1]["start"]
    assert output["paths"][1]["preferred_import"] == (
        "import { BioTemplatePackWorkspaceView, BioTemplatePresetWorkspaceView, "
        "useBioTemplatePackWorkspace, useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk'"
    )
    assert "useBioTemplatePackWorkspace" in output["paths"][1]["drop_down_to"]
    assert "BioTemplateExperimentWorkspaceView" in output["paths"][1]["drop_down_to"]
    assert "getBioTemplateComponentProps" in output["paths"][1]["drop_down_to"]
    assert output["paths"][1]["prefer_over"] == [
        "separate template control forms plus manual component adapters",
        "manual PlateMapEditor + WellPlate + SampleLegend wiring",
        "manual DataFrame + SampleSelector + GroupAssigner sample-sheet pages",
        "raw design_data.templates object plumbing",
    ]
    assert output["paths"][2]["start"] == ["FormBuilder", "SettingsModal", "defineControlModel"]
    assert output["paths"][2]["preferred_import"] == (
        "import { FormBuilder, SettingsModal, defineControlModel } from '@morscherlab/mint-sdk'"
    )
    assert "form or settings modal" in output["paths"][2]["use_when"]
    assert "manual FormField + NumberInput/DatePicker/BaseToggle rows" in output["paths"][2]["prefer_over"]
    assert "manual SettingsModal tabs for basic fields" in output["paths"][2]["prefer_over"]
    assert "defineControls" in output["paths"][2]["drop_down_to"]
    assert "NumberInput" in output["paths"][2]["drop_down_to"]
    assert "DatePicker" in output["paths"][2]["drop_down_to"]
    assert "controlsToSettingsSchema" in output["paths"][2]["drop_down_to"]
    assert output["paths"][3]["task"] == "Custom plugin chrome and route navigation"
    assert output["paths"][3]["start"] == ["PluginWorkspaceView", "useAppExperiment"]
    assert output["paths"][3]["preferred_import"] == (
        "import { PluginWorkspaceView, useAppExperiment, useCurrentExperiment } "
        "from '@morscherlab/mint-sdk'"
    )
    assert "Only when ControlWorkspaceView is not enough" in output["paths"][3]["use_when"]
    assert "experiment chip with selector/save/detach wiring" in output["paths"][3]["use_when"]
    assert "experimentShell" in output["paths"][3]["use_when"]
    assert "responsive sidebars" in output["paths"][3]["use_when"]
    assert "route-owned Teleport sidebars with pinned footers" in output["paths"][3]["use_when"]
    assert (
        "PluginWorkspaceView owns the common AppLayout + AppTopBar + AppSidebar shell"
        in output["paths"][3]["use_when"]
    )
    assert "shared LEAF-style sidebar language" in output["paths"][3]["use_when"]
    assert "sidebarContentId/showSidebarWhenEmpty" in output["paths"][3]["use_when"]
    assert "Drop to useAppExperiment only for custom topbar composition" in output["paths"][3]["use_when"]
    assert "manual AppLayout + AppTopBar + AppSidebar shell" in output["paths"][3]["prefer_over"]
    assert "manual AppTopBar + AppPageSelector composition" in output["paths"][3]["prefer_over"]
    assert "manual AppTopBar + AppPillNav composition" in output["paths"][3]["prefer_over"]
    assert (
        "manual ExperimentPopover + ExperimentSelectorModal state wiring"
        in output["paths"][3]["prefer_over"]
    )
    assert "hand-coded page switch data outside PluginMetadata.nav_items" in output["paths"][3]["prefer_over"]
    assert "AppLayout + AppTopBar + AppSidebar for unusual multi-sidebar chrome" in output["paths"][3]["drop_down_to"]
    assert (
        "AppLayout responsiveSidebar / v-model:sidebarOpen with AppSidebar variant=\"analysis\""
        in output["paths"][3]["drop_down_to"]
    )
    assert (
        "AppSidebar contentId / showWhenEmpty for non-workspace sidebar targets"
        in output["paths"][3]["drop_down_to"]
    )
    assert (
        "getPluginPageSelectorItems(contract) for raw contract nav metadata"
        in output["paths"][3]["drop_down_to"]
    )
    assert (
        "AppTopBar pageSelector / current-page-selector-id props for custom page pickers"
        in output["paths"][3]["drop_down_to"]
    )
    assert (
        "AppTopBar pillNav / current-pill-id props, with children for dropdown modes"
        in output["paths"][3]["drop_down_to"]
    )
    assert "useCurrentExperiment for lower-level guards or non-topbar context" in output["paths"][3]["drop_down_to"]
    assert {
        "name": "GroupingModal",
        "replacement": "AutoGroupModal",
        "docs": "mint docs frontend AutoGroupModal",
        "migration_guide": "mint docs deprecated-apis",
    } in output["avoid_in_new_code"]
    assert {
        "name": "usePluginApi",
        "replacement": "useGeneratedPluginClient",
        "docs": "mint docs frontend-api",
        "migration_guide": "mint docs deprecated-apis",
    } in output["avoid_in_new_code"]
    assert any("Run mint docs frontend <name>" in note for note in output["notes"])


def test_docs_frontend_component_chooser_preferred_imports_are_root_exports(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "chooser"], json_output=True)

    output = json.loads(capsys.readouterr().out)
    manifest = docs_command._load_bundled("frontend")
    root_exports = {
        item["name"]
        for item in manifest["exports"]
        if isinstance(item, dict) and isinstance(item.get("name"), str)
    }

    for path in output["paths"]:
        statement = path["preferred_import"]
        if "from '@morscherlab/mint-sdk'" not in statement:
            continue
        imported = re.search(r"import\s*\{(?P<body>.*?)\}", statement)
        assert imported is not None
        names = {
            re.split(r"\s+as\s+", spec.strip(), maxsplit=1)[0].strip()
            for spec in imported.group("body").split(",")
            if spec.strip()
        }
        assert names <= root_exports


def test_docs_frontend_root_exports_dose_calculator_types(monkeypatch):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    manifest = docs_command._load_bundled("frontend")
    root_exports = {
        item["name"]
        for item in manifest["exports"]
        if isinstance(item, dict) and isinstance(item.get("name"), str)
    }

    assert {
        "ConversionResult",
        "DilutionParams",
        "DilutionResult",
        "SerialDilutionParams",
        "SerialDilutionResult",
        "SerialDilutionStep",
        "UseDoseCalculatorReturn",
        "WellConcentration",
    } <= root_exports


def test_docs_frontend_component_chooser_avoid_list_matches_retired_api_catalog(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "chooser"], json_output=True)

    output = json.loads(capsys.readouterr().out)
    manifest = docs_command._load_bundled("frontend")
    components = manifest["categories"]["components"]
    composables = manifest["categories"]["composables"]
    manifest_deprecated = [
        item["name"]
        for item in [*components, *composables]
        if item.get("deprecated") is True
    ]
    expected = {
        "AppPageSelector": "AppTopBar",
        "AppPillNav": "AppTopBar",
        "FormFieldRenderer": "FormBuilder",
        "FormSection": "FormBuilder",
        "GroupingModal": "AutoGroupModal",
        "SettingsButton": "AppTopBar",
        "ToastNotification": "AppToastContainer",
        "usePluginApi": "useGeneratedPluginClient",
        "controlsToTopBarTabs": "controlsToViewItems",
    }
    actual = {item["name"]: item for item in output["avoid_in_new_code"]}

    assert manifest_deprecated == []
    assert set(actual) == set(expected)
    for name, replacement in expected.items():
        assert actual[name]["replacement"] == replacement
        if name.startswith("use") or name == "controlsToTopBarTabs":
            assert actual[name]["docs"] == "mint docs frontend-api"
        else:
            assert actual[name]["docs"] == f"mint docs frontend {replacement}"
        assert actual[name]["migration_guide"] == "mint docs deprecated-apis"


def test_docs_frontend_lists_control_settings_schema_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "controlsToSettingsSchema"])

    output = capsys.readouterr().out
    assert "controlsToSettingsSchema" in output
    assert "Convert controls into a SettingsModal schema" in output


def test_docs_frontend_lists_control_topbar_settings_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "controlsToTopBarSettingsConfig"])

    output = capsys.readouterr().out
    assert "controlsToTopBarSettingsConfig" in output
    assert "passes compact controls through to SettingsModal" in output


def test_docs_frontend_lists_app_sidebar_auto_forms(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "AppSidebar"])

    output = capsys.readouterr().out
    assert "controls" in output
    assert "controlOptions" in output
    assert "ControlWorkspaceOptions" in output
    assert "forms" in output
    assert "modelValue" in output
    assert "values" in output
    assert "update:modelValue" in output
    assert "update:values" in output
    assert "Supports default v-model" in output
    assert "import { AppLayout, AppSidebar, AppTopBar, defineControlModel }" in output
    assert "const sidebarModel = defineControlModel({" in output
    assert '<AppSidebar v-model="values" :model="sidebarModel" />' in output
    assert "LEAF-style analysis sidebar chrome with SDK-owned mobile behavior" in output
    assert '<AppLayout responsive-sidebar sidebar-width="20rem">' in output
    assert 'variant="analysis"' in output
    assert 'title="Peak Picking"' in output
    assert 'subtitle="Current experiment"' in output
    assert "contentId" in output
    assert "showWhenEmpty" in output
    assert "Route-owned sidebar content shell with a pinned action footer" in output
    assert '<AppSidebar variant="analysis" content-id="run-sidebar" show-when-empty>' in output
    assert '<Teleport to="#run-sidebar">' in output
    assert "Prefer ControlWorkspaceView" in output
    assert "Compact control schema" in output
    assert "Model returned by defineControlModel()" in output
    assert "FormBuilder schemas keyed by section ID" in output


def test_docs_frontend_lists_form_builder_control_schema(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "FormBuilder"])

    output = capsys.readouterr().out
    assert "FormBuilder" in output
    assert "controls" in output
    assert "controlOptions" in output
    assert "ControlWorkspaceOptions" in output
    assert "schema" in output
    assert "modelValue" in output
    assert "showActions" in output
    assert "import { FormBuilder, defineControlModel }" in output
    assert "const formModel = defineControlModel({" in output
    assert '<FormBuilder v-model="values" :model="formModel" />' in output


def test_docs_frontend_settings_modal_shows_control_workspace_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "SettingsModal"])

    output = capsys.readouterr().out
    assert "Usage" in output
    assert "import { SettingsModal, defineControlModel }" in output
    assert "const values = ref({})" in output
    assert "const settingsModel = defineControlModel({" in output
    assert '<SettingsModal v-model="open" v-model:values="values" :model="settingsModel" />' in output
    assert "AppTopBar can forward the same model through settingsConfig.model" in output
    assert "ControlWorkspaceOptions" in output


def test_docs_frontend_lists_bio_template_controls(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useBioTemplateControls"])

    output = capsys.readouterr().out
    assert "useBioTemplateControls" in output
    assert "Build FormBuilder schema, AppSidebar panels, and defaults" in output


def test_docs_frontend_lists_bio_template_components(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useBioTemplateComponents"])

    output = capsys.readouterr().out
    assert "useBioTemplateComponents" in output
    assert "WellPlate" in output
    assert "DoseCalculator" in output

    docs_command.cmd_docs(path_args=["frontend", "toBioTemplateComponentBindings"])
    binding_output = capsys.readouterr().out
    assert "toBioTemplateComponentBindings" in binding_output
    assert "concrete props" in binding_output

    docs_command.cmd_docs(path_args=["frontend", "toBioTemplateComponentBindingsById"])
    binding_output = capsys.readouterr().out
    assert "toBioTemplateComponentBindingsById" in binding_output
    assert "stable template component id" in binding_output


def test_docs_frontend_lists_bio_template_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useBioTemplateWorkspace"])

    output = capsys.readouterr().out
    assert "useBioTemplateWorkspace" in output
    assert "BioTemplateRenderer" in output
    assert "AppSidebar" in output
    assert "bindings" in output
    assert "componentUsage" in output


def test_docs_frontend_lists_bio_template_preset_workspace_view(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "BioTemplatePresetWorkspaceView"])

    output = capsys.readouterr().out
    assert "BioTemplatePresetWorkspaceView" in output
    assert "Complete editable WellPlate/DoseCalculator workspace" in output
    assert "import { ref } from 'vue'" in output
    assert "const values = ref({ sampleNames: ['Control', 'Treatment'] })" in output
    assert '<BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen" />' in output
    assert 'v-slot="{ bindings }"' in output
    assert '<WellPlate v-bind="bindings.componentBindingsById.value[\'plate-map:WellPlate\'].props" />' in output
    assert (
        '<DoseCalculator v-bind="bindings.componentBindingsById.value'
        '[\'dose-response:DoseCalculator\'].props" />'
    ) in output
    assert "workspace" in output
    assert "Pass :workspace only when you need lower-level save" in output
    assert "showTemplateSummary" in output
    assert "sidebarVariant" in output


def test_docs_frontend_lists_bio_template_experiment_workspace_view(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "BioTemplateExperimentWorkspaceView"])

    output = capsys.readouterr().out
    assert "BioTemplateExperimentWorkspaceView" in output
    assert "Current-experiment template workspace" in output
    assert "createWellPlateScreenCollection" in output
    assert ':status="{ loading, error, hasExperiment }"' in output
    assert "load: loadCurrent" in output
    assert 'v-slot="{ bindings }"' in output
    assert '<WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />' in output
    assert (
        '<DoseCalculator v-bind="bindings.componentBindingsById'
        '[\'dose-response:DoseCalculator\'].props" />'
    ) in output
    assert "target" in output
    assert "showTemplateSummary" in output


def test_docs_frontend_lists_bio_template_pack_workspace_view(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "BioTemplatePackWorkspaceView"])

    output = capsys.readouterr().out
    assert "BioTemplatePackWorkspaceView" in output
    assert "curated biology template pack" in output
    assert '<BioTemplatePackWorkspaceView pack="cell-culture-screen" />' in output
    assert ':workspace="pack.workspace"' in output
    assert "pack.loadCurrent" in output
    assert 'v-slot="{ bindings }"' in output
    assert '<WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />' in output
    assert (
        '<DoseCalculator v-bind="bindings.componentBindingsById'
        '[\'dose-response:DoseCalculator\'].props" />'
    ) in output
    assert "workspaceOptions" in output


def test_docs_frontend_lists_bio_template_preset_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useBioTemplatePresetWorkspace"])

    output = capsys.readouterr().out
    assert "useBioTemplatePresetWorkspace" in output
    assert "current-experiment save" in output
    assert "controlValues" in output
    assert "componentProps" in output


def test_docs_frontend_lists_bio_template_pack_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useBioTemplatePackWorkspace"])

    output = capsys.readouterr().out
    assert "useBioTemplatePackWorkspace" in output
    assert "curated biology template pack" in output
    assert "const { bindings, saveCurrent }" in output
    assert '<AppTopBar v-bind="bindings.topBar.value" />' in output
    assert '<AppSidebar v-bind="bindings.sidebar" />' in output
    assert '<BioTemplateRenderer v-bind="bindings.renderer" />' in output
    assert '<WellPlate v-bind="bindings.componentBindingsById[\'plate-map:WellPlate\'].props" />' in output
    assert (
        '<DoseCalculator v-bind="bindings.componentBindingsById'
        '[\'dose-response:DoseCalculator\'].props" />'
    ) in output
    assert "await saveCurrent()" in output


def test_docs_frontend_lists_bio_template_component_props_lookup(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "getBioTemplateComponentProps"])

    output = capsys.readouterr().out
    assert "getBioTemplateComponentProps" in output
    assert "Return the first props object for an SDK component" in output


def test_docs_contract_json_outputs_contract(tmp_path: Path, monkeypatch, capsys):
    project = _make_scaffold(tmp_path)
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["contract", str(project)], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["contract"]["plugin"]["routesPrefix"] == "/my-analyzer"
    assert [endpoint["name"] for endpoint in payload["contract"]["endpoints"]] == ["health", "analyze"]
    assert payload["frontendUsage"]["clientHook"] == "const pluginClient = useGeneratedPluginClient()"
    assert payload["frontendUsage"]["contractHook"] == "const pluginContract = useGeneratedPluginContract()"
    assert payload["frontendUsage"]["contractHash"] == "const contractHash = pluginContract.contractHash"
    assert payload["frontendUsage"]["endpointLookup"] == "const analyzeEndpoint = pluginContract.getEndpoint('analyze')"
    assert payload["frontendUsage"]["endpointGuard"] == "pluginContract.hasEndpoint('analyze')"
    assert (
        payload["frontendUsage"]["endpointUrl"]
        == "const analyzeUrl = pluginContract.buildEndpointUrl('analyze', { body })"
    )
    assert payload["frontendUsage"]["apiPrefix"] == "const apiPrefix = pluginContract.apiPrefix"
    assert payload["frontendUsage"]["routesPrefix"] == "const routesPrefix = pluginContract.routesPrefix"
    assert payload["frontendUsage"]["pageSelectorItems"] == (
        "const pageSelector = pluginContract.pageSelectorItems"
    )
    assert payload["frontendUsage"]["endpointNames"] == "const endpointNames = pluginContract.endpoints"
    assert (
        payload["frontendUsage"]["endpointDefinitions"]
        == "const endpointDefinitions = pluginContract.endpointDefinitions"
    )
    assert payload["frontendUsage"]["sampleCall"] == "await pluginClient.analyze({ body })"
    assert payload["frontendUsage"]["settingsHook"] is None
    assert payload["warnings"] == []


def test_docs_template_prints_template_detail(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template", "plate-map"])

    output = capsys.readouterr().out
    assert "Template: plate-map" in output
    assert "from mint_sdk.templates import PlateMapTemplate" in output
    assert "await plugin.save_template(experiment_id, template)" in output
    assert "toPlateMapEditorState" in output
    assert "composable: frontend/src/composables/usePlateMapTemplate.ts" in output
    assert "const template = usePlateMapTemplate()" in output
    assert "await template.loadCurrent()" in output
    assert "await template.saveCurrent()" in output
    assert "workspace view bindings:" in output
    assert "status: { loading: template.loading" in output
    assert "error: template.error" in output
    assert "currentExperimentId: template.currentExperimentId" in output
    assert "lastLoadedAt: template.lastLoadedAt" in output
    assert (
        "actions: { load: template.loadCurrent, "
        "reset: template.resetToDefaultTemplate, save: template.saveCurrent }"
    ) in output
    assert "disabled: !template.hasExperiment" not in output
    assert "generated page auto-loads when currentExperimentId is available" in output
    assert "component usage scaffold:" in output
    assert "toBioTemplateComponentUsage" in output
    assert "usage.sfc" in output
    assert "getPlateMapTemplateSchema" in output
    assert "GET /templates/plate-map/schema" in output
    assert "mint add data-template plate-map" in output


def test_docs_template_prints_dataframe_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template", "sample-sheet"])

    output = capsys.readouterr().out
    assert "toTemplateDataFrame" in output
    assert 'const frame = toTemplateDataFrame(template)' in output
    assert '<DataFrame v-bind="frame" />' in output


def test_docs_template_json_outputs_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template", "dose-response"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "dose-response"
    assert payload["template_id"] == "dose-response"
    assert "toDoseConditions" in payload["frontend_adapters"]
    assert "toBioTemplateComponentUsage" in payload["frontend_component_usage_helpers"]
    assert payload["frontend_composable"] == "useDoseResponseTemplate"
    assert "loadCurrent()" in payload["frontend_current_helpers"]
    assert "error" in payload["frontend_current_helpers"]
    assert "lastLoadedAt" in payload["frontend_current_helpers"]
    assert "lastSavedAt" in payload["frontend_current_helpers"]
    assert "resetToDefaultTemplate()" in payload["frontend_current_helpers"]
    assert any(
        binding.startswith("status: { loading: template.loading")
        for binding in payload["frontend_workspace_bindings"]
    )
    assert (
        "actions: { load: template.loadCurrent, reset: template.resetToDefaultTemplate, "
        "save: template.saveCurrent }"
    ) in payload["frontend_workspace_bindings"]
    assert payload["routes"]["save"] == "POST /templates/dose-response/{experiment_id}"


def test_docs_template_resolves_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template", "wellplate"])

    output = capsys.readouterr().out
    assert "Template: plate-map" in output
    assert "PlateMapTemplate.create_96_well" in output


def test_docs_template_json_resolves_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template", "omics matrix"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "assay-matrix"
    assert payload["template_id"] == "assay-matrix"


def test_docs_template_lists_templates(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template"])

    output = capsys.readouterr().out
    assert "Bio data templates:" in output
    assert "plate-map" in output
    assert "sample-sheet" in output
    assert "sample-prep" in output
    assert "dose-response" in output
    assert "calibration-curve" in output
    assert "time-course" in output
    assert "protocol-steps" in output
    assert "assay-matrix" in output
    assert "reagent-list" in output
    assert "flow-cytometry-panel" in output
    assert "instrument-run" in output
    assert "qpcr-plate" in output
    assert "mint add data-template --list --json" in output
    assert "mint add data-template-pack cell-culture-screen --page" in output
    assert "mint add data-template-preset wellplate-screen --page" in output
    assert "mint add data-template-preset elisa-assay --page" in output
    assert "mint add data-template-preset western-blot-assay --page" in output
    assert "mint docs template-preset wellplate-screen" in output
    assert "mint add data-template plate-map --page" in output


def test_docs_template_preset_prints_preset_detail(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset", "wellplate"])

    output = capsys.readouterr().out
    assert "Template preset: wellplate-screen" in output
    assert "plate-map" in output
    assert "sample-sheet" in output
    assert "dose-response" in output
    assert 'plugin.save_template_preset(experiment_id, "wellplate-screen")' in output
    assert 'save_template_preset_collection(plugin, experiment_id, "wellplate-screen")' in output
    assert "mint add data-template-preset wellplate-screen --page" in output
    assert "create_wellplate_screen_collection" in output
    assert "plugin.save_template_collection" in output
    assert "Aliases: wellplate, well-plate screen, drug screen" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert 'preset="wellplate-screen"' in output
    assert ':workspace="workspace"' not in output
    assert 'label="Well-plate screen"' in output
    assert "extractTemplateCollection(collection)" in output


def test_docs_template_preset_json_resolves_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset", "mass spec batch"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "lcms-batch"
    assert payload["templates"] == ["sample-sheet", "instrument-run", "assay-matrix"]


def test_docs_template_preset_json_resolves_elisa_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset", "immunoassay"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "elisa-assay"
    assert payload["templates"] == ["plate-map", "sample-sheet", "calibration-curve", "assay-matrix"]


def test_docs_template_preset_json_resolves_flow_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset", "facs"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "flow-cytometry-assay"
    assert payload["templates"] == ["sample-sheet", "flow-cytometry-panel", "assay-matrix"]


def test_docs_template_preset_json_resolves_western_blot_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset", "immunoblot"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "western-blot-assay"
    assert payload["templates"] == ["sample-sheet", "reagent-list", "protocol-steps", "assay-matrix"]


def test_docs_template_preset_lists_presets(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-preset"])

    output = capsys.readouterr().out
    assert "Bio data template presets:" in output
    assert "wellplate-screen" in output
    assert "qpcr-expression" in output
    assert "lcms-batch" in output
    assert "elisa-assay" in output
    assert "flow-cytometry-assay" in output
    assert "western-blot-assay" in output
    assert "aliases: western blot, western-blot, immunoblot" in output


def test_docs_template_pack_prints_pack_detail(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-pack", "cell-culture-screen"])

    output = capsys.readouterr().out
    assert "Template pack: cell-culture-screen" in output
    assert "sample-sheet" in output
    assert "dose-response" in output
    assert "flow-cytometry-panel" in output
    assert "mint add data-template-pack cell-culture-screen --page" in output
    assert "GET /templates/packs/cell-culture-screen/schema" in output
    assert "POST /templates/packs/cell-culture-screen/{experiment_id}" in output
    assert "useCellCultureScreenTemplatePack" in output
    assert "page: frontend/src/views/CellCultureScreenTemplatePackView.vue" in output
    assert "route: /templates/packs/cell-culture-screen" in output
    assert "await pack.loadCurrent()" in output
    assert "await pack.saveCurrent()" in output
    assert "workspace view bindings:" in output
    assert "status: { loading: pack.loading" in output
    assert "error: pack.error" in output
    assert "currentExperimentId: pack.currentExperimentId" in output
    assert "lastLoadedAt: pack.lastLoadedAt" in output
    assert (
        "actions: { load: pack.loadCurrent, reset: pack.resetToDefaultTemplates, "
        "save: pack.saveCurrent }"
    ) in output
    assert "disabled: !pack.hasExperiment" not in output
    assert "generated page auto-loads when pack.currentExperimentId is available" in output
    assert "pack.applyTemplateCollection(customCollection)" in output
    assert "pack.sampleSheet" in output
    assert "getCellCultureScreenTemplatePack" in output
    assert "mint docs template reagent-list" in output


def test_docs_template_pack_json_resolves_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-pack", "metabolomics"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "omics-assay"
    assert payload["templates"] == [
        "sample-sheet",
        "sample-prep",
        "reagent-list",
        "protocol-steps",
        "instrument-run",
        "calibration-curve",
        "assay-matrix",
    ]
    assert payload["route_prefix"] == "/templates/packs/omics-assay"
    assert payload["frontend_composable"] == "useOmicsAssayTemplatePack"
    assert payload["frontend_view_file"] == "frontend/src/views/OmicsAssayTemplatePackView.vue"
    assert payload["frontend_route"] == "/templates/packs/omics-assay"
    assert payload["routes"]["load"] == "GET /templates/packs/omics-assay/{experiment_id}"
    assert "saveCurrent()" in payload["frontend_current_helpers"]
    assert "error" in payload["frontend_current_helpers"]
    assert "lastLoadedAt" in payload["frontend_current_helpers"]
    assert "lastSavedAt" in payload["frontend_current_helpers"]
    assert "resetToDefaultTemplates()" in payload["frontend_current_helpers"]
    assert any(
        binding.startswith("status: { loading: pack.loading")
        for binding in payload["frontend_workspace_bindings"]
    )
    assert (
        "actions: { load: pack.loadCurrent, reset: pack.resetToDefaultTemplates, "
        "save: pack.saveCurrent }"
    ) in payload["frontend_workspace_bindings"]
    assert payload["typed_template_refs"] == [
        "sampleSheet",
        "samplePrep",
        "reagentList",
        "protocolSteps",
        "instrumentRun",
        "calibrationCurve",
        "assayMatrix",
    ]
    assert "getOmicsAssayTemplatePack" in payload["generated_client_endpoints"]


def test_docs_template_pack_lists_packs(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["template-pack"])

    output = capsys.readouterr().out
    assert "Bio data template packs:" in output
    assert "cell-culture-screen" in output
    assert "omics-assay" in output
    assert "longitudinal-study" in output
    assert "molecular-assay" in output
    assert "mint docs template-pack cell-culture-screen" in output


def test_docs_r_bridge_prints_usage(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["r-bridge"])

    output = capsys.readouterr().out
    assert "R analysis bridge" in output
    assert "save result payloads" in output
    assert "RAnalysisBridge" in output
    assert "RScriptSpec" in output
    assert "plugin.save_analysis(experiment_id, response.result)" in output
    assert "mint add r-analysis drp-fit --page" in output
    assert "POST /r/<analysis>/run/{experiment_id}" in output
    assert "use<Analysis>RAnalysis()" in output
    assert "frontend helper: currentExperimentId" in output
    assert "frontend helper: runCurrentWithParameters(parameters)" in output
    assert "Generated frontend page:" in output
    assert "ControlWorkspaceView" in output
    assert "defineControlModel()" in output
    assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" />' in output
    assert "MINT_R_INPUT" in output
    assert "mint_read_input()" in output
    assert "mint_parameter(name, default)" in output
    assert "mint_required_parameter(name)" in output
    assert "mint_artifact_path(...)" in output
    assert "mint doctor --r --explain" in output
    assert "checks: jsonlite package declaration" in output
    assert "checks: R bridge helper (r_scripts/mint_bridge.R)" in output


def test_docs_r_bridge_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["r-analysis"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert payload["name"] == "r-bridge"
    assert "save result payloads" in payload["purpose"]
    assert payload["route_pattern"] == "POST /r/<analysis>/run/{experiment_id}"
    assert "runCurrent()" in payload["frontend_helpers"]
    assert "defineControlModel()" in payload["generated_frontend_page"]
    assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" />' in payload["generated_frontend_page"]
    assert "RAnalysisBridge" in payload["python_exports"]
    assert "MINT_R_ARTIFACT_DIR" in payload["r_environment"]
    assert "mint_parameter(name, default)" in payload["r_helper_functions"]
    assert "mint_required_parameter(name)" in payload["r_helper_functions"]
    assert "mint_artifact_path(...)" in payload["r_helper_functions"]
    assert "r_scripts/mint_bridge.R" in payload["generated_files"]
    assert "jsonlite package declaration" in payload["diagnostic_checks"]
    assert "R bridge helper (r_scripts/mint_bridge.R)" in payload["diagnostic_checks"]


def test_docs_python_analysis_plugin_lists_template_preset_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["python", "AnalysisPlugin"])

    output = capsys.readouterr().out
    assert "save_template_preset" in output
    assert "save_template_collection" in output
    assert "load_template" in output


def test_docs_python_plugin_nav_item_explains_stable_ids(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["python", "PluginNavItem"])

    output = capsys.readouterr().out
    assert "homepage plugin cards" in output
    assert "generated contracts" in output
    assert "AppTopBar" in output
    assert "id" in output


def test_docs_search_finds_templates(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "plate-map"])

    output = capsys.readouterr().out
    assert "templates" in output
    assert "bio-data" in output
    assert "plate-map" in output
    assert "mint docs template plate-map" in output


def test_docs_search_finds_expanded_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "omics matrix"])

    output = capsys.readouterr().out
    assert "assay-matrix" in output
    assert "mint docs template assay-matrix" in output


def test_docs_search_finds_template_alias(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "wellplate"])

    output = capsys.readouterr().out
    assert "plate-map" in output
    assert "mint docs template plate-map" in output


def test_docs_search_finds_qpcr_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "gene expression"])

    output = capsys.readouterr().out
    assert "qpcr-plate" in output
    assert "mint docs template qpcr-plate" in output


def test_docs_search_finds_sample_prep_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "extraction"])

    output = capsys.readouterr().out
    assert "sample-prep" in output
    assert "mint docs template sample-prep" in output


def test_docs_search_finds_instrument_run_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "sample queue"])

    output = capsys.readouterr().out
    assert "instrument-run" in output
    assert "mint docs template instrument-run" in output


def test_docs_search_finds_calibration_curve_template(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "standard curve"])

    output = capsys.readouterr().out
    assert "calibration-curve" in output
    assert "mint docs template calibration-curve" in output


def test_docs_search_template_json(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "DoseCalculator"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    template_results = [item for item in payload if item["sdk"] == "templates"]
    assert template_results[0]["name"] == "dose-response"
    assert template_results[0]["source"] == "mint docs template dose-response"


def test_docs_search_finds_template_pack(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "drug screen"])

    output = capsys.readouterr().out
    assert "cell-culture-screen" in output
    assert "mint docs template-pack cell-culture-screen" in output


def test_docs_search_finds_frontend_api_migration(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "VITE_API_PREFIX"])

    output = capsys.readouterr().out
    assert "frontend-api" in output
    assert "mint docs frontend-api" in output

    docs_command.cmd_docs(path_args=["search", "backend frontend contract typed client"])
    contract_output = capsys.readouterr().out
    assert "frontend-api" in contract_output
    assert "mint docs frontend-api" in contract_output


def test_docs_search_finds_legacy_nav_items_metadata_guide(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "navItems"])

    output = capsys.readouterr().out
    assert "deprecated-apis" in output
    assert "mint docs deprecated-apis" in output


def test_docs_search_finds_homepage_plugincard_metadata(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "homepage plugincard icon"])

    output = capsys.readouterr().out
    assert "PluginMetadata" in output
    assert "PluginMetadata icon/color/nav_items" in output

    docs_command.cmd_docs(path_args=["search", "plugin page metadata icons"])
    page_output = capsys.readouterr().out
    assert "PluginMetadata" in page_output
    assert "PluginMetadata icon/color/nav_items" in page_output

    docs_command.cmd_docs(path_args=["search", "homepage plugincard page selector"])
    selector_output = capsys.readouterr().out
    assert "PluginMetadata" in selector_output
    assert "getPluginPageSelectorItems" in selector_output


def test_docs_search_finds_current_experiment_topbar_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "current experiment topbar"])

    output = capsys.readouterr().out
    assert "useAppExperiment" in output
    assert "Manages the current experiment selection" in output


def test_docs_search_finds_endpoint_url_builder(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "buildPluginEndpointUrl"])

    output = capsys.readouterr().out
    assert "buildPluginEndpointUrl" in output


def test_docs_search_finds_control_schema_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "AppSidebar panels"])

    output = capsys.readouterr().out
    assert "useControlSchema" in output


def test_docs_search_finds_simple_control_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "simple data model form controls"])

    output = capsys.readouterr().out
    assert "ControlWorkspaceView" in output
    assert "useControlWorkspace" in output
    assert "defineControlModel" in output

    docs_command.cmd_docs(path_args=["search", "simple data model complete control component form"])
    natural_output = capsys.readouterr().out
    assert "ControlWorkspaceView" in natural_output
    assert "defineControlModel" in natural_output


def test_docs_search_finds_generated_form_state_shortcuts(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "saving disabled readonly generated forms"])

    output = capsys.readouterr().out
    assert "ControlWorkspaceView" in output
    assert "AppSidebar" in output


def test_docs_search_finds_frontend_component_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "component chooser"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output

    docs_command.cmd_docs(path_args=["search", "component bindings WellPlate DoseCalculator"])
    binding_output = capsys.readouterr().out
    assert "frontend-component-chooser" in binding_output
    assert "mint docs frontend choose" in binding_output


def test_docs_search_finds_component_value_sync_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "sidebar form model apply-to-wells"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_leaf_style_sidebar_language(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "LEAF-style analysis sidebar design language"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_route_owned_sidebar_shell(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "route-owned sidebar Teleport pinned footer"])

    output = capsys.readouterr().out
    assert "frontend-sidebar-language" in output
    assert "mint docs frontend sidebar" in output
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_sidebar_language_guide(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "MS Designer pinned action bar sidebar"])

    output = capsys.readouterr().out
    assert "frontend-sidebar-language" in output
    assert "mint docs frontend sidebar" in output


def test_docs_search_finds_control_initial_values_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "controlOptions.initialValues"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_component_consolidation_guide(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "redundant components"])

    output = capsys.readouterr().out
    assert "frontend-component-consolidation" in output
    assert "mint docs frontend consolidate" in output


def test_docs_search_finds_root_import_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "root import public components"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_sample_sheet_component_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "manual sample sheet"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_finds_bio_template_component_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "WellPlate DoseCalculator"])

    output = capsys.readouterr().out
    assert "useBioTemplateComponents" in output


def test_docs_search_finds_template_pack_component_chooser(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "template pack WellPlate DoseCalculator"])

    output = capsys.readouterr().out
    assert "frontend-component-chooser" in output
    assert "mint docs frontend choose" in output


def test_docs_search_combines_component_name_and_description(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "BioTemplateRenderer WellPlate"])

    output = capsys.readouterr().out
    assert "BioTemplateRenderer" in output


def test_docs_search_finds_well_plate_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "well plate workspace"])

    output = capsys.readouterr().out
    assert "BioTemplatePresetWorkspaceView" in output


def test_docs_search_finds_wellplate_dose_design_workspace(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "wellplate dose design"])

    output = capsys.readouterr().out
    assert "DoseDesignWorkspaceView" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert "useBioTemplatePresetWorkspace" in output

    docs_command.cmd_docs(path_args=["search", "database wellplate template design_data"])
    database_output = capsys.readouterr().out
    assert "wellplate-screen" in database_output
    assert "mint docs template-preset wellplate-screen" in database_output
    assert database_output.index("wellplate-screen") < database_output.index("plate-map")


def test_docs_search_finds_template_current_helpers(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "loadCurrent"])

    output = capsys.readouterr().out
    assert "mint docs template plate-map" in output
    assert "mint docs template-pack cell-culture-screen" in output


def test_docs_search_finds_template_preset(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "mass spec batch"])

    output = capsys.readouterr().out
    assert "lcms-batch" in output
    assert "mint docs template-preset lcms-batch" in output


def test_docs_search_finds_frontend_template_preset_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "createWellPlateScreenCollection"], json_output=True)

    payload = json.loads(capsys.readouterr().out)
    assert any(
        item["sdk"] == "frontend"
        and item["category"] == "templatePresets"
        and item["name"] == "wellplate-screen"
        for item in payload
    )


def test_docs_search_finds_r_bridge(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "Rscript"])

    output = capsys.readouterr().out
    assert "r-bridge" in output
    assert "mint docs r-bridge" in output

    docs_command.cmd_docs(path_args=["search", "R interface analysis plugin"])
    interface_output = capsys.readouterr().out
    assert "r-bridge" in interface_output
    assert "mint docs r-bridge" in interface_output


def test_docs_frontend_lists_bundled_templates(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "templates"])

    output = capsys.readouterr().out
    assert "plate-map" in output
    assert "qpcr-plate" in output
    assert "mint docs frontend <name>" in output


def test_docs_frontend_lists_bundled_template_presets(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "templatePresets"])

    output = capsys.readouterr().out
    assert "wellplate-screen" in output
    assert "lcms-batch" in output
    assert "elisa-assay" in output
    assert "flow-cytometry-assay" in output
    assert "western-blot-assay" in output
    assert "mint docs frontend <name>" in output


def test_docs_frontend_template_preset_detail(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "wellplate-screen"])

    output = capsys.readouterr().out
    assert "plate-map" in output
    assert "sample-sheet" in output
    assert "createWellPlateScreenCollection" in output
    assert "PlateMapEditor" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert "const values = ref({})" in output
    assert '<BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen"' in output
    assert ':workspace="workspace"' not in output
    assert "Aliases" in output
    assert "wellplate, well-plate screen, drug screen" in output
    assert "mint add data-template-preset wellplate-screen --page" in output
    assert "mint docs template-preset wellplate-screen" in output


def test_docs_frontend_elisa_template_preset_detail(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "elisa-assay"])

    output = capsys.readouterr().out
    assert "calibration-curve" in output
    assert "assay-matrix" in output
    assert "createElisaAssayCollection" in output
    assert "PlateMapEditor" in output
    assert "BioTemplatePresetWorkspaceView" in output
    assert '<BioTemplatePresetWorkspaceView v-model="values" preset="elisa-assay"' in output
    assert ':workspace="workspace"' not in output
    assert "mint docs template-preset elisa-assay" in output


def test_docs_frontend_composable_lists_return_members(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useExperimentSave"])

    output = capsys.readouterr().out
    assert "UseExperimentSaveReturn" in output
    assert "currentExperimentId" in output
    assert "saveTemplatePreset" in output
    assert "saveCurrentTemplatePreset" in output
    assert "saveDesign" in output
    assert "isLoading" in output
    assert "lastLoadedAt" in output
    assert "loadCurrentDesign" in output
    assert "loadCurrentAnalysis" in output
    assert "deleteCurrentDesign" in output


def test_docs_frontend_use_form_lists_replace_state(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useForm"])

    output = capsys.readouterr().out
    assert "replaceState" in output
    assert "new clean baseline" in output


def test_docs_frontend_use_form_builder_lists_update_schema(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useFormBuilder"])

    output = capsys.readouterr().out
    assert "updateSchema" in output
    assert "still-mounted forms" in output


def test_docs_frontend_lists_template_collection_helper(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useTemplateCollection"])

    output = capsys.readouterr().out
    assert "Manages a biology template collection" in output
    assert "UseTemplateCollectionReturn" in output
    assert "templateCollection" in output
    assert "templateIds" in output
    assert "requireTemplate" in output
    assert "saveCurrent" in output


def test_docs_frontend_lists_request_sync_state(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useRequestSyncState"])

    output = capsys.readouterr().out
    assert "Shared loading/error/timestamp state" in output
    assert "lastLoadedAt" in output
    assert "lastRunAt" in output
    assert "markSaved" in output
    assert "markRun" in output
    assert "run" in output


def test_docs_frontend_lists_plugin_config_sync_state(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "usePluginConfig"])

    output = capsys.readouterr().out
    assert "lastLoadedAt" in output
    assert "lastSavedAt" in output
    assert "Whether local config differs" in output


def test_docs_frontend_lists_experiment_selector_sync_state(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useExperimentSelector"])

    output = capsys.readouterr().out
    assert "lastLoadedAt" in output
    assert "Timestamp of the last successful experiment fetch" in output
    assert "Fetch and append the next page" in output


def test_docs_frontend_lists_debounced_watch(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useDebouncedWatch"])

    output = capsys.readouterr().out
    assert "useDebouncedWatch" in output
    assert "debounced callback execution" in output
    assert "cancel" in output
    assert "flush" in output
    assert "isPending" in output


def test_docs_frontend_lists_experiment_data_sync_state(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "useExperimentData"])

    output = capsys.readouterr().out
    assert "lastLoadedAt" in output
    assert "Timestamp of the last successful experiment data fetch" in output
    assert "Hierarchy tree rows normalised" in output


def test_docs_search_finds_frontend_composable_return_member(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["search", "saveTemplatePreset"])

    output = capsys.readouterr().out
    assert "useExperimentSave" in output
    assert "members: saveTemplatePreset" in output

    docs_command.cmd_docs(path_args=["search", "saveCurrentTemplatePreset"])
    current_output = capsys.readouterr().out
    assert "useExperimentSave" in current_output
    assert "members: saveCurrentTemplatePreset" in current_output


def test_docs_frontend_uses_current_bundled_composable_descriptions(monkeypatch, capsys):
    monkeypatch.setattr(docs_command, "find_platform_root", lambda: None)

    docs_command.cmd_docs(path_args=["frontend", "usePluginSettings"])
    settings_output = capsys.readouterr().out
    assert "Read plugin settings exposed through the platform context." in settings_output
    assert "Return a generated plugin client" not in settings_output
    assert "*/" not in settings_output

    docs_command.cmd_docs(path_args=["frontend", "useCurrentExperiment"])
    experiment_output = capsys.readouterr().out
    assert "Read and optionally load the current platform experiment" in experiment_output
    assert "lastLoadedAt" in experiment_output
    assert "Timestamp of the last successful current-experiment fetch" in experiment_output
    assert "Read plugin settings exposed" not in experiment_output
    assert "*/" not in experiment_output


def _make_scaffold(tmp_path: Path) -> Path:
    project = tmp_path / "plugin"
    context = _build_template_context(
        derive_names("My Analyzer"),
        {"description": "Analyze things", "type": "analysis", "include_frontend": "true"},
    )
    write_files(project, context, include_frontend=True)
    return project
