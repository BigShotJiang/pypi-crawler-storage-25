"""Tests for the Typer-based mint CLI."""

import json

from mint_sdk.cli import app
from mint_sdk.init_command import _build_template_context, derive_names, write_files
from typer.testing import CliRunner

runner = CliRunner()


def _make_scaffold(tmp_path, *, frontend: bool = True):
    context = _build_template_context(
        derive_names("My Analyzer"),
        {
            "description": "Desc",
            "type": "analysis",
            "include_frontend": "true" if frontend else "false",
        },
    )
    write_files(tmp_path, context, include_frontend=frontend)
    return tmp_path


class TestCliHelp:
    def test_help_shows_platform_panel(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Platform" in result.output

    def test_help_shows_develop_panel(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Develop" in result.output

    def test_platform_before_develop_in_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        platform_pos = result.output.index("Platform")
        develop_pos = result.output.index("Develop")
        assert platform_pos < develop_pos

    def test_no_args_shows_help(self) -> None:
        result = runner.invoke(app, [])
        assert result.exit_code == 2  # Click convention for no_args_is_help
        assert "Platform" in result.output


class TestCliVersion:
    def test_version_flag(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "mint" in result.output

    def test_version_short_flag(self) -> None:
        result = runner.invoke(app, ["-V"])
        assert result.exit_code == 0
        assert "mint" in result.output


class TestSubApps:
    def test_dev_help(self) -> None:
        result = runner.invoke(app, ["dev", "--help"])
        assert result.exit_code == 0
        assert "logs" in result.output

    def test_sdk_help(self) -> None:
        result = runner.invoke(app, ["sdk", "--help"])
        assert result.exit_code == 0
        assert "link" in result.output
        assert "unlink" in result.output
        assert "update" in result.output
        assert "generate" in result.output

    def test_sdk_generate_outputs_json(self, tmp_path) -> None:
        project = _make_scaffold(tmp_path)

        result = runner.invoke(app, ["sdk", "generate", str(project), "--json"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["ok"] is True
        assert payload["check"] is False
        assert payload["detail"].endswith("mint-plugin.contract.json and frontend/src/generated/mint-plugin.ts")

    def test_sdk_generate_check_outputs_stale_json(self, tmp_path) -> None:
        project = _make_scaffold(tmp_path)
        result = runner.invoke(app, ["sdk", "generate", str(project)])
        assert result.exit_code == 0
        client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
        client_path.write_text(client_path.read_text() + "\n// stale\n")

        stale = runner.invoke(app, ["sdk", "generate", str(project), "--check", "--json"])

        assert stale.exit_code == 1
        payload = json.loads(stale.output)
        assert payload["ok"] is False
        assert payload["check"] is True
        assert "stale" in payload["detail"]
        assert payload["fix_hint"] == "Run `mint sdk generate`."

    def test_add_help(self) -> None:
        result = runner.invoke(app, ["add", "--help"])
        assert result.exit_code == 0
        assert "setting" in result.output
        assert "endpoint" in result.output
        assert "router" in result.output
        assert "schema" in result.output
        assert "service" in result.output
        assert "migration" in result.output
        assert "frontend-composable" in result.output
        assert "r-analysis" in result.output

    def test_doctor_help_shows_r_flag(self) -> None:
        result = runner.invoke(app, ["doctor", "--help"])
        assert result.exit_code == 0
        assert "--r" in result.output
        assert "--json" in result.output

    def test_doctor_r_outputs_json(self, tmp_path) -> None:
        result = runner.invoke(app, ["doctor", str(tmp_path), "--r", "--json"])

        assert result.exit_code == 1
        payload = json.loads(result.output)
        assert payload["ok"] is False
        assert payload["total"] >= 1
        assert any(check["label"] == "R dependencies" for check in payload["checks"])

    def test_init_help_shows_template_catalog_flags(self) -> None:
        result = runner.invoke(app, ["init", "--help"])
        assert result.exit_code == 0
        assert "--list-templates" in result.output
        assert "--json" in result.output

    def test_init_lists_templates(self) -> None:
        result = runner.invoke(app, ["init", "--list-templates"])
        assert result.exit_code == 0
        assert "Available plugin starter templates:" in result.output
        assert "analysis-basic" in result.output
        assert "cell-culture-screen" in result.output
        assert "omics-assay" in result.output
        assert "longitudinal-study" in result.output
        assert "molecular-assay" in result.output
        assert "elisa-assay" in result.output
        assert "flow-cytometry-assay" in result.output
        assert "western-blot-assay" in result.output

    def test_init_lists_templates_json(self) -> None:
        result = runner.invoke(app, ["init", "--list-templates", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        names = [item["name"] for item in payload["templates"]]
        assert names[:2] == ["analysis-basic", "file-upload-analysis"]
        assert "cell-culture-screen" in names
        assert "omics-assay" in names
        assert "molecular-assay" in names
        assert "elisa-assay" in names
        assert "flow-cytometry-assay" in names
        assert "western-blot-assay" in names
        assert payload["templates"][0]["init_command"] == "mint init --template analysis-basic"

    def test_add_r_analysis_help_shows_page_flag(self) -> None:
        result = runner.invoke(app, ["add", "r-analysis", "--help"])
        assert result.exit_code == 0
        assert "--page" in result.output

    def test_add_endpoint_help_shows_generate_flag(self) -> None:
        result = runner.invoke(app, ["add", "endpoint", "--help"])
        assert result.exit_code == 0
        assert "--generate" in result.output

    def test_add_data_template_help_shows_list_flag(self) -> None:
        result = runner.invoke(app, ["add", "data-template", "--help"])
        assert result.exit_code == 0
        assert "--list" in result.output
        assert "--json" in result.output
        assert "sample-prep" in result.output
        assert "calibration-curve" in result.output
        assert "protocol-steps" in result.output
        assert "assay-matrix" in result.output
        assert "reagent-list" in result.output
        assert "flow-cytometry-panel" in result.output
        assert "instrument-run" in result.output
        assert "qpcr-plate" in result.output

    def test_add_data_template_lists_templates(self) -> None:
        result = runner.invoke(app, ["add", "data-template", "--list"])
        assert result.exit_code == 0
        assert "Available data templates:" in result.output
        assert "plate-map" in result.output
        assert "sample-prep" in result.output
        assert "calibration-curve" in result.output
        assert "time-course" in result.output
        assert "protocol-steps" in result.output
        assert "assay-matrix" in result.output
        assert "reagent-list" in result.output
        assert "instrument-run" in result.output
        assert "qpcr-plate" in result.output
        assert "Ready-to-save template presets:" in result.output
        assert "wellplate-screen" in result.output
        assert "qpcr-expression" in result.output
        assert "lcms-batch" in result.output
        assert "elisa-assay" in result.output
        assert "flow-cytometry-assay" in result.output
        assert "western-blot-assay" in result.output
        assert "mint add data-template-preset wellplate-screen --page" in result.output
        assert "mint add data-template-preset elisa-assay --page" in result.output
        assert "mint add data-template-preset western-blot-assay --page" in result.output
        assert "mint docs template-preset <name>" in result.output

    def test_add_data_template_lists_templates_json(self) -> None:
        result = runner.invoke(app, ["add", "data-template", "--list", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert [item["name"] for item in payload["templates"]] == [
            "plate-map",
            "sample-sheet",
            "sample-prep",
            "dose-response",
            "calibration-curve",
            "time-course",
            "protocol-steps",
            "assay-matrix",
            "reagent-list",
            "flow-cytometry-panel",
            "instrument-run",
            "qpcr-plate",
        ]
        assert payload["templates"][0]["add_command"] == "mint add data-template plate-map --page"
        assert [item["name"] for item in payload["presets"]] == [
            "wellplate-screen",
            "qpcr-expression",
            "lcms-batch",
            "elisa-assay",
            "flow-cytometry-assay",
            "western-blot-assay",
        ]
        assert payload["presets"][0]["templates"] == [
            "plate-map",
            "sample-sheet",
            "dose-response",
        ]

    def test_add_data_template_unknown_suggests_template(self) -> None:
        result = runner.invoke(app, ["add", "data-template", "plate-mapp"])
        assert result.exit_code == 1
        assert "Unknown data template: plate-mapp" in result.output
        assert "Did you mean: plate-map?" in result.output
        assert "mint add data-template --list" in result.output

    def test_add_data_template_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template(*, path, template, generate, page):
            calls.append((path, template.value, generate, page))

        monkeypatch.setattr(add_command, "cmd_add_data_template", fake_cmd_add_data_template)

        result = runner.invoke(
            app,
            ["add", "data-template", "wellplate", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "plate-map", False, True)]

    def test_add_data_template_hyphenated_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template(*, path, template, generate, page):
            calls.append((path, template.value, generate, page))

        monkeypatch.setattr(add_command, "cmd_add_data_template", fake_cmd_add_data_template)

        result = runner.invoke(
            app,
            ["add", "data-template", "dose-design", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "dose-response", False, True)]

    def test_add_data_template_pack_help_and_list(self) -> None:
        help_result = runner.invoke(app, ["add", "data-template-pack", "--help"])
        assert help_result.exit_code == 0
        assert "cell-culture-screen" in help_result.output
        assert "--list" in help_result.output

        list_result = runner.invoke(app, ["add", "data-template-pack", "--list"])
        assert list_result.exit_code == 0
        assert "Available data-template packs:" in list_result.output
        assert "omics-assay" in list_result.output
        assert "longitudinal-study" in list_result.output
        assert "molecular-assay" in list_result.output

    def test_add_data_template_pack_lists_json(self) -> None:
        result = runner.invoke(app, ["add", "data-template-pack", "--list", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert [item["name"] for item in payload["packs"]] == [
            "cell-culture-screen",
            "omics-assay",
            "longitudinal-study",
            "molecular-assay",
        ]
        assert payload["packs"][0]["templates"] == [
            "sample-sheet",
            "sample-prep",
            "plate-map",
            "reagent-list",
            "protocol-steps",
            "dose-response",
            "flow-cytometry-panel",
        ]
        assert "instrument-run" in payload["packs"][1]["templates"]
        assert "sample-prep" in payload["packs"][1]["templates"]
        assert "calibration-curve" in payload["packs"][1]["templates"]
        assert "instrument-run" in payload["packs"][3]["templates"]
        assert "sample-prep" in payload["packs"][3]["templates"]
        assert "calibration-curve" in payload["packs"][3]["templates"]

    def test_add_data_template_pack_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_pack(*, path, pack, generate, page):
            calls.append((path, pack.value, generate, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_pack",
            fake_cmd_add_data_template_pack,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-pack", "metabolomics", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "omics-assay", False, True)]

    def test_add_data_template_pack_hyphenated_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_pack(*, path, pack, generate, page):
            calls.append((path, pack.value, generate, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_pack",
            fake_cmd_add_data_template_pack,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-pack", "gene-expression", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "molecular-assay", False, True)]

    def test_add_data_template_preset_help_and_list(self) -> None:
        help_result = runner.invoke(app, ["add", "data-template-preset", "--help"])
        assert help_result.exit_code == 0
        assert "wellplate-screen" in help_result.output
        assert "--list" in help_result.output

        list_result = runner.invoke(app, ["add", "data-template-preset", "--list"])
        assert list_result.exit_code == 0
        assert "Available data-template presets:" in list_result.output
        assert "qpcr-expression" in list_result.output
        assert "lcms-batch" in list_result.output
        assert "elisa-assay" in list_result.output
        assert "flow-cytometry-assay" in list_result.output
        assert "western-blot-assay" in list_result.output
        assert "aliases: western blot, western-blot, immunoblot" in list_result.output
        assert "components: DataFrame, ReagentList, ExperimentTimeline, SampleSelector" in list_result.output
        assert "add: mint add data-template-preset western-blot-assay --page" in list_result.output

    def test_add_data_template_preset_lists_json(self) -> None:
        result = runner.invoke(app, ["add", "data-template-preset", "--list", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert [item["name"] for item in payload["presets"]] == [
            "wellplate-screen",
            "qpcr-expression",
            "lcms-batch",
            "elisa-assay",
            "flow-cytometry-assay",
            "western-blot-assay",
        ]
        assert payload["presets"][0]["add_command"] == (
            "mint add data-template-preset wellplate-screen --page"
        )

    def test_add_data_template_preset_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_preset(*, path, preset, page):
            calls.append((path, preset.value, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_preset",
            fake_cmd_add_data_template_preset,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-preset", "wellplate", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "wellplate-screen", True)]

    def test_add_data_template_preset_hyphenated_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_preset(*, path, preset, page):
            calls.append((path, preset.value, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_preset",
            fake_cmd_add_data_template_preset,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-preset", "dose-planner", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "wellplate-screen", True)]

    def test_add_data_template_preset_elisa_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_preset(*, path, preset, page):
            calls.append((path, preset.value, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_preset",
            fake_cmd_add_data_template_preset,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-preset", "immunoassay", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "elisa-assay", True)]

    def test_add_data_template_preset_western_alias_resolves(self, monkeypatch, tmp_path) -> None:
        from mint_sdk import add_command

        calls = []

        def fake_cmd_add_data_template_preset(*, path, preset, page):
            calls.append((path, preset.value, page))

        monkeypatch.setattr(
            add_command,
            "cmd_add_data_template_preset",
            fake_cmd_add_data_template_preset,
        )

        result = runner.invoke(
            app,
            ["add", "data-template-preset", "immunoblot", "--path", str(tmp_path), "--page"],
        )

        assert result.exit_code == 0
        assert calls == [(str(tmp_path), "western-blot-assay", True)]

    def test_add_data_template_preset_unknown_suggests_preset(self) -> None:
        result = runner.invoke(app, ["add", "data-template-preset", "wellplatee"])
        assert result.exit_code == 1
        assert "Unknown data-template preset: wellplatee" in result.output
        assert "Did you mean: wellplate-screen?" in result.output
        assert "mint add data-template-preset --list" in result.output

    def test_auth_help(self) -> None:
        result = runner.invoke(app, ["auth", "--help"])
        assert result.exit_code == 0
        assert "login" in result.output
        assert "logout" in result.output

    def test_experiment_help(self) -> None:
        result = runner.invoke(app, ["experiment", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "get" in result.output
        assert "update" in result.output
        assert "types" in result.output

    def test_project_help(self) -> None:
        result = runner.invoke(app, ["project", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "get" in result.output
        assert "create" in result.output
        assert "update" in result.output
        assert "delete" in result.output
