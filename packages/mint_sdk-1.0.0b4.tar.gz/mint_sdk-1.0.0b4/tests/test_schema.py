"""Tests for SDK schema conversion helpers."""

from __future__ import annotations

from enum import Enum
from typing import Literal

from mint_sdk.schema import settings_model_to_form_fields, settings_model_to_settings_schema
from pydantic import BaseModel, Field


class TestSettingsModelToFormFields:
    def test_scalar_fields_map_to_form_types(self) -> None:
        class Settings(BaseModel):
            method: str = "default"
            threshold: float = Field(2.5, ge=0.0, le=10.0, description="score cutoff")
            enabled: bool = True

        fields = settings_model_to_form_fields(Settings)
        by_name = {field["name"]: field for field in fields}

        assert by_name["method"]["type"] == "text"
        assert by_name["threshold"]["type"] == "number"
        assert by_name["threshold"]["hint"] == "score cutoff"
        assert by_name["threshold"]["validation"] == {"min": 0.0, "max": 10.0}
        assert by_name["enabled"]["type"] == "toggle"

    def test_literal_becomes_select_options(self) -> None:
        class Settings(BaseModel):
            method: Literal["default", "robust"] = "default"

        field = settings_model_to_form_fields(Settings)[0]
        assert field["type"] == "select"
        assert field["props"]["options"] == [
            {"label": "default", "value": "default"},
            {"label": "robust", "value": "robust"},
        ]

    def test_enum_becomes_select_options(self) -> None:
        class Method(str, Enum):
            fast = "fast"
            precise = "precise"

        class Settings(BaseModel):
            method: Method = Method.fast

        field = settings_model_to_form_fields(Settings)[0]
        assert field["type"] == "select"
        assert field["defaultValue"] == Method.fast
        assert field["props"]["options"] == [
            {"label": "fast", "value": "fast"},
            {"label": "precise", "value": "precise"},
        ]


class TestSettingsModelToSettingsSchema:
    def test_wraps_fields_in_settings_group(self) -> None:
        class Settings(BaseModel):
            threshold: float = 2.5

        schema = settings_model_to_settings_schema(
            Settings,
            group_label="Analysis Settings",
            description="Controls the run",
            columns=2,
        )

        assert schema["groups"][0]["label"] == "Analysis Settings"
        assert schema["groups"][0]["description"] == "Controls the run"
        assert schema["groups"][0]["columns"] == 2
        assert schema["groups"][0]["fields"][0]["name"] == "threshold"
