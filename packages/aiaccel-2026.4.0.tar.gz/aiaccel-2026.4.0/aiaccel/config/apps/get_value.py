# Copyright (C) 2025 National Institute of Advanced Industrial Science and Technology (AIST)
# SPDX-License-Identifier: MIT

import argparse

from omegaconf import OmegaConf as oc  # noqa: N813

from aiaccel.config.config import prepare_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", help="Configuration file path")
    parser.add_argument("key", help="Target key in the configuration file")

    args, _ = parser.parse_known_args()
    config = prepare_config(args.config)

    print(oc.select(config, args.key))


if __name__ == "__main__":
    main()
