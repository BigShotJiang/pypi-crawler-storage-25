"""Branding and terminal art for Forithmus CLI."""
from rich.console import Console
from rich.panel import Panel

LOGO = r"""
    ______           _ __  __
   / ____/___  _____(_) /_/ /_  ____ ___  __  _______
  / /_  / __ \/ ___/ / __/ __ \/ __ `__ \/ / / / ___/
 / __/ / /_/ / /  / / /_/ / / / / / / / / /_/ (__  )
/_/    \____/_/  /_/\__/_/ /_/_/ /_/ /_/\__,_/____/
"""

VERSION = "0.1.0"

def print_banner(console: Console):
    """Print the Forithmus CLI banner."""
    console.print()
    console.print(LOGO, style="bold cyan", highlight=False)
    console.print("  [bold white]Forithmus[/bold white] [dim]Research Hub CLI[/dim]")
    console.print(f"  [dim cyan]v{VERSION}[/dim cyan]")
    console.print()


def print_header(console: Console, title: str, subtitle: str = ""):
    """Print a section header."""
    text = f"[bold]{title}[/bold]"
    if subtitle:
        text += f"\n[dim]{subtitle}[/dim]"
    console.print(Panel(text, border_style="cyan", padding=(0, 2)))
