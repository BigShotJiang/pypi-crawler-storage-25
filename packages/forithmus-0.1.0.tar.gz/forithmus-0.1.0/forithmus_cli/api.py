from __future__ import annotations
"""API client for the Forithmus Research Hub."""
import sys
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from forithmus_cli.auth import get_api_url, get_token

console = Console()


def _headers() -> dict:
    token = get_token()
    h = {"X-Requested-With": "XMLHttpRequest"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def api_get(path: str, params: dict | None = None):
    """GET request to the API. Returns parsed JSON or None."""
    url = get_api_url()
    try:
        res = httpx.get(f"{url}{path}", headers=_headers(), params=params, timeout=30)
        if res.status_code == 200:
            return res.json()
        if res.status_code == 401:
            console.print("[red]Session expired. Run: forithmus login[/red]")
            return None
        return None
    except httpx.RequestError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        return None


def api_post(path: str, data=None, files=None, timeout=30):
    """POST request to the API. Returns parsed JSON or None."""
    url = get_api_url()
    try:
        if files:
            res = httpx.post(f"{url}{path}", headers=_headers(), files=files, timeout=timeout)
        else:
            res = httpx.post(f"{url}{path}", headers=_headers(), json=data, timeout=timeout)
        if res.status_code < 400:
            return res.json()
        detail = "Unknown error"
        try:
            detail = res.json().get("detail", detail)
        except Exception:
            pass
        console.print(f"[red]Error ({res.status_code}): {detail}[/red]")
        return None
    except httpx.RequestError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        return None


def upload_file(path: str, endpoint: str, field_name: str = "file",
                extra_fields: dict | None = None, desc: str = "Uploading") -> dict | None:
    """Upload a file with progress bar. Returns API response or None."""
    url = get_api_url()
    filepath = Path(path)
    if not filepath.exists():
        console.print(f"[red]File not found: {path}[/red]")
        return None

    file_size = filepath.stat().st_size
    size_mb = file_size / (1024 * 1024)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(f"{desc} ({size_mb:.0f} MB)", total=file_size)

        def _read_chunks(f, chunk_size=1024 * 1024):
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                progress.update(task, advance=len(chunk))
                yield chunk

        with open(filepath, "rb") as f:
            headers = _headers()
            fields = extra_fields or {}

            try:
                # Stream file in chunks to avoid loading entire file into memory
                # (Docker images can be multiple GB)
                files_dict = {field_name: (filepath.name, _read_chunks(f), "application/octet-stream")}
                data_dict = {k: str(v) for k, v in fields.items()} if fields else None

                with httpx.Client(timeout=httpx.Timeout(600.0, connect=30.0)) as client:
                    res = client.post(
                        f"{url}{endpoint}",
                        headers=headers,
                        files=files_dict,
                        data=data_dict,
                        timeout=httpx.Timeout(600.0, connect=30.0),
                    )

                if res.status_code < 400:
                    return res.json()

                detail = "Upload failed"
                try:
                    detail = res.json().get("detail", detail)
                except Exception:
                    pass
                console.print(f"[red]Error ({res.status_code}): {detail}[/red]")
                return None

            except httpx.RequestError as e:
                console.print(f"[red]Upload failed: {e}[/red]")
                return None


def poll_status(endpoint: str, key: str = "status", target: str = "ready",
                fail_values: set | None = None, interval: float = 3.0,
                timeout: float = 600.0, desc: str = "Processing") -> str | None:
    """Poll an endpoint until status reaches target or fails. Returns final status."""
    import time
    fail_values = fail_values or {"failed", "rejected"}
    url = get_api_url()
    start = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[progress.description]{desc}..."),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(desc, total=None)
        while time.time() - start < timeout:
            try:
                res = httpx.get(f"{url}{endpoint}", headers=_headers(), timeout=10)
                if res.status_code == 200:
                    status = res.json().get(key, "")
                    if status == target:
                        return status
                    if status in fail_values:
                        return status
            except Exception:
                pass
            time.sleep(interval)

    console.print(f"[yellow]Timed out waiting for {target}[/yellow]")
    return None
