"""
forithmus-cli: Forithmus Research Hub command-line tool.

Commands:
  login                        Authenticate with the platform
  logout                       Clear stored credentials
  whoami                       Show current user info
  challenges                   List your challenges
  init <slug>                  Download schema and set up local config
  generate                     Generate dummy test data from schema
  test <image>                 Run and validate Docker container locally
  validate <output-dir>        Validate output files against schema
  submit <file>                Submit Docker container or prediction file
  upload-data <file>           Upload test data to a phase
  upload-gt <file>             Upload ground truth to a phase
  upload-eval <file>           Upload evaluation container to a phase
  status                       Check phase data status
"""
import os
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from forithmus_cli.branding import print_banner, print_header, VERSION
from forithmus_cli.auth import login_cmd, logout_cmd, whoami_cmd, get_token
from forithmus_cli.api import api_get, api_post, upload_file, poll_status
from forithmus_cli.validator import validate_output
from forithmus_cli.docker_runner import run_docker_test
from forithmus_cli.schema import load_config, save_config, generate_dummy_data
from forithmus_cli.buddy import fori, THINKING, HAPPY, SAD, CELEBRATE

app = typer.Typer(
    name="forithmus",
    help="Forithmus Research Hub CLI",
    invoke_without_command=True,
    add_completion=False,
)
console = Console()


@app.callback()
def main(ctx: typer.Context):
    """Forithmus Research Hub CLI"""
    if ctx.invoked_subcommand is None:
        print_banner(console)
        fori.greet()
        console.print(ctx.get_help())
        raise typer.Exit()


def _require_auth():
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run: forithmus login[/red]")
        raise typer.Exit(1)
    return token


def _require_config():
    config = load_config()
    if not config:
        console.print("[red]No config found. Run: forithmus init <challenge-slug>[/red]")
        raise typer.Exit(1)
    return config


# ─── Auth commands ───

def _get_api_url() -> str:
    """Resolve API URL from env var or default."""
    return os.environ.get("FORITHMUS_API_URL", "https://research.forithmus.com/api")

@app.command()
def login():
    """Authenticate with the Forithmus Research Hub via browser."""
    print_banner(console)
    url = _get_api_url()
    login_cmd(url)


@app.command()
def logout():
    """Clear stored credentials."""
    logout_cmd()
    fori.bye()


@app.command()
def whoami():
    """Show current user info and connection status."""
    whoami_cmd()


# ─── Challenge commands ───

@app.command()
def challenges():
    """List challenges you've joined."""
    _require_auth()
    data = api_get("/challenges?mine=true&limit=100")
    items = data.get("items", data) if isinstance(data, dict) else data
    if not items:
        console.print("[dim]No challenges found.[/dim]")
        return

    table = Table(title="My Challenges", border_style="dim")
    table.add_column("Title", style="bold")
    table.add_column("Slug", style="dim")
    table.add_column("Role", style="cyan")
    table.add_column("Status")
    table.add_column("Submissions", justify="right")

    for ch in items:
        status_style = {"open": "green", "draft": "yellow", "closed": "red"}.get(ch.get("status", ""), "")
        table.add_row(
            ch["title"],
            ch["slug"],
            ch.get("my_role", ""),
            f"[{status_style}]{ch.get('status', '')}[/{status_style}]",
            str(ch.get("submission_count", 0)),
        )

    console.print(table)


@app.command()
def init(
    challenge_slug: str = typer.Argument(help="Challenge slug"),
    phase: str = typer.Option(None, "--phase", "-p", help="Phase slug (defaults to the default phase)"),
):
    """Download challenge schema and set up local config for testing."""
    _require_auth()
    print_header(console, "Initializing", f"Challenge: {challenge_slug}")

    challenge = api_get(f"/challenges/{challenge_slug}")
    if not challenge:
        console.print(f"[red]Challenge '{challenge_slug}' not found.[/red]")
        raise typer.Exit(1)

    phases = api_get(f"/challenges/{challenge_slug}/phases")
    if not phases:
        console.print("[red]No phases found.[/red]")
        raise typer.Exit(1)

    # Find target phase
    if phase:
        target = next((p for p in phases if p["slug"] == phase), None)
    else:
        target = next((p for p in phases if p.get("is_default")), phases[0])

    if not target:
        slugs = ", ".join(p["slug"] for p in phases)
        console.print(f"[red]Phase '{phase}' not found. Available: {slugs}[/red]")
        raise typer.Exit(1)

    # Clear old test data if switching challenges
    import shutil
    old_config = load_config()
    if old_config and old_config.get("challenge") != challenge_slug:
        test_data = Path(".forithmus") / "test_data"
        if test_data.exists():
            shutil.rmtree(test_data)
            console.print("[dim]Cleared old test data from previous challenge.[/dim]")

    config = {
        "challenge": challenge_slug,
        "challenge_title": challenge.get("title", ""),
        "phase": target["slug"],
        "phase_id": target["id"],
        "phase_name": target.get("name", ""),
        "submission_type": target["submission_type"],
        "data_schema": target.get("data_schema", {}),
        "ranking_config": target.get("ranking_config", {}),
    }
    save_config(config)

    console.print(f"[green]Initialized:[/green] {challenge['title']}")
    console.print(f"  Phase: {target['name']} ({target['submission_type']})")
    console.print(f"  Config: .forithmus/config.json")

    schema = config["data_schema"]
    if schema:
        sections = [k for k in ("input", "output", "ground_truth", "prediction") if schema.get(k)]
        console.print(f"  Schema: {', '.join(sections)}")
    else:
        console.print("  [yellow]No data schema defined yet.[/yellow]")

    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print("  forithmus generate        Generate dummy test data")
    console.print("  forithmus test <image>     Test your Docker container locally")
    console.print("  forithmus submit <file>    Submit to the platform")


@app.command()
def generate():
    """Generate dummy test data from the challenge schema."""
    config = _require_config()
    schema = config.get("data_schema", {})
    if not schema:
        console.print("[yellow]No data schema. Nothing to generate.[/yellow]")
        raise typer.Exit(1)

    print_header(console, "Generating dummy data", config.get("challenge_title", ""))

    fori.say(THINKING, "Generating mock data...")
    input_dir, gt_dir = generate_dummy_data(schema)
    console.print(f"[green]Input data:[/green]  {input_dir}")
    if gt_dir:
        console.print(f"[green]Ground truth:[/green] {gt_dir}")

    # Count generated files
    input_count = sum(1 for _ in Path(input_dir).rglob("*") if _.is_file())
    console.print(f"\n  {input_count} files generated")
    fori.happy(f"{input_count} mock files ready!")
    console.print(f"[dim]Test your container:[/dim]")
    console.print(f"  forithmus test <your-docker-image>")


# ─── Test & validate commands ───

@app.command()
def test(
    image: str = typer.Argument(help="Docker image name or .tar.gz path"),
    timeout: int = typer.Option(300, "--timeout", "-t", help="Timeout in seconds"),
):
    """Run and validate your Docker container locally against the challenge schema."""
    config = _require_config()
    schema = config.get("data_schema", {})

    print_header(console, "Local test", f"{image}")

    # Step 1: Generate dummy data
    console.print("\n[bold cyan]Step 1/3[/bold cyan] Generating dummy input data...")
    input_dir, gt_dir = generate_dummy_data(schema) if schema else (None, None)
    if not input_dir:
        console.print("[yellow]No schema, using empty input.[/yellow]")
        import tempfile
        input_dir = tempfile.mkdtemp(prefix="forithmus_input_")

    input_count = sum(1 for _ in Path(input_dir).rglob("*") if _.is_file())
    console.print(f"  {input_count} input files generated")

    # Step 2: Run Docker
    console.print(f"\n[bold cyan]Step 2/3[/bold cyan] Running container (timeout: {timeout}s)...")
    output_dir, success, logs = run_docker_test(image, input_dir, timeout)

    if logs:
        # Show last few lines of logs
        lines = logs.strip().split("\n")
        for line in lines[-10:]:
            console.print(f"  [dim]{line}[/dim]")

    if not success:
        fori.sad("Container failed. Check the logs above.")
        raise typer.Exit(1)

    console.print(f"  [green]Container exited successfully[/green]")

    # Step 3: Validate output
    console.print(f"\n[bold cyan]Step 3/3[/bold cyan] Validating output...")
    output_count = sum(1 for _ in Path(output_dir).rglob("*") if _.is_file())
    console.print(f"  {output_count} output files found")

    if schema:
        errors = validate_output(output_dir, schema, input_dir)
        if errors:
            fori.sad(f"Found {len(errors)} issue{'s' if len(errors) > 1 else ''} with your output!")
            console.print()
            for i, err in enumerate(errors[:10], 1):
                console.print(f"  [red]{i}.[/red] {err}")
                console.print()
            if len(errors) > 10:
                console.print(f"  [dim]... and {len(errors) - 10} more issues[/dim]")
            console.print("[dim]Fix the issues above and run the test again.[/dim]")
            raise typer.Exit(1)
        console.print(f"  [green]All checks passed[/green]")
    else:
        console.print(f"  [yellow]No schema to validate against[/yellow]")

    fori.celebrate("Ready to submit!")
    console.print(f"  forithmus submit {image}")


@app.command()
def validate(
    output_dir: str = typer.Argument(help="Path to output directory to validate"),
    input_dir: str = typer.Option(None, "--input", "-i", help="Path to input directory (for case count matching)"),
):
    """Validate output files against the challenge schema (without running Docker)."""
    config = _require_config()
    schema = config.get("data_schema", {})
    if not schema:
        console.print("[yellow]No data schema to validate against.[/yellow]")
        return

    errors = validate_output(output_dir, schema, input_dir)

    if errors:
        fori.sad(f"Found {len(errors)} issue{'s' if len(errors) > 1 else ''} with your output!")
        console.print()
        for i, err in enumerate(errors, 1):
            console.print(f"  [red]{i}.[/red] {err}")
            console.print()
        console.print("[dim]Fix the issues above and validate again.[/dim]")
        raise typer.Exit(1)

    fori.celebrate("Output looks perfect!")


# ─── Submit command ───

@app.command()
def submit(
    target: str = typer.Argument(help="Docker .tar.gz path or prediction file"),
    tier: str = typer.Option("cpu-4", "--tier", help="Compute tier (cpu-4, gpu-t4, gpu-a100)"),
    time_budget: int = typer.Option(60, "--time-budget", "-t", help="Time budget in minutes"),
    description: str = typer.Option("", "--desc", "-d", help="Submission description"),
):
    """Submit a Docker container or prediction file to the platform."""
    _require_auth()
    config = _require_config()

    slug = config["challenge"]
    phase_id = config["phase_id"]
    sub_type = config.get("submission_type", "docker")

    print_header(console, "Submitting", f"{config.get('challenge_title', slug)} / {config.get('phase_name', '')}")
    fori.say(THINKING, "Let me check your submission...")

    filepath = Path(target)
    if not filepath.exists():
        console.print(f"[red]File not found: {target}[/red]")
        raise typer.Exit(1)

    size_mb = filepath.stat().st_size / (1024 * 1024)
    console.print(f"  File: {filepath.name} ({size_mb:.0f} MB)")
    console.print(f"  Type: {sub_type}")
    if sub_type == "docker":
        console.print(f"  Tier: {tier}, Budget: {time_budget} min")

    if sub_type == "docker":
        # Two-step upload: pre-upload -> scan -> submit
        console.print(f"\n[bold cyan]Step 1/3[/bold cyan] Uploading...")
        resp = upload_file(
            target,
            f"/challenges/{slug}/submissions/pre-upload-docker",
            field_name="file",
            extra_fields={"phase_id": phase_id},
            desc="Uploading Docker image",
        )
        if not resp:
            fori.sad("Upload failed.")

            raise typer.Exit(1)

        upload_id = resp.get("upload_id")
        gcs_key = resp.get("gcs_key")
        console.print(f"  Upload ID: {upload_id}")

        # Step 2: Wait for scan
        console.print(f"\n[bold cyan]Step 2/3[/bold cyan] Scanning for malware...")
        status = poll_status(
            f"/challenges/{slug}/submissions/upload-status/{upload_id}",
            target="ready",
            fail_values={"failed", "rejected"},
            desc="Virus scan",
        )
        if status != "ready":
            console.print(f"[red]Scan failed: {status}[/red]")
            raise typer.Exit(1)
        console.print(f"  [green]Scan passed[/green]")

        # Step 3: Create submission
        console.print(f"\n[bold cyan]Step 3/3[/bold cyan] Creating submission...")
        from forithmus_cli.auth import get_api_url
        import httpx
        url = get_api_url()
        from forithmus_cli.api import _headers
        res = httpx.post(
            f"{url}/challenges/{slug}/submissions/upload-docker",
            headers=_headers(),
            data={
                "phase_id": phase_id,
                "gcs_key": gcs_key,
                "tier": tier,
                "time_budget_minutes": str(time_budget),
                "description": description,
            },
            timeout=30,
        )
        if res.status_code >= 400:
            detail = "Submission failed"
            try:
                detail = res.json().get("detail", detail)
            except Exception:
                pass
            console.print(f"[red]Error: {detail}[/red]")
            raise typer.Exit(1)

        sub = res.json()
        fori.celebrate("Submitted! Now let's see how it scores!")
        console.print(f"  ID: {sub.get('id', '')}")
        console.print(f"  Status: {sub.get('status', '')}")

    else:
        # File submission: direct upload
        console.print(f"\n[bold cyan]Uploading prediction file...[/bold cyan]")
        resp = upload_file(
            target,
            f"/challenges/{slug}/submissions/upload-file",
            field_name="file",
            extra_fields={"phase_id": phase_id, "description": description},
            desc="Uploading predictions",
        )
        if not resp:
            raise typer.Exit(1)
        sub = resp
        console.print(f"  [green]Submitted![/green]")
        console.print(f"  ID: {sub.get('id', '')}")

    from forithmus_cli.auth import get_api_url, _get_frontend_url
    base = _get_frontend_url(get_api_url())
    console.print(f"\n[dim]View results at: {base}/challenges/{slug}/submissions/{sub.get('id', '')}[/dim]")


# ─── Host data upload commands ───

@app.command("upload-data")
def upload_data(
    file: str = typer.Argument(help="Test data ZIP file"),
):
    """Upload test data to the current phase (host only)."""
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id = config["phase_id"]

    print_header(console, "Upload test data", config.get("phase_name", ""))
    resp = upload_file(
        file,
        f"/challenges/{slug}/phases/{phase_id}/data/test-data",
        desc="Uploading test data",
    )
    if resp:
        fori.happy("Test data uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command("upload-gt")
def upload_gt(
    file: str = typer.Argument(help="Ground truth ZIP file"),
):
    """Upload ground truth to the current phase (host only)."""
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id = config["phase_id"]

    print_header(console, "Upload ground truth", config.get("phase_name", ""))
    resp = upload_file(
        file,
        f"/challenges/{slug}/phases/{phase_id}/data/ground-truth",
        desc="Uploading ground truth",
    )
    if resp:
        fori.happy("Ground truth uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command("upload-eval")
def upload_eval(
    file: str = typer.Argument(help="Evaluation container .tar.gz"),
):
    """Upload evaluation Docker container to the current phase (host only)."""
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id = config["phase_id"]

    print_header(console, "Upload evaluation container", config.get("phase_name", ""))
    resp = upload_file(
        file,
        f"/challenges/{slug}/phases/{phase_id}/data/eval-container",
        desc="Uploading evaluation container",
    )
    if resp:
        fori.happy("Eval container uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command()
def status():
    """Check data upload status for the current phase."""
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id = config["phase_id"]

    print_header(console, "Phase status", f"{config.get('challenge_title', slug)} / {config.get('phase_name', '')}")

    data = api_get(f"/challenges/{slug}/phases/{phase_id}/data/status")
    if not data:
        console.print("[red]Failed to fetch status.[/red]")
        return

    for key in ("test_data", "ground_truth", "eval_container"):
        info = data.get(key, {})
        uploaded = info.get("uploaded", False)
        status_val = info.get("processing_status", "")
        icon = "[green]OK[/green]" if uploaded else "[red]Missing[/red]"
        label = key.replace("_", " ").title()
        extra = f" ({status_val})" if status_val and status_val != "complete" else ""
        console.print(f"  {icon} {label}{extra}")

    # Also check readiness
    readiness = api_get(f"/challenges/{slug}/phases/{phase_id}/readiness")
    if readiness:
        console.print()
        ready = readiness.get("ready", False)
        if ready:
            console.print("[green bold]Phase is ready to accept submissions.[/green bold]")
        else:
            console.print("[yellow]Phase is not ready:[/yellow]")
            for issue in readiness.get("issues", []):
                console.print(f"  [yellow]![/yellow] {issue}")


@app.command("download-image")
def download_image(
    submission_id: str = typer.Argument(help="Submission ID to download Docker image for"),
    output: str = typer.Option(None, "--output", "-o", help="Output filename (default: <submission_id>.tar)"),
):
    """Download a kept Docker image for a submission (host only).

    Only works when keep_docker_images is enabled on the challenge.
    Limited to once per image per week.
    """
    _require_auth()
    config = _require_config()
    slug = config["challenge"]

    if not output:
        output = f"{submission_id[:12]}.tar"

    print_header(console, "Download Docker image", f"Submission: {submission_id[:12]}...")

    from forithmus_cli.auth import get_api_url
    import httpx

    url = get_api_url()
    from forithmus_cli.api import _headers

    fori.say(THINKING, "Fetching image from registry...")

    try:
        with httpx.stream(
            "GET",
            f"{url}/challenges/{slug}/submissions/{submission_id}/docker-image",
            headers=_headers(),
            timeout=httpx.Timeout(600.0, connect=30.0),
        ) as response:
            if response.status_code == 429:
                fori.sad("Download limit reached. You can download each image once per week.")
                raise typer.Exit(1)
            if response.status_code == 403:
                fori.sad("Docker image download not available for this challenge.")
                raise typer.Exit(1)
            if response.status_code == 404:
                fori.sad("No Docker image found. It may have been deleted or keep_docker_images is disabled.")
                raise typer.Exit(1)
            if response.status_code >= 400:
                detail = "Download failed"
                try:
                    detail = response.json().get("detail", detail)
                except Exception:
                    pass
                fori.sad(detail)
                raise typer.Exit(1)

            # Stream download with progress
            total = int(response.headers.get("content-length", 0))
            from rich.progress import Progress, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn

            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                console=console,
            ) as progress:
                task = progress.add_task("Downloading", total=total or None)
                with open(output, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=1024 * 1024):
                        f.write(chunk)
                        progress.update(task, advance=len(chunk))

        size_mb = os.path.getsize(output) / (1024 * 1024)
        fori.happy(f"Downloaded! {size_mb:.0f} MB saved to {output}")
        console.print(f"\n[dim]Load with: docker load -i {output}[/dim]")

    except httpx.RequestError as e:
        fori.sad(f"Connection error: {e}")
        raise typer.Exit(1)


@app.command()
def version():
    """Show CLI version."""
    print_banner(console)


    fori.bye()


def _cli():
    """Entry point with banner on no-args."""
    if len(sys.argv) == 1:
        print_banner(console)
    app()


if __name__ == "__main__":
    _cli()
