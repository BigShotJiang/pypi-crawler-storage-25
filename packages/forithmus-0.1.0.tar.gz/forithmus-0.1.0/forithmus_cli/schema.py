from __future__ import annotations
"""Schema handling: load config, generate smart mock data from auto-detected schema.

The schema comes from the platform's auto-detection system which scans uploaded
data and baseline outputs. It knows:
  - Input format (flat files, subfolders, JSON, CSV) with shapes, dtypes, case IDs
  - Output format (files, JSON with keys, CSV with columns)
  - Mapping type (one_to_one or many_to_one) with match field
  - Mock count (how many samples to generate)

Mock data generation creates structurally valid test data with consistent case IDs
across input and output so participants can test their containers locally.
"""
import csv
import json
import os
from pathlib import Path

import numpy as np

CONFIG_FILE = Path(".forithmus") / "config.json"


def load_config() -> dict | None:
    if not CONFIG_FILE.exists():
        return None
    return json.loads(CONFIG_FILE.read_text())


def save_config(config: dict):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


# ═══════════════════════════════════════════════════════════════
# Mock data generation
# ═══════════════════════════════════════════════════════════════

def generate_dummy_data(schema: dict, base_dir: str | None = None) -> tuple[str, str | None]:
    """Generate mock input (and expected output) from the detected schema.

    Uses _mapping.mock_count for sample size and creates consistent case IDs
    across input and output directories.

    Returns (input_dir, expected_output_dir or None).
    """
    import shutil
    base = Path(base_dir) if base_dir else Path(".forithmus") / "test_data"
    # Always clear old mock data before generating fresh
    if base.exists():
        shutil.rmtree(base)
    input_dir = str(base / "input")
    output_dir = None

    input_schema = schema.get("input", {})
    output_schema = schema.get("output", {})
    mapping = schema.get("_mapping", {})
    mock_count = mapping.get("mock_count", 5)

    # Generate case IDs from input schema or create generic ones
    case_ids = _get_case_ids(input_schema, mock_count)

    # Generate input
    if input_schema:
        os.makedirs(input_dir, exist_ok=True)
        _generate_section(input_dir, input_schema, case_ids)

    # Generate expected output (so participants know what structure to produce)
    if output_schema and output_schema.get("type"):
        output_dir = str(base / "expected_output")
        os.makedirs(output_dir, exist_ok=True)
        _generate_section(output_dir, output_schema, case_ids, mapping=mapping)

    return input_dir, output_dir


def _get_case_ids(input_schema: dict, count: int) -> list[str]:
    """Extract or generate case IDs for mock data."""
    # Try to get from detected case_ids_sample
    if input_schema.get("type") == "flat_files":
        ff = input_schema.get("flat_files", {})
        sample = ff.get("case_ids_sample", [])
        if sample:
            # Use detected IDs, pad if we need more
            ids = list(sample[:count])
            while len(ids) < count:
                ids.append(f"case_{len(ids)+1:03d}")
            return ids
    elif input_schema.get("type") == "directory":
        structure = input_schema.get("structure", {})
        if structure:
            first_group = next(iter(structure.values()))
            sample = first_group.get("case_ids_sample", [])
            if sample:
                ids = list(sample[:count])
                while len(ids) < count:
                    ids.append(f"case_{len(ids)+1:03d}")
                return ids

    return [f"case_{i+1:03d}" for i in range(count)]


def _generate_section(base_dir: str, schema: dict, case_ids: list[str], mapping: dict | None = None):
    """Generate files for one schema section (input or output)."""
    schema_type = schema.get("type", "")

    if schema_type == "flat_files":
        _gen_flat_files(base_dir, schema.get("flat_files", {}), case_ids)

    elif schema_type == "directory":
        for dirname, spec in schema.get("structure", {}).items():
            dir_path = os.path.join(base_dir, dirname)
            os.makedirs(dir_path, exist_ok=True)
            _gen_flat_files(dir_path, spec, case_ids)

    elif schema_type == "json":
        _gen_json_output(base_dir, schema, case_ids, mapping)

    elif schema_type == "csv":
        _gen_csv_output(base_dir, schema, case_ids, mapping)


# ── File generators ──

def _gen_flat_files(dir_path: str, spec: dict, case_ids: list[str]):
    """Generate flat files (numpy, nifti, png, json metadata) for each case ID."""
    os.makedirs(dir_path, exist_ok=True)
    fmt = spec.get("format", "numpy")
    pattern = spec.get("pattern", "*.npy")

    for case_id in case_ids:
        ext = pattern.replace("*", "")
        filename = f"{case_id}{ext}"
        filepath = os.path.join(dir_path, filename)

        if fmt == "nifti":
            _gen_nifti(filepath, spec)
        elif fmt == "numpy":
            _gen_numpy(filepath, spec)
        elif fmt == "png":
            _gen_png(filepath, spec)
        elif fmt == "json":
            _gen_json_metadata(filepath, case_id)
        elif fmt == "csv":
            # Single CSV is handled by _gen_csv_output, not here
            pass
        else:
            # Unknown format: create empty placeholder
            Path(filepath).touch()


def _random_shape(spec: dict, default_ndim: int = 3) -> list[int]:
    """Pick a shape from the spec, randomizing per-axis when shapes vary."""
    if spec.get("_shapes_vary") and spec.get("_shape_min") and spec.get("_shape_max"):
        lo = spec["_shape_min"]
        hi = spec["_shape_max"]
        return [int(np.random.randint(lo[i], hi[i] + 1)) for i in range(len(lo))]
    if spec.get("_shape"):
        return list(spec["_shape"])
    dims = spec.get("dimensions", [default_ndim])
    ndim = dims[0] if isinstance(dims, list) else dims
    return [32] * ndim


def _gen_nifti(filepath: str, spec: dict):
    """Generate a dummy NIfTI file with realistic header (spacing, affine)."""
    try:
        import nibabel as nib
        shape = _random_shape(spec, default_ndim=3)
        dtype = spec.get("dtype", "float32")
        data = np.random.rand(*shape).astype(dtype)

        # Use detected affine if available, otherwise create one from spacing
        affine = None
        if spec.get("affine"):
            affine = np.array(spec["affine"], dtype=np.float64)
        elif spec.get("spacing"):
            sp = spec["spacing"]
            affine = np.diag([*sp[:3], 1.0] if len(sp) >= 3 else [*sp, *([1.0] * (4 - len(sp)))])
        else:
            # Default: 1mm isotropic
            affine = np.eye(4)

        img = nib.Nifti1Image(data, affine)
        nib.save(img, filepath)
    except ImportError:
        shape = _random_shape(spec, default_ndim=3)
        dtype = spec.get("dtype", "float32")
        np.save(filepath.replace(".nii.gz", ".npy").replace(".nii", ".npy"),
                np.random.rand(*shape).astype(dtype))


def _gen_numpy(filepath: str, spec: dict):
    """Generate a dummy numpy file."""
    shape = _random_shape(spec, default_ndim=2)
    dtype = spec.get("dtype", "float32")
    np.save(filepath, np.random.rand(*shape).astype(dtype))


def _gen_png(filepath: str, spec: dict):
    """Generate a dummy PNG image."""
    shape = _random_shape(spec, default_ndim=3)
    if not shape:
        shape = [64, 64, 3]
    if len(shape) == 2:
        data = (np.random.rand(*shape) * 255).astype(np.uint8)
    else:
        data = (np.random.rand(*shape[:3]) * 255).astype(np.uint8)
    try:
        from PIL import Image
        Image.fromarray(data).save(filepath)
    except ImportError:
        np.save(filepath.replace(".png", ".npy"), data)


def _gen_json_metadata(filepath: str, case_id: str):
    """Generate a dummy JSON metadata file for one case."""
    data = {
        "id": case_id,
        "modality": "CT",
        "age": int(np.random.randint(20, 80)),
        "sex": np.random.choice(["M", "F"]),
    }
    Path(filepath).write_text(json.dumps(data, indent=2))


# ── JSON output generator ──

def _gen_json_output(base_dir: str, schema: dict, case_ids: list[str], mapping: dict | None = None):
    """Generate a mock JSON output file with correct keys and matching case IDs."""
    filename = schema.get("filename", "predictions.json")
    filepath = os.path.join(base_dir, filename)
    keys = schema.get("keys", {})
    structure = schema.get("structure", "array")
    case_id_field = schema.get("case_id_field")
    sample = schema.get("sample")

    if structure == "array":
        entries = []
        for case_id in case_ids:
            entry = _gen_json_entry(keys, case_id, case_id_field, sample)
            entries.append(entry)
        Path(filepath).write_text(json.dumps(entries, indent=2))

    elif structure == "object":
        if schema.get("keyed_by_case"):
            # Object keyed by case ID
            obj = {}
            for case_id in case_ids:
                obj[case_id] = _gen_json_entry(keys, case_id, None, None)
            Path(filepath).write_text(json.dumps(obj, indent=2))
        else:
            # Single object
            obj = _gen_json_entry(keys, case_ids[0] if case_ids else "case_001", case_id_field, sample)
            Path(filepath).write_text(json.dumps(obj, indent=2))


def _gen_json_entry(keys: dict, case_id: str, case_id_field: str | None, sample: dict | None) -> dict:
    """Generate one JSON entry with correct types for each key."""
    entry = {}
    for key, value_type in keys.items():
        if key == case_id_field:
            entry[key] = case_id
        elif value_type == "string":
            entry[key] = f"sample_{key}"
        elif value_type == "integer":
            # Use sample value as reference for range
            if sample and key in sample and isinstance(sample[key], int):
                entry[key] = int(np.random.randint(0, max(sample[key] + 1, 5)))
            else:
                entry[key] = int(np.random.randint(0, 10))
        elif value_type == "number":
            entry[key] = round(float(np.random.rand()), 4)
        elif value_type == "boolean":
            entry[key] = bool(np.random.choice([True, False]))
        elif value_type == "array":
            entry[key] = [round(float(np.random.rand()), 4) for _ in range(3)]
        elif value_type == "object":
            entry[key] = {"value": round(float(np.random.rand()), 4)}
        else:
            entry[key] = None
    return entry


# ── CSV output generator ──

def _gen_csv_output(base_dir: str, schema: dict, case_ids: list[str], mapping: dict | None = None):
    """Generate a mock CSV output file with correct columns and matching case IDs."""
    filename = schema.get("filename", "predictions.csv")
    filepath = os.path.join(base_dir, filename)
    columns = schema.get("columns", ["case_id", "prediction"])
    col_types = schema.get("column_types", {})
    case_id_col = schema.get("case_id_column")
    sample_row = schema.get("sample_row", {})

    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for case_id in case_ids:
            row = []
            for col in columns:
                if col == case_id_col:
                    row.append(case_id)
                elif col_types.get(col) == "integer":
                    row.append(int(np.random.randint(0, 100)))
                elif col_types.get(col) == "number":
                    row.append(round(float(np.random.rand()), 4))
                else:
                    row.append(f"val_{col}")
            writer.writerow(row)
