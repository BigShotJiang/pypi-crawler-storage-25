from __future__ import annotations
"""Authentication: browser-based login with server-side polling, token management."""
import json
import secrets
import time
import webbrowser
from pathlib import Path

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

console = Console()
CONFIG_DIR = Path.home() / ".forithmus"
TOKEN_FILE = CONFIG_DIR / "credentials.json"


def get_api_url() -> str:
    if TOKEN_FILE.exists():
        data = json.loads(TOKEN_FILE.read_text())
        return data.get("api_url", "https://research.forithmus.com/api")
    return "https://research.forithmus.com/api"


def get_token() -> str | None:
    """Get the current access token, refreshing if expired."""
    if not TOKEN_FILE.exists():
        return None
    data = json.loads(TOKEN_FILE.read_text())
    token = data.get("access_token")
    if not token:
        return None
    try:
        import base64
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.b64decode(payload_b64))
        if payload.get("exp", 0) < time.time() - 60:
            new_token = _refresh_token()
            return new_token
    except Exception:
        pass
    return token


def get_credentials() -> dict | None:
    if not TOKEN_FILE.exists():
        return None
    return json.loads(TOKEN_FILE.read_text())


def save_credentials(api_url: str, access_token: str, refresh_token: str):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps({
        "api_url": api_url,
        "access_token": access_token,
        "refresh_token": refresh_token,
    }, indent=2))
    TOKEN_FILE.chmod(0o600)


def _refresh_token() -> str | None:
    if not TOKEN_FILE.exists():
        return None
    data = json.loads(TOKEN_FILE.read_text())
    refresh = data.get("refresh_token")
    api_url = data.get("api_url", "https://research.forithmus.com")
    if not refresh:
        return None
    try:
        res = httpx.post(f"{api_url}/auth/refresh", json={"refresh_token": refresh}, timeout=10)
        if res.status_code == 200:
            new_data = res.json()
            save_credentials(api_url, new_data["access_token"], new_data.get("refresh_token", refresh))
            return new_data["access_token"]
    except Exception:
        pass
    return None


def _get_frontend_url(api_url: str) -> str:
    """Resolve frontend URL from API URL.
    Production: https://research.forithmus.com/api -> https://research.forithmus.com
    Dev: http://localhost:3001 -> http://localhost:5181"""
    if ":3001" in api_url:
        return api_url.replace(":3001", ":5181")
    # Strip /api suffix for production
    if api_url.endswith("/api"):
        return api_url[:-4]
    return api_url


# ─── Browser-based auth with server-side polling ───


def login_cmd(url: str):
    """Browser-based login: open browser, poll server for completion."""
    api_url = url.rstrip("/")
    if not api_url.startswith("http"):
        api_url = f"https://{api_url}"
    # Security: enforce HTTPS except for localhost development
    if api_url.startswith("http://") and "localhost" not in api_url and "127.0.0.1" not in api_url:
        console.print("[red]Refusing to connect over insecure HTTP. Use HTTPS.[/red]")
        raise SystemExit(1)

    # Create a CLI auth session on the server
    session_id = secrets.token_urlsafe(32)

    try:
        res = httpx.post(f"{api_url}/auth/cli-session", json={"session_id": session_id}, timeout=10)
        if res.status_code != 200:
            console.print("[red]Could not create auth session. Check your internet connection and try again.[/red]")
            raise SystemExit(1)
    except httpx.RequestError:
        console.print("[red]Could not reach the server. Check your internet connection and try again.[/red]")
        raise SystemExit(1)

    # Build the login URL
    frontend_url = _get_frontend_url(api_url)
    auth_url = f"{frontend_url}/login?cli=true&session={session_id}"

    # Open browser
    console.print("[dim]Opening browser for authentication...[/dim]")
    try:
        webbrowser.open(auth_url)
    except Exception:
        pass

    console.print()
    console.print(f"  [bold]Login URL:[/bold]")
    console.print(f"  [cyan]{auth_url}[/cyan]")
    console.print()
    console.print("  [dim]Log in via the browser. The CLI will detect it automatically.[/dim]")
    console.print("  [dim]Press Ctrl+C to cancel.[/dim]")
    console.print()

    # Poll the server for completion
    try:
        with console.status("[bold cyan]Waiting for browser authentication...[/bold cyan]"):
            deadline = time.time() + 300  # 5 minute timeout
            while time.time() < deadline:
                time.sleep(2)
                try:
                    poll_res = httpx.get(
                        f"{api_url}/auth/cli-session/{session_id}",
                        timeout=10,
                    )
                    if poll_res.status_code == 200:
                        data = poll_res.json()
                        if data.get("status") == "authenticated":
                            save_credentials(api_url, data["access_token"], data["refresh_token"])
                            _print_auth_success(data, api_url)
                            return
                except httpx.RequestError:
                    pass  # Network blip, keep polling

        console.print("[yellow]Timed out waiting for browser login (5 minutes).[/yellow]")
        console.print("[dim]Run forithmus login to try again.[/dim]")

    except KeyboardInterrupt:
        console.print("\n[dim]Cancelled.[/dim]")



def _print_auth_success(data: dict, api_url: str):
    """Display authenticated success message."""
    user = data.get("user", {})
    name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
    email = user.get("email", "")
    role = user.get("platform_role", "user")
    credits = user.get("platform_credits", 0)

    console.print()
    console.print(Panel(
        f"[bold green]Authenticated[/bold green]\n\n"
        f"  [bold]{name}[/bold]\n"
        f"  [dim]{email}[/dim]\n"
        f"  [dim]{role}[/dim]  [dim cyan]${credits:.2f} credits[/dim cyan]",
        border_style="green",
        padding=(1, 3),
    ))
    console.print()
    console.print("  [dim]Get started:[/dim]")
    console.print("    forithmus challenges      [dim]List your challenges[/dim]")
    console.print("    forithmus init <slug>      [dim]Set up local config[/dim]")
    console.print("    forithmus submit <file>    [dim]Submit to platform[/dim]")
    console.print()


def logout_cmd():
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        console.print("[green]Logged out.[/green]")
    else:
        console.print("[dim]Not logged in.[/dim]")


def whoami_cmd():
    token = get_token()
    if not token:
        console.print("[yellow]Not logged in. Run: forithmus login[/yellow]")
        return
    from forithmus_cli.api import api_get
    user = api_get("/users/me")
    if user:
        console.print(f"[bold]{user.get('first_name', '')} {user.get('last_name', '')}[/bold]")
        console.print(f"Email: {user.get('email', '')}")
        console.print(f"Role: {user.get('platform_role', 'user')}")
        console.print(f"Credits: ${user.get('platform_credits', 0):.2f}")
        console.print(f"API: {get_api_url()}")
    else:
        console.print("[red]Failed to fetch user info. Try: forithmus login[/red]")
