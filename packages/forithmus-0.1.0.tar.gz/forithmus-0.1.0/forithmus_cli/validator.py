from __future__ import annotations
"""Output validation: checks Docker container output against the auto-detected schema.

Produces clear, actionable error messages that tell the user exactly what went wrong
and how to fix it. Each error message includes:
  - What was expected
  - What was found
  - How to fix it
"""
import csv
import json
import os
from pathlib import Path


def _safe_filename(name: str) -> str:
    """Sanitize a filename from the schema to prevent path traversal."""
    # Strip directory components and dangerous characters
    name = os.path.basename(name)
    if name.startswith("."):
        name = "_" + name[1:]
    return name


def _check_path_escape(path: str, base: str) -> bool:
    """Verify a resolved path stays within the base directory."""
    return str(Path(path).resolve()).startswith(str(Path(base).resolve()))


def validate_output(output_dir: str, schema: dict, input_dir: str | None = None) -> list[str]:
    """Validate the output directory against the schema. Returns list of error messages."""
    errors = []
    output_schema = schema.get("output", {})
    mapping = schema.get("_mapping", {})

    if not output_schema or not output_schema.get("type"):
        return errors

    out_type = output_schema["type"]
    input_case_ids = _collect_input_case_ids(schema.get("input", {}), input_dir)

    if out_type == "flat_files":
        errors.extend(_validate_flat_files(output_dir, output_schema.get("flat_files", {}),
                                            input_case_ids, mapping))
    elif out_type == "directory":
        errors.extend(_validate_directory(output_dir, output_schema.get("structure", {}),
                                           input_case_ids, mapping))
    elif out_type == "json":
        errors.extend(_validate_json(output_dir, output_schema, input_case_ids, mapping))
    elif out_type == "csv":
        errors.extend(_validate_csv(output_dir, output_schema, input_case_ids, mapping))

    return errors


def _collect_input_case_ids(input_schema: dict, input_dir: str | None) -> list[str]:
    """Collect case IDs from input schema or by scanning the input directory/files."""
    inp_type = input_schema.get("type", "")

    # File-based input: IDs from filenames
    if inp_type == "flat_files":
        ff = input_schema.get("flat_files", {})
        ids = ff.get("case_ids_sample", [])
        if ids:
            return ids
    elif inp_type == "directory":
        structure = input_schema.get("structure", {})
        if structure:
            first = next(iter(structure.values()))
            ids = first.get("case_ids_sample", [])
            if ids:
                return ids

    # CSV input: IDs from the case_id column
    elif inp_type == "csv":
        id_col = input_schema.get("case_id_column")
        if id_col and input_dir:
            filename = input_schema.get("filename", "")
            csv_path = os.path.join(input_dir, filename) if filename else None
            if not csv_path or not os.path.exists(csv_path):
                # Find any CSV in the input dir
                for f in Path(input_dir).glob("*.csv"):
                    csv_path = str(f)
                    break
            if csv_path and os.path.exists(csv_path):
                try:
                    with open(csv_path, newline="") as f:
                        reader = csv.DictReader(f)
                        return [row[id_col] for row in reader if id_col in row]
                except Exception:
                    pass
        # Fallback to schema sample
        sample = input_schema.get("sample_row", {})
        if sample and id_col and id_col in sample:
            return []  # Can't enumerate all IDs from a single sample

    # JSON input: IDs from the case_id field
    elif inp_type == "json":
        id_field = input_schema.get("case_id_field")
        if id_field and input_dir:
            filename = input_schema.get("filename", "")
            json_path = os.path.join(input_dir, filename) if filename else None
            if not json_path or not os.path.exists(json_path):
                for f in Path(input_dir).glob("*.json"):
                    json_path = str(f)
                    break
            if json_path and os.path.exists(json_path):
                try:
                    import json as json_mod
                    with open(json_path) as f:
                        data = json_mod.load(f)
                    if isinstance(data, list):
                        return [str(e.get(id_field, "")) for e in data if isinstance(e, dict)]
                except Exception:
                    pass

    # Fallback: scan directory for filenames (only for file-based inputs)
    if input_dir and os.path.isdir(input_dir) and inp_type in ("flat_files", "directory", ""):
        ids = []
        for f in sorted(Path(input_dir).rglob("*")):
            if f.is_file():
                name = f.stem
                if name.endswith(".nii"):
                    name = name[:-4]
                ids.append(name)
        return ids

    return []


# ═══════════════════════════════════════════════════════════
# Flat files validation
# ═══════════════════════════════════════════════════════════

def _validate_flat_files(output_dir: str, spec: dict, input_ids: list[str],
                          mapping: dict) -> list[str]:
    errors = []
    fmt = spec.get("format", "")
    pattern = spec.get("pattern", "*")
    ext = pattern.replace("*", "") if pattern else ""

    # Check for files nested in subdirectories (common mistake)
    nested_files = list(Path(output_dir).rglob("*"))
    nested_files = [f for f in nested_files if f.is_file()]
    top_level = [f for f in Path(output_dir).iterdir() if f.is_file()]
    subdirs = [d for d in Path(output_dir).iterdir() if d.is_dir()]

    if not top_level and nested_files and subdirs:
        errors.append(
            f"Output files are inside subdirectories ({', '.join(d.name for d in subdirs[:3])}/) "
            f"but should be directly in /output/. "
            f"Save your files to /output/ not /output/subfolder/."
        )
        return errors

    # Reject symlinks (security: prevent container from linking to host files)
    symlinks = [f.name for f in top_level if f.is_symlink()]
    if symlinks:
        errors.append(
            f"Symlinks found in output: {', '.join(symlinks[:5])}. "
            f"Output must contain regular files, not symbolic links."
        )
        top_level = [f for f in top_level if not f.is_symlink()]

    output_files = sorted(top_level)
    if not output_files:
        errors.append(
            "No output files found in /output/. "
            f"Your container should produce {fmt} files with pattern '{pattern}'."
        )
        return errors

    # Check for zero-byte files
    zero_files = [f.name for f in output_files if f.stat().st_size == 0]
    if zero_files:
        errors.append(
            f"Empty (0 bytes) output files: {', '.join(zero_files[:5])}. "
            f"These files were created but contain no data. "
            f"Make sure your model actually writes predictions."
        )

    # Check file extension
    if ext:
        wrong_ext = [f.name for f in output_files if not f.name.endswith(ext)]
        if wrong_ext:
            errors.append(
                f"Wrong file extension: found {wrong_ext[:3]}. "
                f"Expected all files to end with '{ext}'. "
                f"Make sure your container saves output as {fmt} files."
            )

    # 1:1 mapping checks
    if mapping.get("type") == "one_to_one" and input_ids:
        if len(output_files) != len(input_ids):
            errors.append(
                f"File count mismatch: your container produced {len(output_files)} files "
                f"but there are {len(input_ids)} input files. "
                f"For this challenge, each input file should produce exactly one output file."
            )

        # Extract output stems (case-sensitive first, then case-insensitive fallback)
        output_stems = {}
        for f in output_files:
            stem = f.stem
            if stem.endswith(".nii"):
                stem = stem[:-4]
            output_stems[stem] = f.name

        missing = [cid for cid in input_ids if cid not in output_stems]

        # Case-insensitive check: detect case mismatch
        if missing:
            lower_stems = {s.lower(): s for s in output_stems}
            case_mismatches = []
            still_missing = []
            for cid in missing:
                if cid.lower() in lower_stems:
                    actual = lower_stems[cid.lower()]
                    case_mismatches.append((cid, actual))
                else:
                    still_missing.append(cid)

            if case_mismatches:
                examples = [f"'{exp}' (found '{got}')" for exp, got in case_mismatches[:3]]
                errors.append(
                    f"Filename case mismatch for {len(case_mismatches)} file(s): {', '.join(examples)}. "
                    f"Filenames are case-sensitive. Use the exact same casing as the input files."
                )

            if still_missing:
                errors.append(
                    f"Missing output for {len(still_missing)} input case(s): "
                    f"{', '.join(still_missing[:5])}"
                    + (f" and {len(still_missing)-5} more" if len(still_missing) > 5 else "") + ". "
                    f"Output filenames must match input filenames. "
                    f"Example: input '{still_missing[0]}{ext}' expects output '{still_missing[0]}{ext}'."
                )

        extra = set(output_stems.keys()) - set(input_ids)
        if extra:
            errors.append(
                f"Unexpected output files: {', '.join(sorted(extra)[:5])}. "
                f"These don't match any input filename. Did you rename them?"
            )

    # Shape/dtype/content checks
    if fmt == "numpy":
        errors.extend(_validate_numpy_files(output_files[:5], spec))
    if fmt == "nifti":
        errors.extend(_validate_nifti_shapes(output_files[:5], spec))

    return errors


def _validate_numpy_files(files: list[Path], spec: dict) -> list[str]:
    """Validate numpy files: dimensions, dtype, NaN/Inf, and emptiness."""
    errors = []
    import numpy as np
    expected_ndim = spec.get("dimensions", [None])[0]
    expected_dtype = spec.get("dtype")

    for f in files:
        try:
            arr = np.load(str(f), allow_pickle=False)
        except Exception as e:
            errors.append(
                f"{f.name}: cannot read numpy file ({e}). "
                f"Make sure you save with np.save() and the file is not corrupt."
            )
            continue

        # Dimensions check
        if expected_ndim and len(arr.shape) != expected_ndim:
            errors.append(
                f"{f.name}: wrong dimensions. Expected {expected_ndim}D array "
                f"but got {len(arr.shape)}D (shape {list(arr.shape)}). "
                f"Check that your model outputs the correct number of dimensions."
            )

        # Dtype check
        if expected_dtype and str(arr.dtype) != expected_dtype:
            errors.append(
                f"{f.name}: wrong data type. Expected {expected_dtype} but got {arr.dtype}. "
                f"Fix: output = output.astype(np.{expected_dtype})"
            )

        # NaN check
        if np.issubdtype(arr.dtype, np.floating) and np.any(np.isnan(arr)):
            nan_count = int(np.sum(np.isnan(arr)))
            nan_pct = round(100 * nan_count / arr.size, 1)
            errors.append(
                f"{f.name}: contains {nan_count} NaN values ({nan_pct}% of the array). "
                f"NaN values indicate your model failed to produce a prediction for some voxels. "
                f"Fix: output = np.nan_to_num(output, nan=0.0)"
            )

        # Infinity check
        if np.issubdtype(arr.dtype, np.floating) and np.any(np.isinf(arr)):
            inf_count = int(np.sum(np.isinf(arr)))
            errors.append(
                f"{f.name}: contains {inf_count} Infinity values. "
                f"This usually means a division by zero in your model. "
                f"Fix: output = np.nan_to_num(output, posinf=0.0, neginf=0.0)"
            )

        # Empty array check
        if arr.size == 0:
            errors.append(
                f"{f.name}: array is empty (size 0). "
                f"Your model produced a zero-element array. Check your output logic."
            )

    return errors


def _validate_nifti_shapes(files: list[Path], spec: dict) -> list[str]:
    errors = []
    try:
        import nibabel as nib
    except ImportError:
        return errors

    expected_ndim = spec.get("dimensions", [None])[0]
    expected_dtype = spec.get("dtype")

    for f in files:
        try:
            img = nib.load(str(f))
            if expected_ndim and len(img.shape) != expected_ndim:
                errors.append(
                    f"{f.name}: wrong dimensions. Expected {expected_ndim}D volume "
                    f"but got {len(img.shape)}D (shape {img.shape})."
                )
            if expected_dtype:
                actual = str(img.get_data_dtype())
                if expected_dtype not in actual:
                    errors.append(
                        f"{f.name}: wrong dtype. Expected {expected_dtype} but got {actual}."
                    )
        except Exception as e:
            errors.append(f"{f.name}: cannot read NIfTI file: {e}")
    return errors


# ═══════════════════════════════════════════════════════════
# Directory output validation
# ═══════════════════════════════════════════════════════════

def _validate_directory(output_dir: str, structure: dict, input_ids: list[str],
                         mapping: dict) -> list[str]:
    errors = []
    expected_folders = list(structure.keys())

    actual_folders = [d for d in os.listdir(output_dir) if os.path.isdir(os.path.join(output_dir, d))]

    for dirname in expected_folders:
        dir_path = os.path.join(output_dir, dirname)
        if not os.path.isdir(dir_path):
            errors.append(
                f"Missing output subfolder: '{dirname}/'. "
                f"Your container should create /output/{dirname}/ with the prediction files inside. "
                f"Expected subfolders: {', '.join(expected_folders)}"
            )
            continue
        errors.extend(_validate_flat_files(dir_path, structure[dirname], input_ids, mapping))

    unexpected = set(actual_folders) - set(expected_folders)
    if unexpected:
        errors.append(
            f"Unexpected output subfolders: {', '.join(sorted(unexpected))}. "
            f"Expected only: {', '.join(expected_folders)}"
        )

    return errors


# ═══════════════════════════════════════════════════════════
# JSON output validation
# ═══════════════════════════════════════════════════════════

def _validate_json(output_dir: str, schema: dict, input_ids: list[str],
                    mapping: dict) -> list[str]:
    errors = []
    filename = _safe_filename(schema.get("filename", "predictions.json"))
    filepath = os.path.join(output_dir, filename)

    if not os.path.exists(filepath):
        # Check if they wrote a different filename
        json_files = [f for f in os.listdir(output_dir) if f.endswith(".json")]
        if json_files:
            errors.append(
                f"Expected output file '{filename}' not found. "
                f"Found: {', '.join(json_files)}. "
                f"Rename your output to '{filename}' or check the challenge schema."
            )
        else:
            errors.append(
                f"No JSON output file found. Your container should write /output/{filename}. "
                f"Make sure you save your predictions as JSON."
            )
        return errors

    try:
        with open(filepath) as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        errors.append(
            f"'{filename}' is not valid JSON: {e}. "
            f"Check for syntax errors in your JSON output. "
            f"Common issues: trailing commas, missing quotes, NaN/Infinity values."
        )
        return errors

    structure = schema.get("structure", "array")
    keys = schema.get("keys", {})
    case_id_field = schema.get("case_id_field")

    # Structure check
    if structure == "array":
        if not isinstance(data, list):
            errors.append(
                f"'{filename}' should contain a JSON array (list), "
                f"but got {type(data).__name__}. "
                f"Your output should look like: [{{'case_id': '...', ...}}, ...]"
            )
            return errors

        if len(data) == 0:
            errors.append(
                f"'{filename}' is an empty array. "
                f"It should contain one entry per input case."
            )
            return errors

        # Entry count check
        if mapping.get("entries_match_inputs") and input_ids:
            if len(data) != len(input_ids):
                errors.append(
                    f"'{filename}' has {len(data)} entries but there are {len(input_ids)} input cases. "
                    f"Each input should have exactly one prediction entry."
                )

        # Key checks on first few entries
        for i, entry in enumerate(data[:5]):
            if not isinstance(entry, dict):
                errors.append(
                    f"'{filename}[{i}]' should be an object/dict, got {type(entry).__name__}. "
                    f"Each entry should be like: {{'case_id': '...', 'label': 0, ...}}"
                )
                continue

            # Missing keys
            missing_keys = [k for k in keys if k not in entry]
            if missing_keys:
                errors.append(
                    f"'{filename}[{i}]' is missing required key(s): {', '.join(missing_keys)}. "
                    f"Your entry has: {list(entry.keys())}. "
                    f"Expected keys: {list(keys.keys())}."
                )

            # Extra keys (warning, not error)
            # Wrong types
            for key, expected_type in keys.items():
                if key not in entry:
                    continue
                if not _check_json_type(entry[key], expected_type):
                    actual_type = type(entry[key]).__name__
                    example = _type_example(expected_type)
                    errors.append(
                        f"'{filename}[{i}].{key}' has wrong type. "
                        f"Expected {expected_type} but got {actual_type} (value: {repr(entry[key])}). "
                        f"It should be like: {example}"
                    )

            # Only check keys on first entry if there are errors
            if missing_keys:
                break

        # Case ID field validation
        if case_id_field and input_ids and len(data) > 0:
            if isinstance(data[0], dict):
                if case_id_field not in data[0]:
                    errors.append(
                        f"'{filename}' entries are missing the '{case_id_field}' field. "
                        f"This field should contain the input case ID "
                        f"(e.g. '{input_ids[0]}') to link predictions to inputs."
                    )
                else:
                    output_ids = {str(e.get(case_id_field, "")) for e in data if isinstance(e, dict)}
                    input_set = set(input_ids)
                    missing = input_set - output_ids
                    if missing and len(missing) == len(input_set):
                        # Show what IDs were found vs expected
                        sample_found = sorted(output_ids)[:3]
                        sample_expected = sorted(input_set)[:3]
                        errors.append(
                            f"No '{case_id_field}' values in '{filename}' match the input case IDs. "
                            f"Found values like: {sample_found}. "
                            f"Expected values like: {sample_expected}. "
                            f"Make sure the '{case_id_field}' field uses the same IDs as the input filenames."
                        )
                    elif missing:
                        errors.append(
                            f"'{filename}' is missing predictions for {len(missing)} case(s): "
                            f"{', '.join(sorted(missing)[:5])}"
                            + (f" and {len(missing)-5} more" if len(missing) > 5 else "")
                        )

    elif structure == "object":
        if not isinstance(data, dict):
            errors.append(
                f"'{filename}' should contain a JSON object, "
                f"but got {type(data).__name__}."
            )

    return errors


def _check_json_type(value, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    return True


def _type_example(t: str) -> str:
    examples = {
        "string": '"value"',
        "integer": "42",
        "number": "0.85",
        "boolean": "true",
        "array": "[1, 2, 3]",
        "object": '{"key": "value"}',
    }
    return examples.get(t, "...")


# ═══════════════════════════════════════════════════════════
# CSV output validation
# ═══════════════════════════════════════════════════════════

def _validate_csv(output_dir: str, schema: dict, input_ids: list[str],
                   mapping: dict) -> list[str]:
    errors = []
    filename = _safe_filename(schema.get("filename", "predictions.csv"))
    filepath = os.path.join(output_dir, filename)

    if not os.path.exists(filepath):
        csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        if csv_files:
            errors.append(
                f"Expected '{filename}' but found: {', '.join(csv_files)}. "
                f"Rename your output file to '{filename}'."
            )
        else:
            errors.append(
                f"No CSV output file found. Your container should write /output/{filename}."
            )
        return errors

    try:
        with open(filepath, newline="") as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames or []

            if not header:
                errors.append(
                    f"'{filename}' has no header row. "
                    f"CSV must start with a header: {','.join(schema.get('columns', ['col1', 'col2']))}"
                )
                return errors

            expected_cols = schema.get("columns", [])

            # Missing columns
            missing_cols = [c for c in expected_cols if c not in header]
            if missing_cols:
                errors.append(
                    f"'{filename}' is missing column(s): {', '.join(missing_cols)}. "
                    f"Your CSV has: {', '.join(header)}. "
                    f"Expected: {', '.join(expected_cols)}."
                )

            # Extra columns (just info)
            extra_cols = [c for c in header if c not in expected_cols]

            rows = list(reader)

    except Exception as e:
        errors.append(f"Cannot read '{filename}': {e}")
        return errors

    # Case ID column check
    case_id_col = schema.get("case_id_column")
    if case_id_col and input_ids and case_id_col in header:
        output_ids = {row.get(case_id_col, "") for row in rows}
        input_set = set(input_ids)
        missing = input_set - output_ids
        if missing and len(missing) == len(input_set):
            sample_found = sorted(output_ids)[:3]
            sample_expected = sorted(input_set)[:3]
            errors.append(
                f"No '{case_id_col}' values match the input case IDs. "
                f"Found: {sample_found}. Expected: {sample_expected}. "
                f"Make sure the '{case_id_col}' column uses the same IDs as the input."
            )
        elif missing:
            errors.append(
                f"'{filename}' is missing rows for {len(missing)} case(s): "
                f"{', '.join(sorted(missing)[:5])}"
            )
    elif case_id_col and case_id_col not in header:
        errors.append(
            f"'{filename}' is missing the ID column '{case_id_col}'. "
            f"This column links your predictions to input cases. "
            f"Your CSV has: {', '.join(header)}"
        )

    return errors
