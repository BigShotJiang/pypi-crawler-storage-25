"""Docker container runner: runs participant's Docker locally for testing."""
import tempfile
from pathlib import Path


def run_docker_test(image: str, input_dir: str, timeout: int = 300) -> tuple[str, bool, str]:
    """Run a Docker container with mounted input and capture output.

    Args:
        image: Docker image name or .tar.gz path
        input_dir: path to input data directory
        timeout: max runtime in seconds

    Returns:
        (output_dir, success, logs)
    """
    output_dir = tempfile.mkdtemp(prefix="forithmus_output_")

    try:
        import docker
        client = docker.from_env()

        # Load image from tarball if needed
        if image.endswith((".tar.gz", ".tar")):
            with open(image, "rb") as f:
                loaded = client.images.load(f)
                if loaded:
                    image = loaded[0].tags[0] if loaded[0].tags else loaded[0].id

        # Run container (hardened: non-root, no capabilities, no network)
        container = client.containers.run(
            image,
            volumes={
                input_dir: {"bind": "/input", "mode": "ro"},
                output_dir: {"bind": "/output", "mode": "rw"},
            },
            detach=True,
            remove=False,
            network_disabled=True,
            user="1000:1000",
            cap_drop=["ALL"],
            security_opt=["no-new-privileges:true"],
            pids_limit=512,
            mem_limit="4g",
        )

        # Wait for completion
        result = container.wait(timeout=timeout)
        logs = container.logs().decode("utf-8", errors="replace")
        exit_code = result.get("StatusCode", 1)
        container.remove()

        return output_dir, exit_code == 0, logs

    except ImportError:
        return output_dir, False, "Docker SDK not installed. Run: pip install docker"
    except Exception as e:
        return output_dir, False, str(e)
