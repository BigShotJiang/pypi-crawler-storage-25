"""Boundary tests for ``larva.shell.web`` packaged web surface.

Tests prove:
- Normative REST endpoint inventory matches INTERFACES.md contract
- Startup contract honors port and no-open flags
- Served HTML contains documented UI affordances
- Preserved runnable liveness proof lives in tests/shell/artifacts/web_runtime_liveness.md

Sources:
- INTERFACES.md :: Web Runtime Surface (lines 82-151)
- USER_GUIDE.md :: §14 Web UI and plugin (lines 391-422)
- README.md :: serve and web UI startup examples (lines 221-238)
- tests/shell/artifacts/web_runtime_liveness.md :: packaged runtime probe and captured startup log
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest
from returns.result import Failure, Result, Success

if TYPE_CHECKING:
    from collections.abc import Callable

# FastAPI/TestClient imports are optional at module load time
# to allow tests to run without web dependencies installed
pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from httpx import AsyncClient
from starlette.testclient import TestClient

from larva.app.facade import DefaultLarvaFacade, LarvaError
from larva.core import assemble as assemble_module
from larva.core import normalize as normalize_module
from larva.core import spec as spec_module
from larva.core import validate as validate_module
from larva.core.spec import PersonaSpec
from larva.core.validate import ValidationReport
from larva.shell import web as web_module
from larva.shell import python_api
from larva.shell.web import app
from larva.shell.python_api_components import LarvaApiError


# -----------------------------------------------------------------------------
# Spec-Fixture Conformance: authoritative minimal PersonaSpec
# Source: INTERFACES.md :: PersonaSpec Contract (lines 11-48)
# -----------------------------------------------------------------------------

_MINIMAL_SPEC: PersonaSpec = {
    "id": "test-persona",
    "description": "Test persona",
    "prompt": "You are a test assistant.",
    "model": "test-model",
    "capabilities": {},
    "spec_version": "0.1.0",
}


def _valid_report() -> ValidationReport:
    return {"valid": True, "errors": [], "warnings": []}


def _invalid_report(code: str = "PERSONA_INVALID") -> ValidationReport:
    return {
        "valid": False,
        "errors": [{"code": code, "message": "invalid", "details": {}}],
        "warnings": [],
    }


# -----------------------------------------------------------------------------
# Shared spy doubles for web surface testing
# -----------------------------------------------------------------------------


class CallRecordingRegistry:
    """In-memory registry that records calls for test assertions."""

    def __init__(self) -> None:
        self.save_inputs: list[PersonaSpec] = []
        self.load_outputs: dict[str, PersonaSpec] = {}
        self.list_result: list[PersonaSpec] = []

    def list(self) -> list[PersonaSpec]:
        return list(self.list_result)

    def load(self, persona_id: str) -> PersonaSpec | None:
        return self.load_outputs.get(persona_id)

    def save(self, spec: PersonaSpec) -> None:
        self.save_inputs.append(spec)
        self.load_outputs[spec["id"]] = spec

    def delete(self, persona_id: str) -> bool:
        if persona_id in self.load_outputs:
            del self.load_outputs[persona_id]
            return True
        return False

    def clear(self) -> int:
        count = len(self.load_outputs)
        self.load_outputs.clear()
        return count


@dataclass
class MockFacade:
    """Facade double that delegates to in-memory registry."""

    _registry: CallRecordingRegistry
    _report_map: dict[str, ValidationReport] = field(default_factory=dict)
    assemble_inputs: list[dict[str, Any]] = field(default_factory=list)

    def validate(self, spec: PersonaSpec) -> ValidationReport:
        return self._report_map.get(str(spec.get("id", "")), _valid_report())

    def register(self, spec: PersonaSpec) -> dict[str, Any]:
        self._registry.save(spec)
        return {"id": spec["id"], "registered": True}

    def resolve(
        self, persona_id: str, overrides: dict[str, Any] | None = None
    ) -> PersonaSpec | None:
        return self._registry.load(persona_id)

    def list(self) -> list[dict[str, Any]]:
        return [
            {
                "id": s["id"],
                "description": s.get("description", ""),
                "model": s.get("model", ""),
                "spec_digest": s.get("spec_digest", ""),
            }
            for s in self._registry.list()
        ]

    def update(self, persona_id: str, patches: dict[str, Any]) -> PersonaSpec | None:
        spec = self._registry.load(persona_id)
        if spec is None:
            raise LarvaError(
                error={"code": "PERSONA_NOT_FOUND", "message": f"Persona {persona_id} not found"}
            )
        for key in patches:
            root = key.split(".", 1)[0]
            if root in ("id", "spec_digest", "spec_version"):
                raise LarvaApiError(
                    error={
                        "code": "FORBIDDEN_PATCH_FIELD",
                        "message": (
                            f"patch field '{root}' is not permitted at canonical update boundary"
                        ),
                        "details": {"field": root, "key": key},
                    }
                )
        for key, value in patches.items():
            if key != "id":
                spec[key] = value  # type: ignore[misc]
        self._registry.save(spec)
        return spec

    def delete(self, persona_id: str) -> dict[str, Any]:
        deleted = self._registry.delete(persona_id)
        return {"id": persona_id, "deleted": deleted}

    def clear(self, confirm: str) -> int:
        if confirm != "CLEAR REGISTRY":
            raise LarvaApiError(
                error={"code": "CLEAR_CONFIRMATION_MISMATCH", "message": "Confirmation required"}
            )
        return self._registry.clear()

    def assemble(
        self,
        id: str,
        prompts: list[str] | None = None,
        toolsets: list[str] | None = None,
        constraints: list[str] | None = None,
        model: str | None = None,
        overrides: dict[str, Any] | None = None,
    ) -> PersonaSpec:
        self.assemble_inputs.append(
            {
                "id": id,
                "prompts": prompts,
                "toolsets": toolsets,
                "constraints": constraints,
                "model": model,
                "overrides": overrides,
            }
        )
        spec: PersonaSpec = {
            "id": id,
            "prompt": "\n\n".join(prompts) if prompts else "",
            "model": model or "default-model",
            "capabilities": {},
            "spec_version": "0.1.0",
        }
        return spec


class MockApiError(Exception):
    """Simulates LarvaApiError for error path tests."""

    def __init__(self, error: dict[str, Any]) -> None:
        super().__init__(str(error))
        self.error = error


# -----------------------------------------------------------------------------
# Fixture setup
# -----------------------------------------------------------------------------


@pytest.fixture
def mock_registry() -> CallRecordingRegistry:
    return CallRecordingRegistry()


@pytest.fixture
def mock_facade(mock_registry: CallRecordingRegistry) -> MockFacade:
    return MockFacade(_registry=mock_registry)


# -----------------------------------------------------------------------------
# Tests: Normative endpoint inventory (INTERFACES.md lines 111-123)
# -----------------------------------------------------------------------------


class TestWebSurfaceEndpoints:
    """Tests for packaged web endpoint contract.

    Source: INTERFACES.md :: Normative endpoint inventory (lines 106-129)

    Each test verifies the documented contract:
    - Method and path match the table
    - Response envelope matches envelope rules
    - Error mapping respects LarvaApiError -> HTTP 400
    """

    def test_get_root_returns_html_ui(self) -> None:
        """GET / returns packaged HTML UI artifact.

        Contract: INTERFACES.md line 113
        """
        client = TestClient(app)

        resp = client.get("/")

        assert resp.status_code == 200
        assert "text/html" in resp.headers.get("content-type", "")
        assert "LARVA" in resp.text or "larva" in resp.text.lower()
        # Verify HTML is served, not JSON
        assert resp.text.strip().startswith("<!DOCTYPE") or resp.text.strip().startswith("<html")

    def test_get_api_personas_returns_data_envelope(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """GET /api/personas returns {data: PersonaSummary[]}.

        Contract: INTERFACES.md line 113
        """
        mock_registry.list_result = [
            {
                "id": "alpha",
                "description": "Persona alpha",
                "prompt": "You are alpha.",
                "model": "gpt-4o-mini",
                "capabilities": {},
                "spec_version": "0.1.0",
                "spec_digest": "sha256:alpha",
            }
        ]
        client = TestClient(app)
        monkeypatch.setattr(web_module, "list_personas", lambda: mock_facade.list())

        resp = client.get("/api/personas")

        assert resp.status_code == 200
        data = resp.json()
        assert "data" in data
        assert isinstance(data["data"], list)
        assert data["data"][0]["description"] == "Persona alpha"

    def test_get_api_personas_by_id_returns_spec(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """GET /api/personas/{persona_id} returns resolved spec.

        Contract: INTERFACES.md line 115
        """
        spec: PersonaSpec = {
            "id": "web-test-id",
            "prompt": "You are web test.",
            "model": "test-model",
            "capabilities": {},
            "spec_version": "0.1.0",
        }
        mock_registry.save(spec)
        monkeypatch.setattr(
            web_module,
            "resolve",
            lambda pid, overrides=None: (
                mock_facade.resolve(pid)
                or (_ for _ in ()).throw(
                    LarvaError(
                        error={"code": "PERSONA_NOT_FOUND", "message": f"Persona {pid} not found"}
                    )
                )
            ),
        )

        client = TestClient(app)
        resp = client.get("/api/personas/web-test-id")

        assert resp.status_code == 200
        assert resp.json()["data"]["id"] == "web-test-id"

    def test_post_api_personas_validates_and_registers(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """POST /api/personas validates then registers spec.

        Contract: INTERFACES.md line 116
        """
        monkeypatch.setattr(web_module, "validate", lambda s: _valid_report())
        monkeypatch.setattr(web_module, "register", lambda s: mock_facade.register(s))

        client = TestClient(app)
        payload = {"spec": _MINIMAL_SPEC}

        resp = client.post("/api/personas", json=payload)

        assert resp.status_code == 200
        assert resp.json()["data"]["id"] == "test-persona"
        assert len(mock_registry.save_inputs) == 1

    def test_post_api_personas_rejects_invalid_spec(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """POST /api/personas returns PERSONA_INVALID on validation failure.

        Contract: INTERFACES.md line 116
        Source: USER_GUIDE.md :: VALID_SPEC_VERSION requirement (lines 422-425)
        """
        monkeypatch.setattr(web_module, "validate", lambda s: _invalid_report())

        client = TestClient(app)
        resp = client.post("/api/personas", json={"id": "bad-id"})

        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "PERSONA_INVALID"

    def test_patch_api_personas_updates_and_revalidates(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """PATCH /api/personas/{id} delegates through shared update seam.

        Contract: INTERFACES.md line 117
        """
        spec: PersonaSpec = {
            "id": "update-target",
            "prompt": "Original",
            "model": "old-model",
            "capabilities": {},
            "spec_version": "0.1.0",
            "spec_digest": "sha256:original",
        }
        mock_registry.save(spec)

        def fake_update(pid: str, patches: dict[str, Any]) -> PersonaSpec:
            result = mock_facade.update(pid, patches)
            if result is None:
                raise LarvaError(
                    error={"code": "PERSONA_NOT_FOUND", "message": f"Persona {pid} not found"}
                )
            return result

        monkeypatch.setattr(web_module, "update", fake_update)

        client = TestClient(app)

        # Attempt to patch protected metadata must be rejected
        resp = client.patch(
            "/api/personas/update-target",
            json={
                "model": "new-model",
                "spec_digest": "sha256:malicious",
                "spec_version": "0.2.0",
            },
        )

        assert resp.status_code == 400
        error = resp.json()["error"]
        assert error["code"] == "FORBIDDEN_PATCH_FIELD"
        assert error["details"] == {"field": "spec_digest", "key": "spec_digest"}

    def test_delete_api_personas_returns_deletion_result(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """DELETE /api/personas/{id} returns {data: {id, deleted}}.

        Contract: INTERFACES.md line 118
        """
        spec: PersonaSpec = {
            "id": "delete-me",
            "prompt": "Delete me",
            "model": "test-model",
            "capabilities": {},
            "spec_version": "0.1.0",
        }
        mock_registry.save(spec)

        def fake_delete(pid: str) -> dict[str, Any]:
            return mock_facade.delete(pid)

        monkeypatch.setattr(web_module, "delete", fake_delete)

        client = TestClient(app)
        resp = client.delete("/api/personas/delete-me")

        assert resp.status_code == 200
        assert resp.json()["data"]["id"] == "delete-me"
        assert resp.json()["data"]["deleted"] is True

    def test_post_api_personas_clear_requires_confirmation(
        self,
        mock_facade: MockFacade,
        mock_registry: CallRecordingRegistry,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """POST /api/personas/clear only clears on valid confirmation.

        Contract: INTERFACES.md line 119
        Source: USER_GUIDE.md :: larva clear requires confirmation string (lines 270-274)
        """

        def fake_clear(confirm: str = "") -> int:
            return mock_facade.clear(confirm)

        monkeypatch.setattr(web_module, "clear", fake_clear)

        client = TestClient(app)

        # Add a persona to the registry first
        spec: PersonaSpec = {
            "id": "to-clear",
            "prompt": "Clear me",
            "model": "test",
            "capabilities": {},
            "spec_version": "0.1.0",
        }
        mock_registry.save(spec)

        # Wrong confirmation should return error
        resp = client.post("/api/personas/clear", json={"confirm": "WRONG"})
        assert resp.status_code == 400
        assert "error" in resp.json()

        # Correct confirmation should clear
        resp = client.post("/api/personas/clear", json={"confirm": "CLEAR REGISTRY"})
        assert resp.status_code == 200
        assert "cleared" in resp.json()["data"]

    def test_post_api_personas_validate_returns_report(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """POST /api/personas/validate returns validation report.

        Contract: INTERFACES.md line 120
        """
        monkeypatch.setattr(web_module, "validate", lambda s: _valid_report())

        client = TestClient(app)
        resp = client.post("/api/personas/validate", json=_MINIMAL_SPEC)

        assert resp.status_code == 200
        assert resp.json()["data"]["valid"] is True

    def test_post_api_personas_assemble_returns_spec(
        self, mock_facade: MockFacade, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """POST /api/personas/assemble returns assembled PersonaSpec.

        Contract: INTERFACES.md line 121
        """
        monkeypatch.setattr(
            web_module,
            "assemble",
            lambda id, description=None, prompts=None, toolsets=None, constraints=None, model=None, overrides=None: (
                mock_facade.assemble(
                    id=id,
                    prompts=prompts,
                    toolsets=toolsets,
                    constraints=constraints,
                    model=model,
                    overrides=overrides,
                )
            ),
        )

        client = TestClient(app)
        resp = client.post(
            "/api/personas/assemble",
            json={
                "id": "assembled-persona",
                "prompts": ["You are X.", "Be careful."],
                "toolsets": ["filesystem"],
                "constraints": ["guardrails"],
                "model": "gpt-5.4",
                "overrides": {
                    "can_spawn": ["child-analyst"],
                    "compaction_prompt": "Summarize the active worktree before handoff.",
                },
            },
        )

        assert resp.status_code == 200
        assert resp.json()["data"]["id"] == "assembled-persona"
        assert mock_facade.assemble_inputs == [
            {
                "id": "assembled-persona",
                "prompts": ["You are X.", "Be careful."],
                "toolsets": ["filesystem"],
                "constraints": ["guardrails"],
                "model": "gpt-5.4",
                "overrides": {
                    "can_spawn": ["child-analyst"],
                    "compaction_prompt": "Summarize the active worktree before handoff.",
                },
            }
        ]

    def test_post_api_personas_assemble_rejects_variables_input(
        self, mock_facade: MockFacade, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """POST /api/personas/assemble must reject variables at canonical boundary.

        Hard-cut policy: variables are not permitted at canonical assembly boundary.
        The web endpoint must reject JSON bodies containing 'variables' field.
        """
        monkeypatch.setattr(
            web_module,
            "assemble",
            lambda id, description=None, prompts=None, toolsets=None, constraints=None, model=None, overrides=None: (
                mock_facade.assemble(
                    id=id,
                    prompts=prompts,
                    toolsets=toolsets,
                    constraints=constraints,
                    model=model,
                    overrides=overrides,
                )
            ),
        )

        client = TestClient(app)
        resp = client.post(
            "/api/personas/assemble",
            json={
                "id": "test-vars",
                "prompts": ["You are X."],
                "variables": {"role": "assistant"},  # forbidden legacy field at root
            },
        )

        # Should reject - variables is not a valid assemble input
        assert resp.status_code == 400, f"Expected 400, got {resp.status_code}: {resp.json()}"
        assert "error" in resp.json()

    def test_patch_api_personas_projects_forbidden_patch_field_as_structured_400(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """PATCH /api/personas/{id} must not leak PatchError as a generic 500."""

        class _Registry:
            def __init__(self, spec: PersonaSpec) -> None:
                self._spec = spec

            def save(self, spec: PersonaSpec) -> Result[None, Any]:
                self._spec = spec
                return Success(None)

            def get(self, persona_id: str) -> Result[PersonaSpec, Any]:
                if persona_id != self._spec["id"]:
                    return Failure(
                        {
                            "code": "PERSONA_NOT_FOUND",
                            "message": "missing",
                            "persona_id": persona_id,
                        }
                    )
                return Success(dict(self._spec))

            def list(self) -> Result[list[PersonaSpec], Any]:
                return Success([dict(self._spec)])

            def delete(self, persona_id: str) -> Result[None, Any]:
                return Success(None)

            def clear(self, confirm: str = "CLEAR REGISTRY") -> Result[int, Any]:
                return Success(1)

        class _Components:
            def load_prompt(self, name: str) -> Result[dict[str, str], Any]:
                return Success({"text": name})

            def load_toolset(self, name: str) -> Result[dict[str, dict[str, str]], Any]:
                return Success({"capabilities": {}})

            def load_constraint(self, name: str) -> Result[dict[str, object], Any]:
                return Success({})

            def load_model(self, name: str) -> Result[dict[str, object], Any]:
                return Success({"model": name})

            def list_components(self) -> Result[dict[str, list[str]], Any]:
                return Success({"prompts": [], "toolsets": [], "constraints": [], "models": []})

        facade = DefaultLarvaFacade(
            spec=spec_module,
            assemble=assemble_module,
            validate=validate_module,
            normalize=normalize_module,
            components=_Components(),
            registry=_Registry(
                {
                    **_MINIMAL_SPEC,
                    "spec_digest": "sha256:"
                    + hashlib.sha256(
                        json.dumps(_MINIMAL_SPEC, sort_keys=True, separators=(",", ":")).encode(
                            "utf-8"
                        )
                    ).hexdigest(),
                }
            ),
        )
        monkeypatch.setattr(python_api, "_get_facade", lambda: facade)

        client = TestClient(app)
        resp = client.patch(
            "/api/personas/test-persona",
            json={"tools": {"shell": "read_write"}},
        )

        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "FORBIDDEN_PATCH_FIELD"
        assert resp.json()["error"]["details"] == {"field": "tools", "key": "tools"}

    def test_get_api_components_lists_names(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """GET /api/components returns component names.

        Contract: INTERFACES.md line 122
        """
        client = TestClient(app)
        resp = client.get("/api/components")

        assert resp.status_code == 200
        data = resp.json()["data"]
        assert "prompts" in data
        assert "toolsets" in data
        assert "constraints" in data
        assert "models" in data

    def test_get_api_components_by_type_name_raises_400_on_invalid_type(self) -> None:
        """GET /api/components/{type}/{name} returns 400 for invalid type.

        Contract: INTERFACES.md line 123
        """
        client = TestClient(app)
        resp = client.get("/api/components/invalid-type/test")

        assert resp.status_code == 400
        assert "Invalid component type" in resp.text
        assert "prompts | toolsets | constraints | models" in resp.text

    def test_get_api_components_by_type_name_rejects_singular_alias(self) -> None:
        """GET /api/components/{type}/{name} rejects singular type aliases."""
        client = TestClient(app)
        resp = client.get("/api/components/prompt/test")

        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "INVALID_INPUT"
        assert resp.json()["error"]["details"]["reason"] == "invalid_kind"

    def test_post_api_personas_assemble_missing_id_returns_structured_invalid_input(self) -> None:
        """POST /api/personas/assemble must fail closed when id is omitted."""
        client = TestClient(app)

        resp = client.post(
            "/api/personas/assemble",
            json={
                "prompts": ["base-prompt"],
                "toolsets": ["filesystem"],
                "constraints": ["safe"],
                "model": "gpt-4o-mini",
            },
        )

        assert resp.status_code == 400
        body = resp.json()
        assert body["error"]["code"] == "INVALID_INPUT"
        assert body["error"]["numeric_code"] == 1
        assert "id" in body["error"]["message"]
        assert body["error"]["details"] == {"field": "id", "reason": "missing_required_field"}

    @pytest.mark.parametrize(
        ("method", "path"),
        [
            ("post", "/api/personas"),
            ("patch", "/api/personas/test-persona"),
            ("post", "/api/personas/clear"),
            ("post", "/api/personas/validate"),
            ("post", "/api/personas/assemble"),
        ],
    )
    def test_json_body_endpoints_reject_non_object_payloads_with_structured_400(
        self,
        method: str,
        path: str,
    ) -> None:
        """JSON-body endpoints must fail closed on non-object JSON payloads."""
        client = TestClient(app, raise_server_exceptions=False)

        response = getattr(client, method)(path, json=["not", "an", "object"])

        assert response.status_code == 400
        body = response.json()
        assert body["error"]["code"] == "INVALID_INPUT"
        assert body["error"]["numeric_code"] == 1
        assert body["error"]["message"] == "params must be an object"
        assert body["error"]["details"]["field"] == "params"

    def test_post_api_personas_rejects_non_object_spec_wrapper_with_structured_400(self) -> None:
        """POST /api/personas must reject wrapped spec values that are not objects."""
        client = TestClient(app, raise_server_exceptions=False)

        response = client.post("/api/personas", json={"spec": ["not", "an", "object"]})

        assert response.status_code == 400
        body = response.json()
        assert body["error"]["code"] == "INVALID_INPUT"
        assert body["error"]["numeric_code"] == 1
        assert body["error"]["message"] == "parameter 'spec' must be object"
        assert body["error"]["details"]["field"] == "spec"

    def test_get_api_components_projection_returns_ui_metadata(self) -> None:
        """GET /api/components/projection returns web-facing display metadata.

        The projection endpoint provides UI-only display metadata (labels,
        descriptions) for rendering the preset-library and compose-persona UI.

        Canonical component kind vocabulary (prompts, toolsets, constraints,
        models) is preserved as the authoritative internal category. The
        projection does NOT change any canonical input fields.

        Contract: this endpoint is additive — existing /api/components behavior
        is unchanged.
        """
        client = TestClient(app)
        resp = client.get("/api/components/projection")

        assert resp.status_code == 200
        data = resp.json()["data"]
        assert isinstance(data, list)
        assert len(data) == 4

        # Verify projection structure for each canonical kind
        for item in data:
            assert "canonical_kind" in item
            assert "display_label" in item
            assert "plural_display_label" in item
            assert "description" in item
            assert "singular_alias" in item
            assert "assemble_field" in item
            assert "ui_hint" in item

        # Verify toolsets projection uses "Capability Preset" wording
        toolsets_proj = next(p for p in data if p["canonical_kind"] == "toolsets")
        assert toolsets_proj["display_label"] == "Capability Preset"
        assert toolsets_proj["plural_display_label"] == "Capability Presets"
        assert toolsets_proj["assemble_field"] == "toolsets"
        assert toolsets_proj["ui_hint"] == "preset"

        # Verify prompts still use "Prompt" wording
        prompts_proj = next(p for p in data if p["canonical_kind"] == "prompts")
        assert prompts_proj["display_label"] == "Prompt"
        assert prompts_proj["plural_display_label"] == "Prompts"
        assert prompts_proj["ui_hint"] == "prompt"

        # Verify constraints are still exposed (not hidden from UI)
        constraints_proj = next(p for p in data if p["canonical_kind"] == "constraints")
        assert constraints_proj["display_label"] == "Constraint"
        assert constraints_proj["assemble_field"] == "constraints"

    def test_get_api_components_projection_is_additive(self) -> None:
        """The projection endpoint does not change existing /api/components behavior.

        Both endpoints must continue to work independently.
        """
        client = TestClient(app)

        # Original endpoint still works
        resp_components = client.get("/api/components")
        assert resp_components.status_code == 200
        assert "prompts" in resp_components.json()["data"]
        assert "toolsets" in resp_components.json()["data"]

        # Projection endpoint is additive
        resp_projection = client.get("/api/components/projection")
        assert resp_projection.status_code == 200
        assert len(resp_projection.json()["data"]) == 4


# -----------------------------------------------------------------------------
# Tests: Convenience-only UI behavior documentation
# Source: INTERFACES.md lines 131-138
# -----------------------------------------------------------------------------


class TestWebUiHtmlContent:
    """Tests verifying HTML UI contains documented affordances.

    Source: INTERFACES.md :: Convenience-only UI behavior (lines 131-138)
    Source: INTERFACES.md web runtime contract (line 97: serves HTML)
    """

    def test_served_html_contains_prompt_copy_button(self) -> None:
        """HTML contains copy prompt affordance for operator convenience.

        Contract: INTERFACES.md lines 136-137
        Source: src/larva/shell/web_ui.html copy button implementation
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        assert html_path.exists(), "web_ui.html should exist"

        content = html_path.read_text()
        # Verify copy prompt affordance exists
        assert "copyPrompt" in content, "HTML should contain copyPrompt function"
        assert "navigator.clipboard" in content, "Copy should use browser clipboard API"
        assert 'title="Copy prompt"' in content, "Copy button should have accessible title"

    def test_served_html_contains_staged_state_visual_indicators(self) -> None:
        """HTML UI displays staged changes visual feedback.

        Source: INTERFACES.md convenience-only UI behavior requires one shared
        staged-change treatment for editable sections.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        # Verify staged state indicators exist
        assert "staged" in content, "HTML should track staged changes"
        assert ".staged-border" in content, "Shared staged border utility should exist"
        assert ".staged-section" in content, "Shared staged section utility should exist"
        assert "border-left:2px solid var(--warning);padding-left:8px" not in content, (
            "Repeated inline staged section styling should be removed"
        )

    def test_components_view_uses_preset_library_copy_and_internal_source_labels(self) -> None:
        """Components view should present a preset library without losing canonical source kinds.

        Source: user task web_preset_redesign_followup.web-preset-library-ui
        Required outcome: preset-library wording becomes primary while internal
        component kinds remain inspectable in the HTML surface.
        """
        client = TestClient(app)
        resp = client.get("/")

        assert resp.status_code == 200
        html = resp.text

        assert "Preset Library" in html
        assert "Prompt Presets" in html
        assert "Capability Presets" in html
        assert "Behavior & Policy Presets" in html
        assert "Model Presets" in html
        assert "Internal source" in html
        assert "Component Library" not in html
        assert ">Components</button>" not in html
        assert "type.toUpperCase()" not in html

    def test_compose_persona_modal_uses_output_first_copy_and_hides_constraints_picker(
        self,
    ) -> None:
        """Compose modal should lead with output copy and capability presets.

        Source: user task web_preset_redesign_followup.web-compose-persona-reframe
        Required outcome: output-first compose wording replaces assembly-first
        copy, toolsets are shown as capability presets, and constraints are not
        exposed as a top-level picker.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "Compose Persona" in content
        assert "Start with the persona output you want" in content
        assert '<div class="section-label">Output Persona ID</div>' in content
        assert '<div class="section-label">Capability Presets</div>' in content
        assert '<div class="section-label">Behavior Preset</div>' in content
        assert '<div class="section-label">Constraints</div>' not in content
        assert "Assemble Persona" not in content

    def test_compose_persona_modal_prefills_behavior_presets_but_keeps_fields_editable(
        self,
    ) -> None:
        """Compose modal should prefill editable behavior fields from presets.

        Source: user task web_preset_redesign_followup.web-compose-persona-reframe
        Completion criteria: behavior presets may prefill can_spawn /
        compaction_prompt while both fields remain directly editable before
        submission.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "applyAssembleBehaviorPreset" in content
        assert "fetch(`/api/components/constraints/${name}`)" in content
        assert "assembleForm.overrides.can_spawn" in content
        assert "assembleForm.overrides.compaction_prompt" in content
        assert "setComposeSpawnMode('specific')" in content
        assert "removeComposeSpawnTag(i)" in content

    def test_compose_persona_modal_handles_behavior_preset_prefill_failures(self) -> None:
        """Compose modal should surface preset-prefill failures without re-exposing constraints.

        Source: user task web_preset_redesign_followup.web-compose-persona-reframe
        Failure coverage: behavior preset fetch failures leave direct-edit
        fields available and surface inline feedback.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "assemblePresetStatus" in content
        assert "assemblePresetError" in content
        assert "Failed to load behavior preset preview" in content
        assert (
            "Behavior preset preview unavailable. You can still edit spawn policy and compaction prompt directly."
            in content
        )

    def test_served_html_uses_sidebar_description_fallback_without_digest_noise(self) -> None:
        """Sidebar summary rows should prefer description and show empty fallback copy.

        Source: INTERFACES.md convenience-only UI behavior for sidebar summary rows.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "x-text=\"p.description || 'No description'\"" in content
        assert "((p.spec_digest || '').slice(0, 24) + '...')" not in content
        assert ":title=\"p.spec_digest || ''\"" in content

    def test_served_html_uses_multiline_editors_for_description_and_compaction(self) -> None:
        """Description and compaction prompt should use multi-line editing surfaces.

        Source: INTERFACES.md convenience-only UI behavior for multi-line text fields.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert '<textarea class="inline-input inline-textarea"' in content
        assert "commitEdit('description')" in content
        assert (
            '<textarea class="prompt-editor" :class="{ \'staged-border\': staged.compaction_prompt !== undefined }"'
            in content
        )

    def test_served_html_uses_prompt_toggle_wording_and_non_interrupting_full_json_view(
        self,
    ) -> None:
        """Prompt controls should use approved wording and not interrupt editing.

        Source: INTERFACES.md convenience-only UI behavior for prompt detail toggles.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "showRawJson ? 'Detail' : 'Full JSON'" in content
        assert "showRawJson ? 'Detail' : 'Raw JSON'" not in content
        assert "editingPrompt ? 'Close' : 'Edit'" in content
        assert ':disabled="editingPrompt"' in content
        assert "this.showRawJson = false;" in content

    def test_served_html_uses_close_wording_for_non_persisting_section_toggles(self) -> None:
        """Section mode toggles should use Close wording when save remains staged.

        Source: INTERFACES.md convenience-only UI behavior and user-approved staged-save model.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "editingCapabilities ? 'Close' : 'Edit'" in content
        assert "editingParams ? 'Close' : 'Edit'" in content
        assert "editingCapabilities ? 'Done' : 'Edit'" not in content
        assert "editingParams ? 'Done' : 'Edit'" not in content

    def test_served_html_contains_three_state_spawn_policy_control(self) -> None:
        """HTML exposes the approved three-state spawn policy affordance.

        Source: user-approved web UI copy and INTERFACES.md convenience-only UI behavior.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "SPAWN POLICY" in content
        assert 'aria-label="Spawn policy"' in content
        assert ">None</button>" in content
        assert ">Any</button>" in content
        assert ">Specific</button>" in content
        assert "Cannot spawn child personas" in content
        assert "Can spawn any persona" in content
        assert "Can spawn only listed personas" in content
        assert "setSpawnPolicyMode('none')" in content
        assert "setSpawnPolicyMode('any')" in content
        assert "setSpawnPolicyMode('specific')" in content
        assert "getSpawnSpecificTags" in content
        assert "add persona id..." in content

    def test_served_html_no_longer_uses_old_bool_shaped_spawn_toggle_copy(self) -> None:
        """Spawn policy UI should not present the old bool-ish toggle wording as primary UX.

        Source: user-approved replacement of the old can_spawn toggle/tag bifurcation.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert '<div class="meta-label">can_spawn</div>' not in content
        assert "Set to true" not in content
        assert "@click=\"stageChange('can_spawn', !getVal('can_spawn'))\"" not in content

    def test_html_contains_api_endpoint_references(self) -> None:
        """HTML UI references normative REST endpoints from contract.

        Source: INTERFACES.md endpoint inventory (lines 111-123)
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        # Verify normative API paths are referenced in JS fetch calls
        assert "/api/personas" in content, "HTML should reference /api/personas endpoint"
        assert "/api/components" in content, "HTML should reference /api/components endpoint"

    def test_html_preserves_summary_library_when_detail_fetch_fails(self) -> None:
        """HTML keeps list summaries visible even when per-persona resolve fails.

        Source: src/larva/shell/web_ui.html summary/detail loading logic
        Regression target: legacy registry entries should remain visible in the library.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "this.personas = summaries" in content, (
            "Library should keep summary results instead of replacing them with resolved details"
        )
        assert "ensurePersonaDetail" in content, (
            "Detail loading should be a separate step from summary listing"
        )
        assert "Full persona details unavailable" in content, (
            "UI should explain unresolved detail failures instead of hiding the entry"
        )
        assert "full.filter(Boolean)" not in content, (
            "UI must not drop personas solely because full-detail loading failed"
        )

    def test_html_distinguishes_registry_loading_empty_and_blocking_error_states(self) -> None:
        """HTML separates registry loading, true-empty, and blocking list failure UX.

        Source: vectl step hard_cut_finish_20260417_registry_ux_cleanup.web_registry_error_state
        Source: runtime contract says /api/personas error envelope must block instead of rendering empty library.
        Regression target: error envelopes from the authoritative list endpoint must not fall through to the empty state.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "personaRegistryState" in content, "UI should track registry load state explicitly"
        assert "personaRegistryError" in content, (
            "UI should preserve the blocking registry error message"
        )
        assert "personaRegistryState === 'loading'" in content, (
            "UI should render a dedicated loading state while /api/personas is in flight"
        )
        assert "personaRegistryState === 'ready' && personas.length === 0" in content, (
            "True-empty state should only render after a successful empty registry response"
        )
        assert "personaRegistryState === 'error'" in content, (
            "Blocking registry errors should render distinctly from empty results"
        )
        assert "Unable to load persona library" in content, (
            "Blocking state should explain that the canonical registry failed closed"
        )

    def test_html_omits_legacy_tools_and_side_effect_policy_sections(self) -> None:
        """HTML should not render forbidden legacy persona fields as first-class UI sections.

        Source: canonical PersonaSpec excludes tools and side_effect_policy.
        """
        html_path = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web_ui.html"
        content = html_path.read_text()

        assert "TOOLS (deprecated)" not in content
        assert "SIDE EFFECT POLICY (deprecated)" not in content
        assert "toggleToolsEdit" not in content
        assert "syncTools" not in content


# -----------------------------------------------------------------------------
# Tests: Startup contract
# Source: INTERFACES.md :: Startup contract (lines 90-104)
# -----------------------------------------------------------------------------


class TestWebStartupContract:
    """Tests for larva serve startup behavior.

    Source: INTERFACES.md :: Startup contract (lines 90-104)
    Source: USER_GUIDE.md §14 (lines 393-405)
    """

    def test_main_default_port_is_7400(self) -> None:
        """Server defaults to port 7400.

        Contract: INTERFACES.md lines 94-96
        """
        # Use function signature to verify defaults
        import inspect

        sig = inspect.signature(web_module.main)
        port_param = sig.parameters.get("port")
        assert port_param is not None
        assert port_param.default == 7400

    def test_main_accepts_port_and_no_open_arguments(self) -> None:
        """main() accepts port and no_open arguments.

        Contract: INTERFACES.md lines 96-97
        """
        import inspect

        sig = inspect.signature(web_module.main)
        assert "port" in sig.parameters
        assert "no_open" in sig.parameters
        no_open_param = sig.parameters.get("no_open")
        assert no_open_param is not None
        assert no_open_param.default is False

    def test_app_serves_packaged_web_ui_html_at_root(self) -> None:
        """Root path serves web_ui.html from static dir.

        Contract: INTERFACES.md line 97
        Source: src/larva/shell/web.py serve_index function
        """
        # Static file served at root
        client = TestClient(app)
        resp = client.get("/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers.get("content-type", "")

    def test_uvicorn_binding_host_is_localhost(self) -> None:
        """Server binds to 127.0.0.1 by default.

        Contract: INTERFACES.md line 94
        """
        # The uvicorn.run call uses 127.0.0.1
        # Verify via source inspection
        source = Path(__file__).parent.parent.parent / "src" / "larva" / "shell" / "web.py"
        content = source.read_text()
        assert 'host="127.0.0.1"' in content or "host='127.0.0.1'" in content, (
            "Should bind to 127.0.0.1"
        )


# -----------------------------------------------------------------------------
# Tests: Error envelope conformance
# Source: INTERFACES.md lines 125-129
# -----------------------------------------------------------------------------


class TestWebErrorEnvelope:
    """Tests for response envelope rules.

    Source: INTERFACES.md :: Shared response envelope rules (lines 125-129)
    """

    def test_success_responses_use_data_envelope(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Successful responses return {"data": ...} envelope.

        Contract: INTERFACES.md line 127
        """
        monkeypatch.setattr(web_module, "validate", lambda s: _valid_report())

        client = TestClient(app)
        resp = client.post("/api/personas/validate", json=_MINIMAL_SPEC)

        assert "data" in resp.json()
        assert resp.status_code == 200

    def test_larva_api_error_maps_to_400_with_error_envelope(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """LarvaApiError maps to HTTP 400 with {"error": ...} envelope.

        Contract: INTERFACES.md lines 127-128
        """

        def raise_api_error() -> None:
            raise LarvaApiError(error={"code": "PERSONA_NOT_FOUND", "message": "Persona not found"})

        def list_with_error() -> list[dict[str, Any]]:
            raise_api_error()
            raise AssertionError("unreachable")  # type: ignore[unreachable]

        monkeypatch.setattr(web_module, "list_personas", list_with_error)

        client = TestClient(app)
        resp = client.get("/api/personas")

        assert resp.status_code == 400
        assert "error" in resp.json()
