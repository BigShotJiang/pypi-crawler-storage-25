"""Boundary tests for ``larva.shell.cli`` facade-backed commands.

Task boundary: shell_cli.shell-cli-component-implement
- Tests facade-backed commands: validate, assemble, register, resolve, list
- Tests component commands: component list/show via injected ComponentStore seam
- Uses doubles/harness for downstream seams (facade, component store, registry)

Coverage:
- text + `--json` success path behavior
- exit code mapping 0/1/2 for valid/invalid/not-found/generic errors
- JSON error envelope with code/numeric_code/message/details
- regressions: JSON/text separation, resolve not-found vs generic failure exit codes,
  validate invalid-spec exits 1

Sources:
- ARCHITECTURE.md :: Module: larva.shell.cli
- INTERFACES.md :: B. CLI Interface
- INTERFACES.md :: G. Error Codes
"""

from __future__ import annotations

import hashlib
import json
import importlib
import io
import runpy
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, cast

import pytest
from returns.result import Failure, Result, Success

from larva.app.facade import (
    AssembleRequest,
    DefaultLarvaFacade,
    LarvaError,
    PersonaSummary,
    RegisteredPersona,
)
from larva import cli_facade
from larva.core import assemble as assemble_module
from larva.core import normalize as normalize_module
from larva.core import spec as spec_module
from larva.core import validate as validate_module
from larva.core.spec import PersonaSpec
from larva.core.validate import ValidationReport
from larva import cli_entrypoint
from larva.shell import cli
from larva.shell import cli_runtime
from larva.shell.components import ComponentStoreError
from larva.shell.cli import (
    EXIT_ERROR,
    EXIT_CRITICAL,
    EXIT_OK,
    CliCommandResult,
    CliFailure,
    JsonErrorEnvelope,
    assemble_command,
    component_list_command,
    component_show_command,
    list_command,
    run_cli,
    register_command,
    resolve_command,
    validate_command,
)
from larva.shell.cli_projection import (
    project_validation_report,
    render_validation_report_text,
)
from larva.shell.cli_types import CliCommandResult as SharedCliCommandResult
from larva.shell.cli_types import CliFailure as SharedCliFailure
from larva.shell.cli_types import JsonErrorEnvelope as SharedJsonErrorEnvelope
from tests.shell.fixture_taxonomy import (
    canonical_constraint_fixture,
    canonical_persona_spec,
    canonical_toolset_fixture,
)

if TYPE_CHECKING:
    from larva.shell.registry import RegistryError


def test_package_cli_main_delegates_to_shell_cli(monkeypatch: pytest.MonkeyPatch) -> None:
    from larva import cli as compat_cli

    calls: list[list[str] | None] = []

    def fake_main(argv: list[str] | None = None) -> int:
        calls.append(argv)
        return 17

    monkeypatch.setattr(compat_cli.shell_cli, "main", fake_main)

    exported_main = compat_cli.main

    assert exported_main(["list"]) == 17
    assert calls == [["list"]]


def test_python_module_cli_executes_same_shell_entrypoint(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[object] = []

    def fake_main(argv: object = None) -> int:
        calls.append(argv)
        return 9

    monkeypatch.setattr("larva.shell.cli.main", fake_main)
    sys.modules.pop("larva.cli", None)

    with pytest.raises(SystemExit) as exc_info:
        runpy.run_module("larva.cli", run_name="__main__")

    assert exc_info.value.code == 9
    assert calls == [None]


def test_cli_entrypoint_delegates_to_shell_cli_main(monkeypatch: pytest.MonkeyPatch) -> None:
    facade = object()
    component_store = object()
    calls: list[tuple[list[str], object, object]] = []

    def fake_build_default_facade() -> object:
        return facade

    def fake_component_store() -> object:
        return component_store

    def fake_run_cli(
        argv: list[str],
        *,
        facade: object,
        stdout: object,
        stderr: object,
        component_store: object | None = None,
    ) -> int:
        calls.append((argv, facade, component_store))
        assert stdout is sys.stdout
        assert stderr is sys.stderr
        return 23

    monkeypatch.setattr(cli_entrypoint, "build_default_facade", fake_build_default_facade)
    monkeypatch.setattr(cli_entrypoint, "FilesystemComponentStore", fake_component_store)
    monkeypatch.setattr("larva.shell.cli.run_cli", fake_run_cli)

    assert cli_entrypoint.main(["list"]) == 23
    assert calls == [(["list"], facade, component_store)]


def test_cli_facade_wrapper_uses_shared_default_factory(monkeypatch: pytest.MonkeyPatch) -> None:
    sentinel = object()
    calls: list[str] = []

    def fake_build_default_facade() -> object:
        calls.append("build")
        return sentinel

    monkeypatch.setattr(
        "larva.shell.shared.facade_factory.build_default_facade",
        fake_build_default_facade,
    )

    assert cli_facade.build_default_facade() is sentinel
    assert calls == ["build"]


def test_cli_facade_and_python_api_share_default_factory_entrypoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[object] = []

    def fake_build_default_facade() -> object:
        facade = object()
        calls.append(facade)
        return facade

    monkeypatch.setattr(
        "larva.shell.shared.facade_factory.build_default_facade",
        fake_build_default_facade,
    )

    import larva.shell.python_api as python_api_module

    reloaded_python_api = importlib.reload(python_api_module)
    reloaded_cli_facade = importlib.reload(cli_facade)
    try:
        python_api_build_count = len(calls)
        cli_facade_instance = reloaded_cli_facade.build_default_facade()

        assert python_api_build_count >= 1
        assert len(calls) == python_api_build_count + 1
        assert reloaded_python_api._get_facade() is calls[python_api_build_count - 1]
        assert cli_facade_instance is calls[-1]
    finally:
        importlib.reload(reloaded_python_api)
        importlib.reload(reloaded_cli_facade)


def test_cli_facade_source_has_no_direct_default_facade_constructor() -> None:
    assert cli_facade.__file__ is not None
    source = Path(cli_facade.__file__).read_text(encoding="utf-8")

    assert "DefaultLarvaFacade(" not in source
    assert "_build_default_facade" not in source


def test_shell_cli_source_uses_shared_factory_without_entrypoint_reexport() -> None:
    assert cli.__file__ is not None
    source = Path(cli.__file__).read_text(encoding="utf-8")

    assert "from larva.cli_entrypoint import main" in source
    assert "from larva.cli_facade import build_default_facade" not in source
    assert "from larva.shell.shared.facade_factory import build_default_facade" in source


def test_cli_entrypoint_source_has_no_local_default_factory_or_store_authority() -> None:
    assert cli_entrypoint.__file__ is not None
    source = Path(cli_entrypoint.__file__).read_text(encoding="utf-8")

    assert "from larva.cli_facade import build_default_facade" not in source
    assert "from larva.shell.shared.facade_factory import build_default_facade" in source
    assert "FilesystemComponentStore(" in source
    assert "run_cli(" in source


def _canonical_spec(persona_id: str, digest: str | None = None) -> PersonaSpec:
    return canonical_persona_spec(persona_id=persona_id, digest=digest)


def _digest_for(spec: dict[str, object]) -> str:
    payload = {k: v for k, v in spec.items() if k != "spec_digest"}
    canonical_json = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return f"sha256:{hashlib.sha256(canonical_json.encode('utf-8')).hexdigest()}"


def _valid_report() -> ValidationReport:
    return {"valid": True, "errors": [], "warnings": []}


def _invalid_report(code: str = "PERSONA_INVALID") -> ValidationReport:
    return {
        "valid": False,
        "errors": [{"code": code, "message": "invalid", "details": {}}],
        "warnings": [],
    }


# ============================================================================
# Test Doubles for Downstream Dependencies
# ============================================================================


@dataclass
class SpyAssembleModule:
    candidate: PersonaSpec
    calls: list[str] = field(default_factory=list)
    inputs: list[dict[str, object]] = field(default_factory=list)

    def assemble_candidate(self, data: dict[str, object]) -> PersonaSpec:
        self.calls.append("assemble")
        self.inputs.append(data)
        return dict(self.candidate)


@dataclass
class SpyValidateModule:
    report: ValidationReport
    calls: list[str] = field(default_factory=list)
    inputs: list[PersonaSpec] = field(default_factory=list)

    def validate_spec(
        self,
        spec: PersonaSpec,
        registry_persona_ids: frozenset[str] | None = None,
    ) -> ValidationReport:
        self.calls.append("validate")
        self.inputs.append(dict(spec))
        return self.report


@dataclass
class SpyNormalizeModule:
    calls: list[str] = field(default_factory=list)
    inputs: list[PersonaSpec] = field(default_factory=list)

    def normalize_spec(self, spec: PersonaSpec) -> PersonaSpec:
        self.calls.append("normalize")
        normalized = dict(spec)
        # Simple digest based on id only (avoid hashing nested dicts)
        normalized["spec_digest"] = f"sha256:{normalized.get('id', 'unknown')}"
        self.inputs.append(normalized)
        return normalized


@dataclass
class InMemoryComponentStore:
    """Minimal component store double for CLI component command tests."""

    list_result: Result[dict[str, list[str]], Exception] = field(
        default_factory=lambda: Success(
            {
                "prompts": ["default-prompt"],
                "toolsets": ["default-toolset"],
                "constraints": ["default-constraint"],
                "models": ["default-model"],
            }
        )
    )
    prompt_result: Result[dict[str, str], Exception] = field(
        default_factory=lambda: Success({"text": "Prompt body"})
    )
    toolset_result: Result[dict[str, dict[str, str]], Exception] = field(
        default_factory=lambda: Success(canonical_toolset_fixture())
    )
    constraint_result: Result[dict[str, object], Exception] = field(
        default_factory=lambda: Success(canonical_constraint_fixture())
    )
    model_result: Result[dict[str, object], Exception] = field(
        default_factory=lambda: Success({"model": "gpt-4o-mini"})
    )
    last_loaded: tuple[str, str] | None = None

    def load_prompt(self, name: str) -> Result[dict[str, str], Exception]:
        self.last_loaded = ("prompts", name)
        if name in {"missing", "nonexistent"}:
            return Failure(ComponentStoreError(f"Prompt not found: {name}", "prompt", name))
        return self.prompt_result

    def load_toolset(self, name: str) -> Result[dict[str, dict[str, str]], Exception]:
        self.last_loaded = ("toolsets", name)
        if name in {"missing", "nonexistent"}:
            return Failure(ComponentStoreError(f"Toolset not found: {name}", "toolset", name))
        return self.toolset_result

    def load_constraint(self, name: str) -> Result[dict[str, object], Exception]:
        self.last_loaded = ("constraints", name)
        if name in {"missing", "nonexistent"}:
            return Failure(ComponentStoreError(f"Constraint not found: {name}", "constraint", name))
        return self.constraint_result

    def load_model(self, name: str) -> Result[dict[str, object], Exception]:
        self.last_loaded = ("models", name)
        if name in {"missing", "nonexistent"}:
            return Failure(ComponentStoreError(f"Model not found: {name}", "model", name))
        return self.model_result

    def list_components(self) -> Result[dict[str, list[str]], Exception]:
        return self.list_result


@dataclass
class InMemoryRegistryStore:
    """Minimal registry store double for CLI tests."""

    get_result: Result[PersonaSpec, Any] = field(
        default_factory=lambda: Success(_canonical_spec("default"))
    )
    list_result: Result[list[PersonaSpec], Any] = field(default_factory=lambda: Success([]))
    save_result: Result[None, Any] = field(default_factory=lambda: Success(None))
    delete_result: Result[None, Any] = field(default_factory=lambda: Success(None))
    clear_result: Result[int, Any] = field(default_factory=lambda: Success(0))
    save_inputs: list[PersonaSpec] = field(default_factory=list)
    last_delete_id: str | None = None
    last_clear_confirm: str | None = None

    def save(self, spec: PersonaSpec) -> Result[None, Any]:
        self.save_inputs.append(dict(spec))
        return self.save_result

    def get(self, persona_id: str) -> Result[PersonaSpec, Any]:
        return self.get_result

    def list(self) -> Result[list[PersonaSpec], Any]:
        return self.list_result

    def delete(self, persona_id: str) -> Result[None, Any]:
        self.last_delete_id = persona_id
        return self.delete_result

    def clear(self, confirm: str = "CLEAR REGISTRY") -> Result[int, Any]:
        self.last_clear_confirm = confirm
        return self.clear_result


def _make_facade(
    *,
    report: ValidationReport | None = None,
    candidate: PersonaSpec | None = None,
    components: InMemoryComponentStore | None = None,
    registry: InMemoryRegistryStore | None = None,
) -> DefaultLarvaFacade:
    """Create a test facade with specified doubles."""
    assemble_module = SpyAssembleModule(candidate or _canonical_spec("assembled"))
    validate_module = SpyValidateModule(report or _valid_report())
    normalize_module = SpyNormalizeModule()
    return DefaultLarvaFacade(
        spec=spec_module,
        assemble=assemble_module,
        validate=validate_module,
        normalize=normalize_module,
        components=components or InMemoryComponentStore(),
        registry=registry or InMemoryRegistryStore(),
    )


# ============================================================================
# Validate Command Tests
# ============================================================================


class TestValidateCommand:
    """Tests for the validate command handler."""

    def test_validate_success_text_mode_returns_exit_ok(self) -> None:
        """Validate with valid spec returns exit code 0 in text mode."""
        facade = _make_facade(report=_valid_report())
        spec = _canonical_spec("valid-spec")

        result = validate_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_validate_success_json_mode_returns_exit_ok_with_json_payload(self) -> None:
        """Validate with valid spec returns JSON payload in JSON mode."""
        facade = _make_facade(report=_valid_report())
        spec = _canonical_spec("valid-spec")

        result = validate_command(spec, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["valid"] is True

    def test_validate_invalid_spec_returns_exit_error(self) -> None:
        """Validate with invalid spec returns exit code 1 in text mode."""
        facade = _make_facade(report=_invalid_report("INVALID_SPEC_VERSION"))
        spec = _canonical_spec("invalid-spec")

        result = validate_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        # Regression: validate invalid-spec must exit 1, not 0 or 2
        assert failure["exit_code"] == 1

    def test_validate_invalid_spec_json_mode_returns_error_envelope(self) -> None:
        """Validate with invalid spec returns JSON error envelope in JSON mode."""
        facade = _make_facade(report=_invalid_report("INVALID_SPEC_VERSION"))
        spec = _canonical_spec("invalid-spec")

        result = validate_command(spec, as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert "code" in error
        assert "numeric_code" in error
        assert "message" in error
        assert "details" in error
        assert error["code"] == "PERSONA_INVALID"
        assert error["numeric_code"] == 101

    def test_validate_invalid_text_and_json_projections_share_primary_message(self) -> None:
        """Text and JSON failure projections should agree on the primary validation message."""
        report: ValidationReport = {
            "valid": False,
            "errors": [
                {
                    "code": "EXTRA_FIELD_NOT_ALLOWED",
                    "message": "unknown top-level field 'tools' is not permitted at canonical admission boundary",
                    "details": {"field": "tools"},
                }
            ],
            "warnings": [],
        }
        facade = _make_facade(report=report)
        spec = _canonical_spec("invalid-projection")

        text_result = validate_command(spec, as_json=False, facade=facade)
        json_result = validate_command(spec, as_json=True, facade=facade)

        assert isinstance(text_result, Failure)
        assert isinstance(json_result, Failure)
        assert (
            text_result.failure()["exit_code"] == json_result.failure()["exit_code"] == EXIT_ERROR
        )
        assert report["errors"][0]["message"] in text_result.failure()["stderr"]
        assert json_result.failure()["error"]["message"] == report["errors"][0]["message"]
        assert json_result.failure()["error"]["details"]["report"] == report

    def test_validate_warning_text_and_json_projections_preserve_same_warning_facts(self) -> None:
        """Text and JSON success projections should preserve the same warning facts."""
        report: ValidationReport = {
            "valid": True,
            "errors": [],
            "warnings": [
                "unknown model identifier 'custom-model-x' is outside the known-model snapshot",
                "capabilities is empty; this is valid but likely under-specified",
            ],
        }
        facade = _make_facade(report=report)
        spec = _canonical_spec("warning-projection")

        text_result = validate_command(spec, as_json=False, facade=facade)
        json_result = validate_command(spec, as_json=True, facade=facade)

        assert isinstance(text_result, Success)
        assert isinstance(json_result, Success)
        assert text_result.unwrap()["exit_code"] == json_result.unwrap()["exit_code"] == EXIT_OK
        for warning in report["warnings"]:
            assert warning in text_result.unwrap()["stdout"]
        assert json_result.unwrap()["json"]["data"] == report

    def test_validate_real_facade_surfaces_registry_snapshot_warning(self) -> None:
        """Real validation path must surface registry-context warnings instead of fixed empty warnings."""
        facade = DefaultLarvaFacade(
            spec=spec_module,
            assemble=SpyAssembleModule(_canonical_spec("assembled-unused")),
            validate=validate_module,
            normalize=normalize_module,
            components=InMemoryComponentStore(),
            registry=InMemoryRegistryStore(
                list_result=Success([_canonical_spec("known-child")]),
            ),
        )
        spec = _canonical_spec("warning-runtime")
        spec["can_spawn"] = ["known-child", "missing-child"]

        result = validate_command(spec, as_json=True, facade=facade)

        assert isinstance(result, Success)
        report = cast("ValidationReport", result.unwrap()["json"]["data"])
        assert report["valid"] is True
        assert report["errors"] == []
        assert (
            "can_spawn references ids outside the current registry snapshot: missing-child"
            in report["warnings"]
        )


# ============================================================================
# Assemble Command Tests
# ============================================================================


class TestAssembleCommand:
    """Tests for the assemble command handler."""

    def test_assemble_success_text_mode_returns_exit_ok(self) -> None:
        """Assemble with valid request returns exit code 0 in text mode."""
        facade = _make_facade(
            report=_valid_report(),
            candidate=_canonical_spec("assembled-persona"),
        )
        request: AssembleRequest = {"id": "assembled-persona"}

        result = assemble_command(request, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_assemble_success_json_mode_returns_json_payload(self) -> None:
        """Assemble with valid request returns JSON payload in JSON mode."""
        facade = _make_facade(
            report=_valid_report(),
            candidate=_canonical_spec("assembled-persona"),
        )
        request: AssembleRequest = {"id": "assembled-persona"}

        result = assemble_command(request, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["id"] == "assembled-persona"

    def test_assemble_invalid_request_returns_exit_error(self) -> None:
        """Assemble with invalid request returns exit code 1."""
        facade = _make_facade(report=_invalid_report("PERSONA_INVALID"))
        request: AssembleRequest = {"id": "bad-request"}

        result = assemble_command(request, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_assemble_failure_json_mode_returns_error_envelope(self) -> None:
        """Assemble failure returns JSON error envelope in JSON mode."""
        facade = _make_facade(report=_invalid_report("PERSONA_INVALID"))
        request: AssembleRequest = {"id": "bad-request"}

        result = assemble_command(request, as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_INVALID"
        assert error["numeric_code"] == 101


# ============================================================================
# Register Command Tests
# ============================================================================


class TestRegisterCommand:
    """Tests for the register command handler."""

    def test_register_success_text_mode_returns_exit_ok(self) -> None:
        """Register with valid spec returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(report=_valid_report(), registry=registry)
        spec = _canonical_spec("register-me")

        result = register_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_register_success_json_mode_returns_json_payload(self) -> None:
        """Register with valid spec returns JSON payload in JSON mode."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(report=_valid_report(), registry=registry)
        spec = _canonical_spec("register-me")

        result = register_command(spec, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["registered"] is True
        assert cli_result["json"]["data"]["id"] == "register-me"

    def test_register_invalid_spec_returns_exit_error(self) -> None:
        """Register with invalid spec returns exit code 1."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(
            report=_invalid_report("PERSONA_INVALID"),
            registry=registry,
        )
        spec = _canonical_spec("invalid-register")

        result = register_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_register_failure_json_mode_returns_error_envelope(self) -> None:
        """Register failure returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(
            report=_invalid_report("PERSONA_INVALID"),
            registry=registry,
        )
        spec = _canonical_spec("invalid-register")

        result = register_command(spec, as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_INVALID"
        assert error["numeric_code"] == 101


# ============================================================================
# Resolve Command Tests
# ============================================================================


class TestResolveCommand:
    """Tests for the resolve command handler."""

    def test_resolve_success_text_mode_returns_exit_ok(self) -> None:
        """Resolve existing persona returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("resolve-me")))
        facade = _make_facade(report=_valid_report(), registry=registry)

        result = resolve_command("resolve-me", as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_resolve_success_json_mode_returns_json_payload(self) -> None:
        """Resolve existing persona returns JSON payload in JSON mode."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("resolve-me")))
        facade = _make_facade(report=_valid_report(), registry=registry)

        result = resolve_command("resolve-me", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["id"] == "resolve-me"

    def test_resolve_not_found_returns_exit_error_not_generic_failure(
        self,
    ) -> None:
        """Resolve non-existent persona returns exit code 1 (not-found).

        Regression: resolve not-found should return exit code 1 (domain error),
        not exit code 2 (generic/critical failure).
        """
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("missing", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        # Key regression: not-found must exit 1, not 2
        assert failure["exit_code"] == EXIT_ERROR
        assert failure["exit_code"] == 1

    def test_resolve_not_found_json_mode_returns_error_envelope_with_correct_code(
        self,
    ) -> None:
        """Resolve not-found in JSON mode returns error envelope with PERSONA_NOT_FOUND."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("missing", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_NOT_FOUND"
        assert error["numeric_code"] == 100
        assert "persona_id" in error["details"]

    def test_resolve_registry_read_failure_returns_exit_error(self) -> None:
        """Registry read failure returns exit code 1 (domain error)."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "REGISTRY_SPEC_READ_FAILED",
                    "message": "failed to read spec json",
                    "persona_id": "broken",
                    "path": "/tmp/broken.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("broken", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        # Registry errors are domain errors, exit code 1
        assert failure["exit_code"] == EXIT_ERROR

    def test_resolve_validation_failure_returns_exit_error(self) -> None:
        """Resolve with validation failure returns exit code 1."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("invalid-resolve")))
        facade = _make_facade(
            report=_invalid_report("INVALID_SPEC_VERSION"),
            registry=registry,
        )

        result = resolve_command("invalid-resolve", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR


# ============================================================================
# List Command Tests
# ============================================================================


class TestListCommand:
    """Tests for the list command handler."""

    def test_list_success_text_mode_returns_exit_ok(self) -> None:
        """List with valid registry returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore(
            list_result=Success(
                [
                    _canonical_spec("persona-a"),
                    _canonical_spec("persona-b"),
                ]
            )
        )
        facade = _make_facade(registry=registry)

        result = list_command(as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_list_success_json_mode_returns_json_payload(self) -> None:
        """List returns JSON payload with summaries in JSON mode."""
        registry = InMemoryRegistryStore(
            list_result=Success(
                [
                    _canonical_spec("persona-a"),
                    _canonical_spec("persona-b"),
                ]
            )
        )
        facade = _make_facade(registry=registry)

        result = list_command(as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        data = cli_result["json"]["data"]
        assert isinstance(data, list)
        assert len(data) == 2
        ids = [item["id"] for item in data]
        assert "persona-a" in ids
        assert "persona-b" in ids
        assert data[0]["description"] == "Persona persona-a"
        assert data[1]["description"] == "Persona persona-b"

    def test_list_empty_registry_returns_exit_ok_with_empty_list(self) -> None:
        """List with empty registry returns exit code 0 with empty list."""
        registry = InMemoryRegistryStore(list_result=Success([]))
        facade = _make_facade(registry=registry)

        result = list_command(as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_list_empty_registry_json_mode_returns_empty_array(self) -> None:
        """List with empty registry returns empty JSON array in JSON mode."""
        registry = InMemoryRegistryStore(list_result=Success([]))
        facade = _make_facade(registry=registry)

        result = list_command(as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"] == []

    def test_list_registry_read_failure_returns_exit_error(self) -> None:
        """Registry read failure returns exit code 1."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = list_command(as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_list_failure_json_mode_returns_error_envelope(self) -> None:
        """List failure returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = list_command(as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "REGISTRY_INDEX_READ_FAILED"
        assert error["numeric_code"] == 107


# ============================================================================
# Delete Command Tests
# ============================================================================


class TestDeleteCommand:
    """Tests for the delete command handler."""

    def test_delete_success_text_mode_returns_exit_ok(self) -> None:
        """Delete existing persona returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(registry=registry)

        from larva.shell.cli import delete_command

        result = delete_command("test-persona", as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert registry.last_delete_id == "test-persona"

    def test_delete_success_json_mode_returns_json_payload(self) -> None:
        """Delete existing persona returns JSON payload in JSON mode."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(registry=registry)

        from larva.shell.cli import delete_command

        result = delete_command("test-persona", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["deleted"] is True
        assert cli_result["json"]["data"]["id"] == "test-persona"

    def test_delete_not_found_returns_exit_error(self) -> None:
        """Delete non-existent persona returns exit code 1."""
        registry = InMemoryRegistryStore(
            delete_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import delete_command

        result = delete_command("missing", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_delete_not_found_json_mode_returns_error_envelope(self) -> None:
        """Delete non-existent persona returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            delete_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import delete_command

        result = delete_command("missing", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_NOT_FOUND"
        assert error["numeric_code"] == 100

    def test_delete_invalid_id_returns_exit_error(self) -> None:
        """Delete with invalid persona id returns exit code 1."""
        registry = InMemoryRegistryStore(
            delete_result=Failure(
                {
                    "code": "INVALID_PERSONA_ID",
                    "message": "invalid persona id 'Bad-Id': expected flat kebab-case",
                    "persona_id": "Bad-Id",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import delete_command

        result = delete_command("Bad-Id", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR


# ============================================================================
# Clone Command Tests
# ============================================================================


class TestCloneCommand:
    """Tests for the clone command handler."""

    def test_clone_success_text_mode_returns_exit_ok(self) -> None:
        """Clone existing persona returns exit code 0 in text mode."""
        source_spec = _canonical_spec("source-persona")
        registry = InMemoryRegistryStore(get_result=Success(source_spec))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command("source-persona", "cloned-persona", as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert len(registry.save_inputs) == 1
        assert registry.save_inputs[0]["id"] == "cloned-persona"

    def test_clone_success_json_mode_returns_json_payload(self) -> None:
        """Clone existing persona returns JSON payload in JSON mode."""
        source_spec = _canonical_spec("source-to-clone")
        registry = InMemoryRegistryStore(get_result=Success(source_spec))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command("source-to-clone", "clone-target", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["id"] == "clone-target"
        # Digest should be recomputed, not copied
        assert cli_result["json"]["data"]["spec_digest"] != "sha256:original"

    def test_clone_source_not_found_returns_exit_error(self) -> None:
        """Clone non-existent persona returns exit code 1."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command("missing", "cloned-persona", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "Clone failed" in failure.get("stderr", "")

    def test_clone_source_not_found_json_mode_returns_error_envelope(self) -> None:
        """Clone non-existent persona returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found in registry",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command("missing", "cloned-persona", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_NOT_FOUND"
        assert error["numeric_code"] == 100

    def test_clone_invalid_new_id_returns_exit_error(self) -> None:
        """Clone with invalid new_id returns exit code 1."""
        source_spec = _canonical_spec("valid-source")
        registry = InMemoryRegistryStore(get_result=Success(source_spec))
        facade = _make_facade(
            report=_invalid_report("INVALID_PERSONA_ID"),
            registry=registry,
        )

        from larva.shell.cli import clone_command

        result = clone_command("valid-source", "Bad_Clone_Id", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_clone_invalid_new_id_json_mode_returns_error_envelope(self) -> None:
        """Clone with invalid new_id returns JSON error envelope in JSON mode."""
        source_spec = _canonical_spec("valid-source")
        registry = InMemoryRegistryStore(get_result=Success(source_spec))
        facade = _make_facade(
            report=_invalid_report("PERSONA_INVALID"),
            registry=registry,
        )

        from larva.shell.cli import clone_command

        result = clone_command("valid-source", "Bad_Clone_Id", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_INVALID"
        assert error["numeric_code"] == 101

    def test_clone_registry_write_failure_returns_exit_error(self) -> None:
        """Clone with registry write failure returns exit code 1."""
        source_spec = _canonical_spec("source-write-fail")
        registry = InMemoryRegistryStore(
            get_result=Success(source_spec),
            save_result=Failure(
                {
                    "code": "REGISTRY_WRITE_FAILED",
                    "message": "disk full during save",
                    "persona_id": "cloned-write-fail",
                    "path": "/tmp/cloned-write-fail.json",
                }
            ),
        )
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command(
            "source-write-fail", "cloned-write-fail", as_json=False, facade=facade
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "Clone failed" in failure.get("stderr", "")

    def test_clone_preserves_canonical_fields_except_id_and_digest(self) -> None:
        """Clone preserves canonical source fields except id and spec_digest."""
        source_spec: PersonaSpec = {
            "id": "original-persona",
            "description": "Original description",
            "prompt": "Original prompt text",
            "model": "gpt-4",
            "capabilities": {"shell": "full_access"},
            "model_params": {"temperature": 0.7, "max_tokens": 4000},
            "can_spawn": True,
            "compaction_prompt": "Custom compaction",
            "spec_version": "0.1.0",
            "spec_digest": "sha256:stale",
        }
        source_spec["spec_digest"] = _digest_for(source_spec)
        registry = InMemoryRegistryStore(get_result=Success(source_spec))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import clone_command

        result = clone_command("original-persona", "cloned-persona", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        cloned = cli_result["json"]["data"]
        assert cloned["id"] == "cloned-persona"
        assert cloned["description"] == "Original description"
        assert cloned["prompt"] == "Original prompt text"
        assert cloned["model"] == "gpt-4"
        assert cloned["capabilities"] == {"shell": "full_access"}
        assert "tools" not in cloned
        assert cloned["model_params"] == {"temperature": 0.7, "max_tokens": 4000}
        assert "side_effect_policy" not in cloned
        assert cloned["can_spawn"] is True
        assert cloned["compaction_prompt"] == "Custom compaction"
        assert cloned["spec_version"] == "0.1.0"
        # Digest must be recomputed
        assert cloned["spec_digest"] != "sha256:stale"


# ============================================================================
# Clear Command Tests
# ============================================================================


class TestClearCommand:
    """Tests for the clear command handler."""

    def test_clear_success_text_mode_returns_exit_ok(self) -> None:
        """Clear with correct confirmation returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore(clear_result=Success(3))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("CLEAR REGISTRY", as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert registry.last_clear_confirm == "CLEAR REGISTRY"

    def test_clear_success_json_mode_returns_json_payload(self) -> None:
        """Clear with correct confirmation returns JSON payload in JSON mode."""
        registry = InMemoryRegistryStore(clear_result=Success(5))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("CLEAR REGISTRY", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["cleared"] is True
        assert cli_result["json"]["data"]["count"] == 5

    def test_clear_wrong_confirm_returns_exit_error(self) -> None:
        """Clear with wrong confirmation token returns exit code 1."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("wrong token", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "CLEAR REGISTRY" in failure.get("stderr", "")

    def test_clear_wrong_confirm_json_mode_returns_error_envelope(self) -> None:
        """Clear with wrong confirmation token returns JSON error envelope."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("wrong token", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "INVALID_CONFIRMATION_TOKEN"

    def test_clear_empty_registry_returns_exit_ok_with_count_zero(self) -> None:
        """Clear with empty registry returns success with count 0."""
        registry = InMemoryRegistryStore(clear_result=Success(0))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("CLEAR REGISTRY", as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert cli_result["json"]["data"]["count"] == 0

    def test_clear_registry_failure_returns_exit_error(self) -> None:
        """Clear with registry failure returns exit code 1."""
        registry = InMemoryRegistryStore(
            clear_result=Failure(
                {
                    "code": "REGISTRY_DELETE_FAILED",
                    "message": "failed to delete one or more specs",
                    "operation": "clear",
                    "persona_id": None,
                    "path": "/tmp/index.json",
                    "failed_spec_paths": [],
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import clear_command

        result = clear_command("CLEAR REGISTRY", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR


# ============================================================================
# JSON/Text Separation Regression Tests
# ============================================================================


class TestJsonTextSeparation:
    """Regression tests for JSON/text output separation."""

    def test_success_text_mode_has_no_json_key(self) -> None:
        """Success in text mode must not include 'json' key in result."""
        registry = InMemoryRegistryStore(list_result=Success([_canonical_spec("test")]))
        facade = _make_facade(registry=registry)

        result = list_command(as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        # Text mode must not leak JSON into the result
        assert "json" not in cli_result

    def test_failure_text_mode_has_no_json_key(self) -> None:
        """Failure in text mode must not include 'json' key in result."""
        facade = _make_facade(report=_invalid_report("PERSONA_INVALID"))
        spec = _canonical_spec("invalid")

        result = register_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        # Text mode must not leak JSON into the result
        assert "json" not in failure

    def test_json_mode_includes_json_key_on_success(self) -> None:
        """Success in JSON mode must include 'json' key with data."""
        registry = InMemoryRegistryStore(list_result=Success([_canonical_spec("test")]))
        facade = _make_facade(registry=registry)

        result = list_command(as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert "json" in cli_result
        assert "data" in cli_result["json"]

    def test_json_mode_includes_error_key_on_failure(self) -> None:
        """Failure in JSON mode must include 'error' key."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("missing", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure


# ============================================================================
# Exit Code Mapping Tests
# ============================================================================


class TestExitCodeMapping:
    """Tests for exit code mapping from facade errors."""

    def test_success_returns_exit_ok(self) -> None:
        """All successful operations return exit code 0."""
        registry = InMemoryRegistryStore()
        facade = _make_facade(report=_valid_report(), registry=registry)
        spec = _canonical_spec("test")

        # Validate success
        result = validate_command(spec, as_json=False, facade=facade)
        assert isinstance(result, Success)
        assert result.unwrap()["exit_code"] == EXIT_OK

        # Assemble success
        result = assemble_command({"id": "test"}, as_json=False, facade=facade)
        assert isinstance(result, Success)
        assert result.unwrap()["exit_code"] == EXIT_OK

        # Register success
        result = register_command(spec, as_json=False, facade=facade)
        assert isinstance(result, Success)
        assert result.unwrap()["exit_code"] == EXIT_OK

    def test_not_found_returns_exit_error(self) -> None:
        """Not-found errors return exit code 1."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("missing", as_json=False, facade=facade)

        assert isinstance(result, Failure)
        assert result.failure()["exit_code"] == EXIT_ERROR

    def test_validation_failure_returns_exit_error(self) -> None:
        """Validation failures return exit code 1."""
        facade = _make_facade(report=_invalid_report("INVALID_SPEC_VERSION"))
        spec = _canonical_spec("invalid")

        result = validate_command(spec, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        assert result.failure()["exit_code"] == EXIT_ERROR


# ============================================================================
# JSON Error Envelope Format Tests
# ============================================================================


class TestJsonErrorEnvelope:
    """Tests for JSON error envelope format."""

    def test_error_envelope_has_required_fields(self) -> None:
        """Error envelope must have code, numeric_code, message, details."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'test' not found",
                    "persona_id": "test",
                }
            )
        )
        facade = _make_facade(registry=registry)

        result = resolve_command("test", as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        error = failure["error"]

        assert "code" in error
        assert "numeric_code" in error
        assert "message" in error
        assert "details" in error

    def test_error_envelope_numeric_codes_match_spec(self) -> None:
        """Error numeric codes match INTERFACES.md G. Error Codes."""
        test_cases: list[tuple[str, int, dict[str, Any]]] = [
            ("PERSONA_NOT_FOUND", 100, {"persona_id": "missing"}),
            ("PERSONA_INVALID", 101, {"report": {}}),
            ("PERSONA_CYCLE", 102, {}),
            ("INVALID_PERSONA_ID", 104, {"persona_id": "bad-id"}),
            ("COMPONENT_NOT_FOUND", 105, {"component_type": "prompt"}),
            ("COMPONENT_CONFLICT", 106, {}),
            ("REGISTRY_INDEX_READ_FAILED", 107, {"path": "/tmp/index.json"}),
            ("REGISTRY_SPEC_READ_FAILED", 108, {"persona_id": "x", "path": "/x.json"}),
            ("REGISTRY_WRITE_FAILED", 109, {"persona_id": "x", "path": "/x.json"}),
            ("REGISTRY_UPDATE_FAILED", 110, {"persona_id": "x", "path": "/index.json"}),
        ]

        for code, expected_numeric, details in test_cases:
            registry = InMemoryRegistryStore(
                get_result=Failure(
                    {
                        "code": code,
                        "message": f"test {code}",
                        **details,
                    }
                )
            )
            facade = _make_facade(registry=registry)
            result = resolve_command("test", as_json=True, facade=facade)

            assert isinstance(result, Failure)
            error = result.failure()["error"]
            assert error["numeric_code"] == expected_numeric, (
                f"Expected {expected_numeric} for {code}"
            )


class TestCliSharedProjectionAuthority:
    """Shared CLI helper authorities stay centralized."""

    def test_cli_helpers_reexport_shared_cli_types(self) -> None:
        from larva.shell import cli_helpers

        assert cli_helpers.CliCommandResult is SharedCliCommandResult
        assert cli_helpers.CliFailure is SharedCliFailure
        assert cli_helpers.JsonErrorEnvelope is SharedJsonErrorEnvelope

    def test_cli_helpers_reexport_shared_validation_projection_helpers(self) -> None:
        from larva.shell import cli_helpers

        assert cli_helpers.project_validation_report is project_validation_report
        assert cli_helpers.render_validation_report_text is render_validation_report_text

    def test_cli_helpers_source_removes_duplicate_cli_type_declarations(self) -> None:
        from larva.shell import cli_helpers

        assert cli_helpers.__file__ is not None
        source = Path(cli_helpers.__file__).read_text(encoding="utf-8")

        assert "CliExitCode = Literal[0, 1, 2]" not in source
        assert "class JsonErrorEnvelope(TypedDict):" not in source
        assert "class CliFailure(TypedDict, total=False):" not in source
        assert "class CliCommandResult(TypedDict, total=False):" not in source

    def test_cli_runtime_source_removes_duplicate_cli_type_and_validation_renderer_authority(
        self,
    ) -> None:
        assert cli_runtime.__file__ is not None
        source = Path(cli_runtime.__file__).read_text(encoding="utf-8")

        assert "CliExitCode = Literal[0, 1, 2]" not in source
        assert "class JsonErrorEnvelope(TypedDict):" not in source
        assert "def _render_validation_report(" not in source

    def test_validation_report_projection_preserves_invalid_parity_facts(self) -> None:
        report: ValidationReport = {
            "valid": False,
            "errors": [
                {
                    "code": "EXTRA_FIELD_NOT_ALLOWED",
                    "message": "unknown top-level field 'tools' is not permitted at canonical admission boundary",
                    "details": {"field": "tools"},
                }
            ],
            "warnings": [],
        }

        projection = project_validation_report(report).unwrap()

        assert (
            projection["primary_message"]
            == "unknown top-level field 'tools' is not permitted at canonical admission boundary"
        )
        assert projection["report"] == report
        assert (
            render_validation_report_text(report).unwrap()
            == "invalid: unknown top-level field 'tools' is not permitted at canonical admission boundary\n"
        )

    def test_validation_report_projection_preserves_warning_parity_facts(self) -> None:
        report: ValidationReport = {
            "valid": True,
            "errors": [],
            "warnings": [
                "unknown model identifier 'custom-model-x' is outside the known-model snapshot",
                "capabilities is empty; this is valid but likely under-specified",
            ],
        }

        projection = project_validation_report(report).unwrap()
        rendered = render_validation_report_text(report).unwrap()

        assert projection["warnings"] == report["warnings"]
        assert rendered.startswith("valid\n")
        for warning in report["warnings"]:
            assert warning in rendered

    def test_component_show_uses_shared_component_query_service(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        recorded: dict[str, object] = {}

        def _fake_query_component(
            component_store: object,
            *,
            component_type: str,
            component_name: str,
            operation: str,
        ) -> Result[dict[str, object], LarvaError]:
            recorded.update(
                {
                    "component_store": component_store,
                    "component_type": component_type,
                    "component_name": component_name,
                    "operation": operation,
                }
            )
            return Success({"text": "Shared query payload"})

        store = InMemoryComponentStore()
        monkeypatch.setattr("larva.shell.cli_commands.query_component", _fake_query_component)

        result = component_show_command("prompts/test-prompt", as_json=True, component_store=store)

        assert isinstance(result, Success)
        assert result.unwrap()["json"]["data"] == {"text": "Shared query payload"}
        assert recorded == {
            "component_store": store,
            "component_type": "prompts",
            "component_name": "test-prompt",
            "operation": "cli.component_show",
        }

    def test_cli_component_error_exit_code_helper_marks_internal_as_critical(self) -> None:
        internal_error: JsonErrorEnvelope = {
            "code": "INTERNAL",
            "numeric_code": 10,
            "message": "boom",
            "details": {},
        }
        invalid_error: JsonErrorEnvelope = {
            "code": "INVALID_INPUT",
            "numeric_code": 1,
            "message": "bad input",
            "details": {},
        }

        assert cli_runtime.cli_exit_code_for_error(internal_error) == EXIT_CRITICAL
        assert cli_runtime.cli_exit_code_for_error(invalid_error) == EXIT_ERROR


@dataclass
class RecordingFacade:
    """Simple facade double for run_cli dispatch tests."""

    validate_report: ValidationReport = field(default_factory=_valid_report)
    assemble_result: Result[PersonaSpec, LarvaError] = field(
        default_factory=lambda: Success(_canonical_spec("assembled"))
    )
    register_result: Result[RegisteredPersona, LarvaError] = field(
        default_factory=lambda: Success({"id": "registered", "registered": True})
    )
    resolve_result: Result[PersonaSpec, LarvaError] = field(
        default_factory=lambda: Success(_canonical_spec("resolved"))
    )
    list_result: Result[list[PersonaSummary], LarvaError] = field(
        default_factory=lambda: Success([])
    )
    delete_result: Result[dict[str, object], LarvaError] = field(
        default_factory=lambda: Success({"id": "deleted", "deleted": True})
    )
    clear_result: Result[dict[str, object], LarvaError] = field(
        default_factory=lambda: Success({"cleared": True, "count": 0})
    )
    update_result: Result[PersonaSpec, LarvaError] = field(
        default_factory=lambda: Success(_canonical_spec("updated"))
    )
    clone_result: Result[PersonaSpec, LarvaError] = field(
        default_factory=lambda: Success(_canonical_spec("cloned"))
    )
    export_all_result: Result[list[PersonaSpec], LarvaError] = field(
        default_factory=lambda: Success([])
    )
    export_ids_result: Result[list[PersonaSpec], LarvaError] = field(
        default_factory=lambda: Success([])
    )
    validate_calls: int = 0
    assemble_calls: int = 0
    register_calls: int = 0
    resolve_calls: int = 0
    list_calls: int = 0
    delete_calls: int = 0
    clear_calls: int = 0
    update_calls: int = 0
    clone_calls: int = 0
    export_all_calls: int = 0
    export_ids_calls: int = 0
    last_resolve_id: str | None = None
    last_resolve_overrides: dict[str, object] | None = None
    last_delete_id: str | None = None
    last_clear_confirm: str | None = None
    last_update_id: str | None = None
    last_update_patches: dict[str, object] | None = None
    last_clone_source: str | None = None
    last_clone_target: str | None = None
    last_export_ids: list[str] | None = None

    def validate(self, spec: PersonaSpec) -> ValidationReport:
        del spec
        self.validate_calls += 1
        return self.validate_report

    def assemble(self, request: AssembleRequest) -> Result[PersonaSpec, LarvaError]:
        del request
        self.assemble_calls += 1
        return self.assemble_result

    def register(self, spec: PersonaSpec) -> Result[RegisteredPersona, LarvaError]:
        del spec
        self.register_calls += 1
        return self.register_result

    def resolve(
        self,
        id: str,
        overrides: dict[str, object] | None = None,
    ) -> Result[PersonaSpec, LarvaError]:
        self.resolve_calls += 1
        self.last_resolve_id = id
        self.last_resolve_overrides = overrides
        return self.resolve_result

    def list(self) -> Result[list[PersonaSummary], LarvaError]:
        self.list_calls += 1
        return self.list_result

    def delete(self, persona_id: str) -> Result[dict[str, object], LarvaError]:
        self.delete_calls += 1
        self.last_delete_id = persona_id
        if isinstance(self.delete_result, Success):
            # Return the persona_id in the result for success case
            return Success({"id": persona_id, "deleted": True})
        return self.delete_result

    def clear(self, confirm: str = "CLEAR REGISTRY") -> Result[dict[str, object], LarvaError]:
        self.clear_calls += 1
        self.last_clear_confirm = confirm
        return self.clear_result

    def update(
        self,
        persona_id: str,
        patches: dict[str, object],
    ) -> Result[PersonaSpec, LarvaError]:
        self.update_calls += 1
        self.last_update_id = persona_id
        self.last_update_patches = patches
        return self.update_result

    def clone(self, source_id: str, new_id: str) -> Result[PersonaSpec, LarvaError]:
        self.clone_calls += 1
        self.last_clone_source = source_id
        self.last_clone_target = new_id
        return self.clone_result

    def export_all(self) -> Result[list[PersonaSpec], LarvaError]:
        self.export_all_calls += 1
        return self.export_all_result

    def export_ids(self, ids: list[str]) -> Result[list[PersonaSpec], LarvaError]:
        self.export_ids_calls += 1
        self.last_export_ids = ids
        return self.export_ids_result


# ============================================================================
# Export Command Tests
# ============================================================================


class TestExportCommand:
    """Tests for the export command handler."""

    def test_export_all_success_text_mode_returns_exit_ok(self) -> None:
        """Export all with valid specs returns exit code 0 in text mode."""
        spec_alpha = _canonical_spec("export-alpha")
        spec_beta = _canonical_spec("export-beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "export-alpha" in cli_result["stdout"]
        assert "export-beta" in cli_result["stdout"]

    def test_export_all_success_json_mode_returns_json_payload(self) -> None:
        """Export all returns JSON payload in JSON mode."""
        spec_alpha = _canonical_spec("export-alpha")
        spec_beta = _canonical_spec("export-beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        data = cli_result["json"]["data"]
        assert isinstance(data, list)
        assert len(data) == 2
        assert data[0]["id"] == "export-alpha"
        assert data[1]["id"] == "export-beta"

    def test_export_all_empty_registry_returns_ok_with_empty_text(self) -> None:
        """Export all with empty registry returns success in text mode."""
        registry = InMemoryRegistryStore(list_result=Success([]))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert cli_result["stdout"] == ""

    def test_export_all_empty_registry_json_mode_returns_empty_array(self) -> None:
        """Export all with empty registry returns empty JSON array."""
        registry = InMemoryRegistryStore(list_result=Success([]))
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert cli_result["json"]["data"] == []

    def test_export_all_failure_returns_exit_error(self) -> None:
        """Registry read failure returns exit code 1."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_export_all_failure_json_mode_returns_error_envelope(self) -> None:
        """Registry failure returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command([], export_all=True, as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "REGISTRY_INDEX_READ_FAILED"
        assert error["numeric_code"] == 107

    def test_export_ids_success_text_mode_returns_exit_ok(self) -> None:
        """Export ids with valid specs returns exit code 0 in text mode."""
        spec_one = _canonical_spec("export-one")
        spec_two = _canonical_spec("export-two")

        def get_by_id(persona_id: str) -> Result[PersonaSpec, Any]:
            if persona_id == "export-one":
                return Success(spec_one)
            if persona_id == "export-two":
                return Success(spec_two)
            return Failure({"code": "PERSONA_NOT_FOUND", "message": "not found"})

        registry = InMemoryRegistryStore(get_result=Success(spec_one))
        registry.get = get_by_id  # type: ignore[method-assign]
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command(
            ["export-one", "export-two"], export_all=False, as_json=False, facade=facade
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "export-one" in cli_result["stdout"]
        assert "export-two" in cli_result["stdout"]

    def test_export_ids_success_json_mode_returns_json_payload(self) -> None:
        """Export ids returns JSON payload in JSON mode."""
        spec_one = _canonical_spec("export-one")

        def get_by_id(persona_id: str) -> Result[PersonaSpec, Any]:
            if persona_id == "export-one":
                return Success(spec_one)
            return Failure({"code": "PERSONA_NOT_FOUND", "message": "not found"})

        registry = InMemoryRegistryStore(get_result=Success(spec_one))
        registry.get = get_by_id  # type: ignore[method-assign]
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command(["export-one"], export_all=False, as_json=True, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        data = cli_result["json"]["data"]
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["id"] == "export-one"

    def test_export_ids_empty_returns_ok_with_empty_text(self) -> None:
        """Export ids with empty list returns success in text mode."""
        facade = _make_facade()

        from larva.shell.cli import export_command

        result = export_command([], export_all=False, as_json=False, facade=facade)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert cli_result["stdout"] == ""

    def test_export_ids_not_found_returns_exit_error(self) -> None:
        """Export ids with missing persona returns exit code 1."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command(["missing"], export_all=False, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_export_ids_not_found_json_mode_returns_error_envelope(self) -> None:
        """Export ids with missing persona returns JSON error envelope."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import export_command

        result = export_command(["missing"], export_all=False, as_json=True, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_NOT_FOUND"
        assert error["numeric_code"] == 100

    def test_export_both_all_and_ids_returns_critical_failure(self) -> None:
        """Export with both all and ids returns critical failure."""
        facade = _make_facade()

        from larva.shell.cli import export_command

        result = export_command(["id1"], export_all=True, as_json=False, facade=facade)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_CRITICAL
        assert (
            "both" in failure.get("stderr", "").lower()
            or "both" in failure.get("error", {}).get("message", "").lower()
        )


class TestRunCli:
    def test_validate_parse_error_json_returns_internal_numeric_code(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(["validate", "--json"], facade=facade, stdout=stdout, stderr=stderr)

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        assert payload["error"]["numeric_code"] == 10
        assert stderr.getvalue() == ""

    def test_validate_json_success_writes_json_stdout_only(self, tmp_path: Path) -> None:
        spec_path = tmp_path / "valid.json"
        spec_path.write_text(json.dumps(_canonical_spec("ok")), encoding="utf-8")
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["validate", str(spec_path), "--json"], facade=facade, stdout=stdout, stderr=stderr
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["valid"] is True
        assert stderr.getvalue() == ""

    def test_validate_missing_id_text_returns_domain_failure_with_stderr_only(
        self, tmp_path: Path
    ) -> None:
        spec_path = tmp_path / "missing-id.json"
        spec_path.write_text(json.dumps({"spec_version": "0.1.0"}), encoding="utf-8")
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["validate", str(spec_path)],
            facade=cli.build_default_facade(),
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        assert stdout.getvalue() == ""
        assert "Validation failed" in stderr.getvalue()
        assert "required field" in stderr.getvalue()
        assert "canonical admission boundary" in stderr.getvalue()

    def test_validate_missing_id_json_returns_persona_invalid_envelope(
        self, tmp_path: Path
    ) -> None:
        spec_path = tmp_path / "missing-id.json"
        spec_path.write_text(json.dumps({"spec_version": "0.1.0"}), encoding="utf-8")
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["validate", str(spec_path), "--json"],
            facade=cli.build_default_facade(),
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "PERSONA_INVALID"
        assert payload["error"]["numeric_code"] == 101
        first_error = payload["error"]["details"]["report"]["errors"][0]
        assert first_error["code"] == "MISSING_REQUIRED_FIELD"
        assert first_error["details"]["field"] in {
            "id",
            "description",
            "prompt",
            "model",
            "capabilities",
        }
        assert stderr.getvalue() == ""

    def test_register_missing_file_text_returns_critical_and_stderr_only(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["register", "/missing/spec.json"], facade=facade, stdout=stdout, stderr=stderr
        )

        assert exit_code == EXIT_CRITICAL
        assert stdout.getvalue() == ""
        assert "spec file not found" in stderr.getvalue()

    def test_register_missing_file_json_returns_error_envelope_on_stdout(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["register", "/missing/spec.json", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        assert payload["error"]["numeric_code"] == 10
        assert stderr.getvalue() == ""

    def test_assemble_override_parse_error_returns_critical(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["assemble", "--id", "persona", "--override", "bad"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        assert stdout.getvalue() == ""
        assert "expected key=value" in stderr.getvalue()

    def test_assemble_output_short_flag_writes_json_file(self, tmp_path: Path) -> None:
        output_path = tmp_path / "assembled-short.json"
        facade = RecordingFacade(assemble_result=Success(_canonical_spec("assembled-short")))
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["assemble", "--id", "assembled-short", "-o", str(output_path)],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        assert stdout.getvalue() == ""
        assert stderr.getvalue() == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        assert payload["id"] == "assembled-short"

    def test_assemble_output_long_flag_writes_json_file(self, tmp_path: Path) -> None:
        output_path = tmp_path / "assembled-long.json"
        facade = RecordingFacade(assemble_result=Success(_canonical_spec("assembled-long")))
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["assemble", "--id", "assembled-long", "--output", str(output_path)],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        assert stdout.getvalue() == ""
        assert stderr.getvalue() == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        assert payload["id"] == "assembled-long"

    def test_resolve_passes_parsed_overrides_to_facade(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "resolve",
                "persona-1",
                "--override",
                "model=gpt-4o-mini",
                "--override",
                "can_spawn=false",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        assert facade.last_resolve_id == "persona-1"
        assert facade.last_resolve_overrides == {"model": "gpt-4o-mini", "can_spawn": "false"}

    def test_component_list_json_routes_to_component_store_only(self) -> None:
        facade = RecordingFacade()
        components = InMemoryComponentStore(
            list_result=Success(
                {
                    "prompts": ["a"],
                    "toolsets": ["b"],
                    "constraints": ["c"],
                    "models": ["d"],
                }
            )
        )
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["component", "list", "--json"],
            facade=facade,
            component_store=components,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["prompts"] == ["a"]
        assert stderr.getvalue() == ""
        assert facade.validate_calls == 0
        assert facade.assemble_calls == 0
        assert facade.register_calls == 0
        assert facade.resolve_calls == 0
        assert facade.list_calls == 0

    def test_component_show_routes_to_target_loader_only(self) -> None:
        facade = RecordingFacade()
        components = InMemoryComponentStore()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["component", "show", "prompts/test-prompt", "--json"],
            facade=facade,
            component_store=components,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["text"] == "Prompt body"
        assert components.last_loaded == ("prompts", "test-prompt")
        assert stderr.getvalue() == ""
        assert facade.validate_calls == 0
        assert facade.assemble_calls == 0
        assert facade.register_calls == 0
        assert facade.resolve_calls == 0
        assert facade.list_calls == 0

    def test_component_show_missing_target_returns_not_found_envelope(self) -> None:
        facade = RecordingFacade()
        components = InMemoryComponentStore()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["component", "show", "prompts/", "--json"],
            facade=facade,
            component_store=components,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INVALID_INPUT"
        assert payload["error"]["numeric_code"] == 1
        assert payload["error"]["details"]["reason"] == "invalid_kind"
        assert stderr.getvalue() == ""

    def test_component_list_generic_failure_maps_to_internal_without_text_leak(self) -> None:
        facade = RecordingFacade()
        components = InMemoryComponentStore(list_result=Failure(RuntimeError("boom")))
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["component", "list", "--json"],
            facade=facade,
            component_store=components,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        assert payload["error"]["numeric_code"] == 10
        assert stderr.getvalue() == ""

    def test_delete_success_routes_to_facade_delete(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["delete", "test-persona", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["deleted"] is True
        assert payload["data"]["id"] == "test-persona"
        assert stderr.getvalue() == ""
        assert facade.delete_calls == 1
        assert facade.last_delete_id == "test-persona"

    def test_delete_not_found_returns_exit_error(self) -> None:
        facade = RecordingFacade(
            delete_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found",
                    "numeric_code": 100,
                    "details": {"persona_id": "missing"},
                }
            )
        )
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["delete", "missing", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "PERSONA_NOT_FOUND"
        assert stderr.getvalue() == ""

    def test_clear_success_with_confirmation_routes_to_facade_clear(self) -> None:
        facade = RecordingFacade(clear_result=Success({"cleared": True, "count": 3}))
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["clear", "--confirm", "CLEAR REGISTRY", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["cleared"] is True
        assert payload["data"]["count"] == 3
        assert stderr.getvalue() == ""
        assert facade.clear_calls == 1
        assert facade.last_clear_confirm == "CLEAR REGISTRY"

    def test_clear_wrong_confirm_returns_exit_error(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["clear", "--confirm", "wrong token", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INVALID_CONFIRMATION_TOKEN"
        assert stderr.getvalue() == ""
        assert facade.clear_calls == 0

    def test_clear_missing_confirm_returns_parse_error(self) -> None:
        facade = RecordingFacade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["clear", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        assert stderr.getvalue() == ""


# ============================================================================
# Component List Command Tests
# ============================================================================


class TestComponentListCommand:
    """Tests for the component_list_command handler.

    Contract from INTERFACES.md:
    - Exit code 0: success
    - Exit code 1: error (component directory access failure)
    - Direct to injected ComponentStore.list_components()
    """

    def test_component_list_success_text_mode_returns_exit_ok(self) -> None:
        """Component list with valid store returns exit code 0 in text mode."""
        components = InMemoryComponentStore()

        result = component_list_command(as_json=False, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_component_list_success_json_mode_returns_json_payload(self) -> None:
        """Component list returns JSON payload with inventory in JSON mode."""
        components = InMemoryComponentStore()

        result = component_list_command(as_json=True, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        data = cli_result["json"]["data"]
        assert "prompts" in data
        assert "toolsets" in data
        assert "constraints" in data
        assert "models" in data
        # Verify list of each type
        assert isinstance(data["prompts"], list)
        assert isinstance(data["toolsets"], list)
        assert isinstance(data["constraints"], list)
        assert isinstance(data["models"], list)

    def test_component_list_with_components_returns_exit_ok(self) -> None:
        """Component list with actual components returns exit code 0."""
        # Use the InMemoryComponentStore with predefined components
        components = InMemoryComponentStore()
        # The InMemoryComponentStore returns empty lists by default
        # but we can override it to test non-empty results

        result = component_list_command(as_json=False, component_store=components)

        assert isinstance(result, Success)
        assert result.unwrap()["exit_code"] == EXIT_OK

    def test_component_list_empty_store_returns_exit_ok_with_empty_dict(self) -> None:
        """Component list with empty store returns exit code 0 with empty dict."""
        components = InMemoryComponentStore(
            list_result=Success(
                {
                    "prompts": [],
                    "toolsets": [],
                    "constraints": [],
                    "models": [],
                }
            )
        )

        result = component_list_command(as_json=True, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert cli_result["json"]["data"]["prompts"] == []
        assert cli_result["json"]["data"]["toolsets"] == []
        assert cli_result["json"]["data"]["constraints"] == []
        assert cli_result["json"]["data"]["models"] == []


class TestComponentShowCommand:
    """Tests for the component_show_command handler.

    Contract from INTERFACES.md:
    - Exit code 0: success
    - Exit code 1: not found (component does not exist or cannot be parsed)
    - Direct to ComponentStore.load_<type>(name)
    - Type is one of: prompts, toolsets, constraints, models
    """

    def test_component_show_prompt_success_text_mode_returns_exit_ok(self) -> None:
        """Component show with valid prompt returns exit code 0 in text mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/test-prompt", as_json=False, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_component_show_prompt_success_json_mode_returns_json_payload(self) -> None:
        """Component show with valid prompt returns JSON payload in JSON mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/test-prompt", as_json=True, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert "data" in cli_result["json"]
        assert "text" in cli_result["json"]["data"]

    def test_component_show_prompt_singular_alias_returns_invalid_input(self) -> None:
        """Component show must reject singular aliases at public ingress."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompt/test-prompt", as_json=True, component_store=components
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert failure["error"]["code"] == "INVALID_INPUT"
        assert failure["error"]["details"]["reason"] == "invalid_kind"

    def test_component_show_toolset_success_text_mode_returns_exit_ok(self) -> None:
        """Component show with valid toolset returns exit code 0 in text mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "toolsets/test-toolset", as_json=False, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_component_show_toolset_success_json_mode_returns_json_payload(self) -> None:
        """Component show with valid toolset returns JSON payload in JSON mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "toolsets/test-toolset", as_json=True, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert "data" in cli_result["json"]
        assert "capabilities" in cli_result["json"]["data"]
        assert "tools" not in cli_result["json"]["data"]

    def test_component_show_constraint_success_text_mode_returns_exit_ok(self) -> None:
        """Component show with valid constraint returns exit code 0 in text mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "constraints/test-constraint", as_json=False, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_component_show_model_success_text_mode_returns_exit_ok(self) -> None:
        """Component show with valid model returns exit code 0 in text mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "models/test-model", as_json=False, component_store=components
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_component_show_not_found_returns_exit_error(self) -> None:
        """Component show with non-existent component returns exit code 1."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/nonexistent", as_json=False, component_store=components
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        # Not found should return exit code 1
        assert failure["exit_code"] == EXIT_ERROR
        assert failure["exit_code"] == 1

    def test_component_show_not_found_json_mode_returns_error_envelope(self) -> None:
        """Component show not found returns JSON error envelope in JSON mode."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/nonexistent", as_json=True, component_store=components
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert "code" in error
        assert "numeric_code" in error
        assert "message" in error
        assert "details" in error
        # COMPONENT_NOT_FOUND = 105
        assert error["numeric_code"] == 105


class TestComponentCommandJsonTextSeparation:
    """Regression tests for JSON/text output separation on component commands."""

    def test_component_list_success_text_mode_has_no_json_key(self) -> None:
        """Component list success in text mode must not include 'json' key."""
        components = InMemoryComponentStore()

        result = component_list_command(as_json=False, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert "json" not in cli_result

    def test_component_list_failure_text_mode_has_no_json_key(self) -> None:
        """Component list failure in text mode must not include 'json' key."""

        # Create a failing component store that returns error
        class FailingComponentStore:
            def load_prompt(self, name: str):
                return Failure(Exception("not implemented"))

            def load_toolset(self, name: str):
                return Failure(Exception("not implemented"))

            def load_constraint(self, name: str):
                return Failure(Exception("not implemented"))

            def load_model(self, name: str):
                return Failure(Exception("not implemented"))

            def list_components(self):
                return Failure(Exception("directory access failed"))

        result = component_list_command(as_json=False, component_store=FailingComponentStore())

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "json" not in failure

    def test_component_show_success_text_mode_has_no_json_key(self) -> None:
        """Component show success in text mode must not include 'json' key."""
        components = InMemoryComponentStore()

        result = component_show_command("prompts/test", as_json=False, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert "json" not in cli_result

    def test_component_show_failure_text_mode_has_no_json_key(self) -> None:
        """Component show failure in text mode must not include 'json' key."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/nonexistent", as_json=False, component_store=components
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "json" not in failure

    def test_component_list_json_mode_includes_json_key_on_success(self) -> None:
        """Component list success in JSON mode must include 'json' key with data."""
        components = InMemoryComponentStore()

        result = component_list_command(as_json=True, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert "json" in cli_result
        assert "data" in cli_result["json"]

    def test_component_show_json_mode_includes_json_key_on_success(self) -> None:
        """Component show success in JSON mode must include 'json' key with data."""
        components = InMemoryComponentStore()

        result = component_show_command("prompts/test", as_json=True, component_store=components)

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert "json" in cli_result
        assert "data" in cli_result["json"]

    def test_component_list_json_mode_includes_error_key_on_failure(self) -> None:
        """Component list failure in JSON mode must include 'error' key."""

        class FailingComponentStore:
            def load_prompt(self, name: str):
                return Failure(Exception("not implemented"))

            def load_toolset(self, name: str):
                return Failure(Exception("not implemented"))

            def load_constraint(self, name: str):
                return Failure(Exception("not implemented"))

            def load_model(self, name: str):
                return Failure(Exception("not implemented"))

            def list_components(self):
                return Failure(Exception("directory access failed"))

        result = component_list_command(as_json=True, component_store=FailingComponentStore())

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure

    def test_component_show_json_mode_includes_error_key_on_failure(self) -> None:
        """Component show failure in JSON mode must include 'error' key."""
        components = InMemoryComponentStore()

        result = component_show_command(
            "prompts/nonexistent", as_json=True, component_store=components
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert "error" in failure


# ============================================================================
# _read_spec_json Boundary Tests
# ============================================================================
# Regression tests for _read_spec_json behavior boundaries:
# - File not found returns critical failure with INTERNAL code
# - JSON decode error returns critical failure with parse details
# - OSError returns critical failure with error details
# - Non-dict root returns critical failure
# - Valid JSON dict returns Success with loaded spec


class TestReadSpecJson:
    """Tests for the _read_spec_json helper function behavior boundaries."""

    def test_file_not_found_returns_critical_failure(self, tmp_path: Path) -> None:
        """Non-existent file returns Failure with INTERNAL error code."""
        from larva.shell import cli as cli_module

        missing_path = tmp_path / "does-not-exist.json"
        result = cli_module._read_spec_json(str(missing_path))

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["code"] == "INTERNAL"
        assert failure["numeric_code"] == 10
        assert "not found" in failure["message"].lower()
        assert failure["details"]["path"] == str(missing_path)

    def test_json_decode_error_returns_failure_with_line_info(self, tmp_path: Path) -> None:
        """Invalid JSON returns Failure with decode error details."""
        from larva.shell import cli as cli_module

        invalid_path = tmp_path / "invalid.json"
        invalid_path.write_text('{"id": "test", "invalid json"', encoding="utf-8")

        result = cli_module._read_spec_json(str(invalid_path))

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["code"] == "INTERNAL"
        assert failure["numeric_code"] == 10
        assert "not valid" in failure["message"].lower() and "json" in failure["message"].lower()
        # JSONDecodeError provides line/column info when available
        assert "line" in failure["details"] or "column" in failure["details"]

    def test_os_error_returns_failure_with_error_details(self, tmp_path: Path) -> None:
        """OS-level read error returns Failure with error details."""
        from larva.shell import cli as cli_module

        # Create a directory instead of a file - will cause OSError on open
        error_path = tmp_path / "is-a-dir.json"
        error_path.mkdir()

        result = cli_module._read_spec_json(str(error_path))

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["code"] == "INTERNAL"
        assert failure["numeric_code"] == 10
        assert "read" in failure["message"].lower() or "failed" in failure["message"].lower()
        assert "error" in failure["details"]

    def test_non_dict_root_returns_failure(self, tmp_path: Path) -> None:
        """JSON root that is not a dict returns Failure."""
        from larva.shell import cli as cli_module

        array_path = tmp_path / "array.json"
        array_path.write_text('["not", "a", "dict"]', encoding="utf-8")

        result = cli_module._read_spec_json(str(array_path))

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["code"] == "INTERNAL"
        assert failure["numeric_code"] == 10
        assert "object" in failure["message"].lower()

    def test_valid_json_dict_returns_success(self, tmp_path: Path) -> None:
        """Valid JSON file with dict root returns Success with loaded spec."""
        from larva.shell import cli as cli_module

        valid_path = tmp_path / "valid.json"
        spec = _canonical_spec("test-persona")
        valid_path.write_text(json.dumps(spec), encoding="utf-8")

        result = cli_module._read_spec_json(str(valid_path))

        assert isinstance(result, Success)
        loaded = result.unwrap()
        assert loaded["id"] == "test-persona"


# ============================================================================
# _dispatch Boundary Tests
# ============================================================================
# Regression tests for _dispatch command routing behavior:
# - Validates correct command -> handler routing
# - Tests error propagation from _read_spec_json in validate/register paths
# - Tests error propagation from override parsing in assemble/resolve paths
# - Component subcommand routing


class TestDispatch:
    """Tests for the _dispatch command routing function."""

    def test_validate_command_routes_to_validate_handler(self, tmp_path: Path) -> None:
        """Validate command routes to validate_command handler."""
        from larva.shell import cli as cli_module

        spec_path = tmp_path / "valid.json"
        spec_path.write_text(json.dumps(_canonical_spec("test")), encoding="utf-8")

        # Create args namespace that mimics argparse
        class Args:
            command = "validate"
            spec = str(spec_path)
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        # Validate should call facade.validate
        assert facade.validate_calls == 1

    def test_register_command_routes_to_register_handler(self, tmp_path: Path) -> None:
        """Register command routes to register_command handler."""
        from larva.shell import cli as cli_module

        spec_path = tmp_path / "valid.json"
        spec_path.write_text(json.dumps(_canonical_spec("test")), encoding="utf-8")

        class Args:
            command = "register"
            spec = str(spec_path)
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        assert facade.register_calls == 1

    def test_validate_with_missing_file_returns_critical(self) -> None:
        """Validate command with missing spec file returns critical failure."""
        from larva.shell import cli as cli_module

        class Args:
            command = "validate"
            spec = "/nonexistent/path/spec.json"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Failure)
        failure = result.failure()
        # Missing file should be critical (exit code 2)
        assert failure["exit_code"] == EXIT_CRITICAL

    def test_register_with_missing_file_returns_critical(self) -> None:
        """Register command with missing spec file returns critical failure."""
        from larva.shell import cli as cli_module

        class Args:
            command = "register"
            spec = "/nonexistent/path/spec.json"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_CRITICAL

    def test_assemble_with_bad_override_returns_critical(self) -> None:
        """Assemble with malformed override returns critical failure."""
        from larva.shell import cli as cli_module

        class Args:
            command = "assemble"
            id = "test-id"
            prompts = []
            toolsets = []
            constraints = []
            overrides = ["not-a-valid-override"]  # Missing '='
            variables = []
            model = None
            output = None
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_CRITICAL
        assert "override" in failure["error"]["message"].lower()

    def test_resolve_command_routes_to_resolve_handler(self) -> None:
        """Resolve command routes to resolve_command handler."""
        from larva.shell import cli as cli_module

        class Args:
            command = "resolve"
            id = "test-id"
            overrides = []
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        assert facade.resolve_calls == 1
        assert facade.last_resolve_id == "test-id"

    def test_list_command_routes_to_list_handler(self) -> None:
        """List command routes to list_command handler."""
        from larva.shell import cli as cli_module

        class Args:
            command = "list"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        assert facade.list_calls == 1

    def test_clone_command_routes_to_clone_handler(self) -> None:
        """Clone command routes to clone_command handler."""
        from larva.shell import cli as cli_module

        class Args:
            command = "clone"
            source_id = "source-persona"
            new_id = "cloned-persona"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        assert facade.clone_calls == 1
        assert facade.last_clone_source == "source-persona"
        assert facade.last_clone_target == "cloned-persona"

    def test_component_list_routes_to_component_list_handler(self) -> None:
        """Component list routes to component_list_command handler."""
        from larva.shell import cli as cli_module

        class Args:
            command = "component"
            component_command = "list"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        # Component commands should NOT call facade methods
        assert facade.validate_calls == 0
        assert facade.assemble_calls == 0
        assert facade.register_calls == 0
        assert facade.resolve_calls == 0
        assert facade.list_calls == 0

    def test_component_show_routes_to_component_show_handler(self) -> None:
        """Component show routes to component_show_command handler."""
        from larva.shell import cli as cli_module

        class Args:
            command = "component"
            component_command = "show"
            ref = "prompts/test-prompt"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Success)
        # Component commands should NOT call facade methods
        assert facade.validate_calls == 0
        assert facade.assemble_calls == 0
        assert facade.register_calls == 0
        assert facade.resolve_calls == 0
        assert facade.list_calls == 0

    def test_unknown_command_returns_critical(self) -> None:
        """Unknown command returns critical failure."""
        from larva.shell import cli as cli_module

        class Args:
            command = "unknown-command"
            as_json = False

        facade = RecordingFacade()
        components = InMemoryComponentStore()

        result = cli_module._dispatch(Args(), facade=facade, component_store=components)

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_CRITICAL


# ============================================================================
# Update Command Tests
# ============================================================================


class TestUpdateCommand:
    """Tests for the update command handler."""

    def test_update_success_text_mode_returns_exit_ok(self) -> None:
        """Update with valid patches returns exit code 0 in text mode."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("update-me")))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import update_command

        result = update_command(
            "update-me",
            patches={"description": "Updated description"},
            as_json=False,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK

    def test_update_success_json_mode_returns_json_payload(self) -> None:
        """Update with valid patches returns JSON payload in JSON mode."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("update-me")))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import update_command

        result = update_command(
            "update-me",
            patches={"description": "Updated"},
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        assert cli_result["json"]["data"]["id"] == "update-me"

    def test_update_not_found_returns_exit_error(self) -> None:
        """Update non-existent persona returns exit code 1."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import update_command

        result = update_command(
            "missing", patches={"description": "x"}, as_json=False, facade=facade
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_update_not_found_json_mode_returns_error_envelope(self) -> None:
        """Update not-found returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            get_result=Failure(
                {
                    "code": "PERSONA_NOT_FOUND",
                    "message": "persona 'missing' not found",
                    "persona_id": "missing",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli import update_command

        result = update_command(
            "missing", patches={"description": "x"}, as_json=True, facade=facade
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "PERSONA_NOT_FOUND"
        assert error["numeric_code"] == 100

    def test_update_validation_failure_returns_exit_error(self) -> None:
        """Update with invalid patches returns exit code 1."""
        registry = InMemoryRegistryStore(get_result=Success(_canonical_spec("update-invalid")))
        facade = _make_facade(
            report=_invalid_report("INVALID_SPEC_VERSION"),
            registry=registry,
        )

        from larva.shell.cli import update_command

        result = update_command(
            "update-invalid", patches={"description": None}, as_json=False, facade=facade
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_update_success_applies_patches_and_returns_updated_spec(self) -> None:
        """Update applies patches and returns updated spec."""
        existing = _canonical_spec("patch-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli import update_command

        result = update_command(
            "patch-test",
            patches={"description": "New description"},
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        # Verify the patches were applied (the spec would have been updated)
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result


class TestRunLoopUpdateCommandRouting:
    """Tests for run_cli routing to update_command."""

    def test_update_success_routes_to_facade_update(self) -> None:
        """Update command routes to update_command and calls facade.update."""
        existing = _canonical_spec("route-update")
        registry = InMemoryRegistryStore(get_result=Success(existing))

        facade = RecordingFacade()
        facade.update_result = Success(existing)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "route-update", "--set", "description=Updated"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        assert stderr.getvalue() == ""
        assert facade.update_calls == 1
        assert facade.last_update_id == "route-update"
        assert facade.last_update_patches == {"description": "Updated"}


# ============================================================================
# --set Type Inference Tests (CLI)
# ============================================================================


class TestParseSetValues:
    """Tests for _parse_set_values type inference."""

    def test_parse_boolean_true(self) -> None:
        """Boolean 'true' is inferred as Python True."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["enabled=true"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"enabled": True}

    def test_parse_boolean_false(self) -> None:
        """Boolean 'false' is inferred as Python False."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["disabled=false"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"disabled": False}

    def test_parse_boolean_case_insensitive(self) -> None:
        """Boolean inference is case-insensitive."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["enabled=TRUE", "disabled=FALSE"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"enabled": True, "disabled": False}

    def test_parse_null(self) -> None:
        """Null 'null' is inferred as Python None."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["cleared=null"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"cleared": None}

    def test_parse_null_case_insensitive(self) -> None:
        """Null inference is case-insensitive."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["value=NULL"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"value": None}

    def test_parse_integer(self) -> None:
        """Integer strings are inferred as Python int."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["count=42"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"count": 42}

    def test_parse_negative_integer(self) -> None:
        """Negative integer strings are inferred as Python int."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["offset=-10"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"offset": -10}

    def test_parse_float(self) -> None:
        """Float strings are inferred as Python float."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["temperature=0.7"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"temperature": 0.7}

    def test_parse_negative_float(self) -> None:
        """Negative float strings are inferred as Python float."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["delta=-0.5"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"delta": -0.5}

    def test_parse_string_fallback(self) -> None:
        """Non-type strings fall back to string."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["name=gpt-4o"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"name": "gpt-4o"}

    def test_parse_string_with_equals(self) -> None:
        """Strings containing equals preserve the equals."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["equation=a=b"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"equation": "a=b"}

    def test_parse_multiple_values(self) -> None:
        """Multiple values are parsed and combined."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(
            ["enabled=true", "count=5", "name=test"],
            flag="--set",
        )
        assert isinstance(result, Success)
        assert result.unwrap() == {"enabled": True, "count": 5, "name": "test"}

    def test_parse_dot_key_creates_nested_dict(self) -> None:
        """Dot notation creates nested dict structure."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["model_params.temperature=0.7"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"model_params": {"temperature": 0.7}}

    def test_parse_nested_dot_key_creates_deep_nesting(self) -> None:
        """Multiple dots create deeper nesting."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["a.b.c=1"], flag="--set")
        assert isinstance(result, Success)
        assert result.unwrap() == {"a": {"b": {"c": 1}}}

    def test_parse_multiple_nested_keys(self) -> None:
        """Multiple nested keys merge correctly."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(
            ["model_params.temperature=0.7", "model_params.max_tokens=1000"],
            flag="--set",
        )
        assert isinstance(result, Success)
        assert result.unwrap() == {"model_params": {"temperature": 0.7, "max_tokens": 1000}}

    def test_parse_empty_key_returns_failure(self) -> None:
        """Empty key returns failure."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["=value"], flag="--set")
        assert isinstance(result, Failure)

    def test_parse_missing_equals_returns_failure(self) -> None:
        """Missing equals returns failure."""
        from larva.shell.cli_helpers import _parse_set_values

        result = _parse_set_values(["novalue"], flag="--set")
        assert isinstance(result, Failure)


class TestRunLoopUpdateTypeInference:
    """Tests for CLI --set type inference through run_cli."""

    def test_update_set_boolean_true(self) -> None:
        """Update --set with boolean true is inferred correctly."""
        existing = _canonical_spec("bool-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "bool-test", "--set", "can_spawn=true", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["can_spawn"] is True

    def test_update_set_boolean_false(self) -> None:
        """Update --set with boolean false is inferred correctly."""
        existing = _canonical_spec("bool-test-false")
        existing["can_spawn"] = True
        existing["spec_digest"] = _digest_for(existing)
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "bool-test-false", "--set", "can_spawn=false", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["can_spawn"] is False

    def test_update_set_null(self) -> None:
        """Update --set with null is inferred correctly."""
        existing = _canonical_spec("null-test")
        existing["description"] = "Will be nulled"
        existing["spec_digest"] = _digest_for(existing)
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "null-test", "--set", "description=null", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["description"] is None

    def test_update_set_integer(self) -> None:
        """Update --set with integer is inferred correctly."""
        existing = _canonical_spec("int-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "int-test", "--set", "model_params.max_tokens=1000", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["model_params"]["max_tokens"] == 1000

    def test_update_set_float(self) -> None:
        """Update --set with float is inferred correctly."""
        existing = _canonical_spec("float-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "float-test", "--set", "model_params.temperature=0.9", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["model_params"]["temperature"] == 0.9

    def test_update_set_string_fallback(self) -> None:
        """Update --set with string falls back correctly."""
        existing = _canonical_spec("string-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "string-test", "--set", "description=A new description", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["description"] == "A new description"

    def test_update_set_nested_path(self) -> None:
        """Update --set with nested path creates nested dict."""
        existing = _canonical_spec("nested-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update", "nested-test", "--set", "model_params.max_tokens=2000", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["model_params"]["max_tokens"] == 2000

    def test_update_set_multiple_values(self) -> None:
        """Update --set with multiple values processes all correctly."""
        existing = _canonical_spec("multi-test")
        registry = InMemoryRegistryStore(get_result=Success(existing))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update",
                "multi-test",
                "--set",
                "description=Updated",
                "--set",
                "can_spawn=true",
                "--set",
                "model_params.temperature=0.5",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["description"] == "Updated"
        assert payload["data"]["can_spawn"] is True
        assert payload["data"]["model_params"]["temperature"] == 0.5


# ============================================================================
# Update Batch Command Tests
# ============================================================================


class TestUpdateBatchCommand:
    """Tests for the update_batch command handler."""

    def test_update_batch_success_text_mode_returns_exit_ok(self) -> None:
        """Update batch with matching personas returns exit code 0 in text mode."""
        spec_alpha = _canonical_spec("alpha")
        spec_beta = _canonical_spec("beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o-mini"},
            set_clauses={"description": "Updated"},
            dry_run=False,
            as_json=False,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "Matched: 2" in cli_result["stdout"]
        assert "Updated: 2" in cli_result["stdout"]
        assert "alpha: True" in cli_result["stdout"]
        assert "beta: True" in cli_result["stdout"]

    def test_update_batch_success_json_mode_returns_json_payload(self) -> None:
        """Update batch returns JSON payload in JSON mode."""
        spec_alpha = _canonical_spec("alpha")
        spec_beta = _canonical_spec("beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o-mini"},
            set_clauses={"description": "Updated"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        assert cli_result["exit_code"] == EXIT_OK
        assert "json" in cli_result
        data = cli_result["json"]["data"]
        assert data["matched"] == 2
        assert data["updated"] == 2
        assert len(data["items"]) == 2

    def test_update_batch_dry_run_returns_preview_without_writes(self) -> None:
        """Update batch dry_run returns matched without saving."""
        spec_alpha = _canonical_spec("alpha")
        spec_beta = _canonical_spec("beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o-mini"},
            set_clauses={"description": "Should not persist"},
            dry_run=True,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        data = cli_result["json"]["data"]
        assert data["matched"] == 2
        assert data["updated"] == 0
        # Verify no saves occurred
        assert registry.save_inputs == []

    def test_update_batch_no_matches_returns_zero_counts(self) -> None:
        """Update batch with no matching personas returns zero counts."""
        spec_alpha = _canonical_spec("alpha")
        spec_alpha["model"] = "gpt-4"
        spec_alpha["spec_digest"] = _digest_for(spec_alpha)
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "nonexistent-model"},
            set_clauses={"description": "Updated"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        data = cli_result["json"]["data"]
        assert data["matched"] == 0
        assert data["updated"] == 0
        assert data["items"] == []

    @pytest.mark.parametrize(
        ("where_key", "expected_field", "expected_value"),
        [
            ("tools.shell", "tools", "read_only"),
            ("side_effect_policy", "side_effect_policy", "read_only"),
        ],
    )
    def test_update_batch_rejects_legacy_where_fields(
        self,
        where_key: str,
        expected_field: str,
        expected_value: object,
    ) -> None:
        """Update batch must fail closed on non-canonical where vocabulary."""
        registry = InMemoryRegistryStore(list_result=Success([_canonical_spec("alpha")]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={where_key: expected_value},
            set_clauses={"description": "Updated"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        error = failure["error"]
        assert error["code"] == "INVALID_INPUT"
        assert error["numeric_code"] == 1
        assert expected_field in error["message"]
        assert error["details"]["field"] == expected_field
        assert error["details"]["where_key"] == where_key
        assert registry.save_inputs == []

    def test_update_batch_failure_returns_exit_error(self) -> None:
        """Registry failure returns exit code 1."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "cannot read registry index",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o-mini"},
            set_clauses={"description": "Test"},
            dry_run=False,
            as_json=False,
            facade=facade,
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR

    def test_update_batch_failure_json_mode_returns_error_envelope(self) -> None:
        """Registry failure returns JSON error envelope in JSON mode."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "cannot read registry index",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o-mini"},
            set_clauses={"description": "Test"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Failure)
        failure = result.failure()
        assert failure["exit_code"] == EXIT_ERROR
        assert "error" in failure
        error = failure["error"]
        assert error["code"] == "REGISTRY_INDEX_READ_FAILED"
        assert error["numeric_code"] == 107

    def test_update_batch_dotted_where_matches_nested_fields(self) -> None:
        """Update batch where clause with dot notation matches nested fields."""
        spec_match = _canonical_spec("match")
        spec_match["model_params"] = {"temperature": 0.7}
        spec_match["spec_digest"] = _digest_for(spec_match)
        spec_no_match = _canonical_spec("no-match")
        spec_no_match["model_params"] = {"temperature": 0.3}
        spec_no_match["spec_digest"] = _digest_for(spec_no_match)

        registry = InMemoryRegistryStore(list_result=Success([spec_match, spec_no_match]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model_params.temperature": 0.7},
            set_clauses={"description": "Matched"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        data = cli_result["json"]["data"]
        assert data["matched"] == 1
        assert data["updated"] == 1
        assert data["items"][0]["id"] == "match"

    def test_update_batch_multiple_where_clauses_use_and_semantics(self) -> None:
        """Update batch with multiple where clauses uses AND semantics."""
        spec_match = _canonical_spec("match")
        spec_match["model"] = "gpt-4o"
        spec_match["model_params"] = {"temperature": 0.7}
        spec_match["spec_digest"] = _digest_for(spec_match)

        spec_wrong_model = _canonical_spec("wrong-model")
        spec_wrong_temp = _canonical_spec("wrong-temp")
        spec_wrong_temp["model"] = "gpt-4o"
        spec_wrong_temp["spec_digest"] = _digest_for(spec_wrong_temp)

        registry = InMemoryRegistryStore(
            list_result=Success([spec_match, spec_wrong_model, spec_wrong_temp])
        )
        facade = _make_facade(report=_valid_report(), registry=registry)

        from larva.shell.cli_commands import update_batch_command

        result = update_batch_command(
            where_clauses={"model": "gpt-4o", "model_params.temperature": 0.7},
            set_clauses={"description": "Matched"},
            dry_run=False,
            as_json=True,
            facade=facade,
        )

        assert isinstance(result, Success)
        cli_result = result.unwrap()
        data = cli_result["json"]["data"]
        assert data["matched"] == 1
        assert data["updated"] == 1


class TestRunLoopBatchUpdate:
    """Tests for CLI update-batch dispatch through run_cli."""

    def test_update_batch_success_json(self) -> None:
        """Update batch success returns JSON with matched/updated counts."""
        spec_alpha = _canonical_spec("alpha")
        spec_beta = _canonical_spec("beta")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha, spec_beta]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model=gpt-4o-mini",
                "--set",
                "description=Updated",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["matched"] == 2
        assert payload["data"]["updated"] == 2
        assert len(payload["data"]["items"]) == 2
        assert stderr.getvalue() == ""

    def test_update_batch_success_text(self) -> None:
        """Update batch success formats text output with Matched/Updated counts."""
        spec_alpha = _canonical_spec("alpha")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model=gpt-4o-mini",
                "--set",
                "description=Updated",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        output = stdout.getvalue()
        assert "Matched: 1" in output
        assert "Updated: 1" in output
        assert "alpha: True" in output

    def test_update_batch_dry_run_json(self) -> None:
        """Update batch --dry-run returns preview without writes."""
        spec_alpha = _canonical_spec("alpha")
        registry = InMemoryRegistryStore(list_result=Success([spec_alpha]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model=gpt-4o-mini",
                "--set",
                "description=Preview",
                "--dry-run",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["matched"] == 1
        assert payload["data"]["updated"] == 0
        assert payload["data"]["items"][0]["updated"] is False
        # Verify no saves
        assert registry.save_inputs == []

    def test_update_batch_no_where_returns_critical(self) -> None:
        """Update batch without --where returns critical error."""
        facade = _make_facade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update-batch", "--set", "description=Test", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        # argparse reports "the following arguments are required: --where"
        assert "--where" in payload["error"]["details"]["message"]

    def test_update_batch_no_set_returns_critical(self) -> None:
        """Update batch without --set returns critical error."""
        facade = _make_facade()
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["update-batch", "--where", "model=gpt-4o-mini", "--json"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "INTERNAL"
        # argparse reports "the following arguments are required: --set"
        assert "--set" in payload["error"]["details"]["message"]

    def test_update_batch_failure_json_returns_error_envelope(self) -> None:
        """Update batch failure returns JSON error envelope."""
        registry = InMemoryRegistryStore(
            list_result=Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
        )
        facade = _make_facade(registry=registry)
        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model=gpt-4o-mini",
                "--set",
                "description=Test",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_ERROR
        payload = json.loads(stdout.getvalue())
        assert payload["error"]["code"] == "REGISTRY_INDEX_READ_FAILED"
        assert payload["error"]["numeric_code"] == 107

    def test_update_batch_nested_where_json(self) -> None:
        """Update batch with nested --where key matches nested specs."""
        spec_match = _canonical_spec("match")
        spec_match["model_params"] = {"temperature": "0.9"}  # String to match CLI parsing
        spec_match["spec_digest"] = _digest_for(spec_match)
        spec_no_match = _canonical_spec("no-match")
        spec_no_match["model_params"] = {"temperature": "0.1"}
        spec_no_match["spec_digest"] = _digest_for(spec_no_match)

        registry = InMemoryRegistryStore(list_result=Success([spec_match, spec_no_match]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model_params.temperature=0.9",
                "--set",
                "description=Hot",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["matched"] == 1
        assert payload["data"]["items"][0]["id"] == "match"

    def test_update_batch_multiple_where_json(self) -> None:
        """Update batch with multiple --where clauses uses AND semantics."""
        spec_match = _canonical_spec("match")
        spec_match["model"] = "gpt-4o"
        spec_match["model_params"] = {"temperature": "0.7"}  # String to match CLI parsing
        spec_match["spec_digest"] = _digest_for(spec_match)

        registry = InMemoryRegistryStore(list_result=Success([spec_match]))
        facade = _make_facade(report=_valid_report(), registry=registry)

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            [
                "update-batch",
                "--where",
                "model=gpt-4o",
                "--where",
                "model_params.temperature=0.7",
                "--set",
                "description=Matched",
                "--json",
            ],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_OK
        payload = json.loads(stdout.getvalue())
        assert payload["data"]["matched"] == 1
        assert payload["data"]["updated"] == 1


# ============================================================================
# Doctor Registry Command Tests
# ============================================================================


# ============================================================================
# Doctor Registry Command Tests
# ============================================================================


class TestDoctorRegistryCommand:
    """Tests for the doctor diagnostic command and underlying registry probe."""

    def test_doctor_registry_empty_registry_returns_ok(self) -> None:
        """Doctor registry with empty registry returns exit 0."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Success

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({})
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            result = doctor_registry_command(as_json=False, facade=None)

            assert isinstance(result, Success)
            cli_result = result.unwrap()
            assert cli_result["exit_code"] == EXIT_OK
            assert "DIAGNOSTIC OK" in cli_result["stdout"]

    def test_doctor_registry_index_read_failure_returns_error(self) -> None:
        """Doctor registry when index read fails returns exit 1."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Failure

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Failure(
                {
                    "code": "REGISTRY_INDEX_READ_FAILED",
                    "message": "index unreadable",
                    "path": "/tmp/index.json",
                }
            )
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            result = doctor_registry_command(as_json=False, facade=None)

            assert isinstance(result, Failure)
            failure = result.failure()
            assert failure["exit_code"] == EXIT_ERROR

    def test_doctor_registry_spec_read_failure_returns_error(self) -> None:
        """Doctor registry when spec read fails returns exit 1."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Failure, Success

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({"persona-a": "sha256:abc"})
            mock_store._read_spec.return_value = Failure(
                {
                    "code": "REGISTRY_SPEC_READ_FAILED",
                    "message": "spec file missing",
                    "persona_id": "persona-a",
                    "path": "/fake/root/persona-a.json",
                }
            )
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            result = doctor_registry_command(as_json=False, facade=None)

            assert isinstance(result, Failure)
            failure = result.failure()
            assert failure["exit_code"] == EXIT_ERROR
            assert "DIAGNOSTIC FAIL" in failure["stderr"]

    def test_doctor_registry_with_entries_succeeds(self) -> None:
        """Doctor registry with valid entries returns exit 0."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Success

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success(
                {
                    "persona-a": "sha256:aaa",
                    "persona-b": "sha256:bbb",
                }
            )
            spec = {"id": "persona-a", "description": "Test persona"}
            mock_store._read_spec.return_value = Success(spec)
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            result = doctor_registry_command(as_json=False, facade=None)

            assert isinstance(result, Success)
            cli_result = result.unwrap()
            assert cli_result["exit_code"] == EXIT_OK
            assert "DIAGNOSTIC OK" in cli_result["stdout"]

    def test_doctor_registry_json_mode_returns_json_payload(self) -> None:
        """Doctor registry in JSON mode returns structured payload."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Success

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({})
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            result = doctor_registry_command(as_json=True, facade=None)

            assert isinstance(result, Success)
            cli_result = result.unwrap()
            assert cli_result["exit_code"] == EXIT_OK
            assert "json" in cli_result
            assert cli_result["json"]["data"]["status"] == "ok"

    def test_doctor_extra_argument_returns_critical(self) -> None:
        """Doctor rejects extra positional arguments after surface simplification."""
        from larva.shell.cli import run_cli

        facade = _make_facade()

        stdout = io.StringIO()
        stderr = io.StringIO()

        exit_code = run_cli(
            ["doctor", "registry"],
            facade=facade,
            stdout=stdout,
            stderr=stderr,
        )

        assert exit_code == EXIT_CRITICAL

    def test_doctor_via_cli_full_path(self) -> None:
        """Doctor via run_cli succeeds with the single public surface."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli import run_cli
        from returns.result import Success

        facade = _make_facade()
        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({})
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            stdout = io.StringIO()
            stderr = io.StringIO()

            exit_code = run_cli(
                ["doctor"],
                facade=facade,
                stdout=stdout,
                stderr=stderr,
            )

            assert exit_code == EXIT_OK

    def test_doctor_json_mode_via_cli_full_path_succeeds(self) -> None:
        """Doctor supports JSON mode on the single public surface."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli import run_cli
        from returns.result import Success

        facade = _make_facade()
        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({})
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            stdout = io.StringIO()
            stderr = io.StringIO()

            exit_code = run_cli(
                ["doctor", "--json"],
                facade=facade,
                stdout=stdout,
                stderr=stderr,
            )

            assert exit_code == EXIT_OK
            payload = json.loads(stdout.getvalue())
            assert payload["data"]["status"] == "ok"

    def test_doctor_registry_with_malformed_spec_fails_via_facade_validation(self) -> None:
        """Doctor registry with facade catches malformed spec that list/serve would reject.

        Regression test: previously doctor did shallow filesystem reads only and would
        report OK for registry entries that facade-backed list/serve would reject due to
        missing spec_version or other canonical admission failures.
        """
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Failure, Success

        # A spec missing spec_version - this is what list/serve reject
        # Include all required fields except spec_version so normalize catches it
        malformed_spec = {
            "id": "malformed-persona",
            "description": "Missing spec_version",
            "prompt": "You are helpful.",
            "model": "gpt-4o-mini",
            "capabilities": {"shell": "read_only"},
            # spec_version intentionally omitted to trigger canonical validation failure
        }

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success(
                {
                    "malformed-persona": "sha256:malformed",
                }
            )
            mock_store._read_spec.return_value = Success(malformed_spec)
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            # Build facade with REAL validate/normalize modules so _normalize_and_validate
            # runs production canonical checks (NOT spy doubles that return valid unconditionally)
            facade = DefaultLarvaFacade(
                spec=spec_module,
                assemble=assemble_module,
                validate=validate_module,
                normalize=normalize_module,
                components=InMemoryComponentStore(),
                registry=InMemoryRegistryStore(),
            )

            result = doctor_registry_command(as_json=False, facade=facade)

            assert isinstance(result, Failure)
            failure = result.failure()
            assert failure["exit_code"] == EXIT_ERROR
            assert "DIAGNOSTIC FAIL" in failure["stderr"]
            assert "spec_version" in failure["stderr"]
            assert "malformed-persona" in failure["stderr"]

    def test_doctor_cli_fails_on_malformed_spec_via_facade_validation(self) -> None:
        """doctor must expose facade-backed validation failures on its only surface."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli import run_cli
        from returns.result import Success

        malformed_spec = {
            "id": "malformed-persona",
            "description": "Missing spec_version",
            "prompt": "You are helpful.",
            "model": "gpt-4o-mini",
            "capabilities": {"shell": "read_only"},
        }

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success({"malformed-persona": "sha256:bad"})
            mock_store._read_spec.return_value = Success(malformed_spec)
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            facade = DefaultLarvaFacade(
                spec=spec_module,
                assemble=assemble_module,
                validate=validate_module,
                normalize=normalize_module,
                components=InMemoryComponentStore(),
                registry=InMemoryRegistryStore(),
            )

            stdout = io.StringIO()
            stderr = io.StringIO()

            exit_code = run_cli(
                ["doctor"],
                facade=facade,
                stdout=stdout,
                stderr=stderr,
            )

            assert exit_code == EXIT_ERROR
            error_output = stderr.getvalue()
            assert "DIAGNOSTIC FAIL" in error_output
            assert "spec_version" in error_output
            assert "malformed-persona" in error_output

    def test_doctor_registry_with_valid_specs_succeeds_via_facade_validation(self) -> None:
        """Doctor registry with facade passes valid specs that list/serve accept."""
        from pathlib import Path
        from unittest.mock import MagicMock, patch
        from larva.shell.cli_commands import doctor_registry_command
        from returns.result import Success

        with patch("larva.shell.registry.FileSystemRegistryStore") as mock_store_class:
            mock_store = MagicMock()
            mock_store._read_index.return_value = Success(
                {
                    "persona-a": "sha256:aaa",
                    "persona-b": "sha256:bbb",
                }
            )
            mock_store._read_spec.return_value = Success(_canonical_spec("persona-a"))
            mock_store.root = Path("/fake/root")
            mock_store_class.return_value = mock_store

            # Build facade with REAL modules so validation runs production checks
            facade = DefaultLarvaFacade(
                spec=spec_module,
                assemble=assemble_module,
                validate=validate_module,
                normalize=normalize_module,
                components=InMemoryComponentStore(),
                registry=InMemoryRegistryStore(),
            )

            result = doctor_registry_command(as_json=False, facade=facade)

            assert isinstance(result, Success)
            cli_result = result.unwrap()
            assert cli_result["exit_code"] == EXIT_OK
            assert "DIAGNOSTIC OK" in cli_result["stdout"]
