# larva — Agent Usage Guide

**Audience:** AI agents (nervus, anima, and other opifex components) consuming larva as a tool.
**larva does:** validate, assemble, normalize, register, resolve PersonaSpec JSON.
**larva does NOT do:** call LLMs, execute agents, enforce runtime tool policy, store memory across runs.

---

## 1. How to Call larva

### Primary: MCP Server

larva runs as an MCP server (stdio, HTTP, or SSE). stdio is the default for CLI
usage. HTTP is the standard remote transport (MCP spec 2025-03-26+). SSE is legacy.
Prefer MCP for all programmatic access.

Available tools:
```
larva_validate(spec)                    → ValidationReport
larva_assemble(components)              → PersonaSpec
larva_register(spec)                    → {id, registered}
larva_resolve(id, overrides?)           → PersonaSpec
larva_list()                            → [{id, description, spec_digest, model}]
larva_update(id, patches)               → PersonaSpec
larva_update_batch(where, patches, dry_run?) → {items, matched, updated}
larva_clone(source_id, new_id)          → PersonaSpec
larva_delete(id)                        → {id, deleted}
larva_clear(confirm)                    → {cleared, count}
larva_export(all?, ids?)                → [PersonaSpec, ...]
larva_component_list()                  → {prompts, toolsets, constraints, models}
larva_component_show(type, name)        → component content
```

For `larva_export`, provide exactly one selector: `all=true` to export the
full registry, or `ids=[...]` to export specific personas. `{all:false}` is
rejected as a missing selector.

For every MCP PersonaSpec input, forbidden legacy vocabulary is `tools` and
`side_effect_policy`. Unknown top-level fields are rejected as non-canonical.

### Fallback: CLI

```bash
larva validate <spec.json> [--json]
larva assemble --id <id> [--prompt <name>]... [--toolset <name>]... [--constraints <name>]... [--model <name>] [--override key=value]... [-o output.json]
larva register <spec.json> [--json]
larva resolve <id> [--override key=value]... [--json]
larva list [--json]
larva delete <id> [--json]
larva clear --confirm "CLEAR REGISTRY" [--json]
larva component list [--json]
larva component show <type>/<name> [--json]
larva doctor [--json]
larva opencode [OPENCODE_ARG ...]
```

Use `--json` for machine-readable output on canonical larva commands. Those
commands exit 0 (success), 1 (domain error), 2 (input/critical failure).

`larva doctor` always runs the registry diagnostic through the same
facade-backed canonical validation path used by list/serve. There is no
separate shallow mode.

`larva opencode` is different: it is a launcher for the real OpenCode CLI, not a
JSON-producing larva operation. It builds a temporary `OPENCODE_CONFIG_CONTENT`
from the registry, injects the larva OpenCode plugin, and forwards remaining
arguments to `opencode`. A leading `--` after `opencode` is optional and is
stripped before forwarding.

### Fallback: Python API

```python
from larva.shell.python_api import (
    assemble, validate, register, resolve, list,
    delete, clear, component_list, component_show,
)
```

---

## 2. PersonaSpec — The Core Data Structure

A PersonaSpec is a flat, self-contained JSON object. All larva operations produce or consume this shape.

```json
{
  "spec_version": "0.1.0",
  "id": "code-reviewer",
  "description": "Reviews code changes with read-focused tooling.",
  "prompt": "You are a senior code reviewer...",
  "model": "claude-opus-4-20250514",
  "model_params": {
    "temperature": 0.3,
    "max_tokens": 4096
  },
  "capabilities": {
    "filesystem": "read_write",
    "shell": "read_only",
    "git": "read_only"
  },
  "can_spawn": false,
  "compaction_prompt": "Summarize working context into concise carry-forward notes.",
  "spec_digest": "sha256:e3b0c442..."
}
```

**Field constraints:**
- `id`: required, must match `^[a-z0-9]+(-[a-z0-9]+)*$` (flat kebab-case, no namespaces)
- `spec_version`: required on canonical input and must be `"0.1.0"`
- `spec_digest`: computed by larva during normalization (SHA-256 of canonical JSON, sorted keys, no whitespace, excluding spec_digest itself). Do not set manually.
- `capabilities`: required canonical capability map. `capabilities: {}` means no declared capability postures, not unrestricted access.
- `can_spawn`: boolean or list of persona ids the persona may spawn

**No assembly metadata in output.** No `base:`, no component references. Output is always flat.

---

## 3. Core Operations

### 3.1 validate

Check a PersonaSpec for schema conformance and semantic validity.

**MCP:**
```json
{ "spec": { "id": "my-agent", "spec_version": "0.1.0", "prompt": "You are..." } }
```

**Returns:** `ValidationReport`
```json
{
  "valid": true,
  "errors": [],
  "warnings": [
    "unknown model identifier 'custom-model-x' is outside the known-model snapshot",
    "description looks like prompt text instead of a short operational summary",
    "can_spawn references ids outside the current registry snapshot: missing-child"
  ]
}
```

- `errors` is always present (empty list when valid).
- `warnings` is always present and is non-blocking.
- Canonical warning conditions include: unknown model identifiers; empty/all-`none` capability posture; descriptions outside the guidance range; prompt-like descriptions; unknown capability-family identifiers; read-focused reviewer/auditor identities paired with `read_write`/`destructive` capability postures; and `can_spawn` targets missing from the current registry snapshot.
- Prompt text is treated as opaque data; `{placeholder}` style text is not rejected or interpreted as a template variable.
- `model_params` is an optional canonical field and remains valid across validate/register/resolve/update flows.

**Decision:** Use `valid` field to gate next action.

---

### 3.2 assemble

Compose a PersonaSpec from named components stored in `~/.larva/components/`.

**MCP:**
```json
{
  "id": "code-reviewer",
  "prompts": ["code-reviewer", "careful-reasoning"],
  "toolsets": ["code-tools"],
  "constraints": ["strict"],
  "model": "claude-opus-4",
  "overrides": { "description": "Custom description" }
}
```

All fields except `id` are optional.

**Returns:** Complete, validated, normalized PersonaSpec JSON (ready to register or use directly).

**Error triggers:**
- `COMPONENT_NOT_FOUND` — named component does not exist in `~/.larva/components/`
- `COMPONENT_CONFLICT` — two components set the same scalar field without an `overrides` key resolving it
- `VARIABLES_NOT_ALLOWED` — non-canonical placeholder-map input is rejected at the assembly boundary

**Conflict resolution:** Use `overrides` to explicitly win over conflicting component values.

---

### 3.3 register

Store a PersonaSpec in the global registry at `~/.larva/registry/`.

**MCP:**
```json
{ "spec": { <PersonaSpec> } }
```

**Returns:**
```json
{ "id": "code-reviewer", "registered": true }
```

- Spec must pass validation. larva revalidates before writing.
- Overwrites existing registration for the same `id`.
- Registry index at `~/.larva/registry/index.json` maps `id → spec_digest`.

---

### 3.4 resolve

Fetch a registered persona by id, optionally patching fields at call time.

**MCP:**
```json
{ "id": "code-reviewer", "overrides": { "model": "claude-opus-4-20250514" } }
```

**Returns:** PersonaSpec with overrides applied. `spec_digest` is recomputed after override.

**Error triggers:**
- `PERSONA_NOT_FOUND` — id not in registry

**Key behavior:** Overrides trigger revalidation and renormalization. A null/falsey override value is applied as-is (not ignored).

---

### 3.5 list

Enumerate all registered personas.

**MCP:** no parameters

**Returns:**
```json
[
  {
    "id": "code-reviewer",
    "description": "Reviews code changes with read-focused tooling.",
    "spec_digest": "sha256:e3b0c442...",
    "model": "claude-opus-4-20250514"
  }
]
```

---

### 3.6 delete

Remove a registered persona from the registry.

**MCP:**
```json
{ "id": "old-persona" }
```

**Returns:**
```json
{ "id": "old-persona", "deleted": true }
```

**Error triggers:**
- `PERSONA_NOT_FOUND` (100) — id not in registry
- `INVALID_PERSONA_ID` (104) — id format invalid
- `REGISTRY_DELETE_FAILED` (111) — file system deletion failed

**Key behavior:** Deletion is atomic (index-first). If deletion partially fails, the registry remains consistent for `list()`.

---

### 3.7 clear

Remove ALL registered personas from the registry. Irreversible.

**MCP:**
```json
{ "confirm": "CLEAR REGISTRY" }
```

**Returns:**
```json
{ "cleared": true, "count": 7 }
```

**Safety guard:** The `confirm` parameter must be exactly `"CLEAR REGISTRY"`. Any other value is rejected immediately without touching the file system.

**Error triggers:**
- `INVALID_CONFIRMATION_TOKEN` (112) — confirm string does not match
- `REGISTRY_DELETE_FAILED` (111) — file system deletion failed (partial failure possible; `details.failed_ids` lists which ids could not be removed)

**Python API:** `confirm` is keyword-only: `clear(confirm="CLEAR REGISTRY")`

---

### 3.8 component_list

Discover all available components by type. Call this before `assemble` to know what component names are valid.

**MCP:** no parameters

**Returns:**
```json
{
  "prompts": ["code-reviewer", "architect"],
  "toolsets": ["readonly", "readwrite"],
  "constraints": ["strict", "autonomous"],
  "models": ["default", "claude-opus"]
}
```

---

### 3.9 component_show

Inspect a specific component's content.

**MCP:**
```json
{ "component_type": "prompts", "name": "code-reviewer" }
```

**Returns:** Component content dict. Shape varies by type:
- Prompt: `{"text": "You are a senior code reviewer..."}`
- Toolset: `{"capabilities": {"filesystem": "read_write", ...}}`
- Constraint: `{"can_spawn": false, "compaction_prompt": "...", ...}`
- Model: `{"model": "claude-opus-4-20250514", "model_params": {...}}`

**Error triggers:**
- `COMPONENT_NOT_FOUND` (105) — component does not exist or type is invalid

**Note:** Components are read-only through larva. larva does not create or delete components — they are managed as files in `~/.larva/components/`.

---

## 4. Component Library

Components live in `~/.larva/components/` organized by type. Component names are bare filenames without extensions.

| Type | Directory | File format | Contributes to |
|------|-----------|-------------|----------------|
| Prompt | `prompts/` | `.md` (plain text) | `prompt` |
| Toolset | `toolsets/` | `.yaml` | `capabilities` |
| Constraint | `constraints/` | `.yaml` | `can_spawn`, `compaction_prompt` |
| Model | `models/` | `.yaml` | `model`, `model_params` |

### Prompt Component (`prompts/code-reviewer.md`)
```markdown
You are a senior code reviewer. Focus on correctness over style.
Always cite specific line numbers when pointing out issues.
```

### Toolset Component (`toolsets/code-tools.yaml`)
```yaml
capabilities:
  filesystem: read_write
  shell: read_only
  git: read_only
```

### Constraint Component (`constraints/strict.yaml`)
```yaml
can_spawn: false
compaction_prompt: |
  Summarize the working context into concise carry-forward notes.
```

### Model Component (`models/claude-opus-4.yaml`)
```yaml
model: "claude-opus-4-20250514"
model_params:
  temperature: 0.3
  max_tokens: 4096
```

### Assembly Rules

- **Prompts**: Concatenated in declared order, `\n\n` separator → single `prompt` string.
- **Scalars** (`model`, `can_spawn`): Multiple component sources for same field → `COMPONENT_CONFLICT`. Resolve with `overrides`.
- **capabilities**: Multiple toolsets may merge only if no contradictory posture for same tool family. Contradiction → `COMPONENT_CONFLICT`.
- **model_params**: Deep-merged from model component. `overrides` can patch individual keys.

### Browsing Components via CLI

```bash
larva component list                          # list all components
larva component show prompts/code-reviewer    # show a prompt component
larva component show toolsets/code-tools      # show a toolset component
larva component show --json prompts/base      # machine-readable
```

---

## 5. Placeholder policy

Canonical larva does not support non-canonical placeholder-map inputs on PersonaSpec or assembly requests.

- Placeholder-map inputs at validate/register/assemble/update boundaries are rejected as extra/forbidden fields.
- Prompt text must already be fully composed before admission.
- Prompt text is opaque; `{placeholder}` style text is not interpreted as a template variable.

---

## 6. Error Handling

All errors use a single envelope shape:

```json
{
  "code": "COMPONENT_CONFLICT",
  "numeric_code": 106,
  "message": "Field 'can_spawn' set by both 'constraints/strict' and 'constraints/autonomous'",
  "details": {
    "field": "can_spawn",
    "sources": ["constraints/strict", "constraints/autonomous"]
  }
}
```

**Transport wrapping:**
- MCP: error payload returned directly as above
- CLI `--json`: payload wrapped as `{ "error": <above> }`

**Error code table:**

| Code | Name | Typical cause |
|------|------|---------------|
| 10 | `INTERNAL` | Unmapped fallback |
| 100 | `PERSONA_NOT_FOUND` | `resolve` id not in registry |
| 101 | `PERSONA_INVALID` | validation failed |
| 102 | `PERSONA_CYCLE` | circular reference (reserved) |
| 104 | `INVALID_PERSONA_ID` | id violates kebab-case rules |
| 105 | `COMPONENT_NOT_FOUND` | named component not on disk |
| 106 | `COMPONENT_CONFLICT` | two components set same scalar field |
| 107 | `REGISTRY_INDEX_READ_FAILED` | `~/.larva/registry/index.json` unreadable |
| 108 | `REGISTRY_SPEC_READ_FAILED` | `<id>.json` unreadable |
| 109 | `REGISTRY_WRITE_FAILED` | cannot write spec file |
| 110 | `REGISTRY_UPDATE_FAILED` | cannot update index |
| 111 | `REGISTRY_DELETE_FAILED` | persona file deletion failed |
| 112 | `INVALID_CONFIRMATION_TOKEN` | confirm token for `clear` does not match |

---

## 7. File System Layout

```
~/.larva/
  components/
    prompts/<name>.md          # prompt fragments
    toolsets/<name>.yaml       # tool posture maps
    constraints/<name>.yaml    # can_spawn + compaction_prompt
    models/<name>.yaml         # model + model_params
  registry/
    <id>.json                  # one file per registered persona
    index.json                 # {id: spec_digest} mapping
```

---

## 8. Common Workflows

### Workflow A: Generate and register a new persona

```
1. Build PersonaSpec JSON (LLM-generated or hand-written)
2. larva_validate(spec) → check valid=true
3. larva_register(spec) → get id back
4. larva_resolve(id) → confirm round-trip
```

### Workflow B: Compose from components

```
1. larva_component_list() → discover available components
2. larva_assemble({id, prompts, toolsets, constraints, model}) → PersonaSpec
3. Inspect returned spec; adjust overrides if COMPONENT_CONFLICT
4. larva_register(spec)
```

### Workflow C: Load for agent execution

```
1. larva_resolve(id) → PersonaSpec
   OR
   larva_resolve(id, overrides={model: "..."}) → PersonaSpec with runtime patch
2. Pass spec to anima or agent runner
```

For OpenCode, use the wrapper instead of writing `.opencode/opencode.json`:

```bash
larva opencode --agent python-senior
larva opencode run "check this bug" --agent python-senior
```

The wrapper only projects registered personas into OpenCode's startup config; it
does not call the model or own runtime policy.

### Workflow D: Discover available personas

```
1. larva_list() → [{id, description, spec_digest, model}, ...]
2. larva_resolve(id) → full spec for chosen persona
```

### Workflow E: Remove a persona

```
1. larva_delete(id) → {id, deleted: true}
```

### Workflow F: Reset registry

```
1. larva_clear(confirm="CLEAR REGISTRY") → {cleared: true, count: N}
```

---

## 9. Critical Constraints

- **No LLM calls.** larva is pure persona management. It does not execute or call any model.
- **No inheritance.** There is no `base:` field. Composition is explicit.
- **Error-on-conflict.** Conflicting scalar fields from multiple components always error. Use `overrides` to resolve.
- **Ids are global and flat.** No namespacing in v1. Ids must be kebab-case: `^[a-z0-9]+(-[a-z0-9]+)*$`.
- **spec_version is schema identity, not persona revisioning.** Canonical PersonaSpec input requires `spec_version: "0.1.0"`; public canonical admission/update paths do not treat it as optional, and patch/update attempts to mutate it are rejected.
- **spec_digest is always recomputed.** Do not pass stale digest values; larva overwrites them.
- **Override revalidation is mandatory.** When overrides are applied via `resolve`, the result is revalidated and renormalized. Invalid overrides produce `PERSONA_INVALID`.
- **No cross-run persona memory.** Persona changes require explicit `register`. There is no hidden mutable state.
- **Components are read-only.** larva reads components from `~/.larva/components/` but does not create, modify, or delete them. Component file management is external.
- **`clear` requires confirmation.** The confirm token `"CLEAR REGISTRY"` must be passed exactly. This is irreversible.
