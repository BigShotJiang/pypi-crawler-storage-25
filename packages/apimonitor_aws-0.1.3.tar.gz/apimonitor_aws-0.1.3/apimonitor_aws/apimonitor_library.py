import boto3
import uuid
from botocore.exceptions import ClientError


#Custom AWS library for APIMonitor
#Manages S3, DynamoDB, and SNS interactions
class AWS_RESOURCES_MANAGER:
    def __init__(self, region='us-east-1'):
        self.region = region
        self.s3 = boto3.client('s3', region_name=region)
        self.dynamodb = boto3.resource('dynamodb', region_name=region)
        self.sns = boto3.client('sns', region_name=region)
        self.bucket_name = 'api-details-apimonitor'
        self.pvp_bucket = "apimonitor-profiles"
        self.results_table_name = 'apimonitor-results'
        
        
        
        
#Creates the S3 bucket for profile pictures if it doesn't exist.
    def create_s3_bucket(self):
        try:
            self.s3.head_bucket(Bucket=self.bucket_name)
            print(f'Bucket {self.bucket_name} already exists.')
        except ClientError:
            self.s3.create_bucket(Bucket=self.bucket_name)
            self.s3.put_public_access_block(
                Bucket=self.bucket_name,
                PublicAccessBlockConfiguration={
                    'BlockPublicAcls': True,
                    'IgnorePublicAcls': True,
                    'BlockPublicPolicy': True,
                    'RestrictPublicBuckets': True,
                }
            )
            print(f'Bucket {self.bucket_name} created.')
            
            
            
            
#Generates a pre-signed URL for direct browser-to-S3 upload.
#Returns the URL and the S3 object key.
    def pfp_upload_url(self, user_id, content_type='image/jpeg'):
        key = f'profiles/{user_id}/{uuid.uuid4()}.jpg'
        url = self.s3.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': self.pvp_bucket,
                'Key': key,
                'ContentType': content_type,
            },
            ExpiresIn=300
        )
        return {'upload_url': url, 'key': key}



#Generates a pre-signed URL to retrieve a profile picture.
    def get_pfp_url(self, key):
        if not key:
            return None
        url = self.s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': self.pvp_bucket, 'Key': key},
            ExpiresIn=3600
        )
        return url

#Creates the dynamodb table
    def create_dynamodb_table(self):
        try:
            table = self.dynamodb.create_table(
                TableName=self.results_table_name,
                KeySchema=[
                    {'AttributeName': 'api_id', 'KeyType': 'HASH'},
                    {'AttributeName': 'timestamp', 'KeyType': 'RANGE'},
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'api_id', 'AttributeType': 'S'},
                    {'AttributeName': 'timestamp', 'AttributeType': 'S'},
                ],
                BillingMode='PAY_PER_REQUEST'
            )
            table.wait_until_exists()
            print(f'DynamoDB table {self.results_table_name} created.')
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceInUseException':
                print(f'Table {self.results_table_name} already exists.')
            else:
                raise
            
            
#Writes a single API check result to DynamoDB.
    def write_check_result(self, api_id, timestamp, status_code, latency_ms, is_up):
        table = self.dynamodb.Table(self.results_table_name)
        table.put_item(Item={
            'api_id': str(api_id),
            'timestamp': timestamp,
            'status_code': status_code,
            'latency_ms': str(latency_ms),
            'is_up': is_up,
        })


#Retrieves all check results for a given API from DynamoDB.
    def get_check_results(self, api_id):
        table = self.dynamodb.Table(self.results_table_name)
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key('api_id').eq(str(api_id))
        )
        return response.get('Items', [])

    
#Creates the SNS topic for failure alerts.
    def create_sns_topic(self):
        if hasattr(self, "_topic_arn"):
            return self._topic_arn

        response = self.sns.create_topic(Name='apimonitor-alerts')
        self._topic_arn = response['TopicArn']

        print(f"[SNS] Topic ARN: {self._topic_arn}")
        return self._topic_arn


#Subscribes a user email to the SNS alerts topic.
    def subscribe_email_to_topic(self, topic_arn, email):
        subs = self.sns.list_subscriptions_by_topic(TopicArn=topic_arn)

        for sub in subs['Subscriptions']:
            if sub['Endpoint'] == email:
                print(f"[SNS] Already subscribed: {email}")
                print(f"[SNS] Status: {sub['SubscriptionArn']}")
                return sub['SubscriptionArn']

        response = self.sns.subscribe(
            TopicArn=topic_arn,
            Protocol='email',
            Endpoint=email
        )

        print(f"[SNS] Subscription created for {email}")
        print("IMPORTANT: Confirm email subscription in inbox")

        return response['SubscriptionArn']


#Publishes a failure alert to SNS.
    def send_alert(self, topic_arn, api_name, api_url, status_code):
        print(f"[SNS] Sending alert for {api_name}")

        response = self.sns.publish(
            TopicArn=topic_arn,
            Subject=f'APImonitor Alert: {api_name} is down',
            Message=(
                f'Your monitored API has failed.\n\n'
                f'API: {api_name}\n'
                f'URL: {api_url}\n'
                f'Status code: {status_code}\n\n'
                f'APIMonitor will notify you when it recovers.'
            )
         )

        print(f"[SNS] MessageId: {response.get('MessageId')}")
        return response
   
    
        
        
    #Creates the DynamoDB table for storing registered APIs.
    def create_apis_table(self):
        try:
            table = self.dynamodb.create_table(
                TableName='apimonitor-apis',
                KeySchema=[
                    {'AttributeName': 'api_id', 'KeyType': 'HASH'},
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'api_id', 'AttributeType': 'S'},
                ],
                BillingMode='PAY_PER_REQUEST'
            )
            table.wait_until_exists()
            print('apimonitor-apis table created.')
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceInUseException':
                print('apimonitor-apis table already exists.')
            else:
                raise
    #Syncs a registered API to DynamoDB so Lambda can find it.
    def sync_api_to_dynamodb(self, api_id, name, url, interval, user_email):
        table = self.dynamodb.Table('apimonitor-apis')
        table.put_item(Item={
                'api_id': str(api_id),
                'name': name,
                'url': url,
                'interval': str(interval),
                'user_email': user_email,
                'is_active': True,
                'last_alerted_at': None,
            })
    #Removes an API from DynamoDB when deleted.
    def remove_api_from_dynamodb(self, api_id):
        table = self.dynamodb.Table('apimonitor-apis')
        table.delete_item(Key={'api_id': str(api_id)})