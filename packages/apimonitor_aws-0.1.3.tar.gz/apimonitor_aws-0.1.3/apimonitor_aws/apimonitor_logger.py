import logging
import csv
import os
from datetime import datetime, timezone

LOG_FILE = 'apimonitor.log'
CSV_FILE = 'apimonitor_logs.csv'

#system and user log writer
def log_event(event_type, detail):
    try:
        logging.basicConfig(
            filename=LOG_FILE,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        logging.info(f'{event_type} - {detail}')

        file_exists = os.path.isfile(CSV_FILE)
        with open(CSV_FILE, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['timestamp', 'event_type', 'detail'])
            if not file_exists:
                writer.writeheader()
            writer.writerow({
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'event_type': event_type,
                'detail': detail,
            })
    except Exception:
        pass