"""Tests for session store."""
from __future__ import annotations

import json

import pytest

from infinium_cline_connector import session_store


class TestSessionDirName:
    def test_default_dir_name(self):
        """Should use 'infinium-cline-sessions' to avoid collision."""
        assert session_store._SESSION_DIR_NAME == "infinium-cline-sessions"


class TestAppendAndRead:
    def test_append_and_read_events(self, tmp_session_dir):
        session_store.append_event("s1", {"hookName": "TaskStart", "taskId": "s1"}, tmp_session_dir)
        session_store.append_event("s1", {"hookName": "PostToolUse", "taskId": "s1"}, tmp_session_dir)

        events = session_store.read_events("s1", tmp_session_dir)
        assert len(events) == 2
        assert events[0]["hookName"] == "TaskStart"
        assert events[1]["hookName"] == "PostToolUse"

    def test_read_nonexistent_session(self, tmp_session_dir):
        events = session_store.read_events("nonexistent", tmp_session_dir)
        assert events == []

    def test_malformed_lines_skipped(self, tmp_session_dir):
        session_store.append_event("s1", {"hookName": "TaskStart"}, tmp_session_dir)
        # Manually append a malformed line
        from pathlib import Path
        path = Path(tmp_session_dir) / "s1.jsonl"
        with open(path, "a") as f:
            f.write("not json\n")
        session_store.append_event("s1", {"hookName": "TaskComplete"}, tmp_session_dir)

        events = session_store.read_events("s1", tmp_session_dir)
        assert len(events) == 2  # Malformed line skipped


class TestMetadata:
    def test_flush_offset(self, tmp_session_dir):
        assert session_store.read_flush_offset("s1", tmp_session_dir) == 0
        session_store.write_flush_offset("s1", 5, tmp_session_dir)
        assert session_store.read_flush_offset("s1", tmp_session_dir) == 5

    def test_failure_count(self, tmp_session_dir):
        assert session_store.read_failure_count("s1", tmp_session_dir) == 0
        count = session_store.increment_failure_count("s1", tmp_session_dir)
        assert count == 1
        count = session_store.increment_failure_count("s1", tmp_session_dir)
        assert count == 2
        session_store.reset_failure_count("s1", tmp_session_dir)
        assert session_store.read_failure_count("s1", tmp_session_dir) == 0

    def test_origin_cwd(self, tmp_session_dir):
        assert session_store.read_origin_cwd("s1", tmp_session_dir) is None
        session_store.write_origin_cwd("s1", "/tmp/project", tmp_session_dir)
        assert session_store.read_origin_cwd("s1", tmp_session_dir) == "/tmp/project"
        # Second write should be ignored (only write once)
        session_store.write_origin_cwd("s1", "/tmp/other", tmp_session_dir)
        assert session_store.read_origin_cwd("s1", tmp_session_dir) == "/tmp/project"

    def test_token_snapshot(self, tmp_session_dir):
        assert session_store.read_token_snapshot("s1", tmp_session_dir) == {}
        session_store.write_token_snapshot("s1", {"prompt_tokens": 100}, tmp_session_dir)
        assert session_store.read_token_snapshot("s1", tmp_session_dir) == {"prompt_tokens": 100}


class TestSessionLifecycle:
    def test_remove_session(self, tmp_session_dir):
        session_store.append_event("s1", {"hookName": "TaskStart"}, tmp_session_dir)
        session_store.write_flush_offset("s1", 1, tmp_session_dir)

        session_store.remove_session("s1", tmp_session_dir)
        assert session_store.read_events("s1", tmp_session_dir) == []
        assert session_store.read_flush_offset("s1", tmp_session_dir) == 0

    def test_move_to_failed(self, tmp_session_dir):
        session_store.append_event("s1", {"hookName": "TaskStart"}, tmp_session_dir)
        dest = session_store.move_to_failed("s1", tmp_session_dir)
        assert dest is not None
        assert dest.exists()
        assert session_store.read_events("s1", tmp_session_dir) == []

    def test_list_and_count_failed(self, tmp_session_dir):
        session_store.append_event("s1", {"hookName": "TaskStart"}, tmp_session_dir)
        session_store.move_to_failed("s1", tmp_session_dir)
        assert session_store.count_failed(tmp_session_dir) == 1
        files = session_store.list_failed(tmp_session_dir)
        assert len(files) == 1

    def test_list_active_sessions(self, tmp_session_dir):
        session_store.append_event("s1", {"x": 1}, tmp_session_dir)
        session_store.append_event("s2", {"x": 2}, tmp_session_dir)
        active = session_store.list_active_sessions(tmp_session_dir)
        assert set(active) == {"s1", "s2"}
