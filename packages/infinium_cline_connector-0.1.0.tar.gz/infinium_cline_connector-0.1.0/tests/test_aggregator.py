"""Tests for the session aggregator."""
from __future__ import annotations

import pytest

from infinium_cline_connector.aggregator import (
    SessionAggregator,
    _parse_hook_event,
    _summarize_tool_input,
    _summarize_tool_output,
    _truncate,
)
from infinium_cline_connector.config import ConnectorConfig


@pytest.fixture
def config():
    return ConnectorConfig()


@pytest.fixture
def aggregator(config):
    return SessionAggregator(config)


# ---------------------------------------------------------------------------
# Event parsing
# ---------------------------------------------------------------------------


class TestParseHookEvent:
    def test_task_start(self, sample_task_start):
        event = _parse_hook_event(sample_task_start)
        assert event.event_name == "TaskStart"
        assert event.task_id == "cline-test-1"
        assert event.task_text == "Fix the login bug"
        assert event.model_provider == "anthropic"
        assert event.model_slug == "claude-sonnet-4"
        assert event.cline_version == "3.36"
        assert event.workspace_roots == ["/tmp/project"]

    def test_user_prompt_submit(self, sample_user_prompt):
        event = _parse_hook_event(sample_user_prompt)
        assert event.event_name == "UserPromptSubmit"
        assert event.prompt == "Fix the login validation"

    def test_pre_tool_use(self, sample_pre_tool_use):
        event = _parse_hook_event(sample_pre_tool_use)
        assert event.event_name == "PreToolUse"
        assert event.tool_name == "execute_command"
        assert event.tool_parameters == {"command": "npm test"}

    def test_post_tool_use_success(self, sample_post_tool_use_success):
        event = _parse_hook_event(sample_post_tool_use_success)
        assert event.event_name == "PostToolUse"
        assert event.tool_name == "execute_command"
        assert event.tool_success is True
        assert event.tool_result == "All 42 tests passed"
        assert event.tool_duration_ms == 3200

    def test_post_tool_use_failure(self, sample_post_tool_use_failure):
        event = _parse_hook_event(sample_post_tool_use_failure)
        assert event.tool_success is False
        assert event.tool_result == "3 tests failed"
        assert event.tool_duration_ms == 5000

    def test_task_complete(self, sample_task_complete):
        event = _parse_hook_event(sample_task_complete)
        assert event.event_name == "TaskComplete"
        assert event.task_text == "Fix the login bug"

    def test_task_cancel(self, sample_task_cancel):
        event = _parse_hook_event(sample_task_cancel)
        assert event.event_name == "TaskCancel"

    def test_pre_compact(self):
        from tests.conftest import _base_event
        event_dict = _base_event(
            "PreCompact",
            preCompact={"conversationLength": 50, "estimatedTokens": 12000},
        )
        event = _parse_hook_event(event_dict)
        assert event.event_name == "PreCompact"
        assert event.conversation_length == 50
        assert event.estimated_tokens == 12000

    def test_unknown_event(self):
        event = _parse_hook_event({"hookName": "FutureEvent", "taskId": "t-1"})
        assert event.event_name == "FutureEvent"
        assert event.task_id == "t-1"

    def test_missing_fields_defaults(self):
        event = _parse_hook_event({})
        assert event.event_name == "Unknown"
        assert event.task_id == "unknown"
        assert event.model_provider is None


# ---------------------------------------------------------------------------
# Aggregator ingestion
# ---------------------------------------------------------------------------


class TestAggregatorIngest:
    def test_task_start_creates_session(self, aggregator, sample_task_start):
        event, payload = aggregator.ingest(sample_task_start)
        assert aggregator.active_session_count == 1
        assert payload is None  # No flush on TaskStart

    def test_task_complete_triggers_flush(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p
        assert payload is not None
        assert aggregator.active_session_count == 0  # Session removed after flush

    def test_task_cancel_triggers_flush(self, aggregator, sample_task_start, sample_task_cancel):
        aggregator.ingest(sample_task_start)
        _, payload = aggregator.ingest(sample_task_cancel)
        assert payload is not None
        assert aggregator.active_session_count == 0

    def test_no_flush_on_tool_events(self, aggregator, sample_task_start, sample_pre_tool_use):
        aggregator.ingest(sample_task_start)
        _, payload = aggregator.ingest(sample_pre_tool_use)
        assert payload is None
        assert aggregator.active_session_count == 1

    def test_full_session_payload_structure(self, aggregator, full_session_events):
        payload = aggregator.replay_events(full_session_events)
        assert payload is not None
        d = payload.to_dict()

        assert d["name"] == "Fix the login bug"
        assert d["environment"]["framework"] == "cline"
        assert d["environment"]["custom_tags"]["model"] == "anthropic/claude-sonnet-4"
        assert "cline" in d["sections"]["general"]["tags"]
        assert "vscode" in d["sections"]["general"]["tags"]
        assert d["duration"] == 15.0

    def test_tool_use_steps(self, aggregator, full_session_events):
        payload = aggregator.replay_events(full_session_events)
        d = payload.to_dict()
        tool_steps = [s for s in d["steps"] if s["action"] == "tool_use"]
        assert len(tool_steps) == 1
        assert tool_steps[0]["description"] == "Tool: execute_command"
        assert tool_steps[0]["duration_ms"] == 3200

    def test_failed_tool_creates_error(self, aggregator, sample_task_start, sample_post_tool_use_failure, sample_task_complete):
        events = [sample_task_start, sample_post_tool_use_failure, sample_task_complete]
        payload = aggregator.replay_events(events)
        d = payload.to_dict()
        assert d.get("errors") is not None
        assert len(d["errors"]) == 1
        assert d["errors"][0]["error_type"] == "ToolError"

    def test_replay_empty_returns_none(self, aggregator):
        result = aggregator.replay_events([])
        assert result is None


# ---------------------------------------------------------------------------
# PostToolUse matching
# ---------------------------------------------------------------------------


class TestToolMatching:
    def test_pre_post_matching_by_name(self, aggregator, sample_task_start, sample_pre_tool_use, sample_post_tool_use_success, sample_task_complete):
        events = [sample_task_start, sample_pre_tool_use, sample_post_tool_use_success, sample_task_complete]
        payload = aggregator.replay_events(events)
        d = payload.to_dict()
        tool_steps = [s for s in d["steps"] if s["action"] == "tool_use"]
        assert len(tool_steps) == 1
        assert tool_steps[0]["input_preview"] is not None  # From PreToolUse
        assert tool_steps[0]["output_preview"] is not None  # From PostToolUse

    def test_post_without_pre_creates_inline(self, aggregator, sample_task_start, sample_post_tool_use_success, sample_task_complete):
        """PostToolUse without matching PreToolUse should still work."""
        events = [sample_task_start, sample_post_tool_use_success, sample_task_complete]
        payload = aggregator.replay_events(events)
        d = payload.to_dict()
        tool_steps = [s for s in d["steps"] if s["action"] == "tool_use"]
        assert len(tool_steps) == 1


# ---------------------------------------------------------------------------
# Tool summarization
# ---------------------------------------------------------------------------


class TestToolSummarization:
    def test_execute_command_input(self):
        result = _summarize_tool_input("execute_command", {"command": "npm test"}, 200)
        assert result == "npm test"

    def test_read_file_input(self):
        result = _summarize_tool_input("read_file", {"path": "/src/login.py"}, 200)
        assert result == "/src/login.py"

    def test_generic_fallback_input(self):
        result = _summarize_tool_input("future_tool", {"x": 1}, 200)
        assert result is not None

    def test_string_result_output(self):
        result = _summarize_tool_output("execute_command", "All tests passed", 200)
        assert result == "All tests passed"

    def test_bool_result_output(self):
        assert _summarize_tool_output("x", True, 100) == "Succeeded"
        assert _summarize_tool_output("x", False, 100) == "Failed"

    def test_none_result_output(self):
        assert _summarize_tool_output("x", None, 100) is None

    def test_truncate_long_text(self):
        text = "a" * 300
        result = _truncate(text, 100)
        assert len(result) == 100
        assert result.endswith("...")

    def test_truncate_none(self):
        assert _truncate(None, 100) is None


# ---------------------------------------------------------------------------
# Session duration
# ---------------------------------------------------------------------------


class TestDuration:
    def test_session_duration(self, aggregator, full_session_events):
        payload = aggregator.replay_events(full_session_events)
        assert payload.duration == 15.0

    def test_empty_session_duration(self, aggregator, sample_task_start, sample_task_complete):
        events = [sample_task_start, sample_task_complete]
        payload = aggregator.replay_events(events)
        assert payload.duration == 15.0  # 10:00:00 to 10:00:15
