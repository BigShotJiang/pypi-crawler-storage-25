"""Tests for configuration."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from infinium_cline_connector.config import (
    ConnectorConfig,
    load_trace_granularity,
    save_trace_granularity,
    project_config_path,
    _read_config_at,
    _write_config_at,
)


class TestDefaults:
    def test_flush_on_stop_false_by_default(self):
        """Cline has no Stop event, so flush_on_stop should be False."""
        config = ConnectorConfig()
        assert config.flush_on_stop is False
        assert config.flush_on_session_end is True

    def test_session_ttl_30_minutes(self):
        config = ConnectorConfig()
        assert config.session_ttl_seconds == 1800

    def test_webhook_path_cline(self):
        config = ConnectorConfig()
        assert config.webhook_path == "/hooks/cline"


class TestTraceGranularity:
    def test_default_when_no_config(self, tmp_path):
        """load_trace_granularity on missing file should return (False, True)."""
        flush_stop, flush_session = load_trace_granularity(tmp_path)
        assert flush_stop is False
        assert flush_session is True

    def test_save_and_load(self, tmp_path):
        save_trace_granularity(False, True, tmp_path)
        flush_stop, flush_session = load_trace_granularity(tmp_path)
        assert flush_stop is False
        assert flush_session is True

    def test_load_hook_config_defaults(self, tmp_path):
        """load_hook_config should have same defaults as dataclass."""
        config, paused = ConnectorConfig.load_hook_config(cwd=tmp_path)
        assert config.flush_on_stop is False
        assert config.flush_on_session_end is True
        assert paused is False


class TestConfigValidation:
    def test_validate_raises_on_empty(self):
        config = ConnectorConfig()
        with pytest.raises(ValueError, match="Agent ID"):
            config.validate()

    def test_validate_raises_on_missing_secret(self):
        config = ConnectorConfig(agent_id="test-id")
        with pytest.raises(ValueError, match="Agent Secret"):
            config.validate()

    def test_validate_passes_when_configured(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        config.validate()  # Should not raise

    def test_error_message_references_cline(self):
        config = ConnectorConfig()
        try:
            config.validate()
        except ValueError as e:
            assert "infinium-cline" in str(e)


class TestProjectConfig:
    def test_read_write_config(self, tmp_path):
        path = tmp_path / "config.json"
        _write_config_at(path, {"agent_id": "test-123", "base_url": "https://example.com"})
        data = _read_config_at(path)
        assert data["agent_id"] == "test-123"

    def test_read_missing_returns_empty(self, tmp_path):
        data = _read_config_at(tmp_path / "nonexistent.json")
        assert data == {}
