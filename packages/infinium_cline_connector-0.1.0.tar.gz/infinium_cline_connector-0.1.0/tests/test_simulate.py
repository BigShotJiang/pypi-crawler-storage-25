"""Tests for the Cline `simulate` command pipeline (dry-run)."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from infinium_cline_connector.config import ConnectorConfig
from infinium_cline_connector.simulate import (
    SimulationResult,
    _generate_session,
    run_simulation,
)


class TestGenerateSession:
    def test_produces_five_events(self):
        events = _generate_session()
        assert len(events) == 5

    def test_event_names_cover_full_lifecycle(self):
        names = [e["hookName"] for e in _generate_session()]
        assert names == [
            "TaskStart", "UserPromptSubmit", "PreToolUse", "PostToolUse", "TaskComplete",
        ]

    def test_nested_json_shape(self):
        """Cline uses nested sub-objects keyed by hook name."""
        events = _generate_session()
        assert "taskStart" in events[0]
        assert "userPromptSubmit" in events[1]
        assert "preToolUse" in events[2]
        assert "postToolUse" in events[3]
        assert "taskComplete" in events[4]

    def test_shared_task_id(self):
        events = _generate_session()
        tids = {e["taskId"] for e in events}
        assert len(tids) == 1

    def test_model_is_nested_object(self):
        event = _generate_session()[0]
        assert isinstance(event["model"], dict)
        assert "provider" in event["model"]
        assert "slug" in event["model"]


class TestRunSimulation:
    def test_dry_run_skips_send(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        with patch("infinium_cline_connector.simulate.send_trace") as mock_send:
            result = run_simulation(config, dry_run=True)

        mock_send.assert_not_called()
        assert result.trace_id == "dry-run"
        assert result.event_count == 5

    def test_payload_tagged_as_simulated(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        result = run_simulation(config, dry_run=True)
        tags = result.payload.environment.get("custom_tags") or {}
        assert tags.get("simulated") == "true"

    def test_live_run_calls_send_trace(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        with patch("infinium_cline_connector.simulate.send_trace", return_value={"traceId": "cline-trace"}) as mock_send:
            result = run_simulation(config, dry_run=False)

        mock_send.assert_called_once()
        assert result.trace_id == "cline-trace"

    def test_invalid_config_raises(self):
        config = ConnectorConfig(agent_id="", agent_secret="")
        with pytest.raises(ValueError, match="Agent ID"):
            run_simulation(config, dry_run=True)
