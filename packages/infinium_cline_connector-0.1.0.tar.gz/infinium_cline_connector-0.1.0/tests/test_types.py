"""Tests for type definitions."""
from infinium_cline_connector.types import (
    HOOK_EVENTS,
    SESSION_END_EVENTS,
    SESSION_START_EVENTS,
    TURN_END_EVENTS,
    HookEvent,
    InfiniumTracePayload,
    PromptTurn,
    SessionData,
    ToolUseRecord,
)


def test_hook_events_has_all_eight():
    assert len(HOOK_EVENTS) == 8
    assert "TaskStart" in HOOK_EVENTS
    assert "TaskResume" in HOOK_EVENTS
    assert "TaskCancel" in HOOK_EVENTS
    assert "TaskComplete" in HOOK_EVENTS
    assert "PreToolUse" in HOOK_EVENTS
    assert "PostToolUse" in HOOK_EVENTS
    assert "UserPromptSubmit" in HOOK_EVENTS
    assert "PreCompact" in HOOK_EVENTS


def test_session_end_events():
    assert SESSION_END_EVENTS == frozenset({"TaskComplete", "TaskCancel"})


def test_turn_end_events_empty():
    """Cline has no per-turn flush trigger."""
    assert len(TURN_END_EVENTS) == 0


def test_session_start_events():
    assert SESSION_START_EVENTS == frozenset({"TaskStart", "TaskResume"})


def test_hook_event_construction():
    event = HookEvent(
        event_name="PostToolUse",
        task_id="cline-123",
        timestamp="2026-04-03T10:00:00Z",
        tool_name="execute_command",
        tool_success=True,
        tool_duration_ms=500,
        tool_result="ok",
    )
    assert event.event_name == "PostToolUse"
    assert event.task_id == "cline-123"
    assert event.tool_success is True
    assert event.tool_duration_ms == 500


def test_tool_use_record_has_success_field():
    record = ToolUseRecord(tool_name="read_file", success=True, duration_ms=150)
    assert record.success is True
    assert record.duration_ms == 150


def test_session_data_no_subagents():
    """Cline SessionData should not have subagent fields."""
    session = SessionData(session_id="test-1")
    assert not hasattr(session, "total_subagents")


def test_payload_to_dict_omits_none():
    payload = InfiniumTracePayload(
        name="Test", description="desc", current_datetime="2026-04-03T10:00:00Z", duration=1.0,
    )
    d = payload.to_dict()
    assert "steps" not in d
    assert "errors" not in d
    assert "llm_usage" not in d
    assert d["name"] == "Test"


def test_payload_to_dict_includes_values():
    payload = InfiniumTracePayload(
        name="Test", description="desc", current_datetime="2026-04-03T10:00:00Z", duration=1.0,
        steps=[{"step_number": 1, "action": "test"}],
    )
    d = payload.to_dict()
    assert "steps" in d
    assert len(d["steps"]) == 1
