"""Tests for the Cline hook entry point."""
from __future__ import annotations

import json
import sys
from io import StringIO
from unittest.mock import patch, MagicMock

import pytest


class TestHookStdoutResponse:
    """Cline hooks MUST return JSON on stdout."""

    def test_valid_event_returns_json(self, sample_task_start):
        from infinium_cline_connector.hook import main

        stdin = StringIO(json.dumps(sample_task_start))
        stdout = StringIO()

        with patch("sys.stdin", stdin), patch("sys.stdout", stdout), \
             patch("infinium_cline_connector.hook._process_event"):
            main()

        response = json.loads(stdout.getvalue())
        assert response["cancel"] is False
        assert response["contextModification"] is None
        assert response["errorMessage"] is None

    def test_empty_stdin_returns_json(self):
        from infinium_cline_connector.hook import main

        stdin = StringIO("")
        stdout = StringIO()

        with patch("sys.stdin", stdin), patch("sys.stdout", stdout):
            main()

        response = json.loads(stdout.getvalue())
        assert response["cancel"] is False

    def test_invalid_json_returns_json(self):
        from infinium_cline_connector.hook import main

        stdin = StringIO("not json")
        stdout = StringIO()

        with patch("sys.stdin", stdin), patch("sys.stdout", stdout):
            main()

        response = json.loads(stdout.getvalue())
        assert response["cancel"] is False

    def test_non_dict_returns_json(self):
        from infinium_cline_connector.hook import main

        stdin = StringIO("[1, 2, 3]")
        stdout = StringIO()

        with patch("sys.stdin", stdin), patch("sys.stdout", stdout):
            main()

        response = json.loads(stdout.getvalue())
        assert response["cancel"] is False

    def test_processing_error_still_returns_json(self, sample_task_start):
        from infinium_cline_connector.hook import main

        stdin = StringIO(json.dumps(sample_task_start))
        stdout = StringIO()

        with patch("sys.stdin", stdin), patch("sys.stdout", stdout), \
             patch("infinium_cline_connector.hook._process_event", side_effect=RuntimeError("boom")):
            main()

        response = json.loads(stdout.getvalue())
        assert response["cancel"] is False


class TestProcessEvent:
    def test_task_id_mapping(self, sample_task_start, tmp_session_dir):
        """taskId should be used as session_id for session_store."""
        from infinium_cline_connector.hook import _process_event
        from infinium_cline_connector import session_store

        with patch.object(session_store, "get_session_dir", return_value=__import__("pathlib").Path(tmp_session_dir)):
            with patch("infinium_cline_connector.config.ConnectorConfig.load_hook_config") as mock_config:
                mock_cfg = MagicMock()
                mock_cfg.session_dir = tmp_session_dir
                mock_cfg.flush_on_session_end = False
                mock_config.return_value = (mock_cfg, False)

                _process_event(sample_task_start)

        # Event should be stored with taskId as the session key
        events = session_store.read_events("cline-test-1", tmp_session_dir)
        assert len(events) == 1
        assert events[0]["hookName"] == "TaskStart"

    def test_missing_task_id_generates_unique(self, tmp_session_dir):
        """Missing taskId should generate a unique ID, not 'unknown'."""
        from infinium_cline_connector.hook import _process_event

        event = {"hookName": "TaskStart", "timestamp": "2026-04-03T10:00:00Z"}

        with patch("infinium_cline_connector.config.ConnectorConfig.load_hook_config") as mock_config:
            mock_cfg = MagicMock()
            mock_cfg.session_dir = tmp_session_dir
            mock_cfg.flush_on_session_end = False
            mock_config.return_value = (mock_cfg, False)

            _process_event(event)

        # Should NOT use "unknown" as the task_id
        from infinium_cline_connector import session_store
        events = session_store.read_events("unknown", tmp_session_dir)
        assert len(events) == 0  # No events under "unknown"

    def test_timestamp_injection(self):
        """If Cline doesn't provide a timestamp, one should be injected."""
        event = {"hookName": "TaskStart", "taskId": "t-1"}
        from infinium_cline_connector.hook import _process_event

        with patch("infinium_cline_connector.config.ConnectorConfig.load_hook_config") as mock_config, \
             patch("infinium_cline_connector.session_store.append_event") as mock_append, \
             patch("infinium_cline_connector.session_store.read_origin_cwd", return_value=None), \
             patch("infinium_cline_connector.session_store.write_origin_cwd"):
            mock_cfg = MagicMock()
            mock_cfg.session_dir = None
            mock_cfg.flush_on_session_end = False
            mock_config.return_value = (mock_cfg, False)

            _process_event(event)

        stored = mock_append.call_args[0][1]
        assert "timestamp" in stored
        assert stored["timestamp"].endswith("Z")

    def test_paused_skips_flush(self, sample_task_complete, tmp_session_dir):
        """When paused, events are stored but no flush is spawned."""
        from infinium_cline_connector.hook import _process_event

        with patch("infinium_cline_connector.config.ConnectorConfig.load_hook_config") as mock_config, \
             patch("infinium_cline_connector.hook._spawn_flush") as mock_flush:
            mock_cfg = MagicMock()
            mock_cfg.session_dir = tmp_session_dir
            mock_cfg.flush_on_session_end = True
            mock_config.return_value = (mock_cfg, True)  # paused=True

            _process_event(sample_task_complete)

        mock_flush.assert_not_called()

    def test_task_complete_spawns_flush(self, sample_task_complete, tmp_session_dir):
        """TaskComplete should spawn a final flush."""
        from infinium_cline_connector.hook import _process_event

        with patch("infinium_cline_connector.config.ConnectorConfig.load_hook_config") as mock_config, \
             patch("infinium_cline_connector.hook._spawn_flush") as mock_flush, \
             patch("infinium_cline_connector.session_store.read_origin_cwd", return_value="/tmp"):
            mock_cfg = MagicMock()
            mock_cfg.session_dir = tmp_session_dir
            mock_cfg.flush_on_session_end = True
            mock_config.return_value = (mock_cfg, False)

            _process_event(sample_task_complete)

        mock_flush.assert_called_once()
        args = mock_flush.call_args
        assert args[0][0] == "cline-test-1"  # session_id
        assert args[1].get("final") is True or args[0][-1] is True
