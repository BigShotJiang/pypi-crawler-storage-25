"""Shared fixtures for Cline connector tests."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List

import pytest


# ---------------------------------------------------------------------------
# Sample Cline hook events
# ---------------------------------------------------------------------------

def _base_event(hook_name: str, task_id: str = "cline-test-1", **extra) -> Dict[str, Any]:
    """Build a base Cline hook event with common fields."""
    event = {
        "hookName": hook_name,
        "taskId": task_id,
        "timestamp": "2026-04-03T10:00:00Z",
        "clineVersion": "3.36",
        "workspaceRoots": ["/tmp/project"],
        "userId": "user-1",
        "model": {"provider": "anthropic", "slug": "claude-sonnet-4"},
    }
    event.update(extra)
    return event


@pytest.fixture
def sample_task_start() -> Dict[str, Any]:
    return _base_event("TaskStart", taskStart={"task": "Fix the login bug"})


@pytest.fixture
def sample_user_prompt() -> Dict[str, Any]:
    return _base_event(
        "UserPromptSubmit",
        timestamp="2026-04-03T10:00:01Z",
        userPromptSubmit={"prompt": "Fix the login validation"},
    )


@pytest.fixture
def sample_pre_tool_use() -> Dict[str, Any]:
    return _base_event(
        "PreToolUse",
        timestamp="2026-04-03T10:00:02Z",
        preToolUse={"tool": "execute_command", "parameters": {"command": "npm test"}},
    )


@pytest.fixture
def sample_post_tool_use_success() -> Dict[str, Any]:
    return _base_event(
        "PostToolUse",
        timestamp="2026-04-03T10:00:05Z",
        postToolUse={
            "tool": "execute_command",
            "parameters": {"command": "npm test"},
            "result": "All 42 tests passed",
            "success": True,
            "durationMs": 3200,
        },
    )


@pytest.fixture
def sample_post_tool_use_failure() -> Dict[str, Any]:
    return _base_event(
        "PostToolUse",
        timestamp="2026-04-03T10:00:05Z",
        postToolUse={
            "tool": "execute_command",
            "parameters": {"command": "npm test"},
            "result": "3 tests failed",
            "success": False,
            "durationMs": 5000,
        },
    )


@pytest.fixture
def sample_task_complete() -> Dict[str, Any]:
    return _base_event(
        "TaskComplete",
        timestamp="2026-04-03T10:00:15Z",
        taskComplete={"task": "Fix the login bug"},
    )


@pytest.fixture
def sample_task_cancel() -> Dict[str, Any]:
    return _base_event(
        "TaskCancel",
        timestamp="2026-04-03T10:00:10Z",
        taskCancel={"task": "Fix the login bug"},
    )


@pytest.fixture
def full_session_events(
    sample_task_start,
    sample_user_prompt,
    sample_pre_tool_use,
    sample_post_tool_use_success,
    sample_task_complete,
) -> List[Dict[str, Any]]:
    """A complete task session from start to finish."""
    return [
        sample_task_start,
        sample_user_prompt,
        sample_pre_tool_use,
        sample_post_tool_use_success,
        sample_task_complete,
    ]


# ---------------------------------------------------------------------------
# Temp directory fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_session_dir(tmp_path):
    """Provide a temporary session directory."""
    d = tmp_path / "infinium-cline-sessions"
    d.mkdir()
    return str(d)


@pytest.fixture
def tmp_config_dir(tmp_path):
    """Provide a temporary .infinium config directory."""
    d = tmp_path / ".infinium"
    d.mkdir()
    return d


@pytest.fixture
def mock_ui_messages(tmp_path):
    """Create a mock ui_messages.json file and return (task_id, path)."""
    task_id = "cline-mock-task"
    task_dir = tmp_path / "tasks" / task_id
    task_dir.mkdir(parents=True)

    messages = [
        {
            "type": "say",
            "say": "api_req_started",
            "ts": "2026-04-03T10:00:00Z",
            "text": json.dumps({
                "tokensIn": 1500,
                "tokensOut": 500,
                "cacheReads": 200,
                "cacheWrites": 50,
                "cost": 0.05,
                "apiProtocol": "anthropic",
            }),
        },
        {"type": "say", "say": "text", "ts": "2026-04-03T10:00:01Z", "text": "output"},
        {
            "type": "say",
            "say": "api_req_started",
            "ts": "2026-04-03T10:00:05Z",
            "text": json.dumps({
                "tokensIn": 2000,
                "tokensOut": 800,
                "cacheReads": 1500,
                "cacheWrites": 100,
                "cost": 0.08,
                "apiProtocol": "anthropic",
            }),
        },
    ]

    ui_path = task_dir / "ui_messages.json"
    ui_path.write_text(json.dumps(messages), encoding="utf-8")
    return task_id, ui_path
