"""Tests for CLI hook installation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from infinium_cline_connector.cli import _write_hooks, _remove_hooks, _find_existing_hooks


class TestWriteHooks:
    def test_creates_hook_scripts(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        hooks_dir = _write_hooks()
        assert hooks_dir.exists()

        expected_events = [
            "TaskStart", "TaskResume", "TaskCancel", "TaskComplete",
            "PreToolUse", "PostToolUse", "UserPromptSubmit", "PreCompact",
        ]

        for event in expected_events:
            if sys.platform == "win32":
                path = hooks_dir / f"{event}.cmd"
            else:
                path = hooks_dir / event
            assert path.exists(), f"Missing hook script: {path}"
            content = path.read_text(encoding="utf-8")
            assert "infinium_cline_connector.hook" in content

    def test_scripts_are_in_clinerules(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        hooks_dir = _write_hooks()
        assert hooks_dir == tmp_path / ".clinerules" / "hooks"

    def test_idempotent_rewrite(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _write_hooks()
        _write_hooks()  # Should not error

        if sys.platform == "win32":
            path = tmp_path / ".clinerules" / "hooks" / "TaskStart.cmd"
        else:
            path = tmp_path / ".clinerules" / "hooks" / "TaskStart"
        assert path.exists()

    @pytest.mark.skipif(sys.platform == "win32", reason="Unix permissions")
    def test_scripts_executable_on_unix(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        hooks_dir = _write_hooks()
        for path in hooks_dir.iterdir():
            assert path.stat().st_mode & 0o111  # executable bit set


class TestRemoveHooks:
    def test_removes_infinium_scripts(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _write_hooks()
        removed = _remove_hooks()
        assert len(removed) > 0
        # All Infinium scripts should be gone
        hooks_dir = tmp_path / ".clinerules" / "hooks"
        for path in removed:
            assert not path.exists()

    def test_preserves_non_infinium_hooks(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        hooks_dir = tmp_path / ".clinerules" / "hooks"
        hooks_dir.mkdir(parents=True)
        # Create a non-infinium hook
        other_hook = hooks_dir / "TaskStart"
        other_hook.write_text("#!/bin/sh\necho other")
        if sys.platform != "win32":
            other_hook.chmod(0o755)

        # Now write infinium hooks (will overwrite TaskStart)
        _write_hooks()
        _remove_hooks()

        # The non-infinium hook was overwritten, so it's gone
        # But if we had a separate event...
        custom = hooks_dir / "CustomHook"
        custom.write_text("#!/bin/sh\necho custom")
        _remove_hooks()
        assert custom.exists()  # Non-infinium hooks preserved


class TestFindExistingHooks:
    def test_finds_hooks(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _write_hooks()
        result = _find_existing_hooks()
        assert result is not None
        assert ".clinerules" in result

    def test_none_when_no_hooks(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = _find_existing_hooks()
        assert result is None
