"""Tests for the Cline transcript (ui_messages.json) parser."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

import infinium_cline_connector.transcript as transcript_mod
from infinium_cline_connector.transcript import TokenUsage, read_token_usage


@pytest.fixture
def _patch_find(mock_ui_messages, monkeypatch):
    """Patch _find_ui_messages to use the mock fixture."""
    task_id, ui_path = mock_ui_messages

    def _patched(tid):
        if tid == task_id:
            return ui_path
        return None

    monkeypatch.setattr(transcript_mod, "_find_ui_messages", _patched)
    return task_id


class TestReadTokenUsage:
    def test_reads_tokens_from_mock(self, _patch_find):
        usage = read_token_usage(_patch_find, model="anthropic/claude-sonnet-4")
        assert usage is not None
        assert usage.input_tokens == 3500  # 1500 + 2000
        assert usage.output_tokens == 1300  # 500 + 800
        assert usage.cache_reads == 1700  # 200 + 1500
        assert usage.cache_writes == 150  # 50 + 100
        assert abs(usage.total_cost - 0.13) < 0.001
        assert usage.api_calls == 2
        assert usage.model == "anthropic/claude-sonnet-4"

    def test_per_call_tracking(self, _patch_find):
        usage = read_token_usage(_patch_find)
        assert len(usage._per_call) == 2
        assert usage._per_call[0]["input_tokens"] == 1500
        assert usage._per_call[1]["input_tokens"] == 2000

    def test_missing_task_returns_none(self):
        usage = read_token_usage("nonexistent-task-id")
        assert usage is None

    def test_empty_messages_returns_none(self, tmp_path, monkeypatch):
        task_id = "empty-task"
        task_dir = tmp_path / "tasks" / task_id
        task_dir.mkdir(parents=True)
        (task_dir / "ui_messages.json").write_text("[]")
        monkeypatch.setattr(transcript_mod, "_find_ui_messages", lambda tid: task_dir / "ui_messages.json")

        usage = read_token_usage(task_id)
        assert usage is None

    def test_no_api_req_started_returns_none(self, tmp_path, monkeypatch):
        task_id = "no-api-task"
        task_dir = tmp_path / "tasks" / task_id
        task_dir.mkdir(parents=True)
        msgs = [{"type": "say", "say": "text", "text": "hello"}]
        (task_dir / "ui_messages.json").write_text(json.dumps(msgs))
        monkeypatch.setattr(transcript_mod, "_find_ui_messages", lambda tid: task_dir / "ui_messages.json")

        usage = read_token_usage(task_id)
        assert usage is None

    def test_malformed_inner_json_skipped(self, tmp_path, monkeypatch):
        task_id = "bad-json-task"
        task_dir = tmp_path / "tasks" / task_id
        task_dir.mkdir(parents=True)
        msgs = [
            {"type": "say", "say": "api_req_started", "text": "not-valid-json"},
            {"type": "say", "say": "api_req_started", "text": json.dumps({"tokensIn": 100, "tokensOut": 50, "cost": 0.01})},
        ]
        (task_dir / "ui_messages.json").write_text(json.dumps(msgs))
        monkeypatch.setattr(transcript_mod, "_find_ui_messages", lambda tid: task_dir / "ui_messages.json")

        usage = read_token_usage(task_id)
        assert usage is not None
        assert usage.api_calls == 1  # Only the valid entry
        assert usage.input_tokens == 100

    def test_missing_fields_default_to_zero(self, tmp_path, monkeypatch):
        task_id = "sparse-task"
        task_dir = tmp_path / "tasks" / task_id
        task_dir.mkdir(parents=True)
        msgs = [{"type": "say", "say": "api_req_started", "text": json.dumps({"tokensIn": 100})}]
        (task_dir / "ui_messages.json").write_text(json.dumps(msgs))
        monkeypatch.setattr(transcript_mod, "_find_ui_messages", lambda tid: task_dir / "ui_messages.json")

        usage = read_token_usage(task_id)
        assert usage.input_tokens == 100
        assert usage.output_tokens == 0
        assert usage.cache_reads == 0
        assert usage.total_cost == 0.0
