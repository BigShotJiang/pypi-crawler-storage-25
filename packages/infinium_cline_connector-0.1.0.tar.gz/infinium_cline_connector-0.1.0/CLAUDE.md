# CLAUDE.md

Infinium Cline Connector — bridges Cline (VS Code extension) hooks to the Infinium agent tracing API.

## Connector Compatibility Monitor

A scheduled task (`weekly-connector-monitor`) runs every Wednesday at 9 AM to check whether upstream Cline changes could break this connector. When making fixes from that monitor, follow these rules.

### Upstream Surface This Connector Depends On

| Surface | What we depend on | Connector file |
|---------|---|---|
| **Hook activation** | Cline v3.36+ with hooks enabled (Settings > Cline > Features > Enable Hooks) | README, `cli.py` |
| **Hook events (8)** | TaskStart, TaskResume, TaskCancel, TaskComplete, PreToolUse, PostToolUse, UserPromptSubmit, PreCompact | `types.py` |
| **Hook event JSON (NESTED)** | Top-level: `hookName` (not hook_event_name), `taskId` (not session_id), `timestamp`, `clineVersion`, `workspaceRoots` (array, not cwd), `userId`, `model` (nested: `{provider, slug}`). Event data in nested keys: `taskStart.task`, `preToolUse.tool`/`.parameters`, `postToolUse.tool`/`.parameters`/`.result`/`.success`/`.durationMs`, `userPromptSubmit.prompt`, `preCompact.conversationLength`/`.estimatedTokens` | `types.py`, `aggregator.py`, `session_store.py` |
| **Stdout response (REQUIRED)** | Cline expects JSON response on stdout: `{"cancel": false, "contextModification": null, "errorMessage": null}` — failure to respond blocks Cline | `hook.py` |
| **Token usage file** | `ui_messages.json` at `globalStorage/saoudrizwan.claude-dev/tasks/<taskId>/` — entries with `say: "api_req_started"` containing double-JSON-encoded `text` with `tokensIn`, `tokensOut` | `transcript.py` |
| **Extension ID** | Hardcoded `saoudrizwan.claude-dev` in storage path | `transcript.py` |
| **Tool names** | execute_command, shell, read_file, readFile, write_to_file, writeFile, replace_in_file, editFile, search_files, grep, list_files, browser_action | `aggregator.py` |
| **Session end events** | TaskComplete, TaskCancel (NOT Stop — Cline uses different lifecycle) | `hook.py`, `types.py` |

### Key Cline Differences from Other Connectors

- **Nested JSON** — event data is in sub-objects keyed by event type, not flat fields
- **Field name mapping** — `hookName` -> `hook_event_name`, `taskId` -> `session_id`, `workspaceRoots[0]` -> `cwd`
- **Model is an object** — `{provider: "anthropic", slug: "claude-sonnet-4"}`, not a flat string
- **Stdout response required** — must always write JSON to stdout or Cline hangs
- **No Stop event** — flush triggers on TaskComplete/TaskCancel instead

### Branching and PR Conventions

- Branch name: `fix/upstream-compat-YYYY-MM-DD`
- PR title format: `fix(cline): adapt to Cline v<version> changes`
- PR body must include: what changed upstream, what broke or would break, what was updated
- One PR per upstream tool

### Testing Before PR

```bash
pip install -e ".[dev]"
pytest tests/ -v --no-cov
```

### What to Change (and What Not To)

**Change** when Cline updates its hook system:
- `types.py` — HOOK_EVENTS frozenset, HookEvent dataclass, SESSION_END_EVENTS
- `aggregator.py` — nested JSON parsing in `_parse_hook_event()`, tool name mapping, model field extraction
- `hook.py` — stdout response format, flush trigger events
- `session_store.py` — field normalization (hookName->hook_event_name, taskId->session_id)
- `transcript.py` — extension ID, storage paths per platform, ui_messages.json schema
- `tests/conftest.py` — test fixtures must match Cline's JSON schema
- `tests/` — update all event mocks

**Do not change:**
- `sdk_bridge.py` — talks to Infinium API, not Cline
- `config.py` — credential management is connector-internal
- `error_log.py`, `history.py`, `jsonl_log.py` — internal utilities

## Commands

```bash
pip install -e .                    # Install (dev)
infinium-cline init                 # Interactive setup wizard
infinium-cline test                 # Verify connection works
infinium-cline status               # Show current config + tracing state
infinium-cline pause                # Temporarily stop tracing
infinium-cline resume               # Resume tracing
infinium-cline history              # View recent traces
infinium-cline errors               # View connector errors
infinium-cline retry                # Resend failed traces
```

If `infinium-cline` is not on PATH, use `python -m infinium_cline_connector <command>`.

## Architecture

```
infinium_cline_connector/
  __init__.py          # Package exports, __version__ (single source of truth)
  __main__.py          # python -m entry point -> CLI
  cli.py               # Click CLI (init, test, status, pause, resume, etc.)
  config.py            # Credentials: project (.infinium/) -> env vars
  hook.py              # Command hook entry point (stdin -> stdout response -> JSONL -> flush)
  flush_worker.py      # Background worker for trace flush (non-blocking)
  session_store.py     # JSONL session file I/O + field normalization
  aggregator.py        # Session event aggregation -> trace payloads (nested JSON parsing)
  sdk_bridge.py        # InfiniumTracePayload -> SDK TaskData -> send
  types.py             # Data models (HookEvent, SessionData, etc.)
  transcript.py        # Read token usage from Cline's ui_messages.json
  server.py            # Optional HTTP mode
  error_log.py         # Persistent error log
  history.py           # Local trace history
  jsonl_log.py         # JSONL file utilities
```

## Data Flow

```
Cline (VS Code) -> command hook -> python -m infinium_cline_connector.hook
                                     | reads nested JSON from stdin
                                     | IMMEDIATELY writes stdout response (required)
                                     | normalizes fields (hookName->hook_event_name, etc.)
                                     | checks: paused? -> skip
                                     +- append to {tmpdir}/infinium-cline-sessions/{taskId}.jsonl
                                     +- on TaskComplete/TaskCancel:
                                          spawn detached background worker
                                          -> read .jsonl -> SessionAggregator
                                          -> read ui_messages.json for token usage
                                          -> sdk_bridge.send_trace()
                                          -> POST /agents/{agent_id}/trace
```
