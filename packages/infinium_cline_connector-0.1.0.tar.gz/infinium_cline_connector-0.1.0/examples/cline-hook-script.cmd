@echo off
rem Windows equivalent of the Cline hook script. `infinium-cline init`
rem writes one of these per event into .clinerules/hooks/ automatically.
python -m infinium_cline_connector.hook
