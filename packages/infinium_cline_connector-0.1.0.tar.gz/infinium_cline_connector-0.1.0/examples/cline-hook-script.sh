#!/bin/sh
# Cline invokes hook scripts from .clinerules/hooks/<EventName>[.cmd]
# This shows the portable Unix form. `infinium-cline init` writes these
# for you — this file is here only as a reference.
python -m infinium_cline_connector.hook
