"""
Infinium Cline Connector — bridge between Cline (VS Code extension) hooks and Infinium agent tracing.
"""

__version__ = "0.1.0"

from .config import ConnectorConfig
from .aggregator import SessionAggregator

__all__ = ["ConnectorConfig", "SessionAggregator", "__version__"]
