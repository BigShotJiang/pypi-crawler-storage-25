"""
CLI entry point for the Infinium Cline Connector.
"""
from __future__ import annotations

import json
import logging
import re
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__

_UUID_RE = re.compile(
    r"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$",
    re.IGNORECASE,
)

_DEFAULT_EVENTS = [
    "TaskStart",
    "TaskResume",
    "TaskCancel",
    "TaskComplete",
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "PreCompact",
]


@click.group()
@click.version_option(version=__version__, prog_name="infinium-cline-connector")
def main() -> None:
    """Infinium Cline Connector — bridge Cline to Infinium agent tracing.

    \b
    Shortcut: If 'infinium-cline' is not on your PATH, use:
      python -m infinium_cline_connector <command>
    """
    pass


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@main.command()
@click.option("--agent-id", default=None, help="Infinium Agent ID (non-interactive)")
@click.option("--agent-secret", default=None, help="Infinium Agent Secret (non-interactive)")
@click.option("--base-url", default=None, help="Infinium API base URL")
@click.option("--no-interactive", is_flag=True, help="Skip prompts, use flags only")
def init(
    agent_id: Optional[str],
    agent_secret: Optional[str],
    base_url: Optional[str],
    no_interactive: bool,
) -> None:
    """Set up Infinium tracing for Cline (project-level)."""
    from .config import (
        get_active_config_source,
        has_existing_config,
        load_credentials,
        save_credentials,
        save_trace_granularity,
    )

    if no_interactive:
        _init_non_interactive(agent_id, agent_secret, base_url)
        return

    click.echo()
    click.echo("  Infinium Cline Connector")
    click.echo("  ========================")
    click.echo()

    if has_existing_config():
        existing_id, _, existing_url = load_credentials()
        source = get_active_config_source()
        source_label = {"project": "project", "env": "environment variables"}.get(source, source)
        click.echo("  Existing configuration found:")
        click.echo(f"    Agent ID:  {existing_id[:12]}...")
        click.echo(f"    API URL:   {existing_url}")
        click.echo(f"    Source:    {source_label}")

        hooks_path = _find_existing_hooks()
        if hooks_path:
            click.echo(f"    Hooks:     {hooks_path}")
        click.echo()

        choice = click.prompt(
            "  What would you like to do?\n"
            "    [1] Update credentials\n"
            "    [2] Reconfigure hooks\n"
            "    [3] Full re-setup\n"
            "    [4] Cancel\n\n"
            "  Choice",
            type=click.IntRange(1, 4),
            default=4,
        )

        if choice == 1:
            _update_credentials_interactive(existing_id)
            return
        elif choice == 2:
            _setup_hooks_interactive()
            return
        elif choice == 3:
            pass
        else:
            click.echo("\n  Cancelled.")
            return

    click.echo()
    click.echo("  Tracing will be configured for this project only.")
    click.echo()

    if agent_id:
        entered_id = agent_id
    else:
        entered_id = click.prompt("  Enter your Infinium Agent ID")

    entered_id = entered_id.strip()
    if not _UUID_RE.match(entered_id):
        click.echo(f"\n  Warning: '{entered_id}' doesn't look like a UUID. Proceeding anyway.\n")

    if agent_secret:
        entered_secret = agent_secret
    else:
        entered_secret = click.prompt("  Enter your Infinium Agent Secret", hide_input=True)

    entered_secret = entered_secret.strip()
    if not entered_secret:
        click.echo("\n  Error: Agent Secret cannot be empty.", err=True)
        sys.exit(1)

    url = base_url or "https://platform.i42m.ai/api/v1"
    click.echo()

    path, keyring_ok = save_credentials(entered_id, entered_secret, url)
    click.echo(f"  Config saved to:    {path}")
    if keyring_ok:
        click.echo("  Secret stored in:   OS keyring (secure)")
    else:
        click.echo(
            "  Warning: Could not store secret in OS keyring.\n"
            "  Set INFINIUM_AGENT_SECRET as an environment variable instead."
        )

    # Cline only supports per-session flush (no Stop event for per-turn)
    save_trace_granularity(False, True)

    hooks_path = _write_hooks()
    click.echo(f"  Hooks written to:   {hooks_path}")

    click.echo()
    click.echo("  IMPORTANT: Enable hooks in Cline:")
    click.echo("    VS Code -> Settings -> Extensions -> Cline -> Features -> Enable Hooks")
    click.echo()
    click.echo("  Hooks will not fire until this setting is enabled.")

    gitignore_path = Path.cwd() / ".gitignore"
    needs_gitignore = True
    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
        if ".infinium/" in content or ".infinium" in content:
            needs_gitignore = False
    if needs_gitignore:
        click.echo()
        click.echo("  Tip: Add .infinium/ to your .gitignore to keep config out of git.")

    click.echo()
    click.echo("  Setup complete! Cline will now send traces to Infinium.")
    click.echo()
    _print_quick_reference()


def _init_non_interactive(
    agent_id: Optional[str],
    agent_secret: Optional[str],
    base_url: Optional[str],
) -> None:
    from .config import save_credentials, save_trace_granularity

    if not agent_id or not agent_secret:
        click.echo("Error: --agent-id and --agent-secret are required with --no-interactive", err=True)
        sys.exit(1)

    url = base_url or "https://platform.i42m.ai/api/v1"
    path, keyring_ok = save_credentials(agent_id, agent_secret, url)
    save_trace_granularity(False, True)
    hooks_path = _write_hooks()

    click.echo(f"Config saved to: {path}")
    click.echo(f"Hooks written to: {hooks_path}")
    if not keyring_ok:
        click.echo("Warning: Keyring unavailable. Set INFINIUM_AGENT_SECRET env var.")
    click.echo("Remember to enable hooks in Cline: VS Code Settings -> Cline -> Features -> Enable Hooks")


@main.command(hidden=True)
@click.pass_context
def setup(ctx: click.Context) -> None:
    """Alias for init."""
    ctx.invoke(init)


# ---------------------------------------------------------------------------
# update-credentials
# ---------------------------------------------------------------------------


@main.command("update-credentials")
@click.option("--agent-id", default=None, help="New Agent ID")
@click.option("--agent-secret", default=None, help="New Agent Secret")
def update_credentials(agent_id: Optional[str], agent_secret: Optional[str]) -> None:
    """Update your Infinium credentials."""
    from .config import require_project_config

    require_project_config()
    _update_credentials_interactive(override_id=agent_id, override_secret=agent_secret)


def _update_credentials_interactive(
    existing_id: Optional[str] = None,
    override_id: Optional[str] = None,
    override_secret: Optional[str] = None,
) -> None:
    from .config import load_credentials, save_credentials

    current_id, _, current_url = load_credentials()
    display_id = existing_id or current_id
    click.echo()

    if override_id and override_secret:
        new_id = override_id
        new_secret = override_secret
    else:
        if display_id:
            click.echo(f"  Current Agent ID: {display_id[:12]}...")
            change_id = click.confirm("  Change Agent ID?", default=False)
            new_id = click.prompt("  Enter new Agent ID").strip() if change_id else display_id
        else:
            new_id = click.prompt("  Enter your Infinium Agent ID").strip()

        new_secret = override_secret or click.prompt("  Enter your Agent Secret", hide_input=True).strip()

    if not new_secret:
        click.echo("\n  Error: Agent Secret cannot be empty.", err=True)
        return

    path, keyring_ok = save_credentials(new_id, new_secret, current_url)
    click.echo()
    click.echo(f"  Credentials updated! (saved to {path})")
    if keyring_ok:
        click.echo("  Secret stored in OS keyring.")
    else:
        click.echo("  Warning: Could not store secret in OS keyring.\n  Set INFINIUM_AGENT_SECRET as an environment variable.")
    click.echo()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@main.command()
def status() -> None:
    """Show current configuration."""
    from .config import (
        get_active_config_source, is_paused, load_credentials,
        load_trace_granularity, project_config_path, require_project_config,
    )

    require_project_config()

    agent_id, agent_secret, base_url = load_credentials()
    paused = is_paused()
    source = get_active_config_source()

    click.echo()
    click.echo("  Infinium Cline Connector Status")
    click.echo("  --------------------------------")

    click.echo(f"  Tracing:      {'PAUSED' if paused else 'active'}")

    if agent_id:
        click.echo(f"  Agent ID:     {agent_id[:12]}...")
    else:
        click.echo("  Agent ID:     NOT CONFIGURED — run 'infinium-cline init'")

    click.echo(f"  Secret:       {'configured' if agent_secret else 'NOT FOUND'}")
    click.echo(f"  API URL:      {base_url}")

    flush_on_stop, flush_on_session_end = load_trace_granularity()
    if flush_on_session_end:
        granularity_label = "per-session (on TaskComplete/TaskCancel)"
    else:
        granularity_label = "disabled"
    click.echo(f"  Granularity:  {granularity_label}")

    if source == "project":
        resolved = project_config_path()
        source_label = f"project ({resolved})"
    elif source == "env":
        source_label = "environment variables"
    else:
        source_label = source or "(not found)"
    click.echo(f"  Config from:  {source_label}")

    from . import session_store
    failed_count = session_store.count_failed()
    if failed_count:
        click.echo(f"  Pending retry: {failed_count} failed trace(s)")

    from . import error_log
    last_err = error_log.last_error()
    if last_err:
        err_time = last_err.get("timestamp", "")[:16].replace("T", " ")
        err_msg = last_err.get("message", "")[:60]
        click.echo(f"  Last error:    {err_time} — {err_msg}")

    hooks_path = _find_existing_hooks()
    if hooks_path:
        click.echo(f"  Hooks:        {hooks_path}")

    click.echo()


# ---------------------------------------------------------------------------
# pause / resume
# ---------------------------------------------------------------------------


@main.command()
def pause() -> None:
    """Pause tracing — hooks stay installed but traces are not sent."""
    from .config import is_paused, require_project_config, set_paused

    require_project_config()
    if is_paused():
        click.echo("\n  Tracing is already paused.\n")
        return
    set_paused(True)
    click.echo("\n  Tracing paused. Run 'infinium-cline resume' to resume.\n")


@main.command()
def resume() -> None:
    """Resume tracing after a pause."""
    from .config import is_paused, require_project_config, set_paused

    require_project_config()
    if not is_paused():
        click.echo("\n  Tracing is already active.\n")
        return
    set_paused(False)
    click.echo("\n  Tracing resumed!\n")


# ---------------------------------------------------------------------------
# uninstall
# ---------------------------------------------------------------------------


@main.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def uninstall(yes: bool) -> None:
    """Remove the Infinium connector completely."""
    from .config import delete_config, require_project_config

    require_project_config()

    click.echo()
    click.echo("  This will remove:")
    click.echo("    - Infinium hooks from .clinerules/hooks/")
    click.echo("    - Credentials (config file + keyring secret)")
    click.echo()

    if not yes and not click.confirm("  Are you sure?", default=False):
        click.echo("\n  Cancelled.\n")
        return

    removed_hooks = _remove_hooks()
    delete_config()

    click.echo()
    if removed_hooks:
        for p in removed_hooks:
            click.echo(f"  Hooks removed: {p}")
    else:
        click.echo("  No hooks found to remove.")
    click.echo("  Credentials removed.")
    click.echo()
    click.echo("  Reinstall anytime with: pip install infinium-cline-connector && infinium-cline init")
    click.echo()


# ---------------------------------------------------------------------------
# test
# ---------------------------------------------------------------------------


@main.command("test")
@click.option("--verbose", "-v", is_flag=True, help="Show the full payload")
def test_connection(verbose: bool) -> None:
    """Send a test trace to verify your setup works."""
    from .config import ConnectorConfig, require_project_config
    from .types import InfiniumTracePayload
    from . import sdk_bridge
    from infinium import get_current_iso_datetime

    require_project_config()
    config = ConnectorConfig.load()
    try:
        config.validate()
    except ValueError as e:
        click.echo(f"\n  Configuration error: {e}", err=True)
        sys.exit(1)

    click.echo()
    click.echo(f"  Agent ID:  {config.agent_id[:12]}...")
    click.echo(f"  API URL:   {config.base_url}")
    click.echo("  Sending test trace...")

    payload = InfiniumTracePayload(
        name="Connection Test",
        description="Test trace from Infinium Cline Connector",
        current_datetime=get_current_iso_datetime(),
        duration=0.1,
        input_summary="Test ping",
        output_summary="Connection verified",
        steps=[{"step_number": 1, "action": "test_ping", "description": "Verify connectivity"}],
    )

    if verbose:
        click.echo()
        click.echo("  Payload:")
        click.echo(json.dumps(payload.to_dict(), indent=2))
        click.echo()

    try:
        result = sdk_bridge.send_trace(config, payload)
        trace_id = result.get("traceId", result.get("id", "unknown"))
        click.echo(f"\n  Connection verified! Trace ID: {trace_id}")
        click.echo("  Your setup is working correctly.\n")
    except Exception as e:
        click.echo(f"\n  Connection failed: {e}", err=True)
        click.echo("\n  Troubleshooting:")
        click.echo("    - Check your Agent ID and Secret are correct")
        click.echo("    - Verify your API key is active in Infinium")
        click.echo("    - Check network connectivity\n")
        sys.exit(1)


# ---------------------------------------------------------------------------
# simulate — run a full end-to-end session without Cline
# ---------------------------------------------------------------------------


@main.command("simulate", hidden=True)
@click.option("--count", "-n", default=1, type=int, help="Number of sessions to simulate")
@click.option("--task", default=None, help="Override the simulated task text")
@click.option("--command", default=None, help="Override the simulated shell command")
@click.option("--model-provider", default=None, help="Override simulated model provider (e.g. anthropic, openai)")
@click.option("--model-slug", default=None, help="Override simulated model slug (e.g. claude-sonnet-4, gpt-5)")
@click.option("--dry-run", is_flag=True, help="Build payload but don't send to Infinium")
@click.option("--verbose", "-v", is_flag=True, help="Show the full payload")
def simulate(
    count: int,
    task: Optional[str],
    command: Optional[str],
    model_provider: Optional[str],
    model_slug: Optional[str],
    dry_run: bool,
    verbose: bool,
) -> None:
    """(Internal) Simulate a Cline task end-to-end for smoke testing.

    Hidden from the public CLI surface — used by the connector maintainers
    to exercise the full hook -> aggregator -> SDK path without installing
    the Cline VS Code extension.
    """
    from .config import ConnectorConfig, require_project_config
    from .simulate import run_simulation

    require_project_config()
    config = ConnectorConfig.load()

    try:
        config.validate()
    except ValueError as e:
        click.echo(f"\n  Configuration error: {e}", err=True)
        sys.exit(1)

    click.echo()
    click.echo(f"  Agent ID:  {config.agent_id[:12]}...")
    click.echo(f"  API URL:   {config.base_url}")
    mode = "dry-run" if dry_run else "live"
    click.echo(f"  Mode:      {mode}")
    click.echo(f"  Sessions:  {count}")
    click.echo()

    kwargs: dict = {"dry_run": dry_run}
    if task:
        kwargs["task"] = task
    if command:
        kwargs["command"] = command
    if model_provider:
        kwargs["model_provider"] = model_provider
    if model_slug:
        kwargs["model_slug"] = model_slug

    sent = 0
    failed = 0
    for i in range(1, count + 1):
        try:
            result = run_simulation(config, **kwargs)
            click.echo(
                f"  [{i}/{count}] Task {result.session_id}: "
                f"{result.event_count} events -> trace {result.trace_id}"
            )
            if verbose:
                click.echo(json.dumps(result.payload.to_dict(), indent=2, default=str))
            sent += 1
        except Exception as e:
            click.echo(f"  [{i}/{count}] Failed: {e}", err=True)
            failed += 1

    click.echo()
    if failed == 0:
        click.echo(f"  All {sent} simulated task(s) traced successfully.")
    else:
        click.echo(f"  {sent} succeeded, {failed} failed.", err=True)
    click.echo()


# ---------------------------------------------------------------------------
# retry
# ---------------------------------------------------------------------------


@main.command()
@click.option("--dry-run", is_flag=True, help="Show what would be retried without sending")
def retry(dry_run: bool) -> None:
    """Retry sending failed traces."""
    from . import session_store
    from .aggregator import SessionAggregator
    from . import sdk_bridge, history
    from .config import ConnectorConfig, require_project_config

    require_project_config()
    config = ConnectorConfig.load()
    try:
        config.validate()
    except ValueError as e:
        click.echo(f"\n  Configuration error: {e}", err=True)
        sys.exit(1)

    failed_files = session_store.list_failed(config.session_dir)
    if not failed_files:
        click.echo("\n  No failed traces to retry.\n")
        return

    click.echo(f"\n  Found {len(failed_files)} failed trace(s).")

    if dry_run:
        click.echo("  (dry run)\n")
        for f in failed_files:
            events = session_store.read_failed_events(f)
            click.echo(f"    {f.name}  ({len(events)} events, task: {f.stem[:12]}...)")
        click.echo()
        return

    click.echo()
    succeeded = failed = 0

    for f in failed_files:
        events = session_store.read_failed_events(f)
        if not events:
            click.echo(f"    {f.stem[:12]}... — empty, removing")
            session_store.remove_failed(f)
            continue

        aggregator = SessionAggregator(config)
        payload = aggregator.replay_events(events)

        if payload is None:
            click.echo(f"    {f.stem[:12]}... — skipped (no payload)")
            session_store.remove_failed(f)
            continue

        from .flush_worker import _compute_duration_from_events, _fit_payload
        payload.duration = _compute_duration_from_events(events)
        payload = _fit_payload(payload)

        try:
            result = sdk_bridge.send_trace(config, payload)
            trace_id = result.get("traceId", result.get("id", "unknown"))
            click.echo(f"    {f.stem[:12]}... — sent (trace: {trace_id})")
            session_store.remove_failed(f)
            succeeded += 1
            try:
                history.append_entry({
                    "timestamp": payload.current_datetime,
                    "session_id": f.stem[:12],
                    "trace_id": str(trace_id),
                    "name": payload.name,
                    "status": "retried",
                })
            except Exception:
                pass
        except Exception as e:
            click.echo(f"    {f.stem[:12]}... — failed ({e})")
            failed += 1

    click.echo(f"\n  Retried {succeeded + failed}: {succeeded} succeeded, {failed} failed.\n")


# ---------------------------------------------------------------------------
# history / errors
# ---------------------------------------------------------------------------


@main.command()
@click.option("--limit", "-n", default=10, type=int)
@click.option("--json", "as_json", is_flag=True)
@click.option("--clear", is_flag=True)
def history(limit: int, as_json: bool, clear: bool) -> None:
    """View local trace history."""
    from . import history as hist

    if clear:
        click.echo(f"\n  {'History cleared.' if hist.clear_history() else 'No history to clear.'}\n")
        return

    entries = hist.read_entries(limit)
    if not entries:
        click.echo("\n  No trace history yet. Traces appear after your next Cline task.\n")
        return

    if as_json:
        for e in entries:
            click.echo(json.dumps(e))
        return

    click.echo(f"\n  Last {len(entries)} trace(s):\n")
    click.echo(f"  {'Time':<20} {'Steps':>5} {'Tools':>5} {'Errors':>6} {'Status':<8} {'Trace ID'}")
    click.echo(f"  {'-'*20} {'-'*5} {'-'*5} {'-'*6} {'-'*8} {'-'*12}")

    for e in entries:
        ts = e.get("timestamp", "")[:16].replace("T", " ")
        click.echo(
            f"  {ts:<20} {e.get('turns', 0):>5} {e.get('tool_calls', 0):>5} "
            f"{e.get('errors', 0):>6} {e.get('status', '?'):<8} "
            f"{(e.get('trace_id') or '—')[:15]}"
        )
    click.echo()


@main.command()
@click.option("--limit", "-n", default=20, type=int)
@click.option("--json", "as_json", is_flag=True)
@click.option("--clear", is_flag=True)
def errors(limit: int, as_json: bool, clear: bool) -> None:
    """View recent connector errors."""
    from . import error_log

    if clear:
        click.echo(f"\n  {'Error log cleared.' if error_log.clear_errors() else 'No error log to clear.'}\n")
        return

    entries = error_log.read_errors(limit)
    if not entries:
        click.echo("\n  No errors recorded.\n")
        return

    if as_json:
        for e in entries:
            click.echo(json.dumps(e))
        return

    click.echo(f"\n  Last {len(entries)} error(s):\n")
    click.echo(f"  {'Time':<20} {'Type':<18} {'Session':<14} {'Message'}")
    click.echo(f"  {'-'*20} {'-'*18} {'-'*14} {'-'*40}")

    for e in entries:
        ts = e.get("timestamp", "")[:16].replace("T", " ")
        click.echo(f"  {ts:<20} {e.get('error_type', '?'):<18} {e.get('session_id', '?'):<14} {e.get('message', '')[:50]}")
    click.echo()


# ---------------------------------------------------------------------------
# start / health / cleanup
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default=None)
@click.option("--port", default=None, type=int)
@click.option("--log-level", default=None)
def start(host: Optional[str], port: Optional[int], log_level: Optional[str]) -> None:
    """Start the HTTP server (requires [server] extra)."""
    try:
        import uvicorn
    except ImportError:
        click.echo("Install with: pip install infinium-cline-connector[server]", err=True)
        sys.exit(1)

    from .config import ConnectorConfig, require_project_config
    require_project_config()
    config = ConnectorConfig.load()
    config.mode = "http"
    if host:
        config.host = host
    if port:
        config.port = port
    if log_level:
        config.log_level = log_level
    try:
        config.validate()
    except ValueError as e:
        click.echo(f"Configuration error: {e}", err=True)
        sys.exit(1)

    logging.basicConfig(level=getattr(logging, config.log_level.upper(), logging.INFO))
    click.echo(f"Starting Infinium Cline Connector on {config.hook_url}")
    from .server import create_app
    uvicorn.run(create_app(config), host=config.host, port=config.port, log_level=config.log_level.lower())


@main.command()
@click.option("--host", default="127.0.0.1")
@click.option("--port", default=9339, type=int)
def health(host: str, port: int) -> None:
    """Check if the HTTP server is running."""
    import httpx
    url = f"http://{host}:{port}/health"
    try:
        resp = httpx.get(url, timeout=5.0)
        data = resp.json()
        click.echo(f"Status: {data.get('status')}, Version: {data.get('version')}, Sessions: {data.get('active_sessions')}")
    except Exception as e:
        click.echo(f"Not reachable at {url}: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option("--max-age", default=1800, type=int, help="Max age in seconds (default: 1800)")
@click.option("--session-dir", default=None)
def cleanup(max_age: int, session_dir: Optional[str]) -> None:
    """Remove stale session files."""
    from . import session_store
    removed = session_store.cleanup_stale(max_age, session_dir)
    click.echo(f"Removed {len(removed)} stale session file(s)." if removed else "No stale files found.")


# ---------------------------------------------------------------------------
# Hook helpers
# ---------------------------------------------------------------------------


def _hook_command() -> str:
    """Return the command to invoke the hook."""
    python = sys.executable
    return f'"{python}" -m infinium_cline_connector.hook'


def _write_hooks() -> Path:
    """Create executable hook scripts in .clinerules/hooks/. Returns the hooks directory."""
    hooks_dir = Path.cwd() / ".clinerules" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    python = sys.executable
    command = f'"{python}" -m infinium_cline_connector.hook'

    for event_name in _DEFAULT_EVENTS:
        if sys.platform == "win32":
            script_path = hooks_dir / f"{event_name}.cmd"
            script_content = f"@echo off\n{command}\n"
        else:
            script_path = hooks_dir / event_name
            script_content = f"#!/bin/sh\n{command}\n"

        # Remove existing (idempotent re-init)
        if script_path.exists():
            script_path.unlink()

        script_path.write_text(script_content, encoding="utf-8")

        if sys.platform != "win32":
            script_path.chmod(0o755)

    return hooks_dir


def _remove_hooks() -> list[Path]:
    """Remove Infinium hook scripts from .clinerules/hooks/. Returns paths removed."""
    removed = []
    hooks_dir = Path.cwd() / ".clinerules" / "hooks"
    if not hooks_dir.exists():
        return removed

    for path in hooks_dir.iterdir():
        if not path.is_file():
            continue
        try:
            content = path.read_text(encoding="utf-8")
            if "infinium_cline_connector" in content:
                path.unlink()
                removed.append(path)
        except (OSError, UnicodeDecodeError):
            continue

    # Remove empty directory
    try:
        hooks_dir.rmdir()
    except OSError:
        pass
    try:
        (Path.cwd() / ".clinerules").rmdir()
    except OSError:
        pass

    return removed


def _find_existing_hooks() -> Optional[str]:
    """Find where Infinium hooks are currently configured."""
    hooks_dir = Path.cwd() / ".clinerules" / "hooks"
    if not hooks_dir.exists():
        return None
    for path in hooks_dir.iterdir():
        if not path.is_file():
            continue
        try:
            content = path.read_text(encoding="utf-8")
            if "infinium_cline_connector" in content:
                return str(hooks_dir)
        except (OSError, UnicodeDecodeError):
            continue
    return None


def _print_quick_reference() -> None:
    click.echo("  Quick Reference")
    click.echo("  ---------------")
    click.echo("  infinium-cline test              Verify your connection works")
    click.echo("  infinium-cline status            Check configuration & tracing state")
    click.echo("  infinium-cline pause             Temporarily stop tracing")
    click.echo("  infinium-cline resume            Resume tracing")
    click.echo("  infinium-cline history           View recent traces")
    click.echo("  infinium-cline errors            View connector errors")
    click.echo("  infinium-cline retry             Resend failed traces")
    click.echo("  infinium-cline update-credentials  Change agent ID or secret")
    click.echo("  infinium-cline uninstall         Remove the connector")
    click.echo()
    click.echo("  Tip: Run 'infinium-cline test' now to verify everything works!")
    click.echo()


def _setup_hooks_interactive() -> None:
    click.echo()
    hooks_path = _write_hooks()
    click.echo(f"\n  Hooks written to: {hooks_path}")
    click.echo("\n  Remember to enable hooks in Cline: VS Code Settings -> Cline -> Features -> Enable Hooks")
    click.echo()


if __name__ == "__main__":
    main()
