"""
Command hook entry point for Cline.

Cline invokes this script for each hook event, passing JSON on stdin.
Unlike Claude Code/Codex, Cline REQUIRES a JSON response on stdout:
    {"cancel": false, "contextModification": null, "errorMessage": null}

Events are accumulated in session JSONL files. On TaskComplete/TaskCancel,
a background flush worker is spawned to send the trace.

Usage (configured automatically by `infinium-cline init`):
    echo '{"hookName":"PostToolUse","taskId":"abc",...}' | python -m infinium_cline_connector.hook
"""
from __future__ import annotations

import json
import logging
import random
import subprocess
import sys

logger = logging.getLogger(__name__)

# Events that trigger a session-end flush (in a background worker)
_FLUSH_EVENTS = frozenset({"TaskComplete", "TaskCancel"})

# Probability of running stale-file cleanup on non-flush events (1 in 20)
_CLEANUP_PROBABILITY = 0.05

# Response that Cline expects on stdout
_OK_RESPONSE = json.dumps({"cancel": False, "contextModification": None, "errorMessage": None})


def _spawn_flush(
    session_id: str,
    event_name: str,
    cwd: str,
    session_dir: str | None = None,
    final: bool = False,
) -> None:
    """Spawn a detached background process to flush the session."""
    cmd = [
        sys.executable, "-m", "infinium_cline_connector.flush_worker",
        "--session-id", session_id,
        "--event-name", event_name,
        "--cwd", cwd,
    ]
    if session_dir:
        cmd.extend(["--session-dir", session_dir])
    if final:
        cmd.append("--final")

    kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NO_WINDOW = 0x08000000
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NO_WINDOW
    else:
        kwargs["start_new_session"] = True

    try:
        subprocess.Popen(cmd, **kwargs)
    except Exception as exc:
        logger.debug("Failed to spawn flush worker", exc_info=True)
        try:
            from . import error_log
            error_log.append_error(
                error_type="flush_spawn_failed",
                session_id=session_id,
                message=f"Could not spawn background flush worker: {exc}",
                context={"event_name": event_name, "final": final},
            )
        except Exception:
            pass  # error_log must never crash the hook


def _spawn_cleanup(cwd: str, session_dir: str | None = None) -> None:
    """Spawn a detached background process to clean up stale session files."""
    cmd = [
        sys.executable, "-m", "infinium_cline_connector.flush_worker",
        "--cleanup",
        "--cwd", cwd,
    ]
    if session_dir:
        cmd.extend(["--session-dir", session_dir])

    kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NO_WINDOW = 0x08000000
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NO_WINDOW
    else:
        kwargs["start_new_session"] = True

    try:
        subprocess.Popen(cmd, **kwargs)
    except Exception:
        logger.debug("Failed to spawn cleanup worker", exc_info=True)


def main() -> None:
    """Read a hook event from stdin, store it, and spawn background flush if needed.

    CRITICAL: Always writes a JSON response to stdout — Cline requires this.
    """
    logging.basicConfig(
        level=logging.WARNING,
        format="[infinium-cline-connector] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    try:
        raw = sys.stdin.read()
    except Exception:
        logger.debug("Failed to read from stdin", exc_info=True)
        sys.stdout.write(_OK_RESPONSE)
        sys.stdout.flush()
        return

    if not raw.strip():
        sys.stdout.write(_OK_RESPONSE)
        sys.stdout.flush()
        return

    try:
        event = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Invalid JSON from Cline hook")
        sys.stdout.write(_OK_RESPONSE)
        sys.stdout.flush()
        return

    if not isinstance(event, dict):
        sys.stdout.write(_OK_RESPONSE)
        sys.stdout.flush()
        return

    try:
        _process_event(event)
    except Exception:
        logger.exception("Error processing hook event")
    finally:
        # ALWAYS respond — Cline requires it
        sys.stdout.write(_OK_RESPONSE)
        sys.stdout.flush()


def _process_event(event: dict) -> None:
    """Process a Cline hook event (store + maybe flush)."""
    # Cline provides timestamps, but inject one if missing as safety
    if not event.get("timestamp"):
        from datetime import datetime, timezone
        event["timestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Cline uses hookName and taskId (not hook_event_name and session_id)
    event_name = event.get("hookName", "Unknown")
    task_id = event.get("taskId") or ""
    if not task_id:
        import uuid
        task_id = f"unknown-{uuid.uuid4().hex[:8]}"

    # Normalize: store hook_event_name for aggregator compatibility
    event["hook_event_name"] = event_name
    event["session_id"] = task_id

    from pathlib import Path
    from . import session_store
    from .config import ConnectorConfig

    # Resolve cwd from workspace_roots
    workspace_roots = event.get("workspaceRoots", [])
    event_cwd = Path(workspace_roots[0]) if workspace_roots else None

    if event_name not in ("TaskStart", "TaskResume"):
        origin = session_store.read_origin_cwd(task_id)
        if origin:
            event_cwd = Path(origin)

    config, paused = ConnectorConfig.load_hook_config(cwd=event_cwd)
    session_dir = config.session_dir

    if event_name in ("TaskStart", "TaskResume") and event_cwd:
        session_store.write_origin_cwd(task_id, str(event_cwd), session_dir)

    # Always store the event
    try:
        session_store.append_event(task_id, event, session_dir)
    except Exception:
        logger.exception("Failed to store event")
        return

    if paused:
        return

    cwd_str = str(event_cwd) if event_cwd else "."

    # Flush on TaskComplete/TaskCancel (explicit session end)
    if event_name in _FLUSH_EVENTS and config.flush_on_session_end:
        _spawn_flush(task_id, event_name, cwd_str, session_dir, final=True)
    elif random.random() < _CLEANUP_PROBABILITY:
        _spawn_cleanup(cwd_str, session_dir)


if __name__ == "__main__":
    main()
