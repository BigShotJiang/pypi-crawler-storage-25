"""
Shared JSONL log file with auto-rotation.

Used by error_log and history modules to avoid duplicating append/read/rotate logic.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class JsonlLog:
    """Append-only JSONL log file with automatic rotation."""

    def __init__(self, path: Path, max_entries: int) -> None:
        self.path = path
        self.max_entries = max_entries

    def append(self, entry: Dict[str, Any]) -> None:
        """Append a single entry as a JSON line, rotating if needed."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(entry, default=str, separators=(",", ":")) + "\n"
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(line)
        self._rotate_if_needed()

    def read(self, limit: int = 0) -> List[Dict[str, Any]]:
        """Read entries. Returns last *limit* entries, or all if limit=0."""
        if not self.path.exists():
            return []
        entries: List[Dict[str, Any]] = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return entries[-limit:] if limit else entries

    def count(self) -> int:
        """Count the number of entries."""
        if not self.path.exists():
            return 0
        n = 0
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    n += 1
        return n

    def clear(self) -> bool:
        """Delete the log file. Returns True if it existed."""
        if self.path.exists():
            self.path.unlink()
            return True
        return False

    def _rotate_if_needed(self) -> None:
        """Keep only the last max_entries entries if the file grows too large."""
        if not self.path.exists():
            return

        # Snapshot mtime before reading so we can detect concurrent writers.
        try:
            mtime_before = self.path.stat().st_mtime
        except OSError:
            return

        with open(self.path, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]

        # Only rotate when significantly over the limit to reduce the window
        # for race conditions between concurrent writers.
        if len(lines) <= int(self.max_entries * 1.2):
            return

        # If the file was modified while we were reading, another process is
        # writing — skip rotation to avoid losing their entries.
        try:
            if self.path.stat().st_mtime != mtime_before:
                return
        except OSError:
            return

        keep = lines[-self.max_entries:]
        tmp_path: Optional[str] = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.path.parent), suffix=".tmp"
            )
            with os.fdopen(fd, "w", encoding="utf-8") as tmp:
                tmp.writelines(keep)
            os.replace(tmp_path, str(self.path))
        except OSError:
            # Atomic replace failed — clean up temp file and leave the
            # original intact (it's only over-limit, not broken).
            if tmp_path is not None:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
            logger.debug("JSONL rotation failed for %s, will retry next append", self.path.name)
