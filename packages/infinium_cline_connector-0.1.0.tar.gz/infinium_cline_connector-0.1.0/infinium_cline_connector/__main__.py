"""Enable `python -m infinium_cline_connector` as CLI entry point."""
from infinium_cline_connector.cli import main

main()
