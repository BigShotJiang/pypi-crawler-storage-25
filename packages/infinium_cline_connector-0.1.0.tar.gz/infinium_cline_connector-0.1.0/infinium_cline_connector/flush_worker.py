"""
Background flush worker for the Infinium Cline Connector.

This module runs as a detached subprocess spawned by hook.py. It performs
the slow work (reading session files, reading token data, sending API
requests) outside of the synchronous hook process so that Cline
is never blocked waiting for network I/O.

Usage (invoked automatically by hook.py — not meant to be run manually):
    python -m infinium_cline_connector.flush_worker --session-id <id> --event-name <name> --cwd <path>
    python -m infinium_cline_connector.flush_worker --final --session-id <id> --cwd <path>
    python -m infinium_cline_connector.flush_worker --cleanup --cwd <path>
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time

logger = logging.getLogger(__name__)

_APP_RETRIES = 2
_RETRY_DELAY_S = 1.0
_MAX_CONSECUTIVE_FAILURES = 3
_MAX_PAYLOAD_BYTES = 950_000


# ---------------------------------------------------------------------------
# Payload fitting
# ---------------------------------------------------------------------------

def _payload_size(payload: "InfiniumTracePayload") -> int:
    return len(json.dumps(payload.to_dict(), default=str, ensure_ascii=False).encode("utf-8", errors="replace"))


def _fit_payload(payload: "InfiniumTracePayload") -> "InfiniumTracePayload":
    """Progressively truncate a payload until it fits within the API size limit."""
    if _payload_size(payload) <= _MAX_PAYLOAD_BYTES:
        return payload

    truncated = False

    if payload.steps:
        for limit in (200, 100):
            for step in payload.steps:
                for key in ("input_preview", "output_preview"):
                    val = step.get(key)
                    if val and len(val) > limit:
                        step[key] = val[:limit - 3] + "..."
                        truncated = True
        if _payload_size(payload) <= _MAX_PAYLOAD_BYTES:
            if truncated:
                _mark_truncated(payload)
            return payload

    if payload.steps and len(payload.steps) > 2:
        kept = max(len(payload.steps) // 2, 1)
        dropped = len(payload.steps) - kept
        payload.steps = payload.steps[-kept:]
        for i, step in enumerate(payload.steps, 1):
            step["step_number"] = i
        if payload.description:
            payload.description = f"[{dropped} earlier steps truncated] {payload.description}"
        truncated = True
        if _payload_size(payload) <= _MAX_PAYLOAD_BYTES:
            _mark_truncated(payload)
            return payload

    if payload.steps:
        for step in payload.steps:
            step.pop("input_preview", None)
            step.pop("output_preview", None)
        truncated = True

    if payload.steps and len(payload.steps) > 10:
        if _payload_size(payload) > _MAX_PAYLOAD_BYTES:
            payload.steps = payload.steps[-10:]
            for i, step in enumerate(payload.steps, 1):
                step["step_number"] = i
            truncated = True

    if truncated:
        _mark_truncated(payload)
    return payload


def _mark_truncated(payload: "InfiniumTracePayload") -> None:
    if payload.environment and isinstance(payload.environment.get("custom_tags"), dict):
        payload.environment["custom_tags"]["truncated"] = "true"


def _compute_duration_from_events(events: list) -> float:
    from datetime import datetime

    fmt = "%Y-%m-%dT%H:%M:%SZ"
    timestamps = []
    for ev in events:
        ts = ev.get("timestamp")
        if ts:
            try:
                timestamps.append(datetime.strptime(ts, fmt))
            except (ValueError, TypeError):
                pass
    if len(timestamps) < 2:
        return 0.0
    return max(0.0, (max(timestamps) - min(timestamps)).total_seconds())


# ---------------------------------------------------------------------------
# Flush logic
# ---------------------------------------------------------------------------

def flush_session(session_id: str, event_name: str, config: "ConnectorConfig", is_final: bool = False) -> None:
    """Aggregate and send a trace for a Cline task."""
    from . import session_store
    from .aggregator import SessionAggregator
    from . import sdk_bridge
    from . import history
    from . import error_log

    try:
        config.validate()
    except ValueError as e:
        logger.error("Cannot send trace — %s", e)
        error_log.append_error("config_error", session_id, str(e), context={"event_name": event_name})
        return

    all_events = session_store.read_events(session_id, config.session_dir)
    if not all_events:
        return

    is_session_end = is_final or event_name in ("TaskComplete", "TaskCancel")

    if not is_session_end:
        failure_count = session_store.read_failure_count(session_id, config.session_dir)
        if failure_count >= _MAX_CONSECUTIVE_FAILURES:
            logger.info("Skipping flush — %d consecutive failures", failure_count)
            return

    # Cline flushes are always full-session (no incremental per-turn)
    events_to_replay = all_events
    trace_type = "session"

    aggregator = SessionAggregator(config)
    payload = None
    for ev in events_to_replay:
        _, p = aggregator.ingest(ev)
        if p is not None:
            payload = p

    if payload is None:
        payloads = aggregator.flush_all()
        payload = payloads[0] if payloads else None

    if payload is None:
        logger.warning("No payload produced for session %s (%s)", session_id[:12], event_name)
        error_log.append_error(
            error_type="empty_payload",
            session_id=session_id,
            message="Aggregator produced no payload from session events",
            context={"event_name": event_name, "event_count": len(events_to_replay)},
        )
        return

    payload.duration = _compute_duration_from_events(events_to_replay)
    payload = _fit_payload(payload)

    if payload.environment and "custom_tags" in payload.environment:
        payload.environment["custom_tags"]["trace_type"] = trace_type

    # Extract token usage from Cline's ui_messages.json
    # The task_id is the session_id (mapped from taskId in hook events)
    task_id = session_id
    model = None
    model_provider = None
    for ev in all_events:
        m = ev.get("model", {})
        if isinstance(m, dict) and m.get("provider"):
            model_provider = m["provider"]
            model = f"{m.get('provider', '')}/{m.get('slug', '')}"
            break

    try:
        from .transcript import read_token_usage

        token_usage = read_token_usage(task_id, model=model)
        if token_usage:
            payload.llm_usage = {
                "model": token_usage.model,
                "provider": model_provider or "unknown",
                "prompt_tokens": token_usage.input_tokens,
                "completion_tokens": token_usage.output_tokens,
                "total_tokens": token_usage.input_tokens + token_usage.output_tokens,
                "api_calls_count": token_usage.api_calls,
                "cache_reads": token_usage.cache_reads,
                "cache_writes": token_usage.cache_writes,
                "total_cost": token_usage.total_cost,
            }
    except Exception:
        logger.debug("Failed to read token usage from ui_messages.json", exc_info=True)

    turns = len(payload.steps or [])
    tool_calls = sum(1 for s in (payload.steps or []) if s.get("action", "").startswith("tool_use"))
    errors = len(payload.errors or [])

    try:
        last_exc: BaseException | None = None
        result = None
        for attempt in range(_APP_RETRIES + 1):
            try:
                result = sdk_bridge.send_trace(config, payload)
                last_exc = None
                break
            except Exception as exc:
                last_exc = exc
                err_msg = str(exc).lower()
                if "authentication" in err_msg or "unauthorized" in err_msg:
                    break
                if attempt < _APP_RETRIES:
                    time.sleep(_RETRY_DELAY_S * (attempt + 1))

        if last_exc is not None:
            raise last_exc

        trace_id = result.get("traceId", result.get("id", "unknown"))
        logger.info("Trace sent for session %s (traceId=%s)", session_id[:12], trace_id)

        session_store.reset_failure_count(session_id, config.session_dir)

        try:
            history.append_entry({
                "timestamp": payload.current_datetime,
                "session_id": session_id[:12],
                "trace_id": str(trace_id),
                "name": payload.name,
                "turns": turns,
                "tool_calls": tool_calls,
                "errors": errors,
                "duration_s": round(payload.duration, 1),
                "status": "sent",
                "trace_type": trace_type,
            })
        except Exception:
            logger.debug("Failed to append history entry", exc_info=True)

    except Exception as exc:
        error_msg = str(exc)[:200]
        logger.warning("Trace failed for session %s: %s", session_id[:12], error_msg)

        from . import error_log as _error_log
        _error_log.append_error(
            error_type="flush_failed",
            session_id=session_id,
            message=error_msg,
            context={"event_name": event_name, "trace_type": trace_type},
        )

        if is_session_end:
            try:
                session_store.move_to_failed(session_id, config.session_dir)
            except Exception:
                logger.debug("Failed to move session to failed/", exc_info=True)

            try:
                history.append_entry({
                    "timestamp": payload.current_datetime,
                    "session_id": session_id[:12],
                    "trace_id": None,
                    "name": payload.name,
                    "turns": turns,
                    "tool_calls": tool_calls,
                    "errors": errors,
                    "duration_s": round(payload.duration, 1),
                    "status": "failed",
                    "error": error_msg,
                    "trace_type": trace_type,
                })
            except Exception:
                logger.debug("Failed to append failure history entry", exc_info=True)
        else:
            session_store.increment_failure_count(session_id, config.session_dir)

        return

    if is_session_end:
        session_store.remove_session(session_id, config.session_dir)


# ---------------------------------------------------------------------------
# Stale cleanup
# ---------------------------------------------------------------------------

def cleanup_stale_with_rescue(config: "ConnectorConfig") -> None:
    """Clean up stale session files, attempting a last-chance flush first."""
    from . import session_store

    session_dir = config.session_dir
    d = session_store.get_session_dir(session_dir)
    now = time.time()

    for path in d.glob("*.jsonl"):
        try:
            mtime = path.stat().st_mtime
            age = now - mtime
            if age <= config.session_ttl_seconds:
                continue

            session_id = path.stem

            try:
                flush_session(session_id, "stale_cleanup", config, is_final=True)
            except Exception:
                logger.debug("Last-chance flush failed for stale session %s", session_id[:12], exc_info=True)

            try:
                if path.stat().st_mtime != mtime:
                    continue
            except OSError:
                pass

            session_store.remove_session(session_id, session_dir)
        except OSError as e:
            logger.debug("Error during stale cleanup of %s: %s", path, e)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point when invoked as `python -m infinium_cline_connector.flush_worker`."""
    logging.basicConfig(
        level=logging.WARNING,
        format="[infinium-cline-flush-worker] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    parser = argparse.ArgumentParser(description="Infinium Cline flush worker (background)")
    parser.add_argument("--session-id", required=False)
    parser.add_argument("--event-name", required=False, default="TaskComplete")
    parser.add_argument("--cwd", required=False)
    parser.add_argument("--session-dir", required=False)
    parser.add_argument("--cleanup", action="store_true")
    parser.add_argument("--final", action="store_true", help="Treat as session summary flush")
    args = parser.parse_args()

    from pathlib import Path
    from .config import ConnectorConfig

    cwd = Path(args.cwd) if args.cwd else None
    config = ConnectorConfig.load(cwd=cwd)

    if args.session_dir:
        config.session_dir = args.session_dir

    if args.cleanup:
        try:
            cleanup_stale_with_rescue(config)
        except Exception:
            logger.debug("Stale session cleanup failed", exc_info=True)
        return

    if not args.session_id:
        logger.error("--session-id is required for flush")
        sys.exit(1)

    flush_session(args.session_id, args.event_name, config, is_final=args.final)


if __name__ == "__main__":
    main()
