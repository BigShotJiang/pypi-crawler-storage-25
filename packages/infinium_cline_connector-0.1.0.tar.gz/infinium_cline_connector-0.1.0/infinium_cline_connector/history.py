"""
Local trace history — records a summary of each trace sent to Infinium.

Stored as JSONL at ~/.infinium/history.jsonl. Auto-rotates at 1000 entries.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from .jsonl_log import JsonlLog

_log = JsonlLog(Path.home() / ".infinium" / "history.jsonl", max_entries=1000)


def append_entry(entry: Dict[str, Any]) -> None:
    """Append a single history entry as a JSON line."""
    _log.append(entry)


def read_entries(limit: int = 10) -> List[Dict[str, Any]]:
    """Read the last N history entries."""
    return _log.read(limit)


def clear_history() -> bool:
    """Delete the history file. Returns True if file existed."""
    return _log.clear()


def count_entries() -> int:
    """Count the number of history entries."""
    return _log.count()
