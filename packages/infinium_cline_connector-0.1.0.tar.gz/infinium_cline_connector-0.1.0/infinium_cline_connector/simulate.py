"""
Simulated Cline session generator for end-to-end smoke testing.

Produces a realistic sequence of Cline hook events (nested JSON) and runs
them through the real aggregator + sdk_bridge path — without requiring the
Cline VS Code extension. Requires valid Infinium credentials (run
`infinium-cline init` first).

Invoked via `infinium-cline simulate`.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from .aggregator import SessionAggregator
from .config import ConnectorConfig
from .sdk_bridge import send_trace
from .types import InfiniumTracePayload

logger = logging.getLogger(__name__)


@dataclass
class SimulationResult:
    session_id: str
    event_count: int
    trace_id: str
    payload: InfiniumTracePayload


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _generate_session(
    task: str = "Fix the login validation bug",
    command: str = "npm test",
    start: Optional[datetime] = None,
    model_provider: str = "anthropic",
    model_slug: str = "claude-sonnet-4",
) -> List[Dict[str, Any]]:
    """Build a realistic Cline task lifecycle (TaskStart → TaskComplete).

    Cline events use nested JSON — the sub-object keyed by the hook name
    holds the event-specific fields. TaskStart opens the task; the inner
    UserPromptSubmit is a distinct follow-up message within that task
    (matching how Cline actually fires the two events in real sessions).
    """
    start = start or datetime.now(timezone.utc)
    tid = f"cline-sim-{uuid.uuid4().hex[:8]}"
    follow_up = f"Go ahead and verify by running `{command}`."
    common = {
        "taskId": tid,
        "clineVersion": "3.36",
        "workspaceRoots": ["."],
        "userId": "sim-user",
        "model": {"provider": model_provider, "slug": model_slug},
    }

    return [
        {
            **common,
            "hookName": "TaskStart",
            "timestamp": _iso(start),
            "taskStart": {"task": task},
        },
        {
            **common,
            "hookName": "UserPromptSubmit",
            "timestamp": _iso(start + timedelta(seconds=1)),
            "userPromptSubmit": {"prompt": follow_up},
        },
        {
            **common,
            "hookName": "PreToolUse",
            "timestamp": _iso(start + timedelta(seconds=2)),
            "preToolUse": {"tool": "execute_command", "parameters": {"command": command}},
        },
        {
            **common,
            "hookName": "PostToolUse",
            "timestamp": _iso(start + timedelta(seconds=5)),
            "postToolUse": {
                "tool": "execute_command",
                "parameters": {"command": command},
                "result": "All 42 tests passed",
                "success": True,
                "durationMs": 3000,
            },
        },
        {
            **common,
            "hookName": "TaskComplete",
            "timestamp": _iso(start + timedelta(seconds=6)),
            "taskComplete": {"task": task},
        },
    ]


def run_simulation(
    config: ConnectorConfig,
    task: str = "Fix the login validation bug",
    command: str = "npm test",
    dry_run: bool = False,
    model_provider: str = "anthropic",
    model_slug: str = "claude-sonnet-4",
) -> SimulationResult:
    config.validate()

    events = _generate_session(
        task=task,
        command=command,
        model_provider=model_provider,
        model_slug=model_slug,
    )
    session_id = events[0]["taskId"]

    aggregator = SessionAggregator(config)
    payload = aggregator.replay_events(events)
    if payload is None:
        raise RuntimeError("Simulated session produced no trace payload")

    if payload.environment is None:
        payload.environment = {}
    tags = dict(payload.environment.get("custom_tags") or {})
    tags["simulated"] = "true"
    payload.environment["custom_tags"] = tags

    trace_id = "dry-run"
    if not dry_run:
        result = send_trace(config, payload)
        trace_id = result.get("traceId") or result.get("id") or "unknown"

    return SimulationResult(
        session_id=session_id,
        event_count=len(events),
        trace_id=str(trace_id),
        payload=payload,
    )
