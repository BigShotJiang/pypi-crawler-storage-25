"""
Type definitions for Cline hook events and Infinium trace payloads.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Cline hook event types
# ---------------------------------------------------------------------------

# VS Code extension ID for Cline (part of upstream compatibility contract —
# see CLAUDE.md). Used by transcript.py to locate ui_messages.json.
CLINE_EXTENSION_ID = "saoudrizwan.claude-dev"

# All hook events that Cline can emit
HOOK_EVENTS = frozenset({
    "TaskStart",
    "TaskResume",
    "TaskCancel",
    "TaskComplete",
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "PreCompact",
})

# Events that signal session completion
SESSION_END_EVENTS = frozenset({"TaskComplete", "TaskCancel"})

# Events that represent a completed prompt turn (no per-turn flush for Cline)
TURN_END_EVENTS: frozenset = frozenset()

# Events that signal a new session/task is starting
SESSION_START_EVENTS = frozenset({"TaskStart", "TaskResume"})


@dataclass
class HookEvent:
    """Parsed Cline hook event."""

    event_name: str  # from hookName
    task_id: str  # from taskId — used as session_id internally
    timestamp: str  # ISO 8601 (provided by Cline)

    # Common fields from all Cline events
    cline_version: Optional[str] = None
    workspace_roots: Optional[List[str]] = None
    user_id: Optional[str] = None
    model_provider: Optional[str] = None  # from model.provider
    model_slug: Optional[str] = None  # from model.slug

    # TaskStart / TaskResume / TaskComplete / TaskCancel
    task_text: Optional[str] = None  # the task/prompt text

    # UserPromptSubmit
    prompt: Optional[str] = None

    # PreToolUse / PostToolUse
    tool_name: Optional[str] = None
    tool_parameters: Optional[Dict[str, Any]] = None
    tool_result: Optional[str] = None  # PostToolUse only
    tool_success: Optional[bool] = None  # PostToolUse only
    tool_duration_ms: Optional[int] = None  # PostToolUse only

    # PreCompact
    conversation_length: Optional[int] = None
    estimated_tokens: Optional[int] = None

    # Raw payload for anything we don't explicitly parse
    raw: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Aggregated session data
# ---------------------------------------------------------------------------


@dataclass
class ToolUseRecord:
    """A single tool invocation within a session."""

    tool_name: str
    tool_use_id: Optional[str] = None
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    error: Optional[str] = None
    success: Optional[bool] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_ms: Optional[int] = None


@dataclass
class PromptTurn:
    """A single user prompt -> assistant response cycle."""

    prompt: Optional[str] = None
    response: Optional[str] = None
    tool_uses: List[ToolUseRecord] = field(default_factory=list)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


@dataclass
class SessionData:
    """Accumulated data for a Cline task/session."""

    session_id: str  # mapped from taskId
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    model: Optional[str] = None  # combined provider/slug
    model_provider: Optional[str] = None
    model_slug: Optional[str] = None
    cwd: Optional[str] = None  # from workspace_roots[0]
    cline_version: Optional[str] = None

    turns: List[PromptTurn] = field(default_factory=list)

    # Counters
    total_tool_calls: int = 0
    total_errors: int = 0

    # Track pending tool uses (PreToolUse received, PostToolUse not yet)
    _pending_tools: Dict[str, ToolUseRecord] = field(default_factory=dict)
    _current_turn: Optional[PromptTurn] = field(default=None)


# ---------------------------------------------------------------------------
# Infinium trace payload (mirrors SDK TaskData structure)
# ---------------------------------------------------------------------------


@dataclass
class InfiniumTracePayload:
    """Payload sent to POST /agents/{agent_id}/trace."""

    name: str
    description: str
    current_datetime: str
    duration: float

    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    steps: Optional[List[Dict[str, Any]]] = None
    expected_outcome: Optional[Dict[str, Any]] = None
    environment: Optional[Dict[str, Any]] = None
    errors: Optional[List[Dict[str, Any]]] = None
    llm_usage: Optional[Dict[str, Any]] = None
    sections: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict, omitting None values."""
        result: Dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "current_datetime": self.current_datetime,
            "duration": self.duration,
        }
        for key in (
            "input_summary",
            "output_summary",
            "steps",
            "expected_outcome",
            "environment",
            "errors",
            "llm_usage",
            "sections",
        ):
            val = getattr(self, key)
            if val is not None:
                result[key] = val
        return result
