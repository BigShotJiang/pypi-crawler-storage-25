"""
Session aggregator — collects Cline hook events and builds Infinium trace payloads.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from . import __version__
from .config import ConnectorConfig
from .sdk_bridge import sanitize_str as _sanitize_str
from .types import (
    HookEvent,
    InfiniumTracePayload,
    PromptTurn,
    SessionData,
    ToolUseRecord,
)

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _truncate(text: Optional[str], limit: int) -> Optional[str]:
    if text is None:
        return None
    if not isinstance(text, str):
        try:
            text = json.dumps(text, default=str, separators=(",", ":"))
        except (TypeError, ValueError, UnicodeEncodeError):
            text = str(text)
    text = _sanitize_str(text)
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def _summarize_tool_input(tool_name: str, tool_input: Any, limit: int) -> Optional[str]:
    """Extract a human-readable summary from structured tool input."""
    if not tool_input or not isinstance(tool_input, dict):
        return _truncate(tool_input, limit) if tool_input else None

    ti = tool_input
    summary = None

    # Cline tools use various parameter shapes
    if tool_name in ("execute_command", "shell"):
        summary = ti.get("command", "")
    elif tool_name in ("read_file", "readFile"):
        summary = ti.get("path", ti.get("file_path", ""))
    elif tool_name in ("write_to_file", "writeFile"):
        summary = ti.get("path", ti.get("file_path", ""))
    elif tool_name in ("replace_in_file", "editFile"):
        path = ti.get("path", ti.get("file_path", ""))
        summary = f"Edit {_short_path(path)}" if path else None
    elif tool_name in ("search_files", "grep"):
        pattern = ti.get("regex", ti.get("pattern", ""))
        path = ti.get("path", "")
        summary = f'"{pattern}" in {_short_path(path)}' if path else f'"{pattern}"'
    elif tool_name == "list_files":
        summary = ti.get("path", "")
    elif tool_name == "browser_action":
        summary = ti.get("action", "")
    else:
        # Generic fallback
        try:
            summary = json.dumps(ti, default=str, separators=(",", ":"))
        except (TypeError, ValueError):
            summary = str(ti)

    if summary:
        return _truncate(summary, limit)
    return None


def _summarize_tool_output(tool_name: str, tool_result: Any, limit: int) -> Optional[str]:
    """Extract a human-readable summary from tool output.

    Cline PostToolUse sends tool_result as a string with success boolean.
    """
    if tool_result is None:
        return None
    if isinstance(tool_result, bool):
        return "Succeeded" if tool_result else "Failed"
    if isinstance(tool_result, str):
        return _truncate(tool_result, limit)
    if isinstance(tool_result, dict):
        try:
            return _truncate(json.dumps(tool_result, default=str, separators=(",", ":")), limit)
        except (TypeError, ValueError):
            pass
    return _truncate(str(tool_result), limit)


def _short_path(path: str) -> str:
    """Shorten a file path to just filename or last 2 components."""
    if not path:
        return ""
    from pathlib import PurePosixPath, PureWindowsPath
    try:
        p = PureWindowsPath(path) if "\\" in path else PurePosixPath(path)
        parts = p.parts
        if len(parts) <= 2:
            return str(p)
        return str(PurePosixPath(*parts[-2:]))
    except Exception:
        return path


def _parse_hook_event(payload: Dict[str, Any]) -> HookEvent:
    """Parse a raw Cline hook JSON payload into a HookEvent.

    Cline uses nested sub-objects per event type (e.g. taskStart.task,
    postToolUse.result) rather than flat top-level fields.
    """
    hook_name = payload.get("hookName", "Unknown")
    task_id = payload.get("taskId", "unknown")
    model = payload.get("model", {}) or {}
    timestamp = payload.get("timestamp", _now_iso())

    # Extract event-specific fields
    task_text = None
    prompt = None
    tool_name = None
    tool_parameters = None
    tool_result = None
    tool_success = None
    tool_duration_ms = None
    conversation_length = None
    estimated_tokens = None

    if hook_name in ("TaskStart", "TaskResume"):
        sub = payload.get("taskStart") or payload.get("taskResume") or {}
        task_text = sub.get("task")
    elif hook_name in ("TaskComplete", "TaskCancel"):
        sub = payload.get("taskComplete") or payload.get("taskCancel") or {}
        task_text = sub.get("task")
    elif hook_name == "UserPromptSubmit":
        sub = payload.get("userPromptSubmit") or {}
        prompt = sub.get("prompt")
    elif hook_name == "PreToolUse":
        sub = payload.get("preToolUse") or {}
        tool_name = sub.get("tool")
        tool_parameters = sub.get("parameters")
    elif hook_name == "PostToolUse":
        sub = payload.get("postToolUse") or {}
        tool_name = sub.get("tool")
        tool_parameters = sub.get("parameters")
        tool_result = sub.get("result")
        tool_success = sub.get("success")
        tool_duration_ms = sub.get("durationMs")
    elif hook_name == "PreCompact":
        sub = payload.get("preCompact") or {}
        conversation_length = sub.get("conversationLength")
        estimated_tokens = sub.get("estimatedTokens")

    return HookEvent(
        event_name=hook_name,
        task_id=task_id,
        timestamp=timestamp,
        cline_version=payload.get("clineVersion"),
        workspace_roots=payload.get("workspaceRoots"),
        user_id=payload.get("userId"),
        model_provider=model.get("provider") if isinstance(model, dict) else None,
        model_slug=model.get("slug") if isinstance(model, dict) else None,
        task_text=task_text,
        prompt=prompt,
        tool_name=tool_name,
        tool_parameters=tool_parameters,
        tool_result=tool_result,
        tool_success=tool_success,
        tool_duration_ms=tool_duration_ms,
        conversation_length=conversation_length,
        estimated_tokens=estimated_tokens,
        raw=payload,
    )


class SessionAggregator:
    """
    Collects hook events per session and produces Infinium trace payloads.
    """

    def __init__(self, config: ConnectorConfig) -> None:
        self.config = config
        self._sessions: Dict[str, SessionData] = {}
        self._session_timestamps: Dict[str, float] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ingest(self, raw_payload: Dict[str, Any]) -> Tuple[HookEvent, Optional[InfiniumTracePayload]]:
        """Ingest a single hook event. Returns parsed event and optional payload."""
        event = _parse_hook_event(raw_payload)
        session = self._get_or_create_session(event)
        self._apply_event(session, event)

        payload: Optional[InfiniumTracePayload] = None

        # Flush on TaskComplete/TaskCancel (explicit session end)
        if event.event_name in ("TaskComplete", "TaskCancel") and self.config.flush_on_session_end:
            payload = self._build_payload(session)
            self._remove_session(event.task_id)

        return event, payload

    def flush_session(self, session_id: str) -> Optional[InfiniumTracePayload]:
        """Force-flush a session and return the payload."""
        session = self._sessions.get(session_id)
        if session is None:
            return None
        payload = self._build_payload(session)
        self._remove_session(session_id)
        return payload

    def flush_all(self) -> List[InfiniumTracePayload]:
        """Flush all active sessions."""
        payloads = []
        for sid in list(self._sessions.keys()):
            p = self.flush_session(sid)
            if p is not None:
                payloads.append(p)
        return payloads

    def evict_stale(self) -> List[str]:
        """Remove sessions older than session_ttl_seconds."""
        now = time.monotonic()
        cutoff = now - self.config.session_ttl_seconds
        stale = [sid for sid, ts in self._session_timestamps.items() if ts < cutoff]
        for sid in stale:
            self._remove_session(sid)
        return stale

    def replay_events(self, events: List[Dict[str, Any]]) -> Optional[InfiniumTracePayload]:
        """Replay events and return the payload."""
        if not events:
            return None
        payload: Optional[InfiniumTracePayload] = None
        for ev in events:
            _, p = self.ingest(ev)
            if p is not None:
                payload = p
        # If no flush was triggered naturally, force-flush sessions created by these events
        if payload is None:
            payloads = self.flush_all()
            payload = payloads[0] if payloads else None
        return payload

    @property
    def active_session_count(self) -> int:
        return len(self._sessions)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_or_create_session(self, event: HookEvent) -> SessionData:
        sid = event.task_id
        if sid not in self._sessions:
            cwd = event.workspace_roots[0] if event.workspace_roots else None
            self._sessions[sid] = SessionData(
                session_id=sid,
                started_at=event.timestamp,
                cwd=cwd,
                model_provider=event.model_provider,
                model_slug=event.model_slug,
                cline_version=event.cline_version,
            )
            if event.model_provider and event.model_slug:
                self._sessions[sid].model = f"{event.model_provider}/{event.model_slug}"
            self._session_timestamps[sid] = time.monotonic()
            logger.info("New session tracked: %s", sid[:12])
        else:
            self._session_timestamps[sid] = time.monotonic()
        return self._sessions[sid]

    def _remove_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
        self._session_timestamps.pop(session_id, None)

    def _ensure_current_turn(self, session: SessionData) -> PromptTurn:
        if session._current_turn is None:
            turn = PromptTurn(started_at=_now_iso())
            session._current_turn = turn
            session.turns.append(turn)
        return session._current_turn

    def _apply_event(self, session: SessionData, event: HookEvent) -> None:
        handler = getattr(self, f"_handle_{event.event_name}", None)
        if handler is not None:
            handler(session, event)
        else:
            logger.debug("Unhandled event type: %s", event.event_name)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_TaskStart(self, session: SessionData, event: HookEvent) -> None:
        session.started_at = event.timestamp
        if event.model_provider and event.model_slug:
            session.model = f"{event.model_provider}/{event.model_slug}"
            session.model_provider = event.model_provider
            session.model_slug = event.model_slug
        if event.cline_version:
            session.cline_version = event.cline_version
        # Use the task text as the initial prompt if no UserPromptSubmit yet
        if event.task_text and not session.turns:
            turn = PromptTurn(
                prompt=_truncate(event.task_text, self.config.max_input_preview),
                started_at=event.timestamp,
            )
            session._current_turn = turn
            session.turns.append(turn)

    def _handle_TaskResume(self, session: SessionData, event: HookEvent) -> None:
        # Same as TaskStart but marks a resumed session
        self._handle_TaskStart(session, event)

    def _handle_TaskComplete(self, session: SessionData, event: HookEvent) -> None:
        session.ended_at = event.timestamp
        # Close current turn if open
        if session._current_turn is not None:
            session._current_turn.completed_at = event.timestamp
            session._current_turn = None

    def _handle_TaskCancel(self, session: SessionData, event: HookEvent) -> None:
        session.ended_at = event.timestamp
        if session._current_turn is not None:
            session._current_turn.completed_at = event.timestamp
            session._current_turn = None

    def _handle_UserPromptSubmit(self, session: SessionData, event: HookEvent) -> None:
        turn = PromptTurn(
            prompt=_truncate(event.prompt, self.config.max_input_preview),
            started_at=event.timestamp,
        )
        session._current_turn = turn
        session.turns.append(turn)

    def _handle_PreToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_name = event.tool_name or "unknown"
        tool_use_id = f"tool-{len(turn.tool_uses)}"

        input_summary = _summarize_tool_input(
            tool_name, event.tool_parameters, self.config.max_input_preview
        )

        record = ToolUseRecord(
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            input_summary=input_summary,
            started_at=event.timestamp,
        )
        session._pending_tools[tool_use_id] = record

    def _handle_PostToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_name = event.tool_name or "unknown"

        # Match pending PreToolUse: prefer same tool name (FIFO order),
        # fall back to oldest pending if no name match.
        record = None
        for tid, pending in list(session._pending_tools.items()):
            if pending.tool_name == tool_name:
                record = session._pending_tools.pop(tid)
                break
        if record is None and session._pending_tools:
            # No name match — take the oldest pending tool (FIFO)
            first_tid = next(iter(session._pending_tools))
            record = session._pending_tools.pop(first_tid)

        if record is None:
            record = ToolUseRecord(
                tool_name=tool_name,
                tool_use_id=f"tool-{len(turn.tool_uses)}",
            )

        record.output_summary = _summarize_tool_output(
            tool_name, event.tool_result, self.config.max_output_preview
        )
        record.completed_at = event.timestamp
        record.success = event.tool_success
        # Cline provides duration directly
        record.duration_ms = event.tool_duration_ms
        turn.tool_uses.append(record)
        session.total_tool_calls += 1

        if event.tool_success is False:
            record.error = _truncate(event.tool_result, self.config.max_output_preview) or "Tool failed"
            session.total_errors += 1

    def _handle_PreCompact(self, session: SessionData, event: HookEvent) -> None:
        # Informational — no action needed for tracing
        pass

    # ------------------------------------------------------------------
    # Payload building
    # ------------------------------------------------------------------

    def _build_payload(self, session: SessionData) -> InfiniumTracePayload:
        """Convert a SessionData into an Infinium-compatible trace payload."""
        now = _now_iso()
        duration = self._compute_session_duration(session)

        steps: List[Dict[str, Any]] = []
        step_num = 0
        all_errors: List[Dict[str, Any]] = []

        for turn_idx, turn in enumerate(session.turns):
            if turn.prompt:
                step_num += 1
                steps.append({
                    "step_number": step_num,
                    "action": "user_prompt",
                    "description": f"Turn {turn_idx + 1}: User prompt",
                    "input_preview": turn.prompt,
                    "output_preview": turn.response,
                })

            for tool in turn.tool_uses:
                step_num += 1
                step: Dict[str, Any] = {
                    "step_number": step_num,
                    "action": "tool_use",
                    "description": f"Tool: {tool.tool_name}",
                    "duration_ms": tool.duration_ms,
                    "input_preview": tool.input_summary,
                    "output_preview": tool.output_summary,
                }
                if tool.error:
                    step["error"] = {
                        "error_type": "ToolError",
                        "message": tool.error,
                        "recoverable": True,
                    }
                    all_errors.append(step["error"])
                steps.append(step)

        # Name and description
        num_turns = len(session.turns)
        first_prompt = None
        for t in session.turns:
            if t.prompt:
                first_prompt = t.prompt
                break

        if first_prompt:
            clean_prompt = " ".join(first_prompt.split())
            name = _truncate(clean_prompt, 30)
            description = first_prompt
        else:
            name = f"Cline task ({num_turns} turn{'s' if num_turns != 1 else ''})"
            description = f"Cline task with {session.total_tool_calls} tool calls"

        output_summary = None
        for t in reversed(session.turns):
            if t.response:
                output_summary = t.response
                break

        # Environment
        environment: Dict[str, Any] = {
            "framework": "cline",
            "runtime": "cline-connector",
            "sdk_version": __version__,
        }
        custom_tags: Dict[str, str] = {}
        if session.model:
            custom_tags["model"] = session.model
        if session.model_provider:
            custom_tags["model_provider"] = session.model_provider
        if session.cwd:
            custom_tags["working_directory"] = session.cwd
        if session.cline_version:
            custom_tags["cline_version"] = session.cline_version
        custom_tags["session_id"] = session.session_id
        if custom_tags:
            environment["custom_tags"] = custom_tags

        development: Dict[str, Any] = {"framework_used": "cline"}
        if session.cwd:
            development["files_modified"] = [session.cwd]

        tools_used = list({
            tool.tool_name
            for turn in session.turns
            for tool in turn.tool_uses
        })

        sections: Dict[str, Any] = {
            "development": development,
            "general": {
                "tools_used": tools_used,
                "tags": ["cline", "ai-coding-agent", "vscode"],
            },
        }

        trace_datetime = None
        if session.turns:
            last_turn = session.turns[-1]
            trace_datetime = last_turn.started_at or last_turn.completed_at
        if not trace_datetime:
            trace_datetime = session.started_at or now

        return InfiniumTracePayload(
            name=name,
            description=description,
            current_datetime=trace_datetime,
            duration=duration,
            input_summary=first_prompt,
            output_summary=output_summary,
            steps=steps if steps else None,
            errors=all_errors if all_errors else None,
            environment=environment,
            sections=sections,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_duration_ms(start_iso: Optional[str], end_iso: Optional[str]) -> Optional[int]:
        if not start_iso or not end_iso:
            return None
        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            start = datetime.strptime(start_iso, fmt)
            end = datetime.strptime(end_iso, fmt)
            return max(0, int((end - start).total_seconds() * 1000))
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _compute_session_duration(session: SessionData) -> float:
        start = session.started_at
        end = session.ended_at
        if not start:
            return 0.0
        if not end:
            for turn in reversed(session.turns):
                if turn.completed_at:
                    end = turn.completed_at
                    break
        if not end:
            end = _now_iso()
        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            s = datetime.strptime(start, fmt)
            e = datetime.strptime(end, fmt)
            return max(0.0, (e - s).total_seconds())
        except (ValueError, TypeError):
            return 0.0
