"""
Read token usage data from Cline's ui_messages.json file.

Cline stores task data in VS Code's global storage:
    <globalStoragePath>/tasks/<taskId>/ui_messages.json

Token usage appears in api_req_started entries:
    {"type":"say","say":"api_req_started","text":"{\"tokensIn\":100,\"tokensOut\":50,...}"}

The ``text`` field is a JSON string that must be parsed separately.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from .types import CLINE_EXTENSION_ID

logger = logging.getLogger(__name__)


@dataclass
class TokenUsage:
    """Aggregated token usage from a Cline task."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_reads: int = 0
    cache_writes: int = 0
    total_cost: float = 0.0
    api_calls: int = 0
    model: Optional[str] = None
    _per_call: List[dict] = field(default_factory=list)


def _find_global_storage_paths() -> List[Path]:
    """Return candidate globalStorage paths for Cline across IDEs and platforms."""
    candidates: List[Path] = []

    vscode_dirs = ["Code", "Code - Insiders"]

    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            for vsc in vscode_dirs:
                candidates.append(
                    Path(appdata) / vsc / "User" / "globalStorage" / CLINE_EXTENSION_ID
                )
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
        for vsc in vscode_dirs:
            candidates.append(base / vsc / "User" / "globalStorage" / CLINE_EXTENSION_ID)
    else:  # Linux
        base = Path.home() / ".config"
        for vsc in vscode_dirs:
            candidates.append(base / vsc / "User" / "globalStorage" / CLINE_EXTENSION_ID)

    return candidates


def _find_ui_messages(task_id: str) -> Optional[Path]:
    """Find Cline's ui_messages.json for a given task ID."""
    for base in _find_global_storage_paths():
        path = base / "tasks" / task_id / "ui_messages.json"
        if path.exists():
            return path
    return None


def read_token_usage(
    task_id: str,
    model: Optional[str] = None,
) -> Optional[TokenUsage]:
    """
    Read token usage from Cline's ui_messages.json for a given task.

    Scans for entries where ``say == "api_req_started"`` and parses the
    inner JSON string in the ``text`` field to extract token counts and cost.
    """
    path = _find_ui_messages(task_id)
    if not path:
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.debug("Could not read ui_messages.json for task %s: %s", task_id[:12], e)
        return None

    if not isinstance(data, list):
        return None

    usage = TokenUsage(model=model)

    for msg in data:
        if msg.get("say") != "api_req_started":
            continue
        text = msg.get("text", "")
        if not text:
            continue
        try:
            req_data = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            continue

        in_tok = req_data.get("tokensIn", 0) or 0
        out_tok = req_data.get("tokensOut", 0) or 0
        cache_r = req_data.get("cacheReads", 0) or 0
        cache_w = req_data.get("cacheWrites", 0) or 0
        cost = req_data.get("cost", 0.0) or 0.0

        usage.input_tokens += in_tok
        usage.output_tokens += out_tok
        usage.cache_reads += cache_r
        usage.cache_writes += cache_w
        usage.total_cost += cost
        usage.api_calls += 1

        usage._per_call.append({
            "input_tokens": in_tok,
            "output_tokens": out_tok,
            "cache_reads": cache_r,
            "cache_writes": cache_w,
            "cost": cost,
        })

    return usage if usage.api_calls > 0 else None
