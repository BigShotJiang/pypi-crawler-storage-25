"""
Persistent error log for connector failures.

Stored as JSONL at ~/.infinium/errors.jsonl. Auto-rotates at 500 entries.
Gives users visibility into silent failures that stderr logging cannot provide.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .jsonl_log import JsonlLog

_log = JsonlLog(Path.home() / ".infinium" / "errors.jsonl", max_entries=500)


def append_error(
    error_type: str,
    session_id: str,
    message: str,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """Append an error entry. Never raises — safe to call from hook."""
    try:
        entry: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "error_type": error_type,
            "session_id": session_id[:12] if session_id else "unknown",
            "message": message[:200] if message else "",
        }
        if context:
            entry["context"] = context
        _log.append(entry)
    except Exception:
        pass  # Never crash the hook


def read_errors(limit: int = 20) -> List[Dict[str, Any]]:
    """Read the last N error entries."""
    return _log.read(limit)


def last_error() -> Optional[Dict[str, Any]]:
    """Return the most recent error entry, or None."""
    entries = _log.read(limit=1)
    return entries[0] if entries else None


def clear_errors() -> bool:
    """Delete the error log. Returns True if file existed."""
    return _log.clear()
