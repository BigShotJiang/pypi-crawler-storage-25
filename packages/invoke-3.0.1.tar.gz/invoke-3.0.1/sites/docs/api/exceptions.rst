==============
``exceptions``
==============

.. automodule:: invoke.exceptions
