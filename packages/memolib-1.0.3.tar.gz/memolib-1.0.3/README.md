# MemoLib

A comprehensive OCR and computer vision model library built on PyTorch, providing a unified interface for text recognition, object detection, image segmentation, and image classification.

## Features

- **Text Recognition** - SVTRV2 model with GTC (Generative Text Context) pipeline, SMTR decoder, and RCTC loss
- **Object Detection** - YOLO family (v5, v8, v11, v26) with detection and segmentation variants
- **Image Segmentation** - DINO + UperNet semantic segmentation
- **Image Classification** - EfficientNet, PPLCNet, YOLO classification
- **Unified Interface** - Consistent API across all models: `LoadWeight`, `Predict`, `BatchPredict`, `Train`, `Export`
- **Model Export** - Export to ONNX, OpenVINO, or TensorRT formats

## Installation

```bash
pip install memolib
```

### Optional dependencies

```bash
# For YOLO models
pip install memolib[yolo]

# For PPLCNet models
pip install memolib[pplcnet]

# For development
pip install memolib[dev]
```

## Quick Start

### Text Recognition with SVTRV2

```python
from MemoLib import SVTRV2, TrainingConfig

# Load a pre-trained recognition model
model = SVTRV2()
model.LoadWeight("path/to/weights.pth")

# Single prediction
result = model.Predict(image)

# Batch prediction
results = model.BatchPredict([img1, img2, img3])
```

### Object Detection with YOLO

```python
from MemoLib import Yolo, TrainingConfig
from MemoLib.Model.BaseModel import eYoloDetectionModel

# Load a YOLO detection model
model = Yolo()
model.LoadWeight(eYoloDetectionModel.YoloV8n)

# Single prediction
result = model.Predict(image)
```

### Semantic Segmentation with DINO UperNet

```python
from MemoLib.Model.DinoUperNet import DinoUperNet, TrainingConfig

model = DinoUperNet()
model.LoadWeight("path/to/weights.pth")
result = model.Predict(image)
```

### Model Export

```python
from MemoLib.Model.BaseModel import eModelExportType

# Export to ONNX
model.Export("model.onnx", eModelExportType.ONNX)

# Export to OpenVINO
model.Export("model.xml", eModelExportType.OpenVINO)

# Export to TensorRT
model.Export("model.engine", eModelExportType.TensorRT)
```

## Project Structure

```
MemoLib/
├── Model/
│   ├── BaseModel/       # Base interfaces and model type enums
│   │   ├── IModel.py    # Abstract model interface
│   │   └── eModelBase.py # Model type enumerations
│   ├── STVRV2/          # SVTRV2 OCR recognition model
│   ├── YOLO/            # YOLO detection & classification
│   ├── DinoUperNet/     # DINO + UperNet segmentation
│   ├── Efficientnet/    # EfficientNet classification
│   └── PPLCNet/         # PPLCNet classification
```

## Available Model Types

| Category | Models |
|---|---|
| Recognition | SVTRV2 (GTC/SMTR/RCTC) |
| Detection | YOLOv5, YOLOv8, YOLO11, YOLO26, RF-DETR |
| Segmentation | YOLO Segment, DINO UperNet |
| Classification | EfficientNet (B0-B7, V2), PPLCNet, YOLO Class, RF-DETR Class |
| Anomaly Detection | DInomaly, INFormerly |

## Requirements

- Python 3.9+
- PyTorch >= 1.10.0
- torchvision >= 0.11.0
- numpy >= 1.21.0
- opencv-python >= 4.5.0

## License

MIT License
