"""
Image transforms and dataset loaders for SVTRV2 OCR recognition.
- resize_norm_img (SVTR-style normalization with aspect-ratio padding)
- SVTRResize (transform operator)
- LMDBRecDataset (LMDB-based recognition dataset)
- ImageFolderRecDataset (ImageFolder with text labels)
"""

import os
import math
import random
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms as T
from PIL import Image

try:
    import lmdb
    LMDB_AVAILABLE = True
except ImportError:
    LMDB_AVAILABLE = False


def resize_norm_img(img, image_shape, padding=True, interpolation=cv2.INTER_LINEAR):
    """Resize image to (imgH, resized_w) with aspect ratio, pad to imgW, normalize to [-1, 1]."""
    imgC, imgH, imgW = image_shape
    h = img.shape[0]
    w = img.shape[1]
    if not padding:
        resized_image = cv2.resize(img, (imgW, imgH), interpolation=interpolation)
        resized_w = imgW
    else:
        ratio = w / float(h)
        if math.ceil(imgH * ratio) > imgW:
            resized_w = imgW
        else:
            resized_w = int(math.ceil(imgH * ratio))
        resized_image = cv2.resize(img, (resized_w, imgH))
    resized_image = resized_image.astype('float32')
    if image_shape[0] == 1:
        resized_image = resized_image / 255
        resized_image = resized_image[np.newaxis, :]
    else:
        resized_image = resized_image.transpose((2, 0, 1)) / 255
    resized_image -= 0.5
    resized_image /= 0.5
    padding_im = np.zeros((imgC, imgH, imgW), dtype=np.float32)
    padding_im[:, :, 0:resized_w] = resized_image
    valid_ratio = min(1.0, float(resized_w / imgW))
    return padding_im, valid_ratio


class SVTRResize(object):
    """Transform operator: resize + normalize + pad."""

    def __init__(self, image_shape, padding=True, **kwargs):
        self.image_shape = image_shape
        self.padding = padding

    def __call__(self, data):
        img = data['image']
        norm_img, valid_ratio = resize_norm_img(img, self.image_shape, self.padding)
        data['image'] = norm_img
        data['valid_ratio'] = valid_ratio
        r = float(data.get('original_w', img.shape[1])) / float(data.get('original_h', img.shape[0]))
        data['real_ratio'] = max(1, round(r))
        return data


class SimpleRecTransform(object):
    """Simple torchvision-based transform for ImageFolderRecDataset."""

    def __init__(self, image_shape=(3, 32, 128), is_train=False):
        self.image_shape = image_shape
        self.is_train = is_train
        if is_train:
            self.transform = T.Compose([
                T.Resize((image_shape[1], image_shape[2])),
                T.RandomHorizontalFlip(p=0.5),
                T.RandomRotation(degrees=10),
                T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3),
                T.ToTensor(),
                T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
            ])
        else:
            self.transform = T.Compose([
                T.Resize((image_shape[1], image_shape[2])),
                T.ToTensor(),
                T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
            ])

    def __call__(self, img):
        return self.transform(img)


# ── LMDB Recognition Dataset ──────────────────────────────────────

if LMDB_AVAILABLE:
    class LMDBRecDataset(Dataset):
        """
        LMDB-based recognition dataset.
        Expected LMDB key scheme:
            image-{idx:09d}: Raw image bytes (JPEG/PNG)
            label-{idx:09d}: UTF-8 text label string
        """

        def __init__(self, lmdb_path, image_shape=(3, 32, 128),
                     label_encode=None, resize_op=None):
            self.lmdb_path = lmdb_path
            self.image_shape = image_shape
            self.label_encode = label_encode
            self.resize_op = resize_op

            self.env = lmdb.open(lmdb_path, readonly=True, create=False, readahead=False, meminit=False)
            with self.env.begin() as txn:
                self.length = txn.get(b'data/length').decode()
            self.length = int(self.length)

        def __len__(self):
            return self.length

        def __getitem__(self, idx):
            with self.env.begin() as txn:
                imgbuf = txn.get(f'image-{idx:09d}'.encode())
                label = txn.get(f'label-{idx:09d}'.encode()).decode('utf-8')

            img = np.frombuffer(imgbuf, dtype=np.uint8)
            img = cv2.imdecode(img, cv2.IMREAD_COLOR)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            data = {'image': img, 'label': label}
            data['original_h'] = img.shape[0]
            data['original_w'] = img.shape[1]

            if self.resize_op:
                data = self.resize_op(data)
            if self.label_encode:
                data = self.label_encode(data)

            if data is None:
                return self.__getitem__((idx + 1) % self.length)

            return data['image'], data['label'], data['length']
else:
    LMDBRecDataset = None


# ── OCR Recognition Dataset (txt file format) ─────────────────────

class OCRRecDataset(Dataset):
    """
    OCR recognition dataset loaded from a txt file.
    File format (1 line per sample): image_path <tab> text_label
    Example:
        data/img001.jpg    Hello World
        data/img002.jpg    12345

    Directory structure:
        dataset/
        ├── train.txt     (image paths + labels)
        ├── val.txt
        └── images/       (actual image files)
    """

    def __init__(self, txt_path, image_root='', image_shape=(3, 32, 128),
                 label_encode=None, resize_op=None):
        self.txt_path = txt_path
        self.image_root = image_root
        self.image_shape = image_shape
        self.label_encode = label_encode
        self.resize_op = resize_op

        self.images = []
        self.labels = []
        self._load_dataset()

    def _load_dataset(self):
        """Load image paths and labels from txt file."""
        if not os.path.exists(self.txt_path):
            raise FileNotFoundError(f"Dataset file not found: {self.txt_path}")

        with open(self.txt_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split('\t')
                if len(parts) >= 2:
                    img_path = parts[0].strip()
                    label = parts[1].strip()
                elif len(parts) == 1:
                    # Only image path, no label — skip or use filename
                    img_path = parts[0].strip()
                    label = ''
                else:
                    continue

                # Resolve relative paths
                if not os.path.isabs(img_path):
                    img_path = os.path.join(self.image_root, img_path)

                if os.path.exists(img_path):
                    self.images.append(img_path)
                    self.labels.append(label)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_path = self.images[idx]
        text_label = self.labels[idx]

        # Load original image as numpy HWC
        img_orig = Image.open(img_path).convert('RGB')
        orig_w, orig_h = img_orig.size
        img_np = np.array(img_orig)

        data = {'image': img_np, 'label': text_label}
        data['original_h'] = orig_h
        data['original_w'] = orig_w

        if self.resize_op:
            data = self.resize_op(data)
        if self.label_encode:
            data = self.label_encode(data)

        if data is None:
            return self.__getitem__((idx + 1) % self.length)

        return data['image'], data['label'], data['length']


# ── LMDB-backed OCR Recognition Dataset ───────────────────────────

class LMDBTxtDataset(Dataset):
    """
    OCR recognition dataset: labels from txt file, images from LMDB.
    Txt format: lmdb_idx <tab> text_label
    Example:
        33088    mpaign
        1627814  nametags

    Usage:
        dataset = LMDBTxtDataset(
            txt_path='dataset_union14m/train.txt',
            lmdb_path='D:/.../Union14M-L-LMDB-Filtered',
            image_shape=(3, 32, 128),
            label_encode=gtc_encode,
            resize_op=resize_op,
        )
    """

    def __init__(self, txt_path, lmdb_path, image_shape=(3, 32, 128),
                 label_encode=None, resize_op=None):
        self.txt_path = txt_path
        self.lmdb_path = lmdb_path
        self.image_shape = image_shape
        self.label_encode = label_encode
        self.resize_op = resize_op

        # Open LMDB
        if not LMDB_AVAILABLE:
            raise ImportError("lmdb package required for LMDBTxtDataset")
        self.env = lmdb.open(lmdb_path, readonly=True, create=False,
                             readahead=False, meminit=False, lock=False)

        # Load txt indices
        self.samples = []  # list of (lmdb_idx, label)
        self._load_dataset()

    def _load_dataset(self):
        if not os.path.exists(self.txt_path):
            raise FileNotFoundError(f"Txt file not found: {self.txt_path}")

        with open(self.txt_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split('\t')
                if len(parts) >= 2:
                    lmdb_idx = int(parts[0].strip())
                    label = parts[1].strip()
                    self.samples.append((lmdb_idx, label))
                elif len(parts) == 1:
                    lmdb_idx = int(parts[0].strip())
                    self.samples.append((lmdb_idx, ''))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        lmdb_idx, label = self.samples[idx]

        # Read image from LMDB
        img_key = f'image-{lmdb_idx:09d}'.encode()
        with self.env.begin() as txn:
            imgbuf = txn.get(img_key)

        if imgbuf is None:
            return self.__getitem__((idx + 1) % len(self))

        img = np.frombuffer(imgbuf, dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        data = {'image': img, 'label': label}
        data['original_h'] = img.shape[0]
        data['original_w'] = img.shape[1]

        if self.resize_op:
            data = self.resize_op(data)
        if self.label_encode:
            data = self.label_encode(data)

        if data is None:
            return self.__getitem__((idx + 1) % len(self))

        return data['image'], data['label'], data['length']


def rec_collate_fn(batch):
    """
    Collate function for recognition dataloader.
    Input batch: [(image_tensor, label_str, length_int), ...]
    Output for training: [image, ctc_label, ctc_length, label_subs, length_subs, label_next,
                          label_subs_pre, length_subs_pre, label, length, ...]
    """
    images = []
    label_strs = []
    lengths = []

    for item in batch:
        img, label_str, length = item
        images.append(img)
        label_strs.append(label_str)
        lengths.append(length)

    # Stack images
    images = torch.stack(images, dim=0)

    # Return in the order expected by GTCLoss/GTCDecoder:
    # batch = [image, label, label_subs, label_next, length_subs,
    #          label_subs_pre, length_subs_pre, length, ctc_label, ctc_length]
    return [images, label_strs, lengths]
