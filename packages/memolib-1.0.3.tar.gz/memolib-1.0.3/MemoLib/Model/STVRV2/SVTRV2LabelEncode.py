"""
Label encoding for SVTRV2 OCR recognition.
- BaseRecLabelEncode (base class with character dict loading)
- CTCLabelEncode (CTC-style label encoding with blank token)
- SMTRLabelEncode (SMTR sub-string encoding for GTC decoder)
- GTCLabelEncode (wraps SMTR + CTC encoders)
"""

import re
import copy
import random
import numpy as np


class BaseRecLabelEncode(object):
    """Convert between text-label and text-index."""

    def __init__(self, max_text_length, character_dict_path=None,
                 use_space_char=False, lower=False):
        self.max_text_len = max_text_length
        self.beg_str = 'sos'
        self.end_str = 'eos'
        self.lower = lower
        self.reverse = False
        if character_dict_path is None:
            self.character_str = '0123456789abcdefghijklmnopqrstuvwxyz'
            dict_character = list(self.character_str)
            self.lower = True
        else:
            self.character_str = []
            with open(character_dict_path, 'rb') as fin:
                lines = fin.readlines()
                for line in lines:
                    line = line.decode('utf-8').strip('\n').strip('\r\n')
                    self.character_str.append(line)
            if use_space_char:
                self.character_str.append(' ')
            dict_character = list(self.character_str)
            if 'arabic' in character_dict_path:
                self.reverse = True
        dict_character = self.add_special_char(dict_character)
        self.dict = {}
        for i, char in enumerate(dict_character):
            self.dict[char] = i
        self.character = dict_character

    def label_reverse(self, text):
        text_re = []
        c_current = ''
        for c in text:
            if not bool(re.search('[a-zA-Z0-9 :*./%+١٢٣٤٥٦٧٨٩٠-]', c)):
                if c_current != '':
                    text_re.append(c_current)
                text_re.append(c)
                c_current = ''
            else:
                c_current += c
        if c_current != '':
            text_re.append(c_current)
        return ''.join(text_re[::-1])

    def add_special_char(self, dict_character):
        return dict_character

    def encode(self, text):
        if len(text) == 0:
            return None
        if self.lower:
            text = text.lower()
        text_list = []
        for char in text:
            if char not in self.dict:
                continue
            text_list.append(self.dict[char])
        if len(text_list) == 0 or len(text_list) > self.max_text_len:
            return None
        return text_list


class CTCLabelEncode(BaseRecLabelEncode):
    """Convert between text-label and text-index (CTC style)."""

    def __init__(self, max_text_length, character_dict_path=None,
                 use_space_char=False, **kwargs):
        super(CTCLabelEncode, self).__init__(max_text_length, character_dict_path,
                                             use_space_char)
        self.is_reverse = kwargs.get('is_reverse', False)

    def __call__(self, data):
        text = data['label']
        if self.reverse and self.is_reverse:
            text = self.label_reverse(text)
        text = self.encode(text)
        if text is None:
            return None
        data['length'] = np.array(len(text))
        text = text + [0] * (self.max_text_len - len(text))
        data['label'] = np.array(text)
        label = [0] * len(self.character)
        for x in text:
            label[x] += 1
        data['label_ace'] = np.array(label)
        return data

    def add_special_char(self, dict_character):
        dict_character = ['blank'] + dict_character
        return dict_character


class SMTRLabelEncode(BaseRecLabelEncode):
    """Convert between text-label and text-index (SMTR sub-string style)."""

    BOS = '<s>'
    EOS = '</s>'
    IN_F = '<INF>'  # ignore forward
    IN_B = '<INB>'  # ignore backward
    PAD = '<pad>'

    def __init__(self, max_text_length, character_dict_path=None,
                 use_space_char=False, sub_str_len=5, **kwargs):
        super(SMTRLabelEncode, self).__init__(max_text_length, character_dict_path,
                                              use_space_char)
        self.substr_len = sub_str_len
        self.rang_subs = [i for i in range(1, self.substr_len + 1)]
        self.idx_char = [i for i in range(1, self.num_character - 5)]

    def __call__(self, data):
        text = data['label']
        text = self.encode(text)
        if text is None:
            return None
        if len(text) > self.max_text_len:
            return None

        data['length'] = np.array(len(text))
        text_in = [self.dict[self.IN_F]] * (self.substr_len) + text + [
            self.dict[self.IN_B]
        ] * (self.substr_len)

        sub_string_list_pre = []
        next_label_pre = []
        sub_string_list = []
        next_label = []
        for i in range(self.substr_len, len(text_in) - self.substr_len):
            sub_string_list.append(text_in[i - self.substr_len:i])
            next_label.append(text_in[i])
            if self.substr_len - i == 0:
                sub_string_list_pre.append(text_in[-i:])
            else:
                sub_string_list_pre.append(text_in[-i:self.substr_len - i])
            next_label_pre.append(text_in[-(i + 1)])

        sub_string_list.append(
            [self.dict[self.IN_F]] * (self.substr_len - len(text[-self.substr_len:])) +
            text[-self.substr_len:])
        next_label.append(self.dict[self.EOS])
        sub_string_list_pre.append(
            text[:self.substr_len] + [self.dict[self.IN_B]] *
            (self.substr_len - len(text[:self.substr_len])))
        next_label_pre.append(self.dict[self.EOS])

        # Data augmentation: random perturbation of sub-strings
        for sstr, l in zip(sub_string_list[self.substr_len:], next_label[self.substr_len:]):
            id_shu = np.random.choice(self.rang_subs, 2)
            sstr1 = copy.deepcopy(sstr)
            sstr1[id_shu[0] - 1] = random.randint(1, self.num_character - 5)
            if sstr1 not in sub_string_list:
                sub_string_list.append(sstr1)
                next_label.append(l)
            sstr[id_shu[1] - 1] = random.randint(1, self.num_character - 5)

        for sstr, l in zip(sub_string_list_pre[self.substr_len:], next_label_pre[self.substr_len:]):
            id_shu = np.random.choice(self.rang_subs, 2)
            sstr1 = copy.deepcopy(sstr)
            sstr1[id_shu[0] - 1] = random.randint(1, self.num_character - 5)
            if sstr1 not in sub_string_list_pre:
                sub_string_list_pre.append(sstr1)
                next_label_pre.append(l)
            sstr[id_shu[1] - 1] = random.randint(1, self.num_character - 5)

        data['length_subs'] = np.array(len(sub_string_list))
        sub_string_list = sub_string_list + [[self.dict[self.PAD]] * self.substr_len] * \
                          ((self.max_text_len * 2) + 2 - len(sub_string_list))
        next_label = next_label + [self.dict[self.PAD]] * ((self.max_text_len * 2) + 2 - len(next_label))
        data['label_subs'] = np.array(sub_string_list)
        data['label_next'] = np.array(next_label)

        data['length_subs_pre'] = np.array(len(sub_string_list_pre))
        sub_string_list_pre = sub_string_list_pre + [[self.dict[self.PAD]] * self.substr_len] * \
                              ((self.max_text_len * 2) + 2 - len(sub_string_list_pre))
        next_label_pre = next_label_pre + [self.dict[self.PAD]] * ((self.max_text_len * 2) + 2 - len(next_label_pre))
        data['label_subs_pre'] = np.array(sub_string_list_pre)
        data['label_next_pre'] = np.array(next_label_pre)

        text = [self.dict[self.BOS]] + text + [self.dict[self.EOS]]
        text = text + [self.dict[self.PAD]] * (self.max_text_len + 2 - len(text))
        data['label'] = np.array(text)
        return data

    def add_special_char(self, dict_character):
        dict_character = [self.EOS] + dict_character + [self.BOS, self.IN_F, self.IN_B, self.PAD]
        self.num_character = len(dict_character)
        return dict_character


class GTCLabelEncode():
    """Wraps SMTR + CTC label encoders."""

    def __init__(self, gtc_label_encode, max_text_length, character_dict_path=None,
                 use_space_char=False, **kwargs):
        self.gtc_label_encode = SMTRLabelEncode(
            max_text_length=max_text_length,
            character_dict_path=character_dict_path,
            use_space_char=use_space_char,
            **gtc_label_encode)
        self.ctc_label_encode = CTCLabelEncode(
            max_text_length, character_dict_path, use_space_char)

    def __call__(self, data):
        data_ctc = self.ctc_label_encode({'label': data['label']})
        data = self.gtc_label_encode(data)
        if data_ctc is None or data is None:
            return None
        data['ctc_label'] = data_ctc['label']
        data['ctc_length'] = data_ctc['length']
        return data
