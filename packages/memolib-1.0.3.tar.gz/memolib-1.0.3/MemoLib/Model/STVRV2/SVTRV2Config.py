from dataclasses import dataclass, field
from typing import ClassVar
from os import path
from ..BaseModel.eModelBase import eOptimizerType


@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ImageSizeH:           int   = 32
    ImageSizeW:           int   = 128
    Dims:                 list  = None       # [128, 256, 384]
    Depths:               list  = None       # [6, 6, 6]
    Num_heads:            list  = None       # [4, 8, 12]
    DropoutRate:          float = 0.1
    DropPathRate:         float = 0.1

    # ── Training ─────────────────────────────────
    Epochs:               int   = 30
    BatchSize:            int   = 32
    LearningRate:         float = 1.25e-5
    WeightDecay:          float = 0.05
    OptimizerType:        str   = eOptimizerType.AdamW
    Patience:             int   = 5

    # ── Warmup ───────────────────────────────────
    WarmupEpochs:         int   = 5
    WarmupLearningRate:   float = None

    # ── Layers ───────────────────────────────────
    FreezeLayers:         int   = -1
    UnfreezeLayers:       int   = -1

    # ── DataPaths ────────────────────────────────
    DatasetPath:          str   = ""
    LmdbPath:             str   = ""        # LMDB folder (images from LMDB, labels from txt)
    PretrainedPath:       str   = path.abspath(path.join(path.dirname(__file__),
                                                          '..', '..', 'Pretrain',
                                                          'svtrv2_smtr_gtc_rctc', 'best.pth'))
    CharacterDictPath:    str   = path.abspath(path.join(path.dirname(__file__),
                                                          '..', '..', 'Pretrain',
                                                          'svtrv2_smtr_gtc_rctc',
                                                          'EN_symbol_dict.txt'))

    # ── CharacterSet ─────────────────────────────
    MaxTextLength:        int   = 25
    UseSpaceChar:         bool  = False

    # ── Augmentation ─────────────────────────────
    Saturation:           float = 0.0
    Contrast:             float = 0.0
    Brightness:           float = 0.0
    Rotation:             float = 0.0
    FlipLeftRight:        float = 0.5
    FlipUpDown:           float = 0.0
    Translation:          float = 0.0
    Shear:                float = 0.0
    Scale:                float = 0.0
    Perspective:          float = 0.0

    # ── Class variable (khong vao __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ImageSizeH", "ImageSizeW", "Dims", "Depths",
                         "Num_heads", "DropoutRate", "DropPathRate"],
        "Training":     ["Epochs", "BatchSize", "LearningRate",
                         "WeightDecay", "OptimizerType", "Patience"],
        "Warmup":       ["WarmupLearningRate", "WarmupEpochs"],
        "Layers":       ["FreezeLayers", "UnfreezeLayers"],
        "DataPaths":    ["DatasetPath", "LmdbPath", "PretrainedPath", "CharacterDictPath"],
        "CharacterSet": ["MaxTextLength", "UseSpaceChar"],
        "Augmentation": ["Saturation", "Contrast", "Brightness", "Rotation",
                         "FlipLeftRight", "FlipUpDown", "Translation", "Shear",
                         "Scale", "Perspective"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        if self.Dims is None:
            object.__setattr__(self, "Dims", [128, 256, 384])
        if self.Depths is None:
            object.__setattr__(self, "Depths", [6, 6, 6])
        if self.Num_heads is None:
            object.__setattr__(self, "Num_heads", [4, 8, 12])
        if self.WarmupLearningRate is None:
            self.WarmupLearningRate = self.LearningRate * 0.1

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' khong thuoc category '{cat}'")
