"""
Loss functions copied from OpenOCR for SVTRV2 GTC recognition.
- CTCLoss (CTC loss with blank=0)
- SMTRLoss (passes through SMTR loss dict from decoder)
- GTCLoss (combined CTC + SMTR loss)
"""

import torch
from torch import nn


class CTCLoss(nn.Module):

    def __init__(self, use_focal_loss=False, zero_infinity=False, **kwargs):
        super(CTCLoss, self).__init__()
        self.loss_func = nn.CTCLoss(blank=0, reduction='none', zero_infinity=zero_infinity)
        self.use_focal_loss = use_focal_loss

    def forward(self, predicts, batch):
        batch_size = predicts.size(0)
        label, label_length = batch[1], batch[2]
        predicts = predicts.log_softmax(2)
        predicts = predicts.permute(1, 0, 2)
        preds_lengths = torch.tensor([predicts.size(0)] * batch_size, dtype=torch.long, device=predicts.device)
        loss = self.loss_func(predicts, label, preds_lengths, label_length)

        if self.use_focal_loss:
            clamped_loss = torch.clamp(loss, min=-20, max=20)
            weight = 1 - torch.exp(-clamped_loss)
            weight = torch.square(weight)
            loss = torch.where(weight > 0, loss * weight, loss)
        loss = loss.mean()
        return {'loss': loss}


class SMTRLoss(nn.Module):

    def __init__(self, **kwargs):
        super(SMTRLoss, self).__init__()

    def forward(self, predicts, batch):
        if isinstance(predicts, list):
            predicts = predicts[0]
        return predicts


class GTCLoss(nn.Module):

    def __init__(self, gtc_loss=None, gtc_weight=1.0, ctc_weight=1.0,
                 zero_infinity=True, **kwargs):
        super(GTCLoss, self).__init__()
        self.ctc_loss = CTCLoss(zero_infinity=zero_infinity)
        self.gtc_loss = SMTRLoss() if gtc_loss is None else SMTRLoss(**gtc_loss)
        self.gtc_weight = gtc_weight
        self.ctc_weight = ctc_weight

    def forward(self, predicts, batch):
        ctc_loss = self.ctc_loss(predicts['ctc_pred'], [None] + batch[-2:])['loss']
        gtc_loss = self.gtc_loss(predicts['gtc_pred'], batch[:-2])['loss']
        return {
            'loss': self.ctc_weight * ctc_loss + self.gtc_weight * gtc_loss,
            'ctc_loss': ctc_loss,
            'gtc_loss': gtc_loss
        }
