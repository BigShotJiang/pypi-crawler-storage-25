"""
SVTRV2 OCR Recognition Model - Full GTC pipeline.
Encoder: SVTRv2LNConvTwo33 (hybrid Conv+Transformer)
Decoder: GTCDecoder = SMTRDecoder (autoregressive) + RCTCDecoder (CTC)
Loss: GTCLoss = 0.1*CTCLoss + 1.0*SMTRLoss
"""

import torch.nn as nn
from os import path, makedirs
import torch
from torch import optim
from threading import Thread, Event
from torch.utils.data import DataLoader
import datetime
import numpy as np
import traceback as tb_module

from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType, eOptimizerType
from .SVTRV2Config import TrainingConfig
from .SVTRV2Encoder import SVTRv2LNConvTwo33
from .SVTRV2Decoder import GTCDecoder, SMTRDecoder, RCTCDecoder
from .SVTRV2Loss import GTCLoss
from .SVTRV2LabelEncode import SMTRLabelEncode, CTCLabelEncode, GTCLabelEncode
from .SVTRV2Transform import SVTRResize, resize_norm_img, OCRRecDataset, LMDBTxtDataset, rec_collate_fn


class SVTRV2(IModel):

    @property
    def IsTraining(self):
        return self._isTraining
    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining
    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg               = TrainingConfig()
        self._isTraining       = False
        self._isStopTraining   = False
        self.StopTrainingEvent = Event()
        self.model             = None
        self.callbacks         = None
        self.ClassesNumber     = 0  # vocab_size for recognition
        self.ProcessName       = ""
        self.Device            = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file         = None

    # ── Helpers ───────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    @staticmethod
    def _count_params(model):
        total = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return trainable, total

    # ── Build model components ────────────────────────────────────────
    def _build_encoder(self):
        """Build SVTRv2LNConvTwo33 encoder."""
        model_params = self.cfg.get_by_category("ModelParams")
        dims = model_params["Dims"]
        depths = model_params["Depths"]
        num_heads = model_params["Num_heads"]
        dropout_rate = model_params["DropoutRate"]
        drop_path_rate = model_params["DropPathRate"]
        image_size_h = model_params["ImageSizeH"]
        image_size_w = model_params["ImageSizeW"]

        mixer = [
            ['Conv', 'Conv', 'Conv', 'Conv', 'Conv', 'Conv'],
            ['Conv', 'Conv', 'FGlobal', 'Global', 'Global', 'Global'],
            ['Global', 'Global', 'Global', 'Global', 'Global', 'Global'],
        ]
        local_k = [[5, 5], [5, 5], [-1, -1]]
        sub_k = [[1, 1], [2, 1], [-1, -1]]

        encoder = SVTRv2LNConvTwo33(
            max_sz=[image_size_h, image_size_w],
            in_channels=3,
            out_channels=dims[-1],
            depths=depths,
            dims=dims,
            num_heads=num_heads,
            mixer=mixer,
            local_k=local_k,
            sub_k=sub_k,
            use_pos_embed=False,
            last_stage=False,
            feat2d=True,
            drop_rate=dropout_rate,
            drop_path_rate=drop_path_rate,
        )
        return encoder

    def _build_decoder(self, vocab_size):
        """Build GTCDecoder with SMTR + CTC sub-decoders."""
        model_params = self.cfg.get_by_category("ModelParams")
        dims = model_params["Dims"]
        image_size_h = model_params["ImageSizeH"]
        image_size_w = model_params["ImageSizeW"]
        max_text_length = self.cfg.MaxTextLength
        drop_path_rate = model_params["DropPathRate"]

        in_channels = dims[-1]  # 384

        smtr_config = {
            'in_channels': in_channels,
            'out_channels': vocab_size,
            'num_layer': 1,
            'drop_path_rate': drop_path_rate,
            'max_len': max_text_length,
            'vis_seq': (image_size_w // 4) * (image_size_h // 4),
            'ds': False,
            'pos2d': True,
            'max_size': [image_size_h // 4, image_size_w // 4],
            'sub_str_len': 5,
            'next_mode': True,
        }
        gtc_decoder = SMTRDecoder(**smtr_config)

        rctc_config = {
            'in_channels': in_channels,
            'out_channels': vocab_size,
        }
        ctc_decoder = RCTCDecoder(**rctc_config)

        decoder = GTCDecoder(
            in_channels=in_channels,
            gtc_decoder=gtc_decoder,
            ctc_decoder=ctc_decoder,
            detach=True,
            infer_gtc=False,
            out_channels=vocab_size,
        )
        return decoder

    def _build_model(self, vocab_size):
        """Build full SVTRV2 recognition model."""
        encoder = self._build_encoder()
        decoder = self._build_decoder(vocab_size)
        model = SVTRV2RecognitionModel(encoder, decoder)
        return model

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        data_params = self.cfg.get_by_category("DataPaths")

        if weightPath is None or weightPath == "":
            weightPath = data_params["PretrainedPath"]

        # Use the vocab_size from label encoding
        vocab_size = self.ClassesNumber
        if vocab_size == 0:
            vocab_size = 6625  # default OpenOCR vocab size

        model = self._build_model(vocab_size)

        if weightPath and path.exists(weightPath):
            state_dict = self._load_checkpoint(weightPath, self.Device)
            model.load_state_dict(state_dict, strict=False)
            self._write_log(f"Loaded pretrained weights from: {weightPath}")

        model.to(self.Device)
        model.eval()
        return model

    def _load_checkpoint(self, weight_path, device):
        """Load state_dict from OpenOCR checkpoint format."""
        ckpt = torch.load(weight_path, map_location=device, weights_only=True)

        if isinstance(ckpt, dict) and "state_dict" in ckpt:
            sd = ckpt["state_dict"]
            # Strip 'encoder.' and 'decoder.' prefixes
            state_dict = {}
            for k, v in sd.items():
                key = k
                if key.startswith("encoder."):
                    key = key[len("encoder."):]
                elif key.startswith("decoder."):
                    key = key[len("decoder."):]
                state_dict[key] = v
            return state_dict

        return ckpt if isinstance(ckpt, dict) else {}

    # ── Label encoding setup ──────────────────────────────────────────
    def _setup_label_encode(self):
        """Setup GTC label encoder based on config."""
        data_params = self.cfg.get_by_category("DataPaths")
        char_params = self.cfg.get_by_category("CharacterSet")

        max_text_length = char_params["MaxTextLength"]
        use_space_char = char_params["UseSpaceChar"]
        character_dict_path = data_params["CharacterDictPath"]

        gtc_encode = GTCLabelEncode(
            gtc_label_encode={'name': 'SMTRLabelEncode'},
            max_text_length=max_text_length,
            character_dict_path=character_dict_path,
            use_space_char=use_space_char,
        )
        return gtc_encode

    # ── Build vocabulary size from character dict ─────────────────────
    def _get_vocab_size(self):
        """Get vocabulary size from character dict or use default."""
        data_params = self.cfg.get_by_category("DataPaths")
        character_dict_path = data_params["CharacterDictPath"]

        if character_dict_path and path.exists(character_dict_path):
            chars = []
            with open(character_dict_path, 'rb') as f:
                lines = f.readlines()
                for line in lines:
                    chars.append(line.decode('utf-8').strip('\n').strip('\r\n'))
            # SMTR adds: EOS + chars + BOS + IN_F + IN_B + PAD
            vocab_size = len(chars) + 6  # EOS, BOS, IN_F, IN_B, PAD + blank from CTC
            return vocab_size
        else:
            return 6625  # default OpenOCR vocab size

    # ── Optimizer ─────────────────────────────────────────────────────
    def _build_optimizer(self, parameters, use_warmup_lr: bool = False):
        train_params = self.cfg.get_by_category("Training")
        warmup_params = self.cfg.get_by_category("Warmup")

        lr = warmup_params["WarmupLearningRate"] if use_warmup_lr else train_params["LearningRate"]
        weight_decay = train_params["WeightDecay"]

        optimizer_type = train_params["OptimizerType"]
        if optimizer_type == eOptimizerType.Adam:
            return optim.Adam(parameters, lr=lr, weight_decay=weight_decay)
        elif optimizer_type == eOptimizerType.AdamW:
            return optim.AdamW(parameters, lr=lr, weight_decay=weight_decay)
        elif optimizer_type == eOptimizerType.SGD:
            momentum = train_params.get("Momentum", 0.9)
            return optim.SGD(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)
        elif optimizer_type == eOptimizerType.RMSprop:
            momentum = train_params.get("Momentum", 0.9)
            return optim.RMSprop(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)
        else:
            raise ValueError(f"OptimizerType khong hop le: {optimizer_type}")

    def _get_current_lr(self, optimizer):
        return optimizer.param_groups[0]['lr']

    # ── Train ─────────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining = True
            self.callbacks = callbacks
            self.StopTrainingEvent.clear()

            model_params = self.cfg.get_by_category("ModelParams")
            data_params = self.cfg.get_by_category("DataPaths")
            train_params = self.cfg.get_by_category("Training")
            layer_params = self.cfg.get_by_category("Layers")
            char_params = self.cfg.get_by_category("CharacterSet")

            # ── ProcessName ───────────────────────────────────────
            self.ProcessName = f"SVTRV2_rec_{model_params['Dims']}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # ── Dataset ───────────────────────────────────────────
            dataset_path = data_params["DatasetPath"]
            train_txt = path.join(dataset_path, "train.txt")
            val_txt = path.join(dataset_path, "val.txt")

            if not path.exists(train_txt):
                raise FileNotFoundError(f"Khong tim thay file train: {train_txt}")
            if not path.exists(val_txt):
                raise FileNotFoundError(f"Khong tim thay file val: {val_txt}")

            # ── Setup label encode & vocab ────────────────────────
            gtc_encode = self._setup_label_encode()
            vocab_size = self._get_vocab_size()
            self.ClassesNumber = vocab_size
            self._write_log(f"Vocab size: {vocab_size}")
            self._write_log(f"Max text length: {char_params['MaxTextLength']}")

            # ── Resize transform ──────────────────────────────────
            image_shape = (3, model_params["ImageSizeH"], model_params["ImageSizeW"])
            resize_op = SVTRResize(image_shape=image_shape, padding=True)

            # ── Datasets ──────────────────────────────────────────
            lmdb_path = data_params.get("LmdbPath", "")
            if lmdb_path:
                # LMDB-backed: images from LMDB, labels from txt
                train_dataset = LMDBTxtDataset(
                    txt_path=train_txt,
                    lmdb_path=lmdb_path,
                    image_shape=(3, image_shape[0], image_shape[1]),
                    label_encode=gtc_encode,
                    resize_op=resize_op,
                )
                val_dataset = LMDBTxtDataset(
                    txt_path=val_txt,
                    lmdb_path=lmdb_path,
                    image_shape=(3, image_shape[0], image_shape[1]),
                    label_encode=gtc_encode,
                    resize_op=resize_op,
                )
            else:
                # File-based: images from disk
                train_dataset = OCRRecDataset(
                    txt_path=train_txt,
                    image_root=dataset_path,
                    image_shape=(3, image_shape[0], image_shape[1]),
                    label_encode=gtc_encode,
                    resize_op=resize_op,
                )
                val_dataset = OCRRecDataset(
                    txt_path=val_txt,
                    image_root=dataset_path,
                    image_shape=(3, image_shape[0], image_shape[1]),
                    label_encode=gtc_encode,
                    resize_op=resize_op,
                )

            self.TrainLoader = DataLoader(
                train_dataset,
                batch_size=train_params["BatchSize"],
                shuffle=True,
                num_workers=0,
                pin_memory=True,
                collate_fn=rec_collate_fn,
            )
            self.ValLoader = DataLoader(
                val_dataset,
                batch_size=train_params["BatchSize"],
                shuffle=False,
                num_workers=0,
                pin_memory=True,
                collate_fn=rec_collate_fn,
            )

            # ── Save folder ───────────────────────────────────────
            save_folder = path.join("TrainResult", self.ProcessName)
            makedirs(save_folder, exist_ok=True)

            # ── Open log file ─────────────────────────────────────
            self._log_file = open(path.join(save_folder, "training.log"), 'w')

            # ── Build model ───────────────────────────────────────
            self.model = self._build_model(vocab_size)

            # ── Load pretrained weights ───────────────────────────
            pretrained_path = data_params["PretrainedPath"]
            if pretrained_path and path.exists(pretrained_path):
                state_dict = self._load_checkpoint(pretrained_path, self.Device)
                self.model.load_state_dict(state_dict, strict=False)
                self._write_log(f"Loaded pretrained: {pretrained_path}")

            # ── Freeze layers ─────────────────────────────────────
            freeze_layers = layer_params["FreezeLayers"]
            if freeze_layers == -1:
                for param in self.model.encoder.parameters():
                    param.requires_grad = False
            elif freeze_layers > 0:
                for i, (_, param) in enumerate(self.model.encoder.parameters()):
                    param.requires_grad = False
                    if i >= freeze_layers:
                        break

            # Always train decoder
            for param in self.model.decoder.parameters():
                param.requires_grad = True

            # ── Optimizer warmup (train decoder only) ─────────────
            self.optimizer = self._build_optimizer(
                self.model.decoder.parameters(), use_warmup_lr=True
            )

            train_thread = Thread(target=self.__train_model)
            train_thread.name = "TrainThread"
            train_thread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)
            self._write_log(msg)

    # ── Train loop ────────────────────────────────────────────────────
    def __train_model(self):
        try:
            train_params = self.cfg.get_by_category("Training")
            warmup_params = self.cfg.get_by_category("Warmup")
            layer_params = self.cfg.get_by_category("Layers")

            num_epochs = train_params["Epochs"]
            early_stop_patience = train_params["Patience"]
            warmup_epochs = warmup_params["WarmupEpochs"]
            unfreeze_layers = layer_params["UnfreezeLayers"]

            # ── Loss ──────────────────────────────────────────────
            self.criterion = GTCLoss(gtc_weight=1.0, ctc_weight=0.1)

            # ── Visualization history ───────────────────────────
            self._train_loss_history = []
            self._train_acc_history = []
            self._val_loss_history = []
            self._val_acc_history = []
            self._train_ctc_loss_history = []
            self._train_gtc_loss_history = []

            # ── Params ────────────────────────────────────────────
            trainable, total = self._count_params(self.model)
            self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

            best_acc = 0.0
            best_val_loss = float('inf')
            early_stop_counter = 0
            scheduler = None

            for epoch in range(num_epochs):
                self._write_log(f'Epoch {epoch+1}/{num_epochs}')
                self._write_log('-' * 10)

                # ── Train ─────────────────────────────────────────
                self.model.train()
                running_loss = 0.0
                running_ctc_loss = 0.0
                running_gtc_loss = 0.0
                correct = 0
                total_samples = 0

                for batch_data in self.TrainLoader:
                    images = batch_data[0].to(self.Device)  # [B, C, H, W]
                    label_strs = batch_data[1]  # list of text strings
                    lengths = batch_data[2]  # list of int lengths

                    # Compute loss (includes forward pass internally)
                    loss_dict = self._compute_recognition_loss(images, label_strs, lengths)

                    loss = loss_dict['loss']
                    ctc_loss_val = loss_dict.get('ctc_loss', 0.0)
                    gtc_loss_val = loss_dict.get('gtc_loss', 0.0)

                    self.optimizer.zero_grad()
                    loss.backward()
                    self.optimizer.step()

                    running_loss += loss.item() * images.size(0)
                    running_ctc_loss += ctc_loss_val * images.size(0)
                    running_gtc_loss += gtc_loss_val * images.size(0)

                    # Simple accuracy: check if predicted length matches
                    total_samples += images.size(0)
                    # For recognition, we use exact match as accuracy approximation
                    if loss_dict.get('acc', 0) > 0:
                        correct += loss_dict['acc']

                epoch_loss = running_loss / len(self.TrainLoader.dataset)
                epoch_ctc_loss = running_ctc_loss / len(self.TrainLoader.dataset)
                epoch_gtc_loss = running_gtc_loss / len(self.TrainLoader.dataset)
                epoch_acc = 100 * correct / total_samples if total_samples > 0 else 0

                self._write_log(f'Train Loss: {epoch_loss:.4f} | '
                                f'CTC Loss: {epoch_ctc_loss:.4f} | '
                                f'GTC Loss: {epoch_gtc_loss:.4f} | '
                                f'Train Acc: {epoch_acc:.2f}%')

                self._train_loss_history.append(epoch_loss)
                self._train_acc_history.append(epoch_acc)
                self._train_ctc_loss_history.append(epoch_ctc_loss)
                self._train_gtc_loss_history.append(epoch_gtc_loss)

                # ── Eval ──────────────────────────────────────────
                self.model.eval()
                test_loss = 0.0
                test_correct = 0
                test_total = 0

                with torch.no_grad():
                    for batch_data in self.ValLoader:
                        images = batch_data[0].to(self.Device)
                        label_strs = batch_data[1]

                        loss_dict = self._compute_recognition_loss(images, label_strs, None)

                        test_loss += loss_dict['loss'].item() * images.size(0)
                        test_total += images.size(0)
                        if loss_dict.get('acc', 0) > 0:
                            test_correct += loss_dict['acc']

                epoch_test_loss = test_loss / len(self.ValLoader.dataset)
                test_acc = 100 * test_correct / test_total if test_total > 0 else 0

                self._write_log(f'Val Loss: {epoch_test_loss:.4f} | Val Acc: {test_acc:.2f}%')

                self._val_loss_history.append(epoch_test_loss)
                self._val_acc_history.append(test_acc)

                # ── Callback ──────────────────────────────────────
                if self.callbacks is not None:
                    self.callbacks("Info", f'Epoch {epoch+1}/{num_epochs} | '
                                           f'Val Loss: {epoch_test_loss:.4f} | '
                                           f'Val Acc: {test_acc:.2f}%')

                # ── Early stopping ────────────────────────────────
                if early_stop_patience > 0:
                    if epoch_test_loss < best_val_loss:
                        best_val_loss = epoch_test_loss
                        early_stop_counter = 0
                        self._write_log(f'Val loss improved: {best_val_loss:.4f}')
                    else:
                        early_stop_counter += 1
                        msg = f'No improvement {early_stop_counter}/{early_stop_patience}'
                        self._write_log(msg)
                        if self.callbacks is not None:
                            self.callbacks("Info", msg)
                        if early_stop_counter >= early_stop_patience:
                            msg = f'Early stopping after {early_stop_patience} epochs'
                            self._write_log(msg)
                            if self.callbacks is not None:
                                self.callbacks("Info", msg)
                            break

                # ── Save best ─────────────────────────────────────
                if test_acc > best_acc:
                    best_acc = test_acc
                    self.__save_model("best.pth")

                # ── Warmup done -> unfreeze encoder ────────────────
                if epoch + 1 == warmup_epochs:
                    if unfreeze_layers == -1:
                        for param in self.model.encoder.parameters():
                            param.requires_grad = True
                    elif unfreeze_layers > 0:
                        for param in self.model.encoder.stages[-unfreeze_layers:].parameters():
                            param.requires_grad = True

                    self.optimizer = self._build_optimizer(
                        self.model.parameters(), use_warmup_lr=False
                    )
                    scheduler = optim.lr_scheduler.CosineAnnealingLR(
                        self.optimizer, T_max=num_epochs - warmup_epochs)
                    self._write_log(f'Warmup done - unfreeze encoder, LR -> {train_params["LearningRate"]}')
                    trainable, total = self._count_params(self.model)
                    self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

                # ── Scheduler ─────────────────────────────────────
                if scheduler is not None:
                    scheduler.step()

                if self.IsStopTraining:
                    break

            # ── Finish ──────────────────────────────────────────────
            msg = f'Training done | Best Val Acc: {best_acc:.2f}%'
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

            self.__save_model("last.pth")

            if self._log_file:
                self._log_file.close()
                self._log_file = None

            if hasattr(self.model, 'cpu'):
                self.model.cpu()
            del self.model
            self.model = None
            torch.cuda.empty_cache()

            self.IsTraining = False
            self.StopTrainingEvent.set()

        except Exception as ex:
            print(f"Training error: {str(ex)}")
            self._write_log(f"Training error: {str(ex)}")
            self._write_log(tb_module.format_exc())
            if self.callbacks is not None:
                self.callbacks("Error", f"Training error: {str(ex)}")
            self.IsTraining = False

    def _compute_recognition_loss(self, images, label_strs, *args):
        """Compute GTCLoss for a recognition batch."""
        # Build label tensors from text strings using the label encoders
        model_params = self.cfg.get_by_category("ModelParams")
        char_params = self.cfg.get_by_category("CharacterSet")
        max_text_length = char_params["MaxTextLength"]
        use_space_char = char_params["UseSpaceChar"]
        character_dict_path = self.cfg.get_by_category("DataPaths")["CharacterDictPath"]

        # Encode labels
        smtr_encode = SMTRLabelEncode(
            max_text_length=max_text_length,
            character_dict_path=character_dict_path,
            use_space_char=use_space_char,
            sub_str_len=5,
        )
        ctc_encode = CTCLabelEncode(
            max_text_length=max_text_length,
            character_dict_path=character_dict_path,
            use_space_char=use_space_char,
        )

        batch_size = images.size(0)
        device = images.device

        # Encode all labels
        encoded = []
        ctc_labels = []
        ctc_lengths = []
        for txt in label_strs:
            data = {'label': txt}
            data['original_h'] = model_params["ImageSizeH"]
            data['original_w'] = model_params["ImageSizeW"]

            smtr_data = smtr_encode(data)
            ctc_data = ctc_encode({'label': txt})

            if smtr_data is None or ctc_data is None:
                # Skip invalid samples
                continue

            encoded.append(smtr_data)
            ctc_labels.append(ctc_data['label'])
            ctc_lengths.append(ctc_data['length'])

        if not encoded:
            return {'loss': torch.tensor(0.0, device=device), 'ctc_loss': 0.0, 'gtc_loss': 0.0, 'acc': 0}

        # Stack tensors
        # SMTR data keys: label_subs, label_next, length_subs,
        #                 label_subs_pre, length_subs_pre, label, length
        label_subs = torch.tensor([d['label_subs'] for d in encoded], device=device)
        label_next = torch.tensor([d['label_next'] for d in encoded], device=device)
        length_subs = torch.tensor([d['length_subs'] for d in encoded], device=device)
        label_subs_pre = torch.tensor([d['label_subs_pre'] for d in encoded], device=device)
        length_subs_pre = torch.tensor([d['length_subs_pre'] for d in encoded], device=device)
        label = torch.tensor([d['label'] for d in encoded], device=device)
        length = torch.tensor([d['length'] for d in encoded], device=device)

        ctc_label = torch.tensor(ctc_labels, device=device)
        ctc_length = torch.tensor(ctc_lengths, device=device)

        # Build batch tensor for GTCLoss:
        # [image, label, label_subs, label_next, length_subs,
        #  label_subs_pre, length_subs_pre, length, ctc_label, ctc_length]
        batch_tensor = [images, label, label_subs, label_next, length_subs,
                        label_subs_pre, length_subs_pre, length, ctc_label, ctc_length]

        # Forward pass
        outputs = self.model(images)  # {'gtc_pred': [..., logits], 'ctc_pred': [...]}

        # Compute loss
        loss_dict = self.criterion(outputs, batch_tensor)

        # Simple accuracy: count exact matches (approximate)
        acc = 0
        if 'ctc_pred' in outputs:
            # Decode CTC predictions for accuracy
            preds = outputs['ctc_pred']  # [B, W, vocab_size] or [B, W, vocab_size] softmaxed
            if preds.dim() == 3 and preds.shape[-1] > 1:
                pred_ids = preds.argmax(dim=-1)  # [B, W]
                for i in range(min(batch_size, len(label_strs))):
                    pred_seq = pred_ids[i].cpu().numpy()
                    # Remove blanks (0) and duplicates
                    cleaned = []
                    prev = -1
                    for pid in pred_seq:
                        if pid != 0 and pid != prev:
                            cleaned.append(int(pid))
                        prev = pid
                    # Map back to characters
                    pred_text = ''
                    for cid in cleaned:
                        if character_dict_path:
                            with open(character_dict_path, 'rb') as f:
                                lines = f.readlines()
                                chars = [l.decode('utf-8').strip() for l in lines]
                            if cid < len(chars):
                                pred_text += chars[cid]
                        else:
                            default_chars = '0123456789abcdefghijklmnopqrstuvwxyz'
                            if cid < len(default_chars):
                                pred_text += default_chars[cid]
                    if pred_text == label_strs[i]:
                        acc += 1

        loss_dict['acc'] = acc
        return loss_dict

    # ── Save model ────────────────────────────────────────────────────
    def __save_model(self, model_name):
        save_path = path.join("TrainResult", self.ProcessName, "Weights", model_name)
        makedirs(path.dirname(save_path), exist_ok=True)
        torch.save(self.model.state_dict(), save_path)
        self._write_log(f"Saved {model_name} to {save_path}")

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, path_to_pytorch_model: str, export_type: eModelExportType,
               export_image_size_h: int = 32, export_image_size_w: int = 128):
        temp_model = None
        try:
            self.ClassesNumber = self.ClassesNumber or 6625
            temp_model = self.LoadWeight(path_to_pytorch_model)
            path_export = path.splitext(path_to_pytorch_model)[0]
            dummy_input = torch.randn(1, 3, export_image_size_h, export_image_size_w).to(self.Device)

            if export_type == eModelExportType.ONNX:
                onnx_path = path_export + ".onnx"
                torch.onnx.export(
                    temp_model, dummy_input, onnx_path,
                    input_names=['input'],
                    output_names=['output'],
                    dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                    opset_version=13,
                )
                print(f"Exported ONNX: {onnx_path}")

            elif export_type == eModelExportType.OpenVINO:
                import openvino as ov
                onnx_path = path_export + ".onnx"
                torch.onnx.export(
                    temp_model, dummy_input, onnx_path,
                    input_names=['input'],
                    output_names=['output'],
                    dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                    opset_version=13,
                )
                ov_model = ov.convert_model(onnx_path, example_input=dummy_input)
                xml_path = onnx_path.replace(".onnx", ".xml")
                ov.save_model(ov_model, xml_path)
                print(f"Exported OpenVINO: {xml_path}")
                del ov_model

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Export error: {str(ex)}")
            raise
        finally:
            if temp_model is not None and hasattr(temp_model, 'cpu'):
                temp_model.cpu()
            del temp_model
            torch.cuda.empty_cache()

    # ── Stop ──────────────────────────────────────────────────────────
    def StopTraining(self):
        self.IsStopTraining = True
        self.StopTrainingEvent.wait()
        self.IsStopTraining = False

    def Predict(self, img):
        """Predict text from a single PIL Image."""
        if self.model is None:
            raise RuntimeError("Model not trained. Call Train() first or LoadWeight().")

        self.model.eval()
        img_np = np.array(img.convert('RGB'))
        norm_img, _ = resize_norm_img(img_np, (3, self.cfg.ImageSizeH, self.cfg.ImageSizeW))
        tensor = torch.from_numpy(norm_img).unsqueeze(0).to(self.Device)

        with torch.no_grad():
            outputs = self.model(tensor)

        # Decode CTC prediction
        ctc_pred = outputs['ctc_pred'] if isinstance(outputs, dict) else outputs
        pred_ids = ctc_pred.argmax(dim=-1)[0].cpu().numpy()

        # Get character dict
        char_dict = self._get_char_dict()

        # Remove blanks and duplicates
        text = ''
        prev = -1
        for pid in pred_ids:
            if pid != 0 and pid != prev:
                if pid < len(char_dict):
                    text += char_dict[pid]
            prev = pid
        return text

    def BatchPredict(self, batch_img):
        """Predict text from a batch of PIL Images."""
        texts = []
        for img in batch_img:
            texts.append(self.Predict(img))
        return texts

    def _get_char_dict(self):
        """Get character list from dict path."""
        character_dict_path = self.cfg.get_by_category("DataPaths")["CharacterDictPath"]
        if character_dict_path and path.exists(character_dict_path):
            with open(character_dict_path, 'rb') as f:
                lines = f.readlines()
                return [l.decode('utf-8').strip('\n').strip('\r\n') for l in lines]
        return '0123456789abcdefghijklmnopqrstuvwxyz'


class SVTRV2RecognitionModel(nn.Module):
    """Full SVTRV2 recognition model: Encoder + GTCDecoder."""

    def __init__(self, encoder, decoder):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder

    def forward(self, x, data=None):
        x = self.encoder(x)  # [B, C, H, W]
        x = self.decoder(x, data=data)  # {'gtc_pred': ..., 'ctc_pred': ...} or ctc_pred
        return x
