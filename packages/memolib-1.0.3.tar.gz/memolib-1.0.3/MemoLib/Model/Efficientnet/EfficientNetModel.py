import torch.nn as nn
from os import path, makedirs
import torch
from torch import optim
import copy
from threading import Thread, Event
from torch.utils.data import DataLoader
import datetime
import torchvision
from torchvision import transforms, datasets
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType, eOptimizerType
from ..BaseModel.eClassificationModel import eEfficientNetModel
from .EfficientNetConfig import TrainingConfig

try:
    import openvino as ov
    OPENVINO_AVAILABLE = True
except ImportError:
    OPENVINO_AVAILABLE = False

_ARCH_MAP = {
    eEfficientNetModel.B0: torchvision.models.efficientnet_b0,
    eEfficientNetModel.B1: torchvision.models.efficientnet_b1,
    eEfficientNetModel.B2: torchvision.models.efficientnet_b2,
    eEfficientNetModel.B3: torchvision.models.efficientnet_b3,
    eEfficientNetModel.B4: torchvision.models.efficientnet_b4,
    eEfficientNetModel.B5: torchvision.models.efficientnet_b5,
    eEfficientNetModel.B6: torchvision.models.efficientnet_b6,
    eEfficientNetModel.B7: torchvision.models.efficientnet_b7,
}

class EfficientNet(IModel):

    @property
    def IsTraining(self):
        return self._isTraining
    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining
    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg              = TrainingConfig()
        self._isTraining      = False
        self._isStopTraining  = False
        self.StopTrainingEvent = Event()
        self.model            = None
        self.callbacks        = None
        self.ClassesNumber    = 0
        self.ProcessName      = ""
        self.Device           = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file        = None

    # ── Helpers ───────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    @staticmethod
    def _count_params(model):
        total = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return trainable, total

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        model_params = self.cfg.get_by_category("ModelParams")
        data_params  = self.cfg.get_by_category("DataPaths")

        # Nếu không truyền weightPath thì lấy từ config
        if weightPath is None or weightPath == "":
            weightPath = data_params["PretrainedPath"]

        isUsePretrained       = model_params["IsUsePretrained"]
        dropoutOutputBackbone = model_params["DropoutOuputBackbone"]
        architecture          = model_params["Architecture"]

        builder = _ARCH_MAP.get(architecture)
        if builder is None:
            raise ValueError(f"Architecture không hợp lệ: {architecture}")

        weights = torchvision.models.get_weight(
            f"EfficientNet_{architecture.name}_Weights.IMAGENET1K_V1"
        ) if isUsePretrained else None

        model = builder(weights=weights)
        model.classifier = nn.Sequential(
            nn.Dropout(p=dropoutOutputBackbone),
            nn.Linear(model.classifier[1].in_features, self.ClassesNumber)
        )

        if weightPath and path.exists(weightPath):
            model.load_state_dict(torch.load(weightPath, map_location=self.Device))

        model.to(self.Device)
        model.eval()
        return model

    # ── Augmentation ──────────────────────────────────────────────────
    def PrepareAugmentation(self):
        aug_params   = self.cfg.get_by_category("Augmentation")
        model_params = self.cfg.get_by_category("ModelParams")
        imageSize    = model_params["ImageSize"]

        train_transform = transforms.Compose([
            transforms.Resize((imageSize, imageSize)),
            transforms.RandomHorizontalFlip(p=aug_params["FlipLeftRight"]),
            transforms.RandomVerticalFlip(p=aug_params["FlipUpDown"]),
            transforms.RandomRotation(degrees=aug_params["Rotation"]),
            transforms.RandomAffine(
                degrees   = 0,
                translate = (aug_params["Translation"], aug_params["Translation"]),
                scale     = (1 - aug_params["Scale"], 1 + aug_params["Scale"]),
                shear     = aug_params["Shear"],
            ),
            transforms.ColorJitter(
                brightness = aug_params["Brightness"],
                contrast   = aug_params["Contrast"],
                saturation = aug_params["Saturation"],
            ),
            transforms.RandomPerspective(
                distortion_scale = aug_params["Perspective"],
                p                = 0.5 if aug_params["Perspective"] > 0 else 0.0,
            ),
            transforms.ToTensor(),
            transforms.Normalize(
                mean = [0.485, 0.456, 0.406],
                std  = [0.229, 0.224, 0.225],
            ),
            transforms.RandomErasing(
                p     = aug_params["Erasing"],
                scale = (0.02, 0.33),
                ratio = (0.3, 3.3),
            ),
        ])

        val_transform = transforms.Compose([
            transforms.Resize((imageSize, imageSize)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean = [0.485, 0.456, 0.406],
                std  = [0.229, 0.224, 0.225],
            ),
        ])

        return train_transform, val_transform

    # ── Optimizer ─────────────────────────────────────────────────────
    def _build_optimizer(self, parameters, use_warmup_lr: bool = False):
        trainParams    = self.cfg.get_by_category("Training")
        warmupParams   = self.cfg.get_by_category("Warmup")

        lr             = warmupParams["WarmupLearningRate"] if use_warmup_lr else trainParams["LearningRate"]
        weight_decay   = trainParams["WeightDecay"]
        momentum       = trainParams["Momentum"]
        optimizer_type = trainParams["OptimizerType"]

        if optimizer_type == eOptimizerType.Adam:
            return optim.Adam(parameters, lr=lr, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.AdamW:
            return optim.AdamW(parameters, lr=lr, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.SGD:
            return optim.SGD(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.RMSprop:
            return optim.RMSprop(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)

        else:
            raise ValueError(f"OptimizerType không hợp lệ: {optimizer_type}")

    def _get_current_lr(self, optimizer):
        return optimizer.param_groups[0]['lr']

    def _log_lr_change(self, old_lr, new_lr):
        if old_lr != new_lr:
            msg = f"Learning rate: {old_lr:.6f} -> {new_lr:.6f}"
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

    # ── Visualization ─────────────────────────────────────────────────
    def _plot_results(self, save_dir):
        """Plot train/val loss and accuracy curves → results.png."""
        if not hasattr(self, '_train_loss_history') or not self._train_loss_history:
            return

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

        epochs = range(1, len(self._train_loss_history) + 1)
        ax1.plot(epochs, self._train_loss_history, 'b-o', label='Train Loss')
        if hasattr(self, '_val_loss_history') and self._val_loss_history:
            ax1.plot(epochs, self._val_loss_history, 'r-o', label='Val Loss')
        ax1.set_xlabel('Epoch'); ax1.set_ylabel('Loss')
        ax1.legend(); ax1.grid(True)

        ax2.plot(epochs, self._train_acc_history, 'b-o', label='Train Acc')
        if hasattr(self, '_val_acc_history') and self._val_acc_history:
            ax2.plot(epochs, self._val_acc_history, 'r-o', label='Val Acc')
        ax2.set_xlabel('Epoch'); ax2.set_ylabel('Accuracy (%)')
        ax2.legend(); ax2.grid(True)

        fig.suptitle(f'{self.ProcessName}', fontsize=12)
        fig.savefig(path.join(save_dir, 'results.png'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    def _plot_confusion_matrix(self, save_dir, class_names):
        """Plot confusion matrix → confusion_matrix.png."""
        if not hasattr(self, '_all_labels') or not hasattr(self, '_all_preds'):
            return

        cm = confusion_matrix(self._all_labels, self._all_preds)
        cm_norm = cm.astype('float') / (cm.sum(axis=1)[:, np.newaxis] + 1e-8)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

        im1 = ax1.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        ax1.set_title('Confusion Matrix')
        fig.colorbar(im1, ax=ax1)
        self._set_ticklabels(ax1, class_names)
        self._annotate_cm(ax1, cm)

        im2 = ax2.imshow(cm_norm, interpolation='nearest', cmap=plt.cm.Blues)
        ax2.set_title('Normalized Confusion Matrix')
        fig.colorbar(im2, ax=ax2)
        self._set_ticklabels(ax2, class_names)
        self._annotate_cm(ax2, cm_norm, normalize=True)

        fig.savefig(path.join(save_dir, 'confusion_matrix.png'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    @staticmethod
    def _annotate_cm(ax, cm, normalize=False):
        """Annotate confusion matrix cells with values."""
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                val = cm[i, j]
                if normalize:
                    val = val * 100
                    text = f'{val:.1f}%'
                else:
                    text = str(int(val))
                color = 'white' if val > thresh else 'black'
                ax.text(j, i, text, ha='center', va='center', color=color, fontsize=8)

    @staticmethod
    def _set_ticklabels(ax, class_names):
        n = len(class_names)
        if n <= 20:
            ax.set_xticks(range(n))
            ax.set_xticklabels(class_names, rotation=45, ha='right', fontsize=6)
            ax.set_yticks(range(n))
            ax.set_yticklabels(class_names, rotation=45, ha='right', fontsize=6)

    def _save_batch_images(self, save_dir, max_batches=2):
        """Save train/val batch images with labels → train_batch*.jpg, val_batch*_labels.jpg, val_batch*_pred.jpg."""
        mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)

        # Save train batches from pre-saved history
        batch_idx = 0
        for images, labels in zip(self._train_images_history, self._train_labels_history):
            if batch_idx >= max_batches:
                break
            self._save_batch_images_helper(images, labels, save_dir, 'train', batch_idx, mean, std)
            batch_idx += 1

        # Save val batches (labels + predictions from pre-saved)
        batch_idx = 0
        for images, labels in zip(self._val_images_history, self._val_labels_history):
            if batch_idx >= max_batches:
                break
            self._save_batch_images_helper(images, labels, save_dir, 'val_labels', batch_idx, mean, std)
            # Create pred labels from pre-collected predictions
            n = min(images.size(0), 4)
            pred_labels = torch.tensor([self._all_preds[batch_idx * self.ValLoader.batch_size + i]
                                       for i in range(n)], dtype=torch.long)
            self._save_batch_images_helper(images, pred_labels, save_dir, 'val_pred', batch_idx, mean, std)
            batch_idx += 1

    def _save_batch_images_helper(self, images, labels, save_dir, prefix, batch_idx, mean, std):
        """Decode tensor images and save with class labels drawn."""
        n = min(images.size(0), 4)  # max 4 images per file
        fig, axes = plt.subplots(1, n, figsize=(n * 3, 3))
        if n == 1:
            axes = [axes]

        class_names = getattr(self, '_class_names', None)
        for i in range(n):
            img = images[i].cpu()
            img = img * std.cpu() + mean.cpu()  # denormalize (move to cpu first)
            img = img.clamp(0, 1)
            img = img.permute(1, 2, 0).numpy()
            img = (img * 255).astype(np.uint8)
            label_text = class_names[int(labels[i].cpu().item())] if class_names else str(int(labels[i].cpu().item()))
            axes[i].imshow(img)
            axes[i].set_title(label_text, fontsize=8)
            axes[i].axis('off')

        fig.suptitle(f'{prefix} batch {batch_idx}', fontsize=9)
        fig.tight_layout()
        fig.savefig(path.join(save_dir, f'{prefix}{batch_idx}.jpg'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    # ── Train ─────────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining  = True
            self.callbacks   = callbacks
            self.StopTrainingEvent.clear()

            self.Train_Transform, self.Val_Transform = self.PrepareAugmentation()

            modelParams  = self.cfg.get_by_category("ModelParams")
            dataParams   = self.cfg.get_by_category("DataPaths")
            trainParams  = self.cfg.get_by_category("Training")
            layerParams  = self.cfg.get_by_category("Layers")

            # ── ProcessName ───────────────────────────────────────
            self.ProcessName = f"EfficientNet_{modelParams['Architecture']}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # ── Dataset ───────────────────────────────────────────
            datasetPath = dataParams["DatasetPath"]
            trainPath   = path.join(datasetPath, "train")
            valPath     = path.join(datasetPath, "val")

            if not path.exists(trainPath):
                raise FileNotFoundError(f"Không tìm thấy thư mục train: {trainPath}")
            if not path.exists(valPath):
                raise FileNotFoundError(f"Không tìm thấy thư mục val: {valPath}")

            train_dataset      = datasets.ImageFolder(trainPath, transform=self.Train_Transform)
            val_dataset        = datasets.ImageFolder(valPath,   transform=self.Val_Transform)
            self.ClassesNumber = len(train_dataset.classes)

            self.TrainLoader = DataLoader(
                train_dataset,
                batch_size  = trainParams["BatchSize"],
                shuffle     = True,
                num_workers = 4,
                pin_memory  = True,
            )
            self.ValLoader = DataLoader(
                val_dataset,
                batch_size  = trainParams["BatchSize"],
                shuffle     = False,
                num_workers = 4,
                pin_memory  = True,
            )

            # ── Save folder ───────────────────────────────────────
            saveFolder = path.join("TrainResult", self.ProcessName)
            makedirs(saveFolder, exist_ok=True)

            with open(path.join(saveFolder, "classes.txt"), 'w') as f:
                f.write("\n".join(train_dataset.classes))

            # ── Open log file ─────────────────────────────────────
            self._log_file = open(path.join(saveFolder, "training.log"), 'w')

            # ── Load model ────────────────────────────────────────
            self.model = self.LoadWeight()

            # ── Freeze layers ─────────────────────────────────────
            freezeLayers = layerParams["FreezeLayers"]
            if freezeLayers == -1:
                for param in self.model.parameters():
                    param.requires_grad = False
            elif freezeLayers > 0:
                for i, (_, param) in enumerate(self.model.named_parameters()):
                    param.requires_grad = False
                    if i >= freezeLayers:
                        break

            # Luôn đảm bảo classifier được train
            for param in self.model.classifier.parameters():
                param.requires_grad = True

            # ── Optimizer warmup ──────────────────────────────────
            self.optimizer = self._build_optimizer(
                self.model.classifier.parameters(), use_warmup_lr=True
            )

            trainThread      = Thread(target=self.__train_model)
            trainThread.name = "TrainThread"
            trainThread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)

    # ── Train loop ────────────────────────────────────────────────────
    def __train_model(self):
        try:
            trainParams  = self.cfg.get_by_category("Training")
            warmupParams = self.cfg.get_by_category("Warmup")
            layerParams  = self.cfg.get_by_category("Layers")
            modelParams  = self.cfg.get_by_category("ModelParams")

            num_epochs          = trainParams["Epochs"]
            early_stop_patience = trainParams["Patience"]
            warmupEpochs        = warmupParams["WarmupEpochs"]
            unfreezeLayers      = layerParams["UnfreezeLayers"]
            imageSize           = modelParams["ImageSize"]
            isBinary            = self.ClassesNumber == 1

            criterion = nn.BCEWithLogitsLoss() if isBinary else nn.CrossEntropyLoss()

            best_acc           = 0.0
            best_val_loss      = float('inf')
            early_stop_counter = 0
            scheduler          = None

            # ── Visualization history ───────────────────────
            self._train_loss_history = []
            self._train_acc_history = []
            self._val_loss_history = []
            self._val_acc_history = []
            self._all_labels = []
            self._all_preds = []
            self._val_images_history = []
            self._val_labels_history = []
            self._train_images_history = []
            self._train_labels_history = []
            classes_file = path.join("TrainResult", self.ProcessName, "classes.txt")
            if path.exists(classes_file):
                with open(classes_file, 'r') as f:
                    self._class_names = [line.strip() for line in f if line.strip()]
            else:
                self._class_names = [f'class_{i}' for i in range(self.ClassesNumber)]

            # ── Params ────────────────────────────────────────
            trainable, total = self._count_params(self.model)
            self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

            for epoch in range(num_epochs):
                self._write_log(f'Epoch {epoch+1}/{num_epochs}')
                self._write_log('-' * 10)

                # ── Params ────────────────────────────────────────
                trainable, total = self._count_params(self.model)
                self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

                # ── Train ─────────────────────────────────────────
                self.model.train()
                running_loss = 0.0
                correct      = 0
                total        = 0

                for images, labels in self.TrainLoader:
                    images = images.to(self.Device)
                    labels = labels.to(self.Device)

                    self.optimizer.zero_grad()
                    outputs = self.model(images)

                    if isBinary:
                        outputs = outputs.squeeze(1)
                        loss    = criterion(outputs, labels.float())
                        predicted = (torch.sigmoid(outputs) > 0.5).long()
                    else:
                        loss      = criterion(outputs, labels)
                        _, predicted = torch.max(outputs, 1)

                    loss.backward()
                    self.optimizer.step()

                    running_loss += loss.item() * images.size(0)
                    total        += labels.size(0)
                    correct      += (predicted == labels).sum().item()

                    # ── Save train images (keep last 2 batches) ────────────
                    self._train_images_history.append(images.cpu())
                    self._train_labels_history.append(labels.cpu())
                    if len(self._train_images_history) > 2:
                        self._train_images_history.pop(0)
                        self._train_labels_history.pop(0)

                epoch_loss = running_loss / len(self.TrainLoader.dataset)
                epoch_acc  = 100 * correct / total
                self._write_log(f'Train Loss: {epoch_loss:.4f} | Train Acc: {epoch_acc:.2f}%')

                # ── Record history ────────────────────────────
                self._train_loss_history.append(epoch_loss)
                self._train_acc_history.append(epoch_acc)

                # ── Eval ──────────────────────────────────────────
                self.model.eval()
                test_loss = 0.0
                correct   = 0
                total     = 0

                with torch.no_grad():
                    for images, labels in self.ValLoader:
                        images = images.to(self.Device)
                        labels = labels.to(self.Device)
                        outputs = self.model(images)

                        if isBinary:
                            outputs   = outputs.squeeze(1)
                            loss      = criterion(outputs, labels.float())
                            predicted = (torch.sigmoid(outputs) > 0.5).long()
                        else:
                            loss      = criterion(outputs, labels)
                            _, predicted = torch.max(outputs, 1)

                        test_loss += loss.item() * images.size(0)
                        total     += labels.size(0)
                        correct   += (predicted == labels).sum().item()

                       # ── Collect for confusion matrix ────────────
                        self._all_labels.extend(labels.cpu().numpy().tolist())
                        self._all_preds.extend(predicted.cpu().numpy().tolist())

                       # ── Save val images (keep last 2 batches) ────────────
                        self._val_images_history.append(images.cpu())
                        self._val_labels_history.append(labels.cpu())
                        if len(self._val_images_history) > 2:
                            self._val_images_history.pop(0)
                            self._val_labels_history.pop(0)

                epoch_test_loss = test_loss / len(self.ValLoader.dataset)
                test_acc        = 100 * correct / total
                self._write_log(f'Val Loss: {epoch_test_loss:.4f} | Val Acc: {test_acc:.2f}%')

                # ── Record history ────────────────────────────
                self._val_loss_history.append(epoch_test_loss)
                self._val_acc_history.append(test_acc)

                # ── Plot results every 5 epochs ───────────────
                save_folder = path.join("TrainResult", self.ProcessName)
                if (epoch + 1) % 5 == 0 or epoch == 0:
                    self._plot_results(save_folder)

                if self.callbacks is not None:
                    self.callbacks("Info", f'Epoch {epoch+1}/{num_epochs} | '
                                           f'Val Loss: {epoch_test_loss:.4f} | '
                                           f'Val Acc: {test_acc:.2f}%')

                # ── Early stopping ────────────────────────────────
                if early_stop_patience > 0:
                    if epoch_test_loss < best_val_loss:
                        best_val_loss      = epoch_test_loss
                        early_stop_counter = 0
                        self._write_log(f'Val loss improved: {best_val_loss:.4f}')
                    else:
                        early_stop_counter += 1
                        msg = f'No improvement {early_stop_counter}/{early_stop_patience}'
                        self._write_log(msg)
                        if self.callbacks is not None:
                            self.callbacks("Info", msg)

                        if early_stop_counter >= early_stop_patience:
                            msg = f'Early stopping after {early_stop_patience} epochs'
                            self._write_log(msg)
                            if self.callbacks is not None:
                                self.callbacks("Info", msg)
                            break

                # ── Save best ─────────────────────────────────────
                if test_acc > best_acc:
                    best_acc = test_acc
                    self.__saveModel(copy.deepcopy(self.model), "best.pth")

                # ── Warmup xong -> unfreeze ────────────────────────
                if epoch + 1 == warmupEpochs:
                    if unfreezeLayers == -1:
                        for param in self.model.features.parameters():
                            param.requires_grad = True
                    elif unfreezeLayers > 0:
                        for param in self.model.features[-unfreezeLayers:].parameters():
                            param.requires_grad = True

                    self.optimizer = self._build_optimizer(
                        self.model.parameters(), use_warmup_lr=False
                    )
                    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
                        self.optimizer, mode='min', factor=0.9, patience=5
                    )
                    self._write_log(f'Warmup done — unfreeze {unfreezeLayers} layers, LR -> {trainParams["LearningRate"]}')
                    trainable, total = self._count_params(self.model)
                    self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

                # ── Scheduler ─────────────────────────────────────
                if scheduler is not None:
                    old_lr = self._get_current_lr(self.optimizer)
                    scheduler.step(epoch_test_loss)
                    new_lr = self._get_current_lr(self.optimizer)
                    self._log_lr_change(old_lr, new_lr)

                if self.IsStopTraining:
                    break

            # ── Kết thúc ──────────────────────────────────────────
            msg = f'Training done | Best Val Acc: {best_acc:.2f}%'
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

            self.__saveModel(self.model, "last.pth")

            # ── Close log file ──────────────────────────────────
            if self._log_file:
                self._log_file.close()
                self._log_file = None

            if hasattr(self.model, 'cpu'):
                self.model.cpu()
            del self.model
            self.model = None
            torch.cuda.empty_cache()

            # ── Save final visualizations (model deleted, no device conflict) ──
            save_folder = path.join("TrainResult", self.ProcessName)
            self._plot_results(save_folder)
            self._plot_confusion_matrix(save_folder, self._class_names)
            self._save_batch_images(save_folder)

            # ── Export ────────────────────────────────────────────
            weightsFolder = path.join("TrainResult", self.ProcessName, "Weights")
            for weight_file in ["last.pth", "best.pth"]:
                weight_path = path.join(weightsFolder, weight_file)
                self.Export(weight_path, eModelExportType.OpenVINO, imageSize)
                self.Export(weight_path, eModelExportType.ONNX,     imageSize)

            self.IsTraining = False
            self.StopTrainingEvent.set()

        except Exception as ex:
            print(f"Training error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Training error: {str(ex)}")
            self.IsTraining = False

    # ── Save model ────────────────────────────────────────────────────
    def __saveModel(self, model, modelName):
        savePath = path.join("TrainResult", self.ProcessName, "Weights", modelName)
        makedirs(path.dirname(savePath), exist_ok=True)
        torch.save(model.state_dict(), savePath)

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType, exportImageSize: int = 224):
        tempModel = None
        try:
            self.ClassesNumber = self.ClassesNumber or 1
            tempModel   = self.LoadWeight(pathToPytorchModel)
            pathExport  = path.splitext(pathToPytorchModel)[0]
            dummy_input = torch.randn(1, 3, exportImageSize, exportImageSize).to(self.Device)

            match exportType:
                case eModelExportType.ONNX:
                    onnxPath = pathExport + ".onnx"
                    torch.onnx.export(
                        tempModel, dummy_input, onnxPath,
                        input_names  = ['input'],
                        output_names = ['output'],
                        dynamic_axes = {'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                        opset_version = 13,
                    )
                    print(f"Exported ONNX: {onnxPath}")

                case eModelExportType.OpenVINO:
                    if not OPENVINO_AVAILABLE:
                        raise RuntimeError("OpenVINO không được cài. Chạy: pip install openvino")
                    onnxPath = pathExport + ".onnx"
                    torch.onnx.export(
                        tempModel, dummy_input, onnxPath,
                        input_names  = ['input'],
                        output_names = ['output'],
                        dynamic_axes = {'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                        opset_version = 13,
                    )
                    ov_model = ov.convert_model(onnxPath, example_input=dummy_input)
                    xmlPath = onnxPath.replace(".onnx", ".xml")
                    ov.save_model(ov_model, xmlPath)
                    print(f"Exported OpenVINO: {xmlPath}")
                    del ov_model

                case _:
                    print(f"Export type không hợp lệ: {exportType}")

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Export error: {str(ex)}")
            raise
        finally:
            if tempModel is not None and hasattr(tempModel, 'cpu'):
                tempModel.cpu()
            del tempModel
            torch.cuda.empty_cache()

    # ── Stop ──────────────────────────────────────────────────────────
    def StopTraining(self):
        self.IsStopTraining = True
        self.StopTrainingEvent.wait()
        self.IsStopTraining = False

    def Predict(self, _img): pass

    def BatchPredict(self, _batchImg): pass