from dataclasses import dataclass, field
from typing import ClassVar
from ..BaseModel.eModelBase import eOptimizerType
from ..BaseModel.eClassificationModel import eEfficientNetModel

_EFFICIENTNET_IMAGE_SIZE: dict = {
    eEfficientNetModel.B0: 224,
    eEfficientNetModel.B1: 240,
    eEfficientNetModel.B2: 260,
    eEfficientNetModel.B3: 300,
    eEfficientNetModel.B4: 380,
    eEfficientNetModel.B5: 456,
    eEfficientNetModel.B6: 528,
    eEfficientNetModel.B7: 600,
}

@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ProcessName:           str   = ""
    ImageSize:              int   = None
    Architecture:           str   = eEfficientNetModel.B0
    IsUsePretrained:        bool  = True
    DropoutOuputBackbone:   float = 0.2

    # ── Training ─────────────────────────────────
    Epochs:                 int   = 30
    BatchSize:              int   = 32
    LearningRate:           float = 0.001
    Momentum:               float = 0.9
    WeightDecay:            float = 1e-5
    OptimizerType:          str   = eOptimizerType.Adam
    Patience:               int   = 5

    # ── Warmup ───────────────────────────────────
    WarmupEpochs:           int   = 3
    WarmupLearningRate:     float = None

    # ── Layers ───────────────────────────────────
    FreezeLayers:           int   = -1
    UnfreezeLayers:         int   = 20
    UnfreezeEpochs:         int   = 10

    # ── DataPaths ────────────────────────────────
    DatasetPath:            str   = ""
    PretrainedPath:         str   = ""

    # ── Augmentation ─────────────────────────────
    Saturation:             float = 0.4
    Contrast:               float = 0.3
    Brightness:             float = 0.3
    Rotation:               float = 15.0
    Translation:            float = 0.1
    Scale:                  float = 0.2
    Shear:                  float = 5.0
    Perspective:            float = 0.0
    Erasing:                float = 0.2
    FlipUpDown:             float = 0.0
    FlipLeftRight:          float = 0.5

    # ── Class variable (không vào __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ProcessName", "ImageSize", "Architecture", "IsUsePretrained", "DropoutOuputBackbone"],
        "Training":     ["Epochs", "BatchSize", "LearningRate", "Momentum",
                         "WeightDecay", "OptimizerType", "Patience"],
        "Warmup":       ["WarmupLearningRate", "WarmupEpochs"],
        "Layers":       ["FreezeLayers", "UnfreezeLayers", "UnfreezeEpochs"],
        "DataPaths":    ["DatasetPath", "PretrainedPath"],
        "Augmentation": ["Saturation", "Contrast", "Brightness", "Rotation",
                         "Translation", "Scale", "Shear", "Perspective",
                         "Erasing", "FlipUpDown", "FlipLeftRight"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        # Flag: user có truyền ImageSize thủ công không
        object.__setattr__(self, "_image_size_overridden", self.ImageSize is not None)

        if self.ImageSize is None:
            object.__setattr__(self, "ImageSize",
                               _EFFICIENTNET_IMAGE_SIZE.get(self.Architecture, 224))

        if self.WarmupLearningRate is None:
            self.WarmupLearningRate = self.LearningRate * 0.1

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

        if name == "ImageSize":
            # Đánh dấu user đã set ImageSize thủ công
            object.__setattr__(self, "_image_size_overridden", True)

        elif name == "Architecture":
            # Chỉ tự động cập nhật ImageSize nếu chưa bị override thủ công
            if not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImageSize",
                                    _EFFICIENTNET_IMAGE_SIZE.get(value, 224))

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' không thuộc category '{cat}'")

    def reset_image_size(self):
        """ Reset ImageSize về auto theo Architecture """
        object.__setattr__(self, "_image_size_overridden", False)
        object.__setattr__(self, "ImageSize",
                           _EFFICIENTNET_IMAGE_SIZE.get(self.Architecture, 224))