import torch.nn as nn
from os import path, makedirs, sys
import torch
from torch import optim
import copy
from threading import Thread, Event
from torch.utils.data import DataLoader
import datetime
from torchvision import transforms, datasets
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType, eOptimizerType
from ..BaseModel.eClassificationModel import ePPLCNetModel
from .PPLCNetConfig import TrainingConfig

try:
    import openvino as ov
    OPENVINO_AVAILABLE = True
except ImportError:
    OPENVINO_AVAILABLE = False

# ── Import PP-LCNet from workspace ──────────────────────────────
_PP_LCNET_PATH = r"D:\Nghia\Python-Workspace\PP-LCNet"
if _PP_LCNET_PATH not in sys.path:
    sys.path.insert(0, _PP_LCNET_PATH)
from pplcnet import (
    PPLCNet_x0_25,
    PPLCNet_x0_35,
    PPLCNet_x0_5,
    PPLCNet_x0_75,
    PPLCNet_x1_0,
)

# ── Model registry ──────────────────────────────────────────────
_MODEL_MAP = {
    ePPLCNetModel.PPLCNetx25: PPLCNet_x0_25,
    ePPLCNetModel.PPLCNetx35: PPLCNet_x0_35,
    ePPLCNetModel.PPLCNetx50: PPLCNet_x0_5,
    ePPLCNetModel.PPLCNetx75: PPLCNet_x0_75,
    ePPLCNetModel.PPLCNetx100: PPLCNet_x1_0,
}



class PPLCNet(IModel):

    @property
    def IsTraining(self):
        return self._isTraining
    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining
    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg              = TrainingConfig()
        self._isTraining      = False
        self._isStopTraining  = False
        self.StopTrainingEvent = Event()
        self.model            = None
        self.callbacks        = None
        self.ClassesNumber    = 0
        self.ProcessName      = ""
        self.Device           = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file        = None

    # ── Helpers ─────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    @staticmethod
    def _count_params(model):
        total = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return trainable, total

    # ── Load weight ─────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        model_params = self.cfg.get_by_category("ModelParams")
        data_params  = self.cfg.get_by_category("DataPaths")

        if weightPath is None or weightPath == "":
            weightPath = data_params["PretrainedPath"]

        dropout_output    = model_params["DropoutOutputBackbone"]
        architecture      = model_params["Architecture"]

        builder = _MODEL_MAP.get(architecture)
        if builder is None:
            raise ValueError(f"Architecture không hợp lệ: {architecture}")

        model = builder(num_classes=self.ClassesNumber, dropout_prob=dropout_output)

        if weightPath and path.exists(weightPath):
            state_dict = torch.load(weightPath, map_location=self.Device)
            if "model_state_dict" in state_dict:
                state_dict = state_dict["model_state_dict"]
            model.load_state_dict(state_dict, strict=False)
            self._write_log(f"Loaded weights from {weightPath}")

        model.to(self.Device)
        model.eval()
        return model

    # ── Augmentation ────────────────────────────────────────────────
    def PrepareAugmentation(self):
        aug_params   = self.cfg.get_by_category("Augmentation")
        model_params = self.cfg.get_by_category("ModelParams")
        img_size     = model_params["ImageSize"]

        if isinstance(img_size, int):
            img_size = (img_size, img_size)
        h, w = img_size

        train_transform = transforms.Compose([
            transforms.Resize((h, w)),
            transforms.RandomRotation(degrees=aug_params["Rotation"], fill=0),
            transforms.ColorJitter(
                brightness=aug_params["Brightness"],
                contrast  = aug_params["Contrast"],
                saturation=aug_params["Saturation"],
            ),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

        val_transform = transforms.Compose([
            transforms.Resize((h, w)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

        return train_transform, val_transform

    # ── Optimizer ───────────────────────────────────────────────────
    def _build_optimizer(self, parameters, use_warmup_lr: bool = False):
        train_params  = self.cfg.get_by_category("Training")
        warmup_params = self.cfg.get_by_category("Warmup")

        lr        = warmup_params["WarmupLearningRate"] if use_warmup_lr else train_params["LearningRate"]
        weight_decay = train_params["WeightDecay"]
        momentum  = train_params["Momentum"]
        opt_type  = train_params["OptimizerType"]

        if opt_type == eOptimizerType.Adam:
            return optim.Adam(parameters, lr=lr, weight_decay=weight_decay)
        elif opt_type == eOptimizerType.AdamW:
            return optim.AdamW(parameters, lr=lr, weight_decay=weight_decay)
        elif opt_type == eOptimizerType.SGD:
            return optim.SGD(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)
        elif opt_type == eOptimizerType.RMSprop:
            return optim.RMSprop(parameters, lr=lr, momentum=momentum, weight_decay=weight_decay)
        else:
            raise ValueError(f"OptimizerType không hợp lệ: {opt_type}")

    def _get_current_lr(self, optimizer):
        return optimizer.param_groups[0]['lr']

    def _log_lr_change(self, old_lr, new_lr):
        if old_lr != new_lr:
            msg = f"Learning rate: {old_lr:.6f} -> {new_lr:.6f}"
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

    # ── Visualization ───────────────────────────────────────────────
    def _plot_results(self, save_dir):
        """Plot train/val loss and accuracy curves -> results.png."""
        if not hasattr(self, '_train_loss_history') or not self._train_loss_history:
            return

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

        epochs = range(1, len(self._train_loss_history) + 1)
        ax1.plot(epochs, self._train_loss_history, 'b-o', label='Train Loss')
        if hasattr(self, '_val_loss_history') and self._val_loss_history:
            ax1.plot(epochs, self._val_loss_history, 'r-o', label='Val Loss')
        ax1.set_xlabel('Epoch'); ax1.set_ylabel('Loss')
        ax1.legend(); ax1.grid(True)

        ax2.plot(epochs, self._train_acc_history, 'b-o', label='Train Acc')
        if hasattr(self, '_val_acc_history') and self._val_acc_history:
            ax2.plot(epochs, self._val_acc_history, 'r-o', label='Val Acc')
        ax2.set_xlabel('Epoch'); ax2.set_ylabel('Accuracy (%)')
        ax2.legend(); ax2.grid(True)

        fig.suptitle(f'{self.ProcessName}', fontsize=12)
        fig.savefig(path.join(save_dir, 'results.png'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    def _plot_confusion_matrix(self, save_dir, class_names):
        """Plot confusion matrix -> confusion_matrix.png."""
        if not hasattr(self, '_all_labels') or not hasattr(self, '_all_preds'):
            return

        cm = confusion_matrix(self._all_labels, self._all_preds)
        cm_norm = cm.astype('float') / (cm.sum(axis=1)[:, np.newaxis] + 1e-8)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

        im1 = ax1.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        ax1.set_title('Confusion Matrix')
        fig.colorbar(im1, ax=ax1)
        self._set_ticklabels(ax1, class_names)
        self._annotate_cm(ax1, cm)

        im2 = ax2.imshow(cm_norm, interpolation='nearest', cmap=plt.cm.Blues)
        ax2.set_title('Normalized Confusion Matrix')
        fig.colorbar(im2, ax=ax2)
        self._set_ticklabels(ax2, class_names)
        self._annotate_cm(ax2, cm_norm, normalize=True)

        fig.savefig(path.join(save_dir, 'confusion_matrix.png'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    @staticmethod
    def _annotate_cm(ax, cm, normalize=False):
        """Annotate confusion matrix cells with values."""
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                val = cm[i, j]
                if normalize:
                    val = val * 100
                    text = f'{val:.1f}%'
                else:
                    text = str(int(val))
                color = 'white' if val > thresh else 'black'
                ax.text(j, i, text, ha='center', va='center', color=color, fontsize=8)

    @staticmethod
    def _set_ticklabels(ax, class_names):
        n = len(class_names)
        if n <= 20:
            ax.set_xticks(range(n))
            ax.set_xticklabels(class_names, rotation=45, ha='right', fontsize=6)
            ax.set_yticks(range(n))
            ax.set_yticklabels(class_names, rotation=45, ha='right', fontsize=6)

    def _save_batch_images(self, save_dir, max_batches=2):
        """Save train/val batch images with labels -> train_batch*.jpg, val_batch*_labels.jpg, val_batch*_pred.jpg."""
        mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)

        batch_idx = 0
        for images, labels in zip(self._train_images_history, self._train_labels_history):
            if batch_idx >= max_batches:
                break
            self._save_batch_images_helper(images, labels, save_dir, 'train', batch_idx, mean, std)
            batch_idx += 1

        batch_idx = 0
        for images, labels in zip(self._val_images_history, self._val_labels_history):
            if batch_idx >= max_batches:
                break
            self._save_batch_images_helper(images, labels, save_dir, 'val_labels', batch_idx, mean, std)
            n = min(images.size(0), 4)
            pred_labels = torch.tensor([self._all_preds[batch_idx * self.ValLoader.batch_size + i]
                                       for i in range(n)], dtype=torch.long)
            self._save_batch_images_helper(images, pred_labels, save_dir, 'val_pred', batch_idx, mean, std)
            batch_idx += 1

    def _save_batch_images_helper(self, images, labels, save_dir, prefix, batch_idx, mean, std):
        """Decode tensor images and save with class labels drawn."""
        n = min(images.size(0), 4)
        fig, axes = plt.subplots(1, n, figsize=(n * 3, 3))
        if n == 1:
            axes = [axes]

        class_names = getattr(self, '_class_names', None)
        for i in range(n):
            img = images[i].cpu()
            img = img * std.cpu() + mean.cpu()
            img = img.clamp(0, 1)
            img = img.permute(1, 2, 0).numpy()
            img = (img * 255).astype(np.uint8)
            label_text = class_names[int(labels[i].cpu().item())] if class_names else str(int(labels[i].cpu().item()))
            axes[i].imshow(img)
            axes[i].set_title(label_text, fontsize=8)
            axes[i].axis('off')

        fig.suptitle(f'{prefix} batch {batch_idx}', fontsize=9)
        fig.tight_layout()
        fig.savefig(path.join(save_dir, f'{prefix}{batch_idx}.jpg'), dpi=150, bbox_inches='tight')
        plt.close(fig)

    # ── Train ───────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining  = True
            self.callbacks   = callbacks
            self.StopTrainingEvent.clear()

            self.Train_Transform, self.Val_Transform = self.PrepareAugmentation()

            model_params  = self.cfg.get_by_category("ModelParams")
            data_params   = self.cfg.get_by_category("DataPaths")
            train_params  = self.cfg.get_by_category("Training")

            # ── ProcessName ───────────────────────────────────
            self.ProcessName = f"PPLCNet_{model_params['Architecture']}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # ── Dataset ─────────────────────────────────────
            dataset_path = data_params["DatasetPath"]
            train_path   = path.join(dataset_path, "train")
            val_path     = path.join(dataset_path, "val")

            if not path.exists(train_path):
                raise FileNotFoundError(f"Không tìm thấy thư mục train: {train_path}")
            if not path.exists(val_path):
                raise FileNotFoundError(f"Không tìm thấy thư mục val: {val_path}")

            train_dataset = datasets.ImageFolder(train_path, transform=self.Train_Transform)
            val_dataset   = datasets.ImageFolder(val_path,   transform=self.Val_Transform)
            self.ClassesNumber = len(train_dataset.classes)

            self.TrainLoader = DataLoader(
                train_dataset,
                batch_size  = train_params["BatchSize"],
                shuffle     = True,
                num_workers = 4,
                pin_memory  = True,
            )
            self.ValLoader = DataLoader(
                val_dataset,
                batch_size  = train_params["BatchSize"],
                shuffle     = False,
                num_workers = 4,
                pin_memory  = True,
            )

            # ── Save folder ─────────────────────────────────
            save_folder = path.join("TrainResult", self.ProcessName)
            makedirs(save_folder, exist_ok=True)

            with open(path.join(save_folder, "classes.txt"), 'w') as f:
                f.write("\n".join(train_dataset.classes))

            # ── Open log file ───────────────────────────────
            self._log_file = open(path.join(save_folder, "training.log"), 'w')

            # ── Load model ──────────────────────────────────
            self.model = self.LoadWeight()

            # ── Freeze layers ───────────────────────────────
            freeze_layers = train_params.get("FreezeLayers", -1)
            if freeze_layers == -1:
                for param in self.model.parameters():
                    param.requires_grad = False
            elif freeze_layers > 0:
                for i, (_, param) in enumerate(self.model.named_parameters()):
                    param.requires_grad = False
                    if i >= freeze_layers:
                        break

            for param in self.model.classifier.parameters():
                param.requires_grad = True

            # ── Optimizer warmup ────────────────────────────
            self.optimizer = self._build_optimizer(
                self.model.classifier.parameters(), use_warmup_lr=True
            )

            train_thread = Thread(target=self.__train_model)
            train_thread.name = "TrainThread"
            train_thread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)

    # ── Train loop ──────────────────────────────────────────────────
    def __train_model(self):
        try:
            train_params  = self.cfg.get_by_category("Training")
            warmup_params = self.cfg.get_by_category("Warmup")
            model_params  = self.cfg.get_by_category("ModelParams")

            num_epochs        = train_params["Epochs"]
            early_stop_patience = train_params["Patience"]
            warmup_epochs     = warmup_params["WarmupEpochs"]
            max_grad_norm     = train_params["MaxGradNorm"]
            is_binary         = self.ClassesNumber == 1

            criterion = nn.BCEWithLogitsLoss() if is_binary else nn.CrossEntropyLoss()

            best_acc       = 0.0
            best_val_loss  = float('inf')
            early_stop_counter = 0

            # ── Visualization history ─────────────────────
            self._train_loss_history = []
            self._train_acc_history = []
            self._val_loss_history = []
            self._val_acc_history = []
            self._all_labels = []
            self._all_preds = []
            self._val_images_history = []
            self._val_labels_history = []
            self._train_images_history = []
            self._train_labels_history = []
            classes_file = path.join("TrainResult", self.ProcessName, "classes.txt")
            if path.exists(classes_file):
                with open(classes_file, 'r') as f:
                    self._class_names = [line.strip() for line in f if line.strip()]
            else:
                self._class_names = [f'class_{i}' for i in range(self.ClassesNumber)]

            # ── Params ────────────────────────────────────
            trainable, total = self._count_params(self.model)
            self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

            # ── LR Scheduler: Cosine Annealing with Warmup ──
            def lr_lambda(epoch):
                if epoch < warmup_epochs:
                    return (epoch + 1) / warmup_epochs
                else:
                    progress = (epoch - warmup_epochs) / max(num_epochs - warmup_epochs, 1)
                    return 0.5 * (1 + torch.cos(torch.tensor(progress * 3.14159)))

            scheduler = optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda=lr_lambda)

            for epoch in range(num_epochs):
                self._write_log(f'Epoch {epoch+1}/{num_epochs}')
                self._write_log('-' * 10)

                # ── Params ────────────────────────────────
                trainable, total = self._count_params(self.model)
                self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

                # ── Train ─────────────────────────────────
                self.model.train()
                running_loss = 0.0
                correct      = 0
                total        = 0

                for images, labels in self.TrainLoader:
                    images = images.to(self.Device)
                    labels = labels.to(self.Device)

                    self.optimizer.zero_grad()
                    outputs = self.model(images)

                    if is_binary:
                        outputs = outputs.squeeze(1)
                        loss    = criterion(outputs, labels.float())
                        predicted = (torch.sigmoid(outputs) > 0.5).long()
                    else:
                        loss      = criterion(outputs, labels)
                        _, predicted = torch.max(outputs, 1)

                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_grad_norm)
                    self.optimizer.step()

                    running_loss += loss.item() * images.size(0)
                    total        += labels.size(0)
                    correct      += (predicted == labels).sum().item()

                    # ── Save train images (keep last 2 batches) ─
                    self._train_images_history.append(images.cpu())
                    self._train_labels_history.append(labels.cpu())
                    if len(self._train_images_history) > 2:
                        self._train_images_history.pop(0)
                        self._train_labels_history.pop(0)

                epoch_loss = running_loss / len(self.TrainLoader.dataset)
                epoch_acc  = 100 * correct / total
                self._write_log(f'Train Loss: {epoch_loss:.4f} | Train Acc: {epoch_acc:.2f}%')

                # ── Record history ────────────────────────
                self._train_loss_history.append(epoch_loss)
                self._train_acc_history.append(epoch_acc)

                # ── Eval ──────────────────────────────────
                self.model.eval()
                test_loss = 0.0
                correct   = 0
                total     = 0

                with torch.no_grad():
                    for images, labels in self.ValLoader:
                        images = images.to(self.Device)
                        labels = labels.to(self.Device)
                        outputs = self.model(images)

                        if is_binary:
                            outputs   = outputs.squeeze(1)
                            loss      = criterion(outputs, labels.float())
                            predicted = (torch.sigmoid(outputs) > 0.5).long()
                        else:
                            loss      = criterion(outputs, labels)
                            _, predicted = torch.max(outputs, 1)

                        test_loss += loss.item() * images.size(0)
                        total     += labels.size(0)
                        correct   += (predicted == labels).sum().item()

                        # ── Collect for confusion matrix ──────
                        self._all_labels.extend(labels.cpu().numpy().tolist())
                        self._all_preds.extend(predicted.cpu().numpy().tolist())

                        # ── Save val images (keep last 2 batches) ─
                        self._val_images_history.append(images.cpu())
                        self._val_labels_history.append(labels.cpu())
                        if len(self._val_images_history) > 2:
                            self._val_images_history.pop(0)
                            self._val_labels_history.pop(0)

                epoch_test_loss = test_loss / len(self.ValLoader.dataset)
                test_acc        = 100 * correct / total
                self._write_log(f'Val Loss: {epoch_test_loss:.4f} | Val Acc: {test_acc:.2f}%')

                # ── Record history ────────────────────────
                self._val_loss_history.append(epoch_test_loss)
                self._val_acc_history.append(test_acc)

                # ── Plot results every 5 epochs ───────────
                save_folder = path.join("TrainResult", self.ProcessName)
                if (epoch + 1) % 5 == 0 or epoch == 0:
                    self._plot_results(save_folder)

                scheduler.step()

                if self.callbacks is not None:
                    self.callbacks("Info", f'Epoch {epoch+1}/{num_epochs} | '
                                           f'Val Loss: {epoch_test_loss:.4f} | '
                                           f'Val Acc: {test_acc:.2f}%')

                # ── Early stopping ────────────────────────
                if early_stop_patience > 0:
                    if epoch_test_loss < best_val_loss:
                        best_val_loss      = epoch_test_loss
                        early_stop_counter = 0
                        self._write_log(f'Val loss improved: {best_val_loss:.4f}')
                    else:
                        early_stop_counter += 1
                        msg = f'No improvement {early_stop_counter}/{early_stop_patience}'
                        self._write_log(msg)
                        if self.callbacks is not None:
                            self.callbacks("Info", msg)

                        if early_stop_counter >= early_stop_patience:
                            msg = f'Early stopping after {early_stop_patience} epochs'
                            self._write_log(msg)
                            if self.callbacks is not None:
                                self.callbacks("Info", msg)
                            break

                # ── Save best ─────────────────────────────
                if test_acc > best_acc:
                    best_acc = test_acc
                    self.__saveModel(copy.deepcopy(self.model), "best.pth")

                # ── Scheduler step ────────────────────────
                scheduler.step()

                if self.IsStopTraining:
                    break

            # ── Kết thúc ────────────────────────────────────
            msg = f'Training done | Best Val Acc: {best_acc:.2f}%'
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

            self.__saveModel(self.model, "last.pth")

            # ── Close log file ────────────────────────────
            if self._log_file:
                self._log_file.close()
                self._log_file = None

            if hasattr(self.model, 'cpu'):
                self.model.cpu()
            del self.model
            self.model = None
            torch.cuda.empty_cache()

            # ── Save final visualizations ─────────────────
            save_folder = path.join("TrainResult", self.ProcessName)
            self._plot_results(save_folder)
            self._plot_confusion_matrix(save_folder, self._class_names)
            self._save_batch_images(save_folder)

            # ── Export ────────────────────────────────────
            weights_folder = path.join("TrainResult", self.ProcessName, "Weights")
            for weight_file in ["last.pth", "best.pth"]:
                weight_path = path.join(weights_folder, weight_file)
                img_size = model_params["ImageSize"]
                if isinstance(img_size, tuple):
                    export_h, export_w = img_size
                else:
                    export_h = export_w = img_size
                self.Export(weight_path, eModelExportType.OpenVINO, (export_h, export_w))
                self.Export(weight_path, eModelExportType.ONNX,     (export_h, export_w))

            self.IsTraining = False
            self.StopTrainingEvent.set()

        except Exception as ex:
            print(f"Training error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Training error: {str(ex)}")
            self.IsTraining = False

    # ── Save model ──────────────────────────────────────────────────
    def __saveModel(self, model, model_name):
        save_path = path.join("TrainResult", self.ProcessName, "Weights", model_name)
        makedirs(path.dirname(save_path), exist_ok=True)
        torch.save(model.state_dict(), save_path)

    # ── Export ──────────────────────────────────────────────────────
    def Export(self, path_to_pytorch_model: str, export_type: eModelExportType, export_image_size=(80, 160)):
        temp_model = None
        try:
            self.ClassesNumber = self.ClassesNumber or 1
            h, w = export_image_size if isinstance(export_image_size, tuple) else (export_image_size, export_image_size)
            temp_model   = self.LoadWeight(path_to_pytorch_model)
            path_export  = path.splitext(path_to_pytorch_model)[0]
            dummy_input  = torch.randn(1, 3, h, w).to(self.Device)

            match export_type:
                case eModelExportType.ONNX:
                    onnx_path = path_export + ".onnx"
                    torch.onnx.export(
                        temp_model, dummy_input, onnx_path,
                        input_names  = ['input'],
                        output_names = ['output'],
                        dynamic_axes = {'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                        opset_version = 13,
                    )
                    print(f"Exported ONNX: {onnx_path}")

                case eModelExportType.OpenVINO:
                    if not OPENVINO_AVAILABLE:
                        raise RuntimeError("OpenVINO không được cài. Chạy: pip install openvino")
                    onnx_path = path_export + ".onnx"
                    torch.onnx.export(
                        temp_model, dummy_input, onnx_path,
                        input_names  = ['input'],
                        output_names = ['output'],
                        dynamic_axes = {'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
                        opset_version = 13,
                    )
                    ov_model = ov.convert_model(onnx_path, example_input=dummy_input)
                    xml_path = onnx_path.replace(".onnx", ".xml")
                    ov.save_model(ov_model, xml_path)
                    print(f"Exported OpenVINO: {xml_path}")
                    del ov_model

                case _:
                    print(f"Export type không hợp lệ: {export_type}")

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Export error: {str(ex)}")
            raise
        finally:
            if temp_model is not None and hasattr(temp_model, 'cpu'):
                temp_model.cpu()
            del temp_model
            torch.cuda.empty_cache()

    # ── Stop ────────────────────────────────────────────────────────
    def StopTraining(self):
        self.IsStopTraining = True
        self.StopTrainingEvent.wait()
        self.IsStopTraining = False

    def Predict(self, _img): pass

    def BatchPredict(self, _batch_img): pass
