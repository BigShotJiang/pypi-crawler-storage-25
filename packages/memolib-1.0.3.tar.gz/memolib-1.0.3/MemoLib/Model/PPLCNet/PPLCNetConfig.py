from dataclasses import dataclass, field
from typing import ClassVar, Tuple
from ..BaseModel.eModelBase import eOptimizerType
from ..BaseModel.eClassificationModel import ePPLCNetModel

_PPLCNET_IMAGE_SIZE: dict = {
    ePPLCNetModel.PPLCNetx25: (80, 160),
    ePPLCNetModel.PPLCNetx35: (80, 160),
    ePPLCNetModel.PPLCNetx50: (80, 160),
    ePPLCNetModel.PPLCNetx75: (80, 160),
    ePPLCNetModel.PPLCNetx100: (80, 160),
}


@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ProcessName:          str   = ""
    ImageSize:            Tuple[int, int] = None
    Architecture:         str   = ePPLCNetModel.PPLCNetx25
    IsUsePretrained:      bool  = True
    DropoutOutputBackbone: float = 0.0

    # ── Training ─────────────────────────────────
    Epochs:               int   = 30
    BatchSize:            int   = 32
    LearningRate:         float = 0.001
    Momentum:             float = 0.9
    WeightDecay:          float = 1e-4
    OptimizerType:        str   = eOptimizerType.AdamW
    Patience:             int   = 5
    MaxGradNorm:          float = 1.0

    # ── Warmup ───────────────────────────────────
    WarmupEpochs:         int   = 5
    WarmupLearningRate:   float = None

    # ── Layers ───────────────────────────────────
    FreezeLayers:         int   = -1
    UnfreezeLayers:       int   = -1

    # ── DataPaths ────────────────────────────────
    DatasetPath:          str   = ""
    PretrainedPath:       str   = ""

    # ── Augmentation ─────────────────────────────
    Rotation:             float = 15.0
    Brightness:           float = 0.1
    Contrast:             float = 0.1
    Saturation:           float = 0.1
    FlipLeftRight:        float = 0.0
    FlipUpDown:           float = 0.0

    # ── Class variable (không vào __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ProcessName", "ImageSize", "Architecture",
                         "IsUsePretrained", "DropoutOutputBackbone"],
        "Training":     ["Epochs", "BatchSize", "LearningRate", "Momentum",
                         "WeightDecay", "OptimizerType", "Patience", "MaxGradNorm"],
        "Warmup":       ["WarmupLearningRate", "WarmupEpochs"],
        "Layers":       ["FreezeLayers", "UnfreezeLayers"],
        "DataPaths":    ["DatasetPath", "PretrainedPath"],
        "Augmentation": ["Rotation", "Brightness", "Contrast", "Saturation",
                         "FlipLeftRight", "FlipUpDown"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        object.__setattr__(self, "_image_size_overridden", self.ImageSize is not None)

        if self.ImageSize is None:
            object.__setattr__(self, "ImageSize",
                               _PPLCNET_IMAGE_SIZE.get(self.Architecture, (80, 160)))

        if self.WarmupLearningRate is None:
            self.WarmupLearningRate = self.LearningRate * 0.1

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

        if name == "ImageSize":
            object.__setattr__(self, "_image_size_overridden", True)

        elif name == "Architecture":
            if not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImageSize",
                                    _PPLCNET_IMAGE_SIZE.get(value, (80, 160)))

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' không thuộc category '{cat}'")

    def reset_image_size(self):
        """ Reset ImageSize về auto theo Architecture """
        object.__setattr__(self, "_image_size_overridden", False)
        object.__setattr__(self, "ImageSize",
                           _PPLCNET_IMAGE_SIZE.get(self.Architecture, (80, 160)))
