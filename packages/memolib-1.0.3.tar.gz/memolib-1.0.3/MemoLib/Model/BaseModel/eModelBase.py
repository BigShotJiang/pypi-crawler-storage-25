from enum import Enum

class eModelType(Enum):
    pass

class eDetectionModelType(eModelType):
    pass

class eSegmentationModelType(eModelType):
    pass

class eClassificationModelType(eModelType):
    pass

class eRecognitionModelType(eModelType):
    pass

class eAnomalyDetectionModelType(eModelType):
    pass

class eModelExportType(Enum):
    ONNX = 0
    OpenVINO = 1
    TensorRT = 2

class eOptimizerType(Enum):
    SGD = 0
    Adam = 1
    AdamW = 2
    RMSprop = 3
    Adagrad = 4
