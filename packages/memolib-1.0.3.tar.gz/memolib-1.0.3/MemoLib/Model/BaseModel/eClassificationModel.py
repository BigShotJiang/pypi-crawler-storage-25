from MemoLib.Model.BaseModel.eModelBase import eClassificationModelType

class eYoloClassificationModel(eClassificationModelType):
    YoloV5n = 0
    YoloV5s = 1
    YoloV5m = 2
    YoloV5l = 3
    YoloV5x = 4
    YoloV8n = 5
    YoloV8s = 6
    YoloV8m = 7
    YoloV8l = 8
    YoloV8x = 9
    Yolo11n = 10
    Yolo11s = 11
    Yolo11m = 12
    Yolo11l = 13
    Yolo11x = 14
    Yolo26n = 15
    Yolo26s = 16
    Yolo26m = 17
    Yolo26l = 18
    Yolo26x = 19

class eRFDetrClassificationModel(eClassificationModelType):
    RFDETRNano = 0
    RFDETRSmall = 1
    RFDETRMedium = 2
    RFDETRLarge = 3
    RFDETRXLarge = 4
    RFDETR2XLarge = 5
    
class eEfficientNetModel(eClassificationModelType):
    B0 = 0
    B1 = 1
    B2 = 2
    B3 = 3
    B4 = 4
    B5 = 5
    B6 = 6
    B7 = 7
    V2S = 8
    V2M = 9
    V2L = 10
    V2XL = 11

class ePPLCNetModel(eClassificationModelType):
    PPLCNetx25 = 0
    PPLCNetx35 = 1
    PPLCNetx50 = 2
    PPLCNetx75 = 3
    PPLCNetx100 = 4
