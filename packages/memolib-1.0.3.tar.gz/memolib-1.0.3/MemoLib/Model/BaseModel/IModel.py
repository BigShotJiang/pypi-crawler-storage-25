from abc import ABC, abstractmethod
from .eModelBase import eModelExportType

class IModel(ABC):
    @abstractmethod
    def LoadWeight(self, weightPath: str): pass

    @abstractmethod
    def Predict(self, img): pass

    @abstractmethod
    def BatchPredict(self, batchImg): pass

    @abstractmethod
    def Train(self): pass

    @abstractmethod
    def StopTraining(self): pass

    @abstractmethod
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType): pass

    @abstractmethod
    def StopTraining(self): pass

