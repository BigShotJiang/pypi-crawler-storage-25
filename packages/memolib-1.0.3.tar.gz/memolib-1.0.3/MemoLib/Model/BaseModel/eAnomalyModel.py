from MemoLib.Model.BaseModel.eModelBase import eAnomalyDetectionModelType

class eDinomalyModel(eAnomalyDetectionModelType):
    Dinomaly_S = 0
    Dinomaly_B = 1
    Dinomaly_L = 2

class eINPFormerlyModel(eAnomalyDetectionModelType):
    INFormerly_S = 0
    INFormerly_B = 1
    INFormerly_L = 2

