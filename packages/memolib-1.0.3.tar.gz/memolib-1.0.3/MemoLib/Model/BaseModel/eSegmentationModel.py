from .eModelBase import eSegmentationModelType

class eYoloSegmentationModel(eSegmentationModelType):
    YoloV5n = 0
    YoloV5s = 1
    YoloV5m = 2
    YoloV5l = 3
    YoloV5x = 4
    YoloV8n = 5
    YoloV8s = 6
    YoloV8m = 7
    YoloV8l = 8
    YoloV8x = 9
    Yolo11n = 10
    Yolo11s = 11
    Yolo11m = 12
    Yolo11l = 13
    Yolo11x = 14
    Yolo26n = 15
    Yolo26s = 16
    Yolo26m = 17
    Yolo26l = 18
    Yolo26x = 19

class eDinoUperNetModel(eSegmentationModelType):
    DINO_S = 0
    DINO_B = 1
    DINO_L = 2

class eRFDetrSegmentationModel(eSegmentationModelType):
    RFDETRNano = 0
    RFDETRSmall = 1
    RFDETRMedium = 2
    RFDETRLarge = 3
    RFDETRXLarge = 4
    RFDETR2XLarge = 5