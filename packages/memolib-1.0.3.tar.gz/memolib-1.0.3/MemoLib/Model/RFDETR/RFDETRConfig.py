from dataclasses import dataclass, field
from typing import ClassVar, Optional
from ..BaseModel.eModelBase import eOptimizerType
from ..BaseModel.eDetectionModel import eRFDetrDetectionModel

_RFDETR_IMAGE_SIZE: dict = {
    eRFDetrDetectionModel.RFDETRNano: 384,
    eRFDetrDetectionModel.RFDETRSmall: 512,
    eRFDetrDetectionModel.RFDETRMedium: 576,
    eRFDetrDetectionModel.RFDETRLarge: 704,
    eRFDetrDetectionModel.RFDETRXLarge: 704,
    eRFDetrDetectionModel.RFDETR2XLarge: 704,
}


@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ProcessName:    str = ""
    ImageSize:      int = None
    Architecture:   eRFDetrDetectionModel = eRFDetrDetectionModel.RFDETRNano
    IsUsePretrained: bool = True
    TaskType:       str = "detect"  # detect | segment

    # ── Training ─────────────────────────────────
    Epochs:             int = 100
    BatchSize:          int = 4
    GradAccumSteps:     int = 4
    LearningRate:       float = 1e-4
    LearningRateEncoder: float = 1.5e-4
    WeightDecay:        float = 1e-4
    OptimizerType:      str = eOptimizerType.AdamW
    Patience:           int = 10
    WarmupEpochs:       float = 0.0
    ImgSize:            int = None  # override ImageSize (RFDETR resolution)
    Device:             str = ""  # empty = auto, "cuda", "cuda:0", "cpu"
    Workers:            int = 2
    Project:            str = "TrainResult"
    Name:               str = ""
    SavePeriod:         int = 10  # checkpoint interval (PTL checkpoint_interval)
    UseEma:             bool = True
    EmaDecay:           float = 0.993
    LrDrop:             int = 100
    Tensorboard:        bool = True
    Wandb:              bool = False
    MultiScale:         bool = True
    DatasetFormat:      str = ""  # empty = auto-detect, yolo | coco | roboflow

    # ── DataPaths ────────────────────────────────
    DatasetPath:    str = ""
    PretrainedPath: str = ""  # empty = use rfdetr pretrained weights from hub

    # ── Augmentation ─────────────────────────────
    DropPath:       float = 0.0
    ClassNamesFile: Optional[str] = None  # path to classes.txt

    # ── Class variable (không vào __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ProcessName", "ImageSize", "Architecture", "IsUsePretrained", "TaskType"],
        "Training":     ["Epochs", "BatchSize", "GradAccumSteps", "LearningRate",
                         "LearningRateEncoder", "WeightDecay", "OptimizerType", "Patience",
                         "WarmupEpochs", "ImgSize", "Device", "Workers", "Project", "Name",
                         "SavePeriod", "UseEma", "EmaDecay", "LrDrop", "Tensorboard",
                         "Wandb", "MultiScale", "DatasetFormat"],
        "DataPaths":    ["DatasetPath", "PretrainedPath"],
        "Augmentation": ["DropPath", "ClassNamesFile"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        object.__setattr__(self, "_image_size_overridden", self.ImageSize is not None)

        if self.ImageSize is None:
            object.__setattr__(self, "ImageSize",
                               _RFDETR_IMAGE_SIZE.get(self.Architecture, 384))

        if self.ImgSize is None:
            object.__setattr__(self, "ImgSize", self.ImageSize)

        if self.Device is None or self.Device == "":
            import torch
            if torch.cuda.is_available():
                object.__setattr__(self, "Device", "cuda")
            else:
                object.__setattr__(self, "Device", "cpu")

        if self.Name is None or self.Name == "":
            arch_name = self.Architecture.name if hasattr(self.Architecture, "name") else str(self.Architecture)
            object.__setattr__(self, "Name", f"{self.ProcessName}_{arch_name}_{self.TaskType}")

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

        if name == "ImageSize":
            object.__setattr__(self, "_image_size_overridden", True)
            if getattr(self, "ImgSize", None) is None or not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImgSize", value)

        elif name == "Architecture":
            if not getattr(self, "_image_size_overridden", False):
                size = _RFDETR_IMAGE_SIZE.get(value, 384)
                super().__setattr__("ImageSize", size)
                super().__setattr__("ImgSize", size)

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' không thuộc category '{cat}'")

    def reset_image_size(self):
        """ Reset ImageSize về auto theo Architecture """
        object.__setattr__(self, "_image_size_overridden", False)
        size = _RFDETR_IMAGE_SIZE.get(self.Architecture, 384)
        object.__setattr__(self, "ImageSize", size)
        object.__setattr__(self, "ImgSize", size)
