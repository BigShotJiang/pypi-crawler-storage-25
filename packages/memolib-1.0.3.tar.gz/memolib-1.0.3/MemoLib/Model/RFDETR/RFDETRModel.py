from os import path, makedirs
import torch
from threading import Thread, Event
import datetime
from collections import defaultdict
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType
from ..BaseModel.eDetectionModel import eRFDetrDetectionModel
from .RFDETRConfig import TrainingConfig

try:
    from rfdetr import (
        RFDETRNano,
        RFDETRSmall,
        RFDETRMedium,
        RFDETRLarge,
    )
    from rfdetr.config import SegmentationTrainConfig
    RFDETR_AVAILABLE = True
except ImportError:
    RFDETR_AVAILABLE = False

_MODEL_CLASS_MAP = {
    eRFDetrDetectionModel.RFDETRNano: RFDETRNano,
    eRFDetrDetectionModel.RFDETRSmall: RFDETRSmall,
    eRFDetrDetectionModel.RFDETRMedium: RFDETRMedium,
    eRFDetrDetectionModel.RFDETRLarge: RFDETRLarge,
    # Note: RFDETRXLarge / RFDETR2XLarge require Roboflow platform license
    # and are not available in the open-source rfdetr package.
}


class RFDETRModel(IModel):

    @property
    def IsTraining(self):
        return self._isTraining

    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining

    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg = TrainingConfig()
        self._isTraining = False
        self._isStopTraining = False
        self.StopTrainingEvent = Event()
        self.model = None           # rfdetr.RFDETR instance
        self._trainer = None        # PTL trainer reference (for stop)
        self.ClassesNumber = 0
        self.ClassesList = []
        self.ProcessName = ""
        self.Device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file = None
        self._callbacks = None

    # ── Helpers ───────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        model_params = self.cfg.get_by_category("ModelParams")
        task_type = model_params["TaskType"]
        architecture = model_params["Architecture"]
        is_pretrained = model_params["IsUsePretrained"]

        if not RFDETR_AVAILABLE:
            raise ImportError(
                "rfdetr package is not installed. "
                "Install with: pip install rfdetr"
            )

        model_cls = _MODEL_CLASS_MAP.get(architecture)
        if model_cls is None:
            raise ValueError(f"Unknown RFDETR architecture: {architecture}")

        # Build kwargs for model init
        init_kwargs = {}
        if weightPath and path.exists(weightPath):
            init_kwargs["pretrain_weights"] = weightPath
        elif weightPath:
            raise FileNotFoundError(f"Weight file không tồn tại: {weightPath}")
        elif not is_pretrained:
            init_kwargs["pretrain_weights"] = None

        self.model = model_cls(**init_kwargs)
        return self.model

    # ── Auto-detect dataset format ────────────────────────────────────
    @staticmethod
    def _detect_dataset_format(dataset_path: str) -> str:
        """Auto-detect dataset format: yolo | coco | roboflow."""
        try:
            from rfdetr.datasets.coco import is_valid_coco_dataset
            from rfdetr.datasets.yolo import is_valid_yolo_dataset
        except ImportError:
            # Fallback manual check
            coco_json = path.join(dataset_path, "train", "_annotations.coco.json")
            if path.exists(coco_json):
                return "coco"
            yaml_files = [f for f in __import__('os').listdir(dataset_path)
                          if f.startswith("data") and f.endswith((".yaml", ".yml"))]
            if yaml_files:
                return "yolo"
            return "yolo"  # default

        if is_valid_coco_dataset(dataset_path):
            return "coco"
        if is_valid_yolo_dataset(dataset_path):
            return "yolo"
        return "yolo"  # default

    # ── Build train kwargs ────────────────────────────────────────────
    def _build_train_kwargs(self):
        model_params = self.cfg.get_by_category("ModelParams")
        train_params = self.cfg.get_by_category("Training")
        aug_params = self.cfg.get_by_category("Augmentation")
        data_params = self.cfg.get_by_category("DataPaths")

        resolution = train_params["ImgSize"]
        dataset_format = train_params["DatasetFormat"]
        if not dataset_format:
            dataset_format = self._detect_dataset_format(data_params["DatasetPath"])

        kwargs = {
            "resolution": resolution,
            "epochs": train_params["Epochs"],
            "batch_size": train_params["BatchSize"],
            "grad_accum_steps": train_params["GradAccumSteps"],
            "lr": train_params["LearningRate"],
            "lr_encoder": train_params["LearningRateEncoder"],
            "weight_decay": train_params["WeightDecay"],
            "warmup_epochs": train_params["WarmupEpochs"],
            "lr_drop": train_params["LrDrop"],
            "checkpoint_interval": train_params["SavePeriod"],
            "use_ema": train_params["UseEma"],
            "ema_decay": train_params["EmaDecay"],
            "dataset_dir": path.abspath(data_params["DatasetPath"]),
            "output_dir": path.abspath(path.join(self.cfg.Project, self.ProcessName)),
            "dataset_file": dataset_format,
            "multi_scale": train_params["MultiScale"],
            "num_workers": train_params["Workers"],
            "tensorboard": train_params["Tensorboard"],
            "wandb": train_params["Wandb"],
            "drop_path": aug_params["DropPath"],
            "device": train_params["Device"],
        }

        # Class names
        if self.ClassesList:
            kwargs["class_names"] = self.ClassesList

        # Custom pretrained weights path
        pretrained_path = data_params["PretrainedPath"]
        if pretrained_path and path.exists(pretrained_path):
            kwargs["pretrain_weights"] = pretrained_path

        return kwargs

    # ── Train ─────────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining = True
            self._callbacks = callbacks
            self.StopTrainingEvent.clear()
            self._isStopTraining = False

            model_params = self.cfg.get_by_category("ModelParams")
            train_params = self.cfg.get_by_category("Training")
            data_params = self.cfg.get_by_category("DataPaths")

            task_type = model_params["TaskType"]
            dataset_path = data_params["DatasetPath"]

            # ── Validate dataset path ──
            if not dataset_path or not path.exists(dataset_path):
                raise FileNotFoundError(f"Không tìm thấy thư mục dataset: {dataset_path}")

            # Auto-detect dataset format
            dataset_format = train_params["DatasetFormat"]
            if not dataset_format:
                dataset_format = self._detect_dataset_format(dataset_path)

            # Validate dataset structure
            if dataset_format == "yolo":
                yaml_path = path.join(dataset_path, "data.yaml")
                if path.exists(yaml_path):
                    pass  # use yaml
                elif path.exists(path.join(dataset_path, "train")):
                    self._auto_generate_yaml(dataset_path)
                    yaml_path = path.join(dataset_path, "data.yaml")
                else:
                    raise FileNotFoundError(
                        f"Dataset cần có cấu trúc 'train/' và 'val/' hoặc file 'data.yaml'"
                    )
            elif dataset_format == "coco":
                coco_path = path.join(dataset_path, "train", "_annotations.coco.json")
                if not path.exists(coco_path):
                    raise FileNotFoundError(f"Dataset COCO cần file: {coco_path}")
            else:
                raise ValueError(f"Dataset format không hợp lệ: {dataset_format}")

            # ── ProcessName ──
            arch_name = model_params["Architecture"].name if hasattr(model_params["Architecture"], "name") else str(model_params["Architecture"])
            self.ProcessName = f"RFDETR_{arch_name}_{task_type}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # ── Load model ──
            self.model = self.LoadWeight()

   # ── Get classes info ──
            if dataset_format == "yolo":
                import yaml
                yaml_path = path.join(dataset_path, "data.yaml")
                if path.exists(yaml_path):
                    with open(yaml_path, 'r', encoding='utf-8') as f:
                        yaml_data = yaml.safe_load(f)
                    if "names" in yaml_data:
                        names = yaml_data["names"]
                        if isinstance(names, dict):
                            self.ClassesList = [names[i] for i in sorted(names.keys())]
                        else:
                            self.ClassesList = names
                        self.ClassesNumber = len(self.ClassesList)
            elif dataset_format == "coco":
                import json
                coco_path = path.join(dataset_path, "train", "_annotations.coco.json")
                if path.exists(coco_path):
                    with open(coco_path, encoding='utf-8') as f:
                        anns = json.load(f)
                    categories = sorted(anns["categories"], key=lambda c: c.get("id", float("inf")))
                    self.ClassesList = [c["name"] for c in categories]
                    self.ClassesNumber = len(self.ClassesList)
            else:
                # Fallback: try yolo first, then coco
                yaml_path = path.join(dataset_path, "data.yaml")
                if path.exists(yaml_path):
                    import yaml
                    with open(yaml_path, 'r', encoding='utf-8') as f:
                        yaml_data = yaml.safe_load(f)
                    if "names" in yaml_data:
                        names = yaml_data["names"]
                        if isinstance(names, dict):
                            self.ClassesList = [names[i] for i in sorted(names.keys())]
                        else:
                            self.ClassesList = names
                        self.ClassesNumber = len(self.ClassesList)
                else:
                    import json
                    coco_path = path.join(dataset_path, "train", "_annotations.coco.json")
                    if path.exists(coco_path):
                        with open(coco_path, encoding='utf-8') as f:
                            anns = json.load(f)
                        categories = sorted(anns["categories"], key=lambda c: c.get("id", float("inf")))
                        self.ClassesList = [c["name"] for c in categories]
                        self.ClassesNumber = len(self.ClassesList)

            # ── Open log file ──
            save_folder = path.join(self.cfg.Project, self.ProcessName)
            makedirs(save_folder, exist_ok=True)
            self._log_file = open(path.join(save_folder, "training.log"), 'w')

            self._write_log(f"Task: {task_type}")
            self._write_log(f"Architecture: {arch_name}")
            self._write_log(f"Resolution: {train_params['ImgSize']}")
            self._write_log(f"Device: {train_params['Device']}")
            if self.ClassesNumber > 0:
                self._write_log(f"Classes: {self.ClassesNumber}")

            # ── Build train kwargs ──
            train_kwargs = self._build_train_kwargs()

            # ── Train in thread ──
            def __train_wrapper():
                try:
                    self._train_thread = Thread(target=self._run_ptl_training, args=(train_kwargs,), daemon=True)
                    self._train_thread.start()
                    self._train_thread.join()
                except Exception as e:
                    msg = f"Training error: {str(e)}"
                    self._write_log(msg)
                    if self._callbacks:
                        self._callbacks("Error", msg)
                    self.IsTraining = False

            self._main_thread = Thread(target=__train_wrapper)
            self._main_thread.name = "RFDETRTrainThread"
            self._main_thread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)

    def _run_ptl_training(self, train_kwargs):
        """Run the actual RFDETR training loop with stop support."""
        try:
            from rfdetr.training import RFDETRDataModule, RFDETRModelModule, build_trainer

            # Build config from kwargs
            train_params = self.cfg.get_by_category("Training")
            resolution = train_kwargs.pop("resolution")

            # Handle device for PTL
            accelerator, devices = self._resolve_device(train_kwargs.pop("device", "cuda"))

            # Build model module
            module = RFDETRModelModule(self.model.model_config, self.model.get_train_config(**train_kwargs))

            # Patch the model to track trainer reference
            original_forward = module.forward
            def patched_forward(batch, batch_idx):
                return original_forward(batch, batch_idx)
            module.forward = patched_forward

            datamodule = RFDETRDataModule(self.model.model_config, module.config)

            trainer_kwargs = {"accelerator": accelerator}
            if devices is not None:
                trainer_kwargs["devices"] = devices

            trainer = build_trainer(module.config, self.model.model_config, **trainer_kwargs)

            # Store trainer reference for stop
            self._trainer = trainer

            # Register stop callback
            def _on_epoch_end(trainer, pl_module):
                if self._isStopTraining:
                    trainer.should_stop = True

            trainer.callbacks.append(_on_epoch_end)

            # Train
            trainer.fit(module, datamodule)

            # Sync weights back
            self.model.model = module.model

            # ── Export after training ──
            weights_dir = path.join(self.cfg.Project, self.ProcessName, "checkpoints")
            for weight_file in ["last.ckpt", "best.ckpt"]:
                weight_ckpt = path.join(weights_dir, weight_file)
                if path.exists(weight_ckpt):
                    try:
                        self.Export(weight_ckpt, eModelExportType.ONNX, train_params["ImgSize"])
                    except Exception as ex:
                        self._write_log(f"Export error ({weight_file}): {str(ex)}")

            if self._log_file:
                self._log_file.close()
                self._log_file = None

            self.IsTraining = False
            self.StopTrainingEvent.set()
            if self._callbacks:
                self._callbacks("Info", "Training completed")

        except Exception as e:
            msg = f"Training error: {str(e)}"
            self._write_log(msg)
            if self._callbacks:
                self._callbacks("Error", msg)
            self.IsTraining = False
        finally:
            self._trainer = None

    def _resolve_device(self, device_str):
        """Map device string to PTL accelerator/devices."""
        if device_str is None:
            return None, None
        try:
            resolved = torch.device(device_str)
        except (TypeError, ValueError):
            return None, None

        if resolved.type == "cpu":
            return "cpu", None
        if resolved.type == "cuda":
            return "gpu", [resolved.index] if resolved.index is not None else None
        if resolved.type == "mps":
            return "mps", [resolved.index] if resolved.index is not None else None
        return None, None

    # ── Stop ──────────────────────────────────────────────────────────
    def StopTraining(self):
        self._isStopTraining = True
        self.StopTrainingEvent.set()
        if self._trainer is not None:
            self._trainer.should_stop = True
        # Wait for thread to finish
        if hasattr(self, '_main_thread') and self._main_thread.is_alive():
            self._main_thread.join()
        self._isStopTraining = False

    # ── Predict ───────────────────────────────────────────────────────
    def Predict(self, img):
        if self.model is None:
            raise RuntimeError("Model chưa được load. Gọi LoadWeight() trước.")
        results = self.model.predict(img)
        return results

    # ── BatchPredict ──────────────────────────────────────────────────
    def BatchPredict(self, batchImg):
        if self.model is None:
            raise RuntimeError("Model chưa được load. Gọi LoadWeight() trước.")
        if isinstance(batchImg, list):
            results = self.model.predict(batchImg)
            return results
        return self.model.predict([batchImg])

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType, exportImageSize: int = 560):
        try:
            if not path.exists(pathToPytorchModel):
                raise FileNotFoundError(f"Weight file không tồn tại: {pathToPytorchModel}")

            if exportType == eModelExportType.ONNX:
                export_dir = path.dirname(pathToPytorchModel)
                makedirs(export_dir, exist_ok=True)

                self.model.export(
                    output_dir=export_dir,
                    shape=(exportImageSize, exportImageSize),
                    batch_size=1,
                    verbose=False,
                )
                print(f"Exported ONNX to {export_dir}")

            else:
                # RFDETR only supports ONNX natively
                print(f"Export type không hợp lệ cho RFDETR: {exportType}. Chỉ hỗ trợ ONNX.")

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self._callbacks is not None:
                self._callbacks("Error", f"Export error: {str(ex)}")
            raise

    # ── Auto generate data.yaml ───────────────────────────────────────
    def _auto_generate_yaml(self, dataset_path: str):
        yaml_path = path.join(dataset_path, "data.yaml")
        train_dir = path.join(dataset_path, "train")
        val_dir = path.join(dataset_path, "val")

        if not path.exists(train_dir) or not path.exists(val_dir):
            return

        # Count classes
        train_classes = sorted([d for d in __import__('os').listdir(train_dir)
                               if path.isdir(path.join(train_dir, d))])
        val_classes = sorted([d for d in __import__('os').listdir(val_dir)
                             if path.isdir(path.join(val_dir, d))])

        nc = len(train_classes)
        self.ClassesNumber = nc
        self.ClassesList = train_classes

        yaml_content = f"path: {dataset_path}\n"
        yaml_content += f"nc: {nc}\n"
        yaml_content += f"names: {train_classes}\n"
        yaml_content += f"train: {path.join('..', 'train')}\n"
        yaml_content += f"val: {path.join('..', 'val')}\n"

        with open(yaml_path, 'w', encoding='utf-8') as f:
            f.write(yaml_content)
