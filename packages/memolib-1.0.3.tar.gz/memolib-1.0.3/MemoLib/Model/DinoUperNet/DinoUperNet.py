import torch
import torch.nn as nn
import torch.nn.functional as F
from os import path, makedirs
from torch import optim
from torch.optim.lr_scheduler import CosineAnnealingLR, MultiStepLR, LinearLR, SequentialLR
from threading import Thread, Event
from torch.utils.data import DataLoader
import datetime
import torchvision
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType, eOptimizerType
from ..BaseModel.eSegmentationModel import eDinoUperNetModel
from .DinoUperNetConfig import TrainingConfig
import os
import gc
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

try:
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    ALBUMENTATIONS_AVAILABLE = True
except ImportError:
    ALBUMENTATIONS_AVAILABLE = False

try:
    import openvino as ov
    OPENVINO_AVAILABLE = True
except ImportError:
    OPENVINO_AVAILABLE = False


# ── Scheduler: chỉ scale head, backbone giữ nguyên LR ────────────────────────

class _HeadOnlyScheduler:
    """Wrapper: apply LR schedule only to head param group, backbone LR unchanged."""

    def __init__(self, optimizer, head_scheduler, backbone_lr):
        self.optimizer = optimizer
        self.head_scheduler = head_scheduler
        self.backbone_lr = backbone_lr

    def step(self):
        self.head_scheduler.step()
        # Restore backbone LR (scheduler may have scaled it down)
        if len(self.optimizer.param_groups) == 2:
            self.optimizer.param_groups[0]['lr'] = self.backbone_lr

    def get_last_lr(self):
        return self.head_scheduler.get_last_lr()


# ── PPM ───────────────────────────────────────────────────────────────────────

class _PPM(nn.Module):
    """Pyramid Pooling Module.

    Uses F.interpolate-based global pooling instead of nn.AdaptiveAvgPool2d
    to avoid ONNX export failures when pool_scale is not a factor of input size.
    """

    def __init__(self, in_channels: int, out_channels: int, pool_scales: tuple = (1, 2, 3, 6)):
        super().__init__()
        self.stages = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )
            for _ in pool_scales
        ])
        self.bottleneck = nn.Sequential(
            nn.Conv2d(in_channels + out_channels * len(pool_scales), out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.pool_scales = pool_scales

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h, w = x.shape[2:]
        pooled = []
        for scale, stage in zip(self.pool_scales, self.stages):
            # Pool to (scale, scale) via interpolate, then squeeze to (1, 1)
            pooled_feat = F.interpolate(x, size=(scale, scale), mode="bilinear", align_corners=False)
            pooled_feat = stage(pooled_feat)
            pooled_feat = pooled_feat.mean(dim=(2, 3), keepdim=True)
            pooled.append(F.interpolate(pooled_feat, size=(h, w), mode="bilinear", align_corners=False))
        return self.bottleneck(torch.cat([x] + pooled, dim=1))


# ── UPerHead ──────────────────────────────────────────────────────────────────

class _UPerHead(nn.Module):
    """UPerNet decode head for ViT backbones."""

    def __init__(self, in_channels: int = 384, channels: int = 512, num_classes: int = 2,
                 pool_scales: tuple = (1, 2, 3, 6), dropout: float = 0.1):
        super().__init__()

        self.ppm = _PPM(in_channels, channels, pool_scales)

        self.lateral_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, channels, 1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
            )
            for _ in range(3)
        ])

        self.fpn_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(channels, channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
            )
            for _ in range(3)
        ])

        self.head = nn.Sequential(
            nn.Conv2d(channels * 4, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout),
            nn.Conv2d(channels, num_classes, 1),
        )

    def forward(self, features: tuple) -> torch.Tensor:
        f1, f2, f3, f4 = features

        ppm_out = self.ppm(f4)

        lat = [conv(f) for conv, f in zip(self.lateral_convs, [f1, f2, f3])]

        lat[2] = lat[2] + F.interpolate(ppm_out, size=lat[2].shape[2:], mode="bilinear", align_corners=False)
        lat[1] = lat[1] + F.interpolate(lat[2], size=lat[1].shape[2:], mode="bilinear", align_corners=False)
        lat[0] = lat[0] + F.interpolate(lat[1], size=lat[0].shape[2:], mode="bilinear", align_corners=False)

        fpn_outs = [conv(l) for conv, l in zip(self.fpn_convs, lat)]
        fpn_outs.append(ppm_out)

        ref = fpn_outs[0].shape[2:]
        fpn_outs = [
            F.interpolate(x, size=ref, mode="bilinear", align_corners=False)
            for x in fpn_outs
        ]

        x = torch.cat(fpn_outs, dim=1)
        return self.head(x)


# ── _DINOv2Segmentation ───────────────────────────────────────────────────────

class _DINOv2Segmentation(nn.Module):
    """DINOv2 backbone + UPerNet decode head."""

    def __init__(self, num_classes: int = 2, backbone_name: str = "dinov2_vits14", feature_dim: int = 384,
                 decoder_channels: int = 512, dropout: float = 0.1, pool_scales: tuple = (1, 2, 3, 6)):
        super().__init__()

        self.backbone = torch.hub.load("facebookresearch/dinov2", backbone_name, pretrained=True)

        self.decode_head = _UPerHead(
            in_channels=feature_dim, num_classes=num_classes,
            channels=decoder_channels, dropout=dropout, pool_scales=pool_scales,
        )

    def set_backbone_requires_grad(self, requires_grad: bool):
        """Control backbone gradient tracking (called by Train/LoadWeight)."""
        for param in self.backbone.parameters():
            param.requires_grad = requires_grad

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        H, W = x.shape[2:]

        # Manually collect intermediate layers (last 4 blocks)
        x = self.backbone.prepare_tokens_with_masks(x)
        features = []
        num_blocks = len(self.backbone.blocks)
        target_indices = set(range(num_blocks - 4, num_blocks))
        for i, blk in enumerate(self.backbone.blocks):
            x = blk(x)
            if i in target_indices:
                feat = self.backbone.norm(x)
                feat = feat[:, 1 + self.backbone.num_register_tokens:]
                B, _, D = feat.shape
                pH, pW = H // self.backbone.patch_size, W // self.backbone.patch_size
                feat = feat.reshape(B, pH, pW, D)
                feat = feat.permute(0, 3, 1, 2).contiguous()
                features.append(feat)

        logits = self.decode_head(tuple(features))

        return F.interpolate(logits, size=(H, W), mode="bilinear", align_corners=False)


_ARCH_MAP = {
    eDinoUperNetModel.DINO_S: ("dinov2_vits14", 384),
    eDinoUperNetModel.DINO_B: ("dinov2_vitb14", 768),
    eDinoUperNetModel.DINO_L: ("dinov2_vitl14", 1024),
}


# ── ONNX Wrapper ──────────────────────────────────────────────────────────────

class _ONNXWrapper(nn.Module):
    """Wraps _DINOv2Segmentation for ONNX tracing."""

    def __init__(self, model: _DINOv2Segmentation):
        super().__init__()
        self.model = model
        self.model.eval()
        for m in self.model.modules():
            m.eval()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.model(x)
        return logits.argmax(dim=1, keepdim=True)  # (1, 1, H, W) mask


# ── SegDataset ────────────────────────────────────────────────────────────────

class _SegDataset(torchvision.datasets.ImageFolder):
    """
    Segmentation dataset: loads image + mask pairs from images/ and masks/.
    Applies same albumentation transform to both image and mask.
    """

    def __init__(self, root: str, transform=None):
        self.root = root
        self.images_dir = path.join(root, "images")
        self.masks_dir = path.join(root, "masks")
        self.transform = transform

        self.filenames = sorted(
            f for f in __import__('os').listdir(self.images_dir)
            if f.lower().endswith(('.png', '.jpg', '.jpeg'))
        )
        assert self.filenames, f"No images found in {self.images_dir}"

        self.classes = ['__segmentation__']
        self.class_to_idx = {'__segmentation__': 0}

    def __len__(self):
        return len(self.filenames)

    def __getitem__(self, idx):
        fname = self.filenames[idx]
        # Image extension → mask extension (.png)
        mask_fname = fname.rsplit(".", 1)[0] + ".png"
        image = np.array(Image.open(path.join(self.images_dir, fname)).convert("RGB"))
        mask = np.array(Image.open(path.join(self.masks_dir, mask_fname)))

        # ADE20K: 150 classes (1-150) + background (0) = 151 classes total. Keep mask as-is.

        if self.transform is not None:
            augmented = self.transform(image=image, mask=mask)
            image = augmented["image"]
            mask = augmented["mask"].long()
        else:
            mask = torch.from_numpy(mask).long()

        return image, mask


class DinoUperNet(IModel):

    @property
    def IsTraining(self):
        return self._isTraining
    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining
    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg               = TrainingConfig()
        self._isTraining       = False
        self._isStopTraining   = False
        self.StopTrainingEvent = Event()
        self.model             = None
        self.callbacks         = None
        self.ClassesNumber     = 0
        self.ProcessName       = ""
        self.Device            = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file         = None

    # ── Helpers ───────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    @staticmethod
    def _count_params(model):
        total = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return trainable, total

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        model_params = self.cfg.get_by_category("ModelParams")
        backbone_name, feature_dim = _ARCH_MAP.get(model_params["Architecture"], ("dinov2_vits14", 384))
        backboneParams = self.cfg.get_by_category("Backbone")

        model = _DINOv2Segmentation(
            num_classes=self.ClassesNumber,
            backbone_name=backbone_name,
            feature_dim=feature_dim,
            decoder_channels=model_params["DecoderChannels"],
            dropout=model_params["Dropout"],
            pool_scales=model_params["PoolScales"],
        )

        if weightPath and path.exists(weightPath):
            state_dict = torch.load(weightPath, map_location=self.Device)
            new_state_dict = {}
            for k, v in state_dict.items():
                name = k[7:] if k.startswith('module.') else k
                new_state_dict[name] = v
            model.load_state_dict(new_state_dict, strict=False)

        model.to(self.Device)
        model.set_backbone_requires_grad(not backboneParams["FreezeBackbone"])
        return model

    # ── Augmentation ──────────────────────────────────────────────────
    def PrepareAugmentation(self):
        if not ALBUMENTATIONS_AVAILABLE:
            raise RuntimeError("albumentations is required. Install: pip install albumentations")

        aug_params   = self.cfg.get_by_category("Augmentation")
        model_params = self.cfg.get_by_category("ModelParams")
        imageSize    = model_params["ImageSize"]

        train_transform = A.Compose([
            A.RandomResizedCrop(
                size=(imageSize, imageSize),
                scale=(aug_params["LongSideScaleMin"], 1.0),
                ratio=(0.75, 1.33),
            ),
            A.HorizontalFlip(p=aug_params["HFlipP"]),
            A.ColorJitter(
                brightness=aug_params["BrightnessFactor"],
                contrast=aug_params["ContrastFactor"],
                saturation=aug_params["SaturationFactor"],
                hue=aug_params["HueFactor"],
                p=aug_params["ColorJitterP"],
            ),
            A.GaussianBlur(
                blur_limit=aug_params["GaussianBlurLimit"],
                p=aug_params["GaussianBlurP"],
            ),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], max_pixel_value=255.0),
            ToTensorV2(),
        ], is_check_shapes=False)

        val_transform = A.Compose([
            A.Resize(imageSize, imageSize),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], max_pixel_value=255.0),
            ToTensorV2(),
        ], is_check_shapes=False)

        return train_transform, val_transform

    # ── Optimizer ─────────────────────────────────────────────────────
    def _build_optimizer(self, model, use_warmup_lr: bool = False):
        trainParams = self.cfg.get_by_category("Training")
        warmupParams = self.cfg.get_by_category("Warmup")
        backboneParams = self.cfg.get_by_category("Backbone")

        lr = warmupParams["WarmupStartFactor"] * trainParams["LearningRate"] if use_warmup_lr else trainParams["LearningRate"]
        warmup_factor = warmupParams["WarmupStartFactor"] if use_warmup_lr else 1.0
        weight_decay = trainParams["WeightDecay"]
        optimizer_type = trainParams["OptimizerType"]

        freeze = backboneParams["FreezeBackbone"]
        backbone_lr = backboneParams["BackboneLR"] * warmup_factor if not freeze else 0.0
        head_lr = backboneParams["HeadLR"] * warmup_factor if not freeze else lr

        # Backbone luôn frozen → chỉ có head params
        head_params = list(model.decode_head.parameters())
        param_groups = [{"params": head_params, "lr": head_lr}]

        if not freeze:
            backbone_params = list(model.backbone.parameters())
            param_groups.insert(0, {"params": backbone_params, "lr": backbone_lr})

        if optimizer_type == eOptimizerType.Adam:
            return optim.Adam(param_groups, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.AdamW:
            return optim.AdamW(param_groups, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.SGD:
            momentum = trainParams.get("Momentum", 0.9)
            return optim.SGD(param_groups, momentum=momentum, weight_decay=weight_decay)

        elif optimizer_type == eOptimizerType.RMSprop:
            momentum = trainParams.get("Momentum", 0.9)
            return optim.RMSprop(param_groups, momentum=momentum, weight_decay=weight_decay)

        else:
            raise ValueError(f"OptimizerType không hợp lệ: {optimizer_type}")

    def _get_current_lr(self, optimizer):
        # Luôn trả về head LR (group cuối)
        return optimizer.param_groups[-1]['lr']

    def _log_lr_change(self, old_lr, new_lr):
        if old_lr != new_lr:
            msg = f"Learning rate: {old_lr:.6f} -> {new_lr:.6f}"
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

    def _update_all_lrs(self, optimizer, backbone_lr, head_lr):
        """Update LR for each param group."""
        if len(optimizer.param_groups) == 2:
            optimizer.param_groups[0]['lr'] = backbone_lr
            optimizer.param_groups[1]['lr'] = head_lr
        else:
            optimizer.param_groups[0]['lr'] = head_lr

    @staticmethod
    def _update_iou_stats(preds, labels, num_classes, ignore_index, inter, union):
        """Update intersection/union counters for a single batch (in-place)."""
        valid = (labels != ignore_index)
        preds_masked = preds.masked_fill(~valid, -1)
        labels_masked = labels.masked_fill(~valid, -1)
        for c in range(num_classes):
            pred_c = (preds_masked == c)
            label_c = (labels_masked == c)
            inter[c] += (pred_c & label_c).sum().item()
            union[c] += (pred_c | label_c).sum().item()

    @staticmethod
    def _calc_miou_from_stats(inter, union, num_classes):
        """Compute mIoU from accumulated intersection/union counters."""
        ious = []
        for c in range(num_classes):
            if union[c] == 0:
                continue
            ious.append(inter[c] / union[c])
        return float(np.mean(ious)) * 100.0 if ious else 0.0

    # ── Visualization ─────────────────────────────────────────────────
    def _plot_results(self, save_dir):
        """Plot train/val loss curves."""
        if not hasattr(self, '_train_loss_history') or not self._train_loss_history:
            return

        fig, ax = plt.subplots(1, 1, figsize=(10, 4))

        epochs = range(1, len(self._train_loss_history) + 1)
        ax.plot(epochs, self._train_loss_history, 'b-o', label='Train Loss')
        if hasattr(self, '_val_loss_history') and self._val_loss_history:
            ax.plot(epochs, self._val_loss_history, 'r-o', label='Val Loss')
        ax.set_xlabel('Epoch'); ax.set_ylabel('Loss')
        ax.legend(); ax.grid(True)

        fig.suptitle(f'{self.ProcessName}', fontsize=12)
        fig.savefig(path.join(save_dir, 'results.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    def _plot_pixel_accuracy(self, save_dir):
        """Plot pixel accuracy curves."""
        if not hasattr(self, '_train_pix_acc_history') or not self._train_pix_acc_history:
            return

        fig, ax = plt.subplots(1, 1, figsize=(10, 4))

        epochs = range(1, len(self._train_pix_acc_history) + 1)
        ax.plot(epochs, self._train_pix_acc_history, 'b-o', label='Train Pix Acc')
        if hasattr(self, '_val_pix_acc_history') and self._val_pix_acc_history:
            ax.plot(epochs, self._val_pix_acc_history, 'r-o', label='Val Pix Acc')
        ax.set_xlabel('Epoch'); ax.set_ylabel('Pixel Accuracy (%)')
        ax.legend(); ax.grid(True)

        fig.suptitle(f'{self.ProcessName}', fontsize=12)
        fig.savefig(path.join(save_dir, 'pixel_accuracy.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    def _plot_miou(self, save_dir):
        """Plot mIoU curves."""
        if not hasattr(self, '_train_miou_history') or not self._train_miou_history:
            return

        fig, ax = plt.subplots(1, 1, figsize=(10, 4))

        epochs = range(1, len(self._train_miou_history) + 1)
        ax.plot(epochs, self._train_miou_history, 'b-o', label='Train mIoU')
        if hasattr(self, '_val_miou_history') and self._val_miou_history:
            ax.plot(epochs, self._val_miou_history, 'r-o', label='Val mIoU')
        ax.set_xlabel('Epoch'); ax.set_ylabel('mIoU (%)')
        ax.legend(); ax.grid(True)

        fig.suptitle(f'{self.ProcessName}', fontsize=12)
        fig.savefig(path.join(save_dir, 'miou.png'), dpi=150, bbox_inches='tight')
        plt.close('all')

    # ── Train ─────────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining  = True
            self.callbacks   = callbacks
            self.StopTrainingEvent.clear()

            self.Train_Transform, self.Val_Transform = self.PrepareAugmentation()

            modelParams  = self.cfg.get_by_category("ModelParams")
            dataParams   = self.cfg.get_by_category("DataPaths")
            trainParams  = self.cfg.get_by_category("Training")

            self.ProcessName = f"DinoUperNet_{modelParams['Architecture'].name}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            datasetPath = dataParams["DatasetPath"]
            trainPath   = path.join(datasetPath, "train")
            valPath     = path.join(datasetPath, "val")

            if not path.exists(trainPath):
                raise FileNotFoundError(f"Không tìm thấy thư mục train: {trainPath}")
            if not path.exists(valPath):
                raise FileNotFoundError(f"Không tìm thấy thư mục val: {valPath}")

            train_dataset = _SegDataset(trainPath, transform=self.Train_Transform)
            val_dataset   = _SegDataset(valPath,   transform=self.Val_Transform)
            self.ClassesNumber = len(train_dataset.classes)

            if modelParams["NumClasses"] > 1:
                self.ClassesNumber = modelParams["NumClasses"]

            self.TrainLoader = DataLoader(
                train_dataset,
                batch_size  = trainParams["BatchSize"],
                shuffle     = True,
                num_workers = 4,
                pin_memory  = True,
            )
            self.ValLoader = DataLoader(
                val_dataset,
                batch_size  = trainParams["BatchSize"],
                shuffle     = False,
                num_workers = 4,
                pin_memory  = True,
            )

            # Resolve Project from config
            project_name = modelParams.get("Project", "TrainResult")
            saveFolder = path.join(project_name, self.ProcessName)
            makedirs(saveFolder, exist_ok=True)

            self._log_file = open(path.join(saveFolder, "training.log"), 'w')

            self.model = self.LoadWeight()

            backboneParams = self.cfg.get_by_category("Backbone")
            freeze = backboneParams["FreezeBackbone"]
            backbone_lr = backboneParams["BackboneLR"]
            self._write_log(f"Backbone: {'frozen' if freeze else f'unfrozen (LR={backbone_lr})'}")
            self.optimizer = self._build_optimizer(self.model, use_warmup_lr=True)

            trainThread      = Thread(target=self.__train_model)
            trainThread.name = "TrainThread"
            trainThread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)

    # ── Train loop ────────────────────────────────────────────────────
    def __train_model(self):
        try:
            trainParams  = self.cfg.get_by_category("Training")
            warmupParams = self.cfg.get_by_category("Warmup")
            schedulerParams = self.cfg.get_by_category("Scheduler")
            backboneParams  = self.cfg.get_by_category("Backbone")

            num_epochs          = trainParams["Epochs"]
            early_stop_patience = trainParams["Patience"]
            warmupEpochs        = warmupParams["WarmupEpochs"]

            criterion = nn.CrossEntropyLoss(ignore_index=255)

            best_val_miou  = 0.0
            early_stop_counter = 0
            scheduler      = None
            initial_backbone_lr = backboneParams["BackboneLR"]

            self._train_loss_history = []
            self._val_loss_history = []
            self._train_pix_acc_history = []
            self._val_pix_acc_history = []
            self._train_miou_history = []
            self._val_miou_history = []
            self._class_names = [f'class_{i}' for i in range(self.ClassesNumber)]

            trainable, total = self._count_params(self.model)
            self._write_log(f'Params: {trainable:,} / {total:,} ({100*trainable/total:.1f}%)')

            for epoch in range(num_epochs):
                self._write_log(f'Epoch {epoch+1}/{num_epochs}')
                self._write_log('-' * 10)

                # ── Train ─────────────────────────────────────────
                self.model.train()
                running_loss = 0.0
                correct_pix  = 0
                total_pix    = 0
                train_inter  = [0] * self.ClassesNumber
                train_union  = [0] * self.ClassesNumber

                loader = tqdm(self.TrainLoader, desc=f'Epoch {epoch+1}/{num_epochs} [Train]', leave=False) if TQDM_AVAILABLE else self.TrainLoader
                for images, labels in loader:
                    images = images.to(self.Device)
                    labels = labels.to(self.Device).long()

                    self.optimizer.zero_grad()
                    outputs = self.model(images)
                    loss = criterion(outputs, labels)
                    loss.backward()
                    self.optimizer.step()

                    running_loss += loss.item() * images.size(0)

                    # Detach outputs ngay sau backward để giải phóng graph
                    preds = outputs.detach().argmax(dim=1)
                    correct_pix += (preds == labels).sum().item()
                    total_pix   += labels.numel()
                    self._update_iou_stats(preds, labels, self.ClassesNumber, 255, train_inter, train_union)
                    del outputs

                epoch_loss = running_loss / len(self.TrainLoader.dataset)
                epoch_pix_acc = 100 * correct_pix / total_pix
                epoch_miou = self._calc_miou_from_stats(train_inter, train_union, self.ClassesNumber)
                self._write_log(f'Train Loss: {epoch_loss:.4f} | Train Pix Acc: {epoch_pix_acc:.2f}% | Train mIoU: {epoch_miou:.2f}%')

                self._train_loss_history.append(epoch_loss)
                self._train_pix_acc_history.append(epoch_pix_acc)
                self._train_miou_history.append(epoch_miou)

                # Giải phóng tqdm internal state (giữ reference tensors)
                del loader

                # ── Eval ──────────────────────────────────────────
                self.model.eval()
                test_loss = 0.0
                correct_pix = 0
                total_pix   = 0
                val_inter   = [0] * self.ClassesNumber
                val_union   = [0] * self.ClassesNumber

                with torch.no_grad():
                    loader = tqdm(self.ValLoader, desc=f'Epoch {epoch+1}/{num_epochs} [Val]', leave=False) if TQDM_AVAILABLE else self.ValLoader
                    for images, labels in loader:
                        images = images.to(self.Device)
                        labels = labels.to(self.Device).long()
                        outputs = self.model(images)
                        loss = criterion(outputs, labels)
                        test_loss += loss.item() * images.size(0)

                        preds = outputs.detach().argmax(dim=1)
                        correct_pix += (preds == labels).sum().item()
                        total_pix   += labels.numel()
                        self._update_iou_stats(preds, labels, self.ClassesNumber, 255, val_inter, val_union)
                        del outputs

                epoch_test_loss = test_loss / len(self.ValLoader.dataset)
                test_pix_acc = 100 * correct_pix / total_pix
                test_miou = self._calc_miou_from_stats(val_inter, val_union, self.ClassesNumber)
                self._write_log(f'Val Loss: {epoch_test_loss:.4f} | Val Pix Acc: {test_pix_acc:.2f}% | Val mIoU: {test_miou:.2f}%')

                self._val_loss_history.append(epoch_test_loss)
                self._val_pix_acc_history.append(test_pix_acc)
                self._val_miou_history.append(test_miou)

                # Giải phóng tqdm internal state
                del loader

                # ── Plot every 5 epochs ───────────────────────
                save_folder = path.join("TrainResult", self.ProcessName)
                if (epoch + 1) % 5 == 0 or epoch == 0:
                    self._plot_results(save_folder)
                    self._plot_pixel_accuracy(save_folder)
                    self._plot_miou(save_folder)

                if self.callbacks is not None:
                    self.callbacks("Info", f'Epoch {epoch+1}/{num_epochs} | '
                                           f'Val Loss: {epoch_test_loss:.4f} | '
                                           f'Val Pix Acc: {test_pix_acc:.2f}% | '
                                           f'Val mIoU: {test_miou:.2f}%')

                # ── Save best + Early stopping (dùng chung improved flag) ──
                improved = test_miou > best_val_miou
                if improved:
                    best_val_miou = test_miou
                    self.__saveModel(self.model, "best.pth")
                    self._write_log(f'Val mIoU improved: {best_val_miou:.2f}% — saved best.pth')

                if early_stop_patience > 0:
                    if improved:
                        early_stop_counter = 0
                    else:
                        early_stop_counter += 1
                        msg = f'No improvement {early_stop_counter}/{early_stop_patience}'
                        self._write_log(msg)
                        if self.callbacks is not None:
                            self.callbacks("Info", msg)

                        if early_stop_counter >= early_stop_patience:
                            msg = f'Early stopping after {early_stop_patience} epochs'
                            self._write_log(msg)
                            if self.callbacks is not None:
                                self.callbacks("Info", msg)
                            break

                # ── Warmup: linear LR ramp (backbone + head) ────
                if epoch < warmupEpochs and warmupEpochs > 0:
                    progress = (epoch + 1) / warmupEpochs
                    head_lr = trainParams["LearningRate"] * (warmupParams["WarmupStartFactor"] + (1.0 - warmupParams["WarmupStartFactor"]) * progress)
                    backbone_lr = backboneParams["BackboneLR"] * (warmupParams["WarmupStartFactor"] + (1.0 - warmupParams["WarmupStartFactor"]) * progress) if not backboneParams["FreezeBackbone"] else 0.0
                    old_lr = self._get_current_lr(self.optimizer)
                    self._update_all_lrs(self.optimizer, backbone_lr, head_lr)
                    self._log_lr_change(old_lr, head_lr)

               # ── Warmup xong -> main scheduler (chỉ head, backbone giữ nguyên LR) ────
                if epoch + 1 == warmupEpochs and warmupEpochs > 0:
                    remaining = max(num_epochs - warmupEpochs, 1)

                    if schedulerParams["Scheduler"] == "cosine":
                        head_sched = CosineAnnealingLR(
                            self.optimizer, T_max=remaining,
                            eta_min=schedulerParams["LRMin"]
                        )
                        print(f"Scheduler: CosineAnnealingLR ({schedulerParams['LRMin']} over {remaining} epochs)")
                    else:
                        head_sched = MultiStepLR(
                            self.optimizer,
                            milestones=schedulerParams["LRMilestones"],
                            gamma=schedulerParams["LRGamma"]
                        )
                        print(f"Scheduler: MultiStepLR milestones={schedulerParams['LRMilestones']} gamma={schedulerParams['LRGamma']}")

                    # Chỉ apply schedule cho head param group
                    scheduler = _HeadOnlyScheduler(self.optimizer, head_sched, initial_backbone_lr)
                    self._write_log(f'Warmup done — scheduler active')

                elif scheduler is not None:
                    scheduler.step()

                if self.IsStopTraining:
                    break

                # ── Release GPU memory after epoch ───────────────
                torch.cuda.empty_cache()
                gc.collect()

            msg = f'Training done | Best Val mIoU: {best_val_miou:.2f}%'
            self._write_log(msg)
            if self.callbacks is not None:
                self.callbacks("Info", msg)

            self.__saveModel(self.model, "last.pth")

            if self._log_file:
                self._log_file.close()
                self._log_file = None

            if hasattr(self.model, 'cpu'):
                self.model.cpu()
            del self.model
            self.model = None
            torch.cuda.empty_cache()

            save_folder = path.join("TrainResult", self.ProcessName)
            self._plot_results(save_folder)
            self._plot_pixel_accuracy(save_folder)
            self._plot_miou(save_folder)

            # ── Export ────────────────────────────────────────────
            model_params = self.cfg.get_by_category("ModelParams")
            image_size = model_params["ImageSize"]
            weightsFolder = path.join("TrainResult", self.ProcessName, "Weights")
            for weight_file in ["last.pth", "best.pth"]:
                weight_path = path.join(weightsFolder, weight_file)
                if path.exists(weight_path):
                    self.Export(weight_path, eModelExportType.ONNX, image_size)

            self.IsTraining = False
            self.StopTrainingEvent.set()

        except Exception as ex:
            print(f"Training error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Training error: {str(ex)}")
            self.IsTraining = False

    # ── Save model ────────────────────────────────────────────────────
    def __saveModel(self, model, modelName):
        savePath = path.join("TrainResult", self.ProcessName, "Weights", modelName)
        makedirs(path.dirname(savePath), exist_ok=True)
        torch.save(model.state_dict(), savePath)

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType, exportImageSize: int = None):
        tempModel = None
        try:
            self.ClassesNumber = self.ClassesNumber or 2
            tempModel   = self.LoadWeight(pathToPytorchModel)

            match exportType:
                case eModelExportType.ONNX:
                    model_params = self.cfg.get_by_category("ModelParams")
                    backbone_name, feature_dim = _ARCH_MAP.get(
                        model_params["Architecture"], ("dinov2_vits14", 384)
                    )
                    image_size = exportImageSize if exportImageSize is not None else model_params["ImageSize"]

                    # Verify image_size divisible by 14
                    if image_size % 14 != 0:
                        suggestion = round(image_size / 14) * 14
                        print(f"[WARN] image-size={image_size} không chia hết cho patch_size=14. "
                              f"Nên dùng {suggestion}.")

                    B, C, H, W = 1, 3, image_size, image_size
                    num_classes = self.ClassesNumber

                    print("=" * 60)
                    print("ONNX EXPORT")
                    print("=" * 60)
                    print(f"Device       : {self.Device}")
                    print(f"Input shape  : ({B}, {C}, {H}, {W})  [fixed]")
                    print(f"Output shape : ({B}, 1, {H}, {W})  [mask]")
                    print(f"Opset        : 17")
                    print(f"Output file  : {path.splitext(pathToPytorchModel)[0]}.onnx")
                    print("=" * 60)

                    wrapper = _ONNXWrapper(tempModel)
                    wrapper.eval()
                    dummy = torch.randn(B, C, H, W, dtype=torch.float32, device=self.Device)

                    onnx_path = path.splitext(pathToPytorchModel)[0] + ".onnx"
                    print("Exporting... (TracerWarnings từ DINOv2 là bình thường)")

                    with torch.no_grad():
                        torch.onnx.export(
                            wrapper,
                            dummy,
                            onnx_path,
                            opset_version=17,
                            input_names=["input"],
                            output_names=["output"],
                            dynamic_axes=None,
                            do_constant_folding=True,
                            export_params=True,
                        )

                    size_mb = os.path.getsize(onnx_path) / 1024 / 1024
                    print(f"[OK] Saved: {onnx_path}  ({size_mb:.1f} MB)\n")

                    # Verify ONNX model structure
                    try:
                        import onnx
                        onnx.checker.check_model(onnx.load(onnx_path))
                        print("[OK] ONNX model structure is valid\n")
                    except ImportError:
                        print("[SKIP] onnx package not installed, skipping model check\n")
                    except Exception as e:
                        print(f"[WARN] ONNX model check: {e}\n")

                    # Verify PyTorch vs ONNX output
                    sess = None
                    try:
                        import onnxruntime as ort
                        with torch.no_grad():
                            torch_out = wrapper(dummy).cpu().numpy()
                        providers = ["CPUExecutionProvider"]
                        if "CUDAExecutionProvider" in ort.get_available_providers():
                            providers.insert(0, "CUDAExecutionProvider")
                        sess = ort.InferenceSession(onnx_path, providers=providers)
                        input_name = sess.get_inputs()[0].name
                        onnx_out = sess.run(None, {input_name: dummy.cpu().numpy()})[0]

                        mismatch = (torch_out != onnx_out).sum()
                        total = torch_out.size

                        print("VERIFICATION: PyTorch vs ONNX")
                        print(f"  Mismatch — {mismatch} / {total} pixels ({100*mismatch/total:.2f}%)")
                        if mismatch == 0:
                            print("  [PASS] Verification passed")
                        else:
                            print("  [WARN] Verification failed")
                    except ImportError:
                        print("[SKIP] onnxruntime not installed — skipping verification.\n")
                    except Exception as e:
                        print(f"[WARN] Verification error: {e}\n")
                    finally:
                        if sess is not None:
                            del sess
                        torch.cuda.empty_cache()

                    # Simplify ONNX if onnx-simplifier is available
                    try:
                        import onnxsim
                        print("Simplifying ONNX model...")
                        model_onnx = onnx.load(onnx_path)
                        model_simp, check = onnxsim.simplify(
                            model_onnx,
                            check_n=3,
                            perform_optimization=True,
                        )
                        if check:
                            backup = onnx_path.replace(".onnx", "_original.onnx")
                            os.replace(onnx_path, backup)
                            onnx.save(model_simp, onnx_path)
                            orig_mb = os.path.getsize(backup) / 1024 / 1024
                            simp_mb = os.path.getsize(onnx_path) / 1024 / 1024
                            print(f"[OK] Simplified: {orig_mb:.1f} MB → {simp_mb:.1f} MB "
                                  f"({100*(1-simp_mb/orig_mb):+.1f}%)")
                            print(f"     Original backup: {backup}")
                        else:
                            print("[FAIL] Simplification check failed, keeping original")
                    except ImportError:
                        print("[SKIP] onnx-simplifier not installed. "
                              "Install: pip install onnx-simplifier\n")
                    except Exception as e:
                        print(f"[WARN] Simplification error: {e}\n")

                    print("[DONE] ONNX export complete!")
                    print(f"  Input  : (1, 3, {H}, {W})")
                    print(f"  Output : (1, 1, {H}, {W})  [mask]")

                case eModelExportType.OpenVINO:
                    if not OPENVINO_AVAILABLE:
                        raise RuntimeError("OpenVINO không được cài. Chạy: pip install openvino")
                    # OpenVINO không hỗ trợ DINOv2 backbone — chỉ export decoder head
                    model_params = self.cfg.get_by_category("ModelParams")
                    arch_enum = model_params["Architecture"]
                    _, feature_dim = _ARCH_MAP.get(arch_enum, ("dinov2_vits14", 384))

                    export_image_size = exportImageSize if exportImageSize is not None else model_params["ImageSize"]
                    export_model = _UPerHead(in_channels=feature_dim, num_classes=self.ClassesNumber,
                                             channels=model_params["DecoderChannels"],
                                             dropout=model_params["Dropout"],
                                             pool_scales=model_params["PoolScales"])
                    export_model.load_state_dict(tempModel.decode_head.state_dict(), strict=True)
                    export_model.eval()

                    pH, pW = export_image_size // 14, export_image_size // 14
                    dummy_input = torch.randn(1, feature_dim * 4, pH, pW)

                    pathExport = path.splitext(pathToPytorchModel)[0]
                    onnxPath = pathExport + ".onnx"
                    torch.onnx.export(
                        export_model, dummy_input, onnxPath,
                        input_names  = ['features'],
                        output_names = ['logits'],
                        dynamic_axes = {'features': {0: 'batch_size'}, 'logits': {0: 'batch_size'}},
                        opset_version = 17,
                    )

                    ov_model = ov.convert_model(onnxPath, example_input=dummy_input)
                    xmlPath = onnxPath.replace(".onnx", ".xml")
                    ov.save_model(ov_model, xmlPath)
                    print(f"Exported OpenVINO (decoder head): {xmlPath}")
                    del ov_model

                case _:
                    print(f"Export type không hợp lệ: {exportType}")

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Export error: {str(ex)}")
            raise
        finally:
            try:
                del wrapper
            except NameError:
                pass
            try:
                del dummy
            except NameError:
                pass
            if tempModel is not None and hasattr(tempModel, 'cpu'):
                tempModel.cpu()
            del tempModel
            torch.cuda.empty_cache()

    # ── Stop ──────────────────────────────────────────────────────────
    def StopTraining(self):
        self.IsStopTraining = True
        self.StopTrainingEvent.wait(timeout=120)
        self.IsStopTraining = False

    def Predict(self, img):
        """Predict segmentation mask for a single image.
        img: numpy array (H, W, C) or PIL Image."""
        if self.model is None:
            raise RuntimeError("Model not loaded. Call LoadWeight first.")
        self.model.eval()
        with torch.no_grad():
            if isinstance(img, np.ndarray):
                img = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0).float() / 255.0
            elif isinstance(img, Image.Image):
                img = torchvision.transforms.functional.to_tensor(img).unsqueeze(0)
            img = img.to(self.Device)
            output = self.model(img)
            pred = output.argmax(dim=1).squeeze(0).cpu().numpy()
        return pred

    def BatchPredict(self, batchImg):
        """Predict segmentation masks for a batch of images.
        batchImg: numpy array (B, H, W, C) or list of PIL Images."""
        if self.model is None:
            raise RuntimeError("Model not loaded. Call LoadWeight first.")
        self.model.eval()
        with torch.no_grad():
            if isinstance(batchImg, np.ndarray):
                batchImg = torch.from_numpy(batchImg).permute(0, 3, 1, 2).float() / 255.0
            batchImg = batchImg.to(self.Device)
            output = self.model(batchImg)
            preds = output.argmax(dim=1).cpu().numpy()
        return preds
