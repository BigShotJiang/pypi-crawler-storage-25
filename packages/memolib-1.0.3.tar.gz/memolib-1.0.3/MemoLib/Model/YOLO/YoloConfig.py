from dataclasses import dataclass, field
from typing import ClassVar
from ..BaseModel.eModelBase import eOptimizerType
from ..BaseModel.eDetectionModel import eYoloDetectionModel
from ..BaseModel.eSegmentationModel import eYoloSegmentationModel
from ..BaseModel.eClassificationModel import eYoloClassificationModel

_YOLO_IMAGE_SIZE: dict = {
    # YOLOv5
    eYoloDetectionModel.YoloV5n: 640,
    eYoloDetectionModel.YoloV5s: 640,
    eYoloDetectionModel.YoloV5m: 640,
    eYoloDetectionModel.YoloV5l: 640,
    eYoloDetectionModel.YoloV5x: 640,
    # YOLOv8
    eYoloDetectionModel.YoloV8n: 640,
    eYoloDetectionModel.YoloV8s: 640,
    eYoloDetectionModel.YoloV8m: 640,
    eYoloDetectionModel.YoloV8l: 640,
    eYoloDetectionModel.YoloV8x: 640,
    # YOLO11
    eYoloDetectionModel.Yolo11n: 640,
    eYoloDetectionModel.Yolo11s: 640,
    eYoloDetectionModel.Yolo11m: 640,
    eYoloDetectionModel.Yolo11l: 640,
    eYoloDetectionModel.Yolo11x: 640,
    # YOLO26
    eYoloDetectionModel.Yolo26n: 640,
    eYoloDetectionModel.Yolo26s: 640,
    eYoloDetectionModel.Yolo26m: 640,
    eYoloDetectionModel.Yolo26l: 640,
    eYoloDetectionModel.Yolo26x: 640,
}

@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ProcessName:        str = ""
    ImageSize:          int = None
    Architecture:       str = eYoloDetectionModel.Yolo11n
    IsUsePretrained:    bool = True
    TaskType:           str = "detect"  # detect | segment | classify

    # ── Training ─────────────────────────────────
    Epochs:             int = 100
    BatchSize:          int = 16
    LearningRate:       float = 0.01
    Momentum:           float = 0.937
    WeightDecay:        float = 0.0005
    OptimizerType:      str = eOptimizerType.SGD
    Patience:           int = 50
    WarmupEpochs:       int = 3
    WarmupLearningRate: float = None
    ImgSize:            int = None  # override ImageSize (Ultralytics param)
    Device:             str = ""  # empty = auto, "0" = cuda:0, "cpu" = cpu
    Workers:            int = 8
    Amp:                bool = True  # Automatic Mixed Precision
    Project:            str = "TrainResult"
    Name:               str = ""
    SavePeriod:         int = -1  # -1 = save at every epoch, >=0 = save every N epochs
    Cache:              bool = False  # cache images for training

    # ── DataPaths ────────────────────────────────
    DatasetPath:        str = ""
    PretrainedPath:     str = ""  # empty = use ultralytics pretrained

    # ── Augmentation ─────────────────────────────
    HsvH:               float = 0.015  # HSV-Hue augmentations
    HsvS:               float = 0.7    # HSV-Saturation
    HsvV:               float = 0.4    # HSV-Value
    Degrees:            float = 0.0    # rotation
    Translate:          float = 0.1    # translation
    Scale:              float = 0.5    # scale
    Shear:              float = 0.0    # shear
    Perspective:        float = 0.0    # perspective
    FlipHorizontal:     float = 0.5    # flip left-right
    FlipVertical:       float = 0.0    # flip up-down
    Mosaic:             float = 0.0    # mosaic augmentation
    MixUp:              float = 0.0    # MixUp augmentation
    CopyPaste:          float = 0.0    # Copy-Paste augmentation
    Erosion:            float = 1.0    # erosion

    # ── Class variable (không vào __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ProcessName", "ImageSize", "Architecture", "IsUsePretrained", "TaskType"],
        "Training":     ["Epochs", "BatchSize", "LearningRate", "Momentum",
                         "WeightDecay", "OptimizerType", "Patience", "WarmupEpochs",
                         "WarmupLearningRate", "ImgSize", "Device", "Workers", "Amp",
                         "Project", "Name", "SavePeriod", "Cache"],
        "DataPaths":    ["DatasetPath", "PretrainedPath"],
        "Augmentation": ["HsvH", "HsvS", "HsvV", "Degrees", "Translate", "Scale",
                         "Shear", "Perspective", "FlipHorizontal", "FlipVertical",
                         "Mosaic", "MixUp", "CopyPaste", "Erosion"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        object.__setattr__(self, "_image_size_overridden", self.ImageSize is not None)

        if self.ImageSize is None:
            object.__setattr__(self, "ImageSize",
                               _YOLO_IMAGE_SIZE.get(self.Architecture, 640))

        if self.ImgSize is None:
            object.__setattr__(self, "ImgSize", self.ImageSize)

        if self.WarmupLearningRate is None:
            self.WarmupLearningRate = self.LearningRate * 0.01

        if self.Device is None or self.Device == "":
            import torch
            self.Device = "0" if torch.cuda.is_available() else "cpu"

        if self.Name is None or self.Name == "":
            self.Name = f"{self.ProcessName}_{self.Architecture}_{self.TaskType}"

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

        if name == "ImageSize":
            object.__setattr__(self, "_image_size_overridden", True)
            if getattr(self, "ImgSize", None) is None or not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImgSize", value)

        elif name == "Architecture":
            if not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImageSize",
                                    _YOLO_IMAGE_SIZE.get(value, 640))
                super().__setattr__("ImgSize", _YOLO_IMAGE_SIZE.get(value, 640))

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' không thuộc category '{cat}'")

    def reset_image_size(self):
        """ Reset ImageSize về auto theo Architecture """
        object.__setattr__(self, "_image_size_overridden", False)
        size = _YOLO_IMAGE_SIZE.get(self.Architecture, 640)
        object.__setattr__(self, "ImageSize", size)
        object.__setattr__(self, "ImgSize", size)
