from os import path, makedirs
import torch
from threading import Thread, Event
import datetime
from ..BaseModel.IModel import IModel
from ..BaseModel.eModelBase import eModelExportType
from ..BaseModel.eDetectionModel import eYoloDetectionModel
from ..BaseModel.eSegmentationModel import eYoloSegmentationModel
from ..BaseModel.eClassificationModel import eYoloClassificationModel
from .YoloConfig import TrainingConfig

try:
    from ultralytics import YOLO as UltralyticsYOLO
    ULTRALYTICS_AVAILABLE = True
except ImportError:
    ULTRALYTICS_AVAILABLE = False

_MODEL_WEIGHT_MAP = {
    # YOLOv5
    eYoloDetectionModel.YoloV5n: "yolov5n.pt",
    eYoloDetectionModel.YoloV5s: "yolov5s.pt",
    eYoloDetectionModel.YoloV5m: "yolov5m.pt",
    eYoloDetectionModel.YoloV5l: "yolov5l.pt",
    eYoloDetectionModel.YoloV5x: "yolov5x.pt",
    # YOLOv8
    eYoloDetectionModel.YoloV8n: "yolov8n.pt",
    eYoloDetectionModel.YoloV8s: "yolov8s.pt",
    eYoloDetectionModel.YoloV8m: "yolov8m.pt",
    eYoloDetectionModel.YoloV8l: "yolov8l.pt",
    eYoloDetectionModel.YoloV8x: "yolov8x.pt",
    # YOLO11
    eYoloDetectionModel.Yolo11n: "yolo11n.pt",
    eYoloDetectionModel.Yolo11s: "yolo11s.pt",
    eYoloDetectionModel.Yolo11m: "yolo11m.pt",
    eYoloDetectionModel.Yolo11l: "yolo11l.pt",
    eYoloDetectionModel.Yolo11x: "yolo11x.pt",
    # YOLO26
    eYoloDetectionModel.Yolo26n: "yolo26n.pt",
    eYoloDetectionModel.Yolo26s: "yolo26s.pt",
    eYoloDetectionModel.Yolo26m: "yolo26m.pt",
    eYoloDetectionModel.Yolo26l: "yolo26l.pt",
    eYoloDetectionModel.Yolo26x: "yolo26x.pt",
}

_SEGMENT_WEIGHT_MAP = {
    # YOLOv8
    eYoloSegmentationModel.YoloV8n: "yolov8n-seg.pt",
    eYoloSegmentationModel.YoloV8s: "yolov8s-seg.pt",
    eYoloSegmentationModel.YoloV8m: "yolov8m-seg.pt",
    eYoloSegmentationModel.YoloV8l: "yolov8l-seg.pt",
    eYoloSegmentationModel.YoloV8x: "yolov8x-seg.pt",
    # YOLO11
    eYoloSegmentationModel.Yolo11n: "yolo11n-seg.pt",
    eYoloSegmentationModel.Yolo11s: "yolo11s-seg.pt",
    eYoloSegmentationModel.Yolo11m: "yolo11m-seg.pt",
    eYoloSegmentationModel.Yolo11l: "yolo11l-seg.pt",
    eYoloSegmentationModel.Yolo11x: "yolo11x-seg.pt",
    # YOLO26
    eYoloSegmentationModel.Yolo26n: "yolo26n-seg.pt",
    eYoloSegmentationModel.Yolo26s: "yolo26s-seg.pt",
    eYoloSegmentationModel.Yolo26m: "yolo26m-seg.pt",
    eYoloSegmentationModel.Yolo26l: "yolo26l-seg.pt",
    eYoloSegmentationModel.Yolo26x: "yolo26x-seg.pt",
}

_CLASS_WEIGHT_MAP = {
    # YOLOv8
    eYoloClassificationModel.YoloV8n: "yolov8n-cls.pt",
    eYoloClassificationModel.YoloV8s: "yolov8s-cls.pt",
    eYoloClassificationModel.YoloV8m: "yolov8m-cls.pt",
    eYoloClassificationModel.YoloV8l: "yolov8l-cls.pt",
    eYoloClassificationModel.YoloV8x: "yolov8x-cls.pt",
    # YOLO11
    eYoloClassificationModel.Yolo11n: "yolo11n-cls.pt",
    eYoloClassificationModel.Yolo11s: "yolo11s-cls.pt",
    eYoloClassificationModel.Yolo11m: "yolo11m-cls.pt",
    eYoloClassificationModel.Yolo11l: "yolo11l-cls.pt",
    eYoloClassificationModel.Yolo11x: "yolo11x-cls.pt",
    # YOLO26
    eYoloClassificationModel.Yolo26n: "yolo26n-cls.pt",
    eYoloClassificationModel.Yolo26s: "yolo26s-cls.pt",
    eYoloClassificationModel.Yolo26m: "yolo26m-cls.pt",
    eYoloClassificationModel.Yolo26l: "yolo26l-cls.pt",
    eYoloClassificationModel.Yolo26x: "yolo26x-cls.pt",
}


class Yolo(IModel):

    @property
    def IsTraining(self):
        return self._isTraining

    @IsTraining.setter
    def IsTraining(self, value):
        self._isTraining = value

    @property
    def IsStopTraining(self):
        return self._isStopTraining

    @IsStopTraining.setter
    def IsStopTraining(self, value):
        self._isStopTraining = value

    def __init__(self):
        self.cfg = TrainingConfig()
        self._isTraining = False
        self._isStopTraining = False
        self.StopTrainingEvent = Event()
        self.model = None
        self.callbacks = None
        self.ClassesNumber = 0
        self.ClassesList = []
        self.ProcessName = ""
        self.Device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._log_file = None
        self._train_result_path = None

    # ── Helpers ───────────────────────────────────────────────────────
    def _write_log(self, msg: str):
        line = msg + "\n"
        print(msg)
        if self._log_file:
            self._log_file.write(line)
            self._log_file.flush()

    # ── Load weight ───────────────────────────────────────────────────
    def LoadWeight(self, weightPath: str = None):
        data_params = self.cfg.get_by_category("DataPaths")
        model_params = self.cfg.get_by_category("ModelParams")

        task_type = model_params["TaskType"]
        architecture = model_params["Architecture"]
        is_pretrained = model_params["IsUsePretrained"]

        # Determine weight file
        if weightPath and path.exists(weightPath):
            weight_file = weightPath
        elif weightPath:
            raise FileNotFoundError(f"Weight file không tồn tại: {weightPath}")
        else:
            weight_file = data_params["PretrainedPath"]

        # Nếu không có pretrained path, dùng ultralytics weight map
        if not weight_file or weight_file == "":
            weight_name = self._get_weight_name(architecture, task_type)
            if weight_name and is_pretrained:
                weight_file = weight_name  # ultralytics sẽ tự download
            else:
                raise ValueError(
                    "Cần cung cấp PretrainedPath hoặc IsUsePretrained=True với architecture hợp lệ"
                )

        self.model = UltralyticsYOLO(weight_file)
        return self.model

    @staticmethod
    def _get_weight_name(architecture, task_type: str):
        if task_type == "detect":
            return _MODEL_WEIGHT_MAP.get(architecture)
        elif task_type == "segment":
            return _SEGMENT_WEIGHT_MAP.get(architecture)
        elif task_type == "classify":
            return _CLASS_WEIGHT_MAP.get(architecture)
        return None

    # ── Build train kwargs ────────────────────────────────────────────
    def _build_train_kwargs(self):
        model_params = self.cfg.get_by_category("ModelParams")
        train_params = self.cfg.get_by_category("Training")
        aug_params = self.cfg.get_by_category("Augmentation")

        img_size = train_params["ImgSize"]
        task_type = model_params["TaskType"]

        kwargs = {
            "task": task_type,
            "imgsz": img_size,
            "epochs": train_params["Epochs"],
            "batch": train_params["BatchSize"],
            "lr0": train_params["LearningRate"],
            "momentum": train_params["Momentum"],
            "weight_decay": train_params["WeightDecay"],
            "patience": train_params["Patience"],
            "warmup_epochs": train_params["WarmupEpochs"],
            "warmup_momentum": 0.8,
            "warmup_bias_lr": train_params["WarmupLearningRate"],
            "device": train_params["Device"] if train_params["Device"] else "",
            "workers": train_params["Workers"],
            "amp": train_params["Amp"],
            "cache": train_params["Cache"],
            "save": True,
            "save_period": train_params["SavePeriod"],
            "project": path.abspath(self.cfg.Project),
            "name": self.ProcessName,
            "exist_ok": True,
            # ── Augmentation ──
            "hsv_h": aug_params["HsvH"],
            "hsv_s": aug_params["HsvS"],
            "hsv_v": aug_params["HsvV"],
            "degrees": aug_params["Degrees"],
            "translate": aug_params["Translate"],
            "scale": aug_params["Scale"],
            "shear": aug_params["Shear"],
            "perspective": aug_params["Perspective"],
            "flipud": aug_params["FlipVertical"],
            "fliplr": aug_params["FlipHorizontal"],
            "mosaic": aug_params["Mosaic"],
            "mixup": aug_params["MixUp"],
            "copy_paste": aug_params["CopyPaste"],
        }
        return kwargs

    # ── Callbacks ─────────────────────────────────────────────────────
    def _register_stop_callback(self):
        """Register stop callback using Ultralytics add_callback API."""
        def _on_epoch_end(trainer):
            if self._isStopTraining:
                trainer.stop = True  # Ultralytics trainer stop signal

        def _on_train_end(trainer):
            # ── Export ────────────────────────────────────────
            weights_dir = path.join(self.cfg.Project, self.ProcessName, "weights")
            for weight_file in ["best.pt", "last.pt"]:
                weight_pt = path.join(weights_dir, weight_file)
                if path.exists(weight_pt):
                    try:
                        self.Export(weight_pt, eModelExportType.ONNX, self.cfg.ImgSize)
                        self.Export(weight_pt, eModelExportType.OpenVINO, self.cfg.ImgSize)
                        # self.Export(weight_pt, eModelExportType.TensorRT, self.cfg.ImgSize)
                    except Exception as ex:
                        self._write_log(f"Export error ({weight_file}): {str(ex)}")

            if self._log_file:
                self._log_file.close()
                self._log_file = None
            self.IsTraining = False
            self.StopTrainingEvent.set()
            if self.callbacks:
                self.callbacks("Info", "Training completed")

        self.model.add_callback("on_train_epoch_end", _on_epoch_end)
        self.model.add_callback("on_train_end", _on_train_end)

    # ── Train ─────────────────────────────────────────────────────────
    def Train(self, callbacks=None):
        try:
            if self.IsTraining:
                return

            self.IsTraining = True
            self.callbacks = callbacks
            self.StopTrainingEvent.clear()

            model_params = self.cfg.get_by_category("ModelParams")
            train_params = self.cfg.get_by_category("Training")
            data_params = self.cfg.get_by_category("DataPaths")

            task_type = model_params["TaskType"]
            dataset_path = data_params["DatasetPath"]

            # ── Validate dataset path ──
            if not dataset_path or not path.exists(dataset_path):
                raise FileNotFoundError(f"Không tìm thấy thư mục dataset: {dataset_path}")

            # Validate dataset structure based on task type
            yaml_path = dataset_path  # default: pass dataset dir directly (Ultralytics auto-generates YAML)
            if task_type == "classify":
                train_dir = path.join(dataset_path, "train")
                val_dir = path.join(dataset_path, "val")
            else:
                # detect/segment: YAML file or directory with data.yaml
                yaml_path = path.join(dataset_path, "data.yaml")
                if path.exists(yaml_path):
                    pass  # use yaml
                elif path.exists(path.join(dataset_path, "train")):
                    yaml_path = path.join(dataset_path, "data.yaml")
                    # Auto-generate YAML if needed
                    self._auto_generate_yaml(dataset_path, task_type)
                else:
                    raise FileNotFoundError(
                        f"Dataset cần có cấu trúc 'train/' và 'val/' hoặc file 'data.yaml'"
                    )

            # ── ProcessName ──
            arch_name = model_params["Architecture"].name if hasattr(model_params["Architecture"], "name") else str(model_params["Architecture"])
            self.ProcessName = f"Yolo_{arch_name}_{task_type}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # ── Load model ──
            self.model = self.LoadWeight()

            # ── Get classes info ──
            if task_type == "classify":
                train_dir = path.join(dataset_path, "train")
                if path.exists(train_dir):
                    self.ClassesList = sorted([d for d in __import__('os').listdir(train_dir)
                                               if path.isdir(path.join(train_dir, d))])
                    self.ClassesNumber = len(self.ClassesList)
                    # Save classes
                    save_folder = path.join(self.cfg.Project, self.ProcessName)
                    makedirs(save_folder, exist_ok=True)
                    with open(path.join(save_folder, "classes.txt"), 'w') as f:
                        f.write("\n".join(self.ClassesList))

            # ── Open log file ──
            save_folder = path.join(self.cfg.Project, self.ProcessName)
            makedirs(save_folder, exist_ok=True)
            self._log_file = open(path.join(save_folder, "training.log"), 'w')
            self._train_result_path = save_folder

            self._write_log(f"Task: {task_type}")
            self._write_log(f"Architecture: {arch_name}")
            self._write_log(f"Image size: {train_params['ImgSize']}")
            self._write_log(f"Device: {train_params['Device']}")
            if self.ClassesNumber > 0:
                self._write_log(f"Classes: {self.ClassesNumber}")

            # ── Build train kwargs ──
            train_kwargs = self._build_train_kwargs()
            train_kwargs["data"] = yaml_path if path.exists(yaml_path) else dataset_path

            # ── Train in thread ──
            def __train_wrapper():
                try:
                    self._register_stop_callback()
                    self.model.train(**train_kwargs)
                except Exception as e:
                    msg = f"Training error: {str(e)}"
                    self._write_log(msg)
                    if self.callbacks:
                        self.callbacks("Error", msg)
                    self.IsTraining = False
            self._train_thread = Thread(target=__train_wrapper)
            self._train_thread.name = "YoloTrainThread"
            self._train_thread.start()

        except Exception as ex:
            self.IsTraining = False
            msg = f"Error while preparing training: {str(ex)}"
            print(msg)
            if callbacks is not None:
                callbacks("Error", msg)

    # ── Auto generate data.yaml ───────────────────────────────────────
    def _auto_generate_yaml(self, dataset_path: str, task_type: str):
        yaml_path = path.join(dataset_path, "data.yaml")
        train_dir = path.join(dataset_path, "train")
        val_dir = path.join(dataset_path, "val")

        if not path.exists(train_dir) or not path.exists(val_dir):
            return

        # Count classes
        train_classes = sorted([d for d in __import__('os').listdir(train_dir)
                               if path.isdir(path.join(train_dir, d))])
        val_classes = sorted([d for d in __import__('os').listdir(val_dir)
                             if path.isdir(path.join(val_dir, d))])

        nc = len(train_classes)
        self.ClassesNumber = nc
        self.ClassesList = train_classes

        yaml_content = f"path: {dataset_path}\n"
        yaml_content += f"nc: {nc}\n"
        yaml_content += f"names: {train_classes}\n"

        if task_type in ("detect", "segment"):
            yaml_content += f"train: {path.join('..', 'train')}\n"
            yaml_content += f"val: {path.join('..', 'val')}\n"
        elif task_type == "classify":
            yaml_content += f"train: {path.join('..', 'train')}\n"
            yaml_content += f"val: {path.join('..', 'val')}\n"

        with open(yaml_path, 'w', encoding='utf-8') as f:
            f.write(yaml_content)

    # ── Stop ──────────────────────────────────────────────────────────
    def StopTraining(self):
        self._isStopTraining = True
        self.StopTrainingEvent.set()
        # Wait for thread to finish
        if hasattr(self, '_train_thread') and self._train_thread.is_alive():
            self._train_thread.join()
        self._isStopTraining = False

    # ── Predict ───────────────────────────────────────────────────────
    def Predict(self, img):
        if self.model is None:
            raise RuntimeError("Model chưa được load. Gọi LoadWeight() trước.")
        results = self.model(img)
        return results[0]

    # ── BatchPredict ──────────────────────────────────────────────────
    def BatchPredict(self, batchImg):
        if self.model is None:
            raise RuntimeError("Model chưa được load. Gọi LoadWeight() trước.")
        results = self.model(batchImg)
        return results

    # ── Export ────────────────────────────────────────────────────────
    def Export(self, pathToPytorchModel: str, exportType: eModelExportType, exportImageSize: int = 640):
        try:
            if not path.exists(pathToPytorchModel):
                raise FileNotFoundError(f"Weight file không tồn tại: {pathToPytorchModel}")

            model = UltralyticsYOLO(pathToPytorchModel)

            format_map = {
                eModelExportType.ONNX: "onnx",
                eModelExportType.OpenVINO: "openvino",
                eModelExportType.TensorRT: "engine",
            }


            export_format = format_map.get(exportType)
            if export_format is None:
                print(f"Export type không hợp lệ: {exportType}")
                return

            export_dir = path.dirname(pathToPytorchModel)
            makedirs(export_dir, exist_ok=True)

            model.export(
                format=export_format,
                imgsz=exportImageSize,
                half=exportType == eModelExportType.TensorRT,
                dynamic=False,
                simplify=True,
                device=self.Device if isinstance(self.Device, str) else "0",
            )

            print(f"Exported {export_format} from {pathToPytorchModel}")

        except Exception as ex:
            print(f"Export error: {str(ex)}")
            if self.callbacks is not None:
                self.callbacks("Error", f"Export error: {str(ex)}")
            raise
