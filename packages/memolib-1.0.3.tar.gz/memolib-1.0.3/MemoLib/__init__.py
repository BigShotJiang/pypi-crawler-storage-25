"""MemoLib - A comprehensive OCR and computer vision model library."""

from .Model.BaseModel import (
    IModel,
    eModelType, eDetectionModelType, eSegmentationModelType,
    eClassificationModelType, eRecognitionModelType,
    eAnomalyDetectionModelType,
    eModelExportType, eOptimizerType,
    eYoloDetectionModel, eRFDetrDetectionModel,
    eYoloSegmentationModel,
    eYoloClassificationModel, eRFDetrClassificationModel,
    eEfficientNetModel, ePPLCNetModel,
    eDinomalyModel, eINPFormerlyModel,
)

from .Model import (
    SVTRV2, SVTRV2RecognitionModel,
    TrainingConfig,
    SVTRv2LNConvTwo33,
    SMTRDecoder, RCTCDecoder, GTCDecoder,
    GTCLoss, CTCLoss, SMTRLoss,
    SMTRLabelEncode, CTCLabelEncode, GTCLabelEncode,
    DropPath, Identity, Mlp,
)

__version__ = '0.1.0'

__all__ = [
    '__version__',
    # Base model types
    'IModel',
    'eModelType', 'eDetectionModelType', 'eSegmentationModelType',
    'eClassificationModelType', 'eRecognitionModelType',
    'eAnomalyDetectionModelType',
    'eModelExportType', 'eOptimizerType',
    'eYoloDetectionModel', 'eRFDetrDetectionModel',
    'eYoloSegmentationModel',
    'eYoloClassificationModel', 'eRFDetrClassificationModel',
    'eEfficientNetModel', 'ePPLCNetModel',
    'eDinomalyModel', 'eINPFormerlyModel',
    # SVTRV2 models
    'SVTRV2', 'SVTRV2RecognitionModel',
    'TrainingConfig',
    'SVTRv2LNConvTwo33',
    'SMTRDecoder', 'RCTCDecoder', 'GTCDecoder',
    'GTCLoss', 'CTCLoss', 'SMTRLoss',
    'SMTRLabelEncode', 'CTCLabelEncode', 'GTCLabelEncode',
    'DropPath', 'Identity', 'Mlp',
]
