"""Add resy_token and resy_reservation_id to bookings

Revision ID: 0021
Revises: 0020
Create Date: 2026-04-25
"""

import sqlalchemy as sa

from alembic import op

revision = "0021"
down_revision = "0020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("bookings", sa.Column("resy_token", sa.Text(), nullable=True))
    op.add_column(
        "bookings", sa.Column("resy_reservation_id", sa.Integer(), nullable=True)
    )


def downgrade() -> None:
    op.drop_column("bookings", "resy_reservation_id")
    op.drop_column("bookings", "resy_token")
