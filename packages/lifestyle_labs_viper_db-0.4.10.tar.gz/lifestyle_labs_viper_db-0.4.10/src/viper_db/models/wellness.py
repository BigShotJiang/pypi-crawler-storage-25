from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class Wellness(SQLModel, table=True):
    __tablename__ = "wellness"
    __mapper_args__ = {"eager_defaults": True}

    experience_id: int = Field(
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )
    wellness_type: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    booking_required: bool | None = Field(
        default=True,
        sa_column=sa.Column(sa.Boolean, server_default=sa.text("true")),
    )
    amenities: list[str] | None = Field(
        default_factory=list,
        sa_column=sa.Column(sa.ARRAY(sa.Text), server_default="{}"),
    )

    experience: "Experience" = Relationship(back_populates="wellness_detail")
