from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class Neighborhood(SQLModel, table=True):
    __tablename__ = "neighborhoods"
    __table_args__ = (sa.UniqueConstraint("name", "city"),)
    __mapper_args__ = {"eager_defaults": True}

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    city: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    borough: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    centroid_lat: float | None = Field(
        default=None, sa_column=sa.Column(sa.Numeric(9, 6))
    )
    centroid_lng: float | None = Field(
        default=None, sa_column=sa.Column(sa.Numeric(9, 6))
    )

    experiences: list["Experience"] = Relationship(back_populates="neighborhood")
