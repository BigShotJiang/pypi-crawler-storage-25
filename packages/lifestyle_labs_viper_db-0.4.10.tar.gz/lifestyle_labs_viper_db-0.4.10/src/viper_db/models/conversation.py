from datetime import datetime
from typing import TYPE_CHECKING, Optional
from uuid import UUID

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

from ._base import utcnow_field

if TYPE_CHECKING:
    from .booking import Booking
    from .experience import Experience
    from .message import Message
    from .user import User


class Conversation(SQLModel, table=True):
    __tablename__ = "conversations"
    __table_args__ = (
        sa.Index("idx_conversations_user_id", "user_id"),
        sa.Index("idx_conversations_booking_id", "booking_id"),
    )
    __mapper_args__ = {"eager_defaults": True}

    id: int | None = Field(default=None, primary_key=True)
    name: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    thread_id: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    user_id: UUID = Field(
        sa_column=sa.Column(
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
    )
    booking_id: int | None = Field(
        default=None,
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("bookings.id", ondelete="SET NULL"),
        ),
    )
    experience_id: int | None = Field(
        default=None,
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="SET NULL"),
        ),
    )
    created_at: datetime = utcnow_field()
    updated_at: datetime = utcnow_field()

    user: "User" = Relationship(back_populates="conversations")
    booking: Optional["Booking"] = Relationship(back_populates="conversations")
    experience: Optional["Experience"] = Relationship(back_populates="conversations")
    messages: list["Message"] = Relationship(back_populates="conversation")
