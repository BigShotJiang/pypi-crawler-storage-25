from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

import sqlalchemy as sa
from pgvector.sqlalchemy import Vector
from sqlalchemy.dialects.postgresql import TSVECTOR
from sqlmodel import Field, Relationship, SQLModel

from ._base import utcnow_field

if TYPE_CHECKING:
    from .booking import Booking
    from .conversation import Conversation
    from .experience_type import ExperienceType
    from .neighborhood import Neighborhood
    from .nightlife import Nightlife
    from .restaurant import Restaurant
    from .wellness import Wellness


class Experience(SQLModel, table=True):
    __tablename__ = "experiences"
    __table_args__ = (
        sa.CheckConstraint(
            "price_tier BETWEEN 1 AND 4", name="ck_experiences_price_tier"
        ),
        sa.Index("idx_experiences_type", "experience_type_id"),
        sa.Index("idx_experiences_neighborhood", "neighborhood_id"),
        sa.Index("idx_experiences_price_tier", "price_tier"),
        sa.Index("idx_experiences_is_active", "is_active"),
        sa.Index("idx_experiences_vibes", "vibes", postgresql_using="gin"),
    )
    __mapper_args__ = {"eager_defaults": True}

    id: int | None = Field(default=None, primary_key=True)
    experience_type_id: int = Field(foreign_key="experience_types.id", nullable=False)
    name: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    description: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    address: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    latitude: float | None = Field(
        default=None,
        sa_column=sa.Column(sa.Numeric(9, 6)),
    )
    longitude: float | None = Field(
        default=None,
        sa_column=sa.Column(sa.Numeric(9, 6)),
    )
    neighborhood_id: int | None = Field(default=None, foreign_key="neighborhoods.id")
    price_tier: int | None = Field(default=None, sa_column=sa.Column(sa.SmallInteger))
    price: float | None = Field(
        default=None,
        sa_column=sa.Column(sa.Numeric(10, 2)),
    )
    vibes: list[str] | None = Field(
        default_factory=list,
        sa_column=sa.Column(sa.ARRAY(sa.Text), server_default="{}"),
    )
    categories: list[str] | None = Field(
        default_factory=list,
        sa_column=sa.Column(sa.ARRAY(sa.Text), server_default="{}"),
    )
    embedding: list[float] | None = Field(
        default=None,
        sa_column=sa.Column(Vector(1536)),
    )
    phone: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    website: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    image_urls: list[str] | None = Field(
        default_factory=list,
        sa_column=sa.Column(sa.ARRAY(sa.Text), server_default="{}"),
    )
    search_vector: Any = Field(
        default=None,
        sa_column=sa.Column(TSVECTOR),
    )
    is_active: bool = Field(default=True, nullable=False)
    booking_rules: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    cancellation_policy: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    created_at: datetime = utcnow_field()
    updated_at: datetime = utcnow_field()

    experience_type: "ExperienceType" = Relationship(back_populates="experiences")
    neighborhood: Optional["Neighborhood"] = Relationship(back_populates="experiences")
    restaurant: Optional["Restaurant"] = Relationship(back_populates="experience")
    nightlife_detail: Optional["Nightlife"] = Relationship(back_populates="experience")
    wellness_detail: Optional["Wellness"] = Relationship(back_populates="experience")
    bookings: list["Booking"] = Relationship(back_populates="experience")
    conversations: list["Conversation"] = Relationship(back_populates="experience")
