"""SMS conversation model — maps phone numbers to LangGraph threads."""

from datetime import datetime

import sqlalchemy as sa
from sqlmodel import Field, SQLModel

from ._base import utcnow_field


class SmsConversation(SQLModel, table=True):
    __tablename__ = "sms_conversations"
    __mapper_args__ = {"eager_defaults": True}

    id: int | None = Field(default=None, primary_key=True)
    phone_number: str = Field(
        sa_column=sa.Column(sa.Text, unique=True, nullable=False),
    )
    thread_id: str = Field(
        sa_column=sa.Column(sa.Text, nullable=False),
    )
    assistant_id: str | None = Field(
        default=None,
        sa_column=sa.Column(sa.Text),
    )
    created_at: datetime = utcnow_field()
    last_message_at: datetime = utcnow_field()
