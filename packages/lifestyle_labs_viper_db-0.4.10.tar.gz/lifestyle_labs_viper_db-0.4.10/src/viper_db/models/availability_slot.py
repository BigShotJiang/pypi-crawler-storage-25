"""
Availability slot model — stores scraped Resy table availability.

Each row represents a single time slot for a specific restaurant, date,
party size, and table type. The unique constraint on
(experience_id, date, party_size, time, slot_type) prevents duplicates
and enables upsert logic in the scraping pipeline.
"""

import datetime as dt
from typing import Optional

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import Field, SQLModel

from ._base import utcnow_field


class AvailabilitySlot(SQLModel, table=True):
    __tablename__ = "availability_slots"
    __table_args__ = (
        sa.UniqueConstraint(
            "experience_id",
            "date",
            "party_size",
            "time",
            "slot_type",
            name="uq_availability_slot",
        ),
        sa.Index(
            "idx_availability_experience_date",
            "experience_id",
            "date",
        ),
        sa.Index(
            "idx_availability_date_available",
            "date",
            "is_available",
            postgresql_where=sa.text("is_available = true"),
        ),
    )
    __mapper_args__ = {"eager_defaults": True}

    id: Optional[int] = Field(
        default=None,
        sa_column=sa.Column(sa.BigInteger, primary_key=True, autoincrement=True),
    )
    experience_id: int = Field(
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            nullable=False,
        ),
    )
    date: dt.date = Field(sa_column=sa.Column(sa.Date, nullable=False))
    party_size: int = Field(sa_column=sa.Column(sa.SmallInteger, nullable=False))
    time: dt.time = Field(sa_column=sa.Column(sa.Time, nullable=False))
    end_time: Optional[dt.time] = Field(default=None, sa_column=sa.Column(sa.Time))
    slot_type: Optional[str] = Field(default=None, sa_column=sa.Column(sa.Text))
    is_available: bool = Field(
        default=True,
        sa_column=sa.Column(sa.Boolean, nullable=False, server_default=sa.text("true")),
    )
    metadata_: Optional[dict] = Field(
        default_factory=dict,
        sa_column=sa.Column("metadata", JSONB, server_default=sa.text("'{}'::jsonb")),
    )
    created_at: dt.datetime = utcnow_field()
    updated_at: dt.datetime = utcnow_field()
