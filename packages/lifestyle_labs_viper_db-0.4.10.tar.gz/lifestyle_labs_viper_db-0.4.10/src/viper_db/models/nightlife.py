from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class Nightlife(SQLModel, table=True):
    __tablename__ = "nightlife"
    __mapper_args__ = {"eager_defaults": True}

    experience_id: int = Field(
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )
    venue_type: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    has_dancefloor: bool | None = Field(
        default=False,
        sa_column=sa.Column(sa.Boolean, server_default=sa.text("false")),
    )
    dress_code: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    age_minimum: int | None = Field(
        default=21, sa_column=sa.Column(sa.SmallInteger, server_default=sa.text("21"))
    )
    cover_charge: float | None = Field(
        default=None,
        sa_column=sa.Column(sa.Numeric(8, 2)),
    )

    experience: "Experience" = Relationship(back_populates="nightlife_detail")
