"""Configurable async engine + session factory.

Each consumer (viper-api, viper-agents) reads its own DB URL from its own
config and passes it in via ``create_db_client``.
"""

from contextvars import ContextVar
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

_current_session: ContextVar[AsyncSession] = ContextVar("_current_session")


@dataclass
class DbClient:
    engine: AsyncEngine
    session_factory: async_sessionmaker[AsyncSession]

    def get_session(self) -> AsyncSession:
        return _current_session.get()

    def set_session(self, session: AsyncSession) -> None:
        _current_session.set(session)


def create_db_client(
    db_url: str,
    pool_size: int = 5,
    max_overflow: int = 10,
    pool_timeout: int = 10,
    pool_recycle: int = 300,
    connect_args: dict | None = None,
) -> DbClient:
    if "asyncpg" not in db_url:
        db_url = db_url.replace("postgresql://", "postgresql+asyncpg://", 1)

    engine = create_async_engine(
        db_url,
        echo=False,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_recycle=pool_recycle,
        pool_pre_ping=False,
        connect_args=connect_args or {},
    )

    session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    return DbClient(engine=engine, session_factory=session_factory)
