"""CRUD operations for the restaurants table."""

from typing import Optional

import sqlalchemy as sa
from sqlalchemy import func
from sqlalchemy import text as sa_text
from sqlalchemy.orm import selectinload
from sqlmodel import select

from viper_db.models.experience import Experience
from viper_db.models.neighborhood import Neighborhood
from viper_db.models.restaurant import Restaurant
from viper_db.utils.db import get_session

NEIGHBORHOOD_ALIASES: dict[str, str] = {
    "NoLita": "Nolita",
    "SoHo / Greenwich Village": "SoHo",
    "Midtown East": "Midtown",
    "Midtown West": "Midtown",
    "Central Park South": "Midtown",
    "Columbus Circle": "Midtown",
    "Hell's Kitchen": "Midtown",
    "Koreatown": "Midtown",
}


def _normalize_neighborhood(name: str) -> str:
    return NEIGHBORHOOD_ALIASES.get(name, name)


def _expand_neighborhood_ids(
    selected_ids: list[int],
    all_neighborhoods: list[dict],
) -> list[int]:
    """Given selected neighborhood IDs, expand to include all IDs that share
    the same canonical name."""
    id_to_canonical: dict[int, str] = {}
    canonical_to_ids: dict[str, list[int]] = {}
    for n in all_neighborhoods:
        canonical = _normalize_neighborhood(n["name"])
        id_to_canonical[n["id"]] = canonical
        canonical_to_ids.setdefault(canonical, []).append(n["id"])

    expanded = set(selected_ids)
    for sid in selected_ids:
        canonical = id_to_canonical.get(sid)
        if canonical:
            expanded.update(canonical_to_ids[canonical])
    return list(expanded)


CUISINE_ALIASES: dict[str, str] = {
    "Afro Caribbean": "Caribbean",
    "Afro-Caribbean": "Caribbean",
    "European-Caribbean": "Caribbean",
    "American (Asian-influenced)": "American",
    "American (bistro)": "American",
    "American (brunch)": "American",
    "American (wood-fired bar & grill)": "American",
    "American bistro": "American",
    "American seafood": "American",
    "American Tavern": "American",
    "Contemporary American": "American",
    "Contemporary American (Daniel Boulud)": "American",
    "New American": "American",
    "New American (wine bar + small plates)": "American",
    "Tuscan-American": "Italian",
    "Asian": "Asian",
    "Asian American": "Asian",
    "Contemporary Asian": "Asian",
    "Pan-Asian": "Asian",
    "Southeast Asian": "Asian",
    "Aperitivo Bar)": "Bar",
    "Bar Food": "Bar",
    "Cocktail bar": "Bar",
    "Cocktail Bar": "Bar",
    "Cocktail bar (Japanese-American)": "Bar",
    "Cocktail bar (Japanese-inspired)": "Bar",
    "Cocktail bar + bar snacks (and chef\u2019s counter in The Studio)": "Bar",
    "Cocktail-driven tasting menu": "Bar",
    "Cocktails": "Bar",
    "Lounge": "Bar",
    "Wine Bar": "Bar",
    "Oyster Bar": "Seafood",
    "Bistro": "French",
    "French - American": "French",
    "French (tabac-style wine bar)": "French",
    "French & Italian (bakery + dining room)": "French",
    "French Bistro": "French",
    "French Café": "French",
    "french mediterranean": "French",
    "French Seafood": "French",
    "Contemporary French": "French",
    "French Vietnamese": "Vietnamese",
    "Vietnamese (Bistro)": "Vietnamese",
    "Vietnamese-French": "Vietnamese",
    "British": "British",
    "British Seafood": "British",
    "Cantonese": "Chinese",
    "Cantonese-American": "Chinese",
    "Contemporary Chinese": "Chinese",
    "Chinese, Contemporary (wine bar)": "Chinese",
    "Sichuan": "Chinese",
    "Gastropub": "European",
    "Southern European": "European",
    "Iberian Seafood": "Spanish",
    "Spanish (pintxos + wine)": "Spanish",
    "Basque": "Spanish",
    "Tapas": "Spanish",
    "Italian (aperitivo bar + restaurant)": "Italian",
    "Italian (Campanian)": "Italian",
    "Italian (Emilian)": "Italian",
    "Italian (trattoria)": "Italian",
    "Italian Seafood": "Italian",
    "Italian-American": "Italian",
    "Italian-American (Cafe": "Italian",
    "Roman Italian": "Italian",
    "Japanese (Kappo)": "Japanese",
    "Japanese (Sushi)": "Japanese",
    "Japanese (udon)": "Japanese",
    "Japanese Izakaya": "Japanese",
    "Japanese ramen": "Japanese",
    "Japanese-inspired": "Japanese",
    "Japanese-inspired ramen": "Japanese",
    "Omakase": "Japanese",
    "Sushi": "Japanese",
    "Sushi Omakase": "Japanese",
    "Sustainable sushi": "Japanese",
    "Korean American": "Korean",
    "Korean BBQ": "Korean",
    "Korean Contemporary": "Korean",
    "Korean Fried Chicken": "Korean",
    "Korean Steakhouse": "Korean",
    "Korean-American": "Korean",
    "Korean-Southern (fusion)": "Korean",
    "Korean, Contemporary": "Korean",
    "Contemporary Korean": "Korean",
    "Eastern Mediterranean": "Mediterranean",
    "Israeli": "Mediterranean",
    "Israeli-inspired": "Mediterranean",
    "Tel Avivian": "Mediterranean",
    "Lebanese": "Middle Eastern",
    "Iranian": "Middle Eastern",
    "Persian": "Middle Eastern",
    "Moroccan": "Middle Eastern",
    "North Indian": "Indian",
    "North Indian (Punjabi)": "Indian",
    "Modern Mexican": "Mexican",
    "Thai (contemporary)": "Thai",
    "Hawaiian": "Hawaiian",
    "Filipino": "Filipino",
    "Peruvian": "Peruvian",
    "Bottle Service": "Nightlife",
    "Brunch": "Brunch",
    "Contemporary": "Modern",
    "Experimental": "Modern",
    "International": "Modern",
    "Modern": "Modern",
    "Live-Fire": "Steakhouse",
    "Market": "Market",
    "Pizza": "Pizza",
    "Southern": "Southern",
    "Kosher": "Kosher",
    "Jewish": "Jewish",
}


def _normalize_cuisine(raw: str) -> str:
    return CUISINE_ALIASES.get(raw, raw)


def _expand_cuisines(canonical_names: list[str]) -> list[str]:
    """Given canonical cuisine names, return all raw values that map to them."""
    expanded = set(canonical_names)
    for raw, canonical in CUISINE_ALIASES.items():
        if canonical in canonical_names:
            expanded.add(raw)
    return list(expanded)


class RestaurantsDAO:
    @property
    def session(self):
        return get_session()

    async def upsert(self, data) -> Restaurant:
        existing = await self.session.get(Restaurant, data.experience_id)
        if existing:
            for key, val in data.model_dump(exclude_unset=True).items():
                setattr(existing, key, val)
            await self.session.commit()
            return existing

        restaurant = Restaurant(**data.model_dump())
        self.session.add(restaurant)
        await self.session.commit()
        return restaurant

    async def get_by_id(self, experience_id: int) -> Optional[Restaurant]:
        return await self.session.get(Restaurant, experience_id)

    async def get_all(self) -> list[Restaurant]:
        result = await self.session.execute(select(Restaurant))
        return list(result.scalars().all())

    async def get_active_resy_roster(self) -> list[dict]:
        """Return (experience_id, resy_venue_id, resy_name)
        for active restaurants with Resy IDs."""
        result = await self.session.execute(
            select(
                Restaurant.experience_id,
                Restaurant.resy_venue_id,
                Restaurant.resy_name,
            )
            .join(Experience, Experience.id == Restaurant.experience_id)
            .where(
                Restaurant.resy_venue_id.is_not(None),
                Experience.is_active == True,  # noqa: E712
            )
        )
        return [
            {
                "experience_id": row[0],
                "resy_venue_id": row[1],
                "resy_name": row[2],
            }
            for row in result.fetchall()
        ]

    async def get_paginated(
        self, page: int = 1, page_size: int = 20
    ) -> tuple[list[Restaurant], int]:
        count_result = await self.session.execute(
            select(func.count()).select_from(Restaurant)
        )
        total = count_result.scalar_one()

        offset = (page - 1) * page_size
        result = await self.session.execute(
            select(Restaurant)
            .join(Experience, Restaurant.experience_id == Experience.id)
            .options(
                selectinload(Restaurant.experience).selectinload(Experience.neighborhood)
            )
            .order_by(Experience.name.asc(), Restaurant.experience_id.asc())
            .offset(offset)
            .limit(page_size)
        )
        return list(result.scalars().all()), total

    async def get_filtered(
        self,
        neighborhood_ids: list[int] | None = None,
        cuisines: list[str] | None = None,
        *,
        search: str | None = None,
    ) -> list[Restaurant]:
        stmt = (
            select(Restaurant)
            .join(Experience, Restaurant.experience_id == Experience.id)
            .options(
                selectinload(Restaurant.experience).selectinload(Experience.neighborhood)
            )
            .where(Experience.is_active == True)  # noqa: E712
        )

        if neighborhood_ids:
            nbh_result = await self.session.execute(
                select(Neighborhood.id, Neighborhood.name)
            )
            all_nbh = [{"id": r[0], "name": r[1]} for r in nbh_result.fetchall()]
            expanded_ids = _expand_neighborhood_ids(neighborhood_ids, all_nbh)
            stmt = stmt.where(Experience.neighborhood_id.in_(expanded_ids))
        if cuisines:
            expanded = _expand_cuisines(cuisines)
            stmt = stmt.where(
                sa.literal_column("restaurants.cuisine").op("&&")(
                    sa.cast(expanded, sa.ARRAY(sa.Text))
                )
            )
        if search:
            stmt = stmt.where(Experience.name.ilike(f"%{search}%"))

        stmt = stmt.order_by(Experience.name.asc(), Restaurant.experience_id.asc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_filter_options(self) -> dict:
        nbh_result = await self.session.execute(
            select(Neighborhood.id, Neighborhood.name).order_by(Neighborhood.name)
        )
        raw_neighborhoods = [
            {"id": row[0], "name": row[1]} for row in nbh_result.fetchall()
        ]

        grouped: dict[str, list[int]] = {}
        for n in raw_neighborhoods:
            canonical = _normalize_neighborhood(n["name"])
            grouped.setdefault(canonical, []).append(n["id"])
        neighborhoods = sorted(
            [{"ids": ids, "name": name} for name, ids in grouped.items()],
            key=lambda x: x["name"],
        )

        cuisine_result = await self.session.execute(
            sa_text(
                "SELECT DISTINCT unnest(r.cuisine) AS cuisine "
                "FROM restaurants r "
                "JOIN experiences e ON e.id = r.experience_id "
                "WHERE e.is_active = true "
                "ORDER BY cuisine"
            )
        )
        raw_cuisines = [row[0] for row in cuisine_result.fetchall()]
        cuisines = sorted({_normalize_cuisine(c) for c in raw_cuisines})

        return {"neighborhoods": neighborhoods, "cuisines": cuisines}


restaurants_dao = RestaurantsDAO()
