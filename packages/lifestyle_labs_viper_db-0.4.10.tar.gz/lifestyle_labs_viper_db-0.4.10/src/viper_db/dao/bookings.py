"""CRUD operations for the bookings table."""

import logging
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import selectinload
from sqlmodel import select

from viper_db.models import Booking
from viper_db.models.enums import BookingStatus
from viper_db.models.experience import Experience
from viper_db.utils.db import get_session

logger = logging.getLogger(__name__)


class BookingsDAO:
    @property
    def session(self):
        return get_session()

    async def create(self, data: dict) -> Booking:
        booking = Booking(**data)
        if booking.status == BookingStatus.CONFIRMED and not booking.confirmed_at:
            booking.confirmed_at = datetime.now(timezone.utc)
        self.session.add(booking)
        await self.session.commit()
        return booking

    async def get_by_user(self, user_id: UUID) -> list[Booking]:
        result = await self.session.execute(
            select(Booking)
            .where(Booking.user_id == user_id)
            .order_by(Booking.booking_date.desc(), Booking.booking_time.desc())
        )
        return list(result.scalars().all())

    async def get_by_user_with_experience(self, user_id: UUID) -> list[Booking]:
        """Fetch user bookings with experience, neighborhood,
        and restaurant eagerly loaded."""
        result = await self.session.execute(
            select(Booking)
            .where(Booking.user_id == user_id)
            .options(
                selectinload(Booking.experience).selectinload(Experience.neighborhood),
                selectinload(Booking.experience).selectinload(Experience.restaurant),
            )
            .order_by(Booking.booking_date.desc(), Booking.booking_time.desc())
        )
        return list(result.scalars().all())

    async def get_by_id(self, booking_id: int) -> Optional[Booking]:
        return await self.session.get(Booking, booking_id)


bookings_dao = BookingsDAO()
