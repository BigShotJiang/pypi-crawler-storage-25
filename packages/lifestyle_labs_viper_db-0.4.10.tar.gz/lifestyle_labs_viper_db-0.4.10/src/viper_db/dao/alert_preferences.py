"""CRUD operations for the alert_preferences table."""

from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from sqlmodel import select

from viper_db.models.alert_preference import AlertPreference
from viper_db.utils.db import get_session


class AlertPreferencesDAO:
    @property
    def session(self):
        return get_session()

    async def create(self, **kwargs) -> AlertPreference:
        pref = AlertPreference(**kwargs)
        self.session.add(pref)
        await self.session.commit()
        return pref

    async def get_by_user(
        self, user_id: UUID, active_only: bool = True
    ) -> list[AlertPreference]:
        stmt = select(AlertPreference).where(AlertPreference.user_id == user_id)
        if active_only:
            stmt = stmt.where(AlertPreference.is_active == True)  # noqa: E712
        stmt = stmt.order_by(AlertPreference.created_at.desc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_matched_by_user(self, user_id: UUID) -> list[AlertPreference]:
        stmt = (
            select(AlertPreference)
            .where(AlertPreference.user_id == user_id)
            .where(AlertPreference.matched_slot_ids.isnot(None))
            .order_by(AlertPreference.notified_at.desc())
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_all_active(self) -> list[AlertPreference]:
        stmt = (
            select(AlertPreference)
            .where(AlertPreference.is_active == True)  # noqa: E712
            .where(AlertPreference.matched_slot_ids.is_(None))
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def mark_matched(
        self, pref_id: int, slot_ids: list[int]
    ) -> Optional[AlertPreference]:
        pref = await self.session.get(AlertPreference, pref_id)
        if not pref:
            return None
        pref.matched_slot_ids = slot_ids
        pref.is_active = False
        pref.notified_at = datetime.now(timezone.utc)
        self.session.add(pref)
        await self.session.commit()
        return pref

    async def deactivate(self, pref_id: int) -> Optional[AlertPreference]:
        pref = await self.session.get(AlertPreference, pref_id)
        if not pref:
            return None
        pref.is_active = False
        self.session.add(pref)
        await self.session.commit()
        return pref

    async def delete(self, pref_id: int, user_id: UUID) -> bool:
        pref = await self.session.get(AlertPreference, pref_id)
        if not pref or pref.user_id != user_id:
            return False
        await self.session.delete(pref)
        await self.session.commit()
        return True


alert_preferences_dao = AlertPreferencesDAO()
