"""Integration tests for AvailabilitySlotsDAO batch queries against the live DB."""

import datetime as dt

import pytest
from sqlalchemy import text

from viper_db.dao.availability_slots import AvailabilitySlotsDAO


@pytest.fixture
def dao(db_session):
    d = AvailabilitySlotsDAO()
    d._test_session = db_session
    return d


@pytest.fixture(autouse=True)
def _patch_dao_session(dao, db_session, monkeypatch):
    monkeypatch.setattr(
        AvailabilitySlotsDAO,
        "session",
        property(lambda self: db_session),
    )


async def _find_day_with_slots(
    db_session, party_size: int = 2, min_experiences: int = 2
) -> tuple[dt.date, list[int]] | None:
    """Pick a recent date + experience_id set with >0 available slots.

    Keeps the test hermetic against a fluctuating scrape window.
    """
    row = (
        await db_session.execute(
            text(
                "SELECT a.date, ARRAY_AGG(DISTINCT a.experience_id) AS ids "
                "FROM availability_slots a "
                "WHERE a.is_available = true AND a.party_size = :party_size "
                "GROUP BY a.date "
                "HAVING COUNT(DISTINCT a.experience_id) >= :min_exp "
                "ORDER BY a.date "
                "LIMIT 1"
            ),
            {"party_size": party_size, "min_exp": min_experiences},
        )
    ).fetchone()
    if row is None:
        return None
    return row[0], list(row[1])


async def test_get_experiences_available_by_ids_returns_slots(dao, db_session):
    picked = await _find_day_with_slots(db_session, party_size=2, min_experiences=2)
    if picked is None:
        pytest.skip("No pre-scraped availability slots for party_size=2 in the DB")
    date, ids = picked

    rows = await dao.get_experiences_available_by_ids(
        experience_ids=ids[:5],
        date=date,
        party_size=2,
    )

    assert rows, "Expected at least one row back"
    for r in rows:
        assert r["experience_id"] in ids
        for slot in r["slots"]:
            assert set(slot.keys()) >= {"time", "slot_type"}
            assert len(slot["time"]) == 5


async def test_get_experiences_available_by_ids_empty_list(dao):
    rows = await dao.get_experiences_available_by_ids(
        experience_ids=[],
        date=dt.date.today(),
        party_size=2,
    )
    assert rows == []


async def test_get_experiences_available_by_ids_unknown_ids(dao):
    rows = await dao.get_experiences_available_by_ids(
        experience_ids=[-1, -2, -3],
        date=dt.date.today(),
        party_size=2,
    )
    assert rows == []


async def test_get_experiences_available_by_ids_time_filter(dao, db_session):
    picked = await _find_day_with_slots(db_session, party_size=2, min_experiences=1)
    if picked is None:
        pytest.skip("No pre-scraped availability slots for party_size=2 in the DB")
    date, ids = picked

    rows = await dao.get_experiences_available_by_ids(
        experience_ids=ids[:3],
        date=date,
        party_size=2,
        time_from=dt.time(18, 0),
        time_to=dt.time(21, 30),
    )

    for r in rows:
        for slot in r["slots"]:
            assert "18:00" <= slot["time"] <= "21:30"
