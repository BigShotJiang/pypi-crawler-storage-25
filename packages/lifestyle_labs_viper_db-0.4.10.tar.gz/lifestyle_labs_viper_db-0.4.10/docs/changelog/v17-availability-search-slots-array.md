# v17 — Add `slots` Array to Availability Search DAO

## Summary

Added a `slots` field to the rows returned by `get_experiences_available_on_date`. Each row now includes a de-duplicated, sorted list of available slot times as 24-hour `HH:MM` strings. This gives the tool-calling agent direct visibility into which specific times are open per restaurant without having to make follow-up per-restaurant queries.

## Changes

### DAO: `get_experiences_available_on_date` (`dao/availability_slots.py`)
- Added `ARRAY_AGG(DISTINCT TO_CHAR(a.time, 'HH24:MI') ORDER BY TO_CHAR(a.time, 'HH24:MI')) AS slots` to the SELECT clause
- `GROUP BY` unchanged (grouping is still per-experience)
- Added `"slots": list(row.slots or [])` to each returned row dict
- Docstring updated to describe the new field

### Example Output
```json
{
  "experience_id": 123,
  "name": "Le Bernardin",
  "slot_count": 4,
  "slots": ["17:30", "18:00", "20:00", "20:30"],
  ...
}
```

## Compatibility

Additive change — existing callers keep working. The new key is always present (empty list if Postgres returns `NULL`, which would only happen if no rows matched, in which case the row wouldn't be emitted anyway).

## Affected Paths
- `src/viper_db/dao/availability_slots.py`
