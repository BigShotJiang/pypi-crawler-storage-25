# v19 — Drop Empty-Slot Experiences from Batch Availability

## Summary

`get_experiences_available_by_ids` now uses an `INNER JOIN` on
`availability_slots` instead of a `LEFT JOIN`. Experiences that have
zero matching available slots for the requested date / party size / time
window are no longer returned — only experiences with at least one slot
appear in the result set.

This aligns the method with `get_experiences_available_on_date`, which
already used an `INNER JOIN` and never returned empty-slot rows.

## What changed

- File: `src/viper_db/dao/availability_slots.py`
- `LEFT JOIN availability_slots a` → `JOIN availability_slots a`
- The `COALESCE(json_agg(…) FILTER (WHERE a.id IS NOT NULL), '[]'::json)`
  wrapper simplified to a plain `json_agg(…)` — with an inner join
  `a.id` is never NULL.

## Why

When a user provides a date and party size the intent is to find
restaurants with open tables. Returning rows with `slots: []` forced
every consumer to filter them out, and the agent was surfacing
restaurants with no availability to the user.

## Affected paths

- `src/viper_db/dao/availability_slots.py`
- `tests/test_availability_slots_dao.py` (no changes needed — existing
  tests query dates/IDs that have slots)
