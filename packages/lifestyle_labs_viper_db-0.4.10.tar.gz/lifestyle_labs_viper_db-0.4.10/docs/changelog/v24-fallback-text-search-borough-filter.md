# v24 — borough filter in fallback_text_search

## What was built

Added `borough` parameter to `ExperiencesDAO.fallback_text_search()`.
When `borough` is provided (and `neighborhood` is not), results are
filtered by `n.borough ILIKE :borough_pattern`, matching the behavior
already present in `hybrid_discover`.

Previously the fallback had no borough awareness, so a discovery query
for "Brooklyn" that fell through to the ILIKE fallback could return
Manhattan restaurants whose descriptions mentioned Brooklyn.

## Affected paths

- `src/viper_db/dao/experiences.py` — `fallback_text_search()`
