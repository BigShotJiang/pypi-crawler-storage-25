# v20 — Pre-filter Nearby Candidates by Availability

## Summary

`get_nearby_candidates` now accepts optional `date`, `party_size`,
`time_from`, and `time_to` keyword arguments. When provided, the
candidate set is restricted to experiences that have at least one
matching pre-scraped slot *before* Haversine sorting, and each returned
dict includes an `availability_slots` key with the matched slot data.

When the parameters are omitted the method behaves identically to
before — all active experiences with coordinates are returned.

## What changed

- **Method:** `ExperiencesDAO.get_nearby_candidates` —
  new keyword-only params `date`, `party_size`, `time_from`, `time_to`.
- **New private method:** `ExperiencesDAO._nearby_with_availability` —
  raw SQL path that `JOIN`s `availability_slots` via `EXISTS` subquery,
  Haversine-sorts the filtered set, then batch-fetches slot data for the
  top N candidates.

## Why

Previously the nearby endpoint picked the closest restaurants first,
then tacked on availability second. Restaurants without open tables
still consumed Google Routes API quota and were returned to the user
with empty slots. Now only restaurants with actual availability enter
the distance check, so every nearby result is bookable.

## Affected paths

- `src/viper_db/dao/experiences.py`
