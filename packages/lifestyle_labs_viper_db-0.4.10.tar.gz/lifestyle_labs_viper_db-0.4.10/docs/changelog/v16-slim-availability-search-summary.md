# v16 — Slim `ExperienceAvailabilitySummary` Payload from Availability Search DAO

## Summary

Reduced the payload returned by `get_experiences_available_on_date` to the fields the agent actually needs for broad availability search. Dropped `image_urls`, `price_tier`, `url_slug`, and `next_available_time` from both the SQL projection and the returned dict. These fields were only ever consumed by a mobile component that has since been removed, and they added noise to the agent's tool-call context.

## Changes

### DAO: `get_experiences_available_on_date` (`dao/availability_slots.py`)
- Removed `e.image_urls`, `e.price_tier`, `r.url_slug`, and `MIN(a.time) AS next_available_time` from the SELECT clause
- Removed the matching columns from the `GROUP BY` clause
- Removed `image_urls`, `price_tier`, `url_slug`, and `next_available_time` from each returned row dict
- Remaining per-row fields: `experience_id`, `name`, `neighborhood`, `cuisine`, `vibes`, `slot_count`

## Breaking Changes

Callers of `get_experiences_available_on_date` that depend on `image_urls`, `price_tier`, `url_slug`, or `next_available_time` will no longer receive them. No callers inside the workspace rely on these keys — the only mobile consumer (`AvailabilityGallery`) was deleted in the accompanying `viper-mobile` changelog entry, and the agent tool (`find_available_tables`) never used them.

## Affected Paths
- `src/viper_db/dao/availability_slots.py`
