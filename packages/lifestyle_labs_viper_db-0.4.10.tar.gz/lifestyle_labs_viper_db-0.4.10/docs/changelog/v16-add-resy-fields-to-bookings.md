# v16 — Add Resy fields to bookings table

## What was built

Alembic migration `0021` adds two nullable columns to the `bookings` table:

| Column | Type | Purpose |
|--------|------|---------|
| `resy_token` | `Text` | The `rr://…` token needed for cancellation via the Resy API |
| `resy_reservation_id` | `Integer` | Resy's internal reservation ID |

## Modified files

- `viper_db/models/booking.py` — added `resy_token` and `resy_reservation_id` fields to `Booking`.
- `alembic/versions/0021_add_resy_fields_to_bookings.py` — migration file.
