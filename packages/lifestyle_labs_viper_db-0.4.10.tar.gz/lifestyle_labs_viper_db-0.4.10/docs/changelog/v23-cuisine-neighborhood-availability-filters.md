# v23 — cuisine/neighborhood filters on broad availability

## What was built

Added `cuisine` and `neighborhood` optional parameters to
`get_experiences_available_on_date` in the availability slots DAO.

### SQL changes

- `cuisine` filter: `EXISTS (SELECT 1 FROM unnest(r.cuisine) c WHERE c ILIKE :cuisine_pattern)`
- `neighborhood` filter: `AND n.name ILIKE :neighborhood_pattern`

Both are additive WHERE clauses — existing queries unchanged.

## Affected paths

- `src/viper_db/dao/availability_slots.py`
