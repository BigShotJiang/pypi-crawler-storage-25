# v22 — Borough column, neighborhood centroids, geo-candidate query

## What was built

Added `borough`, `centroid_lat`, `centroid_lng` columns to the `neighborhoods`
table and a new `get_geo_candidates` DAO method on `ExperiencesDAO`.

### Migration

```sql
ALTER TABLE neighborhoods
  ADD COLUMN borough TEXT,
  ADD COLUMN centroid_lat NUMERIC(9,6),
  ADD COLUMN centroid_lng NUMERIC(9,6);
```

All 52 neighborhoods populated with borough (Manhattan/Brooklyn/Queens) using
NYC NTA 2020 data. Centroids sourced from NTA official centroids where matched,
with fallback to average experience lat/lng for neighborhoods without an NTA
match.

### Model

`Neighborhood` model gains three nullable fields:
`borough`, `centroid_lat`, `centroid_lng`.

### DAO changes

- `ExperiencesDAO.get_geo_candidates(centroid_lat, centroid_lng, limit)` —
  returns the N closest active experience IDs to a given centroid using
  squared-Euclidean distance ordering.
- `ExperiencesDAO.hybrid_discover` — new optional params: `borough`,
  `exclude_ids`, `geo_candidate_ids`. Filters are applied to both CTEs.
- `AvailabilitySlotsDAO.get_experiences_available_on_date` — new optional
  params: `exclude_ids`, `borough`.

## Affected paths

- `viper-db/src/viper_db/models/neighborhood.py`
- `viper-db/src/viper_db/dao/experiences.py`
- `viper-db/src/viper_db/dao/availability_slots.py`
