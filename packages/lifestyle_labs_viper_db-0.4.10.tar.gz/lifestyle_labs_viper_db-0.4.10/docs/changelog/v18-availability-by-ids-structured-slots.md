# v18 — Per-ID Availability DAO with Structured Slots

## Summary

Adds `AvailabilitySlotsDAO.get_experiences_available_by_ids(...)` —
per-experience availability lookup for a caller-provided ID list in one
SQL round trip. Structured slots `{time, slot_type}` so API callers can
pass Resy table types (`Dining Room`, `Bar`, `Patio`, …) through to the
UI without a second join.

Backs the new viper-api `POST /availability-slots/batch-search` endpoint
(v23) and viper-agents `find_experiences` tool (v20).

## What was built

- File: `src/viper_db/dao/availability_slots.py`
- New method:
  ```py
  async def get_experiences_available_by_ids(
      self,
      experience_ids: list[int],
      date: dt.date,
      party_size: Optional[int] = None,
      time_from: Optional[dt.time] = None,
      time_to: Optional[dt.time] = None,
  ) -> list[dict]: ...
  ```
- SQL: single `SELECT … FROM experiences e LEFT JOIN availability_slots a
  ON … WHERE e.id = ANY(:experience_ids) GROUP BY …`. `LEFT JOIN` means
  experiences without slots return `slot_count=0` and `slots=[]` instead
  of being dropped — makes the agent-side zip with discovery rows trivial.
- Slots are aggregated via `json_agg(json_build_object('time', …,
  'slot_type', …) ORDER BY a.time)` and returned as
  `list[dict[time, slot_type]]`. Mirrors the projection of
  `get_experiences_available_on_date`, but scoped to an explicit ID set
  and with structured slots instead of plain `HH:MM` strings.
- Empty `experience_ids` short-circuits to `[]` without hitting the DB.

## Tests

`tests/test_availability_slots_dao.py` covers happy path, empty IDs,
unknown IDs, and the `time_from`/`time_to` filter — all against the live
Supabase DB fixture.

## Affected Paths

- `src/viper_db/dao/availability_slots.py`
- `tests/test_availability_slots_dao.py` (new)
