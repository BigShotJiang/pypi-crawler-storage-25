# v21 — DB latency: eager_defaults + remove refresh

**Date**: 2026-05-04

## What was built

Eliminated 2-3 unnecessary DB roundtrips per INSERT/UPDATE by switching
all ORM models to `eager_defaults` mode (uses `INSERT ... RETURNING *`)
and removing the post-commit `session.refresh()` calls from every DAO.

Also disabled `pool_pre_ping` to eliminate the `SELECT 1` roundtrip on
every connection checkout (~100-200ms saved per request).

## Changes

| Area | Detail |
|------|--------|
| **Models** (14 files) | Added `__mapper_args__ = {"eager_defaults": True}` to all `SQLModel` classes |
| **DAOs** (9 files, 13 occurrences) | Removed `await self.session.refresh(...)` from every `create()` / `update()` / `upsert()` method |
| **client.py** | `pool_pre_ping=True` → `pool_pre_ping=False` |

## Affected paths

- `viper-db/src/viper_db/models/*.py` (all 14 model files)
- `viper-db/src/viper_db/dao/*.py` (all 9 DAO files)
- `viper-db/src/viper_db/client.py`

## Impact

| Metric | Before | After |
|--------|--------|-------|
| Roundtrips per INSERT | 3 (INSERT + SELECT refresh + pre_ping) | 1 (INSERT RETURNING) |
| Roundtrips per UPDATE | 3 (UPDATE + SELECT refresh + pre_ping) | 1 (UPDATE RETURNING) |
| Pool checkout overhead | ~100-200ms (SELECT 1) | 0ms |

## Migration

- SQL migration `drop_messages_from_realtime_publication` applied to
  remove `public.messages` from `supabase_realtime` publication
  (saves ~500ms per message INSERT from WAL overhead).
- RLS was already disabled on `public.messages` — no action needed.
