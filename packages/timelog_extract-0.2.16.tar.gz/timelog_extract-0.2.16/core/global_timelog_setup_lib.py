"""Shared setup implementation for onboarding wizard (doctor, smoke, project config)."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import sysconfig
from datetime import datetime
from pathlib import Path

import questionary
import typer
from rich.console import Console
from rich import box
from rich.table import Table

from core.global_timelog_machine_setup import run_global_timelog_setup
from core.onboarding_guidance import build_setup_next_steps, print_next_steps
from core.config import resolve_projects_config_path
from core.setup_github_env import configure_github_env_for_setup
from core.setup_projects_config_bootstrap import ensure_projects_config
from core.setup_project_identity_wizard import run_project_identity_wizard
from outputs.cli_heroes import print_command_hero
from outputs.terminal_theme import STYLE_BORDER, STYLE_LABEL, STYLE_MUTED

REPO_ROOT = Path(__file__).resolve().parent.parent


def _timestamped_backup_path(path: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return path.with_name(f"{path.stem}.backup-{stamp}{path.suffix}")


def _looks_like_projects_config(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    projects = payload.get("projects")
    return isinstance(projects, list)


def _ensure_minimal_projects_config(
    console,
    *,
    yes: bool,
    dry_run: bool,
    prompt_bootstrap_root: bool = False,
    bootstrap_root: str | None = None,
) -> tuple[str, str, list[str]]:
    """
    Ensure a minimal timelog projects configuration is present in the current working directory.

    This may create or validate a `timelog_projects.json` file and produce actionable notes and follow-up steps. Behavior is affected by `yes` (non-interactive confirmation), `dry_run` (preview without writing), and an optional `bootstrap_root` to seed configuration.

    Parameters:
        console: Console-like object used for prompts and informational output.
        yes (bool): If True, proceed without interactive confirmation.
        dry_run (bool): If True, show what would change but do not write files.
        prompt_bootstrap_root (bool): If True, ask for bootstrap root even when yes=True.
        bootstrap_root (str | None): Optional path used to bootstrap project discovery; when None no special bootstrap root is used.

    Returns:
        status (str): High-level result status such as `"PASS"`, `"ACTION_REQUIRED"`, or similar.
        notes (str): Human-readable notes or summary about actions taken or required.
        next_steps (list[str]): Ordered list of follow-up steps the user should perform.
    """
    result = ensure_projects_config(
        console=console,
        yes=yes,
        dry_run=dry_run,
        prompt_bootstrap_root=prompt_bootstrap_root,
        bootstrap_root=bootstrap_root,
        config_path=resolve_projects_config_path(),
        timestamped_backup_path_fn=_timestamped_backup_path,
        looks_like_projects_config_fn=_looks_like_projects_config,
    )
    return result.status, result.notes, result.next_steps


def _print_environment_status(console) -> None:
    table = Table(title="Environment checks", box=box.ROUNDED)
    table.border_style = STYLE_BORDER
    table.header_style = f"bold {STYLE_LABEL}"
    table.add_column("Check", style=STYLE_LABEL)
    table.add_column("Status")
    table.add_column("Details", style="dim")
    gittan_in_path = shutil.which("gittan")
    scripts_path = sysconfig.get_path("scripts")
    path_values = {str(Path(part).expanduser()) for part in os.environ.get("PATH", "").split(":") if part}
    scripts_in_path = str(Path(scripts_path).expanduser()) in path_values
    table.add_row("`gittan` command", "[green]OK[/green]" if gittan_in_path else "[yellow]MISSING[/yellow]", gittan_in_path or "Command not currently available in PATH")
    table.add_row("Python scripts PATH", "[green]OK[/green]" if scripts_in_path else "[yellow]ACTION[/yellow]", scripts_path if scripts_in_path else f"Add to PATH: {scripts_path}")
    github_user = os.environ.get("GITHUB_USER", "")
    github_token = os.environ.get("GITHUB_TOKEN", "")
    table.add_row("GitHub user env", "[green]SET[/green]" if github_user else "[dim]optional[/dim]", github_user or "(not set)")
    table.add_row("GitHub token env", "[green]SET[/green]" if github_token else "[dim]optional[/dim]", "(set)" if github_token else "(not set)")
    console.print(table)
    if not scripts_in_path:
        shell = os.environ.get("SHELL", "")
        shell_name = Path(shell).name if shell else ""
        rc_file = "~/.zshrc" if shell_name == "zsh" else "~/.bashrc" if shell_name == "bash" else "~/.profile"
        console.print(f"[cyan]Detected shell:[/cyan] {shell or '(unknown)'}")
        console.print(f"[cyan]Suggested profile file:[/cyan] {rc_file}")
        console.print(f"[yellow]Tip:[/yellow] add this to your shell profile: `export PATH=\"{scripts_path}:$PATH\"`")
        console.print(f"[dim]Apply now in current terminal:[/dim] `export PATH=\"{scripts_path}:$PATH\"`")


def _print_setup_header(console, *, dry_run: bool) -> None:
    print_command_hero(console, "setup")
    if dry_run:
        console.print("[yellow]Dry run mode:[/yellow] commands are previewed; no system files are changed.")
    console.print("")


def _print_setup_environment_loaded(console) -> None:
    projects_present = int(resolve_projects_config_path().is_file())
    github_user_set = int(bool((os.environ.get("GITHUB_USER") or "").strip()))
    github_token_set = int(bool((os.environ.get("GITHUB_TOKEN") or "").strip()))
    console.print(
        "[dim]Environment loaded:[/dim] "
        f"{projects_present} project config, {github_user_set} GitHub user env, {github_token_set} GitHub token env"
    )
    console.print("")


def _run_doctor_check(console, *, dry_run: bool) -> str:
    if dry_run:
        console.print("[yellow]Dry run:[/yellow] would run `gittan doctor`.")
        return "PASS (dry-run)"
    console.print("[dim]Running `gittan doctor` inside setup...[/dim]")
    try:
        # Run doctor in-process so Rich rendering uses the same theme as setup.
        from core.cli_doctor_sources_projects import doctor as run_doctor

        run_doctor()
    except typer.Exit as exc:
        code = exc.exit_code if isinstance(exc.exit_code, int) else 1
        if code == 0:
            return "PASS"
        return "ACTION_REQUIRED"
    except Exception as exc:
        console.print(f"[yellow]Doctor check reported issues.[/yellow] {exc}")
        return "ACTION_REQUIRED"
    return "PASS"


def _run_smoke_report(console, *, dry_run: bool) -> str:
    if dry_run:
        console.print("[yellow]Dry run:[/yellow] would run `gittan report --last-week --include-uncategorized --format json --quiet`.")
        return "PASS (dry-run)"
    entry = REPO_ROOT / "timelog_extract.py"
    with console.status("[bold blue]Running smoke report...[/bold blue]"):
        completed = subprocess.run(
            [sys.executable, str(entry), "report", "--last-week", "--include-uncategorized", "--format", "json", "--quiet"],
            check=False,
            capture_output=True,
            text=True,
            cwd=str(Path.cwd()),
        )
    if completed.returncode != 0:
        console.print("[yellow]Smoke report failed; check output below.[/yellow]")
        if completed.stderr:
            console.print(f"[dim]{completed.stderr.strip()}[/dim]")
        if completed.stdout:
            console.print(completed.stdout.strip()[:1200])
        return "FAIL"
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None
    if isinstance(payload, dict) and payload.get("schema") == "timelog_extract.truth_payload":
        totals = payload.get("totals", {})
        console.print("[green]Smoke report passed.[/green]")
        console.print(f"[dim]schema={payload.get('schema')} | events={totals.get('event_count','n/a')} | days={totals.get('days_with_activity','n/a')} | hours={totals.get('hours_estimated','n/a')}[/dim]")
        return "PASS"
    else:
        console.print("[yellow]Smoke report completed, but output was not recognized as truth payload JSON.[/yellow]")
        if completed.stdout:
            console.print(completed.stdout.strip()[:1200])
        if completed.stderr:
            console.print(f"[dim]{completed.stderr.strip()}[/dim]")
        return "ACTION_REQUIRED"


def _run_mapping_wizard_with_summary(console, *, dry_run: bool) -> tuple[str, str]:
    outcome = run_project_identity_wizard(console, config_path=resolve_projects_config_path(), dry_run=dry_run)
    status_map = {
        "Confirmed": ("PASS", "Confirmed customer->project mapping."),
        "Confirmed (dry-run)": ("PASS (dry-run)", "Confirmed customer->project mapping."),
        "Skip this step": ("SKIPPED", "User skipped mapping."),
        "No customers provided": ("SKIPPED", "No customers provided."),
        "No candidates selected": ("SKIPPED", "No candidates selected."),
        "No unresolved mappings": ("SKIPPED", "No unresolved project->customer mappings found."),
        "No mappings selected": ("SKIPPED", "No mappings selected; nothing saved."),
        "Nothing to save": ("SKIPPED", "No mapping changes were saved."),
        "No projects": ("SKIPPED", "No projects found in config."),
    }
    return status_map.get(outcome, ("ACTION_REQUIRED", f"Unexpected mapping outcome: {outcome}"))


def run_setup_wizard(
    console,
    *,
    yes: bool,
    dry_run: bool,
    skip_smoke: bool,
    bootstrap_root: str | None = None,
    fast: bool = False,
    prompt_project_mapping: bool = False,
) -> None:
    _print_setup_header(console, dry_run=dry_run)
    summary_rows: list[tuple[str, str, str]] = []
    next_steps: list[str] = []
    _print_environment_status(console)
    _print_setup_environment_loaded(console)
    summary_rows.append(("Environment checks", "PASS", "Printed PATH and optional env status."))
    try:
        github_env_status, github_env_note, github_env_steps = configure_github_env_for_setup(
            console, yes=yes, dry_run=dry_run
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        console.print(f"[yellow]GitHub env bootstrap could not complete:[/yellow] {exc}")
        github_env_status = "ACTION_REQUIRED"
        github_env_note = f"GitHub env bootstrap failed: {exc}"
        github_env_steps = [
            "Set GITHUB_USER and optionally GITHUB_TOKEN manually, then rerun `gittan doctor --github-source auto`."
        ]
    summary_rows.append(("GitHub env bootstrap", github_env_status, github_env_note))
    next_steps.extend(github_env_steps)
    if fast:
        summary_rows.append(("Step 1: Global Timelog Setup", "SKIPPED", "Skipped in --fast mode for quicker onboarding."))
    else:
        should_setup_timelog = yes or questionary.confirm("Configure global timelog automation now?", default=True).ask()
        if should_setup_timelog:
            run_global_timelog_setup(console, yes=yes, dry_run=dry_run)
            summary_rows.append(
                (
                    "Step 1: Global Timelog Setup",
                    "PASS" if not dry_run else "PASS (dry-run)",
                    "Configured or previewed global hooks + global ignore.",
                )
            )
        else:
            console.print("[yellow]Skipped global timelog automation.[/yellow]")
            summary_rows.append(("Step 1: Global Timelog Setup", "SKIPPED", "User skipped this step."))
    projects_status, projects_note, project_steps = _ensure_minimal_projects_config(
        console,
        yes=yes,
        dry_run=dry_run,
        prompt_bootstrap_root=prompt_project_mapping and not dry_run,
        bootstrap_root=bootstrap_root,
    )
    summary_rows.append(("Step 2: Project Bootstrap", projects_status, projects_note))
    next_steps.extend(project_steps)

    # Conservative onboarding step: confirm customer->project mapping without inventing match_terms.
    if not yes:
        try:
            status, notes = _run_mapping_wizard_with_summary(console, dry_run=dry_run)
            summary_rows.append(("Step 3: Project Mapping", status, notes))
        except KeyboardInterrupt as exc:
            summary_rows.append(("Step 3: Project Mapping", "STOPPED", "User cancelled setup during mapping step."))
            console.print("[yellow]Setup stopped before save.[/yellow]")
            raise typer.Exit(code=130) from exc
        except Exception as exc:  # pragma: no cover - defensive summary visibility
            summary_rows.append(("Step 3: Project Mapping", "ACTION_REQUIRED", f"Wizard error: {exc}"))
            raise
    elif prompt_project_mapping and not dry_run:
        should_run_mapping = questionary.confirm("Run project mapping now?", default=True).ask()
        if should_run_mapping:
            try:
                status, notes = _run_mapping_wizard_with_summary(console, dry_run=dry_run)
                summary_rows.append(("Step 3: Project Mapping", status, notes))
            except KeyboardInterrupt as exc:
                summary_rows.append(("Step 3: Project Mapping", "STOPPED", "User cancelled setup during mapping step."))
                console.print("[yellow]Setup stopped before save.[/yellow]")
                raise typer.Exit(code=130) from exc
            except Exception as exc:  # pragma: no cover - defensive summary visibility
                summary_rows.append(("Step 3: Project Mapping", "ACTION_REQUIRED", f"Wizard error: {exc}"))
                raise
        else:
            summary_rows.append(("Step 3: Project Mapping", "SKIPPED", "User skipped optional mapping prompt."))
    else:
        summary_rows.append(("Step 3: Project Mapping", "SKIPPED", "Skipped in non-interactive (--yes) mode."))
    doctor_status = _run_doctor_check(console, dry_run=dry_run)
    summary_rows.append(("Step 4: Doctor Check", doctor_status, "Ran (or previewed) source/permission diagnostics."))
    smoke_status = "SKIPPED"
    if fast:
        console.print("[yellow]Skipped smoke report (--fast).[/yellow]")
        summary_rows.append(("Smoke report", "SKIPPED", "Skipped in --fast mode for quicker onboarding."))
    elif skip_smoke:
        console.print("[yellow]Skipped smoke report (--skip-smoke).[/yellow]")
        summary_rows.append(("Smoke report", "SKIPPED", "Skipped via --skip-smoke flag."))
    else:
        should_smoke = yes or questionary.confirm("Run final smoke report now?", default=True).ask()
        if should_smoke:
            smoke_status = _run_smoke_report(console, dry_run=dry_run)
            summary_rows.append(("Smoke report", smoke_status, "Ran (or previewed) JSON smoke report command."))
        else:
            console.print("[yellow]Skipped smoke report.[/yellow]")
            summary_rows.append(("Smoke report", "SKIPPED", "User skipped this step."))
            smoke_status = "SKIPPED"
    summary_rows.append(
        (
            "Step 5: Triage Review (optional)",
            "SKIPPED",
            "Not run inside setup in this version; available as optional follow-up via `gittan review`.",
        )
    )
    summary_table = Table(title="Setup summary", box=box.ROUNDED)
    summary_table.border_style = STYLE_BORDER
    summary_table.header_style = f"bold {STYLE_LABEL}"
    summary_table.add_column("Step", style=STYLE_LABEL)
    summary_table.add_column("Result")
    summary_table.add_column("Notes", style=STYLE_MUTED)
    for step, result, notes in summary_rows:
        if result.startswith("PASS"):
            style = "green"
        elif result == "FAIL":
            style = "red"
        elif result in ("ACTION_REQUIRED", "SKIPPED"):
            style = "yellow"
        else:
            style = "yellow"
        summary_table.add_row(step, f"[{style}]{result}[/{style}]", notes)
    console.print("\n")
    console.print(summary_table)
    console.print("\n")
    next_steps.extend(
        build_setup_next_steps(
            dry_run=dry_run,
            projects_status=projects_status,
            mapping_status=next((result for step, result, _ in summary_rows if step == "Step 3: Project Mapping"), "SKIPPED"),
            doctor_status=doctor_status,
            smoke_status=smoke_status,
            fast=fast,
        )
    )
    print_next_steps(console, list(dict.fromkeys(next_steps)))
    console.print("\n[green]Setup wizard completed.[/green]")
