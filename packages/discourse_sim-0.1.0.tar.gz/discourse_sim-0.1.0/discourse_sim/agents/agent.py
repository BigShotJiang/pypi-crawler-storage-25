"""
discourse_sim.agents.agent
==========================
Agent dataclass and population factory.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from discourse_sim.config import SimConfig


QUIRK_OPTIONS = [
    "uses sarcasm heavily",
    "adds emojis liberally",
    "writes short, punchy sentences",
    "writes long reflective sentences",
    "asks rhetorical questions constantly",
    "uses casual slang",
    "formal and polished tone",
    "heavy use of hashtags",
]


@dataclass
class Agent:
    """
    A synthetic social media user.

    Identity
    --------
    id       : unique string identifier (e.g. "agent_0")
    kind     : ideological type from SimConfig.agent_distribution
    attitude : [-1, +1]  — -1 = strongly pro-topic-subject, +1 = strongly against
    exposure : [0, 1]    — cumulative threat narrative saturation

    Beliefs
    -------
    economic_threat_belief  : perceived economic harm from the event subject
    cultural_threat_belief  : perceived cultural threat
    security_threat_belief  : perceived security/crime risk (updated by threat news)
    humanitarian_belief     : humanitarian obligation weight (updated by framing)

    Psychology
    ----------
    openness             : [0,1] — how readily beliefs change (0=rigid, 1=open)
    conformity           : [0,1] — peer influence susceptibility
    emotional_reactivity : [0,1] — news impact amplifier
    trust_peers          : [0,1] — weight given to social neighbourhood

    State
    -----
    mood             : [-1,+1] — affective state; decays; shocked by threat news
    messages         : list of all posts generated so far
    attitude_history : attitude value after each timestep
    reasoning_log    : tool-call audit trail per day
    quirk            : writing style (assigned once, fixed)
    """

    id:       str
    kind:     str
    attitude: float
    exposure: float

    economic_threat_belief: float = 0.0
    cultural_threat_belief: float = 0.0
    security_threat_belief: float = 0.0
    humanitarian_belief:    float = 0.0

    openness:             float = 0.5
    conformity:           float = 0.5
    emotional_reactivity: float = 0.5
    trust_peers:          float = 0.7

    mood:             float = 0.0
    messages:         list  = field(default_factory=list)
    attitude_history: list  = field(default_factory=list)
    reasoning_log:    list  = field(default_factory=list)
    quirk:            str   = ""


def make_agents(config: "SimConfig") -> dict[str, Agent]:
    """
    Spawn N agents according to SimConfig.agent_distribution and kind_priors.

    The distribution is converted to a weighted sampling pool so that
    proportions are respected even for non-round N values.
    """
    rng = random.Random(config.network_seed)

    # Build weighted pool (oversample then trim)
    pool: list[str] = []
    for kind, proportion in config.agent_distribution.items():
        count = round(proportion * config.n_agents)
        pool.extend([kind] * count)

    # Adjust pool length to exactly n_agents
    while len(pool) < config.n_agents:
        pool.append(rng.choice(list(config.agent_distribution.keys())))
    pool = pool[: config.n_agents]
    rng.shuffle(pool)

    agents: dict[str, Agent] = {}
    for i, kind in enumerate(pool):
        priors = config.kind_priors[kind]

        def u(key: str) -> float:
            lo, hi = priors[key]
            return rng.uniform(lo, hi)

        agents[f"agent_{i}"] = Agent(
            id=f"agent_{i}",
            kind=kind,
            attitude=u("attitude"),
            exposure=rng.uniform(0.0, 0.3),
            economic_threat_belief=u("economic_threat"),
            cultural_threat_belief=u("cultural_threat"),
            humanitarian_belief=u("humanitarian"),
            openness=u("openness"),
            emotional_reactivity=u("emotional_react"),
            conformity=rng.uniform(0.3, 0.8),
            trust_peers=rng.uniform(0.4, 0.9),
        )

    return agents
