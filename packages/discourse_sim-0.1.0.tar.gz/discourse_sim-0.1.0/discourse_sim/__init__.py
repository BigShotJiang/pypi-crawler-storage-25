"""
discourse_sim
=============
LLM-augmented Agent-Based Social Simulation for modelling
public discourse dynamics following a critical real-world event.

Quick start
-----------
from discourse_sim import DiscourseSimulation

sim = DiscourseSimulation(
    critical_event="In November 2023, Dublin city centre saw a major riot...",
    event_date="2023-11-23",
    n_agents=100,
    n_days=15,
    agent_distribution={"centrist": 0.45, "far_right": 0.20,
                        "pro_imm": 0.25, "media": 0.10},
    topic="immigration in Ireland",
    ollama_model="mistral:7b-instruct-q4_0",
)

sim.run()
df = sim.to_dataframe()
"""

from discourse_sim.core import DiscourseSimulation

__all__ = ["DiscourseSimulation"]
__version__ = "0.1.0"
