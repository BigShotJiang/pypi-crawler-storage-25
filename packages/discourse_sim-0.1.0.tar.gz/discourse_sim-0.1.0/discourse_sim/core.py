"""
discourse_sim.core
==================
Main user-facing class: DiscourseSimulation.
Orchestrates config → agents → network → tools → timeline → run_loop → output.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Dict, List, Optional, Union

import networkx as nx

from discourse_sim.config import SimConfig, DEFAULT_KIND_PRIORS
from discourse_sim.agents.agent import make_agents
from discourse_sim.tools.search_tools import make_tools
from discourse_sim.timeline.timeline import Timeline
from discourse_sim.simulation.engine import run_loop
from discourse_sim.utils.dataframes import build_dataframes


class DiscourseSimulation:
    """
    LLM-augmented Agent-Based Social Simulation of public discourse
    following a critical real-world event.

    Parameters
    ----------
    critical_event : str
        Plain-text description of the event (injected into every agent prompt).

    event_date : str
        ISO date string "YYYY-MM-DD" — Day 0 of the simulation.

    topic : str
        Subject domain, e.g. "immigration in Ireland", "housing policy".
        Used to ground search queries and scoring prompts.

    n_agents : int, default 100
        Number of synthetic agents.

    n_days : int, default 15
        Number of simulation days.

    agent_distribution : dict, default Ireland 2025 empirical split
        Proportions of each agent kind. Must sum to 1.0.
        Example: {"centrist": 0.5, "far_right": 0.3, "pro_imm": 0.2}

    kind_priors : dict, optional
        Override prior distributions for any or all agent kinds.
        Unspecified kinds fall back to DEFAULT_KIND_PRIORS.
        Example to add a new kind:
            kind_priors={
                "nationalist": {
                    "attitude":        (0.6, 1.0),
                    "economic_threat": (0.5, 0.9),
                    "cultural_threat": (0.6, 1.0),
                    "humanitarian":    (-0.4, 0.1),
                    "openness":        (0.1, 0.3),
                    "emotional_react": (0.7, 1.0),
                }
            }

    timeline : dict[int, str], optional
        Explicit daily news entries keyed by 0-based day index.
        Any day not supplied falls back to an auto-generated entry.
        Example:
            {
                0: "[VERIFIED] The march took place at...",
                4: "[VERIFIED] Government announced...",
            }
        If None, all days use auto-generated entries backed by live search.

    search_query_prefix : str, optional
        Prefix for all DuckDuckGo queries.
        Defaults to the first 8 words of critical_event + topic.

    ollama_model : str, default "mistral:7b-instruct-q4_0"
        Ollama model name. Must be pulled locally.

    temperature : float, default 0.75

    network_k : int, default 6
        Watts-Strogatz nearest-neighbour count.

    network_p : float, default 0.3
        Watts-Strogatz rewiring probability.

    network_seed : int, default 42

    use_llm_scoring : bool, default True

    verbose : bool, default True

    threat_keywords : list[str], optional
        Override the default threat keyword list for belief updates.

    humanitarian_keywords : list[str], optional
        Override the default humanitarian keyword list.

    Examples
    --------
    Basic usage — Dublin march:

        sim = DiscourseSimulation(
            critical_event=(
                "In late April 2025, Dublin saw a large anti-immigration march "
                "from the Garden of Remembrance to the Custom House..."
            ),
            event_date="2025-04-26",
            topic="immigration in Ireland",
            n_agents=100,
            n_days=15,
            agent_distribution={
                "centrist": 0.45, "far_right": 0.20,
                "pro_imm":  0.25, "media":     0.10,
            },
        )
        sim.run()
        df = sim.to_dataframe()  # returns df_messages
        dfs = sim.to_dataframes()  # returns {"history", "agents", "messages"}

    Custom kind — adding a "nationalist" type:

        from discourse_sim.config import DEFAULT_KIND_PRIORS

        custom_priors = {**DEFAULT_KIND_PRIORS, "nationalist": {...}}
        sim = DiscourseSimulation(
            ...,
            agent_distribution={"centrist": 0.4, "nationalist": 0.3, "pro_imm": 0.3},
            kind_priors=custom_priors,
        )

    With an explicit partial timeline:

        sim = DiscourseSimulation(
            ...,
            timeline={
                0: "[VERIFIED] Day 0: The protest began at 2pm...",
                4: "[VERIFIED] Day 4: Government announced deportation flight...",
            },
        )
    """

    def __init__(
        self,
        critical_event:        str,
        event_date:            str,
        topic:                 str,
        n_agents:              int                     = 100,
        n_days:                int                     = 15,
        agent_distribution:    Optional[Dict[str, float]] = None,
        kind_priors:           Optional[Dict[str, dict]]  = None,
        timeline:              Optional[Dict[int, str]]   = None,
        search_query_prefix:   Optional[str]              = None,
        ollama_model:          str                     = "mistral:7b-instruct-q4_0",
        temperature:           float                   = 0.75,
        network_k:             int                     = 6,
        network_p:             float                   = 0.3,
        network_seed:          int                     = 42,
        use_llm_scoring:       bool                    = True,
        verbose:               bool                    = True,
        threat_keywords:       Optional[List[str]]     = None,
        humanitarian_keywords: Optional[List[str]]     = None,
    ):
        # Merge user kind_priors with defaults (user overrides take precedence)
        merged_priors = {**DEFAULT_KIND_PRIORS}
        if kind_priors:
            merged_priors.update(kind_priors)

        # Build config
        cfg_kwargs = dict(
            critical_event=critical_event,
            event_date=event_date,
            topic=topic,
            n_agents=n_agents,
            n_days=n_days,
            kind_priors=merged_priors,
            timeline=timeline,
            ollama_model=ollama_model,
            temperature=temperature,
            network_k=network_k,
            network_p=network_p,
            network_seed=network_seed,
            use_llm_scoring=use_llm_scoring,
            verbose=verbose,
        )
        if agent_distribution is not None:
            cfg_kwargs["agent_distribution"] = agent_distribution
        if search_query_prefix is not None:
            cfg_kwargs["search_query_prefix"] = search_query_prefix
        if threat_keywords is not None:
            cfg_kwargs["threat_keywords"] = threat_keywords
        if humanitarian_keywords is not None:
            cfg_kwargs["humanitarian_keywords"] = humanitarian_keywords

        self.config = SimConfig(**cfg_kwargs)

        # Internal state (populated on run())
        self._agents:        Optional[dict] = None
        self._G:             Optional[nx.Graph] = None
        self._neighbors:     Optional[dict] = None
        self._history:       Optional[list] = None
        self._agent_records: Optional[list] = None
        self._ran:           bool = False

    # ── Setup ─────────────────────────────────────────────────────────────────

    def _setup(self):
        cfg = self.config

        # Build agents
        self._agents = make_agents(cfg)

        # Build Watts-Strogatz network
        # k must be even AND less than n_agents; clamp automatically
        safe_k = min(cfg.network_k, cfg.n_agents - 1)
        if safe_k % 2 != 0:
            safe_k = max(2, safe_k - 1)   # keep even
        if safe_k != cfg.network_k and cfg.verbose:
            print(f"  [info] network_k clamped from {cfg.network_k} → {safe_k} "
                  f"(n_agents={cfg.n_agents} requires k < n)")
        self._G = nx.watts_strogatz_graph(
            cfg.n_agents, safe_k, cfg.network_p, seed=cfg.network_seed
        )
        agent_ids = list(self._agents.keys())
        self._neighbors = {
            agent_ids[node]: [agent_ids[nb] for nb in self._G.neighbors(node)]
            for node in self._G.nodes()
        }

    # ── Run ───────────────────────────────────────────────────────────────────

    def run(self) -> "DiscourseSimulation":
        """
        Execute the full simulation. Returns self for chaining.

            sim = DiscourseSimulation(...).run()
            df  = sim.to_dataframe()
        """
        self._setup()

        tools    = make_tools(self.config.search_query_prefix)
        timeline = Timeline(self.config)

        self._history, self._agent_records = run_loop(
            agents=self._agents,
            G=self._G,
            neighbors=self._neighbors,
            config=self.config,
            timeline=timeline,
            tools=tools,
        )
        self._ran = True

        if self.config.verbose:
            self._print_summary()

        return self

    # ── Output ────────────────────────────────────────────────────────────────

    def to_dataframe(self):
        """
        Return the exploded messages DataFrame (one row per agent per day).
        Requires pandas.
        """
        self._check_ran()
        return build_dataframes(self._history, self._agent_records)["messages"]

    def to_dataframes(self) -> dict:
        """
        Return a dict of three DataFrames:
            "history"  — one row per timestep (aggregate)
            "agents"   — one row per agent per timestep
            "messages" — one row per agent per timestep (exploded messages)
        Requires pandas.
        """
        self._check_ran()
        return build_dataframes(self._history, self._agent_records)

    @property
    def history(self) -> list:
        """Raw history list (no pandas dependency)."""
        self._check_ran()
        return self._history

    @property
    def agent_records(self) -> list:
        """Raw agent_records list (no pandas dependency)."""
        self._check_ran()
        return self._agent_records

    @property
    def agents(self) -> dict:
        """Agent dict after simulation (final states)."""
        self._check_ran()
        return self._agents

    # ── Internals ─────────────────────────────────────────────────────────────

    def _check_ran(self):
        if not self._ran:
            raise RuntimeError(
                "Simulation has not been run yet. Call .run() first."
            )

    def _print_summary(self):
        import numpy as np
        h = self._history
        print(f"\n\n{'=' * 70}")
        print("  SIMULATION COMPLETE")
        print(f"{'=' * 70}")
        print(f"  {'Day':<5} {'Date':<14} {'AvgAttitude':>12} "
              f"{'Polarization':>13} {'AvgMood':>9} {'AvgExposure':>12}")
        print(f"  {'-'*5} {'-'*14} {'-'*12} {'-'*13} {'-'*9} {'-'*12}")
        for snap in h:
            print(f"  Day {snap['t']:<2}  {snap['date']:<14} "
                  f"{snap['avg_attitude']:>+12.3f} "
                  f"{snap['polarization']:>13.3f} "
                  f"{snap['avg_mood']:>+9.3f} "
                  f"{snap['avg_exposure']:>12.3f}")

    def __repr__(self) -> str:
        status = "ran" if self._ran else "not run"
        return (
            f"DiscourseSimulation("
            f"topic={self.config.topic!r}, "
            f"n_agents={self.config.n_agents}, "
            f"n_days={self.config.n_days}, "
            f"status={status})"
        )
