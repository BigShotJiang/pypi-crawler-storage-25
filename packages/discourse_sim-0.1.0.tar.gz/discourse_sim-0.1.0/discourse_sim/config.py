"""
discourse_sim.config
====================
Central configuration dataclass. All user-facing parameters live here.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from typing import Dict, List, Optional


# ── Default agent kinds and their priors ────────────────────────────────────
# Users can extend / override these by passing custom_kind_priors to SimConfig.
DEFAULT_KIND_PRIORS: Dict[str, dict] = {
    "far_right": {
        "attitude":        (0.5,   1.0),
        "economic_threat": (0.4,   0.9),
        "cultural_threat": (0.4,   0.9),
        "humanitarian":    (-0.5,  0.1),
        "openness":        (0.1,   0.4),
        "emotional_react": (0.6,   1.0),
    },
    "pro_imm": {
        "attitude":        (-1.0, -0.3),
        "economic_threat": (-0.5,  0.1),
        "cultural_threat": (-0.5,  0.0),
        "humanitarian":    (0.4,   1.0),
        "openness":        (0.6,   1.0),
        "emotional_react": (0.3,   0.7),
    },
    "centrist": {
        "attitude":        (-0.4,  0.4),
        "economic_threat": (-0.2,  0.4),
        "cultural_threat": (-0.2,  0.3),
        "humanitarian":    (0.0,   0.5),
        "openness":        (0.4,   0.7),
        "emotional_react": (0.3,   0.6),
    },
    "media": {
        "attitude":        (-0.3,  0.3),
        "economic_threat": (-0.2,  0.3),
        "cultural_threat": (-0.2,  0.2),
        "humanitarian":    (0.1,   0.5),
        "openness":        (0.5,   0.8),
        "emotional_react": (0.2,   0.5),
    },
}


@dataclass
class SimConfig:
    """
    All configuration for a DiscourseSimulation run.

    Required parameters
    -------------------
    critical_event : str
        Plain-text description of the event all agents are reacting to.
        This is injected into every agent prompt on every day.
        Example:
            "In November 2023, Dublin city centre erupted in riots following
             a knife attack near a school. Far-right agitators set buses alight
             and attacked Gardaí. The event dominated Irish media for weeks."

    event_date : str  (ISO format: "YYYY-MM-DD")
        Calendar date of Day 0. All subsequent days are offset from this.

    topic : str
        The subject domain agents post about.
        Example: "immigration in Ireland", "housing policy", "climate protests"
        Used to anchor web search queries and scoring prompts.

    Optional parameters
    -------------------
    n_agents : int  (default 100)
        Total number of synthetic agents.

    n_days : int  (default 15)
        Number of simulation timesteps (one per day).

    agent_distribution : dict  (default Ireland 2025 empirical distribution)
        Proportions of each agent kind. Must sum to 1.0.
        Keys must match entries in kind_priors.
        Example: {"centrist": 0.45, "far_right": 0.20,
                  "pro_imm": 0.25, "media": 0.10}

    kind_priors : dict  (default DEFAULT_KIND_PRIORS)
        Per-kind prior distributions for attitude and belief dimensions.
        Each entry: {"attitude": (lo, hi), "economic_threat": (lo, hi), ...}
        Users can pass a fully custom dict or override individual kinds.

    timeline : dict[int, str]  (default: None → auto-generated via LLM search)
        Optional explicit daily news entries keyed by day index (0-based).
        If provided, overrides automatic news retrieval for those days.
        Any day not present falls back to a generic continuation message.
        Example:
            {
                0: "[VERIFIED] Day 0: The march took place at ...",
                4: "[VERIFIED] Day 4: Government announced ...",
            }
        If None, agents rely entirely on live DuckDuckGo search results.

    search_query_prefix : str  (default: derived from topic + event summary)
        Prefix prepended to all DuckDuckGo search queries.
        Example: "Dublin immigration march April 2025 Ireland"
        Override this to localise searches for non-Irish events.

    ollama_model : str  (default "mistral:7b-instruct-q4_0")
        Any Ollama model string. Model must be pulled locally.

    temperature : float  (default 0.75)
        LLM temperature for post generation.

    network_k : int  (default 6)
        Watts-Strogatz nearest-neighbour count.

    network_p : float  (default 0.3)
        Watts-Strogatz rewiring probability.

    network_seed : int  (default 42)
        Random seed for network and agent initialisation.

    use_llm_scoring : bool  (default True)
        If False, uses keyword heuristic instead of LLM for attitude scoring.

    verbose : bool  (default True)
        Print per-agent and per-day progress to stdout.

    threat_keywords : list[str]
        Words in daily news that trigger security_threat_belief increase
        and exposure accumulation. Override for non-immigration topics.

    humanitarian_keywords : list[str]
        Words in daily news that trigger humanitarian_belief increase.
    """

    # ── Required ──────────────────────────────────────────────────────────────
    critical_event: str
    event_date:     str   # "YYYY-MM-DD"
    topic:          str

    # ── Agent population ──────────────────────────────────────────────────────
    n_agents: int = 100
    n_days:   int = 15

    agent_distribution: Dict[str, float] = field(default_factory=lambda: {
        "centrist":  0.45,
        "far_right": 0.20,
        "pro_imm":   0.25,
        "media":     0.10,
    })

    kind_priors: Dict[str, dict] = field(
        default_factory=lambda: DEFAULT_KIND_PRIORS
    )

    # ── Timeline ──────────────────────────────────────────────────────────────
    timeline: Optional[Dict[int, str]] = None   # None = rely on live search

    # ── Search ────────────────────────────────────────────────────────────────
    search_query_prefix: Optional[str] = None   # None = auto-derived

    # ── LLM ───────────────────────────────────────────────────────────────────
    ollama_model:     str   = "mistral:7b-instruct-q4_0"
    temperature:      float = 0.75
    use_llm_scoring:  bool  = True

    # ── Network ───────────────────────────────────────────────────────────────
    network_k:    int   = 6
    network_p:    float = 0.3
    network_seed: int   = 42

    # ── Belief update keywords ────────────────────────────────────────────────
    threat_keywords: List[str] = field(default_factory=lambda: [
        "arson", "attack", "violence", "crime", "danger",
        "get them out", "deportation", "deport", "riot", "assault",
    ])
    humanitarian_keywords: List[str] = field(default_factory=lambda: [
        "refugee", "asylum", "rights", "children", "family",
        "compassion", "solidarity", "waiting", "humanitarian",
    ])

    # ── Display ───────────────────────────────────────────────────────────────
    verbose: bool = True

    # ── Post-init validation ──────────────────────────────────────────────────
    def __post_init__(self):
        # Validate date
        try:
            self._parsed_date = date.fromisoformat(self.event_date)
        except ValueError:
            raise ValueError(
                f"event_date must be ISO format 'YYYY-MM-DD', got: {self.event_date!r}"
            )

        # Validate distribution sums to ~1.0
        total = sum(self.agent_distribution.values())
        if abs(total - 1.0) > 0.01:
            raise ValueError(
                f"agent_distribution proportions must sum to 1.0, got {total:.3f}"
            )

        # Validate all distribution keys have priors
        for kind in self.agent_distribution:
            if kind not in self.kind_priors:
                raise ValueError(
                    f"Agent kind '{kind}' in agent_distribution has no entry in kind_priors. "
                    f"Add a prior for it or use one of: {list(self.kind_priors.keys())}"
                )

        # Auto-derive search prefix if not provided
        if self.search_query_prefix is None:
            # Use first 8 words of critical_event + topic
            words = self.critical_event.split()[:8]
            self.search_query_prefix = " ".join(words) + " " + self.topic

    @property
    def parsed_date(self) -> date:
        return self._parsed_date
