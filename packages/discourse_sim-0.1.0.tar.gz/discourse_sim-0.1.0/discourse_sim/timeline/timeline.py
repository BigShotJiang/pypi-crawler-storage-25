"""
discourse_sim.timeline.timeline
================================
Manages the daily news context fed to agents.

Three modes, selected automatically:
1. FULL — user supplied a complete dict[int, str] covering all days.
2. PARTIAL — user supplied some days; gaps filled with generic continuation.
3. NONE — user supplied nothing; every day falls back to generic continuation.

In all modes, agents also call the live search tool (search_event_news)
during the Observe phase, so even with no timeline the simulation is
grounded in real retrieved news.

The generic continuation message is always contextually grounded because it
references the critical_event text and the topic from SimConfig.
"""

from __future__ import annotations

from datetime import timedelta
from typing import TYPE_CHECKING, Dict, Optional

if TYPE_CHECKING:
    from discourse_sim.config import SimConfig


class Timeline:
    """
    Provides a daily news entry string for each simulation day.

    Parameters
    ----------
    config : SimConfig
    """

    def __init__(self, config: "SimConfig"):
        self._config    = config
        self._entries: Dict[int, str] = config.timeline or {}

    def get(self, day: int) -> str:
        """
        Return the news entry for a given day.

        If the user provided an entry for this day, return it verbatim.
        Otherwise return a generic contextually grounded continuation.
        """
        if day in self._entries:
            return self._entries[day]
        return self._auto_entry(day)

    def _auto_entry(self, day: int) -> str:
        cfg          = self._config
        current_date = cfg.parsed_date + timedelta(days=day)
        date_str     = current_date.strftime("%B %d, %Y")

        if day == 0:
            return (
                f"[AUTO] Day 0 — {date_str}: "
                f"The critical event is unfolding. "
                f"Context: {cfg.critical_event[:300]}"
            )

        return (
            f"[AUTO] Day {day} — {date_str}: "
            f"Ongoing public debate and media coverage following the event. "
            f"Topic: {cfg.topic}. "
            f"Agents are searching live news for the latest developments."
        )

    def summary(self) -> str:
        """Human-readable summary of timeline coverage."""
        total     = self._config.n_days
        provided  = len(self._entries)
        auto      = total - provided
        return (
            f"Timeline: {provided}/{total} days user-provided, "
            f"{auto}/{total} days auto-generated."
        )
