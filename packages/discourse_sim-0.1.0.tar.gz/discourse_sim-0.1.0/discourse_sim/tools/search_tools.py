"""
discourse_sim.tools.search_tools
=================================
LangChain tools used by the Observe phase.
Tools are constructed at runtime so the search prefix can be injected
from SimConfig rather than being hardcoded.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from langchain_core.tools import tool
from langchain_community.tools import DuckDuckGoSearchRun

if TYPE_CHECKING:
    pass


def make_tools(search_query_prefix: str) -> list:
    """
    Build and return the three agent tools with the correct search prefix
    baked in. Called once per simulation run.

    Parameters
    ----------
    search_query_prefix : str
        Prepended to every DuckDuckGo query.
        Example: "Dublin immigration march April 2025 Ireland"
    """
    _ddg = DuckDuckGoSearchRun()

    @tool
    def search_event_news(query: str) -> str:
        """Search for real news related to the critical event and its aftermath.
        Use a focused query about reactions, policy changes, protests, or public opinion."""
        try:
            full_query = f"{search_query_prefix} {query}"
            results = _ddg.run(full_query)
            return results[:1200]
        except Exception as e:
            return f"Search unavailable: {e}"

    @tool
    def get_sentiment_of_text(text: str) -> str:
        """Analyse the stance of a piece of text toward the event subject.
        Returns: pro / anti / neutral with a lexicon-based confidence score."""
        lower = text.lower()
        pro_words  = ["welcome", "rights", "asylum", "refugee", "humanitarian",
                      "diversity", "support", "integration", "compassion", "solidarity"]
        anti_words = ["illegal", "threat", "invasion", "crime", "full",
                      "deport", "ban", "dangerous", "replace", "too many",
                      "get them out", "riot", "attack"]
        pro_score  = sum(1 for w in pro_words  if w in lower)
        anti_score = sum(1 for w in anti_words if w in lower)
        if anti_score > pro_score:
            return f"anti (confidence: {min(1.0, anti_score * 0.2):.2f})"
        elif pro_score > anti_score:
            return f"pro (confidence: {min(1.0, pro_score * 0.2):.2f})"
        return "neutral (confidence: 0.50)"

    @tool
    def recall_agent_memory(recent_posts_json: str) -> str:
        """Summarise an agent's recent posting history for day-to-day consistency.
        Input must be a JSON array of recent post strings."""
        try:
            posts = json.loads(recent_posts_json)
            if not posts:
                return "No prior posts to recall."
            summary = f"You have made {len(posts)} post(s) since the event.\n"
            for i, p in enumerate(posts[-3:], 1):
                summary += f"  Post -{len(posts[-3:]) - i + 1}: \"{p[:100]}...\"\n"
            return summary.strip()
        except Exception:
            return "Could not parse memory — start fresh."

    return [search_event_news, get_sentiment_of_text, recall_agent_memory]
