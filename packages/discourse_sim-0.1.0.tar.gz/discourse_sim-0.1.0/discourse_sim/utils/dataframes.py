"""
discourse_sim.utils.dataframes
================================
Helper functions to convert raw simulation output into analysis-ready DataFrames.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False

if TYPE_CHECKING:
    pass


def build_dataframes(history: list, agent_records: list) -> dict:
    """
    Convert simulation output into three analysis-ready DataFrames.

    Parameters
    ----------
    history       : list of per-timestep aggregate dicts (from run_loop)
    agent_records : list of per-agent per-timestep dicts  (from run_loop)

    Returns
    -------
    dict with keys:
        "history"  : pd.DataFrame — one row per timestep
        "agents"   : pd.DataFrame — one row per agent per timestep
        "messages" : pd.DataFrame — one row per agent per timestep (exploded messages)
    """
    if not HAS_PANDAS:
        raise ImportError("pandas is required for build_dataframes(). "
                          "Run: pip install pandas")

    df_history = pd.DataFrame(history).drop(columns=["messages", "scores"], errors="ignore")
    df_agents  = pd.DataFrame(agent_records)

    # Explode messages: one row per agent per day with correct per-day state
    rows = []
    for snap in history:
        for aid, msg in snap["messages"].items():
            rows.append({
                "t":                 snap["t"],
                "date":              snap["date"],
                "agent_id":          aid,
                "message":           msg,
                "interpreted_score": snap["scores"].get(aid, 0.0),
                "avg_attitude":      snap["avg_attitude"],
                "polarization":      snap["polarization"],
                "news_summary":      snap["news"][:120],
            })

    df_messages = pd.DataFrame(rows)

    # Merge with per-day agent state (NOT live final state)
    df_messages = df_messages.merge(
        df_agents[[
            "t", "agent_id", "kind",
            "attitude", "mood", "exposure",
            "economic_threat_belief",
            "cultural_threat_belief",
            "security_threat_belief",
            "humanitarian_belief",
            "quirk",
        ]],
        on=["t", "agent_id"],
        how="left"
    )

    df_messages = df_messages[[
        "t", "date", "agent_id", "kind", "quirk",
        "message", "interpreted_score",
        "attitude", "mood", "exposure",
        "economic_threat_belief", "cultural_threat_belief",
        "security_threat_belief", "humanitarian_belief",
        "avg_attitude", "polarization", "news_summary",
    ]]

    return {
        "history":  df_history,
        "agents":   df_agents,
        "messages": df_messages,
    }
