"""
discourse_sim.simulation.engine
================================
Core simulation engine: Observe-Think-Act loop, belief update, run loop.
"""

from __future__ import annotations

import json
import re
import random
from datetime import timedelta
from typing import TYPE_CHECKING

import numpy as np
from tqdm import trange

from langchain_core.messages import HumanMessage

try:
    from langchain_ollama import ChatOllama
except ImportError:
    from langchain_community.chat_models import ChatOllama

from discourse_sim.agents.agent import Agent, QUIRK_OPTIONS

if TYPE_CHECKING:
    from discourse_sim.config import SimConfig
    from discourse_sim.timeline.timeline import Timeline


# ── LLM factory ──────────────────────────────────────────────────────────────

def _make_llm(config: "SimConfig", temperature: float | None = None) -> ChatOllama:
    return ChatOllama(
        model=config.ollama_model,
        temperature=temperature if temperature is not None else config.temperature,
        num_predict=512,
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _build_memory(agent: Agent) -> str:
    if not agent.messages:
        return "[]"
    return json.dumps(agent.messages[-5:])


def _safe_float(val, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


# ── Observe–Think–Act ─────────────────────────────────────────────────────────

def generate_message(
    agent:      Agent,
    day:        int,
    config:     "SimConfig",
    timeline:   "Timeline",
    tools:      list,
) -> str:
    """
    Execute one Observe–Think–Act cycle for an agent on a given day.

    Observe : call search_event_news + recall_agent_memory tools in Python
    Think   : build a structured prompt with all context
    Act     : single LLM call → post text
    """
    if not agent.quirk:
        agent.quirk = random.choice(QUIRK_OPTIONS)

    current_date       = config.parsed_date + timedelta(days=day)
    day_label          = f"Day {day} ({current_date.strftime('%B %d, %Y')})"
    todays_development = timeline.get(day)

    # ── OBSERVE ──────────────────────────────────────────────────────────────
    observations: list[str] = []

    # Tool A: live news search
    search_tool  = tools[0]   # search_event_news
    memory_tool  = tools[2]   # recall_agent_memory
    search_query = f"{agent.kind} reaction {config.topic} aftermath day {day}"
    try:
        search_result = search_tool.invoke(search_query)
    except Exception as e:
        search_result = f"Search failed: {e}"
    observations.append(f"[NEWS SEARCH]\n{search_result[:600]}")
    agent.reasoning_log.append({
        "day": day,
        "steps": [{"tool": "search_event_news",
                   "input": search_query,
                   "observation": search_result[:200]}]
    })

    # Tool B: memory recall
    try:
        memory_result = memory_tool.invoke(_build_memory(agent))
    except Exception as e:
        memory_result = f"Memory recall failed: {e}"
    observations.append(f"[YOUR MEMORY]\n{memory_result}")

    observations_text = "\n\n".join(observations)

    # ── THINK + ACT ───────────────────────────────────────────────────────────
    prompt = f"""You are a social media user reacting to a major public event.

=== THE EVENT YOU ARE REACTING TO ===
{config.critical_event}
======================================

YOUR PROFILE:
- Type: {agent.kind}
- Topic stance: {agent.attitude:.2f}  (-1=strongly supportive of subject, +1=strongly opposed)
- Threat exposure: {agent.exposure:.2f}
- Mood: {agent.mood:.2f}  (-1=angry, +1=hopeful)
- Writing style: {agent.quirk}
- Beliefs: economic_threat={agent.economic_threat_belief:.2f}, \
cultural_threat={agent.cultural_threat_belief:.2f}, \
humanitarian={agent.humanitarian_belief:.2f}

TODAY — {day_label}:
{todays_development}

WHAT YOU JUST OBSERVED:
{observations_text}

TASK: Write ONE social media post (max 40 words) reacting to today's situation.
- Ground your post in the news you just searched and today's context.
- Stay consistent with your memory — do NOT flip your stance overnight.
- Write as a real person, not as an AI.
- Output ONLY the post text. No labels, no preamble."""

    try:
        llm  = _make_llm(config)
        resp = llm.invoke([HumanMessage(content=prompt)])
        post = resp.content.strip()
        post = re.sub(r"(?i)^(post|answer|output|response)\s*:\s*", "", post).strip()
        return post[:300] if post else _fallback(agent, day_label)
    except Exception as e:
        if config.verbose:
            print(f"  WARNING: LLM call failed for {agent.id} (day {day}): {e}")
        return _fallback(agent, day_label)


def _fallback(agent: Agent, day_label: str) -> str:
    return f"[{agent.kind}] {day_label} — stance {agent.attitude:.2f}"


# ── Attitude scoring ──────────────────────────────────────────────────────────

def score_message(message: str, config: "SimConfig") -> float:
    """Convert a post to a float in [-1, +1]."""
    if not config.use_llm_scoring:
        return _heuristic_score(message)

    prompt = (
        f"Analyse this social media post about {config.topic}:\n"
        f"---\n{message}\n---\n"
        "Rate it on a scale from -1 to +1:\n"
        "  -1 = strongly supportive / pro\n"
        "   0 = neutral\n"
        "  +1 = strongly opposed / anti\n\n"
        "Reply with ONLY a single number, e.g.: 0.6 or -0.3"
    )
    try:
        llm   = _make_llm(config, temperature=0.0)
        resp  = llm.invoke([HumanMessage(content=prompt)])
        match = re.search(r"-?\d+\.?\d*", resp.content.strip())
        return float(np.clip(float(match.group()), -1, 1)) if match else 0.0
    except Exception:
        return 0.0


def _heuristic_score(message: str) -> float:
    msg = message.lower()
    if any(w in msg for w in ["stop", "threat", "illegal", "full", "danger",
                               "deport", "riot", "attack", "ban"]):
        return 0.7
    elif any(w in msg for w in ["welcome", "support", "rights", "asylum",
                                 "solidarity", "refugee", "compassion"]):
        return -0.7
    return 0.0


# ── Belief update ─────────────────────────────────────────────────────────────

def update_beliefs(
    agent:           Agent,
    own_score:       float,
    neighbor_scores: list,
    news:            str,
    config:          "SimConfig",
) -> None:
    """
    Update agent belief state after all agents have posted.

    Components:
    1. News salience   — threat / humanitarian keyword scan
    2. Peer influence  — conformity × trust_peers × (peer_mean - attitude)
    3. Mood dynamics   — exponential decay + news shock
    4. Belief inertia  — 1 - openness × 0.5
    5. Full attitude   — inertia × prior + (1-inertia) × weighted blend
    6. Exposure        — monotonic increase on threat-coded days
    """
    news_lower = news.lower()

    threat_count = sum(1 for w in config.threat_keywords      if w in news_lower)
    human_count  = sum(1 for w in config.humanitarian_keywords if w in news_lower)
    news_threat  = threat_count * 0.06
    news_human   = human_count  * 0.06
    impact       = agent.emotional_reactivity

    # Sub-belief updates
    agent.security_threat_belief = float(np.clip(
        agent.security_threat_belief + news_threat * impact, -1, 1))
    agent.humanitarian_belief = float(np.clip(
        agent.humanitarian_belief + news_human * impact * agent.openness, -1, 1))

    # Peer influence
    peer_pull = 0.0
    if neighbor_scores:
        peer_mean = float(np.mean(neighbor_scores))
        peer_pull = agent.conformity * agent.trust_peers * (peer_mean - agent.attitude)

    # Mood
    mood_shock = -0.1 if news_threat > 0 else 0.04
    agent.mood = float(np.clip(0.8 * agent.mood + mood_shock, -1, 1))

    # Inertia
    inertia = 1.0 - agent.openness * 0.5

    # Composite belief pressure
    belief_composite = (
        0.3 * agent.economic_threat_belief +
        0.3 * agent.cultural_threat_belief +
        0.2 * agent.security_threat_belief -
        0.2 * agent.humanitarian_belief
    )

    new_attitude = (
        inertia * agent.attitude +
        (1 - inertia) * (
            0.4 * own_score        +
            0.3 * peer_pull        +
            0.3 * belief_composite
        )
    )

    agent.attitude = float(np.clip(new_attitude, -1, 1))
    agent.attitude_history.append(agent.attitude)

    # Exposure accumulation
    if news_threat > 0:
        agent.exposure = min(1.0, agent.exposure + 0.07 * agent.emotional_reactivity)


# ── Main simulation loop ──────────────────────────────────────────────────────

def run_loop(
    agents:    dict[str, Agent],
    G,
    neighbors: dict[str, list[str]],
    config:    "SimConfig",
    timeline:  "Timeline",
    tools:     list,
) -> tuple[list, list]:
    """
    Execute the full T-timestep simulation loop.

    Returns
    -------
    history      : list of per-timestep aggregate dicts
    agent_records: list of per-agent per-timestep dicts
    """
    history:       list = []
    agent_records: list = []

    agent_ids     = list(agents.keys())
    node_to_agent = {i: agent_ids[i] for i in range(len(agent_ids))}

    end_date = config.parsed_date + timedelta(days=config.n_days - 1)

    if config.verbose:
        print(f"\n{'=' * 62}")
        print(f"  SIMULATION: {config.topic}")
        print(f"  Critical event : {config.critical_event[:80]}...")
        print(f"  Start : {config.parsed_date.strftime('%B %d, %Y')}  (Day 0)")
        print(f"  End   : {end_date.strftime('%B %d, %Y')}  (Day {config.n_days - 1})")
        print(f"  Agents: {len(agents)}  |  Network edges: {G.number_of_edges()}")
        print(f"  {timeline.summary()}")
        print(f"{'=' * 62}\n")

    for t in trange(config.n_days, desc="Days", disable=not config.verbose):
        current_date       = config.parsed_date + timedelta(days=t)
        date_label         = current_date.strftime("%B %d, %Y")
        todays_development = timeline.get(t)

        if config.verbose:
            print(f"\n{'─' * 62}")
            print(f"  Day {t:>2}  |  {date_label}")
            print(f"  News: {todays_development[:90]}...")
            print(f"{'─' * 62}")

        # Step 1: generate posts
        posts: dict[str, str] = {}
        for aid, agent in agents.items():
            if config.verbose:
                print(f"  [>] {aid} ({agent.kind:10s}) attitude={agent.attitude:+.2f}")
            msg = generate_message(agent, t, config, timeline, tools)
            posts[aid] = msg
            agent.messages.append(msg)
            if config.verbose:
                print(f"       >> \"{msg[:80]}{'...' if len(msg) > 80 else ''}\"")

        # Step 2: score posts
        scores: dict[str, float] = {
            aid: score_message(msg, config)
            for aid, msg in posts.items()
        }

        # Step 3: update beliefs
        for aid, agent in agents.items():
            neigh_scores = [
                _safe_float(scores[n])
                for n in neighbors.get(aid, []) if n in scores
            ]
            update_beliefs(
                agent=agent,
                own_score=_safe_float(scores[aid]),
                neighbor_scores=neigh_scores,
                news=todays_development,
                config=config,
            )

        # Step 4: aggregate snapshot
        avg_att = float(np.mean([a.attitude for a in agents.values()]))
        polar   = float(np.mean([
            abs(agents[node_to_agent[u]].attitude - agents[node_to_agent[v]].attitude)
            for u, v in G.edges()
        ])) if G.number_of_edges() > 0 else 0.0

        history.append({
            "t":            t,
            "date":         date_label,
            "news":         todays_development,
            "avg_attitude": avg_att,
            "polarization": polar,
            "avg_mood":     float(np.mean([a.mood     for a in agents.values()])),
            "avg_exposure": float(np.mean([a.exposure for a in agents.values()])),
            "messages":     posts,
            "scores":       scores,
        })

        # Step 5: per-agent panel
        for aid, agent in agents.items():
            agent_records.append({
                "t":                      t,
                "date":                   date_label,
                "agent_id":               aid,
                "kind":                   agent.kind,
                "attitude":               agent.attitude,
                "economic_threat_belief": agent.economic_threat_belief,
                "cultural_threat_belief": agent.cultural_threat_belief,
                "security_threat_belief": agent.security_threat_belief,
                "humanitarian_belief":    agent.humanitarian_belief,
                "mood":                   agent.mood,
                "exposure":               agent.exposure,
                "quirk":                  agent.quirk,
                "last_message":           posts[aid],
                "interpreted_score":      scores.get(aid, 0.0),
            })

        if config.verbose:
            print(f"\n  [stats]  avg_attitude={avg_att:+.3f}  "
                  f"polarization={polar:.3f}")

    return history, agent_records
