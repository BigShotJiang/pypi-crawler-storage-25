"""
examples/custom_agent_kinds.py
==============================
Example 3: Adding a custom agent kind ("nationalist") with its own priors.
Shows how to extend beyond the four default kinds.
"""

from discourse_sim import DiscourseSimulation
from discourse_sim.config import DEFAULT_KIND_PRIORS

# ── Define a new kind by extending the defaults ───────────────────────────────
custom_priors = {
    **DEFAULT_KIND_PRIORS,   # keep all existing kinds
    "nationalist": {
        # Very anti-immigration, high cultural threat, low openness
        # Distinct from far_right: more focused on national identity than security
        "attitude":        (0.55, 0.95),
        "economic_threat": (0.2,  0.6),   # less economically focused
        "cultural_threat": (0.7,  1.0),   # primary driver is cultural
        "humanitarian":    (-0.6, 0.0),
        "openness":        (0.1,  0.35),
        "emotional_react": (0.5,  0.85),
    },
}

sim = DiscourseSimulation(
    critical_event=(
        "In November 2023, Dublin city centre erupted in riots following a knife attack "
        "near a school. Far-right agitators set buses alight, attacked Gardaí, and targeted "
        "immigrant-owned businesses. The event shocked Ireland and dominated media for weeks."
    ),
    event_date="2023-11-23",
    topic="immigration and civil disorder in Ireland",
    n_agents=80,
    n_days=14,
    agent_distribution={
        "centrist":    0.35,
        "far_right":   0.15,
        "nationalist": 0.20,   # new kind
        "pro_imm":     0.20,
        "media":       0.10,
    },
    kind_priors=custom_priors,
    ollama_model="mistral:7b-instruct-q4_0",
    threat_keywords=[
        "riot", "arson", "attack", "violence", "knife", "asylum seeker",
        "deport", "crime", "danger", "get them out",
    ],
    humanitarian_keywords=[
        "refugee", "rights", "children", "family", "compassion",
        "solidarity", "innocent", "asylum",
    ],
)

sim.run()
dfs = sim.to_dataframes()
dfs["messages"].to_excel("dublin_riots_messages.xlsx", index=False)
print("Done. Shape:", dfs["messages"].shape)
