"""
examples/dublin_march.py
========================
Example 1: Reproduce the original Dublin anti-immigration march experiment.
Full explicit timeline, 100 agents, 15 days.
"""

from discourse_sim import DiscourseSimulation

# ── Critical event description ────────────────────────────────────────────────
DUBLIN_MARCH = """
In late April 2025, Dublin saw a large anti-immigration march from the Garden of
Remembrance to the Custom House, with thousands protesting what they described as
high levels of immigration and pressure on housing and public services. The protest
featured slogans such as 'Ireland is Full' and 'Get Them Out', and it was met by a
counter-protest ("United Against Racism"). The government has also faced pressure
after a series of violent protests, arson threats, and resistance to building new
asylum seeker centres in certain regions.
""".strip()

# ── Verified 15-day post-event timeline ───────────────────────────────────────
DUBLIN_TIMELINE = {
    0:  "[VERIFIED] Day 0 — April 26: The 'National Protest' march moves from the Garden "
        "of Remembrance to Custom House Quay. Over 5,000 gather. Conor McGregor posts "
        "video in support. ~1,000 United Against Racism counter-protesters at the GPO. "
        "3 arrests. Luas services disrupted.",
    1:  "[VERIFIED] Day 1 — April 27: Taoiseach Martin says the government is 'not concerned' "
        "by the protest and rejects its 'narrow nationalism'.",
    2:  "[CONTEXT ONLY] Day 2 — April 28: International coverage peaks. US right-wing outlets "
        "amplify footage. Background: 18,651 asylum applications in 2024, a record.",
    3:  "[CONTEXT ONLY] Day 3 — April 29: 1,599 deportation orders signed in first 4 months "
        "of 2025 — almost double 2024 rate — yet fewer than half carried out.",
    4:  "[VERIFIED] Day 4 — April 30: Charter deportation flight to Tbilisi, Georgia. "
        "39 people removed including children. Cost: €103,751. Minister O'Callaghan defends.",
    5:  "[CONTEXT ONLY] Day 5 — May 1: Ongoing debate. Q1 2025 protection applications "
        "fell 42% vs Q1 2024.",
    6:  "[CONTEXT ONLY] Day 6 — May 2: International Protection Bill 2025 under development "
        "to align with EU Migration and Asylum Pact (June 2026).",
    7:  "[CONTEXT ONLY] Day 7 — May 3: One week since march. Far right failed to win "
        "parliamentary seats in Nov 2024 but demonstrated strong street mobilisation.",
    8:  "[CONTEXT ONLY] Day 8 — May 4: Debate about IPAS consultation failures. Communities "
        "complained about lack of notice before centres open — driver of local protests since 2022.",
    9:  "[VERIFIED] Day 9 — May 5: RTÉ publishes explainer on deportation enforcement gap. "
        "1,599 orders signed, fewer than half executed. Lawyer warns of injunction risk.",
    10: "[CONTEXT ONLY] Day 10 — May 6: Net migration ~72,000/year since 2022. "
        "18,651 asylum applications in 2024. Figures circulate widely.",
    11: "[VERIFIED CONTEXT] Day 11 — May 7: Deportations tripled Q1 2025 vs Q1 2024. "
        "Two Georgia flights (Feb 27 + Apr 30) = 71 removals. EU Pact framing confirmed.",
    12: "[CONTEXT ONLY] Day 12 — May 8: Far-right activists target delivery driver post-march. "
        "Socialist Party calls for anti-fascist mobilisation.",
    13: "[CONTEXT ONLY] Day 13 — May 9: Ireland population 5.46 million (April 2025). "
        "Net migration nearly doubled since 2022.",
    14: "[CONTEXT ONLY] Day 14 — May 10: Two weeks on. International Protection Bill in "
        "development. Both sides remain active.",
}

# ── Run ───────────────────────────────────────────────────────────────────────
sim = DiscourseSimulation(
    critical_event=DUBLIN_MARCH,
    event_date="2025-04-26",
    topic="immigration in Ireland",
    n_agents=100,
    n_days=15,
    agent_distribution={
        "centrist":  0.45,
        "far_right": 0.20,
        "pro_imm":   0.25,
        "media":     0.10,
    },
    timeline=DUBLIN_TIMELINE,
    ollama_model="mistral:7b-instruct-q4_0",
    temperature=0.75,
    network_k=6,
    network_p=0.3,
    network_seed=42,
)

sim.run()

# ── Output ────────────────────────────────────────────────────────────────────
dfs = sim.to_dataframes()

dfs["messages"].to_excel("dublin_march_messages.xlsx", index=False)
dfs["history"].to_csv("dublin_march_history.csv",  index=False)
dfs["agents"].to_csv("dublin_march_agents.csv",    index=False)

print(f"\nSaved: dublin_march_messages.xlsx, dublin_march_history.csv, dublin_march_agents.csv")
print(dfs["messages"].shape)
