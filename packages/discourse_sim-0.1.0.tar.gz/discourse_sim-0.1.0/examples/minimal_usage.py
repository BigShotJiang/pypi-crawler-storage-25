"""
examples/minimal_usage.py
=========================
Example 2: Minimal usage — no explicit timeline, live search only.
Good starting point for any new event.
"""

from discourse_sim import DiscourseSimulation

sim = DiscourseSimulation(
    critical_event=(
        "In August 2024, violent riots erupted across several UK cities following "
        "false social media claims linking a knife attack in Southport to an asylum seeker. "
        "Far-right mobs attacked mosques, hotels housing asylum seekers, and attacked police. "
        "Counter-protests mobilised across the country within days."
    ),
    event_date="2024-08-03",
    topic="immigration and far-right violence in the UK",
    n_agents=5,
    n_days=3,
    agent_distribution={
        "centrist":  0.40,
        "far_right": 0.25,
        "pro_imm":   0.25,
        "media":     0.10,
    },
    # No timeline supplied — agents rely on live DuckDuckGo search each day
    ollama_model="mistral:7b-instruct-q4_0",
    verbose=True,
)

sim.run()
df = sim.to_dataframe()
print(df[["date", "agent_id", "kind", "message", "attitude"]].head(20))
df.to_excel("uk_riots_messages.xlsx", index=False)
