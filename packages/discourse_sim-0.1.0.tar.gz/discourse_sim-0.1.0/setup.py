from setuptools import setup, find_packages

setup(
    name="discourse_sim",
    version="0.1.0",
    description=(
        "LLM-augmented Agent-Based Social Simulation for modelling "
        "public discourse dynamics following a critical real-world event."
    ),
    author="dreji18",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "numpy",
        "networkx",
        "tqdm",
        "pandas",
        "langchain-core",
        "langchain-community",
        "duckduckgo-search",
    ],
    extras_require={
        "ollama": ["langchain-ollama"],
    },
)
