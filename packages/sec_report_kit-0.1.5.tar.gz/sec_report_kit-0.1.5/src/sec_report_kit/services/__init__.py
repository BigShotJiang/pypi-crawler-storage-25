"""Normalization and summarization services."""
