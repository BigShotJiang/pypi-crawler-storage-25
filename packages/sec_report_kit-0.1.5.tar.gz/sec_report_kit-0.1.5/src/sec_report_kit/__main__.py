from sec_report_kit.cli import main


if __name__ == "__main__":  # pragma: no cover
    main()
