"""MCP registration orchestration for all supported CLIs."""

from __future__ import annotations

from .cli_registry import register_all, unregister_all
from .skills import install_skills

__all__ = [
    "register_all",
    "unregister_all",
    "install_skills",
]
