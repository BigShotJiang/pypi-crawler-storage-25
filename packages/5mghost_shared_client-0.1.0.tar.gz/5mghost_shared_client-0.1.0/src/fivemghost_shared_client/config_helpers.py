"""Path constants and configuration helpers for shared MCP client."""

from __future__ import annotations

from pathlib import Path


def build_shared_auth_paths(home_dir: Path | str | None = None) -> dict[str, Path]:
    """Resolve the shared auth home directory for local MCP clients."""
    root = Path(home_dir) if home_dir is not None else Path.home()
    shared_auth_dir = root / ".mkterswingman"
    return {
        "shared_auth_dir": shared_auth_dir,
        "shared_auth_json": shared_auth_dir / "auth.json",
    }


def ensure_config_dir(config_path: Path) -> None:
    """Create a config directory if it doesn't exist, with 700 permissions."""
    config_path.mkdir(parents=True, exist_ok=True)
    # Best-effort tighten permissions (no-op on Windows)
    try:
        config_path.chmod(0o700)
    except OSError:
        pass


def ensure_shared_auth_dir(auth_path: Path = None) -> None:
    """Create the shared auth home directory used by first-party local MCPs."""
    if auth_path is None:
        auth_path = Path.home() / ".mkterswingman" / "auth.json"
    auth_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        auth_path.parent.chmod(0o700)
    except OSError:
        pass


# Auth gateway (shared with yt-mcp)
AUTH_URL = "https://mkterswingman.com"

# Shared auth location
SHARED_AUTH_DIR = Path.home() / ".mkterswingman"
SHARED_AUTH_JSON = SHARED_AUTH_DIR / "auth.json"
