# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-17

### Added
- Initial release.
- `SpineClient` (sync) and `AsyncSpineClient` (async) with context-manager support.
- `runs.create`, `runs.get`, and `RunHandle.wait()` / `stream_progress()`.
- `canvas.get_dag`, `canvas.get_tasks`, `canvas.get_task`.
- Typed Pydantic models mirroring the Spine API schemas.
- Typed exception hierarchy for every API error.
- Automatic retry on transient 5xx and 429 responses (honours `Retry-After`).
- Google-style docstrings throughout; ships `py.typed`.

[Unreleased]: https://github.com/Spine-AI/spine-py/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/Spine-AI/spine-py/releases/tag/v0.1.0
