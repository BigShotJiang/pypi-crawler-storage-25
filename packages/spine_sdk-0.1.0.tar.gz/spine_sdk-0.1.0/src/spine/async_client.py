"""Asynchronous client for the Spine API.

Use this when you are running inside an ``asyncio`` event loop (FastAPI,
aiohttp, discord.py, etc.). The API surface matches :class:`spine.client.SpineClient`
exactly — every method is a direct ``async`` twin.

.. code-block:: python

    import asyncio
    from spine import AsyncSpineClient

    async def main() -> None:
        async with AsyncSpineClient() as client:
            handle = await client.runs.create(prompt="Hello")
            result = await handle.wait()
            print(result.final_output)

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
from types import TracebackType
from typing import Any, Mapping, Optional, Sequence, Tuple, Type

import httpx

from ._client import _BaseClient
from ._retries import RetryPolicy
from .exceptions import SpineConnectionError, SpineTimeoutError
from .resources import AsyncCanvasResource, AsyncRunsResource


class AsyncSpineClient(_BaseClient):
    """Asynchronous client for the Spine API.

    See :class:`spine.client.SpineClient` for the full argument
    documentation — the constructor signature is identical, with the
    exception that ``http_client`` expects an :class:`httpx.AsyncClient`.

    Attributes:
        runs: Async resource namespace for creating and polling runs.
        canvas: Async resource namespace for introspecting canvases.
    """

    runs: AsyncRunsResource
    canvas: AsyncCanvasResource

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        retry_policy: Optional[RetryPolicy] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retry_policy=retry_policy,
        )
        self._http: httpx.AsyncClient = http_client or httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self._timeout,
        )
        self._owns_http = http_client is None

        self.runs = AsyncRunsResource(self)
        self.canvas = AsyncCanvasResource(self)

    async def aclose(self) -> None:
        """Release the underlying async HTTP connection pool.

        Idempotent. Only closes the transport when the client was not
        constructed with an injected ``http_client``.
        """
        if self._owns_http:
            await self._http.aclose()

    async def __aenter__(self) -> "AsyncSpineClient":
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        await self.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Optional[Sequence[Tuple[str, Any]]] = None,
    ) -> httpx.Response:
        """Async twin of :meth:`spine.client.SpineClient._request`."""
        attempt = 0
        while True:
            try:
                response = await self._http.request(
                    method,
                    path,
                    params=params,
                    data=data,
                    files=list(files) if files else None,
                    headers=self._default_headers,
                )
            except httpx.TimeoutException as exc:
                raise SpineTimeoutError(f"Request to {path} timed out") from exc
            except httpx.ConnectError as exc:
                if not self.retry_policy.should_retry(attempt=attempt, response=None):
                    raise SpineConnectionError(f"Failed to connect to {path}: {exc}") from exc
                await asyncio.sleep(self.retry_policy.compute_delay(attempt=attempt, response=None))
                attempt += 1
                continue
            except httpx.HTTPError as exc:
                raise SpineConnectionError(f"Transport error on {path}: {exc}") from exc

            if not self.retry_policy.should_retry(attempt=attempt, response=response):
                return response

            await asyncio.sleep(self.retry_policy.compute_delay(attempt=attempt, response=response))
            attempt += 1


__all__ = ["AsyncSpineClient"]
