"""Polling helpers for long-running Spine runs.

The Spine API uses a polling model: ``POST /run`` accepts a run and
returns immediately, and the caller polls ``GET /run/{run_id}`` until the
run reaches a terminal state. Writing that loop by hand is tedious and
error-prone, so the SDK ships :class:`RunHandle` and
:class:`AsyncRunHandle` which encapsulate the pattern with sensible
defaults (exponential backoff, timeouts, typed results).

Both handles are returned directly from
:meth:`spine.resources.runs.RunsResource.create` and
:meth:`spine.resources.runs.AsyncRunsResource.create` — you never
construct them yourself.
"""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING, AsyncIterator, Iterator, Optional

from .enums import TERMINAL_STATUSES, RunStatus
from .exceptions import SpineAPIError, SpineTimeoutError
from .models import CreateRunResponse, GetRunResponse, RunProgress, RunResult

if TYPE_CHECKING:
    from .async_client import AsyncSpineClient
    from .client import SpineClient


DEFAULT_POLL_INTERVAL = 2.0
"""Initial delay between polls, in seconds."""

DEFAULT_MAX_POLL_INTERVAL = 30.0
"""Upper bound on poll delay — with exponential backoff, we hit this
quickly on long-running jobs so we don't hammer the API."""

DEFAULT_WAIT_TIMEOUT = 900.0
"""Default total wait time (15 minutes) for :meth:`RunHandle.wait`."""


class _HandleBase:
    """Shared state for sync and async run handles.

    Attributes:
        run_id: UUID of the run this handle refers to.
        canvas_id: UUID of the canvas the run writes into.
        create_response: The original :class:`CreateRunResponse` returned
            from ``POST /run``.
    """

    run_id: str
    canvas_id: Optional[str]
    create_response: CreateRunResponse

    def __init__(
        self,
        *,
        run_id: str,
        canvas_id: Optional[str],
        create_response: CreateRunResponse,
    ) -> None:
        self.run_id = run_id
        self.canvas_id = canvas_id
        self.create_response = create_response

    def __repr__(self) -> str:
        return f"<{type(self).__name__} run_id={self.run_id!r} canvas_id={self.canvas_id!r}>"


class RunHandle(_HandleBase):
    """Synchronous polling handle for a Spine run.

    Returned from :meth:`spine.resources.runs.RunsResource.create`. The
    handle remembers the underlying client, so polling methods do not
    require you to pass it back in.
    """

    def __init__(
        self,
        *,
        client: "SpineClient",
        run_id: str,
        canvas_id: Optional[str],
        create_response: CreateRunResponse,
    ) -> None:
        super().__init__(
            run_id=run_id,
            canvas_id=canvas_id,
            create_response=create_response,
        )
        self._client = client

    def refresh(self) -> GetRunResponse:
        """Fetch a fresh status snapshot.

        Equivalent to ``client.runs.get(handle.run_id)``.
        """
        return self._client.runs.get(self.run_id)

    def wait(
        self,
        *,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_poll_interval: float = DEFAULT_MAX_POLL_INTERVAL,
    ) -> RunResult:
        """Block until the run reaches a terminal state and return its result.

        The method uses truncated exponential backoff: each poll waits
        twice as long as the previous one, up to ``max_poll_interval``.

        Args:
            timeout: Maximum total time to wait, in seconds.
            poll_interval: Initial delay between polls.
            max_poll_interval: Upper bound on the poll delay.

        Returns:
            The run's :class:`RunResult`.

        Raises:
            SpineTimeoutError: If the timeout is reached before the run
                terminates.
            SpineAPIError: If the run terminates with status
                :attr:`RunStatus.FAILED` (no usable result). Partial
                successes return normally; inspect the result's
                ``errors`` via :meth:`refresh` if you need them.
        """
        deadline = time.monotonic() + timeout
        interval = poll_interval
        while True:
            snapshot = self.refresh()
            if snapshot.status in TERMINAL_STATUSES:
                return _result_or_raise(snapshot)

            if time.monotonic() >= deadline:
                raise SpineTimeoutError(f"Run {self.run_id} did not complete within {timeout}s")

            sleep_for = min(interval, max(0.0, deadline - time.monotonic()))
            time.sleep(sleep_for)
            interval = min(interval * 2, max_poll_interval)

    def stream_progress(
        self,
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> Iterator[RunProgress]:
        """Yield :class:`RunProgress` snapshots until the run terminates.

        Useful for driving a progress bar. The generator exits silently
        once the run reaches a terminal state — call :meth:`refresh` or
        :meth:`wait` afterwards if you need the final result.

        Args:
            poll_interval: Delay between polls, in seconds.

        Yields:
            A :class:`RunProgress` for each successful poll where the
            run is still running.
        """
        while True:
            snapshot = self.refresh()
            if snapshot.status in TERMINAL_STATUSES:
                return
            if snapshot.progress is not None:
                yield snapshot.progress
            time.sleep(poll_interval)


class AsyncRunHandle(_HandleBase):
    """Async twin of :class:`RunHandle`."""

    def __init__(
        self,
        *,
        client: "AsyncSpineClient",
        run_id: str,
        canvas_id: Optional[str],
        create_response: CreateRunResponse,
    ) -> None:
        super().__init__(
            run_id=run_id,
            canvas_id=canvas_id,
            create_response=create_response,
        )
        self._client = client

    async def refresh(self) -> GetRunResponse:
        """Async twin of :meth:`RunHandle.refresh`."""
        return await self._client.runs.get(self.run_id)

    async def wait(
        self,
        *,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_poll_interval: float = DEFAULT_MAX_POLL_INTERVAL,
    ) -> RunResult:
        """Async twin of :meth:`RunHandle.wait`."""
        deadline = time.monotonic() + timeout
        interval = poll_interval
        while True:
            snapshot = await self.refresh()
            if snapshot.status in TERMINAL_STATUSES:
                return _result_or_raise(snapshot)

            if time.monotonic() >= deadline:
                raise SpineTimeoutError(f"Run {self.run_id} did not complete within {timeout}s")

            sleep_for = min(interval, max(0.0, deadline - time.monotonic()))
            await asyncio.sleep(sleep_for)
            interval = min(interval * 2, max_poll_interval)

    async def stream_progress(
        self,
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> AsyncIterator[RunProgress]:
        """Async twin of :meth:`RunHandle.stream_progress`."""
        while True:
            snapshot = await self.refresh()
            if snapshot.status in TERMINAL_STATUSES:
                return
            if snapshot.progress is not None:
                yield snapshot.progress
            await asyncio.sleep(poll_interval)


def _result_or_raise(snapshot: GetRunResponse) -> RunResult:
    """Return ``snapshot.result`` or raise the appropriate error."""
    if snapshot.status == RunStatus.FAILED:
        error_messages = _summarise_errors(snapshot)
        raise SpineAPIError(
            f"Run {snapshot.run_id} failed: {error_messages}",
            status_code=0,
            error_message=error_messages,
            response_body=None,
            request_id=None,
        )

    if snapshot.result is None:
        raise SpineAPIError(
            f"Run {snapshot.run_id} reached terminal status "
            f"{snapshot.status.value} but returned no result",
            status_code=0,
            error_message=None,
            response_body=None,
            request_id=None,
        )
    return snapshot.result


def _summarise_errors(snapshot: GetRunResponse) -> str:
    if not snapshot.errors:
        return "no error detail provided"
    return "; ".join(err.error for err in snapshot.errors)


__all__ = ["AsyncRunHandle", "RunHandle"]
