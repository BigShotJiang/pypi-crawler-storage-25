"""Pydantic models for Spine API requests and responses.

The models use ``extra="ignore"`` so new backend fields do not break old
SDK releases, and ``populate_by_name=True`` so users can construct them
with either Python names or JSON aliases.
"""

from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from .enums import RunStatus


class _SpineModel(BaseModel):
    """Base class for every SDK model.

    Centralises the :class:`ConfigDict` so all models share the same
    tolerance for unknown fields and the same alias behaviour.
    """

    model_config = ConfigDict(
        extra="ignore",
        populate_by_name=True,
        str_strip_whitespace=True,
    )


class RunProgress(_SpineModel):
    """Progress snapshot for a running Spine run.

    Only present when the run's status is :attr:`RunStatus.RUNNING`.

    Attributes:
        tasks_completed: Number of canvas tasks that have reached a terminal
            state (``completed`` or ``error``).
        tasks_total: Total number of canvas tasks spawned so far. This value
            can grow during the run as new sub-tasks are created.
        elapsed_ms: Wall-clock time since the run was created, in
            milliseconds.
    """

    tasks_completed: int = Field(ge=0)
    tasks_total: int = Field(ge=0)
    elapsed_ms: int = Field(ge=0)


class RunArtifact(_SpineModel):
    """A downloadable output produced by a run.

    Artifacts are created for block types that produce files (reports,
    spreadsheets, slide decks, images, prototypes, etc.).

    Attributes:
        id: UUID of the canvas node that produced this artifact.
        type: Short type tag — one of ``docx``, ``xlsx``, ``pptx``, ``html``,
            or ``png``.
        name: Human-readable filename (e.g. ``"Q4 Market Report.docx"``).
        download_url: Pre-signed URL that can be fetched directly (no auth
            headers required). Expires after a short window.
        size_bytes: File size in bytes, when known.
    """

    id: str
    type: str
    name: str
    download_url: str
    size_bytes: Optional[int] = None


class RunResult(_SpineModel):
    """Terminal payload of a successful (or partially successful) run.

    Attributes:
        final_output: Markdown-formatted summary of the run, suitable for
            display in a chat UI or logging.
        artifacts: List of downloadable files produced by the run.
    """

    final_output: str
    artifacts: List[RunArtifact] = Field(default_factory=list)


class RunMetadata(_SpineModel):
    """Metadata about a completed run.

    Attributes:
        template_used: The canvas template Spine resolved the run to.
        models_used: LLM model identifiers used (e.g.
            ``"anthropic/claude-sonnet-4-6"``).
        credits_consumed: Total credits billed for the run.
    """

    template_used: str
    models_used: List[str] = Field(default_factory=list)
    credits_consumed: int = Field(ge=0)


class RunError(_SpineModel):
    """A single error that occurred during a run.

    A run with terminal status :attr:`RunStatus.FAILED` or
    :attr:`RunStatus.PARTIAL` will typically contain one or more of these
    in :attr:`GetRunResponse.errors`.

    Attributes:
        error: Human-readable error message.
        block_id: UUID of the canvas node that failed, when the error is
            scoped to a single block.
        block_type: Block type string (e.g. ``"document-block"``) of the
            failed block, when known.
        recoverable: Whether the error is likely to succeed on retry.
    """

    error: str
    block_id: Optional[str] = None
    block_type: Optional[str] = None
    recoverable: Optional[bool] = None


class CreateRunResponse(_SpineModel):
    """Response from :meth:`spine.resources.runs.RunsResource.create`.

    The run executes asynchronously. Callers should poll
    :meth:`spine.resources.runs.RunsResource.get` with ``run_id`` until the
    status becomes terminal, or use the convenience
    :meth:`spine.polling.RunHandle.wait` helper.

    Attributes:
        run_id: UUID of the newly created run.
        status: Always ``"running"`` at creation time.
        canvas_id: UUID of the canvas that will hold the output blocks.
        poll_url: Relative path to poll for status (``/v1/run/{run_id}``).
        estimated_duration_ms: Spine's best estimate of how long the run
            will take, in milliseconds.
    """

    run_id: str
    status: str
    canvas_id: Optional[str] = None
    poll_url: str
    estimated_duration_ms: int = Field(ge=0)


class GetRunResponse(_SpineModel):
    """Response from :meth:`spine.resources.runs.RunsResource.get`.

    The set of populated fields depends on :attr:`status`:

    * ``RUNNING`` — :attr:`progress` is set.
    * ``COMPLETED`` — :attr:`result` and :attr:`metadata` are set.
    * ``PARTIAL`` — :attr:`result`, :attr:`metadata`, and :attr:`errors`
      are set.
    * ``FAILED`` — :attr:`errors` is set.

    Attributes:
        run_id: UUID of the run.
        status: Current lifecycle state.
        canvas_id: UUID of the underlying canvas.
        duration_ms: Total wall-clock duration, once the run has finished.
        progress: Progress snapshot, while still running.
        result: Final output and artifacts, once terminal.
        metadata: Billing and configuration metadata.
        errors: Errors encountered, if any.
        prompt: The original prompt submitted.
        template: The template the run was created with.
        blocks: Optional block-type allow-list the run was created with.
        agent_instructions: Extra agent instructions submitted with the run.
    """

    run_id: str
    status: RunStatus
    canvas_id: Optional[str] = None
    duration_ms: Optional[int] = None
    progress: Optional[RunProgress] = None
    result: Optional[RunResult] = None
    metadata: Optional[RunMetadata] = None
    errors: Optional[List[RunError]] = None
    prompt: Optional[str] = None
    template: Optional[str] = None
    blocks: Optional[List[str]] = None
    agent_instructions: Optional[str] = None


class CanvasNode(_SpineModel):
    """A single node in the canvas block graph.

    Attributes:
        id: UUID of the block.
        name: Display name of the block.
        type: Block type string (e.g. ``"document-block"``).
        status: Current state of the block (``idle``, ``running``,
            ``completed``, ``error``, etc.).
        content: Textual content, if the block has any.
        url: External or download URL associated with the block.
        sources: Sources used to produce the block (block-type specific).
    """

    id: str
    name: str
    type: str
    status: str
    content: Optional[str] = None
    url: Optional[str] = None
    sources: List[Any] = Field(default_factory=list)


class CanvasEdge(_SpineModel):
    """A directed edge in the canvas block graph.

    An edge from ``source_id`` to ``target_id`` means the target block
    depends on (or was derived from) the source block.
    """

    source_id: str
    target_id: str


class CanvasDAG(_SpineModel):
    """Full block graph for a canvas.

    Attributes:
        canvas_id: UUID of the canvas.
        canvas_name: Human-readable canvas name.
        nodes: All blocks in the canvas.
        edges: Dependency edges between blocks.
    """

    canvas_id: str
    canvas_name: str
    nodes: List[CanvasNode] = Field(default_factory=list)
    edges: List[CanvasEdge] = Field(default_factory=list)


class TaskNode(_SpineModel):
    """A node in the run's task tree.

    Attributes:
        task_id: UUID of the task.
        name: Display name of the task (usually the tool-call or agent
            subject).
        task_type: Server-side task type
            (``parent-task``, ``persona-task``, ``tool-call-task``, ...).
        status: Terminal state of the task (``completed``, ``error``,
            ``running``).
        children: Sub-tasks, if any.
    """

    task_id: str
    name: str
    task_type: str
    status: str
    children: Optional[List["TaskNode"]] = None


TaskNode.model_rebuild()


class TaskTree(_SpineModel):
    """Full task tree for a canvas.

    The tree is split into completed and not-yet-completed subtrees so
    callers can render them differently.

    Attributes:
        canvas_id: UUID of the canvas.
        completed: Root tasks whose subtree has fully completed.
        not_completed: Root tasks still in progress or failed.
    """

    canvas_id: str
    completed: List[TaskNode] = Field(default_factory=list)
    not_completed: List[TaskNode] = Field(default_factory=list)


__all__ = [
    "CanvasDAG",
    "CanvasEdge",
    "CanvasNode",
    "CreateRunResponse",
    "GetRunResponse",
    "RunArtifact",
    "RunError",
    "RunMetadata",
    "RunProgress",
    "RunResult",
    "TaskNode",
    "TaskTree",
]
