"""Shared base for the sync and async clients.

Both :class:`spine.client.SpineClient` and
:class:`spine.async_client.AsyncSpineClient` inherit from
:class:`_BaseClient` to share URL construction, auth, timeouts, and
retry configuration.

The actual HTTP transport (``httpx.Client`` vs ``httpx.AsyncClient``) is
constructed by the concrete subclasses so the sync and async paths stay
genuinely decoupled.
"""

from __future__ import annotations

import os
from typing import Optional

import httpx

from ._retries import RetryPolicy
from ._version import __version__

DEFAULT_BASE_URL = "https://api.getspine.ai"
"""Production base URL. Overridden by the ``SPINE_BASE_URL`` env var or the
``base_url`` constructor argument."""

DEFAULT_TIMEOUT = httpx.Timeout(60.0, connect=10.0)
"""Default per-request timeout: 60s total, 10s to connect."""

API_PREFIX = "/v1"
"""The Spine API is mounted under ``/v1``."""


class _BaseClient:
    """Shared configuration for sync and async clients.

    Subclasses create the concrete :class:`httpx.Client` or
    :class:`httpx.AsyncClient` instance and attach resource namespaces.

    Attributes:
        base_url: Normalised base URL (no trailing slash, includes
            ``/v1``).
        retry_policy: Configured retry policy; consulted by the concrete
            subclass on each request.
    """

    base_url: str
    retry_policy: RetryPolicy

    def __init__(
        self,
        *,
        api_key: Optional[str],
        base_url: Optional[str],
        timeout: Optional[httpx.Timeout],
        retry_policy: Optional[RetryPolicy],
    ) -> None:
        resolved_key = api_key or os.environ.get("SPINE_API_KEY")
        if not resolved_key:
            raise ValueError(
                "Missing API key. Pass api_key=... or set the SPINE_API_KEY environment variable."
            )
        self._api_key = resolved_key
        self._timeout = timeout or DEFAULT_TIMEOUT
        self.retry_policy = retry_policy or RetryPolicy()
        self.base_url = _normalise_base_url(
            base_url or os.environ.get("SPINE_BASE_URL") or DEFAULT_BASE_URL
        )

    @property
    def _default_headers(self) -> dict[str, str]:
        """Headers applied to every outgoing request."""
        return {
            "X-API-KEY": self._api_key,
            "User-Agent": f"spine-sdk-python/{__version__}",
            "Accept": "application/json",
        }


def _normalise_base_url(raw: str) -> str:
    """Strip trailing slashes and append ``/v1`` if missing."""
    trimmed = raw.rstrip("/")
    if trimmed.endswith(API_PREFIX):
        return trimmed
    return f"{trimmed}{API_PREFIX}"
