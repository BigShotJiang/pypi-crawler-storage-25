"""Multipart-upload helpers for ``runs.create``.

The Spine ``POST /v1/run`` endpoint accepts multipart/form-data. This
module normalises the many shapes a caller might pass as ``files=...`` into
the tuple form expected by :class:`httpx.Client.post`.
"""

from __future__ import annotations

import mimetypes
import os
from pathlib import Path
from typing import IO, Iterable, List, Mapping, Optional, Tuple, Union, cast

FileLike = Union[
    str,
    os.PathLike[str],
    Path,
    IO[bytes],
    Tuple[str, IO[bytes]],
    Tuple[str, IO[bytes], str],
    Tuple[str, bytes],
    Tuple[str, bytes, str],
    Mapping[str, object],
]
"""All shapes accepted by :func:`build_multipart_files`.

* ``"path/to/file.pdf"`` — opened from disk, filename and content-type
  inferred.
* ``pathlib.Path("...")`` — same.
* An open file object — filename inferred from ``.name`` if available.
* A ``(filename, fileobj)`` tuple.
* A ``(filename, fileobj, content_type)`` tuple.
* A ``(filename, bytes)`` tuple.
* A ``(filename, bytes, content_type)`` tuple.
* A mapping with keys ``filename``, ``content`` (bytes or IO), and
  optional ``content_type``.
"""

_HttpxFileTuple = Tuple[str, Tuple[str, Union[bytes, IO[bytes]], str]]


def build_multipart_files(
    files: Optional[Iterable[FileLike]],
) -> List[_HttpxFileTuple]:
    """Normalise a mixed iterable of file inputs into httpx's expected shape.

    Args:
        files: Iterable of file-like inputs (see :data:`FileLike`). May be
            ``None`` or empty, in which case an empty list is returned.

    Returns:
        A list of tuples suitable for passing as the ``files=`` argument to
        :meth:`httpx.Client.post`. Every entry is keyed on the form field
        name ``"files"`` — the endpoint accepts multiple files under
        that same field.

    Raises:
        TypeError: If an entry is not one of the accepted shapes.
        FileNotFoundError: If a string/Path entry points to a missing file.
    """
    if not files:
        return []

    result: List[_HttpxFileTuple] = []
    for entry in files:
        result.append(("files", _normalise(entry)))
    return result


def _normalise(entry: FileLike) -> Tuple[str, Union[bytes, IO[bytes]], str]:
    if isinstance(entry, (str, os.PathLike)):
        return _from_path(Path(entry))

    if isinstance(entry, Path):
        return _from_path(entry)

    if isinstance(entry, tuple):
        return _from_tuple(entry)

    if isinstance(entry, Mapping):
        return _from_mapping(entry)

    if hasattr(entry, "read"):
        raw_name = getattr(entry, "name", None)
        filename = os.path.basename(raw_name) if isinstance(raw_name, str) else "upload.bin"
        return filename, entry, _guess_content_type(filename)

    raise TypeError(f"Unsupported file entry: {type(entry).__name__!r}")


def _from_path(path: Path) -> Tuple[str, IO[bytes], str]:
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {path}")
    handle = path.open("rb")
    return path.name, handle, _guess_content_type(path.name)


def _from_tuple(entry: Tuple[object, ...]) -> Tuple[str, Union[bytes, IO[bytes]], str]:
    if len(entry) == 2:
        raw_filename, raw_payload = entry
        raw_content_type: object = _guess_content_type(str(raw_filename))
    elif len(entry) == 3:
        raw_filename, raw_payload, raw_content_type = entry[0], entry[1], entry[2]
    else:
        raise TypeError(
            "File tuple must be (filename, payload) or (filename, payload, content_type)"
        )
    if not isinstance(raw_filename, str):
        raise TypeError("File tuple filename must be str")
    if not isinstance(raw_content_type, str):
        raise TypeError("File tuple content_type must be str")
    payload: Union[bytes, IO[bytes]]
    if isinstance(raw_payload, (bytes, bytearray)):
        payload = bytes(raw_payload)
    elif hasattr(raw_payload, "read"):
        payload = cast(IO[bytes], raw_payload)
    else:
        raise TypeError("File tuple payload must be bytes or a readable object")
    return raw_filename, payload, raw_content_type


def _from_mapping(entry: Mapping[str, object]) -> Tuple[str, Union[bytes, IO[bytes]], str]:
    filename = entry.get("filename")
    content = entry.get("content")
    content_type = entry.get("content_type")

    if not isinstance(filename, str):
        raise TypeError("File mapping must have a string 'filename' key")
    if not isinstance(content_type, str):
        content_type = _guess_content_type(filename)

    if isinstance(content, (bytes, bytearray)):
        return filename, bytes(content), content_type
    if hasattr(content, "read"):
        return filename, content, content_type  # type: ignore[return-value]

    raise TypeError("File mapping 'content' must be bytes or a readable object")


def _guess_content_type(filename: str) -> str:
    content_type, _ = mimetypes.guess_type(filename)
    return content_type or "application/octet-stream"
