"""Synchronous client for the Spine API.

The entry point is :class:`SpineClient`. It owns an :class:`httpx.Client`
and exposes resource namespaces for each area of the API
(:attr:`runs <SpineClient.runs>`, :attr:`canvas <SpineClient.canvas>`).

Use it as a context manager so the underlying HTTP connection pool is
closed deterministically:

.. code-block:: python

    from spine import SpineClient

    with SpineClient(api_key="sk_spine_...") as client:
        handle = client.runs.create(prompt="Hello")
        result = handle.wait()
"""

from __future__ import annotations

import time
from types import TracebackType
from typing import Any, Mapping, Optional, Sequence, Tuple, Type

import httpx

from ._client import _BaseClient
from ._retries import RetryPolicy
from .exceptions import SpineConnectionError, SpineTimeoutError
from .resources import CanvasResource, RunsResource


class SpineClient(_BaseClient):
    """Synchronous client for the Spine API.

    Args:
        api_key: The API key issued for your Spine workspace. If omitted,
            reads ``SPINE_API_KEY`` from the environment.
        base_url: Override the API base URL (useful for staging or
            enterprise deployments). Defaults to the ``SPINE_BASE_URL``
            environment variable, or ``https://api.getspine.ai``.
        timeout: Per-request timeout. Accepts either a float (seconds) or
            a pre-built :class:`httpx.Timeout`.
        retry_policy: Override the default retry policy (3 retries, 0.5s
            base with exponential backoff).
        http_client: Inject a pre-configured :class:`httpx.Client`
            (advanced — for custom transports, proxies, or test doubles).
            The SDK still injects auth and user-agent headers on each
            request, so your custom client does not need to set them.

    Attributes:
        runs: Resource namespace for creating and polling runs.
        canvas: Resource namespace for introspecting canvases.
    """

    runs: RunsResource
    canvas: CanvasResource

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        retry_policy: Optional[RetryPolicy] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retry_policy=retry_policy,
        )
        self._http: httpx.Client = http_client or httpx.Client(
            base_url=self.base_url,
            timeout=self._timeout,
        )
        self._owns_http = http_client is None

        self.runs = RunsResource(self)
        self.canvas = CanvasResource(self)

    def close(self) -> None:
        """Release the underlying HTTP connection pool.

        Safe to call multiple times. Only closes the transport if the
        client was constructed without an injected ``http_client``.
        """
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> "SpineClient":
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Optional[Sequence[Tuple[str, Any]]] = None,
    ) -> httpx.Response:
        """Execute an HTTP request with auth, retries, and error wrapping.

        This is a low-level helper used by resource classes. User code
        should not normally need to call it directly.

        Args:
            method: HTTP method (``"GET"``, ``"POST"``, ...).
            path: Path relative to :attr:`base_url` (must start with
                ``"/"``).
            params: Query-string parameters.
            data: Form fields for multipart/urlencoded requests.
            files: Files for multipart uploads. Each entry is a
                ``(field_name, (filename, content, content_type))`` tuple.

        Returns:
            The raw :class:`httpx.Response`. Callers are responsible for
            passing it through :func:`spine._envelope.unwrap_envelope`.

        Raises:
            SpineConnectionError: If the transport cannot reach the
                server after the retry budget is exhausted.
            SpineTimeoutError: If the request exceeds its timeout.
        """
        attempt = 0
        last_response: Optional[httpx.Response] = None
        while True:
            try:
                response = self._http.request(
                    method,
                    path,
                    params=params,
                    data=data,
                    files=list(files) if files else None,
                    headers=self._default_headers,
                )
            except httpx.TimeoutException as exc:
                raise SpineTimeoutError(f"Request to {path} timed out") from exc
            except httpx.ConnectError as exc:
                if not self.retry_policy.should_retry(attempt=attempt, response=None):
                    raise SpineConnectionError(f"Failed to connect to {path}: {exc}") from exc
                time.sleep(self.retry_policy.compute_delay(attempt=attempt, response=None))
                attempt += 1
                continue
            except httpx.HTTPError as exc:
                raise SpineConnectionError(f"Transport error on {path}: {exc}") from exc

            last_response = response
            if not self.retry_policy.should_retry(attempt=attempt, response=response):
                return response

            time.sleep(self.retry_policy.compute_delay(attempt=attempt, response=response))
            attempt += 1
            _ = last_response  # loop continues


__all__ = ["SpineClient"]
