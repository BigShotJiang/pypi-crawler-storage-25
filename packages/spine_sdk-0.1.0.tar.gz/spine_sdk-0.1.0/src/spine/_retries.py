"""Transient-failure retry policy for HTTP requests.

Retries are attempted on:

* Connection failures (:class:`httpx.ConnectError`,
  :class:`httpx.ReadError`, :class:`httpx.WriteError`).
* HTTP 429 responses (respecting ``Retry-After``).
* HTTP 5xx responses (exponential backoff).

The retry budget and base delay are configurable per-client; see
:class:`spine.client.SpineClient`.
"""

from __future__ import annotations

import email.utils
import random
import time
from dataclasses import dataclass
from typing import Optional

import httpx


@dataclass(frozen=True)
class RetryPolicy:
    """Configuration for transient-failure retries.

    Attributes:
        max_retries: Maximum number of retry attempts after the initial
            request. ``0`` disables retries.
        base_delay: Base delay in seconds for exponential backoff.
        max_delay: Upper bound on the delay between retries, in seconds.
        jitter: Multiplicative jitter factor applied to every delay
            (``0.1`` means ±10%).
    """

    max_retries: int = 3
    base_delay: float = 0.5
    max_delay: float = 30.0
    jitter: float = 0.1

    def should_retry(self, *, attempt: int, response: Optional[httpx.Response]) -> bool:
        """Return ``True`` if another attempt should be made."""
        if attempt >= self.max_retries:
            return False
        if response is None:
            return True
        status = response.status_code
        return status == 429 or 500 <= status < 600

    def compute_delay(
        self,
        *,
        attempt: int,
        response: Optional[httpx.Response],
    ) -> float:
        """Compute the delay before the next retry attempt.

        Honours the server's ``Retry-After`` header on 429 responses. Falls
        back to exponential backoff with jitter otherwise.

        Args:
            attempt: Zero-indexed count of completed attempts.
            response: The response that triggered the retry, if any.

        Returns:
            The delay in seconds before retrying.
        """
        if response is not None:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            if retry_after is not None:
                return min(retry_after, self.max_delay)

        raw: float = self.base_delay * (2**attempt)
        jitter_factor: float = 1.0 + random.uniform(-self.jitter, self.jitter)
        delay: float = raw * jitter_factor
        return min(delay, self.max_delay)


def _parse_retry_after(value: Optional[str]) -> Optional[float]:
    """Parse an HTTP ``Retry-After`` header value.

    The header can be either a delta-seconds integer or an HTTP-date.
    Returns ``None`` if the value cannot be parsed.
    """
    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        pass
    try:
        parsed_date = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if parsed_date is None:
        return None
    delta: float = parsed_date.timestamp() - time.time()
    return max(0.0, delta)
