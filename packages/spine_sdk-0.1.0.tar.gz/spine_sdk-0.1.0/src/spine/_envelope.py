"""Response-envelope handling.

The Spine API wraps every response body in
``{"success": bool, "error": str | null, "data": ...}``. The SDK strips
this envelope before handing data to user code, and raises the right
exception on ``success: false``.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

import httpx

from .exceptions import SpineAPIError, map_http_error


def unwrap_envelope(response: httpx.Response) -> Any:
    """Return the ``data`` field of a successful Spine API response.

    Args:
        response: The :class:`httpx.Response` to unwrap.

    Returns:
        The value of the response body's ``data`` field (which may be
        ``None``, a dict, or a list depending on the endpoint).

    Raises:
        SpineAPIError: If the response status is non-2xx, or if the body
            declares ``success: false``. The specific subclass
            (:class:`AuthenticationError`, :class:`NotFoundError`, ...) is
            chosen based on the HTTP status code.
    """
    body = _safe_json(response)
    request_id = response.headers.get("X-Request-ID")

    if response.status_code >= 400:
        raise map_http_error(
            status_code=response.status_code,
            body=body,
            request_id=request_id,
        )

    if not isinstance(body, Mapping):
        raise SpineAPIError(
            "Malformed response: expected a JSON object",
            status_code=response.status_code,
            response_body=None,
            request_id=request_id,
        )

    if body.get("success") is False:
        raise map_http_error(
            status_code=response.status_code or 500,
            body=body,
            request_id=request_id,
        )

    return body.get("data")


def _safe_json(response: httpx.Response) -> Optional[Mapping[str, Any]]:
    """Parse the response body as JSON, returning ``None`` on failure."""
    try:
        parsed = response.json()
    except ValueError:
        return None
    if isinstance(parsed, Mapping):
        return parsed
    return None
