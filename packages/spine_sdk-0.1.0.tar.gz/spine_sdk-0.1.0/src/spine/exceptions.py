"""Exception hierarchy for the Spine Python SDK.

Every failure raised by the SDK is a subclass of :class:`SpineError`, so
callers can use a single ``except SpineError`` clause as a catch-all. Users
who want to branch on specific failure modes can catch the leaf classes
(:class:`AuthenticationError`, :class:`NotFoundError`, etc.) instead.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional


class SpineError(Exception):
    """Base class for every exception raised by ``spine``.

    Catch this if you just want to handle "any SDK failure" without caring
    about the specific cause.
    """


class SpineConnectionError(SpineError):
    """Raised when the HTTP transport cannot reach the server.

    Typical causes: DNS failure, connection refused, TLS errors, or network
    outage. This exception is raised after the SDK has exhausted its retry
    budget.
    """


class SpineTimeoutError(SpineError):
    """Raised when an operation exceeds its timeout budget.

    Raised by both the HTTP layer (request timeout) and by
    :meth:`spine.polling.RunHandle.wait` (polling timeout).
    """


class SpineAPIError(SpineError):
    """Raised when the API returns an error response (4xx or 5xx).

    Attributes:
        status_code: The HTTP status code returned by the server.
        error_message: The ``error`` field from the JSON envelope, if the
            server returned a structured error body.
        request_id: Value of the ``X-Request-ID`` response header, useful
            when reporting issues to support.
        response_body: Raw JSON body returned by the server. ``None`` if
            the body could not be parsed as JSON.
    """

    status_code: int
    error_message: Optional[str]
    request_id: Optional[str]
    response_body: Optional[Mapping[str, Any]]

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_message: Optional[str] = None,
        request_id: Optional[str] = None,
        response_body: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_message = error_message
        self.request_id = request_id
        self.response_body = response_body


class BadRequestError(SpineAPIError):
    """Raised for HTTP 400 responses.

    The request was malformed or semantically invalid (e.g. unknown
    template, invalid block types, bad UUID).
    """


class AuthenticationError(SpineAPIError):
    """Raised for HTTP 401 responses.

    The ``X-API-KEY`` header was missing, malformed, or revoked.
    """


class NotFoundError(SpineAPIError):
    """Raised for HTTP 404 responses.

    The requested run, canvas, or task does not exist — or belongs to
    another tenant.
    """


class RateLimitError(SpineAPIError):
    """Raised for HTTP 429 responses that exceed the retry budget.

    Transient 429s are retried automatically with backoff; this exception
    only surfaces once the retry budget is exhausted.
    """


class ServerError(SpineAPIError):
    """Raised for HTTP 5xx responses that exceed the retry budget.

    Transient 5xxs are retried automatically; this exception surfaces only
    after the final retry fails.
    """


_STATUS_TO_EXCEPTION: dict[int, type[SpineAPIError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    404: NotFoundError,
    429: RateLimitError,
}


def map_http_error(
    *,
    status_code: int,
    body: Optional[Mapping[str, Any]],
    request_id: Optional[str],
) -> SpineAPIError:
    """Construct the right :class:`SpineAPIError` subclass for an HTTP failure.

    Args:
        status_code: HTTP status code of the response.
        body: Parsed JSON body, or ``None`` if parsing failed.
        request_id: Value of the ``X-Request-ID`` response header.

    Returns:
        A freshly constructed (not yet raised) :class:`SpineAPIError`
        subclass appropriate for ``status_code``.
    """
    error_message: Optional[str] = None
    if isinstance(body, Mapping):
        raw_error = body.get("error")
        if isinstance(raw_error, str):
            error_message = raw_error

    exc_cls: type[SpineAPIError]
    if status_code in _STATUS_TO_EXCEPTION:
        exc_cls = _STATUS_TO_EXCEPTION[status_code]
    elif 500 <= status_code < 600:
        exc_cls = ServerError
    else:
        exc_cls = SpineAPIError

    display = error_message or f"HTTP {status_code}"
    return exc_cls(
        display,
        status_code=status_code,
        error_message=error_message,
        request_id=request_id,
        response_body=body,
    )


__all__ = [
    "AuthenticationError",
    "BadRequestError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "SpineAPIError",
    "SpineConnectionError",
    "SpineError",
    "SpineTimeoutError",
    "map_http_error",
]
