"""Single source of truth for the spine-sdk version.

Hatch reads this file during build (see ``pyproject.toml``
``[tool.hatch.version]``), and ``spine.__init__`` re-exports it as
``spine.__version__``.
"""

__version__ = "0.1.0"
