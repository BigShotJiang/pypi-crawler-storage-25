"""Enumerations used by the Spine API.

These mirror the valid-value sets the server accepts. Keeping them as
``str``-valued enums means users can pass either the enum member
(``Template.REPORT``) or the raw string (``"report"``) and serialisation
works transparently.
"""

from __future__ import annotations

from enum import Enum


class Template(str, Enum):
    """Canvas generation template.

    Controls which block types the orchestrator is allowed to create
    while fulfilling a run. ``AUTO`` lets Spine choose from all supported
    block types; the others constrain it to a specific artifact shape.
    """

    AUTO = "auto"
    DEEP_RESEARCH = "deep_research"
    REPORT = "report"
    SLIDES = "slides"
    MEMO = "memo"
    EXCEL = "excel"
    APP = "app"
    LANDING_PAGE = "landing_page"


class BlockType(str, Enum):
    """Canvas block types that can be requested in ``runs.create(blocks=...)``.

    If ``blocks`` is provided, Spine will only create blocks of these types
    (and will reject the request if the resulting output cannot be produced
    from them).
    """

    PROMPT = "prompt-block"
    LIST = "list-block"
    MEMO = "memo-block"
    DOCUMENT = "document-block"
    EXCEL = "excel-block"
    DEEP_RESEARCH = "deep-research-block"
    IMAGE = "image-block"
    PRESENTATION = "presentation-block"
    APP = "app-block"
    TABLE = "table-block"
    PROTOTYPE = "prototype-block"
    LANDING_PAGE = "landing-page-block"
    TEXT = "text-block"
    WEB = "web-block"
    YOUTUBE = "yt-block"
    WEB_RESEARCH = "web-research-block"
    FILE = "file-block"


class RunStatus(str, Enum):
    """Lifecycle state of a run.

    A run is created in ``RUNNING`` and transitions to exactly one terminal
    state: ``COMPLETED`` (all blocks succeeded), ``PARTIAL`` (some blocks
    failed but a usable result exists), or ``FAILED`` (no usable result).
    """

    RUNNING = "running"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"

    @property
    def is_terminal(self) -> bool:
        """Return ``True`` if this status will not change further."""
        return self is not RunStatus.RUNNING


TERMINAL_STATUSES = frozenset({RunStatus.COMPLETED, RunStatus.PARTIAL, RunStatus.FAILED})
"""Convenience set of statuses at which polling should stop."""
