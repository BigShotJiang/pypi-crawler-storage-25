"""``canvas`` resource — introspect canvas block graphs and task trees."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._envelope import unwrap_envelope
from ..models import CanvasDAG, TaskNode, TaskTree

if TYPE_CHECKING:
    from ..async_client import AsyncSpineClient
    from ..client import SpineClient


class CanvasResource:
    """Synchronous ``client.canvas`` namespace."""

    def __init__(self, client: "SpineClient") -> None:
        self._client = client

    def get_dag(self, canvas_id: str) -> CanvasDAG:
        """Fetch the block dependency graph for a canvas.

        Args:
            canvas_id: UUID of the canvas.

        Returns:
            A :class:`CanvasDAG` containing all blocks and dependency
            edges.

        Raises:
            NotFoundError: If the canvas does not exist in the caller's
                tenant.
        """
        response = self._client._request("GET", f"/canvas/{canvas_id}/dag")
        payload = unwrap_envelope(response)
        return CanvasDAG.model_validate(payload)

    def get_tasks(self, canvas_id: str) -> TaskTree:
        """Fetch the full task tree for a canvas.

        Args:
            canvas_id: UUID of the canvas.

        Returns:
            A :class:`TaskTree` split into completed and not-yet-completed
            subtrees.
        """
        response = self._client._request("GET", f"/canvas/{canvas_id}/tasks")
        payload = unwrap_envelope(response)
        return TaskTree.model_validate(payload)

    def get_task(self, canvas_id: str, task_id: str) -> TaskNode:
        """Fetch a single task (with its immediate children).

        Args:
            canvas_id: UUID of the canvas.
            task_id: UUID of the task within that canvas.

        Returns:
            A :class:`TaskNode` with its direct children populated.
        """
        response = self._client._request(
            "GET",
            f"/canvas/{canvas_id}/tasks/{task_id}",
        )
        payload = unwrap_envelope(response)
        return TaskNode.model_validate(payload)


class AsyncCanvasResource:
    """Asynchronous ``client.canvas`` namespace."""

    def __init__(self, client: "AsyncSpineClient") -> None:
        self._client = client

    async def get_dag(self, canvas_id: str) -> CanvasDAG:
        """Async twin of :meth:`CanvasResource.get_dag`."""
        response = await self._client._request("GET", f"/canvas/{canvas_id}/dag")
        payload = unwrap_envelope(response)
        return CanvasDAG.model_validate(payload)

    async def get_tasks(self, canvas_id: str) -> TaskTree:
        """Async twin of :meth:`CanvasResource.get_tasks`."""
        response = await self._client._request("GET", f"/canvas/{canvas_id}/tasks")
        payload = unwrap_envelope(response)
        return TaskTree.model_validate(payload)

    async def get_task(self, canvas_id: str, task_id: str) -> TaskNode:
        """Async twin of :meth:`CanvasResource.get_task`."""
        response = await self._client._request(
            "GET",
            f"/canvas/{canvas_id}/tasks/{task_id}",
        )
        payload = unwrap_envelope(response)
        return TaskNode.model_validate(payload)
