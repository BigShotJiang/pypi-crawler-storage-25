"""``runs`` resource — create and poll Spine runs.

A run is an asynchronous canvas-generation task. It is created by
:meth:`RunsResource.create` (or :meth:`AsyncRunsResource.create`) and
progresses through a sequence of statuses until it reaches a terminal
state (see :class:`spine.enums.RunStatus`).

The :class:`~spine.polling.RunHandle` object returned by ``create`` holds
a reference back to the client so callers can use
:meth:`~spine.polling.RunHandle.wait` or
:meth:`~spine.polling.RunHandle.stream_progress` without manually
re-passing the client.
"""

from __future__ import annotations

import contextlib
import json
from typing import TYPE_CHECKING, Any, Iterable, Optional, Union

from .._envelope import unwrap_envelope
from .._files import FileLike, build_multipart_files
from ..enums import BlockType, Template
from ..models import CreateRunResponse, GetRunResponse
from ..polling import AsyncRunHandle, RunHandle

if TYPE_CHECKING:
    from ..async_client import AsyncSpineClient
    from ..client import SpineClient


BlockSpec = Union[BlockType, str]
TemplateSpec = Union[Template, str]


class RunsResource:
    """Synchronous ``client.runs`` namespace."""

    def __init__(self, client: "SpineClient") -> None:
        self._client = client

    def create(
        self,
        prompt: str,
        *,
        template: TemplateSpec = Template.AUTO,
        blocks: Optional[Iterable[BlockSpec]] = None,
        agent_instructions: Optional[str] = None,
        webhook_url: Optional[str] = None,
        files: Optional[Iterable[FileLike]] = None,
    ) -> RunHandle:
        """Create a new canvas run and return a polling handle.

        The run executes asynchronously on the server. This call returns
        as soon as the run has been accepted; use the returned
        :class:`~spine.polling.RunHandle` to wait for it to finish.

        Args:
            prompt: The user-facing prompt that describes what the run
                should produce. Required and non-empty.
            template: Which canvas template Spine should use. Defaults
                to :attr:`Template.AUTO`, which lets Spine choose.
            blocks: Optional allow-list of block types. If set, Spine
                will only create blocks of these types. Accepts
                :class:`BlockType` members or raw strings.
            agent_instructions: Additional instructions injected into the
                agent's system prompt.
            webhook_url: URL the backend will POST to when the run
                reaches a terminal state. Not yet implemented
                server-side; accepted for forward compatibility.
            files: Files to upload with the run. Accepts paths, file
                objects, ``(filename, bytes)`` tuples, etc. — see
                :data:`spine._files.FileLike`.

        Returns:
            A :class:`~spine.polling.RunHandle` wrapping the newly
            created run.

        Raises:
            BadRequestError: If ``prompt`` is empty, ``template`` is
                unknown, or ``blocks`` contains invalid values.
            AuthenticationError: If the API key is missing or revoked.
        """
        form = _build_form(
            prompt=prompt,
            template=template,
            blocks=blocks,
            agent_instructions=agent_instructions,
            webhook_url=webhook_url,
        )
        multipart_files = build_multipart_files(files)
        try:
            response = self._client._request(
                "POST",
                "/run",
                data=form,
                files=multipart_files,
            )
            payload = unwrap_envelope(response)
        finally:
            _close_files(multipart_files)

        parsed = CreateRunResponse.model_validate(payload)
        return RunHandle(
            client=self._client,
            run_id=parsed.run_id,
            canvas_id=parsed.canvas_id,
            create_response=parsed,
        )

    def get(self, run_id: str) -> GetRunResponse:
        """Fetch the current state of a run.

        Args:
            run_id: UUID of the run to fetch.

        Returns:
            A :class:`GetRunResponse` with status-dependent fields
            populated (progress while running, result once terminal).

        Raises:
            NotFoundError: If no run with that ID exists in the caller's
                tenant.
        """
        response = self._client._request("GET", f"/run/{run_id}")
        payload = unwrap_envelope(response)
        return GetRunResponse.model_validate(payload)


class AsyncRunsResource:
    """Asynchronous ``client.runs`` namespace."""

    def __init__(self, client: "AsyncSpineClient") -> None:
        self._client = client

    async def create(
        self,
        prompt: str,
        *,
        template: TemplateSpec = Template.AUTO,
        blocks: Optional[Iterable[BlockSpec]] = None,
        agent_instructions: Optional[str] = None,
        webhook_url: Optional[str] = None,
        files: Optional[Iterable[FileLike]] = None,
    ) -> AsyncRunHandle:
        """Async twin of :meth:`RunsResource.create`.

        See :meth:`RunsResource.create` for full argument documentation.
        """
        form = _build_form(
            prompt=prompt,
            template=template,
            blocks=blocks,
            agent_instructions=agent_instructions,
            webhook_url=webhook_url,
        )
        multipart_files = build_multipart_files(files)
        try:
            response = await self._client._request(
                "POST",
                "/run",
                data=form,
                files=multipart_files,
            )
            payload = unwrap_envelope(response)
        finally:
            _close_files(multipart_files)

        parsed = CreateRunResponse.model_validate(payload)
        return AsyncRunHandle(
            client=self._client,
            run_id=parsed.run_id,
            canvas_id=parsed.canvas_id,
            create_response=parsed,
        )

    async def get(self, run_id: str) -> GetRunResponse:
        """Async twin of :meth:`RunsResource.get`."""
        response = await self._client._request("GET", f"/run/{run_id}")
        payload = unwrap_envelope(response)
        return GetRunResponse.model_validate(payload)


def _build_form(
    *,
    prompt: str,
    template: TemplateSpec,
    blocks: Optional[Iterable[BlockSpec]],
    agent_instructions: Optional[str],
    webhook_url: Optional[str],
) -> dict[str, str]:
    """Assemble the multipart form fields for ``POST /run``."""
    form: dict[str, str] = {
        "prompt": prompt,
        "template": _template_value(template),
    }
    if blocks is not None:
        form["blocks"] = json.dumps([_block_value(b) for b in blocks])
    if agent_instructions is not None:
        form["agent_instructions"] = agent_instructions
    if webhook_url is not None:
        form["webhook_url"] = webhook_url
    return form


def _template_value(template: TemplateSpec) -> str:
    if isinstance(template, Template):
        return template.value
    return str(template)


def _block_value(block: BlockSpec) -> str:
    if isinstance(block, BlockType):
        return block.value
    return str(block)


def _close_files(multipart_files: Any) -> None:
    """Close any file handles opened by :func:`build_multipart_files`.

    Bytes payloads are left alone; only real file objects are closed so
    we don't leak file descriptors when reading from disk paths.
    """
    for entry in multipart_files:
        _, payload_tuple = entry
        _, payload, _ = payload_tuple
        close = getattr(payload, "close", None)
        if callable(close):
            with contextlib.suppress(Exception):
                close()
