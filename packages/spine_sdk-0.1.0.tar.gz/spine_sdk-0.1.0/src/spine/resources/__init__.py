"""Resource namespaces exposed as attributes on the client.

Each module here defines a pair of classes — one sync, one async — that
group related endpoints under a single attribute (``client.runs``,
``client.canvas``).
"""

from .canvas import AsyncCanvasResource, CanvasResource
from .runs import AsyncRunsResource, RunsResource

__all__ = [
    "AsyncCanvasResource",
    "AsyncRunsResource",
    "CanvasResource",
    "RunsResource",
]
