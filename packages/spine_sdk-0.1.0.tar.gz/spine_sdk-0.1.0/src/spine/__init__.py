"""Official Python SDK for the Spine API.

Typical usage:

.. code-block:: python

    from spine import SpineClient

    with SpineClient(api_key="sk_spine_...") as client:
        handle = client.runs.create(prompt="Summarise Q4 AI chip market")
        result = handle.wait()
        print(result.final_output)

See :class:`SpineClient` and :class:`AsyncSpineClient` for the full API.
"""

from __future__ import annotations

from ._retries import RetryPolicy
from ._version import __version__
from .async_client import AsyncSpineClient
from .client import SpineClient
from .enums import BlockType, RunStatus, Template
from .exceptions import (
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SpineAPIError,
    SpineConnectionError,
    SpineError,
    SpineTimeoutError,
)
from .models import (
    CanvasDAG,
    CanvasEdge,
    CanvasNode,
    CreateRunResponse,
    GetRunResponse,
    RunArtifact,
    RunError,
    RunMetadata,
    RunProgress,
    RunResult,
    TaskNode,
    TaskTree,
)
from .polling import AsyncRunHandle, RunHandle

__all__ = [
    "AsyncRunHandle",
    "AsyncSpineClient",
    "AuthenticationError",
    "BadRequestError",
    "BlockType",
    "CanvasDAG",
    "CanvasEdge",
    "CanvasNode",
    "CreateRunResponse",
    "GetRunResponse",
    "NotFoundError",
    "RateLimitError",
    "RetryPolicy",
    "RunArtifact",
    "RunError",
    "RunHandle",
    "RunMetadata",
    "RunProgress",
    "RunResult",
    "RunStatus",
    "ServerError",
    "SpineAPIError",
    "SpineClient",
    "SpineConnectionError",
    "SpineError",
    "SpineTimeoutError",
    "TaskNode",
    "TaskTree",
    "Template",
    "__version__",
]
