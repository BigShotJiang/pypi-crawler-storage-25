"""End-to-end tests for the sync :class:`SpineClient` against a respx mock."""

from __future__ import annotations

import httpx
import pytest
import respx

from spine import (
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RunStatus,
    SpineClient,
    Template,
)
from tests.conftest import API_KEY, BASE_URL, envelope, error_envelope


def test_create_run_posts_form_and_returns_handle(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    route = mocked_router.post("/run").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-1",
                    "status": "running",
                    "canvas_id": "canvas-1",
                    "poll_url": "/v1/run/run-1",
                    "estimated_duration_ms": 30000,
                }
            ),
        )
    )

    handle = sync_client.runs.create(
        prompt="Hello",
        template=Template.REPORT,
        agent_instructions="be brief",
    )

    assert route.called
    request = route.calls.last.request
    assert request.headers["X-API-KEY"] == API_KEY
    assert request.headers["User-Agent"].startswith("spine-sdk-python/")
    body = request.content
    assert b"prompt=Hello" in body
    assert b"template=report" in body
    assert b"agent_instructions=be+brief" in body

    assert handle.run_id == "run-1"
    assert handle.canvas_id == "canvas-1"


def test_create_run_serialises_blocks_as_json(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-2",
                    "status": "running",
                    "canvas_id": None,
                    "poll_url": "/v1/run/run-2",
                    "estimated_duration_ms": 0,
                }
            ),
        )
    )

    sync_client.runs.create(
        prompt="x",
        blocks=["document-block", "memo-block"],
    )

    body = mocked_router.calls.last.request.content
    # blocks is a JSON string embedded in the urlencoded form; commas and
    # quotes get percent-encoded.
    assert b"blocks=" in body
    assert b"document-block" in body
    assert b"memo-block" in body


def test_get_run_returns_typed_response(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.get("/run/run-5").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-5",
                    "status": "completed",
                    "canvas_id": "c-5",
                    "duration_ms": 12000,
                    "result": {
                        "final_output": "done",
                        "artifacts": [
                            {
                                "id": "node-1",
                                "type": "docx",
                                "name": "Report.docx",
                                "download_url": "https://example.com/r.docx",
                                "size_bytes": 10240,
                            }
                        ],
                    },
                    "metadata": {
                        "template_used": "report",
                        "models_used": ["anthropic/claude-sonnet-4-6"],
                        "credits_consumed": 42,
                    },
                }
            ),
        )
    )

    run = sync_client.runs.get("run-5")
    assert run.status == RunStatus.COMPLETED
    assert run.result is not None
    assert run.result.final_output == "done"
    assert run.result.artifacts[0].name == "Report.docx"
    assert run.metadata is not None
    assert run.metadata.credits_consumed == 42


def test_get_run_raises_not_found(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.get("/run/missing").mock(
        return_value=httpx.Response(404, json=error_envelope("Run not found"))
    )

    with pytest.raises(NotFoundError) as info:
        sync_client.runs.get("missing")
    assert info.value.status_code == 404


def test_create_run_raises_bad_request(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(
        return_value=httpx.Response(400, json=error_envelope("Invalid template"))
    )

    with pytest.raises(BadRequestError):
        sync_client.runs.create(prompt="x", template="bogus")


def test_missing_api_key_raises() -> None:
    with pytest.raises(ValueError, match="Missing API key"):
        SpineClient(api_key=None, base_url=BASE_URL)


def test_auth_failure_surfaces(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.get("/run/any").mock(
        return_value=httpx.Response(401, json=error_envelope("bad key"))
    )
    with pytest.raises(AuthenticationError):
        sync_client.runs.get("any")


def test_canvas_get_dag(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.get("/canvas/c-1/dag").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "canvas_id": "c-1",
                    "canvas_name": "Test",
                    "nodes": [
                        {
                            "id": "n-1",
                            "name": "Block 1",
                            "type": "document-block",
                            "status": "completed",
                            "content": "text",
                            "url": None,
                            "sources": [],
                        }
                    ],
                    "edges": [{"source_id": "n-1", "target_id": "n-2"}],
                }
            ),
        )
    )

    dag = sync_client.canvas.get_dag("c-1")
    assert dag.canvas_id == "c-1"
    assert dag.nodes[0].name == "Block 1"
    assert dag.edges[0].source_id == "n-1"


def test_canvas_get_tasks(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.get("/canvas/c-1/tasks").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "canvas_id": "c-1",
                    "completed": [
                        {
                            "task_id": "t-1",
                            "name": "Outline",
                            "task_type": "parent-task",
                            "status": "completed",
                            "children": [],
                        }
                    ],
                    "not_completed": [],
                }
            ),
        )
    )

    tree = sync_client.canvas.get_tasks("c-1")
    assert len(tree.completed) == 1
    assert tree.completed[0].task_id == "t-1"


def test_canvas_get_single_task(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.get("/canvas/c-1/tasks/t-1").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "task_id": "t-1",
                    "name": "Outline",
                    "task_type": "parent-task",
                    "status": "completed",
                    "children": None,
                }
            ),
        )
    )

    task = sync_client.canvas.get_task("c-1", "t-1")
    assert task.name == "Outline"


def test_client_is_context_manager() -> None:
    with SpineClient(api_key=API_KEY, base_url=BASE_URL) as client:
        assert isinstance(client, SpineClient)


def test_create_run_with_file_uses_multipart(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-m",
                    "status": "running",
                    "canvas_id": None,
                    "poll_url": "/v1/run/run-m",
                    "estimated_duration_ms": 0,
                }
            ),
        )
    )

    sync_client.runs.create(
        prompt="hello",
        files=[("notes.txt", b"hi there")],
    )

    request = mocked_router.calls.last.request
    assert request.headers["content-type"].startswith("multipart/form-data")
    assert b'name="prompt"' in request.content
    assert b'filename="notes.txt"' in request.content
    assert b"hi there" in request.content
