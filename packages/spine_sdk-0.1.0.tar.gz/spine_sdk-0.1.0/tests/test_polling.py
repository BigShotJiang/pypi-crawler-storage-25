"""Unit tests for :class:`spine.polling.RunHandle` and its async twin."""

from __future__ import annotations

import httpx
import pytest
import respx

from spine import AsyncSpineClient, SpineAPIError, SpineClient, SpineTimeoutError
from tests.conftest import envelope


def _create_payload(run_id: str = "run-poll") -> dict[str, object]:
    return envelope(
        {
            "run_id": run_id,
            "status": "running",
            "canvas_id": "c-1",
            "poll_url": f"/v1/run/{run_id}",
            "estimated_duration_ms": 5000,
        }
    )


def _running_snapshot(run_id: str, progress: tuple[int, int]) -> dict[str, object]:
    done, total = progress
    return envelope(
        {
            "run_id": run_id,
            "status": "running",
            "canvas_id": "c-1",
            "progress": {
                "tasks_completed": done,
                "tasks_total": total,
                "elapsed_ms": 1000,
            },
        }
    )


def _completed_snapshot(run_id: str) -> dict[str, object]:
    return envelope(
        {
            "run_id": run_id,
            "status": "completed",
            "canvas_id": "c-1",
            "duration_ms": 2000,
            "result": {"final_output": "done", "artifacts": []},
            "metadata": {
                "template_used": "memo",
                "models_used": [],
                "credits_consumed": 1,
            },
        }
    )


def test_wait_polls_until_completed(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(return_value=httpx.Response(200, json=_create_payload()))
    mocked_router.get("/run/run-poll").mock(
        side_effect=[
            httpx.Response(200, json=_running_snapshot("run-poll", (0, 3))),
            httpx.Response(200, json=_running_snapshot("run-poll", (2, 3))),
            httpx.Response(200, json=_completed_snapshot("run-poll")),
        ]
    )

    handle = sync_client.runs.create(prompt="x")
    result = handle.wait(timeout=5, poll_interval=0.01, max_poll_interval=0.01)

    assert result.final_output == "done"


def test_wait_raises_on_timeout(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.post("/run").mock(return_value=httpx.Response(200, json=_create_payload()))
    mocked_router.get("/run/run-poll").mock(
        return_value=httpx.Response(200, json=_running_snapshot("run-poll", (0, 1)))
    )

    handle = sync_client.runs.create(prompt="x")
    with pytest.raises(SpineTimeoutError):
        handle.wait(timeout=0.05, poll_interval=0.01, max_poll_interval=0.01)


def test_wait_raises_on_failed(sync_client: SpineClient, mocked_router: respx.MockRouter) -> None:
    mocked_router.post("/run").mock(return_value=httpx.Response(200, json=_create_payload()))
    mocked_router.get("/run/run-poll").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-poll",
                    "status": "failed",
                    "canvas_id": "c-1",
                    "errors": [{"error": "something broke"}],
                }
            ),
        )
    )

    handle = sync_client.runs.create(prompt="x")
    with pytest.raises(SpineAPIError) as info:
        handle.wait(timeout=5, poll_interval=0.01)
    assert "something broke" in str(info.value)


def test_stream_progress_yields_snapshots(
    sync_client: SpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(return_value=httpx.Response(200, json=_create_payload()))
    mocked_router.get("/run/run-poll").mock(
        side_effect=[
            httpx.Response(200, json=_running_snapshot("run-poll", (0, 3))),
            httpx.Response(200, json=_running_snapshot("run-poll", (2, 3))),
            httpx.Response(200, json=_completed_snapshot("run-poll")),
        ]
    )

    handle = sync_client.runs.create(prompt="x")
    snapshots = list(handle.stream_progress(poll_interval=0.01))

    assert [s.tasks_completed for s in snapshots] == [0, 2]


async def test_async_wait_polls_until_completed(
    async_client: AsyncSpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.post("/run").mock(return_value=httpx.Response(200, json=_create_payload()))
    mocked_router.get("/run/run-poll").mock(
        side_effect=[
            httpx.Response(200, json=_running_snapshot("run-poll", (0, 2))),
            httpx.Response(200, json=_completed_snapshot("run-poll")),
        ]
    )

    handle = await async_client.runs.create(prompt="x")
    result = await handle.wait(timeout=5, poll_interval=0.01, max_poll_interval=0.01)
    assert result.final_output == "done"
