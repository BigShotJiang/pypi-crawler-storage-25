"""Integration smoke tests against a real Spine deployment.

These are gated on the ``SPINE_API_KEY`` environment variable. When not
set, every test in this module is skipped — so the default ``pytest``
invocation never hits the network.

Run manually with::

    SPINE_API_KEY=sk_spine_... \\
        SPINE_BASE_URL=https://staging.getspine.ai \\
        pytest -m integration tests/integration/
"""

from __future__ import annotations

import os

import pytest

from spine import SpineClient, Template

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not os.environ.get("SPINE_API_KEY"),
        reason="SPINE_API_KEY not set; integration tests are opt-in.",
    ),
]


def test_can_round_trip_a_memo_run() -> None:
    """Create a minimal memo run, wait for it, and assert the shape of the result."""
    with SpineClient() as client:
        handle = client.runs.create(
            prompt="Write a two-sentence memo on cloud spend optimisation.",
            template=Template.MEMO,
        )
        assert handle.run_id

        result = handle.wait(timeout=600, poll_interval=5)
        assert result.final_output
