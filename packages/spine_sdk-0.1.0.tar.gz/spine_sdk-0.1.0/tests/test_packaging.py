"""Wheel-contents verification.

Builds the distribution artefacts and asserts the wheel contains only the
Python source in ``src/spine`` — no tests, docs, examples, or CLAUDE.md
files leak into the published package.

This test shells out to ``python -m build`` so it requires the ``build``
package (installed via the ``dev`` extras).
"""

from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def wheel_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Build a wheel into a throwaway directory and return its path."""
    out_dir = tmp_path_factory.mktemp("dist")
    subprocess.run(
        [sys.executable, "-m", "build", "--wheel", "--outdir", str(out_dir)],
        check=True,
        cwd=PROJECT_ROOT,
    )
    wheels = list(out_dir.glob("spine_sdk-*.whl"))
    assert len(wheels) == 1, f"expected exactly one wheel, got {wheels}"
    return wheels[0]


def test_wheel_contains_only_expected_files(wheel_path: Path) -> None:
    with zipfile.ZipFile(wheel_path) as archive:
        names = archive.namelist()

    forbidden_fragments = (
        "tests/",
        "docs/",
        "examples/",
        ".github/",
        "CLAUDE.md",
        ".pre-commit-config.yaml",
        ".python-version",
        "MANIFEST.in",
    )
    for name in names:
        for fragment in forbidden_fragments:
            assert fragment not in name, f"Wheel leaks {fragment!r} via {name!r}"


def test_wheel_contains_py_typed(wheel_path: Path) -> None:
    with zipfile.ZipFile(wheel_path) as archive:
        names = archive.namelist()
    assert any(name.endswith("spine/py.typed") for name in names), (
        "Wheel must ship the py.typed marker so downstream type checkers pick up our hints."
    )


def test_wheel_ships_core_modules(wheel_path: Path) -> None:
    with zipfile.ZipFile(wheel_path) as archive:
        names = archive.namelist()
    required = {
        "spine/__init__.py",
        "spine/client.py",
        "spine/async_client.py",
        "spine/models.py",
        "spine/polling.py",
        "spine/exceptions.py",
    }
    present = {n for n in names if n.startswith("spine/")}
    missing = required - present
    assert not missing, f"Wheel is missing required modules: {sorted(missing)}"
