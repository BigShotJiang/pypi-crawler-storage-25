"""Unit tests for :mod:`spine._envelope`."""

from __future__ import annotations

import httpx
import pytest

from spine._envelope import unwrap_envelope
from spine.exceptions import (
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SpineAPIError,
)


def _response(status: int, body: object, headers: dict[str, str] | None = None) -> httpx.Response:
    return httpx.Response(status, json=body, headers=headers or {})


def test_unwrap_returns_data_on_success() -> None:
    resp = _response(200, {"success": True, "error": None, "data": {"hello": "world"}})
    assert unwrap_envelope(resp) == {"hello": "world"}


def test_unwrap_returns_none_when_data_is_null() -> None:
    resp = _response(200, {"success": True, "error": None, "data": None})
    assert unwrap_envelope(resp) is None


def test_unwrap_raises_on_success_false() -> None:
    resp = _response(200, {"success": False, "error": "nope", "data": None})
    with pytest.raises(SpineAPIError) as info:
        unwrap_envelope(resp)
    assert info.value.error_message == "nope"


def test_unwrap_raises_bad_request_on_400() -> None:
    resp = _response(400, {"success": False, "error": "invalid template", "data": None})
    with pytest.raises(BadRequestError) as info:
        unwrap_envelope(resp)
    assert info.value.status_code == 400
    assert info.value.error_message == "invalid template"


def test_unwrap_raises_auth_on_401() -> None:
    resp = _response(401, {"success": False, "error": "bad key", "data": None})
    with pytest.raises(AuthenticationError):
        unwrap_envelope(resp)


def test_unwrap_raises_not_found_on_404() -> None:
    resp = _response(404, {"success": False, "error": "run not found", "data": None})
    with pytest.raises(NotFoundError):
        unwrap_envelope(resp)


def test_unwrap_raises_rate_limit_on_429() -> None:
    resp = _response(429, {"success": False, "error": "slow down", "data": None})
    with pytest.raises(RateLimitError):
        unwrap_envelope(resp)


def test_unwrap_raises_server_error_on_500() -> None:
    resp = _response(503, {"success": False, "error": "down", "data": None})
    with pytest.raises(ServerError):
        unwrap_envelope(resp)


def test_unwrap_propagates_request_id() -> None:
    resp = _response(
        500,
        {"success": False, "error": "boom", "data": None},
        headers={"X-Request-ID": "req-123"},
    )
    with pytest.raises(ServerError) as info:
        unwrap_envelope(resp)
    assert info.value.request_id == "req-123"


def test_unwrap_raises_on_malformed_body() -> None:
    resp = httpx.Response(200, content=b"not json")
    with pytest.raises(SpineAPIError):
        unwrap_envelope(resp)
