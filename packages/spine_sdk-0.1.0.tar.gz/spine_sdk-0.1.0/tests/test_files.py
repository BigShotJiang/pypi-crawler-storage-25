"""Unit tests for :mod:`spine._files`."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from spine._files import build_multipart_files


def test_build_returns_empty_when_none() -> None:
    assert build_multipart_files(None) == []


def test_build_returns_empty_when_empty_iterable() -> None:
    assert build_multipart_files([]) == []


def test_build_from_path(tmp_path: Path) -> None:
    file_path = tmp_path / "data.txt"
    file_path.write_text("hello")

    result = build_multipart_files([file_path])

    assert len(result) == 1
    field, (filename, handle, content_type) = result[0]
    assert field == "files"
    assert filename == "data.txt"
    assert content_type == "text/plain"
    assert hasattr(handle, "read")


def test_build_from_string_path(tmp_path: Path) -> None:
    file_path = tmp_path / "data.bin"
    file_path.write_bytes(b"\x00\x01")

    result = build_multipart_files([str(file_path)])

    _, (filename, _, content_type) = result[0]
    assert filename == "data.bin"
    assert content_type == "application/octet-stream"


def test_build_from_file_object_with_name() -> None:
    buf = io.BytesIO(b"hi")
    buf.name = "/tmp/buf.pdf"  # type: ignore[attr-defined]

    result = build_multipart_files([buf])

    _, (filename, payload, content_type) = result[0]
    assert filename == "buf.pdf"
    assert content_type == "application/pdf"
    assert payload is buf


def test_build_from_file_object_without_name() -> None:
    buf = io.BytesIO(b"hi")

    result = build_multipart_files([buf])

    _, (filename, _, content_type) = result[0]
    assert filename == "upload.bin"
    assert content_type == "application/octet-stream"


def test_build_from_tuple_two_element() -> None:
    result = build_multipart_files([("report.docx", b"payload")])

    _, (filename, payload, content_type) = result[0]
    assert filename == "report.docx"
    assert payload == b"payload"
    # docx content type
    assert "officedocument" in content_type


def test_build_from_tuple_three_element() -> None:
    result = build_multipart_files([("x.dat", b"hi", "application/x-custom")])

    _, (filename, payload, content_type) = result[0]
    assert filename == "x.dat"
    assert payload == b"hi"
    assert content_type == "application/x-custom"


def test_build_from_mapping() -> None:
    entry = {"filename": "notes.md", "content": b"# hi"}
    result = build_multipart_files([entry])

    _, (filename, payload, content_type) = result[0]
    assert filename == "notes.md"
    assert payload == b"# hi"
    assert content_type == "text/markdown"


def test_build_rejects_bad_entry() -> None:
    with pytest.raises(TypeError):
        build_multipart_files([123])  # type: ignore[list-item]


def test_build_raises_if_path_missing(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        build_multipart_files([tmp_path / "nope.txt"])
