"""Unit tests for :mod:`spine.exceptions`."""

from __future__ import annotations

import pytest

from spine.exceptions import (
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SpineAPIError,
    SpineError,
    map_http_error,
)


@pytest.mark.parametrize(
    ("status", "expected"),
    [
        (400, BadRequestError),
        (401, AuthenticationError),
        (404, NotFoundError),
        (429, RateLimitError),
        (500, ServerError),
        (502, ServerError),
        (504, ServerError),
        (418, SpineAPIError),
    ],
)
def test_map_http_error_selects_right_subclass(status: int, expected: type[SpineAPIError]) -> None:
    exc = map_http_error(
        status_code=status,
        body={"error": "oops"},
        request_id=None,
    )
    assert isinstance(exc, expected)
    assert exc.status_code == status
    assert exc.error_message == "oops"


def test_map_http_error_uses_default_message_when_body_missing() -> None:
    exc = map_http_error(status_code=500, body=None, request_id="req-1")
    assert "HTTP 500" in str(exc)
    assert exc.request_id == "req-1"


def test_spine_api_error_is_spine_error() -> None:
    exc = map_http_error(status_code=400, body=None, request_id=None)
    assert isinstance(exc, SpineError)
