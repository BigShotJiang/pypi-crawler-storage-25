"""End-to-end tests for the async :class:`AsyncSpineClient`.

These mirror the sync tests in :mod:`tests.test_client_sync`. Every
scenario should exist in both files so the clients stay interchangeable.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from spine import AsyncSpineClient, NotFoundError, RunStatus, Template
from tests.conftest import API_KEY, envelope, error_envelope


async def test_async_create_run(
    async_client: AsyncSpineClient, mocked_router: respx.MockRouter
) -> None:
    route = mocked_router.post("/run").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-a",
                    "status": "running",
                    "canvas_id": "c-a",
                    "poll_url": "/v1/run/run-a",
                    "estimated_duration_ms": 10000,
                }
            ),
        )
    )

    handle = await async_client.runs.create(prompt="Hi", template=Template.MEMO)

    assert route.called
    assert handle.run_id == "run-a"
    assert route.calls.last.request.headers["X-API-KEY"] == API_KEY


async def test_async_get_run_completed(
    async_client: AsyncSpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.get("/run/run-b").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "run_id": "run-b",
                    "status": "completed",
                    "canvas_id": "c-b",
                    "duration_ms": 9000,
                    "result": {"final_output": "ok", "artifacts": []},
                    "metadata": {
                        "template_used": "memo",
                        "models_used": [],
                        "credits_consumed": 0,
                    },
                }
            ),
        )
    )

    run = await async_client.runs.get("run-b")
    assert run.status == RunStatus.COMPLETED
    assert run.result is not None
    assert run.result.final_output == "ok"


async def test_async_not_found(
    async_client: AsyncSpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.get("/run/nope").mock(
        return_value=httpx.Response(404, json=error_envelope("nope"))
    )

    with pytest.raises(NotFoundError):
        await async_client.runs.get("nope")


async def test_async_canvas_introspection(
    async_client: AsyncSpineClient, mocked_router: respx.MockRouter
) -> None:
    mocked_router.get("/canvas/c-1/dag").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "canvas_id": "c-1",
                    "canvas_name": "Test",
                    "nodes": [],
                    "edges": [],
                }
            ),
        )
    )
    mocked_router.get("/canvas/c-1/tasks").mock(
        return_value=httpx.Response(
            200,
            json=envelope({"canvas_id": "c-1", "completed": [], "not_completed": []}),
        )
    )
    mocked_router.get("/canvas/c-1/tasks/t-1").mock(
        return_value=httpx.Response(
            200,
            json=envelope(
                {
                    "task_id": "t-1",
                    "name": "x",
                    "task_type": "parent-task",
                    "status": "completed",
                    "children": None,
                }
            ),
        )
    )

    dag = await async_client.canvas.get_dag("c-1")
    tasks = await async_client.canvas.get_tasks("c-1")
    task = await async_client.canvas.get_task("c-1", "t-1")

    assert dag.canvas_id == "c-1"
    assert tasks.canvas_id == "c-1"
    assert task.name == "x"
