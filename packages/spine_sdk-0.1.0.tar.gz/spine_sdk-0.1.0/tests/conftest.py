"""Shared pytest fixtures.

The SDK never hits the real network in unit tests — every test installs a
``respx`` mock router that intercepts all ``httpx`` traffic and lets each
test script the responses it expects.
"""

from __future__ import annotations

from typing import Iterator

import httpx
import pytest
import respx

from spine import AsyncSpineClient, RetryPolicy, SpineClient

BASE_URL = "https://api.test.spine"
API_KEY = "sk_spine_test_key"


@pytest.fixture
def mocked_router() -> Iterator[respx.MockRouter]:
    """Install a respx router that asserts all requests are mocked."""
    with respx.mock(base_url=f"{BASE_URL}/v1", assert_all_called=False) as router:
        yield router


@pytest.fixture
def sync_client(mocked_router: respx.MockRouter) -> Iterator[SpineClient]:
    """A sync client pre-pointed at the mock server with retries disabled."""
    del mocked_router  # fixture only here to enforce ordering
    client = SpineClient(
        api_key=API_KEY,
        base_url=BASE_URL,
        retry_policy=RetryPolicy(max_retries=0),
        timeout=httpx.Timeout(5.0),
    )
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
async def async_client(mocked_router: respx.MockRouter) -> AsyncSpineClient:
    """An async client pre-pointed at the mock server with retries disabled."""
    del mocked_router
    client = AsyncSpineClient(
        api_key=API_KEY,
        base_url=BASE_URL,
        retry_policy=RetryPolicy(max_retries=0),
        timeout=httpx.Timeout(5.0),
    )
    try:
        yield client
    finally:
        await client.aclose()


def envelope(data: object) -> dict[str, object]:
    """Wrap ``data`` in the Spine API response envelope."""
    return {"success": True, "error": None, "data": data}


def error_envelope(message: str) -> dict[str, object]:
    """Build a Spine API error envelope."""
    return {"success": False, "error": message, "data": None}
