# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DescribeExtensionRequest(DaraModel):
    def __init__(
        self,
        dbinstance_id: str = None,
        database_name: str = None,
        extension_name: str = None,
    ):
        # The instance ID.
        # 
        # >  You can call the [DescribeDBInstances](https://help.aliyun.com/document_detail/86911.html) Interface to query the details of all AnalyticDB PostgreSQL Instances in the target region, including Instance IDs.
        # 
        # This parameter is required.
        self.dbinstance_id = dbinstance_id
        # Database name.
        # 
        # *   Only contain letters, digits, and underscores (_).
        # *   Must start with a letter.
        # *   Up to 63 characters in length.
        # 
        # This parameter is required.
        self.database_name = database_name
        # The extension name.
        # 
        # This parameter is required.
        self.extension_name = extension_name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.dbinstance_id is not None:
            result['DBInstanceId'] = self.dbinstance_id

        if self.database_name is not None:
            result['DatabaseName'] = self.database_name

        if self.extension_name is not None:
            result['ExtensionName'] = self.extension_name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('DBInstanceId') is not None:
            self.dbinstance_id = m.get('DBInstanceId')

        if m.get('DatabaseName') is not None:
            self.database_name = m.get('DatabaseName')

        if m.get('ExtensionName') is not None:
            self.extension_name = m.get('ExtensionName')

        return self

