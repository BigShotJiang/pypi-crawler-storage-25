2026-03-19 Version: 5.1.0
- Support API CreateAIService.
- Support API DeleteAIService.
- Support API DescribeAIService.
- Support API ListAIServices.
- Support API ModifyAIServiceSecurityIps.
- Support API PauseSupabaseProject.
- Support API ResumeSupabaseProject.


2026-03-16 Version: 5.0.3
- Update API GetSupabaseProject: add response parameters Body.DBSecurityIpList.
- Update API ModifySupabaseProjectSecurityIps: add request parameters UpdateDb.
- Update API ModifySupabaseProjectSecurityIps: add request parameters UpdateWeb.


2026-02-09 Version: 5.0.2
- Update API CreateSupabaseProject: add request parameters PayType.
- Update API CreateSupabaseProject: add request parameters Period.
- Update API CreateSupabaseProject: add request parameters UsedTime.
- Update API CreateSupabaseProject: add response parameters Body.OrderId.


2025-12-15 Version: 4.15.2
- Update API GetSupabaseProject: add response parameters Body.Eni.


2025-12-05 Version: 4.15.1
- Update API GetSupabaseProject: add response parameters Body.InstanceVersion.
- Update API GetSupabaseProject: add response parameters Body.PayType.
- Update API GetSupabaseProject: add response parameters Body.StorageType.
- Update API ListAINodePools: add response parameters Body.AINodePoolInfos.$.AINodeInfos.$.ZoneId.
- Update API ListSupabaseProjects: add request parameters PageNumber.
- Update API ListSupabaseProjects: add request parameters PageSize.
- Update API ListSupabaseProjects: add response parameters Body.Items.$.ExpireTime.


2025-11-28 Version: 4.15.0
- Support API CreateDBInstanceIPArray.
- Support API CreateDatabase.
- Support API DeleteDBInstanceIPArray.
- Support API DeleteDatabase.
- Support API DeletePrivateRAGService.
- Support API DeployPrivateRAGService.
- Support API DescribeDatabase.
- Support API DescribeExtension.
- Support API DescribePrivateRAGService.
- Support API DescribeRebalanceStatus.
- Support API DescribeZonesPrivateRAGService.
- Support API DownloadSlowSQLRecords.
- Support API ListDatabaseExtensions.
- Support API ListInstanceDatabases.
- Support API ListSlowSQLRecords.


2025-10-30 Version: 4.14.0
- Support API QueryKnowledgeBasesContent.
- Update API ChatWithKnowledgeBase: add request parameters RegionId.
- Update API ChatWithKnowledgeBase: add response parameters Body.ChatCompletion.Choices.$.Message.ReasoningContent.
- Update API ChatWithKnowledgeBaseStream: add request parameters RegionId.
- Update API ChatWithKnowledgeBaseStream: add response parameters Body.ChatCompletion.Choices.$.Message.ReasoningContent.
- Update API QueryContent: add request parameters Offset.
- Update API QueryContent: add request parameters OrderBy.


2025-09-30 Version: 4.13.0
- Support API ChatWithKnowledgeBase.
- Support API ChatWithKnowledgeBaseStream.


2025-09-29 Version: 4.12.1
- Update API QueryCollectionData: add request parameters IncludeSparseValues.
- Update API QueryCollectionData: add response parameters Body.Matches.$.SparseValues.


2025-09-23 Version: 4.12.0
- Support API AddAINode.
- Support API CreateModelService.
- Support API DeleteAINode.
- Support API DeleteModelService.
- Support API DescribeModelService.
- Support API ListAINodePools.
- Support API ListModelServices.
- Support API ListSupportModels.


2025-09-12 Version: 4.11.0
- Support API EnableCollectionGraphRAG.
- Support API GetGraphRAGJob.


2025-09-11 Version: 4.10.5
- Update API QueryCollectionData: add response parameters Body.Matches.$.MetadataV2.


2025-09-10 Version: 4.10.4
- Update API CreateDocumentCollection: add request parameters EnableGraph.
- Update API CreateDocumentCollection: add request parameters EntityTypes.
- Update API CreateDocumentCollection: add request parameters LLMModel.
- Update API CreateDocumentCollection: add request parameters Language.
- Update API CreateDocumentCollection: add request parameters RelationshipTypes.
- Update API DescribeDBInstanceAttribute: add response parameters Body.Items.$.GraphEngineStatus.
- Update API QueryContent: add request parameters GraphEnhance.
- Update API QueryContent: add request parameters GraphSearchArgs.
- Update API QueryContent: add response parameters Body.Entities.
- Update API QueryContent: add response parameters Body.Relations.
- Update API UpsertChunks: add response parameters Body.JobId.


2025-08-05 Version: 4.10.3
- Update API UploadDocumentAsync: add request parameters SplitterModel.


2025-07-30 Version: 4.10.2
- Update API DescribeDocument: add response parameters Body.DocumentLoaderResultFileUrl.
- Update API GetUploadDocumentJob: add response parameters Body.ChunkResult.DocumentLoaderResultFileUrl.


2025-07-18 Version: 4.10.1
- Update API UploadDocumentAsync: add request parameters VlEnhance.


2025-07-10 Version: 4.10.0
- Support API CreateSupabaseProject.
- Support API DeleteSupabaseProject.
- Support API GetSupabaseProject.
- Support API GetSupabaseProjectApiKeys.
- Support API GetSupabaseProjectDashboardAccount.
- Support API ListSupabaseProjects.
- Support API ModifySupabaseProjectSecurityIps.
- Support API ResetSupabaseProjectPassword.


2025-06-17 Version: 4.9.2
- Update API DescribeDBInstanceAttribute: add response parameters Body.Items.$.InstanceSpec.


2025-06-11 Version: 4.9.1
- Update API UpsertChunks: add request parameters AllowInsertWithFilter.


2025-06-05 Version: 4.9.0
- Support API ModifyCollection.


2025-05-29 Version: 4.8.5
- Update API CreateDBInstance: add request parameters CacheStorageSize.
- Update API DescribeDBInstanceAttribute: add response parameters Body.Items.$.CacheStorageSize.
- Update API QueryContent: add request parameters UrlExpiration.
- Update API TextEmbedding: add request parameters Dimension.
- Update API UpgradeDBInstance: add request parameters CacheStorageSize.
- Update API UpgradeDBInstance: add request parameters ServerlessResource.
- Update API UpsertChunks: add request parameters ShouldReplaceFile.
- Update API UpsertChunks: add request parameters TextChunks.$.Filter.
- Update API UpsertChunks: add request parameters TextChunks.$.Id.


2025-04-27 Version: 4.8.4
- Generated python 2016-05-03 for gpdb.

2025-03-25 Version: 4.8.3
- Update API QueryContent: update param Content.


2025-03-18 Version: 4.8.2
- Update API DescribeDownloadRecords: add param DownloadTaskType.


2025-03-12 Version: 4.8.1
- Update API CreateCollection: add param SparseVectorIndexConfig.
- Update API CreateCollection: add param SupportSparse.
- Update API CreateCollection: update param MetadataIndices.
- Update API CreateSecret: add param WorkspaceId.
- Update API CreateSecret: update param DBInstanceId.
- Update API CreateSecret: update param TestConnection.
- Update API CreateVectorIndex: add param Type.
- Update API CreateVectorIndex: update param Dimension.
- Update API CreateVectorIndex: update param HnswEfConstruction.
- Update API DeleteSecret: add param WorkspaceId.
- Update API DeleteSecret: update param DBInstanceId.
- Update API DeleteVectorIndex: add param Type.
- Update API DescribeCollection: update response param.
- Update API DescribeTable: add param WorkspaceId.
- Update API DescribeTable: update param DBInstanceId.
- Update API ExecuteStatement: add param RagWorkspaceCollection.
- Update API ExecuteStatement: add param WorkspaceId.
- Update API ExecuteStatement: update param DBInstanceId.
- Update API GetSecretValue: add param WorkspaceId.
- Update API GetSecretValue: update param DBInstanceId.
- Update API ListSecrets: add param WorkspaceId.
- Update API ListSecrets: update param DBInstanceId.
- Update API QueryCollectionData: add param SparseVector.
- Update API UpsertCollectionData: update param Rows.


2025-03-08 Version: 4.8.0
- Support API GetStatementResult.


2025-03-07 Version: 4.7.1
- Update API CreateDocumentCollection: add param Dimension.
- Update API CreateDocumentCollection: update param EmbeddingModel.


2025-02-19 Version: 4.7.0
- Support API CancelCreateIndexJob.
- Support API CloneDBInstance.
- Support API CreateBackup.
- Support API CreateIndex.
- Support API DeleteBackup.
- Support API DeleteIndex.
- Support API DescribeBackupJob.
- Support API DescribeCreateIndexJob.
- Support API DescribeIndex.
- Support API ListBackupJobs.
- Support API ListIndices.
- Support API ModifyDBInstanceDeploymentMode.
- Update API CreateCollection: add param HnswEfConstruction.
- Update API CreateDBInstance: add param AINodeSpecInfos.
- Update API CreateDBInstance: add param MasterAISpec.
- Update API CreateDocumentCollection: add param HnswEfConstruction.
- Update API CreateVectorIndex: add param HnswEfConstruction.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API ModifyMasterSpec: add param MasterAISpec.
- Update API ModifyMasterSpec: update param MasterCU.


2025-02-17 Version: 4.6.0
- Support API CancelCreateIndexJob.
- Support API CloneDBInstance.
- Support API CreateBackup.
- Support API CreateIndex.
- Support API DeleteBackup.
- Support API DeleteIndex.
- Support API DescribeBackupJob.
- Support API DescribeCreateIndexJob.
- Support API DescribeIndex.
- Support API ListBackupJobs.
- Support API ListIndices.
- Support API ModifyDBInstanceDeploymentMode.
- Update API CreateCollection: add param HnswEfConstruction.
- Update API CreateDBInstance: add param AINodeSpecInfos.
- Update API CreateDBInstance: add param MasterAISpec.
- Update API CreateDocumentCollection: add param HnswEfConstruction.
- Update API CreateVectorIndex: add param HnswEfConstruction.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API ModifyMasterSpec: add param MasterAISpec.
- Update API ModifyMasterSpec: update param MasterCU.


2025-02-13 Version: 4.5.0
- Support API CancelCreateIndexJob.
- Support API CloneDBInstance.
- Support API CreateBackup.
- Support API CreateIndex.
- Support API DeleteBackup.
- Support API DeleteIndex.
- Support API DescribeBackupJob.
- Support API DescribeCreateIndexJob.
- Support API DescribeIndex.
- Support API ListBackupJobs.
- Support API ListIndices.
- Support API ModifyDBInstanceDeploymentMode.
- Update API CreateCollection: add param HnswEfConstruction.
- Update API CreateDBInstance: add param MasterAISpec.
- Update API CreateDocumentCollection: add param HnswEfConstruction.
- Update API CreateVectorIndex: add param HnswEfConstruction.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API ModifyMasterSpec: add param MasterAISpec.
- Update API ModifyMasterSpec: update param MasterCU.


2025-01-10 Version: 4.3.0
- Support API CreateBackup.
- Support API DeleteBackup.
- Support API DescribeBackupJob.
- Support API ListBackupJobs.
- Update API ModifyMasterSpec: update param AccessKeyId.


2024-12-20 Version: 4.2.0
- Support API CreateRemoteADBDataSource.
- Support API DeleteAccount.
- Support API DeleteRemoteADBDataSource.
- Support API GetAccount.
- Support API ListRemoteADBDataSources.
- Support API ModifyDBInstanceNetworkType.
- Support API ModifyDBInstancePayType.
- Support API ModifyRemoteADBDataSource.
- Support API TextEmbedding.
- Update API AllocateInstancePublicConnection: update param AccessKeyId.
- Update API BindDBResourceGroupWithRole: update param AccessKeyId.
- Update API CreateAccount: delete param ResourceGroupId.
- Update API CreateAccount: update param AccessKeyId.
- Update API CreateAccount: update param AccountPassword.
- Update API CreateCollection: add param MetadataIndices.
- Update API CreateCollection: update param AccessKeyId.
- Update API CreateDBInstance: add param DeployMode.
- Update API CreateDBInstance: add param StandbyVSwitchId.
- Update API CreateDBInstance: add param StandbyZoneId.
- Update API CreateDBInstance: update param AccessKeyId.
- Update API CreateDBInstancePlan: update param AccessKeyId.
- Update API CreateDBResourceGroup: update param AccessKeyId.
- Update API CreateDocumentCollection: add param MetadataIndices.
- Update API CreateDocumentCollection: update param AccessKeyId.
- Update API CreateJDBCDataSource: update param JDBCPassword.
- Update API CreateSampleData: update param AccessKeyId.
- Update API CreateStreamingJob: update param Password.
- Update API DescribeActiveSQLRecords: update param AccessKeyId.
- Update API DescribeAvailableResources: update param AccessKeyId.
- Update API DescribeDBClusterNode: update param AccessKeyId.
- Update API DescribeDBClusterPerformance: update param AccessKeyId.
- Update API DescribeDBInstanceAttribute: update param AccessKeyId.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API DescribeDBInstanceDataBloat: update param AccessKeyId.
- Update API DescribeDBInstanceDataSkew: update param AccessKeyId.
- Update API DescribeDBInstanceDiagnosisSummary: update param AccessKeyId.
- Update API DescribeDBInstanceErrorLog: update param AccessKeyId.
- Update API DescribeDBInstanceIPArrayList: update param AccessKeyId.
- Update API DescribeDBInstanceIndexUsage: update param AccessKeyId.
- Update API DescribeDBInstanceNetInfo: update param AccessKeyId.
- Update API DescribeDBInstancePerformance: update param AccessKeyId.
- Update API DescribeDBInstancePlans: update param AccessKeyId.
- Update API DescribeDBInstanceSSL: update param AccessKeyId.
- Update API DescribeDBInstanceSupportMaxPerformance: update param AccessKeyId.
- Update API DescribeDBInstances: update param AccessKeyId.
- Update API DescribeDBResourceGroup: update param AccessKeyId.
- Update API DescribeDBResourceManagementMode: update param AccessKeyId.
- Update API DescribeDBVersionInfos: update param AccessKeyId.
- Update API DescribeDataReDistributeInfo: update param AccessKeyId.
- Update API DescribeDataShareInstances: update param AccessKeyId.
- Update API DescribeDiagnosisDimensions: update param AccessKeyId.
- Update API DescribeDiagnosisMonitorPerformance: update param AccessKeyId.
- Update API DescribeDiagnosisRecords: update param AccessKeyId.
- Update API DescribeDiagnosisSQLInfo: update param AccessKeyId.
- Update API DescribeDownloadRecords: update param AccessKeyId.
- Update API DescribeDownloadSQLLogs: update param AccessKeyId.
- Update API DescribeHealthStatus: update param AccessKeyId.
- Update API DescribeIMVInfos: update param AccessKeyId.
- Update API DescribeJDBCDataSource: update response param.
- Update API DescribeLogBackups: update param AccessKeyId.
- Update API DescribeModifyParameterLog: update param AccessKeyId.
- Update API DescribeParameters: update param AccessKeyId.
- Update API DescribeRoles: update param AccessKeyId.
- Update API DescribeSQLLogCount: update param AccessKeyId.
- Update API DescribeSQLLogs: update param AccessKeyId.
- Update API DescribeSQLLogsV2: update param AccessKeyId.
- Update API DescribeSQLLogsV2: update response param.
- Update API DescribeSampleData: update param AccessKeyId.
- Update API DescribeSupportFeatures: update param AccessKeyId.
- Update API DescribeTags: update param AccessKeyId.
- Update API DescribeWaitingSQLInfo: update param AccessKeyId.
- Update API DescribeWaitingSQLRecords: update param AccessKeyId.
- Update API DisableDBResourceGroup: update param AccessKeyId.
- Update API DownloadDiagnosisRecords: update param AccessKeyId.
- Update API DownloadSQLLogsRecords: update param AccessKeyId.
- Update API EnableDBResourceGroup: update param AccessKeyId.
- Update API GetUploadDocumentJob: update response param.
- Update API HandleActiveSQLRecord: update param AccessKeyId.
- Update API ListTagResources: update param AccessKeyId.
- Update API ModifyAccountDescription: add param ClientToken.
- Update API ModifyAccountDescription: update param AccessKeyId.
- Update API ModifyAccountDescription: update param AccountDescription.
- Update API ModifyDBInstanceConnectionString: add param ClientToken.
- Update API ModifyDBInstanceConnectionString: update param AccessKeyId.
- Update API SetDataShareInstance: update param AccessKeyId.
- Update API UpgradeExtensions: add param DatabaseName.


2024-09-06 Version: 4.1.0
- Support API Rerank.


2024-08-29 Version: 4.0.2
- Update API DescribeDataBackups: update param EndTime.
- Update API DescribeDataBackups: update param StartTime.
- Update API ModifyMasterSpec: update param MasterCU.


2024-08-28 Version: 4.0.1
- Update API QueryCollectionData: add param RelationalTableFilter.


2024-08-23 Version: 4.0.0
- Update API CheckHadoopNetConnection: add param DataSourceId.
- Update API CheckHadoopNetConnection: update param EmrInstanceId.
- Update API CheckJDBCSourceNetConnection: add param DataSourceId.
- Update API CheckJDBCSourceNetConnection: update param JdbcConnectionString.
- Update API CreateAccount: add param AccountType.
- Update API DescribeAccounts: add param AccountType.
- Update API DescribeAccounts: update response param.
- Update API DescribeDBInstanceDataBloat: add param Database.
- Update API DescribeDBInstanceDataBloat: add param OrderBy.
- Update API DescribeDBInstanceDataSkew: add param Database.
- Update API DescribeDBInstanceDataSkew: add param OrderBy.
- Update API DescribeDBInstanceIndexUsage: add param Database.
- Update API DescribeDBInstanceIndexUsage: add param OrderBy.
- Update API DescribeDBInstanceIndexUsage: update response param.
- Update API DescribeHadoopDataSource: update response param.
- Update API DescribeJDBCDataSource: update response param.


2024-08-04 Version: 3.9.1
- Update API CancelUpsertCollectionDataJob: add param WorkspaceId.
- Update API CancelUpsertCollectionDataJob: update param DBInstanceId.
- Update API CreateCollection: add param WorkspaceId.
- Update API CreateCollection: update param DBInstanceId.
- Update API CreateNamespace: add param WorkspaceId.
- Update API CreateNamespace: update param DBInstanceId.
- Update API DeleteCollection: add param WorkspaceId.
- Update API DeleteCollection: update param DBInstanceId.
- Update API DeleteCollectionData: add param WorkspaceId.
- Update API DeleteCollectionData: update param DBInstanceId.
- Update API DeleteNamespace: add param WorkspaceId.
- Update API DeleteNamespace: update param DBInstanceId.
- Update API DescribeCollection: add param WorkspaceId.
- Update API DescribeCollection: update param DBInstanceId.
- Update API DescribeNamespace: add param WorkspaceId.
- Update API DescribeNamespace: update param DBInstanceId.
- Update API GetUpsertCollectionDataJob: add param WorkspaceId.
- Update API GetUpsertCollectionDataJob: update param DBInstanceId.
- Update API InitVectorDatabase: add param WorkspaceId.
- Update API InitVectorDatabase: update param DBInstanceId.
- Update API ListCollections: add param WorkspaceId.
- Update API ListCollections: update param DBInstanceId.
- Update API ListNamespaces: add param WorkspaceId.
- Update API ListNamespaces: update param DBInstanceId.
- Update API QueryCollectionData: add param WorkspaceId.
- Update API QueryCollectionData: update param DBInstanceId.
- Update API UpdateCollectionDataMetadata: add param WorkspaceId.
- Update API UpdateCollectionDataMetadata: update param DBInstanceId.
- Update API UpsertCollectionData: add param WorkspaceId.
- Update API UpsertCollectionData: update param DBInstanceId.
- Update API UpsertCollectionDataAsync: add param WorkspaceId.
- Update API UpsertCollectionDataAsync: update param DBInstanceId.


2024-07-19 Version: 3.9.0
- Support API CreateSecret.
- Support API DeleteSecret.
- Support API DescribeTable.
- Support API ExecuteStatement.
- Support API GetSecretValue.
- Support API ListDatabases.
- Support API ListSchemas.
- Support API ListSecrets.
- Support API ListTables.


2024-07-18 Version: 3.8.3
- Update API ListDocuments: add param MaxResults.
- Update API ListDocuments: add param NextToken.
- Update API ListDocuments: update response param.
- Update API QueryContent: add param IncludeFileUrl.


2024-07-03 Version: 3.8.2
- Update API DescribeDocument: update response param.


2024-06-27 Version: 3.8.1
- Update API DescribeStreamingDataService: update response param.
- Update API ListStreamingDataServices: update response param.


2024-05-28 Version: 3.8.0
- Support API BindDBResourceGroupWithRole.
- Support API CreateDBResourceGroup.
- Support API DeleteDBResourceGroup.
- Support API DescribeDBResourceGroup.
- Support API DescribeRoles.
- Support API DisableDBResourceGroup.
- Support API EnableDBResourceGroup.
- Support API ModifyDBResourceGroup.
- Support API PauseDataRedistribute.
- Support API ResumeDataRedistribute.
- Support API UnbindDBResourceGroupWithRole.


2024-05-17 Version: 3.7.0
- Support API CheckHadoopDataSource.
- Support API CheckHadoopNetConnection.
- Support API CheckJDBCSourceNetConnection.
- Support API CreateExtensions.
- Support API CreateExternalDataService.
- Support API CreateHadoopDataSource.
- Support API CreateJDBCDataSource.
- Support API CreateStreamingDataService.
- Support API CreateStreamingDataSource.
- Support API CreateStreamingJob.
- Support API DeleteExtension.
- Support API DeleteExternalDataService.
- Support API DeleteHadoopDataSource.
- Support API DeleteJDBCDataSource.
- Support API DeleteStreamingDataService.
- Support API DeleteStreamingDataSource.
- Support API DeleteStreamingJob.
- Support API DescribeExternalDataService.
- Support API DescribeHadoopClustersInSameNet.
- Support API DescribeHadoopConfigs.
- Support API DescribeHadoopDataSource.
- Support API DescribeJDBCDataSource.
- Support API DescribeStreamingDataService.
- Support API DescribeStreamingDataSource.
- Support API DescribeStreamingJob.
- Support API ListExternalDataServices.
- Support API ListExternalDataSources.
- Support API ListInstanceExtensions.
- Support API ListStreamingDataServices.
- Support API ListStreamingDataSources.
- Support API ListStreamingJobs.
- Support API ModifyExternalDataService.
- Support API ModifyHadoopDataSource.
- Support API ModifyJDBCDataSource.
- Support API ModifyStreamingDataService.
- Support API ModifyStreamingDataSource.
- Support API ModifyStreamingJob.
- Support API UpgradeExtensions.


2024-05-13 Version: 3.6.2
- Update API CreateDBInstance: update param SecurityIPList.


2024-05-11 Version: 3.6.1
- Generated python 2016-05-03 for gpdb.

2024-05-09 Version: 3.6.0
- Support API DescribeDBResourceManagementMode.


2024-04-29 Version: 3.5.4
- Update API QueryCollectionData: add param IncludeMetadataFields.
- Update API QueryCollectionData: add param Offset.
- Update API QueryCollectionData: add param OrderBy.
- Update API QueryCollectionData: update param HybridSearchArgs.
- Update API QueryCollectionData: update response param.
- Update API QueryContent: add param IncludeMetadataFields.


2024-04-22 Version: 3.5.3
- Update API DescribeSampleData: update response param.
- Update API QueryCollectionData: add param HybridSearch.
- Update API QueryCollectionData: add param HybridSearchArgs.
- Update API QueryContent: add param HybridSearch.
- Update API QueryContent: add param HybridSearchArgs.
- Update API QueryContent: add param IncludeVector.
- Update API QueryContent: add param RecallWindow.
- Update API QueryContent: add param RerankFactor.
- Update API QueryContent: update response param.


2024-02-19 Version: 3.5.2
- Update API DescribeSampleData: update response param.
- Update API QueryContent: add param IncludeVector.
- Update API QueryContent: add param RecallWindow.
- Update API QueryContent: add param RerankFactor.
- Update API QueryContent: update response param.


2024-01-18 Version: 3.5.1
- Generated python 2016-05-03 for gpdb.

2024-01-18 Version: 3.5.1
- Generated python 2016-05-03 for gpdb.

2024-01-18 Version: 3.5.0
- Generated python 2016-05-03 for gpdb.

2024-01-17 Version: 3.4.1
- Generated python 2016-05-03 for gpdb.

2024-01-10 Version: 3.4.0
- Generated python 2016-05-03 for gpdb.

2023-12-18 Version: 3.3.3
- Generated python 2016-05-03 for gpdb.

2023-12-11 Version: 3.3.2
- Generated python 2016-05-03 for gpdb.

2023-11-07 Version: 3.3.1
- Generated python 2016-05-03 for gpdb.

2023-11-06 Version: 3.3.0
- Generated python 2016-05-03 for gpdb.

2023-09-20 Version: 3.2.2
- Generated python 2016-05-03 for gpdb.

2023-09-18 Version: 3.2.1
- Generated python 2016-05-03 for gpdb.

2023-09-18 Version: 3.2.1
- Generated python 2016-05-03 for gpdb.

2023-09-18 Version: 3.2.1
- Generated python 2016-05-03 for gpdb.

2023-09-11 Version: 3.2.0
- Generated python 2016-05-03 for gpdb.

2023-08-18 Version: 3.1.0
- Generated python 2016-05-03 for gpdb.

2023-08-09 Version: 3.0.0
- Generated python 2016-05-03 for gpdb.

2023-08-02 Version: 2.0.2
- Add Cloud Disk Encryption.

2023-07-26 Version: 2.0.1
- Add Cloud Disk Encryption.

2023-07-10 Version: 2.0.0
- Add Cloud Disk Encryption.

2023-01-09 Version: 1.1.21
- Support Pause and Resume Instance.


2022-12-13 Version: 1.1.20
- Support describe cluster support features.


2022-12-12 Version: 1.1.19
- Support describe cluster support features.


2022-12-08 Version: 1.1.18
- Support describe cluster support features.


2022-11-02 Version: 1.1.16
- Support serverless v2


2022-09-26 Version: 1.1.15
- Support Openapi Tag.
- Support Tag Ram.


2022-09-14 Version: 1.1.14
- Support Openapi Tag.
- Support Tag Ram.


2022-09-05 Version: 1.1.13
- Support Resource Group.

2022-08-25 Version: 1.1.11
- Support diagnose instance.

2022-08-10 Version: 1.1.10
- Support diagnose instance.

2022-06-27 Version: 1.1.9
- Support diagnose instance.

2022-05-30 Version: 1.1.8
- Support rebalance instance.

2022-04-28 Version: 1.1.7
- Support upgrade instance.

2022-04-19 Version: 1.1.6
- Support set datashare.

2022-02-16 Version: 1.1.5
- Support set datashare.

2022-02-15 Version: 1.0.1
- AMP Version Change.

2021-09-15 Version: 1.0.0
- AMP version.

