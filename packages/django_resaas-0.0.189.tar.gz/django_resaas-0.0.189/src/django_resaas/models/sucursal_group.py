
from django.db import models
from django.contrib.auth.models import Group
from django_resaas.core.base.models import TimeModel

class SucursalGroup(TimeModel):
    sucursal = models.ForeignKey('django_resaas.Sucursal', on_delete=models.CASCADE)
    group = models.ForeignKey(Group, on_delete=models.CASCADE)

    class Meta:
        unique_together = ("sucursal", "group")
        permissions = ()

    class RESAAS:
        label_field = "sucursal.nome"
        # route="view_entidade"

    def __str__(self):
        return f'{self.sucursal.nome} | {self.group.name}'
