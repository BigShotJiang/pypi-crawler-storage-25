"""Windows 经典控制台（conhost / 非 Windows Terminal）下 Textual 的兼容检测与可选预处理。

经典 cmd 窗口对鼠标 reporting、子进程混写同一控制台等场景容易花屏；此处仅做轻量启发式与开关，
无法代替「使用 Windows Terminal」或「子进程勿写控制台」等根本方案。
"""

from __future__ import annotations

import os
import sys


def tui_use_mouse() -> bool:
    """是否让 Textual 启用鼠标。默认始终开启；经典 Windows conhost 若错位可设 ``AICD_TUI_MOUSE=0``。"""
    v = (os.environ.get("AICD_TUI_MOUSE") or "").strip().lower()
    if v in ("0", "false", "no", "off"):
        return False
    return True


def tui_ansi_color_preference() -> bool | None:
    """
    若返回 True/False 则传给 ``App(ansi_color=...)``；返回 None 表示使用 Textual 默认。

    部分旧控制台在 ``ansi_color=True`` 时略稳定（直输出 ANSI），可用 ``AICD_TUI_ANSI_COLOR=1`` 尝试。
    """
    v = (os.environ.get("AICD_TUI_ANSI_COLOR") or "").strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    return None


def ensure_windows_vt_mode_early() -> None:
    """
    在 Textual 拉起前尽量打开 stdout/stderr 的虚拟终端处理，与 Textual 内逻辑一致但更早执行，
    减少其它初始化输出打在未开 VT 的缓冲区上的概率。
    """
    if sys.platform != "win32":
        return
    if os.environ.get("AICD_SKIP_WIN_VT") == "1":
        return
    try:
        import ctypes
        import msvcrt
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004

        def _try_file(f: object) -> None:
            if f is None:
                return
            fileno = getattr(f, "fileno", None)
            if not callable(fileno):
                return
            try:
                fd = fileno()
            except (OSError, ValueError):
                return
            h = msvcrt.get_osfhandle(fd)
            mode = wintypes.DWORD()
            if not kernel32.GetConsoleMode(h, ctypes.byref(mode)):
                return
            if mode.value & ENABLE_VIRTUAL_TERMINAL_PROCESSING:
                return
            kernel32.SetConsoleMode(h, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING)

        for stream in (sys.stdout, sys.stderr):
            _try_file(stream)
    except Exception:
        pass
