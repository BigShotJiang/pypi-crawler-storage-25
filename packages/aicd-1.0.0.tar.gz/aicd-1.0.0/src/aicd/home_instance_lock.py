"""同一 AICD_HOME 下仅允许一个「根」操作系统进程持有主运行时（多连接 serve 进程内 refcount）。

锁文件：``HOME/data/.aicd_instance.lock``，首行 PID。同一进程内多次 ``build_runtime``（如 ``--runtime-api`` 多连接）
用内存引用计数，仅最后一次 ``shutdown`` 时删除锁文件。

环境变量 **`AICD_SKIP_HOME_INSTANCE_LOCK=1`**：跳过占用检查（测试用）。"""
from __future__ import annotations

import os
import threading
from pathlib import Path

from aicd.invocation import InvocationContext


class HomeInstanceLockError(RuntimeError):
    """当前 HOME 已被其它根进程占用。"""


_LOCK_GUARD = threading.Lock()
# 进程内：同一 HOME 的 build_runtime 嵌套次数（跨进程仍看锁文件）
_INPROC_REFS: dict[str, int] = {}


def instance_lock_path(home: Path) -> Path:
    return (home.resolve() / "data" / ".aicd_instance.lock")


def should_acquire_instance_lock(
    inv: InvocationContext, *, explicit: bool | None
) -> bool:
    if (os.environ.get("AICD_SKIP_HOME_INSTANCE_LOCK") or "").strip() in (
        "1",
        "true",
        "yes",
        "on",
    ):
        return False
    if explicit is not None:
        return bool(explicit)
    if inv.depth > 0:
        return False
    if inv.spawned_by != "user":
        # host / 插件 / 任务子进程拉起的 aicd 不抢锁，避免误拦 chat-once 等子进程
        return False
    return True


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid)
        if not h:
            return False
        kernel32.CloseHandle(h)
        return True
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _acquire_pid_file(home: Path) -> tuple[bool, str]:
    path = instance_lock_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    me = os.getpid()
    hint = (
        "若需要同时运行多个 Aicd 实例，请为其它实例指定不同的 HOME，例如：\n"
        "  Windows CMD:  set AICD_HOME=D:\\\\.aicd2 && aicd tui\n"
        "  PowerShell:  $env:AICD_HOME=\"$HOME\\.aicd2\"; aicd tui\n"
        "  或:  aicd --home D:\\\\.aicd2 tui\n"
    )
    for _ in range(120):
        try:
            fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, f"{me}\n".encode("ascii"))
            finally:
                os.close(fd)
            return True, ""
        except FileExistsError:
            pass
        except OSError:
            pass
        try:
            raw = path.read_text(encoding="utf-8")
            line0 = raw.strip().splitlines()[0].strip()
            other = int(line0)
        except (OSError, ValueError, IndexError):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            continue
        if other == me:
            return True, ""
        if _pid_alive(other):
            return (
                False,
                f"检测到当前 AICD_HOME 已由另一进程占用（PID {other}），禁止再启动本实例。\n"
                + hint,
            )
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    return False, "无法获取实例锁（重试超时）。请稍后再试，或检查 " + str(path)


def _release_pid_file_if_owner(home: Path) -> None:
    path = instance_lock_path(home)
    me = os.getpid()
    try:
        raw = path.read_text(encoding="utf-8")
        other = int(raw.strip().splitlines()[0])
    except (OSError, ValueError, IndexError):
        return
    if other == me:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def acquire_home_instance_lock(home: Path) -> tuple[bool, str]:
    """成功时返回 (True, "")；锁被其它进程占用时 (False, 提示文案)。"""
    key = str(home.resolve())
    with _LOCK_GUARD:
        _INPROC_REFS[key] = _INPROC_REFS.get(key, 0) + 1
        depth = _INPROC_REFS[key]
    if depth > 1:
        return True, ""
    ok, msg = _acquire_pid_file(home)
    if not ok:
        with _LOCK_GUARD:
            _INPROC_REFS[key] -= 1
            if _INPROC_REFS[key] <= 0:
                _INPROC_REFS.pop(key, None)
        return False, msg
    return True, ""


def release_home_instance_lock(home: Path) -> None:
    key = str(home.resolve())
    with _LOCK_GUARD:
        r = _INPROC_REFS.get(key, 0) - 1
        if r > 0:
            _INPROC_REFS[key] = r
            return
        _INPROC_REFS.pop(key, None)
    _release_pid_file_if_owner(home)
