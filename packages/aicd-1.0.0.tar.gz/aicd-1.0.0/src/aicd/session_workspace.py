"""交互 TUI 默认 AI 工作区：HOME/workspaces/workspace_年月日时分秒，或 cwd 下同名目录。

``/workspaces list`` / ``clear`` 仅管理 HOME 下 ``workspaces/`` 内 ``workspace_*`` 目录。"""
from __future__ import annotations

import re
import shutil
import uuid
from datetime import datetime
from pathlib import Path

WORKSPACE_DIR_PREFIX = "workspace_"
_STAMP_RE = re.compile(r"^workspace_\d{14}$")

# 本地时间与用户工作流一致（与日志文件名同类）
_STAMP_FMT = "%Y%m%d%H%M%S"


def session_workspaces_root(home: Path) -> Path:
    return (home.resolve() / "workspaces").resolve()


def new_stamped_workspace_name() -> str:
    return f"{WORKSPACE_DIR_PREFIX}{datetime.now().strftime(_STAMP_FMT)}"


def create_session_workspace(container_dir: Path) -> Path:
    """在 ``container_dir`` 下新建唯一目录 ``workspace_YYYYMMDDHHMMSS``（必要时创建父目录）。"""
    parent = container_dir.expanduser().resolve()
    parent.mkdir(parents=True, exist_ok=True)
    name = new_stamped_workspace_name()
    path = parent / name
    if path.exists():
        path = parent / f"{name}_{uuid.uuid4().hex[:8]}"
    path.mkdir(parents=False)
    return path.resolve()


def list_managed_workspaces(home: Path) -> list[Path]:
    """列出 ``HOME/workspaces`` 下名称形如 ``workspace_14位时间戳`` 的子目录（已解析路径、排序）。"""
    root = session_workspaces_root(home)
    if not root.is_dir():
        return []
    out: list[Path] = []
    for p in root.iterdir():
        if p.is_dir() and _STAMP_RE.match(p.name):
            out.append(p.resolve())
    return sorted(out)


def clear_managed_workspaces_except(
    home: Path, keep: Path
) -> tuple[int, list[str]]:
    """删除 ``HOME/workspaces`` 下除 ``keep`` 外的所有受管 ``workspace_*`` 目录。返回 (删除数, 路径列表)。"""
    keep_r = keep.expanduser().resolve()
    deleted: list[str] = []
    for p in list_managed_workspaces(home):
        if p == keep_r:
            continue
        shutil.rmtree(p, ignore_errors=False)
        deleted.append(str(p))
    return len(deleted), deleted
