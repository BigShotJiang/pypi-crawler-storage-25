from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _fs_list_dir(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.list_dir(args["path"])


def _fs_read_file(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    mb_raw = args.get("max_bytes")
    mb_i: int | None = None
    if mb_raw is not None and str(mb_raw).strip() != "":
        try:
            mb_i = int(mb_raw)
        except (TypeError, ValueError):
            return {"ok": False, "error": "max_bytes must be an integer"}
        if mb_i < 1:
            return {"ok": False, "error": "max_bytes must be >= 1"}
    bo_raw = args.get("byte_offset")
    bo_i: int | None = None
    if bo_raw is not None and str(bo_raw).strip() != "":
        try:
            bo_i = int(bo_raw)
        except (TypeError, ValueError):
            return {"ok": False, "error": "byte_offset must be an integer"}
        if bo_i < 0:
            return {"ok": False, "error": "byte_offset must be >= 0"}
    return router._fs.read_file(
        args["path"],
        max_bytes=mb_i,
        byte_offset=bo_i,
        align_utf8=bool(args.get("align_utf8", True)),
    )


def _fs_write_file(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.write_file(args["path"], args["content"])


def _fs_delete(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.delete_path(args["path"], dry_run=bool(args.get("dry_run")))


def _fs_mkdir(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.mkdir(args["path"])


def _fs_move(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.move(args["from_path"], args["to_path"])


def _fs_glob(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.glob_names(args["directory"], args["pattern"])


def _fs_search_regex(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.search_content_regex(
        args["directory"],
        args["regex"],
        glob_filter=str(args.get("glob_filter", "*")),
    )


HANDLERS: dict[str, Any] = {
    "fs_list_dir": _fs_list_dir,
    "fs_read_file": _fs_read_file,
    "fs_write_file": _fs_write_file,
    "fs_delete": _fs_delete,
    "fs_mkdir": _fs_mkdir,
    "fs_move": _fs_move,
    "fs_glob": _fs_glob,
    "fs_search_regex": _fs_search_regex,
}
