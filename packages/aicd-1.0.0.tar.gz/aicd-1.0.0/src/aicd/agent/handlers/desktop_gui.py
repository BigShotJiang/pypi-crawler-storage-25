"""桌面 GUI 自动化（非 Web）：窗口枚举/聚焦、截图、键鼠。"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from aicd.agent.tool_args_coerce import coerce_tool_json_array
from aicd.tools.desktop_gui import run_desktop_gui_automation
from aicd.tools.host_desktop_open import open_url_with_browser, reveal_path_in_file_manager

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


async def _desktop_gui_automation(
    router: ToolRouter, args: dict[str, Any]
) -> dict[str, Any]:
    raw = args.get("steps")
    coerced = coerce_tool_json_array(raw, "steps", allow_empty=False)
    if isinstance(coerced, dict):
        return coerced
    steps: list[dict[str, Any]] = []
    for i, item in enumerate(coerced):
        if not isinstance(item, dict):
            return {"ok": False, "error": f"steps[{i}] must be object"}
        steps.append(dict(item))
    return await asyncio.to_thread(
        run_desktop_gui_automation,
        steps=steps,
        policy_check=router._policy.check_allowed,
        cwd=router.cwd,
    )


def _desktop_open_url(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return open_url_with_browser(
        str(args.get("url") or ""),
        policy_check=router._policy.check_allowed,
        block_external_network=bool(router._cfg.agent.block_external_network),
    )


def _desktop_reveal_path(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    ps = args.get("path")
    if ps is None or not str(ps).strip():
        return {"ok": False, "revealed": False, "error": "path is required"}
    target = router._resolve_path(str(ps).strip())
    return reveal_path_in_file_manager(target)


HANDLERS: dict[str, Any] = {
    "desktop_gui_automation": _desktop_gui_automation,
    "desktop_open_url": _desktop_open_url,
    "desktop_reveal_path": _desktop_reveal_path,
}
