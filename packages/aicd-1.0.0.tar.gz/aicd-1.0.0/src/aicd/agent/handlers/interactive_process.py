from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicd.tools.interactive_process import dispatch as interactive_process_dispatch

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


async def _interactive_process(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return await interactive_process_dispatch(router, args)


HANDLERS: dict[str, Any] = {
    "interactive_process": _interactive_process,
}
