from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicd.agent.handlers.net_tools import _web_user_agent
from aicd.tools import site_bookmarks as sb

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _site_bookmarks_list(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return sb.list_entries(
        router._layout["data"],
        tag=args.get("tag"),
        query=args.get("query"),
    )


def _site_bookmarks_get(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return sb.get_entry(
        router._layout["data"],
        entry_id=args.get("entry_id"),
        url=args.get("url"),
    )


async def _site_bookmarks_add(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    wf = router._cfg.integrations.web_fetch
    tags = args.get("tags")
    tag_list: list[str] | None
    if isinstance(tags, list):
        tag_list = [str(x) for x in tags]
    elif tags is None:
        tag_list = None
    else:
        tag_list = None
    return await sb.add_entry(
        router._layout["data"],
        url=str(args.get("url") or ""),
        display_name=args.get("display_name"),
        tags=tag_list,
        notes=args.get("notes"),
        strict_site_root=bool(args.get("strict_site_root", True)),
        allow_single_path_segment=bool(
            args.get("allow_single_path_segment", False)
        ),
        fetch_summary=bool(args.get("fetch_summary", True)),
        user_agent=_web_user_agent(router),
        timeout_sec=float(args.get("timeout_sec") or wf.default_timeout_sec),
        max_bytes=int(args.get("max_response_bytes") or wf.max_response_bytes),
        block_external_network=bool(router._cfg.agent.block_external_network),
    )


async def _site_bookmarks_update(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    wf = router._cfg.integrations.web_fetch
    raw_patch = args.get("patch")
    patch = raw_patch if isinstance(raw_patch, dict) else {}
    return await sb.update_entry(
        router._layout["data"],
        entry_id=str(args.get("entry_id") or ""),
        patch=patch,
        refetch_summary=bool(args.get("refetch_summary", False)),
        user_agent=_web_user_agent(router),
        timeout_sec=float(args.get("timeout_sec") or wf.default_timeout_sec),
        max_bytes=int(args.get("max_response_bytes") or wf.max_response_bytes),
        block_external_network=bool(router._cfg.agent.block_external_network),
    )


def _site_bookmarks_remove(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return sb.remove_entry(
        router._layout["data"],
        entry_id=args.get("entry_id"),
        url=args.get("url"),
    )


HANDLERS: dict[str, Any] = {
    "site_bookmarks_list": _site_bookmarks_list,
    "site_bookmarks_get": _site_bookmarks_get,
    "site_bookmarks_add": _site_bookmarks_add,
    "site_bookmarks_update": _site_bookmarks_update,
    "site_bookmarks_remove": _site_bookmarks_remove,
}
