from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicd.tools.artifact_query import run_artifact_query

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _artifact_query(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    p = router._resolve_path(str(args["path"]))
    return run_artifact_query(
        p,
        str(args.get("operation", "meta")),
        pattern=str(args.get("pattern", "") or ""),
        context_lines=args.get("context_lines", 2),
        max_matches=args.get("max_matches", 80),
        ignore_case=bool(args.get("ignore_case", False)),
        max_scan_bytes=args.get("max_scan_bytes"),
        encoding=str(args.get("encoding", "utf-8") or "utf-8"),
        multiline=bool(args.get("multiline", False)),
        dotall=bool(args.get("dotall", False)),
        json_path=str(args.get("json_path", "") or ""),
        max_json_bytes=args.get("max_json_bytes"),
        max_xml_bytes=args.get("max_xml_bytes"),
        start_line=args.get("start_line", 1),
        max_lines=args.get("max_lines", 200),
    )


HANDLERS = {
    "artifact_query": _artifact_query,
}
