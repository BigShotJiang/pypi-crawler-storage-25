"""子 Agent（task_ai）可选工作流角色：与主会话 /mode plan 配合。

Host / 工具入参规范化（省略 default、统一别名）见 :mod:`aicd.tasks.task_create_helpers` 中的
``parse_task_ai_agent_workflow``；运行时自数据库读取用列 **tasks.agent_workflow**（``task_result`` 等会把列合并进返回的 ``payload``）。
"""

from __future__ import annotations

from typing import Final

SUB_AGENT_WORKFLOW_CANONICAL: Final[frozenset[str]] = frozenset(
    {"default", "planner", "executor", "reviewer", "full_cycle"}
)


def normalize_sub_agent_workflow(raw: object | None) -> str:
    """
    规范化为 ``default`` | ``planner`` | ``executor`` | ``reviewer`` | ``full_cycle``。

    * **full_cycle**：单个子任务内先后做 计划 → 执行 → 自检（仍在一个 task_ai 里完成）。
    """
    if raw is None:
        return "default"
    s = str(raw).strip().lower().replace("-", "_")
    if not s:
        return "default"
    aliases = {
        "plan": "planner",
        "planning": "planner",
        "architect": "planner",
        "build": "executor",
        "implement": "executor",
        "implementation": "executor",
        "ship": "executor",
        "verify": "reviewer",
        "review": "reviewer",
        "qa": "reviewer",
        "audit": "reviewer",
        "per": "full_cycle",
        "plan_execute_review": "full_cycle",
        "cycle": "full_cycle",
    }
    s = aliases.get(s, s)
    if s not in SUB_AGENT_WORKFLOW_CANONICAL:
        raise ValueError(
            "agent_workflow must be one of "
            f"{sorted(SUB_AGENT_WORKFLOW_CANONICAL)} "
            "(or aliases: plan→planner, build→executor, review→reviewer, "
            "plan_execute_review→full_cycle)"
        )
    return s


def resolve_sub_agent_workflow_for_runtime(raw: object | None) -> str:
    """
    与 ``normalize_sub_agent_workflow`` 相同语义，从 **列值或合并后的 payload 字段** 读取时
    **不抛错**：非法或无法识别的值落到 ``default``。
    """
    try:
        return normalize_sub_agent_workflow(raw)
    except ValueError:
        return "default"
