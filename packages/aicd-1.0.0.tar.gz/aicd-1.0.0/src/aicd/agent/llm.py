from __future__ import annotations

import asyncio
import base64
import io
import math
import random
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Protocol

from openai import APIConnectionError, APIStatusError, APITimeoutError, AsyncOpenAI
from PIL import Image

from aicd.agent.model_context_probe import probe_model_context_tokens
from aicd.config import (
    AppConfig,
    LLMConfig,
    effective_llm_config,
    resolve_llm_model_context_window_tokens,
)

if TYPE_CHECKING:
    from aicd.session_log import SessionLogger

_VISION_MIME_BY_EXT: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
}


def _lanczos() -> int:
    try:
        return Image.Resampling.LANCZOS  # type: ignore[attr-defined]
    except AttributeError:
        return Image.LANCZOS


def _merge_api_and_config_window(
    api_tokens: int | None, config_tokens: int | None
) -> int | None:
    """
    ``modelContextTokens`` / profile 写入的配置值**优先于** HTTP 探测；
    未配置时再采用探测值（与 **llm_profile_add** 对 Ollama 的规则一致）。
    """
    if config_tokens is not None and int(config_tokens) > 0:
        return int(config_tokens)
    if api_tokens is not None and int(api_tokens) > 0:
        return int(api_tokens)
    return None


def _combine_main_vision_windows(a: int | None, b: int | None) -> int | None:
    """主模与 vision 各有一扇时取保守 min；仅一侧有值则用该值。"""
    parts = [int(x) for x in (a, b) if x is not None and int(x) > 0]
    if not parts:
        return None
    return min(parts)


def _is_retryable_llm_error(exc: BaseException) -> bool:
    if isinstance(exc, (APITimeoutError, APIConnectionError)):
        return True
    if isinstance(exc, APIStatusError):
        return exc.status_code in (429, 502, 503)
    return False


def image_file_to_data_url_with_meta(
    path: Path,
    *,
    max_long_edge: int = 1920,
    compress_if_source_ge_bytes: int = 1024 * 1024,
    max_encoded_bytes: int = 1024 * 1024,
    hard_max_source_bytes: int = 20 * 1024 * 1024,
) -> tuple[str, dict[str, int]]:
    """
    返回 ``(data_url, meta)``。``meta`` 含 **source_***（磁盘原图像素）与 **sent_***（实际送入多模态 API 的 PNG 像素），
    供 **image_crop** 将模型在「缩小图」上给出的 bbox 映射回原图。
    """
    suf = path.suffix.lower()
    if suf not in _VISION_MIME_BY_EXT:
        raise ValueError(
            f"unsupported image extension {path.suffix!r} (use png/jpg/jpeg/webp/gif)"
        )
    raw = path.read_bytes()
    if len(raw) > hard_max_source_bytes:
        raise ValueError(
            f"image file too large (>{hard_max_source_bytes // (1024 * 1024)}MB): {path}"
        )
    im = Image.open(io.BytesIO(raw))
    im.load()
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGB")
    source_width, source_height = im.size
    w, h = source_width, source_height
    long_edge = max(w, h)
    scale = 1.0
    if long_edge > max_long_edge:
        scale = min(scale, max_long_edge / long_edge)
    if len(raw) >= compress_if_source_ge_bytes:
        scale = min(scale, math.sqrt(compress_if_source_ge_bytes / len(raw)))
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    if nw != w or nh != h:
        im = im.resize((nw, nh), _lanczos())

    min_side_floor = 128
    for _ in range(16):
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True)
        data = buf.getvalue()
        if len(data) <= max_encoded_bytes or min(im.size) <= min_side_floor:
            break
        nw2 = max(1, int(im.width * 0.85))
        nh2 = max(1, int(im.height * 0.85))
        if nw2 == im.width and nh2 == im.height:
            break
        im = im.resize((nw2, nh2), _lanczos())

    b64 = base64.standard_b64encode(data).decode("ascii")
    meta = {
        "source_width": source_width,
        "source_height": source_height,
        "sent_width": im.width,
        "sent_height": im.height,
    }
    return "data:image/png;base64," + b64, meta


def image_file_to_data_url(
    path: Path,
    *,
    max_long_edge: int = 1920,
    compress_if_source_ge_bytes: int = 1024 * 1024,
    max_encoded_bytes: int = 1024 * 1024,
    hard_max_source_bytes: int = 20 * 1024 * 1024,
) -> str:
    """
    将本地图片转为 ``data:image/...;base64,...``，供 OpenAI 兼容多模态接口使用。

    - 任一边长大于 ``max_long_edge``（默认 1920）时按长边缩放到不超过该值。
    - 源文件不小于 ``compress_if_source_ge_bytes``（默认 1MiB）时参与缩放（按像素与体积启发式），
      且编码为 PNG 后若仍大于 ``max_encoded_bytes``（默认 1MiB）则迭代缩小直至满足或达到最小边 128。
    """
    url, _ = image_file_to_data_url_with_meta(
        path,
        max_long_edge=max_long_edge,
        compress_if_source_ge_bytes=compress_if_source_ge_bytes,
        max_encoded_bytes=max_encoded_bytes,
        hard_max_source_bytes=hard_max_source_bytes,
    )
    return url


class LLMClient(Protocol):
    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        ...


def create_llm_client(app_cfg: AppConfig) -> "OpenAICompatibleClient":
    """持有 ``AppConfig`` 引用，便于运行时调整 ``cfg.llm`` 采样参数与模型名。"""
    return OpenAICompatibleClient(app_cfg)


class OpenAICompatibleClient:
    """三种协议均走 OpenAI SDK；按当前 ``cfg.llm`` 组装 ``chat.completions`` 参数。"""

    def __init__(self, app_cfg: AppConfig) -> None:
        self._app_cfg = app_cfg
        self._client: AsyncOpenAI | None = None
        self._client_sig: tuple[str, str] | None = None
        self._session_log: SessionLogger | None = None
        #: HTTP 探测得到的主模上下文窗（与配置表合并前）
        self._api_model_context_tokens: int | None = None
        self._api_model_context_source: str = ""
        self._api_model_context_detail: str = ""
        self._main_probe_signature: tuple[str, str] | None = None
        #: 与主模不同时，vision 模型的探测结果
        self._api_vision_context_tokens: int | None = None
        self._api_vision_context_source: str = ""
        self._api_vision_context_detail: str = ""
        self._vision_probe_signature: tuple[str, str] | None = None

    def attach_session_log(self, slog: SessionLogger | None) -> None:
        """记录 LLM 重试等事件到会话日志（可选）。"""
        self._session_log = slog

    def effective_context_budget_tokens(self, configured_cap: int) -> int:
        """在配置上限与服务端上下文窗口之间取保守值，并预留 completion 空间。"""
        cap = max(4096, min(2_000_000, int(configured_cap)))
        llm = self._app_cfg.llm
        reserve = (
            int(llm.max_output_tokens)
            if llm.max_output_tokens is not None
            else 8192
        )
        reserve = max(1024, min(256_000, reserve))
        raw = self._effective_model_context_window_tokens()
        if raw is None or raw <= 0:
            return cap
        prov = max(4096, int(raw) - reserve)
        return min(cap, prov)

    def _effective_model_context_window_tokens(self) -> int | None:
        llm = self._app_cfg.llm
        eff = effective_llm_config(llm)
        main_id = (eff.model or "").strip()
        vision_id = (llm.vision_model or eff.model or "").strip()
        cfg_main = resolve_llm_model_context_window_tokens(llm, main_id)
        main_m = _merge_api_and_config_window(
            self._api_model_context_tokens, cfg_main
        )
        if not vision_id or vision_id == main_id:
            return main_m
        cfg_vis = resolve_llm_model_context_window_tokens(llm, vision_id)
        vis_m = _merge_api_and_config_window(
            self._api_vision_context_tokens, cfg_vis
        )
        return _combine_main_vision_windows(main_m, vis_m)

    def model_context_meta(self) -> dict[str, Any]:
        llm = self._app_cfg.llm
        eff = effective_llm_config(llm)
        main_id = (eff.model or "").strip()
        vision_id = (llm.vision_model or eff.model or "").strip()
        reserve = (
            int(llm.max_output_tokens)
            if llm.max_output_tokens is not None
            else 8192
        )
        reserve = max(1024, min(256_000, reserve))
        cfg_cap = self._app_cfg.agent.context_budget_tokens
        cfg_main = resolve_llm_model_context_window_tokens(llm, main_id)
        main_m = _merge_api_and_config_window(
            self._api_model_context_tokens, cfg_main
        )
        vis_m: int | None = None
        cfg_vis: int | None = None
        if vision_id and vision_id != main_id:
            cfg_vis = resolve_llm_model_context_window_tokens(llm, vision_id)
            vis_m = _merge_api_and_config_window(
                self._api_vision_context_tokens, cfg_vis
            )
        eff_win = self._effective_model_context_window_tokens()
        return {
            "model_context_window_tokens": eff_win,
            "model_context_window_main_merged": main_m,
            "model_context_window_vision_merged": vis_m,
            "model_context_config_main_tokens": cfg_main,
            "model_context_config_vision_tokens": cfg_vis,
            "model_context_api_main_tokens": self._api_model_context_tokens,
            "model_context_api_vision_tokens": self._api_vision_context_tokens
            if vision_id != main_id
            else None,
            "model_context_probe_source": self._api_model_context_source or None,
            "model_context_probe_detail": self._api_model_context_detail or None,
            "model_context_probe_source_vision": self._api_vision_context_source
            or None
            if vision_id != main_id
            else None,
            "model_context_probe_detail_vision": self._api_vision_context_detail
            or None
            if vision_id != main_id
            else None,
            "completion_reserve_tokens": reserve,
            "context_budget_tokens_configured": cfg_cap,
            "context_budget_tokens_effective": self.effective_context_budget_tokens(
                cfg_cap
            ),
        }

    async def _ensure_model_context_probed(self) -> None:
        eff = effective_llm_config(self._app_cfg.llm)
        llm = self._app_cfg.llm
        main_sig = (eff.base_url, (eff.model or "").strip())
        vision_id = (llm.vision_model or eff.model or "").strip()
        main_ok = self._main_probe_signature == main_sig
        vis_sig = (
            (eff.base_url, vision_id)
            if vision_id and vision_id != (eff.model or "").strip()
            else None
        )
        vis_ok = vis_sig is None or self._vision_probe_signature == vis_sig
        if main_ok and vis_ok:
            return
        await self.probe_model_context(force=True)

    async def probe_model_context(self, *, force: bool = False) -> None:
        """HTTP 探测上下文窗；与 ``llm.modelContextTokens`` / profile 合并时 **配置优先**。"""
        eff = effective_llm_config(self._app_cfg.llm)
        llm = self._app_cfg.llm
        main_sig = (eff.base_url, (eff.model or "").strip())
        vision_id = (llm.vision_model or eff.model or "").strip()
        main_id = (eff.model or "").strip()

        need_main = force or self._main_probe_signature != main_sig
        vis_sig: tuple[str, str] | None = None
        if vision_id and vision_id != main_id:
            vis_sig = (eff.base_url, vision_id)
        need_vision = vis_sig is not None and (
            force or self._vision_probe_signature != vis_sig
        )

        if need_main:
            to, src, detail = await probe_model_context_tokens(
                base_url=eff.base_url,
                api_key=eff.api_key or "",
                model_id=eff.model,
                proto=eff.proto,
                timeout_sec=min(30.0, max(5.0, float(eff.timeout_sec))),
            )
            self._api_model_context_tokens = to
            self._api_model_context_source = src or ""
            self._api_model_context_detail = detail or ""
            self._main_probe_signature = main_sig
            slog = self._session_log
            if slog:
                slog.write_event(
                    "llm",
                    "OpenAICompatibleClient",
                    "model_context_probe",
                    f"model={eff.model!r} source={src} tokens={to}",
                    (detail or "")[:2000],
                )

        if vis_sig is None:
            self._api_vision_context_tokens = None
            self._api_vision_context_source = ""
            self._api_vision_context_detail = ""
            self._vision_probe_signature = None
        elif need_vision:
            vto, vsrc, vdet = await probe_model_context_tokens(
                base_url=eff.base_url,
                api_key=eff.api_key or "",
                model_id=vision_id,
                proto=eff.proto,
                timeout_sec=min(30.0, max(5.0, float(eff.timeout_sec))),
            )
            self._api_vision_context_tokens = vto
            self._api_vision_context_source = vsrc or ""
            self._api_vision_context_detail = vdet or ""
            self._vision_probe_signature = vis_sig
            slog = self._session_log
            if slog:
                slog.write_event(
                    "llm",
                    "OpenAICompatibleClient",
                    "model_context_probe_vision",
                    f"model={vision_id!r} source={vsrc} tokens={vto}",
                    (vdet or "")[:2000],
                )

    def _get_client(self) -> AsyncOpenAI:
        eff = effective_llm_config(self._app_cfg.llm)
        sig = (eff.base_url, eff.api_key or "")
        if self._client is None or self._client_sig != sig:
            kwargs: dict[str, Any] = {"api_key": eff.api_key or "dummy"}
            if eff.base_url:
                kwargs["base_url"] = eff.base_url
            self._client = AsyncOpenAI(**kwargs)
            self._client_sig = sig
        return self._client

    def _completion_kwargs(
        self, llm: LLMConfig, eff: LLMConfig
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": eff.model,
            "timeout": eff.timeout_sec,
        }
        if llm.temperature is not None:
            body["temperature"] = float(llm.temperature)
        if llm.top_p is not None:
            body["top_p"] = float(llm.top_p)
        if llm.frequency_penalty is not None:
            body["frequency_penalty"] = float(llm.frequency_penalty)
        if llm.presence_penalty is not None:
            body["presence_penalty"] = float(llm.presence_penalty)
        if llm.max_output_tokens is not None:
            body["max_tokens"] = int(llm.max_output_tokens)
        extra: dict[str, Any] = {}
        if llm.extra_body:
            extra.update(llm.extra_body)
        if llm.repetition_penalty is not None:
            extra.setdefault("repetition_penalty", float(llm.repetition_penalty))
        if extra:
            body["extra_body"] = extra
        return body

    def _log_retry(
        self, operation: str, attempt_index: int, total_attempts: int, err: str, delay: float
    ) -> None:
        slog = self._session_log
        if slog:
            slog.write_event(
                "llm",
                "OpenAICompatibleClient",
                operation,
                f"retry {attempt_index}/{total_attempts} sleep={delay:.2f}s",
                err[:2000],
            )

    async def _call_chat_completions_with_retry(
        self,
        operation: str,
        call: Callable[[], Awaitable[Any]],
    ) -> Any:
        llm = self._app_cfg.llm
        max_extra = max(0, min(20, int(llm.max_retries)))
        total = max_extra + 1
        base = float(llm.retry_base_delay_sec)
        if base <= 0:
            base = 0.1
        last: BaseException | None = None
        for attempt in range(total):
            try:
                return await call()
            except Exception as e:  # noqa: BLE001
                last = e
                if attempt >= total - 1 or not _is_retryable_llm_error(e):
                    raise
                delay = base * (2**attempt) + random.uniform(
                    0, max(0.05, base * 0.25)
                )
                self._log_retry(
                    operation,
                    attempt + 1,
                    total,
                    repr(e),
                    delay,
                )
                await asyncio.sleep(delay)
        assert last is not None
        raise last

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        await self._ensure_model_context_probed()
        client = self._get_client()
        eff = effective_llm_config(self._app_cfg.llm)
        llm = self._app_cfg.llm
        kw = self._completion_kwargs(llm, eff)

        async def _once() -> Any:
            return await client.chat.completions.create(
                messages=messages,
                tools=tools or [],
                **kw,
            )

        return await self._call_chat_completions_with_retry("chat.completions", _once)

    async def chat_with_images(
        self, user_prompt: str, image_paths: list[Path]
    ) -> dict[str, Any]:
        """
        单次用户消息中含多张图片（OpenAI 兼容 ``image_url`` data URL）。
        模型名：``llm.vision_model`` 或回退 ``llm.model``。

        返回 ``{"analysis": str, "per_image": [{path, source_width, source_height, sent_width, sent_height}, ...]}``。
        **sent_*** 为实际送入 API 的像素尺寸；插入 Word 等应仍使用 **path** 指向的**原始文件**，
        若模型按像素报 bbox，应对 **原图** 调用 **image_crop** 并传入 **bbox_reference_width/height = sent_***。
        """
        if not image_paths:
            raise ValueError("image_paths must be non-empty")
        if len(image_paths) > 10:
            raise ValueError("at most 10 images per vision request")
        await self._ensure_model_context_probed()
        eff = effective_llm_config(self._app_cfg.llm)
        llm = self._app_cfg.llm
        model = (llm.vision_model or eff.model).strip()
        content: list[dict[str, Any]] = [{"type": "text", "text": user_prompt}]
        per_image: list[dict[str, Any]] = []
        for p in image_paths:
            pr = p.resolve()
            url, meta = image_file_to_data_url_with_meta(pr)
            per_image.append(
                {
                    "path": str(pr),
                    "source_width": meta["source_width"],
                    "source_height": meta["source_height"],
                    "sent_width": meta["sent_width"],
                    "sent_height": meta["sent_height"],
                }
            )
            content.append({"type": "image_url", "image_url": {"url": url}})
        messages: list[dict[str, Any]] = [{"role": "user", "content": content}]
        client = self._get_client()
        kw = self._completion_kwargs(llm, eff)
        kw["model"] = model

        async def _once() -> Any:
            return await client.chat.completions.create(messages=messages, **kw)

        resp = await self._call_chat_completions_with_retry(
            "chat.completions.vision",
            _once,
        )
        msg = resp.choices[0].message
        text = (msg.content or "").strip()
        return {"analysis": text, "per_image": per_image}
