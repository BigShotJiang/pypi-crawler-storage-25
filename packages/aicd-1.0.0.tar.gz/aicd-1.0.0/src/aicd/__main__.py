from aicd.cli_encoding import configure_cli_utf8

configure_cli_utf8()

from aicd.app import main

if __name__ == "__main__":
    main()
