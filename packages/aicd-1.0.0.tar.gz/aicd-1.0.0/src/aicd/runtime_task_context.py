"""Per-async-task context for nested `task_ai` workers (parent links, scratch paths, messaging)."""

from __future__ import annotations

from contextvars import ContextVar

current_task_id: ContextVar[str | None] = ContextVar("current_task_id", default=None)
