from __future__ import annotations

import re

_TOPIC_SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9_-]{0,79})?$")
# UUID / short hex ids / simple slugs used as task ids
_SAFE_TASK_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")


def validate_topic_slug(raw: str | None) -> str | None:
    if raw is None:
        return None
    s = raw.strip().lower()
    if not s:
        return None
    if not _TOPIC_SLUG_RE.match(s):
        raise ValueError(
            "topic_slug must be non-empty, lowercase, and match "
            "^[a-z0-9][a-z0-9_-]{0,79}$ (user-visible deliverables folder segment)"
        )
    return s


def is_safe_task_id(task_id: str) -> bool:
    if not task_id or ".." in task_id or "/" in task_id or "\\" in task_id:
        return False
    return bool(_SAFE_TASK_ID_RE.match(task_id))
