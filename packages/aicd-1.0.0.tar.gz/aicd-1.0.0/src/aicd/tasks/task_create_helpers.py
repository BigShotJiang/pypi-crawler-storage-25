"""Host / 工具 / TUI 共用的后台任务创建入参整理（避免散落重复逻辑）。"""

from __future__ import annotations

from aicd.agent.workflow_profile import normalize_sub_agent_workflow
from aicd.tasks.safe_ids import validate_topic_slug


def thread_root_id_when_no_parent(
    *,
    parent_id: str | None,
    chat_session_id: object | None,
) -> str | None:
    """
    顶层任务（无有效 parent）时，用主会话 id 写入 ``thread_root_id``，与主对话对齐；
    嵌套子任务返回 ``None``（由 :meth:`TaskManager.create_ai_task` 等从 parent 继承）。
    """
    if parent_id is not None and str(parent_id).strip():
        return None
    if isinstance(chat_session_id, str) and chat_session_id.strip():
        return chat_session_id.strip()
    return None


def read_only_paths_coerce(raw: object | None) -> list[str] | None:
    """``task_ai`` 的 ``read_only_paths``：非 list 或空表视为 ``None``（与入库前 strip 一致）。"""
    if not isinstance(raw, list):
        return None
    out = [str(x).strip() for x in raw if isinstance(x, str) and x.strip()]
    return out if out else None


def coerce_task_estimated_steps(raw: object | None) -> int | None:
    """工具入参里的 ``estimated_steps``：无法解析为 int 时返回 ``None``。"""
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def parse_task_ai_topic_slug(topic: object | None) -> tuple[str | None, str | None]:
    """
    解析 ``topic_slug``。返回 ``(slug, error)``：
    缺失或空 → ``(None, None)``；非法 → ``(None, message)``。
    """
    if topic is None:
        return None, None
    if not isinstance(topic, str) or not topic.strip():
        return None, None
    try:
        return validate_topic_slug(topic.strip()), None
    except ValueError as e:
        return None, str(e)


def parse_task_ai_agent_workflow(raw: object | None) -> tuple[str | None, str | None]:
    """
    Host / ``task_ai`` 工具边界使用。返回 ``(value_for_create_ai_task, error)``：

    * 省略、空串、或规范化后为 ``default`` → ``(None, None)``（payload 不存该字段）。
    * 其它合法角色 → ``("planner"|…, None)``。
    * 非法 → ``(None, err)``。
    """
    if raw is None:
        return None, None
    if not str(raw).strip():
        return None, None
    try:
        canon = normalize_sub_agent_workflow(raw)
    except ValueError as e:
        return None, str(e)
    if canon == "default":
        return None, None
    return canon, None
