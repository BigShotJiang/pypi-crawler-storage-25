from __future__ import annotations

from typing import Any

from aicd.network_policy import outbound_tool_url_blocked_reason
from aicd.tools.browser_automation import (
    build_chromium_launch_kwargs,
    playwright_chromium_launch_hint,
)


class BrowserCDP:
    """Playwright-based headless control (CDP-compatible stack)."""

    async def navigate(
        self,
        url: str,
        wait_until: str = "load",
        timeout_ms: float = 60_000,
        *,
        block_external_network: bool = False,
        headless: bool = True,
        browser_channel: str | None = None,
        executable_path: str | None = None,
    ) -> dict[str, Any]:
        br = outbound_tool_url_blocked_reason(
            url, block_external=block_external_network
        )
        if br:
            return {
                "ok": False,
                "error": br,
                "network_policy": "block_external_network",
            }
        try:
            from playwright.async_api import async_playwright
        except ImportError as e:
            return {
                "ok": False,
                "error": f"playwright not available: {e}",
                "hint": "pip install playwright && python -m playwright install chromium",
            }
        try:
            launch_kw = build_chromium_launch_kwargs(
                headless=bool(headless),
                slow_mo_ms=None,
                browser_channel=browser_channel,
                executable_path=executable_path,
            )
        except ValueError as e:
            return {"ok": False, "error": str(e)}
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(**launch_kw)
                page = await browser.new_page()
                try:
                    await page.goto(
                        url, wait_until=wait_until, timeout=int(timeout_ms)
                    )
                    title = await page.title()
                    content = await page.content()
                finally:
                    await browser.close()
        except Exception as e:
            return {
                "ok": False,
                "error": str(e),
                "hint": playwright_chromium_launch_hint(str(e)),
            }
        snippet = content[:8000] + ("..." if len(content) > 8000 else "")
        return {
            "ok": True,
            "title": title,
            "url": url,
            "html_snippet": snippet,
        }
