"""使用 XlsxWriter 生成 .xlsx（可选依赖）：侧重格式、列宽、冻结窗格等，不替代 openpyxl 读写/补丁。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from aicd.tools.office_text_norm import normalize_office_newlines

MAX_SHEETS = 20
MAX_ROWS_PER_SHEET = 5000
MAX_COLS = 256


def _policy_touch(path: Path, policy_check: Callable[[Path], None]) -> Path:
    path = path.expanduser().resolve()
    policy_check(path)
    return path


def _coerce_cell(val: Any) -> tuple[str, Any | None]:
    """返回 (literal|formula, value)。"""
    if val is None:
        return ("literal", None)
    if isinstance(val, dict):
        if "formula" in val and val["formula"] is not None:
            return ("formula", str(val["formula"]))
        if "value" in val:
            return _coerce_cell(val["value"])
        return ("literal", None)
    if isinstance(val, (list, tuple)) and len(val) == 2 and str(val[0]).lower() == "formula":
        return ("formula", str(val[1]))
    if isinstance(val, str) and val.strip().startswith("="):
        return ("formula", val)
    if isinstance(val, str):
        return ("literal", normalize_office_newlines(val))
    return ("literal", val)


def _xf_header(workbook: Any, hf: dict[str, Any] | None) -> Any:
    if not hf:
        return workbook.add_format({"bold": True})
    fmt: dict[str, Any] = {}
    if hf.get("bold") is not None:
        fmt["bold"] = bool(hf["bold"])
    if hf.get("font_size") is not None:
        fmt["font_size"] = int(hf["font_size"])
    if hf.get("font_color"):
        fmt["font_color"] = str(hf["font_color"]).lstrip("#")
    if hf.get("bg_color"):
        fmt["bg_color"] = str(hf["bg_color"]).lstrip("#")
    if hf.get("border"):
        fmt["border"] = 1
    return workbook.add_format(fmt)


def xlsx_write_xlsxwriter(
    path: Path,
    sheets: list[dict[str, Any]],
    *,
    policy_check: Callable[[Path], None],
) -> dict[str, Any]:
    """
    新建 .xlsx（**整本重写**，与 ``xlsx_write_workbook`` 的 **append** 语义不同）。

    文本单元格/合并区 ``text`` 内的换行：``\\n`` 会规范为 **CRLF**；调用方宜优先使用 **``\\r\\n``**。

    ``sheets`` 每项:
    - ``name``, 可选 ``headers``, ``rows``（单元格可为字面量、``=公式``、``{\"formula\":\"=A1+B1\"}``、``[\"formula\",\"=A1\"]``）
    - ``column_widths``: 可选，列表，每列宽度（XlsxWriter 字符单位）
    - ``freeze_panes``: 可选 ``{row, col}`` — **0-based**，在下一行/列起冻结
    - ``header_format``: 可选 ``{bold, font_size, font_color, bg_color, border}``
    - ``merge_ranges``: 可选 ``[{first_row, first_col, last_row, last_col, text?}]`` — **0-based**
    """
    try:
        import xlsxwriter  # noqa: PLC0415
    except ImportError as e:
        return {
            "ok": False,
            "error": f"xlsxwriter not installed: {e}",
            "hint": "pip install 'aicd[xlsxwriter]' 或 pip install XlsxWriter",
        }

    if not isinstance(sheets, list) or not sheets:
        return {"ok": False, "error": "sheets must be non-empty list"}
    if len(sheets) > MAX_SHEETS:
        return {"ok": False, "error": f"max {MAX_SHEETS} sheets"}

    out_path = _policy_touch(path, policy_check)
    if out_path.suffix.lower() != ".xlsx":
        return {"ok": False, "error": "path must end with .xlsx"}
    out_path.parent.mkdir(parents=True, exist_ok=True)

    workbook = xlsxwriter.Workbook(str(out_path))

    def _fail(msg: str) -> dict[str, Any]:
        try:
            workbook.close()
        except Exception:
            pass
        try:
            out_path.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "error": msg}

    try:
        for spec in sheets:
            if not isinstance(spec, dict):
                return _fail("each sheet must be object")
            name = spec.get("name") or "Sheet"
            if not isinstance(name, str):
                return _fail("sheet name must be string")
            name = name[:31] if len(name) > 31 else name

            headers = spec.get("headers")
            rows = spec.get("rows") or []
            if headers is not None and not isinstance(headers, (list, tuple)):
                return _fail("headers must be list")
            if not isinstance(rows, list):
                return _fail("rows must be list")

            n_header = 1 if headers else 0
            n_data = len(rows)
            if n_header + n_data > MAX_ROWS_PER_SHEET:
                return _fail(f"max {MAX_ROWS_PER_SHEET} rows per sheet")

            ws = workbook.add_worksheet(name)
            hf_raw = spec.get("header_format")
            hfm = hf_raw if isinstance(hf_raw, dict) else None
            hfmt = _xf_header(workbook, hfm)
            plain = workbook.add_format({})

            merges = spec.get("merge_ranges")
            if merges is not None:
                if not isinstance(merges, list):
                    return _fail("merge_ranges must be list")
                for mi, m in enumerate(merges):
                    if not isinstance(m, dict):
                        return _fail(f"merge_ranges[{mi}] must be object")
                    try:
                        fr = int(m["first_row"])
                        fc = int(m["first_col"])
                        lr = int(m["last_row"])
                        lc = int(m["last_col"])
                    except (KeyError, TypeError, ValueError):
                        return _fail(
                            f"merge_ranges[{mi}] needs first_row, first_col, last_row, last_col"
                        )
                    tx = m.get("text")
                    if tx is not None:
                        ws.merge_range(
                            fr, fc, lr, lc, normalize_office_newlines(str(tx)), plain
                        )
                    else:
                        ws.merge_range(fr, fc, lr, lc, "", plain)

            r0 = 0
            if headers:
                if len(headers) > MAX_COLS:
                    return _fail(f"max {MAX_COLS} columns")
                for c, h in enumerate(headers):
                    hv = (
                        normalize_office_newlines(str(h))
                        if isinstance(h, str)
                        else h
                    )
                    ws.write(r0, c, hv, hfmt)
                r0 = 1

            for ri, row in enumerate(rows):
                if not isinstance(row, (list, tuple)):
                    return _fail(f"rows[{ri}] must be array")
                if len(row) > MAX_COLS:
                    return _fail(f"max {MAX_COLS} columns")
                for c, cell in enumerate(row):
                    kind, v = _coerce_cell(cell)
                    if kind == "formula" and v is not None:
                        ws.write_formula(r0 + ri, c, str(v), plain)
                    else:
                        ws.write(r0 + ri, c, v, plain)

            cwidths = spec.get("column_widths")
            if isinstance(cwidths, list) and cwidths:
                for c, w in enumerate(cwidths):
                    if w is None:
                        continue
                    try:
                        ws.set_column(c, c, float(w))
                    except (TypeError, ValueError):
                        pass

            fp = spec.get("freeze_panes")
            if isinstance(fp, dict):
                try:
                    fr = int(fp.get("row", 0))
                    fc = int(fp.get("col", 0))
                    ws.freeze_panes(fr, fc)
                except (TypeError, ValueError):
                    pass

        workbook.close()
    except Exception as e:  # noqa: BLE001
        try:
            workbook.close()
        except Exception:
            pass
        try:
            out_path.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "error": str(e)}

    return {
        "ok": True,
        "path": str(out_path),
        "engine": "xlsxwriter",
        "note": "新建工作簿；读表/补丁已有文件仍用 xlsx_read_workbook / xlsx_patch_workbook（openpyxl）。",
    }
