"""大文档按标题层级与可选最大字节数切块。

输出：**``<output_dir>/chunks/*.md``** + **``chunks/index.json``**（schema 见 **``doc_analysis_kit``**）。
通常接在 **``doc_normalize``** / **``document_outline``** 之后，当单节仍过大时使用。
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from aicd.tools.doc_analysis_kit import (
    CHUNK_INDEX_NAME,
    CHUNKS_SUBDIR,
    SCHEMA_CHUNK_INDEX,
    clamp_heading_level,
    source_stat_from_path,
)
from aicd.tools.document_outline import build_outline_payload
from aicd.tools.fs_tool import _decode_utf8_range


def _slugify(title: str, fallback: str) -> str:
    base = (title or fallback).strip()[:80]
    s = re.sub(r"[^\w\u4e00-\u9fff]+", "_", base, flags=re.UNICODE).strip("_")
    return s[:60] if s else "chunk"


def _read_range_bytes(path: Path, start: int, end: int) -> bytes:
    with path.open("rb") as f:
        f.seek(start)
        return f.read(max(0, end - start))


def run_markdown_chunk_split(
    doc_path: Path,
    output_dir: Path,
    *,
    split_max_level: int = 3,
    max_chunk_bytes: int | None = None,
    excerpt_len: int = 400,
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """
    - **split_max_level**：在该级别及更高级别的标题处切开（例如 **3** → H1–H3 起始边界）。
    - **max_chunk_bytes**：单块 UTF-8 字节上限；超出则在同一段内再按字节切分。
    """
    src = doc_path.expanduser().resolve()
    if not src.is_file():
        return {"ok": False, "error": f"not a file: {src}"}
    base = output_dir.expanduser().resolve()
    chunks_dir = base / CHUNKS_SUBDIR
    chunks_dir.mkdir(parents=True, exist_ok=True)

    try:
        source_stat = source_stat_from_path(src)
    except OSError as e:
        return {"ok": False, "error": str(e)}
    file_sz = source_stat["size"]

    sml = clamp_heading_level(split_max_level)
    pl = build_outline_payload(src, max_heading_level=6)
    headings: list[dict[str, Any]] = list(pl.get("headings") or [])
    split_idx = [i for i, h in enumerate(headings) if int(h.get("level") or 99) <= sml]

    boundary_bytes: list[int] = [0]
    title_at: dict[int, str] = {0: ""}
    for i in split_idx:
        bo = int(headings[i]["byte_offset"])
        boundary_bytes.append(bo)
        title_at[bo] = str(headings[i].get("text") or "").strip()
    boundary_bytes = sorted(set(boundary_bytes))

    segments: list[tuple[int, int, str]] = []
    for k, sb in enumerate(boundary_bytes):
        eb = boundary_bytes[k + 1] if k + 1 < len(boundary_bytes) else file_sz
        if eb <= sb:
            continue
        segments.append((sb, eb, title_at.get(sb, "")))

    if not segments:
        segments = [(0, file_sz, "")]

    ex_len = max(0, min(4000, int(excerpt_len)))
    index_chunks: list[dict[str, Any]] = []
    file_counter = 0

    cap: int | None = None
    if max_chunk_bytes is not None:
        cap = max(4096, int(max_chunk_bytes))

    for sb, eb, heading_title in segments:
        if cap is None or (eb - sb) <= cap:
            file_counter += 1
            blob = _read_range_bytes(src, sb, eb)
            text, _, _ = _decode_utf8_range(blob, file_offset=sb)
            excerpt = text[:ex_len] if ex_len else ""
            slug = _slugify(heading_title, f"chunk_{file_counter:03d}")
            fname = f"{file_counter:03d}_{slug}.md"
            out_p = chunks_dir / fname
            out_p.write_text(text, encoding=encoding)
            index_chunks.append(
                {
                    "file": fname,
                    "path": str(out_p.resolve()),
                    "heading": heading_title,
                    "start_byte": sb,
                    "end_byte": eb,
                    "char_count": len(text),
                    "excerpt": excerpt,
                }
            )
            continue

        pos = sb
        part = 0
        while pos < eb:
            file_counter += 1
            part += 1
            take = min(cap, eb - pos)
            blob = _read_range_bytes(src, pos, pos + take)
            text, _, _ = _decode_utf8_range(blob, file_offset=pos)
            excerpt = text[:ex_len] if ex_len else ""
            if heading_title:
                ht = f"{heading_title} (part {part})"
            else:
                ht = f"part_{part}"
            slug = _slugify(ht, f"chunk_{file_counter:03d}")
            fname = f"{file_counter:03d}_{slug}.md"
            out_p = chunks_dir / fname
            out_p.write_text(text, encoding=encoding)
            pos_end = pos + len(blob)
            index_chunks.append(
                {
                    "file": fname,
                    "path": str(out_p.resolve()),
                    "heading": ht,
                    "start_byte": pos,
                    "end_byte": min(pos_end, eb),
                    "char_count": len(text),
                    "excerpt": excerpt,
                }
            )
            pos = pos_end

    idx_path = chunks_dir / CHUNK_INDEX_NAME
    idx_body = {
        "schema": SCHEMA_CHUNK_INDEX,
        "source_path": str(src),
        "source_stat": source_stat,
        "split_max_level": sml,
        "max_chunk_bytes": cap,
        "chunk_count": len(index_chunks),
        "chunks": index_chunks,
    }
    idx_path.write_text(
        json.dumps(idx_body, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return {
        "ok": True,
        "chunks_dir": str(chunks_dir),
        "index_path": str(idx_path.resolve()),
        "chunk_count": len(index_chunks),
        "source_path": str(src),
    }
