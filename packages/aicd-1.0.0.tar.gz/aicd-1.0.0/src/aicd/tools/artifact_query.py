"""大文件落地后的结构化访问：元信息、按行/块正则、JSON path、XML 扁平遍历。"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from aicd.kit.format_data import op_json_path_get, op_xml_parse_flat
from aicd.tools.markdown_regex_scan import run_markdown_regex_scan

MAX_META_HEAD = 8_000
DEFAULT_REGEX_SCAN_BYTES = 2_000_000
DEFAULT_JSON_BYTES = 16_000_000
DEFAULT_XML_BYTES = 2_000_000


def _clamp_int(v: Any, lo: int, hi: int, default: int) -> int:
    try:
        x = int(v)
    except (TypeError, ValueError):
        x = default
    return max(lo, min(hi, x))


def run_artifact_query(
    path: Path,
    operation: str,
    *,
    # regex line (streamed)
    pattern: str = "",
    context_lines: int = 2,
    max_matches: int = 80,
    ignore_case: bool = False,
    max_scan_bytes: int = DEFAULT_REGEX_SCAN_BYTES,
    encoding: str = "utf-8",
    # regex multiline (first N bytes)
    multiline: bool = False,
    dotall: bool = False,
    # json_path
    json_path: str = "",
    max_json_bytes: int = DEFAULT_JSON_BYTES,
    # xml_flat
    max_xml_bytes: int = DEFAULT_XML_BYTES,
    # line window
    start_line: int = 1,
    max_lines: int = 200,
) -> dict[str, Any]:
    op_raw = (operation or "").strip().lower().replace("-", "_")
    p = path.expanduser().resolve()
    if not p.is_file():
        return {"ok": False, "error": f"not a file: {p}"}

    if op_raw in ("meta", "file_meta", "stat"):
        try:
            st = p.stat()
        except OSError as e:
            return {"ok": False, "error": str(e)}
        head = ""
        try:
            with p.open("r", encoding=encoding, errors="replace", newline="") as f:
                head = f.read(MAX_META_HEAD)
        except OSError as e:
            return {"ok": False, "error": f"read head: {e}"}
        return {
            "ok": True,
            "path": str(p),
            "size_bytes": st.st_size,
            "encoding_hint": encoding,
            "head_preview": head,
            "head_preview_chars": len(head),
            "note": "Full body on disk; use line_range|regex|json_path|xml_flat or fs_read_file byte_offset.",
        }

    if op_raw in ("regex_lines", "line_regex", "grep_lines"):
        if not pattern.strip():
            return {"ok": False, "error": "pattern required"}
        return run_markdown_regex_scan(
            p,
            pattern,
            context_lines=_clamp_int(context_lines, 0, 20, 2),
            max_matches=_clamp_int(max_matches, 1, 500, 80),
            ignore_case=bool(ignore_case),
            encoding=encoding,
        )

    if op_raw in ("regex_multiline", "multiline_regex"):
        if not pattern.strip():
            return {"ok": False, "error": "pattern required"}
        try:
            size = p.stat().st_size
        except OSError as e:
            return {"ok": False, "error": str(e)}
        lim_b = _clamp_int(
            max_scan_bytes, 4096, 50_000_000, DEFAULT_REGEX_SCAN_BYTES
        )
        to_read = min(lim_b, size)
        try:
            with p.open("rb") as f:
                raw = f.read(to_read)
        except OSError as e:
            return {"ok": False, "error": str(e)}
        text = raw.decode(encoding, errors="replace")
        flags = re.MULTILINE if multiline else 0
        if dotall:
            flags |= re.DOTALL
        if ignore_case:
            flags |= re.IGNORECASE
        try:
            rx = re.compile(pattern, flags)
        except re.error as e:
            return {"ok": False, "error": f"invalid regex: {e}"}
        cap = _clamp_int(max_matches, 1, 2000, 80)
        matches: list[dict[str, Any]] = []
        for i, m in enumerate(rx.finditer(text)):
            if i >= cap:
                break
            matches.append(
                {
                    "start": m.start(),
                    "end": m.end(),
                    "match": (m.group(0) or "")[:4000],
                }
            )
        return {
            "ok": True,
            "matches": matches,
            "match_count": len(matches),
            "scanned_chars": len(text),
            "file_size_bytes": size,
            "truncated_scan": size > to_read,
        }

    if op_raw in ("json_path", "json_get_path"):
        jp = (json_path or "").strip()
        if not jp:
            return {"ok": False, "error": "json_path required (dot notation, e.g. items.0.id)"}
        lim_b = _clamp_int(max_json_bytes, 1024, 50_000_000, DEFAULT_JSON_BYTES)
        try:
            size = p.stat().st_size
        except OSError as e:
            return {"ok": False, "error": str(e)}
        if size > lim_b:
            return {
                "ok": False,
                "error": f"file {size} bytes exceeds max_json_bytes={lim_b}",
                "hint": "Use fs_read_file with byte_offset to inspect a slice, or split the file.",
            }
        try:
            raw_txt = p.read_text(encoding=encoding, errors="strict")
        except UnicodeDecodeError:
            try:
                raw_txt = p.read_text(encoding=encoding, errors="replace")
            except OSError as e:
                return {"ok": False, "error": str(e)}
        except OSError as e:
            return {"ok": False, "error": str(e)}
        return op_json_path_get({"text": raw_txt, "path": jp})

    if op_raw in ("xml_flat", "xml_parse_flat"):
        lim_b = _clamp_int(max_xml_bytes, 1024, 20_000_000, DEFAULT_XML_BYTES)
        try:
            size = p.stat().st_size
        except OSError as e:
            return {"ok": False, "error": str(e)}
        if size > lim_b:
            return {
                "ok": False,
                "error": f"file {size} bytes exceeds max_xml_bytes={lim_b}",
            }
        try:
            xml_text = p.read_text(encoding=encoding, errors="replace")
        except OSError as e:
            return {"ok": False, "error": str(e)}
        return op_xml_parse_flat({"xml": xml_text})

    if op_raw in ("line_range", "lines", "line_window"):
        sl = _clamp_int(start_line, 1, 10_000_000, 1)
        ml = _clamp_int(max_lines, 1, 10_000, 200)
        lines_out: list[str] = []
        n = 0
        truncated_tail = False
        try:
            with p.open("r", encoding=encoding, errors="replace", newline="") as f:
                for i, line in enumerate(f, start=1):
                    if i < sl:
                        continue
                    if n >= ml:
                        truncated_tail = True
                        break
                    lines_out.append(line.rstrip("\r\n"))
                    n += 1
        except OSError as e:
            return {"ok": False, "error": str(e)}
        return {
            "ok": True,
            "start_line": sl,
            "lines_returned": len(lines_out),
            "lines": lines_out,
            "truncated": truncated_tail,
        }

    return {
        "ok": False,
        "error": f"unknown operation: {operation!r}",
        "hint": "meta|regex_lines|regex_multiline|json_path|xml_flat|line_range",
    }
