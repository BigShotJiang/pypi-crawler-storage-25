"""文档库项目清单：目录树、内容清单、资源索引与快照。"""

from __future__ import annotations

from aicd.tools.doc_project.kit import (
    attribution_footer_markdown,
    doc_manifest_coverage_report,
    doc_manifest_validate,
    doc_project_export,
    doc_revision_diff_summary,
    doc_text_health_check,
    get_doc_project,
    init_doc_project,
    library_doc_batch_quality_pass,
    library_doc_node_resolve,
    library_doc_snapshot,
    library_resources_scan,
    patch_doc_project,
)

__all__ = [
    "attribution_footer_markdown",
    "doc_manifest_coverage_report",
    "doc_manifest_validate",
    "doc_project_export",
    "doc_revision_diff_summary",
    "doc_text_health_check",
    "get_doc_project",
    "init_doc_project",
    "library_doc_batch_quality_pass",
    "library_doc_node_resolve",
    "library_doc_snapshot",
    "library_resources_scan",
    "patch_doc_project",
]
