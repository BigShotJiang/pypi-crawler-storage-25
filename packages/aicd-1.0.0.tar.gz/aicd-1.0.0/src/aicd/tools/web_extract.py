"""从 HTML 中提取正文（优先 trafilatura，减轻广告/导航噪声）。"""

from __future__ import annotations

import re
from typing import Any

# 与 trafilatura 文本上限配合，避免超大页撑爆内存
_MAX_HTML_INPUT = 2_000_000


def _naive_html_to_text(html: str, *, max_chars: int) -> str:
    t = re.sub(r"(?is)<script[^>]*>.*?</script>", " ", html)
    t = re.sub(r"(?is)<style[^>]*>.*?</style>", " ", t)
    t = re.sub(r"(?is)<noscript[^>]*>.*?</noscript>", " ", t)
    t = re.sub(r"(?is)<[^>]+>", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > max_chars:
        return t[:max_chars]
    return t


def extract_main_text_from_html(
    html: str,
    url: str,
    *,
    max_chars: int = 500_000,
) -> tuple[str, dict[str, Any]]:
    """
    返回 ``(text, meta)``。``meta`` 含 ``engine``：``trafilatura`` | ``naive`` | ``empty``。
    未安装 trafilatura 时 ``meta.install_suggestions`` 提示 ``pip install aicd[web]``。
    """
    meta: dict[str, Any] = {"engine": "empty", "url": url}
    if not html or not html.strip():
        return "", meta
    chunk = html[:_MAX_HTML_INPUT] if len(html) > _MAX_HTML_INPUT else html
    if len(html) > _MAX_HTML_INPUT:
        meta["html_truncated_input"] = True

    try:
        import trafilatura  # noqa: PLC0415

        extracted = trafilatura.extract(
            chunk,
            url=url or None,
            include_comments=False,
            include_tables=True,
            favor_precision=True,
        )
        if extracted and str(extracted).strip():
            text = str(extracted).strip()
            meta["engine"] = "trafilatura"
            if len(text) > max_chars:
                text = text[:max_chars]
                meta["truncated"] = True
            return text, meta
        meta["engine"] = "trafilatura"
        meta["note"] = "trafilatura returned empty; fallback naive"
    except ImportError:
        meta["trafilatura_missing"] = True
        meta["install_suggestions"] = [
            'pip install "aicd[web]"',
            "pip install trafilatura",
        ]

    text = _naive_html_to_text(chunk, max_chars=max_chars)
    meta["engine"] = "naive" if text else "empty"
    if meta.get("trafilatura_missing"):
        meta["hint"] = (
            "已用简易去标签提取，广告/页眉页脚可能仍在；安装 trafilatura 可显著改善正文抽取"
        )
    return text, meta
