"""全静态 HTML 站点：目录导航、多页、PPT 式轮播（见 ``bundle`` 模块）。"""

from aicd.tools.static_site.bundle import normalize_static_bundle_mode, run_static_html_bundle

__all__ = ["normalize_static_bundle_mode", "run_static_html_bundle"]
