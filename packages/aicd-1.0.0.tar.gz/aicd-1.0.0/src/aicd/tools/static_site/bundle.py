"""全静态站点生成：单页 TOC、多页导航、轮播 deck、可选 data/*.json 与 site.json。"""

from __future__ import annotations

import html
import json
import os
import re
from pathlib import Path
from typing import Any

from aicd.tools.viz_assets import (
    CHART_JS,
    MERMAID_JS,
    VIS_CSS,
    VIS_JS,
    copy_viz_resources,
)

SITE_SCHEMA_VERSION = "aicd.static_site.v1_1"

_PRINT_CSS_BLOCK = """
  @media print {
    .aicd-toc-nav, .aicd-site-nav { position: static !important; break-inside: avoid; }
    .aicd-toc-layout { grid-template-columns: 1fr !important; }
    .aicd-subpage-header { background: none !important; border-color: #ccc !important; }
    .aicd-deck-bar, .aicd-deck-footer, .aicd-deck-dots { display: none !important; }
    .aicd-deck-viewport { position: static !important; overflow: visible !important; }
    .aicd-slide { position: static !important; opacity: 1 !important; display: block !important; break-after: page; page-break-after: always; min-height: auto !important; }
    html, body { height: auto !important; overflow: visible !important; }
  }
"""

_SITE_TREE_STOPPROP_JS = """
<script>
(function () {
  document.querySelectorAll(".aicd-tree-summary a").forEach(function (a) {
    a.addEventListener("click", function (e) { e.stopPropagation(); });
  });
})();
</script>
"""

# 用户/工具传入的 mode 别名 → 规范名（写入 site.json、日志可读）
MODE_ALIASES: dict[str, str] = {
    "single_toc": "single_toc",
    "single": "single_toc",
    "toc": "single_toc",
    "multi_page": "multi_page",
    "site": "multi_page",
    "multipage": "multi_page",
    "slide_deck": "slide_deck",
    "deck": "slide_deck",
    "slides": "slide_deck",
}

_FORBIDDEN_URL = re.compile(
    r"https?://[^\s\"'<>]+",
    flags=re.IGNORECASE,
)


def _assert_no_remote_urls(fragment: str, *, where: str) -> None:
    m = _FORBIDDEN_URL.search(fragment or "")
    if m:
        raise ValueError(f"{where}: 禁止外链 http(s) URL：{m.group(0)!r}")


def normalize_static_bundle_mode(mode: str) -> tuple[str, str]:
    """返回 ``(规范化键, 标准 mode 名)``；未知则第二项与键相同。"""
    key = mode.strip().lower().replace("-", "_")
    canonical = MODE_ALIASES.get(key, key)
    return key, canonical


def _path_is_under(parent: Path, child: Path) -> bool:
    """``child`` 是否位于 ``parent`` 目录下（解析后比较，比字符串 startswith 更可靠）。"""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _href_to_site_index(*, page_file: Path, site_root: Path) -> str:
    """从子页文件到站点根 ``index.html`` 的相对 URL（POSIX）。"""
    idx = (site_root / "index.html").resolve()
    return Path(os.path.relpath(idx, page_file.parent.resolve())).as_posix()


def _subpage_top_chrome(*, site_title: str, rel_path: str, index_href: str) -> str:
    parts = [html.escape(x, quote=False) for x in Path(rel_path.replace("\\", "/")).parts]
    crumb_el = (
        '<span class="aicd-subpage-crumb">' + " › ".join(parts) + "</span>" if parts else ""
    )
    return f"""
<header class="aicd-subpage-header">
  <nav class="aicd-subpage-topnav" aria-label="站内导航">
    <a class="aicd-subpage-home" href="{html.escape(index_href, quote=True)}">← {html.escape(site_title, quote=False)}</a>
    {crumb_el}
  </nav>
</header>
"""


_SUBPAGE_STYLES = """
<style>
  .aicd-subpage-header { border-bottom: 1px solid #e5e7eb; margin: -1rem -1rem 1rem -1rem; padding: 0.6rem 1rem; background: #f8fafc; }
  .aicd-subpage-topnav { display: flex; flex-wrap: wrap; align-items: center; gap: 0.75rem; font-size: 0.9rem; }
  .aicd-subpage-home { font-weight: 600; color: #1d4ed8; text-decoration: none; }
  .aicd-subpage-home:hover { text-decoration: underline; }
  .aicd-subpage-crumb { color: #64748b; font-size: 0.82rem; }
</style>
"""


def _offline_data_demo_snippet(data_rel_paths: list[str], *, dark: bool = False) -> str:
    """首个 ``data/*.json`` 的相对 fetch 演示（无后端）；便于 smoke / 手工排查 file:// 限制。"""
    if not data_rel_paths:
        return ""
    first = data_rel_paths[0].replace("\\", "/")
    rel_js = json.dumps(first)
    theme = "aicd-data-demo--dark" if dark else ""
    return f"""
<style>
  .aicd-data-demo {{ margin-top: 1.5rem; padding: 0.75rem; border: 1px solid #ddd; border-radius: 8px; background: #f9fafb; }}
  .aicd-data-demo-title {{ margin: 0 0 0.5rem 0; font-size: 0.9rem; }}
  .aicd-data-demo-pre {{ margin: 0; white-space: pre-wrap; word-break: break-word; font-size: 0.8rem; max-height: 24rem; overflow: auto; }}
  .aicd-data-demo--dark {{ border-color: #374151; background: #111827; color: #e5e7eb; }}
  .aicd-data-demo--dark .aicd-data-demo-title {{ color: #9ca3af; }}
</style>
<section class="aicd-data-demo {theme}" aria-label="本地 JSON（fetch 演示）">
  <p class="aicd-data-demo-title">数据预览（相对路径 fetch；<code>file://</code> 下常失败，请用本地 HTTP）</p>
  <pre id="aicd-data-fetch-status" class="aicd-data-demo-pre"></pre>
</section>
<script>
(function () {{
  var el = document.getElementById("aicd-data-fetch-status");
  if (!el) return;
  var u = {rel_js};
  fetch(u).then(function (r) {{ return r.json(); }}).then(function (d) {{
    var s = JSON.stringify(d, null, 2);
    el.textContent = "fetch OK: " + u + "\\n" + (s.length > 6000 ? s.slice(0, 6000) + "\\n…" : s);
  }}).catch(function (e) {{
    el.textContent = "fetch 未成功: " + u + "\\n" + String(e) + "\\n（建议在站点根执行 python -m http.server，再用 html_bundle_smoke 的 base_url 打开）";
  }});
}})();
</script>
"""


def _rel_res_prefix(*, site_root: Path, page_path: Path) -> str:
    """从 ``page_path`` 到站点根 ``res/`` 的相对 URL 前缀（含 res，无前导 ./）。"""
    try:
        rel = page_path.parent.relative_to(site_root.resolve())
    except ValueError:
        rel = Path(".")
    if rel == Path("."):
        return "res"
    return "/".join([".."] * len(rel.parts)) + "/res"


def _viz_bootstrap_with_prefix(res_prefix: str, include_demo_init: bool) -> str:
    if not include_demo_init:
        return ""
    # 与 viz_assets._VIZ_BOOTSTRAP 等价，路径改为 res_prefix
    rp = res_prefix.rstrip("/")
    return rf"""
<script>
(function () {{
  if (!window.Chart) return;
  var el = document.getElementById("aicd-chart-demo");
  if (!el) return;
  new Chart(el, {{
    type: "line",
    data: {{
      labels: ["A", "B", "C", "D"],
      datasets: [{{ label: "示例", data: [2, 5, 3, 7], borderWidth: 2 }}]
    }},
    options: {{ responsive: true, plugins: {{ legend: {{ display: false }} }} }}
  }});
}})();
(function () {{
  if (!window.vis) return;
  var mount = document.getElementById("aicd-vis-network");
  if (!mount) return;
  var nodes = new vis.DataSet([
    {{ id: 1, label: "节点A" }}, {{ id: 2, label: "节点B" }}, {{ id: 3, label: "节点C" }}
  ]);
  var edges = new vis.DataSet([
    {{ from: 1, to: 2 }}, {{ from: 2, to: 3 }}, {{ from: 3, to: 1 }}
  ]);
  new vis.Network(mount, {{ nodes: nodes, edges: edges }}, {{
    physics: {{ stabilization: true }},
    interaction: {{ hover: true }}
  }});
}})();
</script>
"""


def build_document_with_res_prefix(
    title: str,
    body: str,
    *,
    res_prefix: str,
    meta_description: str | None = None,
    extra_head: str = "",
    extra_scripts: str = "",
    include_default_chart_vis_init: bool = False,
) -> str:
    """与 ``build_viz_html_document`` 相同，但 ``res/`` 路径可相对于子目录页面。"""
    rp = res_prefix.rstrip("/")
    tail = _viz_bootstrap_with_prefix(rp, include_default_chart_vis_init)
    desc = ""
    if meta_description and str(meta_description).strip():
        desc = f'  <meta name="description" content="{html.escape(str(meta_description).strip(), quote=True)}"/>\n'
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="generator" content="aicd-static_site"/>
{desc}  <title>{html.escape(title, quote=True)}</title>
  <link rel="stylesheet" href="{rp}/{VIS_CSS}"/>
  <style>
    body {{ font-family: system-ui, Segoe UI, Roboto, sans-serif; margin: 1rem; line-height: 1.5; }}
    section {{ margin-bottom: 2rem; }}
    .network {{ width: 100%; height: 480px; border: 1px solid #ccc; border-radius: 6px; }}
    pre.mermaid {{ background: #f8f9fa; padding: 1rem; border-radius: 6px; overflow: auto; }}
{_PRINT_CSS_BLOCK}
  </style>
  {extra_head}
</head>
<body>
{body}
  <script src="{rp}/{CHART_JS}"></script>
  <script src="{rp}/{MERMAID_JS}"></script>
  <script src="{rp}/{VIS_JS}"></script>
  <script>
    mermaid.initialize({{ startOnLoad: true, securityLevel: "loose", theme: "neutral" }});
  </script>
  {tail}
  {extra_scripts}
</body>
</html>
"""


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _empty_site_tree() -> dict[str, Any]:
    return {"dirs": {}, "pages": []}


def _site_tree_insert(tree: dict[str, Any], parts: list[str], href: str, title: str) -> None:
    if len(parts) == 1:
        tree["pages"].append({"href": href, "title": title})
        return
    seg = parts[0]
    if seg not in tree["dirs"]:
        tree["dirs"][seg] = _empty_site_tree()
    _site_tree_insert(tree["dirs"][seg], parts[1:], href, title)


def _site_tree_first_href(tree: dict[str, Any]) -> str | None:
    """子树按标题排序后第一个页面 URL（供文件夹链到组内首页）。"""
    for p in sorted(tree["pages"], key=lambda x: (str(x["title"]).lower(), x["href"])):
        return str(p["href"])
    for name in sorted(tree["dirs"].keys(), key=lambda x: x.lower()):
        h = _site_tree_first_href(tree["dirs"][name])
        if h:
            return h
    return None


def _render_site_tree_html(
    tree: dict[str, Any],
    *,
    folder_link_first: bool = True,
    collapsible: bool = True,
) -> str:
    """由 ``rel_path`` 生成嵌套 ``<ul>``；可选 ``<details>`` 折叠分组。"""
    chunks: list[str] = []
    for p in sorted(tree["pages"], key=lambda x: (str(x["title"]).lower(), x["href"])):
        h = html.escape(p["href"], quote=True)
        t = html.escape(str(p["title"]), quote=False)
        chunks.append(f'    <li class="aicd-tree-leaf"><a href="{h}">{t}</a></li>')
    for name in sorted(tree["dirs"].keys(), key=lambda x: x.lower()):
        sub = tree["dirs"][name]
        inner = _render_site_tree_html(
            sub, folder_link_first=folder_link_first, collapsible=collapsible
        )
        label = html.escape(name, quote=False)
        first = _site_tree_first_href(sub) if folder_link_first else None
        if first:
            fh = html.escape(first, quote=True)
            title_attr = html.escape(f"{name} — 打开组内首页", quote=True)
            folder_el = (
                f'<a class="aicd-tree-folder is-link" href="{fh}" '
                f'title="{title_attr}">{label}</a>'
            )
        else:
            folder_el = f'<span class="aicd-tree-folder">{label}</span>'
        nested = f'<ul class="aicd-site-tree aicd-site-tree-nested">\n{inner}\n      </ul>'
        aria_l = html.escape(name, quote=True)
        if collapsible:
            chunks.append(
                f'    <li class="aicd-tree-branch" role="group" aria-label="{aria_l}">\n'
                f'      <details class="aicd-tree-details" open>\n'
                f'        <summary class="aicd-tree-summary">{folder_el}</summary>\n'
                f"        {nested}\n"
                f"      </details>\n"
                f"    </li>"
            )
        else:
            chunks.append(
                f'    <li class="aicd-tree-branch" role="group" aria-label="{aria_l}">\n'
                f"      {folder_el}\n"
                f"      {nested}\n"
                f"    </li>"
            )
    return "\n".join(chunks)


_TOC_SCROLL_SPY_JS = """
<script>
(function () {
  var nav = document.querySelector(".aicd-toc-nav");
  if (!nav) return;
  var links = Array.prototype.slice.call(nav.querySelectorAll('a[href^="#"]'));
  if (!links.length) return;
  var byId = {};
  links.forEach(function (a) {
    var href = a.getAttribute("href") || "";
    if (href.charAt(0) !== "#") return;
    byId[decodeURIComponent(href.slice(1))] = a;
  });
  var sections = Array.prototype.slice.call(document.querySelectorAll(".aicd-toc-section[id]"));
  if (!sections.length) return;
  function clearActive() {
    links.forEach(function (x) {
      x.classList.remove("is-active");
      x.removeAttribute("aria-current");
    });
  }
  function update() {
    var offset = 72;
    var cur = sections[0];
    for (var i = 0; i < sections.length; i++) {
      var r = sections[i].getBoundingClientRect();
      if (r.top <= offset) cur = sections[i];
      else break;
    }
    var lk = byId[cur.id];
    if (lk) {
      clearActive();
      lk.classList.add("is-active");
      lk.setAttribute("aria-current", "location");
    }
  }
  var ticking = false;
  function onScrollOrResize() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      update();
    });
  }
  window.addEventListener("scroll", onScrollOrResize, { passive: true });
  window.addEventListener("resize", onScrollOrResize, { passive: true });
  update();
})();
</script>
"""


def _write_data_dir(root: Path, data_payloads: dict[str, Any]) -> list[str]:
    written: list[str] = []
    ddir = root / "data"
    for name, obj in (data_payloads or {}).items():
        safe = str(name).strip().replace("\\", "/").split("/")[-1]
        if not safe or safe in (".", ".."):
            continue
        if not safe.endswith(".json"):
            safe = f"{safe}.json"
        p = ddir / safe
        _write_text(p, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
        written.append(str(p.relative_to(root)).replace("\\", "/"))
    return written


def build_single_page_toc_html(
    *,
    title: str,
    sections: list[dict[str, Any]],
    site_root: Path,
    include_chart_resources: bool,
    appendix_html: str = "",
) -> Path:
    """单页长文 + 侧边 TOC；输出 ``index.html``。"""
    main_parts: list[str] = []
    toc_parts: list[str] = []
    for sec in sections:
        sid = str(sec.get("id") or sec.get("section_id") or "").strip()
        stitle = str(sec.get("title") or "").strip()
        body = str(sec.get("body_html") or "")
        _assert_no_remote_urls(body, where=f"section {sid or stitle}")
        if not sid:
            sid = re.sub(r"[^\w\-]+", "-", stitle.lower()).strip("-") or "section"
        main_parts.append(
            f'<section class="aicd-toc-section" id="{html.escape(sid, quote=True)}">'
            f"<h2>{html.escape(stitle, quote=False)}</h2>{body}</section>"
        )
        toc_parts.append(
            f'<li><a href="#{html.escape(sid, quote=True)}">{html.escape(stitle, quote=False)}</a></li>'
        )
    body_inner = f"""
<div class="aicd-toc-layout">
  <nav class="aicd-toc-nav" aria-label="目录">
    <strong>目录</strong>
    <ol>{"".join(toc_parts)}</ol>
  </nav>
  <main class="aicd-toc-main">
    {"".join(main_parts)}
    {appendix_html}
  </main>
</div>
"""
    extra_head = """
<style>
  .aicd-toc-layout { display: grid; grid-template-columns: minmax(200px, 260px) 1fr; gap: 1.5rem; align-items: start; max-width: 1200px; margin: 0 auto; }
  .aicd-toc-nav { position: sticky; top: 0.5rem; padding: 0.75rem; border: 1px solid #ddd; border-radius: 8px; background: #fafafa; font-size: 0.95rem; }
  .aicd-toc-nav ol { margin: 0.5rem 0 0 0; padding-left: 1.2rem; }
  .aicd-toc-nav a { color: #1e3a8a; text-decoration: none; border-radius: 4px; padding: 0.12rem 0.35rem; display: inline-block; }
  .aicd-toc-nav a:hover { background: #f1f5f9; }
  .aicd-toc-nav a:focus-visible { outline: 2px solid #2563eb; outline-offset: 2px; }
  .aicd-toc-nav a.is-active { font-weight: 600; color: #1e40af; background: #dbeafe; }
  .aicd-toc-main section { scroll-margin-top: 0.75rem; }
  @media (max-width: 720px) {
    .aicd-toc-layout { grid-template-columns: 1fr; }
    .aicd-toc-nav { position: relative; top: auto; }
  }
{_PRINT_CSS_BLOCK}
</style>
"""
    out = site_root / "index.html"
    meta_d = (title + " — 章节导航")[:300]
    if include_chart_resources:
        rp = _rel_res_prefix(site_root=site_root, page_path=out)
        doc = build_document_with_res_prefix(
            title,
            body_inner,
            res_prefix=rp,
            meta_description=meta_d,
            extra_head=extra_head,
            extra_scripts=_TOC_SCROLL_SPY_JS,
            include_default_chart_vis_init=False,
        )
    else:
        doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="generator" content="aicd-static_site"/>
  <meta name="description" content="{html.escape(meta_d, quote=True)}"/>
  <title>{html.escape(title, quote=True)}</title>
  {extra_head}
</head>
<body>
{body_inner}
{_TOC_SCROLL_SPY_JS}
</body>
</html>
"""
    _write_text(out, doc)
    return out


def build_multi_page_site(
    *,
    site_title: str,
    pages: list[dict[str, Any]],
    site_root: Path,
    include_chart_resources: bool,
    index_appendix_html: str = "",
    folder_link_first: bool = True,
    site_tree_collapsible: bool = True,
    subpage_navigation: bool = True,
) -> tuple[Path, list[Path], list[dict[str, Any]]]:
    """多页站点：``index.html`` + ``pages/**/*.html``；索引按 ``rel_path`` 目录嵌套为树。

    第三项为已写出页面的清单（``rel_path`` / ``title`` / ``href``），供 ``site.json`` 使用。
    """
    written: list[Path] = []
    page_records: list[dict[str, Any]] = []
    pages_dir = site_root / "pages"
    site_tree = _empty_site_tree()
    for pg in pages:
        rel = str(pg.get("rel_path") or pg.get("path") or "").strip().lstrip("/\\")
        if not rel:
            rel = f"page-{len(written)}.html"
        rel = rel.replace("\\", "/")
        if not rel.lower().endswith(".html"):
            rel = rel + ".html"
        if rel.startswith("/") or ".." in Path(rel).parts:
            raise ValueError(f"非法页面路径: {rel!r}")
        ptitle = str(pg.get("title") or rel).strip()
        body = str(pg.get("body_html") or "")
        _assert_no_remote_urls(body, where=f"page {rel}")
        full_path = (pages_dir / Path(rel).name) if "/" not in rel else pages_dir / rel
        if not _path_is_under(pages_dir, full_path):
            raise ValueError(f"页面须位于 pages/ 下: {rel!r}")
        rp = _rel_res_prefix(site_root=site_root, page_path=full_path)
        idx_href = _href_to_site_index(page_file=full_path, site_root=site_root)
        chrome = (
            _subpage_top_chrome(site_title=site_title, rel_path=rel, index_href=idx_href)
            if subpage_navigation
            else ""
        )
        page_body = f'{chrome}<article class="aicd-page-body">{body}</article>'
        sub_extra = _SUBPAGE_STYLES if subpage_navigation else ""
        meta_p = f"{site_title} — {ptitle}"[:300]
        if include_chart_resources:
            doc = build_document_with_res_prefix(
                ptitle,
                page_body,
                res_prefix=rp,
                meta_description=meta_p,
                extra_head=sub_extra,
                include_default_chart_vis_init=False,
            )
        else:
            doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="generator" content="aicd-static_site"/>
  <meta name="description" content="{html.escape(meta_p, quote=True)}"/>
  <title>{html.escape(ptitle, quote=True)}</title>
  {sub_extra}
</head>
<body>
{page_body}
</body>
</html>
"""
        _write_text(full_path, doc)
        written.append(full_path)
        href = str(full_path.relative_to(site_root)).replace("\\", "/")
        page_records.append({"rel_path": rel, "title": ptitle, "href": href})
        _site_tree_insert(site_tree, list(Path(rel).parts), href, ptitle)

    tree_inner = _render_site_tree_html(
        site_tree,
        folder_link_first=folder_link_first,
        collapsible=site_tree_collapsible,
    )
    tree_script = _SITE_TREE_STOPPROP_JS if site_tree_collapsible else ""
    if not tree_inner.strip():
        tree_inner = (
            '    <li class="aicd-tree-empty" style="list-style:none;color:#9ca3af;font-size:0.9rem;">'
            "（尚未添加任何子页面）</li>"
        )
    collapsible_css = (
        """
  .aicd-tree-details { margin: 0.15rem 0; border-radius: 6px; }
  .aicd-tree-summary { list-style: none; cursor: pointer; display: flex; align-items: center; flex-wrap: wrap; gap: 0.35rem; padding: 0.15rem 0; }
  .aicd-tree-summary::-webkit-details-marker { display: none; }"""
        if site_tree_collapsible
        else ""
    )
    index_styles = f"""
<style>
  .aicd-site-header h1 {{ margin: 0 0 0.35rem 0; }}
  .aicd-site-desc {{ margin: 0 0 1rem 0; color: #555; font-size: 0.95rem; }}
  .aicd-site-tree-root {{ list-style: none; padding-left: 0; margin: 0; }}
  .aicd-site-tree-nested {{ list-style: none; padding: 0.1rem 0 0.2rem 0.85rem; margin: 0; border-left: 2px solid #e5e7eb; }}
  .aicd-tree-folder {{ display: block; font-size: 0.78rem; font-weight: 700; color: #6b7280; margin: 0.5rem 0 0.2rem 0; text-transform: uppercase; letter-spacing: 0.04em; }}
  .aicd-tree-folder.is-link {{ text-decoration: none; color: inherit; cursor: pointer; }}
  .aicd-tree-folder.is-link:hover {{ color: #2563eb; text-decoration: underline; }}
  .aicd-tree-folder.is-link:focus-visible {{ outline: 2px solid #2563eb; outline-offset: 2px; border-radius: 2px; }}
  .aicd-tree-branch {{ margin: 0.05rem 0; list-style: none; }}
  .aicd-tree-leaf {{ margin: 0.2rem 0; list-style: none; }}
  .aicd-tree-leaf a {{ text-decoration: none; color: #2563eb; font-weight: 500; }}
  .aicd-tree-leaf a:hover {{ text-decoration: underline; }}
  .aicd-tree-leaf a:focus-visible {{ outline: 2px solid #2563eb; outline-offset: 1px; border-radius: 2px; }}{collapsible_css}
{_PRINT_CSS_BLOCK}
</style>
"""
    index_meta = (site_title + " — 站点索引")[:300]
    tree_blurb = (
        "目录按路径嵌套，分组可折叠（<code>&lt;details&gt;</code>）。"
        if site_tree_collapsible
        else "目录按路径嵌套列出。"
    )
    index_body = f"""
{index_styles}
<header class="aicd-site-header">
  <h1>{html.escape(site_title, quote=False)}</h1>
  <p class="aicd-site-desc">全静态站点；图表资源在根目录 <code>res/</code>；子页在 <code>pages/</code>；{tree_blurb}</p>
</header>
<nav class="aicd-site-nav" aria-label="站点目录树">
  <ul class="aicd-site-tree aicd-site-tree-root">
{tree_inner}
  </ul>
</nav>
{tree_script}
{index_appendix_html}
"""
    index_path = site_root / "index.html"
    if include_chart_resources:
        ix_rp = _rel_res_prefix(site_root=site_root, page_path=index_path)
        index_doc = build_document_with_res_prefix(
            site_title,
            index_body,
            res_prefix=ix_rp,
            meta_description=index_meta,
            include_default_chart_vis_init=False,
        )
    else:
        index_doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="generator" content="aicd-static_site"/>
  <meta name="description" content="{html.escape(index_meta, quote=True)}"/>
  <title>{html.escape(site_title, quote=True)}</title>
</head>
<body>
{index_body}
</body>
</html>
"""
    _write_text(index_path, index_doc)
    return index_path, written, page_records


def build_slide_deck_html(
    *,
    title: str,
    slides: list[dict[str, Any]],
    site_root: Path,
    include_chart_resources: bool,
    transition: str,
    autoplay_ms: int | None,
    footer_appendix_html: str = "",
) -> Path:
    """单文件 ``deck.html``：全屏幻灯片、键盘与可选自动播放。"""
    norm_trans = (transition or "fade").strip().lower()
    if norm_trans not in ("fade", "slide", "none"):
        norm_trans = "fade"
    autoplay = int(autoplay_ms) if autoplay_ms is not None and int(autoplay_ms) > 0 else None

    slide_blocks: list[str] = []
    dots: list[str] = []
    for i, sl in enumerate(slides):
        body = str(sl.get("body_html") or "")
        _assert_no_remote_urls(body, where=f"slide {i}")
        st = str(sl.get("title") or "").strip()
        head = f'<h2 class="aicd-slide-title">{html.escape(st, quote=False)}</h2>' if st else ""
        slide_blocks.append(
            f'<section class="aicd-slide" data-idx="{i}" '
            f'id="slide-{i}" role="group" aria-label="第 {i + 1} 张">{head}<div class="aicd-slide-body">{body}</div></section>'
        )
        dots.append(
            f'<button type="button" class="aicd-deck-dot" data-go="{i}" aria-label="第 {i + 1} 张">{i + 1}</button>'
        )

    trans_css = ""
    if norm_trans == "fade":
        trans_css = """
    .aicd-slide { opacity: 0; transition: opacity 0.35s ease; pointer-events: none; }
    .aicd-slide.is-active { opacity: 1; pointer-events: auto; }
        """
    elif norm_trans == "slide":
        trans_css = """
    .aicd-slide { transform: translateX(12px); opacity: 0; transition: transform 0.35s ease, opacity 0.35s ease; pointer-events: none; }
    .aicd-slide.is-active { transform: translateX(0); opacity: 1; pointer-events: auto; }
        """
    else:
        trans_css = """
    .aicd-slide { display: none; }
    .aicd-slide.is-active { display: flex; }
        """

    deck_inner = f"""
<div class="aicd-deck" id="aicd-deck-root">
  <header class="aicd-deck-bar">
    <span class="aicd-deck-title">{html.escape(title, quote=False)}</span>
    <span class="aicd-deck-counter" id="aicd-deck-counter" aria-live="polite"></span>
  </header>
  <div class="aicd-deck-viewport">
    {"".join(slide_blocks)}
  </div>
  <footer class="aicd-deck-footer">
    <div class="aicd-deck-dots">{"".join(dots)}</div>
    <p class="aicd-deck-hint">← → 切换；Home / End 首尾；触控区左右滑动翻页</p>
    {footer_appendix_html}
  </footer>
</div>
"""
    deck_css = f"""
<style>
  html, body {{ height: 100%; margin: 0; }}
  body {{ overflow: hidden; font-family: system-ui, Segoe UI, Roboto, sans-serif; }}
  .aicd-deck {{ height: 100vh; display: flex; flex-direction: column; background: #111827; color: #f9fafb; }}
  .aicd-deck-bar, .aicd-deck-footer {{ flex: 0 0 auto; padding: 0.5rem 1rem; background: #0f172a; border: solid #1f2937; border-width: 0 0 1px; display: flex; align-items: center; gap: 0.75rem; }}
  .aicd-deck-footer {{ border-width: 1px 0 0; flex-wrap: wrap; }}
  .aicd-deck-viewport {{ flex: 1 1 auto; position: relative; overflow: hidden; }}
  .aicd-slide {{
    position: absolute; inset: 0;
    box-sizing: border-box; padding: 2rem 3rem;
    display: flex; flex-direction: column; justify-content: center;
    background: radial-gradient(circle at top, #1f2937, #0b1220);
  }}
  .aicd-slide-title {{ margin-top: 0; }}
  .aicd-slide-body {{ max-width: 960px; }}
  .aicd-slide-body .network {{ height: 420px; background: #111827; border-color: #374151; }}
  .aicd-deck-dots {{ display: flex; flex-wrap: wrap; gap: 0.35rem; }}
  .aicd-deck-dot {{
    min-width: 2rem; padding: 0.2rem 0.45rem; border-radius: 4px; border: 1px solid #4b5563;
    background: #111827; color: #e5e7eb; cursor: pointer; font-size: 0.8rem;
  }}
  .aicd-deck-dot.is-current {{ background: #2563eb; border-color: #1d4ed8; }}
  .aicd-deck-hint {{ margin: 0; font-size: 0.8rem; color: #9ca3af; flex: 1 1 auto; }}
  .aicd-deck-footer .aicd-data-demo {{ flex: 1 1 100%; margin-top: 0.5rem; max-height: 30vh; overflow: auto; }}
  .aicd-slide-body pre.mermaid {{ background: #1f2937; color: #e5e7eb; border: 1px solid #374151; border-radius: 6px; }}
  .aicd-deck-dot:focus-visible {{ outline: 2px solid #93c5fd; outline-offset: 2px; }}
  @media (prefers-reduced-motion: reduce) {{
    .aicd-slide {{ transition: none !important; }}
  }}
  {trans_css}
{_PRINT_CSS_BLOCK}
</style>
"""
    deck_meta = (title + " — 幻灯片")[:300]
    deck_js = f"""
<script>
(function () {{
  var root = document.getElementById("aicd-deck-root");
  if (!root) return;
  var slides = Array.prototype.slice.call(root.querySelectorAll(".aicd-slide"));
  var dots = Array.prototype.slice.call(root.querySelectorAll(".aicd-deck-dot"));
  var counter = document.getElementById("aicd-deck-counter");
  var idx = 0;
  function show(i) {{
    if (!slides.length) return;
    idx = (i + slides.length) % slides.length;
    slides.forEach(function (s, j) {{
      s.classList.toggle("is-active", j === idx);
    }});
    dots.forEach(function (d) {{
      d.classList.toggle("is-current", parseInt(d.getAttribute("data-go"), 10) === idx);
    }});
    if (counter) counter.textContent = (idx + 1) + " / " + slides.length;
    try {{ history.replaceState(null, "", "#slide-" + idx); }} catch (e) {{}}
  }}
  show(0);
  if (location.hash && /^#slide-\\d+$/.test(location.hash)) {{
    var m = parseInt(location.hash.replace("#slide-", ""), 10);
    if (!isNaN(m)) show(m);
  }}
  dots.forEach(function (d) {{
    d.addEventListener("click", function () {{
      show(parseInt(d.getAttribute("data-go"), 10));
    }});
  }});
  document.addEventListener("keydown", function (ev) {{
    if (ev.key === "ArrowRight" || ev.key === "PageDown" || ev.key === " ") {{ ev.preventDefault(); show(idx + 1); }}
    else if (ev.key === "ArrowLeft" || ev.key === "PageUp") {{ ev.preventDefault(); show(idx - 1); }}
    else if (ev.key === "Home") {{ ev.preventDefault(); show(0); }}
    else if (ev.key === "End") {{ ev.preventDefault(); show(slides.length - 1); }}
  }});
  var touchX0 = null, touchY0 = null;
  var vp = root.querySelector(".aicd-deck-viewport");
  if (vp) {{
    vp.addEventListener("touchstart", function (e) {{
      if (!e.touches || !e.touches.length) return;
      touchX0 = e.touches[0].clientX;
      touchY0 = e.touches[0].clientY;
    }}, {{ passive: true }});
    vp.addEventListener("touchend", function (e) {{
      if (touchX0 === null || !e.changedTouches || !e.changedTouches.length) return;
      var dx = e.changedTouches[0].clientX - touchX0;
      var dy = e.changedTouches[0].clientY - (touchY0 || 0);
      touchX0 = null;
      touchY0 = null;
      var th = 44;
      if (Math.abs(dx) < th || Math.abs(dx) < Math.abs(dy)) return;
      if (dx < 0) show(idx + 1); else show(idx - 1);
    }}, {{ passive: true }});
  }}
  var ap = {json.dumps(autoplay)};
  var _apTimer = null;
  var _reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function startAutoplay() {{
    if (!ap || ap <= 0 || _reduceMotion) return;
    stopAutoplay();
    _apTimer = setInterval(function () {{ show(idx + 1); }}, ap);
  }}
  function stopAutoplay() {{
    if (_apTimer) {{ clearInterval(_apTimer); _apTimer = null; }}
  }}
  document.addEventListener("visibilitychange", function () {{
    if (document.hidden) stopAutoplay(); else startAutoplay();
  }});
  startAutoplay();
}})();
</script>
"""
    out = site_root / "deck.html"
    if include_chart_resources:
        rp = _rel_res_prefix(site_root=site_root, page_path=out)
        doc = build_document_with_res_prefix(
            title,
            deck_inner,
            res_prefix=rp,
            meta_description=deck_meta,
            extra_head=deck_css,
            extra_scripts=deck_js,
            include_default_chart_vis_init=False,
        )
    else:
        doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="generator" content="aicd-static_site"/>
  <meta name="description" content="{html.escape(deck_meta, quote=True)}"/>
  <title>{html.escape(title, quote=True)}</title>
  {deck_css}
</head>
<body>
{deck_inner}
{deck_js}
</body>
</html>
"""
    _write_text(out, doc)
    return out


def run_static_html_bundle(
    *,
    output_dir: Path,
    mode: str,
    site_title: str,
    pages: list[dict[str, Any]] | None = None,
    slides: list[dict[str, Any]] | None = None,
    sections: list[dict[str, Any]] | None = None,
    copy_chart_resources: bool = True,
    data_payloads: dict[str, Any] | None = None,
    transition: str = "fade",
    autoplay_ms: int | None = None,
    write_site_manifest: bool = True,
    inject_data_fetch_demo: bool = True,
    site_tree_folder_links: bool = True,
    site_tree_collapsible: bool = True,
    subpage_navigation: bool = True,
) -> dict[str, Any]:
    """生成静态 bundle：目录、页面清单与可选 ``data/*.json``。

    ``mode``: ``single_toc`` | ``multi_page`` | ``slide_deck``（见 ``MODE_ALIASES`` 别名）。

    若写出 ``data/*.json`` 且 ``inject_data_fetch_demo``，会在主导入页注入相对路径
    ``fetch`` 调试块（轮播页使用深色样式）。

    ``site_tree_folder_links``: 多页索引里文件夹标题是否链到该组按标题排序后的第一篇。
    ``site_tree_collapsible``: 多页索引目录分组是否用 ``<details>`` 可折叠。
    ``subpage_navigation``: 多页子页是否加顶栏面包屑与回首页链接。
    """
    root = output_dir.resolve()
    root.mkdir(parents=True, exist_ok=True)
    written_files: list[str] = []
    main_html = ""

    if copy_chart_resources:
        copy_viz_resources(root / "res")

    data_written = _write_data_dir(root, data_payloads or {})
    written_files.extend(data_written)
    demo_light = (
        _offline_data_demo_snippet(data_written, dark=False)
        if (data_written and inject_data_fetch_demo)
        else ""
    )
    demo_dark = (
        _offline_data_demo_snippet(data_written, dark=True)
        if (data_written and inject_data_fetch_demo)
        else ""
    )

    _, canon = normalize_static_bundle_mode(mode)
    page_manifest: list[dict[str, Any]] | None = None
    slide_manifest: list[dict[str, Any]] | None = None
    section_manifest: list[dict[str, Any]] | None = None

    if canon == "single_toc":
        secs = list(sections or pages or [])
        section_manifest = [
            {
                "id": str(
                    s.get("id") or s.get("section_id") or ""
                ).strip(),
                "title": str(s.get("title") or "").strip(),
            }
            for s in secs
        ]
        main_path = build_single_page_toc_html(
            title=site_title,
            sections=secs,
            site_root=root,
            include_chart_resources=copy_chart_resources,
            appendix_html=demo_light,
        )
        main_html = str(main_path.relative_to(root)).replace("\\", "/")
        written_files.append(main_html)
    elif canon == "multi_page":
        index_path, page_paths, page_manifest = build_multi_page_site(
            site_title=site_title,
            pages=list(pages or []),
            site_root=root,
            include_chart_resources=copy_chart_resources,
            index_appendix_html=demo_light,
            folder_link_first=site_tree_folder_links,
            site_tree_collapsible=site_tree_collapsible,
            subpage_navigation=subpage_navigation,
        )
        main_html = str(index_path.relative_to(root)).replace("\\", "/")
        written_files.append(main_html)
        written_files.extend(
            str(p.relative_to(root)).replace("\\", "/") for p in page_paths
        )
    elif canon == "slide_deck":
        slide_manifest = [
            {"index": i, "title": str(sl.get("title") or "").strip() or None}
            for i, sl in enumerate(list(slides or []))
        ]
        deck_path = build_slide_deck_html(
            title=site_title,
            slides=list(slides or []),
            site_root=root,
            include_chart_resources=copy_chart_resources,
            transition=transition,
            autoplay_ms=autoplay_ms,
            footer_appendix_html=demo_dark,
        )
        main_html = str(deck_path.relative_to(root)).replace("\\", "/")
        written_files.append(main_html)
    else:
        raise ValueError(
            f"未知 mode: {mode!r}（支持 single_toc | multi_page | slide_deck 及常见别名）"
        )

    if write_site_manifest:
        written_files.append("site.json")
        manifest: dict[str, Any] = {
            "schema": SITE_SCHEMA_VERSION,
            "mode": canon,
            "title": site_title,
            "main_html": main_html,
            "files": sorted(dict.fromkeys(written_files)),
            "data_files": data_written,
            "copy_chart_resources": copy_chart_resources,
            "transition": transition,
            "autoplay_ms": autoplay_ms,
            "inject_data_fetch_demo": inject_data_fetch_demo,
            "site_tree_folder_links": site_tree_folder_links,
            "site_tree_collapsible": site_tree_collapsible,
            "subpage_navigation": subpage_navigation,
        }
        if page_manifest is not None:
            manifest["pages"] = page_manifest
        if slide_manifest is not None:
            manifest["slides"] = slide_manifest
        if section_manifest is not None:
            manifest["sections"] = section_manifest
        mp = root / "site.json"
        _write_text(mp, json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")

    notes = (
        "本地预览可使用 file:// 打开主 HTML；若页面使用 fetch('./data/…')，"
        "部分浏览器在 file:// 下会拦截请求，建议用 python -m http.server 在站点根启动后通过 http://127.0.0.1:PORT/ 访问。"
    )
    return {
        "ok": True,
        "output_dir": str(root),
        "main_html": main_html,
        "index_path": main_html if main_html.endswith("index.html") else None,
        "written_files": sorted(dict.fromkeys(written_files)),
        "notes": notes,
    }
