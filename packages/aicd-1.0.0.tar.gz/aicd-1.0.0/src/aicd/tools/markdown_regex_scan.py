"""单文件正则扫描（按行流式 + 上下文），避免整文件载入内存。

常用于 **``doc_normalize``** 之后的 **``.md/.txt``**，或与 **``markdown_chunk_split``** 产出的小块配合。
流水线顺序见 **``doc_analysis_kit``**。
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def run_markdown_regex_scan(
    path: Path,
    pattern: str,
    *,
    context_lines: int = 2,
    max_matches: int = 100,
    ignore_case: bool = False,
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """
    在文本文件的每一行上运行 ``re.search``（非跨行）。

    超大文件：仅保留 **上下文行数** 量级的窗口于内存。
    """
    flags = re.IGNORECASE if ignore_case else 0
    try:
        rx = re.compile(pattern, flags)
    except re.error as e:
        return {"ok": False, "error": f"invalid regex: {e}"}

    p = path.expanduser().resolve()
    if not p.is_file():
        return {"ok": False, "error": f"not a file: {p}"}

    ctx = max(0, int(context_lines))
    lim = max(1, int(max_matches))
    matches: list[dict[str, Any]] = []
    prev: list[tuple[int, str]] = []
    line_no = 0

    try:
        with p.open("r", encoding=encoding, errors="replace", newline="") as f:
            for line in f:
                line_no += 1
                s = line.rstrip("\r\n")
                m = rx.search(s)
                if m is not None:
                    match_line = line_no
                    ahead: list[tuple[int, str]] = []
                    if ctx > 0:
                        for _ in range(ctx):
                            try:
                                nxt = next(f)
                            except StopIteration:
                                break
                            line_no += 1
                            ahead.append((line_no, nxt.rstrip("\r\n")))

                    before = [t for _, t in prev[-ctx:]]
                    after = [t for _, t in ahead]
                    snippet = "\n".join(before + [s] + after)
                    matches.append(
                        {
                            "line": match_line,
                            "column": m.start() + 1,
                            "match": m.group(0),
                            "groups": list(m.groups()) if m.lastindex else [],
                            "snippet": snippet[:2000],
                        }
                    )
                    if len(matches) >= lim:
                        break
                    prev = prev[-ctx:] + [(match_line, s)] + ahead
                    continue

                prev.append((line_no, s))
                if len(prev) > ctx * 2 + 1:
                    prev = prev[-(ctx * 2 + 1) :]
    except OSError as e:
        return {"ok": False, "error": str(e)}

    return {
        "ok": True,
        "path": str(p),
        "pattern": pattern,
        "match_count": len(matches),
        "truncated_by_limit": len(matches) >= lim,
        "matches": matches,
        "notes": [
            "Per-line **re.search** only (not multiline); "
            "for cross-line patterns use **markdown_section_slice** + scan, or split the file first."
        ],
    }
