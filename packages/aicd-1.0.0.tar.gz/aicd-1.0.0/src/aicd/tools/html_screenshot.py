"""将本地离线 HTML（如 viz_export_html / viz_data_chart）渲染为 PNG，不删除源 HTML。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable


def render_html_file_to_png(
    html_path: Path,
    output_png: Path,
    *,
    policy_check: Callable[[Path], None],
    selector: str | None = None,
    full_page: bool = True,
    viewport_width: int | None = None,
    viewport_height: int | None = None,
    device_scale_factor: float = 2.0,
    wait_after_load_ms: int = 1200,
    timeout_ms: int = 120_000,
) -> dict[str, Any]:
    """
    用 Playwright 打开 ``file://`` 页面并截图。

    - **不修改、不删除** ``html_path``；同级 ``res/`` 由浏览器按相对路径加载。
    - ``selector`` 非空时截取该元素，否则整页（``full_page`` 控制是否完整滚动高度）。
    - ``viewport_width`` / ``viewport_height`` 均给定且为正时，在导航前设置固定视口（适合 **PPT 单页** 等固定画幅；建议配合 ``full_page=false``）。
    """
    hp = html_path.expanduser().resolve()
    out = output_png.expanduser().resolve()
    policy_check(hp)
    policy_check(out)
    if not hp.is_file():
        return {"ok": False, "error": f"html file not found: {hp}"}
    if hp.suffix.lower() not in {".html", ".htm"}:
        return {"ok": False, "error": "html_path must be .html or .htm"}
    if out.suffix.lower() != ".png":
        return {"ok": False, "error": "output_png_path must end with .png"}

    out.parent.mkdir(parents=True, exist_ok=True)
    uri = hp.resolve().as_uri()

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as e:
        return {
            "ok": False,
            "error": f"playwright not available: {e}",
            "hint": "pip install playwright && python -m playwright install chromium",
        }

    sel = (selector or "").strip() or None
    dsf = max(1.0, min(4.0, float(device_scale_factor)))
    wait_ms = max(0, min(60_000, int(wait_after_load_ms)))

    vw = int(viewport_width) if viewport_width is not None else None
    vh = int(viewport_height) if viewport_height is not None else None
    if (vw is not None) ^ (vh is not None):
        return {
            "ok": False,
            "error": "viewport_width and viewport_height must both be set or both omitted",
        }
    if vw is not None and vh is not None:
        if vw < 16 or vw > 4096 or vh < 16 or vh > 4096:
            return {"ok": False, "error": "viewport sizes must be within 16..4096"}

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                context = browser.new_context(device_scale_factor=dsf)
                page = context.new_page()
                page.set_default_timeout(timeout_ms)
                if vw is not None and vh is not None:
                    page.set_viewport_size({"width": vw, "height": vh})
                page.goto(uri, wait_until="load")
                if wait_ms:
                    page.wait_for_timeout(wait_ms)
                if sel:
                    loc = page.locator(sel).first
                    loc.wait_for(state="visible", timeout=timeout_ms)
                    loc.screenshot(path=str(out), type="png")
                else:
                    page.screenshot(
                        path=str(out),
                        full_page=bool(full_page),
                        type="png",
                    )
            finally:
                browser.close()
    except Exception as e:
        msg = str(e).lower()
        hint = "运行: python -m playwright install chromium"
        if "executable doesn't exist" in msg or "browsertype.launch" in msg:
            hint = "未找到 Chromium，请执行: python -m playwright install chromium"
        return {"ok": False, "error": str(e), "hint": hint}

    if not out.is_file() or out.stat().st_size == 0:
        return {"ok": False, "error": "PNG was not written or is empty"}

    return {
        "ok": True,
        "png_path": str(out),
        "html_path": str(hp),
        "source_retained": True,
        "note": "Source .html and sibling res/ are unchanged; use png_path in docx_compose / pptx_compose.",
    }


def run_html_bundle_smoke(
    entry_html: Path,
    *,
    site_root: Path,
    base_url: str | None,
    policy_check: Callable[[Path], None],
    screenshot_dir: Path,
    report_path: Path | None,
    capture_deck_slides: bool = True,
    wait_after_load_ms: int = 1000,
    timeout_ms: int = 120_000,
) -> dict[str, Any]:
    """打开静态 bundle 的入口 HTML（``file://`` 或 ``base_url`` + 相对路径），收集 console 并截图。"""
    entry = entry_html.expanduser().resolve()
    root = site_root.expanduser().resolve()
    policy_check(entry)
    policy_check(root)
    if not entry.is_file():
        return {"ok": False, "error": f"entry_html not found: {entry}"}
    if entry.suffix.lower() not in {".html", ".htm"}:
        return {"ok": False, "error": "entry_html must be .html or .htm"}

    try:
        rel = entry.relative_to(root)
    except ValueError:
        rel = Path(entry.name)

    if base_url:
        bu = base_url.strip().rstrip("/") + "/"
        url = bu + rel.as_posix()
    else:
        url = entry.resolve().as_uri()

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as e:
        return {
            "ok": False,
            "error": f"playwright not available: {e}",
            "hint": "pip install playwright && python -m playwright install chromium",
        }

    screenshot_dir.mkdir(parents=True, exist_ok=True)
    policy_check(screenshot_dir)
    if report_path:
        policy_check(report_path.parent)

    wait_ms = max(0, min(60_000, int(wait_after_load_ms)))
    console_msgs: list[dict[str, str]] = []
    page_errors: list[str] = []
    screenshot_paths: list[str] = []
    issues: list[str] = []

    stem = entry.stem or "smoke"

    def _push_issue(kind: str, text: str) -> None:
        issues.append(f"{kind}:{text[:500]}")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                context = browser.new_context(device_scale_factor=2.0)
                page = context.new_page()
                page.set_default_timeout(timeout_ms)

                def _on_console(msg: Any) -> None:
                    console_msgs.append({"type": msg.type, "text": msg.text})

                page.on("console", _on_console)
                page.on("pageerror", lambda exc: page_errors.append(str(exc)))

                page.goto(url, wait_until="load")
                try:
                    page.wait_for_load_state("networkidle", timeout=min(8_000, timeout_ms))
                except Exception:
                    pass
                if wait_ms:
                    page.wait_for_timeout(wait_ms)

                def _drain_console_issues() -> None:
                    for m in console_msgs:
                        t = m.get("type", "")
                        if t in ("error", "warning"):
                            _push_issue(f"console_{t}", m.get("text") or "")
                    for pe in page_errors:
                        _push_issue("pageerror", pe)

                shot0 = screenshot_dir / f"{stem}_00.png"
                page.screenshot(path=str(shot0), full_page=False, type="png")
                screenshot_paths.append(str(shot0))

                is_deck = page.locator("#aicd-deck-root").count() > 0
                if capture_deck_slides and is_deck:
                    n = page.locator(".aicd-slide").count()
                    transition_pause = max(120, min(450, wait_ms // 2 or 200))
                    for step in range(1, max(n, 1)):
                        page.keyboard.press("ArrowRight")
                        page.wait_for_timeout(transition_pause)
                        shot = screenshot_dir / f"{stem}_{step:02d}.png"
                        page.screenshot(path=str(shot), full_page=False, type="png")
                        screenshot_paths.append(str(shot))

                _drain_console_issues()
            finally:
                browser.close()
    except Exception as e:
        msg = str(e).lower()
        hint = "运行: python -m playwright install chromium"
        if "executable doesn't exist" in msg or "browsertype.launch" in msg:
            hint = "未找到 Chromium，请执行: python -m playwright install chromium"
        return {"ok": False, "error": str(e), "hint": hint}

    ok = not page_errors and not any(
        m.get("type") == "error" for m in console_msgs
    )
    issues = list(dict.fromkeys(issues))
    report: dict[str, Any] = {
        "ok": ok,
        "url": url,
        "entry_html": str(entry),
        "site_root": str(root),
        "console_messages": console_msgs,
        "page_errors": page_errors,
        "issues": issues,
        "screenshot_paths": screenshot_paths,
        "notes": "若使用 fetch('./data/…')，file:// 可能失败；可设 base_url 指向本地 http.server。",
    }
    if report_path:
        report_path.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        report["report_json_path"] = str(report_path)

    out: dict[str, Any] = {
        "ok": ok,
        "url": url,
        "issues": issues,
        "screenshot_paths": screenshot_paths,
        "notes": report["notes"],
    }
    if report_path:
        out["report_json_path"] = str(report_path)
    return out
