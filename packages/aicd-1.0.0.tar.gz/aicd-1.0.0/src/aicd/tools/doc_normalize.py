"""将源文档规范化为可分析形式（优先 Markdown），并写入可复用缓存清单。

逻辑分块：**校验路径 → 试缓存命中 → 否则落盘 normalized → 可选提纲 → 写清单**。
流水线顺序见 **``aicd.tools.doc_analysis_kit``** 模块文档。
"""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from aicd.tools.doc_analysis_kit import (
    OUTLINES_SUBDIR,
    SCHEMA_DOC_NORMALIZE_MANIFEST,
    clamp_heading_level,
    corpus_paths,
    source_stat_from_path,
)
from aicd.tools.document_outline import build_outline_payload, write_outline_json

MANIFEST_SCHEMA = SCHEMA_DOC_NORMALIZE_MANIFEST

_PANDOC_INPUT_SUFFIXES = frozenset({".odt", ".rtf", ".epub", ".org"})
_OUTLINE_INPUT_SUFFIXES = frozenset({".md", ".markdown", ".html", ".htm", ".txt"})


def _write_outline_sidecar(
    base: Path,
    norm_path: Path,
    *,
    max_heading_level: int,
) -> str | None:
    if norm_path.suffix.lower() not in _OUTLINE_INPUT_SUFFIXES:
        return None
    sub = base / OUTLINES_SUBDIR
    sub.mkdir(parents=True, exist_ok=True)
    dest = sub / f"{norm_path.stem}.json"
    payload = build_outline_payload(norm_path, max_heading_level=max_heading_level)
    write_outline_json(payload, dest)
    return str(dest.resolve())


def _patch_manifest_outline_field(manifest_path: Path, outline_abs: str) -> None:
    try:
        man = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return
    if isinstance(man, dict) and man.get("schema") == MANIFEST_SCHEMA:
        man["outline_path"] = outline_abs
        manifest_path.write_text(
            json.dumps(man, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def _extract_options_key(
    suf: str,
    *,
    docx_engine: str | None,
    page_start: int | None,
    page_end: int | None,
    use_ocr: bool,
    sheet_names: list[str] | None,
    markdown_engine: str | None,
    markitdown_use_llm: bool,
) -> dict[str, Any]:
    """仅纳入与当前扩展名相关的抽取参数，避免无关字段导致缓存误未命中。"""
    d: dict[str, Any] = {}
    if suf == ".docx":
        d["docx_engine"] = (docx_engine or "mammoth").strip().lower()
    if suf == ".pdf":
        d["page_start"] = page_start
        d["page_end"] = page_end
        d["use_ocr"] = bool(use_ocr)
    if suf == ".pptx":
        d["page_start"] = page_start
        d["page_end"] = page_end
    if suf == ".xlsx":
        d["page_start"] = page_start
        d["page_end"] = page_end
        d["sheet_names"] = list(sheet_names) if sheet_names else None
    if suf in _PANDOC_INPUT_SUFFIXES:
        d["via"] = "pandoc"
    if suf in (".pdf", ".docx", ".pptx", ".xlsx"):
        me = (markdown_engine or "").strip().lower()
        d["markdown_engine"] = me if me == "markitdown" else "legacy"
        if me == "markitdown":
            d["markitdown_use_llm"] = bool(markitdown_use_llm)
    return d


def _try_cache_hit(
    *,
    manifest_path: Path,
    base: Path,
    source_stat: dict[str, int],
    opt_key: dict[str, Any],
    save_outline: bool,
    outline_max_heading_level: int,
) -> dict[str, Any] | None:
    """若清单有效且源未变，返回成功结果；否则 ``None``。"""
    try:
        old = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if not isinstance(old, dict) or old.get("schema") != MANIFEST_SCHEMA:
        return None
    ost = old.get("source_stat") or {}
    old_opts = old.get("extract_options") or {}
    if (
        ost.get("size") != source_stat["size"]
        or ost.get("mtime_ns") != source_stat["mtime_ns"]
        or old_opts != opt_key
    ):
        return None
    np = old.get("normalized_path")
    if not np or not Path(np).is_file():
        return None

    notes = ["cache_hit: source mtime/size and extract_options unchanged"]
    outline_ptr: str | None = old.get("outline_path")
    if save_outline:
        omh = clamp_heading_level(outline_max_heading_level)
        op = _write_outline_sidecar(
            base,
            Path(np),
            max_heading_level=omh,
        )
        if op:
            outline_ptr = op
            _patch_manifest_outline_field(manifest_path, op)
            notes.append("refreshed outlines/ JSON (save_outline)")

    return {
        "ok": True,
        "cache_hit": True,
        "manifest_path": str(manifest_path),
        "normalized_path": np,
        "normalized_format": old.get("normalized_format"),
        "images_dir": old.get("images_dir"),
        "outline_path": outline_ptr,
        "extract_options": opt_key,
        "notes": notes,
    }


def _copy_or_convert_normalized(
    src: Path,
    suf: str,
    norm_sub: Path,
    docs_convert: Any,
    *,
    page_start: int | None,
    page_end: int | None,
    use_ocr: bool,
    sheet_names: list[str] | None,
    docx_engine: str | None,
    markdown_engine: str | None,
    markitdown_llm_client: Any | None,
    markitdown_llm_model: str | None,
) -> tuple[Path, str, list[str], str | None, str | None]:
    """返回 (norm_path, format, notes, images_dir, images_relative_prefix)。"""
    notes: list[str] = []
    images_dir: str | None = None
    rel_img: str | None = None

    if suf in (".md", ".markdown"):
        dest = norm_sub / f"{src.stem}.md"
        shutil.copy2(src, dest)
        return dest, "markdown", notes, None, None
    if suf in (".html", ".htm"):
        dest = norm_sub / f"{src.stem}{suf}"
        shutil.copy2(src, dest)
        notes.append("HTML copied; use **document_outline** on this path for headings.")
        return dest, "html", notes, None, None
    if suf == ".txt":
        dest = norm_sub / f"{src.stem}.txt"
        shutil.copy2(src, dest)
        notes.append("Plain text; **document_outline** supports .txt for line-based index.")
        return dest, "txt", notes, None, None

    r = docs_convert.convert_document(
        str(src),
        str(norm_sub),
        output_format="markdown",
        page_start=page_start,
        page_end=page_end,
        use_ocr=use_ocr,
        sheet_names=sheet_names,
        docx_engine=docx_engine,
        markdown_engine=markdown_engine,
        markitdown_llm_client=markitdown_llm_client,
        markitdown_llm_model=markitdown_llm_model,
    )
    if not r.get("ok"):
        raise _ConvertError(r)

    norm_path = Path(str(r["output_path"]))
    fmt = str(r.get("output_format") or "markdown")
    images_dir = r.get("images_dir")
    rel_img = r.get("images_relative_prefix")
    notes.extend(r.get("notes") or [])
    return norm_path, fmt, notes, images_dir, rel_img


class _ConvertError(Exception):
    def __init__(self, payload: dict[str, Any]) -> None:
        super().__init__(payload.get("error", "convert failed"))
        self.payload = payload


def run_doc_normalize(
    source_path: str,
    output_dir: str,
    *,
    docs_convert: Any,
    policy_check: Callable[[Path], None],
    use_cache: bool = True,
    force_refresh: bool = False,
    page_start: int | None = None,
    page_end: int | None = None,
    use_ocr: bool = False,
    sheet_names: list[str] | None = None,
    docx_engine: str | None = None,
    markdown_engine: str | None = None,
    markitdown_use_llm: bool = False,
    markitdown_llm_client: Any | None = None,
    markitdown_llm_model: str | None = None,
    save_outline: bool = False,
    outline_max_heading_level: int = 6,
) -> dict[str, Any]:
    src = Path(source_path).expanduser().resolve()
    policy_check(src)
    if not src.is_file():
        return {"ok": False, "error": f"not a file: {src}"}

    base = Path(output_dir).expanduser().resolve()
    policy_check(base)
    base.mkdir(parents=True, exist_ok=True)
    paths = corpus_paths(base)
    norm_sub = paths["normalized"]
    norm_sub.mkdir(parents=True, exist_ok=True)
    manifest_path = paths["manifest"]

    try:
        source_stat = source_stat_from_path(src)
    except OSError as e:
        return {"ok": False, "error": str(e)}

    suf = src.suffix.lower()
    opt_key = _extract_options_key(
        suf,
        docx_engine=docx_engine,
        page_start=page_start,
        page_end=page_end,
        use_ocr=use_ocr,
        sheet_names=sheet_names,
        markdown_engine=markdown_engine,
        markitdown_use_llm=markitdown_use_llm,
    )

    if use_cache and not force_refresh and manifest_path.is_file():
        hit = _try_cache_hit(
            manifest_path=manifest_path,
            base=base,
            source_stat=source_stat,
            opt_key=opt_key,
            save_outline=save_outline,
            outline_max_heading_level=outline_max_heading_level,
        )
        if hit is not None:
            return hit

    try:
        me_l = (markdown_engine or "").strip().lower()
        mlc = (
            markitdown_llm_client
            if me_l == "markitdown" and markitdown_use_llm
            else None
        )
        mlm = (
            markitdown_llm_model
            if me_l == "markitdown" and markitdown_use_llm
            else None
        )
        norm_path, fmt, notes, images_dir, rel_img = _copy_or_convert_normalized(
            src,
            suf,
            norm_sub,
            docs_convert,
            page_start=page_start,
            page_end=page_end,
            use_ocr=use_ocr,
            sheet_names=sheet_names,
            docx_engine=docx_engine,
            markdown_engine=markdown_engine,
            markitdown_llm_client=mlc,
            markitdown_llm_model=mlm,
        )
    except _ConvertError as e:
        return e.payload

    outline_ptr: str | None = None
    if save_outline:
        omh = clamp_heading_level(outline_max_heading_level)
        outline_ptr = _write_outline_sidecar(base, norm_path, max_heading_level=omh)
        if outline_ptr:
            notes.append("Outlines written under **outlines/** (see **outline_path**).")

    manifest: dict[str, Any] = {
        "schema": MANIFEST_SCHEMA,
        "source_path": str(src),
        "source_stat": source_stat,
        "extract_options": opt_key,
        "normalized_path": str(norm_path.resolve()),
        "normalized_format": fmt,
        "images_dir": images_dir,
        "images_relative_prefix": rel_img,
        "outline_path": outline_ptr,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return {
        "ok": True,
        "cache_hit": False,
        "manifest_path": str(manifest_path),
        "normalized_path": str(norm_path.resolve()),
        "normalized_format": fmt,
        "images_dir": images_dir,
        "images_relative_prefix": rel_img,
        "outline_path": outline_ptr,
        "extract_options": opt_key,
        "notes": notes,
    }
