"""
文档资料分析：**目录约定**、**JSON schema 标识**与**推荐流水线**。

实现分散在各工具中，本模块只做「单一事实来源」，避免魔法字符串与顺序混乱。

**推荐顺序（对模型 / 维护者）**

1. **``doc_normalize``** — 源文件 → ``<output_dir>/normalized/`` 规范副本 + ``cache_manifest.json``；
   可选 ``save_outline`` → ``<output_dir>/outlines/<stem>.json``（与 ``document_outline`` 落盘格式相同）。
2. **``document_outline``** — 若上一步未 ``save_outline``，或需单独对某路径建提纲 / 写库 ``outlines/``。
3. **``markdown_section_slice``** 或 **``fs_read_file``**（``byte_offset`` + ``max_bytes``）— 按节或按字节读，避免整文件进上下文。
4. **``markdown_regex_scan``** / **``fs_search_regex``** — 单文件或目录级检索。
5. **``markdown_chunk_split``** — 单文件仍过大时，写出 ``chunks/*.md`` + ``chunks/index.json``，再对 ``chunks/`` 检索。

**不**在本模块做 I/O；仅常量与纯小函数。
"""

from __future__ import annotations

from pathlib import Path

# —— 目录布局（相对某次分析的 ``output_dir`` / 缓存根） ——
NORMALIZED_SUBDIR = "normalized"
OUTLINES_SUBDIR = "outlines"
CHUNKS_SUBDIR = "chunks"

CACHE_MANIFEST_NAME = "cache_manifest.json"
CHUNK_INDEX_NAME = "index.json"

# —— JSON 根字段 ``schema`` ——
SCHEMA_DOC_NORMALIZE_MANIFEST = "aicd.doc_normalize.v1"
SCHEMA_CHUNK_INDEX = "aicd.markdown_chunk.v1"


def clamp_heading_level(level: int, *, lo: int = 1, hi: int = 6) -> int:
    return max(lo, min(hi, int(level)))


def source_stat_from_path(path: Path) -> dict[str, int]:
    """与 ``cache_manifest`` / ``chunks/index.json`` 中 ``source_stat`` 字段一致。"""
    st = path.stat()
    return {
        "size": st.st_size,
        "mtime_ns": getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)),
    }


def corpus_paths(cache_or_output_root: Path) -> dict[str, Path]:
    """解析一次 ``doc_normalize`` 使用的根目录下的标准子路径。"""
    base = cache_or_output_root.expanduser().resolve()
    return {
        "root": base,
        "normalized": base / NORMALIZED_SUBDIR,
        "outlines": base / OUTLINES_SUBDIR,
        "manifest": base / CACHE_MANIFEST_NAME,
    }
