"""HTML 画幅排版 → 截图 → 全幅导入 PPTX；落盘 **pptx_deck_source.json** 保留可编辑源页列表。"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from pptx import Presentation

from aicd.tools.html_screenshot import render_html_file_to_png
from aicd.tools.office_write import MAX_SLIDES, pptx_compose

MANIFEST_KEY = "aicd_pptx_deck_source"
MANIFEST_VERSION = "1"


def coerce_deck_slide_entries(raw: Any) -> tuple[list[dict[str, Any]], str | None]:
    """``slides`` 每项为 **html 路径字符串** 或 **{html_path, speaker_notes?}**。"""
    if not isinstance(raw, list) or not raw:
        return [], "slides must be a non-empty list"
    out: list[dict[str, Any]] = []
    for i, item in enumerate(raw):
        if isinstance(item, str):
            hp = item.strip()
            if not hp:
                return [], f"slides[{i}] empty string"
            out.append({"html_path": hp, "speaker_notes": None})
        elif isinstance(item, dict):
            hp = item.get("html_path") or item.get("path")
            if hp is None or not str(hp).strip():
                return [], f"slides[{i}] needs html_path (or path)"
            notes = item.get("speaker_notes")
            ns = None if notes is None else str(notes)
            out.append({"html_path": str(hp).strip(), "speaker_notes": ns})
        else:
            return [], f"slides[{i}] must be string or object"
    return out, None


def infer_deck_root(html_paths: list[Path]) -> Path:
    if not html_paths:
        raise ValueError("html_paths empty")
    parents = [p.expanduser().resolve().parent for p in html_paths]
    try:
        return Path(os.path.commonpath([str(p) for p in parents]))
    except ValueError:
        return parents[0]


def _auto_pick_blankish_layout(prs: Any) -> int:
    """选占位符最少的版式（常接近「空白」）；名称含 blank 优先。"""
    best_i = 0
    best_n = 10**9
    for i, layout in enumerate(prs.slide_layouts):
        try:
            phs = list(layout.placeholders)
        except Exception:
            phs = []
        n = len(phs)
        name = ""
        try:
            name = (layout.name or "").lower()
        except Exception:
            pass
        if "blank" in name and n <= 1:
            return i
        if n < best_n:
            best_n = n
            best_i = i
    return best_i


def resolve_layout_index(prs: Any, explicit: int | None) -> tuple[int, str | None]:
    if explicit is not None:
        li = int(explicit)
        if li < 0 or li >= len(prs.slide_layouts):
            return (
                0,
                f"layout_index {li} out of range 0..{len(prs.slide_layouts) - 1}",
            )
        return li, None
    return _auto_pick_blankish_layout(prs), None


def _rel_under(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def pptx_from_html_deck(
    path_out: Path,
    slides: list[dict[str, Any]],
    *,
    deck_root: Path | None,
    policy_check: Callable[[Path], None],
    template_path: Path | None = None,
    layout_index: int | None = None,
    viewport_width: int = 1280,
    viewport_height: int = 720,
    device_scale_factor: float = 2.0,
    wait_after_load_ms: int = 1200,
    timeout_ms: int = 120_000,
    manifest_filename: str = "pptx_deck_source.json",
    png_subdir: str = "_pptx_export/png",
) -> dict[str, Any]:
    """
    按顺序将每页 **HTML** 以固定视口截图，再 **全幅贴入** 每张幻灯片；写入 **manifest** 记录源 HTML 与导出 PNG，
    便于用户改样式、插页后再次调用本函数或手工重跑截图 + ``pptx_compose``。

    - **源文件**：不删除、不修改各 ``.html``；同级 ``res/`` 照常由浏览器加载。
    - **衍生品**：``deck_root / png_subdir / slide_NNN.png`` 可安全重生成。
    """
    if len(slides) > MAX_SLIDES:
        return {"ok": False, "error": f"max {MAX_SLIDES} slides"}
    if (
        viewport_width < 16
        or viewport_width > 4096
        or viewport_height < 16
        or viewport_height > 4096
    ):
        return {
            "ok": False,
            "error": "viewport_width and viewport_height must be within 16..4096",
        }

    resolved_html: list[Path] = []
    for i, entry in enumerate(slides):
        hp = Path(entry["html_path"]).expanduser().resolve()
        policy_check(hp)
        if not hp.is_file():
            return {"ok": False, "error": f"slides[{i}] html not found: {hp}"}
        suf = hp.suffix.lower()
        if suf not in {".html", ".htm"}:
            return {"ok": False, "error": f"slides[{i}] must be .html or .htm, got {hp}"}
        resolved_html.append(hp)

    root = deck_root.expanduser().resolve() if deck_root is not None else infer_deck_root(resolved_html)
    policy_check(root)
    png_dir = (root / png_subdir).resolve()
    policy_check(png_dir)
    png_dir.mkdir(parents=True, exist_ok=True)

    if template_path is not None:
        tp = template_path.expanduser().resolve()
        policy_check(tp)
        if not tp.is_file() or tp.suffix.lower() != ".pptx":
            return {"ok": False, "error": "template_path must be an existing .pptx"}
        prs0 = Presentation(str(tp))
    else:
        prs0 = Presentation()

    slide_w_in = prs0.slide_width / 914400
    slide_h_in = prs0.slide_height / 914400
    li, err = resolve_layout_index(prs0, layout_index)
    if err:
        return {"ok": False, "error": err}

    compose_specs: list[dict[str, Any]] = []
    manifest_entries: list[dict[str, Any]] = []
    png_paths: list[str] = []

    for i, entry in enumerate(slides):
        hp = resolved_html[i]
        png_path = png_dir / f"slide_{i:03d}.png"
        policy_check(png_path)
        render_res = render_html_file_to_png(
            hp,
            png_path,
            policy_check=policy_check,
            selector=None,
            full_page=False,
            viewport_width=viewport_width,
            viewport_height=viewport_height,
            device_scale_factor=device_scale_factor,
            wait_after_load_ms=wait_after_load_ms,
            timeout_ms=timeout_ms,
        )
        if not render_res.get("ok"):
            return {
                "ok": False,
                "error": render_res.get("error", "html render failed"),
                "hint": render_res.get("hint"),
                "failed_slide_index": i,
                "html_path": str(hp),
            }

        spec: dict[str, Any] = {
            "layout_index": li,
            "title": "",
            "bullets": [],
            "image_path": str(png_path.resolve()),
            "image_left_in": 0.0,
            "image_top_in": 0.0,
            "image_width_in": slide_w_in,
            "image_height_in": slide_h_in,
        }
        notes = entry.get("speaker_notes")
        if notes:
            spec["speaker_notes"] = str(notes)
        compose_specs.append(spec)
        png_paths.append(str(png_path.resolve()))
        manifest_entries.append(
            {
                "index": i,
                "html": _rel_under(root, hp),
                "png": _rel_under(root, png_path.resolve()),
                "speaker_notes": bool(notes),
            }
        )

    out = pptx_compose(
        path_out.expanduser().resolve(),
        compose_specs,
        policy_check=policy_check,
        template_path=template_path.expanduser().resolve() if template_path else None,
    )
    if not out.get("ok"):
        return out

    manifest_path = (root / manifest_filename).resolve()
    policy_check(manifest_path)
    payload = {
        MANIFEST_KEY: MANIFEST_VERSION,
        "strategy": "html_viewport_raster_full_bleed",
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "deck_root": str(root),
        "pptx_out": str(path_out.expanduser().resolve()),
        "viewport_css_px": [viewport_width, viewport_height],
        "template_path": str(template_path.resolve()) if template_path else None,
        "layout_index": li,
        "slides": manifest_entries,
        "notes": "Edit HTML (and CSS) under deck_root, add/reorder slides in this manifest or pass a new slides[] list, then re-run pptx_from_html_deck. PNGs under _pptx_export/ are reproducible derivatives.",
    }
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "ok": True,
        "path": out.get("path"),
        "slide_count": out.get("slide_count"),
        "deck_root": str(root),
        "manifest_path": str(manifest_path),
        "png_paths": png_paths,
        "viewport_css_px": [viewport_width, viewport_height],
        "layout_index": li,
        "source_html_retained": True,
    }
