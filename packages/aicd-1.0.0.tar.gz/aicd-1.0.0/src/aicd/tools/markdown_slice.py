"""按字节范围读取文档的一节或一段。

两种模式（二选一）：

- **标题模式**：**``heading_index``** + 可选 **``outline_path``**；边界来自提纲里的 **``byte_offset``**。
- **裸范围模式**：仅 **``start_byte``** / **``end_byte``**；**不**构建提纲，适合无标题大文件。

与 **``fs_read_file``** 一样受路径策略约束；推荐流水线见 **``doc_analysis_kit``**。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from aicd.tools.document_outline import build_outline_payload, read_outline_json
from aicd.tools.fs_tool import FSTool


def _breadcrumb(headings: list[dict[str, Any]], index: int) -> list[str]:
    stack: list[tuple[int, str]] = []
    for i in range(index + 1):
        h = headings[i]
        lv = int(h["level"])
        t = str(h.get("text") or "").strip()
        while stack and stack[-1][0] >= lv:
            stack.pop()
        stack.append((lv, t))
    return [t for _, t in stack]


def _resolve_slice_payload(
    *,
    st: Path,
    outline_path: Path | None,
    use_heading: bool,
    max_heading_level: int,
) -> dict[str, Any] | tuple[str, dict[str, Any]]:
    """返回 ``payload``；若出错返回 ``(error_message, {})``。"""
    if outline_path is not None:
        op = outline_path.expanduser().resolve()
        try:
            payload = read_outline_json(op)
        except (OSError, json.JSONDecodeError, ValueError) as e:
            return (f"outline_path: {e}", {})
    elif use_heading:
        payload = build_outline_payload(st, max_heading_level=max_heading_level)
    else:
        payload = {"source_path": str(st.resolve()), "headings": []}

    if outline_path is not None or use_heading:
        src_in_outline = str(payload.get("source_path") or "")
        if src_in_outline and Path(src_in_outline).resolve() != st.resolve():
            return (
                "outline source_path does not match document path",
                {
                    "outline_source": src_in_outline,
                    "document_path": str(st),
                },
            )
    return payload


def run_markdown_section_slice(
    doc_path: Path,
    fs: FSTool,
    *,
    outline_path: Path | None = None,
    heading_index: int | None = None,
    start_byte: int | None = None,
    end_byte: int | None = None,
    max_heading_level: int = 6,
    max_read_bytes: int | None = None,
    align_utf8: bool = True,
) -> dict[str, Any]:
    if heading_index is not None and (start_byte is not None or end_byte is not None):
        return {
            "ok": False,
            "error": "use either heading_index or explicit start_byte/end_byte, not both",
        }
    if heading_index is None and (start_byte is None and end_byte is None):
        return {
            "ok": False,
            "error": "provide heading_index or start_byte/end_byte",
        }

    st = doc_path.expanduser().resolve()
    if not st.is_file():
        return {"ok": False, "error": f"not a file: {st}"}
    try:
        sz = st.stat().st_size
    except OSError as e:
        return {"ok": False, "error": str(e)}

    use_heading = heading_index is not None
    resolved = _resolve_slice_payload(
        st=st,
        outline_path=outline_path,
        use_heading=use_heading,
        max_heading_level=max_heading_level,
    )
    if isinstance(resolved, tuple):
        err, extra = resolved
        out: dict[str, Any] = {"ok": False, "error": err}
        out.update(extra)
        return out
    payload = resolved

    if use_heading:
        assert heading_index is not None
        headings = payload.get("headings")
        if not isinstance(headings, list) or not headings:
            return {"ok": False, "error": "outline has no headings", "heading_count": 0}
        hi = int(heading_index)
        if hi < 0 or hi >= len(headings):
            return {
                "ok": False,
                "error": f"heading_index {hi} out of range (0..{len(headings) - 1})",
            }
        hb = headings[hi]
        sb = int(hb["byte_offset"])
        if hi + 1 < len(headings):
            eb = int(headings[hi + 1]["byte_offset"])
        else:
            eb = sz
        title = str(hb.get("text") or "")
        line_start = int(hb.get("line") or 1)
        crumb = _breadcrumb(headings, hi)
    else:
        sb = 0 if start_byte is None else int(start_byte)
        eb = sz if end_byte is None else int(end_byte)
        title = ""
        line_start = None
        crumb = []
        hi = -1

    if sb < 0 or eb < sb:
        return {"ok": False, "error": "invalid byte range"}
    if eb > sz:
        eb = sz

    span = eb - sb
    read_cap = span if max_read_bytes is None else min(span, int(max_read_bytes))

    r = fs.read_file(
        str(st),
        byte_offset=sb,
        max_bytes=read_cap,
        align_utf8=align_utf8,
    )
    if not r.get("ok"):
        return r

    line_end: int | None = None
    if heading_index is not None and r.get("text") and line_start is not None:
        line_end = line_start + r["text"].count("\n")

    return {
        "ok": True,
        "path": str(st),
        "heading_index": hi if heading_index is not None else None,
        "title": title,
        "heading_path": crumb,
        "start_byte": sb,
        "end_byte_exclusive": eb,
        "bytes_requested": read_cap,
        "line_start": line_start,
        "line_end": line_end,
        "text": r.get("text"),
        "truncated": bool(r.get("truncated"))
        or (read_cap < span),
        "fs_meta": {
            "byte_offset": r.get("byte_offset"),
            "bytes_read": r.get("bytes_read"),
            "utf8_trim_prefix": r.get("utf8_trim_prefix"),
            "utf8_trim_suffix": r.get("utf8_trim_suffix"),
            "file_size": sz,
        },
    }
