"""Office OOXML 文档内文本换行：Word / PowerPoint / Excel 对单独 ``\\n`` 的显示常不理想，统一为 CRLF。"""

from __future__ import annotations


def normalize_office_newlines(text: str) -> str:
    """
    将段内/单元格内换行规范为 **CRLF**。

    先将 ``\\r\\n`` 与孤立 ``\\r`` 合并为 ``\\n``，再把 ``\\n`` 转为 ``\\r\\n``，避免重复 ``\\r``。
    应用于 **docx_compose** / **pptx_compose** / **xlsx_*** 写入路径；公式串请勿先做此处理
    （在各自 ``_coerce`` 里对非公式分支调用）。
    """
    if not text:
        return text
    t = text.replace("\r\n", "\n").replace("\r", "\n")
    if "\n" not in t:
        return t
    return t.replace("\n", "\r\n")
