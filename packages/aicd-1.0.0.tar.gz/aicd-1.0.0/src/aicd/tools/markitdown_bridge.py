﻿"""可选 MarkItDown 引擎：PDF/DOCX/PPTX/XLSX → Markdown（可选 OpenAI 兼容 llm_client 做图/页描述）。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

_MARKITDOWN_OFFICE = frozenset({".pdf", ".docx", ".pptx", ".xlsx"})


def markitdown_available() -> bool:
    try:
        import markitdown  # noqa: F401
    except ImportError:
        return False
    return True


def convert_with_markitdown(
    src: Path,
    out: Path,
    stem: str,
    images_dir: Path,
    *,
    llm_client: Any | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    suf = src.suffix.lower()
    if suf not in _MARKITDOWN_OFFICE:
        return {
            "ok": False,
            "error": f"markitdown path only supports {sorted(_MARKITDOWN_OFFICE)} here",
        }
    try:
        from markitdown import MarkItDown
    except ImportError:
        return {
            "ok": False,
            "error": "markitdown package not installed",
            "hint": "pip install 'aicd[markitdown]' or pip install markitdown",
        }
    init_kw: dict[str, Any] = {}
    if llm_client is not None and llm_model:
        init_kw["llm_client"] = llm_client
        init_kw["llm_model"] = llm_model
    md = MarkItDown(**init_kw)
    result = md.convert(str(src))
    text = getattr(result, "text_content", None)
    if text is None:
        text = str(result)
    text_s = text or ""
    out_path = out / f"{stem}.md"
    out_path.write_text(text_s, encoding="utf-8")
    notes: list[str] = ["Extracted via optional **markitdown** engine."]
    if llm_client is not None:
        notes.append("MarkItDown LLM caption path enabled (provider billing applies).")
    return {
        "ok": True,
        "output_path": str(out_path.resolve()),
        "output_format": "markdown",
        "output_text_chars": len(text_s),
        "images_dir": str(images_dir.resolve()),
        "images_relative_prefix": images_dir.name,
        "notes": notes,
    }
