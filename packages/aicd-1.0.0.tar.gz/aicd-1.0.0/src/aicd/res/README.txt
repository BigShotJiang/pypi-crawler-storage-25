Offline visualization bundles for exported HTML (copied next to the .html as res/).

Files (re-fetch with: python scripts/download_viz_res.py):
- chart.umd.min.js — Chart.js 4.4.6 (MIT)
- mermaid.min.js — Mermaid 11.4.1 (MIT)
- vis-network.min.js / vis-network.min.css — vis-network 9.1.9 (MIT / Apache-2.0)

See project README for viz_export_html tool usage.
