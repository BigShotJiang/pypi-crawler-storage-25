from aicd.ui.tui import AicdTui

__all__ = ["AicdTui"]
