"""pptx_from_html：coerce / deck_root；整链需 Playwright 时跳过。"""

from __future__ import annotations

from pathlib import Path

import pytest

from aicd.config import PathPolicyConfig
from aicd.tools.path_policy import PathPolicy
from aicd.tools.pptx_from_html import (
    coerce_deck_slide_entries,
    infer_deck_root,
    pptx_from_html_deck,
)


def test_coerce_deck_slide_entries_strings_and_objects() -> None:
    raw = ["a.html", {"html_path": "b.html", "speaker_notes": "n1"}]
    items, err = coerce_deck_slide_entries(raw)
    assert err is None
    assert items[0]["html_path"] == "a.html"
    assert items[0]["speaker_notes"] is None
    assert items[1]["html_path"] == "b.html"
    assert items[1]["speaker_notes"] == "n1"


def test_coerce_deck_slide_entries_path_alias() -> None:
    items, err = coerce_deck_slide_entries([{"path": "x.html"}])
    assert err is None
    assert items[0]["html_path"] == "x.html"


def test_pptx_from_html_rejects_bad_viewport(tmp_path: Path) -> None:
    pol = PathPolicy(PathPolicyConfig(full_disk=True))
    deck = tmp_path / "d"
    deck.mkdir()
    h = deck / "1.html"
    h.write_text("<html/>", encoding="utf-8")
    r = pptx_from_html_deck(
        deck / "o.pptx",
        [{"html_path": str(h)}],
        deck_root=deck,
        policy_check=pol.check_allowed,
        viewport_width=4,
        viewport_height=720,
    )
    assert r.get("ok") is False
    assert "4096" in (r.get("error") or "") or "16" in (r.get("error") or "")


def test_infer_deck_root_common_parent(tmp_path: Path) -> None:
    d = tmp_path / "deck" / "slides"
    d.mkdir(parents=True)
    a = d / "1.html"
    b = d / "2.html"
    a.write_text("<html/>", encoding="utf-8")
    b.write_text("<html/>", encoding="utf-8")
    root = infer_deck_root([a, b])
    assert root == d


def _chromium_available() -> bool:
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            browser.close()
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _chromium_available(), reason="Playwright Chromium not installed")
def test_pptx_from_html_deck_writes_manifest_and_pptx(tmp_path: Path) -> None:
    pol = PathPolicy(PathPolicyConfig(full_disk=True))
    deck = tmp_path / "mydeck"
    slides_dir = deck / "slides"
    slides_dir.mkdir(parents=True)
    h1 = slides_dir / "01.html"
    h2 = slides_dir / "02.html"
    h1.write_text(
        "<!DOCTYPE html><html><body style='margin:0;font:24px sans-serif;background:#eed'>"
        "<div style='padding:40px'>S1</div></body></html>",
        encoding="utf-8",
    )
    h2.write_text(
        "<!DOCTYPE html><html><body style='margin:0;font:24px sans-serif;background:#dee'>"
        "<div style='padding:40px'>S2</div></body></html>",
        encoding="utf-8",
    )
    out_pptx = deck / "out.pptx"
    r = pptx_from_html_deck(
        out_pptx,
        [
            {"html_path": str(h1), "speaker_notes": "note one"},
            {"html_path": str(h2)},
        ],
        deck_root=deck,
        policy_check=pol.check_allowed,
        wait_after_load_ms=400,
        viewport_width=800,
        viewport_height=450,
    )
    assert r.get("ok") is True, r
    assert out_pptx.is_file()
    man = deck / "pptx_deck_source.json"
    assert man.is_file()
    text = man.read_text(encoding="utf-8")
    assert "aicd_pptx_deck_source" in text
    assert "01.html" in text
    png_dir = deck / "_pptx_export" / "png"
    assert (png_dir / "slide_000.png").is_file()
    assert (png_dir / "slide_001.png").is_file()
