"""style_reference_scan、office_write（xlsx/pptx）、docx 样式 profile。"""

from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook
from pptx import Presentation

from aicd.tools.office_write import pptx_compose, pptx_inspect_template, xlsx_write_workbook
from aicd.tools.style_reference import load_docx_style_profile, scan_style_reference


def _policy(p: Path) -> None:
    return None


def test_load_docx_style_profile(tmp_path: Path) -> None:
    y = tmp_path / "s.yaml"
    y.write_text(
        "docx_defaults:\n  default_east_asia_font: 楷体\n  default_body_font_pt: 11\n"
        "notes: |\n  标题居中\n",
        encoding="utf-8",
    )
    r = load_docx_style_profile(y, policy_check=_policy)
    assert r["ok"] is True
    assert r["docx_defaults"]["default_east_asia_font"] == "楷体"
    assert r["docx_defaults"]["default_body_font_pt"] == 11
    assert "标题居中" in r["notes"]


def test_scan_style_reference_dir(tmp_path: Path) -> None:
    d = tmp_path / "ref"
    d.mkdir()
    (d / "tone.md").write_text("# Brand\nUse formal Chinese.\n", encoding="utf-8")
    r = scan_style_reference(d, policy_check=_policy)
    assert r["ok"] is True
    assert r["entry_count"] >= 1
    assert "formal" in r["style_digest"] or "Brand" in r["style_digest"]


def test_xlsx_write_workbook_roundtrip(tmp_path: Path) -> None:
    p = tmp_path / "book.xlsx"
    r = xlsx_write_workbook(
        p,
        [
            {"name": "S1", "headers": ["a", "b"], "rows": [["1", "2"]]},
            {"name": "S2", "rows": [["x"]]},
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    wb = load_workbook(p)
    assert "S1" in wb.sheetnames and "S2" in wb.sheetnames
    assert wb["S1"].cell(1, 1).value == "a"
    assert wb["S1"].cell(2, 1).value == "1"


def test_pptx_compose_and_inspect(tmp_path: Path) -> None:
    out = tmp_path / "deck.pptx"
    r = pptx_compose(
        out,
        [
            {"layout_index": 1, "title": "Hi", "bullets": ["a", "b"]},
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    assert out.is_file()
    prs = Presentation(str(out))
    assert len(prs.slides) == 1

    ins = pptx_inspect_template(out, policy_check=_policy)
    assert ins["ok"] is True
    assert ins["layout_count"] >= 1
    assert isinstance(ins.get("shape_kind_examples"), list)
    assert "chevron" in ins["shape_kind_examples"]


def test_pptx_compose_shapes_table_chart(tmp_path: Path) -> None:
    out = tmp_path / "rich.pptx"
    r = pptx_compose(
        out,
        [
            {
                "layout_index": 1,
                "title": "Q1",
                "bullets": ["Summary"],
                "shapes": [
                    {
                        "kind": "rounded_rectangle",
                        "left_in": 8.5,
                        "top_in": 0.3,
                        "width_in": 1.2,
                        "height_in": 0.5,
                        "fill_rgb": [200, 220, 255],
                    },
                    {
                        "kind": "CHEVRON",
                        "left_in": 0.3,
                        "top_in": 6.5,
                        "width_in": 0.8,
                        "height_in": 0.6,
                        "fill_rgb": [255, 200, 100],
                    },
                ],
                "table": {
                    "data": [["KPI", "Val"], ["A", "1"]],
                    "table_left_in": 0.5,
                    "table_top_in": 4.5,
                    "table_width_in": 4.0,
                    "table_height_in": 1.0,
                },
                "chart": {
                    "chart_type": "column_stacked",
                    "categories": ["A", "B"],
                    "series": [
                        {"name": "S1", "values": [1, 2]},
                        {"name": "S2", "values": [2, 5]},
                    ],
                    "chart_title": "Demo",
                    "chart_left_in": 5.0,
                    "chart_top_in": 4.0,
                    "chart_width_in": 4.5,
                    "chart_height_in": 3.0,
                },
                "text_boxes": [
                    {
                        "left_in": 0.5,
                        "top_in": 6.0,
                        "width_in": 4.0,
                        "height_in": 0.6,
                        "lines": ["Caption: KPI table + chart"],
                        "font_pt": 11,
                        "bold": True,
                    }
                ],
                "speaker_notes": "Say: focus on stacked contribution.",
                "slide_transition": {"effect": "fade", "speed": "med"},
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    prs = Presentation(str(out))
    assert len(prs.slides) == 1
    s0 = prs.slides[0]
    assert s0.has_notes_slide
    assert "stacked" in s0.notes_slide.notes_text_frame.text.lower()
