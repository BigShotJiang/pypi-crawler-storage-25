"""doc_normalize cache, markdown_section_slice, regex scan, chunk split."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aicd.tools.doc_normalize import run_doc_normalize
from aicd.tools.docs_convert import DocumentConverter
from aicd.tools.fs_tool import FSTool
from aicd.tools.path_policy import PathPolicy
from aicd.tools.markdown_chunk import run_markdown_chunk_split
from aicd.tools.markdown_regex_scan import run_markdown_regex_scan
from aicd.tools.document_outline import read_outline_json, write_outline_json
from aicd.tools.markdown_slice import run_markdown_section_slice


@pytest.fixture
def policy(tmp_path: Path):
    from aicd.config import PathPolicyConfig

    cfg = PathPolicyConfig(
        allowed_roots=[str(tmp_path.resolve())],
        max_read_bytes=100_000,
        max_search_file_bytes=1_000_000,
    )
    pol = PathPolicy(cfg)
    pol.set_workspace_root(tmp_path)
    return pol


def test_read_outline_json_roundtrip(policy, tmp_path: Path) -> None:
    p = tmp_path / "ol.json"
    body = {"source_path": "/x", "heading_count": 0, "headings": [], "format_detected": "markdown"}
    write_outline_json(body, p)
    got = read_outline_json(p)
    assert got["heading_count"] == 0


def test_doc_normalize_cache_copy_md(policy, tmp_path: Path) -> None:
    src = tmp_path / "a.md"
    src.write_text("# Hi\n\nbody\n", encoding="utf-8")
    out_base = tmp_path / "out"

    dc = DocumentConverter(policy.check_allowed)
    r1 = run_doc_normalize(
        str(src),
        str(out_base),
        docs_convert=dc,
        policy_check=policy.check_allowed,
    )
    assert r1["ok"] and not r1.get("cache_hit")
    r2 = run_doc_normalize(
        str(src),
        str(out_base),
        docs_convert=dc,
        policy_check=policy.check_allowed,
    )
    assert r2["ok"] and r2.get("cache_hit")
    man = json.loads((out_base / "cache_manifest.json").read_text(encoding="utf-8"))
    assert man["schema"] == "aicd.doc_normalize.v1"
    assert "extract_options" in man


def test_doc_normalize_save_outline(policy, tmp_path: Path) -> None:
    src = tmp_path / "b.md"
    src.write_text("# T\n\npara\n", encoding="utf-8")
    out_base = tmp_path / "norm_out"
    dc = DocumentConverter(policy.check_allowed)
    r = run_doc_normalize(
        str(src),
        str(out_base),
        docs_convert=dc,
        policy_check=policy.check_allowed,
        save_outline=True,
    )
    assert r["ok"] and r.get("outline_path")
    assert (out_base / "outlines" / "b.json").is_file()
    man = json.loads((out_base / "cache_manifest.json").read_text(encoding="utf-8"))
    assert man.get("outline_path")


def test_markdown_section_slice_explicit_bytes_no_headings(
    policy, tmp_path: Path
) -> None:
    p = tmp_path / "plain.log"
    p.write_text("no headings at all\nsecond line\n", encoding="utf-8")
    fs = FSTool(policy, tmp_path)
    r = run_markdown_section_slice(
        p,
        fs,
        start_byte=0,
        end_byte=10,
    )
    assert r["ok"]
    assert "no heading" in (r.get("text") or "")


def test_markdown_section_slice_heading(policy, tmp_path: Path) -> None:
    p = tmp_path / "x.md"
    p.write_text("# A\n\n## B\n\nHello\n\n## C\n\nWorld\n", encoding="utf-8")
    fs = FSTool(policy, tmp_path)
    r = run_markdown_section_slice(
        p,
        fs,
        heading_index=1,
        max_heading_level=6,
    )
    assert r["ok"]
    assert "## B" in (r.get("text") or "")
    assert "World" not in (r.get("text") or "")


def test_markdown_regex_scan_lines(policy, tmp_path: Path) -> None:
    p = tmp_path / "l.txt"
    p.write_text("a\nfoo BAR x\nb\n", encoding="utf-8")
    r = run_markdown_regex_scan(p, r"BAR", context_lines=1, max_matches=5)
    assert r["ok"] and r["match_count"] == 1
    assert r["matches"][0]["line"] == 2


def test_markdown_chunk_split(policy, tmp_path: Path) -> None:
    p = tmp_path / "big.md"
    p.write_text(
        "# T\n\n## one\n\n" + "x\n" * 5 + "\n## two\n\ny\n",
        encoding="utf-8",
    )
    od = tmp_path / "chunks_out"
    r = run_markdown_chunk_split(p, od, split_max_level=2, max_chunk_bytes=50)
    assert r["ok"] and r["chunk_count"] >= 1
    idx = Path(r["index_path"])
    assert idx.is_file()
    data = json.loads(idx.read_text(encoding="utf-8"))
    assert data["schema"] == "aicd.markdown_chunk.v1"
    assert "source_stat" in data and "size" in data["source_stat"]
    assert len(data["chunks"]) == r["chunk_count"]
