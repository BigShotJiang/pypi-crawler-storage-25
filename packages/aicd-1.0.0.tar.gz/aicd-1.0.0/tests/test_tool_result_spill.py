from __future__ import annotations

from pathlib import Path

from aicd.agent.chat_serialize import tool_result_content_for_llm


def test_tool_result_spill_writes_file_when_over_max(tmp_path: Path) -> None:
    spill = tmp_path / "spill"
    ws = tmp_path / "ws"
    ws.mkdir()
    big = {"items": [{"i": i, "t": "x" * 20} for i in range(400)]}
    body = tool_result_content_for_llm(
        big,
        max_len=3000,
        spill_dir=spill,
        workspace_root=ws,
        tool_name="demo_tool",
    )
    assert "_aicd_tool_result_spill" in body
    assert "spill_path_absolute" in body
    assert spill.exists()
    files = list(spill.glob("*.json"))
    assert len(files) == 1
    assert files[0].stat().st_size > 3000


def test_tool_result_no_spill_when_under_max(tmp_path: Path) -> None:
    small = {"ok": True, "n": 1}
    body = tool_result_content_for_llm(
        small,
        max_len=10_000,
        spill_dir=tmp_path / "unused_spill",
        workspace_root=tmp_path,
        tool_name="x",
    )
    assert "_aicd_tool_result_spill" not in body
    assert '"n": 1' in body
