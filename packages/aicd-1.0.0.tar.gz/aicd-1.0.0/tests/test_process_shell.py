"""Windows / Unix shell argv 构造。"""

from __future__ import annotations

import sys

import pytest

from aicd.tools import process_tool as pt


def test_shell_argv_posix(monkeypatch) -> None:
    monkeypatch.setattr(sys, "platform", "linux")
    av = pt.shell_argv_from_user_input(command="echo hi")
    assert av == ["/bin/sh", "-c", "echo hi"]


def test_shell_argv_posix_direct_argv(monkeypatch) -> None:
    monkeypatch.setattr(sys, "platform", "linux")
    av = pt.shell_argv_from_user_input(argv=["/bin/echo", "a b"])
    assert av == ["/bin/echo", "a b"]


def test_shell_argv_windows_cmd(monkeypatch) -> None:
    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setenv("ComSpec", r"C:\Windows\System32\cmd.exe")
    av = pt.shell_argv_from_user_input(command="dir")
    assert av[0].lower().endswith("cmd.exe")
    assert av[1] == "/d"
    assert av[2] == "/c"
    assert "chcp 65001" in av[3]
    assert av[3].endswith("& dir") or "& dir" in av[3]


def test_shell_argv_windows_powershell(monkeypatch) -> None:
    monkeypatch.setattr(sys, "platform", "win32")
    av = pt.shell_argv_from_user_input(command="Get-Location", shell="powershell")
    assert av[0].lower().endswith("powershell.exe") or "powershell" in av[0].lower()
    assert "-Command" in av
    assert av[-1] == "Get-Location"


def test_shell_argv_errors() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        pt.shell_argv_from_user_input(command="   ")
    with pytest.raises(ValueError, match="argv"):
        pt.shell_argv_from_user_input(argv=[])


def test_default_shell_argv_alias(monkeypatch) -> None:
    monkeypatch.setattr(sys, "platform", "linux")
    assert pt.default_shell_argv("x") == ["/bin/sh", "-c", "x"]


def test_coerce_run_command_options() -> None:
    assert pt.coerce_run_command_options({}) == {}
    assert pt.coerce_run_command_options({"command": "x"}) == {}
    assert pt.coerce_run_command_options({"noninteractive_env": True}) == {
        "noninteractive_env": True
    }
    assert pt.coerce_run_command_options({"stdin_mode": "auto_yes"}) == {
        "stdin_mode": "auto_yes"
    }
    o = pt.coerce_run_command_options(
        {"noninteractive_env": True, "stdin_mode": "devnull", "output_idle_timeout_sec": 120}
    )
    assert o == {
        "noninteractive_env": True,
        "stdin_mode": "devnull",
        "output_idle_timeout_sec": 120.0,
    }


def test_sanitize_shell_log_line() -> None:
    from aicd.ui.shell_log_sanitize import sanitize_shell_log_line

    assert sanitize_shell_log_line("plain") == "plain"
    assert "\x1b" not in sanitize_shell_log_line("a\x1b[31mred\x1b[0mb")
    assert sanitize_shell_log_line("done\roverwrite") == "overwrite"
