from __future__ import annotations

import json
from pathlib import Path

from aicd.tools.artifact_query import run_artifact_query


def test_artifact_meta_and_json_path(tmp_path: Path) -> None:
    p = tmp_path / "data.json"
    p.write_text(
        json.dumps({"a": {"b": [1, 2, {"c": "hello"}]}}, ensure_ascii=False),
        encoding="utf-8",
    )
    m = run_artifact_query(p, "meta")
    assert m["ok"] is True
    assert m["size_bytes"] > 0
    assert "head_preview" in m

    j = run_artifact_query(p, "json_path", json_path="a.b.2.c")
    assert j["ok"] is True
    assert j.get("value") == "hello"


def test_artifact_line_range(tmp_path: Path) -> None:
    p = tmp_path / "lines.txt"
    p.write_text("a\nb\nc\nd\n", encoding="utf-8")
    r = run_artifact_query(p, "line_range", start_line=2, max_lines=2)
    assert r["ok"] is True
    assert r["lines"] == ["b", "c"]
