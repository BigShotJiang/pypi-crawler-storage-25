"""启动环境横幅文案。"""

from __future__ import annotations

from aicd.env_probe import (
    BANNER_CRITICAL,
    BANNER_RECOMMEND,
    format_startup_env_chat_banner,
    startup_env_chat_banner_lines,
)


def test_banner_mentions_llm_when_no_key() -> None:
    data = {
        "os": {"system": "Windows", "release": "11"},
        "python": {"version": "3.12.0"},
        "commands": {"git": {"available": True}, "node": {"available": False}},
        "python_modules_optional": {},
    }
    s = format_startup_env_chat_banner(data, has_llm_api_key=False)
    assert "LLM" in s or "密钥" in s
    assert "系统环境检查" in s


def test_banner_ok_with_key() -> None:
    data = {
        "os": {"system": "Linux"},
        "python": {"version": "3.11"},
        "commands": {f"k{i}": {"available": True} for i in range(5)},
        "python_modules_optional": {"pytesseract": {"available": False}},
    }
    s = format_startup_env_chat_banner(data, has_llm_api_key=True)
    assert "runtime_env_refresh" in s
    assert "pytesseract" in s


def test_banner_lines_critical_without_llm_key() -> None:
    data = {
        "os": {"system": "Windows", "release": "11"},
        "python": {"version": "3.12.0"},
        "commands": {"git": {"available": True}},
        "python_modules_optional": {},
    }
    rows = startup_env_chat_banner_lines(data, has_llm_api_key=False)
    kinds = [k for _, k in rows]
    assert BANNER_CRITICAL in kinds
    assert BANNER_RECOMMEND in kinds


def test_banner_lines_no_critical_when_key_ok() -> None:
    data = {
        "os": {"system": "Linux"},
        "python": {"version": "3.11"},
        "commands": {"git": {"available": True}, "node": {"available": True}},
        "python_modules_optional": {},
    }
    rows = startup_env_chat_banner_lines(data, has_llm_api_key=True)
    kinds = [k for _, k in rows]
    assert BANNER_CRITICAL not in kinds
