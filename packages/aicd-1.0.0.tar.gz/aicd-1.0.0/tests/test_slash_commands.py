"""slash 命令辅助函数。"""

from __future__ import annotations

from aicd.ui.slash_commands import join_args_for_shell, parse_slash_line


def test_parse_task_line() -> None:
    p = parse_slash_line("/task ai do something")
    assert p is not None
    cmd, args = p
    assert cmd == "task"
    assert args == ["ai", "do", "something"]


def test_join_args_for_shell_non_empty() -> None:
    s = join_args_for_shell(["echo", "a b"])
    assert "echo" in s
    assert "a b" in s or "a" in s
