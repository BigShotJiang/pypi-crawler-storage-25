"""HOME 单实例锁（正式环境默认启用；pytest 见 conftest AICD_SKIP_HOME_INSTANCE_LOCK）。"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import pytest

from aicd.home_instance_lock import (
    HomeInstanceLockError,
    acquire_home_instance_lock,
    release_home_instance_lock,
)
from aicd.runtime import build_runtime


def test_acquire_release_same_process_refcount(tmp_path: Path) -> None:
    os.environ.pop("AICD_SKIP_HOME_INSTANCE_LOCK", None)
    home = tmp_path / "h"
    (home / "data").mkdir(parents=True)
    assert acquire_home_instance_lock(home) == (True, "")
    assert acquire_home_instance_lock(home) == (True, "")
    release_home_instance_lock(home)
    release_home_instance_lock(home)
    lockp = home / "data" / ".aicd_instance.lock"
    assert not lockp.is_file()


def test_build_runtime_raises_when_lock_held_other_pid(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """模拟锁文件被其它 PID 占用且进程仍存在时 build_runtime 失败。"""
    monkeypatch.delenv("AICD_SKIP_HOME_INSTANCE_LOCK", raising=False)
    home = tmp_path / "iso"
    (home / "data").mkdir(parents=True)
    lockp = home / "data" / ".aicd_instance.lock"
    lockp.write_text("999999999\n", encoding="ascii")

    def _fake_alive(pid: int) -> bool:
        return pid == 999999999

    import aicd.home_instance_lock as hil

    monkeypatch.setattr(hil, "_pid_alive", _fake_alive)

    async def _go() -> None:
        await build_runtime(
            home=home,
            skip_first_setup=True,
            setup_tty_relaxed=True,
            exclusive_home_lock=True,
        )

    with pytest.raises(HomeInstanceLockError):
        asyncio.run(_go())
