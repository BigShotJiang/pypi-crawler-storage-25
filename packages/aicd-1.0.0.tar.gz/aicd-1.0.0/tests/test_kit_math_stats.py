from __future__ import annotations

from aicd.kit import math_stats


def test_describe() -> None:
    r = math_stats.describe([1.0, 2.0, 3.0])
    assert r["ok"] is True
    assert r["n"] == 3
    assert r["mean"] == 2.0


def test_histogram() -> None:
    r = math_stats.histogram([0.0, 0.1, 9.9, 10.0], bins=2)
    assert r["ok"] is True
    assert r["n_bins"] == 2
    assert sum(r["counts"]) == 4


def test_correlation() -> None:
    r = math_stats.correlation_pearson([1, 2, 3], [2, 4, 6])
    assert r["ok"] is True
    assert abs(float(r["pearson_r"]) - 1.0) < 1e-9


def test_run_operation_describe() -> None:
    r = math_stats.run_operation("describe", {"values": [10, 20]})
    assert r["ok"] is True
    assert r["n"] == 2
