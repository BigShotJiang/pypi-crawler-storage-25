"""会话 id：每次 new_chat_session_id 覆盖文件且 id 不同。"""

from __future__ import annotations

from pathlib import Path

from aicd.home import new_chat_session_id


def test_new_chat_session_id_always_fresh(tmp_path: Path) -> None:
    data = tmp_path / "data"
    a = new_chat_session_id(data)
    b = new_chat_session_id(data)
    assert a != b
    path = data / "active_chat_session_id.txt"
    assert path.read_text(encoding="utf-8").strip() == b
