"""子 Agent task_ai 的 agent_workflow 规范化。"""

from __future__ import annotations

import pytest

from aicd.agent.workflow_profile import (
    SUB_AGENT_WORKFLOW_CANONICAL,
    normalize_sub_agent_workflow,
    resolve_sub_agent_workflow_for_runtime,
)


def test_normalize_default_and_aliases() -> None:
    assert normalize_sub_agent_workflow(None) == "default"
    assert normalize_sub_agent_workflow("") == "default"
    assert normalize_sub_agent_workflow("PLAN") == "planner"
    assert normalize_sub_agent_workflow("build") == "executor"
    assert normalize_sub_agent_workflow("review") == "reviewer"
    assert normalize_sub_agent_workflow("plan_execute_review") == "full_cycle"


def test_canonical_set() -> None:
    assert SUB_AGENT_WORKFLOW_CANONICAL == frozenset(
        {"default", "planner", "executor", "reviewer", "full_cycle"}
    )


def test_invalid_raises() -> None:
    with pytest.raises(ValueError, match="agent_workflow"):
        normalize_sub_agent_workflow("nope")


def test_resolve_runtime_never_raises() -> None:
    assert resolve_sub_agent_workflow_for_runtime("nope") == "default"
    assert resolve_sub_agent_workflow_for_runtime(123) == "default"
    assert resolve_sub_agent_workflow_for_runtime("plan") == "planner"
