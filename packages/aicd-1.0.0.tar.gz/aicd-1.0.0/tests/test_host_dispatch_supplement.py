"""host_dispatch.main_chat_supplement：轻量 mock agent。"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

from aicd.host_dispatch import dispatch_host_request


def test_main_chat_supplement_returns_depth_and_enqueued(tmp_path) -> None:
    async def _go() -> None:
        agent = SimpleNamespace(
            enqueue_chat_supplement=AsyncMock(return_value=(3, True)),
        )
        ctx = SimpleNamespace(
            agent=agent,
            invocation=None,
            plugin_registry=None,
        )
        resp = await dispatch_host_request(
            ctx,
            {
                "id": "r-sup",
                "method": "main_chat_supplement",
                "params": {"text": "ping"},
            },
            state_dir=tmp_path,
            require_nonce=False,
        )
        assert resp == {
            "ok": True,
            "id": "r-sup",
            "result": {"queue_depth": 3, "enqueued": True},
        }
        agent.enqueue_chat_supplement.assert_awaited_once_with("ping")

    asyncio.run(_go())


def test_main_chat_supplement_rejects_empty_text(tmp_path) -> None:
    async def _go() -> None:
        agent = SimpleNamespace(
            enqueue_chat_supplement=AsyncMock(),
        )
        ctx = SimpleNamespace(
            agent=agent,
            invocation=None,
            plugin_registry=None,
        )
        resp = await dispatch_host_request(
            ctx,
            {
                "id": "r-empty",
                "method": "main_chat_supplement",
                "params": {"text": "  "},
            },
            state_dir=tmp_path,
            require_nonce=False,
        )
        assert resp["ok"] is False
        assert resp.get("code") == "args"
        agent.enqueue_chat_supplement.assert_not_called()

    asyncio.run(_go())


def test_main_chat_supplement_queue_full_marks_enqueued_false(tmp_path) -> None:
    async def _go() -> None:
        agent = SimpleNamespace(
            enqueue_chat_supplement=AsyncMock(return_value=(100, False)),
        )
        ctx = SimpleNamespace(
            agent=agent,
            invocation=None,
            plugin_registry=None,
        )
        resp = await dispatch_host_request(
            ctx,
            {
                "id": "r-full",
                "method": "enqueue_main_chat_supplement",
                "params": {"message": "x"},
            },
            state_dir=tmp_path,
            require_nonce=False,
        )
        assert resp["ok"] is True
        assert resp["result"] == {"queue_depth": 100, "enqueued": False}

    asyncio.run(_go())
