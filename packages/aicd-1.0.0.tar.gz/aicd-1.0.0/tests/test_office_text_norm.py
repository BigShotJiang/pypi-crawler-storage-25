"""office_text_norm：Office 写入前换行规范。"""

from __future__ import annotations

from aicd.tools.office_text_norm import normalize_office_newlines


def test_normalize_idempotent_crlf() -> None:
    assert normalize_office_newlines("a\r\nb") == "a\r\nb"


def test_normalize_lf_to_crlf() -> None:
    assert normalize_office_newlines("a\nb\nc") == "a\r\nb\r\nc"


def test_normalize_mixed_line_endings() -> None:
    assert normalize_office_newlines("a\r\nb\nc") == "a\r\nb\r\nc"


def test_normalize_empty() -> None:
    assert normalize_office_newlines("") == ""


def test_normalize_plain_no_newline() -> None:
    assert normalize_office_newlines("hello") == "hello"
