"""github_repo_read：路径编码与参数校验。"""

from __future__ import annotations

import pytest

from aicd.tools.github_repo_read import _encode_contents_path, _validate_owner_repo


def test_encode_path_segments() -> None:
    assert _encode_contents_path("a/b c/d") == "a/b%20c/d"


@pytest.mark.parametrize(
    ("owner", "repo", "ok"),
    [
        ("octocat", "Hello-World", True),
        ("a", "b", True),
        ("bad owner", "x", False),
        ("o", "a/b", False),
    ],
)
def test_validate_owner_repo(owner: str, repo: str, ok: bool) -> None:
    o, r, err = _validate_owner_repo(owner, repo)
    if ok:
        assert err is None and o and r
    else:
        assert err
