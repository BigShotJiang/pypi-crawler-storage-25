"""interactive_process 多轮 stdin/stdout 会话（跨平台 asyncio）。"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from aicd.config import PathPolicyConfig
from aicd.tools import interactive_process as ip
from aicd.tools.interactive_process import (
    InteractiveProcessBucket,
    MAX_WRITE_TOTAL_BYTES,
    WRITE_CHUNK_BYTES,
)
from aicd.tools.path_policy import PathPolicy


@pytest.fixture
def router(tmp_path: Path) -> SimpleNamespace:
    pol = PathPolicy(PathPolicyConfig(full_disk=True))
    pol.set_workspace_root(tmp_path)
    proc = SimpleNamespace(_cwd=tmp_path, _policy=pol)
    return SimpleNamespace(
        _process=proc,
        _interactive_bucket=InteractiveProcessBucket(idle_ttl_sec=None),
    )


@pytest.fixture(autouse=True)
def _clean_sessions(router: SimpleNamespace) -> None:
    yield
    asyncio.run(router._interactive_bucket.cleanup_all(reason="test_teardown"))


def test_unknown_session(router: SimpleNamespace) -> None:
    async def run() -> None:
        r = await ip.dispatch(router, {"operation": "read", "session_id": "not-a-uuid"})
        assert r.get("ok") is False
        assert r.get("error") == "unknown_session_id"

    asyncio.run(run())


def test_invalid_session_index_bool(router: SimpleNamespace) -> None:
    async def run() -> None:
        r = await ip.dispatch(
            router,
            {"operation": "read", "session_index": True, "timeout_sec": 1},
        )
        assert r.get("ok") is False
        assert r.get("error") == "invalid_session_index"

    asyncio.run(run())


def test_list_sessions_empty(router: SimpleNamespace) -> None:
    async def run() -> None:
        r = await ip.dispatch(router, {"operation": "list_sessions"})
        assert r.get("ok") is True
        assert r.get("count") == 0

    asyncio.run(run())


def test_label_and_index_selectors(router: SimpleNamespace) -> None:
    argv_echo = [
        sys.executable,
        "-u",
        "-c",
        "import sys\n"
        "line = sys.stdin.readline()\n"
        "sys.stdout.write(line)\n"
        "sys.stdout.flush()\n",
    ]

    async def run() -> None:
        a = await ip.dispatch(
            router,
            {
                "operation": "start",
                "argv": argv_echo,
                "cwd": str(router._process._cwd),
                "session_label": "alpha",
            },
        )
        assert a.get("ok") is True
        b = await ip.dispatch(
            router,
            {
                "operation": "start",
                "argv": argv_echo,
                "cwd": str(router._process._cwd),
            },
        )
        assert b.get("ok") is True

        lst = await ip.dispatch(router, {"operation": "list_sessions"})
        assert lst.get("count") == 2
        assert lst["sessions"][0]["session_label"] == "alpha"
        assert lst["sessions"][0]["session_index"] == 1

        w = await ip.dispatch(
            router,
            {"operation": "write", "session_label": "alpha", "text": "via-label"},
        )
        assert w.get("ok") is True
        rd = await ip.dispatch(
            router,
            {"operation": "read", "session_index": 1, "timeout_sec": 2},
        )
        assert "via-label" in (rd.get("stdout") or "")

        w2 = await ip.dispatch(
            router,
            {"operation": "write", "session_index": 2, "text": "via-idx"},
        )
        assert w2.get("ok") is True
        rd2 = await ip.dispatch(
            router,
            {"operation": "read", "session_index": 2, "timeout_sec": 2},
        )
        assert "via-idx" in (rd2.get("stdout") or "")

        await ip.dispatch(router, {"operation": "terminate", "session_label": "alpha"})
        await ip.dispatch(
            router,
            {"operation": "terminate", "session_id": b["session_id"]},
        )

    asyncio.run(run())


def test_write_payload_too_large(router: SimpleNamespace) -> None:
    argv = [sys.executable, "-u", "-c", "import time; time.sleep(60)"]

    async def run() -> None:
        st = await ip.dispatch(
            router,
            {"operation": "start", "argv": argv, "cwd": str(router._process._cwd)},
        )
        assert st.get("ok") is True
        sid = st["session_id"]
        huge = "x" * (MAX_WRITE_TOTAL_BYTES + 1)
        w = await ip.dispatch(
            router,
            {"operation": "write", "session_id": sid, "text": huge, "append_newline": False},
        )
        assert w.get("ok") is False
        assert w.get("error") == "write_payload_too_large"
        await ip.dispatch(router, {"operation": "terminate", "session_id": sid, "kill_subtree": False})

    asyncio.run(run())


def test_write_chunked_multipart_success(router: SimpleNamespace) -> None:
    """超过单块阈值时自动分块写入，子进程应收到完整一行。"""
    # 总 UTF-8 长度需 <~128KiB：部分平台下单次 stdout read 可能先返回一整块管道缓冲。
    n_body = 120_000  # > WRITE_CHUNK_BYTES，且单次 read 宜 < ~128KiB（管道/平台差异）
    payload = ("z" * n_body) + "\n"
    argv = [
        sys.executable,
        "-u",
        "-c",
        "import sys\n"
        "line = sys.stdin.buffer.readline()\n"
        "sys.stdout.buffer.write(line)\n"
        "sys.stdout.buffer.flush()\n",
    ]

    async def run() -> None:
        st = await ip.dispatch(
            router,
            {"operation": "start", "argv": argv, "cwd": str(router._process._cwd)},
        )
        assert st.get("ok") is True
        sid = st["session_id"]
        w = await ip.dispatch(
            router,
            {
                "operation": "write",
                "session_id": sid,
                "text": payload,
                "append_newline": False,
            },
        )
        assert w.get("ok") is True
        nb = len(payload.encode("utf-8"))
        expect_chunks = (nb + WRITE_CHUNK_BYTES - 1) // WRITE_CHUNK_BYTES
        assert w.get("write_chunks") == expect_chunks
        assert expect_chunks >= 2
        rd = await ip.dispatch(
            router,
            {"operation": "read", "session_id": sid, "timeout_sec": 5, "max_bytes": n_body + 64},
        )
        assert rd.get("ok") is True
        out = rd.get("stdout") or ""
        assert len(out) == len(payload)
        assert out == payload
        await ip.dispatch(router, {"operation": "terminate", "session_id": sid, "kill_subtree": False})

    asyncio.run(run())


def test_start_write_read_terminate(router: SimpleNamespace) -> None:
    argv = [
        sys.executable,
        "-u",
        "-c",
        "import sys\n"
        "for _ in range(2):\n"
        "    line = sys.stdin.readline()\n"
        "    sys.stdout.write(line)\n"
        "    sys.stdout.flush()\n",
    ]

    async def run() -> None:
        sta = await ip.dispatch(
            router,
            {"operation": "start", "argv": argv, "cwd": str(router._process._cwd)},
        )
        assert sta.get("ok") is True
        sid = sta["session_id"]

        w1 = await ip.dispatch(
            router,
            {"operation": "write", "session_id": sid, "text": "hello"},
        )
        assert w1.get("ok") is True

        r1 = await ip.dispatch(
            router,
            {"operation": "read", "session_id": sid, "timeout_sec": 3, "max_bytes": 4096},
        )
        assert r1.get("ok") is True
        assert "hello" in (r1.get("stdout") or "")

        w2 = await ip.dispatch(
            router,
            {"operation": "write", "session_id": sid, "text": "world"},
        )
        assert w2.get("ok") is True
        r2 = await ip.dispatch(
            router,
            {"operation": "read", "session_id": sid, "timeout_sec": 3, "max_bytes": 4096},
        )
        assert r2.get("ok") is True
        assert "world" in (r2.get("stdout") or "")

        st = await ip.dispatch(router, {"operation": "status", "session_id": sid})
        assert st.get("running") is True

        te = await ip.dispatch(
            router,
            {"operation": "terminate", "session_id": sid, "kill_subtree": False},
        )
        assert te.get("ok") is True

    asyncio.run(run())


def test_two_buckets_same_label_ok(tmp_path: Path) -> None:
    """不同 ToolRouter（桶）可有同名 session_label。"""

    def make_ns() -> SimpleNamespace:
        pol = PathPolicy(PathPolicyConfig(full_disk=True))
        pol.set_workspace_root(tmp_path)
        proc = SimpleNamespace(_cwd=tmp_path, _policy=pol)
        return SimpleNamespace(
            _process=proc,
            _interactive_bucket=InteractiveProcessBucket(idle_ttl_sec=None),
        )

    r1, r2 = make_ns(), make_ns()
    argv = [sys.executable, "-u", "-c", "import time; time.sleep(30)"]

    async def run() -> None:
        a1 = await ip.dispatch(
            r1,
            {
                "operation": "start",
                "argv": argv,
                "session_label": "dup",
                "cwd": str(tmp_path),
            },
        )
        a2 = await ip.dispatch(
            r2,
            {
                "operation": "start",
                "argv": argv,
                "session_label": "dup",
                "cwd": str(tmp_path),
            },
        )
        assert a1.get("ok") and a2.get("ok")
        await r1._interactive_bucket.cleanup_all(reason="test")
        await r2._interactive_bucket.cleanup_all(reason="test")

    asyncio.run(run())


def test_prune_idle_terminates_stale(router: SimpleNamespace) -> None:
    bucket = InteractiveProcessBucket(idle_ttl_sec=1.0)
    r = SimpleNamespace(_process=router._process, _interactive_bucket=bucket)
    argv = [sys.executable, "-u", "-c", "import time; time.sleep(60)"]

    async def run() -> None:
        st = await ip.dispatch(
            r,
            {"operation": "start", "argv": argv, "cwd": str(router._process._cwd)},
        )
        assert st.get("ok")
        sid = st["session_id"]
        sess = bucket._registry[sid]
        sess.last_activity_monotonic = time.monotonic() - 10_000.0
        await bucket.prune_idle_sessions()
        lst = await ip.dispatch(r, {"operation": "list_sessions"})
        assert lst["count"] == 0

    asyncio.run(run())
