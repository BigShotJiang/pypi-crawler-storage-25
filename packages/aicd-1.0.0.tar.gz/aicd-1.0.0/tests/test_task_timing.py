"""任务时间戳辅助函数。"""

from __future__ import annotations

import time

from aicd.tasks.manager import _duration_since_started_iso, _utc_iso


def test_duration_since_started_iso_recent() -> None:
    s = _utc_iso()
    time.sleep(0.02)
    d = _duration_since_started_iso(s)
    assert d is not None
    assert d >= 0.015


def test_duration_since_started_iso_bad() -> None:
    assert _duration_since_started_iso(None) is None
    assert _duration_since_started_iso("nope") is None
