from aicd.agent.loop import CHAT_SUPPLEMENT_HEAD, format_merged_chat_supplements


def test_format_merged_chat_supplements_joins_parts() -> None:
    s = format_merged_chat_supplements(["a", "b"])
    assert s.startswith(CHAT_SUPPLEMENT_HEAD)
    assert "a" in s and "b" in s
    assert "\n\n---\n\n" in s
