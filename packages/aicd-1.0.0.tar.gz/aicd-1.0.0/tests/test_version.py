from __future__ import annotations

import pytest

from aicd.version import bump_version_string, parse_version


def test_parse() -> None:
    assert parse_version("0.0.1") == (0, 0, 1)


def test_bump_carry_minor() -> None:
    assert bump_version_string("0.0.1") == "0.0.2"
    assert bump_version_string("0.0.8") == "0.0.9"
    assert bump_version_string("0.0.9") == "0.1.0"
    assert bump_version_string("0.1.0") == "0.1.1"
    assert bump_version_string("0.3.9") == "0.4.0"


def test_bump_invalid() -> None:
    with pytest.raises(ValueError):
        parse_version("1.0")
