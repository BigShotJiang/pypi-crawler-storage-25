"""Unit tests for task_list/task_result wall-clock age helpers."""

from __future__ import annotations

from datetime import datetime, timezone

from aicd.agent.handlers.tasks import _seconds_since_iso_to_ref


def test_seconds_since_iso_z_suffix() -> None:
    ref = datetime(2026, 3, 28, 12, 0, 0, tzinfo=timezone.utc)
    assert _seconds_since_iso_to_ref("2026-03-28T11:00:00Z", ref=ref) == 3600.0


def test_seconds_since_iso_offset() -> None:
    ref = datetime(2026, 1, 2, 12, 0, 0, tzinfo=timezone.utc)
    assert (
        _seconds_since_iso_to_ref("2026-01-02T11:00:00+00:00", ref=ref) == 3600.0
    )


def test_seconds_since_iso_naive_treated_as_utc() -> None:
    ref = datetime(2026, 6, 1, 10, 0, 0, tzinfo=timezone.utc)
    assert _seconds_since_iso_to_ref("2026-06-01T09:00:00", ref=ref) == 3600.0


def test_seconds_since_iso_invalid() -> None:
    ref = datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert _seconds_since_iso_to_ref("not-a-date", ref=ref) is None
    assert _seconds_since_iso_to_ref("", ref=ref) is None
    assert _seconds_since_iso_to_ref(None, ref=ref) is None
