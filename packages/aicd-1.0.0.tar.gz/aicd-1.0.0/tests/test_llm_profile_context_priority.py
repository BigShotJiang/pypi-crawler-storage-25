"""profile 手工上下文优先于 Ollama 探测；merge 规则。"""

from __future__ import annotations

from pathlib import Path

from aicd.agent.handlers.llm_profiles import _llm_profile_add
from aicd.agent.llm import _merge_api_and_config_window
from aicd.config import AppConfig, PROTO_OLLAMA, LLMProfile
from aicd.config_settings import format_llm_profiles_lines, switch_llm_profile_by_token


def test_merge_prefers_config_over_probe() -> None:
    assert _merge_api_and_config_window(256_000, 128_000) == 128_000
    assert _merge_api_and_config_window(64_000, 200_000) == 200_000
    assert _merge_api_and_config_window(64_000, None) == 64_000
    assert _merge_api_and_config_window(None, 128_000) == 128_000
    assert _merge_api_and_config_window(None, None) is None


def test_llm_profile_add_ollama_respects_manual_context(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "aicd.agent.handlers.llm_profiles.fetch_ollama_context_window_tokens",
        lambda **kw: 262_144,
    )
    cfg = AppConfig()
    cfg.llm.timeout_sec = 30.0
    p = tmp_path / "c.yaml"
    p.write_text("llm:\n  modelId: x\n", encoding="utf-8")

    class R:
        _cfg = cfg
        _layout = {"config": p}

        def schedule_llm_hot_reload(self) -> None:
            pass

    r = R()
    out = _llm_profile_add(
        r,
        {
            "name": "ollama-test",
            "type": PROTO_OLLAMA,
            "baseUrl": "http://127.0.0.1:11434",
            "modelId": "gemma:1",
            "contextWindowTokens": 131_072,
            "persist": False,
        },
    )
    assert out["ok"] is True
    assert out["profile"]["contextWindowTokens"] == 131_072


def test_llm_profile_add_ollama_falls_back_to_probe(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "aicd.agent.handlers.llm_profiles.fetch_ollama_context_window_tokens",
        lambda **kw: 262_144,
    )
    cfg = AppConfig()
    cfg.llm.timeout_sec = 30.0
    p = tmp_path / "c.yaml"
    p.write_text("llm:\n  modelId: x\n", encoding="utf-8")

    class R2:
        _cfg = cfg
        _layout = {"config": p}

        def schedule_llm_hot_reload(self) -> None:
            pass

    r = R2()
    out = _llm_profile_add(
        r,
        {
            "name": "ollama-probe",
            "type": PROTO_OLLAMA,
            "baseUrl": "http://127.0.0.1:11434",
            "modelId": "gemma:2",
            "persist": False,
        },
    )
    assert out["ok"] is True
    assert out["profile"]["contextWindowTokens"] == 262_144


def test_switch_by_index_still_works() -> None:
    cfg = AppConfig()
    cfg.llm_profiles = [
        LLMProfile(
            name="a",
            proto=PROTO_OLLAMA,
            base_url="http://x",
            api_key="",
            model="m1",
            context_window_tokens=128_000,
        ),
        LLMProfile(
            name="b",
            proto=PROTO_OLLAMA,
            base_url="http://y",
            api_key="",
            model="m2",
            context_window_tokens=128_000,
        ),
    ]
    cfg.active_llm_profile = "a"
    ok, msg = switch_llm_profile_by_token(cfg, "2")
    assert ok and "b" in msg
    assert cfg.active_llm_profile == "b"


def test_format_llm_profiles_shows_switch_hint() -> None:
    cfg = AppConfig()
    cfg.llm_profiles = [
        LLMProfile(
            name="only",
            proto=PROTO_OLLAMA,
            base_url="http://z",
            api_key="",
            model="m",
            context_window_tokens=131_072,
        ),
    ]
    cfg.active_llm_profile = "only"
    text = format_llm_profiles_lines(cfg)
    assert "/llm use" in text and "/llm <序号>" in text
