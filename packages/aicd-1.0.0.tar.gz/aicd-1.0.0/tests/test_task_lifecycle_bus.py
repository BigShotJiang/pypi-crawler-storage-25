"""task_lifecycle_bus：主会话 lifecycle 事件识别。"""

from __future__ import annotations

import uuid

from aicd.ui.task_lifecycle_bus import bus_event_is_main_session_lifecycle


def test_lifecycle_match() -> None:
    sid = str(uuid.uuid4())
    ev = {
        "topic": "task",
        "task_id": f"main-inbox-{sid}",
        "event": "task_message",
        "kind": "lifecycle",
    }
    assert bus_event_is_main_session_lifecycle(ev, chat_session_id=sid) is True


def test_lifecycle_wrong_session() -> None:
    sid = str(uuid.uuid4())
    other = str(uuid.uuid4())
    ev = {
        "topic": "task",
        "task_id": f"main-inbox-{other}",
        "event": "task_message",
        "kind": "lifecycle",
    }
    assert bus_event_is_main_session_lifecycle(ev, chat_session_id=sid) is False


def test_non_lifecycle() -> None:
    sid = str(uuid.uuid4())
    ev = {
        "topic": "task",
        "task_id": f"main-inbox-{sid}",
        "event": "task_message",
        "kind": "status",
    }
    assert bus_event_is_main_session_lifecycle(ev, chat_session_id=sid) is False
