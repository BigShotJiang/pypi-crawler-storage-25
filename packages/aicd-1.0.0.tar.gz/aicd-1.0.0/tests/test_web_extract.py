"""web_extract：无 trafilatura 时仍能产出文本。"""

from __future__ import annotations

from aicd.tools.web_extract import extract_main_text_from_html


def test_extract_falls_back_when_trafilatura_unused() -> None:
    html = "<html><body><nav>Nav</nav><article><p>Hello 正文</p></article></html>"
    text, meta = extract_main_text_from_html(html, "https://example.test/doc", max_chars=1000)
    assert "Hello" in text or "正文" in text
    assert meta.get("engine") in ("trafilatura", "naive")
