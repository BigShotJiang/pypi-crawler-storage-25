from __future__ import annotations

from aicd.kit import chart_spec


def test_series_to_chartjs_config() -> None:
    cfg = chart_spec.series_to_chartjs_config("bar", ["a", "b"], [1, 2])
    assert cfg["type"] == "bar"
    assert cfg["data"]["labels"] == ["a", "b"]
    assert cfg["data"]["datasets"][0]["data"] == [1.0, 2.0]


def test_line_has_fill_false() -> None:
    cfg = chart_spec.series_to_chartjs_config("line", ["a"], [1])
    assert cfg["type"] == "line"
    assert cfg["data"]["datasets"][0]["fill"] is False


def test_mermaid_bar_text() -> None:
    s = chart_spec.mermaid_bar_from_counts(["x", "y"], [1, 4])
    assert "x" in s
    assert "####" in s or "#" in s


def test_build_html_with_chart() -> None:
    html = chart_spec.build_html_with_chart("T", "bar", ["p"], [3.0])
    assert "Chart" in html
    assert "chart.umd.min.js" in html
