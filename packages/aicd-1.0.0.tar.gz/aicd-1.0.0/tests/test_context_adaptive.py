﻿"""Tests for context_adaptive (plan formulas: continuous + clamp)."""

from aicd.agent.context_adaptive import (
    ADAPTIVE_FORMULA_COEFFICIENTS,
    compute_adaptive_context,
    compute_cap_B,
    compute_context_pressure,
    compute_effective_recent_full_rows,
    compute_hydrate_preview_max_chars,
    compute_tool_result_max_chars,
    infer_window_confidence,
)
from aicd.config import AgentConfig


def test_infer_window_by_w():
    assert infer_window_confidence(model_context_window_tokens=None) == "low"
    assert infer_window_confidence(model_context_window_tokens=128_000) == "high"


def test_tool_result_caps_min_bound():
    c = compute_tool_result_max_chars(
        effective_budget_tokens=10_000,
        model_context_window_tokens=None,
        window_confidence="low",
    )
    assert 6144 <= c <= 32768


def test_low_confidence_discount_when_w_none():
    hi_b = compute_cap_B(200_000, window_confidence="high")
    lo_b = compute_cap_B(200_000, window_confidence="low")
    assert lo_b <= hi_b


def test_model_window_intersection():
    b = 500_000
    no_w = compute_tool_result_max_chars(
        effective_budget_tokens=b,
        model_context_window_tokens=None,
        window_confidence="low",
    )
    with_w = compute_tool_result_max_chars(
        effective_budget_tokens=b,
        model_context_window_tokens=32_000,
        window_confidence="high",
    )
    assert with_w <= no_w


def test_hydrate_preview_low_caps():
    hi = compute_hydrate_preview_max_chars(400_000, window_confidence="high")
    lo = compute_hydrate_preview_max_chars(400_000, window_confidence="low")
    assert lo <= hi
    assert lo <= 110


def test_recent_full_never_exceeds_cfg():
    cfg_rows = 48
    out = compute_effective_recent_full_rows(cfg_rows, 50_000)
    assert out <= cfg_rows
    assert out >= 8 or cfg_rows < 8


def test_context_pressure_display():
    p = compute_context_pressure(100_000, 128_000)
    assert 0 <= p <= 1.0


def test_compute_adaptive_includes_coefficients():
    agent = AgentConfig(chat_history_recent_full_rows=48)
    meta = {
        "model_context_window_tokens": 128_000,
        "model_context_probe_source": "http",
    }
    out = compute_adaptive_context(
        meta=meta, effective_budget_tokens=100_000, agent=agent
    )
    assert "formula_coefficients" in out
    assert out["formula_coefficients"]["tool_cap_B"]["linear"] == 0.12
    assert out["notes"] == []


def test_compute_adaptive_vision_override():
    agent = AgentConfig(
        chat_history_recent_full_rows=48,
        vision_image_token_budget_per_image=5000,
    )
    meta = {"model_context_window_tokens": 128_000}
    out = compute_adaptive_context(
        meta=meta, effective_budget_tokens=100_000, agent=agent
    )
    assert out["vision_tokens_per_image"] == 5000


def test_monotonic_cap_B_budget():
    assert compute_cap_B(50_000, window_confidence="high") <= compute_cap_B(
        100_000, window_confidence="high"
    )


def test_coefficients_export_static():
    assert "hydrate_preview" in ADAPTIVE_FORMULA_COEFFICIENTS
