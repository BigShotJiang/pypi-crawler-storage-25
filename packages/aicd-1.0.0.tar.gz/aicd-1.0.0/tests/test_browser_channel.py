"""build_chromium_launch_kwargs: bundled vs channel vs executable_path."""

from __future__ import annotations

import pytest

from aicd.tools.browser_automation import (
    build_chromium_launch_kwargs,
    playwright_chromium_launch_hint,
)


def test_default_bundled_chromium() -> None:
    kw = build_chromium_launch_kwargs(
        headless=True, slow_mo_ms=None, browser_channel=None, executable_path=None
    )
    assert kw == {"headless": True}


def test_synonyms_omit_channel() -> None:
    for ch in ("", "chromium", "bundled", "playwright", "default"):
        kw = build_chromium_launch_kwargs(
            headless=False, slow_mo_ms=None, browser_channel=ch, executable_path=None
        )
        assert kw == {"headless": False}


def test_chrome_channel() -> None:
    kw = build_chromium_launch_kwargs(
        headless=True,
        slow_mo_ms=None,
        browser_channel="chrome",
        executable_path=None,
    )
    assert kw == {"headless": True, "channel": "chrome"}


def test_channel_case_insensitive() -> None:
    kw = build_chromium_launch_kwargs(
        headless=True, slow_mo_ms=None, browser_channel="Chrome", executable_path=None
    )
    assert kw["channel"] == "chrome"


def test_executable_path_wins_over_channel() -> None:
    kw = build_chromium_launch_kwargs(
        headless=True,
        slow_mo_ms=None,
        browser_channel="chrome",
        executable_path=r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    )
    assert kw == {
        "headless": True,
        "executable_path": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    }
    assert "channel" not in kw


def test_slow_mo() -> None:
    kw = build_chromium_launch_kwargs(
        headless=True, slow_mo_ms=100, browser_channel="msedge", executable_path=None
    )
    assert kw["slow_mo"] == 100
    assert kw["channel"] == "msedge"


def test_unknown_channel_raises() -> None:
    with pytest.raises(ValueError, match="browser_channel"):
        build_chromium_launch_kwargs(
            headless=True,
            slow_mo_ms=None,
            browser_channel="firefox",
            executable_path=None,
        )


def test_playwright_launch_hint_known_missing_browser() -> None:
    h = playwright_chromium_launch_hint("Executable doesn't exist")
    assert "playwright install chromium" in h
    assert "browser_channel" in h


def test_playwright_launch_hint_generic() -> None:
    assert "install chromium" in playwright_chromium_launch_hint("timeout")
