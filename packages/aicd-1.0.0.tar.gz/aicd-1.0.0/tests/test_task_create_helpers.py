"""task_create_helpers：thread_root、topic_slug、agent_workflow、read_only_paths 等入参整理。"""

from __future__ import annotations

from aicd.tasks.task_create_helpers import (
    coerce_task_estimated_steps,
    parse_task_ai_agent_workflow,
    parse_task_ai_topic_slug,
    read_only_paths_coerce,
    thread_root_id_when_no_parent,
)


def test_thread_root_top_level_vs_nested() -> None:
    assert thread_root_id_when_no_parent(
        parent_id=None,
        chat_session_id="  sid1  ",
    ) == "sid1"
    assert thread_root_id_when_no_parent(parent_id=None, chat_session_id=None) is None
    assert thread_root_id_when_no_parent(parent_id="t-1", chat_session_id="sid1") is None


def test_thread_root_empty_parent_treated_as_top_level() -> None:
    assert thread_root_id_when_no_parent(
        parent_id="",
        chat_session_id="s",
    ) == "s"
    assert thread_root_id_when_no_parent(
        parent_id="   ",
        chat_session_id="s",
    ) == "s"


def test_parse_topic_slug() -> None:
    assert parse_task_ai_topic_slug(None) == (None, None)
    assert parse_task_ai_topic_slug("") == (None, None)
    assert parse_task_ai_topic_slug(42) == (None, None)
    slug, err = parse_task_ai_topic_slug("My-Topic")
    assert err is None
    assert slug == "my-topic"
    _, err2 = parse_task_ai_topic_slug("Bad Topic!")
    assert err2 is not None


def test_parse_agent_workflow() -> None:
    assert parse_task_ai_agent_workflow(None) == (None, None)
    assert parse_task_ai_agent_workflow("") == (None, None)
    assert parse_task_ai_agent_workflow("   ") == (None, None)
    assert parse_task_ai_agent_workflow("default") == (None, None)
    assert parse_task_ai_agent_workflow("plan") == ("planner", None)
    w, e = parse_task_ai_agent_workflow("nope")
    assert w is None and e is not None


def test_read_only_paths_coerce() -> None:
    assert read_only_paths_coerce(None) is None
    assert read_only_paths_coerce("x") is None
    assert read_only_paths_coerce([]) is None
    assert read_only_paths_coerce(["", 1, " /a/b "]) == ["/a/b"]


def test_coerce_estimated_steps() -> None:
    assert coerce_task_estimated_steps(None) is None
    assert coerce_task_estimated_steps("3") == 3
    assert coerce_task_estimated_steps("x") is None
