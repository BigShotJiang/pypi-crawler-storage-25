from __future__ import annotations

from aicd.kit import text_regex


def test_findall() -> None:
    r = text_regex.regex_findall("a1b2", r"\d")
    assert r["ok"] is True
    assert r["matches"] == ["1", "2"]


def test_sub() -> None:
    r = text_regex.regex_sub("a-b", r"-", "_")
    assert r["ok"] is True
    assert r["text"] == "a_b"


def test_normalize() -> None:
    r = text_regex.normalize_whitespace("  a \n b  ")
    assert r["ok"] is True
    assert r["text"] == "a b"


def test_split_lines() -> None:
    r = text_regex.split_lines("a\nb")
    assert r["ok"] is True
    assert r["lines"] == ["a", "b"]
