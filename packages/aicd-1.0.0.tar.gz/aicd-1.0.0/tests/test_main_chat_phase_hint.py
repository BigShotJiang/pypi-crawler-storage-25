"""Tests for main-chat LLM wait phase subtitle hints."""

from __future__ import annotations

from aicd.agent.loop import CHAT_SUPPLEMENT_HEAD, main_chat_llm_phase_detail


def test_phase_hint_open_local_page() -> None:
    msgs = [{"role": "user", "content": "[你] 打开网页"}]
    d = main_chat_llm_phase_detail(msgs)
    assert "desktop_open_url" in d


def test_phase_hint_open_html_explicit() -> None:
    msgs = [{"role": "user", "content": "预览 report/index.html"}]
    d = main_chat_llm_phase_detail(msgs)
    assert "desktop_open_url" in d


def test_phase_hint_reveal_path() -> None:
    msgs = [{"role": "user", "content": "在资源管理器里打开这个文件夹"}]
    d = main_chat_llm_phase_detail(msgs)
    assert "desktop_reveal_path" in d


def test_phase_hint_skips_supplement() -> None:
    msgs = [
        {"role": "user", "content": "打开网页"},
        {"role": "user", "content": CHAT_SUPPLEMENT_HEAD + "补充：快点"},
    ]
    d = main_chat_llm_phase_detail(msgs)
    assert "desktop_open_url" in d


def test_phase_hint_default_when_vague() -> None:
    msgs = [{"role": "user", "content": "总结一下上文"}]
    d = main_chat_llm_phase_detail(msgs)
    assert d == "等待大模型响应…"
