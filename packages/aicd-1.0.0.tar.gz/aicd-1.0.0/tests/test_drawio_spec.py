from __future__ import annotations

from aicd.kit import drawio_spec


def test_build_and_summarize_roundtrip() -> None:
    nodes = [
        {"id": "a", "label": "A"},
        {"id": "b", "label": "B"},
    ]
    edges = [{"source": "a", "target": "b", "label": "to"}]
    r = drawio_spec.build_drawio_xml(nodes, edges)
    assert r["ok"]
    xml = r["xml"]
    assert "<mxfile" in xml and "mxGraphModel" in xml
    s = drawio_spec.summarize_drawio_xml(xml)
    assert s["ok"]
    assert s["vertex_count"] == 2
    assert s["edge_count"] == 1


def test_unknown_edge_endpoint() -> None:
    r = drawio_spec.build_drawio_xml([{"id": "x"}], [{"source": "x", "target": "z"}])
    assert not r["ok"]
