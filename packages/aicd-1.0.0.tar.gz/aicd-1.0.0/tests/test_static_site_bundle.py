"""static_html_bundle kit (offline site / deck)."""

from __future__ import annotations

import json
from pathlib import Path

from aicd.tools.static_site.bundle import normalize_static_bundle_mode, run_static_html_bundle


def test_run_static_slide_deck_writes_deck_and_site_json(tmp_path: Path) -> None:
    r = run_static_html_bundle(
        output_dir=tmp_path,
        mode="slide_deck",
        site_title="Demo",
        slides=[{"title": "One", "body_html": "<p>a</p>"}, {"body_html": "<p>b</p>"}],
        copy_chart_resources=False,
        write_site_manifest=True,
    )
    assert r["ok"]
    assert (tmp_path / "deck.html").is_file()
    assert (tmp_path / "site.json").is_file()
    raw = (tmp_path / "deck.html").read_text(encoding="utf-8")
    assert "aicd-deck-root" in raw
    assert "aicd-slide" in raw
    assert "touchstart" in raw and "touchend" in raw
    assert "aicd-static_site" in raw


def test_run_static_multi_page_and_data(tmp_path: Path) -> None:
    r = run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="S",
        pages=[
            {"rel_path": "a.html", "title": "A", "body_html": "<p>1</p>"},
        ],
        copy_chart_resources=False,
        data_payloads={"x": {"k": 1}},
        write_site_manifest=False,
    )
    assert r["ok"]
    assert (tmp_path / "index.html").is_file()
    assert (tmp_path / "pages" / "a.html").is_file()
    assert (tmp_path / "data" / "x.json").is_file()
    assert "site.json" not in r["written_files"]
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert "aicd-data-fetch-status" in idx
    assert "data/x.json" in idx


def test_normalize_bundle_mode() -> None:
    assert normalize_static_bundle_mode("deck")[1] == "slide_deck"
    assert normalize_static_bundle_mode("MULTI-PAGE")[1] == "multi_page"


def test_multi_page_index_nested_tree(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="Tree",
        pages=[
            {"rel_path": "root.html", "title": "根页", "body_html": "<p>a</p>"},
            {"rel_path": "api/ref.html", "title": "API 参考", "body_html": "<p>b</p>"},
            {"rel_path": "api/index.html", "title": "API 总览", "body_html": "<p>c</p>"},
        ],
        copy_chart_resources=False,
        write_site_manifest=False,
        inject_data_fetch_demo=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert "aicd-site-tree-nested" in idx
    assert 'class="aicd-tree-folder is-link"' in idx
    assert "pages/api/ref.html" in idx
    # api 组内按标题排序后首条链在文件夹链接上
    assert 'class="aicd-tree-folder is-link" href="pages/api/ref.html"' in idx
    assert "aicd-tree-details" in idx and "<summary" in idx
    pg = (tmp_path / "pages" / "api" / "ref.html").read_text(encoding="utf-8")
    assert "aicd-subpage-header" in pg
    assert (tmp_path / "pages" / "api" / "ref.html").is_file()


def test_single_toc_scroll_spy_script(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="single_toc",
        site_title="Long",
        pages=[
            {"title": "一", "body_html": "<p>1</p>", "id": "one"},
            {"title": "二", "body_html": "<p>2</p>", "id": "two"},
        ],
        copy_chart_resources=False,
        write_site_manifest=False,
        inject_data_fetch_demo=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert "aicd-toc-section" in idx
    assert "scroll" in idx and "is-active" in idx


def test_multi_page_folder_span_when_no_links(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="S",
        pages=[{"rel_path": "a.html", "title": "A", "body_html": "<p>x</p>"}],
        copy_chart_resources=False,
        write_site_manifest=False,
        site_tree_folder_links=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert 'class="aicd-tree-folder is-link"' not in idx
    assert "aicd-tree-leaf" in idx


def test_multi_page_empty_tree_placeholder(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="Empty",
        pages=[],
        copy_chart_resources=False,
        write_site_manifest=False,
        inject_data_fetch_demo=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert "尚未添加" in idx


def test_site_json_lists_pages_and_schema(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="M",
        pages=[{"rel_path": "x.html", "title": "X", "body_html": "<p>z</p>"}],
        copy_chart_resources=False,
        write_site_manifest=True,
        inject_data_fetch_demo=False,
    )
    data = json.loads((tmp_path / "site.json").read_text(encoding="utf-8"))
    assert str(data.get("schema", "")).startswith("aicd.static_site")
    assert data.get("mode") == "multi_page"
    pages = data.get("pages")
    assert isinstance(pages, list) and len(pages) == 1
    assert pages[0].get("href") == "pages/x.html"
    assert pages[0].get("title") == "X"


def test_site_json_slide_manifest(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="slide_deck",
        site_title="D",
        slides=[{"title": "T", "body_html": "<p>a</p>"}],
        copy_chart_resources=False,
        write_site_manifest=True,
        inject_data_fetch_demo=False,
    )
    data = json.loads((tmp_path / "site.json").read_text(encoding="utf-8"))
    assert data.get("slides") == [{"index": 0, "title": "T"}]


def test_multi_page_flat_tree_when_not_collapsible(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="Flat",
        pages=[
            {"rel_path": "g/a.html", "title": "A", "body_html": "<p>a</p>"},
        ],
        copy_chart_resources=False,
        write_site_manifest=False,
        site_tree_collapsible=False,
        inject_data_fetch_demo=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert '<details class="aicd-tree-details"' not in idx


def test_subpage_navigation_off(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="Bare",
        pages=[{"rel_path": "p.html", "title": "P", "body_html": "<p>x</p>"}],
        copy_chart_resources=False,
        write_site_manifest=False,
        subpage_navigation=False,
        inject_data_fetch_demo=False,
    )
    pg = (tmp_path / "pages" / "p.html").read_text(encoding="utf-8")
    assert "aicd-subpage-header" not in pg


def test_data_demo_skipped_when_disabled(tmp_path: Path) -> None:
    run_static_html_bundle(
        output_dir=tmp_path,
        mode="multi_page",
        site_title="S",
        pages=[{"rel_path": "p.html", "title": "P", "body_html": "<p>x</p>"}],
        copy_chart_resources=False,
        data_payloads={"z": [1]},
        write_site_manifest=False,
        inject_data_fetch_demo=False,
    )
    idx = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert "aicd-data-fetch-status" not in idx
