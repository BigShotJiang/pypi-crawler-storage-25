from __future__ import annotations

import asyncio
from pathlib import Path


def test_viz_data_chart_and_data_stats(tmp_path: Path) -> None:
    from aicd.runtime import build_runtime

    async def _go() -> None:
        ctx = await build_runtime(home=tmp_path / "home")
        ok, _ = ctx.set_ai_workspace(str(tmp_path))
        assert ok is True
        w = await ctx.router.run("ai_workspace_set", {})
        assert w.get("ok") is True
        assert Path(w["workspace"]) == tmp_path.resolve()
        sub = tmp_path / "nested"
        sub.mkdir()
        w2 = await ctx.router.run("ai_workspace_set", {"path": "nested"})
        assert w2.get("ok") is True
        assert Path(w2["workspace"]) == sub.resolve()
        html = tmp_path / "c.html"
        r = await ctx.router.run(
            "viz_data_chart",
            {
                "html_path": str(html),
                "labels": ["a", "b"],
                "values": [1, 3],
                "chart_type": "bar",
            },
        )
        assert r.get("ok") is True
        assert html.is_file()
        assert (html.parent / "res" / "chart.umd.min.js").is_file()

        s = await ctx.router.run(
            "data_stats",
            {"operation": "describe", "values": [1, 2, 3]},
        )
        assert s.get("ok") is True
        assert s.get("mean") == 2.0
        await ctx.conn.close()

    asyncio.run(_go())
