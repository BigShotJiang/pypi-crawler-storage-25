"""Windows CMD: python -c 与 && 链、引号预检。"""

from __future__ import annotations

import sys

from aicd.tools.process_tool import (
    warn_shell_python_c_unbalanced_quotes,
    warn_shell_risky_python_c,
    warn_shell_windows_findstr_maybe_dir_operand,
    warn_shell_windows_python_c_with_and_chain,
)


def test_unbalanced_quotes_detected() -> None:
    msg = warn_shell_python_c_unbalanced_quotes('python -c "import os')
    assert msg is not None
    assert "双引号" in msg or "未成对" in msg


def test_balanced_quotes_ok() -> None:
    assert (
        warn_shell_python_c_unbalanced_quotes(
            'python -c "import os; print(1)"'
        )
        is None
    )


def test_and_chain_python_c_on_windows_only() -> None:
    cmd = 'cd D:\\x && python -c "import os; print(1)"'
    if sys.platform == "win32":
        msg = warn_shell_windows_python_c_with_and_chain(cmd)
        assert msg is not None
        assert "&&" in msg or "同一行" in msg
        assert warn_shell_risky_python_c(cmd) == msg
    else:
        assert warn_shell_windows_python_c_with_and_chain(cmd) is None


def test_findstr_warns_when_last_operand_looks_like_dir_name() -> None:
    cmd = 'findstr /s /i "class" regional-control'
    if sys.platform == "win32":
        msg = warn_shell_windows_findstr_maybe_dir_operand(cmd)
        assert msg is not None
        assert "findstr" in msg.lower() or "文件夹" in msg or "Cannot" in msg
    else:
        assert warn_shell_windows_findstr_maybe_dir_operand(cmd) is None


def test_findstr_no_warn_with_glob() -> None:
    cmd = r'findstr /s /i "class" regional-control\*.*'
    if sys.platform == "win32":
        assert warn_shell_windows_findstr_maybe_dir_operand(cmd) is None
