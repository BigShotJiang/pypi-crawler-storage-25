"""fs_read_file：范围读与 UTF-8 边界。"""

from __future__ import annotations

from pathlib import Path

from aicd.config import AppConfig
from aicd.tools.fs_tool import FSTool, _decode_utf8_range
from aicd.tools.path_policy import PathPolicy


def test_decode_utf8_range_mid_sequence() -> None:
    # "中" = e4 b8 ad — 若从第二字节开始读应跳过 1 字节
    b = "中".encode("utf-8")[1:] + "x".encode()
    t, pre, suf = _decode_utf8_range(b, file_offset=1)
    assert t == "x"
    assert pre == 2


def test_read_file_byte_offset(tmp_path: Path) -> None:
    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    pol.set_workspace_root(tmp_path)
    fs = FSTool(pol, cwd=tmp_path)
    p = tmp_path / "t.txt"
    p.write_text("abcdefgh", encoding="utf-8")
    r = fs.read_file(str(p), max_bytes=3, byte_offset=2, align_utf8=True)
    assert r["ok"] is True
    assert r["text"] == "cde"
    assert r["byte_offset"] == 2
    assert r["bytes_read"] == 3
    assert r["truncated"] is True


def test_read_file_utf8_span(tmp_path: Path) -> None:
    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    pol.set_workspace_root(tmp_path)
    fs = FSTool(pol, cwd=tmp_path)
    p = tmp_path / "u.txt"
    p.write_text("αβγδ", encoding="utf-8")
    raw = p.read_bytes()
    # 从第一个完整字符后截断：β 起
    off = len("α".encode("utf-8"))
    r = fs.read_file(str(p), max_bytes=len(raw) - off, byte_offset=off, align_utf8=True)
    assert r["ok"] is True
    assert r["text"] == "βγδ"
    assert r["truncated"] is False
