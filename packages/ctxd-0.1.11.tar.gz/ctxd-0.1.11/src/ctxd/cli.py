"""Public command-line interface for ctxd."""

import argparse
import getpass
import json
import os
import sys
import webbrowser
from typing import Sequence

from ctxd import Client, CtxdError
from ctxd.config import clear_api_key, resolve_api_key, save_api_key
from ctxd.mcp_server import main as run_mcp_server

_APP_NAME_ALIASES = {
    "google-drive": "google_drive",
    "google_drive": "google_drive",
    "google-calendar": "google_calendar",
    "google_calendar": "google_calendar",
    "slack": "slack",
    "github": "github",
}


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "login":
            return _handle_login(args)
        if args.command == "logout":
            return _handle_logout(args)
        if args.command == "status":
            return _handle_status(args)
        if args.command == "connect":
            return _handle_connect(args)
        if args.command == "mcp":
            return _handle_mcp(args)

        client = Client()

        if args.command == "search":
            result = client.search(args.query)
            return _emit_result(result.model_dump(), as_json=args.json)
        if args.command == "fetch":
            result = client.fetch_document(args.document_uid)
            return _emit_result(result.model_dump(), as_json=args.json)
        if args.command == "profile":
            result = client.get_profile()
            return _emit_result(result.model_dump(), as_json=args.json)
    except (CtxdError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1

    parser.error(f"Unknown command: {args.command}")
    return 2


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ctxd")

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("login")
    subparsers.add_parser("logout")
    subparsers.add_parser("status")

    connect_parser = subparsers.add_parser("connect")
    connect_parser.add_argument("app")
    connect_parser.add_argument("--no-browser", action="store_true")
    connect_parser.add_argument("--timeout", type=float, default=300.0)

    mcp_parser = subparsers.add_parser("mcp")
    mcp_parser.add_argument("--transport", choices=("stdio", "http"), default="stdio")
    mcp_parser.add_argument("--host", default="127.0.0.1")
    mcp_parser.add_argument("--port", type=int, default=8803)

    search_parser = subparsers.add_parser("search")
    search_parser.add_argument("query")
    search_parser.add_argument("--json", action="store_true")

    fetch_parser = subparsers.add_parser("fetch")
    fetch_parser.add_argument("document_uid")
    fetch_parser.add_argument("--json", action="store_true")

    profile_parser = subparsers.add_parser("profile")
    profile_parser.add_argument("--json", action="store_true")

    return parser


def _handle_login(args: argparse.Namespace) -> int:
    del args
    api_key, should_save = _resolve_login_api_key()
    if not api_key:
        raise ValueError(
            "Missing API key. Set `CTXD_API_KEY` or run `ctxd login` in an interactive terminal."
        )

    Client(api_key=api_key).get_profile()

    if should_save:
        save_api_key(api_key)
        print("Saved API key authentication.")
    else:
        print("API key authentication is valid.")
    return 0


def _handle_logout(args: argparse.Namespace) -> int:
    del args
    clear_api_key()
    print("Cleared stored ctxd API key.")
    return 0


def _handle_status(args: argparse.Namespace) -> int:
    del args
    try:
        api_key = resolve_api_key()
    except CtxdError as exc:
        print(f"Not authenticated: {exc}", file=sys.stderr)
        return 1

    if not api_key:
        print(
            "Not authenticated: Missing API key. Set `CTXD_API_KEY` or run `ctxd login`.",
            file=sys.stderr,
        )
        return 1

    print("Authenticated to ctxd.")
    return 0


def _resolve_login_api_key() -> tuple[str | None, bool]:
    env_api_key = os.getenv("CTXD_API_KEY")
    if env_api_key and env_api_key.strip():
        return env_api_key.strip(), False

    try:
        stored_api_key = resolve_api_key()
    except CtxdError:
        stored_api_key = None
    if stored_api_key:
        return stored_api_key, False

    prompted_api_key = _prompt_api_key()
    if prompted_api_key:
        return prompted_api_key, True

    return None, False


def _prompt_api_key() -> str | None:
    if not sys.stdin.isatty():
        return None

    try:
        api_key = getpass.getpass("ctxd API key: ")
    except (EOFError, KeyboardInterrupt):
        return None

    if api_key and api_key.strip():
        return api_key.strip()
    return None


def _handle_connect(args: argparse.Namespace) -> int:
    app_name = _normalize_app_name(args.app)
    auth_url = "https://app.ctxd.dev/knowledge-base/add-application"

    print(f"To connect {app_name}, go to:")
    print(auth_url)

    if not args.no_browser:
        webbrowser.open(auth_url)
    return 0


def _handle_mcp(args: argparse.Namespace) -> int:
    run_mcp_server(transport=args.transport, host=args.host, port=args.port)
    return 0


def _emit_result(payload: dict, *, as_json: bool) -> int:
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 1 if _payload_has_error(payload) else 0

    if "results" in payload:
        error = payload.get("error")
        dsl_parse_error = payload.get("dsl_parse_error")
        if error:
            print(f"Error: {error}")
        if dsl_parse_error:
            print(f"DSL parse error: {dsl_parse_error}")
        if not payload["results"] and not error and not dsl_parse_error:
            print("No results found.")
        for item in payload["results"]:
            print(f"- {item['title']} [{item['id']}]")
            print(f"  URL: {item['url']}")
            if item.get("text"):
                print(f"  Text: {item['text']}")
        return 1 if error or dsl_parse_error else 0

    if "integration_access" in payload:
        print(payload["integration_access"])
        if payload.get("file_tree"):
            print()
            print(payload["file_tree"])
        return 0

    if payload.get("error"):
        print(f"Error: {payload['error']}")
        return 1

    title = payload.get("title") or payload.get("id") or "Document"
    print(title)
    if payload.get("url"):
        print(payload["url"])
    if payload.get("text"):
        print()
        print(payload["text"])
    return 0


def _payload_has_error(payload: dict) -> bool:
    if payload.get("error"):
        return True
    return bool(payload.get("dsl_parse_error"))


def _normalize_app_name(app_name: str) -> str:
    normalized = app_name.strip().lower()
    if normalized not in _APP_NAME_ALIASES:
        raise ValueError(
            "Unsupported app. Use one of: google-drive, slack, github, google-calendar."
        )
    return _APP_NAME_ALIASES[normalized]
