"""Local MCP server for ctxd."""

from fastmcp import FastMCP

from ctxd import Client


def _to_mcp_search_payload(payload: dict) -> dict:
    results = []
    for item in payload.get("results", []):
        mapped = {
            "document_uid": item["id"],
            "app_name": item.get("app_name"),
            "title": item["title"],
            "url": item["url"],
            "requires_fetch_for_full_text": True,
            "metadata": item.get("metadata", {}),
        }
        if item.get("text"):
            mapped["snippet"] = item["text"]
            mapped["is_snippet"] = True
        else:
            mapped["is_snippet"] = False
        results.append(mapped)

    response = {"results": results}
    if payload.get("error"):
        response["error"] = payload["error"]
    if payload.get("dsl_parse_error"):
        response["dsl_parse_error"] = payload["dsl_parse_error"]
    return response


def build_server() -> FastMCP:
    mcp = FastMCP("ctxd")

    @mcp.tool
    def search(query: str) -> dict:
        with Client() as client:
            return _to_mcp_search_payload(client.search(query).model_dump())

    @mcp.tool
    def fetch_document(document_uid: str) -> dict:
        with Client() as client:
            return client.fetch_document(document_uid).model_dump()

    @mcp.tool
    def get_profile() -> dict:
        with Client() as client:
            return client.get_profile().model_dump()

    return mcp


def main(
    *,
    transport: str = "stdio",
    host: str = "127.0.0.1",
    port: int = 8803,
) -> None:
    mcp = build_server()
    if transport == "http":
        mcp.run(transport="http", host=host, port=port)
        return
    mcp.run(transport="stdio")
