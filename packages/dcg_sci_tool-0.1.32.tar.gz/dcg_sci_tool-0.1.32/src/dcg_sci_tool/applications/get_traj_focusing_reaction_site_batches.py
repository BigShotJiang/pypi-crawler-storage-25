from dcg_sci_tool import *
from ovito.data import *
from ase.io import write
import os

def get_traj_focusing_reaction_site_batches(cutoff = 8.0, target_vector=None, new_cell=[20, 20, 20]):
    """
    批量处理当前目录下所有满足特定正则表达式的文件，调用get_traj_focusing_reaction_site函数进行处理，并将结果保存为新的文件。
    
    Args:

        cutoff (float): 截止距离，单位为Å，默认为8.0
    
        target_vector (np.ndarray 或 list/tuple):  目标向量，形状为(3,)，旋转后当前向量将与此向量同向
    
        new_cell (np.ndarray 或 list/tuple): 新的晶胞尺寸，形状为(3,)，如 [a, b, c]

    """
    pattern = "[0-9]+-[0-9]+_-?[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+\.xyz"
    target_files = find_matching_files("./", pattern)
    print("Found files:", target_files)

    target_vector = [0, -1, 0]
    for file in target_files:
        print(f"Processing file: {file}")
        _, _, _, c_idx, o_idx = parse_nebTraj_file_name(file)
        name_without_ext, _ = os.path.splitext(file)
        name_without_ext = "_".join(name_without_ext.split("_")[:3])
        focused_traj, new_indexes = get_traj_focusing_reaction_site(
            file, c_idx, o_idx, cutoff = cutoff, target_vector = target_vector, new_cell=new_cell
        )
        output_file = f"{name_without_ext}_{new_indexes[0]}_{new_indexes[1]}_focused.xyz"
        write(output_file, focused_traj)
        print(f"Saved focused trajectory to: {output_file}")