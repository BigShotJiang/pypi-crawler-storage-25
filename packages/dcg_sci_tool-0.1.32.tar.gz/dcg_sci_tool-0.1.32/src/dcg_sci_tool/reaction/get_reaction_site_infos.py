from dcg_sci_tool.reaction.parse_nebTraj_file_name import parse_nebTraj_file_name
from ovito.io import import_file
from dcg_sci_tool.extract_atom_types import extract_atom_types
# from pathlib import Path
from dcg_sci_tool.reaction.find_nearest_hollow_site import find_nearest_hollow_site
from dcg_sci_tool.reaction.get_hollowSite_outer_neighbors import get_hollowSite_outer_surface_neighbors, get_hollowSite_subsurface_neighbors
from dcg_sci_tool.get_indexes_symbols import get_indexes_symbols
from dcg_sci_tool.reaction.get_hollowSite_Au_Disperation import get_hollowSite_Au_Disperation

def get_reaction_site_infos(input_file):

    """
    获取反应中心的结构信息
    Args:
        input_file (Path): 输入文件路径
    Returns:
        tuple: 包含反应中心结构信息的元组

        N_hollow_sites (int): 反应中心的原子数

        N_hollow_sites_Au_atoms (int): 反应中心的Au原子数

        N_surface_neighbors (int): 反应中心外圈的表面原子数

        N_surface_Au_neighbors (int): 反应中心外圈的表面Au原子数

        N_subsurface_neighbors (int): 反应中心的次表面原子数

        N_subsurface_Au_neighbors (int): 反应中心的次表面Au原子数

        Au_Disperation (float): 反应中心外圈表层Au原子的分散度
    """
    # script_dir = Path(__file__).resolve().parent
    co2_indexes, Ea, dE, C_idx, O_idx = parse_nebTraj_file_name(input_file)
    # pipeline = import_file(f'{script_dir}/{input_file}')
    pipeline = import_file(input_file)
    data = pipeline.compute(0)
    # type_names_order = extract_atom_types(f'{script_dir}/{input_file}')
    type_names_order = extract_atom_types(input_file)

    nearest_hollow_indexes, nearby_hollow_sites_count = find_nearest_hollow_site(data=data, type_names_order=type_names_order, c_index=C_idx, o_index=O_idx)
    hollowSite_outer_surface_neighbors = get_hollowSite_outer_surface_neighbors(data, type_names_order, nearest_hollow_indexes)
    hollowSite_subsurface_neighbors = get_hollowSite_subsurface_neighbors(data, type_names_order, nearest_hollow_indexes)

    # symbols_hollow_sites = get_indexes_symbols(f'{script_dir}/{input_file}',nearest_hollow_indexes)
    symbols_hollow_sites = get_indexes_symbols(input_file, nearest_hollow_indexes)
    N_hollow_sites = len(symbols_hollow_sites)
    N_hollow_sites_Au_atoms = symbols_hollow_sites.count('Au')

    # symbols_outer_surface = get_indexes_symbols(f'{script_dir}/{input_file}',hollowSite_outer_surface_neighbors)
    symbols_outer_surface = get_indexes_symbols(input_file,hollowSite_outer_surface_neighbors)
    N_surface_neighbors = len(symbols_outer_surface)
    N_surface_neighbors = len(symbols_outer_surface)
    N_surface_Au_neighbors = symbols_outer_surface.count('Au')

    # symbols_subsurface = get_indexes_symbols(f'{script_dir}/{input_file}',hollowSite_subsurface_neighbors)
    symbols_subsurface = get_indexes_symbols(input_file,hollowSite_subsurface_neighbors)
    N_subsurface_neighbors = len(symbols_subsurface)
    N_subsurface_Au_neighbors = symbols_subsurface.count('Au')

    Au_Disperation = float(get_hollowSite_Au_Disperation(data, type_names_order, nearest_hollow_indexes))

    return N_hollow_sites, \
        N_hollow_sites_Au_atoms, \
            N_surface_neighbors, \
                N_surface_Au_neighbors, \
                    N_subsurface_neighbors, \
                        N_subsurface_Au_neighbors, \
                            Au_Disperation
