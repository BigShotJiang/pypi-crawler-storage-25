"""
Subscription Management Operations - Handle user subscriptions and related operations
"""
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone
from google.cloud import firestore
from google.cloud.exceptions import GoogleCloudError
from ipulse_shared_base_ftredge.enums import SubscriptionPlanName, SubscriptionStatus, BillingIntervalTimeUnit
from ...models import UserSubscription, SubscriptionPlan, UserStatus
from ...exceptions import SubscriptionError, UserStatusError, ServiceError
from .userstatus_operations import UserstatusOperations
from .user_permissions_operations import UserpermissionsOperations
from ..catalog.catalog_subscriptionplan_service import CatalogSubscriptionPlanService


class UsersubscriptionOperations:
    """
    Handles subscription-related operations for users
    """

    MAX_BULK_SUBSCRIPTION_MIGRATION_USERS = 30

    def __init__(
        self,
        firestore_client: firestore.Client,
        userstatus_ops: UserstatusOperations,
        permissions_ops: UserpermissionsOperations,
        catalog_subscriptionplan_service: Optional[CatalogSubscriptionPlanService] = None,
        logger: Optional[logging.Logger] = None,
        timeout: float = 10.0
    ):
        self.db = firestore_client
        self.userstatus_ops = userstatus_ops
        self.permissions_ops = permissions_ops
        self.logger = logger or logging.getLogger(__name__)
        self.timeout = timeout
        self.catalog_subscriptionplan_service = (
            catalog_subscriptionplan_service
            if catalog_subscriptionplan_service is not None
            else CatalogSubscriptionPlanService(firestore_client=self.db, logger=self.logger)
        )

    def _mutate_userstatus_transactional(
        self,
        user_uid: str,
        updater_uid: str,
        mutation_func
    ):
        """Apply a userstatus mutation atomically in Firestore transaction.

        Delegates to the canonical implementation on UserstatusOperations.
        """
        return self.userstatus_ops._mutate_userstatus_transactional(
            user_uid=user_uid,
            mutation_func=mutation_func,
            updater_uid=updater_uid,
        )

    async def _resolve_target_plan_from_reference(self, plan_reference: str) -> SubscriptionPlan:
        """Resolve a plan reference to the latest active catalog plan."""
        normalized_reference = (plan_reference or "").strip()
        if not normalized_reference:
            raise SubscriptionError(
                detail="plan_reference is required",
                operation="_resolve_target_plan_from_reference"
            )

        target_plan = await self.catalog_subscriptionplan_service.resolve_plan_by_reference(normalized_reference)
        if not target_plan:
            raise SubscriptionError(
                detail=f"No active subscription plan found for reference '{normalized_reference}'",
                plan_id=normalized_reference,
                operation="_resolve_target_plan_from_reference"
            )
        return target_plan

    @staticmethod
    def _build_target_plan_id(target_plan: SubscriptionPlan) -> str:
        """Build a canonical plan id from a resolved target plan."""
        return target_plan.id or f"{target_plan.plan_name.value}_{target_plan.plan_version}"

    def _is_subscription_aligned_with_target_plan(
        self,
        active_subscription: UserSubscription,
        target_plan: SubscriptionPlan,
        target_plan_id: str,
    ) -> bool:
        """Check if the embedded active subscription snapshot already matches target plan terms."""
        current_permissions = [perm.model_dump() for perm in (active_subscription.granted_iam_permissions or [])]
        target_permissions = [perm.model_dump() for perm in (target_plan.granted_iam_permissions or [])]

        return all([
            active_subscription.plan_id == target_plan_id,
            active_subscription.plan_version == target_plan.plan_version,
            str(active_subscription.plan_name) == str(target_plan.plan_name.value),
            active_subscription.subscription_based_insight_credits_per_update == int(target_plan.subscription_based_insight_credits_per_update),
            active_subscription.subscription_based_insight_credits_update_freq_h == int(target_plan.subscription_based_insight_credits_update_freq_h),
            active_subscription.extra_insight_credits_per_cycle == int(target_plan.extra_insight_credits_per_cycle),
            active_subscription.voting_credits_per_update == int(target_plan.voting_credits_per_update),
            active_subscription.voting_credits_update_freq_h == int(target_plan.voting_credits_update_freq_h),
            active_subscription.max_extra_credits_purchases_per_day == int(target_plan.max_extra_credits_purchases_per_day),
            active_subscription.fallback_plan_id == target_plan.fallback_plan_id_if_current_plan_expired,
            current_permissions == target_permissions,
        ])

    def _build_migrated_subscription_preserving_cycle(
        self,
        active_subscription: UserSubscription,
        target_plan: SubscriptionPlan,
        updater_uid: str,
        source: str,
    ) -> UserSubscription:
        """Build migrated subscription snapshot while preserving cycle and billing linkage fields."""
        target_plan_id = self._build_target_plan_id(target_plan)
        migrated_subscription_data = active_subscription.model_dump(exclude_none=False)
        migrated_subscription_data.update({
            "plan_name": target_plan.plan_name,
            "plan_version": target_plan.plan_version,
            "plan_id": target_plan_id,
            "granted_iam_permissions": target_plan.granted_iam_permissions or [],
            "fallback_plan_id": target_plan.fallback_plan_id_if_current_plan_expired,
            "subscription_based_insight_credits_per_update": int(target_plan.subscription_based_insight_credits_per_update),
            "subscription_based_insight_credits_update_freq_h": int(target_plan.subscription_based_insight_credits_update_freq_h),
            "extra_insight_credits_per_cycle": int(target_plan.extra_insight_credits_per_cycle),
            "voting_credits_per_update": int(target_plan.voting_credits_per_update),
            "voting_credits_update_freq_h": int(target_plan.voting_credits_update_freq_h),
            "max_extra_credits_purchases_per_day": int(target_plan.max_extra_credits_purchases_per_day),
            "updated_at": datetime.now(timezone.utc),
            "updated_by": f"UsersubscriptionOperations.migration:{source}:{updater_uid}",
        })
        return UserSubscription(**migrated_subscription_data)

    def _validate_bulk_migration_size(self, user_uids: List[str]) -> None:
        """Validate max bulk migration size guardrail."""
        if len(user_uids) > self.MAX_BULK_SUBSCRIPTION_MIGRATION_USERS:
            raise SubscriptionError(
                detail=(
                    f"Bulk migration accepts at most {self.MAX_BULK_SUBSCRIPTION_MIGRATION_USERS} users per call; "
                    f"received {len(user_uids)}"
                ),
                operation="_validate_bulk_migration_size"
            )

    def create_subscription_from_subscriptionplan(
        self,
        plan: SubscriptionPlan,
        source: str,
        granted_at: Optional[datetime] = None,
        auto_renewal_end: Optional[datetime] = None,
        billing_interval: Optional[BillingIntervalTimeUnit] = None
    ) -> UserSubscription:
        """
        Common helper function to create a UserSubscription from a SubscriptionPlan.

        Args:
            plan: The subscription plan to convert
            source: Source identifier for the subscription
            granted_at: Optional granted timestamp (defaults to now)
            auto_renewal_end: Optional auto-renewal override
            billing_interval: Billing interval chosen by user (month/year). None for free plans.

        Returns:
            UserSubscription object
        """
        # Use provided granted_at or default to now
        start_date = granted_at or datetime.now(timezone.utc)

        # Derive validity cycle from billing option (or default 1 month for free plans)
        validity_length, validity_unit = plan.get_validity_cycle(billing_interval)

        end_date = UserSubscription.calculate_cycle_end_date(
            start_date,
            validity_length,
            validity_unit
        )

        # Use provided auto_renewal_end or default from plan
        effective_auto_renewal_end = auto_renewal_end if auto_renewal_end is not None else plan.plan_default_auto_renewal_end

        try:
            # Validate plan name
            plan_name_enum = SubscriptionPlanName(plan.plan_name)
        except ValueError as e:
            raise SubscriptionError(
                detail=f"Invalid plan name '{plan.plan_name}': {str(e)}",
                plan_id=plan.id or "unknown",
                operation="_create_subscription_from_plan",
                original_error=e
            ) from e

        return UserSubscription(
            plan_name=plan_name_enum,
            plan_version=plan.plan_version,
            plan_id=plan.id or f"{plan.plan_name}_{plan.plan_version}",
            cycle_start_datetime=start_date,
            cycle_end_datetime=end_date,
            validity_time_length=validity_length,
            validity_time_unit=validity_unit,
            auto_renew_end_datetime=effective_auto_renewal_end,
            status=SubscriptionStatus.ACTIVE,
            granted_iam_permissions=plan.granted_iam_permissions or [],
            fallback_plan_id=plan.fallback_plan_id_if_current_plan_expired,
            price_paid_usd=float(plan.get_default_price_usd()),
            created_by=source,
            updated_by=source,
            subscription_based_insight_credits_per_update=int(plan.subscription_based_insight_credits_per_update if plan.subscription_based_insight_credits_per_update is not None else 0),
            subscription_based_insight_credits_update_freq_h=int(plan.subscription_based_insight_credits_update_freq_h if plan.subscription_based_insight_credits_update_freq_h is not None else 24),
            extra_insight_credits_per_cycle=int(plan.extra_insight_credits_per_cycle if plan.extra_insight_credits_per_cycle is not None else 0),
            voting_credits_per_update=int(plan.voting_credits_per_update if plan.voting_credits_per_update is not None else 0),
            voting_credits_update_freq_h=int(plan.voting_credits_update_freq_h if plan.voting_credits_update_freq_h is not None else 744),
            max_extra_credits_purchases_per_day=int(plan.max_extra_credits_purchases_per_day if plan.max_extra_credits_purchases_per_day is not None else 2000),
        )

    async def fetch_subscriptionplan_and_apply_subscription_to_user(
        self,
        user_uid: str,
        plan_id: str,
        updater_uid: str,
        source: str = "system_default_config",
        granted_at: Optional[datetime] = None,
        auto_renewal_end: Optional[datetime] = None
    ) -> UserSubscription:
        """
        Fetch a subscription plan from catalog service and apply to user.

        Args:
            user_uid: User ID to apply subscription to
            plan_id: Plan ID to fetch and apply
            updater_uid: Who is applying the subscription
            source: Source identifier
            granted_at: Optional granted timestamp (overrides plan defaults)
            auto_renewal_end: Optional auto-renewal end date (overrides plan defaults)

        Returns:
            Applied UserSubscription

        Raises:
            SubscriptionError: If plan not found or application fails
        """
        self.logger.info("Fetching and applying subscription plan %s to user %s", plan_id, user_uid)

        try:
            # Fetch the plan from catalog
            catalog_plan = await self.catalog_subscriptionplan_service.get_subscriptionplan(plan_id)
            if not catalog_plan:
                raise SubscriptionError(
                    detail=f"Subscription plan '{plan_id}' not found in catalog",
                    user_uid=user_uid,
                    plan_id=plan_id,
                    operation="fetch_and_apply_subscriptionplan_to_user"
                )

            # Apply the subscription plan to user
            return await self.apply_subscriptionplan(
                user_uid=user_uid,
                subscriptionplan=catalog_plan,
                updater_uid=updater_uid,
                source=source,
                granted_at=granted_at,
                auto_renewal_end=auto_renewal_end,
                add_associated_permissions=True
            )

        except SubscriptionError:
            # Re-raise subscription errors as-is
            raise
        except Exception as e:
            self.logger.error("Failed to fetch and apply subscription plan %s: %s", plan_id, e, exc_info=True)
            raise SubscriptionError(
                detail=f"Failed to fetch and apply subscription plan: {str(e)}",
                user_uid=user_uid,
                plan_id=plan_id,
                operation="fetch_and_apply_subscriptionplan_to_user",
                original_error=e
            ) from e

    async def apply_subscriptionplan(
        self,
        user_uid: str,
        subscriptionplan: SubscriptionPlan,
        updater_uid: str,
        source: str = "system_default_config",
        granted_at: Optional[datetime] = None,
        auto_renewal_end: Optional[datetime] = None,
        add_associated_permissions: bool = True
    ) -> UserSubscription:
        """
        Apply a ready subscription plan to a user.

        Args:
            user_uid: User ID to apply subscription to
            subscriptionplan: Ready SubscriptionPlan object
            updater_uid: Who is applying the subscription
            source: Source identifier
            granted_at: Optional granted timestamp (overrides plan defaults)
            auto_renewal: Optional auto-renewal setting (overrides plan defaults)
            add_associated_permissions: If True, adds IAM permissions from the subscription

        Returns:
            Applied UserSubscription
        """
        self.logger.info("Applying subscription plan %s to user %s", subscriptionplan.id, user_uid)

        try:
            # Create subscription from plan using helper
            subscription = self.create_subscription_from_subscriptionplan(
                plan=subscriptionplan,
                source=f"{source}:{updater_uid}",
                granted_at=granted_at,
                auto_renewal_end=auto_renewal_end
            )

            updated_userstatus, permissions_added = self._mutate_userstatus_transactional(
                user_uid=user_uid,
                updater_uid=f"UsersubscriptionOperations:{source}:{updater_uid}",
                mutation_func=lambda userstatus: userstatus.apply_subscription(
                    subscription,
                    add_associated_permissions=add_associated_permissions,
                    remove_previous_subscription_permissions=True,
                    granted_by=f"UsersubscriptionOperations.apply:{source}:{updater_uid}"
                )
            )

            self.logger.info("Successfully applied subscription %s for user %s", subscription.plan_id, user_uid)
            if add_associated_permissions:
                self.logger.info("Applied %d IAM permissions from new subscription for user %s", permissions_added, user_uid)

            return updated_userstatus.active_subscription or subscription

        except Exception as e:
            self.logger.error("Failed to apply subscription to user status: %s", e, exc_info=True)
            raise SubscriptionError(
                detail=f"Failed to apply subscription to user: {str(e)}",
                user_uid=user_uid,
                plan_id=subscriptionplan.id,
                operation="apply_subscriptionplan",
                original_error=e
            ) from e

    async def get_user_active_subscription(self, user_uid: str) -> Optional[UserSubscription]:
        """Get the user's currently active subscription"""
        userstatus = await self.userstatus_ops.get_userstatus(user_uid)
        if userstatus and userstatus.active_subscription and userstatus.active_subscription.is_active():
            self.logger.info("Active subscription found for user %s: %s", user_uid, userstatus.active_subscription.plan_id)
            return userstatus.active_subscription

        self.logger.info("No active subscription found for user %s", user_uid)
        return None

    async def update_user_subscription(
        self,
        user_uid: str,
        subscription_updates: dict,
        updater_uid: str = "admin_update"
    ) -> Optional[UserSubscription]:
        """
        Update user's active subscription with new values.
        Useful for admin corrections or payment-related updates.

        Args:
            user_uid: User ID
            subscription_updates: Dictionary of fields to update
            updater_uid: Who is making the update

        Returns:
            Updated UserSubscription or None if no active subscription
        """
        self.logger.info("Updating subscription for user %s", user_uid)

        userstatus = await self.userstatus_ops.get_userstatus(user_uid)
        if not userstatus:
            raise UserStatusError(
                detail=f"Userstatus not found for user_uid {user_uid}",
                user_uid=user_uid,
                operation="update_user_subscription"
            )

        if not userstatus.active_subscription:
            self.logger.info("No active subscription to update for user %s", user_uid)
            return None

        try:
            # Update the subscription
            subscription_dict = userstatus.active_subscription.model_dump()
            subscription_dict.update(subscription_updates)
            subscription_dict['updated_at'] = datetime.now(timezone.utc)
            subscription_dict['updated_by'] = updater_uid

            updated_subscription = UserSubscription(**subscription_dict)

            updated_userstatus, _ = self._mutate_userstatus_transactional(
                user_uid=user_uid,
                updater_uid=f"UsersubscriptionOperations:{updater_uid}",
                mutation_func=lambda latest_userstatus: latest_userstatus.apply_subscription(
                    updated_subscription,
                    granted_by=f"UsersubscriptionOperations.update:{updater_uid}"
                )
            )

            self.logger.info("Successfully updated subscription for user %s", user_uid)
            return updated_userstatus.active_subscription

        except Exception as e:
            self.logger.error("Failed to update subscription for user %s: %s", user_uid, e, exc_info=True)
            raise SubscriptionError(
                detail=f"Failed to update subscription: {str(e)}",
                user_uid=user_uid,
                operation="update_user_subscription",
                original_error=e
            ) from e

    async def cancel_user_subscription(
        self,
        user_uid: str,
        updater_uid: str,
        reason: Optional[str] = None
    ) -> bool:
        """Cancel a user's active subscription by downgrading to their fallback plan.

        Cancellation is semantically equivalent to downgrading the user to their
        fallback (free) plan. The subscription stays ACTIVE on the fallback plan
        rather than being set to CANCELLED.

        Args:
            user_uid: User ID
            updater_uid: UID of the admin/system performing the cancellation
            reason: Optional reason for the cancellation

        Returns:
            True if subscription was downgraded to fallback, False if no active subscription
        """
        effective_reason = f"cancel_by_{updater_uid}:{reason or 'not_specified'}"
        result = await self.downgrade_user_subscription_to_fallback_subscriptionplan(
            user_uid=user_uid,
            reason=effective_reason
        )
        return result is not None

    async def downgrade_user_subscription_to_fallback_subscriptionplan(
        self,
        user_uid: str,
        reason: str = "subscription_expired"
    ) -> Optional[UserSubscription]:
        """
        Downgrade user to their fallback plan.

        Args:
            user_uid: User ID
            reason: Reason for downgrade

        Returns:
            New UserSubscription if fallback plan exists, None otherwise
        """
        self.logger.info("Attempting to downgrade user %s to fallback plan. Reason: %s", user_uid, reason)

        userstatus = await self.userstatus_ops.get_userstatus(user_uid)
        if not userstatus:
            raise UserStatusError(
                detail=f"Userstatus not found for user_uid {user_uid}",
                user_uid=user_uid,
                operation="downgrade_to_fallback_plan"
            )

        # Check if user has an active subscription with a fallback plan
        if not userstatus.active_subscription:
            self.logger.info("No active subscription for user %s - cannot downgrade", user_uid)
            return None

        fallback_plan_id = userstatus.active_subscription.fallback_plan_id
        if not fallback_plan_id:
            self.logger.info("No fallback plan configured for user %s", user_uid)
            return None

        try:
            # Resolve the fallback plan (supports both plan_name and legacy versioned plan_id)
            try:
                fallback_plan = await self.catalog_subscriptionplan_service.resolve_plan_by_reference(fallback_plan_id)
                if not fallback_plan:
                    self.logger.error("Fallback plan %s not found or no active version in catalog", fallback_plan_id)
                    return None

            except (GoogleCloudError, ServiceError) as e:
                self.logger.error("Failed to resolve fallback plan %s from catalog: %s", fallback_plan_id, e)
                return None

            # Store the current subscription plan_id for logging
            current_plan_id = userstatus.active_subscription.plan_id

            # Create new subscription from fallback plan with updated granted_at
            new_subscription = self.create_subscription_from_subscriptionplan(
                plan=fallback_plan,
                source=f"downgrade_from_{current_plan_id}:{reason}",
                granted_at=datetime.now(timezone.utc),  # Set to now for downgrade
                auto_renewal_end=fallback_plan.plan_default_auto_renewal_end
            )

            # Apply the downgrade atomically in a Firestore transaction (consistent with apply_subscriptionplan pattern)
            _, permissions_added = self._mutate_userstatus_transactional(
                user_uid=user_uid,
                updater_uid=f"UsersubscriptionOperations:downgrade:{reason}",
                mutation_func=lambda latest_userstatus: latest_userstatus.apply_subscription(
                    new_subscription,
                    add_associated_permissions=True,
                    remove_previous_subscription_permissions=True,
                    granted_by=f"UsersubscriptionOperations:downgrade:{reason}"
                )
            )

            self.logger.info("Applied %d IAM permissions from fallback subscription for user %s", permissions_added, user_uid)

            self.logger.info(
                "Successfully downgraded user %s from %s to fallback plan %s",
                user_uid, current_plan_id, fallback_plan_id
            )
            return new_subscription

        except Exception as e:
            self.logger.error("Failed to downgrade user %s to fallback plan: %s", user_uid, e, exc_info=True)
            raise SubscriptionError(
                detail=f"Failed to downgrade to fallback plan: {str(e)}",
                user_uid=user_uid,
                plan_id=fallback_plan_id,
                operation="downgrade_to_fallback_plan",
                original_error=e
            ) from e

    async def migrate_user_subscription_to_latest_plan_reference(
        self,
        user_uid: str,
        plan_reference: str,
        updater_uid: str,
        source: str = "admin_subscription_migration",
    ) -> Dict[str, Any]:
        """Migrate one user's active subscription snapshot to the latest active version of a plan.

        Migration keeps the current cycle timing and billing linkage fields, while syncing
        plan-derived fields (version, permissions, credits config, fallback plan).
        """
        target_plan = await self._resolve_target_plan_from_reference(plan_reference)
        target_plan_id = self._build_target_plan_id(target_plan)

        updated_userstatus, migration_meta = self._mutate_userstatus_transactional(
            user_uid=user_uid,
            updater_uid=f"UsersubscriptionOperations:migrate_one:{source}:{updater_uid}",
            mutation_func=lambda latest_userstatus: self._migrate_single_userstatus_to_target_plan(
                latest_userstatus=latest_userstatus,
                target_plan=target_plan,
                target_plan_id=target_plan_id,
                updater_uid=updater_uid,
                source=source,
            ),
        )

        final_active_subscription = updated_userstatus.active_subscription
        return {
            "user_uid": user_uid,
            "plan_reference": plan_reference,
            "target_plan_id": target_plan_id,
            "migrated": bool(migration_meta.get("migrated", False)),
            "reason": migration_meta.get("reason"),
            "previous_plan_id": migration_meta.get("previous_plan_id"),
            "final_plan_id": final_active_subscription.plan_id if final_active_subscription else None,
            "permissions_added": int(migration_meta.get("permissions_added", 0)),
        }

    def _migrate_single_userstatus_to_target_plan(
        self,
        latest_userstatus: UserStatus,
        target_plan: SubscriptionPlan,
        target_plan_id: str,
        updater_uid: str,
        source: str,
    ) -> Dict[str, Any]:
        """Mutation function for single-user subscription migration."""
        active_subscription = latest_userstatus.active_subscription

        if not active_subscription:
            return {
                "migrated": False,
                "reason": "no_active_subscription",
                "_has_changes": False,
            }

        if not active_subscription.is_active():
            return {
                "migrated": False,
                "reason": "active_subscription_is_not_currently_active",
                "previous_plan_id": active_subscription.plan_id,
                "_has_changes": False,
            }

        if str(active_subscription.plan_name) != str(target_plan.plan_name.value):
            return {
                "migrated": False,
                "reason": "active_subscription_plan_name_mismatch",
                "previous_plan_id": active_subscription.plan_id,
                "_has_changes": False,
            }

        if self._is_subscription_aligned_with_target_plan(active_subscription, target_plan, target_plan_id):
            return {
                "migrated": False,
                "reason": "already_aligned_with_latest_plan",
                "previous_plan_id": active_subscription.plan_id,
                "_has_changes": False,
            }

        migrated_subscription = self._build_migrated_subscription_preserving_cycle(
            active_subscription=active_subscription,
            target_plan=target_plan,
            updater_uid=updater_uid,
            source=source,
        )
        permissions_added = latest_userstatus.apply_subscription(
            migrated_subscription,
            add_associated_permissions=True,
            remove_previous_subscription_permissions=True,
            granted_by=f"UsersubscriptionOperations.migrate:{source}:{updater_uid}",
        )

        return {
            "migrated": True,
            "reason": "migrated_to_latest_plan",
            "previous_plan_id": active_subscription.plan_id,
            "permissions_added": permissions_added,
            "_has_changes": True,
        }

    async def migrate_user_subscriptions_to_latest_plan_by_user_uids(
        self,
        plan_reference: str,
        user_uids: List[str],
        updater_uid: str,
        source: str = "admin_subscription_migration_bulk",
        use_batch_write: bool = True,
    ) -> Dict[str, Any]:
        """Migrate explicit users to the latest active plan version.

        Bulk calls are capped to MAX_BULK_SUBSCRIPTION_MIGRATION_USERS per request.
        """
        normalized_user_uids = [uid.strip() for uid in user_uids if uid and uid.strip()]
        normalized_user_uids = list(dict.fromkeys(normalized_user_uids))

        self._validate_bulk_migration_size(normalized_user_uids)

        if not normalized_user_uids:
            return {
                "plan_reference": plan_reference,
                "targeted_users": 0,
                "migrated_count": 0,
                "skipped_count": 0,
                "failed_count": 0,
                "results": [],
            }

        target_plan = await self._resolve_target_plan_from_reference(plan_reference)
        target_plan_id = self._build_target_plan_id(target_plan)

        if use_batch_write:
            return await self._migrate_user_subscriptions_to_latest_plan_by_user_uids_batch_write(
                plan_reference=plan_reference,
                target_plan=target_plan,
                target_plan_id=target_plan_id,
                user_uids=normalized_user_uids,
                updater_uid=updater_uid,
                source=source,
            )

        per_user_results: List[Dict[str, Any]] = []
        for user_uid in normalized_user_uids:
            try:
                per_user_result = await self.migrate_user_subscription_to_latest_plan_reference(
                    user_uid=user_uid,
                    plan_reference=plan_reference,
                    updater_uid=updater_uid,
                    source=source,
                )
                per_user_results.append(per_user_result)
            except Exception as exc:
                per_user_results.append({
                    "user_uid": user_uid,
                    "plan_reference": plan_reference,
                    "target_plan_id": target_plan_id,
                    "migrated": False,
                    "reason": "migration_exception",
                    "error": str(exc),
                })

        migrated_count = len([row for row in per_user_results if row.get("migrated") is True])
        failed_count = len([row for row in per_user_results if row.get("reason") == "migration_exception"])
        skipped_count = len(per_user_results) - migrated_count - failed_count

        return {
            "plan_reference": plan_reference,
            "target_plan_id": target_plan_id,
            "targeted_users": len(normalized_user_uids),
            "migrated_count": migrated_count,
            "skipped_count": skipped_count,
            "failed_count": failed_count,
            "results": per_user_results,
            "batch_write_used": False,
        }

    async def _migrate_user_subscriptions_to_latest_plan_by_user_uids_batch_write(
        self,
        plan_reference: str,
        target_plan: SubscriptionPlan,
        target_plan_id: str,
        user_uids: List[str],
        updater_uid: str,
        source: str,
    ) -> Dict[str, Any]:
        """Migrate users using Firestore batch write (max 30 per call)."""
        batch = self.db.batch()
        per_user_results: List[Dict[str, Any]] = []
        pending_writes = 0

        for user_uid in user_uids:
            try:
                userstatus = await self.userstatus_ops.get_userstatus(user_uid)
                if not userstatus:
                    per_user_results.append({
                        "user_uid": user_uid,
                        "plan_reference": plan_reference,
                        "target_plan_id": target_plan_id,
                        "migrated": False,
                        "reason": "userstatus_not_found",
                    })
                    continue

                active_subscription = userstatus.active_subscription
                if not active_subscription:
                    per_user_results.append({
                        "user_uid": user_uid,
                        "plan_reference": plan_reference,
                        "target_plan_id": target_plan_id,
                        "migrated": False,
                        "reason": "no_active_subscription",
                    })
                    continue

                if not active_subscription.is_active():
                    per_user_results.append({
                        "user_uid": user_uid,
                        "plan_reference": plan_reference,
                        "target_plan_id": target_plan_id,
                        "migrated": False,
                        "reason": "active_subscription_is_not_currently_active",
                        "previous_plan_id": active_subscription.plan_id,
                    })
                    continue

                if str(active_subscription.plan_name) != str(target_plan.plan_name.value):
                    per_user_results.append({
                        "user_uid": user_uid,
                        "plan_reference": plan_reference,
                        "target_plan_id": target_plan_id,
                        "migrated": False,
                        "reason": "active_subscription_plan_name_mismatch",
                        "previous_plan_id": active_subscription.plan_id,
                    })
                    continue

                if self._is_subscription_aligned_with_target_plan(active_subscription, target_plan, target_plan_id):
                    per_user_results.append({
                        "user_uid": user_uid,
                        "plan_reference": plan_reference,
                        "target_plan_id": target_plan_id,
                        "migrated": False,
                        "reason": "already_aligned_with_latest_plan",
                        "previous_plan_id": active_subscription.plan_id,
                    })
                    continue

                migrated_subscription = self._build_migrated_subscription_preserving_cycle(
                    active_subscription=active_subscription,
                    target_plan=target_plan,
                    updater_uid=updater_uid,
                    source=source,
                )

                permissions_added = userstatus.apply_subscription(
                    migrated_subscription,
                    add_associated_permissions=True,
                    remove_previous_subscription_permissions=True,
                    granted_by=f"UsersubscriptionOperations.bulk_migrate:{source}:{updater_uid}",
                )

                update_data = userstatus.model_dump(exclude_none=False)
                update_data.pop("user_uid", None)
                update_data.pop("id", None)
                update_data.pop("created_at", None)
                update_data.pop("created_by", None)
                update_data["updated_by"] = f"UsersubscriptionOperations.bulk_migrate:{source}:{updater_uid}"
                update_data["updated_at"] = datetime.now(timezone.utc)

                userstatus_doc_id = f"{UserStatus.OBJ_REF}_{user_uid}"
                userstatus_ref = self.db.collection(self.userstatus_ops.status_collection_name).document(userstatus_doc_id)
                batch.update(userstatus_ref, update_data)
                pending_writes += 1

                per_user_results.append({
                    "user_uid": user_uid,
                    "plan_reference": plan_reference,
                    "target_plan_id": target_plan_id,
                    "migrated": True,
                    "reason": "migrated_to_latest_plan",
                    "previous_plan_id": active_subscription.plan_id,
                    "final_plan_id": migrated_subscription.plan_id,
                    "permissions_added": int(permissions_added),
                })

            except Exception as exc:
                per_user_results.append({
                    "user_uid": user_uid,
                    "plan_reference": plan_reference,
                    "target_plan_id": target_plan_id,
                    "migrated": False,
                    "reason": "migration_exception",
                    "error": str(exc),
                })

        if pending_writes > 0:
            try:
                batch.commit()
            except Exception as exc:
                for result_row in per_user_results:
                    if result_row.get("migrated") is True:
                        result_row["migrated"] = False
                        result_row["reason"] = "batch_commit_failed"
                        result_row["error"] = str(exc)

        migrated_count = len([row for row in per_user_results if row.get("migrated") is True])
        failed_count = len([
            row for row in per_user_results
            if row.get("reason") in {"migration_exception", "batch_commit_failed"}
        ])
        skipped_count = len(per_user_results) - migrated_count - failed_count

        return {
            "plan_reference": plan_reference,
            "target_plan_id": target_plan_id,
            "targeted_users": len(user_uids),
            "migrated_count": migrated_count,
            "skipped_count": skipped_count,
            "failed_count": failed_count,
            "results": per_user_results,
            "batch_write_used": True,
            "writes_attempted": pending_writes,
        }

    async def migrate_active_subscribers_of_plan_to_latest(
        self,
        plan_reference: str,
        updater_uid: str,
        max_users: int = MAX_BULK_SUBSCRIPTION_MIGRATION_USERS,
        offset: int = 0,
        source: str = "admin_subscription_migration_discovery",
        use_batch_write: bool = True,
    ) -> Dict[str, Any]:
        """Find active subscribers for a plan reference and migrate up to max_users.

        This is intended for controlled migrations such as: "migrate all Base users", with
        capped execution per call (default 30 users).
        """
        if max_users < 1 or max_users > self.MAX_BULK_SUBSCRIPTION_MIGRATION_USERS:
            raise SubscriptionError(
                detail=(
                    f"max_users must be between 1 and {self.MAX_BULK_SUBSCRIPTION_MIGRATION_USERS}; "
                    f"received {max_users}"
                ),
                operation="migrate_active_subscribers_of_plan_to_latest"
            )

        target_plan = await self._resolve_target_plan_from_reference(plan_reference)
        target_plan_id = self._build_target_plan_id(target_plan)
        plan_name_reference = str(target_plan.plan_name.value)

        matching_userstatuses, total_matching = await self.userstatus_ops.list_userstatuss_by_active_subscription_plan_name(
            plan_name=plan_name_reference,
            limit=max_users,
            offset=offset,
        )
        candidate_user_uids = [row.user_uid for row in matching_userstatuses]

        migration_result = await self.migrate_user_subscriptions_to_latest_plan_by_user_uids(
            plan_reference=plan_name_reference,
            user_uids=candidate_user_uids,
            updater_uid=updater_uid,
            source=source,
            use_batch_write=use_batch_write,
        )

        next_offset = offset + len(candidate_user_uids)
        has_more_candidates = next_offset < total_matching

        migration_result.update({
            "plan_reference_requested": plan_reference,
            "resolved_plan_reference": plan_name_reference,
            "target_plan_id": target_plan_id,
            "total_matching_active_subscribers": total_matching,
            "offset": offset,
            "next_offset": next_offset,
            "has_more_candidates": has_more_candidates,
            "candidate_user_uids": candidate_user_uids,
        })
        return migration_result

    ######################################################################
    ######################### Subscription Lifecycle Support Methods #####
    ######################################################################
    # Note: The main review method has been moved to UserStatusOperations
    # as it manages overall user status, not just subscriptions