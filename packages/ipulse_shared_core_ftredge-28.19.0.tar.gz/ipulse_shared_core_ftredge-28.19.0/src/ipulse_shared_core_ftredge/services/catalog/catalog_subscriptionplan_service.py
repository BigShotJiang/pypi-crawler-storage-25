"""
Subscription Plan Catalog Service

This service manages subscription plan templates stored in Firestore.
These templates are used to configure and create user subscriptions consistently.
"""

import logging
from typing import Dict, List, Optional, Any
from google.cloud import firestore
from google.cloud.firestore import Client
from ipulse_shared_base_ftredge import SubscriptionPlanName
from ipulse_shared_base_ftredge.enums.enums_status import ObjectOverallStatus
from ipulse_shared_core_ftredge.models.catalog.subscriptionplan import SubscriptionPlan
from ipulse_shared_core_ftredge.services.base.base_firestore_service import BaseFirestoreService
from ipulse_shared_core_ftredge.cache.shared_cache import SharedCache
from ipulse_shared_core_ftredge.exceptions import ServiceError

# Default TTL for resolve_plan_by_reference cache (1 hour).
# Plans change rarely (a few times per quarter at most). 1h gives at most 1h of
# stale terms per service instance after a catalog reseed, while collapsing
# what would otherwise be one Firestore query per protected request down to
# ~1 query per hour per plan per instance.
RESOLVE_PLAN_CACHE_TTL_S = 3600.0


class CatalogSubscriptionPlanService(BaseFirestoreService[SubscriptionPlan]):
    """
    Service for managing subscription plan catalog configurations.

    This service provides CRUD operations for subscription plan templates that define
    the structure and defaults for user subscriptions.
    """

    def __init__(
        self,
        firestore_client: Client,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize the Subscription Plan Catalog Service.

        Args:
            firestore_client: Firestore client instance
            logger: Logger instance (optional)
        """
        super().__init__(
            db=firestore_client,
            collection_name="papp_core_catalog_subscriptionplans",
            resource_type="subscriptionplan",
            model_class=SubscriptionPlan,
            logger=logger or logging.getLogger(__name__)
        )
        self.archive_collection_name = "~archive_papp_core_catalog_subscriptionplans"

        # Per-instance TTL cache for resolve_plan_by_reference. Singleton service
        # lifetime == Cloud Run instance lifetime, so this naturally bounds
        # staleness to RESOLVE_PLAN_CACHE_TTL_S after a catalog reseed.
        # Use invalidate_resolve_cache() for explicit busts.
        self._resolve_cache: SharedCache[SubscriptionPlan] = SharedCache(
            name="catalog_subscriptionplan_resolve",
            ttl=RESOLVE_PLAN_CACHE_TTL_S,
            enabled=True,
            logger=self.logger,
        )

    async def create_subscriptionplan(
        self,
        subscriptionplan_id: str,
        subscription_plan: SubscriptionPlan,
        creator_uid: str
    ) -> SubscriptionPlan:
        """
        Create a new subscription plan.

        Args:
            subscriptionplan_id: Unique identifier for the plan
            subscription_plan: Subscription plan data
            creator_uid: UID of the user creating the plan

        Returns:
            Created subscription plan

        Raises:
            ServiceError: If creation fails
            ValidationError: If plan data is invalid
        """
        self.logger.info(f"Creating subscription plan: {subscriptionplan_id}")

        # Create the document
        created_doc = await self.create_document(
            doc_id=subscriptionplan_id,
            data=subscription_plan,
            creator_uid=creator_uid
        )

        # Convert back to model
        result = SubscriptionPlan.model_validate(created_doc)
        # New plan affects future resolutions; invalidate cache for fresh lookup.
        self.invalidate_resolve_cache()
        self.logger.info(f"Successfully created subscription plan: {subscriptionplan_id}")
        return result

    async def get_subscriptionplan(self, subscriptionplan_id: str) -> Optional[SubscriptionPlan]:
        """
        Retrieve a subscription plan by ID.

        Args:
            subscriptionplan_id: Unique identifier for the plan

        Returns:
            Subscription plan if found, None otherwise

        Raises:
            ServiceError: If retrieval fails
        """
        self.logger.debug(f"Retrieving subscription plan: {subscriptionplan_id}")
        doc_data = await self.get_document(subscriptionplan_id)
        if doc_data is None:
            return None
        return SubscriptionPlan.model_validate(doc_data) if isinstance(doc_data, dict) else doc_data

    async def update_subscriptionplan(
        self,
        subscriptionplan_id: str,
        updates: Dict[str, Any],
        updater_uid: str
    ) -> SubscriptionPlan:
        """
        Update a subscription plan.

        Args:
            subscriptionplan_id: Unique identifier for the plan
            updates: Fields to update
            updater_uid: UID of the user updating the plan

        Returns:
            Updated subscription plan

        Raises:
            ServiceError: If update fails
            ResourceNotFoundError: If plan not found
            ValidationError: If update data is invalid
        """
        self.logger.info(f"Updating subscription plan: {subscriptionplan_id}")

        updated_doc = await self.update_document(
            doc_id=subscriptionplan_id,
            update_data=updates,
            updater_uid=updater_uid
        )

        result = SubscriptionPlan.model_validate(updated_doc)
        # Plan terms or status may have changed; invalidate cache for fresh lookup.
        self.invalidate_resolve_cache()
        self.logger.info(f"Successfully updated subscription plan: {subscriptionplan_id}")
        return result

    async def delete_subscriptionplan(
        self,
        subscriptionplan_id: str,
        archive: bool = True
    ) -> bool:
        """
        Delete a subscription plan.

        Args:
            subscriptionplan_id: Unique identifier for the plan
            archive: Whether to archive the plan before deletion

        Returns:
            True if deletion was successful

        Raises:
            ServiceError: If deletion fails
            ResourceNotFoundError: If plan not found
        """
        self.logger.info(f"Deleting subscription plan: {subscriptionplan_id}")

        if archive:
            # Get the plan data before deletion for archiving
            template = await self.get_subscriptionplan(subscriptionplan_id)
            if template:
                await self.archive_document(
                    document_data=template.model_dump(),
                    doc_id=subscriptionplan_id,
                    archive_collection=self.archive_collection_name,
                    archived_by="system"
                )

        result = await self.delete_document(subscriptionplan_id)
        # Removed plan must drop out of resolution; invalidate cache.
        self.invalidate_resolve_cache()
        self.logger.info(f"Successfully deleted subscription plan: {subscriptionplan_id}")
        return result

    async def list_subscriptionplans(
        self,
        plan_name: Optional[SubscriptionPlanName] = None,
        pulse_status: Optional[ObjectOverallStatus] = None,
        latest_version_only: bool = False,
        limit: Optional[int] = None,
        version_ordering: str = "DESCENDING"
    ) -> List[SubscriptionPlan]:
        """
        List subscription plans with optional filtering.

        Args:
            plan_name: Filter by specific plan name (FREE, BASE, PREMIUM)
            pulse_status: Filter by specific pulse status
            latest_version_only: Only return the latest version per plan
            limit: Maximum number of plans to return
            version_ordering: Order direction for version ('ASCENDING' or 'DESCENDING')

        Returns:
            List of subscription plans

        Raises:
            ServiceError: If listing fails
        """
        self.logger.debug(f"Listing subscription plans - plan_name: {plan_name}, pulse_status: {pulse_status}, latest_version_only: {latest_version_only}, version_ordering: {version_ordering}")

        # Build query filters
        filters = []
        if plan_name:
            filters.append(("plan_name", "==", plan_name.value))
        if pulse_status:
            filters.append(("pulse_status", "==", pulse_status.value))

        # Set ordering
        order_by = "plan_version"
        order_direction = firestore.Query.DESCENDING if version_ordering == "DESCENDING" else firestore.Query.ASCENDING

        # Optimize query if only the latest version of a specific plan is needed
        query_limit = limit
        if latest_version_only and plan_name:
            query_limit = 1
            # Ensure descending order to get the latest
            order_direction = firestore.Query.DESCENDING

        docs = await self.list_documents(
            filters=filters,
            order_by=order_by,
            order_direction=order_direction,
            limit=query_limit
        )

        # Convert to SubscriptionPlan models
        plans = [SubscriptionPlan.model_validate(doc) for doc in docs]

        # If we need the latest of all plans, we fetch all sorted by version
        # and then pick the first one for each plan_name in Python.
        if latest_version_only and not plan_name:
            # This assumes the list is sorted by version descending.
            if order_direction != firestore.Query.DESCENDING:
                self.logger.warning("latest_version_only is True but version_ordering is not DESCENDING. Results may not be the latest.")

            plan_groups = {}
            for plan in plans:
                key = plan.plan_name.value
                if key not in plan_groups:
                    plan_groups[key] = plan  # First one is the latest due to sorting

            return list(plan_groups.values())

        return plans


    def _get_collection(self):
        """Get the Firestore collection reference."""
        return self.db.collection(self.collection_name)

    async def subscriptionplan_exists(self, subscriptionplan_id: str) -> bool:
        """
        Check if a subscription plan exists.

        Args:
            subscriptionplan_id: Unique identifier for the plan

        Returns:
            True if plan exists, False otherwise

        Raises:
            ServiceError: If check fails
        """
        return await self.document_exists(subscriptionplan_id)

    def invalidate_resolve_cache(self, plan_reference: Optional[str] = None) -> None:
        """
        Invalidate the resolve_plan_by_reference TTL cache.

        Args:
            plan_reference: If provided, invalidate only that key. If None,
                clear the entire cache (use after a catalog reseed to force
                immediate pickup of new plan versions).
        """
        if plan_reference:
            self._resolve_cache.invalidate(plan_reference)
        else:
            self._resolve_cache.invalidate_all()

    async def resolve_plan_by_reference(self, plan_reference: str) -> Optional[SubscriptionPlan]:
        """
        Resolve a plan reference to the latest active SubscriptionPlan.

        Accepts either a plan_name (e.g., 'free_subscription') or a legacy
        versioned plan_id (e.g., 'free_subscription_1'). Tries plan_name-based
        resolution first (latest active version), then falls back to direct
        doc-by-ID fetch for backward compatibility with existing Firestore data.

        Results are cached per-instance with a TTL of RESOLVE_PLAN_CACHE_TTL_S
        (default 1h) to avoid hammering Firestore on every protected request.
        Use invalidate_resolve_cache() to force immediate pickup after a
        catalog reseed.

        Args:
            plan_reference: A SubscriptionPlanName value or a legacy plan doc ID.

        Returns:
            The latest active SubscriptionPlan, or None if not found.
        """
        if not plan_reference:
            return None

        # Cache lookup first; on miss, run actual resolution and cache the result.
        cached = self._resolve_cache.get(plan_reference)
        if cached is not None:
            return cached

        resolved = await self._resolve_plan_by_reference_uncached(plan_reference)
        if resolved is not None:
            # Only cache positive resolutions. None results are intentionally not
            # cached so that a brief catalog gap (e.g. mid-reseed) doesn't get
            # pinned for the full TTL window.
            self._resolve_cache.set(plan_reference, resolved)
        return resolved

    async def _resolve_plan_by_reference_uncached(self, plan_reference: str) -> Optional[SubscriptionPlan]:
        """Uncached implementation of resolve_plan_by_reference. See parent for docs."""
        # Strategy 1: Treat as a SubscriptionPlanName and resolve latest active version
        try:
            plan_name_enum = SubscriptionPlanName(plan_reference)
            plans = await self.list_subscriptionplans(
                plan_name=plan_name_enum,
                pulse_status=ObjectOverallStatus.ACTIVE,
                latest_version_only=True,
                limit=1
            )
            if plans:
                self.logger.debug("Resolved plan_name '%s' to doc '%s' (v%s)",
                                  plan_reference, plans[0].id, plans[0].plan_version)
                return plans[0]
            self.logger.warning("No active plan found for plan_name '%s'", plan_reference)
        except ValueError:
            # Not a valid SubscriptionPlanName — fall through to direct ID lookup
            pass

        # Strategy 2: Legacy fallback — treat as a direct versioned doc ID
        plan = await self.get_subscriptionplan(plan_reference)
        if plan:
            if plan.pulse_status == ObjectOverallStatus.ACTIVE:
                self.logger.debug("Resolved legacy plan_id '%s' via direct fetch", plan_reference)
                return plan
            else:
                # Legacy ID exists but plan is not active — try resolving by its plan_name instead
                self.logger.info(
                    "Legacy plan_id '%s' is %s, resolving latest active version of '%s'",
                    plan_reference, plan.pulse_status.value, plan.plan_name.value
                )
                plans = await self.list_subscriptionplans(
                    plan_name=plan.plan_name,
                    pulse_status=ObjectOverallStatus.ACTIVE,
                    latest_version_only=True,
                    limit=1
                )
                if plans:
                    return plans[0]
                self.logger.warning("No active plan found for plan_name '%s' (from legacy ref '%s')",
                                    plan.plan_name.value, plan_reference)

        self.logger.warning("Could not resolve plan reference '%s'", plan_reference)
        return None

    async def validate_subscriptionplan_data(self, subscriptionplan_data: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate subscription plan data.

        Args:
            subscriptionplan_data: Plan data to validate

        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        try:
            SubscriptionPlan.model_validate(subscriptionplan_data)
            return True, []
        except Exception as e:
            return False, [str(e)]
