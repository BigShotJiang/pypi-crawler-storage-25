from dataclasses import dataclass
from enum import Enum
import logging
from typing import AsyncGenerator, Dict, Generic, List, Optional

import torch
from transformers import PreTrainedTokenizerBase
from typing_extensions import TypeVar


@dataclass
class Logprob:
    """Infos for supporting OpenAI compatible logprobs and token ranks.

    Attributes:
        logprob: The logprob of chosen token
        rank: The vocab rank of chosen token (>=1)
        decoded_token: The decoded chosen token index
    """

    logprob: float
    rank: Optional[int] = None
    decoded_token: Optional[str] = None


# PromptLogprobs: First element is None (no prior context for first token),
# subsequent elements contain logprobs for each prompt token position.
PromptLogprobs = List[Optional[Dict[int, Logprob]]]

SampleLogprobs = List[Dict[int, Logprob]]


class CompletionOutput:
    """The output data of one completion output of a request.

    Args:
        index: The index of the output in the request.
        text: The generated output text.
        token_ids: The token IDs of the generated output text.
            Note that it is expected to have EOS token included in the token_ids.
        logprobs: The log probabilities of the top probability words at each
            position if the logprobs are requested.
        finish_reason: The reason why the sequence is finished.
    """

    def __init__(
        self,
        index: int,
        text: str,
        token_ids: List[int],
        logprobs: Optional[SampleLogprobs],
        finish_reason: Optional[str] = None,
    ) -> None:
        self.index = index
        self.text = text
        self.token_ids = token_ids
        self.logprobs = logprobs
        self.finish_reason = finish_reason

    def __repr__(self) -> str:
        return (
            f"CompletionOutput(index={self.index}, "
            f"text={self.text!r}, "
            f"token_ids={self.token_ids}, "
            f"logprobs={self.logprobs}, "
            f"finish_reason={self.finish_reason})"
        )


class RequestOutput:
    def __init__(
        self,
        request_id: str,
        prompt: str,
        prompt_token_ids: List[int],
        prompt_logprobs: Optional[PromptLogprobs],
        outputs: List[CompletionOutput],
        finished: bool,
        num_cached_tokens: int,
    ) -> None:
        self.request_id = request_id
        self.prompt = prompt
        self.prompt_token_ids = prompt_token_ids
        self.prompt_logprobs = prompt_logprobs
        self.outputs = outputs
        self.finished = finished
        self.num_cached_tokens = num_cached_tokens

    def __repr__(self) -> str:
        return (
            f"RequestOutput(request_id={self.request_id}, "
            f"prompt={self.prompt!r}, "
            f"prompt_token_ids={self.prompt_token_ids}, "
            f"prompt_logprobs={self.prompt_logprobs}, "
            f"outputs={self.outputs}, "
            f"finished={self.finished}, "
            f"num_cached_tokens={self.num_cached_tokens})"
        )


@dataclass
class PoolingOutput:
    """The output data of one pooling output of a request.

    Args:
        data: The extracted hidden states.
    """

    data: torch.Tensor

    def __repr__(self) -> str:
        return f"PoolingOutput(data={self.data})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, self.__class__) and bool((self.data == other.data).all())


_O = TypeVar("_O", default=PoolingOutput)


class PoolingRequestOutput(Generic[_O]):
    """
    The output data of a pooling request to the LLM.

    Args:
        request_id (str): A unique identifier for the pooling request.
        outputs (PoolingOutput): The pooling results for the given input.
        prompt_token_ids (list[int]): A list of token IDs used in the prompt.
        finished (bool): A flag indicating whether the pooling is completed.
    """

    def __init__(
        self,
        request_id: str,
        outputs: _O,
        prompt_token_ids: list[int],
        finished: bool,
    ):
        self.request_id = request_id
        self.prompt_token_ids = prompt_token_ids
        self.finished = finished
        self.outputs = outputs

    def __repr__(self):
        return (
            f"{type(self).__name__}(request_id={self.request_id!r}, "
            f"outputs={self.outputs!r}, "
            f"prompt_token_ids={self.prompt_token_ids}, "
            f"finished={self.finished})"
        )


@dataclass
class EmbeddingOutput:
    """The output data of one embedding output of a request.

    Args:
        embedding: The embedding vector, which is a list of floats.
            Its length depends on the hidden dimension of the model.
    """

    embedding: list[float]

    @staticmethod
    def from_base(pooling_output: PoolingOutput) -> "EmbeddingOutput":
        pooled_data = pooling_output.data
        if pooled_data.ndim != 1:
            raise ValueError("pooled_data should be a 1-D embedding vector")

        return EmbeddingOutput(pooled_data.tolist())

    @property
    def hidden_size(self) -> int:
        return len(self.embedding)

    def __repr__(self) -> str:
        return f"EmbeddingOutput(hidden_size={self.hidden_size})"


class EmbeddingRequestOutput(PoolingRequestOutput[EmbeddingOutput]):
    @staticmethod
    def from_base(request_output: PoolingRequestOutput) -> "EmbeddingRequestOutput":
        return EmbeddingRequestOutput(
            request_id=request_output.request_id,
            outputs=EmbeddingOutput.from_base(request_output.outputs),
            prompt_token_ids=request_output.prompt_token_ids,
            finished=request_output.finished,
        )


@dataclass
class ClassificationOutput:
    """The output data of one classification output of a request.

    Args:
        probs: The probability vector, which is a list of floats.
            Its length depends on the number of classes.
    """

    probs: list[float]

    @staticmethod
    def from_base(pooling_output: PoolingOutput) -> "ClassificationOutput":
        # pooling_output shape: (num_classes)
        pooled_data = pooling_output.data
        if pooled_data.ndim != 1:
            raise ValueError("pooled_data should be a 1-D probability vector")

        return ClassificationOutput(pooled_data.tolist())

    @property
    def num_classes(self) -> int:
        return len(self.probs)

    def __repr__(self) -> str:
        return f"ClassificationOutput(num_classes={self.num_classes})"


class ClassificationRequestOutput(PoolingRequestOutput[ClassificationOutput]):
    @staticmethod
    def from_base(request_output: PoolingRequestOutput) -> "ClassificationRequestOutput":
        return ClassificationRequestOutput(
            request_id=request_output.request_id,
            outputs=ClassificationOutput.from_base(request_output.outputs),
            prompt_token_ids=request_output.prompt_token_ids,
            finished=request_output.finished,
        )


@dataclass
class ScoringOutput:
    """The output data of one scoring output of a request.

    Args:
        score: The similarity score, which is a scalar value.
    """

    score: float

    @staticmethod
    def from_base(pooling_output: PoolingOutput) -> "ScoringOutput":
        # pooling_output shape:
        #   classify task: (num_classes) num_classes == 1
        #   embed task: a scalar value
        pooled_data = pooling_output.data.squeeze()
        if pooled_data.ndim != 0:
            raise ValueError("pooled_data should be a scalar score")

        return ScoringOutput(pooled_data.item())

    def __repr__(self) -> str:
        return f"ScoringOutput(score={self.score})"


class ScoringRequestOutput(PoolingRequestOutput[ScoringOutput]):
    @staticmethod
    def from_base(request_output: PoolingRequestOutput) -> "ScoringRequestOutput":
        return ScoringRequestOutput(
            request_id=request_output.request_id,
            outputs=ScoringOutput.from_base(request_output.outputs),
            prompt_token_ids=request_output.prompt_token_ids,
            finished=request_output.finished,
        )


class RequestOutputKind(Enum):
    # Return entire output so far in every RequestOutput
    CUMULATIVE = 0
    # Return only deltas in each RequestOutput
    DELTA = 1
    # Return only final output
    FINAL = 2


class NativeOutputConverter:
    """
    This class has two main functions:
    1. Convert the NativeRequestOutput to RequestOutput, respecting the RequestOutputKind.
    2. For streaming RequestOutput, detokenize incrementally so that
       incomplete tokens (which are represented as replacement character "�") is not returned to the user.
    This class must be initialized per prompt, not per request.

    Args:
        tokenizer: The tokenizer used to tokenize the prompt.
        n: The number of expected outputs. Usually equals to `SamplingParams.n` if not beam search.
        output_kind: Determines how to handle the output. See `RequestOutputKind`.
        request_id: The request ID.
        prompt: The prompt text.
        prompt_token_ids: The prompt token IDs.
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        n: int,
        output_kind: RequestOutputKind,
        skip_special_tokens: bool,
        request_id: str,
        prompt: str,
        prompt_token_ids: List[int],
    ):
        self.n = n
        self.tokenizer = tokenizer
        self.output_kind = output_kind
        self.skip_special_tokens = skip_special_tokens
        self.request_id = request_id
        self.prompt = prompt
        self.prompt_token_ids = prompt_token_ids

    def _decode_token(self, token_id: int) -> str:
        """Decode a single token id to its string representation."""
        decode_res = self.tokenizer.decode([token_id])
        assert type(decode_res) is str
        return decode_res

    def _convert_prompt_logprobs(
        self, native_prompt_logprobs: List[Optional[List[tuple]]]
    ) -> PromptLogprobs:
        """Convert native prompt_logprobs to Python PromptLogprobs format."""
        result: PromptLogprobs = []
        for pos_logprobs in native_prompt_logprobs:
            if pos_logprobs is None:
                result.append(None)
            else:
                result.append(
                    {
                        token_id: Logprob(
                            logprob.logprob, logprob.rank, self._decode_token(token_id)
                        )
                        for token_id, logprob in pos_logprobs
                    }
                )
        return result

    async def convert_stream(
        self, native_output_generator: AsyncGenerator["NativeRequestOutput", None]  # type: ignore # noqa: F821
    ) -> AsyncGenerator[RequestOutput, None]:
        decoders: List[StreamDecoder] = [
            StreamDecoder(self.tokenizer, self.skip_special_tokens) for _ in range(self.n)
        ]
        completion_outputs: List[CompletionOutput] = [
            CompletionOutput(i, "", [], None, None) for i in range(self.n)
        ]
        logprobs: List[List[Dict[int, Logprob]]] = [[] for _ in range(self.n)]
        prompt_logprobs: Optional[PromptLogprobs] = None
        num_cached_tokens: int = 0

        if self.output_kind == RequestOutputKind.FINAL:
            async for native_output in native_output_generator:
                if (n := native_output.num_cached_tokens) is not None:
                    num_cached_tokens = n
                for o in native_output.outputs:
                    if o.finish_reason is not None:
                        completion_outputs[o.index].finish_reason = o.finish_reason
                    if o.logprobs is not None:
                        logprobs[o.index].extend(
                            {
                                token_id: Logprob(
                                    logprob.logprob, logprob.rank, logprob.decoded_token
                                )
                                for token_id, logprob in token_id_to_logprob
                            }
                            for token_id_to_logprob in o.logprobs
                        )
                    # Extract prompt_logprobs from the first output (request-level)
                    if prompt_logprobs is None and o.prompt_logprobs is not None:
                        prompt_logprobs = self._convert_prompt_logprobs(o.prompt_logprobs)
                    decoders[o.index].push(o.token_ids)
                    completion_outputs[o.index].token_ids.extend(o.token_ids)
            for idx, decoder in enumerate(decoders):
                completion_outputs[idx].text = decoder.flush()
                if logprobs[idx]:
                    completion_outputs[idx].logprobs = logprobs[idx]
            yield RequestOutput(
                request_id=self.request_id,
                prompt=self.prompt,
                prompt_token_ids=self.prompt_token_ids,
                prompt_logprobs=prompt_logprobs,
                outputs=completion_outputs,
                finished=all(co.finish_reason is not None for co in completion_outputs),
                num_cached_tokens=num_cached_tokens,
            )

        elif self.output_kind == RequestOutputKind.CUMULATIVE:
            async for native_output in native_output_generator:
                if (n := native_output.num_cached_tokens) is not None:
                    num_cached_tokens = n
                for o in native_output.outputs:
                    if o.finish_reason is not None:
                        completion_outputs[o.index].finish_reason = o.finish_reason
                    if o.logprobs is not None:
                        logprobs[o.index].extend(
                            {
                                token_id: Logprob(
                                    logprob.logprob, logprob.rank, logprob.decoded_token
                                )
                                for token_id, logprob in token_id_to_logprob
                            }
                            for token_id_to_logprob in o.logprobs
                        )
                    # Extract prompt_logprobs from the first output (request-level)
                    if prompt_logprobs is None and o.prompt_logprobs is not None:
                        prompt_logprobs = self._convert_prompt_logprobs(o.prompt_logprobs)
                    text = decoders[o.index].push_decode(o.token_ids)
                    completion_outputs[o.index].text += text
                    completion_outputs[o.index].token_ids.extend(o.token_ids)
                    if logprobs[o.index]:
                        # fmt: off
                        completion_outputs[o.index].logprobs = \
                            logprobs[o.index][: len(completion_outputs[o.index].token_ids)]
                        # fmt: on
                finished = all(co.finish_reason is not None for co in completion_outputs)
                if not finished:
                    yield RequestOutput(
                        request_id=self.request_id,
                        prompt=self.prompt,
                        prompt_token_ids=self.prompt_token_ids,
                        prompt_logprobs=prompt_logprobs,
                        outputs=completion_outputs,
                        finished=False,
                        num_cached_tokens=num_cached_tokens,
                    )
                else:
                    break
            yield RequestOutput(
                request_id=self.request_id,
                prompt=self.prompt,
                prompt_token_ids=self.prompt_token_ids,
                prompt_logprobs=prompt_logprobs,
                outputs=completion_outputs,
                finished=True,
                num_cached_tokens=num_cached_tokens,
            )

        else:
            # RequestOutputKind.DELTA
            # Unlike the above two, we set finished=True per CompletionOutput, not per RequestOutput.
            async for native_output in native_output_generator:
                if (n := native_output.num_cached_tokens) is not None:
                    num_cached_tokens = n
                for o in native_output.outputs:
                    if o.finish_reason is not None:
                        completion_outputs[o.index].finish_reason = o.finish_reason
                    if o.logprobs is not None:
                        logprobs[o.index].extend(
                            {
                                token_id: Logprob(
                                    logprob.logprob, logprob.rank, logprob.decoded_token
                                )
                                for token_id, logprob in token_id_to_logprob
                            }
                            for token_id_to_logprob in o.logprobs
                        )
                    # Extract prompt_logprobs from the first output (request-level)
                    if prompt_logprobs is None and o.prompt_logprobs is not None:
                        prompt_logprobs = self._convert_prompt_logprobs(o.prompt_logprobs)
                    text = decoders[o.index].push_decode(o.token_ids)

                    finished = o.finish_reason is not None

                    completion_outputs[o.index].text = text
                    completion_outputs[o.index].token_ids = o.token_ids
                    # fmt: off
                    completion_outputs[o.index].logprobs = \
                        logprobs[o.index][: len(completion_outputs[o.index].token_ids)]
                    logprobs[o.index] = \
                        logprobs[o.index][len(completion_outputs[o.index].token_ids) :]
                    # fmt: on
                    yield RequestOutput(
                        request_id=self.request_id,
                        prompt=self.prompt,
                        prompt_token_ids=self.prompt_token_ids,
                        prompt_logprobs=prompt_logprobs,
                        outputs=[completion_outputs[o.index]],
                        finished=finished,
                        num_cached_tokens=num_cached_tokens,
                    )


class StreamDecoder:
    # Maximum number of tokenizer.decode() calls allowed per completion output.
    # Set to 4 since BPE-based tokenizers typically split natural language words into at most 4 tokens.
    MAX_DECODE_TRAIL = 4

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        skip_special_tokens: bool,
    ):
        self.tokenizer = tokenizer
        self.skip_special_tokens = skip_special_tokens
        self.token_buffer: List[int] = []

    def push(self, token_ids: List[int]) -> None:
        """
        Push tokens in the buffer without decoding it.
        """
        self.token_buffer.extend(token_ids)

    def push_decode(self, token_ids: List[int]) -> str:
        """
        Push tokens in the buffer and decode them.
        This function returns the first human-readable text as output while pushing tokens one by one,
        and the leftovers are pushed to the buffer.
        You must decode the leftovers by calling `flush()` at the end in a separate function call.
        """
        if len(token_ids) > self.MAX_DECODE_TRAIL:
            # This scenario is unlikely since for streaming requests because
            # the Generator normally emits single token per CompletionOutput.
            # Multiple tokens returned in a CompletionOutput could negatively impact
            # TPOT and user experience, so logging a warning.
            logging.warning(
                f"Received {len(token_ids)} tokens at once in streaming mode. "
                f"This may degrade TPOT and user experience. "
                f"Keeping only last {self.MAX_DECODE_TRAIL} tokens."
            )
            self.token_buffer.extend(token_ids[: -self.MAX_DECODE_TRAIL])
            token_ids = token_ids[-self.MAX_DECODE_TRAIL :]

        for i, token_id in enumerate(token_ids):
            self.token_buffer.append(token_id)
            decoded_text = self._decode(self.token_buffer)
            if not decoded_text.endswith("�"):
                break
        else:
            # failed to retrieve a human-readable text
            return ""

        if i == len(token_ids) - 1:
            self.token_buffer.clear()
        else:
            self.token_buffer = token_ids[i + 1 :]

        return decoded_text

    def flush(self) -> str:
        """
        Decode all remaining tokens in the buffer.
        """
        decoded_text = self._decode(self.token_buffer)
        self.token_buffer.clear()
        return decoded_text

    def has_remaining_tokens(self) -> bool:
        return bool(self.token_buffer)

    def _decode(self, token_ids: List[int]) -> str:
        decode_res = self.tokenizer.decode(
            token_ids,
            skip_special_tokens=self.skip_special_tokens,
            cleanup_tokenization_spaces=True,
        )
        assert type(decode_res) is str
        return decode_res
