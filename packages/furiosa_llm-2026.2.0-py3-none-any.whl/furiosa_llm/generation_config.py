import json
import logging
import os
from typing import Any

from transformers import GenerationConfig

logger = logging.getLogger(__name__)

# Fields from generation_config.json that map to SamplingParams.
# Keys are generation_config field names; values are SamplingParams field names.
_FIELD_MAPPING: dict[str, str] = {
    "repetition_penalty": "repetition_penalty",
    "temperature": "temperature",
    "top_k": "top_k",
    "top_p": "top_p",
    "min_p": "min_p",
    "max_new_tokens": "max_tokens",
}


def try_load_generation_config(model_path: str | os.PathLike) -> GenerationConfig | None:
    """Load GenerationConfig from a model path.

    Returns None if generation_config.json is not found or is malformed.
    """
    try:
        return GenerationConfig.from_pretrained(str(model_path))
    except OSError:
        return None
    except json.JSONDecodeError:
        logger.warning("malformed generation_config.json in %s, ignoring", model_path)
        return None


def get_diff_sampling_params(model_path: str | os.PathLike) -> dict[str, Any]:
    """Extract non-default sampling params from generation_config.json.

    Returns a dict with only supported fields that differ from HF defaults.
    Renames max_new_tokens to max_tokens.
    """
    config = try_load_generation_config(model_path)
    if config is None:
        return {}

    diff = config.to_diff_dict()
    result: dict[str, Any] = {}
    for hf_field, sp_field in _FIELD_MAPPING.items():
        if hf_field in diff and diff[hf_field] is not None:
            result[sp_field] = diff[hf_field]

    return result


def save_generation_config(
    model_id_or_path: str | os.PathLike, save_path: str | os.PathLike
) -> None:
    """Save generation_config.json from source model to artifact path.

    Skips if not found.
    """
    config: GenerationConfig
    unused_kwargs: dict[str, Any]
    try:
        config, unused_kwargs = GenerationConfig.from_pretrained(  # type: ignore[misc]
            str(model_id_or_path), return_unused_kwargs=True
        )
    except (OSError, json.JSONDecodeError):
        return

    if unused_kwargs:
        logger.warning(
            "unrecognized fields in generation_config.json will not be saved to artifact: %s",
            unused_kwargs,
        )

    config.save_pretrained(str(save_path))
