import dataclasses
from dataclasses import dataclass, replace
from enum import Enum
import logging
import os
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, TypeVar, Union

from pydantic import BaseModel, model_serializer, model_validator
from typing_extensions import Self
import yaml

from furiosa_llm.metadata import ModelMetadata
from furiosa_llm.metadata.config_types import AttentionBucket
from furiosa_llm.metadata.hf_utils import _estimate_per_layer_param_count_billions
from furiosa_llm.parallelize.layer_range import (
    Embedding,
    LayerRange,
    OutputHeadAndPostProcess,
    TransformerBlock,
)
from furiosa_llm.parallelize.mppp.config import Device as MpppDevice
from furiosa_llm.parallelize.pipeline.next_gen import Stage
from furiosa_llm.utils import get_logger_with_tz

logger = get_logger_with_tz(logging.getLogger(__name__))


class PipelineMode(Enum):
    UNKNOWN = "unknown"
    LLM_PREFILL = "prefill"
    LLM_DECODE = "decode"

    def __str__(self):
        return self.value

    @classmethod
    def _missing_(cls, value):
        if value is None:
            return cls.UNKNOWN


# FIXME: CompilerConfigContext must provide more generic way to match between target node and compiler config.
# the following implementation is MLPerf-specific (mostly targets gptj and bert) and should be fixed in the future.
@dataclass
class CompilerConfigContext:
    model_metadata: ModelMetadata
    num_pe_per_chip: int = 8
    num_chip: int = 1
    block_idx: Optional[int] = None
    merge_all_blocks: bool = False
    num_blocks_per_graph: Union[int, Sequence[int]] = 1
    embedding_as_single_block: bool = False
    bucket: Optional[AttentionBucket] = None
    phase: Optional[PipelineMode] = None
    compiler_config_overrides: Optional[Mapping] = None
    enable_bf16_partial_sum_for_split: bool = True
    use_activation_dq_if_possible: bool = False

    def load_config(self) -> Mapping:
        raise ValueError("`load_config` without layer range is not supported anymore.")

    def load_config_with_layer_range(self, layer_range: LayerRange) -> Dict[str, Any]:
        from furiosa.native_common.compiler import (
            create_default_compiler_config,
            create_llm_compiler_config_with_layer_range,
        )

        if self.bucket is None:
            raise ValueError("`bucket` is needed for compiler config generation with layer range")

        bucket = self.bucket
        seq_len = None
        if layer_range.is_tokenwise(self.model_metadata.num_hidden_layers):
            logger.info(f"Bucket {self.bucket} is given for tokenwise-kernel compilation.")
            seq_len = self.bucket.input_ids_size * self.bucket.batch_size
            if seq_len < 4:
                bucket = AttentionBucket(seq_len, 128, 128 - 1)
                logger.info(f"will be using bucket {bucket} for seq_len <4")
            elif not (self.bucket.is_prefill and self.bucket.batch_size == 1):
                raise ValueError(
                    f"currently prefill bucket with batch=1 must be specified for tokenwise-kernel compilation, "
                    f"however the provided bucket was {self.bucket} on {layer_range}"
                )

        if (
            layer_range.is_tokenwise(self.model_metadata.num_hidden_layers)
            and not self.bucket.is_prefill
        ):
            raise ValueError(
                f"currently prefill bucket must be specified for tokenwise-kernel compilation, "
                f"however the provided bucket was {self.bucket} on {layer_range}"
            )

        use_activation_dq = self.use_activation_dq_if_possible
        if (
            not (
                layer_range.is_inter_tr_block_tokenwise
                or layer_range.is_last_tr_block_projection_to_output_head(
                    self.model_metadata.num_hidden_layers
                )
            )
            and self.use_activation_dq_if_possible
        ):
            logger.info(
                f"`use_activation_dq_if_possible` is set to True, but the activation dq on {layer_range} is not valid "
                "- setting `enable_deepseek_fp8` to False in the compiler config generation.",
            )
            use_activation_dq = False
        try:
            approx_per_layer_params = _estimate_per_layer_param_count_billions(
                self.model_metadata.hf_configs
            )
            logger.info(
                f"Creating compiler config\n"
                f"Model type: {self.model_metadata.model_type}, "
                f"task: {self.model_metadata.task}, "
                f"~{approx_per_layer_params:.4f}B per-layer params\n"
                f"Layer range details: {layer_range}\n"
                f"Bucket configuration: {self.bucket}\n"
                f"Using activation dequantization: {use_activation_dq}"
            )
            config_yaml = create_llm_compiler_config_with_layer_range(
                self.model_metadata.model_type,
                self.model_metadata.task,
                approx_per_layer_params,
                self.num_chip,
                self.num_pe_per_chip,
                bucket.batch_size,
                bucket.attention_size,
                bucket.input_ids_size,
                layer_range,
                self.enable_bf16_partial_sum_for_split,
                # TODO: put True if valid length tensor is used.
                False,
                False,
                use_activation_dq,
            )
        except Exception as e:
            logger.warning(
                f"Failed to create compiler config with {e}; using default compiler config."
            )
            config_yaml = create_default_compiler_config()

        config = yaml.safe_load(config_yaml)

        if layer_range.is_embedding or layer_range.is_attention:
            # NOTE: The `enable_deepseek_fp8` option applies only to intermediate activations
            # from the preceding attention kernel. It should have no effect on other kernels.
            # However, the compiler currently requires `enable_deepseek_fp8=False` for
            # non-intermediate tokenwise kernels or attention kernels.
            # This can be removed later when the compiler supports more flexible configuration.
            config["enable_deepseek_fp8"] = False

            if (
                seq_len in [16, 32, 64]
                and layer_range.is_embedding
                and self.use_activation_dq_if_possible
            ):
                # For tokenwise kernels with seq_len of 16, 32, or 64,
                # "enable_deepseek_fp8" must be set to True to ensure proper tactic search.
                # NOTE: It is counterintuitive that this option affects the first tokenwise kernel
                # (Embedding~QKV-proj), which is unrelated to activation. This should be addressed in the compiler.
                config["enable_deepseek_fp8"] = True

        return self._postprocess_compiler_config(config)

    def _postprocess_compiler_config(self, compiler_config: Mapping[str, Any]) -> Dict[str, Any]:
        # TODO: move to compiler-config-generator
        config = {
            **compiler_config,
            "insert_wait_by_estimation": False,
            "profile_sync": False,
            "enable_tuc_profile": False,
        }

        if self.compiler_config_overrides:
            config = {**config, **self.compiler_config_overrides}

        return config

    def __hash__(self):
        return hash((getattr(self, field.name) for field in dataclasses.fields(self)))

    def derive_for_stage(
        self, stage: Stage, stage_device: MpppDevice, stage_bucket: AttentionBucket
    ) -> Self:
        return replace(
            self,
            num_chip=stage_device.num_chip,
            num_pe_per_chip=stage_device.num_pe_per_chip,
            bucket=stage_bucket,
        )


class DramShapeKind(Enum):
    FREE = "Free"
    BROADCAST = "Broadcast"
    FIXED = "Fixed"


class AxisTagLabel(BaseModel):
    inner: str


class LabelStride(BaseModel):
    label: AxisTagLabel
    stride: int


# Type to represent field in `AxisTag` enum. Only needed types are defined now.
class AxisTagKind(Enum):
    LabelStride = "LabelStride"
    Broadcast = "Broadcast"


class AxisTag(BaseModel):
    kind: AxisTagKind
    label_stride: Optional[LabelStride] = None

    @model_serializer
    def serialize_model(self):
        # Workaround to make serialization result (yaml) same as counterpart in npu-tools.
        if self.kind is AxisTagKind.Broadcast:
            assert self.label_stride is None
            return "Broadcast"
        elif self.kind is AxisTagKind.LabelStride:
            assert self.label_stride
            return {"LabelStride": self.label_stride.model_dump()}
        else:
            raise ValueError(f"Unknown AxisTag kind: {self.kind}")

    @model_validator(mode="before")
    @classmethod
    def validate_model_before(cls, data: Any):
        if isinstance(data, dict) and "LabelStride" in data:
            data = {"kind": AxisTagKind.LabelStride, "label_stride": data["LabelStride"]}
        elif isinstance(data, str) and data == AxisTagKind.Broadcast.value:
            data = {"kind": AxisTagKind.Broadcast}
        return data

    @model_validator(mode="after")
    def validate_model_after(self) -> Self:
        if self.kind is AxisTagKind.Broadcast:
            if self.label_stride:
                raise ValueError("`label_stride` should not be set for Broadcast kind")
        elif self.kind is AxisTagKind.LabelStride:
            if not self.label_stride:
                raise ValueError("`label_stride` should be set for LabelStride kind")
        else:
            raise ValueError(f"Unknown AxisTag kind: {self.kind}")
        return self

    @classmethod
    def broadcast(cls) -> Self:
        return cls(kind=AxisTagKind.Broadcast)


class GenericAxisTagSize(BaseModel):
    tag: AxisTag
    size: int


class TaggedShape(BaseModel):
    inner: List[GenericAxisTagSize]


class AxisTagSizeStride(BaseModel):
    tag: AxisTag
    size: int
    stride: int


class StridedShape(BaseModel):
    axes: List[AxisTagSizeStride]
    offset: int = 0


class DramShapeGuide(BaseModel):
    kind: DramShapeKind
    inter_chip_axes: Optional[TaggedShape] = None
    intra_chip_axes: Optional[StridedShape] = None

    @model_validator(mode="before")
    @classmethod
    def validate_model(cls, data: Any):
        # Workaround to make serialization result (yaml) same as counterpart in npu-tools.
        if isinstance(data, str) and data in (e.value for e in DramShapeKind):
            return {"kind": DramShapeKind(data)}
        elif isinstance(data, dict) and DramShapeKind.FIXED.value in data:
            assert len(data) == 1
            kind = next(iter(data.keys()))
            return {"kind": kind, **data[kind]}
        else:
            return data

    @model_serializer
    def serialize_model(self):
        # For consistency with `DramShapeGuide` in npu-tools, which is an enum with fields.
        if self.kind is DramShapeKind.FIXED:
            assert self.inter_chip_axes and self.intra_chip_axes
            return {
                self.kind.value: {
                    "inter_chip_axes": self.inter_chip_axes.model_dump(),
                    "intra_chip_axes": self.intra_chip_axes.model_dump(),
                }
            }
        else:
            return self.kind.value

    @classmethod
    def free(cls) -> Self:
        return cls(kind=DramShapeKind.FREE)

    @classmethod
    def broadcast(cls) -> Self:
        return cls(kind=DramShapeKind.BROADCAST)


class SparseRatio(BaseModel):
    mean: float
    sigma: float
    sorted: bool


class ValidLengthInfo(BaseModel):
    target: int
    valid_length: int
    valid_length_axis: int
    sparse_key_axis: int
    sparse_ratio: SparseRatio


# NOTE: This is ported version of `GraphMetadata` in npu-tools.
# But only fields and types that are actually used are ported.
# Keep this same with one in npu-tools.
class GraphMetadata(BaseModel):
    valid_length: Optional[ValidLengthInfo]
    input_dram_shape_guide: List[DramShapeGuide]
    output_dram_shape_guide: List[DramShapeGuide]

    def to_yaml(self) -> str:
        return yaml.dump(self.model_dump(), sort_keys=False)

    def dump_yaml(self, path: Union[str, os.PathLike]) -> None:
        with open(path, "w") as f:
            f.write(self.to_yaml())

    @classmethod
    def from_yaml(cls, data: str) -> Self:
        return cls.model_validate(yaml.safe_load(data))

    @classmethod
    def load_yaml(cls, path: Union[str, os.PathLike]) -> Self:
        with open(path, "r") as f:
            data = f.read()
        return cls.from_yaml(data)


T = TypeVar("T")


def group_consecutive_names(names: Sequence[T]) -> List[Tuple[T, int]]:
    """
    Group consecutive identical names and count their occurrences.

    Takes a sequence of names and returns a list of tuples where each tuple
    contains a unique name and the number of consecutive times it appears.

    Args:
        names: A sequence of string names to be grouped

    Returns:
        A list of tuples, each containing (name, consecutive_count)

    Example:
        >>> group_consecutive_names(['a', 'a', 'b', 'b', 'b', 'a'])
        [('a', 2), ('b', 3), ('a', 1)]
    """
    cur_name = None
    cur_cnt = 0

    if not names:
        return []

    grouped = []
    for name in names:
        if name == cur_name or cur_name is None:
            cur_cnt += 1
        else:
            grouped.append((cur_name, cur_cnt))
            cur_cnt = 1
        cur_name = name

    assert cur_name is not None
    grouped.append((cur_name, cur_cnt))

    return grouped


def generate_layer_range_from_compiler_config_context(
    model_metadata: ModelMetadata,
    num_blocks_per_graph: Union[int, Sequence[int]],
    embedding_as_single_block: bool,
    graph_idx: int,
) -> LayerRange:
    # Consider only transformer blockwise partitioning here.
    all_blocks = []

    # Add embedding layer and 1st transformer layer.
    if embedding_as_single_block:
        all_blocks.extend([LayerRange(start=Embedding()), LayerRange(start=TransformerBlock(0))])
    else:
        all_blocks.append(LayerRange(start=Embedding(), end=TransformerBlock(0)))

    # Add mid blocks.
    for layer_idx in range(1, model_metadata.num_hidden_layers - 1):
        all_blocks.append(LayerRange(start=TransformerBlock(layer_idx)))

    if model_metadata.num_hidden_layers == 1:
        # If there's just one single transformer layer, then merge postprocess into first tr layer.
        final_block = all_blocks.pop()
        all_blocks.append(
            LayerRange(
                start=final_block.start,
                end=OutputHeadAndPostProcess(),
            )
        )
    else:
        all_blocks.append(
            LayerRange(
                start=TransformerBlock(model_metadata.num_hidden_layers - 1),
                end=OutputHeadAndPostProcess(),
            )
        )

    if isinstance(num_blocks_per_graph, int):
        start_block_idx = graph_idx * num_blocks_per_graph
        end_block_idx = start_block_idx + num_blocks_per_graph
    else:
        start_block_idx = sum(num_blocks_per_graph[:graph_idx])
        end_block_idx = start_block_idx + num_blocks_per_graph[graph_idx]

    end_block_layer_range = all_blocks[end_block_idx - 1]

    return LayerRange(
        start=all_blocks[start_block_idx].start,
        end=(
            end_block_layer_range.end
            if end_block_layer_range.end is not None
            else end_block_layer_range.start
        ),
    )
