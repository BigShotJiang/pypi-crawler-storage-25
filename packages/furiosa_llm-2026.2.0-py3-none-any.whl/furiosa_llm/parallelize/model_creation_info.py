from dataclasses import dataclass
from typing import Optional

import torch

from furiosa_llm.metadata import ModelMetadata


@dataclass(frozen=True)
class ModelCreationInfo:
    metadata: ModelMetadata
    random_weight_model: bool
    seed: Optional[int] = None

    def instantiate_model(self) -> torch.nn.Module:
        if self.random_weight_model:
            return self.metadata.random_weight_model()
        else:
            return self.metadata.pretrained_model()

    def is_hashable(self) -> bool:
        return not self.random_weight_model or self.seed is not None
