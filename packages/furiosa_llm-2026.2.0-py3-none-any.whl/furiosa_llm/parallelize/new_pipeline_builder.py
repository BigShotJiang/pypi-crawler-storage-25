from collections import defaultdict
import copy
import dataclasses
from dataclasses import dataclass, field
from itertools import chain
import logging
import operator
import os
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Set, Tuple, Union

from furiosa_torch_ext.torch_ext import SIDE_EFFECT_OPS, preprocess
import ray
from ray.actor import ActorHandle
from ray.exceptions import RayError
import torch
from torch._guards import detect_fake_mode
from torch._subclasses.fake_tensor import FakeTensorMode
from torch.fx import Graph, GraphModule, Node
from torch.fx.node import _side_effectful_functions
from tqdm import tqdm
from typing_extensions import TypeAlias

from furiosa_llm.metadata.config_types import AttentionBucket, LLMPartitioningConfig
from furiosa_llm.metadata.metadata import ModelMetadata
from furiosa_llm.parallelize.block_slicer import (
    PartitionInfo,
    mark_color_to_node_meta,
    remove_marker_nodes,
)
from furiosa_llm.parallelize.compiler_config import CompilerConfigContext
from furiosa_llm.parallelize.export.graphmodule import deserialize_gm
from furiosa_llm.parallelize.export.tensor import ParamfileFormat, ParamFileInfo, ParamFileMetadata
from furiosa_llm.parallelize.graph_partitioner import (
    GraphPartitioner,
    PartitionComposer,
    get_graph_partitioner,
)
from furiosa_llm.parallelize.layer_range import LayerRange, TransformerBlock
from furiosa_llm.parallelize.model_creation_info import ModelCreationInfo
from furiosa_llm.parallelize.model_rewriter.api import ModelRewriter
import furiosa_llm.parallelize.model_rewriter.mppp_config as mrw
from furiosa_llm.parallelize.model_rewriter.mppp_config import DeviceId as MrwDeviceId
from furiosa_llm.parallelize.mppp.api import Mppp
from furiosa_llm.parallelize.mppp.config import Device as MpppDevice
from furiosa_llm.parallelize.mppp.config import MpppConfig
from furiosa_llm.parallelize.node_meta import (
    get_color,
    get_device_id,
    get_spec,
    get_unsharded_tensor_meta,
    set_partition_info,
)
from furiosa_llm.parallelize.pipeline.builder.api import (
    _mark_constants_to_be_embedded,
    apply_pre_parallelization_llm_graph_optimizations,
)
from furiosa_llm.parallelize.pipeline.builder.arg_types import LogitsSliceConfig
from furiosa_llm.parallelize.pipeline.builder.converter import (
    DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
    SUBMOD_PREFIX,
    GraphModuleConverter,
    _add_hash_for_sub_gms,
    _add_valid_length_nodes,
    _propagate_device_id,
    generate_graph_metadata,
)
from furiosa_llm.parallelize.pipeline.builder.single_device_comm_op_converter import (
    convert_to_single_device_comm_ops,
)
from furiosa_llm.parallelize.pipeline.builder.transform import partition_gm
from furiosa_llm.parallelize.pipeline.builder.utils import get_constant_tensors_with_original_name
import furiosa_llm.parallelize.pipeline.types as legacy_pipe
from furiosa_llm.parallelize.pipeline_build_configurer import PipelineBuildConfigGenerator
from furiosa_llm.parallelize.ray_utils import LogActor, drain_logs, setup_logging
from furiosa_llm.parallelize.trace import get_aten_graph_with_metadata
from furiosa_llm.parallelize.utils import (
    get_fake_mode,
    get_list_with_no_dup_with_order_preserved,
    is_aten_op,
    is_custom_op,
    propagate_shape_info_without_real_computation,
)
from furiosa_llm.utils import zip_equal

from .pipeline import next_gen
from .pipeline.next_gen import (
    AttentionStage,
    BlobId,
    DeviceId,
    ParamFileId,
    ParamInfo,
    ParamValue,
    Pipeline,
    Stage,
    StageId,
    StageKind,
    StageTensorId,
    Symbol,
    SymbolVal,
    Task,
    TaskKind,
    TensorId,
    TensorInfo,
    TensorOrigin,
)

PartitionedGraphModule: TypeAlias = GraphModule
TaskId: TypeAlias = Tuple[StageId, Tuple[SymbolVal, ...]]

logger = logging.getLogger(__file__)


# TODO: Redesign this type.
@dataclass
class LocalPipeline(legacy_pipe.Pipeline):
    supertask_id_to_partition_info: Dict[legacy_pipe.SuperTaskId, PartitionInfo] = field(
        default_factory=dict
    )
    intermediate_tensor_id_to_global_id: Dict[str, Optional[str]] = field(default_factory=dict)

    def is_intermediate_tensor(self, tensor_id: str) -> bool:
        """Check if the given tensor is an intermediate tensor."""
        return bool(
            self.tensor_producer_supertasks.get(legacy_pipe.NameAfterMakeFx(tensor_id), None)
        )


def _get_torch_device(
    node: Node,
    device_id_map: Mapping[MrwDeviceId, legacy_pipe.DeviceId],
    devices: Mapping[legacy_pipe.DeviceId, MpppDevice],
) -> torch.device:
    device_id = get_device_id(node)
    if not isinstance(device_id, MrwDeviceId):
        raise ValueError(f"Expected single DeviceId, but got {device_id}")
    return devices[device_id_map[device_id]].to_torch_device()


# TODO: don't return device id mapping and store DeviceId in nodes' metadata instead.
def parallelize_graphmodule(
    gm: GraphModule,
    mppp_config: MpppConfig,
    example_args: Sequence,
) -> Tuple[GraphModule, Dict[mrw.DeviceId, legacy_pipe.DeviceId]]:
    model_rewriter = ModelRewriter(gm, mppp_config)
    rewritten_model = model_rewriter.rewrite(
        example_args,
    )

    devices = mppp_config.devices
    fake_mode = detect_fake_mode() or FakeTensorMode(allow_non_fake_inputs=True)

    def is_replicated(node: Node) -> bool:
        spec = get_spec(node)
        assert isinstance(spec, mrw.ShardSpec)
        return all(p.is_replicate() for p in spec.placements)

    if not all(is_replicated(node) for node in rewritten_model.graph.find_nodes(op="placeholder")):
        raise NotImplementedError(
            "Partitioning of non-replicated inputs is not supported yet. "
            "All inputs must be replicated across all devices."
        )

    with fake_mode:
        example_args_for_rewritten_model = tuple(
            torch.zeros(
                get_unsharded_tensor_meta(node).shape,  # type: ignore [union-attr]
                dtype=get_unsharded_tensor_meta(node).dtype,  # type: ignore [union-attr]
                device=_get_torch_device(node, model_rewriter.get_device_id_map(), devices),
            )
            for node in rewritten_model.graph.find_nodes(op="placeholder")
        )
    propagate_shape_info_without_real_computation(rewritten_model, example_args_for_rewritten_model)

    convert_to_single_device_comm_ops(rewritten_model)

    device_id_map = model_rewriter.get_device_id_map()

    return rewritten_model, device_id_map


def _do_preprocess_for_compiler(
    gm: GraphModule,
) -> None:
    for node in gm.graph.nodes:
        if node.op != "call_module":
            continue
        assert isinstance(node.target, str)
        submod = getattr(gm, node.target)
        tensor_metas = (arg.meta["tensor_meta"] for arg in node.args)  # type: ignore
        fake_mode = detect_fake_mode() or FakeTensorMode(allow_non_fake_inputs=True)
        with fake_mode:
            example_input = tuple(
                torch.zeros(
                    tensor_meta.shape,
                    dtype=tensor_meta.dtype,
                    device="cpu",
                )
                for tensor_meta in tensor_metas
            )
        preprocessed = preprocess(submod, example_input)

        # Move placeholder metadata
        for original_ph_node, preprocessed_ph_node in zip_equal(
            submod.graph.find_nodes(op="placeholder"),
            preprocessed.graph.find_nodes(op="placeholder"),
        ):
            preprocessed_ph_node.meta = original_ph_node.meta.copy()
            if hasattr(original_ph_node, "_dynamo_source"):
                preprocessed_ph_node._dynamo_source = copy.deepcopy(original_ph_node._dynamo_source)
        setattr(gm, node.target, preprocessed)


def is_aten_graph(graph: Graph) -> bool:
    return all(
        node.op in ("placeholder", "get_attr", "output")
        or (
            node.op == "call_function"
            and (
                is_aten_op(node.target)
                or is_custom_op(node.target)
                or node.target == operator.getitem
            )
        )
        for node in graph.nodes
    )


def _capture_placeholder_dynamo_sources(gm: GraphModule) -> List[Dict[str, Any]]:
    placeholder_infos: List[Dict[str, Any]] = []
    for idx, node in enumerate(gm.graph.nodes):
        if node.op != "placeholder":
            continue
        source = getattr(node, "_dynamo_source", None)
        placeholder_infos.append(
            {
                "index": idx,
                "name": node.name,
                "target": node.target,
                "original_name": node.meta.get("original_name"),
                "source": copy.deepcopy(source) if source is not None else None,
            }
        )
    return placeholder_infos


def _restore_placeholder_dynamo_sources(
    gm: GraphModule,
    placeholder_infos: Sequence[Dict[str, Any]],
) -> None:
    if not placeholder_infos:
        return

    name_map: Dict[str, Optional[Dict[str, Any]]] = {}
    target_map: Dict[Any, Optional[Dict[str, Any]]] = {}
    origin_map: Dict[Any, Optional[Dict[str, Any]]] = {}

    for info in placeholder_infos:
        source = info["source"]
        if source is None:
            continue
        name_map.setdefault(info["name"], info)
        target_map.setdefault(info["target"], info)
        original_name = info["original_name"]
        if original_name is not None:
            origin_map.setdefault(original_name, info)

    used_indices: Set[int] = set()

    def take(info: Optional[Dict[str, Any]]) -> Optional[Any]:
        if info is None:
            return None
        idx = info["index"]
        if idx in used_indices or info["source"] is None:
            return None
        used_indices.add(idx)
        return copy.deepcopy(info["source"])

    for node in gm.graph.nodes:
        if node.op != "placeholder":
            continue
        if getattr(node, "_dynamo_source", None) is not None:
            continue

        entry = name_map.get(node.name)
        source = take(entry)
        if node.name in name_map:
            name_map[node.name] = None

        if source is None:
            entry = target_map.get(node.target)
            source = take(entry)
            if node.target in target_map:
                target_map[node.target] = None

        if source is None:
            original_name = node.meta.get("original_name")
            if original_name is not None:
                entry = origin_map.get(original_name)
                source = take(entry)
                if original_name in origin_map:
                    origin_map[original_name] = None

        if source is not None:
            node._dynamo_source = source


def parallelize_and_partition_graphmodule(
    gm: GraphModule,
    mppp_config: MpppConfig,
    *,
    partition_marker: Optional[GraphPartitioner],
    embed_all_constants_into_graph: bool,
    add_valid_length_input_tensor: bool,
    max_embeddable_constant_size: int,
    do_preprocess_for_compiler: bool = False,
) -> Tuple[PartitionedGraphModule, Dict[mrw.DeviceId, legacy_pipe.DeviceId]]:
    placeholder_infos = _capture_placeholder_dynamo_sources(gm)

    # What we want to do is to prevent only side-effect ops with no user from being eliminated by dead code elimination.
    # But union of ``_side_effectful_functions`` and ``SIDE_EFFECT_OPS`` contains only some of those side-effect ops.
    # TODO: Find a way to get a list of all side-effect aten ops.
    for node in gm.graph.nodes:
        if (
            node.op != "output"
            and len(node.users) == 0
            and node.target not in _side_effectful_functions.union(SIDE_EFFECT_OPS)
        ):
            logger.warning(
                f"Node with no users found, this might means meaningful nodes can disappear during postprocess: {node}"
            )
    if not is_aten_graph(gm.graph):
        raise ValueError("The input graph should be in ATen IR level.")

    # mark some tensor constants (get_attr nodes) to be embedded in FX graph as it is
    # (instead of converting them as placeholders in future stages).
    _mark_constants_to_be_embedded(gm)

    # NOTE: add partition id info before graph transformations because those transformations
    # might make it hard to find block boundaries.
    if partition_marker:
        node_to_partition_id, partition_infos = partition_marker.partition_gm(gm)

        node_name_to_node = {node.name: node for node in gm.graph.nodes}

        # Add partition id information for nodes.
        mark_color_to_node_meta(
            {
                node_name_to_node[node_name]: partition_id
                for node_name, partition_id in node_to_partition_id.items()
            }
        )
    else:
        partition_infos = None

    # All marker nodes should be removed before model rewriting stage.
    remove_marker_nodes(gm)

    fake_mode = get_fake_mode(chain(gm.parameters(), gm.buffers()))
    fake_args_for_gm = tuple(
        fake_mode.from_tensor(node.meta["val"])
        for node in gm.graph.nodes
        if node.op == "placeholder"
    )

    parallelized_gm, device_id_map = parallelize_graphmodule(
        gm,
        mppp_config,
        fake_args_for_gm,
    )

    gm = partition_gm(parallelized_gm, SUBMOD_PREFIX, True, bool(partition_marker))

    # Add hash value for each sub GraphModule.
    _add_hash_for_sub_gms(gm)

    GraphModuleConverter._embed_get_attr_nodes_into_submodules(
        gm,
        embed_all_constants_into_graph,
        max_embeddable_constant_size=max_embeddable_constant_size,
    )

    if partition_infos:
        for node in gm.graph.nodes:
            if node.op != "call_module":
                continue
            partition_ids = get_color(node)
            assert partition_ids and len(partition_ids) == 1

            set_partition_info(node, partition_infos[partition_ids[0]])

    if add_valid_length_input_tensor:
        _add_valid_length_nodes(gm)

    _propagate_device_id(gm)

    if do_preprocess_for_compiler:
        _do_preprocess_for_compiler(gm)

    _restore_placeholder_dynamo_sources(gm, placeholder_infos)

    return gm, device_id_map


@dataclass
class SparseSelectConfig:
    version: str
    padding_block_idx: int


def build_partitioned_graphmodule(
    model: ModelCreationInfo,
    devices: Sequence[MpppDevice],
    example_args: Sequence,
    example_kwargs: Mapping[str, Any],
    mppp_or_mppp_config: Union[MpppConfig, Mppp],
    # TODO: make this arg optional.
    param_file_metadata: Union[ParamFileMetadata, ParamFileInfo],
    *,
    input_names: Optional[Sequence[str]] = None,
    output_names: Optional[Sequence[str]] = None,
    # LLM partitioning config
    partitioning_config: Optional[LLMPartitioningConfig] = None,
    # Graph optimization options for LLM
    logits_slice_config: Optional[LogitsSliceConfig] = None,
    padding_block_idx: Optional[int] = None,
    add_valid_length_input_tensor: bool = False,
    # General graph transformation options
    embed_all_constants_into_graph: bool = False,
    max_embeddable_constant_size: int = DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
    # Other options
    cache_dir: Optional[Path] = None,
) -> Tuple[PartitionedGraphModule, MpppConfig, Dict[mrw.DeviceId, legacy_pipe.DeviceId]]:
    if partitioning_config:
        partition_marker = get_graph_partitioner(
            embedding_layer_as_single_partition=partitioning_config.embedding_layer_as_single_building_block,
            use_module_marker=partitioning_config.use_module_marker,
        )

        partition_marker = PartitionComposer(
            partition_marker,
            num_sub_partitions_per_partition=partitioning_config.num_building_blocks_per_partition,
        )
        module_mark_config = partition_marker.get_module_mark_config()
    else:
        partition_marker = None
        module_mark_config = None

    if isinstance(param_file_metadata, ParamFileInfo):
        param_file_metadata = ParamFileMetadata.load(
            param_file_metadata.path, param_file_metadata.format
        )

    aten_gm_with_metadata = get_aten_graph_with_metadata(
        model,
        example_args,
        example_kwargs,
        input_names=input_names,
        output_names=output_names,
        cache_dir=cache_dir,
        param_file_metadata=param_file_metadata,
        module_mark_config=module_mark_config,
    )[0]

    if padding_block_idx is not None or logits_slice_config:
        apply_pre_parallelization_llm_graph_optimizations(
            aten_gm_with_metadata,
            padding_block_idx,
            logits_slice_config,
            model.metadata.seq_dim_in_logits if isinstance(model, ModelCreationInfo) else None,
        )

    if isinstance(mppp_or_mppp_config, Mppp):
        mppp_config = mppp_or_mppp_config.gen_config(
            model,
            model.metadata.config,
            devices,
            example_args,
            example_kwargs,
            graph_module=aten_gm_with_metadata,
        )
    else:
        mppp_config = mppp_or_mppp_config

    partitioned_gm, device_id_map = parallelize_and_partition_graphmodule(
        aten_gm_with_metadata,
        mppp_config,
        partition_marker=partition_marker,
        embed_all_constants_into_graph=embed_all_constants_into_graph,
        add_valid_length_input_tensor=add_valid_length_input_tensor,
        max_embeddable_constant_size=max_embeddable_constant_size,
        do_preprocess_for_compiler=False,
    )

    return partitioned_gm, mppp_config, device_id_map


def convert_partitioned_gm_to_local_pipeline(
    gm: PartitionedGraphModule,
    pipeline_name: str,
    # TODO: merge `device_id_map` into `devices`.
    devices: Mapping[legacy_pipe.DeviceId, MpppDevice],
    device_id_map: Mapping[mrw.DeviceId, legacy_pipe.DeviceId],
    existing_param_file_metadata: Optional[ParamFileMetadata],
    additional_param_file_info: Optional[ParamFileInfo],
    original_model_state_dict: Mapping[str, torch.Tensor],
    cache_dir: Optional[os.PathLike] = None,
) -> LocalPipeline:
    """Convert the given GraphModule to a serializable form."""

    gm_converter = GraphModuleConverter(
        gm,
        devices,
        device_id_map,
    )

    pipeline = gm_converter.convert(
        pipeline_name,
        existing_param_file_metadata,
        legacy_pipe.SuperTaskKind.FX,
        # dummy compiler config context
        CompilerConfigContext(None),  # type: ignore[arg-type]
        additional_param_file_info,
        original_model_state_dict,
        cache_dir=cache_dir,
    )

    return LocalPipeline(
        **{field.name: getattr(pipeline, field.name) for field in dataclasses.fields(pipeline)},
        supertask_id_to_partition_info=gm_converter.supertask_id_to_partition_info,
        intermediate_tensor_id_to_global_id=gm_converter.intermediate_tensor_id_to_global_id,
    )


def _get_additional_param_file_info(
    pipeline_name: str,
    root_dir: Path,
) -> ParamFileInfo:
    # TODO: find better way to generate unique file names.
    cnt = 0
    while os.path.exists(root_dir / f"add_const_file-{pipeline_name}-{cnt}.safetensors"):
        cnt += 1
    return ParamFileInfo(
        path=os.path.join(root_dir, f"add_const_file-{pipeline_name}-{cnt}.safetensors"),
        format=ParamfileFormat.SAFETENSORS,
    )


def build_local_pipeline(
    pipeline_name: str,
    model: ModelCreationInfo,
    devices: Sequence[MpppDevice],
    example_args: Sequence,
    example_kwargs: Mapping[str, Any],
    mppp_or_mppp_config: Union[MpppConfig, Mppp],
    # TODO: make this arg optional.
    param_file_metadata: Union[ParamFileMetadata, ParamFileInfo],
    *,
    input_names: Optional[Sequence[str]] = None,
    output_names: Optional[Sequence[str]] = None,
    # LLM partitioning config
    partitioning_config: Optional[LLMPartitioningConfig] = None,
    # Graph optimization options for LLM
    logits_slice_config: Optional[LogitsSliceConfig] = None,
    padding_block_idx: Optional[int] = None,
    add_valid_length_input_tensor: bool = False,
    # General graph transformation options
    embed_all_constants_into_graph: bool = False,
    max_embeddable_constant_size: int = DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
    # Other options
    cache_dir: Optional[Path] = None,
    dir_for_param_files: Union[str, os.PathLike],
) -> LocalPipeline:
    if isinstance(param_file_metadata, ParamFileInfo):
        param_file_metadata = ParamFileMetadata.load(
            param_file_metadata.path, param_file_metadata.format
        )

    partitioned_gm, mppp_config, device_id_map = build_partitioned_graphmodule(
        model,
        devices,
        example_args,
        example_kwargs,
        mppp_or_mppp_config,
        param_file_metadata,
        input_names=input_names,
        output_names=output_names,
        partitioning_config=partitioning_config,
        logits_slice_config=logits_slice_config,
        padding_block_idx=padding_block_idx,
        add_valid_length_input_tensor=add_valid_length_input_tensor,
        embed_all_constants_into_graph=embed_all_constants_into_graph,
        max_embeddable_constant_size=max_embeddable_constant_size,
        cache_dir=cache_dir,
    )

    additional_param_file_info = _get_additional_param_file_info(
        pipeline_name,
        Path(dir_for_param_files),
    )

    original_model_state_dict = get_constant_tensors_with_original_name(
        partitioned_gm,
    )

    return convert_partitioned_gm_to_local_pipeline(
        partitioned_gm,
        pipeline_name,
        mppp_config.devices,
        device_id_map,
        param_file_metadata,
        additional_param_file_info,
        original_model_state_dict,
        cache_dir,
    )


def get_tensor_origin_from_origin_name(origin: str) -> TensorOrigin:
    """Get TensorOrigin from the original name of the tensor."""
    # Example: "kv_caches_0_1" -> TensorOrigin(name="kv_caches", indices=[0, 1])

    # FIXME: This might not work well for cases that original parameter name containes digits preceded by underscore.
    # Fix this to use inforamtion from GraphModule metadata.
    candidates = origin.split("_")

    final_key_idx = len(candidates) - 1
    while candidates[final_key_idx].isdigit():
        final_key_idx -= 1

    origin_key = "_".join(candidates[: final_key_idx + 1])
    indices: List[Union[int, str]] = [int(index) for index in candidates[final_key_idx + 1 :]]
    return TensorOrigin(
        name=origin_key,
        indices=indices,
    )


# TODO: better name?
class LocalToGlobalPipelineConverter:
    """A class that converts multiple `LocalPipeline`s into single (global) Pipeline."""

    def __init__(
        self,
    ):
        self._init_states()

    def _init_states(self) -> None:
        # Id generation related fields.
        self._next_stage_tensor_id = 0
        self._next_stage_id = 0
        self._next_task_tensor_id = 0
        self._param_file_info_to_id: Dict[ParamFileInfo, ParamFileId] = {}

        # Fields for the global pipeline.
        self.stages: Dict[StageId, Stage] = {}
        self.inputs: List[TensorId] = []
        self.outputs: List[TensorId] = []
        self.tensors: Dict[TensorId, Union[TensorInfo, ParamInfo]] = {}
        self.blobs: Dict[BlobId, Any] = {}
        self.param_files: Dict[ParamFileId, ParamFileInfo] = {}

        # Other metadata
        self.layer_range_to_stage_id: Dict[LayerRange, StageId] = {}
        self.global_to_stage_tensor_id: Dict[Optional[str], StageTensorId] = {}
        self.task_id_to_bucket: Dict[TaskId, AttentionBucket] = {}

    def _get_next_stage_tensor_id(self) -> StageTensorId:
        self._next_stage_tensor_id += 1
        return StageTensorId(f"stage_tensor_{self._next_stage_tensor_id - 1}")

    def _get_next_stage_id(self) -> StageId:
        self._next_stage_id += 1
        return StageId(f"stage_{self._next_stage_id - 1}")

    def _get_next_task_tensor_id(self) -> TensorId:
        self._next_task_tensor_id += 1
        return TensorId(f"task_tensor_{self._next_task_tensor_id - 1}")

    def _get_param_file_id(self, param_file_info: ParamFileInfo) -> ParamFileId:
        if (param_file_id := self._param_file_info_to_id.get(param_file_info)) is not None:
            return param_file_id

        param_file_id = ParamFileId(f"param_file_{len(self._param_file_info_to_id)}")
        self._param_file_info_to_id[param_file_info] = param_file_id
        self.param_files[param_file_id] = param_file_info
        return param_file_id

    def _generate_empty_stages(
        self,
        base_local_pipe: LocalPipeline,
        task_symbol_generator: Callable[[LayerRange], Tuple[StageKind, Sequence[Symbol]]],
    ) -> None:
        """Generate empty stages based on `base_local_pipe` and save it to `self.stages`."""

        base_local_pipe_tensor_id_to_stage_tensor_id: Dict[str, StageTensorId] = {}

        stage_id_to_supertask_id = {}

        for supertask_id, supertask in base_local_pipe.get_supertasks_in_topo_order():
            if supertask.is_input() or supertask.is_output():
                # Skip input and output supertasks.
                continue

            stage_id = self._get_next_stage_id()
            if isinstance(supertask, legacy_pipe.CompSuperTask):
                layer_range = base_local_pipe.supertask_id_to_partition_info[
                    supertask_id
                ].layer_range
                assert layer_range

                stage_kind, symbols = task_symbol_generator(layer_range)

                # Add stage input tensors.
                stage_input_tensors = []
                for input_ in supertask.inputs:
                    if base_local_pipe.tensor_producer_supertasks[input_]:
                        # Intermediate tensor. This should be stage input.
                        stage_tensor_id = base_local_pipe_tensor_id_to_stage_tensor_id[input_]
                        stage_input_tensors.append(stage_tensor_id)

                # Add stage output tensors.
                stage_output_tensors = []
                for output_ in supertask.outputs:
                    stage_tensor_id = self._get_next_stage_tensor_id()
                    base_local_pipe_tensor_id_to_stage_tensor_id[output_] = stage_tensor_id
                    stage_output_tensors.append(stage_tensor_id)
                    global_tensor_id = base_local_pipe.intermediate_tensor_id_to_global_id[output_]

                    assert global_tensor_id not in self.global_to_stage_tensor_id
                    self.global_to_stage_tensor_id[global_tensor_id] = stage_tensor_id

                if stage_kind is StageKind.ATTENTION:
                    new_stage: Stage = AttentionStage(
                        kind=stage_kind,
                        symbols=list(symbols),
                        inputs_from_prev_stages=stage_input_tensors,
                        outputs=stage_output_tensors,
                        device=DeviceId(supertask.device),
                        tasks={},
                        task_input_to_stage_input={},
                        metadata={},
                        # We assume sequence dimension is always 0 for now.
                        seq_dim=0,
                    )
                else:
                    new_stage = Stage(
                        kind=stage_kind,
                        symbols=list(symbols),
                        inputs_from_prev_stages=stage_input_tensors,
                        outputs=stage_output_tensors,
                        device=DeviceId(supertask.device),
                        tasks={},
                        task_input_to_stage_input={},
                        metadata={},
                    )
                stage_id_to_supertask_id[stage_id] = supertask_id
                assert (
                    layer_range not in self.layer_range_to_stage_id
                ), f"Layer range {layer_range} already exists."
                self.layer_range_to_stage_id[layer_range] = stage_id
            else:
                assert isinstance(supertask, legacy_pipe.CommSuperTask)
                assert supertask.kind in (
                    legacy_pipe.SuperTaskKind.SEND,
                    legacy_pipe.SuperTaskKind.RECV,
                )
                # TODO: handle comm supertasks.
                raise NotImplementedError("Communication supertasks are not supported yet.")

            self.stages[stage_id] = new_stage

    def _add_tensor_info(
        self,
        new_tensor_id: TensorId,
        local_tensor_id: legacy_pipe.NameAfterMakeFx,
        local_pipe: LocalPipeline,
    ) -> None:
        local_pipe_tensor_info = local_pipe.tensors[local_tensor_id]

        if tensor_slice_meta := local_pipe.metadata.tensor_slices.inputs.get(local_tensor_id):
            # Pipeline input tensor.
            origin = get_tensor_origin_from_origin_name(tensor_slice_meta.origin)
            self.inputs.append(new_tensor_id)
            tensor_info = TensorInfo(
                shape=local_pipe_tensor_info.shape,
                dtype=next_gen.Dtype(local_pipe_tensor_info.dtype),
                origin=origin,
            )
        elif tensor_slice_meta := local_pipe.metadata.tensor_slices.outputs.get(local_tensor_id):
            # Pipeline output tensor.
            origin = get_tensor_origin_from_origin_name(tensor_slice_meta.origin)
            self.outputs.append(new_tensor_id)
            tensor_info = TensorInfo(
                shape=local_pipe_tensor_info.shape,
                dtype=next_gen.Dtype(local_pipe_tensor_info.dtype),
                origin=origin,
            )
        elif isinstance(local_pipe_tensor_info, legacy_pipe.ParamInfo):
            # Constant tensor.
            param_file_info = local_pipe.param_files[local_pipe_tensor_info.value.param_file]
            new_param_file_id = self._get_param_file_id(param_file_info)

            tensor_info = ParamInfo(
                shape=local_pipe_tensor_info.shape,
                dtype=next_gen.Dtype(local_pipe_tensor_info.dtype),
                value=ParamValue(
                    param_file=new_param_file_id,
                    name=local_pipe_tensor_info.value.name,
                    name_in_graph=local_pipe_tensor_info.value.name_in_graph,
                ),
                origin=None,
            )
        else:
            # Intermediate tensor.
            tensor_info = TensorInfo(
                shape=local_pipe_tensor_info.shape,
                dtype=next_gen.Dtype(local_pipe_tensor_info.dtype),
                origin=None,
            )
        self.tensors[new_tensor_id] = tensor_info

    def _add_comp_task(
        self,
        local_pipe: LocalPipeline,
        local_supertask_id: legacy_pipe.SuperTaskId,
        local_pipe_tensor_id_to_new_tensor_id: Mapping[legacy_pipe.NameAfterMakeFx, TensorId],
        symbol_values: Tuple[SymbolVal, ...],
    ) -> None:
        local_task = local_pipe.supertasks[local_supertask_id]
        assert isinstance(
            local_task, legacy_pipe.CompSuperTask
        ), f"Expected CompSuperTask, but got {type(local_task)}"

        layer_range = local_pipe.supertask_id_to_partition_info[local_supertask_id].layer_range
        assert layer_range

        belonging_stage = self.stages[self.layer_range_to_stage_id[layer_range]]

        # Generate task inputs.
        task_inputs = []
        for input_ in local_task.inputs:
            new_tensor_id = local_pipe_tensor_id_to_new_tensor_id[input_]

            if new_tensor_id not in self.tensors:
                self._add_tensor_info(
                    new_tensor_id,
                    input_,
                    local_pipe,
                )
            if local_pipe.is_intermediate_tensor(input_):
                # For intermediate tensor, we need to add task input to stage input mapping.
                corresponding_stage_tensor_id = self.global_to_stage_tensor_id[
                    local_pipe.intermediate_tensor_id_to_global_id[input_]
                ]
                belonging_stage.task_input_to_stage_input[new_tensor_id] = (
                    corresponding_stage_tensor_id
                )

            task_inputs.append(new_tensor_id)

        # Generate task outputs.
        task_outputs = []
        if len(belonging_stage.outputs) != len(local_task.outputs):
            raise ValueError(
                f"Stage {belonging_stage} has {len(belonging_stage.outputs)} outputs, "
                f"but supertask {local_task} has {len(local_task.outputs)} outputs."
            )
        for output_ in local_task.outputs:
            task_tensor_id = local_pipe_tensor_id_to_new_tensor_id[output_]
            if task_tensor_id not in self.tensors:
                self._add_tensor_info(
                    task_tensor_id,
                    output_,
                    local_pipe,
                )
            task_outputs.append(task_tensor_id)

        # Add data blob
        assert local_task.data_blob
        blob_id = BlobId(local_task.data_blob)

        if (
            blob_id in self.blobs
            and self.blobs[blob_id] is not local_pipe.blobs[local_task.data_blob]
            and self.blobs[blob_id] != local_pipe.blobs[local_task.data_blob]
        ):
            raise ValueError(
                "Blob ID collision: Blobs with same blob ID, but different content exist in multiple local pipelines."
            )
        self.blobs[blob_id] = local_pipe.blobs[local_task.data_blob]

        # Create new task and insert it to the stage.
        metadata = {}
        if layer_range.is_attention:
            # TODO: obtain this information from model metadata.
            metadata["mask_dim"] = 3

        new_task = Task(
            kind=TaskKind.FX,
            inputs=task_inputs,
            outputs=task_outputs,
            data_blob=blob_id,
            metadata=metadata,
        )

        assert (
            symbol_values not in belonging_stage.tasks
        ), f"Symbol {symbol_values} already exists in stage {belonging_stage}."
        belonging_stage.tasks[symbol_values] = new_task

    def fill_tasks_into_stages(
        self,
        local_pipe: LocalPipeline,
        bucket: AttentionBucket,
        task_symbol_generator: Callable[
            [AttentionBucket, LayerRange], Optional[Tuple[SymbolVal, ...]]
        ],
    ) -> None:
        local_pipe_tensor_id_to_new_tensor_id: Mapping[legacy_pipe.NameAfterMakeFx, TensorId] = (
            defaultdict(lambda: self._get_next_task_tensor_id())
        )

        for supertask_id, supertask in local_pipe.get_supertasks_in_topo_order():
            if supertask.kind in (
                legacy_pipe.SuperTaskKind.INPUT,
                legacy_pipe.SuperTaskKind.OUTPUT,
            ):
                # Skip in/output supertasks.
                continue

            layer_range = local_pipe.supertask_id_to_partition_info[supertask_id].layer_range
            assert layer_range

            stage_id = self.layer_range_to_stage_id[layer_range]
            symbol_values = task_symbol_generator(bucket, layer_range)
            if symbol_values is None:
                # This task is not included in the global pipeline.
                continue

            assert (stage_id, symbol_values) not in self.task_id_to_bucket
            self.task_id_to_bucket[(stage_id, symbol_values)] = bucket

            local_task = local_pipe.supertasks[supertask_id]
            assert isinstance(
                local_task, legacy_pipe.CompSuperTask
            ), f"Expected CompSuperTask, but got {type(local_task)}"

            if isinstance(supertask, legacy_pipe.CompSuperTask):
                self._add_comp_task(
                    local_pipe,
                    supertask_id,
                    local_pipe_tensor_id_to_new_tensor_id,
                    symbol_values,
                )
            else:
                # TODO
                raise NotImplementedError("Communication Stage creation is not supported yet.")

    def convert(
        self,
        pipeline_name: str,
        local_pipelines: Mapping[AttentionBucket, LocalPipeline],
        build_config_generator: PipelineBuildConfigGenerator,
    ) -> Tuple[Pipeline, Dict[StageId, LayerRange], Dict[TaskId, AttentionBucket]]:
        """Convert multiple local pipelines into single (global) pipeline.

        This method consists of the following steps:
        1. Create empty stages without tasks based on the first local pipeline. There will be
            exactly one stage per supertask in the first local pipeline.
        2. Create tasks for each stage based on the local pipelines and insert them into proper stages.
            Each task exactly corresponds to different single supertask in the local pipelines, and
            the supertasks to be selected is determined by the `build_config_generator`.
        """

        sample_local_pipe = next(iter(local_pipelines.values()))
        assert isinstance(sample_local_pipe, LocalPipeline)

        # Create stages without tasks.
        self._generate_empty_stages(sample_local_pipe, build_config_generator.get_stage_info)

        if any(
            local_pipe.supertask_id_to_partition_info
            != sample_local_pipe.supertask_id_to_partition_info
            for local_pipe in local_pipelines.values()
        ):
            raise ValueError(
                "All local pipelines must have the same number of supertasks with same layer ranges for composition into global pipeline."
            )

        # Add check all local pipelines have same devices
        if any(
            local_pipe.devices != sample_local_pipe.devices
            for local_pipe in local_pipelines.values()
        ):
            raise ValueError(
                "All local pipelines must have the same devices for composition into global pipeline."
            )
        new_devices = {
            DeviceId(device_id): next_gen.Device(device)
            for device_id, device in sample_local_pipe.devices.items()
        }

        # fill needed tasks into stages
        for bucket, local_pipeline in local_pipelines.items():
            self.fill_tasks_into_stages(
                local_pipeline,
                bucket,
                build_config_generator.get_task_symbol_values,
            )

        stage_id_to_layer_range = {
            stage_id: layer_range for layer_range, stage_id in self.layer_range_to_stage_id.items()
        }

        ret = (
            Pipeline(
                name=pipeline_name,
                devices=new_devices,
                tensors=self.tensors,
                inputs=get_list_with_no_dup_with_order_preserved(self.inputs),
                outputs=get_list_with_no_dup_with_order_preserved(self.outputs),
                stages=self.stages,
                blobs=self.blobs,
                # The compiled result for composable purposes will be filled in later
                # during the `get_compiled_pipeline` routine.
                # Currently giving None
                composable_blobs=None,
                param_files=self.param_files,
                version="v0.2.0",
            ),
            stage_id_to_layer_range,
            self.task_id_to_bucket.copy(),
        )

        # Reset states for after use.
        self._init_states()

        return ret


def _get_example_input(
    task: Task,
    pipeline: Pipeline,
    fake_mode: FakeTensorMode,
) -> Tuple[torch.Tensor, ...]:
    with fake_mode:
        return tuple(
            torch.zeros(
                pipeline.tensors[input_].shape,
                dtype=pipeline.tensors[input_].dtype.to_torch_dtype(),
            )
            for input_ in task.inputs
        )


@dataclass(frozen=True)
class TaskCompileContext:
    pipeline: Pipeline
    pipeline_output_tensors: Set[TensorId]
    stage_tensor_id_to_consumer_stage_ids: Dict[StageTensorId, List[StageId]]

    base_compiler_config_context: CompilerConfigContext
    task_id_to_bucket: Mapping[TaskId, AttentionBucket]

    target_ir: str
    stage_id_to_layer_range: Mapping[StageId, LayerRange]

    dump_path: Optional[Union[str, os.PathLike]]
    cache_dir: Optional[Union[str, os.PathLike]]

    # option used only for testing
    _raise_error_if_compile: bool


# NOTE: The duration of the compilation process is heavily dependent on available CPU resources,
# particularly during the tactic search stage. Allocating 32 CPUs per actor is recommended
# to significantly speed up the compilation.
@ray.remote(num_cpus=32)
class TaskCompileActor:
    """
    A Ray actor that compiles each fx-graph from a task in `Pipeline` (or other data blob) to EDF.
    """

    def __init__(self, ctx: TaskCompileContext, log_level: int, log_actor: ActorHandle[LogActor]):
        """
        Initialize the task compilation actor.
        The actor sets up logging so that logs produced within this process are
        forwarded to the given ``LogActor``. The returned forwarder may internally
        create background threads and other resources, so we keep a reference to it
        and explicitly clean it up in ``close``.
        """
        self._fd_forwarder = setup_logging(level=log_level, log_actor=log_actor, capture_fds=True)
        self.ctx = ctx

    def close(self) -> None:
        """
        Ensure logging resources created by ``setup_logging`` are cleaned up.

        This method attempts to stop the file-descriptor forwarder, which may
        own background threads or OS resources. Errors are intentionally ignored
        to avoid issues during interpreter shutdown or garbage collection.
        """
        try:
            if self._fd_forwarder:
                self._fd_forwarder.stop()
        except Exception as e:
            logging.warning(f"Error during cleanup: {e}")

    def compile_task(
        self,
        stage_id: StageId,
        stage: Stage,
        task: Task,
        symbol_values: Tuple[SymbolVal, ...],
    ) -> Tuple[BlobId, List[Any], str]:
        layer_range = self.ctx.stage_id_to_layer_range[stage_id]
        device = MpppDevice(self.ctx.pipeline.devices[stage.device].val)
        target_npu = GraphModuleConverter.get_target_npu_from_device(device)

        # Create various configs for compiler.
        bucket = self.ctx.task_id_to_bucket[(stage_id, symbol_values)]
        local_compiler_config_context = self.ctx.base_compiler_config_context.derive_for_stage(
            stage, device, bucket
        )

        compiler_config = local_compiler_config_context.load_config_with_layer_range(layer_range)
        blob = self.ctx.pipeline.blobs[task.data_blob]
        gm = deserialize_gm(blob)

        fake_mode = detect_fake_mode() or FakeTensorMode(allow_non_fake_inputs=True)
        example_input = _get_example_input(task, self.ctx.pipeline, fake_mode)
        output_consumer_info = []

        for output_task_tensor_id, output_stage_tensor_id in zip_equal(task.outputs, stage.outputs):
            cur = [legacy_pipe.SuperTaskKind.FX] * len(
                self.ctx.stage_tensor_id_to_consumer_stage_ids[output_stage_tensor_id]
            )

            if output_task_tensor_id in self.ctx.pipeline_output_tensors:
                # This tensor is output of the pipeline (model).
                cur.append(legacy_pipe.SuperTaskKind.OUTPUT)
            output_consumer_info.append(cur)

        end_layer = layer_range.get_end()
        is_tr_block = isinstance(end_layer, TransformerBlock) and end_layer.sub_layer is None

        logger.info(
            f"Compiling stage id: {stage_id}, symbol values: {symbol_values}, layer range: {layer_range}"
        )

        # TODO: redesign generate_graph_metadata function's output_consumer_info arg.
        graph_metadata = generate_graph_metadata(
            local_compiler_config_context,
            gm,
            output_consumer_info,
            is_tr_block,
        )
        logger.info(f"Generated graph metadata: {graph_metadata}")

        assert local_compiler_config_context.bucket is not None  # due to mypy check
        bucket = local_compiler_config_context.bucket

        try:
            compile_result, hash_val = GraphModuleConverter.compile_gm_and_get_preprocessed_gm_hash(
                gm,
                example_input,
                target_npu,
                self.ctx.target_ir,
                compiler_config,
                graph_metadata,
                (os.fspath(self.ctx.dump_path) if self.ctx.dump_path is not None else None),
                self.ctx.cache_dir,
                extra_dump_tag=f"{bucket.batch_size}_{bucket.input_ids_size}_{bucket.attention_size}",
                _raise_error_if_compile=self.ctx._raise_error_if_compile,
            )
        except Exception as e:
            error_message = (
                f"Compilation failed for stage id: {stage_id}, "
                f"symbol values: {symbol_values}, layer range: {layer_range}. "
                f"Error: {str(e)}"
            )
            logger.error(error_message)
            raise RuntimeError(error_message) from e

        expected_graph_count = 2 if self.ctx.target_ir == "precommandgen+edf" else 1
        assert len(compile_result.graphs) == expected_graph_count, (
            f"Expected {expected_graph_count} graphs for target_ir={self.ctx.target_ir}, "
            f"but got {len(compile_result.graphs)}"
        )

        compiled_results_primitive = [g.serialize() for g in compile_result.graphs]

        # NOTE: Returning bytes instead of the `CompiledGraph` object (which is a builtin class generated via Pyo3)
        # this was necessary since `CompiledGraph` cannot be pickled, which is required for Ray remote calls to return the object.
        return task.data_blob, compiled_results_primitive, hash_val


def get_compiled_pipeline(
    pipeline: Pipeline,
    target_ir: str,
    *,
    stage_id_to_layer_range: Mapping[StageId, LayerRange],
    task_id_to_bucket: Mapping[TaskId, AttentionBucket],
    model_metadata: ModelMetadata,
    cache_dir: Optional[Union[str, os.PathLike]] = None,
    compiler_config_overrides: Mapping = {},
    dump_path: Optional[Union[str, os.PathLike]] = None,
    use_activation_dq: bool = False,
    num_compile_workers: int = 1,
    num_cpu_per_compile_worker: int = 32,
    # option used only for testing
    _raise_error_if_compile: bool = False,
) -> Pipeline:
    """Compile all blobs in the given pipeline into `target_ir` level IR.

    Args:
        pipeline: The pipeline whose blobs to be compiled.
        target_ir: The target intermediate representation stage. Possible values include
            "dfg", "lir", and "edf".
        stage_id_to_layer_range: Mapping from stage IDs to layer ranges.
        task_id_to_bucket: Mapping from task IDs to buckets.
        model_metadata: Metadata for the model.
        cache_dir: Optional directory for caching compiled results.
        compiler_config_overrides: Optional compiler configuration overrides.
        dump_path: Optional path to dump compiled results.

    Returns:
        A pipeline with compiled blobs.
    """
    if num_compile_workers < 1:
        raise ValueError("num_compile_workers must be >= 1")

    if num_cpu_per_compile_worker < 1:
        raise ValueError("num_cpu_per_compile_worker must be >= 1")

    from furiosa.native_common.compiler import CompiledGraph

    compiler_config_context = CompilerConfigContext(
        model_metadata,
        compiler_config_overrides=compiler_config_overrides,
        use_activation_dq_if_possible=use_activation_dq,
    )

    new_blobs = {}
    new_composable_blobs = {}
    blob_id_to_gm_hash: Dict[BlobId, BlobId] = {}

    stage_tensor_id_to_consumer_stage_ids: Dict[StageTensorId, List[StageId]] = defaultdict(list)
    for stage_id, stage in pipeline.stages.items():
        for stage_input in stage.inputs_from_prev_stages:
            stage_tensor_id_to_consumer_stage_ids[stage_input].append(stage_id)

    task_compile_ctx = TaskCompileContext(
        pipeline=pipeline,
        pipeline_output_tensors=set(pipeline.outputs),
        stage_tensor_id_to_consumer_stage_ids=stage_tensor_id_to_consumer_stage_ids,
        base_compiler_config_context=compiler_config_context,
        task_id_to_bucket=task_id_to_bucket,
        target_ir=target_ir,
        stage_id_to_layer_range=stage_id_to_layer_range,
        dump_path=dump_path,
        cache_dir=cache_dir,
        _raise_error_if_compile=_raise_error_if_compile,
    )

    actors = []
    started_ray = False

    pbar = None
    log_actor = None
    try:
        if not ray.is_initialized():
            ray.init()
            started_ray = True

        log_actor = LogActor.remote()  # type: ignore[attr-defined]

        compiled_task_blob: Set[BlobId] = set()
        actors = [
            TaskCompileActor.options(num_cpus=num_cpu_per_compile_worker).remote(  # type: ignore[attr-defined]
                task_compile_ctx, logger.getEffectiveLevel(), log_actor=log_actor
            )
            for _ in range(num_compile_workers)
        ]

        assert actors

        tasks_to_compile: List[Tuple[StageId, Stage, Task, Tuple[SymbolVal, ...]]] = []
        for stage_id, stage in pipeline.stages.items():
            for symbol_values, task in stage.tasks.items():
                if task.kind is not TaskKind.FX:
                    raise ValueError(f"Compiling {task.kind} task into edf is not supported yet.")

                if task.data_blob not in compiled_task_blob:
                    tasks_to_compile.append((stage_id, stage, task, symbol_values))
                    compiled_task_blob.add(task.data_blob)

        pbar = tqdm(
            total=len(tasks_to_compile),
            desc="Compilation Progress",
            position=0,
            leave=False,
            dynamic_ncols=True,
            mininterval=0,
            smoothing=0,
        )

        refs: List[ray.ObjectRef] = []
        for i, (stage_id, stage, task, symbol_values) in enumerate(tasks_to_compile):
            refs.append(
                actors[i % len(actors)].compile_task.remote(stage_id, stage, task, symbol_values)
            )

        ray_results = []
        pending_refs = list(refs)
        while pending_refs:
            done_refs, pending_refs = ray.wait(pending_refs, num_returns=1, timeout=1.0)
            for done_ref in done_refs:
                ray_results.append(ray.get(done_ref))
            pbar.n = len(ray_results)
            drain_logs(log_actor)
            pbar.refresh()
    finally:
        if log_actor:
            drain_logs(log_actor)
        for actor in actors:
            try:
                if hasattr(actor, "close"):
                    ray.get(actor.close.remote())
                ray.kill(actor)
            except RayError:
                logger.debug("Failed to kill actor", exc_info=True)
        if started_ray and ray.is_initialized():
            ray.shutdown()

        if pbar:
            pbar.refresh()
            pbar.close()

    for task_blob, compiled_res_primitive, hash_val in ray_results:

        new_blobs[hash_val] = CompiledGraph.deserialize(compiled_res_primitive[0], hash_val)
        # The first of the two returned compiled results is the EDF.
        # The second result can be used as a composable blob
        # - currently it will be presented in precommandgen-ir.

        if len(compiled_res_primitive) == 2:
            new_composable_blobs[hash_val] = CompiledGraph.deserialize(
                compiled_res_primitive[1],
                hash_val,
            )

        # Map the old blob ID to the new hash value
        blob_id_to_gm_hash[task_blob] = BlobId(hash_val)

    compiled_pipeline = pipeline.model_copy(
        update={"blobs": new_blobs, "composable_blobs": new_composable_blobs},
        deep=True,
    )

    # update tasks' kind and data_blob to use the new hash values.
    for stage in compiled_pipeline.stages.values():
        for task in stage.tasks.values():
            task.kind = TaskKind(target_ir)
            if task.data_blob in blob_id_to_gm_hash:
                task.data_blob = blob_id_to_gm_hash[task.data_blob]

    return compiled_pipeline


@dataclass(frozen=True)
class LocalPipelineBuildContext:
    model: ModelCreationInfo
    devices: Sequence[MpppDevice]
    mppp: Mppp
    build_config_generator: PipelineBuildConfigGenerator
    param_file_metadata: Union[ParamFileMetadata, ParamFileInfo]

    paged_attention_block_size: Optional[int]

    input_names_per_bucket: Callable[[AttentionBucket], Optional[Sequence[str]]]
    output_names: Optional[Sequence[str]]

    logits_slice_config: Optional[LogitsSliceConfig]
    padding_block_idx: Optional[int]
    add_valid_length_input_tensor: bool

    embed_all_constants_into_graph: bool
    max_embeddable_constant_size: int

    cache_dir: Optional[Path]
    dir_for_param_files: Union[str, os.PathLike]


# NOTE: PyTorch utilizes threads controlled by the OMP_NUM_THREADS environment variable.
# Setting num_cpus=24 is recommended to optimize the number of threads used during execution.
@ray.remote(num_cpus=24)
class LocalPipelineGenerationActor:
    """
    A Ray actor that builds `Pipeline` on specified buckets.

    Each actor constructs a `Pipeline` that consists of an FX-graph,
    hence it includes tracing of FX-graph and model rewriting.
    """

    def __init__(
        self, ctx: LocalPipelineBuildContext, log_level: int, log_actor: ActorHandle[LogActor]
    ):
        """
        Initialize the pipeline build actor.
        The actor sets up logging so that logs produced within this process are
        forwarded to the given ``LogActor``. The returned forwarder may internally
        create background threads and other resources, so we keep a reference to it
        and explicitly clean it up in ``close``.
        """

        self._fd_forwarder = setup_logging(level=log_level, log_actor=log_actor, capture_fds=True)
        self.ctx = ctx

    def close(self) -> None:
        """
        Ensure logging resources created by ``setup_logging`` are cleaned up.

        This destructor attempts to stop the file-descriptor forwarder, which may
        own background threads or OS resources. Errors are intentionally ignored
        to avoid issues during interpreter shutdown or garbage collection.
        """
        try:
            if self._fd_forwarder:
                self._fd_forwarder.stop()
        except Exception as e:
            logging.warning(f"Error during cleanup: {e}")

    def build_for_bucket(self, bucket: AttentionBucket) -> LocalPipeline:
        ctx = self.ctx

        if ctx.paged_attention_block_size is not None:
            paged_attention_num_blocks = bucket.batch_size * bucket.attention_size + 100
        else:
            paged_attention_num_blocks = None

        args, kwargs = ctx.model.metadata.get_example_input(
            bucket,
            paged_attention_num_blocks=paged_attention_num_blocks,
            paged_attention_block_size=ctx.paged_attention_block_size,
            collapse_batch_seq_dim=self.ctx.build_config_generator.collapse_batch_seq_dim,
        )
        partitioning_config = self.ctx.build_config_generator.get_partitioning_config()

        res_pipeline = build_local_pipeline(
            f"kv{bucket.kv_cache_size}-b{bucket.batch_size}-attn{bucket.attention_size}",
            ctx.model,
            ctx.devices,
            args,
            kwargs,
            ctx.mppp,
            ctx.param_file_metadata,
            input_names=ctx.input_names_per_bucket(bucket),
            output_names=ctx.output_names,
            partitioning_config=partitioning_config,
            logits_slice_config=ctx.logits_slice_config,
            padding_block_idx=ctx.padding_block_idx,
            add_valid_length_input_tensor=ctx.add_valid_length_input_tensor,
            embed_all_constants_into_graph=ctx.embed_all_constants_into_graph,
            max_embeddable_constant_size=ctx.max_embeddable_constant_size,
            cache_dir=ctx.cache_dir,
            dir_for_param_files=ctx.dir_for_param_files,
        )

        return res_pipeline


def build_pipeline(
    pipeline_name: str,
    model: ModelCreationInfo,
    devices: Sequence[MpppDevice],
    target_ir: str,
    mppp: Mppp,
    build_config_generator: PipelineBuildConfigGenerator,
    # TODO: make this arg optional.
    param_file_metadata: ParamFileMetadata,
    dir_for_param_files: Union[str, os.PathLike],
    *,
    paged_attention_block_size: Optional[int],
    # Pipeline metadata
    input_names_per_bucket: Callable[[AttentionBucket], Optional[Sequence[str]]] = lambda _: None,
    output_names: Optional[Sequence[str]] = None,
    # Graph optimization options for LLM
    padding_block_idx: Optional[int] = None,
    add_valid_length_input_tensor: bool = False,
    use_activation_dq: bool = False,
    logits_slice_config: Optional[LogitsSliceConfig] = None,
    # General graph transformation options
    embed_all_constants_into_graph: bool = False,
    max_embeddable_constant_size: int = DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
    # Other options
    compiler_config_overrides: Mapping = {},
    cache_dir: Optional[Path] = None,
    num_pipeline_builder_workers: int = 1,
    num_compile_workers: int = 1,
    num_cpu_per_pipeline_build_worker: int = 1,
    num_cpu_per_compile_worker: int = 1,
    # Options only for testing
    _raise_error_if_compile: bool = False,
) -> Tuple[Pipeline, Dict[StageId, LayerRange]]:
    """Build next-gen pipeline with stage id to LayerRange mapping."""

    if num_pipeline_builder_workers < 1:
        raise ValueError("num_pipeline_builder_workers must be >= 1")

    if num_cpu_per_pipeline_build_worker < 1:
        raise ValueError("num_cpu_per_pipeline_build_worker must be >= 1")

    ctx = LocalPipelineBuildContext(
        model=model,
        devices=devices,
        mppp=mppp,
        build_config_generator=build_config_generator,
        param_file_metadata=param_file_metadata,
        paged_attention_block_size=paged_attention_block_size,
        input_names_per_bucket=input_names_per_bucket,
        output_names=output_names,
        logits_slice_config=logits_slice_config,
        padding_block_idx=padding_block_idx,
        add_valid_length_input_tensor=add_valid_length_input_tensor,
        embed_all_constants_into_graph=embed_all_constants_into_graph,
        max_embeddable_constant_size=max_embeddable_constant_size,
        cache_dir=cache_dir,
        dir_for_param_files=dir_for_param_files,
    )
    buckets = ctx.build_config_generator.get_needed_buckets()

    logger.info(f"Building local pipelines for {len(buckets)} buckets: {buckets}")

    logger.info(
        f"Number of pipeline builder workers: {num_pipeline_builder_workers}, "
        f"Number of CPUs per pipeline build worker: {num_cpu_per_pipeline_build_worker}"
    )
    logger.info(
        f"Number of compile workers: {num_compile_workers}, "
        f"Number of CPUs per compile worker: {num_cpu_per_compile_worker}"
    )
    actors = []
    started_ray = False

    pbar = None
    log_actor: Optional[ActorHandle[LogActor]] = None
    try:
        if not ray.is_initialized():
            ray.init()
            started_ray = True

        log_actor = LogActor.remote()  # type: ignore[attr-defined]

        actors = [
            LocalPipelineGenerationActor.options(num_cpus=num_cpu_per_pipeline_build_worker).remote(  # type: ignore[attr-defined]
                ctx, logger.getEffectiveLevel(), log_actor=log_actor
            )
            for _ in range(num_pipeline_builder_workers)
        ]

        pbar = tqdm(
            total=len(buckets),
            desc="Model Tracing Progress",
            position=0,
            leave=False,
            dynamic_ncols=True,
            mininterval=0,
            smoothing=0,
        )

        assert actors

        refs = {
            bucket: actors[i % len(actors)].build_for_bucket.remote(bucket)
            for i, bucket in enumerate(buckets)
        }
        bucket_to_local_pipeline = {}
        pending_refs = list(refs.values())
        ref_to_bucket = {ref: bucket for bucket, ref in refs.items()}
        while pending_refs:
            done_refs, pending_refs = ray.wait(pending_refs, num_returns=1, timeout=1.0)
            for done_ref in done_refs:
                bucket = ref_to_bucket[done_ref]
                result = ray.get(done_ref)
                bucket_to_local_pipeline[bucket] = result

            pbar.n = len(bucket_to_local_pipeline)
            drain_logs(log_actor)
            pbar.refresh()

    finally:
        if log_actor:
            drain_logs(log_actor)

        for actor in actors:
            try:
                if hasattr(actor, "close"):
                    ray.get(actor.close.remote())
                ray.kill(actor)
            except RayError:
                logger.debug("Failed to kill actor", exc_info=True)

        if started_ray and ray.is_initialized():
            ray.shutdown()

        if pbar:
            pbar.refresh()
            pbar.close()
    glob_pipe_builder = LocalToGlobalPipelineConverter()

    pipeline, stage_id_to_layer_range, task_id_to_bucket = glob_pipe_builder.convert(
        pipeline_name,
        bucket_to_local_pipeline,
        build_config_generator=build_config_generator,
    )

    compile_dump_path = os.environ.get("FURIOSA_COMPILE_DUMP_PATH")

    if target_ir != "fx":
        # If target_ir is not "fx", compilation is needed.
        pipeline = get_compiled_pipeline(
            pipeline,
            target_ir,
            stage_id_to_layer_range=stage_id_to_layer_range,
            task_id_to_bucket=task_id_to_bucket,
            model_metadata=model.metadata,
            cache_dir=cache_dir,
            compiler_config_overrides=compiler_config_overrides,
            use_activation_dq=use_activation_dq,
            dump_path=compile_dump_path,
            num_compile_workers=num_compile_workers,
            num_cpu_per_compile_worker=num_cpu_per_compile_worker,
            _raise_error_if_compile=_raise_error_if_compile,
        )

    return pipeline, stage_id_to_layer_range
