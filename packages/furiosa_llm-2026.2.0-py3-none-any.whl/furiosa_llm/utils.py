import asyncio
import concurrent.futures
import logging
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
from typing import (
    Any,
    AsyncGenerator,
    Awaitable,
    Coroutine,
    Iterable,
    List,
    Optional,
    TypeVar,
    Union,
)

import torch
from torch.overrides import TorchFunctionMode

from furiosa_llm.metadata.next_gen_config_types import PipelineMetadata
from furiosa_llm.optimum.modeling import is_model_path
from furiosa_llm.parallelize.mppp.config import Device
from furiosa_llm.version import FuriosaVersionInfo

logger = logging.getLogger(__name__)


if sys.version_info >= (3, 10):
    def zip_equal(*iterables):  # fmt: skip
        return zip(*iterables, strict=True)
else:
    from more_itertools import zip_equal  # noqa


_modified_handlers = set()


def get_logger_with_tz(logger: logging.Logger) -> logging.Logger:
    """
    This function is used to add timezone info to logging.Logger's formatter.
    Mind that this function updates in-place, and the ancestor handlers of the logger as well.
    So if called to some logger, it may update the root logger as well.
    """
    global _modified_handlers
    current_logger: Optional[logging.Logger] = logger
    # Traverse up the logger hierarchy to modify all relevant handlers
    while current_logger:
        for handler in current_logger.handlers:
            if handler in _modified_handlers:
                continue
            _modified_handlers.add(handler)
            if handler.formatter:
                if handler.formatter.datefmt:
                    handler.formatter.datefmt += "%z"
                else:
                    handler.formatter.datefmt = logging.Formatter.default_time_format + "%z"
            else:
                handler.setFormatter(
                    logging.Formatter(datefmt=logging.Formatter.default_time_format + "%z")
                )
        if not current_logger.propagate:
            break
        current_logger = current_logger.parent

    return logger


T = TypeVar("T")


def get_list_with_no_dup_with_order_preserved(obj: Iterable[T]) -> List[T]:
    return list(dict.fromkeys(obj).keys())


# Borrowed from https://github.com/vllm-project/vllm/blob/6e1fc61f0fb90c37f0d4a1a8f76235a6e4e1103c/vllm/transformers_utils/config.py#L464,
# with some modifications (modifying vllm-specific parts and removing code for multiprocessing).
def maybe_register_config_serialize_by_value() -> None:
    """Try to register HF model configuration class to serialize by value

    If trust_remote_code is set, and the model's config file specifies an
    `AutoConfig` class, then the config class is typically an instance of
    a custom class imported from the HF modules cache.

    Examples:

    >>> from transformers import AutoConfig
    >>> klass = AutoConfig.from_pretrained('meta-llama/Llama-3.1-8B', trust_remote_code=True)
    >>> klass.__class__ # transformers.models.llama.configuration_llama.LlamaConfig
    >>> import transformers_modules # error, not initialized
    >>> klass = AutoConfig.from_pretrained('deepseek-ai/DeepSeek-V2.5', trust_remote_code=True)
    >>> import transformers_modules # success, initialized
    >>> klass.__class__ # transformers_modules.deepseek-ai.DeepSeek-V2.5.98b11844770b2c3ffc18b175c758a803640f4e77.configuration_deepseek.DeepseekV2Config

    In the DeepSeek example, the config class is an instance of a custom
    class that is not serializable by default. This class will not be
    importable in spawned workers, and won't exist at all on
    other nodes, which breaks serialization of the config.

    In this function we tell the cloudpickle serialization library to pass
    instances of these generated classes by value instead of by reference,
    i.e. the class definition is serialized along with its data so that the
    class module does not need to be importable on the receiving end.

    See: https://github.com/cloudpipe/cloudpickle?tab=readme-ov-file#overriding-pickles-serialization-mechanism-for-importable-constructs
    """  # noqa
    try:
        import transformers_modules  # type: ignore [import-not-found]
    except ImportError:
        # the config does not need trust_remote_code
        return

    try:
        # We don't need this.
        # cloudpickle.register_pickle_by_value(transformers_modules)

        # ray vendors its own version of cloudpickle
        import ray

        ray.cloudpickle.register_pickle_by_value(transformers_modules)
    except Exception as e:
        logging.warning(
            "Unable to register remote classes used by"
            " trust_remote_code with by-value serialization. This may"
            " lead to a later error.",
            exc_info=e,
        )


CACHE_DIR = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache")) / "furiosa" / "llm"
HOT_CACHE_DIR = os.environ.get("HOT_CACHE_DIR")


def get_path_via_hot_cache(origin_path: str) -> str:
    if not os.path.isfile(origin_path):
        return origin_path

    if not HOT_CACHE_DIR:
        return origin_path

    if not os.path.exists(HOT_CACHE_DIR):
        os.makedirs(HOT_CACHE_DIR, exist_ok=True)

    if not os.path.isdir(HOT_CACHE_DIR):
        return origin_path

    origin_path = os.path.abspath(origin_path)
    try:
        relative = Path(origin_path).relative_to(CACHE_DIR)
    except Exception:
        relative = Path(origin_path[1:])
    hot_cached_path = os.path.join(HOT_CACHE_DIR, relative)

    if not os.path.exists(hot_cached_path):
        du = shutil.disk_usage(HOT_CACHE_DIR)
        if du.free / du.total < 0.1:
            return origin_path

        with tempfile.NamedTemporaryFile(dir=HOT_CACHE_DIR, delete=False) as tmp_file:
            temp_path = tmp_file.name

        try:
            shutil.copyfile(origin_path, temp_path)
            os.makedirs(os.path.dirname(hot_cached_path), exist_ok=True)
            shutil.move(temp_path, hot_cached_path)
        except Exception as e:
            print(f"Exception in get_path_via_hot_cache: {e}", flush=True)
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    return hot_cached_path if os.path.exists(hot_cached_path) else origin_path


class MetaCopyMode(TorchFunctionMode):
    """Context manager that makes all tensors created or copied inside to be meta tensors."""

    def __init__(self):
        pass

    def _handle_tensor(self, input_tensor: torch.Tensor) -> torch.Tensor:
        return torch.zeros(
            input_tensor.shape, dtype=input_tensor.dtype, layout=input_tensor.layout, device="meta"
        )

    def __torch_function__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs if kwargs else {}

        # clone will get called in Parameter deepcopy
        if func == torch._C._TensorBase.clone:
            to_be_cloned = args[0]
            new_tensor = self._handle_tensor(to_be_cloned)
            return new_tensor
        elif func == torch.Tensor.__deepcopy__:
            assert len(args) == 2 and len(kwargs) == 0
            tensor, memo = args

            if id(tensor) in memo:
                return memo[id(tensor)]

            out = self._handle_tensor(tensor)
            memo[id(tensor)] = out
            return out
        else:
            with torch._C.DisableTorchFunctionSubclass():
                return func(*args, **kwargs)


def download_model_and_get_hash(model_id: str, revision: str) -> str:
    """
    Extract the commit SHA from the huggingface_hub snapshot directory path.
    For example: .../snapshots/11c5a3d5811f50298f278a704980280950aedb10/config.json
    """
    from huggingface_hub import snapshot_download

    assert not is_model_path(model_id), "must be called when the model id is given"
    path = snapshot_download(repo_id=model_id, repo_type="model", revision=revision)

    p = Path(path)
    parts = p.parts
    if "snapshots" in parts:
        i = parts.index("snapshots")
        if i + 1 < len(parts):
            return parts[i + 1]

    raise ValueError("Could not find commit hash in snapshot path.")


def calculate_dir_hashsum(path: os.PathLike) -> str:
    import blake3

    BLOCK_SIZE: int = 8192
    start_ts = time.perf_counter()
    hasher = blake3.blake3()
    path = Path(path)
    if not path.is_dir():
        raise ValueError(f"{path} is not a directory")

    # Collect all files recursively, sort for determinism
    files = sorted([p for p in path.rglob("*") if p.is_file()])
    total_files = len(files)
    total_bytes = 0

    # Calculate the hashsum of all found files
    for file in files:
        # Update with relative path for uniqueness
        rel_path = str(file.relative_to(path)).encode()
        hasher.update(rel_path)
        # Update with file content
        with open(file, "rb") as f:
            while True:
                chunk = f.read(BLOCK_SIZE)
                if not chunk:
                    break
                hasher.update(chunk)
                total_bytes += len(chunk)

    digest = hasher.hexdigest()
    elapsed = time.perf_counter() - start_ts
    mb = total_bytes / (1024 * 1024)
    mbps = (mb / elapsed) if elapsed > 0 else 0.0

    logger.info(
        "Calculated the hashsum in %.3fs for '%s' (files=%d, size=%.2f MB, throughput=%.2f MB/s)",
        elapsed,
        str(path),
        total_files,
        mb,
        mbps,
    )
    return digest


def _looks_like_path(model_id_or_path: Union[str, os.PathLike]) -> bool:
    """Check if the input looks like a filesystem path (but may not exist)."""
    return isinstance(model_id_or_path, os.PathLike) or (
        isinstance(model_id_or_path, str)
        and (
            model_id_or_path.startswith("/")
            or model_id_or_path.startswith(".")
            or model_id_or_path.startswith("~")
        )
    )


def get_path_or_hf_download(
    model_id_or_path: Union[str, os.PathLike],
    revision: Optional[str] = None,
) -> Path:
    """If the model_id_or_path is a model_id, download the model from HuggingFace Hub. Otherwise, just return a path."""
    from huggingface_hub import hf_hub_download, snapshot_download
    from huggingface_hub.errors import EntryNotFoundError, RepositoryNotFoundError

    # 1. Explicit path patterns (/, ., ~) - local only, error if not found
    if _looks_like_path(model_id_or_path):
        path = Path(model_id_or_path).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {model_id_or_path}")
        return path

    # 2. Check if it exists as a local directory first
    path = Path(model_id_or_path)
    if path.exists():
        return path

    # 3. Try HuggingFace hub download
    model_id: str = str(model_id_or_path)
    try:
        # Verify the repository contains an artifact by checking for artifact.json
        hf_hub_download(repo_id=model_id, filename="artifact.json", revision=revision)
        return Path(snapshot_download(repo_id=model_id, revision=revision))
    except RepositoryNotFoundError:
        raise FileNotFoundError(
            f"Could not find '{model_id_or_path}' as a local directory or HuggingFace repository ID."
        ) from None
    except EntryNotFoundError:
        raise ValueError(
            f"'{model_id}' is not a furiosa-llm artifact. "
            f"The repository exists on HuggingFace Hub but does not contain 'artifact.json'. "
            f"To use this model with furiosa-llm, you need to build an artifact first "
            f"using 'ArtifactBuilder' class. "
            f"Please refer to the documentation for the build process."
        ) from None


# Normalize the SDK version to avoid the change of the 3rd version number;
# e.g., 2025.3.1 -> v2025.3.0, 2026.1.0 -> v2026.1
def _normalize_3rd_version_num(version: str) -> str:
    parts = version.split('.')
    assert len(parts) >= 3, f"Invalid SDK version format (expected MAJOR.MINOR.PATCH): {version}"
    major = int(parts[0])
    if major >= 2026:
        return f"v{parts[0]}.{parts[1]}"
    return f"v{parts[0]}.{parts[1]}.0"


# Resolve the huggingface hub revision for the current SDK release.
def resolve_default_hf_revision(
    model_id_or_path: Union[str, os.PathLike],
    sdk_version: FuriosaVersionInfo,
) -> Optional[str]:
    if sdk_version.is_devrelease or is_model_path(model_id_or_path):
        return None

    model_id_parts = str(model_id_or_path).split("/")
    if model_id_parts[0] == "furiosa-ai":
        return _normalize_3rd_version_num(sdk_version.version)

    return None


def resolve_artifact_path(
    model_id_or_path: Union[str, os.PathLike],
    revision: Optional[str],
    sdk_version: FuriosaVersionInfo,
) -> str:
    """Resolve model ID or path to an artifact path.

    This function handles both local paths and HuggingFace model IDs:
    1. For local paths, validates that it's an artifact
    2. For HuggingFace model IDs, resolves revision and downloads

    Args:
        model_id_or_path: A path to furiosa llm engine artifact or a HuggingFace model ID.
        revision: Optional HuggingFace revision (branch, tag, or commit hash).
        sdk_version: SDK version info for resolving default revision.

    Returns:
        The resolved artifact path as a string.

    Raises:
        FileNotFoundError: If the local path does not exist.
    """
    revision = revision or resolve_default_hf_revision(model_id_or_path, sdk_version)
    return str(get_path_or_hf_download(model_id_or_path, revision))


def get_available_devices() -> List[Device]:
    try:
        import furiosa_smi_py  # type: ignore[import-untyped]
        from furiosa_smi_py import (  # type: ignore[import-not-found, import-untyped]
            CoreStatus,
            list_devices,
        )
    except ModuleNotFoundError:
        raise ModuleNotFoundError("Install furiosa_smi_py to get available devices automatically.")
    except Exception as e:
        raise ImportError(f"Failed to import furiosa_smi_py with error {e}")

    try:
        furiosa_smi_py.init()
        devices = list_devices()
        available_devs = []
        for device in devices:
            # e.g. npu1
            name = device.device_info().name()
            if name[:3] != "npu":
                raise RuntimeError(f"Unexpected device name: {name}")
            npu_idx = int(name[3:])
            core_status = device.core_status()

            for pe_status in core_status.pe_status():
                # Cannot be compared by reference (using "is") because `CoreStatus` is a Rust enum exposed with PyO3.
                if pe_status.status() == CoreStatus.Available:
                    available_devs.append(Device(f"npu:{npu_idx}:{pe_status.core()}"))
        return available_devs
    except Exception as e:
        raise RuntimeError(f"Failed to get available devices with error {e}")


def coalesce(*args: Optional[T]) -> Optional[T]:
    """Returns the first argument that is not None."""
    for arg in args:
        if arg is not None:
            return arg
    return None


def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """
    Run an async coroutine from a synchronous context.

    Args:
        coro: The coroutine to run

    Returns:
        The result of the coroutine
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future: concurrent.futures.Future[T] = executor.submit(asyncio.run, coro)
        return future.result()


async def async_collect(gen: AsyncGenerator[T, None]) -> List[T]:
    """Collect all items from an async generator into a list."""
    return [x async for x in gen]


async def async_gather(*coros: Awaitable[T]) -> List[T]:
    """
    Gather multiple coroutines, returning a coroutine (not a Future).

    This is a wrapper around asyncio.gather that always returns a coroutine,
    making it safe to pass to run_sync even when an event loop is already running.
    """
    return list(await asyncio.gather(*coros))


def compute_bucket_lengths(
    pipeline_metadata_list: List["PipelineMetadata"],
) -> tuple[int, int]:
    """Compute max prefill and decode bucket lengths from pipeline metadata.

    This function analyzes all buckets from pipeline metadata to determine:
    1. max_prefill_bucket_len: Maximum attention size for prefill buckets
       (includes append buckets with input_ids_size > 1 for chunked prefill)
    2. max_decode_bucket_len: Maximum attention size for decode buckets
       (buckets with input_ids_size == 1)

    Args:
        pipeline_metadata_list: List of ComposableKernelMetadata objects.

    Returns:
        A tuple of (max_prefill_bucket_len, max_decode_bucket_len).
    """
    all_buckets = set(
        bucket
        for pipe_metadata in pipeline_metadata_list
        for bucket in pipe_metadata.attention_buckets
    )

    max_prefill_bucket_len = max(
        # bucket.input_ids_size > 1 implies the append bucket, enabling chunked prefill
        bucket.attention_size
        for bucket in all_buckets
        if bucket.is_prefill or bucket.input_ids_size > 1
    )
    max_decode_bucket_len = max(
        (
            bucket.attention_size
            for bucket in all_buckets
            if bucket.is_decode and bucket.input_ids_size == 1
        ),
        default=0,
    )

    return max_prefill_bucket_len, max_decode_bucket_len
