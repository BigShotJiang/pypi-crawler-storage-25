from enum import Enum
import functools
import re
from typing import Any, Dict, FrozenSet, Optional, Set, Union

from pydantic import BaseModel, field_serializer, field_validator
import torch
from typing_extensions import Self


@functools.total_ordering
class AttentionType(str, Enum):
    VANILLA = "VANILLA"
    PAGED_ATTENTION = "PAGED_ATTENTION"

    def __lt__(self, other):
        if not isinstance(other, AttentionType):
            return NotImplemented
        return self.value < other.value


@functools.total_ordering
class OptimizationConfig(BaseModel):
    attention_type: AttentionType = AttentionType.PAGED_ATTENTION

    def __hash__(self) -> int:
        return hash(repr(self))

    def __lt__(self, other):
        return repr(self) < repr(other)

    def get_activated_options(self) -> FrozenSet[str]:
        return frozenset(
            key
            for key, value in self.model_dump().items()
            if value and key not in {"attention_type"}
        )

    def get_all_flags(self) -> FrozenSet[str]:
        return frozenset(key for key in self.model_dump() if key != "attention_type")

    def contains(self, other: "OptimizationConfig") -> bool:
        return self.get_enabled_opts().issuperset(other.get_enabled_opts())

    def get_enabled_opts(self) -> Set[str]:
        return {
            k
            for k, v in self.model_dump().items()
            if (k == "attention_type" and v != AttentionType.VANILLA)
            or (k != "attention_type" and v)
        }

    def with_optimizations(self, opts: Dict[str, Any]) -> "OptimizationConfig":
        new_dict = self.model_dump()
        new_dict.update(opts)
        return OptimizationConfig(**new_dict)


class QDtype(str, Enum):
    INT4 = "int4"
    INT8 = "int8"
    FP8 = "fp8"
    BF16 = "bf16"
    FP32 = "fp32"
    MXFP4 = "mxfp4"

    def bits(self) -> int:
        if self == QDtype.INT4:
            return 4
        elif self in (QDtype.INT8, QDtype.FP8):
            return 8
        elif self == QDtype.BF16:
            return 16
        else:
            raise ValueError(f"{self}.bits() is not supported")

    def to_torch_dtype(self) -> torch.dtype:
        if self is QDtype.INT4:
            # NOTE: There's no int4 type in torch. int8 is used instead.
            return torch.int8
        elif self is QDtype.INT8:
            return torch.int8
        elif self is QDtype.FP8:
            # NOTE: We decided to use torch.int8 to represent fp8 in compression stack.
            return torch.int8
        elif self is QDtype.BF16:
            return torch.bfloat16
        elif self is QDtype.FP32:
            return torch.float32
        else:
            raise ValueError(f"{self} has no corresponding torch dtype")

    def suffix(self):
        return QDTYPE_TO_SUFFIX_MAPPING[self]

    @classmethod
    def from_suffix(cls, val: str) -> "QDtype":
        return SUFFIX_TO_QDTYPE_MAPPING[val]


SUFFIX_TO_QDTYPE_MAPPING = {
    "4": QDtype.INT4,
    "8": QDtype.INT8,
    "8f": QDtype.FP8,
    "16": QDtype.BF16,
    "32": QDtype.FP32,
    "mx4f": QDtype.MXFP4,
}

QDTYPE_TO_SUFFIX_MAPPING = {v: k for k, v in SUFFIX_TO_QDTYPE_MAPPING.items()}


@functools.total_ordering
class QuantizationConfig(BaseModel):
    weight: QDtype
    activation: QDtype
    kv_cache: Optional[QDtype]

    def __hash__(self) -> int:
        return hash(repr(self))

    @classmethod
    def w_i8_a_i8_kv_i8(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.INT8, activation=QDtype.INT8, kv_cache=QDtype.INT8)

    @classmethod
    def w_i8_a_i8(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.INT8, activation=QDtype.INT8, kv_cache=None)

    @classmethod
    def w_f8_a_f8_kv_f8(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.FP8, activation=QDtype.FP8, kv_cache=QDtype.FP8)

    @classmethod
    def w_f8_a_f8(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.FP8, activation=QDtype.FP8, kv_cache=None)

    @classmethod
    def w_4_a_16_kv_f8(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.INT4, activation=QDtype.BF16, kv_cache=QDtype.FP8)

    @classmethod
    def w_16_a_16_kv_16(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.BF16, activation=QDtype.BF16, kv_cache=QDtype.BF16)

    @classmethod
    def w_16_a_16(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.BF16, activation=QDtype.BF16, kv_cache=None)

    @classmethod
    def w_8_a_16_kv_16(cls) -> "QuantizationConfig":
        return cls(weight=QDtype.INT8, activation=QDtype.BF16, kv_cache=QDtype.BF16)

    @property
    def is_bf16(self) -> bool:
        return (
            self.weight is QDtype.BF16
            and self.activation is QDtype.BF16
            and self.kv_cache in (None, QDtype.BF16)
        )

    @field_serializer('weight', 'activation', 'kv_cache')
    def serialize(self, dtype: Optional[QDtype]) -> Optional[str]:
        return dtype.value if dtype else None

    @field_validator('weight', 'activation', 'kv_cache', mode="before")
    @classmethod
    def deserialize(cls, dtype: Union[None, str, QDtype]) -> Optional[QDtype]:
        if dtype is None:
            return None
        if isinstance(dtype, QDtype):
            return dtype
        elif isinstance(dtype, str):
            return QDtype(dtype)
        raise ValueError(f"Invalid dtype: {dtype!r}")

    # NOTE: This method should be synced with from_str.
    def __str__(self) -> str:
        return "W{}A{}{}".format(
            self.weight.suffix(),
            self.activation.suffix(),
            f"KV{self.kv_cache.suffix()}" if self.kv_cache else "",
        )

    @classmethod
    # NOTE: This method should be synced with __str__.
    def from_str(cls, val: str) -> Self:
        pattern = re.compile(
            r"W(?P<weight>[a-z0-9]+)A(?P<activation>[a-z0-9]+)(KV(?P<kv_cache>[a-zA-Z0-9]+))?"
        )
        match = pattern.match(val)
        if not match:
            raise ValueError(f"Invalid string format: {val}")

        weight_dtype = QDtype.from_suffix(match.group("weight"))
        activation_dtype = QDtype.from_suffix(match.group("activation"))
        kv_cache_dtype = (
            QDtype.from_suffix(match.group("kv_cache")) if match.group("kv_cache") else None
        )

        return cls(
            weight=weight_dtype,
            activation=activation_dtype,
            kv_cache=kv_cache_dtype,
        )

    def to_compiler_notation(self) -> str:
        """Convert into notation that can be converted into `QType` in dram shape guide generator."""
        if not self.kv_cache:
            raise ValueError(
                "Quantization config without kv cache dtype cannot be converted into compiler qtype notation."
            )
        if self.weight == self.activation == self.kv_cache:
            return f"w{self.weight.suffix()}a{self.activation.suffix()}"
        return f"w{self.weight.suffix()}a{self.activation.suffix()}kv{self.kv_cache.suffix()}"

    def __lt__(self, other):
        return str(self) < str(other)


class LLMConfig(BaseModel, frozen=True):
    optimization_config: OptimizationConfig = OptimizationConfig()
    quantization_config: Optional[QuantizationConfig] = None

    def __init__(
        self,
        optimization_config: OptimizationConfig = OptimizationConfig(),
        quantization_config: Optional[QuantizationConfig] = None,
    ):
        super(LLMConfig, self).__init__(
            optimization_config=optimization_config, quantization_config=quantization_config
        )

    def with_optimizations(self, opts: Dict[str, Any]) -> "LLMConfig":
        return self.model_copy(
            update={
                "optimization_config": self.optimization_config.with_optimizations(opts),
            },
            deep=True,
        )
