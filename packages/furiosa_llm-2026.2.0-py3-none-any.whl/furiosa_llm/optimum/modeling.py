from contextlib import contextmanager
import functools
import logging
import os
from pathlib import Path
from typing import (
    Any,
    Dict,
    Final,
    List,
    Optional,
    Type,
    Union,
    cast,
)
from unittest.mock import patch
import warnings

from huggingface_hub.constants import HUGGINGFACE_HUB_CACHE
from optimum.modeling_base import OptimizedModel
import torch
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel
from transformers.models.auto.modeling_auto import (
    AutoModelForQuestionAnswering as TRAutoModelForQuestionAnswering,
)
from transformers.models.auto.modeling_auto import (
    MODEL_FOR_CAUSAL_LM_MAPPING,
    MODEL_FOR_QUESTION_ANSWERING_MAPPING,
    MODEL_MAPPING,
)
from transformers.models.auto.modeling_auto import AutoModel as TRAutoModel
from transformers.models.auto.modeling_auto import AutoModelForCausalLM as TRAutoModelForCausalLM

import furiosa.models
from furiosa.models.common.export.serve import (
    CausalModelServer,
)
from furiosa.models.language import as_binary_seq_cls_model
from furiosa_llm.metadata.tasks import SCORE, GenerationTask, PoolingTask
from furiosa_llm.optimum.transformers import _AutoModelFinder
from furiosa_llm.optimum.types import (
    AttentionType,
    OptimizationConfig,
)

_WARNINGS_TO_IGNORE = [
    ".*copying from a non-meta parameter in the checkpoint to a meta parameter in the current model, which is a no-op..*",
]

# Pretrained model IDs
FURIOSA_EXAONE3_7D8B_INSTRUCT_PRETRAINED_ID: Final[str] = (
    "furiosa-ai/EXAONE-3.0-7.8B-Instruct-converted"
)
EXAONE_3_7D8B_INSTRUCT_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-3.0-7.8B-Instruct"
EXAONE_3_5_2D4B_INSTRUCT_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct"
EXAONE_3_5_7D8B_INSTRUCT_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-3.5-7.8B-Instruct"
EXAONE_3_5_32B_INSTRUCT_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-3.5-32B-Instruct"
EXAONE_DEEP_2D4B_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-Deep-2.4B"
EXAONE_DEEP_7D8B_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-Deep-7.8B"
EXAONE_DEEP_32B_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-Deep-32B"

EXAONE_4_32B_INSTRUCT_PRETRAINED_ID: Final[str] = "LGAI-EXAONE/EXAONE-4.0-32B-FP8"

GPT_2_PRETRAINED_ID: Final[str] = "gpt2"
GPT_NEO_PRETRAINED_ID: Final[str] = "EleutherAI/gpt-neo-125m"
GPT_J_PRETRAINED_ID: Final[str] = "EleutherAI/gpt-j-6B"

MLPERF_BERT_LARGE_PRETRAINED_ID: Final[str] = "furiosa-ai/mlperf-bert-large"
MLPERF_GPT_J_PRETRAINED_ID: Final[str] = "furiosa-ai/mlperf-gpt-j-6b"

CODE_LLAMA_7B_PRETRAINED_ID: Final[str] = "meta-llama/CodeLlama-7b-hf"
CODE_LLAMA_7B_INSTRUCT_PRETRAINED_ID: Final[str] = "meta-llama/CodeLlama-7b-Instruct-hf"
CODE_LLAMA_13B_PRETRAINED_ID: Final[str] = "meta-llama/CodeLlama-13b-hf"
CODE_LLAMA_13B_INSTRUCT_PRETRAINED_ID: Final[str] = "meta-llama/CodeLlama-13b-Instruct-hf"
LLAMA_7B_PRETRAINED_ID: Final[str] = "huggyllama/llama-7b"
LLAMA_2_70B_CHAT_PRETRAINED_ID: Final[str] = "meta-llama/Llama-2-70b-chat-hf"
LLAMA_3_1_8B_PRETRAINED_ID: Final[str] = "meta-llama/Llama-3.1-8B"
LLAMA_3_1_70B_PRETRAINED_ID: Final[str] = "meta-llama/Llama-3.1-70B"
LLAMA_3_1_8B_INSTRUCT_PRETRAINED_ID: Final[str] = "meta-llama/Llama-3.1-8B-Instruct"
LLAMA_3_1_70B_INSTRUCT_PRETRAINED_ID: Final[str] = "meta-llama/Llama-3.1-70B-Instruct"
LLAMA_3_3_70B_INSTRUCT_PRETRAINED_ID: Final[str] = "meta-llama/Llama-3.3-70B-Instruct"
LLAMA_3_3_70B_INSTRUCT_FP8_BLOCK_PRETRAINED_ID: Final[str] = (
    "RedHatAI/Llama-3.3-70B-Instruct-FP8-block"
)

ELICEAI_HELPY_EDU_B_LLAMA3_1_PRETRAINED_ID: Final[str] = "eliceai/helpy-edu-b-llama3.1"

SOLAR_10D7B_INSTRUCT_PRETRAINED_ID: Final[str] = "upstage/SOLAR-10.7B-Instruct-v1.0"
SOLAR_ENKOJA_10D7B_32K_1_3_PRETRAINED_ID: Final[str] = (
    "UpstageShareFuriosaAI/solar-lnc-enkoja-10.7b-32k-1.3.0-chat.2"
)

DEEPSEEK_R1_DISTILL_LLAMA_8B_PRETRAINED_ID: Final[str] = "deepseek-ai/DeepSeek-R1-Distill-Llama-8B"
DEEPSEEK_R1_DISTILL_LLAMA_70B_PRETRAINED_ID: Final[str] = (
    "deepseek-ai/DeepSeek-R1-Distill-Llama-70B"
)
DEEPSEEK_R1_DISTILL_QWEN_7B_PRETRAINED_ID: Final[str] = "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B"
DEEPSEEK_R1_DISTILL_QWEN_14B_PRETRAINED_ID: Final[str] = "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B"
DEEPSEEK_R1_DISTILL_QWEN_32B_PRETRAINED_ID: Final[str] = "deepseek-ai/DeepSeek-R1-Distill-Qwen-32B"

QWQ_32B_PRETRAINED_ID: Final[str] = "Qwen/QwQ-32B"
QWEN_2_5_0D5B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-0.5B"
QWEN_2_5_1D5B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-1.5B"
QWEN_2_5_3B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-3B"
QWEN_2_5_7B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-7B"
QWEN_2_5_14B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-14B"
QWEN_2_5_32B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-32B"
QWEN_2_5_0D5B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-0.5B-Instruct"
QWEN_2_5_1D5B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-1.5B-Instruct"
QWEN_2_5_3B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-3B-Instruct"
QWEN_2_5_7B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-7B-Instruct"
QWEN_2_5_14B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-14B-Instruct"
QWEN_2_5_32B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-32B-Instruct"
QWEN_2_5_CODER_7B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-Coder-7B-Instruct"
QWEN_2_5_CODER_14B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-Coder-14B-Instruct"
QWEN_2_5_CODER_32B_INSTRUCT_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-Coder-32B-Instruct"
QWEN_2_5_CODER_32B_PRETRAINED_ID: Final[str] = "Qwen/Qwen2.5-Coder-32B"

GPT_OSS_120B_PRETRAINED_ID: Final[str] = "openai/gpt-oss-120b"
GPT_OSS_20B_PRETRAINED_ID: Final[str] = "openai/gpt-oss-20b"

QWEN_3_4B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-4B"
QWEN_3_EMBEDDING_4B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-Embedding-4B"
QWEN_3_RERANKER_4B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-Reranker-4B"

QWEN_3_8B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-8B"
QWEN_3_8B_FP8_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-8B-FP8"
QWEN_3_EMBEDDING_8B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-Embedding-8B"
QWEN_3_RERANKER_8B_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-Reranker-8B"

QWEN_3_32B_FP8_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-32B-FP8"
QWEN_3_30B_A3B_INSTRUCT_2507_PRETRAINED_ID: Final[str] = "Qwen/Qwen3-30B-A3B-Instruct-2507"


"""List of canonical model IDs which the minimum unique set of supported models"""
# Keep the minimum set of base model IDs in alphabetical order.
CANONICAL_MODEL_IDS: Final[List[str]] = [
    EXAONE_4_32B_INSTRUCT_PRETRAINED_ID,
    QWEN_2_5_0D5B_PRETRAINED_ID,
    QWEN_2_5_1D5B_PRETRAINED_ID,
    QWEN_2_5_3B_PRETRAINED_ID,
    QWEN_2_5_7B_PRETRAINED_ID,
    QWEN_2_5_14B_PRETRAINED_ID,
    QWEN_2_5_32B_PRETRAINED_ID,
    QWEN_3_32B_FP8_PRETRAINED_ID,
    GPT_OSS_20B_PRETRAINED_ID,
    GPT_OSS_120B_PRETRAINED_ID,
    LLAMA_3_1_8B_PRETRAINED_ID,
    LLAMA_3_1_70B_PRETRAINED_ID,
    QWEN_3_EMBEDDING_8B_PRETRAINED_ID,
    QWEN_3_RERANKER_8B_PRETRAINED_ID,
]

# Default optimization config of supported models
DEFAULT_OPTIMIZATION_CONFIG = OptimizationConfig(attention_type=AttentionType.PAGED_ATTENTION)

OPTIMIZATION_CONFIG_MAPPER: Dict[str, Any] = {}

# A list of tasks for binary classification
BINARY_CLASSIFICATION_TASKS: Final[List[str]] = [SCORE]


def get_models_lang_class(
    model_cls: Type[PreTrainedModel],
    task: Optional[GenerationTask | PoolingTask] = None,
    use_binary_seq_class: bool = False,
    classifier_token_ids: Optional[List[int]] = None,
) -> Optional[Type[CausalModelServer]]:
    """Find the same named class in furiosa.models and return it.
    If not found, return None.
    """
    cls = getattr(furiosa.models, model_cls.__name__, None)

    # If cls is found, it must be a subclass of CausalModelServer.
    if cls is not None and (not isinstance(cls, type) or not issubclass(cls, CausalModelServer)):
        raise ValueError(f"invalid class '{model_cls.__name__}' is not a CausalModelServer")

    if cls is not None and task in BINARY_CLASSIFICATION_TASKS and use_binary_seq_class:
        if classifier_token_ids is None:
            raise ValueError(
                "classifier_token_ids must be provided for binary classification tasks"
            )
        if len(classifier_token_ids) != 2:
            raise ValueError("classifier_token_ids must contain exactly two token IDs")

        binary_seq_cls = as_binary_seq_cls_model(
            cls, pos_token_id=classifier_token_ids[0], neg_token_id=classifier_token_ids[1]
        )
        logger.info(
            "Converted %s to %s for binary sequence classification",
            cls.__name__,
            binary_seq_cls.__name__,
        )
        return binary_seq_cls
    else:
        return cls


def get_mlperf_opt_config(
    original_model_cls: Type[PreTrainedModel],
) -> Optional[OptimizationConfig]:
    if get_models_lang_class(original_model_cls) is not None:
        return DEFAULT_OPTIMIZATION_CONFIG
    else:
        return None


class DecomposedLayerNorm(torch.nn.Module):
    def __init__(self, hidden_size, eps=1e-5):
        """
        Decomposed torch.nn.LayerNorm for efficient chip2chip communication by decomposing in more smaller units.
        This is only available for inference.
        """
        super().__init__()
        self.weight = torch.nn.Parameter(torch.ones(hidden_size))
        self.bias = torch.nn.Parameter(torch.zeros(hidden_size))
        self.variance_epsilon = eps
        self.hidden_size = hidden_size

    def forward(self, hidden_states):
        input_dtype = hidden_states.dtype
        mean = hidden_states.mean(-1, keepdim=True)
        pow_mean = hidden_states.pow(2).mean(-1, keepdim=True)
        hidden_states = (
            self.weight
            * (hidden_states - mean)
            * torch.rsqrt(pow_mean - mean.pow(2) + self.variance_epsilon)
            + self.bias
        )

        return hidden_states.to(input_dtype)


@contextmanager
def replace_layernorm(temp_layernorm):
    original_layernorm = torch.nn.LayerNorm
    torch.nn.LayerNorm = temp_layernorm  # type: ignore
    try:
        yield
    finally:
        torch.nn.LayerNorm = original_layernorm  # type: ignore


# To suppress verbose but not important warnings
class MCPLogFilter(logging.Filter):
    def filter(self, record):
        return (
            "torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction is enabled. \
                This optimization may affect performance."
            not in record.msg
        )


_cqm_logger = logging.getLogger("create_quantsim_model")
_cqm_logger.addFilter(MCPLogFilter())


logger = logging.getLogger(__name__)


def apply_warning_filters():
    warnings.simplefilter(action='ignore', category=FutureWarning)
    for warning_to_ignore in _WARNINGS_TO_IGNORE:
        warnings.filterwarnings(action="ignore", message=warning_to_ignore, append=True)


def is_model_path(model_id: Union[str, os.PathLike]) -> bool:
    return (
        isinstance(model_id, os.PathLike)
        or model_id.startswith("/")
        or model_id.startswith(".")
        or model_id.startswith("~")
        or Path(model_id).exists()
    )


def get_optimized_cls(
    model_cls: Type[PreTrainedModel],
    task: Optional[GenerationTask | PoolingTask],
    use_binary_seq_class: bool = False,
    classifier_token_ids: Optional[List[int]] = None,
) -> Type[torch.nn.Module]:

    # TODO: ArtifactBuilder should be able to allow users to set classifier_token_ids
    #   for binary classification tasks.
    if classifier_token_ids is None:
        # Token ids for "yes" and "no" of Qwen3 reranker model
        classifier_token_ids = [9693, 2152]

    # Find the corresponding class from furiosa.models
    optimized_cls = get_models_lang_class(
        model_cls, task, use_binary_seq_class, classifier_token_ids
    )
    if optimized_cls is None:
        raise ValueError(
            f"unsupported model: the class '{model_cls.__name__}' not available in furiosa.models"
        )

    return optimized_cls


@contextmanager
def set_default_torch_dtype(
    dtype: torch.dtype,
):
    original_dtype = PreTrainedModel._set_default_torch_dtype(dtype)  # type: ignore[attr-defined]
    try:
        yield
    finally:
        PreTrainedModel._set_default_torch_dtype(original_dtype)  # type: ignore[attr-defined]


def instantiate_model(
    model_id_or_path: Union[str, os.PathLike],  # for model weights
    optimized_cls: Type[CausalModelServer],
    config: PretrainedConfig,
    torch_dtype: Optional[Union[str, torch.dtype]] = None,
    **kwargs,
) -> torch.nn.Module:
    """Instantiate the model from pretrained weights."""

    model_lang_kwargs: Dict[Any, Any] = {}
    if torch_dtype:
        torch_dtype = getattr(torch, torch_dtype) if isinstance(torch_dtype, str) else torch_dtype
        assert isinstance(torch_dtype, torch.dtype)
        model_lang_kwargs["model_dtype"] = str(torch_dtype).split(".")[-1]

    def _load_weights() -> torch.nn.Module:
        return optimized_cls.create(
            str(model_id_or_path),
            config=config,
            **model_lang_kwargs,
        )

    # Suppress too verbose warnings
    with warnings.catch_warnings(record=True):
        apply_warning_filters()

        try:
            with patch(
                "torch.load",
                new=functools.partial(torch.load, mmap=True, weights_only=True),
            ):
                model = _load_weights()
        except OSError:
            # Error occurs if the model was not saved with `_use_new_zipfile_serialization` option.
            # Try again without mmap option.
            model = _load_weights()

    model.eval()
    model.requires_grad_(False)
    return model


class _FuriosaBaseAutoModelClass(_AutoModelFinder):

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: PretrainedConfig,
        use_auth_token: Optional[Union[bool, str]] = None,
        token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: str = HUGGINGFACE_HUB_CACHE,
        subfolder: str = "",
        local_files_only: bool = False,
        *,
        torch_dtype: Optional[Union[str, torch.dtype]] = None,
        _disable_implicit_typecast: bool = False,
        task: Optional[GenerationTask | PoolingTask] = None,
        use_binary_seq_class: bool = False,
        **kwargs,
    ) -> "OptimizedModel":
        # *Design Note*
        #
        # This method basically keeps the same behavior as the original `AutoModel._from_pretrained` method
        # and its variations (e.g., AutoModelForCausalLM._from_pretrained) in transformers library.
        #
        # It additionally supports the quantized model loading and naive quantization.
        # They are provided by additional arguments, `quantization_checkpt_path` and `torch_dtype`.
        # The native quantization is enabled when `torch_dtype` is 'auto' or 'bfloat16'.
        model_cls = cls.find_model_class(model_id, config, **kwargs)

        # TODO - Remove this assertion after the dependency of model_id is removed.
        #  It should be able to run with the model directory. See update_config_inplace() and
        #  get_optimized_cls(). They depend on a model_id string.
        assert isinstance(
            model_id, str
        ), "model_id must be a string rather than Path if it is not a quantized model"

        optimized_cls = get_optimized_cls(model_cls, task, use_binary_seq_class)

        pretrained_weight_load_options = {
            "use_auth_token": use_auth_token,
            "token": token,
            "revision": revision,
            "force_download": force_download,
            "cache_dir": cache_dir,
            "subfolder": subfolder,
            "local_files_only": local_files_only,
        }

        cast_to_bf16 = (
            config.torch_dtype == torch.bfloat16 and not _disable_implicit_typecast
        ) and not torch_dtype

        if cast_to_bf16:
            # To cast model to bf16 without MCP, we need to set torch_dtype.
            torch_dtype = torch.bfloat16

        model = instantiate_model(
            model_id,
            cast(Type[CausalModelServer], optimized_cls),
            config,
            torch_dtype=torch_dtype,
            **pretrained_weight_load_options,
            **kwargs,
        )

        return model


class AutoModel(_FuriosaBaseAutoModelClass, OptimizedModel):
    _model_mapping = MODEL_MAPPING
    _auto_model_cls = TRAutoModel


class AutoModelForCausalLM(_FuriosaBaseAutoModelClass, OptimizedModel):
    _model_mapping = MODEL_FOR_CAUSAL_LM_MAPPING
    _auto_model_cls = TRAutoModelForCausalLM


class AutoModelForQuestionAnswering(_FuriosaBaseAutoModelClass, OptimizedModel):
    _model_mapping = MODEL_FOR_QUESTION_ANSWERING_MAPPING
    _auto_model_cls = TRAutoModelForQuestionAnswering
