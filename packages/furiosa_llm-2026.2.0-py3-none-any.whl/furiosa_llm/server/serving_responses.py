# Adapted from
# https://github.com/vllm-project/vllm/blob/main/vllm/entrypoints/openai/responses/serving.py
# Implementation of OpenResponses specification: https://www.openresponses.org/specification
"""Serving implementation for the OpenResponses API.

This module implements the OpenResponses specification, providing a
multi-provider, interoperable LLM interface.
"""

import asyncio
from http import HTTPStatus
import json
from logging import Logger
import re
import time
from typing import Any, AsyncGenerator, AsyncIterator, Dict, List, Optional, Union

from fastapi import Request
from openai.types.responses import (
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseFunctionToolCall,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseOutputMessage,
    ResponseOutputText,
    ResponseReasoningItem,
    ResponseReasoningTextDeltaEvent,
    ResponseReasoningTextDoneEvent,
    ResponseStatus,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
)
from openai.types.responses.response_content_part_added_event import (
    PartReasoningText as ContentPartAddedReasoningText,
)
from openai.types.responses.response_content_part_done_event import (
    PartReasoningText as ContentPartDoneReasoningText,
)
from openai.types.responses.response_output_text import Logprob as ResponseLogprob
from openai.types.responses.response_output_text import LogprobTopLogprob
from openai.types.responses.response_reasoning_item import Content as ResponseReasoningTextContent
from openai.types.responses.response_text_delta_event import (
    LogprobTopLogprob as DeltaLogprobTopLogprob,
)
from openai.types.responses.response_text_delta_event import Logprob as DeltaLogprob
from openai.types.responses.tool_choice_function import ToolChoiceFunction
from openai.types.shared_params import FunctionDefinition
import partial_json_parser  # type: ignore[import-untyped]
from pydantic import TypeAdapter

from furiosa_llm.api import LLM, RequestOutput, SamplingParams
from furiosa_llm.llm_engine import AsyncLLMEngine
from furiosa_llm.outputs import RequestOutputKind
from furiosa_llm.server.chat_utils import (
    ModelConfigAdapter,
    preprocess_chat,
    resolve_chat_template_content_format,
    resolve_hf_chat_template,
)
from furiosa_llm.server.protocol import (
    DeltaMessage,
    ErrorResponse,
    InputTokensDetails,
    OutputTokensDetails,
    ResponsesRequest,
    ResponsesResponse,
    ResponseUsage,
)
from furiosa_llm.server.reasoning_parsers import ReasoningParser, ReasoningParserManager
from furiosa_llm.server.response_store import ResponseStore
from furiosa_llm.server.serving_base import OpenAIServing
from furiosa_llm.server.tool_parsers import ToolParserManager
from furiosa_llm.server.utils import (
    ConversationMessage,
    handle_disconnect,
    random_tool_call_id,
    random_uuid,
)
from furiosa_llm.vllm_compat import AnyTokenizer

logger = Logger(__name__)


class OpenAIServingResponses(OpenAIServing):
    """Serving implementation for the OpenResponses API.

    This class handles the /v1/responses endpoint, implementing the
    OpenResponses specification for multi-provider LLM interoperability.
    """

    def __init__(
        self,
        llm: LLM,
        served_model_name: str,
        *,
        chat_template: Optional[str] = None,
        reasoning_parser: Optional[str] = None,
        tool_parser: Optional[str] = None,
        enable_auto_tools: bool = False,
        enable_store: bool = False,
        store_max_entries: int = 10000,
        store_ttl: int = 3600,
    ):
        """Initialize the responses serving handler.

        Args:
            llm: The LLM instance.
            served_model_name: The model name to use in responses.
            chat_template: Optional chat template override.
            reasoning_parser: Optional reasoning parser name.
            tool_parser: Optional tool parser name (e.g. "llama3_json").
            enable_auto_tools: Whether to enable automatic tool call detection.
            enable_store: Whether to enable in-memory response store.
            store_max_entries: Maximum number of responses to keep in the store.
            store_ttl: Time-to-live for stored responses in seconds.
        """
        self.async_llm_engine: AsyncLLMEngine = AsyncLLMEngine.from_llm(llm)
        self.tokenizer: AnyTokenizer = llm.tokenizer
        self.model_name = served_model_name
        self.model_config = llm.model_config
        self.model_config_adapter = ModelConfigAdapter(
            llm.model_config,
            trust_remote_code=getattr(llm.model_metadata, "trust_remote_code", False) or False,
            tokenizer_name_or_path=llm.tokenizer.name_or_path,
        )
        self.chat_template = chat_template
        self.default_sampling_params: Dict[str, Any] = llm.default_generation_config

        # Response store for state management
        self.response_store: Optional[ResponseStore] = (
            ResponseStore(max_responses=store_max_entries, ttl_seconds=store_ttl)
            if enable_store
            else None
        )

        # Reasoning parser
        self.reasoning_parser: Optional[ReasoningParser] = None
        if reasoning_parser:
            try:
                parser_factory = ReasoningParserManager.get_reasoning_parser(reasoning_parser)
                if parser_factory:
                    self.reasoning_parser = parser_factory(self.tokenizer)
            except Exception as e:
                logger.warning(f"Failed to initialize reasoning parser: {e}")

        # Tool parser
        self.enable_auto_tools = enable_auto_tools
        self.tool_parser = None
        if self.enable_auto_tools:
            try:
                self.tool_parser = ToolParserManager.get_tool_parser(tool_parser)
            except Exception as e:
                raise TypeError(
                    f"--enable-auto-tool-choice requires tool_parser:'{tool_parser}' "
                    "which has not been registered"
                ) from e

        # Pre-warm tokenizer
        self._prewarm_tokenizer()

    def _prewarm_tokenizer(self) -> None:
        """Pre-warm the tokenizer and chat template."""
        try:
            model_config = ModelConfigAdapter(self.model_config)
            resolved_chat_template = resolve_hf_chat_template(
                self.tokenizer,
                chat_template=self.chat_template,
                tools=None,
                model_config=model_config,
            )
            resolve_chat_template_content_format(
                resolved_chat_template, None, "auto", self.tokenizer, model_config=model_config
            )
            self.tokenizer.apply_chat_template(
                [ConversationMessage({"role": "user", "content": "Hello!"})],
                chat_template=resolved_chat_template,
                add_generation_prompt=True,
                tokenize=True,
            )
        except Exception as e:
            logger.warning(f"Error in pre-warming tokenizer: {e}")

    async def create_responses(
        self,
        request: ResponsesRequest,
        raw_request: Request,
    ) -> Union[AsyncGenerator[str, None], ResponsesResponse, ErrorResponse]:
        """Create a response for the given request.

        This is the main entry point for the /v1/responses endpoint.

        Args:
            request: The responses request.
            raw_request: The raw FastAPI request.

        Returns:
            Either a streaming generator, a complete Response, or an ErrorResponse.
        """
        request_id = request.request_id or f"resp-{random_uuid()}"
        created_time = int(time.time())

        try:
            # Convert input to chat messages
            messages = self._convert_input_to_messages(request)

            # Prepend previous conversation context if previous_response_id is set
            if request.previous_response_id:
                if self.response_store is None:
                    return self.create_error_response(
                        "previous_response_id requires --enable-responses-api-store",
                        err_type="InvalidRequestError",
                        status_code=HTTPStatus.BAD_REQUEST,
                    )
                prev_response = self.response_store.get(request.previous_response_id)
                if prev_response is None:
                    return self.create_error_response(
                        f"Response '{request.previous_response_id}' not found",
                        err_type="NotFoundError",
                        status_code=HTTPStatus.NOT_FOUND,
                    )
                prev_messages = self.response_store.get_messages(request.previous_response_id)
                if prev_messages:
                    # Prepend full prior conversation (includes all prior turns).
                    # Instructions (system message) from the current request are
                    # already in `messages`, so skip any system messages from the
                    # prior conversation to avoid duplication.
                    filtered_prev = [m for m in prev_messages if m.get("role") != "system"]
                    messages = (
                        [m for m in messages if m.get("role") == "system"]
                        + filtered_prev
                        + [m for m in messages if m.get("role") != "system"]
                    )

            # Apply chat template
            chat_template_kwargs: Dict[str, Any] = {
                "chat_template": self.chat_template,
                "add_generation_prompt": True,
            }
            if request.chat_template_kwargs:
                chat_template_kwargs.update(request.chat_template_kwargs)

            _, _, tokens_prompts = await preprocess_chat(
                request=None,  # type: ignore[arg-type]
                tokenizer=self.tokenizer,
                messages=messages,  # type: ignore[arg-type]
                chat_template=chat_template_kwargs.pop("chat_template", None),
                chat_template_content_format="auto",
                model_config=self.model_config_adapter,
                add_generation_prompt=chat_template_kwargs.pop("add_generation_prompt", True),
                tool_dicts=(
                    self._convert_tools_to_chat_format(request.tools)
                    if request.tools and request.tool_choice != "none"
                    else None
                ),
                chat_template_kwargs=chat_template_kwargs,
                tool_parser=self.tool_parser if self.enable_auto_tools else None,
            )
            engine_prompt = tokens_prompts[0]

            # Store messages for future previous_response_id lookups.
            if request.store and self.response_store is not None:
                self.response_store.store_messages(request_id, messages)

        except Exception as e:
            logger.error(f"Error in processing request: {e}")
            return self.create_error_response(str(e))

        try:
            sampling_params = request.to_sampling_params(self.default_sampling_params)
        except ValueError as e:
            return self.create_error_response(str(e))

        # Create initial response object
        initial_response = self._create_initial_response(
            request_id=request_id,
            created_time=created_time,
            model=self.model_name,
            request=request,
            sampling_params=sampling_params,
        )

        # Store response if enabled
        if request.store and self.response_store is not None:
            self.response_store.store(initial_response)

        stream = request.stream or False
        if stream:
            sampling_params.output_kind = RequestOutputKind.DELTA
            result_generator = self.async_llm_engine.generate(
                engine_prompt, sampling_params, request_id
            )
            asyncio.create_task(
                handle_disconnect(raw_request, lambda: self._abort_request(request_id))
            )
            return self._responses_stream_generator(
                request=request,
                result_generator=result_generator,
                request_id=request_id,
                created_time=created_time,
                initial_response=initial_response,
                sampling_params=sampling_params,
            )

        # Non-streaming
        try:
            sampling_params.output_kind = RequestOutputKind.FINAL
            result_generator = self.async_llm_engine.generate(
                engine_prompt, sampling_params, request_id
            )
            asyncio.create_task(
                handle_disconnect(raw_request, lambda: self._abort_request(request_id))
            )

            return await self._responses_full_generator(
                request=request,
                result_generator=result_generator,
                request_id=request_id,
                created_time=created_time,
                initial_response=initial_response,
                sampling_params=sampling_params,
            )
        except ValueError as e:
            return self.create_error_response(str(e))

    def _convert_input_to_messages(self, request: ResponsesRequest) -> List[Dict[str, Any]]:
        """Convert the request input to chat messages.

        Args:
            request: The responses request.

        Returns:
            List of chat messages.
        """
        messages: List[Dict[str, Any]] = []

        # Add instructions as system message if provided
        if request.instructions:
            messages.append(
                {
                    "role": "system",
                    "content": request.instructions,
                }
            )

        # Handle different input types
        if isinstance(request.input, str):
            # Simple string input
            messages.append(
                {
                    "role": "user",
                    "content": request.input,
                }
            )
        elif isinstance(request.input, list):
            # List of items or chat messages
            for item in request.input:
                if isinstance(item, dict):
                    # Check if it's a chat message format
                    if "role" in item:
                        messages.append(item)  # type: ignore[arg-type]
                    # Check if it's a ResponseInputItem format
                    elif "type" in item:
                        messages.extend(self._convert_input_item_to_messages(item))
                else:
                    # ResponseInputItem objects
                    messages.extend(self._convert_input_item_to_messages(item))

        return messages

    def _convert_input_item_to_messages(self, item: Any) -> List[Dict[str, Any]]:
        """Convert a ResponseInputItem to chat messages.

        Note: Multimodal inputs (images, audio, etc.) are not yet supported.
        This is a placeholder for future implementation.

        Args:
            item: The input item to convert.

        Returns:
            List of chat messages.
        """
        messages: List[Dict[str, Any]] = []

        # Handle dict input
        if isinstance(item, dict):
            item_type = item.get("type")
            if item_type == "message":
                role = item.get("role", "user")
                content = item.get("content", "")

                # Handle content list (multimodal) vs string
                if isinstance(content, list):
                    # TODO: Add support for multimodal content (images, audio, etc.)
                    # For now, extract text content only
                    text_parts = []
                    for part in content:
                        if isinstance(part, dict):
                            if part.get("type") == "input_text":
                                text_parts.append(part.get("text", ""))
                            elif part.get("type") == "input_image":
                                # TODO: Implement image input processing
                                logger.warning("Image input is not yet supported")
                            elif part.get("type") == "input_audio":
                                # TODO: Implement audio input processing
                                logger.warning("Audio input is not yet supported")
                            elif part.get("type") == "input_file":
                                # TODO: Implement file input processing
                                logger.warning("File input is not yet supported")
                    content = " ".join(text_parts)
                messages.append({"role": role, "content": content})
            elif item_type == "function_call":
                # Function call becomes an assistant message with tool_calls
                call_id = item.get("call_id", "")
                messages.append(
                    {
                        "role": "assistant",
                        "content": "",
                        "tool_calls": [
                            {
                                "id": call_id,
                                "type": "function",
                                "function": {
                                    "name": item.get("name", ""),
                                    "arguments": item.get("arguments", ""),
                                },
                            }
                        ],
                    }
                )
            elif item_type == "function_call_output":
                # Function call output becomes a tool result
                messages.append(
                    {
                        "role": "tool",
                        "content": item.get("output", ""),
                        "tool_call_id": item.get("call_id", ""),
                    }
                )
        else:
            # Object-style ResponseInputItem
            if hasattr(item, "type"):
                if item.type == "message":
                    content = item.content if hasattr(item, "content") else ""
                    role = item.role if hasattr(item, "role") else "user"
                    if isinstance(content, list):
                        # TODO: Add support for multimodal content
                        text_parts = []
                        for part in content:
                            if hasattr(part, "type") and part.type == "input_text":
                                text_parts.append(part.text if hasattr(part, "text") else "")
                        content = " ".join(text_parts)
                    messages.append({"role": role, "content": content})
                elif item.type == "function_call":
                    call_id = getattr(item, "call_id", "")
                    messages.append(
                        {
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [
                                {
                                    "id": call_id,
                                    "type": "function",
                                    "function": {
                                        "name": getattr(item, "name", ""),
                                        "arguments": getattr(item, "arguments", ""),
                                    },
                                }
                            ],
                        }
                    )

        return messages

    def _create_initial_response(
        self,
        request_id: str,
        created_time: int,
        model: str,
        request: ResponsesRequest,
        sampling_params: Optional[SamplingParams] = None,
    ) -> ResponsesResponse:
        """Create the initial response object.

        Args:
            request_id: The response ID.
            created_time: Creation timestamp.
            model: Model name.
            request: The original request.
            sampling_params: The SamplingParams used by the engine.

        Returns:
            The initial Response object.
        """
        return ResponsesResponse.from_request(
            request,
            request_id=request_id,
            model=model,
            output=[],
            status="in_progress",
            created_at=created_time,
            sampling_params=sampling_params,
        )

    def _append_assistant_message(
        self,
        request_id: str,
        text: str,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """Append the assistant's response to stored message history.

        When tool_calls are provided, the content is set to empty string
        because the raw model output contains tool-call markup that would
        confuse the chat template on subsequent turns.
        """
        if self.response_store is None:
            return
        stored_msgs = self.response_store.get_messages(request_id)
        if stored_msgs is not None:
            if tool_calls:
                msg: Dict[str, Any] = {
                    "role": "assistant",
                    "content": "",
                    "tool_calls": tool_calls,
                }
            else:
                msg = {"role": "assistant", "content": text}
            self.response_store.store_messages(request_id, stored_msgs + [msg])

    @staticmethod
    def _convert_tools_to_chat_format(tools: List[Any]) -> List[Dict[str, Any]]:
        """Convert Responses API tool format to ChatCompletion tool format.

        Responses API tools are flat: {"type": "function", "name": ..., "parameters": ...}
        ChatCompletion tools are nested: {"type": "function", "function": {"name": ..., "parameters": ...}}
        Chat templates expect the ChatCompletion format.
        """
        chat_tools = []
        for tool in tools:
            if hasattr(tool, "type") and tool.type == "function":
                chat_tools.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", ""),
                            "description": getattr(tool, "description", "") or "",
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return chat_tools

    def _should_return_logprobs(self, request: ResponsesRequest) -> bool:
        """Check if logprobs should be returned based on the include parameter."""
        return bool(request.include and "message.output_text.logprobs" in request.include)

    def _convert_logprobs(
        self,
        token_ids: List[int],
        output_logprobs: List[Optional[Dict[int, Any]]],
        num_top_logprobs: Optional[int],
    ) -> List[ResponseLogprob]:
        """Convert engine logprobs to Responses API format."""
        result: List[ResponseLogprob] = []
        for i, token_id in enumerate(token_ids):
            step_top_logprobs = output_logprobs[i] if i < len(output_logprobs) else None
            if step_top_logprobs is None:
                continue
            if token_id not in step_top_logprobs:
                continue

            step_token = step_top_logprobs[token_id]
            decoded = step_token.decoded_token or self.tokenizer.decode(token_id)
            token_bytes = list(decoded.encode("utf-8", errors="replace"))

            top: List[LogprobTopLogprob] = []
            if num_top_logprobs:
                for j, (tid, lp) in enumerate(step_top_logprobs.items()):
                    if j >= num_top_logprobs:
                        break
                    d = lp.decoded_token or self.tokenizer.decode(tid)
                    top.append(
                        LogprobTopLogprob(
                            token=d,
                            bytes=list(d.encode("utf-8", errors="replace")),
                            logprob=max(lp.logprob, -9999.0),
                        )
                    )

            result.append(
                ResponseLogprob(
                    token=decoded,
                    bytes=token_bytes,
                    logprob=max(step_token.logprob, -9999.0),
                    top_logprobs=top,
                )
            )
        return result

    def _convert_delta_logprobs(
        self,
        token_ids: List[int],
        output_logprobs: List[Optional[Dict[int, Any]]],
        num_top_logprobs: Optional[int],
    ) -> List[DeltaLogprob]:
        """Convert engine logprobs to streaming delta event format.

        Similar to _convert_logprobs but produces DeltaLogprob (no bytes field).
        """
        result: List[DeltaLogprob] = []
        for i, token_id in enumerate(token_ids):
            step_top_logprobs = output_logprobs[i] if i < len(output_logprobs) else None
            if step_top_logprobs is None or token_id not in step_top_logprobs:
                continue

            step_token = step_top_logprobs[token_id]
            decoded = step_token.decoded_token or self.tokenizer.decode(token_id)

            top: List[DeltaLogprobTopLogprob] = []
            if num_top_logprobs:
                for j, (tid, lp) in enumerate(step_top_logprobs.items()):
                    if j >= num_top_logprobs:
                        break
                    d = lp.decoded_token or self.tokenizer.decode(tid)
                    top.append(
                        DeltaLogprobTopLogprob(
                            token=d,
                            logprob=max(lp.logprob, -9999.0),
                        )
                    )

            result.append(
                DeltaLogprob(
                    token=decoded,
                    logprob=max(step_token.logprob, -9999.0),
                    top_logprobs=top,
                )
            )
        return result

    async def _responses_stream_generator(
        self,
        request: ResponsesRequest,
        result_generator: AsyncIterator[RequestOutput],
        request_id: str,
        created_time: int,
        initial_response: ResponsesResponse,
        sampling_params: Optional[SamplingParams] = None,
    ) -> AsyncGenerator[str, None]:
        """Generate streaming events for the response.

        Args:
            request: The original request.
            result_generator: The LLM result generator.
            request_id: The response ID.
            created_time: Creation timestamp.
            initial_response: The initial response object.

        Yields:
            SSE-formatted events.
        """
        # Sequence number for events
        sequence_number = 0

        # Helper to build response-bearing events without SDK type constraints
        def _response_event(event_type: str, response: ResponsesResponse, seq: int) -> str:
            event = {
                "type": event_type,
                "response": response.model_dump(by_alias=True),
                "sequence_number": seq,
            }
            return f"data: {json.dumps(event)}\n\n"

        # Emit response.created event
        yield _response_event("response.created", initial_response, sequence_number)
        sequence_number += 1

        # Emit response.in_progress event
        yield _response_event("response.in_progress", initial_response, sequence_number)
        sequence_number += 1

        # Track state
        output_index = 0
        content_index = 0
        output_item_id = f"{request_id}-item-{output_index}"
        full_text = ""
        prompt_tokens = 0
        completion_tokens = 0
        cached_tokens = 0
        reasoning_tokens = 0
        finish_reason: Optional[str] = None
        all_token_ids: List[int] = []
        all_logprobs: List[Optional[Dict[int, Any]]] = []
        first_iteration = True
        first_delta_sent = False
        previous_text = ""
        previous_token_ids: List[int] = []
        previous_delta_messages: List[Any] = []

        reasoning_enabled = self.reasoning_parser is not None
        # Items completed during streaming (e.g. reasoning item emitted
        # before the message item starts).  These are prepended to the
        # final output_items list at the end.
        completed_output_items: List[Any] = []

        # Tool choice detection
        is_named_tool_call = isinstance(request.tool_choice, ToolChoiceFunction)
        is_tool_choice_required = request.tool_choice == "required"
        is_tool_choice_auto = request.tool_choice in ["auto", None]
        auto_tools_enabled = bool(self.enable_auto_tools and self.tool_parser)

        # Streaming tool call state
        should_stream_tool_calls = (
            is_tool_choice_auto and auto_tools_enabled and bool(request.tools)
        )
        streaming_tool_parser: Optional[Any] = None
        if should_stream_tool_calls:
            assert self.tool_parser is not None
            streaming_tool_parser = self.tool_parser(self.tokenizer)
        tool_previous_text = ""
        tool_previous_token_ids: List[int] = []
        streaming_tool_calls_detected = False
        streaming_tool_call_name = ""
        streaming_tool_call_item_id = ""
        streaming_tool_call_call_id = ""
        streaming_tool_call_args_acc = ""

        try:
            async for res in result_generator:
                if (
                    request.store
                    and self.response_store is not None
                    and self.response_store.is_cancelled(request_id)
                ):
                    break

                if res.finished:
                    cached_tokens = res.num_cached_tokens

                if first_iteration:
                    prompt_tokens = len(res.prompt_token_ids)
                    first_iteration = False

                for output in res.outputs:
                    delta_text = output.text
                    delta_token_ids = output.token_ids
                    delta_logprobs_raw = output.logprobs
                    completion_tokens += len(delta_token_ids)
                    if output.finish_reason is not None:
                        finish_reason = output.finish_reason

                    if not delta_text:
                        continue

                    full_text += delta_text

                    # Extract reasoning vs content from delta
                    if reasoning_enabled and self.reasoning_parser:
                        delta_message = self.reasoning_parser.extract_reasoning_content_streaming(
                            previous_text=previous_text,
                            current_text=previous_text + delta_text,
                            delta_text=delta_text,
                            previous_token_ids=previous_token_ids,
                            current_token_ids=previous_token_ids + list(delta_token_ids),
                            delta_token_ids=delta_token_ids,
                        )
                    else:
                        delta_message = DeltaMessage(content=delta_text)

                    previous_text += delta_text
                    previous_token_ids += list(delta_token_ids)

                    if not delta_message:
                        continue

                    # First delta: emit item.added + part.added
                    if not first_delta_sent:
                        if delta_message.reasoning:
                            # Reasoning item
                            reasoning_item_obj = ResponseReasoningItem(
                                type="reasoning",
                                id=output_item_id,
                                summary=[],
                                status="in_progress",
                            )
                            yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=reasoning_item_obj, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1
                            reasoning_part = ContentPartAddedReasoningText(
                                type="reasoning_text", text=""
                            )
                            yield f"data: {ResponseContentPartAddedEvent(type='response.content_part.added', item_id=output_item_id, output_index=output_index, content_index=content_index, part=reasoning_part, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1
                        elif not (
                            should_stream_tool_calls
                            or is_named_tool_call
                            or is_tool_choice_required
                        ):
                            # Message item - only emit eagerly when not tool parsing
                            msg_obj = ResponseOutputMessage(
                                type="message",
                                id=output_item_id,
                                role="assistant",
                                status="in_progress",
                                content=[],
                            )
                            yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=msg_obj, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1
                            text_part = ResponseOutputText(
                                type="output_text",
                                text="",
                                annotations=[],
                                logprobs=[],
                            )
                            yield f"data: {ResponseContentPartAddedEvent(type='response.content_part.added', item_id=output_item_id, output_index=output_index, content_index=content_index, part=text_part, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1
                        first_delta_sent = True

                    # Transition from reasoning to content
                    if (
                        previous_delta_messages
                        and previous_delta_messages[-1].reasoning is not None
                        and delta_message.content is not None
                    ):
                        # Handle tail reasoning if delta has both
                        if delta_message.reasoning is not None:
                            yield f"data: {ResponseReasoningTextDeltaEvent(type='response.reasoning_text.delta', sequence_number=sequence_number, content_index=content_index, output_index=output_index, item_id=output_item_id, delta=delta_message.reasoning).model_dump_json()}\n\n"
                            sequence_number += 1

                        # Finalize reasoning
                        reason_text = "".join(
                            pm.reasoning
                            for pm in previous_delta_messages
                            if pm.reasoning is not None
                        )
                        if delta_message.reasoning:
                            reason_text += delta_message.reasoning

                        reasoning_tokens += len(
                            self.tokenizer.encode(reason_text, add_special_tokens=False)
                        )

                        yield f"data: {ResponseReasoningTextDoneEvent(type='response.reasoning_text.done', item_id=output_item_id, sequence_number=sequence_number, output_index=output_index, content_index=content_index, text=reason_text).model_dump_json()}\n\n"
                        sequence_number += 1
                        reasoning_part_done = ContentPartDoneReasoningText(
                            type="reasoning_text", text=reason_text
                        )
                        yield f"data: {ResponseContentPartDoneEvent(type='response.content_part.done', item_id=output_item_id, output_index=output_index, content_index=content_index, part=reasoning_part_done, sequence_number=sequence_number).model_dump_json()}\n\n"
                        sequence_number += 1

                        reasoning_item_done = ResponseReasoningItem(
                            type="reasoning",
                            id=output_item_id,
                            summary=[],
                            status="completed",
                            content=[
                                ResponseReasoningTextContent(
                                    text=reason_text, type="reasoning_text"
                                )
                            ],
                        )
                        yield f"data: {ResponseOutputItemDoneEvent(type='response.output_item.done', output_index=output_index, item=reasoning_item_done, sequence_number=sequence_number).model_dump_json()}\n\n"
                        sequence_number += 1
                        completed_output_items.append(reasoning_item_done)

                        output_index += 1
                        content_index = 0
                        output_item_id = f"{request_id}-item-{output_index}"

                        # When tool parsing is active, defer the message item
                        # emission - the content might be a tool call, not text.
                        if not (
                            should_stream_tool_calls
                            or is_named_tool_call
                            or is_tool_choice_required
                        ):
                            msg_obj = ResponseOutputMessage(
                                type="message",
                                id=output_item_id,
                                role="assistant",
                                status="in_progress",
                                content=[],
                            )
                            yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=msg_obj, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1
                            text_part = ResponseOutputText(
                                type="output_text",
                                text="",
                                annotations=[],
                                logprobs=[],
                            )
                            yield f"data: {ResponseContentPartAddedEvent(type='response.content_part.added', item_id=output_item_id, output_index=output_index, content_index=content_index, part=text_part, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1

                        previous_delta_messages = []
                        # Reset tool parser state for content phase
                        tool_previous_text = ""
                        tool_previous_token_ids = []
                        # Only emit content part of this delta
                        delta_message = DeltaMessage(content=delta_message.content)

                    # Emit delta event
                    if delta_message.reasoning is not None:
                        yield f"data: {ResponseReasoningTextDeltaEvent(type='response.reasoning_text.delta', sequence_number=sequence_number, content_index=content_index, output_index=output_index, item_id=output_item_id, delta=delta_message.reasoning).model_dump_json()}\n\n"
                        sequence_number += 1
                    elif delta_message.content is not None:
                        if is_named_tool_call:
                            # Named tool choice: stream all content as arguments
                            if not streaming_tool_calls_detected:
                                streaming_tool_calls_detected = True
                                streaming_tool_call_item_id = f"{request_id}-fc-0"
                                streaming_tool_call_call_id = random_tool_call_id()
                                streaming_tool_call_name = str(
                                    request.tool_choice.name  # type: ignore[union-attr]
                                )
                                fc_item = ResponseFunctionToolCall(
                                    type="function_call",
                                    id=streaming_tool_call_item_id,
                                    call_id=streaming_tool_call_call_id,
                                    name=streaming_tool_call_name,
                                    arguments="",
                                    status="in_progress",
                                )
                                yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=fc_item, sequence_number=sequence_number).model_dump_json()}\n\n"
                                sequence_number += 1
                            streaming_tool_call_args_acc += delta_message.content
                            yield f"data: {ResponseFunctionCallArgumentsDeltaEvent(type='response.function_call_arguments.delta', item_id=streaming_tool_call_item_id, output_index=output_index, delta=delta_message.content, sequence_number=sequence_number).model_dump_json()}\n\n"
                            sequence_number += 1

                        elif is_tool_choice_required:
                            # Required tool choice: accumulate and use partial JSON
                            # parsing to detect tool calls incrementally.
                            # Follows the same approach as chat completions:
                            # wait for both "name" and "parameters" keys before
                            # emitting the function call item.
                            if not streaming_tool_calls_detected:
                                streaming_tool_calls_detected = True
                                streaming_tool_call_item_id = f"{request_id}-fc-0"
                                streaming_tool_call_call_id = random_tool_call_id()
                            streaming_tool_call_args_acc += delta_message.content
                            # Try to parse accumulated text as partial JSON
                            try:
                                obj = partial_json_parser.loads(streaming_tool_call_args_acc)
                            except partial_json_parser.core.exceptions.MalformedJSON:
                                obj = None
                            if obj is not None and isinstance(obj, list) and len(obj) > 0:
                                current_tool = obj[-1]
                                # Wait until both "name" and "parameters" are present
                                # - this ensures the name string is complete, matching
                                # the chat completions approach.
                                if (
                                    isinstance(current_tool, dict)
                                    and "name" in current_tool
                                    and "parameters" in current_tool
                                    and not streaming_tool_call_name
                                ):
                                    streaming_tool_call_name = current_tool["name"]
                                    fc_item = ResponseFunctionToolCall(
                                        type="function_call",
                                        id=streaming_tool_call_item_id,
                                        call_id=streaming_tool_call_call_id,
                                        name=streaming_tool_call_name,
                                        arguments="",
                                        status="in_progress",
                                    )
                                    yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=fc_item, sequence_number=sequence_number).model_dump_json()}\n\n"
                                    sequence_number += 1
                                # Emit arguments delta
                                if streaming_tool_call_name:
                                    param_match = re.search(
                                        r'.*"parameters":\s*(.*)',
                                        streaming_tool_call_args_acc,
                                    )
                                    if param_match:
                                        current_args = param_match.group(1)
                                        prev_args_len = len(
                                            getattr(self, "_prev_required_args", "")
                                        )
                                        new_delta = current_args[prev_args_len:]
                                        self._prev_required_args = current_args  # type: ignore[attr-defined]
                                        if new_delta:
                                            yield f"data: {ResponseFunctionCallArgumentsDeltaEvent(type='response.function_call_arguments.delta', item_id=streaming_tool_call_item_id, output_index=output_index, delta=new_delta, sequence_number=sequence_number).model_dump_json()}\n\n"
                                            sequence_number += 1

                        elif should_stream_tool_calls and streaming_tool_parser:
                            # Route content through tool parser for streaming detection
                            tool_current_text = tool_previous_text + delta_message.content
                            tool_current_token_ids = tool_previous_token_ids + list(delta_token_ids)
                            tool_delta = streaming_tool_parser.extract_tool_calls_streaming(
                                previous_text=tool_previous_text,
                                current_text=tool_current_text,
                                delta_text=delta_message.content,
                                previous_token_ids=tool_previous_token_ids,
                                current_token_ids=tool_current_token_ids,
                                delta_token_ids=delta_token_ids,
                                request=request,  # type: ignore[arg-type]
                            )
                            tool_previous_text = tool_current_text
                            tool_previous_token_ids = tool_current_token_ids

                            if tool_delta is not None and tool_delta.tool_calls:
                                dtc = tool_delta.tool_calls[0]
                                if not streaming_tool_calls_detected:
                                    streaming_tool_calls_detected = True
                                    streaming_tool_call_item_id = f"{request_id}-fc-{dtc.index}"
                                    streaming_tool_call_call_id = dtc.id or random_tool_call_id()
                                    fc_item = ResponseFunctionToolCall(
                                        type="function_call",
                                        id=streaming_tool_call_item_id,
                                        call_id=streaming_tool_call_call_id,
                                        name=dtc.function.name or "" if dtc.function else "",
                                        arguments="",
                                        status="in_progress",
                                    )
                                    yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=fc_item, sequence_number=sequence_number).model_dump_json()}\n\n"
                                    sequence_number += 1
                                if dtc.function and dtc.function.name:
                                    streaming_tool_call_name = dtc.function.name
                                if dtc.function and dtc.function.arguments:
                                    streaming_tool_call_args_acc += dtc.function.arguments
                                    yield f"data: {ResponseFunctionCallArgumentsDeltaEvent(type='response.function_call_arguments.delta', item_id=streaming_tool_call_item_id, output_index=output_index, delta=dtc.function.arguments, sequence_number=sequence_number).model_dump_json()}\n\n"
                                    sequence_number += 1
                            elif tool_delta is not None and tool_delta.content:
                                # Buffer content - don't emit yet. The tool parser
                                # may later detect a tool call (e.g. hermes parser
                                # returns content for tokens before <tool_call>).
                                # Content is already accumulated in previous_delta_messages
                                # and will be emitted at finalization if no tool call.
                                pass
                            # else: tool_delta is None - parser absorbed token, skip
                        else:
                            # Accumulate content-only logprobs (exclude reasoning)
                            all_token_ids.extend(delta_token_ids)
                            if delta_logprobs_raw is not None:
                                all_logprobs.extend(delta_logprobs_raw)
                            # Convert per-delta logprobs if requested
                            delta_lp: list = []
                            if self._should_return_logprobs(request) and delta_logprobs_raw:
                                delta_lp = self._convert_delta_logprobs(
                                    list(delta_token_ids),
                                    list(delta_logprobs_raw),
                                    request.top_logprobs,
                                )
                            yield f"data: {ResponseTextDeltaEvent(type='response.output_text.delta', item_id=output_item_id, output_index=output_index, content_index=content_index, delta=delta_message.content, sequence_number=sequence_number, logprobs=delta_lp).model_dump_json()}\n\n"
                            sequence_number += 1

                    previous_delta_messages.append(delta_message)

        except Exception as e:
            logger.error(f"Error in streaming: {e}")
            error_data = self.create_streaming_error_response(
                str(e),
                err_type="InternalServerError",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
            yield f"data: {error_data}\n\n"
            yield "data: [DONE]\n\n"
            return

        # Determine truncation status before building finalization events
        is_truncated = finish_reason == "length"
        item_status: str = "incomplete" if is_truncated else "completed"

        # Finalize: emit done events based on last delta type
        output_items: List[Any] = list(completed_output_items)

        # Check for tool calls
        auto_tools_called = False
        stored_tool_calls: Optional[List[Dict[str, Any]]] = None

        if streaming_tool_calls_detected:
            # Tool calls were detected during streaming - finalize them
            auto_tools_called = True

            # For required tool_choice, finalize the accumulated args
            if is_tool_choice_required:
                # Parse the full accumulated JSON to get final arguments
                try:
                    parsed = partial_json_parser.loads(streaming_tool_call_args_acc)
                    if isinstance(parsed, list) and len(parsed) > 0:
                        tool_def = parsed[0]
                        if isinstance(tool_def, dict) and "parameters" in tool_def:
                            streaming_tool_call_args_acc = json.dumps(
                                tool_def["parameters"], ensure_ascii=False
                            )
                except Exception:
                    pass
                # Clean up temporary state
                if hasattr(self, "_prev_required_args"):
                    del self._prev_required_args  # type: ignore[attr-defined]

            # Flush any unstreamed argument tokens from partial JSON autocomplete
            elif streaming_tool_parser and streaming_tool_parser.prev_tool_call_arr:
                expected_args = json.dumps(
                    streaming_tool_parser.prev_tool_call_arr[0].get("arguments", {}),
                    ensure_ascii=False,
                )
                remaining = expected_args[len(streaming_tool_call_args_acc) :]
                if remaining:
                    yield f"data: {ResponseFunctionCallArgumentsDeltaEvent(type='response.function_call_arguments.delta', item_id=streaming_tool_call_item_id, output_index=output_index, delta=remaining, sequence_number=sequence_number).model_dump_json()}\n\n"
                    sequence_number += 1
                    streaming_tool_call_args_acc = expected_args

            # Emit function_call_arguments.done
            yield f"data: {ResponseFunctionCallArgumentsDoneEvent(type='response.function_call_arguments.done', item_id=streaming_tool_call_item_id, output_index=output_index, arguments=streaming_tool_call_args_acc, name=streaming_tool_call_name or '', sequence_number=sequence_number).model_dump_json()}\n\n"
            sequence_number += 1

            # Emit output_item.done with complete function call
            fc_done = ResponseFunctionToolCall(
                type="function_call",
                id=streaming_tool_call_item_id,
                call_id=streaming_tool_call_call_id,
                name=streaming_tool_call_name,
                arguments=streaming_tool_call_args_acc,
                status="completed",
            )
            output_items.append(fc_done)
            yield f"data: {ResponseOutputItemDoneEvent(type='response.output_item.done', output_index=output_index, item=fc_done, sequence_number=sequence_number).model_dump_json()}\n\n"
            sequence_number += 1

            stored_tool_calls = [
                {
                    "id": streaming_tool_call_call_id,
                    "type": "function",
                    "function": {
                        "name": streaming_tool_call_name or "",
                        "arguments": streaming_tool_call_args_acc,
                    },
                }
            ]
        elif is_tool_choice_auto and auto_tools_enabled and request.tools:
            # Fallback: static tool call detection for non-streaming parsers
            content_text = "".join(
                pm.content for pm in previous_delta_messages if pm.content is not None
            )
            if content_text:
                assert self.tool_parser is not None
                tool_parser_instance = self.tool_parser(self.tokenizer)
                tool_call_info = tool_parser_instance.extract_tool_calls(
                    content_text, request=request  # type: ignore[arg-type]
                )
                auto_tools_called = tool_call_info.tools_called
                if auto_tools_called:
                    stored_tool_calls = []
                    for i, tc in enumerate(tool_call_info.tool_calls):
                        fc = ResponseFunctionToolCall(
                            type="function_call",
                            id=f"{request_id}-fc-{i}",
                            call_id=tc.id,
                            name=tc.function.name,
                            arguments=tc.function.arguments,
                            status="completed",
                        )
                        output_items.append(fc)
                        stored_tool_calls.append(
                            {
                                "id": tc.id,
                                "type": "function",
                                "function": {
                                    "name": tc.function.name,
                                    "arguments": tc.function.arguments,
                                },
                            }
                        )
                        yield f"data: {ResponseOutputItemDoneEvent(type='response.output_item.done', output_index=output_index + i, item=fc, sequence_number=sequence_number).model_dump_json()}\n\n"
                        sequence_number += 1

        if not auto_tools_called and previous_delta_messages:
            last = previous_delta_messages[-1]
            if last.reasoning is not None:
                # Stream ended in reasoning (no content after)
                reason_text = "".join(
                    pm.reasoning for pm in previous_delta_messages if pm.reasoning is not None
                )
                reasoning_tokens += len(
                    self.tokenizer.encode(reason_text, add_special_tokens=False)
                )
                yield f"data: {ResponseReasoningTextDoneEvent(type='response.reasoning_text.done', item_id=output_item_id, sequence_number=sequence_number, output_index=output_index, content_index=content_index, text=reason_text).model_dump_json()}\n\n"
                sequence_number += 1
                reasoning_part_done = ContentPartDoneReasoningText(
                    type="reasoning_text", text=reason_text
                )
                yield f"data: {ResponseContentPartDoneEvent(type='response.content_part.done', item_id=output_item_id, output_index=output_index, content_index=content_index, part=reasoning_part_done, sequence_number=sequence_number).model_dump_json()}\n\n"
                sequence_number += 1
                reasoning_item_done = ResponseReasoningItem(
                    type="reasoning",
                    id=output_item_id,
                    summary=[],
                    status=item_status,  # type: ignore[arg-type]
                    content=[ResponseReasoningTextContent(text=reason_text, type="reasoning_text")],
                )
                output_items.append(reasoning_item_done)
                yield f"data: {ResponseOutputItemDoneEvent(type='response.output_item.done', output_index=output_index, item=reasoning_item_done, sequence_number=sequence_number).model_dump_json()}\n\n"
                sequence_number += 1
            elif last.content is not None:
                # Normal text response.
                # If tool parsing was active, the message item was deferred -
                # emit the initial events now.
                if should_stream_tool_calls:
                    msg_obj = ResponseOutputMessage(
                        type="message",
                        id=output_item_id,
                        role="assistant",
                        status="in_progress",
                        content=[],
                    )
                    yield f"data: {ResponseOutputItemAddedEvent(type='response.output_item.added', output_index=output_index, item=msg_obj, sequence_number=sequence_number).model_dump_json()}\n\n"
                    sequence_number += 1
                    text_part = ResponseOutputText(
                        type="output_text",
                        text="",
                        annotations=[],
                        logprobs=[],
                    )
                    yield f"data: {ResponseContentPartAddedEvent(type='response.content_part.added', item_id=output_item_id, output_index=output_index, content_index=content_index, part=text_part, sequence_number=sequence_number).model_dump_json()}\n\n"
                    sequence_number += 1

                final_content = "".join(
                    pm.content for pm in previous_delta_messages if pm.content is not None
                )
                # Convert logprobs if requested
                stream_logprobs: Optional[List[ResponseLogprob]] = None
                if self._should_return_logprobs(request) and all_logprobs:
                    stream_logprobs = self._convert_logprobs(
                        all_token_ids, all_logprobs, request.top_logprobs
                    )

                yield f"data: {ResponseTextDoneEvent(type='response.output_text.done', item_id=output_item_id, output_index=output_index, content_index=content_index, text=final_content, sequence_number=sequence_number, logprobs=[]).model_dump_json()}\n\n"
                sequence_number += 1
                final_text_part = ResponseOutputText(
                    type="output_text",
                    text=final_content,
                    annotations=[],
                    logprobs=stream_logprobs or [],
                )
                yield f"data: {ResponseContentPartDoneEvent(type='response.content_part.done', item_id=output_item_id, output_index=output_index, content_index=content_index, part=final_text_part, sequence_number=sequence_number).model_dump_json()}\n\n"
                sequence_number += 1
                final_output_item = ResponseOutputMessage(
                    type="message",
                    id=output_item_id,
                    role="assistant",
                    status=item_status,  # type: ignore[arg-type]
                    content=[final_text_part],
                )
                output_items.append(final_output_item)
                yield f"data: {ResponseOutputItemDoneEvent(type='response.output_item.done', output_index=output_index, item=final_output_item, sequence_number=sequence_number).model_dump_json()}\n\n"
                sequence_number += 1

        # Build final response
        usage = ResponseUsage(
            input_tokens=prompt_tokens,
            output_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
            input_tokens_details=InputTokensDetails(cached_tokens=cached_tokens),
            output_tokens_details=OutputTokensDetails(reasoning_tokens=reasoning_tokens),
        )

        completed_time = int(time.time())

        response_status: ResponseStatus = "incomplete" if is_truncated else "completed"

        final_response = ResponsesResponse.from_request(
            request,
            request_id=request_id,
            model=self.model_name,
            output=output_items,
            status=response_status,
            created_at=created_time,
            completed_at=completed_time,
            usage=usage,
            sampling_params=sampling_params,
        )

        # Update stored response
        if request.store and self.response_store is not None:
            self.response_store.update(
                request_id,
                status=response_status,
                output=output_items,
                usage=usage,
                completed_at=completed_time,
            )

        # Append assistant response to stored message history
        self._append_assistant_message(request_id, full_text, tool_calls=stored_tool_calls)

        # Emit response.completed/incomplete event
        event_type = "response.incomplete" if is_truncated else "response.completed"
        yield _response_event(event_type, final_response, sequence_number)
        sequence_number += 1  # noqa: F841

        # Emit done signal
        yield "data: [DONE]\n\n"

    async def _responses_full_generator(
        self,
        request: ResponsesRequest,
        result_generator: AsyncIterator[RequestOutput],
        request_id: str,
        created_time: int,
        initial_response: ResponsesResponse,
        sampling_params: Optional[SamplingParams] = None,
    ) -> Union[ResponsesResponse, ErrorResponse]:
        """Generate a complete (non-streaming) response.

        Args:
            request: The original request.
            result_generator: The LLM result generator.
            request_id: The response ID.
            created_time: Creation timestamp.
            initial_response: The initial response object.

        Returns:
            The complete Response or an ErrorResponse.
        """
        result = None
        async for result in result_generator:
            # Only get the last result
            continue

        if result is None:
            return self.create_error_response("No result from model")

        prompt_tokens = len(result.prompt_token_ids)
        cached_tokens = result.num_cached_tokens
        completion_tokens = 0
        full_text = ""
        finish_reason: Optional[str] = None
        full_token_ids: List[int] = []
        full_logprobs: List[Optional[Dict[int, Any]]] = []

        for output in result.outputs:
            completion_tokens += len(output.token_ids)
            full_text += output.text
            finish_reason = output.finish_reason
            full_token_ids.extend(output.token_ids)
            if output.logprobs is not None:
                full_logprobs.extend(output.logprobs)

        # Extract reasoning content if enabled
        reasoning_content: Optional[str] = None
        content: str = full_text
        reasoning_tokens = 0
        if self.reasoning_parser:
            reasoning_content, parsed_content = self.reasoning_parser.extract_reasoning_content(
                full_text, request=request  # type: ignore[arg-type]
            )
            content = parsed_content or ""
            if reasoning_content:
                reasoning_tokens = len(
                    self.tokenizer.encode(reasoning_content, add_special_tokens=False)
                )

        # Compute content-only token IDs and logprobs (exclude reasoning tokens)
        if reasoning_tokens > 0 and full_logprobs:
            # Skip reasoning tokens from the front
            all_token_ids = full_token_ids[reasoning_tokens:]
            all_logprobs = full_logprobs[reasoning_tokens:]
        else:
            all_token_ids = full_token_ids
            all_logprobs = full_logprobs

        # Create output items
        output_items: List[Any] = []
        auto_tools_called = False
        item_idx = 0

        # Add reasoning item if present
        if reasoning_content:
            output_items.append(
                ResponseReasoningItem(
                    type="reasoning",
                    id=f"{request_id}-item-{item_idx}",
                    summary=[],
                    status="completed",
                    content=[
                        ResponseReasoningTextContent(text=reasoning_content, type="reasoning_text")
                    ],
                )
            )
            item_idx += 1

        # Detect tool calls based on tool_choice
        is_named_tool_call = isinstance(request.tool_choice, ToolChoiceFunction)
        is_tool_choice_required = request.tool_choice == "required"
        is_tool_choice_auto = request.tool_choice in ["auto", None]
        auto_tools_enabled = bool(self.enable_auto_tools and self.tool_parser)

        stored_tool_calls: Optional[List[Dict[str, Any]]] = None

        if is_named_tool_call:
            # Named tool choice: treat all content as arguments for the named function
            auto_tools_called = True
            call_id = random_tool_call_id()
            fc = ResponseFunctionToolCall(
                type="function_call",
                id=f"{request_id}-fc-0",
                call_id=call_id,
                name=str(request.tool_choice.name),  # type: ignore[union-attr]
                arguments=content or "",
                status="completed",
            )
            output_items.append(fc)
            stored_tool_calls = [
                {
                    "id": call_id,
                    "type": "function",
                    "function": {
                        "name": request.tool_choice.name,  # type: ignore[union-attr]
                        "arguments": content or "",
                    },
                }
            ]

        elif is_tool_choice_required and content:
            # Required tool choice: parse content as JSON array of tool definitions
            auto_tools_called = True
            try:
                tool_calls = TypeAdapter(list[FunctionDefinition]).validate_json(content)
                stored_tool_calls = []
                for i, tool_call in enumerate(tool_calls):
                    call_id = random_tool_call_id()
                    arguments = json.dumps(tool_call.get("parameters", {}), ensure_ascii=False)
                    fc = ResponseFunctionToolCall(
                        type="function_call",
                        id=f"{request_id}-fc-{i}",
                        call_id=call_id,
                        name=tool_call["name"],
                        arguments=arguments,
                        status="completed",
                    )
                    output_items.append(fc)
                    stored_tool_calls.append(
                        {
                            "id": call_id,
                            "type": "function",
                            "function": {
                                "name": tool_call["name"],
                                "arguments": arguments,
                            },
                        }
                    )
            except Exception as e:
                logger.warning(f"Failed to parse tool calls from required tool_choice: {e}")
                auto_tools_called = False

        elif is_tool_choice_auto and auto_tools_enabled and request.tools and content:
            # Auto tool choice: use tool parser to detect tool calls
            assert self.tool_parser is not None
            tool_parser_instance = self.tool_parser(self.tokenizer)
            tool_call_info = tool_parser_instance.extract_tool_calls(content, request=request)
            auto_tools_called = tool_call_info.tools_called
            if auto_tools_called:
                stored_tool_calls = []
                for i, tc in enumerate(tool_call_info.tool_calls):
                    fc = ResponseFunctionToolCall(
                        type="function_call",
                        id=f"{request_id}-fc-{i}",
                        call_id=tc.id,
                        name=tc.function.name,
                        arguments=tc.function.arguments,
                        status="completed",
                    )
                    output_items.append(fc)
                    stored_tool_calls.append(
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                    )

        if not auto_tools_called:
            # Convert logprobs if requested
            response_logprobs: Optional[List[ResponseLogprob]] = None
            if self._should_return_logprobs(request) and all_logprobs:
                response_logprobs = self._convert_logprobs(
                    all_token_ids, all_logprobs, request.top_logprobs
                )

            text_part = ResponseOutputText(
                type="output_text",
                text=content,
                annotations=[],
                logprobs=response_logprobs or [],
            )
            output_items.append(
                ResponseOutputMessage(
                    type="message",
                    id=f"{request_id}-item-{item_idx}",
                    role="assistant",
                    status="completed",
                    content=[text_part],
                )
            )

        # Build usage
        usage = ResponseUsage(
            input_tokens=prompt_tokens,
            output_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
            input_tokens_details=InputTokensDetails(cached_tokens=cached_tokens),
            output_tokens_details=OutputTokensDetails(reasoning_tokens=reasoning_tokens),
        )

        completed_time = int(time.time())

        # Determine response status based on finish reason
        is_truncated = finish_reason == "length"
        response_status: ResponseStatus = "incomplete" if is_truncated else "completed"

        # Mark output items as incomplete if truncated
        if is_truncated:
            for item in output_items:
                if hasattr(item, "status"):
                    item.status = "incomplete"

        # Build final response
        final_response = ResponsesResponse.from_request(
            request,
            request_id=request_id,
            model=self.model_name,
            output=output_items,
            status=response_status,
            created_at=created_time,
            completed_at=completed_time,
            usage=usage,
            sampling_params=sampling_params,
        )

        # Update stored response
        if request.store and self.response_store is not None:
            self.response_store.update(
                request_id,
                status=response_status,
                output=output_items,
                usage=usage,
                completed_at=completed_time,
            )

        # Append assistant response to stored message history
        self._append_assistant_message(request_id, full_text, tool_calls=stored_tool_calls)

        return final_response

    async def get_response(self, response_id: str) -> Union[ResponsesResponse, ErrorResponse]:
        """Get a stored response by ID.

        Args:
            response_id: The response ID.

        Returns:
            The Response if found, or an ErrorResponse.
        """
        if self.response_store is None:
            return self.create_error_response(
                "response store is not enabled; use --enable-responses-api-store",
                err_type="InvalidRequestError",
                status_code=HTTPStatus.BAD_REQUEST,
            )
        response = self.response_store.get(response_id)
        if response is None:
            return self.create_error_response(
                f"Response '{response_id}' not found",
                err_type="NotFoundError",
                status_code=HTTPStatus.NOT_FOUND,
            )
        return response

    async def cancel_response(self, response_id: str) -> Union[ResponsesResponse, ErrorResponse]:
        """Cancel a stored response.

        Args:
            response_id: The response ID.

        Returns:
            The cancelled Response if successful, or an ErrorResponse.
        """
        if self.response_store is None:
            return self.create_error_response(
                "response store is not enabled; use --enable-responses-api-store",
                err_type="InvalidRequestError",
                status_code=HTTPStatus.BAD_REQUEST,
            )
        response = self.response_store.cancel(response_id)
        if response is None:
            return self.create_error_response(
                f"Response '{response_id}' not found",
                err_type="NotFoundError",
                status_code=HTTPStatus.NOT_FOUND,
            )

        # Abort the underlying request
        await self._abort_request(response_id)

        return response

    async def _abort_request(self, request_id: str) -> None:
        """Abort an ongoing request.

        Args:
            request_id: The request ID to abort.
        """
        await self.async_llm_engine.abort(request_id)
