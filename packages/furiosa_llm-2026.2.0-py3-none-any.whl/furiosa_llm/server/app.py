from argparse import Namespace
from contextlib import asynccontextmanager
import logging
from typing import Optional

import anyio
from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse, Response, StreamingResponse
import numpy as np
import orjson
import uvicorn

import furiosa.native_runtime
from furiosa.native_runtime.llm import NativePoolingOutput
from furiosa_llm.api import LLM
from furiosa_llm.metadata.tasks import EMBED, GENERATION_TASKS, POOLING_TASKS, SCORE
from furiosa_llm.server.chat_utils import (
    ChatTemplateContentFormatOption,
    ConversationMessage,
    ModelConfigAdapter,
    apply_hf_chat_template,
    resolve_chat_template_content_format,
    resolve_hf_chat_template,
)
from furiosa_llm.server.metrics import get_metrics_mount, install_metrics_logging_thread
from furiosa_llm.server.middleware import (
    AuthenticationMiddleware,
    Log4xx5xxMiddleware,
    RequestLoggerMiddleware,
)
from furiosa_llm.server.models import load_llm_from_args
from furiosa_llm.server.protocol import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    CompletionRequest,
    CompletionResponse,
    DetokenizeRequest,
    EmbeddingRequest,
    EmbeddingResponse,
    ErrorResponse,
    ModelsResponse,
    RerankRequest,
    RerankResponse,
    ResponsesRequest,
    ResponsesResponse,
    ScoreRequest,
    ScoreResponse,
    TokenizeChatRequest,
    TokenizeCompletionRequest,
)
from furiosa_llm.server.serving_chat import OpenAIServingChat
from furiosa_llm.server.serving_completions import OpenAIServingCompletion
from furiosa_llm.server.serving_embedding import OpenAIServingEmbedding
from furiosa_llm.server.serving_responses import OpenAIServingResponses
from furiosa_llm.server.serving_score import ServingScores
from furiosa_llm.server.serving_tokenization import OpenAIServingTokenization
from furiosa_llm.server.utils import parse_request
from furiosa_llm.version import FURIOSA_LLM_VERSION
from furiosa_llm.vllm_compat import MultiModalConfig, get_score_prompt

router = APIRouter()

llm: LLM
openai_serving_completion: Optional[OpenAIServingCompletion] = None
openai_serving_chat: Optional[OpenAIServingChat] = None
openai_serving_embedding: Optional[OpenAIServingEmbedding] = None
openai_serving_responses: Optional[OpenAIServingResponses] = None
serving_score: Optional[ServingScores] = None
openai_serving_tokenization: Optional[OpenAIServingTokenization] = None
openai_serving_models_response: ModelsResponse


def build_model_config_adapter(llm: LLM, args: Namespace) -> ModelConfigAdapter:
    """Build ModelConfigAdapter from LLM and server arguments.

    This bridges the gap between furiosa-llm's dict-based model config and
    vLLM-style ModelConfig interface expected by chat_utils.

    Args:
        llm: The LLM instance with model_config dict and model_metadata.
        args: Server arguments from CLI containing multimodal config options.

    Returns:
        A ModelConfigAdapter with serving-layer attributes configured.

    Raises:
        ValueError: If multimodal limits are negative.
    """
    image_limit = args.image_limit_per_prompt
    video_limit = args.video_limit_per_prompt
    interleave = args.interleave_mm_strings

    if (image_limit is not None and image_limit < 0) or (
        video_limit is not None and video_limit < 0
    ):
        raise ValueError(
            "Multimodal limits (--image-limit-per-prompt, --video-limit-per-prompt) must be non-negative"
        )

    mm_config = MultiModalConfig(
        limit_per_prompt={"image": image_limit, "video": video_limit},
        interleave_mm_strings=interleave,
    )

    return ModelConfigAdapter(
        llm.model_config,
        trust_remote_code=getattr(llm.model_metadata, "trust_remote_code", False) or False,
        tokenizer_name_or_path=llm.tokenizer.name_or_path,
        multimodal_config=mm_config,
        allowed_local_media_path=getattr(args, "allowed_local_media_path", None),
        allowed_media_domains=getattr(args, "allowed_media_domains", None),
    )


@router.get("/health")
async def health() -> Response:
    """Health check."""
    if llm.engine.is_alive():
        return Response(status_code=200)
    else:
        return Response(status_code=503)


@router.get("/version")
async def show_version():
    return ORJSONResponse(
        content={
            "version": FURIOSA_LLM_VERSION.version,
            "furiosa-llm": {
                "stage": FURIOSA_LLM_VERSION.stage,
                "version": FURIOSA_LLM_VERSION.version,
                "git_hash": FURIOSA_LLM_VERSION.hash,
            },
            "furiosa-runtime": {
                "version": furiosa.native_runtime.__version__,
                "git_hash": furiosa.native_runtime.__git_short_hash__,
                "build_time": furiosa.native_runtime.__build_timestamp__,
            },
            "npu-ir": {
                "version": furiosa.native_runtime.__ir_version__,
                "git_hash": furiosa.native_runtime.__ir_git_short_hash__,
                "build_time": furiosa.native_runtime.__ir_build_timestamp__,
            },
        }
    )


@router.get("/v1/models")
async def show_available_models(raw_request: Request):
    return ORJSONResponse(content=openai_serving_models_response.model_dump())


@router.get("/v1/models/{model_id:path}")
async def show_model(raw_request: Request, model_id: str):
    for model in openai_serving_models_response.data:
        if model.id == model_id:
            return ORJSONResponse(content=model.model_dump())
    return ORJSONResponse(
        content={
            "error": {
                "message": f"The model '{model_id}' does not exist",
                "type": "invalid_request_error",
                "param": "model",
                "code": "model_not_found",
            }
        },
        status_code=404,
    )


@router.post("/v1/completions")
async def create_completion(raw_request: Request):
    if not openai_serving_completion:
        return unsupported_task_response("text generation")
    request = await parse_request(raw_request, CompletionRequest)
    generator = await openai_serving_completion.create_completion(request, raw_request)
    if isinstance(generator, ErrorResponse):
        return ORJSONResponse(content=generator.model_dump(), status_code=generator.code)
    elif isinstance(generator, CompletionResponse):
        return ORJSONResponse(content=generator.model_dump())

    return StreamingResponse(content=generator, media_type="text/event-stream")


@router.post("/v1/chat/completions")
async def create_chat_completion(raw_request: Request):
    if not openai_serving_chat:
        return unsupported_task_response("text generation")
    request = await parse_request(raw_request, ChatCompletionRequest)
    generator = await openai_serving_chat.create_chat_completion(request, raw_request)
    if isinstance(generator, ErrorResponse):
        return ORJSONResponse(content=generator.model_dump(), status_code=generator.code)
    elif isinstance(generator, ChatCompletionResponse):
        return ORJSONResponse(content=generator.model_dump())

    return StreamingResponse(content=generator, media_type="text/event-stream")


@router.post("/v1/embeddings")
async def create_embedding(raw_request: Request):
    if not openai_serving_embedding:
        return unsupported_task_response("embedding")
    request = await parse_request(raw_request, EmbeddingRequest)
    response = await openai_serving_embedding.create_embedding(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, EmbeddingResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_embedding")


@router.post("/score")
async def create_score(raw_request: Request):
    if not serving_score:
        return unsupported_task_response("score")
    request = await parse_request(raw_request, ScoreRequest)
    response = await serving_score.create_score(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, ScoreResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_score")


@router.post("/v1/score")
async def create_score_v1(raw_request: Request):
    return await create_score(raw_request)


@router.post("/rerank")
async def do_rerank(raw_request: Request):
    if not serving_score:
        return unsupported_task_response("rerank")
    request = await parse_request(raw_request, RerankRequest)
    response = await serving_score.create_rerank(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, RerankResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_rerank")


@router.post("/v1/rerank")
async def do_rerank_v1(raw_request: Request):
    return await do_rerank(raw_request)


@router.post("/v2/rerank")
async def do_rerank_v2(raw_request: Request):
    return await do_rerank(raw_request)


@router.post("/tokenize")
async def tokenize(raw_request: Request):
    if not openai_serving_tokenization:
        return unsupported_task_response("tokenization")
    if "application/json" not in raw_request.headers.get("Content-Type", ""):
        raise HTTPException(status_code=415, detail="Content-Type must be application/json")
    try:
        body = await raw_request.body()
        data = orjson.loads(body)
        request: TokenizeChatRequest | TokenizeCompletionRequest
        if "messages" in data:
            request = TokenizeChatRequest.model_validate(data)
        else:
            request = TokenizeCompletionRequest.model_validate(data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    response = await openai_serving_tokenization.create_tokenize(request, raw_request)
    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    return ORJSONResponse(content=response.model_dump())


@router.post("/detokenize")
async def detokenize(raw_request: Request):
    if not openai_serving_tokenization:
        return unsupported_task_response("tokenization")
    request = await parse_request(raw_request, DetokenizeRequest)
    response = await openai_serving_tokenization.create_detokenize(request, raw_request)
    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    return ORJSONResponse(content=response.model_dump())


@router.get("/tokenizer_info")
async def tokenizer_info():
    if not openai_serving_tokenization:
        return unsupported_task_response("tokenization")
    response = await openai_serving_tokenization.get_tokenizer_info()
    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    return ORJSONResponse(content=response.model_dump())


# ============================================================================
# OpenResponses API Endpoints
# https://www.openresponses.org/specification
# ============================================================================


@router.post("/v1/responses")
async def create_responses(raw_request: Request):
    """Create a response using the OpenResponses API.

    This endpoint implements the OpenResponses specification,
    providing a multi-provider, interoperable LLM interface.
    """
    if not openai_serving_responses:
        return unsupported_task_response("text generation (responses)")
    request = await parse_request(raw_request, ResponsesRequest)
    result = await openai_serving_responses.create_responses(request, raw_request)

    if isinstance(result, ErrorResponse):
        return ORJSONResponse(content=result.model_dump(), status_code=result.code)
    elif isinstance(result, ResponsesResponse):
        # OpenResponses spec requires all fields to be present, including null values.
        # by_alias=True ensures aliased fields (e.g. schema_ -> schema) are
        # serialized with the correct key for the OpenAI SDK client.
        return ORJSONResponse(content=result.model_dump(by_alias=True))

    # Streaming response
    return StreamingResponse(content=result, media_type="text/event-stream")


@router.get("/v1/responses/{response_id}")
async def get_response(response_id: str):
    """Retrieve a stored response by ID.

    This endpoint allows retrieval of previously created responses
    when store=true was set in the original request.
    """
    if not openai_serving_responses:
        return unsupported_task_response("text generation (responses)")

    result = await openai_serving_responses.get_response(response_id)
    if isinstance(result, ErrorResponse):
        return ORJSONResponse(content=result.model_dump(), status_code=result.code)
    return ORJSONResponse(content=result.model_dump(by_alias=True))


@router.post("/v1/responses/{response_id}/cancel")
async def cancel_response(response_id: str):
    """Cancel an in-progress response.

    This endpoint allows cancellation of responses that are still
    being generated in the background.
    """
    if not openai_serving_responses:
        return unsupported_task_response("text generation (responses)")

    result = await openai_serving_responses.cancel_response(response_id)
    if isinstance(result, ErrorResponse):
        return ORJSONResponse(content=result.model_dump(), status_code=result.code)
    return ORJSONResponse(content=result.model_dump(by_alias=True))


def unsupported_task_response(task: str) -> ORJSONResponse:
    return ORJSONResponse(
        content={
            "error": {
                "message": f"The model does not support {task} task.",
                "type": "invalid_request_error",
                "param": "model",
                "code": "model_not_supported",
            }
        },
        status_code=400,
    )


def init_app(
    args: Namespace,
) -> FastAPI:
    global llm
    global openai_serving_completion
    global openai_serving_chat
    global openai_serving_embedding
    global openai_serving_responses
    global serving_score
    global openai_serving_tokenization
    global openai_serving_models_response

    served_model_name = getattr(args, "served_model_name", None) or str(args.model)
    llm = load_llm_from_args(args, served_model_name=served_model_name)
    task = llm.model_metadata.task

    override_chat_template = None
    if args.chat_template is not None:
        try:
            # Use a context manager to ensure the file is properly closed
            with open(args.chat_template, "r", encoding="utf-8") as f:
                override_chat_template = f.read()
        except Exception as e:
            raise ValueError(f"Error in reading chat template file: {e}")

    openai_serving_models_response = ModelsResponse.from_llm(llm, served_model_name)
    # XXX(n0gu): Currently we only support one task per LLM instance.
    # However in the future we may want to support multiple tasks per LLM.
    # In that case we need to modify type of ModelMetadata.task_type.
    if task in GENERATION_TASKS:
        try:
            llm.tokenizer.get_chat_template()
        except Exception as e:
            raise ValueError(
                f"Failed to load chat template from tokenizer: {e}. Please specify a chat template using the --chat-template option."
            )
        model_config_adapter = build_model_config_adapter(llm, args)
        openai_serving_completion = OpenAIServingCompletion(llm, served_model_name)
        openai_serving_chat = OpenAIServingChat(
            llm,
            served_model_name,
            args.response_role,
            chat_template=override_chat_template,
            chat_template_content_format=args.chat_template_content_format,
            model_config_adapter=model_config_adapter,
            reasoning_parser=args.reasoning_parser,
            enable_auto_tools=args.enable_auto_tool_choice,
            tool_parser=args.tool_call_parser,
        )
        # Initialize OpenResponses API handler
        openai_serving_responses = OpenAIServingResponses(
            llm,
            served_model_name,
            chat_template=override_chat_template,
            reasoning_parser=args.reasoning_parser,
            tool_parser=getattr(args, "tool_call_parser", None),
            enable_auto_tools=getattr(args, "enable_auto_tool_choice", False),
            enable_store=getattr(args, "enable_responses_api_store", False),
            store_max_entries=getattr(args, "responses_api_store_max_entries", 10000),
            store_ttl=getattr(args, "responses_api_store_ttl", 3600),
        )
    if task == EMBED:
        openai_serving_embedding = OpenAIServingEmbedding(llm, served_model_name)
    if task == SCORE:
        serving_score = ServingScores(llm, served_model_name)

    # Tokenization is model-agnostic, always instantiate
    model_config_adapter_for_tokenization = (
        model_config_adapter if task in GENERATION_TASKS else None
    )
    openai_serving_tokenization = OpenAIServingTokenization(
        llm,
        served_model_name,
        chat_template=override_chat_template,
        chat_template_content_format=args.chat_template_content_format,
        model_config_adapter=model_config_adapter_for_tokenization,
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        if not args.disable_log_stats:
            install_metrics_logging_thread()

        try:
            await prewarm_server(llm, override_chat_template, args.chat_template_content_format)
        except Exception as e:
            logging.warning(f"Error while pre-warming server: {e}")

        yield
        llm.engine.shutdown()

    app = FastAPI(lifespan=lifespan)
    app.include_router(router)
    if args.uvicorn_log_level in ("warning", "error", "critical"):
        app.add_middleware(Log4xx5xxMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=args.allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.routes.append(get_metrics_mount())

    return app


async def prewarm_server(
    llm: LLM,
    chat_template: str | None,
    chat_template_content_format: ChatTemplateContentFormatOption = "auto",
):
    # Scarlette (used by FastAPI) uses anyio for asynchronous response streaming.
    # When anyio runs for the first time, it takes 2-4 ms just importing its async backend.
    # Do that here in advance, with a dummy async job.
    await anyio.sleep(0)

    # Prewarm tokenizer (first call to it takes 10-20 ms)
    llm.tokenizer.encode('Tokenizer test.')

    task = llm.model_metadata.task
    if task in POOLING_TASKS:
        # XXX(seungwon): ndarray::to_pyarray() lazy-loads Rust Numpy bindings;
        # Trigger the loading here in advance, in order to prevent first-time delays.
        _ = NativePoolingOutput(data=np.array([0], dtype=np.float32)).data

    if task in GENERATION_TASKS:
        model_config = ModelConfigAdapter(llm.model_config)
        resolved_chat_template = resolve_hf_chat_template(
            llm.tokenizer,
            chat_template=chat_template,
            tools=None,
            model_config=model_config,
        )
        resolve_chat_template_content_format(
            resolved_chat_template,
            None,
            chat_template_content_format,
            llm.tokenizer,
            model_config=model_config,
        )
        apply_hf_chat_template(
            llm.tokenizer,
            [ConversationMessage({"role": "user", "content": "Hello!"})],  # type: ignore[arg-type]
            resolved_chat_template,
            None,
            model_config=model_config,
        )

    if task == SCORE:
        # Create scoring prompt (to trigger Jinja template compilation)
        _ = get_score_prompt(
            llm.tokenizer, data_1="dummy query", data_2="dummy document", score_template=None
        )


def run_server(args, **uvicorn_kwargs) -> None:
    logging.getLogger("httpx").setLevel(logging.WARNING)

    app = init_app(args)

    if args.enable_payload_logging:
        app.add_middleware(RequestLoggerMiddleware)
        logging.warning(
            "Payload logging is enabled. This might expose sensitive data. If you do not fully understand the risks associated with this option, do not enable it."
        )
        # Disable uvicorn's access log
        args.disable_uvicorn_access_log = True

    if args.api_key:
        app.add_middleware(AuthenticationMiddleware, tokens=[args.api_key])

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level=args.uvicorn_log_level,
        access_log=not args.disable_uvicorn_access_log,
        **uvicorn_kwargs,
    )
