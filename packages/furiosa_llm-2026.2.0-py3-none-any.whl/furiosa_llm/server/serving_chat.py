import asyncio
from http import HTTPStatus
import json
from logging import Logger
import re
import time
from typing import (
    Any,
    AsyncGenerator,
    AsyncIterator,
    Callable,
    Final,
    List,
    Optional,
    Sequence,
    Union,
)

from fastapi import Request
from openai_harmony import Message as OpenAIMessage  # type: ignore[import-untyped]
import partial_json_parser  # type: ignore[import-untyped]
from pydantic import TypeAdapter

from furiosa_llm.api import LLM, RequestOutput
from furiosa_llm.llm_engine import AsyncLLMEngine
from furiosa_llm.outputs import CompletionOutput, RequestOutputKind
from furiosa_llm.server.chat_utils import (
    ChatTemplateContentFormatOption,
    ModelConfigAdapter,
    preprocess_chat,
)
from furiosa_llm.server.harmony_utils import (
    get_developer_message,
    get_stop_tokens_for_assistant_actions,
    get_streamable_parser_for_assistant,
    get_system_message,
    parse_chat_input,
    parse_chat_output,
    render_for_completion,
)
from furiosa_llm.server.protocol import (
    ChatCompletionLogProb,
    ChatCompletionLogProbs,
    ChatCompletionLogProbsContent,
    ChatCompletionNamedToolChoiceParam,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionResponseChoice,
    ChatCompletionResponseStreamChoice,
    ChatCompletionStreamResponse,
    ChatMessage,
    CompletionTokenUsageInfo,
    DeltaFunctionCall,
    DeltaMessage,
    DeltaToolCall,
    ErrorResponse,
    FunctionCall,
    FunctionDefinition,
    Logprob,
    PromptTokensDetails,
    ToolCall,
    UsageInfo,
)
from furiosa_llm.server.reasoning_parsers import ReasoningParser, ReasoningParserManager
from furiosa_llm.server.serving_base import OpenAIServing
from furiosa_llm.server.tool_parsers import ToolParser, ToolParserManager
from furiosa_llm.server.utils import (
    MIN_LOGPROB_FOR_JSON,
    clamp_prompt_logprobs,
    handle_disconnect,
    random_tool_call_id,
    random_uuid,
)
from furiosa_llm.vllm_compat import AnyTokenizer, SingletonPrompt, TokensPrompt

logger = Logger(__name__)


class OpenAIServingChat(OpenAIServing):
    def __init__(
        self,
        llm: LLM,
        served_model_name: str,
        response_role: str = "assistant",
        *,
        chat_template: Optional[str],
        model_config_adapter: Optional[ModelConfigAdapter] = None,
        return_tokens_as_token_ids: bool = False,
        chat_template_content_format: ChatTemplateContentFormatOption = "auto",
        reasoning_parser: Optional[str] = None,
        enable_auto_tools: bool = False,
        tool_parser: Optional[str] = None,
    ):
        self.async_llm_engine: AsyncLLMEngine = AsyncLLMEngine.from_llm(llm)
        self.tokenizer: AnyTokenizer = llm.tokenizer
        self.model_name = served_model_name
        self.model_config = llm.model_config
        self.return_tokens_as_token_ids = return_tokens_as_token_ids

        # Use provided adapter or create minimal one for backward compat
        self.model_config_adapter = model_config_adapter or ModelConfigAdapter(
            llm.model_config,
            trust_remote_code=getattr(llm.model_metadata, "trust_remote_code", False) or False,
            tokenizer_name_or_path=llm.tokenizer.name_or_path,
        )

        self.response_role = response_role
        self.chat_template = chat_template
        self.chat_template_content_format = chat_template_content_format
        self.default_sampling_params: dict[str, Any] = llm.default_generation_config
        self.reasoning_parser: Optional[Callable[[AnyTokenizer], ReasoningParser]] = None

        self.enable_auto_tools = enable_auto_tools
        # Ensure attribute always exists even if auto tools are disabled
        self.tool_parser = None
        if self.enable_auto_tools:
            try:
                self.tool_parser = ToolParserManager.get_tool_parser(tool_parser)
            except Exception as e:
                raise TypeError(
                    "Error: --enable-auto-tool-choice requires "
                    f"tool_parser:'{tool_parser}' which has not "
                    "been registered"
                ) from e

        if reasoning_parser:
            try:
                self.reasoning_parser = ReasoningParserManager.get_reasoning_parser(
                    reasoning_parser
                )
                assert self.reasoning_parser is not None
            except Exception as e:
                raise TypeError(f"{reasoning_parser=} has not been registered") from e

        self.use_harmony = llm.model_config["model_type"] == "gpt_oss"
        if self.use_harmony:
            if "stop_token_ids" not in self.default_sampling_params:
                self.default_sampling_params["stop_token_ids"] = []
            self.default_sampling_params["stop_token_ids"].extend(
                get_stop_tokens_for_assistant_actions()
            )

    async def create_chat_completion(
        self,
        request: ChatCompletionRequest,
        raw_request: Request,
    ) -> Union[AsyncGenerator[str, None], ChatCompletionResponse, ErrorResponse]:
        """
        Completion API similar to OpenAI's API.

        See https://platform.openai.com/docs/api-reference/chat/create
        for the API specification. This API mimics the OpenAI
        ChatCompletion API.
        """
        try:
            if (
                request.tool_choice == "auto"
                and not (self.enable_auto_tools and self.tool_parser is not None)
                and not self.use_harmony
            ):
                # for hf tokenizers, "auto" tools requires
                # --enable-auto-tool-choice and --tool-call-parser
                return self.create_error_response(
                    "\"auto\" tool choice requires "
                    "--enable-auto-tool-choice and --tool-call-parser to be set"
                )

            tools_dict = (
                [tool.model_dump() for tool in request.tools]
                if (request.tools and request.tool_choice != "none")
                else None
            )

            _chat_template = request.chat_template or self.chat_template
            _chat_template_kwargs: dict[str, Any] = dict(
                chat_template=_chat_template,
                add_generation_prompt=True,
                tools=tools_dict,
            )
            _chat_template_kwargs.update(request.chat_template_kwargs or {})

            engine_prompt: SingletonPrompt
            if self.use_harmony:
                (
                    _,
                    _,
                    tokens_prompts,
                ) = self._make_request_with_harmony(request)
                engine_prompt = tokens_prompts[0]
                prompt_token_len = len(engine_prompt["prompt_token_ids"])
            else:
                _, _, tokens_prompts = await preprocess_chat(
                    request=request,
                    tokenizer=self.tokenizer,
                    messages=request.messages,  # type: ignore
                    chat_template=_chat_template_kwargs.pop("chat_template", None),
                    chat_template_content_format=self.chat_template_content_format,
                    model_config=self.model_config_adapter,
                    add_generation_prompt=_chat_template_kwargs.pop("add_generation_prompt", True),
                    tool_dicts=_chat_template_kwargs.pop("tools", None),
                    chat_template_kwargs=_chat_template_kwargs,
                    tool_parser=self.tool_parser if self.enable_auto_tools else None,
                )
                engine_prompt = tokens_prompts[0]
                prompt_token_len = len(engine_prompt["prompt_token_ids"])
        except Exception as e:
            logger.error("Error in applying chat template from request: %s", e)
            return self.create_error_response(str(e))

        try:
            sampling_params = request.to_sampling_params(self.default_sampling_params)
            # XXX(n0gu):
            # We call .encode() here even though it will be called again in AsyncLLMEngine.generate().
            # This is because passing pre-encoded tokens (List[int]) to generate() results in higher latency (!)
            # due to issue in .decode() (https://github.com/huggingface/transformers/issues/36872).
            # So passing the raw string is currently optimal.
            if prompt_token_len > self.async_llm_engine.prompt_max_seq_len:
                raise ValueError(
                    f"This model's maximum input context length is {self.async_llm_engine.prompt_max_seq_len} tokens."
                    f" However, your messages resulted in {prompt_token_len} tokens."
                    " Please reduce the length of the messages."
                )

            # Update structured outputs if reasoning is enabled
            if self.reasoning_parser is not None:
                try:
                    reasoning_parser = self.reasoning_parser(self.tokenizer)  # type: ignore
                except RuntimeError as e:
                    logger.exception("Error in reasoning parser creation.")
                    return self.create_error_response(str(e))

                # XXX(n0gu): Since some models allow reasoning to be toggled per request,
                # (e.g. `enable_thinking` parameter of Exaone4)
                # we have to check if reasoning is enabled at the prompt level.
                reasoning_enabled = reasoning_parser.is_reasoning_open(
                    engine_prompt["prompt_token_ids"]
                )
                if reasoning_enabled and sampling_params.structured_outputs_enabled():
                    assert sampling_params.structured_outputs is not None
                    # TODO: implement backend selection when xgrammar is supported.
                    reasoning_grammar = reasoning_parser.to_guided_grammar("auto")
                    sampling_params.structured_outputs.reasoning_grammar = reasoning_grammar

        except ValueError as e:
            return self.create_error_response(str(e))

        request_id = f"chat-{random_uuid()}"
        created_time = int(time.time())

        stream = (
            request.stream
            and (request.best_of is None or request.n == request.best_of)
            and not request.use_beam_search
        )
        if stream:
            sampling_params.output_kind = RequestOutputKind.DELTA
            result_generator = self.async_llm_engine.generate(
                engine_prompt, sampling_params, request_id
            )
            asyncio.create_task(
                handle_disconnect(raw_request, lambda: self._abort_request(request_id))
            )
            return self.chat_completion_stream_generator(
                request,
                result_generator,
                request_id,
                created_time,
            )

        try:
            sampling_params.output_kind = RequestOutputKind.FINAL
            result_generator = self.async_llm_engine.generate(
                engine_prompt, sampling_params, request_id
            )
            asyncio.create_task(
                handle_disconnect(raw_request, lambda: self._abort_request(request_id))
            )

            return await self.chat_completion_full_generator(
                request,
                result_generator,
                request_id,
                created_time,
            )
        except ValueError as e:
            # TODO(vllm): Use a vllm-specific Validation Error
            return self.create_error_response(str(e))

    async def chat_completion_stream_generator(
        self,
        request: ChatCompletionRequest,
        result_generator: AsyncIterator[RequestOutput],
        request_id: str,
        created_time: int,
    ) -> AsyncGenerator[str, None]:
        chunk_object_type: Final = "chat.completion.chunk"

        num_choices = 1 if request.n is None else request.n
        previous_num_tokens = [0] * num_choices
        finish_reason_sent = [False] * num_choices
        reasoning_full_text = [""] * num_choices
        usage_prompt_tokens = 0
        usage_completion_tokens = 0
        usage_completion_tokens_reasoning = 0
        usage_cached_prompt_tokens = 0
        include_stream_usage = request.stream_options and request.stream_options.include_usage

        if self.use_harmony:
            harmony_parsers = [get_streamable_parser_for_assistant() for _ in range(num_choices)]
            harmony_tools_streamed = [False] * num_choices

        # If there's explicit enable_thinking in request, use it.
        enable_thinking = False
        if request.chat_template_kwargs and "enable_thinking" in request.chat_template_kwargs:
            enable_thinking = request.chat_template_kwargs["enable_thinking"]

        reasoning_enabled = self.reasoning_parser is not None
        auto_tools_enabled = bool(self.enable_auto_tools and self.tool_parser)
        is_named_tool_call = isinstance(request.tool_choice, ChatCompletionNamedToolChoiceParam)
        is_tool_choice_required = request.tool_choice == "required"
        is_tool_choice_auto = request.tool_choice in ["auto", None]

        # Determine whether tools are in use with "auto" tool choice
        should_stream_with_auto_tool_parsing = (
            is_tool_choice_auto and auto_tools_enabled and request.tools
        )

        all_previous_token_ids: Optional[List[List[int]]]
        function_name_returned = [False] * num_choices

        # Always track previous_texts for comprehensive output logging
        previous_texts = [""] * num_choices

        # Only one of these will be used, thus previous_texts and
        # all_previous_token_ids will not be used twice in the same iteration.
        if should_stream_with_auto_tool_parsing or reasoning_enabled:
            # These are only required in "auto" tool choice case
            all_previous_token_ids = [[]] * num_choices
            # For reasoning parser and tool call all enabled
            added_content_delta_arr = [False] * num_choices
            reasoning_end_arr = [False] * num_choices
        else:
            all_previous_token_ids = None

        if reasoning_enabled:
            try:
                reasoning_parser = self.reasoning_parser(self.tokenizer)  # type: ignore
            except RuntimeError as e:
                logger.exception("Error in reasoning parser creation.")
                data = self.create_streaming_error_response(str(e))
                yield f"data: {data}\n\n"
                yield "data: [DONE]\n\n"
                return

        # Prepare the tool parser if it's needed
        try:
            if should_stream_with_auto_tool_parsing:
                assert self.tool_parser is not None
                tool_parsers: List[Optional[ToolParser]] = [
                    self.tool_parser(self.tokenizer)
                ] * num_choices
            else:
                tool_parsers = [None] * num_choices
        except Exception as e:
            logger.exception("Error in tool parser creation.")
            data = self.create_streaming_error_response(str(e))
            yield f"data: {data}\n\n"

            yield "data: [DONE]\n\n"
            return

        first_iteration = True
        try:
            async for res in result_generator:
                if res.finished:
                    usage_cached_prompt_tokens = res.num_cached_tokens
                if first_iteration:
                    len_prompt_tokens = len(res.prompt_token_ids)
                    usage_prompt_tokens = len_prompt_tokens
                    role = self.get_chat_request_role(request)
                    for i in range(num_choices):
                        choice_data = ChatCompletionResponseStreamChoice(
                            index=i,
                            delta=DeltaMessage(
                                role=role,
                                content="",
                            ),
                            logprobs=None,
                            finish_reason=None,
                            token_ids=None,
                        )
                        chunk = ChatCompletionStreamResponse(
                            id=request_id,
                            object=chunk_object_type,
                            created=created_time,
                            choices=[choice_data],
                            model=self.model_name,
                            prompt_token_ids=(
                                res.prompt_token_ids if request.return_token_ids else None
                            ),
                        )

                        data = chunk.model_dump_json(exclude_unset=True)
                        yield f"data: {data}\n\n"
                    first_iteration = False

                for output in res.outputs:
                    len_completion_tokens = len(output.token_ids)
                    usage_completion_tokens += len_completion_tokens
                    i = output.index
                    tool_parser = tool_parsers[i]

                    if finish_reason_sent[i]:
                        continue

                    if request.logprobs and request.top_logprobs is not None:
                        assert output.logprobs is not None, "Did not output logprobs"
                        return_as_token_id = (
                            request.return_tokens_as_token_ids is not None
                            and request.return_tokens_as_token_ids
                        )
                        for token_id_to_logprob in output.logprobs:
                            for token_id, logprob in token_id_to_logprob.items():
                                logprob.decoded_token = self._get_decoded_token(
                                    logprob,
                                    token_id,
                                    self.tokenizer,
                                    return_as_token_id=return_as_token_id,
                                )
                        logprobs = self._create_chat_logprobs(
                            token_ids=output.token_ids,
                            top_logprobs=output.logprobs,
                            tokenizer=self.tokenizer,
                            num_output_top_logprobs=request.top_logprobs,
                            return_as_token_id=request.return_tokens_as_token_ids,
                        )
                    else:
                        logprobs = None

                    if self.use_harmony:
                        harmony_parser = harmony_parsers[i]
                        prev_recipient = harmony_parser.current_recipient
                        for token_id in output.token_ids:
                            harmony_parser.process(token_id)
                        cur_channel = harmony_parser.current_channel
                        cur_recipient = harmony_parser.current_recipient
                        if output.token_ids:
                            delta_text = harmony_parser.last_content_delta or ""
                        else:
                            delta_text = ""
                    else:
                        delta_text = output.text

                    if not delta_text and not output.token_ids and not previous_num_tokens[i]:
                        # Chunked prefill case, don't return empty chunks
                        continue

                    delta_message: Optional[DeltaMessage]

                    # just update current_text and current_token_ids
                    if should_stream_with_auto_tool_parsing or reasoning_enabled:
                        assert previous_texts is not None
                        assert all_previous_token_ids is not None
                        previous_text = previous_texts[i]
                        previous_token_ids = all_previous_token_ids[i]
                        current_text = previous_text + delta_text
                        current_token_ids = previous_token_ids + list(output.token_ids)

                    if self.use_harmony:
                        if cur_channel == "final":
                            delta_message = DeltaMessage(content=delta_text)
                        elif cur_channel == "analysis":
                            delta_message = DeltaMessage(reasoning=delta_text)
                            reasoning_full_text[i] += delta_text
                        elif (
                            cur_channel == "commentary"
                            and cur_recipient
                            and cur_recipient.startswith("functions.")
                        ):
                            # Count completed tool calls to determine index
                            base_index = 0
                            for msg in harmony_parser.messages:
                                if (
                                    msg.channel == "commentary"
                                    and msg.recipient
                                    and msg.recipient.startswith("functions.")
                                ):
                                    base_index += 1

                            if prev_recipient != cur_recipient:
                                tool_name = cur_recipient.split("functions.", 1)[1]
                                delta_message = DeltaMessage(
                                    tool_calls=[
                                        DeltaToolCall(
                                            id=random_tool_call_id(),
                                            type="function",
                                            function=DeltaFunctionCall(
                                                name=tool_name,
                                                arguments="",
                                            ),
                                            index=base_index,
                                        )
                                    ]
                                )
                            elif delta_text:
                                delta_message = DeltaMessage(
                                    tool_calls=[
                                        DeltaToolCall(
                                            index=base_index,
                                            function=DeltaFunctionCall(arguments=delta_text),
                                        )
                                    ]
                                )
                            else:
                                delta_message = None

                            if delta_message is not None:
                                harmony_tools_streamed[i] = True
                        else:
                            delta_message = None

                    # handle streaming deltas for tools with named tool_choice
                    elif is_named_tool_call:
                        # XXX(n0gu): as of release 2025.03, no model supports both tool calling and reasoning.
                        # Therefore this branch will not be tested until a model supports both.
                        if (
                            reasoning_enabled
                            and not reasoning_end_arr[i]
                            and not reasoning_parser.is_reasoning_end(previous_token_ids)
                        ):
                            delta_message = reasoning_parser.extract_reasoning_content_streaming(
                                previous_text,
                                current_text,
                                delta_text,
                                previous_token_ids,
                                current_token_ids,
                                output.token_ids,
                                enable_thinking=enable_thinking,
                            )
                            # When encountering think end id in delta_token_ids
                            # or think end id in prompt_token_ids i.e {"enable_thinking": False},
                            # set reasoning status to end.
                            # Only keep 'content', remove 'reasoning'.
                            if reasoning_parser.is_reasoning_end(output.token_ids) or (
                                res.prompt_token_ids
                                and reasoning_parser.is_reasoning_end(res.prompt_token_ids)
                            ):
                                reasoning_end_arr[i] = True
                                if delta_message and delta_message.content:
                                    # This need to be added to next `delta_text`
                                    current_text = delta_message.content
                                    delta_message.content = None
                                else:
                                    current_text = ""
                        else:
                            # Just to add remaining `content`
                            if reasoning_enabled:
                                delta_text = previous_text + delta_text
                                current_text = ""

                            if function_name_returned[i]:
                                delta_tool_call = DeltaToolCall(
                                    index=i, function=DeltaFunctionCall(arguments=delta_text)
                                )
                            else:
                                delta_tool_call = DeltaToolCall(
                                    id=random_tool_call_id(),
                                    type="function",
                                    index=i,
                                    function=DeltaFunctionCall(
                                        name=request.tool_choice.function.name, arguments=delta_text  # type: ignore
                                    ),
                                )
                                function_name_returned[i] = True

                            delta_message = DeltaMessage(
                                tool_calls=[
                                    delta_tool_call,
                                ]
                            )

                    elif is_tool_choice_required:
                        assert previous_texts is not None
                        previous_text = previous_texts[i]
                        current_text = previous_text + delta_text
                        fn_name_returned = function_name_returned[i]

                        # XXX(n0gu): ditto (untested until a model supports both tool calling and reasoning)
                        if reasoning_enabled:
                            _, content = reasoning_parser.extract_reasoning_content(
                                current_text, request
                            )
                        else:
                            content = current_text
                        delta_message, function_name_returned[i] = (
                            self.extract_tool_call_required_streaming(
                                previous_text=previous_text,
                                current_text=content,
                                delta_text=delta_text,
                                function_name_returned=fn_name_returned,
                            )
                        )

                    # XXX(n0gu): ditto (untested until a model supports both tool calling and reasoning)
                    elif should_stream_with_auto_tool_parsing and reasoning_enabled:
                        assert tool_parser is not None
                        assert reasoning_parser is not None
                        assert added_content_delta_arr is not None
                        assert reasoning_end_arr is not None
                        output_token_ids = list(output.token_ids)
                        if not reasoning_end_arr[i]:
                            delta_message = reasoning_parser.extract_reasoning_content_streaming(
                                previous_text,
                                current_text,
                                delta_text,
                                previous_token_ids,
                                current_token_ids,
                                output_token_ids,
                                enable_thinking=enable_thinking,
                            )
                            # When encountering think end id in prompt_token_ids
                            # i.e {"enable_thinking": False},
                            # set reasoning status to end.
                            # Remove the text and token ids related
                            # to 'reasoning'.
                            if res.prompt_token_ids and reasoning_parser.is_reasoning_end(
                                res.prompt_token_ids
                            ):
                                reasoning_end_arr[i] = True
                                current_token_ids = output_token_ids
                                if delta_message and delta_message.content:
                                    current_text = delta_message.content
                                    delta_message.content = None
                                else:
                                    current_text = ""
                            # When encountering think end id in delta_token_ids,
                            # set reasoning status to end.
                            # Remove the text and token ids related
                            # to 'reasoning'.
                            if reasoning_parser.is_reasoning_end(output_token_ids):
                                reasoning_end_arr[i] = True
                                current_token_ids = reasoning_parser.extract_content_ids(
                                    output_token_ids
                                )
                                if delta_message and delta_message.content:
                                    current_text = delta_message.content
                                    delta_message.content = None
                                else:
                                    current_text = ""

                        # handle tool calls only after reasoning is done,
                        else:
                            delta_token_ids = output_token_ids
                            # First time to tool call,
                            # add the remaining text and token ids
                            # to delta from previous
                            if not added_content_delta_arr[i]:
                                added_content_delta_arr[i] = True
                                previous_text = ""
                                previous_token_ids = []
                                delta_text = current_text
                                delta_token_ids = current_token_ids

                            delta_message = tool_parser.extract_tool_calls_streaming(
                                previous_text=previous_text,
                                current_text=current_text,
                                delta_text=delta_text,
                                previous_token_ids=previous_token_ids,
                                current_token_ids=current_token_ids,
                                delta_token_ids=delta_token_ids,
                                request=request,
                            )

                    # when only tool calls
                    elif should_stream_with_auto_tool_parsing:
                        assert tool_parser is not None
                        delta_message = tool_parser.extract_tool_calls_streaming(
                            previous_text=previous_text,
                            current_text=current_text,
                            delta_text=delta_text,
                            previous_token_ids=previous_token_ids,
                            current_token_ids=current_token_ids,
                            delta_token_ids=output.token_ids,
                            request=request,
                        )

                    # when only reasoning
                    elif reasoning_enabled:
                        delta_message = reasoning_parser.extract_reasoning_content_streaming(
                            previous_text,
                            current_text,
                            delta_text,
                            previous_token_ids,
                            current_token_ids,
                            output.token_ids,
                            enable_thinking=enable_thinking,
                        )
                        if delta_message is not None and delta_message.reasoning:
                            reasoning_full_text[i] += delta_message.reasoning

                    # handle streaming just a content delta
                    else:
                        delta_message = DeltaMessage(content=delta_text)

                    # update the previous values for the next iteration
                    if (
                        should_stream_with_auto_tool_parsing or reasoning_enabled
                    ) and not self.use_harmony:
                        assert previous_texts is not None
                        assert all_previous_token_ids is not None
                        previous_texts[i] = current_text
                        all_previous_token_ids[i] = current_token_ids
                    else:
                        # Update for comprehensive logging even in simple case
                        assert previous_texts is not None
                        previous_texts[i] += delta_text

                    # set the previous values for the next iteration
                    previous_num_tokens[i] += len(output.token_ids)

                    if delta_message is None:
                        # if the message delta is None (e.g. because it was a
                        # "control token" for tool calls or the parser otherwise
                        # wasn't ready to send a token, then
                        #   get the next token without streaming a chunk
                        if output.finish_reason is None:
                            continue
                        else:
                            # Handle streaming of content-only delta messages
                            # Following OpenAI's convention: when the delta contains no content and only includes
                            # a finish reason, return an empty delta object that serializes to {"delta": {}}
                            delta_message = DeltaMessage()

                    if output.finish_reason is None:
                        # Send token-by-token response for each request.n
                        choice_data = ChatCompletionResponseStreamChoice(
                            index=i,
                            delta=delta_message,
                            logprobs=logprobs,
                            finish_reason=None,
                            token_ids=output.token_ids if request.return_token_ids else None,
                        )

                    # if the model is finished generating
                    else:
                        # check to make sure we haven't "forgotten" to stream
                        #   any tokens that were generated but previously
                        #   matched by partial json parsing
                        # only happens if we are NOT using structured outputs
                        auto_tools_called = False
                        if tool_parser:
                            auto_tools_called = len(tool_parser.prev_tool_call_arr) > 0
                            index = (
                                len(tool_parser.prev_tool_call_arr) - 1 if auto_tools_called else 0
                            )
                        else:
                            index = 0

                        if (
                            self._should_check_for_unstreamed_tool_arg_tokens(delta_message, output)
                            and tool_parser
                        ):
                            latest_delta_len = 0
                            if (
                                isinstance(delta_message.tool_calls[0].function, DeltaFunctionCall)
                            ) and isinstance(delta_message.tool_calls[0].function.arguments, str):
                                latest_delta_len = len(
                                    delta_message.tool_calls[0].function.arguments
                                )

                            # get the expected call based on partial JSON
                            # parsing which "autocompletes" the JSON
                            expected_call = json.dumps(
                                tool_parser.prev_tool_call_arr[index].get("arguments", {}),
                                ensure_ascii=False,
                            )

                            # get what we've streamed so far for arguments
                            # for the current tool
                            actual_call = tool_parser.streamed_args_for_tool[index]
                            if latest_delta_len > 0:
                                actual_call = actual_call[:-latest_delta_len]

                            # check to see if there's anything left to stream
                            remaining_call = expected_call.replace(actual_call, "", 1)
                            # set that as a delta message
                            delta_message = DeltaMessage(
                                tool_calls=[
                                    DeltaToolCall(
                                        index=index,
                                        function=DeltaFunctionCall(arguments=remaining_call),
                                    )
                                ]
                            )

                        is_finish_reason_tool_calls = (
                            auto_tools_called
                            or (is_tool_choice_required and output.finish_reason == "stop")
                            or (self.use_harmony and harmony_tools_streamed[i])
                        )

                        # Send the finish response for each request.n only once
                        choice_data = ChatCompletionResponseStreamChoice(
                            index=i,
                            delta=delta_message,
                            logprobs=logprobs,
                            finish_reason=(
                                "tool_calls"
                                if is_finish_reason_tool_calls
                                else output.finish_reason
                            ),
                            token_ids=output.token_ids if request.return_token_ids else None,
                        )

                        finish_reason_sent[i] = True
                        if reasoning_full_text[i]:
                            len_completion_tokens_reasoning = len(
                                self.tokenizer.encode(
                                    reasoning_full_text[i], add_special_tokens=False
                                )
                            )
                            usage_completion_tokens_reasoning += len_completion_tokens_reasoning

                    chunk = ChatCompletionStreamResponse(
                        id=request_id,
                        object=chunk_object_type,
                        created=created_time,
                        choices=[choice_data],
                        model=self.model_name,
                    )

                    data = chunk.model_dump_json(exclude_unset=True)
                    yield f"data: {data}\n\n"

        except ValueError as e:
            # TODO(vllm): Use a vllm-specific Validation Error
            data = self.create_streaming_error_response(str(e))
            yield f"data: {data}\n\n"
        except Exception as e:
            logger.error("Error in chat completion stream: %s", e, exc_info=True)
            data = self.create_streaming_error_response(
                "internal server error",
                err_type="InternalServerError",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
            yield f"data: {data}\n\n"

        if include_stream_usage:
            # Send the final usage message after all response.n are finished
            usage = UsageInfo(
                prompt_tokens=usage_prompt_tokens,
                completion_tokens=usage_completion_tokens,
                total_tokens=usage_prompt_tokens + usage_completion_tokens,
                prompt_tokens_details=PromptTokensDetails(
                    cached_tokens=usage_cached_prompt_tokens, audio_tokens=0
                ),
                completion_tokens_details=CompletionTokenUsageInfo(
                    accepted_prediction_tokens=0,
                    audio_tokens=0,
                    reasoning_tokens=usage_completion_tokens_reasoning,
                    rejected_prediction_tokens=0,
                ),
            )
            chunk = ChatCompletionStreamResponse(
                id=request_id,
                object="chat.completion.chunk",
                created=created_time,
                choices=[],
                model=self.model_name,
                usage=usage,
            )
            data = chunk.model_dump_json(exclude_unset=True)
            yield f"data: {data}\n\n"

        # Send the final done message after all response.n are finished
        yield "data: [DONE]\n\n"

    def extract_tool_call_required_streaming(
        self,
        previous_text: str,
        current_text: Optional[str],
        delta_text: str,
        function_name_returned: bool,
    ) -> tuple[Optional[DeltaMessage], bool]:
        if current_text is None or current_text == "":
            # if the current text is empty, we cannot parse it
            return None, function_name_returned
        try:
            obj = partial_json_parser.loads(current_text)
        except partial_json_parser.core.exceptions.MalformedJSON:
            logger.debug('not enough tokens to parse into JSON yet')
            obj = None

        # check if the current text is a valid array
        # containing a partial tool calling object
        # if not repeat
        if obj is None or not isinstance(obj, list) or not len(obj) > 0:
            function_name_returned = False
            delta_message = None
        else:
            _, finishes_previous_tool = OpenAIServingChat._filter_delta_text(
                delta_text, previous_text
            )
            # take the last tool call from the generated list
            current_tool_call = obj[-1]

            # once parameters have been generated the name is complete as well
            if not finishes_previous_tool and (
                "name" not in current_tool_call or "parameters" not in current_tool_call
            ):
                function_name_returned = False
                delta_message = None
            else:
                if not function_name_returned:
                    # get partly generated arguments from the latest tool call
                    param_match = re.search(r'.*"parameters":\s*(.*)', current_text)
                    arguments = param_match.group(1) if param_match else ""
                    arguments, _ = OpenAIServingChat._filter_delta_text(arguments, previous_text)

                    # if this iteration finishes a previous tool call but a
                    # new incomplete tool is already generated, take the
                    # previous from the list
                    if finishes_previous_tool and "parameters" not in current_tool_call:
                        current_tool_call = obj[-2]

                    function_name_returned = True
                    delta_message = DeltaMessage(
                        tool_calls=[
                            DeltaToolCall(
                                id=random_tool_call_id(),
                                function=DeltaFunctionCall(
                                    name=current_tool_call["name"], arguments=arguments
                                ),
                                index=len(obj) - 1,
                                type="function",
                            )
                        ]
                    )

                else:
                    delta_text, _ = OpenAIServingChat._filter_delta_text(delta_text, previous_text)

                    if delta_text != "":
                        delta_message = DeltaMessage(
                            tool_calls=[
                                DeltaToolCall(
                                    function=DeltaFunctionCall(
                                        # OpenAI API returns None
                                        # instead of name every time
                                        name=None,
                                        arguments=delta_text,
                                    ),
                                    index=len(obj) - 1,
                                )
                            ]
                        )
                    else:
                        delta_message = None

        return delta_message, function_name_returned

    @staticmethod
    def _filter_delta_text(delta_text: str, previous_text: str) -> tuple[str, bool]:
        # remove last '},' of the tool definition stemming from the
        # "name"/"parameters" outer object or closing ']' of the tool list
        # count occurrences of opening and closing curly braces and
        # once level 0 is reached stop outputting text
        # if 0 is reached while parsing the delta_text we know the current
        # tool will finish in this current iteration
        bracket_level = OpenAIServingChat._bracket_level(previous_text)
        updated_delta, passed_zero = "", False
        for c in delta_text:
            if c == '{':
                bracket_level += 1
                passed_zero = bracket_level == 0
            elif c == '}':
                bracket_level -= 1
                passed_zero = bracket_level == 0

            if bracket_level != 0:
                updated_delta += c
            else:
                # if a comma is reached at level 0 we can stop
                if c == ',':
                    break
        return updated_delta, passed_zero

    @staticmethod
    def _bracket_level(s: str, opening='{', closing='}') -> int:
        """
        Calculate the current level of nested brackets in a given string.
        """
        level = 0
        for char in s:
            if char == opening:
                level += 1
            elif char == closing:
                level -= 1
        return level

    async def chat_completion_full_generator(
        self,
        request: ChatCompletionRequest,
        result_generator: AsyncIterator[RequestOutput],
        request_id: str,
        created_time: int,
    ) -> Union[ErrorResponse, ChatCompletionResponse]:
        role = self.get_chat_request_role(request)

        choices: List[ChatCompletionResponseChoice] = []

        result = None
        async for result in result_generator:
            # only get the last `result`
            continue
        if result is None:
            return self.create_error_response("No result from model")

        len_prompt_tokens = len(result.prompt_token_ids)
        usage_prompt_tokens = len_prompt_tokens
        usage_cached_prompt_tokens = result.num_cached_tokens
        usage_completion_tokens = 0
        usage_completion_tokens_reasoning = 0

        reasoning_enabled = self.reasoning_parser is not None
        auto_tools_enabled = bool(self.enable_auto_tools and self.tool_parser)
        is_named_tool_call = isinstance(request.tool_choice, ChatCompletionNamedToolChoiceParam)
        is_tool_choice_required = request.tool_choice == "required"
        is_tool_choice_auto = request.tool_choice in ["auto", None]

        for output in result.outputs:
            token_ids = output.token_ids
            out_logprobs = output.logprobs
            if request.logprobs and request.top_logprobs is not None:
                assert out_logprobs is not None, "Did not output logprobs"
                return_as_token_id = (
                    request.return_tokens_as_token_ids is not None
                    and request.return_tokens_as_token_ids
                )
                for token_id_to_logprob in out_logprobs:
                    for token_id, logprob in token_id_to_logprob.items():
                        logprob.decoded_token = self._get_decoded_token(
                            logprob, token_id, self.tokenizer, return_as_token_id=return_as_token_id
                        )
                logprobs = self._create_chat_logprobs(
                    token_ids=token_ids,
                    top_logprobs=out_logprobs,
                    tokenizer=self.tokenizer,
                    num_output_top_logprobs=request.top_logprobs,
                    return_as_token_id=request.return_tokens_as_token_ids,
                )
            else:
                logprobs = None

            len_completion_tokens = len(token_ids)
            usage_completion_tokens += len_completion_tokens

            if self.use_harmony:
                reasoning_content, final_content, _ = parse_chat_output(token_ids)
                tool_call_info = None
                if self.tool_parser is not None:
                    tool_parser = self.tool_parser(self.tokenizer)
                    # NOTE: We use token_ids for openai tool parser
                    tool_call_info = tool_parser.extract_tool_calls(
                        "",
                        request=request,
                        token_ids=token_ids,  # type: ignore
                    )
                    content = tool_call_info.content
                    message = ChatMessage(
                        role=role,
                        reasoning=reasoning_content,
                        content=content,
                        tool_calls=tool_call_info.tool_calls,
                    )
                else:
                    # Normal message
                    message = ChatMessage(
                        role=role,
                        reasoning=reasoning_content,
                        content=final_content,
                    )
                if reasoning_content:
                    usage_completion_tokens_reasoning += len(
                        self.tokenizer.encode(reasoning_content, add_special_tokens=False)
                    )

                choice_data = ChatCompletionResponseChoice(
                    index=output.index,
                    message=message,
                    logprobs=logprobs,
                    finish_reason=(
                        "tool_calls"
                        if (tool_call_info is not None and tool_call_info.tools_called)
                        else output.finish_reason if output.finish_reason else "stop"
                    ),
                    token_ids=output.token_ids if request.return_token_ids else None,
                )
                choices.append(choice_data)
                continue

            if reasoning_enabled:
                try:
                    reasoning_parser = self.reasoning_parser(self.tokenizer)  # type: ignore
                except RuntimeError as e:
                    logger.exception("Error in reasoning parser creation.")
                    return self.create_error_response(str(e))

                reasoning_content, content = reasoning_parser.extract_reasoning_content(
                    output.text, request=request
                )
                if reasoning_content:
                    len_completion_tokens_reasoning = len(
                        self.tokenizer.encode(reasoning_content, add_special_tokens=False)
                    )
                    usage_completion_tokens_reasoning += len_completion_tokens_reasoning
                    message = ChatMessage(role=role, content=content, reasoning=reasoning_content)
                else:
                    message = ChatMessage(role=role, content=output.text)
            else:
                reasoning_content, content = None, output.text

            auto_tools_called = False
            # if auto tools are not enabled, and a named tool choice using
            #   outlines is not being used
            if not auto_tools_enabled and not is_named_tool_call and not is_tool_choice_required:
                message = ChatMessage(role=role, reasoning=reasoning_content, content=content)

            # if the request uses tools and specified a tool choice
            elif is_named_tool_call:
                message = ChatMessage(
                    role=role,
                    reasoning=reasoning_content,
                    content="",
                    tool_calls=[
                        ToolCall(
                            function=FunctionCall(
                                name=request.tool_choice.function.name,  # type: ignore
                                arguments=content or "",
                            )
                        )
                    ],
                )

            # if the request requires tool choice
            elif is_tool_choice_required:
                # TODO: handle metrics for request failure
                assert content is not None
                tool_calls = TypeAdapter(list[FunctionDefinition]).validate_json(content)

                message = ChatMessage(
                    role=role,
                    content="",
                    reasoning=reasoning_content,
                    tool_calls=[
                        ToolCall(
                            function=FunctionCall(
                                name=tool_call.name,
                                arguments=json.dumps(tool_call.parameters, ensure_ascii=False),
                            )
                        )
                        for tool_call in tool_calls
                    ],
                )

            # if the request doesn't use tool choice
            # OR specifies to not use a tool
            elif not request.tool_choice or request.tool_choice == "none":
                message = ChatMessage(role=role, reasoning=reasoning_content, content=content)

            # handle when there are tools and tool choice is auto
            elif is_tool_choice_auto and auto_tools_enabled and request.tools:
                assert self.tool_parser is not None
                try:
                    tool_parser = self.tool_parser(self.tokenizer)
                except RuntimeError as e:
                    logger.exception("Error in tool parser creation.")
                    return self.create_error_response(str(e))

                tool_call_info = tool_parser.extract_tool_calls(content or "", request=request)
                # In the OpenAI API the finish_reason is "tools_called"
                # if the tool choice is auto and the model produced a tool
                # call. The same is not true for named function calls
                auto_tools_called = tool_call_info.tools_called
                if auto_tools_called:
                    message = ChatMessage(
                        role=role,
                        reasoning=reasoning_content,
                        content=tool_call_info.content,
                        tool_calls=tool_call_info.tool_calls,
                    )
                else:
                    # FOR NOW make it a chat message; we will have to detect
                    # the type to make it later.
                    ret_content = content

                    # try to use content return from tool parser first,
                    # tool parser may do some modify for the content.
                    if tool_call_info.content and len(tool_call_info.content) > 0:
                        ret_content = tool_call_info.content

                    message = ChatMessage(
                        role=role, reasoning=reasoning_content, content=ret_content
                    )

            else:
                logger.error(
                    "Error in chat_completion_full_generator - cannot determine "
                    "if tools should be extracted. Returning a standard chat "
                    "completion. Perhaps --enable-auto-tool-choice is not set?"
                )
                message = ChatMessage(role=role, reasoning=reasoning_content, content=content)

            is_finish_reason_tool_calls = auto_tools_called or (
                is_tool_choice_required and output.finish_reason == "stop"
            )
            choice_data = ChatCompletionResponseChoice(
                index=output.index,
                message=message,
                logprobs=logprobs,
                finish_reason=(
                    "tool_calls"
                    if is_finish_reason_tool_calls
                    else (output.finish_reason or "stop")
                ),
                token_ids=output.token_ids if request.return_token_ids else None,
            )
            choices.append(choice_data)

        usage = UsageInfo(
            prompt_tokens=usage_prompt_tokens,
            completion_tokens=usage_completion_tokens,
            total_tokens=usage_prompt_tokens + usage_completion_tokens,
            prompt_tokens_details=PromptTokensDetails(
                cached_tokens=usage_cached_prompt_tokens,
                audio_tokens=0,
            ),
            completion_tokens_details=CompletionTokenUsageInfo(
                accepted_prediction_tokens=0,
                audio_tokens=0,
                reasoning_tokens=usage_completion_tokens_reasoning,
                rejected_prediction_tokens=0,
            ),
        )
        response = ChatCompletionResponse(
            id=request_id,
            created=created_time,
            model=self.model_name,
            choices=choices,
            usage=usage,
            # https://community.openai.com/t/logprob-of-the-prompt/2795/3
            # https://github.com/vllm-project/vllm/pull/7453
            prompt_logprobs=clamp_prompt_logprobs(result.prompt_logprobs),
            prompt_token_ids=result.prompt_token_ids if request.return_token_ids else None,
        )

        return response

    def get_chat_request_role(self, request: ChatCompletionRequest) -> str:
        if request.add_generation_prompt:
            return self.response_role
        else:
            return request.messages[-1]["role"]

    # Based on https://github.com/vllm-project/vllm/blob/v0.8.3/vllm/entrypoints/openai/serving_chat.py#L1100-L1115.
    def _get_top_logprobs(
        self,
        logprobs: dict[int, Logprob],
        top_logprobs: Optional[int],
        tokenizer: AnyTokenizer,
        should_return_as_token_id: bool,
    ) -> list[ChatCompletionLogProb]:
        return [
            ChatCompletionLogProb(
                token=(
                    token := self._get_decoded_token(
                        p[1], p[0], tokenizer, return_as_token_id=should_return_as_token_id
                    )
                ),
                logprob=max(p[1].logprob, MIN_LOGPROB_FOR_JSON),
                bytes=list(token.encode("utf-8", errors="replace")),
            )
            for i, p in enumerate(logprobs.items())
            if top_logprobs and i < top_logprobs
        ]

    # Based on https://github.com/vllm-project/vllm/blob/v0.8.3/vllm/entrypoints/openai/serving_chat.py#L1117-L1162.
    def _create_chat_logprobs(
        self,
        token_ids: Sequence[int],
        top_logprobs: Sequence[Optional[dict[int, Logprob]]],
        tokenizer: AnyTokenizer,
        num_output_top_logprobs: Optional[int] = None,
        return_as_token_id: Optional[bool] = None,
    ) -> ChatCompletionLogProbs:
        """Create OpenAI-style logprobs."""
        logprobs_content: list[ChatCompletionLogProbsContent] = []

        if return_as_token_id is None:
            return_as_token_id = self.return_tokens_as_token_ids
        for i, token_id in enumerate(token_ids):
            step_top_logprobs = top_logprobs[i]
            if step_top_logprobs is None:
                token = f"token_id:{token_id}" if return_as_token_id else tokenizer.decode(token_id)

                logprobs_content.append(
                    ChatCompletionLogProbsContent(
                        token=token,
                        bytes=list(token.encode("utf-8", errors="replace")),
                    )
                )
            else:
                step_token = step_top_logprobs[token_id]
                step_decoded = step_token.decoded_token

                logprobs_content.append(
                    ChatCompletionLogProbsContent(
                        token=self._get_decoded_token(
                            step_token, token_id, tokenizer, return_as_token_id
                        ),
                        logprob=max(step_token.logprob, -9999.0),
                        bytes=(
                            None
                            if step_decoded is None
                            else list(step_decoded.encode("utf-8", errors="replace"))
                        ),
                        top_logprobs=self._get_top_logprobs(
                            step_top_logprobs,
                            num_output_top_logprobs,
                            tokenizer,
                            return_as_token_id,
                        ),
                    )
                )
        return ChatCompletionLogProbs(content=logprobs_content)

    def _should_check_for_unstreamed_tool_arg_tokens(
        self,
        delta_message: Optional[DeltaMessage],
        output: CompletionOutput,
    ) -> bool:
        """
        Check to see if we should check for unstreamed tool arguments tokens.
        This is only applicable when auto tool parsing is enabled, the delta
        is a tool call with arguments.
        """

        # yapf: disable
        return bool(
            # if there is a delta message that includes tool calls which
            # include a function that has arguments
            output.finish_reason is not None
            and self.enable_auto_tools
            and self.tool_parser
            and delta_message
            and delta_message.tool_calls
            and delta_message.tool_calls[0]
            and delta_message.tool_calls[0].function
            and delta_message.tool_calls[0].function.arguments is not None
        )

    async def _abort_request(self, request_id: str) -> None:
        await self.async_llm_engine.abort(request_id)

    def _make_request_with_harmony(
        self,
        request: ChatCompletionRequest,
    ) -> tuple[list[OpenAIMessage], list[list[int]], list[TokensPrompt]]:
        messages: list[OpenAIMessage] = []

        # Add system message.
        # NOTE: In Chat Completion API, browsing is enabled by default
        # if the model supports it. TODO: Support browsing.
        # assert not self.supports_browsing
        # assert not self.supports_code_interpreter
        sys_msg = get_system_message(
            reasoning_effort=request.reasoning_effort,
            browser_description=None,
            python_description=None,
        )
        messages.append(sys_msg)

        # Add developer message.
        dev_msg = get_developer_message(tools=request.tools)
        messages.append(dev_msg)

        # Add user message.
        for chat_msg in request.messages:
            messages.append(parse_chat_input(chat_msg))

        # Render prompt token ids.
        prompt_token_ids = render_for_completion(messages)
        engine_prompt = TokensPrompt(prompt_token_ids=prompt_token_ids)

        return messages, [prompt_token_ids], [engine_prompt]
