from argparse import Namespace
import logging
from typing import Optional

from furiosa_llm.api import LLM
from furiosa_llm.llm_engine import SchedulerConfig
from furiosa_llm.utils import get_logger_with_tz

logger = get_logger_with_tz(logging.getLogger(__name__))


def load_llm_from_args(args: Namespace, served_model_name: Optional[str] = None) -> LLM:
    """
    Returns LLM object loaded from the given arguments."""
    model: str = args.model
    pp: Optional[int] = args.pipeline_parallel_size
    dp: Optional[int] = args.data_parallel_size
    devices = args.devices

    if model == "furiosa-ai/fake-llm":
        from transformers import AutoTokenizer

        from tests.utils import FakeLLM, FakeNativeLLMEngine

        engine = FakeNativeLLMEngine.from_text_output(
            AutoTokenizer.from_pretrained("unsloth/Llama-3.1-8B-Instruct"),
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
            append_eos=True,
        )
        return FakeLLM(engine)

    fxb = getattr(args, "fxb", None)
    if fxb:
        logger.info(f"Loading LLM with v3 engine: model={model}, fxb={fxb}")
    else:
        logger.info(f"Loading LLM from artifact: {model}")
        if args.tensor_parallel_size:
            logger.warning("When loading LLM from artifact, given -tp value will be ignored.")

    scheduler_config = SchedulerConfig.load_from_args(args)

    return LLM(
        model,
        fxb=fxb,
        revision=getattr(args, "revision", None),  # TODO: v3 engine should also support revision
        devices=devices,
        data_parallel_size=dp,
        pipeline_parallel_size=pp,
        scheduler_config=scheduler_config,
        structured_outputs_backend=args.structured_outputs_backend,
        max_io_memory_mb=args.max_io_memory_mb,
        enable_jit_compilation=args.enable_jit_compilation,
        jit_threshold=args.jit_threshold,
        jit_max_workers=args.jit_max_workers,
        jit_unit_size=args.jit_unit_size,
        served_model_name=served_model_name,
    )
