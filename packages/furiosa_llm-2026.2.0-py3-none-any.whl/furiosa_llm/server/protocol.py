# Adapted from
# https://github.com/vllm-project/vllm/blob/4ef41b84766670c1bd8079f58d35bf32b5bcb3ab/vllm/entrypoints/openai/protocol.py

import time
from typing import (
    Annotated,
    Any,
    ClassVar,
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
    TypeAlias,
    Union,
)
import warnings

# isort: off
from openai.types.chat import (
    ChatCompletionContentPartImageParam,
    ChatCompletionContentPartInputAudioParam,
    ChatCompletionContentPartRefusalParam,
    ChatCompletionMessageToolCallParam,
)
from openai.types.chat import ChatCompletionContentPartParam as OpenAIChatCompletionContentPartParam
from openai.types.chat import ChatCompletionMessageParam as OpenAIChatCompletionMessageParam

# isort: on

from openai.types.model import Model as OpenAIModel
from openai.types.responses import (
    ResponseCompletedEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseCreatedEvent,
    ResponseFailedEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseFunctionToolCall,
    ResponseIncompleteEvent,
    ResponseInProgressEvent,
    ResponseInputItemParam,
    ResponseOutputItem,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseReasoningSummaryPartAddedEvent,
    ResponseReasoningSummaryPartDoneEvent,
    ResponseReasoningSummaryTextDeltaEvent,
    ResponseReasoningSummaryTextDoneEvent,
    ResponseStatus,
    ResponseTextConfig,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
)
from openai.types.responses.response import IncompleteDetails, ToolChoice
from openai.types.responses.tool import Tool
from openai.types.shared import Metadata, Reasoning
from openai_harmony import Message as OpenAIHarmonyMessage  # type: ignore[import-untyped]
from pydantic import BaseModel, ConfigDict, Field, model_validator
from typing_extensions import Required, TypedDict

from furiosa_llm.api import LLM, PoolingParams, SamplingParams
from furiosa_llm.outputs import Logprob
from furiosa_llm.sampling_params import StructuredOutputsParams
from furiosa_llm.server.utils import random_uuid


class OpenAIBaseModel(BaseModel):
    # OpenAI API does allow extra fields
    model_config = ConfigDict(extra="allow")
    # Cache class field names
    field_names: ClassVar[Optional[set[str]]] = None


class PromptTokensDetails(OpenAIBaseModel):
    cached_tokens: int = 0
    audio_tokens: int = 0


class CompletionTokenUsageInfo(OpenAIBaseModel):
    accepted_prediction_tokens: int = 0
    audio_tokens: int = 0
    reasoning_tokens: int = 0
    rejected_prediction_tokens: int = 0


class UsageInfo(OpenAIBaseModel):
    prompt_tokens: int = 0
    total_tokens: int = 0
    completion_tokens: Optional[int] = 0
    prompt_tokens_details: Optional[PromptTokensDetails] = None
    completion_tokens_details: Optional[CompletionTokenUsageInfo] = None


class StreamOptions(OpenAIBaseModel):
    include_usage: Optional[bool] = True


class FunctionDefinition(OpenAIBaseModel):
    name: str
    description: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None


class ChatCompletionToolsParam(OpenAIBaseModel):
    type: Literal["function"] = "function"
    function: FunctionDefinition


class ChatCompletionNamedFunction(OpenAIBaseModel):
    name: str


class ChatCompletionNamedToolChoiceParam(OpenAIBaseModel):
    function: ChatCompletionNamedFunction
    type: Literal["function"] = "function"


class JsonSchemaResponseFormat(OpenAIBaseModel):
    name: str
    description: Optional[str] = None
    # schema is the field in openai but that causes conflicts with pydantic so
    # instead use json_schema with an alias
    json_schema: Optional[dict[str, Any]] = Field(default=None, alias='schema')
    strict: Optional[bool] = None


class ResponseFormat(OpenAIBaseModel):
    # type must be "json_schema", "json_object", or "text"
    type: Literal["text", "json_object", "json_schema"]
    json_schema: Optional[JsonSchemaResponseFormat] = None


class AudioURL(TypedDict, total=False):
    url: Required[str]
    """
    Either a URL of the audio or a data URL with base64 encoded audio data.
    """


class ChatCompletionContentPartAudioParam(TypedDict, total=False):
    audio_url: Required[AudioURL]

    type: Required[Literal["audio_url"]]
    """The type of the content part."""


class VideoURL(TypedDict, total=False):
    url: Required[str]
    """
    Either a URL of the video or a data URL with base64 encoded video data.
    """


class ChatCompletionContentPartVideoParam(TypedDict, total=False):
    video_url: Required[VideoURL]

    type: Required[Literal["video_url"]]
    """The type of the content part."""


class CustomChatCompletionContentSimpleImageParam(TypedDict, total=False):
    """A simpler version of the param that only accepts a plain image_url.

    Example:
    {
        "image_url": "https://example.com/image.png"
    }
    """

    image_url: str | None
    uuid: str | None
    """
    User-provided UUID of a media. User must guarantee that it is properly
    generated and unique for different medias.
    """


class CustomChatCompletionContentSimpleAudioParam(TypedDict, total=False):
    """A simpler version of the param that only accepts a plain audio_url.

    Example:
    {
        "audio_url": "https://example.com/audio.mp3"
    }
    """

    audio_url: str | None


class CustomChatCompletionContentSimpleVideoParam(TypedDict, total=False):
    """A simpler version of the param that only accepts a plain video_url.

    Example:
    {
        "video_url": "https://example.com/video.mp4"
    }
    """

    video_url: str | None
    uuid: str | None
    """
    User-provided UUID of a media. User must guarantee that it is properly
    generated and unique for different medias.
    """


class CustomThinkCompletionContentParam(TypedDict, total=False):
    """A Think Completion Content Param that accepts a plain text and a boolean.

    Example:
    {
        "thinking": "I am thinking about the answer",
        "closed": True,
        "type": "thinking"
    }
    """

    thinking: Required[str]
    """The thinking content."""

    closed: bool
    """Whether the thinking is closed."""

    type: Required[Literal["thinking"]]
    """The thinking type."""


ChatCompletionContentPartParam: TypeAlias = (
    OpenAIChatCompletionContentPartParam
    | ChatCompletionContentPartImageParam
    | ChatCompletionContentPartAudioParam
    | ChatCompletionContentPartInputAudioParam
    | ChatCompletionContentPartVideoParam
    | ChatCompletionContentPartRefusalParam
    | CustomChatCompletionContentSimpleImageParam
    | CustomChatCompletionContentSimpleAudioParam
    | CustomChatCompletionContentSimpleVideoParam
    | str
    | CustomThinkCompletionContentParam
)


class CustomChatCompletionMessageParam(TypedDict, total=False):
    """Enables custom roles in the Chat Completion API."""

    role: Required[str]
    """The role of the message's author."""

    content: str | list[ChatCompletionContentPartParam]
    """The contents of the message."""

    name: str
    """An optional name for the participant.

    Provides the model information to differentiate between participants of the
    same role.
    """

    tool_call_id: str | None
    """Tool call that this message is responding to."""

    tool_calls: Iterable[ChatCompletionMessageToolCallParam] | None
    """The tool calls generated by the model, such as function calls."""


ChatCompletionMessageParam: TypeAlias = (
    OpenAIChatCompletionMessageParam | CustomChatCompletionMessageParam | OpenAIHarmonyMessage
)


_GUIDED_DECODING_FIELDS = {
    "guided_json": "json",
    "guided_regex": "regex",
    "guided_choice": "choice",
    "guided_grammar": "grammar",
}


def _convert_guided_to_structured_outputs(data: dict) -> dict:
    """Convert deprecated guided_* fields to structured_outputs with a deprecation warning."""
    has_guided = any(data.get(field) is not None for field in _GUIDED_DECODING_FIELDS)
    if not has_guided:
        return data

    if data.get("structured_outputs") is not None:
        raise ValueError(
            "cannot use both deprecated guided_* fields and structured_outputs simultaneously; "
            "use structured_outputs only"
        )

    structured_outputs: dict = {}
    for old_field, new_field in _GUIDED_DECODING_FIELDS.items():
        value = data.pop(old_field, None)
        if value is not None:
            warnings.warn(
                f"{old_field} is deprecated, use structured_outputs={{'{new_field}': ...}} instead",
                DeprecationWarning,
                stacklevel=4,
            )
            structured_outputs[new_field] = value

    data["structured_outputs"] = structured_outputs
    return data


class ChatCompletionRequest(OpenAIBaseModel):
    messages: List[ChatCompletionMessageParam]
    model: str
    logprobs: Optional[bool] = False
    top_logprobs: Optional[int] = None
    prompt_logprobs: Optional[int] = None
    n: Optional[int] = 1
    temperature: Optional[float] = None
    stream: Optional[bool] = False
    stream_options: Optional[StreamOptions] = None
    top_p: Optional[float] = None
    best_of: Optional[int] = 1
    use_beam_search: bool = False
    top_k: Optional[int] = None
    min_p: Optional[float] = None
    repetition_penalty: Optional[float] = None
    length_penalty: float = 1.0
    stop_token_ids: Optional[list[int]] = None
    ignore_eos: bool = False
    early_stopping: bool = False
    min_tokens: int = 0
    skip_special_tokens: bool = True

    # TODO: completely remove max_tokens when OpenAI removes it
    max_tokens: Optional[int] = Field(
        default=None,
        deprecated="max_tokens is deprecated in favor of the max_completion_tokens field",
    )
    max_completion_tokens: Optional[int] = None

    tools: Optional[List[ChatCompletionToolsParam]] = None
    tool_choice: Optional[
        Union[
            Literal["none"],
            Literal["auto"],
            Literal["required"],
            ChatCompletionNamedToolChoiceParam,
        ]
    ] = "none"
    # NOTE this will be ignored -- the model determines the behavior
    parallel_tool_calls: Optional[bool] = True

    # Structured output
    # TODO: support structural_tag
    response_format: Optional[ResponseFormat] = None
    structured_outputs: Optional[StructuredOutputsParams] = None

    # Deprecated guided_* fields (use structured_outputs instead)
    guided_json: Optional[Union[str, dict, BaseModel]] = Field(
        default=None,
        deprecated="guided_json is deprecated, use structured_outputs={'json': ...} instead",
    )
    guided_regex: Optional[str] = Field(
        default=None,
        deprecated="guided_regex is deprecated, use structured_outputs={'regex': ...} instead",
    )
    guided_choice: Optional[list[str]] = Field(
        default=None,
        deprecated="guided_choice is deprecated, use structured_outputs={'choice': ...} instead",
    )
    guided_grammar: Optional[str] = Field(
        default=None,
        deprecated="guided_grammar is deprecated, use structured_outputs={'grammar': ...} instead",
    )

    add_generation_prompt: bool = True
    chat_template: Optional[str] = Field(
        default=None,
        description=(
            "A Jinja template to use for this conversion. "
            "As of transformers v4.44, default chat template is no longer "
            "allowed, so you must provide a chat template if the tokenizer "
            "does not define one."
        ),
    )
    chat_template_kwargs: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "Additional kwargs to pass to the template renderer. "
            "Will be accessible by the chat template."
        ),
    )
    mm_processor_kwargs: dict[str, Any] | None = Field(
        default=None,
        description=("Additional kwargs to pass to the HF processor."),
    )

    return_tokens_as_token_ids: Optional[bool] = Field(
        default=None,
        description="If specified with 'logprobs', tokens are represented as strings of the form 'token_id:{token_id}' so that tokens that are not JSON-encodable can be identified.",
    )
    return_token_ids: bool | None = Field(
        default=None,
        description=(
            "If specified, the result will include token IDs alongside the "
            "generated text. In streaming mode, prompt_token_ids is included "
            "only in the first chunk, and token_ids contains the delta tokens "
            "for each chunk. This is useful for debugging or when you "
            "need to map generated text back to input tokens."
        ),
    )

    # Parameters that is supported by OpenAI but not by Furiosa.
    # All of them are no-op, but declared as a placeholder.
    audio: Optional[Dict[str, Any]] = None
    frequency_penalty: Optional[float] = 0.0
    function_call: Optional[Union[str, Dict[str, Any]]] = None  # Deprecated
    functions: Optional[List[Any]] = None  # Deprecated
    logit_bias: Optional[Dict[int, float]] = None
    metadata: Optional[Dict[str, Any]] = None
    modalities: Optional[List[str]] = None
    prediction: Optional[Dict[str, Any]] = None
    presence_penalty: Optional[float] = 0.0
    reasoning_effort: Optional[Literal["low", "medium", "high"]] = None
    seed: Optional[int] = None
    service_tier: Optional[str] = "auto"
    stop: Optional[Union[str, List[str]]] = None
    store: Optional[bool] = False
    user: Optional[str] = None
    web_search_options: Optional[Dict[str, Any]] = None

    def to_sampling_params(self, default_sampling_params: dict[str, Any]) -> SamplingParams:
        # 3-tier merge: user request > model generation_config > API defaults
        if (temperature := self.temperature) is None:
            temperature = default_sampling_params.get("temperature")
        if (top_p := self.top_p) is None:
            top_p = default_sampling_params.get("top_p")
        if (top_k := self.top_k) is None:
            top_k = default_sampling_params.get("top_k")
        if (min_p := self.min_p) is None:
            min_p = default_sampling_params.get("min_p", 0.0)
        if (repetition_penalty := self.repetition_penalty) is None:
            repetition_penalty = default_sampling_params.get("repetition_penalty")
        if (max_tokens := self.max_completion_tokens or self.max_tokens) is None:
            max_tokens = default_sampling_params.get("max_tokens")
        if (stop_token_ids := self.stop_token_ids) is None:
            stop_token_ids = default_sampling_params.get("stop_token_ids")

        # Structured output
        structured_outputs = self.structured_outputs
        if structured_outputs is None:
            guided_json = None
            guided_json_object = None
            if self.response_format is not None:
                if self.response_format.type == "json_object":
                    guided_json_object = True
                elif self.response_format.type == "json_schema":
                    json_schema = self.response_format.json_schema
                    assert json_schema is not None
                    guided_json = json_schema.json_schema
            structured_outputs = StructuredOutputsParams.from_optional(
                json=self._get_guided_json_from_tool() or guided_json,
                json_object=guided_json_object,
            )

        return SamplingParams.from_optional(
            n=self.n,
            best_of=self.best_of,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=min_p,
            use_beam_search=self.use_beam_search,
            repetition_penalty=repetition_penalty,
            length_penalty=self.length_penalty,
            stop_token_ids=stop_token_ids,
            ignore_eos=self.ignore_eos,
            early_stopping=self.early_stopping,
            logprobs=self.top_logprobs if self.logprobs else None,
            prompt_logprobs=self.prompt_logprobs,
            max_tokens=max_tokens,
            min_tokens=self.min_tokens,
            skip_special_tokens=self.skip_special_tokens,
            structured_outputs=structured_outputs,
        )

    # Copied from https://github.com/vllm-project/vllm/blob/27e8d1ea3ea9864f371f639daaa5315bf3250364/vllm/entrypoints/openai/protocol.py#L712-L784
    def _get_guided_json_from_tool(self) -> Optional[Union[str, dict, BaseModel]]:
        # user has chosen to not use any tool
        if self.tool_choice == "none" or self.tools is None:
            return None

        # user has chosen to use a named tool
        if type(self.tool_choice) is ChatCompletionNamedToolChoiceParam:
            tool_name = self.tool_choice.function.name
            tools = {tool.function.name: tool.function for tool in self.tools}
            if tool_name not in tools:
                raise ValueError(f"Tool '{tool_name}' has not been passed in `tools`.")
            tool = tools[tool_name]
            return tool.parameters

        if self.tool_choice == "required":
            # Pydantic schema generation cannot be used since the JSON schema
            # has to be constructed for a specific instantiation of a tool list
            # so that parameters of a function are correctly generated
            # based on the chosen function name
            def get_tool_schema(tool: ChatCompletionToolsParam) -> dict:
                return {
                    "properties": {
                        "name": {"type": "string", "enum": [tool.function.name]},
                        # parameters are always generated as '{}' in the final
                        # output if they are missing from the request
                        # (i.e. are None or '{}') so the schema is
                        # updated to produce an empty object in that case
                        "parameters": (
                            tool.function.parameters
                            if tool.function.parameters
                            else {"type": "object", "properties": {}}
                        ),
                    },
                    "required": ["name", "parameters"],
                }

            def get_tool_schema_defs(tools: list[ChatCompletionToolsParam]) -> dict:
                all_defs = dict[str, dict[str, Any]]()
                for tool in tools:
                    if tool.function.parameters is None:
                        continue
                    defs = tool.function.parameters.pop("$defs", {})
                    for def_name, def_schema in defs.items():
                        if def_name in all_defs and all_defs[def_name] != def_schema:
                            raise ValueError(
                                f"Tool definition '{def_name}' has "
                                "multiple schemas, which is not "
                                "supported."
                            )
                        else:
                            all_defs[def_name] = def_schema
                return all_defs

            json_schema = {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "anyOf": [get_tool_schema(tool) for tool in self.tools],
                },
            }
            json_schema_defs = get_tool_schema_defs(self.tools)
            if json_schema_defs:
                json_schema["$defs"] = json_schema_defs
            return json_schema

        return None

    @model_validator(mode="before")
    @classmethod
    def check_tool_usage(cls, data):
        # if "tool_choice" is not set, set to the default value based on "tools"
        if "tool_choice" not in data or data["tool_choice"] is None:
            if data.get("tools"):
                data["tool_choice"] = "auto"
            else:
                data["tool_choice"] = "none"

        # if "tool_choice" is "none" -- no validation is needed for tools
        if "tool_choice" in data and data["tool_choice"] == "none":
            return data

        # if "tool_choice" is specified -- validation
        if "tool_choice" in data:
            # ensure that if "tool choice" is specified, tools are present
            if "tools" not in data or data["tools"] is None:
                raise ValueError("When using `tool_choice`, `tools` must be set.")

            # make sure that tool choice is either a named tool
            # OR that it's set to "auto" or "required"
            if data["tool_choice"] not in ["auto", "required"] and not isinstance(
                data["tool_choice"], dict
            ):
                raise NotImplementedError(
                    f'Invalid value for `tool_choice`: {data["tool_choice"]}! '
                    'Only named tools, "none", "auto" or "required" '
                    'are supported.'
                )

            # if tool_choice is "required" but the "tools" list is empty,
            # override the data to behave like "none" to align with
            # OpenAI’s behavior.
            if (
                data["tool_choice"] == "required"
                and isinstance(data["tools"], list)
                and len(data["tools"]) == 0
            ):
                data["tool_choice"] = "none"
                del data["tools"]
                return data

            # ensure that if "tool_choice" is specified as an object,
            # it matches a valid tool
            correct_usage_message = (
                'Correct usage: `{"type": "function",' ' "function": {"name": "my_function"}}`'
            )
            if isinstance(data["tool_choice"], dict):
                valid_tool = False
                function = data["tool_choice"].get("function")
                if not isinstance(function, dict):
                    raise ValueError(
                        f"Invalid value for `function`: `{function}` in "
                        f"`tool_choice`! {correct_usage_message}"
                    )
                if "name" not in function:
                    raise ValueError(
                        f"Expected field `name` in `function` in "
                        f"`tool_choice`! {correct_usage_message}"
                    )
                function_name = function["name"]
                if not isinstance(function_name, str) or len(function_name) == 0:
                    raise ValueError(
                        f"Invalid `name` in `function`: `{function_name}`"
                        f" in `tool_choice`! {correct_usage_message}"
                    )
                for tool in data["tools"]:
                    if tool["function"]["name"] == function_name:
                        valid_tool = True
                        break
                if not valid_tool:
                    raise ValueError(
                        "The tool specified in `tool_choice` does not match any"
                        " of the specified `tools`"
                    )
        return data

    @model_validator(mode="before")
    @classmethod
    def alias_functions_to_tools(cls, data):
        """
        Move `functions` and `function_call` (which are deprecated) to `tools` and `tool_choice` when necessary.
        This validator must be placed below `check_tool_usage` to ensure that
        this validator runs before `check_tool_usage`.
        """
        if "functions" not in data or "tools" in data:
            return data

        data["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": func["name"],
                    "description": func.get("description"),
                    "parameters": func.get("parameters"),
                },
            }
            for func in data["functions"]
        ]

        if "function_call" in data:
            function_call_value = data["function_call"]
        else:
            function_call_value = "auto" if data["tools"] else "none"
        if "tool_choice" not in data:
            data["tool_choice"] = function_call_value
        return data

    @model_validator(mode="before")
    @classmethod
    def convert_deprecated_guided_params(cls, data):
        return _convert_guided_to_structured_outputs(data)


class CompletionRequest(OpenAIBaseModel):
    model: str
    prompt: Union[str, List[str], List[int], List[List[int]]]
    best_of: Optional[int] = 1
    logprobs: Optional[int] = None
    prompt_logprobs: Optional[int] = None
    max_tokens: Optional[int] = 16
    n: int = 1
    temperature: Optional[float] = None
    top_p: Optional[float] = None

    stream: Optional[bool] = False
    stream_options: Optional[StreamOptions] = None
    use_beam_search: bool = False
    top_k: Optional[int] = None
    min_p: Optional[float] = None
    repetition_penalty: Optional[float] = None
    length_penalty: float = 1.0
    stop_token_ids: Optional[list[int]] = None
    ignore_eos: bool = False
    early_stopping: bool = False
    min_tokens: int = 0
    skip_special_tokens: bool = True

    return_tokens_as_token_ids: Optional[bool] = Field(
        default=None,
        description=(
            "If specified with 'logprobs', tokens are represented as strings of the form 'token_id:{token_id}' so that tokens that are not JSON-encodable can be identified."
        ),
    )
    return_token_ids: bool | None = Field(
        default=None,
        description=(
            "If specified, the result will include token IDs alongside the "
            "generated text. In streaming mode, prompt_token_ids is included "
            "only in the first chunk, and token_ids contains the delta tokens "
            "for each chunk. This is useful for debugging or when you "
            "need to map generated text back to input tokens."
        ),
    )

    # Structured output
    # TODO: support structural_tag
    response_format: Optional[ResponseFormat] = Field(
        default=None,
        description=(
            "Similar to chat completion, this parameter specifies the format "
            "of output. Only {'type': 'json_object'}, {'type': 'json_schema'}"
            ", {'type': 'structural_tag'}, or {'type': 'text' } is supported."
        ),
    )
    structured_outputs: Optional[StructuredOutputsParams] = None

    # Deprecated guided_* fields (use structured_outputs instead)
    guided_json: Optional[Union[str, dict, BaseModel]] = Field(
        default=None,
        deprecated="guided_json is deprecated, use structured_outputs={'json': ...} instead",
    )
    guided_regex: Optional[str] = Field(
        default=None,
        deprecated="guided_regex is deprecated, use structured_outputs={'regex': ...} instead",
    )
    guided_choice: Optional[list[str]] = Field(
        default=None,
        deprecated="guided_choice is deprecated, use structured_outputs={'choice': ...} instead",
    )
    guided_grammar: Optional[str] = Field(
        default=None,
        deprecated="guided_grammar is deprecated, use structured_outputs={'grammar': ...} instead",
    )

    # Parameters that is supported by OpenAI but not by Furiosa.
    # All of them are no-op, but declared as a placeholder.
    echo: Optional[bool] = False
    frequency_penalty: Optional[float] = 0.0
    logit_bias: Optional[Dict[int, float]] = None
    presence_penalty: Optional[float] = 0.0
    seed: Optional[int] = None
    stop: Optional[Union[str, List[str]]] = None
    suffix: Optional[str] = None
    user: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def convert_deprecated_guided_params(cls, data):
        return _convert_guided_to_structured_outputs(data)

    def to_sampling_params(
        self, default_sampling_params: dict[str, Any] | None = None
    ) -> SamplingParams:
        if default_sampling_params is None:
            default_sampling_params = {}

        # 3-tier merge: user request > model generation_config > API defaults
        if (temperature := self.temperature) is None:
            temperature = default_sampling_params.get("temperature")
        if (top_p := self.top_p) is None:
            top_p = default_sampling_params.get("top_p")
        if (top_k := self.top_k) is None:
            top_k = default_sampling_params.get("top_k")
        if (min_p := self.min_p) is None:
            min_p = default_sampling_params.get("min_p", 0.0)
        if (repetition_penalty := self.repetition_penalty) is None:
            repetition_penalty = default_sampling_params.get("repetition_penalty")
        if (max_tokens := self.max_tokens) is None:
            max_tokens = default_sampling_params.get("max_tokens")
        if (stop_token_ids := self.stop_token_ids) is None:
            stop_token_ids = default_sampling_params.get("stop_token_ids")

        structured_outputs = self.structured_outputs
        if structured_outputs is None:
            guided_json = None
            guided_json_object = None
            if self.response_format is not None:
                if self.response_format.type == "json_object":
                    guided_json_object = True
                elif self.response_format.type == "json_schema":
                    json_schema = self.response_format.json_schema
                    assert json_schema is not None
                    guided_json = json_schema.json_schema
            structured_outputs = StructuredOutputsParams.from_optional(
                json=guided_json,
                json_object=guided_json_object,
            )

        return SamplingParams.from_optional(
            n=self.n,
            best_of=self.best_of,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=min_p,
            use_beam_search=self.use_beam_search,
            repetition_penalty=repetition_penalty,
            length_penalty=self.length_penalty,
            stop_token_ids=stop_token_ids,
            ignore_eos=self.ignore_eos,
            early_stopping=self.early_stopping,
            logprobs=self.logprobs,
            prompt_logprobs=self.prompt_logprobs,
            max_tokens=max_tokens,
            min_tokens=self.min_tokens,
            skip_special_tokens=self.skip_special_tokens,
            structured_outputs=structured_outputs,
        )


class CompletionLogProbs(OpenAIBaseModel):
    text_offset: List[int] = Field(default_factory=list)
    token_logprobs: List[Optional[float]] = Field(default_factory=list)
    tokens: List[str] = Field(default_factory=list)
    top_logprobs: List[Optional[Dict[str, float]]] = Field(default_factory=list)


class CompletionResponseChoice(OpenAIBaseModel):
    index: int
    text: str
    logprobs: Optional[CompletionLogProbs] = None
    finish_reason: Optional[str] = None
    # Not part of the OpenAI spec but for tracing the tokens
    token_ids: list[int] | None = None
    prompt_logprobs: Optional[List[Optional[Dict[int, Logprob]]]] = None
    prompt_token_ids: list[int] | None = None


class CompletionResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"cmpl-{random_uuid()}")
    object: str = "text_completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[CompletionResponseChoice]
    usage: UsageInfo


class CompletionResponseStreamChoice(OpenAIBaseModel):
    index: int
    text: str
    logprobs: Optional[CompletionLogProbs] = None
    finish_reason: Optional[str] = None
    # Not part of the OpenAI spec but for tracing the tokens
    prompt_token_ids: list[int] | None = None
    token_ids: list[int] | None = None


class CompletionStreamResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"cmpl-{random_uuid()}")
    object: str = "text_completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[CompletionResponseStreamChoice]
    usage: Optional[UsageInfo] = Field(default=None)


class FunctionCall(OpenAIBaseModel):
    name: str
    arguments: str


class ToolCall(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"call-{random_uuid()}")
    type: Literal["function"] = "function"
    function: FunctionCall


class ChatMessage(OpenAIBaseModel):
    role: str
    content: Optional[str] = None
    reasoning: Optional[str] = None
    tool_calls: List[ToolCall] = Field(default_factory=list)


class ChatCompletionLogProb(OpenAIBaseModel):
    token: str
    logprob: float = -9999.0
    bytes: Optional[List[int]] = None


class ChatCompletionLogProbsContent(ChatCompletionLogProb):
    top_logprobs: List[ChatCompletionLogProb] = Field(default_factory=list)


class ChatCompletionLogProbs(OpenAIBaseModel):
    content: Optional[List[ChatCompletionLogProbsContent]] = None


class ChatCompletionResponseChoice(OpenAIBaseModel):
    index: int
    message: ChatMessage
    logprobs: Optional[ChatCompletionLogProbs] = None
    finish_reason: Optional[str] = None
    # Not part of the OpenAI spec but for tracing the tokens
    token_ids: list[int] | None = None


class ChatCompletionResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"chatcmpl-{random_uuid()}")
    object: Literal["chat.completion"] = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionResponseChoice]
    usage: UsageInfo
    # Not part of the OpenAI spec but for tracing the tokens
    prompt_logprobs: Optional[List[Optional[Dict[int, Logprob]]]] = None
    prompt_token_ids: list[int] | None = None


class DeltaFunctionCall(BaseModel):
    name: Optional[str] = None
    arguments: Optional[str] = None


# a tool call delta where everything is optional
class DeltaToolCall(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"chatcmpl-tool-{random_uuid()}")
    type: Literal["function"] = "function"
    index: int
    function: Optional[DeltaFunctionCall] = None


class DeltaMessage(OpenAIBaseModel):
    role: Optional[str] = None
    content: Optional[str] = None
    reasoning: Optional[str] = None
    tool_calls: List[DeltaToolCall] = Field(default_factory=list)

    def is_empty(self):
        return not any([self.role, self.content, self.reasoning, self.tool_calls])


class ChatCompletionResponseStreamChoice(OpenAIBaseModel):
    index: int
    delta: DeltaMessage
    logprobs: Optional[ChatCompletionLogProbs] = None
    finish_reason: Optional[str] = None
    # Not part of the OpenAI spec but for tracing the tokens
    token_ids: list[int] | None = None


class ChatCompletionStreamResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"chatcmpl-{random_uuid()}")
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionResponseStreamChoice]
    usage: Optional[UsageInfo] = Field(default=None)
    # Not part of the OpenAI spec but for tracing the tokens
    prompt_token_ids: list[int] | None = None


class ExtractedToolCallInformation(BaseModel):
    # indicate if tools were called
    tools_called: bool

    # extracted tool calls
    tool_calls: List[ToolCall]

    # content - per OpenAI spec, content AND tool calls can be returned rarely
    # But some models will do this intentionally
    content: Optional[str] = None


class Model(OpenAIModel):
    artifact_id: str
    max_prompt_len: int
    max_context_len: int

    # TODO: Add runtime-related configuration data.
    @classmethod
    def from_llm(cls, llm: LLM, served_model_name: str) -> "Model":
        assert llm.max_seq_len_to_capture is not None
        return cls(
            id=served_model_name,
            created=int(time.time()),
            object="model",
            owned_by="furiosa-ai",
            artifact_id=llm.artifact_id,
            max_prompt_len=llm.prompt_max_seq_len,
            max_context_len=llm.max_seq_len_to_capture,
        )


class ModelsResponse(OpenAIBaseModel):
    object: Literal["list"] = "list"
    data: List[Model]

    @classmethod
    def from_llm(cls, llm: LLM, served_model_name: str) -> "ModelsResponse":
        return cls(data=[Model.from_llm(llm, served_model_name=served_model_name)])


class ErrorResponse(OpenAIBaseModel):
    object: str = "error"
    message: str
    type: str
    param: Optional[str] = None
    code: int


class EmbeddingRequest(OpenAIBaseModel):
    # Ordered by official OpenAI API documentation
    # https://platform.openai.com/docs/api-reference/embeddings
    input: Union[List[int], List[list[int]], str, List[str]]
    truncate_prompt_tokens: Optional[Annotated[int, Field(ge=-1)]] = None
    normalize: Optional[bool] = True
    dimensions: Optional[Annotated[int, Field(ge=1)]] = None

    # The remaining parameters are no-op placeholders maintained for compatibility with OpenAI client implementations.
    model: Optional[str] = None
    encoding_format: Literal["float", "base64"] = "float"
    user: Optional[str] = None

    def to_pooling_params(self):
        return PoolingParams(
            truncate_prompt_tokens=self.truncate_prompt_tokens,
            normalize=self.normalize,
            dimensions=self.dimensions,
        )


class EmbeddingResponseData(OpenAIBaseModel):
    index: int
    object: str = "embedding"
    embedding: Union[list[float], str]


class EmbeddingResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"embd-{random_uuid()}")
    object: str = "list"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    data: list[EmbeddingResponseData]
    usage: UsageInfo


class ScoreRequest(OpenAIBaseModel):
    model: Optional[str] = None
    text_1: Union[List[str], str]
    text_2: Union[List[str], str]
    truncate_prompt_tokens: Optional[Annotated[int, Field(ge=-1)]] = None

    # If true, use Qwen3-Reranker's officially recommended instruction and templating.
    use_qwen3_template: Optional[bool] = None

    ## Parameters supported by vllm, but not necessary in furiosa-llm yet:
    # mm_processor_kwargs: Optional[dict[str, Any]] = None  # HF processor kwargs
    # priority: int = 0  # Request priority (0: default)
    # softmax: Optional[bool] = None  # (Deprecated) Use use_activation instead
    # activation: Optional[bool] = None  # (Deprecated) Use use_activation instead
    # use_activation: Optional[bool] = None  # Whether to use activation for classification

    def to_pooling_params(self) -> PoolingParams:
        return PoolingParams(truncate_prompt_tokens=self.truncate_prompt_tokens)


class ScoreResponseData(OpenAIBaseModel):
    index: int
    object: str = "score"
    score: float


class ScoreResponse(OpenAIBaseModel):
    id: str = Field(default_factory=lambda: f"score-{random_uuid()}")
    object: str = "list"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    data: list[ScoreResponseData]
    usage: UsageInfo


class RerankRequest(OpenAIBaseModel):
    model: Optional[str] = None
    query: str
    documents: list[str]
    top_n: int = Field(default_factory=lambda: 0)
    truncate_prompt_tokens: Optional[Annotated[int, Field(ge=-1)]] = None

    # If true, use Qwen3-Reranker's officially recommended instruction and templating.
    use_qwen3_template: Optional[bool] = None

    ## Parameters supported by vllm, but not necessary in furiosa-llm yet:
    # mm_processor_kwargs: Optional[dict[str, Any]] = None  # HF processor kwargs
    # priority: int = 0  # Request priority (0: default)
    # softmax: Optional[bool] = None  # (Deprecated) Use use_activation instead
    # activation: Optional[bool] = None  # (Deprecated) Use use_activation instead
    # use_activation: Optional[bool] = None  # Whether to use activation for classification

    def to_pooling_params(self) -> PoolingParams:
        return PoolingParams(truncate_prompt_tokens=self.truncate_prompt_tokens)


class RerankDocument(BaseModel):
    text: Optional[str] = None
    multi_modal: None = None


class RerankResult(BaseModel):
    index: int
    document: RerankDocument
    relevance_score: float


class RerankUsage(BaseModel):
    total_tokens: int


class RerankResponse(OpenAIBaseModel):
    id: str
    model: str
    usage: RerankUsage
    results: list[RerankResult]


class TokenizeCompletionRequest(OpenAIBaseModel):
    model: Optional[str] = None
    prompt: str
    add_special_tokens: bool = Field(
        default=True,
        description="If true (the default), special tokens (e.g. BOS) will be added to the prompt.",
    )
    return_token_strs: Optional[bool] = Field(
        default=False,
        description="If true, also return the token strings corresponding to the token ids.",
    )


class TokenizeChatRequest(OpenAIBaseModel):
    model: Optional[str] = None
    messages: List[ChatCompletionMessageParam]
    add_generation_prompt: bool = Field(
        default=True,
        description="If true (the default), a generation prompt will be added to the chat template.",
    )
    return_token_strs: Optional[bool] = Field(
        default=False,
        description="If true, also return the token strings corresponding to the token ids.",
    )
    continue_final_message: bool = Field(
        default=False,
        description="If true, continues the final message instead of starting a new one.",
    )
    add_special_tokens: bool = Field(
        default=False,
        description="If true, special tokens (e.g. BOS) will be added to the prompt.",
    )
    chat_template: Optional[str] = Field(
        default=None,
        description="A Jinja template to use for this conversion.",
    )
    chat_template_kwargs: Optional[Dict[str, Any]] = None
    mm_processor_kwargs: Optional[Dict[str, Any]] = None
    tools: Optional[List[ChatCompletionToolsParam]] = Field(
        default=None,
        description="A list of tools the model may call.",
    )

    @model_validator(mode="before")
    @classmethod
    def check_generation_prompt(cls, data):
        if data.get("continue_final_message") and data.get("add_generation_prompt"):
            raise ValueError(
                "cannot set both `continue_final_message` and `add_generation_prompt` to True"
            )
        return data


TokenizeRequest: TypeAlias = Union[TokenizeCompletionRequest, TokenizeChatRequest]


class TokenizeResponse(OpenAIBaseModel):
    count: int
    max_model_len: int
    tokens: List[int]
    token_strs: Optional[List[str]] = None


class DetokenizeRequest(OpenAIBaseModel):
    model: Optional[str] = None
    tokens: List[int]


class DetokenizeResponse(OpenAIBaseModel):
    prompt: str


class TokenizerInfoResponse(OpenAIBaseModel):
    model_config = ConfigDict(extra="allow")
    tokenizer_class: str


# ============================================================================
# OpenResponses API Types
# https://www.openresponses.org/specification
#
# Where possible, types are reused from the openai SDK to ensure spec
# compatibility and reduce maintenance.
# ============================================================================


class InputTokensDetails(OpenAIBaseModel):
    cached_tokens: int = 0


class OutputTokensDetails(OpenAIBaseModel):
    reasoning_tokens: int = 0


class ResponseUsage(OpenAIBaseModel):
    input_tokens: int
    input_tokens_details: InputTokensDetails
    output_tokens: int
    output_tokens_details: OutputTokensDetails
    total_tokens: int


class ResponsesRequest(OpenAIBaseModel):
    """Request model for the Responses API.

    Follows the OpenResponses specification:
    https://www.openresponses.org/specification
    """

    model_config = ConfigDict(extra="allow")

    # Core parameters
    input: Union[str, List[Union[ResponseInputItemParam, ResponseOutputItem]]]
    model: str
    instructions: Optional[str] = None

    # Sampling parameters
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    max_output_tokens: Optional[int] = None

    # Control flags
    stream: Optional[bool] = False
    store: Optional[bool] = True  # OpenAI default is True
    background: Optional[bool] = False
    parallel_tool_calls: Optional[bool] = True

    # Tools
    tools: List[Tool] = Field(default_factory=list)
    tool_choice: ToolChoice = "auto"

    # Structured output
    text: Optional[ResponseTextConfig] = None

    # Reasoning
    reasoning: Optional[Reasoning] = None

    # Response continuation
    previous_response_id: Optional[str] = None

    # Context management
    truncation: Optional[Literal["auto", "disabled"]] = "disabled"

    # Include additional response data
    include: Optional[
        List[
            Literal[
                "message.output_text.logprobs",
                "file_search_call.results",
                "message.input_image.image_url",
                "computer_call_output.output.image_url",
                "reasoning.encrypted_content",
                "code_interpreter_call.outputs",
            ]
        ]
    ] = None

    # Parameters that are supported by OpenAI but not by Furiosa.
    # All of them are no-op, but declared as a placeholder.
    frequency_penalty: Optional[float] = 0.0
    presence_penalty: Optional[float] = 0.0
    service_tier: Optional[Literal["auto", "default", "flex"]] = "auto"
    top_logprobs: Optional[int] = 0
    user: Optional[str] = None
    metadata: Optional[Metadata] = None

    # Extension fields (furiosa-specific)
    request_id: str = Field(default_factory=lambda: f"resp-{random_uuid()}")
    chat_template_kwargs: Optional[Dict[str, Any]] = Field(
        default=None,
        description=(
            "Additional kwargs to pass to the template renderer. "
            "Will be accessible by the chat template."
        ),
    )

    @model_validator(mode="before")
    @classmethod
    def validate_background(cls, data: Any) -> Any:
        if data.get("background") and not data.get("store", True):
            raise ValueError("background can only be used when `store` is true")
        return data

    @model_validator(mode="before")
    @classmethod
    def function_call_parsing(cls, data: Any) -> Any:
        """Pre-parse function_call dicts into ResponseFunctionToolCall objects."""
        input_data = data.get("input")
        if input_data is None or isinstance(input_data, (str, bytes)):
            return data
        if not isinstance(input_data, list):
            try:
                input_data = list(input_data)
            except TypeError:
                return data

        processed: list[Any] = []
        for item in input_data:
            if isinstance(item, dict) and item.get("type") == "function_call":
                try:
                    processed.append(ResponseFunctionToolCall(**item))
                except Exception:
                    processed.append(item)
            else:
                processed.append(item)
        data["input"] = processed
        return data

    def _get_guided_json_from_tool(self) -> Optional[Union[str, dict]]:
        """Build a JSON Schema for guided decoding based on tool_choice.

        Mirrors the logic in ChatCompletionRequest._get_guided_json_from_tool,
        adapted for the Responses API flat tool format.
        """
        from openai.types.responses.function_tool import FunctionTool
        from openai.types.responses.tool_choice_function import ToolChoiceFunction

        if self.tool_choice == "none" or not self.tools:
            return None

        # Filter to function tools only
        fn_tools = [t for t in self.tools if isinstance(t, FunctionTool)]
        if not fn_tools:
            return None

        # Named tool choice: constrain output to the named function's parameters
        if isinstance(self.tool_choice, ToolChoiceFunction):
            tool_name = self.tool_choice.name
            tools_by_name = {t.name: t for t in fn_tools}
            if tool_name not in tools_by_name:
                raise ValueError(f"Tool '{tool_name}' has not been passed in `tools`.")
            return tools_by_name[tool_name].parameters

        # Required tool choice: constrain output to a JSON array of tool calls
        if self.tool_choice == "required":

            def get_tool_schema(tool: FunctionTool) -> dict:
                return {
                    "properties": {
                        "name": {"type": "string", "enum": [tool.name]},
                        "parameters": (
                            tool.parameters
                            if tool.parameters
                            else {"type": "object", "properties": {}}
                        ),
                    },
                    "required": ["name", "parameters"],
                }

            json_schema: dict[str, Any] = {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "anyOf": [get_tool_schema(tool) for tool in fn_tools],
                },
            }
            return json_schema

        # "auto" - no guided decoding
        return None

    def to_sampling_params(
        self, default_sampling_params: dict[str, Any] | None = None
    ) -> SamplingParams:
        if default_sampling_params is None:
            default_sampling_params = {}

        # 3-tier merge: user request > model generation_config > API defaults
        if (temperature := self.temperature) is None:
            temperature = default_sampling_params.get("temperature")
        if (top_p := self.top_p) is None:
            top_p = default_sampling_params.get("top_p")
        if (top_k := self.top_k) is None:
            top_k = default_sampling_params.get("top_k")
        if (max_tokens := self.max_output_tokens) is None:
            max_tokens = default_sampling_params.get("max_tokens")
        if (stop_token_ids := None) is None:
            stop_token_ids = default_sampling_params.get("stop_token_ids")

        # Structured output from text.format or tool_choice
        structured_outputs: Optional[StructuredOutputsParams] = None
        if self.text is not None and self.text.format is not None:
            response_format = self.text.format
            if (
                response_format.type == "json_schema"
                and hasattr(response_format, "schema_")
                and response_format.schema_ is not None
            ):
                structured_outputs = StructuredOutputsParams(json=response_format.schema_)
        if structured_outputs is None:
            guided_json = self._get_guided_json_from_tool()
            if guided_json is not None:
                structured_outputs = StructuredOutputsParams(json=guided_json)

        # Logprobs: only enable when include contains "message.output_text.logprobs"
        logprobs: Optional[int] = None
        if self.include and "message.output_text.logprobs" in self.include:
            logprobs = self.top_logprobs if self.top_logprobs else 0

        return SamplingParams.from_optional(
            n=1,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            stop_token_ids=stop_token_ids,
            logprobs=logprobs,
            structured_outputs=structured_outputs,
        )


def _resolve_tool_defaults(tools: List[Tool]) -> List[Tool]:
    """Resolve default values for tools to match OpenAI behavior.

    OpenAI resolves strict=null to strict=true for function tools.
    """
    resolved = []
    for tool in tools:
        if hasattr(tool, "strict") and tool.strict is None:
            tool_dict = tool.model_dump()
            tool_dict["strict"] = True
            resolved.append(type(tool).model_validate(tool_dict))
        else:
            resolved.append(tool)
    return resolved


class ResponsesResponse(OpenAIBaseModel):
    """Response model for the Responses API.

    Dedicated response class to avoid type mismatches with the OpenAI SDK's
    Response model while maintaining full API compatibility.
    """

    id: str
    created_at: int = Field(default_factory=lambda: int(time.time()))
    incomplete_details: Optional[IncompleteDetails] = None
    instructions: Optional[str] = None
    metadata: Metadata = Field(default_factory=dict)
    model: str
    object: Literal["response"] = "response"
    output: List[ResponseOutputItem]
    parallel_tool_calls: bool = True
    temperature: float = 1.0
    tool_choice: ToolChoice = "auto"
    tools: List[Tool] = Field(default_factory=list)
    top_p: float = 1.0
    background: bool = False
    completed_at: Optional[int] = None
    max_output_tokens: Optional[int] = None
    max_tool_calls: Optional[int] = None
    previous_response_id: Optional[str] = None
    reasoning: Reasoning = Field(default_factory=Reasoning)
    service_tier: Optional[str] = "auto"
    status: ResponseStatus = "in_progress"
    text: ResponseTextConfig = Field(
        default_factory=lambda: ResponseTextConfig.model_validate(
            {"format": {"type": "text"}, "verbosity": "medium"}
        )
    )
    top_logprobs: Optional[int] = None
    truncation: Optional[Literal["auto", "disabled"]] = "disabled"
    usage: Optional[ResponseUsage] = None
    user: Optional[str] = None
    # Extra fields for OpenAI compat
    store: bool = True
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0

    @classmethod
    def from_request(
        cls,
        request: ResponsesRequest,
        *,
        request_id: str,
        model: str,
        output: List[ResponseOutputItem],
        status: ResponseStatus,
        created_at: Optional[int] = None,
        completed_at: Optional[int] = None,
        usage: Optional[ResponseUsage] = None,
        sampling_params: Optional[SamplingParams] = None,
    ) -> "ResponsesResponse":
        incomplete_details: Optional[IncompleteDetails] = None
        if status == "incomplete":
            incomplete_details = IncompleteDetails(reason="max_output_tokens")

        default_text = ResponseTextConfig.model_validate(
            {"format": {"type": "text"}, "verbosity": "medium"}
        )

        # Resolve text config: fill in default verbosity if not provided
        resolved_text = request.text if request.text is not None else default_text
        if resolved_text.verbosity is None:
            resolved_text = ResponseTextConfig.model_validate(
                {**resolved_text.model_dump(by_alias=True), "verbosity": "medium"}
            )

        sp = sampling_params
        return cls(
            id=request_id,
            created_at=created_at or int(time.time()),
            incomplete_details=incomplete_details,
            instructions=request.instructions,
            metadata=request.metadata if request.metadata is not None else {},
            model=model,
            output=output,
            parallel_tool_calls=(
                request.parallel_tool_calls if request.parallel_tool_calls is not None else True
            ),
            temperature=sp.temperature if sp else 1.0,
            tool_choice=request.tool_choice,
            tools=_resolve_tool_defaults(request.tools),
            top_p=sp.top_p if sp else 1.0,
            background=(request.background if request.background is not None else False),
            completed_at=completed_at,
            max_output_tokens=request.max_output_tokens,
            previous_response_id=request.previous_response_id,
            reasoning=(request.reasoning if request.reasoning is not None else Reasoning()),
            service_tier="default",
            status=status,
            text=resolved_text,
            top_logprobs=(request.top_logprobs if request.top_logprobs is not None else 0),
            truncation=request.truncation or "disabled",
            usage=usage,
            user=request.user,
            store=request.store if request.store is not None else True,
            presence_penalty=(
                request.presence_penalty if request.presence_penalty is not None else 0.0
            ),
            frequency_penalty=(
                request.frequency_penalty if request.frequency_penalty is not None else 0.0
            ),
        )


# Streaming event types for OpenResponses API
ResponseStreamEvent = Union[
    ResponseCreatedEvent,
    ResponseInProgressEvent,
    ResponseCompletedEvent,
    ResponseFailedEvent,
    ResponseIncompleteEvent,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseReasoningSummaryPartAddedEvent,
    ResponseReasoningSummaryPartDoneEvent,
    ResponseReasoningSummaryTextDeltaEvent,
    ResponseReasoningSummaryTextDoneEvent,
]
