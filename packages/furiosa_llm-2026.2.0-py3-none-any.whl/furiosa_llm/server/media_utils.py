# Media fetching utilities for multimodal support (image, video)
import base64
from io import BytesIO
from pathlib import Path
import re
from typing import NamedTuple
from urllib.parse import urlparse

from PIL import Image
import httpx


class VideoData(NamedTuple):
    """Container for video data with metadata."""

    content: bytes
    """Raw video bytes."""

    mime_type: str | None
    """MIME type of the video (e.g., 'video/mp4')."""


# Regex pattern to parse data URLs
# Format: data:[<mediatype>][;encoding],<data>
DATA_URL_PATTERN = re.compile(
    r"^data:(?P<mediatype>[^;,]+)?(?:;(?P<encoding>[^,]+))?,(?P<data>.+)$",
    re.DOTALL,
)


def _validate_allowed_domain(url: str, allowed_media_domains: list[str]) -> None:
    """Validate that the URL's host is in the allowed media domains list.

    Args:
        url: The URL to validate.
        allowed_media_domains: List of allowed domain names.

    Raises:
        ValueError: If the URL's host is not in the allowed domains list.
    """
    parsed = urlparse(url)
    hostname = parsed.hostname
    if hostname is None:
        raise ValueError(f"cannot determine hostname from URL: {url}")
    if hostname not in allowed_media_domains:
        raise ValueError(
            f"the domain '{hostname}' is not in the allowed media domains; "
            f"allowed domains: {allowed_media_domains}"
        )


def fetch_image(
    image_url: str,
    *,
    timeout: float = 30.0,
    allowed_local_media_path: str | None = None,
    allowed_media_domains: list[str] | None = None,
) -> Image.Image:
    """
    Fetch an image from a URL (HTTP/HTTPS) or decode from a base64 data URL.

    Args:
        image_url: Either an HTTP(S) URL or a base64 data URL
        timeout: Timeout for HTTP requests in seconds
        allowed_local_media_path: If provided, allow loading local files under this path
        allowed_media_domains: If provided, only allow fetching from these domains.
            If not set, all remote domains are allowed.

    Returns:
        PIL Image object

    Raises:
        ValueError: If the URL format is invalid or unsupported
        httpx.HTTPError: If HTTP request fails
    """
    parsed = urlparse(image_url)

    if parsed.scheme in ("http", "https"):
        if allowed_media_domains is not None:
            _validate_allowed_domain(image_url, allowed_media_domains)
        return _fetch_image_from_http(
            image_url, timeout=timeout, allowed_media_domains=allowed_media_domains
        )
    elif parsed.scheme == "data" or image_url.startswith("data:"):
        return _fetch_image_from_data_url(image_url)
    elif parsed.scheme == "file" or parsed.scheme == "":
        if allowed_local_media_path is not None:
            return _fetch_image_from_file(image_url, allowed_local_media_path)
        raise ValueError(
            "Local file access is not allowed. Set allowed_local_media_path to enable."
        )
    else:
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}")


async def fetch_image_async(
    image_url: str,
    *,
    timeout: float = 30.0,
    allowed_local_media_path: str | None = None,
    allowed_media_domains: list[str] | None = None,
) -> Image.Image:
    """
    Asynchronously fetch an image from a URL or decode from a base64 data URL.

    Args:
        image_url: Either an HTTP(S) URL or a base64 data URL
        timeout: Timeout for HTTP requests in seconds
        allowed_local_media_path: If provided, allow loading local files under this path
        allowed_media_domains: If provided, only allow fetching from these domains.
            If not set, all remote domains are allowed.

    Returns:
        PIL Image object
    """
    parsed = urlparse(image_url)

    if parsed.scheme in ("http", "https"):
        if allowed_media_domains is not None:
            _validate_allowed_domain(image_url, allowed_media_domains)
        return await _fetch_image_from_http_async(
            image_url, timeout=timeout, allowed_media_domains=allowed_media_domains
        )
    elif parsed.scheme == "data" or image_url.startswith("data:"):
        return _fetch_image_from_data_url(image_url)
    elif parsed.scheme == "file" or parsed.scheme == "":
        if allowed_local_media_path is not None:
            return _fetch_image_from_file(image_url, allowed_local_media_path)
        raise ValueError(
            "Local file access is not allowed. Set allowed_local_media_path to enable."
        )
    else:
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}")


def _make_redirect_validator(
    allowed_media_domains: list[str] | None,
) -> list:
    """Create an httpx event hook list that validates redirect destinations."""
    if allowed_media_domains is None:
        return []

    def _check_redirect(response: httpx.Response) -> None:
        if response.is_redirect and response.next_request is not None:
            redirect_url = str(response.next_request.url)
            _validate_allowed_domain(redirect_url, allowed_media_domains)

    return [_check_redirect]


def _fetch_image_from_http(
    image_url: str,
    *,
    timeout: float = 30.0,
    allowed_media_domains: list[str] | None = None,
) -> Image.Image:
    """Fetch image from HTTP/HTTPS URL."""
    with httpx.Client(
        timeout=timeout,
        follow_redirects=True,
        event_hooks={"response": _make_redirect_validator(allowed_media_domains)},
    ) as client:
        response = client.get(image_url)
        response.raise_for_status()
        return Image.open(BytesIO(response.content))


async def _fetch_image_from_http_async(
    image_url: str,
    *,
    timeout: float = 30.0,
    allowed_media_domains: list[str] | None = None,
) -> Image.Image:
    """Asynchronously fetch image from HTTP/HTTPS URL."""
    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        event_hooks={"response": _make_redirect_validator(allowed_media_domains)},
    ) as client:
        response = await client.get(image_url)
        response.raise_for_status()
        return Image.open(BytesIO(response.content))


def _fetch_image_from_data_url(data_url: str) -> Image.Image:
    """Decode image from base64 data URL."""
    match = DATA_URL_PATTERN.match(data_url)
    if not match:
        raise ValueError(f"Invalid data URL format: {data_url[:50]}...")

    encoding = match.group("encoding")
    data = match.group("data")

    if encoding == "base64":
        image_data = base64.b64decode(data)
    else:
        raise ValueError(f"Unsupported encoding in data URL: {encoding}")

    return Image.open(BytesIO(image_data))


def _fetch_image_from_file(file_url: str, allowed_local_media_path: str) -> Image.Image:
    """Load image from local file path."""
    # Handle file:// URLs
    if file_url.startswith("file://"):
        file_path = file_url[7:]
    else:
        file_path = file_url

    # Resolve to absolute path
    path = Path(file_path).resolve()
    allowed_path = Path(allowed_local_media_path).resolve()

    # Security check: ensure path is under allowed directory
    try:
        path.relative_to(allowed_path)
    except ValueError:
        raise ValueError(f"File path {path} is not under allowed directory {allowed_path}")

    if not path.exists():
        raise FileNotFoundError(f"Image file not found: {path}")

    return Image.open(path)


def encode_image_base64(
    image: Image.Image,
    *,
    image_mode: str = "RGB",
    format: str = "PNG",
) -> str:
    """
    Encode a PIL Image to base64 string.

    Args:
        image: PIL Image object
        image_mode: Color mode to convert to (default: RGB)
        format: Image format for encoding (default: PNG)

    Returns:
        Base64 encoded string
    """
    if image.mode != image_mode:
        image = image.convert(image_mode)

    buffer = BytesIO()
    image.save(buffer, format=format)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def encode_image_url(
    image: Image.Image,
    *,
    image_mode: str = "RGB",
    format: str = "PNG",
) -> str:
    """
    Encode a PIL Image to a data URL.

    Args:
        image: PIL Image object
        image_mode: Color mode to convert to (default: RGB)
        format: Image format for encoding (default: PNG)

    Returns:
        Data URL string (e.g., "data:image/png;base64,...")
    """
    encoded = encode_image_base64(image, image_mode=image_mode, format=format)
    mimetype = f"image/{format.lower()}"
    return f"data:{mimetype};base64,{encoded}"


# Video fetching functions


def fetch_video(
    video_url: str,
    *,
    timeout: float = 60.0,
    allowed_local_media_path: str | None = None,
    allowed_media_domains: list[str] | None = None,
) -> VideoData:
    """
    Fetch a video from a URL (HTTP/HTTPS) or decode from a base64 data URL.

    Args:
        video_url: Either an HTTP(S) URL or a base64 data URL
        timeout: Timeout for HTTP requests in seconds
        allowed_local_media_path: If provided, allow loading local files under this path
        allowed_media_domains: If provided, only allow fetching from these domains.
            If not set, all remote domains are allowed.

    Returns:
        VideoData containing raw bytes and optional MIME type

    Raises:
        ValueError: If the URL format is invalid or unsupported
        httpx.HTTPError: If HTTP request fails
    """
    parsed = urlparse(video_url)

    if parsed.scheme in ("http", "https"):
        if allowed_media_domains is not None:
            _validate_allowed_domain(video_url, allowed_media_domains)
        return _fetch_video_from_http(
            video_url, timeout=timeout, allowed_media_domains=allowed_media_domains
        )
    elif parsed.scheme == "data" or video_url.startswith("data:"):
        return _fetch_video_from_data_url(video_url)
    elif parsed.scheme == "file" or parsed.scheme == "":
        if allowed_local_media_path is not None:
            return _fetch_video_from_file(video_url, allowed_local_media_path)
        raise ValueError(
            "Local file access is not allowed. Set allowed_local_media_path to enable."
        )
    else:
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}")


async def fetch_video_async(
    video_url: str,
    *,
    timeout: float = 60.0,
    allowed_local_media_path: str | None = None,
    allowed_media_domains: list[str] | None = None,
) -> VideoData:
    """
    Asynchronously fetch a video from a URL or decode from a base64 data URL.

    Args:
        video_url: Either an HTTP(S) URL or a base64 data URL
        timeout: Timeout for HTTP requests in seconds
        allowed_local_media_path: If provided, allow loading local files under this path
        allowed_media_domains: If provided, only allow fetching from these domains.
            If not set, all remote domains are allowed.

    Returns:
        VideoData containing raw bytes and optional MIME type
    """
    parsed = urlparse(video_url)

    if parsed.scheme in ("http", "https"):
        if allowed_media_domains is not None:
            _validate_allowed_domain(video_url, allowed_media_domains)
        return await _fetch_video_from_http_async(
            video_url, timeout=timeout, allowed_media_domains=allowed_media_domains
        )
    elif parsed.scheme == "data" or video_url.startswith("data:"):
        return _fetch_video_from_data_url(video_url)
    elif parsed.scheme == "file" or parsed.scheme == "":
        if allowed_local_media_path is not None:
            return _fetch_video_from_file(video_url, allowed_local_media_path)
        raise ValueError(
            "Local file access is not allowed. Set allowed_local_media_path to enable."
        )
    else:
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}")


def _fetch_video_from_http(
    video_url: str,
    *,
    timeout: float = 60.0,
    allowed_media_domains: list[str] | None = None,
) -> VideoData:
    """Fetch video from HTTP/HTTPS URL."""
    with httpx.Client(
        timeout=timeout,
        follow_redirects=True,
        event_hooks={"response": _make_redirect_validator(allowed_media_domains)},
    ) as client:
        response = client.get(video_url)
        response.raise_for_status()
        mime_type = response.headers.get("content-type", "").split(";")[0].strip()
        return VideoData(content=response.content, mime_type=mime_type or None)


async def _fetch_video_from_http_async(
    video_url: str,
    *,
    timeout: float = 60.0,
    allowed_media_domains: list[str] | None = None,
) -> VideoData:
    """Asynchronously fetch video from HTTP/HTTPS URL."""
    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        event_hooks={"response": _make_redirect_validator(allowed_media_domains)},
    ) as client:
        response = await client.get(video_url)
        response.raise_for_status()
        mime_type = response.headers.get("content-type", "").split(";")[0].strip()
        return VideoData(content=response.content, mime_type=mime_type or None)


def _fetch_video_from_data_url(data_url: str) -> VideoData:
    """Decode video from base64 data URL."""
    match = DATA_URL_PATTERN.match(data_url)
    if not match:
        raise ValueError(f"Invalid data URL format: {data_url[:50]}...")

    mediatype = match.group("mediatype")
    encoding = match.group("encoding")
    data = match.group("data")

    if encoding == "base64":
        video_data = base64.b64decode(data)
    else:
        raise ValueError(f"Unsupported encoding in data URL: {encoding}")

    return VideoData(content=video_data, mime_type=mediatype)


def _fetch_video_from_file(file_url: str, allowed_local_media_path: str) -> VideoData:
    """Load video from local file path."""
    # Handle file:// URLs
    if file_url.startswith("file://"):
        file_path = file_url[7:]
    else:
        file_path = file_url

    # Resolve to absolute path
    path = Path(file_path).resolve()
    allowed_path = Path(allowed_local_media_path).resolve()

    # Security check: ensure path is under allowed directory
    try:
        path.relative_to(allowed_path)
    except ValueError:
        raise ValueError(f"File path {path} is not under allowed directory {allowed_path}")

    if not path.exists():
        raise FileNotFoundError(f"Video file not found: {path}")

    # Guess MIME type from extension
    mime_types = {
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".avi": "video/x-msvideo",
        ".mov": "video/quicktime",
        ".mkv": "video/x-matroska",
        ".wmv": "video/x-ms-wmv",
        ".flv": "video/x-flv",
    }
    mime_type = mime_types.get(path.suffix.lower())

    return VideoData(content=path.read_bytes(), mime_type=mime_type)
