from dataclasses import dataclass
from http import HTTPStatus
import logging
from typing import Any

from fastapi import Request

from furiosa_llm.api import LLM
from furiosa_llm.server.chat_utils import (
    ChatTemplateContentFormatOption,
    ModelConfigAdapter,
    preprocess_chat,
)
from furiosa_llm.server.protocol import (
    DetokenizeRequest,
    DetokenizeResponse,
    ErrorResponse,
    TokenizeChatRequest,
    TokenizeRequest,
    TokenizeResponse,
    TokenizerInfoResponse,
)
from furiosa_llm.server.serving_base import OpenAIServing
from furiosa_llm.vllm_compat import AnyTokenizer

logger = logging.getLogger(__name__)


class OpenAIServingTokenization(OpenAIServing):
    def __init__(
        self,
        llm: LLM,
        served_model_name: str,
        *,
        chat_template: str | None,
        chat_template_content_format: ChatTemplateContentFormatOption = "auto",
        model_config_adapter: ModelConfigAdapter | None = None,
    ):
        self.tokenizer: AnyTokenizer = llm.tokenizer
        self.model_name = served_model_name
        self.model_config = llm.model_config
        self.max_model_len = llm.max_seq_len_to_capture or 0
        self.chat_template_content_format = chat_template_content_format

        self.model_config_adapter = model_config_adapter or ModelConfigAdapter(
            llm.model_config,
            trust_remote_code=getattr(llm.model_metadata, "trust_remote_code", False) or False,
            tokenizer_name_or_path=llm.tokenizer.name_or_path,
        )
        self.chat_template = chat_template

    async def create_tokenize(
        self,
        request: TokenizeRequest,
        raw_request: Request,
    ) -> TokenizeResponse | ErrorResponse:
        if request.model is not None and request.model != self.model_name:
            return self.create_error_response(
                f"the model '{request.model}' does not exist",
                err_type="NotFoundError",
                status_code=HTTPStatus.NOT_FOUND,
            )

        if isinstance(request, TokenizeChatRequest):
            token_ids = await self._tokenize_chat(request)
        else:
            token_ids = self.tokenizer.encode(
                request.prompt,
                add_special_tokens=request.add_special_tokens,
            )

        token_strs = None
        if request.return_token_strs:
            token_strs = self.tokenizer.convert_ids_to_tokens(token_ids)

        return TokenizeResponse(
            tokens=token_ids,
            count=len(token_ids),
            max_model_len=self.max_model_len,
            token_strs=token_strs,
        )

    async def _tokenize_chat(self, request: TokenizeChatRequest) -> list[int]:
        chat_template = request.chat_template or self.chat_template
        tool_dicts = [tool.model_dump() for tool in request.tools] if request.tools else None

        _, _, tokens_prompts = await preprocess_chat(
            request=request,  # type: ignore[arg-type]
            tokenizer=self.tokenizer,
            messages=request.messages,  # type: ignore[arg-type]
            chat_template=chat_template,
            chat_template_content_format=self.chat_template_content_format,
            model_config=self.model_config_adapter,
            add_generation_prompt=request.add_generation_prompt,
            continue_final_message=request.continue_final_message,
            tool_dicts=tool_dicts,
            chat_template_kwargs=request.chat_template_kwargs,
            add_special_tokens=request.add_special_tokens,
        )
        return tokens_prompts[0]["prompt_token_ids"]

    async def create_detokenize(
        self,
        request: DetokenizeRequest,
        raw_request: Request,
    ) -> DetokenizeResponse | ErrorResponse:
        if request.model is not None and request.model != self.model_name:
            return self.create_error_response(
                f"the model '{request.model}' does not exist",
                err_type="NotFoundError",
                status_code=HTTPStatus.NOT_FOUND,
            )

        try:
            # TODO: Use async tokenizer
            decoded_text = self.tokenizer.decode(request.tokens)
        except ValueError as e:
            return self.create_error_response(
                f"failed to detokenize: {e}",
                status_code=HTTPStatus.BAD_REQUEST,
            )
        except Exception as e:
            return self.create_error_response(
                f"internal server error: {e}",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        return DetokenizeResponse(prompt=decoded_text)

    async def get_tokenizer_info(self) -> TokenizerInfoResponse | ErrorResponse:
        try:
            tokenizer = self.tokenizer
            info = TokenizerInfo(tokenizer, self.chat_template).to_dict()
            return TokenizerInfoResponse(**info)
        except Exception as e:
            return self.create_error_response(f"Failed to get tokenizer info: {str(e)}")


@dataclass
class TokenizerInfo:
    tokenizer: AnyTokenizer
    chat_template: str | None

    def to_dict(self) -> dict[str, Any]:
        """Return the tokenizer configuration."""
        return self._get_tokenizer_config()

    def _get_tokenizer_config(self) -> dict[str, Any]:
        """Get tokenizer configuration directly from the tokenizer object."""
        config = dict(getattr(self.tokenizer, "init_kwargs", None) or {})

        # Remove file path fields
        config.pop("vocab_file", None)
        config.pop("merges_file", None)

        config = self._make_json_serializable(config)
        config["tokenizer_class"] = type(self.tokenizer).__name__
        if self.chat_template:
            config["chat_template"] = self.chat_template
        return config

    def _make_json_serializable(self, obj):
        """Convert any non-JSON-serializable objects to serializable format."""
        if hasattr(obj, "content"):
            return obj.content
        elif isinstance(obj, dict):
            return {k: self._make_json_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        else:
            return obj
