# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project


from collections.abc import Sequence
from logging import Logger
from typing import Optional, Union

from furiosa_llm.sampling_params import StructuredOutputsBackend
from furiosa_llm.server.protocol import ChatCompletionRequest, DeltaMessage
from furiosa_llm.server.reasoning_parsers.abs_reasoning_parsers import (
    ReasoningParser,
    ReasoningParserManager,
)
from furiosa_llm.vllm_compat import AnyTokenizer

logger = Logger(__name__)


@ReasoningParserManager.register_module("exaone4")
class Exaone4ReasoningParser(ReasoningParser):
    """
    Reasoning parser for the Exaone4 model.

    The Exaone4 model uses <think>...</think> tokens to denote reasoning text
    within its output. The model provides an explicit switch to enable reasoning
    output via the 'enable_thinking=True' parameter. If this option is set,
    the chat template appends <think> to the end of the prompt.
    This parser extracts the reasoning content from the model’s output, capturing everything
    from the beginning up to the closing </think> token.
    """

    def __init__(self, tokenizer: AnyTokenizer):
        super().__init__(tokenizer)
        self.think_start_token = "<think>"
        self.think_end_token = "</think>"

        if not self.model_tokenizer:
            raise ValueError(
                "The model tokenizer must be passed to the ReasoningParser "
                "constructor during construction."
            )

        self.think_start_token_id = self.vocab.get(self.think_start_token)
        self.think_end_token_id = self.vocab.get(self.think_end_token)
        if self.think_start_token_id is None or self.think_end_token_id is None:
            raise RuntimeError(
                "Exaone4 reasoning parser could not locate think start/end token in the tokenizer!"
            )

    def is_reasoning_end(self, input_ids: list[int]) -> bool:
        return self.think_end_token_id in input_ids

    def is_reasoning_open(self, prompt_token_ids: list[int]) -> bool:
        # XXX: technically we should check if the last <think> is after the last </think>,
        # but in practice the following would be sufficient.
        return (
            self.think_start_token_id in prompt_token_ids
            and self.think_end_token_id not in prompt_token_ids
        )

    def to_guided_grammar(self, backend: StructuredOutputsBackend, **kwargs) -> str:
        # TODO: Support other backends when needed.
        return "start: /(.|\\n)*/ </think>"

    def extract_content_ids(self, input_ids: list[int]) -> list[int]:
        """
        Extract the content after the end tokens
        """
        if self.think_end_token_id not in input_ids[:-1]:
            return []
        else:
            return input_ids[input_ids.index(self.think_end_token_id) + 1 :]

    def extract_reasoning_content_streaming(
        self,
        previous_text: str,
        current_text: str,
        delta_text: str,
        previous_token_ids: Sequence[int],
        current_token_ids: Sequence[int],
        delta_token_ids: Sequence[int],
        **kwargs,
    ) -> Union[DeltaMessage, None]:
        """
        Extract reasoning content from a delta message.
        Handles streaming output where previous + delta = current.
        Uses token IDs for faster processing.
        For text 'abc</think>xyz':
        - 'abc' goes to reasoning_content
        - 'xyz' goes to content
        """

        enable_thinking = kwargs.get("enable_thinking", False)

        # Skip single special tokens
        if len(delta_token_ids) == 1 and delta_token_ids[0] == self.think_end_token_id:
            return None

        if enable_thinking:
            if self.think_end_token_id in delta_token_ids:
                # enable_thinking is enabled and </think> in delta,
                # extract reasoning content
                end_index = delta_text.find(self.think_end_token)
                reasoning_content = delta_text[:end_index]
                content = delta_text[end_index + len(self.think_end_token) :]
                return DeltaMessage(
                    reasoning=reasoning_content, content=content if content else None
                )
            elif self.think_end_token_id in previous_token_ids:
                # enable_thinking, </think> in previous,
                # reasoning content continues
                return DeltaMessage(content=delta_text)
            else:
                # enable_thinking, no </think> in previous or delta,
                # reasoning content continues
                return DeltaMessage(reasoning=delta_text)
        else:
            # thinking is disabled, just content
            return DeltaMessage(content=delta_text)

    def extract_reasoning_content(
        self, model_output: str, request: ChatCompletionRequest
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Extract reasoning content from the model output.

        For text 'abc</think>xyz:
        - 'abc' goes to reasoning_content
        - 'xyz' goes to content

        Returns:
            tuple[Optional[str], Optional[str]]: reasoning content and content
        """

        # Check if the model output contains the </think> tokens.
        # If not, return None for reasoning content and the full model output.
        if self.think_end_token not in model_output:
            return None, model_output

        # Extract reasoning content from the model output.
        reasoning_content, _, content = model_output.partition(self.think_end_token)

        final_content = content or None
        return reasoning_content, final_content
