# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
import asyncio
from functools import cached_property
from http import HTTPStatus
import logging
import math
import time
from typing import Optional, Union, cast

from fastapi import Request

from furiosa_llm.api import LLM
from furiosa_llm.llm_engine import AsyncLLMEngine
from furiosa_llm.outputs import PoolingRequestOutput, RequestOutput, ScoringRequestOutput
from furiosa_llm.sampling_params import PoolingParams, SamplingParams, StructuredOutputsParams
from furiosa_llm.server.protocol import (
    ErrorResponse,
    RerankDocument,
    RerankRequest,
    RerankResponse,
    RerankResult,
    RerankUsage,
    ScoreRequest,
    ScoreResponse,
    ScoreResponseData,
    UsageInfo,
)
from furiosa_llm.server.serving_base import OpenAIServing
from furiosa_llm.server.utils import (
    handle_disconnect,
    merge_async_iterators,
    random_uuid,
)
from furiosa_llm.vllm_compat import (
    TokensPrompt,
    apply_prompt_truncation,
    get_score_prompt,
)

logger = logging.getLogger(__name__)


class ServingScores(OpenAIServing):
    def __init__(self, llm: LLM, served_model_name: str) -> None:
        self.async_llm_engine: AsyncLLMEngine = AsyncLLMEngine.from_llm(llm)
        self.tokenizer = llm.tokenizer
        self.model_type = llm.model_metadata.model_type
        self.model_name = served_model_name
        # TODO(n0gu): The following condition might be changed to cover more cross encoder models.
        self._is_cross_encoder_model = llm.model_metadata.use_binary_seq_class

        if self._is_qwen3_model and not self._is_cross_encoder_model:
            self._yes_no_token_ids = (
                cast(int, self.tokenizer.convert_tokens_to_ids("yes")),
                cast(int, self.tokenizer.convert_tokens_to_ids("no")),
            )
            self._suffix_tokens = self.tokenizer.encode(
                "<|im_start|>assistant\n<think>\n\n</think>\n\n", add_special_tokens=False
            )

    async def create_score(
        self,
        request: ScoreRequest,
        raw_request: Request,
    ) -> Union[ScoreResponse, ErrorResponse]:
        """
        Score API for calculating relevance scores between text pairs.
        Supports two input patterns:
        - text_1 as str and text_2 as list: calculate score between text_1 and each element of text_2
        - both as list: same length, calculate score between each element pair
        """
        try:
            if self._is_cross_encoder_model:
                return await self._score_cross_encoder(request, raw_request)
            elif self._is_qwen3_model:
                return await self._score_qwen3(request, raw_request)
            else:
                return self.create_error_response(
                    "only cross encoder models (converted using as_binary_seq_cls) or original Qwen3 reranker models are supported."
                )
        except ValueError as e:
            return self.create_error_response(str(e), "BadRequest", HTTPStatus.BAD_REQUEST)
        except Exception as e:
            logger.error("Error in creating score: %s", e, exc_info=True)
            return self.create_error_response(
                str(e), "InternalServerError", HTTPStatus.INTERNAL_SERVER_ERROR
            )

    async def create_rerank(
        self, request: RerankRequest, raw_request: Request
    ) -> Union[RerankResponse, ErrorResponse]:
        """
        Rerank API based on JinaAI's rerank API; implements the same
        API interface. Designed for compatibility with off-the-shelf
        tooling, since this is a common standard for reranking APIs

        See example client implementations at
        https://github.com/infiniflow/ragflow/blob/main/rag/llm/rerank_model.py
        numerous clients use this standard.
        """
        try:
            if self._is_cross_encoder_model:
                return await self._rerank_cross_encoder(request, raw_request)
            elif self._is_qwen3_model:
                return await self._rerank_qwen3(request, raw_request)
            else:
                return self.create_error_response(
                    "only cross encoder models (converted using as_binary_seq_cls) or original Qwen3 reranker models are supported."
                )
        except ValueError as e:
            return self.create_error_response(str(e), "BadRequest", HTTPStatus.BAD_REQUEST)
        except Exception as e:
            logger.error("Error in creating rerank: %s", e, exc_info=True)
            return self.create_error_response(
                str(e), "InternalServerError", HTTPStatus.INTERNAL_SERVER_ERROR
            )

    # Deprecated: this property is used to support Qwen3 models without as_binary_seq_cls conversion,
    # but it will be removed in the future.
    @cached_property
    def _is_qwen3_model(self) -> bool:
        """
        Check if the model is an original Qwen3 Reranker model.
        Note: support for unconverted Qwen3 Reranker models will be removed.
        """
        return self.model_type == "qwen3"

    async def _score_cross_encoder(
        self,
        request: ScoreRequest,
        raw_request: Request,
    ) -> ScoreResponse:
        """Score API implementation for cross-encoder models."""
        assert self._is_cross_encoder_model

        # Validate and prepare text pairs
        text_1 = request.text_1
        text_2 = request.text_2

        # Determine input pattern and create pairs
        if isinstance(text_1, str) and isinstance(text_2, str):
            pairs = [(text_1, text_2)]
        elif isinstance(text_1, str) and isinstance(text_2, list):
            # text_1 as str and text_2 as list: calculate score between text_1 and elements of text_2
            pairs = [(text_1, doc) for doc in text_2]
        elif isinstance(text_1, list) and isinstance(text_2, list):
            # both as list: must have same length
            if len(text_1) != len(text_2):
                raise ValueError(
                    "When both text_1 and text_2 are lists, they must have the same length."
                )
            pairs = list(zip(text_1, text_2))
        else:
            raise ValueError(
                "Invalid input combination. Expected: (str, list) or (list, list) with same length."
            )

        # Create pooling params
        pooling_params = PoolingParams(
            truncate_prompt_tokens=request.truncate_prompt_tokens,
        )

        # Construct prompts using score template
        prompts: list[TokensPrompt] = []
        for text1, text2 in pairs:
            _, prompt = get_score_prompt(
                self.tokenizer,
                text1,
                text2,
                # Review requested: should we support custom score_template in the API param level or server arg level?
                score_template=None,
            )
            prompts.append(prompt)

        # Validate prompt lengths
        for prompt in prompts:
            pooling_params.verify_max_prompt_len(
                len(prompt["prompt_token_ids"]), self.async_llm_engine.prompt_max_seq_len
            )

        # Run pooling and extract scores
        scores, total_tokens = await self._run_pooling_and_extract_scores(
            prompts, pooling_params, raw_request, "score"
        )

        # Create score response data
        data = [
            ScoreResponseData(index=i, object="score", score=score)
            for i, score in enumerate(scores)
        ]
        return ScoreResponse(
            id=f"score-{random_uuid()}",
            object="list",
            created=int(time.time()),
            model=self.model_name,
            data=data,
            usage=UsageInfo(
                prompt_tokens=total_tokens,
                total_tokens=total_tokens,
                completion_tokens=0,
            ),
        )

    async def _rerank_cross_encoder(
        self,
        request: RerankRequest,
        raw_request: Request,
    ) -> RerankResponse:
        """Rerank API implementation for cross-encoder models."""
        assert self._is_cross_encoder_model

        # Create pooling params
        pooling_params = PoolingParams(
            truncate_prompt_tokens=request.truncate_prompt_tokens,
        )

        # Construct prompts using score template
        prompts: list[TokensPrompt] = []
        for doc in request.documents:
            _, prompt = get_score_prompt(
                self.tokenizer,
                request.query,
                doc,
                score_template=None,
            )
            prompts.append(prompt)

        # Validate prompt lengths
        for prompt in prompts:
            pooling_params.verify_max_prompt_len(
                len(prompt["prompt_token_ids"]), self.async_llm_engine.prompt_max_seq_len
            )

        # Run pooling and extract scores
        scores, total_tokens = await self._run_pooling_and_extract_scores(
            prompts, pooling_params, raw_request, "rerank"
        )

        # Create rerank response data
        results = [
            RerankResult(
                index=i,
                document=RerankDocument(text=doc),
                relevance_score=score,
            )
            for i, (doc, score) in enumerate(zip(request.documents, scores))
        ]

        # Sort by score descending
        results.sort(key=lambda x: x.relevance_score, reverse=True)

        # Apply top_n if specified
        if request.top_n > 0:
            results = results[: request.top_n]

        # Create response
        return RerankResponse(
            id=f"rerank-{random_uuid()}",
            model=self.model_name,
            usage=RerankUsage(total_tokens=total_tokens),
            results=results,
        )

    # Reference: https://huggingface.co/Qwen/Qwen3-Reranker-0.6B
    async def _rerank_qwen3(
        self,
        request: RerankRequest,
        raw_request: Request,
    ) -> RerankResponse:
        assert self._is_qwen3_model
        true_token_id, false_token_id = self._yes_no_token_ids

        # Create sampling params with allowed tokens restricted to yes/no
        sampling_params = SamplingParams(
            temperature=0,
            max_tokens=1,
            logprobs=20,
            # XXX: must pin to llguidance backend, since xgrammar does not support token id level control
            # TODO: implement allowed_token_ids
            structured_outputs=StructuredOutputsParams(
                grammar=f"start: <[{true_token_id},{false_token_id}]>"
            ),
        )

        model_max_prompt_length = self.async_llm_engine.prompt_max_seq_len

        prompts: list[TokensPrompt] = []
        # Format with Qwen3 Reranker's officially recommended instruction
        # ref: https://huggingface.co/Qwen/Qwen3-Reranker-0.6B#vllm-usage
        if request.use_qwen3_template:
            for doc in request.documents:
                prompt = self._apply_qwen3_template(
                    query=request.query,
                    document=doc,
                    truncate_prompt_tokens=request.truncate_prompt_tokens,
                )
                prompts.append(prompt)
        else:
            # Simply concat query and document
            for document in request.documents:
                concat = request.query + document
                input_ids = self.tokenizer.encode(concat)
                apply_prompt_truncation(
                    input_ids,
                    request.truncate_prompt_tokens,
                    model_max_prompt_length,
                )
                prompts.append(TokensPrompt(prompt_token_ids=input_ids))

        # Generate for all prompts
        request_ids = [f"rerank-{random_uuid()}-{i}" for i in range(len(prompts))]
        async_generators = [
            self.async_llm_engine.generate(prompt, sampling_params, request_id)
            for prompt, request_id in zip(prompts, request_ids)
        ]
        asyncio.create_task(
            handle_disconnect(raw_request, lambda: self._abort_request(request_ids))
        )

        # Collect all outputs using merge_async_iterators
        outputs: list[Optional[RequestOutput]] = [None] * len(prompts)
        async for i, output in merge_async_iterators(*async_generators):
            if output.finished:
                outputs[i] = output
            elif outputs[i] is None:
                # Keep the last output even if not finished
                outputs[i] = output

        # Compute scores from logprobs
        scores = []
        total_tokens = 0
        for i, maybe_output in enumerate(outputs):
            if maybe_output is None or len(maybe_output.outputs) == 0:
                raise RuntimeError("Failed to get output from the model.")

            output = maybe_output
            completion_output = output.outputs[0]
            total_tokens += len(output.prompt_token_ids)

            # Get logprobs from the last token (the yes/no token)
            if completion_output.logprobs is None or len(completion_output.logprobs) == 0:
                raise RuntimeError("Failed to get logprobs from the output.")

            final_logprobs = completion_output.logprobs[-1]

            # Extract yes/no logits
            true_logit = final_logprobs.get(true_token_id)
            false_logit = final_logprobs.get(false_token_id)

            true_logprob = true_logit.logprob if true_logit else -10.0
            false_logprob = false_logit.logprob if false_logit else -10.0

            # Compute score using softmax
            true_score = math.exp(true_logprob)
            false_score = math.exp(false_logprob)
            score = (
                true_score / (true_score + false_score) if (true_score + false_score) > 0 else 0.0
            )

            scores.append(score)

        # Create rerank results
        results = [
            RerankResult(
                index=i,
                document=RerankDocument(text=doc),
                relevance_score=score,
            )
            for i, (doc, score) in enumerate(zip(request.documents, scores))
        ]

        # Sort by score descending
        results.sort(key=lambda x: x.relevance_score, reverse=True)

        # Apply top_n if specified
        if request.top_n > 0:
            results = results[: request.top_n]

        # Create response
        return RerankResponse(
            id=f"rerank-{random_uuid()}",
            model=self.model_name,
            usage=RerankUsage(total_tokens=total_tokens),
            results=results,
        )

    # Reference: https://huggingface.co/Qwen/Qwen3-Reranker-0.6B
    async def _score_qwen3(
        self,
        request: ScoreRequest,
        raw_request: Request,
    ) -> ScoreResponse:
        assert self._is_qwen3_model
        true_token_id, false_token_id = self._yes_no_token_ids

        # Validate and prepare text pairs
        text_1 = request.text_1
        text_2 = request.text_2

        # Determine input pattern and create pairs
        if isinstance(text_1, str) and isinstance(text_2, str):
            pairs = [(text_1, text_2)]
        elif isinstance(text_1, str) and isinstance(text_2, list):
            # text_1 as str and text_2 as list: calculate score between text_1 and elements of text_2
            pairs = [(text_1, doc) for doc in text_2]
        elif isinstance(text_1, list) and isinstance(text_2, list):
            # both as list: must have same length
            if len(text_1) != len(text_2):
                raise ValueError(
                    "When both text_1 and text_2 are lists, they must have the same length."
                )
            pairs = list(zip(text_1, text_2))
        else:
            raise ValueError(
                "Invalid input combination. Expected: (str, list) or (list, list) with same length."
            )

        # Create sampling params with allowed tokens restricted to yes/no
        sampling_params = SamplingParams(
            temperature=0,
            max_tokens=1,
            logprobs=20,
            # XXX: must pin to llguidance backend, since xgrammar does not support token id level control
            # TODO: implement allowed_token_ids
            structured_outputs=StructuredOutputsParams(
                grammar=f"start: <[{true_token_id},{false_token_id}]>"
            ),
        )

        model_max_prompt_length = self.async_llm_engine.prompt_max_seq_len

        prompts: list[TokensPrompt] = []
        # Format with Qwen3 Reranker's officially recommended instruction
        # ref: https://huggingface.co/Qwen/Qwen3-Reranker-0.6B#vllm-usage
        if request.use_qwen3_template:
            for text1, text2 in pairs:
                prompt = self._apply_qwen3_template(
                    query=text1,
                    document=text2,
                    truncate_prompt_tokens=request.truncate_prompt_tokens,
                )
                prompts.append(prompt)
        else:
            # Simply concat text_1 and text_2
            for text1, text2 in pairs:
                concat = text1 + text2
                input_ids = self.tokenizer.encode(concat)
                apply_prompt_truncation(
                    input_ids,
                    request.truncate_prompt_tokens,
                    model_max_prompt_length,
                )
                prompts.append(TokensPrompt(prompt_token_ids=input_ids))

        # Generate for all prompts
        request_ids = [f"score-{random_uuid()}-{i}" for i in range(len(prompts))]
        async_generators = [
            self.async_llm_engine.generate(prompt, sampling_params, request_id)
            for prompt, request_id in zip(prompts, request_ids)
        ]
        asyncio.create_task(
            handle_disconnect(raw_request, lambda: self._abort_request(request_ids))
        )

        # Collect all outputs using merge_async_iterators
        outputs: list[Optional[RequestOutput]] = [None] * len(prompts)
        async for i, output in merge_async_iterators(*async_generators):
            if output.finished:
                outputs[i] = output
            elif outputs[i] is None:
                # Keep the last output even if not finished
                outputs[i] = output

        # Compute scores from logprobs
        scores = []
        total_tokens = 0
        for i, maybe_output in enumerate(outputs):
            if maybe_output is None or len(maybe_output.outputs) == 0:
                raise RuntimeError("Failed to get output from the model.")

            output = maybe_output
            completion_output = output.outputs[0]
            total_tokens += len(output.prompt_token_ids)

            # Get logprobs from the last token (the yes/no token)
            if completion_output.logprobs is None or len(completion_output.logprobs) == 0:
                raise RuntimeError("Failed to get logprobs from the output.")

            final_logprobs = completion_output.logprobs[-1]

            # Extract yes/no logits
            true_logit = final_logprobs.get(true_token_id)
            false_logit = final_logprobs.get(false_token_id)

            true_logprob = true_logit.logprob if true_logit else -10.0
            false_logprob = false_logit.logprob if false_logit else -10.0

            # Compute score using softmax
            true_score = math.exp(true_logprob)
            false_score = math.exp(false_logprob)
            score = (
                true_score / (true_score + false_score) if (true_score + false_score) > 0 else 0.0
            )

            scores.append(score)

        # Create score response data
        data = [
            ScoreResponseData(index=i, object="score", score=score)
            for i, score in enumerate(scores)
        ]

        # Create response
        return ScoreResponse(
            id=f"score-{random_uuid()}",
            object="list",
            created=int(time.time()),
            model=self.model_name,
            data=data,
            usage=UsageInfo(
                prompt_tokens=total_tokens,
                total_tokens=total_tokens,
                completion_tokens=0,
            ),
        )

    def _apply_qwen3_template(
        self,
        query: str,
        document: str,
        truncate_prompt_tokens: Optional[int],
    ) -> TokensPrompt:
        """
        Format a query and document pair using Qwen3-Reranker's official template.

        Args:
            query: The query text.
            document: The document text.
            truncate_prompt_tokens: Optional truncation parameter. If specified, keeps only
                the last k tokens after truncation.

        Returns:
            A TokensPrompt containing the formatted and tokenized prompt.
        """
        instruction = "Given a web search query, retrieve relevant passages that answer the query"
        messages = [
            {
                "role": "system",
                "content": "Judge whether the Document meets the requirements based on the Query and the Instruct provided. Note that the answer can only be \"yes\" or \"no\".",
            },
            {
                "role": "user",
                "content": f"<Instruct>: {instruction}\n<Query>: {query}\n<Document>: {document}",
            },
        ]

        # Apply chat template
        input_ids = cast(
            list[int],
            self.tokenizer.apply_chat_template(
                messages,
                tokenize=True,
                add_generation_prompt=False,
                enable_thinking=False,
            ),
        )
        model_max_prompt_length = self.async_llm_engine.prompt_max_seq_len
        # Apply truncation if specified
        apply_prompt_truncation(
            input_ids,
            truncate_prompt_tokens,
            model_max_prompt_length - len(self._suffix_tokens),
        )

        final_token_ids = input_ids + self._suffix_tokens
        return TokensPrompt(prompt_token_ids=final_token_ids)

    async def _abort_request(self, request_ids: list[str]) -> None:
        for request_id in request_ids:
            await self.async_llm_engine.abort(request_id)

    async def _run_pooling_and_extract_scores(
        self,
        prompts: list[TokensPrompt],
        pooling_params: PoolingParams,
        raw_request: Request,
        request_prefix: str,
    ) -> tuple[list[float], int]:
        """
        Run pooling requests for cross-encoder models and extract scores.

        Args:
            prompts: List of tokenized prompts to process.
            pooling_params: Parameters for pooling.
            raw_request: The raw FastAPI request for disconnect handling.
            request_prefix: Prefix for request IDs (e.g., "score" or "rerank").

        Returns:
            A tuple of (scores, total_tokens).
        """
        request_ids = [f"{request_prefix}-{random_uuid()}-{i}" for i in range(len(prompts))]
        async_generators = [
            self.async_llm_engine.encode(prompt, pooling_params, request_id)
            for prompt, request_id in zip(prompts, request_ids)
        ]
        asyncio.create_task(
            handle_disconnect(raw_request, lambda: self._abort_request(request_ids))
        )

        # Collect all outputs using merge_async_iterators
        outputs: list[PoolingRequestOutput | None] = [None] * len(prompts)
        async for i, output in merge_async_iterators(*async_generators):
            if output.finished:
                outputs[i] = output
            elif outputs[i] is None:
                outputs[i] = output

        # Extract scores from pooling outputs
        scores = []
        total_tokens = 0
        for i, maybe_output in enumerate(outputs):
            if maybe_output is None:
                raise RuntimeError("Failed to get output from the model.")
            scoring_output = ScoringRequestOutput.from_base(maybe_output)
            scores.append(scoring_output.outputs.score)
            total_tokens += len(scoring_output.prompt_token_ids)

        return scores, total_tokens
