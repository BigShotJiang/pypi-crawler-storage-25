# Adapted from
# https://github.com/vllm-project/vllm/blob/main/vllm/entrypoints/openai/responses
"""Response store for managing response state.

This module provides a simple in-memory store for managing response state,
enabling response retrieval and cancellation in the OpenResponses API.
"""

import asyncio
from dataclasses import dataclass, field
from threading import Lock
import time
from typing import Any, Dict, List, Optional

from openai.types.responses import (
    ResponseOutputItem,
    ResponseStatus,
)

from furiosa_llm.server.protocol import ResponsesResponse, ResponseUsage


@dataclass
class StoredResponse:
    """A stored response with its metadata and state."""

    response: ResponsesResponse
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    # For background streaming, we store the events
    streaming_events: List[Any] = field(default_factory=list)
    # For cancellation
    is_cancelled: bool = False
    cancel_event: Optional[asyncio.Event] = None


class ResponseStore:
    """In-memory store for managing response state.

    This store provides thread-safe access to stored responses, enabling:
    - Response retrieval by ID
    - Response state updates
    - Response cancellation
    - Automatic cleanup of old responses

    Note: This is an in-memory store and responses will be lost on restart.
    For persistent storage, a database-backed implementation would be needed.
    """

    def __init__(
        self,
        max_responses: int = 10000,
        ttl_seconds: int = 3600,
    ):
        """Initialize the response store.

        Args:
            max_responses: Maximum number of responses to store.
            ttl_seconds: Time-to-live for responses in seconds.
        """
        self._store: Dict[str, StoredResponse] = {}
        # Stores the full chat message history for each response, enabling
        # conversation continuation via previous_response_id.
        # TODO(reviewer): This stores messages for ALL responses which may cause
        # memory growth. Consider adding a TTL-based cleanup or an env-var toggle
        # if this becomes a concern in production.
        self._messages: Dict[str, List[Dict[str, Any]]] = {}
        self._lock = Lock()
        self._max_responses = max_responses
        self._ttl_seconds = ttl_seconds

    def store(self, response: ResponsesResponse) -> None:
        """Store a response.

        Args:
            response: The response to store.
        """
        with self._lock:
            # Cleanup old responses if we're at capacity
            if len(self._store) >= self._max_responses:
                self._cleanup_old_responses()

            self._store[response.id] = StoredResponse(
                response=response,
                cancel_event=asyncio.Event(),
            )

    def get(self, response_id: str) -> Optional[ResponsesResponse]:
        """Get a response by ID.

        Args:
            response_id: The response ID.

        Returns:
            The response if found, None otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return None
            return stored.response

    def get_stored(self, response_id: str) -> Optional[StoredResponse]:
        """Get the stored response wrapper by ID.

        Args:
            response_id: The response ID.

        Returns:
            The StoredResponse if found, None otherwise.
        """
        with self._lock:
            return self._store.get(response_id)

    def store_messages(self, response_id: str, messages: List[Dict[str, Any]]) -> None:
        """Store the chat message history for a response.

        Args:
            response_id: The response ID.
            messages: The full conversation message list.
        """
        with self._lock:
            self._messages[response_id] = messages

    def get_messages(self, response_id: str) -> Optional[List[Dict[str, Any]]]:
        """Get stored chat message history for a response.

        Args:
            response_id: The response ID.

        Returns:
            The message list if found, None otherwise.
        """
        with self._lock:
            return self._messages.get(response_id)

    def update(
        self,
        response_id: str,
        *,
        status: Optional[ResponseStatus] = None,
        output: Optional[List[ResponseOutputItem]] = None,
        usage: Optional[ResponseUsage] = None,
        completed_at: Optional[int] = None,
    ) -> Optional[ResponsesResponse]:
        """Update a stored response.

        Args:
            response_id: The response ID.
            status: New status for the response.
            output: New output items for the response.
            usage: New usage information for the response.
            completed_at: Completion timestamp.

        Returns:
            The updated response if found, None otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return None

            # Create an updated response
            # Note: Response is immutable, so we need to create a new one
            current = stored.response
            update_dict: Dict[str, Any] = {}

            if status is not None:
                update_dict["status"] = status
            if output is not None:
                update_dict["output"] = output
            if usage is not None:
                update_dict["usage"] = usage
            if completed_at is not None:
                update_dict["completed_at"] = completed_at

            if update_dict:
                # Create a new response with updates
                response_dict = current.model_dump(by_alias=True)
                response_dict.update(update_dict)
                stored.response = ResponsesResponse.model_validate(response_dict)
                stored.updated_at = time.time()

            return stored.response

    def add_streaming_event(self, response_id: str, event: Any) -> bool:
        """Add a streaming event to a stored response.

        Args:
            response_id: The response ID.
            event: The event to add.

        Returns:
            True if the event was added, False if the response was not found.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return False
            stored.streaming_events.append(event)
            stored.updated_at = time.time()
            return True

    def get_streaming_events(
        self, response_id: str, starting_after: Optional[int] = None
    ) -> Optional[List[Any]]:
        """Get streaming events for a response.

        Args:
            response_id: The response ID.
            starting_after: Index to start from (exclusive).

        Returns:
            List of events if response found, None otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return None
            if starting_after is None:
                return list(stored.streaming_events)
            return list(stored.streaming_events[starting_after + 1 :])

    def cancel(self, response_id: str) -> Optional[ResponsesResponse]:
        """Cancel a response.

        Args:
            response_id: The response ID.

        Returns:
            The cancelled response if found and cancellable, None otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return None

            # Only cancel if in progress
            if stored.response.status not in ("in_progress", "queued"):
                return stored.response

            stored.is_cancelled = True
            if stored.cancel_event:
                stored.cancel_event.set()

            # Update status to cancelled
            response_dict = stored.response.model_dump(by_alias=True)
            response_dict["status"] = "cancelled"
            stored.response = ResponsesResponse.model_validate(response_dict)
            stored.updated_at = time.time()

            return stored.response

    def is_cancelled(self, response_id: str) -> bool:
        """Check if a response has been cancelled.

        Args:
            response_id: The response ID.

        Returns:
            True if cancelled, False otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return False
            return stored.is_cancelled

    def get_cancel_event(self, response_id: str) -> Optional[asyncio.Event]:
        """Get the cancellation event for a response.

        Args:
            response_id: The response ID.

        Returns:
            The cancellation event if found, None otherwise.
        """
        with self._lock:
            stored = self._store.get(response_id)
            if stored is None:
                return None
            return stored.cancel_event

    def delete(self, response_id: str) -> bool:
        """Delete a response.

        Args:
            response_id: The response ID.

        Returns:
            True if deleted, False if not found.
        """
        with self._lock:
            if response_id in self._store:
                del self._store[response_id]
                self._messages.pop(response_id, None)
                return True
            return False

    # TODO(n0gu): Currently cleanup only runs when a new entry is inserted.
    # For proper TTL-based eviction, a periodic background task should be added.
    def _cleanup_old_responses(self) -> None:
        """Remove expired responses. Called with lock held."""
        current_time = time.time()
        expired_ids = [
            response_id
            for response_id, stored in self._store.items()
            if current_time - stored.created_at > self._ttl_seconds
        ]
        for response_id in expired_ids:
            del self._store[response_id]
            self._messages.pop(response_id, None)

        # If still at capacity, remove oldest responses
        if len(self._store) >= self._max_responses:
            sorted_by_age = sorted(
                self._store.items(),
                key=lambda x: x[1].created_at,
            )
            # Remove oldest 10%
            to_remove = max(1, len(sorted_by_age) // 10)
            for response_id, _ in sorted_by_age[:to_remove]:
                del self._store[response_id]
                self._messages.pop(response_id, None)

    def __len__(self) -> int:
        """Return the number of stored responses."""
        with self._lock:
            return len(self._store)
