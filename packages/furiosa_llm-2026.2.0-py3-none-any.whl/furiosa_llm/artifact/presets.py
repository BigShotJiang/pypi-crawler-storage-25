"""Preset registry for automatic artifact configuration.

This module defines default configurations (presets) for supported models.
When ``ArtifactBuilder`` receives an empty ``BucketConfig``, it looks up a matching
preset based on the model's ``(model_type, hidden_size, intermediate_size)`` from
the HuggingFace ``PretrainedConfig``.

Matching uses the same per-layer parameter log-distance algorithm as
``COMPILER_CONFIG_REFS`` in ``furiosa-compiler-python``, so fine-tuned models
with the same architecture with little modification should still get a good preset match.
"""

from dataclasses import dataclass
import logging
import math
from typing import List, Optional, Sequence, Tuple

from furiosa.native_common.compiler import approx_per_layer_params_b as _approx_per_layer_params_b
from furiosa_llm.artifact.types.config import BucketConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PresetRef:
    """Reference entry mapping model identity to a :class:`BucketConfig`.

    ``hidden_size`` and ``intermediate_size`` come from the model's HuggingFace
    ``config.json``.  The approximate per-layer parameter count is computed via
    ``furiosa.native_common.compiler.approx_per_layer_params_b`` for log-distance matching.
    """

    model_type: str
    hidden_size: int
    intermediate_size: int
    preset: BucketConfig


# ---------------------------------------------------------------------------
# Preset constants
# ---------------------------------------------------------------------------

# -- helpers for building append bucket lists --------------------------------


def _build_append_buckets(
    attn_sizes: List[int],
    input_sizes: List[int],
    exclude: Optional[Sequence[Tuple[int, int]]] = None,
) -> Tuple[Tuple[int, int, int], ...]:
    excluded = set(exclude) if exclude else set()
    return tuple(
        (1, a, i) for a in attn_sizes for i in input_sizes if a > i and (a, i) not in excluded
    )


# [256, 384, 512, 768, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072]
_COMMON_APPEND_ATTN_SIZES = [256, 384, 512, 768] + [1024 * (2**x) for x in range(8)]
# [128, 256, 384, 512, 640, 768, 896, 1024]
_COMMON_APPEND_INPUT_SIZES = list(range(128, 1024 + 1, 128))


# -- Qwen 2.5 0.5B ----------------------------------------------------------

QWEN_2_5_0D5B_PRESET = BucketConfig(
    prefill_buckets=((1, 1024), (1, 2048), (1, 3072), (1, 4096)),
    decode_buckets=((128, 1024), (128, 2048), (128, 3072), (128, 4096)),
    tokenwise_seq_lens=(128, 1024, 2048, 3072, 4096),
)


# -- EXAONE 4 32B -----------------------------------------------------------

# fmt: off
EXAONE_4_32B_PRESET = BucketConfig(
    prefill_buckets=tuple((1, x) for x in range(128, 1024 + 1, 128)),
    decode_buckets=(
        (1, 512), (1, 1024), (1, 2 * 1024), (1, 4 * 1024), (1, 8 * 1024), (1, 16 * 1024), (1, 32 * 1024), (1, 64 * 1024), (1, 128 * 1024),
        (2, 512), (2, 1024), (2, 2 * 1024), (2, 4 * 1024), (2, 8 * 1024), (2, 16 * 1024), (2, 32 * 1024), (2, 64 * 1024), (2, 128 * 1024),
        (4, 512), (4, 1024), (4, 2 * 1024), (4, 4 * 1024), (4, 8 * 1024), (4, 16 * 1024), (4, 32 * 1024), (4, 64 * 1024), (4, 128 * 1024),
        (8, 512), (8, 1024), (8, 2 * 1024), (8, 4 * 1024), (8, 8 * 1024), (8, 16 * 1024), (8, 32 * 1024), (8, 64 * 1024),
        (16, 512), (16, 1024), (16, 2 * 1024), (16, 4 * 1024), (16, 8 * 1024), (16, 16 * 1024), (16, 32 * 1024),
        (32, 512), (32, 1024), (32, 2 * 1024), (32, 4 * 1024), (32, 8 * 1024), (32, 16 * 1024),
        (64, 512), (64, 1024), (64, 2 * 1024), (64, 4 * 1024), (64, 8 * 1024), (64, 16 * 1024),
        (128, 512), (128, 1024), (128, 2 * 1024), (128, 4 * 1024),
        (256, 512), (256, 1024), (256, 2 * 1024), (256, 4 * 1024),
    ),
    # NOTE: (1, 1024, 256) is excluded due to a runtime timeout issue.
    # See: https://github.com/furiosa-ai/furiosa-runtime/pull/3221
    append_buckets=_build_append_buckets(
        _COMMON_APPEND_ATTN_SIZES, _COMMON_APPEND_INPUT_SIZES, exclude=[(1024, 256)]
    ),
    tokenwise_seq_lens=(2, 4, 8, 16, 32, 64, 128, 256, 384, 512, 1024),
)
# fmt: on


# -- Llama 3.1 8B -----------------------------------------------------------

# fmt: off
LLAMA_3_1_8B_PRESET = BucketConfig(
    prefill_buckets=tuple((1, x) for x in range(128, 1024 + 1, 128)),
    decode_buckets=(
        (1, 1024), (1, 2 * 1024), (1, 4 * 1024), (1, 8 * 1024), (1, 16 * 1024), (1, 32 * 1024), (1, 64 * 1024), (1, 128 * 1024),
        (2, 1024), (2, 2 * 1024), (2, 4 * 1024), (2, 8 * 1024), (2, 16 * 1024), (2, 32 * 1024), (2, 64 * 1024), (2, 128 * 1024),
        (4, 1024), (4, 2 * 1024), (4, 4 * 1024), (4, 8 * 1024), (4, 16 * 1024), (4, 32 * 1024), (4, 64 * 1024),
        (8, 1024), (8, 2 * 1024), (8, 4 * 1024), (8, 8 * 1024), (8, 16 * 1024), (8, 32 * 1024),
        (16, 1024), (16, 2 * 1024), (16, 4 * 1024), (16, 8 * 1024), (16, 16 * 1024),
        (32, 1024), (32, 2 * 1024), (32, 4 * 1024), (32, 8 * 1024),
        (64, 1024), (64, 2 * 1024), (64, 4 * 1024),
        (128, 1024), (128, 2 * 1024), (128, 4 * 1024),
        (256, 1024), (256, 2 * 1024),
    ),
    append_buckets=_build_append_buckets(_COMMON_APPEND_ATTN_SIZES, _COMMON_APPEND_INPUT_SIZES),
    tokenwise_seq_lens=(1, 2, 4, 8, 16, 32, 64, 128, 256, 384, 512, 1024),
)
# fmt: on


# -- Llama 3.3 70B ----------------------------------------------------------

# fmt: off
LLAMA_3_3_70B_PRESET = BucketConfig(
    prefill_buckets=tuple((1, x) for x in range(128, 1024 + 1, 128)),
    decode_buckets=(
        (1, 1024), (1, 2 * 1024), (1, 4 * 1024), (1, 8 * 1024), (1, 16 * 1024), (1, 32 * 1024), (1, 64 * 1024), (1, 128 * 1024),
        (2, 1024), (2, 2 * 1024), (2, 4 * 1024), (2, 8 * 1024), (2, 16 * 1024), (2, 32 * 1024), (2, 64 * 1024), (2, 128 * 1024),
        (4, 1024), (4, 2 * 1024), (4, 4 * 1024), (4, 8 * 1024), (4, 16 * 1024), (4, 32 * 1024), (4, 64 * 1024),
        (8, 1024), (8, 2 * 1024), (8, 4 * 1024), (8, 8 * 1024), (8, 16 * 1024), (8, 32 * 1024),
        (16, 1024), (16, 2 * 1024), (16, 4 * 1024), (16, 8 * 1024), (16, 16 * 1024),
        (32, 1024), (32, 2 * 1024), (32, 4 * 1024),
        (64, 1024), (64, 2 * 1024), (64, 4 * 1024),
        (128, 1024), (128, 2 * 1024), (128, 4 * 1024),
        (256, 1024), (256, 2 * 1024),
    ),
    append_buckets=_build_append_buckets(_COMMON_APPEND_ATTN_SIZES, _COMMON_APPEND_INPUT_SIZES),
    tokenwise_seq_lens=(1, 2, 4, 8, 16, 32, 64, 128, 256, 384, 512, 1024),
)
# fmt: on


# -- Qwen 3 32B FP8 ---------------------------------------------------------

# fmt: off
QWEN_3_32B_FP8_PRESET = BucketConfig(
    prefill_buckets=tuple((1, x) for x in range(128, 1024 + 1, 128)),
    decode_buckets=(
        (1, 1024), (1, 2 * 1024), (1, 4 * 1024), (1, 8 * 1024), (1, 16 * 1024), (1, 32 * 1024), (1, 40 * 1024),
        (2, 1024), (2, 2 * 1024), (2, 4 * 1024), (2, 8 * 1024), (2, 16 * 1024), (2, 32 * 1024), (2, 40 * 1024),
        (4, 1024), (4, 2 * 1024), (4, 4 * 1024), (4, 8 * 1024), (4, 16 * 1024), (4, 32 * 1024), (4, 40 * 1024),
        (8, 1024), (8, 2 * 1024), (8, 4 * 1024), (8, 8 * 1024), (8, 16 * 1024), (8, 32 * 1024),
        (16, 1024), (16, 2 * 1024), (16, 4 * 1024), (16, 8 * 1024), (16, 16 * 1024), (16, 32 * 1024),
        (32, 1024), (32, 2 * 1024), (32, 4 * 1024), (32, 8 * 1024), (32, 16 * 1024), (32, 32 * 1024),
        (64, 1024), (64, 2 * 1024), (64, 4 * 1024), (64, 8 * 1024), (64, 16 * 1024),
        (128, 1024), (128, 2 * 1024), (128, 4 * 1024),
        (256, 1024), (256, 2 * 1024), (256, 4 * 1024),
    ),
    append_buckets=(
        (1, 256, 128),
        (1, 384, 128),
        (1, 512, 128), (1, 512, 256), (1, 512, 384),
        (1, 768, 128), (1, 768, 256), (1, 768, 384), (1, 768, 512), (1, 768, 640),
        (1, 1024, 128), (1, 1024, 256), (1, 1024, 384), (1, 1024, 512), (1, 1024, 640), (1, 1024, 768), (1, 1024, 896),
        (1, 2048, 128), (1, 2048, 256), (1, 2048, 384), (1, 2048, 512), (1, 2048, 640), (1, 2048, 768), (1, 2048, 896), (1, 2048, 1024),
        (1, 4096, 128), (1, 4096, 256), (1, 4096, 384), (1, 4096, 512), (1, 4096, 640), (1, 4096, 768), (1, 4096, 896), (1, 4096, 1024),
        (1, 8192, 128), (1, 8192, 256), (1, 8192, 384), (1, 8192, 512), (1, 8192, 640), (1, 8192, 768), (1, 8192, 896), (1, 8192, 1024),
        (1, 16 * 1024, 128), (1, 16 * 1024, 256), (1, 16 * 1024, 384), (1, 16 * 1024, 512), (1, 16 * 1024, 640), (1, 16 * 1024, 768), (1, 16 * 1024, 896), (1, 16 * 1024, 1024),
        (1, 32 * 1024, 128), (1, 32 * 1024, 256), (1, 32 * 1024, 384), (1, 32 * 1024, 512), (1, 32 * 1024, 640), (1, 32 * 1024, 768), (1, 32 * 1024, 896), (1, 32 * 1024, 1024),
        (1, 40 * 1024, 128),
    ),
    tokenwise_seq_lens=(1, 2, 4, 8, 16, 32, 64, 128, 256, 384, 512, 1024),
)
# fmt: on


# -- Qwen 3 8B (Embedding / Reranker) --------------------------------------

# NOTE: prefill_buckets only contains B1, so these models run sequentially one request at a time.
# Multi-sample CI tests (test_qwen3_reranker_multi_sample, test_qwen3_embedding_multi_sample)
# are currently disabled (#[ignore]) until batch execution is supported.
# TODO: enable batch prefill buckets and re-enable the multi-sample tests.
QWEN_3_8B_POOLING_PRESET = BucketConfig(
    prefill_buckets=((1, 8192),),
    tokenwise_seq_lens=(8192,),
)


# -- Qwen 3 30B-A3B (MoE) --------------------------------------------------

QWEN_3_30B_A3B_PRESET = BucketConfig(
    prefill_buckets=((1, 8), (1, 128)),
    decode_buckets=((1, 1024), (1, 8 * 1024)),
    append_buckets=(
        (1, 256, 128),
        (1, 8 * 1024, 128),
    ),
    tokenwise_seq_lens=(8, 128, 1024),
)


# ---------------------------------------------------------------------------
# Preset registry
# ---------------------------------------------------------------------------

PRESET_REFS: Sequence[PresetRef] = (
    # Qwen 2.5 0.5B  (h=896, i=4864)
    PresetRef(
        model_type="qwen2",
        hidden_size=896,
        intermediate_size=4864,
        preset=QWEN_2_5_0D5B_PRESET,
    ),
    # EXAONE 4 32B  (h=5120, i=27392)
    PresetRef(
        model_type="exaone4",
        hidden_size=5120,
        intermediate_size=27392,
        preset=EXAONE_4_32B_PRESET,
    ),
    # Llama 3.1 8B  (h=4096, i=14336)
    PresetRef(
        model_type="llama",
        hidden_size=4096,
        intermediate_size=14336,
        preset=LLAMA_3_1_8B_PRESET,
    ),
    # Llama 3.3 70B  (h=8192, i=28672)
    PresetRef(
        model_type="llama",
        hidden_size=8192,
        intermediate_size=28672,
        preset=LLAMA_3_3_70B_PRESET,
    ),
    # Qwen 3 32B FP8  (h=5120, i=25600)
    PresetRef(
        model_type="qwen3",
        hidden_size=5120,
        intermediate_size=25600,
        preset=QWEN_3_32B_FP8_PRESET,
    ),
    # Qwen 3 8B Embedding/Reranker  (h=4096, i=12288)
    PresetRef(
        model_type="qwen3",
        hidden_size=4096,
        intermediate_size=12288,
        preset=QWEN_3_8B_POOLING_PRESET,
    ),
    # Qwen 3 30B-A3B MoE  (h=2048, i=6144)
    PresetRef(
        model_type="qwen3_moe",
        hidden_size=2048,
        intermediate_size=6144,
        preset=QWEN_3_30B_A3B_PRESET,
    ),
)


# ---------------------------------------------------------------------------
# Lookup functions
# ---------------------------------------------------------------------------


def find_preset(
    model_type: str,
    hidden_size: int,
    intermediate_size: int,
) -> Optional[BucketConfig]:
    """Find the best-matching :class:`BucketConfig` for a model.

    Filters ``PRESET_REFS`` by *model_type*, then selects the entry
    whose per-layer parameter count is closest (log-distance) to the query.

    Returns ``None`` when no entry matches the given *model_type*.
    """
    input_params = _approx_per_layer_params_b(hidden_size, intermediate_size)
    if input_params <= 0:
        return None

    log_input = math.log(input_params)
    candidates = [r for r in PRESET_REFS if r.model_type == model_type]
    if not candidates:
        return None

    best = min(
        candidates,
        key=lambda r: abs(
            math.log(_approx_per_layer_params_b(r.hidden_size, r.intermediate_size)) - log_input
        ),
    )
    return best.preset


def filter_preset_by_max_model_len(
    preset: BucketConfig,
    max_model_len: int,
) -> BucketConfig:
    """Return a copy of *preset* with buckets exceeding *max_model_len* removed.

    For prefill/decode buckets the second element (attention_size) is checked.
    For append buckets the second element (attention_size) is checked.
    For tokenwise_seq_lens the value itself is checked.
    """
    return BucketConfig(
        prefill_buckets=tuple(b for b in preset.prefill_buckets if b[1] <= max_model_len),
        decode_buckets=tuple(b for b in preset.decode_buckets if b[1] <= max_model_len),
        append_buckets=tuple(b for b in preset.append_buckets if b[1] <= max_model_len),
        tokenwise_seq_lens=tuple(s for s in preset.tokenwise_seq_lens if s <= max_model_len),
    )
