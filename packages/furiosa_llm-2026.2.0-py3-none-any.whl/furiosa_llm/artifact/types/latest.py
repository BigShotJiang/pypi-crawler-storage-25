from pydantic import BaseModel

from ...metadata.config_types import PipelineMetadata  # noqa: F401 (re-exported for Rust binding)


class ArtifactMetadata(BaseModel):
    artifact_id: str
    name: str
    timestamp: int
    furiosa_llm_version: str
    furiosa_compiler_version: str
    includes_composable_ir: bool
