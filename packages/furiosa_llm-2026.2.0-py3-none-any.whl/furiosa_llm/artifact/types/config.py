"""Configuration classes for ArtifactBuilder.

This module defines consolidated configuration classes that group related parameters
for the ArtifactBuilder class, improving code organization and maintainability.
"""

from __future__ import annotations

import os
from typing import (
    Any,
    Callable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

from pydantic import BaseModel, ConfigDict

from furiosa_llm.metadata.config_types import AttentionBucket
from furiosa_llm.metadata.tasks import UnresolvedTaskType
from furiosa_llm.parallelize.pipeline.builder.converter import DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE


class ModelConfig(BaseModel):
    """Configuration for model source and HuggingFace settings.

    Attributes:
        trust_remote_code: Trust remote code when downloading the model and tokenizer
            from HuggingFace.
        revision: Model revision/branch from HuggingFace.
        hf_overrides: Additional HuggingFace Transformers model configuration.
        seed_for_random_weight: The seed to initialize the random number generator
            for creating random weight.
        task: Task type (generation or pooling). Defaults to 'auto', which
            auto-detects the task type from the model.
        binary_classification_head: Use a binary classification head for pooling tasks if applicable.
        max_model_len: Maximum model context length. When set, this value is used
            instead of the model's ``max_position_embeddings`` for bucket preset
            filtering and bucket limit validation. Defaults to ``None``, which
            falls back to ``max_position_embeddings`` from the HuggingFace config.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    trust_remote_code: Optional[bool] = None
    revision: Optional[str] = None
    hf_overrides: Mapping[str, Any] = {}
    seed_for_random_weight: Optional[int] = None
    task: UnresolvedTaskType = "auto"
    binary_classification_head: bool = False
    max_model_len: Optional[int] = None


class BucketConfig(BaseModel):
    """Configuration for attention buckets and sequence lengths.

    Attributes:
        prefill_buckets: Specify the bucket size for prefill as (batch_size, context_length).
        decode_buckets: Specify the bucket size for decode as (batch_size, context_length).
        append_buckets: Specify the append buckets used to manage multiple input_ids
            together with the KV cache. Must be 3-tuples representing
            (batch_size, attention_size, input_ids_size).
        tokenwise_seq_lens: Tokenwise sequence lengths for composable kernel.
        skip_validation: Skip bucket validation checks. **Use with caution** — this
            bypasses both the raw-bucket validation (duplicate detection, prefill
            requirement, positive-dimension checks) and the post-resolve validation
            (max_model_len bounds, decode-bucket requirements for generative models).
            Intended only for special-purpose builds such as partial-bucket artifacts
            where the standard rules do not apply.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, frozen=True)

    prefill_buckets: Sequence[Tuple[int, int]] = ()
    decode_buckets: Sequence[Tuple[int, int]] = ()
    append_buckets: Sequence[Tuple[int, int, int]] = ()
    tokenwise_seq_lens: Sequence[int] = ()
    skip_validation: bool = False

    def has_explicit_buckets(self) -> bool:
        """Return True if any bucket field is explicitly populated."""
        return bool(
            self.prefill_buckets
            or self.decode_buckets
            or self.append_buckets
            or self.tokenwise_seq_lens
        )


class CompilerConfig(BaseModel):
    """Configuration for compiler and model rewriting.

    Attributes:
        compiler_config_overrides: Overrides for the compiler config.
        do_decompositions_for_model_rewrite: Whether to decompose some ops to describe
            various parallelism strategies with mppp config.
        use_blockwise_compile: If True, each task will be compiled in the unit of
            transformer block. The default is True.
        num_blocks_per_supertask: The number of transformer blocks that will be merged
            into one supertask. Valid only when use_blockwise_compile=True.
        embed_all_constants_into_graph: Whether to embed constant tensors into graph
            or make them as input of the graph and save them as separate files.
        paged_attention_block_size: The maximum number of tokens that can be stored
            in a single paged attention block.
        composable_kernel: Use composable kernel compilation.
        use_activation_dq: Use activation dynamic quantization.
            Will be ignored if not available in given composable kernel compilation.
        includes_composable_ir: Includes composable IR.
        embedding_layer_as_single_block: Treat embedding layer as single block.
        enable_bf16_partial_sum_for_split: Enable bf16 partial sum for split.
        max_embeddable_constant_size: Maximum embeddable constant size.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    compiler_config_overrides: Mapping[Any, Any] = {}
    do_decompositions_for_model_rewrite: bool = False
    use_blockwise_compile: bool = True
    num_blocks_per_supertask: Union[
        Union[int, Sequence[int]], Callable[[AttentionBucket], Union[int, Sequence[int]]]
    ] = 1
    embed_all_constants_into_graph: bool = False
    paged_attention_block_size: int = 1
    composable_kernel: bool = True
    use_activation_dq: bool = False
    includes_composable_ir: bool = False
    embedding_layer_as_single_block: bool = False
    enable_bf16_partial_sum_for_split: bool = True
    max_embeddable_constant_size: int = DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE


class ArtifactConfig(BaseModel):
    """Configuration for artifact export.

    Attributes:
        copies_from_model: Relative paths of files to copy from the model directory
            (e.g., LICENSE.txt).
        copies_from_local: Relative paths of files to copy from the local directory
            (e.g., README.md).
        bundle_binaries: If True, all compiled binaries will be bundled into a single
            archive file (binary_bundle.zip) in the output directory.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    copies_from_model: Optional[List[str]] = None
    copies_from_local: Optional[List[os.PathLike]] = None
    bundle_binaries: bool = True


class ParallelConfig(BaseModel):
    """Configuration for parallelism settings.

    Attributes:
        tensor_parallel_size: The number of tensor parallel units. Determines how
            the model's tensors are partitioned across multiple NPU PEs. Please note that a single
            RNGD device contains 8 NPU PEs. For example, if set to 8, it means the model uses
            8-way tensor parallelism in a single NPU device. If set to 32, it means the model uses
            32-way tensor parallelism across 4 NPU devices.
        pipeline_parallel_size: The number of pipeline parallel stages. Determines
            how the model's layers are partitioned across multiple NPU devices.
    """

    tensor_parallel_size: int = 8
    pipeline_parallel_size: int = 1
