"""Resolution helpers for artifact builder types."""

from dataclasses import dataclass
import logging
from pathlib import Path
from typing import List, Optional, Sequence, Union

from transformers.configuration_utils import PretrainedConfig

from ..device import NUM_PES_PER_NPU, get_device_mesh
from ..metadata import ModelMetadata, QuantizationConfig, load_hf_config
from ..metadata.config_types import AttentionBucket
from ..parallelize.mppp.config import Device
from .presets import filter_preset_by_max_model_len, find_preset
from .types.config import BucketConfig, ModelConfig, ParallelConfig
from .validator import validate_resolved_buckets

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ResolvedBuckets:
    """Fully resolved and validated bucket configuration.

    Use the :meth:`resolve` factory to create instances from raw
    :class:`BucketConfig` tuples.
    """

    prefill_buckets: Sequence[AttentionBucket] = ()
    decode_buckets: Sequence[AttentionBucket] = ()
    append_buckets: Sequence[AttentionBucket] = ()
    tokenwise_seq_lens: Sequence[int] = ()

    @staticmethod
    def resolve(
        model_metadata: ModelMetadata,
        bucket_config: BucketConfig,
        max_model_len: int,
    ) -> "ResolvedBuckets":
        """Resolve presets, validate, and convert to AttentionBuckets.

        Processing order:
        1. Partial config check — reject mixed empty/non-empty bucket fields.
        2. Preset resolution — if all bucket fields are empty, look up a preset.
           Raises if no matching preset is found.
        3. Conversion — convert raw tuples to :class:`AttentionBucket` objects.
        4. Validation — check all invariants on the resolved instance.
        """
        prefill_buckets = list(bucket_config.prefill_buckets)
        decode_buckets = list(bucket_config.decode_buckets)
        append_buckets = list(bucket_config.append_buckets)
        tokenwise_seq_lens = list(bucket_config.tokenwise_seq_lens)

        is_generative_model = model_metadata.is_generative_model

        # Non-generative models (embedding/reranker) only need prefill + tokenwise.
        if is_generative_model:
            bucket_fields = {
                "prefill_buckets": prefill_buckets,
                "decode_buckets": decode_buckets,
                "append_buckets": append_buckets,
                "tokenwise_seq_lens": tokenwise_seq_lens,
            }
        else:
            bucket_fields = {
                "prefill_buckets": prefill_buckets,
                "tokenwise_seq_lens": tokenwise_seq_lens,
            }
        populated = {k for k, v in bucket_fields.items() if v}
        all_empty = len(populated) == 0

        # --- Step 1: Partial config check ---
        if (
            not bucket_config.skip_validation
            and not all_empty
            and populated != set(bucket_fields.keys())
        ):
            missing = set(bucket_fields.keys()) - populated
            raise ValueError(
                f"Partial bucket configuration is not allowed. "
                f"The following fields are specified: {sorted(populated)}, "
                f"but these are missing: {sorted(missing)}. "
                f"Either provide all bucket fields or leave all empty to use a preset."
            )

        # --- Step 2: Preset resolution ---
        if all_empty:
            preset = _resolve_bucket_preset(model_metadata, max_model_len)
            if preset is None:
                raise ValueError(
                    "No bucket configuration provided and no matching bucket preset found "
                    f"for model_type={model_metadata.model_type}. "
                    "Please provide explicit bucket configuration."
                )
            prefill_buckets = list(preset.prefill_buckets)
            decode_buckets = list(preset.decode_buckets)
            append_buckets = list(preset.append_buckets)
            tokenwise_seq_lens = list(preset.tokenwise_seq_lens)

        # --- Step 3: Convert tuples to AttentionBucket objects ---
        resolved_prefill = [AttentionBucket.prefill(*bucket) for bucket in prefill_buckets]

        if is_generative_model:
            resolved_decode = [AttentionBucket.decode(*bucket) for bucket in decode_buckets]
        else:
            resolved_decode = []

        resolved_append = [AttentionBucket(b[0], b[1], b[1] - b[2]) for b in append_buckets]

        # --- Step 4: Validate resolved buckets ---
        resolved = ResolvedBuckets(
            prefill_buckets=resolved_prefill,
            decode_buckets=resolved_decode,
            append_buckets=resolved_append,
            tokenwise_seq_lens=tokenwise_seq_lens,
        )
        validate_resolved_buckets(
            resolved,
            is_generative_model=is_generative_model,
            max_model_len=max_model_len,
        )
        return resolved


def resolve_max_model_len(
    hf_config: PretrainedConfig,
    max_model_len: Optional[int],
) -> int:
    """Resolve the effective maximum model context length.

    The HuggingFace config must provide ``max_position_embeddings``.
    If ``max_model_len`` is given, it must not exceed ``max_position_embeddings``.

    Assumes :func:`validate_hf_config` has already been called.

    Args:
        hf_config: HuggingFace pretrained model config.
        max_model_len: User-provided override, or ``None`` to use
            ``max_position_embeddings``.

    Returns:
        The resolved maximum model length.

    Raises:
        ValueError: If ``max_model_len`` exceeds ``max_position_embeddings``.
    """
    max_position_embeddings: int = hf_config.max_position_embeddings

    if max_model_len is None:
        return max_position_embeddings

    if max_model_len > max_position_embeddings:
        raise ValueError(
            f"'max_model_len={max_model_len}' exceeds "
            f"'max_position_embeddings={max_position_embeddings}' "
            f"from the HuggingFace model config."
        )

    return max_model_len


def _get_tp_group_device(tp_size: int, start_idx: int) -> Device:
    if tp_size <= NUM_PES_PER_NPU:
        return Device(f"npu:{start_idx}:0-{tp_size-1}")
    else:
        assert tp_size % NUM_PES_PER_NPU == 0
        return Device(",".join([f"npu:{start_idx + i}" for i in range(tp_size // NUM_PES_PER_NPU)]))


def resolve_device_mesh(parallel_config: ParallelConfig) -> List[Device]:
    """Build a dummy device mesh for compilation.

    The real device configuration is provided by the user when loading
    artifacts via ``LLM.__init__()``.  This helper produces a
    single-data-parallel mesh suitable for the artifact build step.

    Returns:
        A flat list of :class:`Device` objects representing one
        data-parallel group.
    """
    data_parallel_size = 1
    num_chip_per_tp_group = (parallel_config.tensor_parallel_size - 1) // NUM_PES_PER_NPU + 1

    normalized_mesh = [
        [dev for tp_group in pp_tp_group for dev in tp_group]
        for pp_tp_group in get_device_mesh(
            [
                _get_tp_group_device(parallel_config.tensor_parallel_size, i)
                for i in range(
                    0,
                    data_parallel_size
                    * parallel_config.pipeline_parallel_size
                    * num_chip_per_tp_group,
                    num_chip_per_tp_group,
                )
            ],
            parallel_config.tensor_parallel_size,
            parallel_config.pipeline_parallel_size,
            data_parallel_size,
        )
    ]
    return normalized_mesh[0]


def _resolve_bucket_preset(
    model_metadata: ModelMetadata,
    max_model_len: int,
) -> Optional[BucketConfig]:
    """Look up a bucket preset from model metadata and filter by max_model_len.

    Returns ``None`` when no matching preset is found.
    """
    hf_configs = model_metadata.hf_configs
    hidden_size = hf_configs["hidden_size"]
    intermediate_size = hf_configs["intermediate_size"]

    preset = find_preset(
        model_type=model_metadata.model_type,
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
    )
    if preset is None:
        return None

    logger.info(
        "Found bucket preset for model_type=%s, hidden_size=%d, intermediate_size=%d",
        model_metadata.model_type,
        hidden_size,
        intermediate_size,
    )

    # Filter buckets that exceed the model's maximum context length.
    preset = filter_preset_by_max_model_len(preset, max_model_len)
    if not preset.prefill_buckets and not preset.decode_buckets:
        logger.warning(
            "All buckets in preset were filtered out by max_model_len=%d. "
            "Falling back to default single-bucket configuration.",
            max_model_len,
        )
        return None
    logger.info("Filtered bucket preset by max_model_len=%d", max_model_len)

    return preset


def resolve_model_metadata(
    model_id_or_path: Union[str, Path],
    model_config: ModelConfig,
    *,
    hf_config: Optional[PretrainedConfig] = None,
    quantization_config: Optional[QuantizationConfig] = None,
) -> ModelMetadata:
    """Resolve model metadata from a model identifier and configuration.

    Loads the HuggingFace config if not provided, resolves the task type,
    and builds a :class:`ModelMetadata` instance.

    Args:
        model_id_or_path: The HuggingFace model id or a local path.
        model_config: Configuration for model HuggingFace settings.
        hf_config: Pre-loaded HuggingFace config, or ``None`` to load.
        quantization_config: Explicit quantization config, or ``None``
            to resolve from the HuggingFace config.

    Returns:
        A fully resolved :class:`ModelMetadata`.

    Raises:
        ValueError: If the task cannot be resolved automatically.
    """
    from furiosa_llm.metadata import tasks
    from furiosa_llm.metadata.hf_utils import (
        resolve_quantization_config,
        resolve_task,
    )
    from furiosa_llm.optimum.types import LLMConfig

    # Resolve task from model path if not explicitly provided
    if model_config.task == "auto":
        resolved_task = resolve_task(
            str(model_id_or_path), model_config.trust_remote_code, model_config.revision
        )
        if resolved_task is None:
            raise ValueError(
                f"Unable to resolve task for model '{model_id_or_path}'. Please specify the `ModelConfig.task` explicitly."
            )
    else:
        resolved_task = model_config.task

    use_binary_seq_class = model_config.binary_classification_head and resolved_task == tasks.SCORE

    # Use pre-loaded config if available, otherwise load
    if hf_config is None:
        hf_config = load_hf_config(
            model_id_or_path,
            trust_remote_code=model_config.trust_remote_code,
            revision=model_config.revision,
            hf_overrides=model_config.hf_overrides or None,
        )

    # Resolve quantization_config from HF config if not explicitly provided
    if quantization_config is None:
        is_generative = resolved_task in tasks.GENERATION_TASKS
        quantization_config = resolve_quantization_config(
            hf_config, is_generative, model_config.hf_overrides
        )

    llm_config = LLMConfig(quantization_config=quantization_config)

    assert resolved_task is not None  # For type checker
    model_metadata = ModelMetadata(
        task=resolved_task,
        hf_configs=hf_config,
        model_id_or_path=model_id_or_path,
        trust_remote_code=model_config.trust_remote_code,
        revision=model_config.revision,
        use_binary_seq_class=use_binary_seq_class,
        llm_config=llm_config,
    )

    return model_metadata
