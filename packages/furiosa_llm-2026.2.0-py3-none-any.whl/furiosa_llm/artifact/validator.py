"""Validation utilities for artifact configurations."""

from __future__ import annotations

from collections import Counter
from itertools import chain
import logging
import os
from typing import TYPE_CHECKING, Dict

from transformers.configuration_utils import PretrainedConfig

from furiosa.native_llm_common import compute_limits

from ..device import NUM_PES_PER_NPU
from ..metadata.config_types import TokenwiseBucket
from .types.config import ArtifactConfig, BucketConfig, ParallelConfig

if TYPE_CHECKING:
    from .resolver import ResolvedBuckets

logger = logging.getLogger(__name__)


def validate_hf_config(hf_config: PretrainedConfig) -> None:
    """Validate that the HuggingFace config contains all required fields.

    This runs once during ``ArtifactBuilder.__init__`` right after
    :func:`load_hf_config`, so that downstream code can access config
    fields without per-access error handling.

    Required fields:
        - ``max_position_embeddings`` — used for max_model_len resolution and
          bucket validation.
        - ``num_hidden_layers`` (or ``num_layers`` / ``n_layer``) — used for
          pipeline parallelism and compiler configuration.
        - ``hidden_size`` — used for bucket preset resolution and compiler
          configuration.
        - ``intermediate_size`` — used for bucket preset resolution and
          compiler configuration.

    Raises:
        ValueError: If any required field is missing from the config.
    """
    config_dict: Dict[str, object] = hf_config.to_dict()
    missing = []

    if "max_position_embeddings" not in config_dict:
        missing.append("max_position_embeddings")

    has_num_layers = (
        "num_hidden_layers" in config_dict
        or "num_layers" in config_dict
        or "n_layer" in config_dict
    )
    if not has_num_layers:
        missing.append("num_hidden_layers (or num_layers / n_layer)")

    if "hidden_size" not in config_dict:
        missing.append("hidden_size")

    if "intermediate_size" not in config_dict:
        missing.append("intermediate_size")

    if missing:
        raise ValueError(
            f"The HuggingFace model config is missing required fields: {missing}. "
            f"Available fields: {sorted(config_dict.keys())}. "
            f"Please check the model config or set 'hf_overrides' in ModelConfig."
        )


def validate_bucket_config(bucket_config: BucketConfig) -> None:
    """Validate a bucket configuration's input integrity.

    Checks on raw :class:`BucketConfig` tuples before resolution.
    Called only when explicit bucket fields are populated
    (i.e. ``bucket_config.has_explicit_buckets()`` is ``True``).

    Rules:
        1. No duplicate bucket entries.
        2. Must have at least one prefill bucket.
        3. All bucket dimensions must be positive.
        4. Append bucket ``attention_size`` must exceed ``input_ids_size``.

    Raises:
        ValueError: If any validation rule is violated.
    """
    prefill = list(bucket_config.prefill_buckets)
    decode = list(bucket_config.decode_buckets)
    append = list(bucket_config.append_buckets)

    # Rule 1: No duplicate bucket entries.
    _validate_no_duplicates(prefill, "prefill")
    _validate_no_duplicates(decode, "decode")
    _validate_no_duplicates(append, "append")

    # Rule 2: Must have at least one prefill bucket.
    if not prefill:
        raise ValueError(
            "Bucket configuration must contain at least one prefill bucket. "
            "Provide prefill_buckets explicitly or ensure a matching bucket preset exists."
        )

    # Rule 3: All bucket dimensions must be positive.
    for i, pb in enumerate(prefill):
        if pb[0] <= 0 or pb[1] <= 0:
            raise ValueError(
                f"prefill_buckets[{i}] = {pb}: " "batch_size and context_length must be positive."
            )
    for i, db in enumerate(decode):
        if db[0] <= 0 or db[1] <= 0:
            raise ValueError(
                f"decode_buckets[{i}] = {db}: " "batch_size and context_length must be positive."
            )
    for i, ab in enumerate(append):
        if ab[0] <= 0 or ab[1] <= 0 or ab[2] <= 0:
            raise ValueError(f"append_buckets[{i}] = {ab}: " "all dimensions must be positive.")

    # Rule 4: Append bucket attention_size must exceed input_ids_size.
    for i, ab in enumerate(append):
        if ab[1] <= ab[2]:
            raise ValueError(
                f"append_buckets[{i}] = {ab}: "
                "attention_size must be greater than input_ids_size."
            )


def validate_resolved_buckets(
    buckets: ResolvedBuckets,
    *,
    is_generative_model: bool,
    max_model_len: int,
) -> None:
    """Validate resolved buckets against model constraints.

    Called after :meth:`ResolvedBuckets.resolve` to check rules that
    depend on resolved values (``is_generative_model``, ``max_model_len``).

    Rules:
        1. Generative models must have decode buckets.
        2. Non-generative models should not have decode buckets (warning).
        3. No individual bucket should exceed ``max_model_len``.
        4. Combined bucket limits must not exceed ``max_model_len``.

    Raises:
        ValueError: If any validation rule is violated.
    """
    prefill = list(buckets.prefill_buckets)
    decode = list(buckets.decode_buckets)
    append = list(buckets.append_buckets)

    # Rule 1: Generative models must have decode buckets.
    if is_generative_model and not decode:
        raise ValueError(
            "Generative models require at least one decode bucket. "
            "Provide decode_buckets explicitly or ensure a matching bucket preset exists."
        )

    # Rule 2: Non-generative models should not have decode buckets.
    if not is_generative_model and decode:
        logger.warning(
            "decode_buckets are provided but will be ignored "
            "because the model is not a generative model."
        )

    # Rule 3: No individual bucket should exceed max_model_len.
    for i, b in enumerate(prefill):
        if b.attention_size > max_model_len:
            raise ValueError(
                f"prefill_buckets[{i}] context_length={b.attention_size} exceeds "
                f"max_model_len={max_model_len}."
            )
    for i, b in enumerate(decode):
        if b.attention_size > max_model_len:
            raise ValueError(
                f"decode_buckets[{i}] context_length={b.attention_size} exceeds "
                f"max_model_len={max_model_len}."
            )
    for i, b in enumerate(append):
        if b.attention_size > max_model_len:
            raise ValueError(
                f"append_buckets[{i}] attention_size={b.attention_size} exceeds "
                f"max_model_len={max_model_len}."
            )

    # Rule 4: Combined bucket limits must not exceed max_model_len.
    bucket_limits = compute_limits(
        tokenwise_buckets=[TokenwiseBucket(x) for x in buckets.tokenwise_seq_lens],
        attention_buckets=list(chain(prefill, decode, append)),
    )
    logger.info(f"The computed bucket limits are {bucket_limits.max_executable_len}")

    if max_model_len < bucket_limits.max_executable_len:
        raise ValueError(
            f"The maximum executable length {bucket_limits.max_executable_len} derived from bucket configuration "
            f"exceeds the model's maximum position embeddings {max_model_len}. "
            f"Please reduce the bucket sizes or adjust tokenwise_seq_lens to fit within the model's limit."
        )


def validate_artifact_config(
    artifact_config: ArtifactConfig,
    *,
    model_id_or_path: str,
) -> None:
    """Validate artifact copy sources before building.

    Checks that local files exist and that model files are downloadable
    from the Hugging Face Hub.

    Raises:
        ValueError: If any file is missing or cannot be downloaded.
    """
    if artifact_config.copies_from_local is not None:
        for local_file in artifact_config.copies_from_local:
            if not os.path.exists(local_file):
                raise ValueError(
                    f"The file {local_file} of copies_from_local does not exist in the local directory."
                )

    if artifact_config.copies_from_model is not None:
        from huggingface_hub import hf_hub_download

        for model_file in artifact_config.copies_from_model:
            try:
                _ = hf_hub_download(model_id_or_path, model_file)
            except Exception as e:
                raise ValueError(
                    f"Fail to download {model_file} from Hugging Face Hub's repository {model_id_or_path}."
                ) from e


def validate_parallel_config(parallel_config: ParallelConfig) -> None:
    """Validate parallelism settings against hardware constraints.

    A single RNGD device contains 8 NPU PEs. Up to 8 RNGD devices can
    be installed in one machine.  The supported tensor_parallel_size
    values are {4, 8, 32}, and ``pipeline_parallel_size`` must be a
    positive integer.  The total number of devices required
    (``ceil(tp / 8) * pp``) must not exceed 8.

    Raises:
        ValueError: If any constraint is violated.
    """
    SUPPORTED_TP_SIZES = {4, 8, 32}
    MAX_DEVICES = 8

    tp = parallel_config.tensor_parallel_size
    pp = parallel_config.pipeline_parallel_size

    if tp not in SUPPORTED_TP_SIZES:
        raise ValueError(
            f"tensor_parallel_size={tp} is not supported. "
            f"Supported values are {sorted(SUPPORTED_TP_SIZES)}."
        )

    if pp < 1:
        raise ValueError(f"pipeline_parallel_size={pp} must be a positive integer.")

    num_devices = ((tp - 1) // NUM_PES_PER_NPU + 1) * pp
    if num_devices > MAX_DEVICES:
        raise ValueError(
            f"The parallel configuration requires {num_devices} RNGD device(s) "
            f"(tensor_parallel_size={tp}, pipeline_parallel_size={pp}), "
            f"but at most {MAX_DEVICES} devices are supported."
        )


def _validate_no_duplicates(buckets: list, bucket_type_name: str) -> None:
    """Raise an error if duplicate bucket entries are found."""
    duplicates = [b for b, cnt in Counter(buckets).items() if cnt > 1]
    if duplicates:
        raise ValueError(f"Duplicate {bucket_type_name} buckets found: {duplicates}")
