from dataclasses import field, fields
from enum import Enum
import json
import os
from typing import List, Literal, Optional, Sequence, Union

from pydantic import BaseModel, RootModel
from pydantic.dataclasses import dataclass


class SchedulingLoop(Enum):
    """The scheduling loop type used in the scheduler."""

    EAGER = "eager"
    STEP_BASED = "step_based"

    @classmethod
    def _missing_(cls, value):
        if isinstance(value, str):
            return cls[value.upper()]


class DataParallelRoutingPolicy(Enum):
    """The routing policy for data-parallel request distribution."""

    ROUND_ROBIN = "round_robin"
    PREFIX_AWARE = "prefix_aware"

    @classmethod
    def _missing_(cls, value):
        if isinstance(value, str):
            return cls[value.upper()]


@dataclass
class PrefixCacheConfig:
    """
    * enabled: If True, enable prefix caching (default: True). Prefix caching can improve performance by reusing prefix tokens in decoding.
    * lookahead_requests: The prefix cache will try to preserve enough spare blocks to accommodate this many unscheduled requests.
    """

    enabled: bool = field(default=True, metadata={"cli_alias": "enable_prefix_caching"})
    lookahead_requests: int = field(
        default=2, metadata={"cli_alias": "prefix_cache_lookahead_requests"}
    )

    @classmethod
    def load_from_args(cls, args) -> "PrefixCacheConfig":
        prefix_cache_config = PrefixCacheConfig()
        for prefix_cache_config_attr in fields(PrefixCacheConfig):
            if (
                v := getattr(
                    args,
                    prefix_cache_config_attr.metadata.get("cli_alias")
                    or prefix_cache_config_attr.name,
                    None,
                )
            ) is not None:
                setattr(prefix_cache_config, prefix_cache_config_attr.name, v)

        return prefix_cache_config


@dataclass
class SchedulerConfig:
    """
    * version: Version of the `SchedulerConfig`.
    * scheduler_kind: Select named scheduler implementation with specialized strategy when provided.
                      Use default scheduler when omitted, which handles generic cases well.
    * npu_queue_limit: Maximum number of tasks that can be queued in the hardware
    * max_processing_samples: Maximum number of samples that can be processed by the scheduler
    * spare_blocks_ratio: Ratio of spare blocks that are reserved by scheduler. Smaller value will force the scheduler to use dram aggressively
    * is_offline: If True, use strategies optimized for offline scenario
    * estimation_time_limit_ms: Amount of time scheduler will use to make scheduling decision.
    * prefix_cache_config: Configuration for prefix caching.
    * experimental_scheduling_loop_type: Type of scheduling loop to use. If 'eager', use eager scheduling loop. If 'step_based', use the experimental step-based scheduling loop. Use default eager scheduling loop when omitted.
    * max_concurrency: Maximum concurrent decode requests per iteration.
    * max_num_batched_tokens: Maximum number of batched tokens per iteration.
    * data_parallel_routing_policy: Routing policy for data-parallel request distribution.
                                    'round_robin' or 'prefix_aware'.
                                    Defaults to 'prefix_aware' when prefix caching is enabled, 'round_robin' otherwise.
    """

    scheduler_kind: Optional[str] = None
    npu_queue_limit: int = 1
    max_processing_samples: int = 65536
    spare_blocks_ratio: float = 0.0
    # TODO: migrate to `scheduler_kind='offline'`
    is_offline: bool = False
    estimation_time_limit_ms: Optional[int] = None
    prefix_cache_config: PrefixCacheConfig = field(default_factory=PrefixCacheConfig)
    experimental_scheduling_loop_type: SchedulingLoop = SchedulingLoop.EAGER
    experimental_aggressive_batching: bool = False
    max_concurrency: Optional[int] = None
    max_num_batched_tokens: Optional[int] = None
    data_parallel_routing_policy: DataParallelRoutingPolicy = DataParallelRoutingPolicy.ROUND_ROBIN

    def __post_init__(self):
        if self.is_offline:
            self.scheduler_kind = "offline"

    # custom comparator to handle float comparison
    def __eq__(self, other):
        return (
            self.scheduler_kind == other.scheduler_kind
            and self.npu_queue_limit == other.npu_queue_limit
            and self.max_processing_samples == other.max_processing_samples
            and abs(self.spare_blocks_ratio - other.spare_blocks_ratio) < 1e-6
        )

    def export(self, path: Union[str, os.PathLike]):
        with open(path, "w") as f:
            f.write(RootModel[SchedulerConfig](self).model_dump_json(indent=4))

    @classmethod
    def load_from_args(cls, args) -> "SchedulerConfig":
        scheduler_config = SchedulerConfig()
        for scheduler_config_attr in fields(SchedulerConfig):
            if (v := getattr(args, scheduler_config_attr.name, None)) is not None:
                setattr(scheduler_config, scheduler_config_attr.name, v)

        scheduler_config.prefix_cache_config = PrefixCacheConfig.load_from_args(args)

        # Unless specified by user, default to PREFIX_AWARE routing policy when prefix caching is enabled, as it can better utilize the prefix cache.
        if (
            scheduler_config.data_parallel_routing_policy == DataParallelRoutingPolicy.ROUND_ROBIN
            and getattr(args, "data_parallel_routing_policy", None) is None
            and scheduler_config.prefix_cache_config.enabled
        ):
            scheduler_config.data_parallel_routing_policy = DataParallelRoutingPolicy.PREFIX_AWARE

        return scheduler_config

    @classmethod
    def load(cls, path: Union[str, os.PathLike]) -> "SchedulerConfig":
        with open(path) as f:
            o = json.load(f)
            return SchedulerConfig(**o)


class AttentionBucket(BaseModel):
    batch_size: int  # batch size, batch size must be a multiple of 2 now.
    attention_size: int
    kv_cache_size: int

    @property
    def input_ids_size(self) -> int:
        return self.attention_size - self.kv_cache_size

    def __init__(self, batch_size: int, attention_size: int, kv_cache_size: int):
        super(AttentionBucket, self).__init__(
            batch_size=batch_size, attention_size=attention_size, kv_cache_size=kv_cache_size
        )

    @classmethod
    def prefill(cls, batch_size: int, attention_size: int) -> "AttentionBucket":
        return cls(batch_size, attention_size, 0)

    @classmethod
    def decode(cls, batch_size: int, attention_size: int) -> "AttentionBucket":
        return cls(batch_size, attention_size, attention_size - 1)

    @property
    def is_prefill(self) -> bool:
        return self.kv_cache_size == 0

    @property
    def is_decode(self) -> bool:
        return self.kv_cache_size > 0 and self.input_ids_size == 1

    @property
    def is_extend(self) -> bool:
        return self.kv_cache_size > 0 and self.input_ids_size > 1

    def __hash__(self) -> int:
        return hash((str(self.__class__), self.batch_size, self.attention_size))


class TokenwiseBucket(BaseModel):
    input_size: int

    def __init__(self, input_size: int):
        super(TokenwiseBucket, self).__init__(input_size=input_size)


class PagedAttentionConfig(BaseModel):
    """Paged attention configuration.

    Attributes:
        block_size (int): The maximum number of tokens that can be stored in a single paged attention block
        padding_block_idx (int|None): Padding block's index. This will be used for optimization.
    """

    block_size: int

    # Padding block's index. This will be used for optimization.
    padding_block_idx: Optional[int] = None

    def __init__(self, block_size: int, padding_block_idx: Optional[int] = None):
        assert block_size > 0
        super(PagedAttentionConfig, self).__init__(
            block_size=block_size, padding_block_idx=padding_block_idx
        )


@dataclass
class GeneratorConfig:
    buckets: List[AttentionBucket]
    model_qname: str  # qualified name of the model (module + class)
    paged_attention_config: Optional[PagedAttentionConfig]
    packing_type: Literal["IDENTITY"]
    num_speculative_tokens: Optional[int]
    unpadded_vocab_size: Optional[int]

    def export(self, path: Union[str, os.PathLike]):
        with open(path, "w") as f:
            f.write(RootModel[GeneratorConfig](self).model_dump_json(indent=4))

    @classmethod
    def load(cls, path: Union[str, os.PathLike]) -> "GeneratorConfig":
        with open(path) as f:
            o = json.load(f)
            return GeneratorConfig(**o)


class PipelineMetadata(BaseModel, frozen=True):
    output_logits_size: Optional[int]
    num_blocks_per_supertask: Union[int, List[int]] = 1


@dataclass(frozen=True)
class LLMPartitioningConfig:
    embedding_layer_as_single_building_block: bool = False
    num_building_blocks_per_partition: Union[int, Sequence[int]] = 1
    use_module_marker: bool = True
