from contextlib import ExitStack
import functools
import logging
import os
from pathlib import Path
import sys
from typing import Any, Dict, Final, Iterable, Optional, Tuple, Type, Union

from optimum.modeling_base import OptimizedModel
from pydantic import BaseModel, Field, PrivateAttr
import torch
import transformers
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel
from transformers.models.auto.configuration_auto import AutoConfig
from transformers.models.auto.modeling_auto import MODEL_FOR_CAUSAL_LM_MAPPING
from transformers.trainer_utils import set_seed

from furiosa.models.common.export.serve import CausalModelServer
from furiosa_llm.metadata.config_types import AttentionBucket
from furiosa_llm.metadata.tasks import (
    EMBED,
    GENERATION_TASKS,
    GenerationTask,
    PoolingTask,
    TaskType,
)
from furiosa_llm.optimum import (
    AttentionType,
    OptimizationConfig,
    QDtype,
    QuantizationConfig,
)
from furiosa_llm.optimum.modeling import (
    AutoModel,
    get_optimized_cls,
    is_model_path,
    set_default_torch_dtype,
)
from furiosa_llm.optimum.types import LLMConfig

from ..utils import calculate_dir_hashsum, download_model_and_get_hash, get_logger_with_tz
from .hf_utils import (
    TASK_TYPE_TO_AUTO_MODEL_CLASS,
    get_model_cls,
    validate_model_support,
)
from .utils import generate_input_sample

DEFAULT_SEED_VALUE: Final = 42

# The maximum number of `Model.pretrained_models` kept.
# A custom pytest hook is used to group parametrized tests to work around this limit.
# Note that this should be at least 2 because quantized models recursively load base models!
PRETRAINED_MODEL_CACHE_SIZE: Final = 2

logger = get_logger_with_tz(logging.getLogger(__name__))


class ModelMetadataBase(BaseModel):
    """Base metadata for a model, containing only serialized fields and runtime-safe methods.

    After deserialization from artifact.json, use this type.
    Build-phase-only methods (model loading, tracing, etc.) are in ModelMetadata.
    """

    # Note that changing the fields in this class is a breaking change because they are serialized
    # in artifact.json.
    #
    # You must also update furiosa-llm-common/src/artifact/types/commons.rs accordingly
    # if you change the fields in this class, because ModelMetadataBase
    # is serialized and deserialized in Rust part.

    model_type: str = Field(..., alias="model_type")
    task: GenerationTask | PoolingTask = Field(..., alias="task")
    llm_config: LLMConfig = Field(default_factory=LLMConfig)
    hf_configs: Dict[str, Any] = Field(default_factory=dict)
    # path to load pre-trained model weights (optional)
    model_weight_path: Optional[os.PathLike] = None
    trust_remote_code: Optional[bool] = None

    # If True, the model uses the binary sequence classification head for optimization
    use_binary_seq_class: bool = False

    @property
    def num_hidden_layers(self) -> int:
        return (
            self.hf_configs.get("num_hidden_layers")
            or self.hf_configs.get("num_layers")
            or self.hf_configs["n_layer"]
        )

    @property
    def attention_type(self) -> AttentionType:
        return self.llm_config.optimization_config.attention_type

    @property
    def optimize_options(self) -> OptimizationConfig:
        return self.llm_config.optimization_config

    @property
    def quantization_config(self) -> Optional[QuantizationConfig]:
        return self.llm_config.quantization_config

    @property
    def is_generative_model(self) -> bool:
        return self.task in GENERATION_TASKS

    @property
    def kv_cache_dtype(self) -> Optional[QDtype]:
        if not self.is_generative_model:
            return None
        if self.quantization_config:
            return self.quantization_config.kv_cache
        return QDtype.FP32

    @property
    def is_quantized(self) -> bool:
        return self.quantization_config is not None

    @property
    def config(self) -> PretrainedConfig:
        # Reconstruct config from hf_configs dict via setattr to avoid
        # constructor validation errors from inter-field inconsistencies.
        model_type = self.hf_configs["model_type"]
        config = AutoConfig.for_model(model_type)
        for key, value in self.hf_configs.items():
            if key not in ("model_type", "transformers_version"):
                setattr(config, key, value)
        return config

    def get_output_logits_size(self, bucket: AttentionBucket) -> Optional[int]:
        if not self.is_generative_model:
            return None
        return bucket.input_ids_size


@functools.total_ordering
class ModelMetadata(ModelMetadataBase):
    """Full model metadata with build-phase capabilities.

    Extends ModelMetadataBase with private attrs and methods that are only
    available during build phase (not after deserialization from artifact.json).
    """

    # Below fields are not serialized in artifact.json.
    # After deserialization, both Rust and Python sides shouldn't rely on these fields.
    _model_id_or_path: Optional[Union[str, Path]] = PrivateAttr(default=None)
    _revision: Optional[str] = PrivateAttr(default=None)
    # Hash sum via blake3 or huggingface git commit
    _weights_hash: Optional[str] = PrivateAttr(default=None)
    # Cached optimized model class resolved during construction
    _optimized_cls: Optional[Type[torch.nn.Module]] = PrivateAttr(default=None)

    def __init__(
        self,
        task: TaskType,
        hf_configs: Optional[Union[PretrainedConfig, Dict[str, Any]]] = None,
        llm_config: LLMConfig = LLMConfig(),
        model_weight_path: Optional[os.PathLike] = None,
        trust_remote_code: Optional[bool] = None,
        # model id or path for weights (used only during build, not after artifact loading)
        model_id_or_path: Optional[Union[str, Path]] = None,
        revision: Optional[str] = None,
        use_binary_seq_class: bool = False,
        # --- Parameters for Rust deserialization only ---
        # These are populated by Rust when loading artifacts and should not be
        # provided when creating ModelMetadata from Python code directly.
        model_type: Optional[str] = None,
    ):
        if isinstance(hf_configs, PretrainedConfig):
            hf_configs = hf_configs.to_dict()

        # model_type can be provided directly from Rust deserialization,
        # or extracted from hf_configs when created from Python
        if model_type is None:
            model_type = hf_configs.get("model_type") if hf_configs else None
        if model_type is None:
            raise ValueError("model_type must be present in hf_configs or provided as parameter")

        super(ModelMetadata, self).__init__(
            model_type=model_type,
            task=task,
            llm_config=llm_config,
            hf_configs=hf_configs or {},
            model_weight_path=model_weight_path,
            trust_remote_code=trust_remote_code,
        )
        self._model_id_or_path = model_id_or_path
        self._revision = revision
        self.use_binary_seq_class = use_binary_seq_class

        # Eagerly validate model support for fail-fast.
        # This is skipped when loading from artifacts (model_id_or_path is None).
        if model_id_or_path is not None:
            self._optimized_cls = validate_model_support(
                self.model_cls,
                self.model_type,
                self.task,
                self.hf_configs,
                self.use_binary_seq_class,
            )

    @property
    @functools.lru_cache
    def model_cls(self) -> Type[PreTrainedModel]:
        assert self._model_id_or_path is not None
        return get_model_cls(
            self._model_id_or_path, self.trust_remote_code, self._revision, self.task
        )

    def __str__(self):
        name = str(self._model_id_or_path).rsplit("/", maxsplit=1)[-1]

        return "{}_{}L{}{}".format(
            name,
            self.num_hidden_layers,
            f"_{self.get_optimized_cls().__module__}",
            f"_{self.quantization_config}" if self.is_quantized else "",
        )

    @property
    def name(self):
        return self.__str__()

    @property
    def __hash_key(self):
        """A hashable key to uniquely identify the model metadata."""
        return (
            self._model_id_or_path,
            self.task,
            self.num_hidden_layers,
            self.attention_type,
            self.optimize_options,
            self.quantization_config,
        )

    def __eq__(self, other):
        if not isinstance(other, ModelMetadata):
            return False
        return self.__hash_key == other.__hash_key

    def __lt__(self, other):
        if not isinstance(other, ModelMetadata):
            return NotImplemented
        return self.__hash_key < other.__hash_key

    def __hash__(self):
        return hash(self.__hash_key)

    def get_optimized_cls(self) -> Type[torch.nn.Module]:
        if self._optimized_cls is not None:
            return self._optimized_cls
        return get_optimized_cls(self.model_cls, self.task, self.use_binary_seq_class)

    def ensure_model_and_update_weight_hash(self):
        if is_model_path(self._model_id_or_path):
            if self._revision is not None:
                logging.warning("Ignoring Huggingface model revision because the model is local.")
            self._revision = None
            self._weights_hash = calculate_dir_hashsum(self._model_id_or_path)
        else:
            self._revision = download_model_and_get_hash(self._model_id_or_path, self._revision)
            self._weights_hash = self._revision

    @functools.lru_cache(maxsize=1)
    def _random_weight_model(
        self,
        seed: int,
        run_gc: bool,
    ) -> torch.nn.Module:
        # FIXME: This is a workaround to reduce memory usage
        self._pretrained_model.cache_clear()
        if run_gc:
            import gc

            gc.collect()
        set_seed(seed)
        print(f"\x1b[1;36m(Creating {self} with random weights)\x1b[0m", end="", file=sys.stderr)
        sys.stderr.flush()

        contexts = []
        if self.quantization_config and self.quantization_config.is_bf16:
            contexts.append(set_default_torch_dtype(torch.bfloat16))
        with ExitStack() as stack:
            for ctx in contexts:
                stack.enter_context(ctx)

            config = self.config
            optimized_cls = self.get_optimized_cls()
            if issubclass(optimized_cls, PreTrainedModel):
                model: torch.nn.Module = optimized_cls(config=config)
            elif issubclass(optimized_cls, CausalModelServer):

                def _qdtype_to_model_lang_dtype(qdtype: QDtype) -> str:
                    if qdtype is QDtype.FP32:
                        return "float32"
                    elif qdtype is QDtype.BF16:
                        return "bfloat16"
                    else:
                        raise ValueError(f"Unsupported qdtype: {qdtype}")

                if not self.quantization_config:
                    model_dtype = "float32"
                    kv_cache_dtype = model_dtype if self.is_generative_model else None
                else:
                    model_dtype = _qdtype_to_model_lang_dtype(self.quantization_config.weight)
                    kv_cache_dtype = (
                        _qdtype_to_model_lang_dtype(self.quantization_config.kv_cache)
                        if self.quantization_config.kv_cache
                        else None
                    )

                model = optimized_cls.create(
                    None,
                    config=config,
                    model_dtype=model_dtype,
                    kv_cache_dtype=kv_cache_dtype,
                )
            else:
                raise ValueError(
                    f"Unsupported model class: {optimized_cls.__module__}.{optimized_cls.__name__}"
                )

        model.eval()
        model.requires_grad_(False)

        return model

    # FIXME: This wraps internal function to properly cache the model(because of default args)
    def random_weight_model(
        self,
        seed: int = DEFAULT_SEED_VALUE,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        return self._random_weight_model(seed, run_gc)  # type: ignore[arg-type]

    @functools.lru_cache(maxsize=PRETRAINED_MODEL_CACHE_SIZE)
    def _pretrained_model(
        self,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        # FIXME: This is a workaround to reduce memory usage
        self._random_weight_model.cache_clear()
        if run_gc:
            import gc

            gc.collect()
        logger.info(f"\x1b[1;36m(Loading {self})\x1b[0m")

        auto_model_cls: Optional[Type[OptimizedModel]]
        if self.task is None:
            auto_model_cls = AutoModel
        else:
            auto_model_cls = TASK_TYPE_TO_AUTO_MODEL_CLASS.get(self.task)
            if auto_model_cls is None:
                raise ValueError(f"Unsupported task_type: {self.task}")

        if self.quantization_config:
            torch_dtype = self.quantization_config.activation.to_torch_dtype()
        else:
            torch_dtype = None

        return auto_model_cls.from_pretrained(
            model_id=self._model_id_or_path,
            config=self.config,
            optimization_config=self.optimize_options,
            trust_remote_code=self.trust_remote_code,
            revision=self._revision,
            _disable_implicit_typecast=True,
            torch_dtype=torch_dtype,
            task=self.task,
            use_binary_seq_class=self.use_binary_seq_class,
        )

    # FIXME: This wraps internal function to properly cache the model
    def pretrained_model(
        self,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        return self._pretrained_model(run_gc)  # type: ignore[arg-type]

    def uses_models(self) -> Iterable[str]:
        return [self.name]

    @property
    def seq_dim_in_logits(self) -> Optional[int]:
        """Returns which dimension is sequence dimension in output logits tensor."""
        # This function is used for prefill last block slicing.

        if (
            self.model_cls in MODEL_FOR_CAUSAL_LM_MAPPING.values()
            or self.model_cls is transformers.BertForQuestionAnswering
        ):
            return 1

        if self.task == EMBED:
            return None
        else:
            raise NotImplementedError(f"Sequence dimension in logits for model {self} is unknown")

    @property
    def batch_dim_in_mask(self) -> int:
        if self.task in GENERATION_TASKS:
            return 0
        else:
            raise ValueError(f"Batch dimension in mask for model {self} is unknown")

    def attn_dim_in_mask(self, phase: str) -> int:
        if issubclass(self.get_optimized_cls(), CausalModelServer):
            # expect 3d mask (batch_size, input_ids_size, attention_size)
            return 2
        else:
            raise ValueError(f"attention dimension in {phase} mask for model {self} is unknown")

    @functools.cached_property
    def prefill_mask_dim(self) -> int:
        if issubclass(self.get_optimized_cls(), CausalModelServer):
            # For models-lang models, the mask dimension is always 3.
            return 3
        elif self.model_cls is transformers.BertForQuestionAnswering:
            # For BERT models, the mask dimension is always 2.
            return 2
        else:
            raise ValueError(f"Prefill mask dimension for model {self} is unknown. ")

    @functools.cached_property
    def decode_mask_dim(self) -> Optional[int]:
        if not self.is_generative_model:
            return None
        elif issubclass(self.get_optimized_cls(), CausalModelServer):
            # For For models-lang models, the mask dimension is always 3.
            return 3
        else:
            raise ValueError(f"Decode mask dimension for model {self} is unknown. ")

    def get_example_input(
        self,
        bucket: AttentionBucket,
        paged_attention_num_blocks: Optional[int] = None,
        paged_attention_block_size: Optional[int] = None,
        collapse_batch_seq_dim: bool = False,
        random_value: bool = False,
        device: torch.device = torch.device("cpu"),
    ) -> Tuple[Tuple, Dict]:
        if self.is_generative_model and self.attention_type is AttentionType.PAGED_ATTENTION:
            if not paged_attention_num_blocks:
                raise ValueError(
                    "`paged_attention_num_blocks` should be given for paged attention models."
                )
            if not paged_attention_block_size:
                raise ValueError(
                    "`paged_attention_block_size` should be given for paged attention models."
                )
        elif self.is_generative_model:
            if paged_attention_num_blocks is not None:
                raise ValueError(
                    "`paged_attention_num_blocks` should be given if and only if the model is paged attention model."
                )
            if paged_attention_block_size is not None:
                raise ValueError(
                    "`paged_attention_block_size` should be given if and only if the model is paged attention model."
                )

        if not self.is_generative_model and not bucket.is_prefill:
            raise ValueError("only generative model supports non-prefill bucket")

        return (), generate_input_sample(
            self.get_optimized_cls(),
            self.config,
            bucket,
            self.task,
            self.kv_cache_dtype.to_torch_dtype() if self.kv_cache_dtype else None,
            paged_attention_num_blocks,
            paged_attention_block_size,
            collapse_batch_seq_dim=collapse_batch_seq_dim,
            device=device,
        )
