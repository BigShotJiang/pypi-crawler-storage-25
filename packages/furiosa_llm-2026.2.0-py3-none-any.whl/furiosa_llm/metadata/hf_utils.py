import copy
import functools
from pathlib import Path
from typing import Any, Dict, Final, Mapping, Optional, Sequence, Type, Union

from optimum.modeling_base import OptimizedModel
import torch
import transformers
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel
from transformers.models.auto.configuration_auto import AutoConfig
from transformers.models.auto.modeling_auto import (
    MODEL_FOR_CAUSAL_LM_MAPPING,
    MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING_NAMES,
    MODEL_FOR_TEXT_ENCODING_MAPPING_NAMES,
)
from transformers.quantizers.auto import AutoQuantizationConfig
from transformers.utils.quantization_config import (
    CompressedTensorsConfig,
    FineGrainedFP8Config,
    Mxfp4Config,
    QuantizationConfigMixin,
)

from furiosa_llm.metadata.tasks import EMBED, GENERATE, SCORE, GenerationTask, PoolingTask, TaskType
from furiosa_llm.optimum import QDtype, QuantizationConfig, modeling
from furiosa_llm.optimum.modeling import (
    AutoModel,
    AutoModelForCausalLM,
    _FuriosaBaseAutoModelClass,
    get_optimized_cls,
)


def convert_hf_quant_config(
    hf_quant_config: Union[Dict[str, Any], QuantizationConfigMixin],
) -> QuantizationConfig:
    """Convert an HF quantization config (Mxfp4Config, FineGrainedFP8Config, etc.)
    to the internal QuantizationConfig."""
    if isinstance(hf_quant_config, QuantizationConfigMixin):
        quant_config = hf_quant_config
    else:
        # Handle compressed-tensors directly to avoid importing the external
        # compressed_tensors package, which has no release compatible with
        # transformers>=5.0. AutoQuantizationConfig.from_dict() would trigger
        # transformers' CompressedTensorsConfig.__init__() that requires it.
        quant_method = hf_quant_config.get("quant_method", "")
        if quant_method in ("compressed-tensors", "compressed_tensors"):
            return QuantizationConfig(
                weight=QDtype.FP8,
                activation=QDtype.BF16,
                kv_cache=QDtype.BF16,
            )
        quant_config = AutoQuantizationConfig.from_dict(hf_quant_config)
    if isinstance(quant_config, Mxfp4Config):
        if quant_config.dequantize:
            weight_dtype = QDtype.BF16
        else:
            weight_dtype = QDtype.MXFP4
        return QuantizationConfig(
            weight=weight_dtype,
            activation=QDtype.BF16,
            kv_cache=QDtype.BF16,
        )
    elif isinstance(quant_config, FineGrainedFP8Config):
        return QuantizationConfig(
            weight=QDtype.FP8,
            activation=QDtype.BF16,
            kv_cache=QDtype.BF16,
        )
    elif isinstance(quant_config, CompressedTensorsConfig):
        return QuantizationConfig(
            weight=QDtype.FP8,
            activation=QDtype.BF16,
            kv_cache=QDtype.BF16,
        )
    else:
        raise NotImplementedError(f"Unsupported quantization config type: {type(quant_config)}")


def resolve_quantization_config(
    hf_config: PretrainedConfig,
    is_generative: bool,
    hf_overrides: Optional[Mapping[str, Any]] = None,
) -> Optional[QuantizationConfig]:
    """Resolve QuantizationConfig from an HF PretrainedConfig.

    Checks (in order):
    1. hf_overrides["quantization_config"] if present
    2. hf_config.quantization_config if present
    3. Auto BF16 cast if torch_dtype is bfloat16
    """
    # Check overrides first
    hf_quant_config = hf_overrides.get("quantization_config") if hf_overrides else None
    # Then check HF config
    if hf_quant_config is None:
        hf_quant_config = getattr(hf_config, "quantization_config", None)

    if hf_quant_config is not None:
        return convert_hf_quant_config(hf_quant_config)

    # Auto BF16 cast
    config_dict = hf_config.to_dict()
    torch_dtype = config_dict.get("torch_dtype") or config_dict.get("dtype")
    if torch_dtype == "bfloat16":
        if is_generative:
            return QuantizationConfig.w_16_a_16_kv_16()
        else:
            return QuantizationConfig.w_16_a_16()

    return None


@functools.lru_cache(maxsize=32)
def _load_base_config(
    model_id_or_path: str,
    trust_remote_code: Optional[bool] = None,
    revision: Optional[str] = None,
) -> PretrainedConfig:
    return AutoConfig.from_pretrained(
        model_id_or_path,
        trust_remote_code=trust_remote_code,
        revision=revision,
    )


def adjust_layer_types(layer_types: Sequence[Any], num_hidden_layers: int) -> list:
    if len(layer_types) == num_hidden_layers:
        return list(layer_types)
    return (list(layer_types) * ((num_hidden_layers // len(layer_types)) + 1))[:num_hidden_layers]


def load_hf_config(
    model_id_or_path: Union[str, Path],
    trust_remote_code: Optional[bool] = None,
    revision: Optional[str] = None,
    hf_overrides: Optional[Mapping[str, Any]] = None,
) -> PretrainedConfig:
    if not hf_overrides:
        return _load_base_config(str(model_id_or_path), trust_remote_code, revision)

    normalized = dict(hf_overrides)

    # Case 1: QuantizationConfigMixin → merge into on-disk dict
    qc = normalized.get("quantization_config")
    if isinstance(qc, QuantizationConfigMixin):
        base = _load_base_config(str(model_id_or_path), trust_remote_code, revision)
        base_qc = copy.deepcopy(base.to_dict().get("quantization_config", {}))
        for k, v in qc.__dict__.items():
            if not k.startswith("_") and v is not None:
                base_qc[k] = v
        normalized["quantization_config"] = base_qc

    # Case 2: num_hidden_layers → adjust layer_types
    num_layers = normalized.get("num_hidden_layers")
    if num_layers is not None and "layer_types" not in normalized:
        base = _load_base_config(str(model_id_or_path), trust_remote_code, revision)
        base_lt = getattr(base, "layer_types", None)
        if base_lt:
            normalized["layer_types"] = adjust_layer_types(base_lt, num_layers)

    return AutoConfig.from_pretrained(
        model_id_or_path,
        trust_remote_code=trust_remote_code,
        revision=revision,
        **normalized,
    )


def _estimate_per_layer_param_count_billions(hf_configs: Dict[str, Any]) -> float:
    """Estimate per-layer transformer parameter count in billions.

    Extracts ``hidden_size`` and ``intermediate_size`` from the HuggingFace
    config dict (with fallback keys ``n_embd`` / ``n_inner`` / ``4 * hidden_size``)
    and delegates the actual computation to the Rust implementation
    ``approx_per_layer_params_b()`` exposed via PyO3.

    See the Rust docstring in ``furiosa-compiler-python/src/compiler_config.rs``
    for details on the formula and its approximations.
    """
    from furiosa.native_common.compiler import approx_per_layer_params_b

    hidden_size: Optional[int] = hf_configs.get("hidden_size") or hf_configs.get("n_embd")
    if hidden_size is None:
        raise ValueError("hidden_size (or n_embd) must be present in hf_configs")
    intermediate_size: int = (
        hf_configs.get("intermediate_size") or hf_configs.get("n_inner") or (4 * hidden_size)
    )
    return approx_per_layer_params_b(hidden_size, intermediate_size)


def validate_model_support(
    model_cls: Type[PreTrainedModel],
    model_type: str,
    task: Union[GenerationTask, PoolingTask],
    hf_configs: Dict[str, Any],
    use_binary_seq_class: bool = False,
) -> Type[torch.nn.Module]:
    """Validate that the model is supported for compilation.

    Checks:
    1. An optimized model class exists (via get_optimized_cls)
    2. A compiler config exists for this (model_type, task) combination

    Returns the optimized model class on success.
    """
    optimized_cls = get_optimized_cls(model_cls, task, use_binary_seq_class)

    from furiosa.native_common.compiler import find_compiler_config

    approx_per_layer_params = _estimate_per_layer_param_count_billions(hf_configs)
    if find_compiler_config(model_type, task, approx_per_layer_params) is None:
        raise ValueError(
            f"No compiler configuration available for model_type='{model_type}', "
            f"task='{task}'. This model is not currently supported for compilation."
        )

    return optimized_cls


def resolve_task(
    model_id_or_path: Union[str, Path],
    trust_remote_code: Optional[bool],
    revision: Optional[str] = None,
) -> Optional[TaskType]:
    """Resolve the task type from the model class.

    Checks the model class against known HF auto-mapping dicts for generation, embedding, and sequence classification tasks.
    Returns the resolved task type as a string, or None if it cannot be resolved.
    """
    model_cls = get_model_cls(model_id_or_path, trust_remote_code, revision)
    if model_cls in MODEL_FOR_CAUSAL_LM_MAPPING.values():
        return GENERATE
    elif model_cls in MODEL_FOR_TEXT_ENCODING_MAPPING_NAMES.values():
        return EMBED
    elif model_cls in MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING_NAMES.values():
        return SCORE
    else:
        return None


TASK_TYPE_TO_AUTO_MODEL_CLASS: Final[Dict[str, Type[OptimizedModel]]] = {
    GENERATE: AutoModelForCausalLM,
    EMBED: AutoModel,
    SCORE: AutoModelForCausalLM,
}


def get_model_cls(
    model_id_or_path: Union[str, Path],
    trust_remote_code: Optional[bool],
    revision: Optional[str] = None,
    task_type: Optional[str] = None,
) -> Type[PreTrainedModel]:
    model_config = AutoConfig.from_pretrained(
        model_id_or_path, trust_remote_code=trust_remote_code, revision=revision
    )
    supported_architectures = getattr(model_config, "architectures", [])

    if task_type:
        if auto_model_cls := TASK_TYPE_TO_AUTO_MODEL_CLASS.get(task_type):
            return auto_model_cls.find_model_class(
                model_id_or_path,
                model_config,
                trust_remote_code=trust_remote_code,
            )
        else:
            raise NotImplementedError(f"Unsupported task_type: {task_type}")
    else:
        if len(supported_architectures) != 1:
            raise ValueError(
                f"Task type not given, but multiple architectures found: {supported_architectures}"
            )

        if model_cls := getattr(transformers, supported_architectures[0], None):
            return model_cls

        # Model should be loaded with remote code.
        if not hasattr(model_config, "auto_map"):
            raise ValueError(
                f"Model {model_id_or_path} is not a local model, but does not have an auto map in config."
            )
        auto_class_names = [
            auto_class_name
            for auto_class_name, class_ref in model_config.auto_map.items()
            if class_ref.rsplit('.', maxsplit=1)[-1] == supported_architectures[0]
        ]
        assert len(auto_class_names) == 1
        auto_class_name = auto_class_names[0]
        if not (module_finder := getattr(modeling, auto_class_name)):
            raise ValueError(f"Unsupported auto model class type: {auto_class_name}")
        assert issubclass(module_finder, _FuriosaBaseAutoModelClass)
        return module_finder.find_model_class(
            model_id_or_path,
            model_config,
            trust_remote_code=trust_remote_code,
        )
