from typing import Final, List, Literal, Union, get_args

# Reference : https://github.com/vllm-project/vllm/blob/v0.11.1/vllm/tasks.py

# Generation task constants
GENERATE: Final[Literal["generate"]] = "generate"

GenerationTask = Literal["generate"]

# Pooling task constants
EMBED: Final[Literal["embed"]] = "embed"
CLASSIFY: Final[Literal["classify"]] = "classify"
SCORE: Final[Literal["score"]] = "score"
TOKEN_EMBED: Final[Literal["token_embed"]] = "token_embed"
TOKEN_CLASSIFY: Final[Literal["token_classify"]] = "token_classify"
PLUGIN: Final[Literal["plugin"]] = "plugin"

PoolingTask = Literal[
    "embed",
    "classify",
    "score",
    "token_embed",
    "token_classify",
    "plugin",
]

# Composite type aliases for convenience
TaskType = Union[GenerationTask, PoolingTask]
UnresolvedTaskType = Union[Literal["auto"], TaskType]

GENERATION_TASKS: Final[List[str]] = list(get_args(GenerationTask))
POOLING_TASKS: Final[List[str]] = list(get_args(PoolingTask))

POOLING: Final[str] = "pooling"
