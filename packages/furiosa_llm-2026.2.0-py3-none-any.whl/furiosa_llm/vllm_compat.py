from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Tuple, Union, cast

from transformers import PreTrainedTokenizerBase
from transformers.tokenization_utils import PreTrainedTokenizer
from transformers.tokenization_utils_fast import PreTrainedTokenizerFast
from typing_extensions import NotRequired, TypeAlias, TypedDict, TypeVar

# TODO: Add MistralTokenizer
AnyTokenizer = Union[PreTrainedTokenizer, PreTrainedTokenizerFast]

# Type aliases for multimodal data (vLLM compatibility)
_T = TypeVar("_T")
ModalityData: TypeAlias = _T | list[_T | None] | None
MultiModalDataDict: TypeAlias = dict[str, ModalityData[Any]]
MultiModalUUIDDict: TypeAlias = dict[str, list[str | None] | str]


# adopted from https://github.com/vllm-project/vllm/blob/main/vllm/inputs/data.py
class TextPrompt(TypedDict):
    """Schema for a text prompt."""

    prompt: str
    """The input text to be tokenized before passing to the model."""

    multi_modal_data: NotRequired[MultiModalDataDict | None]
    """
    Optional multi-modal data to pass to the model,
    if the model supports it.
    """

    mm_processor_kwargs: NotRequired[dict[str, Any] | None]
    """
    Optional multi-modal processor kwargs to be forwarded to the
    multimodal input mapper & processor.
    Placeholder: not fully supported in furiosa-llm yet.
    """

    multi_modal_uuids: NotRequired[MultiModalUUIDDict]
    """
    Optional user-specified UUIDs for multimodal items, mapped by modality.
    Lists must match the number of items per modality and may contain `None`.
    For `None` entries, the hasher will compute IDs automatically; non-None
    entries override the default hashes for caching, and MUST be unique per
    multimodal item.
    """

    cache_salt: NotRequired[str]
    """
    Optional cache salt to be used for prefix caching.
    Placeholder: not fully supported in furiosa-llm yet.
    """


class TokensPrompt(TypedDict):
    """Schema for a tokenized prompt."""

    prompt_token_ids: list[int]
    """A list of token IDs to pass to the model."""

    prompt: NotRequired[str]
    """The prompt text corresponding to the token IDs, if available."""

    token_type_ids: NotRequired[list[int]]
    """
    A list of token type IDs to pass to the cross encoder model.
    Placeholder: not fully supported in furiosa-llm yet.
    """

    multi_modal_data: NotRequired[MultiModalDataDict | None]
    """
    Optional multi-modal data to pass to the model,
    if the model supports it.
    """

    mm_processor_kwargs: NotRequired[dict[str, Any] | None]
    """
    Optional multi-modal processor kwargs to be forwarded to the
    multimodal input mapper & processor.
    Placeholder: not fully supported in furiosa-llm yet.
    """

    multi_modal_uuids: NotRequired[MultiModalUUIDDict]
    """
    Optional user-specified UUIDs for multimodal items, mapped by modality.
    Lists must match the number of items per modality and may contain `None`.
    For `None` entries, the hasher will compute IDs automatically; non-None
    entries override the default hashes for caching.
    """

    cache_salt: NotRequired[str]
    """
    Optional cache salt to be used for prefix caching.
    Placeholder: not fully supported in furiosa-llm yet.
    """


SingletonPrompt = Union[str, TextPrompt, TokensPrompt]

# TODO: support ExplicitEncoderDecoderPrompt later
PromptType = Union[SingletonPrompt]


# A shallow version of transformers.tokenization_utils_base.BatchEncoding
@dataclass
class BatchEncoding:
    input_ids: list[int]
    attention_mask: list[int]
    token_type_ids: Optional[list[int]] = None

    def __len__(self) -> int:
        return len(self.input_ids)


@dataclass
class MultiModalConfig:
    """Configuration for multimodal input handling.

    This is a simplified version of vLLM's MultiModalConfig,
    providing compatibility for vLLM-derived serving code.

    Attributes:
        limit_per_prompt: Maximum number of items allowed per modality per prompt.
            e.g., {"image": 5, "video": 2, "audio": 1}
            A value of None means no limit for that modality.
        interleave_mm_strings: If True, multimodal placeholders are interleaved
            at their original positions. If False, they are prepended to the prompt.
        media_io_kwargs: Additional kwargs for media I/O operations.
    """

    limit_per_prompt: dict[str, int | None] = field(default_factory=dict)
    interleave_mm_strings: bool = False
    media_io_kwargs: dict[str, Any] = field(default_factory=dict)


def preprocess_prompt(
    prompt: PromptType,
    tokenizer: PreTrainedTokenizerBase,
    tokenization_kwargs: Optional[dict[str, Any]] = None,
) -> Tuple[BatchEncoding, Callable[[], str]]:
    """
    Returns a tuple of `(BatchEncoding, prompt string getter)`.

    The prompt is needed as a string for output handling (`RequestOutput`), not as input to the model.
    To minimize latency, it's recommended to call `prompt_getter` after invoking `self.native_engine.stream_generate`.
    """
    if tokenization_kwargs is None:
        tokenization_kwargs = {}
    if isinstance(prompt, str):
        prompt_str = prompt
        input_ids = tokenizer.encode(prompt_str, **tokenization_kwargs)
        return (
            BatchEncoding(input_ids=input_ids, attention_mask=[1] * len(input_ids)),
            lambda: prompt_str,
        )
    if isinstance(prompt, dict):
        if "prompt" in prompt:
            prompt_str = prompt["prompt"]  # type: ignore
            input_ids = tokenizer.encode(prompt_str, **tokenization_kwargs)
            return (
                BatchEncoding(input_ids=input_ids, attention_mask=[1] * len(input_ids)),
                lambda: prompt_str,
            )
        elif "prompt_token_ids" in prompt:
            input_ids = prompt["prompt_token_ids"]
            decode_res = tokenizer.decode(input_ids, skip_special_tokens=True)
            assert type(decode_res) is str
            return (
                BatchEncoding(input_ids=input_ids, attention_mask=[1] * len(input_ids)),
                lambda: decode_res,
            )

    raise ValueError(f"Unsupported prompt type: {type(prompt)}")


def prompt_to_str(prompt: PromptType, tokenizer: PreTrainedTokenizerBase) -> str:
    """
    Convert a PromptType to a string.

    Args:
        prompt: The prompt to convert (can be str, TextPrompt, or TokensPrompt).
        tokenizer: The tokenizer to use for decoding token IDs.

    Returns:
        The prompt as a string.

    Raises:
        ValueError: If the prompt type is not supported.
    """
    if isinstance(prompt, str):
        return prompt
    elif isinstance(prompt, dict):
        if "prompt" in prompt:
            return prompt["prompt"]  # type: ignore
        elif "prompt_token_ids" in prompt:
            return tokenizer.decode(
                prompt["prompt_token_ids"], skip_special_tokens=True  # type: ignore
            )
    raise ValueError(f"Unsupported prompt type: {type(prompt)}")


def get_score_prompt(
    tokenizer: AnyTokenizer,
    data_1: str,
    data_2: str,
    score_template: str | None = None,
    tokenization_kwargs: dict[str, Any] | None = None,
) -> tuple[str, TokensPrompt]:
    """Apply score template if model supports it."""
    if tokenization_kwargs is None:
        tokenization_kwargs = {}

    # XXX: Currently only Qwen reranker model is supported, so does this function.
    # We need to design a more general interface, e.g. implementing `get_score_template` method in Model class like vLLM does.
    # Also note that the number of suffix newline is really crucial for accuracy.
    if score_template is None:
        score_template = """<|im_start|>system
Judge whether the Document meets the requirements based on the Query and the Instruct provided. Note that the answer can only be "yes" or "no".<|im_end|>
<|im_start|>user
<Instruct>: {{ messages | selectattr("role", "eq", "system") | map(attribute="content") | first | default("Given a web search query, retrieve relevant passages that answer the query") }}
<Query>: {{ messages | selectattr("role", "eq", "query") | map(attribute="content") | first }}
<Document>: {{ messages | selectattr("role", "eq", "document") | map(attribute="content") | first }}<|im_end|>
<|im_start|>assistant
<think>

</think>

"""

    messages = [
        {
            "role": "system",
            "content": "Given a web search query, retrieve relevant passages that answer the query",
        },
        {
            "role": "query",
            "content": data_1,
        },
        {
            "role": "document",
            "content": data_2,
        },
    ]

    # Apply chat template
    rendered_prompt = cast(
        str,
        tokenizer.apply_chat_template(
            messages,
            chat_template=score_template,
            tokenize=False,
            add_generation_prompt=False,
            **tokenization_kwargs,
        ),
    )
    prompt_token_ids = tokenizer.encode(
        rendered_prompt, add_special_tokens=False, **tokenization_kwargs
    )
    return rendered_prompt, {"prompt_token_ids": prompt_token_ids}


def apply_prompt_truncation(
    encoded: Union[BatchEncoding, list[int]],
    truncate_prompt_tokens: Optional[int],
    prompt_max_seq_len: int,
) -> None:
    """
    Apply truncation to encoded based on truncate_prompt_tokens parameter.

    Args:
        encoded: The batch encoding or list of token IDs to truncate (modified in-place).
        truncate_prompt_tokens: Controls prompt truncation.
            Set to -1 to use the model's default truncation size.
            Set to k to keep only the last k tokens (left truncation).
            Set to None to disable truncation.
        prompt_max_seq_len: The model's default maximum prompt sequence length.
    """
    if truncate_prompt_tokens is None:
        return

    truncate_k = truncate_prompt_tokens
    if truncate_k == -1:
        # use model's default truncation size
        truncate_k = prompt_max_seq_len

    # token ids case
    if isinstance(encoded, list):
        if truncate_k > 0 and len(encoded) > truncate_k:
            # left truncation: keep only the last k tokens
            del encoded[:-truncate_k]
        return

    # batch encoding case
    if truncate_k > 0 and len(encoded.input_ids) > truncate_k:
        # left truncation: keep only the last k tokens
        encoded.input_ids = encoded.input_ids[-truncate_k:]
        encoded.attention_mask = encoded.attention_mask[-truncate_k:]
