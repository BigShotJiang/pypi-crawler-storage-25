from pathlib import Path

from packaging.version import Version


def add_version_args(parser):
    parser.add_argument(
        "--full",
        action="store_true",
        default=False,
        help="show full version information including native-llm and npu-ir",
    )
    parser.set_defaults(dispatch_function=show_version)


def _get_furiosa_llm_version():
    """Get furiosa-llm version without importing the heavy furiosa_llm package."""
    try:
        git_version_path = Path(__file__).resolve().parent.parent / "git_version.txt"
        version = Version(git_version_path.read_text().strip())
    except Exception:
        version = Version("0.0.1dev0+unknown")

    base_version = version.base_version
    if version.is_devrelease:
        stage = f"dev{version.dev}"
    elif version.is_prerelease and version.pre is not None:
        stage = f"{version.pre[0]}{version.pre[1]}"
    else:
        stage = "release"

    assert version.local is not None
    rev = version.local.split(".")[0][1:]
    return f"{base_version}-{stage} (rev: {rev[0:9]})"


def show_version(args):
    print(f"furiosa-llm v{_get_furiosa_llm_version()}")

    if args.full:
        try:
            import furiosa.native_runtime as rt

            print(
                f"native-llm v{rt.__version__}"
                f" (rev: {rt.__git_short_hash__},"
                f" built at {rt.__build_timestamp__})"
            )
            print(
                f"npu-ir v{rt.__ir_version__}"
                f" (rev: {rt.__ir_git_short_hash__},"
                f" built at {rt.__ir_build_timestamp__})"
            )
        except ImportError:
            print("native-llm: not available")
            print("npu-ir: not available")
