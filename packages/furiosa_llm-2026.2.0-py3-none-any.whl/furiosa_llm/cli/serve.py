import argparse
import json

from furiosa_llm.api import DEFAULT_JIT_MAX_WORKERS, DEFAULT_JIT_THRESHOLD, DEFAULT_JIT_UNIT_SIZE
from furiosa_llm.sampling_params import StructuredOutputsBackend
from furiosa_llm.server.app import run_server
from furiosa_llm.server.reasoning_parsers import ReasoningParserManager
from furiosa_llm.server.tool_parsers import ToolParserManager


def add_serve_args(serve_parser):
    serve_parser.add_argument(
        "model",
        type=str,
        help="The Hugging Face model id, or path to Furiosa model artifact. Currently only one model is supported per server.",
    )
    serve_parser.add_argument(
        "--revision",
        type=str,
        help="The specific model revision on Hugging Face Hub if the model is given as a Hugging Face model id. It can be a branch name, a tag name, or a commit id."
        " Its default value is main. However, if a given model belongs to the furiosa-ai organization, the model will use the release model tag by default.",
    )
    serve_parser.add_argument(
        "--served-model-name",
        type=str,
        default=None,
        help="The model name used in the API. If not specified, the model name "
        "will be the same as the model argument.",
    )
    serve_parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host to bind the server to (default: %(default)s)",
    )
    serve_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind the server to (default: %(default)s)",
    )
    serve_parser.add_argument(
        "--allowed-origins",
        type=json.loads,
        default=["*"],
        help='Allowed origins in json list (default: ["*"])',
    )
    serve_parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="API key to use for Bearer token authentication (default: None, i.e., authentication is disabled)",
    )
    serve_parser.add_argument(
        "--disable-log-stats", action="store_true", help="Disable logging statistics."
    )
    serve_parser.add_argument(
        "--enable-payload-logging",
        default=False,
        action="store_true",
        help="Enabling HTTP POST request payload logging. This logging can expose sensitive data,"
        " increasing the risk of data breaches and regulatory non-compliance (e.g., GDPR)."
        " It may also lead to excessive storage usage and potential security vulnerabilities if the logs are not properly protected."
        " If you do not fully understand the risks associated with this option, do not enable it.",
    )
    serve_parser.add_argument(
        "--chat-template",
        type=str,
        help="If given, the default chat template will be overridden with the given file. (Default: use chat template from tokenizer)",
    )
    serve_parser.add_argument(
        "--chat-template-content-format",
        type=str,
        choices=["auto", "string", "openai"],
        default="auto",
        help='The format to render message content within a chat template. '
        '"string" will render the content as a string (Example: `"Hello World"`). '
        '"openai" will render the content as a list of dictionaries, '
        'similar to OpenAI schema (Example: `[{"type": "text", "text": "Hello world!"}]`). '
        '(default: %(default)s)',
    )
    serve_parser.add_argument(
        "--enable-auto-tool-choice",
        action="store_true",
        default=False,
        help="Enable auto tool choice for supported models. Use --tool-call-parser to specify which parser to use",
    )
    valid_tool_parsers = ToolParserManager.tool_parsers.keys()
    serve_parser.add_argument(
        "--tool-call-parser",
        type=str,
        metavar="{" + ",".join(valid_tool_parsers) + "}",
        default=None,
        help="Select the tool call parser depending on the model that you're using."
        " This is used to parse the model-generated tool call into OpenAI API "
        "format. Required for --enable-auto-tool-choice.",
    )
    valid_reasoning_parsers = ReasoningParserManager.reasoning_parsers.keys()
    serve_parser.add_argument(
        "--reasoning-parser",
        type=str,
        metavar="{" + ",".join(valid_reasoning_parsers) + "}",
        default=None,
        help="Select the reasoning parser depending on the model that you're "
        "using. This is used to parse the reasoning content into OpenAI "
        "API format. Required for reasoning models.",
    )
    serve_parser.add_argument(
        "--enable-responses-api-store",
        action="store_true",
        default=False,
        help="Enable in-memory response store for the Responses API. "
        "When enabled, responses can be retrieved via GET /v1/responses/{id} "
        "and multi-turn conversations can use previous_response_id. (default: %(default)s)",
    )
    serve_parser.add_argument(
        "--responses-api-store-max-entries",
        type=int,
        default=10000,
        help="Maximum number of responses to keep in the store. "
        "Oldest entries are evicted when the limit is reached. (default: %(default)s)",
    )
    serve_parser.add_argument(
        "--responses-api-store-ttl",
        type=int,
        default=3600,
        help="Time-to-live for stored responses in seconds. (default: %(default)s)",
    )
    serve_parser.add_argument(
        "--structured-outputs-backend",
        type=str,
        metavar="{" + ",".join(StructuredOutputsBackend.__args__) + "}",
        default="auto",
        help="Which engine will be used for structured outputs (JSON schema / regex etc)",
    )
    serve_parser.add_argument(
        "--response-role",
        type=str,
        default="assistant",
        help="Response role for /v1/chat/completions API (default: %(default)s)",
    )
    serve_parser.add_argument(
        "-tp",
        "--tensor-parallel-size",
        type=int,
        help="Number of tensor parallel replicas. (default: 4)",
    )
    serve_parser.add_argument(
        "-pp",
        "--pipeline-parallel-size",
        type=int,
        help="Number of pipeline stages.",
    )
    serve_parser.add_argument(
        "-dp",
        "--data-parallel-size",
        type=int,
        help="Data parallelism size. If not given, it will be inferred from total available PEs and other parallelism degrees.",
    )
    serve_parser.add_argument(
        "-pb",
        "--prefill-buckets",
        type=str,
        nargs="+",
        help="List of prefill buckets to use. If not given, the prefill buckets specified in the artifact will be used by default.",
    )
    serve_parser.add_argument(
        "-db",
        "--decode-buckets",
        type=str,
        nargs="+",
        help="List of decode buckets to use. If not given, the decode buckets specified in the artifact will be used by default.",
    )
    serve_parser.add_argument(
        "--max-prompt-len",
        type=int,
        default=None,
        help="Maximum prompt length to capture for the model. If given, prefill buckets with longer attention size than this value will be ignored.",
    )
    serve_parser.add_argument(
        "--max-model-len",
        type=int,
        default=None,
        help="Maximum supported sequence length of the model. If given, decode buckets with longer attention size than this value will be ignored.",
    )
    serve_parser.add_argument(
        "--max-batch-size",
        type=int,
        default=None,
        help="Maximum batch size to process in a single npu request. If given, buckets with larger batch size than this value will be ignored.",
    )
    serve_parser.add_argument(
        "--min-batch-size",
        type=int,
        default=None,
        help="Minimum batch size to process in a single npu request. If given, buckets with smaller batch size than this value will be ignored.",
    )
    serve_parser.add_argument(
        "--devices",
        type=str,
        default=None,
        help="The devices to run the model. It can be a single device or a comma-separated list of devices. "
        'Each device can be either "npu:X" or "npu:X:Y", where X is a device index and Y is a NPU core range notation '
        '(e.g. "npu:0" for whole npu 0, "npu:0:0" for core 0 of NPU 0, and "npu:0:0-3" for fused core 0-3 of npu 0). '
        "If not given, all available unoccupied devices will be used.",
    )
    serve_parser.add_argument(
        "--scheduler-kind",
        type=str,
        default=None,
        help="Select named scheduler implementation with specialized strategy when provided. "
        "(default: use default scheduler which handles generic cases well)",
    )
    serve_parser.add_argument(
        "--npu-queue-limit",
        type=int,
        default=None,
        help="If given, override the NPU queue limit of the scheduler config. (default: use value from artifact)",
    )
    serve_parser.add_argument(
        "--max-processing-samples",
        type=int,
        default=None,
        help="If given, override the maximum processing samples of the scheduler config. (default: use value from artifact)",
    )
    serve_parser.add_argument(
        "--spare-blocks-ratio",
        type=float,
        default=0.0,  # LLM-924
        help="The spare blocks ratio of the scheduler config (default: 0.0)."
        " Increasing this value might improve the performance but might lead to OOM.",
    )
    serve_parser.add_argument(
        "--estimation-time-limit-ms",
        type=int,
        default=None,
        help="The estimation time limit in milliseconds of the scheduler config (default: None)."
        " Increasing this value will allow scheduler to calculate better batching strategy at the expense of given computation time",
    )
    serve_parser.add_argument(
        "--enable-prefix-caching",
        default=True,
        action=argparse.BooleanOptionalAction,
        help="Enable prefix caching.",
    )
    serve_parser.add_argument(
        "--experimental-scheduling-loop-type",
        type=str,
        choices=["eager", "step_based"],
        default="eager",
        help=argparse.SUPPRESS,  # TODO(jonggeon): add help message once this feature is stable
    )
    serve_parser.add_argument(
        "--experimental-aggressive-batching",
        default=False,
        action=argparse.BooleanOptionalAction,
        help=argparse.SUPPRESS,  # TODO(jonggeon): add help message once this feature is stable
    )
    serve_parser.add_argument(
        "--data-parallel-routing-policy",
        type=str,
        choices=["round_robin", "prefix_aware"],
        default=None,
        help="Routing policy for data-parallel request distribution. "
        "'round_robin' distributes requests evenly across data-parallel replicas. "
        "'prefix_aware' attempts to route requests towards replicas with higher prefix cache affinity. "
        "(default: 'prefix_aware' when prefix caching is enabled, 'round_robin' otherwise)",
    )
    serve_parser.add_argument(
        "--max-concurrency",
        type=int,
        default=None,
        help="Maximum concurrent decode requests per iteration (default: None). Higher values improve throughput but may increase time-to-first-token (TTFT)",
    )
    serve_parser.add_argument(
        "--max-num-batched-tokens",
        type=int,
        default=None,
        help="Maximum number of batched tokens per iteration (default: None). Higher values improve individual TPOT but may increase time-to-first-token (TTFT) and decrease overall throughput",
    )
    serve_parser.add_argument(
        "--prefix-cache-lookahead-requests",
        type=int,
        default=2,
        help="Number of lookahead requests for prefix caching. The prefix cache will actively try to preserve enough spare blocks to accommodate this many unscheduled requests at all times. (experimental feature)",
    )
    serve_parser.add_argument(
        "--use-mock-backend",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--max-io-memory-mb",
        type=int,
        default=None,
        help="Maximum NPU memory in MB for I/O tensors (range: 0-49152). "
        "If None, runtime will automatically estimate required memory size. "
        "Setting this value too small for the model may cause an OOM (Out of Memory) error at runtime.",
    )
    serve_parser.add_argument(
        "--uvicorn-log-level",
        type=str,
        choices=["debug", "info", "warning", "error", "critical", "trace"],
        default="info",
        help="Log level for uvicorn (default: info).",
    )
    serve_parser.add_argument(
        "--disable-uvicorn-access-log",
        default=False,
        action=argparse.BooleanOptionalAction,
        help="Disable uvicorn access log.",
    )
    serve_parser.add_argument(
        "--enable-jit-compilation",
        default=False,
        action=argparse.BooleanOptionalAction,
        help="[EXPERIMENTAL] Enable JIT compilation.",
    )
    serve_parser.add_argument(
        "--jit-threshold",
        type=int,
        default=DEFAULT_JIT_THRESHOLD,
        help="[EXPERIMENTAL] Number of requests before triggering JIT compilation (default: %(default)s).",
    )
    serve_parser.add_argument(
        "--jit-max-workers",
        type=int,
        default=DEFAULT_JIT_MAX_WORKERS,
        help="[EXPERIMENTAL] Maximum concurrent background JIT compilations (default: %(default)s).",
    )
    serve_parser.add_argument(
        "--jit-unit-size",
        type=int,
        default=DEFAULT_JIT_UNIT_SIZE,
        help="[EXPERIMENTAL] Number of stages to compile together (default: %(default)s).",
    )

    # Multimodal configuration arguments
    serve_parser.add_argument(
        "--allowed-local-media-path",
        type=str,
        default=None,
        help="Path under which local media files can be accessed (security). "
        "If not set, local file access is disabled for security reasons.",
    )
    serve_parser.add_argument(
        "--image-limit-per-prompt",
        type=int,
        default=None,
        help="Maximum number of images allowed per prompt. If not set, no limit is enforced.",
    )
    serve_parser.add_argument(
        "--video-limit-per-prompt",
        type=int,
        default=None,
        help="Maximum number of videos allowed per prompt. If not set, no limit is enforced.",
    )
    serve_parser.add_argument(
        "--allowed-media-domains",
        type=str,
        nargs="+",
        default=None,
        help="List of allowed domain names for remote media fetching (SSRF protection). "
        "If not set, all remote domains are allowed. "
        "Example: --allowed-media-domains example.com cdn.example.com",
    )
    serve_parser.add_argument(
        "--interleave-mm-strings",
        action="store_true",
        help="Interleave multimodal placeholders at original positions in the prompt. "
        "If not set, placeholders are prepended to the prompt.",
    )

    serve_parser.add_argument(
        "--fxb",
        type=str,
        default=None,
        help="Path to the FXB file or directory. When provided, the model argument is treated "
        "as a model hub repository id or directory and the v3 engine is used.",
    )

    serve_parser.set_defaults(dispatch_function=serve)


def serve(args):
    run_server(args)
