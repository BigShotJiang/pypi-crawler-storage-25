from __future__ import annotations

import html
import re
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any

import yaml
from mkdocs.exceptions import PluginError
from mkdocs.plugins import BasePlugin
from mkdocs.structure.files import File, Files


SHORTCODE_RE = re.compile(r'::process-timeline\{\s*file\s*=\s*"([^"]+)"\s*\}')
CSS_PATH = "assets/process-timeline.css"
JS_PATH = "assets/process-timeline.js"


@dataclass(frozen=True)
class Contact:
    name: str
    role: str | None
    email: str | None
    support: "SupportLink | None"


@dataclass(frozen=True)
class SupportLink:
    label: str
    url: str


@dataclass(frozen=True)
class Reference:
    label: str
    url: str


@dataclass(frozen=True)
class Task:
    title: str
    description: str
    url: str | None


@dataclass(frozen=True)
class Milestone:
    id: str
    title: str
    summary: str
    description: str
    duration_weeks: float
    contact: Contact
    references: list[Reference]
    tasks: list[Task]


@dataclass(frozen=True)
class ProcessTimeline:
    title: str
    description: str
    show_progress: bool
    milestones: list[Milestone]


class ProcessTimelinePlugin(BasePlugin):
    def on_config(self, config: dict[str, Any]) -> dict[str, Any]:
        extra_css = config.setdefault("extra_css", [])
        if CSS_PATH not in extra_css:
            extra_css.append(CSS_PATH)

        extra_javascript = config.setdefault("extra_javascript", [])
        if JS_PATH not in extra_javascript:
            extra_javascript.append(JS_PATH)
        return config

    def on_files(self, files: Files, config: dict[str, Any]) -> Files:
        if not any(file.src_uri == CSS_PATH for file in files):
            css_text = resources.files("mkdocs_process_timeline_plugin.assets").joinpath(
                "process-timeline.css"
            ).read_text(encoding="utf-8")
            files.append(File.generated(config, CSS_PATH, content=css_text))
        if not any(file.src_uri == JS_PATH for file in files):
            js_text = resources.files("mkdocs_process_timeline_plugin.assets").joinpath(
                "process-timeline.js"
            ).read_text(encoding="utf-8")
            files.append(File.generated(config, JS_PATH, content=js_text))
        return files

    def on_page_markdown(self, markdown: str, page: Any, config: dict[str, Any], files: Files) -> str:
        if not SHORTCODE_RE.search(markdown):
            return markdown

        def replace(match: re.Match[str]) -> str:
            relative_path = match.group(1)
            timeline = load_process_timeline(config["docs_dir"], relative_path)
            return render_process_timeline(timeline)

        return SHORTCODE_RE.sub(replace, markdown)


def load_process_timeline(docs_dir: str | Path, relative_path: str) -> ProcessTimeline:
    path = Path(docs_dir) / relative_path
    if not path.exists():
        raise PluginError(f"{relative_path}: YAML file does not exist")

    try:
        raw_data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise PluginError(f"{relative_path}: failed to parse YAML: {exc}") from exc

    return validate_process_timeline(raw_data, relative_path)


def validate_process_timeline(data: Any, filename: str) -> ProcessTimeline:
    if not isinstance(data, dict):
        raise PluginError(f"{filename}: YAML root must be a mapping")

    title = require_string(data, "title", filename)
    description = require_string(data, "description", filename)
    show_progress = optional_bool(data, "show_progress", filename, default=True)

    milestones_raw = data.get("milestones")
    if not isinstance(milestones_raw, list) or not milestones_raw:
        raise PluginError(f"{filename}: milestones must be a non-empty list")

    seen_ids: set[str] = set()
    milestones: list[Milestone] = []
    for index, milestone_raw in enumerate(milestones_raw, start=1):
        milestones.append(validate_milestone(milestone_raw, filename, index, seen_ids))

    return ProcessTimeline(
        title=title,
        description=description,
        show_progress=show_progress,
        milestones=milestones,
    )


def validate_milestone(
    data: Any, filename: str, index: int, seen_ids: set[str]
) -> Milestone:
    if not isinstance(data, dict):
        raise PluginError(f"{filename}: milestone #{index} must be a mapping")

    milestone_id = require_string(data, "id", filename, context=f"milestone #{index}")
    if milestone_id in seen_ids:
        raise PluginError(f"{filename}: duplicate milestone id '{milestone_id}'")
    seen_ids.add(milestone_id)

    context = f"milestone '{milestone_id}'"
    title = require_string(data, "title", filename, context=context)
    summary = require_string(data, "summary", filename, context=context)
    description = require_string(data, "description", filename, context=context)
    duration_weeks = require_positive_number(data, "duration_weeks", filename, context)
    contact = validate_contact(data.get("contact"), filename, milestone_id)
    references = validate_references(data.get("references"), filename, milestone_id)
    tasks = validate_tasks(data.get("tasks"), filename, milestone_id)

    return Milestone(
        id=milestone_id,
        title=title,
        summary=summary,
        description=description,
        duration_weeks=duration_weeks,
        contact=contact,
        references=references,
        tasks=tasks,
    )


def validate_contact(data: Any, filename: str, milestone_id: str) -> Contact:
    if not isinstance(data, dict):
        raise PluginError(f"{filename}: milestone '{milestone_id}': contact must be a mapping")
    name = require_string(data, "name", filename, context=f"milestone '{milestone_id}' contact")
    role = optional_string(data, "role", filename, context=f"milestone '{milestone_id}' contact")
    email_raw = data.get("email")
    if email_raw is not None and not isinstance(email_raw, str):
        raise PluginError(f"{filename}: milestone '{milestone_id}' contact: email must be a string")
    support = validate_support(data.get("support"), filename, milestone_id)
    return Contact(name=name, role=role, email=email_raw, support=support)


def validate_support(data: Any, filename: str, milestone_id: str) -> SupportLink | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise PluginError(f"{filename}: milestone '{milestone_id}' contact: support must be a mapping")
    label = require_string(data, "label", filename, context=f"milestone '{milestone_id}' support")
    url = require_string(data, "url", filename, context=f"milestone '{milestone_id}' support")
    return SupportLink(label=label, url=url)


def validate_references(data: Any, filename: str, milestone_id: str) -> list[Reference]:
    if data is None:
        return []
    if not isinstance(data, list):
        raise PluginError(f"{filename}: milestone '{milestone_id}': references must be a list")
    references: list[Reference] = []
    for item in data:
        if not isinstance(item, dict):
            raise PluginError(f"{filename}: milestone '{milestone_id}': each reference must be a mapping")
        label = require_string(item, "label", filename, context=f"milestone '{milestone_id}' reference")
        url = require_string(item, "url", filename, context=f"milestone '{milestone_id}' reference")
        references.append(Reference(label=label, url=url))
    return references


def validate_tasks(data: Any, filename: str, milestone_id: str) -> list[Task]:
    if not isinstance(data, list):
        raise PluginError(f"{filename}: milestone '{milestone_id}': tasks must be a list")

    tasks: list[Task] = []
    for item in data:
        if not isinstance(item, dict):
            raise PluginError(f"{filename}: milestone '{milestone_id}': each task must be a mapping")
        title = require_string(item, "title", filename, context=f"milestone '{milestone_id}' task")
        description = require_string(item, "description", filename, context=f"milestone '{milestone_id}' task")
        url = optional_string(item, "url", filename, context=f"milestone '{milestone_id}' task")
        tasks.append(Task(title=title, description=description, url=url))
    return tasks


def require_string(data: dict[str, Any], key: str, filename: str, context: str | None = None) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        prefix = f"{filename}: "
        if context:
            prefix += f"{context}: "
        raise PluginError(f"{prefix}{key} is required and must be a non-empty string")
    return value


def optional_string(data: dict[str, Any], key: str, filename: str, context: str | None = None) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        prefix = f"{filename}: "
        if context:
            prefix += f"{context}: "
        raise PluginError(f"{prefix}{key} must be a non-empty string when present")
    return value


def require_positive_number(data: dict[str, Any], key: str, filename: str, context: str) -> float:
    value = data.get(key)
    if not isinstance(value, (int, float)) or value <= 0:
        raise PluginError(f"{filename}: {context}: {key} must be a positive number")
    return float(value)


def optional_bool(data: dict[str, Any], key: str, filename: str, default: bool) -> bool:
    value = data.get(key, default)
    if not isinstance(value, bool):
        raise PluginError(f"{filename}: {key} must be a boolean when present")
    return value


def render_process_timeline(timeline: ProcessTimeline) -> str:
    total_duration = sum(item.duration_weeks for item in timeline.milestones)
    total_tasks = sum(len(item.tasks) for item in timeline.milestones)
    total_references = sum(len(item.references) for item in timeline.milestones)

    progress_nav = render_progress_nav(timeline.milestones) if timeline.show_progress else ""
    body_class = "ptl-body ptl-body--with-progress" if timeline.show_progress else "ptl-body"
    timeline_items = "\n".join(render_timeline_item(index, milestone) for index, milestone in enumerate(timeline.milestones))
    detail_sections = "\n".join(render_detail_section(milestone) for milestone in timeline.milestones)

    return f"""
<section class="ptl-root">
  <div class="ptl-summary">
    <h2 class="ptl-summary__title">{escape(timeline.title)}</h2>
    <p class="ptl-summary__description">{escape(timeline.description)}</p>
    <div class="ptl-summary__stats">
      {render_stat("Milestones", str(len(timeline.milestones)))}
      {render_stat("Estimated duration", format_duration(total_duration))}
      {render_stat("Required tasks", str(total_tasks))}
      {render_stat("References", str(total_references))}
    </div>
  </div>
  <div class="ptl-timeline">
    <div class="ptl-timeline__intro">
      <h3>Timeline journey</h3>
      <p>Select a milestone to jump to the detailed section below.</p>
    </div>
    <ol class="ptl-timeline__list">
      {timeline_items}
    </ol>
  </div>
  <div class="{body_class}">
    {progress_nav}
    <div class="ptl-details">
      {detail_sections}
    </div>
  </div>
</section>
""".strip()


def render_progress_nav(milestones: list[Milestone]) -> str:
    links = "\n".join(
        (
            f'<a class="ptl-progress__marker" href="#milestone-{escape(milestone.id)}" '
            f'data-ptl-progress-target="milestone-{escape(milestone.id)}">'
            f'<span class="ptl-progress__marker-dot" aria-hidden="true"></span>'
            f'<span class="ptl-progress__marker-label">{escape(milestone.title)}</span>'
            "</a>"
        )
        for milestone in milestones
    )
    return f"""
<nav class="ptl-progress" aria-label="Timeline progress">
  <div class="ptl-progress__track" aria-label="Timeline scroll progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" role="progressbar">
    <div class="ptl-progress__fill"></div>
  </div>
  <div class="ptl-progress__markers">
    {links}
  </div>
</nav>
""".strip()


def render_stat(label: str, value: str) -> str:
    return (
        '<div class="ptl-summary__stat">'
        f'<span class="ptl-summary__stat-label">{escape(label)}</span>'
        f'<span class="ptl-summary__stat-value">{escape(value)}</span>'
        "</div>"
    )


def render_timeline_item(index: int, milestone: Milestone) -> str:
    card = (
        f'<a class="ptl-timeline__card" href="#milestone-{escape(milestone.id)}">'
        f"<h3>{escape(milestone.title)}</h3>"
        f"<p>{escape(milestone.summary)}</p>"
        f'<span class="ptl-timeline__meta">Milestone {index + 1} • {escape(format_duration(milestone.duration_weeks))}</span>'
        "</a>"
    )

    if index % 2 == 0:
        return (
            '<li class="ptl-timeline__item">'
            f"{card}"
            '<div class="ptl-timeline__dot" aria-hidden="true"></div>'
            '<div class="ptl-timeline__spacer"></div>'
            "</li>"
        )

    return (
        '<li class="ptl-timeline__item">'
        '<div class="ptl-timeline__spacer"></div>'
        '<div class="ptl-timeline__dot" aria-hidden="true"></div>'
        f"{card}"
        "</li>"
    )


def render_detail_section(milestone: Milestone) -> str:
    email_html = ""
    if milestone.contact.email:
        email = escape(milestone.contact.email)
        email_html = f'<p><a href="mailto:{email}">{email}</a></p>'

    role_html = ""
    if milestone.contact.role:
        role_html = f'<p class="ptl-detail__contact-role">{escape(milestone.contact.role)}</p>'

    support_heading_html = ""
    support_html = ""
    if milestone.contact.support:
        support_heading_html = "<h4>Support</h4>"
        support_html = (
            f'<p class="ptl-detail__support"><a href="{escape(milestone.contact.support.url)}">'
            f'{escape(milestone.contact.support.label)}</a></p>'
        )

    references_panel_html = ""
    if milestone.references:
        references_html = "".join(
            f'<li><a href="{escape(ref.url)}">{escape(ref.label)}</a></li>' for ref in milestone.references
        )
        references_panel_html = f"""
    <div class="ptl-detail__panel ptl-detail__panel--references">
      <h4>References</h4>
      <ul>{references_html}</ul>
    </div>""".rstrip()
    tasks_html = "".join(render_task(task) for task in milestone.tasks)

    return f"""
<section class="ptl-detail" id="milestone-{escape(milestone.id)}">
  <div class="ptl-detail__header">
    <div class="ptl-detail__title-wrap">
      <h3>{escape(milestone.title)}</h3>
      <p class="ptl-detail__summary">{escape(milestone.summary)}</p>
    </div>
    <div class="ptl-detail__duration">{escape(format_duration(milestone.duration_weeks))}</div>
  </div>
  <p class="ptl-detail__description">{escape(milestone.description)}</p>
  <div class="ptl-detail__grid">
    <div class="ptl-detail__panel ptl-detail__panel--tasks">
      <h4>Tasks</h4>
      <ul>{tasks_html}</ul>
    </div>
    <div class="ptl-detail__panel ptl-detail__panel--contact">
      <h4>Contact</h4>
      <p><strong>{escape(milestone.contact.name)}</strong></p>
      {role_html}
      {email_html}
      {support_heading_html}
      {support_html}
    </div>
    {references_panel_html}
  </div>
</section>
""".strip()


def format_duration(value: float) -> str:
    if value.is_integer():
        return f"{int(value)} weeks"
    return f"{value:g} weeks"


def escape(value: str) -> str:
    return html.escape(value, quote=True)


def render_task(task: Task) -> str:
    title_html = escape(task.title)
    if task.url:
        title_html = f'<a href="{escape(task.url)}">{title_html}</a>'
    return f"<li>{title_html}<p>{escape(task.description)}</p></li>"
