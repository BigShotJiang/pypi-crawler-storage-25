(function () {
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function updateTimelineProgress(root) {
    var progress = root.querySelector(".ptl-progress");
    if (!progress) {
      return;
    }

    var track = progress.querySelector(".ptl-progress__track");
    var viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    var viewportPoint = viewportHeight * 0.45;
    var scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
    var scrollHeight = Math.max(
      document.documentElement.scrollHeight,
      document.body ? document.body.scrollHeight : 0
    );
    var maxScroll = Math.max(scrollHeight - viewportHeight, 1);
    var amount = clamp(scrollTop / maxScroll, 0, 1);
    progress.style.setProperty("--ptl-progress", amount.toFixed(4));
    if (track) {
      track.setAttribute("aria-valuenow", String(Math.round(amount * 100)));
    }

    updateActiveMarker(root, progress, viewportPoint);
  }

  function updateActiveMarker(root, progress, viewportPoint) {
    var details = Array.prototype.slice.call(root.querySelectorAll(".ptl-detail"));
    var markers = Array.prototype.slice.call(progress.querySelectorAll("[data-ptl-progress-target]"));
    var activeId = "";
    var activeDistance = Infinity;

    details.forEach(function (detail) {
      var rect = detail.getBoundingClientRect();
      var detailCenter = rect.top + rect.height / 2;
      var distance = Math.abs(detailCenter - viewportPoint);
      if (rect.bottom >= 0 && rect.top <= window.innerHeight && distance < activeDistance) {
        activeDistance = distance;
        activeId = detail.id;
      }
    });

    markers.forEach(function (marker) {
      var active = marker.getAttribute("data-ptl-progress-target") === activeId;
      marker.classList.toggle("ptl-progress__marker--active", active);
      if (active) {
        marker.setAttribute("aria-current", "step");
      } else {
        marker.removeAttribute("aria-current");
      }
    });
  }

  function updateAll() {
    Array.prototype.forEach.call(document.querySelectorAll(".ptl-root"), updateTimelineProgress);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", updateAll);
  } else {
    updateAll();
  }

  window.addEventListener("scroll", updateAll, { passive: true });
  window.addEventListener("resize", updateAll);
})();
