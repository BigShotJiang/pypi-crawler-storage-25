from __future__ import annotations

from pathlib import Path

import pytest
from mkdocs.exceptions import PluginError

from mkdocs_process_timeline_plugin.plugin import (
    ProcessTimelinePlugin,
    load_process_timeline,
    render_process_timeline,
    validate_process_timeline,
)


VALID_YAML = """
title: Delivery Process
description: Track the delivery lifecycle from intake to release.
milestones:
  - id: intake
    title: Intake
    summary: Capture the request.
    description: Gather the inputs needed to begin.
    duration_weeks: 1
    contact:
      name: Alex Doe
      role: Intake Lead
      email: alex@example.com
      support:
        label: Open support request
        url: https://example.com/support/intake
    references:
      - label: Intake guide
        url: https://example.com/intake
    tasks:
      - title: Capture request
        description: Log the request and attach the intake packet.
        url: https://example.com/docs/capture-request
      - title: Confirm scope
        description: Verify the request fits the delivery process.
        url: https://example.com/docs/confirm-scope
  - id: planning
    title: Planning
    summary: Shape the delivery plan.
    description: Define the timeline and owners.
    duration_weeks: 2.5
    contact:
      name: Blake Roe
    tasks:
      - title: Build plan
        description: Document owners, dates, and execution checkpoints.
"""


def test_valid_yaml_loads(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")

    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    assert timeline.title == "Delivery Process"
    assert timeline.show_progress is True
    assert len(timeline.milestones) == 2
    assert timeline.milestones[0].id == "intake"
    assert timeline.milestones[1].contact.support is None
    assert timeline.milestones[1].contact.role is None
    assert timeline.milestones[1].tasks[0].url is None
    assert timeline.milestones[1].references == []


def test_missing_file_fails(tmp_path: Path) -> None:
    with pytest.raises(PluginError, match="does not exist"):
        load_process_timeline(tmp_path, "processes/missing.yml")


def test_duplicate_ids_fail() -> None:
    data = {
        "title": "A",
        "description": "B",
        "milestones": [
            milestone_dict("dup"),
            milestone_dict("dup"),
        ],
    }

    with pytest.raises(PluginError, match="duplicate milestone id 'dup'"):
        validate_process_timeline(data, "processes/delivery.yml")


def test_missing_required_fields_fail() -> None:
    data = {
        "title": "A",
        "description": "B",
        "milestones": [
            {
                "id": "one",
                "summary": "Missing title",
                "description": "Desc",
                "duration_weeks": 1,
                "contact": {"name": "A", "role": "B", "support": {"label": "Support", "url": "https://example.com/support"}},
                "references": [],
                "tasks": [{"title": "Task", "description": "Desc", "url": "https://example.com/task"}],
            }
        ],
    }

    with pytest.raises(PluginError, match="milestone 'one': title is required"):
        validate_process_timeline(data, "processes/delivery.yml")


def test_show_progress_can_be_disabled() -> None:
    data = {
        "title": "A",
        "description": "B",
        "show_progress": False,
        "milestones": [milestone_dict("one")],
    }

    timeline = validate_process_timeline(data, "processes/delivery.yml")
    html = render_process_timeline(timeline)

    assert timeline.show_progress is False
    assert 'class="ptl-progress"' not in html
    assert 'class="ptl-body ptl-body--with-progress"' not in html


def test_show_progress_must_be_boolean_when_present() -> None:
    data = {
        "title": "A",
        "description": "B",
        "show_progress": "no",
        "milestones": [milestone_dict("one")],
    }

    with pytest.raises(PluginError, match="show_progress must be a boolean"):
        validate_process_timeline(data, "processes/delivery.yml")


def test_renderer_outputs_timeline_anchors_and_matching_detail_ids(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    assert 'href="#milestone-intake"' in html
    assert 'id="milestone-intake"' in html
    assert 'href="#milestone-planning"' in html
    assert 'id="milestone-planning"' in html


def test_renderer_outputs_progress_markers(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    assert 'class="ptl-progress"' in html
    assert 'role="progressbar"' in html
    assert 'data-ptl-progress-target="milestone-intake"' in html
    assert 'data-ptl-progress-target="milestone-planning"' in html


def test_renderer_outputs_summary_counts(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    assert "Milestones" in html
    assert ">2<" in html
    assert "Estimated duration" in html
    assert ">3.5 weeks<" in html
    assert "Required tasks" in html
    assert ">3<" in html
    assert "References" in html
    assert ">3<" in html
    assert "Open support request" in html
    assert "Capture request" in html
    assert "Log the request and attach the intake packet." in html


def test_renderer_omits_support_section_when_not_present(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    planning_section = html.split('id="milestone-planning"', 1)[1]
    assert "Planning support request" not in planning_section


def test_renderer_omits_role_when_not_present(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    planning_section = html.split('id="milestone-planning"', 1)[1]
    assert "Planner" not in planning_section


def test_renderer_omits_task_link_when_not_present(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    planning_section = html.split('id="milestone-planning"', 1)[1]
    assert "https://example.com/docs/build-plan" not in planning_section
    assert "Build plan" in planning_section


def test_renderer_omits_references_section_when_not_present(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")
    timeline = load_process_timeline(docs_dir, "processes/delivery.yml")

    html = render_process_timeline(timeline)

    planning_section = html.split('id="milestone-planning"', 1)[1]
    assert "Plan template" not in planning_section
    assert "<h4>References</h4>" not in planning_section


def test_plugin_replaces_shortcode(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")

    plugin = ProcessTimelinePlugin()
    config = {"docs_dir": str(docs_dir), "extra_css": []}
    markdown = '# Page\n\n::process-timeline{file="processes/delivery.yml"}\n'

    output = plugin.on_page_markdown(markdown, page=None, config=config, files=[])

    assert 'class="ptl-root"' in output
    assert "::process-timeline" not in output


def test_plugin_replaces_shortcode_with_whitespace_variants(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    file_path = docs_dir / "processes" / "delivery.yml"
    file_path.parent.mkdir()
    file_path.write_text(VALID_YAML, encoding="utf-8")

    plugin = ProcessTimelinePlugin()
    config = {"docs_dir": str(docs_dir), "extra_css": []}
    markdown = '# Page\n\n::process-timeline{ file = "processes/delivery.yml" }\n'

    output = plugin.on_page_markdown(markdown, page=None, config=config, files=[])

    assert 'class="ptl-root"' in output
    assert "::process-timeline" not in output


def test_plugin_leaves_markdown_unchanged_without_shortcode() -> None:
    plugin = ProcessTimelinePlugin()
    config = {"docs_dir": ".", "extra_css": []}
    markdown = "# Page\n\nNo shortcode here.\n"

    output = plugin.on_page_markdown(markdown, page=None, config=config, files=[])

    assert output == markdown


def test_plugin_registers_bundled_css_and_javascript() -> None:
    plugin = ProcessTimelinePlugin()
    config: dict[str, object] = {}

    updated_config = plugin.on_config(config)

    assert updated_config["extra_css"] == ["assets/process-timeline.css"]
    assert updated_config["extra_javascript"] == ["assets/process-timeline.js"]


def test_plugin_does_not_duplicate_registered_assets() -> None:
    plugin = ProcessTimelinePlugin()
    config = {
        "extra_css": ["assets/process-timeline.css"],
        "extra_javascript": ["assets/process-timeline.js"],
    }

    updated_config = plugin.on_config(config)

    assert updated_config["extra_css"] == ["assets/process-timeline.css"]
    assert updated_config["extra_javascript"] == ["assets/process-timeline.js"]


def milestone_dict(milestone_id: str) -> dict[str, object]:
    return {
        "id": milestone_id,
        "title": "Title",
        "summary": "Summary",
        "description": "Description",
        "duration_weeks": 1,
        "contact": {"name": "Name"},
        "tasks": [{"title": "Task", "description": "Description"}],
    }
