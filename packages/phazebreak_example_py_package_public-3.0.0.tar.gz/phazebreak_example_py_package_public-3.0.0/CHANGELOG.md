# 3.0.0 (2026-05-06)

This was a version bump only for example-py-package-public to align it with other projects, there were no code changes.