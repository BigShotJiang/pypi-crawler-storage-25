"""Sample Hello World application."""


def hello():
    """Return a friendly greeting."""
    return "Hello example-py-package-public"
