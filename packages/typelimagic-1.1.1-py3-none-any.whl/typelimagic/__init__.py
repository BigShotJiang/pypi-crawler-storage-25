"""
typelimagic - A sophisticated yet simple data validation library.

A Python package for declarative data validation with type hints support,
custom validators, and nested schema composition.
"""

__version__ = "1.1.1"
__author__ = "PyValidify Team"
__email__ = "contact@pyvalidify.io"
__license__ = "MIT"
__description__ = "A sophisticated yet simple data validation library for Python"
__url__ = "https://github.com/typelimagic/typelimagic"

from .schema import BaseModel, Schema, Field
from .validators import (
    validator,
    range_,
    length_,
    regex_,
    email,
    url,
    min_length,
    max_length,
    min_value,
    max_value,
    one_of,
    contains,
    custom,
)
from .errors import ValidationError, ValidationErrorDetail
from .types import Validator, ValidatorFunc

__all__ = [
    # Core
    "BaseModel",
    "Schema",
    "Field",
    # Decorators
    "validator",
    # Built-in validators
    "range_",
    "length_",
    "regex_",
    "email",
    "url",
    "min_length",
    "max_length",
    "min_value",
    "max_value",
    "one_of",
    "contains",
    "custom",
    # Errors
    "ValidationError",
    "ValidationErrorDetail",
    # Types
    "Validator",
    "ValidatorFunc",
]
