"""
Comprehensive test suite for pyvalidify.
"""

import pytest
from typelimagic import (
    BaseModel, Field, validator, ValidationError,
    range_, length_, regex_, email, url, min_length, max_length,
    min_value, max_value, one_of, contains, custom,
)
from typing import List, Optional, Dict, Any, Set, Tuple, Literal


class TestBasicValidation:
    """Test basic validation functionality."""

    def test_simple_required_field(self):
        class User(BaseModel):
            name: str
            age: int

        with pytest.raises(ValidationError) as exc:
            User()
        assert "name" in str(exc.value) or "required" in str(exc.value).lower()

    def test_field_with_default(self):
        class Config(BaseModel):
            debug: bool = False
            port: int = 8080

        c = Config()
        assert c.debug is False
        assert c.port == 8080

    def test_required_field_missing(self):
        class Item(BaseModel):
            id: int
            name: str

        with pytest.raises(ValidationError) as exc:
            Item()
        errors = exc.value.to_dict()
        assert 'id' in errors
        assert 'name' in errors

    def test_valid_data(self):
        class Person(BaseModel):
            name: str
            age: int

        p = Person(name="Alice", age=30)
        assert p.name == "Alice"
        assert p.age == 30

    def test_dict_method(self):
        class User(BaseModel):
            name: str
            age: int

        user = User(name="Bob", age=25)
        data = user.dict()
        assert data == {"name": "Bob", "age": 25}

    def test_json_serialization(self):
        class Settings(BaseModel):
            debug: bool
            timeout: int

        s = Settings(debug=True, timeout=30)
        json_str = s.json()
        assert '"debug": true' in json_str or '"debug":true' in json_str
        assert '"timeout": 30' in json_str or '"timeout":30' in json_str


class TestTypeValidation:
    """Test type validation and coercion."""

    def test_int_type(self):
        class Model(BaseModel):
            count: int

        m = Model(count=42)
        assert m.count == 42

    def test_float_type(self):
        class Model(BaseModel):
            ratio: float

        m = Model(ratio=3.14)
        assert m.ratio == 3.14

    def test_str_type(self):
        class Model(BaseModel):
            text: str

        m = Model(text="hello")
        assert m.text == "hello"

    def test_wrong_type(self):
        class Model(BaseModel):
            age: int

        with pytest.raises(ValidationError) as exc:
            Model(age="not an int")
        assert "type" in str(exc.value).lower()

    def test_optional_field(self):
        from typing import Optional

        class Model(BaseModel):
            optional_field: Optional[int] = None

        m1 = Model()
        assert m1.optional_field is None

        m2 = Model(optional_field=42)
        assert m2.optional_field == 42

        m3 = Model(optional_field=None)
        assert m3.optional_field is None


class TestListValidation:
    """Test list/tuple validation."""

    def test_list_of_ints(self):
        class Model(BaseModel):
            numbers: List[int]

        m = Model(numbers=[1, 2, 3])
        assert m.numbers == [1, 2, 3]

    def test_list_type_error(self):
        class Model(BaseModel):
            numbers: List[int]

        with pytest.raises(ValidationError):
            Model(numbers=[1, "two", 3])

    def test_empty_list(self):
        class Model(BaseModel):
            items: List[str]

        m = Model(items=[])
        assert m.items == []

    def test_nested_list(self):
        class Model(BaseModel):
            matrix: List[List[int]]

        m = Model(matrix=[[1, 2], [3, 4]])
        assert m.matrix == [[1, 2], [3, 4]]


class TestDictValidation:
    """Test dictionary validation."""

    def test_dict_with_string_values(self):
        class Model(BaseModel):
            mapping: Dict[str, int]

        m = Model(mapping={"a": 1, "b": 2})
        assert m.mapping == {"a": 1, "b": 2}

    def test_nested_dict(self):
        class Model(BaseModel):
            data: Dict[str, Dict[str, int]]

        m = Model(data={"outer": {"inner": 42}})
        assert m.data == {"outer": {"inner": 42}}


class TestCustomValidators:
    """Test custom validators."""

    def test_range_validator(self):
        class Model(BaseModel):
            age: int = Field(validators=[range_(min_value=0, max_value=150)])

        m = Model(age=25)
        assert m.age == 25

        with pytest.raises(ValidationError):
            Model(age=-5)

        with pytest.raises(ValidationError):
            Model(age=200)

    def test_length_validator(self):
        class Model(BaseModel):
            username: str = Field(validators=[length_(min_len=3, max_len=20)])

        m = Model(username="alice")
        assert m.username == "alice"

        with pytest.raises(ValidationError):
            Model(username="ab")

        with pytest.raises(ValidationError):
            Model(username="a" * 25)

    def test_regex_validator(self):
        class Model(BaseModel):
            code: str = Field(validators=[regex_(r'^[A-Z]{3}-\d{3}$')])

        m = Model(code="ABC-123")
        assert m.code == "ABC-123"

        with pytest.raises(ValidationError):
            Model(code="abc-123")

    def test_email_validator(self):
        class Model(BaseModel):
            email: str = Field(validators=[email])

        m = Model(email="user@example.com")
        assert m.email == "user@example.com"

        with pytest.raises(ValidationError):
            Model(email="not-an-email")

    def test_url_validator(self):
        class Model(BaseModel):
            site: str = Field(validators=[url])

        m = Model(site="https://example.com")
        assert m.site == "https://example.com"

        with pytest.raises(ValidationError):
            Model(site="not-a-url")

    def test_one_of_validator(self):
        class Model(BaseModel):
            status: str = Field(validators=[one_of("active", "inactive", "pending")])

        m = Model(status="active")
        assert m.status == "active"

        with pytest.raises(ValidationError):
            Model(status="invalid")

    def test_custom_validator(self):
        def is_even(value: int) -> bool:
            return value % 2 == 0

        class Model(BaseModel):
            number: int = Field(validators=[custom(is_even, "Must be even")])

        m = Model(number=4)
        assert m.number == 4

        with pytest.raises(ValidationError):
            Model(number=3)

    def test_contains_validator(self):
        class Model(BaseModel):
            description: str = Field(validators=[contains("python", "valid", case_sensitive=False)])

        m = Model(description="A Python validation library")
        assert m.description == "A Python validation library"

        with pytest.raises(ValidationError):
            Model(description="Something else")


class TestFieldDecorator:
    """Test field-level validator decorator."""

    def test_validator_decorator(self):
        class Model(BaseModel):
            name: str

            @validator("name")
            def validate_name(cls, value: str) -> str:
                if not value.isalpha():
                    raise ValidationError.with_detail("name", "format", "Name must contain only letters")
                return value.capitalize()

        m = Model(name="alice")
        assert m.name == "Alice"

        with pytest.raises(ValidationError):
            Model(name="alice123")

    def test_multiple_validators_on_same_field(self):
        class Model(BaseModel):
            username: str

            @validator("username")
            def min_length(cls, v: str) -> str:
                if len(v) < 3:
                    raise ValidationError.with_detail("username", "length", "Too short")
                return v

            @validator("username")
            def max_length(cls, v: str) -> str:
                if len(v) > 20:
                    raise ValidationError.with_detail("username", "length", "Too long")
                return v

        m = Model(username="alice")
        assert m.username == "alice"

        with pytest.raises(ValidationError):
            Model(username="ab")

        with pytest.raises(ValidationError):
            Model(username="a" * 25)


class TestNestedSchemas:
    """Test nested schema composition."""

    def test_nested_model(self):
        class Address(BaseModel):
            street: str
            city: str
            zip_code: str

        class Person(BaseModel):
            name: str
            age: int
            address: Address

        p = Person(
            name="Alice",
            age=30,
            address={"street": "123 Main St", "city": "Springfield", "zip_code": "12345"}
        )
        assert isinstance(p.address, Address)
        assert p.address.city == "Springfield"

    def test_list_of_models(self):
        class Item(BaseModel):
            id: int
            name: str

        class Container(BaseModel):
            items: List[Item]

        c = Container(items=[
            {"id": 1, "name": "A"},
            {"id": 2, "name": "B"}
        ])
        assert len(c.items) == 2
        assert c.items[0].name == "A"

    def test_dict_of_models(self):
        class User(BaseModel):
            name: str

        class Organization(BaseModel):
            users: Dict[str, User]

        o = Organization(users={
            "admin": {"name": "Alice"},
            "guest": {"name": "Bob"}
        })
        assert o.users["admin"].name == "Alice"


class TestErrorHandling:
    """Test error reporting and formatting."""

    def test_validation_error_structure(self):
        class Model(BaseModel):
            age: int = Field(validators=[range_(min_value=0)])

        with pytest.raises(ValidationError) as exc:
            Model(age=-5)

        err = exc.value
        assert "age" in err.errors
        assert err.errors["age"][0].code == "range"
        assert "less than minimum" in err.errors["age"][0].message

    def test_multiple_field_errors(self):
        class Model(BaseModel):
            a: int
            b: int

        with pytest.raises(ValidationError) as exc:
            Model(a="not int", b="also not int")

        err_dict = exc.value.to_dict()
        assert "a" in err_dict
        assert "b" in err_dict

    def test_error_to_dict(self):
        class Model(BaseModel):
            value: int = Field(validators=[min_value(0)])

        with pytest.raises(ValidationError) as exc:
            Model(value=-1)

        error_dict = exc.value.to_dict()
        assert "value" in error_dict
        assert "code" in error_dict["value"][0]
        assert "message" in error_dict["value"][0]

    def test_validation_with_multiple_errors(self):
        class Model(BaseModel):
            name: str = Field(validators=[min_length(3)])
            age: int = Field(validators=[min_value(0)])

        with pytest.raises(ValidationError) as exc:
            Model(name="ab", age=-1)

        err_dict = exc.value.to_dict()
        assert "name" in err_dict
        assert "age" in err_dict


class TestFieldWithDefaultFactory:
    """Test default factory functionality."""

    def test_default_factory_list(self):
        class Model(BaseModel):
            items: List[str] = Field(default_factory=list)

        m1 = Model()
        m2 = Model()
        m1.items.append("test")
        assert m1.items == ["test"]
        assert m2.items == []  # Separate instances

    def test_default_factory_dict(self):
        class Model(BaseModel):
            data: Dict[str, int] = Field(default_factory=dict)

        m = Model()
        assert m.data == {}


class TestComplexSchemas:
    """Test complex real-world-like schemas."""

    def test_user_schema(self):
        from typing import Optional

        class Address(BaseModel):
            street: str
            city: str
            country: str = "USA"

        class User(BaseModel):
            username: str = Field(validators=[min_length(3), max_length(20)])
            email: str = Field(validators=[email])
            age: int = Field(validators=[range_(0, 150)])
            address: Optional[Address] = None
            tags: List[str] = Field(default_factory=list)

        user = User(
            username="alice",
            email="alice@example.com",
            age=25,
            address={"street": "123 Main", "city": "NYC"}
        )
        assert user.username == "alice"
        assert user.address.city == "NYC"

    def test_api_response_schema(self):
        class Pagination(BaseModel):
            page: int
            per_page: int
            total: int

        class ApiResponse(BaseModel):
            success: bool
            data: List[Dict[str, Any]]
            pagination: Pagination

        response = ApiResponse(
            success=True,
            data=[{"id": 1, "name": "Item1"}],
            pagination={"page": 1, "per_page": 10, "total": 1}
        )
        assert response.success is True
        assert response.pagination.total == 1


class TestValidationMethods:
    """Test classmethod validation utilities."""

    def test_validate_dict(self):
        class Model(BaseModel):
            value: int = Field(validators=[min_value(0)])

        assert Model.validate_dict({"value": 5}) is True
        assert Model.validate_dict({"value": -1}) is False

    def test_validate_method(self):
        class Model(BaseModel):
            value: int = Field(validators=[min_value(0)])

        m = Model(value=5)
        assert m.validate() is True

        # Invalid value set manually
        m.value = -1
        assert m.validate() is False

    def test_revalidation(self):
        class Model(BaseModel):
            number: int = Field(validators=[min_value(0)])

        # Initially valid
        m = Model(number=5)

        # Manually set to invalid value and revalidate
        m.number = -5
        assert m.validate() is False


class TestEdgeCases:
    """Test edge cases and special scenarios."""

    def test_none_value_for_optional(self):
        from typing import Optional

        class Model(BaseModel):
            optional: Optional[int] = None

        m = Model(optional=None)
        assert m.optional is None

    def test_empty_string(self):
        class Model(BaseModel):
            text: str

        m = Model(text="")
        assert m.text == ""

    def test_zero_value(self):
        class Model(BaseModel):
            count: int = Field(validators=[min_value(0)])

        m = Model(count=0)
        assert m.count == 0

    def test_whitespace_string(self):
        class Model(BaseModel):
            text: str = Field(validators=[min_length(1)])

        m = Model(text="   ")
        assert m.text == "   "
