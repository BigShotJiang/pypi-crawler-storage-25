"""
Tests for advanced validator functionality.
"""

import pytest
from typelimagic import (
    BaseModel, Field, validator, ValidationError,
    range_, custom, min_length, max_length, min_value, max_value, regex_,
)
from typing import Optional, Any, Set, Union, Literal


class TestValidatorChaining:
    """Test multiple validators on a field."""

    def test_chained_validators(self):
        class Model(BaseModel):
            value: int = Field(validators=[
                min_value(0),
                max_value(100),
                custom(lambda x: x % 2 == 0, "Must be even")
            ])

        m = Model(value=50)
        assert m.value == 50

        # Odd number fails
        with pytest.raises(ValidationError):
            Model(value=51)

        # Too high fails
        with pytest.raises(ValidationError):
            Model(value=101)

    def test_string_validators_chain(self):
        class Model(BaseModel):
            code: str = Field(validators=[
                min_length(5),
                max_length(10),
                regex_(r'^[A-Z0-9]+$')
            ])

        m = Model(code="ABC123")
        assert m.code == "ABC123"


class TestModelLevelValidation:
    """Test model-level validators."""

    def test_model_validator_success(self):
        class Model(BaseModel):
            start: int
            end: int

            @validator("model")
            def check_range(self):
                if self.start >= self.end:
                    raise ValidationError.with_detail("", "range", "start must be less than end")

        m = Model(start=1, end=10)
        assert m.start == 1

    def test_model_validator_failure(self):
        class Model(BaseModel):
            start: int
            end: int

            @validator("model")
            def check_range(self):
                if self.start >= self.end:
                    raise ValidationError.with_detail("", "range", "start must be less than end")

        with pytest.raises(ValidationError):
            Model(start=10, end=1)

    def test_model_validator_access_to_all_fields(self):
        class Model(BaseModel):
            a: int
            b: int
            sum: int

            @validator("model")
            def compute_sum(self):
                self.sum = self.a + self.b

        m = Model(a=3, b=4)
        assert m.sum == 7

    def test_multiple_model_validators(self):
        class Model(BaseModel):
            x: int
            y: int

            @validator("model")
            def positive_x(self):
                if self.x <= 0:
                    raise ValidationError.with_detail("", "positive", "x must be positive")

            @validator("model")
            def positive_y(self):
                if self.y <= 0:
                    raise ValidationError.with_detail("", "positive", "y must be positive")

        m = Model(x=5, y=10)
        assert m.x == 5

        with pytest.raises(ValidationError) as exc:
            Model(x=-1, y=10)
        assert "x must be positive" in str(exc.value)


class TestInheritance:
    """Test schema inheritance."""

    def test_basic_inheritance(self):
        class Base(BaseModel):
            id: int
            created_at: str = ""

        class Extended(Base):
            name: str
            updated_at: str = ""

        e = Extended(id=1, name="test", created_at="2024-01-01", updated_at="2024-01-02")
        assert e.id == 1
        assert e.name == "test"

    def test_inherited_validators(self):
        class Base(BaseModel):
            value: int

            @validator("value")
            def positive(cls, v):
                if v <= 0:
                    raise ValidationError.with_detail("value", "positive", "Must be positive")
                return v

        class Extended(Base):
            name: str

        e = Extended(value=5, name="test")
        assert e.value == 5

        with pytest.raises(ValidationError):
            Extended(value=-1, name="test")

    def test_field_override_in_inheritance(self):
        class Base(BaseModel):
            value: int = 0

        class Extended(Base):
            value: int = 10  # Override default

        e = Extended()
        assert e.value == 10

    def test_multiple_inheritance(self):
        class Mixin1(BaseModel):
            field1: str

        class Mixin2(BaseModel):
            field2: int

        class Combined(Mixin1, Mixin2):
            field3: float

        c = Combined(field1="hello", field2=42, field3=3.14)
        assert c.field1 == "hello"
        assert c.field2 == 42
        assert c.field3 == 3.14


class TestOptionalAndUnionTypes:
    """Test Optional, Union, and complex type handling."""

    def test_optional_with_validation(self):
        class Model(BaseModel):
            optional_value: Optional[int] = Field(validators=[min_value(0)], default=None)

        m = Model(optional_value=None)
        assert m.optional_value is None

        m = Model(optional_value=5)
        assert m.optional_value == 5

        with pytest.raises(ValidationError):
            Model(optional_value=-1)

    def test_union_type(self):
        class Model(BaseModel):
            value: Union[int, str]

        m1 = Model(value=42)
        assert m1.value == 42

        m2 = Model(value="text")
        assert m2.value == "text"

    def test_union_validation(self):
        class Model(BaseModel):
            value: Union[int, str] = Field(validators=[custom(lambda x: len(str(x)) > 2, "Too short")])

        m = Model(value="abc")
        assert m.value == "abc"

        with pytest.raises(ValidationError):
            Model(value="ab")

    def test_literal_type(self):
        class Model(BaseModel):
            status: Literal["active", "inactive", "pending"]

        m = Model(status="active")
        assert m.status == "active"

        with pytest.raises(ValidationError):
            Model(status="invalid")

    def test_any_type(self):
        class Model(BaseModel):
            value: Any

        m = Model(value="string")
        assert m.value == "string"

        m = Model(value=123)
        assert m.value == 123

        m = Model(value={"key": "value"})
        assert m.value == {"key": "value"}


class TestSetValidation:
    """Test set validation."""

    def test_set_of_strings(self):
        class Model(BaseModel):
            tags: Set[str]

        m = Model(tags={"python", "validation", "library"})
        assert isinstance(m.tags, set)
        assert "python" in m.tags

    def test_set_type_error(self):
        class Model(BaseModel):
            tags: Set[str]

        with pytest.raises(ValidationError):
            Model(tags=["list", "not", "set"])


class TestTupleValidation:
    """Test tuple validation with fixed types per position."""

    def test_tuple_two_types(self):
        from typing import Tuple

        class Model(BaseModel):
            point: Tuple[int, int]

        m = Model(point=(3, 4))
        assert m.point == (3, 4)

    def test_tuple_multiple_types(self):
        from typing import Tuple

        class Model(BaseModel):
            data: Tuple[str, int, bool]

        m = Model(data=("hello", 42, True))
        assert m.data == ("hello", 42, True)

    def test_tuple_type_mismatch(self):
        from typing import Tuple

        class Model(BaseModel):
            data: Tuple[str, int]

        with pytest.raises(ValidationError):
            Model(data=("hello", "not an int"))

    def test_tuple_wrong_length(self):
        from typing import Tuple

        class Model(BaseModel):
            data: Tuple[int, int, int]

        with pytest.raises(ValidationError):
            Model(data=(1, 2))  # Too short


class TestReprAndStr:
    """Test string representations."""

    def test_repr(self):
        class Model(BaseModel):
            name: str
            age: int

        m = Model(name="Bob", age=25)
        repr_str = repr(m)
        assert "Model" in repr_str
        assert "name='Bob'" in repr_str
        assert "age=25" in repr_str

    def test_json(self):
        import json

        class Model(BaseModel):
            value: int
            name: str

        m = Model(value=42, name="test")
        data = json.loads(m.json())
        assert data == {"value": 42, "name": "test"}

    def test_json_indent(self):
        class Model(BaseModel):
            value: int

        m = Model(value=42)
        json_str = m.json(indent=2)
        assert "\n" in json_str


class TestFieldAlias:
    """Test field aliasing."""

    def test_field_alias(self):
        class Model(BaseModel):
            internal_name: str = Field(alias="externalName")

        m = Model(externalName="test")
        assert m.internal_name == "test"
        d = m.dict()
        assert d == {"externalName": "test"}

    def test_multiple_aliases(self):
        class Model(BaseModel):
            firstName: str = Field(alias="first_name")
            lastName: str = Field(alias="last_name")

        m = Model(first_name="John", last_name="Doe")
        assert m.firstName == "John"
        assert m.lastName == "Doe"


class TestModelReuse:
    """Test reusing models and validate_dict method."""

    def test_validate_dict_multiple_times(self):
        class Model(BaseModel):
            value: int = Field(validators=[min_value(0)])

        # Valid
        assert Model.validate_dict({"value": 5}) is True

        # Invalid
        assert Model.validate_dict({"value": -1}) is False

        # Valid again
        assert Model.validate_dict({"value": 10}) is True
