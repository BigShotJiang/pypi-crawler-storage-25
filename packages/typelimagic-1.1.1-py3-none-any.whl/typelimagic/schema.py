"""
Schema definition and model base classes.
"""

from typing import (
    Any, Callable, Dict, List, Optional, Set, Type, Union, get_origin, get_args
)
import re

from .errors import ValidationError, ValidationErrorDetail
from .types import Validator, ValidatorFunc

# Sentinel for missing default
_UNSET = object()


class Field:
    """Field definition with metadata and validators."""
    def __init__(
        self,
        name: Optional[str] = None,
        type_: Optional[Type] = None,
        default: Any = _UNSET,
        default_factory: Optional[Callable[[], Any]] = None,
        validators: Optional[List[Validator]] = None,
        description: str = "",
        alias: Optional[str] = None,
    ):
        self.name = name
        self.type_ = type_
        self._default = default
        self.default_factory = default_factory
        self.validators = validators or []
        self.description = description
        self.alias = alias
        # Required if neither default nor default_factory provided
        self.required = (default is _UNSET and default_factory is None)

    def has_default(self) -> bool:
        return self._default is not _UNSET or self.default_factory is not None

    def get_default(self) -> Any:
        if self._default is not _UNSET:
            return self._default
        if self.default_factory is not None:
            return self.default_factory()
        raise RuntimeError("Field has no default")


def validator(field_name: str, func: Optional[ValidatorFunc] = None):
    """Decorator to add a validator for a specific field."""
    def decorator(f: ValidatorFunc) -> ValidatorFunc:
        f._validator_field = field_name
        f._is_validator = True
        return f

    if func is None:
        return decorator
    return decorator(func)


class SchemaMeta(type):
    """Metaclass for BaseModel to collect fields and validators."""

    def __new__(mcs, name, bases, namespace):
        cls = super().__new__(mcs, name, bases, dict(namespace))

        fields_: Dict[str, Field] = {}
        validators_: Dict[str, List[Callable]] = {}

        # Inherit from bases
        for base in bases:
            if hasattr(base, '_fields'):
                fields_.update(base._fields.copy())
            if hasattr(base, '_validators'):
                validators_.update(base._validators.copy())

        # Process annotations
        annotations = namespace.get('__annotations__', {})
        for attr_name, attr_type in annotations.items():
            if attr_name.startswith('_'):
                continue

            raw_value = namespace.get(attr_name, _UNSET)

            if isinstance(raw_value, Field):
                field_obj = raw_value
                field_obj.name = attr_name
                field_obj.type_ = attr_type
                # Re-evaluate required based on field's own defaults
                if field_obj.has_default():
                    field_obj.required = False
                else:
                    field_obj.required = True
            else:
                if raw_value is _UNSET:
                    field_obj = Field(name=attr_name, type_=attr_type)
                else:
                    field_obj = Field(name=attr_name, type_=attr_type, default=raw_value)

            fields_[attr_name] = field_obj

        # Collect validator methods (from @validator decorator)
        for attr_name, attr_value in namespace.items():
            if callable(attr_value) and hasattr(attr_value, '_validator_field'):
                v_field = getattr(attr_value, '_validator_field')
                if v_field:
                    validators_.setdefault(v_field, []).append(attr_name)

        cls._fields = fields_
        cls._validators = validators_
        return cls


class BaseModel(metaclass=SchemaMeta):
    """Base class for all validation schemas."""

    _fields: Dict[str, Field]
    _validators: Dict[str, List[Callable]]

    def __init__(self, **data: Any):
        self._initial_data = data.copy()
        self._errors: Dict[str, List[ValidationErrorDetail]] = {}
        validated_data: Dict[str, Any] = {}
        missing_fields: List[str] = []

        # First pass: validate fields that are provided or have defaults
        for field_name, field_def in self._fields.items():
            # Get raw value (check field name and alias)
            if field_name in data:
                raw_value = data[field_name]
            elif field_def.alias and field_def.alias in data:
                raw_value = data[field_def.alias]
            else:
                if field_def.has_default():
                    raw_value = field_def.get_default()
                else:
                    missing_fields.append(field_name)
                    continue

            try:
                validated = self._validate_field(field_def, raw_value)
                validated_data[field_name] = validated
                # Set attribute now so model validators can access it
                setattr(self, field_name, validated)
            except ValidationError as e:
                self._errors[field_name] = e.details

        # If any field errors, raise early
        if self._errors:
            raise ValidationError(self._errors)

        # Run model-level validators (may set additional attributes)
        self._run_model_validators(validated_data)

        # After model validators, check missing fields
        for field_name in missing_fields:
            if hasattr(self, field_name):
                validated_data[field_name] = getattr(self, field_name)
            else:
                self._add_error(field_name, "required", "Field is required")

        # If any errors now, raise
        if self._errors:
            raise ValidationError(self._errors)

        # Ensure all fields are set as attributes (including those from missing now added)
        for field_name in self._fields:
            if field_name not in validated_data:
                # This could happen if a model validator set attribute but we didn't add to validated_data yet? We added above.
                # But just in case, fetch from attribute
                validated_data[field_name] = getattr(self, field_name, None)
            setattr(self, field_name, validated_data[field_name])

        # Run model-level validators
        self._run_model_validators(validated_data)

        # After model validators, check missing fields (may have been set by validators)
        for field_name in missing_fields:
            if hasattr(self, field_name):
                # Attribute was set by model validator; include it
                validated_data[field_name] = getattr(self, field_name)
            else:
                self._add_error(field_name, "required", "Field is required")

        # If any errors now, raise
        if self._errors:
            raise ValidationError(self._errors)

        # Set attributes for all fields
        for field_name in self._fields:
            setattr(self, field_name, validated_data[field_name])

    def _validate_field(self, field_def: Field, value: Any) -> Any:
        """Validate a single field."""
        current = value

        # Type validation
        if field_def.type_ is not Any:
            current = self._validate_type(field_def.type_, current, field_def.name)

        # If value is None and field is not required (i.e., optional), skip validators
        if current is None and not field_def.required:
            return None

        # Field-defined validators
        for v in field_def.validators:
            current = self._run_validator(v, current, field_def.name)

        # Method validators from @validator decorator
        if field_def.name in self._validators:
            for method_name in self._validators[field_def.name]:
                method = getattr(self, method_name)
                current = self._run_validator(method, current, field_def.name)

        return current

    def _run_validator(self, v: ValidatorFunc, value: Any, field_name: str) -> Any:
        try:
            return v(value)
        except ValidationError:
            raise
        except Exception as e:
            raise ValidationError.with_detail(field_name, "validator_error", str(e), {"value": value})

    def _validate_type(self, expected: Type, value: Any, field_name: str) -> Any:
        """Validate and coerce value to expected type."""
        # Handle Any
        if expected is Any:
            return value

        origin = get_origin(expected)
        args = get_args(expected)

        # Optional[T]
        if origin is Union and type(None) in args:
            if value is None:
                return None
            non_none = next(a for a in args if a is not type(None))
            return self._validate_type(non_none, value, field_name)

        # BaseModel subclass
        if isinstance(expected, type) and issubclass(expected, BaseModel):
            if isinstance(value, expected):
                return value
            if isinstance(value, dict):
                return expected(**value)
            raise ValidationError.with_detail(field_name, "type", f"Expected {expected.__name__}, got {type(value).__name__}")

        # List
        if origin is list:
            if not isinstance(value, (list, tuple)):
                raise ValidationError.with_detail(field_name, "type", f"Expected list, got {type(value).__name__}")
            item_type = args[0] if args else Any
            return [self._validate_type(item_type, v, f"{field_name}[{i}]") for i, v in enumerate(value)]

        # Dict
        if origin is dict:
            if not isinstance(value, dict):
                raise ValidationError.with_detail(field_name, "type", f"Expected dict, got {type(value).__name__}")
            kt = args[0] if args else Any
            vt = args[1] if len(args) > 1 else Any
            return {
                self._validate_type(kt, k, f"{field_name}.key"): self._validate_type(vt, v, f"{field_name}.{k}")
                for k, v in value.items()
            }

        # Set
        if origin is set:
            if not isinstance(value, set):
                raise ValidationError.with_detail(field_name, "type", f"Expected set, got {type(value).__name__}")
            it = args[0] if args else Any
            return {self._validate_type(it, v, field_name) for v in value}

        # Tuple
        if origin is tuple:
            if not isinstance(value, (list, tuple)):
                raise ValidationError.with_detail(field_name, "type", f"Expected tuple, got {type(value).__name__}")
            if len(args) != len(value):
                raise ValidationError.with_detail(field_name, "type", f"Expected tuple of length {len(args)}, got {len(value)}")
            return tuple(self._validate_type(t, v, f"{field_name}[{i}]") for i, (t, v) in enumerate(zip(args, value)))

        # Literal
        if hasattr(origin, '__name__') and origin.__name__ == 'Literal':
            if value not in args:
                raise ValidationError.with_detail(field_name, "literal", f"Value must be one of {args}")
            return value

        # Basic type
        if not isinstance(value, expected):
            raise ValidationError.with_detail(field_name, "type", f"Type error: expected {expected.__name__}, got {type(value).__name__}")

        return value

    def _run_model_validators(self, data):
        """Run all model-level validators (field_name == 'model')."""
        for method_name in self._validators.get('model', []):
            method = getattr(self, method_name)
            try:
                method()
            except ValidationError:
                raise
            except Exception as e:
                raise ValidationError.with_detail("model", "validator_error", str(e))

    def _add_error(self, field: str, code: str, message: str, context: Optional[Dict] = None):
        if field not in self._errors:
            self._errors[field] = []
        self._errors[field].append(ValidationErrorDetail(field=field, code=code, message=message, context=context or {}))

    def dict(self) -> Dict[str, Any]:
        result = {}
        for field_name, field_def in self._fields.items():
            val = getattr(self, field_name, None)
            key = field_def.alias if field_def.alias else field_name
            result[key] = val
        return result

    def json(self, **kwargs) -> str:
        import json
        return json.dumps(self.dict(), **kwargs)

    def validate(self) -> bool:
        try:
            type(self)(**self.dict())
            return True
        except ValidationError:
            return False

    @classmethod
    def validate_dict(cls, data: Dict[str, Any]) -> bool:
        try:
            cls(**data)
            return True
        except ValidationError:
            return False

    def __repr__(self) -> str:
        fields_str = ", ".join(f"{k}={v!r}" for k, v in self.dict().items())
        return f"{self.__class__.__name__}({fields_str})"


# Backwards compatibility
Schema = BaseModel
