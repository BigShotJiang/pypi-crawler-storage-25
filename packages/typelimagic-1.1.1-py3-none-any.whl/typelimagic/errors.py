"""
Custom exception classes and error detail structures.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ValidationErrorDetail:
    """Detailed information about a single validation error."""
    field: str
    code: str
    message: str
    context: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.field:
            return f"{self.field}: {self.message}"
        return self.message

    def to_dict(self) -> Dict[str, Any]:
        """Convert error detail to dictionary."""
        return {
            "field": self.field,
            "code": self.code,
            "message": self.message,
            "context": self.context,
        }


class ValidationError(ValueError):
    """Raised when data fails validation."""

    def __init__(
        self,
        errors: Optional[Dict[str, List[ValidationErrorDetail]]] = None,
        message: str = "Validation failed"
    ):
        self.errors = errors or {}
        self.message = message
        self.details: List[ValidationErrorDetail] = []

        # Flatten errors if dict provided
        if isinstance(errors, dict):
            for field_errors in errors.values():
                self.details.extend(field_errors)
        elif isinstance(errors, list):
            self.details = errors

        # Build error message
        error_messages = [str(detail) for detail in self.details]
        full_message = f"{message}: {'; '.join(error_messages)}" if error_messages else message
        super().__init__(full_message)

    @classmethod
    def with_detail(
        cls,
        field: str,
        code: str,
        message: str,
        context: Optional[Dict[str, Any]] = None
    ) -> "ValidationError":
        """Create a ValidationError with a single detail."""
        detail = ValidationErrorDetail(
            field=field,
            code=code,
            message=message,
            context=context or {}
        )
        return cls(errors={field: [detail]})

    def to_dict(self) -> Dict[str, Any]:
        """Convert validation error to dictionary."""
        result = {}
        for field, details in self.errors.items():
            result[field] = [d.to_dict() for d in details]
        return result

    def __str__(self) -> str:
        if self.details:
            return "; ".join(str(d) for d in self.details)
        return self.message


__all__ = ["ValidationError", "ValidationErrorDetail"]
