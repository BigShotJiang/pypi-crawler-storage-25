"""
Type definitions and type aliases.
"""

from typing import Any, Callable, Union, List

# Type for a single validation function
ValidatorFunc = Callable[[Any], Any]

# Type for a list of validators (can be single or multiple)
Validator = Union[ValidatorFunc, List[ValidatorFunc]]

# Callable that receives model and raises ValidationError
ModelValidator = Callable[["BaseModel"], None]

__all__ = ["Validator", "ValidatorFunc", "ModelValidator"]
