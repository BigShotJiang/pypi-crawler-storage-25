"""
Built-in validators and validator utilities.
"""

from typing import Any, Callable, Optional, Pattern, Union
import re
from .errors import ValidationError
from .types import Validator, ValidatorFunc


def validator(field_name: str, func: Optional[ValidatorFunc] = None):
    """Decorator to add a validator for a specific field."""
    def decorator(f: ValidatorFunc) -> ValidatorFunc:
        f._validator_field = field_name
        f._is_validator = True
        return f

    if func is None:
        return decorator
    return decorator(func)


def range_(
    min_value: Optional[Union[int, float]] = None,
    max_value: Optional[Union[int, float]] = None,
    min_inclusive: bool = True,
    max_inclusive: bool = True,
) -> Validator:
    """Validator for numeric ranges."""
    def validate(value: Union[int, float]) -> Union[int, float]:
        if min_value is not None:
            if min_inclusive:
                if value < min_value:
                    raise ValidationError.with_detail(
                        "", "range", f"Value {value} is less than minimum {min_value}",
                        {"min": min_value, "max": max_value, "min_inclusive": min_inclusive, "max_inclusive": max_inclusive}
                    )
            else:
                if value <= min_value:
                    raise ValidationError.with_detail(
                        "", "range", f"Value {value} is not greater than {min_value}",
                        {"min": min_value}
                    )

        if max_value is not None:
            if max_inclusive:
                if value > max_value:
                    raise ValidationError.with_detail(
                        "", "range", f"Value {value} is greater than maximum {max_value}",
                        {"min": min_value, "max": max_value}
                    )
            else:
                if value >= max_value:
                    raise ValidationError.with_detail(
                        "", "range", f"Value {value} is not less than {max_value}",
                        {"max": max_value}
                    )

        return value

    return validate


def length_(
    min_len: Optional[int] = None,
    max_len: Optional[int] = None,
) -> Validator:
    """Validator for string/list length."""
    def validate(value: Any) -> Any:
        length = len(value)

        if min_len is not None and length < min_len:
            raise ValidationError.with_detail(
                "", "length", f"Length {length} is less than minimum {min_len}",
                {"min": min_len, "max": max_len}
            )

        if max_len is not None and length > max_len:
            raise ValidationError.with_detail(
                "", "length", f"Length {length} is greater than maximum {max_len}",
                {"min": min_len, "max": max_len}
            )

        return value

    return validate


def regex_(pattern: Union[str, Pattern], flags: int = 0) -> Validator:
    """Validator that value matches a regex pattern."""
    compiled = re.compile(pattern, flags) if isinstance(pattern, str) else pattern

    def validate(value: str) -> str:
        if not compiled.search(value):
            raise ValidationError.with_detail(
                "", "regex", f"Value does not match pattern {pattern}",
                {"pattern": pattern}
            )
        return value

    return validate


# Pre-built validators
email = regex_(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

min_length = lambda n: length_(min_len=n)
max_length = lambda n: length_(max_len=n)
min_value = lambda n: range_(min_value=n)
max_value = lambda n: range_(max_value=n)


def one_of(*allowed: Any) -> Validator:
    """Validator that value is one of the allowed values."""
    allowed_set = set(allowed)

    def validate(value: Any) -> Any:
        if value not in allowed_set:
            raise ValidationError.with_detail(
                "", "choice", f"Value {value!r} is not one of {allowed}",
                {"allowed": list(allowed)}
            )
        return value

    return validate


def contains(*substrings: str, case_sensitive: bool = True) -> Validator:
    """Validator that string contains all specified substrings."""
    def validate(value: str) -> str:
        for substring in substrings:
            if case_sensitive:
                if substring not in value:
                    raise ValidationError.with_detail(
                        "", "contains", f"String does not contain {substring!r}",
                        {"required_substring": substring}
                    )
            else:
                if substring.lower() not in value.lower():
                    raise ValidationError.with_detail(
                        "", "contains", f"String does not contain {substring!r} (case-insensitive)",
                        {"required_substring": substring, "case_sensitive": False}
                    )
        return value
    return validate


def custom(func: Callable[[Any], bool], message: str = "Validation failed") -> Validator:
    """Create a custom validator from a function."""
    def validate(value: Any) -> Any:
        try:
            if not func(value):
                raise ValidationError.with_detail("", "custom", message)
        except ValidationError:
            raise
        except Exception as e:
            raise ValidationError.with_detail("", "custom_error", str(e))
        return value
    return validate


def _url_validator(value: str) -> bool:
    """Validate URL using urllib.parse."""
    from urllib.parse import urlparse
    try:
        parsed = urlparse(value)
        return parsed.scheme in ('http', 'https') and bool(parsed.netloc)
    except Exception:
        return False

url = custom(_url_validator, "Invalid URL format")

min_length = lambda n: length_(min_len=n)
max_length = lambda n: length_(max_len=n)
min_value = lambda n: range_(min_value=n)
max_value = lambda n: range_(max_value=n)


def one_of(*allowed: Any) -> Validator:
    """Validator that value is one of the allowed values."""
    allowed_set = set(allowed)

    def validate(value: Any) -> Any:
        if value not in allowed_set:
            raise ValidationError.with_detail(
                "", "choice", f"Value {value!r} is not one of {allowed}",
                {"allowed": list(allowed)}
            )
        return value

    return validate


def contains(*substrings: str, case_sensitive: bool = True) -> Validator:
    """Validator that string contains all specified substrings."""
    def validate(value: str) -> str:
        for substring in substrings:
            if case_sensitive:
                if substring not in value:
                    raise ValidationError.with_detail(
                        "", "contains", f"String does not contain {substring!r}",
                        {"required_substring": substring}
                    )
            else:
                if substring.lower() not in value.lower():
                    raise ValidationError.with_detail(
                        "", "contains", f"String does not contain {substring!r} (case-insensitive)",
                        {"required_substring": substring, "case_sensitive": False}
                    )
        return value
    return validate


def custom(func: Callable[[Any], bool], message: str = "Validation failed") -> Validator:
    """Create a custom validator from a function."""
    def validate(value: Any) -> Any:
        try:
            if not func(value):
                raise ValidationError.with_detail("", "custom", message)
        except ValidationError:
            raise
        except Exception as e:
            raise ValidationError.with_detail("", "custom_error", str(e))
        return value
    return validate


__all__ = [
    "validator",
    "range_",
    "length_",
    "regex_",
    "email",
    "url",
    "min_length",
    "max_length",
    "min_value",
    "max_value",
    "one_of",
    "contains",
    "custom",
    "Validator",
    "Callback",
]
