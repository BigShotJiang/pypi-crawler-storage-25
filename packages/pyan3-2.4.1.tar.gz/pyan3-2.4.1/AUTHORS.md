Original [pyan.py](https://github.com/ejrh/ejrh/blob/master/utils/pyan.py) for Python 2 by Edmund Horner, 2012. [Original blog post with explanation](http://ejrh.wordpress.com/2012/01/31/call-graphs-in-python-part-2/).

[Coloring and grouping](https://ejrh.wordpress.com/2012/08/18/coloured-call-graphs/) for GraphViz output by Juha Jeronen.

[Git repository cleanup](https://github.com/davidfraser/pyan/) and maintenance by David Fraser.

[yEd GraphML output, and framework for easily adding new output formats](https://github.com/davidfraser/pyan/pull/1) by Patrick Massot.

A bugfix [[2]](https://github.com/davidfraser/pyan/pull/2) and the option `--dot-rankdir` [[3]](https://github.com/davidfraser/pyan/pull/3) contributed by GitHub user ch41rmn.

A bug in `.tgf` output [[4]](https://github.com/davidfraser/pyan/pull/4) pointed out and fix suggested by Adam Eijdenberg.

This Python 3 port, analyzer expansion, and additional refactoring by Juha Jeronen.

HTML and SVG export by Jan Beitner.

Support for relative imports by Jan Beitner and Rakan Alanazi.

Relative path fix by Joenio Marques da Costa.

Migration to [uv](https://github.com/astral-sh/uv) build system by [A M](https://github.com/amw007) (BackBenchDevs).

Deterministic edge ordering fix by [Aurélien Grosdidier](https://github.com/aurelg).

`--dot-ranksep` and `--graphviz-layout` options by [Maciej A. Czyzewski](https://github.com/maciejczyzewski).

`get_module_name` bug report (`.py` in directory names) and `resolve_imports` KeyError fix by [CannedFish](https://github.com/CannedFish).

Directional graph filtering idea (`--direction up/down`) by [anetczuk](https://github.com/anetczuk).

Further contributions by Ioannis Filippidis, Jan Malek, José Eduardo Montenegro Cavalcanti de Oliveira, Mantas Zimnickas, Sam Basak, Brady Deetz, and GitHub user dmfreemon.

2026 revival, modernization for Python 3.10–3.14, module-level dependency analysis, and comprehensive test suite by Juha Jeronen, with [Claude](https://claude.ai/) (Anthropic) as AI pair programmer.
