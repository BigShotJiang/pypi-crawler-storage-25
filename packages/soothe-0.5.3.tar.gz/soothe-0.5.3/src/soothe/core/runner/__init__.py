"""SootheRunner -- protocol-orchestrated agent runner (RFC-0003, RFC-0007, RFC-0008, RFC-0009).

Wraps `create_soothe_agent()` with protocol pre/post-processing and
yields the deepagents-canonical ``(namespace, mode, data)`` stream
extended with ``soothe.*`` custom events for protocol observability.

RFC-0007 adds autonomous iteration: when ``autonomous=True``, the runner
loops reflect -> revise -> re-execute until the goal is complete or
max_iterations is reached.

RFC-0008 adds agentic loop: default execution mode with Reason → Act
iterative refinement loop (RFC-201) replacing single-pass execution.

RFC-0009 adds DAG-based step execution: plans with multiple steps are
iterated via ``StepScheduler``, independent steps can run in parallel,
and ``ConcurrencyController`` enforces hierarchical limits.

Implementation is decomposed into five mixins:

- `PhasesMixin`     -- pre/post-stream, LangGraph streaming, HITL loop
- `AgenticMixin`    -- agentic loop (RFC-0008)
- `AutonomousMixin` -- autonomous iteration loop (RFC-0007)
- `StepLoopMixin`   -- DAG-based step execution (RFC-0009)
- `CheckpointMixin` -- progressive checkpoint, artifacts, reports (RFC-0010)
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from soothe.config import SootheConfig
from soothe.core.intention import IntentHint
from soothe.core.workspace import resolve_workspace_for_stream
from soothe.protocols.planner import Plan, PlannerProtocol
from soothe.protocols.policy import PolicyProtocol

from ._runner_agentic import AgenticMixin
from ._runner_autonomous import AutonomousMixin
from ._runner_checkpoint import CheckpointMixin
from ._runner_phases import PhasesMixin
from ._runner_shared import StreamChunk
from ._runner_steps import StepLoopMixin
from ._types import generate_thread_id
from .factory import LoopRunnerFactory
from .local_runner import LocalLoopRunner, SubprocessLoopError

# Re-export types
__all__ = [
    "IntentHint",
    "LoopRunnerFactory",
    "LocalLoopRunner",
    "SootheRunner",
    "SubprocessLoopError",
    "generate_thread_id",
]

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from soothe.core.agent import CoreAgent
    from soothe.core.goal_engine import GoalEngine
    from soothe.protocols.memory import MemoryProtocol

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SootheRunner
# ---------------------------------------------------------------------------


class SootheRunner(CheckpointMixin, StepLoopMixin, AutonomousMixin, AgenticMixin, PhasesMixin):
    """Protocol-orchestrated agent runner.

    Wraps ``create_soothe_agent()`` with pre/post protocol steps and
    provides ``astream()`` that yields the deepagents-canonical stream
    format extended with ``soothe.*`` protocol custom events.

    Args:
        config: Soothe configuration. If ``None``, uses defaults.
    """

    def __init__(self, config: SootheConfig | None = None) -> None:
        """Initialize the runner with optional config."""
        import time

        from soothe.core.agent import create_soothe_agent
        from soothe.core.intention import IntentClassifier
        from soothe.core.resolver import (
            resolve_checkpointer,
            resolve_durability,
            resolve_goal_engine,
        )
        from soothe.core.scheduling import ConcurrencyController
        from soothe.protocols.concurrency import ConcurrencyPolicy

        init_start = time.perf_counter()

        self._config = config or SootheConfig()
        self._checkpointer_pool = None  # Will be set if using PostgreSQL

        # Installation workspace for fallback resolution (BM-001 fix)
        from soothe.config.env import default_soothe_workspace_dir

        self._installation_workspace = (
            Path(self._config.workspace_dir or default_soothe_workspace_dir())
            .expanduser()
            .resolve()
        )

        # Initialize intent classifier (IG-226: core.intention module).
        # Unified classification is always enabled; classifier is omitted only if fast model is unavailable.
        fast_model = None
        try:
            fast_model = self._config.create_chat_model("fast")
        except Exception:
            logger.exception(
                "Failed to create fast model for classification. Classification will be disabled."
            )
            fast_model = None

        if fast_model:
            self._intent_classifier = IntentClassifier(
                model=fast_model,
                assistant_name=self._config.assistant_name,
                soothe_config=self._config,
            )
            logger.info("[IntentClassifier] Initialized in LLM mode")
        else:
            logger.warning("No fast model available, classification disabled")
            self._intent_classifier = None

        checkpointer_start = time.perf_counter()
        checkpointer_result = resolve_checkpointer(self._config)
        if isinstance(checkpointer_result, tuple):
            self._checkpointer_pool = checkpointer_result[1]
            # Checkpointer will be created from pool in async context (_runner_phases.py)
            self._checkpointer = None  # Placeholder, set during async initialization
            self._checkpointer_initialized = False
        else:
            self._checkpointer = checkpointer_result
            self._checkpointer_pool = None
            self._checkpointer_initialized = True
        checkpointer_ms = (time.perf_counter() - checkpointer_start) * 1000
        logger.debug("Checkpointer resolved in %.1fms", checkpointer_ms)

        agent_start = time.perf_counter()
        self._agent: CoreAgent = create_soothe_agent(
            self._config,
            checkpointer=self._checkpointer,
        )
        agent_ms = (time.perf_counter() - agent_start) * 1000
        logger.info("CoreAgent created in %.1fms", agent_ms)

        # Access protocols via CoreAgent typed properties
        self._memory: MemoryProtocol | None = self._agent.memory
        self._planner: PlannerProtocol | None = self._agent.planner
        self._policy: PolicyProtocol | None = self._agent.policy

        # GoalEngine resolved in Layer 3 (separate from CoreAgent Layer 1)
        self._goal_engine: GoalEngine | None = resolve_goal_engine(self._config)

        durability_start = time.perf_counter()
        self._durability = resolve_durability(self._config)
        durability_ms = (time.perf_counter() - durability_start) * 1000
        logger.debug("Durability resolved in %.1fms", durability_ms)

        # Model for consensus loop (RFC-204 goal validation)
        self._model: Any | None = None
        try:
            self._model = self._config.create_chat_model("think")
            logger.debug("Consensus model initialized (role=think)")
        except Exception:
            logger.debug("Consensus model unavailable, consensus will use heuristic fallback")

        self._current_thread_id: str | None = None
        self._current_plan: Plan | None = None
        self._artifact_store: Any | None = (
            None  # Last-known store for CLI/debug; authoritative copy is on RunnerState
        )
        _lim = self._config.agent_loop.limits
        self._concurrency = ConcurrencyController(
            ConcurrencyPolicy(
                max_parallel_goals=_lim.max_parallel_goals,
                max_parallel_steps=_lim.max_parallel_steps,
                max_parallel_subagents=_lim.max_parallel_subagents,
                global_max_llm_calls=_lim.global_max_llm_calls,
                step_parallelism=_lim.step_parallelism,
            )
        )
        self._context_restore_lock = asyncio.Lock()
        self._interrupt_resolvers: dict[str, Any] = {}  # keyed by loop_id (Bug 5.7)
        # Client-visible loop id for the active ``astream`` (daemon / TUI HITL scope).
        self._client_loop_id_for_stream: str | None = None

        # IG-406: Shared PostgreSQL pool for AgentLoop state persistence
        # Initialized lazily in async context for high-concurrency support
        self._agentloop_shared_pool: Any = None  # SharedPostgreSQLPool | None

        total_ms = (time.perf_counter() - init_start) * 1000
        logger.info("SootheRunner initialized in %.1fms", total_ms)

    # -- public helpers -----------------------------------------------------

    @property
    def config(self) -> SootheConfig:
        """The active configuration."""
        return self._config

    @property
    def current_thread_id(self) -> str | None:
        """Thread ID for the active session, or ``None``."""
        return self._current_thread_id

    @property
    def current_plan(self) -> Plan | None:
        """The current plan, or ``None``."""
        return self._current_plan

    def set_current_thread_id(self, thread_id: str | None) -> None:
        """Set the active thread ID used by future runs.

        Args:
            thread_id: Thread ID to reuse, or ``None`` to clear.
        """
        self._current_thread_id = thread_id

    def _clear_query_scoped_runner_state(self) -> None:
        """Clear per-query mirrors on this singleton runner (IG-110).

        Authoritative plan and artifact data live on ``RunnerState`` per call;
        this resets CLI/debug pointers so cancelled or completed runs do not
        leak into the next ``astream`` invocation.
        """
        self._current_plan = None
        self._artifact_store = None

    def thread_context_manager(self) -> Any:
        """Return ``ThreadContextManager`` for durability/thread operations (IG-110).

        Callers outside core (e.g. daemon) should use this instead of reading
        ``runner._durability`` directly.
        """
        from soothe.core.thread import ThreadContextManager

        return ThreadContextManager(self._durability, self._config)

    async def resume_persisted_thread(self, thread_id: str) -> Any:
        """Resume thread metadata from durability (wrapper for daemon/CLI)."""
        return await self.thread_context_manager().resume_thread(thread_id)

    async def create_persisted_thread(
        self,
        *,
        thread_id: str | None = None,
        initial_message: Any = None,
        metadata: Any = None,
    ) -> Any:
        """Create a persisted thread (wrapper for daemon/CLI)."""
        return await self.thread_context_manager().create_thread(
            thread_id=thread_id,
            initial_message=initial_message,
            metadata=metadata,
        )

    async def get_agentloop_shared_pool(self) -> Any:
        """Get or initialize the shared PostgreSQL pool for AgentLoop state.

        IG-406: Singleton pool for high-concurrency (200+ threads) support.
        Pool is shared across all AgentLoopStateManager instances.

        Returns:
            SharedPostgreSQLPool instance if PostgreSQL configured, None for SQLite.
        """
        if self._agentloop_shared_pool is not None:
            return self._agentloop_shared_pool

        if self._config.persistence.default_backend != "postgresql":
            return None

        from soothe.core.loop.state.persistence.shared_pool import SharedPostgreSQLPool

        self._agentloop_shared_pool = await SharedPostgreSQLPool.get_shared_instance(self._config)
        return self._agentloop_shared_pool

    async def list_persisted_threads(
        self,
        thread_filter: Any | None = None,
        *,
        include_stats: bool = False,
        include_last_message: bool = False,
    ) -> list[Any]:
        """List threads with optional filtering."""
        return await self.thread_context_manager().list_threads(
            thread_filter,
            include_stats=include_stats,
            include_last_message=include_last_message,
        )

    async def get_persisted_thread(self, thread_id: str) -> Any:
        """Return enhanced thread info."""
        return await self.thread_context_manager().get_thread(thread_id)

    async def archive_persisted_thread(self, thread_id: str) -> None:
        """Archive a thread."""
        await self.thread_context_manager().archive_thread(thread_id)

    async def delete_persisted_thread(self, thread_id: str) -> None:
        """Delete a thread."""
        await self.thread_context_manager().delete_thread(thread_id)

    async def get_persisted_thread_messages(
        self,
        thread_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
        include_events: bool = False,
    ) -> list[Any]:
        """Load thread messages."""
        return await self.thread_context_manager().get_thread_messages(
            thread_id,
            limit=limit,
            offset=offset,
            include_events=include_events,
        )

    async def get_persisted_thread_artifacts(self, thread_id: str) -> list[Any]:
        """List thread artifacts."""
        return await self.thread_context_manager().get_thread_artifacts(thread_id)

    async def touch_thread_activity_timestamp(self, thread_id: str) -> None:
        """Refresh ``updated_at`` on thread metadata (activity ping)."""
        if not thread_id:
            return
        try:
            # Empty merge still reloads and persists with a fresh ``ThreadInfo.updated_at``
            # (``get_thread`` can be None for non-durability / not-yet-created records).
            await self._durability.update_thread_metadata(thread_id, {})
            logger.debug("Thread %s updated_at refreshed", thread_id)
        except KeyError:
            logger.debug(
                "touch_thread_activity_timestamp: no durability record for %s",
                thread_id,
            )
        except Exception:
            logger.debug("touch_thread_activity_timestamp failed", exc_info=True)

    def protocol_summary(self) -> dict[str, str]:
        """Return a summary of active protocol implementations."""
        return {
            "memory": type(self._memory).__name__ if self._memory else "none",
            "planner": type(self._planner).__name__ if self._planner else "none",
            "policy": type(self._policy).__name__ if self._policy else "none",
            "durability": type(self._durability).__name__,
        }

    async def memory_stats(self) -> dict[str, Any]:
        """Return memory statistics for the /memory slash command."""
        if not self._memory:
            return {"status": "disabled"}
        return {
            "status": "active",
            "backend": type(self._memory).__name__,
        }

    async def list_threads(self) -> list[dict[str, Any]]:
        """List all threads via DurabilityProtocol."""
        threads = await self._durability.list_threads()
        return [t.model_dump() for t in threads]

    async def list_durability_threads(self, thread_filter: Any | None = None) -> list[Any]:
        """List threads with optional ``ThreadFilter`` (daemon / tooling)."""
        return await self._durability.list_threads(thread_filter)

    async def cleanup(self) -> None:
        """Clean up resources during shutdown.

        Stops background indexer tasks and closes connection pools.
        IG-406: Closes shared AgentLoop PostgreSQL pool at daemon shutdown.
        """
        if self._checkpointer_pool is not None:
            try:
                # Check if pool is a string (SQLite path) or an object (PostgreSQL pool)
                is_sqlite = isinstance(self._checkpointer_pool, str)
            except Exception:
                is_sqlite = False

            try:
                if not is_sqlite:
                    # PostgreSQL pool needs explicit closing
                    await self._checkpointer_pool.close()
                    logger.info("Closed PostgreSQL checkpointer connection pool")
                # SQLite checkpointer manages its own connection via AsyncSqliteSaver
            except Exception:
                logger.debug("Failed to close checkpointer pool", exc_info=True)

        # IG-406: Close shared AgentLoop PostgreSQL pool
        if self._agentloop_shared_pool is not None:
            try:
                from soothe.core.loop.state.persistence.shared_pool import (
                    SharedPostgreSQLPool,
                )

                await SharedPostgreSQLPool.close_shared_instance()
                self._agentloop_shared_pool = None
                logger.info("Closed shared AgentLoop PostgreSQL pool")
            except Exception:
                logger.debug("Failed to close shared AgentLoop pool", exc_info=True)

        await self._close_attached_store(self._memory)

    def set_interrupt_resolver(self, loop_id: str, resolver: Any | None) -> None:
        """Set a temporary interactive interrupt resolver for a specific loop.

        Args:
            loop_id: The loop identifier to scope this resolver to.
            resolver: Async callable receiving pending interrupt payloads and
                returning a LangGraph resume payload, or `None` to remove the
                resolver for this loop.
        """
        if resolver is not None:
            self._interrupt_resolvers[loop_id] = resolver
        else:
            self._interrupt_resolvers.pop(loop_id, None)

    async def get_thread_state_values(self, thread_id: str) -> dict[str, Any]:
        """Return checkpoint state values for a thread.

        Args:
            thread_id: Thread identifier to inspect.

        Returns:
            State values keyed by channel name. Empty when no checkpoint exists.
        """
        await self._ensure_checkpointer_initialized()
        config = {"configurable": {"thread_id": thread_id}}
        state = await self._agent.graph.aget_state(config)
        if state and state.values:
            return dict(state.values)
        return {}

    async def update_thread_state_values(self, thread_id: str, values: dict[str, Any]) -> None:
        """Persist partial checkpoint state for a thread.

        Args:
            thread_id: Thread identifier to update.
            values: Partial state values to write.
        """
        await self._ensure_checkpointer_initialized()
        config = {"configurable": {"thread_id": thread_id}}
        await self._agent.graph.aupdate_state(config, values)

    async def _close_attached_store(self, owner: Any | None) -> None:
        """Close a nested `_store` field when available."""
        if owner is None:
            return
        store = getattr(owner, "_store", None)
        if store is not None:
            await self._safe_close(store)

    async def _safe_close(self, obj: Any) -> None:
        """Close an object that exposes a close method (sync or async)."""
        close_method = getattr(obj, "close", None)
        if not callable(close_method):
            return
        try:
            import asyncio

            if asyncio.iscoroutinefunction(close_method):
                await close_method()
            else:
                close_method()
        except Exception:
            logger.debug("Failed to close resource %s", type(obj).__name__, exc_info=True)

    # -- query classification helpers (RFC-0008, RFC-0012) -----------------

    async def _pre_stream_parallel_memory_context(
        self,
        user_input: str,
        complexity: str,
    ) -> tuple[list[Any], Any | None]:
        """Run memory and context operations in parallel for medium/complex queries (RFC-0008 Phase 2).

        Args:
            user_input: User query text.
            complexity: Query complexity level.

        Returns:
            Tuple of (memory_items, None).
        """
        if complexity not in ("medium", "complex"):
            return ([], None)

        if self._memory:
            try:
                memory_items = await self._memory.recall(user_input, limit=5)
                return memory_items, None
            except Exception:
                logger.debug("Memory recall failed", exc_info=True)
                return ([], None)
        return ([], None)

    # -- main stream --------------------------------------------------------

    async def astream(
        self,
        user_input: str,
        *,
        thread_id: str | None = None,
        workspace: str | None = None,
        autonomous: bool = False,
        max_iterations: int | None = None,
        preferred_subagent: str | None = None,
        client_loop_id: str | None = None,
        intent_hint: IntentHint | None = None,
    ) -> AsyncGenerator[StreamChunk]:
        """Stream agent execution with protocol orchestration.

        Yields ``(namespace, mode, data)`` tuples in the deepagents-canonical
        format.  Protocol events are emitted as ``custom`` events with
        ``soothe.*`` type prefix.

        **Two execution modes**:
        - ``autonomous=True`` (RFC-0007): Goal-driven iteration with explicit goal management
        - Default (RFC-201): Agentic loop with Reason → Act iteration

        Args:
            user_input: The user's query text.
            thread_id: Thread ID for persistence. Generated if not provided.
            workspace: Thread-specific workspace path (RFC-103). When omitted, resolved via
                ``resolve_workspace_for_stream`` (config ``workspace_dir``, then cwd). The
                resolved path is always a non-empty absolute directory string for this call.
            autonomous: Enable autonomous iteration loop (explicit goals).
            max_iterations: Override max iterations from config.
            preferred_subagent: Optional subagent hint merged into AgentLoop (IG-349).
            client_loop_id: Daemon client loop scope for interactive HITL (RFC-221); when set
                with a matching ``set_interrupt_resolver`` entry, CoreAgent interrupts pause
                until the client sends ``resume_interrupts``.
            intent_hint: Suggested intent to bypass LLM classification. When provided for
                chitchat or quiz, skips the intent classification LLM call entirely.
        """
        # Update thread_id for logging if one is provided
        from soothe.core.loop.engine.hitl_scope import (
            reset_hitl_interrupt_resolver_context,
            set_hitl_interrupt_resolver_context,
        )
        from soothe.logging import set_thread_id

        # Only set thread_id if explicitly provided
        if thread_id:
            set_thread_id(thread_id)
        elif self._current_thread_id:
            set_thread_id(self._current_thread_id)

        cl_scope = (client_loop_id or "").strip()
        prev_client_loop = self._client_loop_id_for_stream
        self._client_loop_id_for_stream = cl_scope or None
        hitl_tok = set_hitl_interrupt_resolver_context(
            self._interrupt_resolvers.get(cl_scope) if cl_scope else None
        )
        try:
            resolved = resolve_workspace_for_stream(
                explicit=workspace,
                installation_default=str(self._installation_workspace),
                config_workspace_dir=getattr(self._config, "workspace_dir", None),
            )
            effective_workspace = resolved.path
            tid_for_log = str(thread_id or self._current_thread_id or "")
            logger.debug(
                "stream_workspace_resolved thread_id=%s path=%s source=%s",
                tid_for_log,
                effective_workspace,
                resolved.source,
            )

            # Autonomous mode
            if autonomous and self._goal_engine:
                async for chunk in self._run_autonomous(
                    user_input,
                    thread_id=thread_id,
                    workspace=effective_workspace,
                    max_iterations=max_iterations or self._config.autonomous.max_iterations,
                    intent_hint=intent_hint,
                ):
                    yield chunk
                return

            # Default: agentic loop (RFC-0008)
            async for chunk in self._run_agentic_loop(
                user_input,
                thread_id=thread_id,
                workspace=effective_workspace,
                max_iterations=max_iterations or self._config.agent_loop.max_iterations,
                preferred_subagent=preferred_subagent,
                intent_hint=intent_hint,
            ):
                yield chunk
        finally:
            reset_hitl_interrupt_resolver_context(hitl_tok)
            self._client_loop_id_for_stream = prev_client_loop
            self._clear_query_scoped_runner_state()
