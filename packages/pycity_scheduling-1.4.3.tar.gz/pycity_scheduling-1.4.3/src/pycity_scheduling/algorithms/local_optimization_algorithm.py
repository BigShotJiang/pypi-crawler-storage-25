"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import numpy as np
import pyomo.environ as pyomo

from pycity_scheduling.algorithms.algorithm import DistributedAlgorithm, SolverNode
from pycity_scheduling.solvers import DEFAULT_SOLVER, DEFAULT_SOLVER_OPTIONS


class LocalOptimization(DistributedAlgorithm):
    """
    Implementation of the reference Local Optimization algorithm.
    Schedule all nodes (i.e., buildings) in `city_district` on their own.

    Parameters
    ----------
    city_district : CityDistrict
    solver : str, optional
        Solver to use for solving the local problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        `__call__` is the function being called when generating an instance
        with the pyomo SolverFactory. In addition to the options provided,
        `node_ids` is passed to this call containing the IDs of the entities
        being optimized.
        `set_instance` is called when a pyomo Model is set as an instance of
        a persistent solver. `solve` is called to perform an optimization. If
        not set, `save_results` and `load_solutions` may be set to false to
        provide a speedup.
    mode : str, optional
        Specifies which set of constraints to use.
        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the local optimization algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, city_district, solver=DEFAULT_SOLVER, solver_options=DEFAULT_SOLVER_OPTIONS, mode="convex",
                 measure_performance=False, robustness=None):
        super(LocalOptimization, self).__init__(city_district, solver, solver_options, mode)
        self.measure_performance = measure_performance
        self.robustness = robustness
        # create solver nodes for each entity
        self.nodes = [
            SolverNode(solver, solver_options, [entity], mode, measure_performance=measure_performance,
                       robustness=robustness)
            for entity in self.entities
        ]
        # create coupling for city district model only
        self._add_coupling(self.nodes[0].model)
        # create pyomo parameters for beta of each entity
        for node in self.nodes:
            node.model.beta = pyomo.Param(mutable=True, initialize=1)
        self._add_objective()

    def _add_coupling(self, model):
        """Adds the coupling constraint to the model.

        This constraint 'connects' the district operator to all its nodes.

        Parameters
        ----------
        model : pyomo.ConcreteModel
            Model to add the constraint to.
        """
        model.cd_consumption = pyomo.Param(self.city_district.model.t, mutable=True)

        def p_el_couple_rule(model, t):
            return self.city_district.model.p_el_vars[t] == model.cd_consumption[t]
        model.couple = pyomo.Constraint(self.city_district.model.t, rule=p_el_couple_rule)
        return

    def _add_objective(self):
        for node, entity in zip(self.nodes, self.entities):
            node.model.o = pyomo.Objective(expr=node.model.beta * entity.get_objective())
        return

    def _presolve(self, full_update, beta, robustness, debug):
        results, params = super()._presolve(full_update, beta, robustness, debug)
        for entity in self.entities:
            entity.model.beta = self._get_beta(params, beta)
        for node in self.nodes[1:]:
            if full_update:
                node.full_update(robustness=robustness)
            else:
                node.obj_update()
        return results, params

    def _solve(self, results, params, debug):
        results["cpu_cycles"] = np.uint64(0)
        results["cpu_instructions"] = np.uint64(0)

        self._solve_nodes(results, params, self.nodes[1:], variables=None, debug=debug)
        for t in range(len(self.nodes[0].model.cd_consumption)):
            self.nodes[0].model.cd_consumption[t] = sum(entity.p_el_schedule[t] for entity in self.entities[1:])
        self.nodes[0].full_update(params["robustness"])
        self.nodes[0].solve(results, debug=debug)
        self._save_time(results, params)
        results["obj_value"] = self._get_objective()
        return

    def _get_objective(self):
        obj_value = 0
        for i, node, entity in zip(range(len(self.entities)), self.nodes, self.entities):
            obj_value += pyomo.value(entity.get_objective())
        return obj_value
