"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import numpy as np
import pyomo.environ as pyomo

from pycity_scheduling.algorithms.algorithm import OptimizationAlgorithm, SolverNode
from pycity_scheduling.solvers import DEFAULT_SOLVER, DEFAULT_SOLVER_OPTIONS


class CentralOptimization(OptimizationAlgorithm):
    """
    Implementation of the reference Central Optimization algorithm.
    Schedule the entire city_district on its own.

    Parameters
    ----------
    city_district : CityDistrict
    solver : str, optional
        Solver to use for solving the centralized problem.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        `__call__` is the function being called when generating an instance
        with the pyomo SolverFactory. In addition to the options provided,
        `node_ids` is passed to this call containing the IDs of the entities
        being optimized.
        `set_instance` is called when a pyomo Model is set as an instance of
        a persistent solver. `solve` is called to perform an optimization. If
        not set, `save_results` and `load_solutions` may be set to false to
        provide a speedup.
    mode : str, optional
        Specifies which set of constraints to use.
        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the central optimization algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, city_district, solver=DEFAULT_SOLVER, solver_options=DEFAULT_SOLVER_OPTIONS, mode="convex",
                 measure_performance=False, robustness=None):
        super(CentralOptimization, self).__init__(city_district, solver, solver_options, mode)
        self.measure_performance = measure_performance
        self.robustness = robustness
        # create single solver node for all entities
        self.node = SolverNode(solver, solver_options, self.entities, mode, measure_performance=measure_performance,
                               robustness=robustness)
        # add coupling between all entities in the single model
        self._add_coupling(self.node.model)
        # create pyomo parameters for beta of each entity
        for entity in self.entities:
            entity.model.beta = pyomo.Param(mutable=True, initialize=1)
        self._add_objective()

    def _add_coupling(self, model):
        """Adds the coupling constraint to the model.

        This constraint 'connects' the district operator to all its nodes.

        Parameters
        ----------
        model : pyomo.ConcreteModel
            Model to add the constraint to.
        """
        def p_el_couple_rule(model, t):
            return self.city_district.model.p_el_vars[t] == \
                   sum(entity.model.p_el_vars[t] for entity in self.entities[1:])
        model.couple = pyomo.Constraint(self.city_district.model.t, rule=p_el_couple_rule)
        return

    def _add_objective(self):
        self.node.model.o = pyomo.Objective(expr=sum(entity.model.beta * entity.get_objective()
                                                     for entity in self.entities))
        return

    def _presolve(self, full_update, beta, robustness, debug):
        results, params = super()._presolve(full_update, beta, robustness, debug)
        for entity in self.entities:
            entity.model.beta = self._get_beta(params, beta)
        if full_update:
            self.node.full_update(robustness=robustness)
        else:
            self.node.obj_update()
        return results, params

    def _solve(self, results, params, debug):
        results["cpu_cycles"] = np.uint64(0)
        results["cpu_instructions"] = np.uint64(0)

        if self.node.measure_performance:
            self.node.perf.measure_perf(self.node.solve, results, debug)
        else:
            self.node.solve(results, debug=debug)

        # Save results & objective value
        self._save_time(results, params)
        try:
            results["obj_value"] = pyomo.value(self.node.model.o)
        except:
            results["obj_value"] = 0.0

        return
