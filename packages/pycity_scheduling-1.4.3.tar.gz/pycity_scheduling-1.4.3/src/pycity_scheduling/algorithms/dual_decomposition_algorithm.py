"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import numpy as np
import pyomo.environ as pyomo

from pycity_scheduling.classes import (CityDistrict, Building, Photovoltaic, WindEnergyConverter)
from pycity_scheduling.algorithms.algorithm import IterationAlgorithm, DistributedAlgorithm, SolverNode
from pycity_scheduling.solvers import DEFAULT_SOLVER, DEFAULT_SOLVER_OPTIONS


class DualDecomposition(IterationAlgorithm, DistributedAlgorithm):
    """
    Implementation of the distributed Dual Decomposition algorithm as described in [1].

    Parameters
    ----------
    city_district : CityDistrict
    solver : str, optional
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        `__call__` is the function being called when generating an instance
        with the pyomo SolverFactory. In addition to the options provided,
        `node_ids` is passed to this call containing the IDs of the entities
        being optimized.
        `set_instance` is called when a pyomo Model is set as an instance of
        a persistent solver. `solve` is called to perform an optimization. If
        not set, `save_results` and `load_solutions` may be set to false to
        provide a speedup.
    mode : str, optional
        Specifies which set of constraints to use.
        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    eps_primal : float, optional
        Primal stopping criterion for the Dual Decomposition algorithm.
    rho : float, optional
        Step size for the Dual Decomposition algorithm.
    norm_order : int, optional
        Order of norm to be used for stopping criteria evaluation. For max-norm, use np.inf.
    max_iterations : int, optional
        Maximum number of ADMM iterations.
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the Dual Decomposition algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.

    References
    ----------
    [1] "Distributed Optimization for Scheduling Electrical Demand in Complex City Districts" by
    M. Diekerhof, S. Schwarz, F. Martin, A. Monti in IEEE Systems Journal, vol. 12, no. 4, pp. 3226-3237, Dec. 2018.
    """
    def __init__(self, city_district, solver=DEFAULT_SOLVER, solver_options=DEFAULT_SOLVER_OPTIONS, mode="convex",
                 eps_primal=0.1, rho=2.0, norm_order=np.inf, max_iterations=10000, measure_performance=False,
                 robustness=None):
        super(DualDecomposition, self).__init__(city_district, solver, solver_options, mode)
        self.eps_primal = eps_primal
        self.rho = rho
        self.norm_order = norm_order
        self.max_iterations = max_iterations
        self.measure_performance = measure_performance
        self.robustness = robustness
        self.op_horizon = self.city_district.op_horizon

        # Only consider entities of type CityDistrict, Building, Photovoltaic, WindEnergyConverter
        self._entities = [entity for entity in self.entities if
                          isinstance(entity, (CityDistrict, Building, Photovoltaic, WindEnergyConverter))]

        # Create a solver node for each entity
        self.nodes = [SolverNode(solver, solver_options, [entity], mode, measure_performance=measure_performance,
                                 robustness=robustness)
                      for entity in self._entities]

        # Create pyomo parameters for each entity
        for node, entity in zip(self.nodes, self._entities):
            node.model.beta = pyomo.Param(mutable=True, initialize=1)
            node.model.lambdas = pyomo.Param(entity.model.t, mutable=True, initialize=0)
        self._add_objective()

    def _add_objective(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            obj = node.model.beta * entity.get_objective()
            if isinstance(entity, CityDistrict):
                # penalty term is expanded and constant is omitted
                # invert sign of p_el_schedule and p_el_vars (omitted for quadratic term)
                for t in range(self.op_horizon):
                    obj -= node.model.lambdas[t] * entity.model.p_el_vars[t]
            else:
                for t in range(self.op_horizon):
                    obj += node.model.lambdas[t] * entity.model.p_el_vars[t]
            node.model.o = pyomo.Objective(expr=obj)
        return

    def _get_objective(self, residual=None):
        obj_value = 0
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            # additionally impose aggregator objective function with current residual schedule:
            if isinstance(entity, CityDistrict) and residual is not None:
                original_p_el_values = None
                original_p_el_import_values = None
                original_p_el_export_values = None
                original_max_consumption_value = None
                if hasattr(entity.model, "p_el_vars"):
                    original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                    actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                          in range(len(residual))}
                    entity.model.p_el_vars.set_values(actual_p_el_values)
                if hasattr(entity.model, "p_el_import_vars"):
                    original_p_el_import_values = {idx: var.value for idx, var in
                                                   entity.model.p_el_import_vars.items()}
                    actual_p_el_import_values = {j: original_p_el_import_values.get(j, 0.0) +
                                                    max(float(residual[j]), 0.0) for j in range(len(residual))}
                    entity.model.p_el_import_vars.set_values(actual_p_el_import_values)
                if hasattr(entity.model, "p_el_export_vars"):
                    original_p_el_export_values = {idx: var.value for idx, var in
                                                   entity.model.p_el_export_vars.items()}
                    actual_p_el_export_values = {j: original_p_el_export_values.get(j, 0.0) +
                                                    min(float(residual[j]), 0.0) for j in range(len(residual))}
                    entity.model.p_el_export_vars.set_values(actual_p_el_export_values)
                if hasattr(entity.model, "max_consumption_var"):
                    original_max_consumption_value = pyomo.value(entity.model.max_consumption_var)
                    original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                    actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                          in range(len(residual))}
                    actual_max_consumption_value = max(abs(v) for v in actual_p_el_values.values())
                    entity.model.max_consumption_var.set_value(actual_max_consumption_value)
                obj_value += pyomo.value(entity.get_objective())
                if hasattr(entity.model, "p_el_vars"):
                    entity.model.p_el_vars.set_values(original_p_el_values)
                if hasattr(entity.model, "p_el_import_vars"):
                    entity.model.p_el_import_vars.set_values(original_p_el_import_values)
                if hasattr(entity.model, "p_el_export_vars"):
                    entity.model.p_el_export_vars.set_values(original_p_el_export_values)
                if hasattr(entity.model, "max_consumption_var"):
                    entity.model.max_consumption_var.set_value(original_max_consumption_value)
            else:
                obj_value += pyomo.value(entity.get_objective())
        return obj_value

    def _presolve(self, full_update, beta, robustness, debug):
        results, params = super()._presolve(full_update, beta, robustness, debug)
        for node, entity in zip(self.nodes, self._entities):
            node.model.beta = self._get_beta(params, entity)
            if full_update:
                node.full_update(robustness)
        results["r_norms"] = []
        results["lambdas"] = []
        return results, params

    def _is_last_iteration(self, results, params, debug):
        if super(DualDecomposition, self)._is_last_iteration(results, params, debug):
            return True
        return results["r_norms"][-1] <= self.eps_primal

    def _iteration(self, results, params, debug):
        super(DualDecomposition, self)._iteration(results, params, debug)
        if "lambdas" not in params:
            params["lambdas"] = np.zeros(self.op_horizon)
        lambdas = params["lambdas"]

        # ------------------------------------------
        # 1) Optimize all entities
        # ------------------------------------------
        to_solve_nodes = []
        variables = []
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            for t in range(self.op_horizon):
                node.model.lambdas[t] = lambdas[t]
            node.obj_update()
            to_solve_nodes.append(node)
            variables.append([entity.model.p_el_vars[t] for t in range(self.op_horizon)])
        self._solve_nodes(results, params, to_solve_nodes, variables=variables, debug=debug)

        # ------------------------------------------
        # 2) Calculate incentive signal update
        # ------------------------------------------
        p_el_schedules = np.stack([entity.p_el_schedule for entity in self._entities], axis=0)
        lambdas -= self.rho * p_el_schedules[0]
        lambdas += self.rho * np.sum(p_el_schedules[1:], axis=0)

        # ------------------------------------------
        # 3) Calculate parameters for stopping criteria and metrics
        # ------------------------------------------
        r = np.zeros(self.op_horizon)
        r -= p_el_schedules[0]
        r += np.sum(p_el_schedules[1:], axis=0)
        results["r_norms"].append(np.linalg.norm(r, ord=self.norm_order))
        results["lambdas"].append(np.copy(lambdas))
        results["obj_value"].append(self._get_objective(residual=r))

        # ------------------------------------------
        # 4) Save required parameters for another iteration
        # ------------------------------------------
        params["lambdas"] = lambdas
        return
