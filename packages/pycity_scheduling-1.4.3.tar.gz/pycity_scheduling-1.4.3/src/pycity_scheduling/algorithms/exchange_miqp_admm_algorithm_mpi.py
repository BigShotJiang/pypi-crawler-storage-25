"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import pickle
import numpy as np
import pyomo.environ as pyomo
import matplotlib.pyplot as plt

from pycity_scheduling.classes import (CityDistrict, Building, Photovoltaic, WindEnergyConverter)
from pycity_scheduling.algorithms.algorithm import IterationAlgorithm, DistributedAlgorithm, SolverNode
from pycity_scheduling.solvers import DEFAULT_SOLVER, DEFAULT_SOLVER_OPTIONS


class ExchangeMIQPADMMMPI(IterationAlgorithm, DistributedAlgorithm):
    """Implementation of the Exchange MIQP ADMM algorithm.

    Implements the Exchange MIQP ADMM algorithm described in [1], [2], and [3] using parallel computations with MPI.

    Parameters
    ----------
    city_district : CityDistrict
    mpi_interface : MPIInterface
        MPI Interface to use for solving the Exchange MIQP ADMM subproblems in parallel.
    solver : str, optional
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        `__call__` is the function being called when generating an instance
        with the pyomo SolverFactory. In addition to the options provided,
        `node_ids` is passed to this call containing the IDs of the entities
        being optimized.
        `set_instance` is called when a pyomo Model is set as an instance of
        a persistent solver. `solve` is called to perform an optimization. If
        not set, `save_results` and `load_solutions` may be set to false to
        provide a speedup.
    mode : str, optional
        Specifies which set of constraints to use.
        - `convex` : Use linear constraints
        - `integer` : May use non-linear constraints
    x_update_mode : str, optional
        Specifies which variant of Exchange MIQP ADMM to use.
        - `constrained` : use the algorithm with constraints
        - `unconstrained` : use the algorithm without constraints (deprecated; no longer supported!)
    measure_performance : bool, optional
        Measure CPU cycles and instructions as well as MPI communication efforts for the Exchange MIQP ADMM algorithm.
        This is recommended for performance benchmarking purposes only and requires Linux perf as well as Linux kernel
        setting 'kernel.perf_event_paranoid=0'.
    eps_exch_primal : float, optional
        Primal stopping criterion for the Exchange MIQP ADMM algorithm.
    eps_exch_dual : float, optional
        Dual stopping criterion for the Exchange MIQP ADMM algorithm.
    gamma : float, optional
        Exchange MIQP ADMM scaling parameter
    gamma_incr : float, optional
        Varying scaling parameter scheme increase parameter
    rho : float, optional
        Stepsize for the ADMM algorithm.
    varying_penalty_parameter : bool, optional
        Apply a varying penalty parameter scheme, see [3] - chapter 3.4.1
    tau_incr : float, optional
        Varying penalty parameter scheme increase parameter
    tau_decr : float, optional
        Varying penalty parameter scheme decrease parameter
    mu : float, optional
        Varying penalty parameter scheme conditional change parameter
    norm_order : int, optional
        Order of norm to be used for stopping criteria evaluation. For max-norm, use np.inf.
    max_iterations : int, optional
        Maximum number of Exchange MIQP ADMM iterations.
    lower_bound : float, optional
        Numerical value of lower bound for MIP gap calculation.
        For lower bound estimation based on r-norm and s-norm values, use None (default).
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.

    References
    ----------
    [1] "Alternating Direction Method of Multipliers for Decentralized
    Electric Vehicle Charging Control" by Jose Rivera, Philipp Wolfrum,
    Sandra Hirche, Christoph Goebel, and Hans-Arno Jacobsen
    Online: https://mediatum.ub.tum.de/doc/1187583/1187583.pdf (accessed on 2020/09/28)

    [2] "A simple effective heuristic for embedded mixed-integer quadratic programming" by Reza Takapoui,
    Nicholas Moehle, Stephen Boyd, and Alberto Bemporad
    Online: https://web.stanford.edu/~boyd/papers/pdf/miqp_admm.pdf (accessed on 2023/09/06)

    [3] "Distributed Optimization and Statistical Learning via the Alternating Direction Method of Multipliers" by
    Stephen Boyd, Neal Parikh, Eric Chu, Borja Peleato, and Jonathan Eckstein
    Online: https://web.stanford.edu/~boyd/papers/pdf/admm_distr_stats.pdf (accessed on 2023/10/09)
    """
    def __init__(self, city_district, mpi_interface, solver=DEFAULT_SOLVER, solver_options=DEFAULT_SOLVER_OPTIONS,
                 mode="convex", measure_performance=False, x_update_mode="constrained", eps_exch_primal=0.01,
                 eps_exch_dual=0.1, gamma=1.0, gamma_incr=1.0, rho=2.0, varying_penalty_parameter=False, tau_incr=2.0,
                 tau_decr=2.0, mu=10.0, norm_order=2, max_iterations=10000, lower_bound=None, robustness=None):
        super(ExchangeMIQPADMMMPI, self).__init__(city_district, solver, solver_options, mode)
        self.mpi_interface = mpi_interface
        self.measure_performance = measure_performance
        self.x_update_mode = x_update_mode
        self.eps_exch_primal = eps_exch_primal
        self.eps_exch_dual = eps_exch_dual
        self.gamma = gamma
        self.gamma_incr = gamma_incr
        self.rho = rho
        self.varying_penalty_parameter = varying_penalty_parameter
        self.tau_incr = tau_incr
        self.tau_decr = tau_decr
        self.mu = mu
        self.norm_order = norm_order
        self.max_iterations = max_iterations
        self.lower_bound = lower_bound
        self.robustness = robustness
        self.op_horizon = self.city_district.op_horizon

        # Only consider entities of type CityDistrict, Building, Photovoltaic, WindEnergyConverter
        self._entities = [entity for entity in self.entities if
                          isinstance(entity, (CityDistrict, Building, Photovoltaic, WindEnergyConverter))]

        # Create solver nodes for each entity
        self.nodes = [
            SolverNode(solver, solver_options, [entity], mode, measure_performance=measure_performance,
                       robustness=robustness)
            for entity in self._entities
        ]

        # Determine which MPI processes is responsible for which node(s):
        self.mpi_process_range = self.mpi_interface.get_mpi_process_range(len(self._entities))

        # Create pyomo parameters for each entity
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                node.model.gamma_ = pyomo.Param(mutable=True, initialize=self.gamma)
                node.model.rho_ = pyomo.Param(mutable=True, initialize=self.rho)
                node.model.beta = pyomo.Param(mutable=True, initialize=1)
                node.model.x_ = pyomo.Param(entity.model.t, mutable=True, initialize=0)
                node.model.u_exch = pyomo.Param(entity.model.t, mutable=True, initialize=0)
                node.model.last_p_el_schedules = pyomo.Param(entity.model.t, mutable=True, initialize=0)

        # Additions to the Exchange ADMM algorithm in order to obtain Exchange MIQP ADMM
        self.feasible = False
        self.district_binaries = self._get_binaries()
        self.district_equalities_t, self.district_equalities_n, \
            self.district_inequalities_t, self.district_inequalities_n = self._get_constraints()
        self._set_parameters()
        self._add_objective(exchange_admm_obj_terms=True, miqp_admm_obj_terms=True)

    # Function to get the binary variables from the model, to store them and to change their domain to reals
    def _get_binaries(self):
        district_binaries_dict = {}

        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            # skip CityDistrict object:
            if isinstance(entity, CityDistrict):
                district_binaries_dict[i] = {}
                continue

            var_dict = {}
            for en in entity.get_all_entities():
                for var in en.model.component_objects(pyomo.Var):
                    if var[0].domain is pyomo.Binary:
                        var.domain = pyomo.Reals
                        var.setlb(0)
                        var.setub(1)
                        for index in var:
                            var[index].fixed = False
                        var_dict[var.name] = {
                            'var': var,
                            'x_val': np.zeros((len(var), self.max_iterations + 1)),
                            'x_k': np.zeros((len(var), self.max_iterations + 1)),
                            'u_int_k': np.zeros((len(var), self.max_iterations + 1))
                        }
            district_binaries_dict[i] = var_dict

        return district_binaries_dict

    def _get_constraints(self):
        # There are time indexed and none indexed constraints. They all need be stored in separate lists.
        district_equalities_t = {}
        district_equalities_n = {}
        district_inequalities_t = {}
        district_inequalities_n = {}

        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            eq_t_dict = {}
            eq_n_dict = {}
            ineq_t_dict = {}
            ineq_n_dict = {}

            # skip CityDistrict object:
            if isinstance(entity, CityDistrict):
                district_equalities_t[i] = {}
                district_equalities_n[i] = {}
                district_inequalities_t[i] = {}
                district_inequalities_n[i] = {}
                continue

            for en in entity.get_all_entities():
                for constr in en.model.component_objects(pyomo.Constraint):
                    equality_flag = False
                    inequality_flag = False
                    none_index_flag = False

                    # check if a constraint is indexed
                    for index in constr:
                        if index is None:
                            none_index_flag = True

                        # check if the constraint is an equality constraint and write it in the form Ax-b=0
                        if pyomo.value(constr[index].lower) == pyomo.value(constr[index].upper):
                            expr = constr[index].body - constr[index].lower
                            constr[index].set_value(expr == 0)
                            equality_flag = True

                        # if the constraint is not an equality constraint it must be an inequality constraint;
                        # the next three checks are about to write that constraint in the form Cx-d >= 0
                        elif pyomo.value(constr[index].upper) is None:
                            expr = constr[index].body - constr[index].lower
                            constr[index].set_value(expr >= 0)
                            inequality_flag = True

                        elif pyomo.value(constr[index].lower) is None:
                            expr = -constr[index].body + constr[index].upper
                            constr[index].set_value(expr >= 0)
                            inequality_flag = True

                        else:
                            # edge case: lb and ub set; print a warning
                            expr = -constr[index].body + constr[index].upper
                            expr = constr[index].body - constr[index].lower
                            print("WARNING: Constraint has both lb and ub and is not deactivated!")
                            inequality_flag = True

                    # enter constraint into the right dictionary
                    if equality_flag:
                        if none_index_flag:
                            eq_n_dict[constr.name] = {'constr': constr, 'time_indexed': False}
                        else:
                            eq_t_dict[constr.name] = {'constr': constr, 'time_indexed': True}
                    if inequality_flag:
                        if none_index_flag:
                            ineq_n_dict[constr.name] = {'constr': constr, 'time_indexed': False}
                        else:
                            ineq_t_dict[constr.name] = {'constr': constr, 'time_indexed': True}

            district_equalities_t[i] = eq_t_dict
            district_equalities_n[i] = eq_n_dict
            district_inequalities_t[i] = ineq_t_dict
            district_inequalities_n[i] = ineq_n_dict

        return district_equalities_t, district_equalities_n, district_inequalities_t, district_inequalities_n

    def _set_parameters(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            vars_dict = self.district_binaries[i]
            node.model.time_set = pyomo.RangeSet(0, self.op_horizon - 1)

            if vars_dict:
                var_names = list(vars_dict.keys())
                node.model.bin_set = pyomo.Set(initialize=var_names)

                node.model.x_k = pyomo.Param(node.model.bin_set, node.model.time_set, mutable=True,
                                             initialize=0)
                node.model.u_int = pyomo.Param(node.model.bin_set, node.model.time_set, mutable=True,
                                              initialize=0)

            if self.x_update_mode == "unconstrained":
                # Create parameters for each constraint
                eq_t_dict = self.district_equalities_t[i]
                if eq_t_dict:
                    node.model.eq_t_set = pyomo.Set(initialize=list(eq_t_dict.keys()))
                    node.model.u_eq_t = pyomo.Param(node.model.eq_t_set, node.model.time_set,
                                                    mutable=True, initialize=0)

                eq_n_dict = self.district_equalities_n[i]
                if eq_n_dict:
                    node.model.eq_n_set = pyomo.Set(initialize=list(eq_n_dict.keys()))
                    node.model.u_eq_n = pyomo.Param(node.model.eq_n_set, mutable=True, initialize=0)

                ineq_t_dict = self.district_inequalities_t[i]
                if ineq_t_dict:
                    node.model.ineq_t_set = pyomo.Set(initialize=list(ineq_t_dict.keys()))
                    node.model.u_ineq_t = pyomo.Param(node.model.ineq_t_set, node.model.time_set,
                                                      mutable=True, initialize=0)
                    node.model.v_k_t = pyomo.Param(node.model.ineq_t_set, node.model.time_set,
                                                   mutable=True, initialize=0)

                ineq_n_dict = self.district_inequalities_n[i]
                if ineq_n_dict:
                    node.model.ineq_n_set = pyomo.Set(initialize=list(ineq_n_dict.keys()))
                    node.model.u_ineq_n = pyomo.Param(node.model.ineq_n_set, mutable=True, initialize=0)
                    node.model.v_k_n = pyomo.Param(node.model.ineq_n_set, mutable=True, initialize=0)
        return

    # Returns True, if no constraint or binary variable violations occur
    def _check_violations(self, print_out=True, detailed_print_out=False):
        if self.mpi_interface.mpi_size > 1:
            violated_var_counter_arr = np.zeros(len(self._entities), dtype=np.int32)
            violated_constr_counter_arr = np.zeros(len(self._entities), dtype=np.int32)
            total_var_counter_arr = np.zeros(len(self._entities), dtype=np.int32)
            total_constr_counter_arr = np.zeros(len(self._entities), dtype=np.int32)
            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                violated_var_counter = 0
                violated_constr_counter = 0
                total_var_counter = 0
                total_constr_counter = 0

                if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                    vars_dict = self.district_binaries[i]

                    # check binaries:
                    for var_name, var_info in vars_dict.items():
                        var = var_info['var']

                        for t in range(len(var)):
                            total_var_counter += 1
                            val = var[t].value
                            if (-0.001 < val < 0.001) or (0.999 < val < 1.001):
                                continue
                            violated_var_counter += 1
                            if detailed_print_out:
                                var[t].pprint()

                    # check equality constraints:
                    for constr_name, constr_info in self.district_equalities_t[i].items():
                        total_constr_counter += len(constr_info['constr'])
                        for index in range(len(constr_info['constr'])):
                            c = constr_info['constr'][index]
                            if c.body is not None:
                                if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                    violated_constr_counter += 1
                                    if detailed_print_out:
                                        print(constr_name, pyomo.value(c.body))
                                elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                    violated_constr_counter += 1
                                    if detailed_print_out:
                                        print(constr_name, pyomo.value(c.body))

                    for constr_name, constr_info in self.district_equalities_n[i].items():
                        total_constr_counter += 1
                        c = constr_info['constr']
                        if hasattr(c, 'body'):
                            if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))
                            elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))

                    # check inequality constraints:
                    for constr_name, constr_info in self.district_inequalities_t[i].items():
                        total_constr_counter += len(constr_info['constr'])
                        for index in range(len(constr_info['constr'])):
                            c = constr_info['constr'][index]
                            if c.body is not None:
                                if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                    violated_constr_counter += 1
                                    if detailed_print_out:
                                        print(constr_name, pyomo.value(c.body))
                                elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                    violated_constr_counter += 1
                                    if detailed_print_out:
                                        print(constr_name, pyomo.value(c.body))

                    for constr_name, constr_info in self.district_inequalities_n[i].items():
                        total_constr_counter += 1
                        c = constr_info['constr']
                        if hasattr(c, 'body'):
                            if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))
                            elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))

                    violated_var_counter_arr[i] = violated_var_counter
                    violated_constr_counter_arr[i] = violated_constr_counter
                    total_var_counter_arr[i] = total_var_counter
                    total_constr_counter_arr[i] = total_constr_counter

            violated_var_counter_tmp = np.zeros(len(self._entities), dtype=np.int32)
            violated_constr_counter_tmp = np.zeros(len(self._entities), dtype=np.int32)
            total_var_counter_tmp = np.zeros(len(self._entities), dtype=np.int32)
            total_constr_counter_tmp = np.zeros(len(self._entities), dtype=np.int32)
            self.mpi_interface.get_comm().Allreduce(violated_var_counter_arr, violated_var_counter_tmp,
                                                    self.mpi_interface.mpi.SUM)
            self.mpi_interface.get_comm().Allreduce(violated_constr_counter_arr, violated_constr_counter_tmp,
                                                    self.mpi_interface.mpi.SUM)
            self.mpi_interface.get_comm().Allreduce(total_var_counter_arr, total_var_counter_tmp,
                                                    self.mpi_interface.mpi.SUM)
            self.mpi_interface.get_comm().Allreduce(total_constr_counter_arr, total_constr_counter_tmp,
                                                    self.mpi_interface.mpi.SUM)
            violated_var_counter = np.sum(violated_var_counter_tmp)
            violated_constr_counter = np.sum(violated_constr_counter_tmp)
            total_var_counter = np.sum(total_var_counter_tmp)
            total_constr_counter = np.sum(total_constr_counter_tmp)
        else:
            violated_var_counter = 0
            violated_constr_counter = 0
            total_var_counter = 0
            total_constr_counter = 0
            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                vars_dict = self.district_binaries[i]

                # check binaries:
                for var_name, var_info in vars_dict.items():
                    var = var_info['var']

                    for t in range(len(var)):
                        total_var_counter += 1
                        val = var[t].value
                        if (-0.001 < val < 0.001) or (0.999 < val < 1.001):
                            continue
                        violated_var_counter += 1
                        if detailed_print_out:
                            var[t].pprint()

                # check equality constraints:
                for constr_name, constr_info in self.district_equalities_t[i].items():
                    total_constr_counter += len(constr_info['constr'])
                    for index in range(len(constr_info['constr'])):
                        c = constr_info['constr'][index]
                        if c.body is not None:
                            if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))
                            elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))

                for constr_name, constr_info in self.district_equalities_n[i].items():
                    total_constr_counter += 1
                    c = constr_info['constr']
                    if hasattr(c, 'body'):
                        if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))
                        elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))

                # check inequality constraints:
                for constr_name, constr_info in self.district_inequalities_t[i].items():
                    total_constr_counter += len(constr_info['constr'])
                    for index in range(len(constr_info['constr'])):
                        c = constr_info['constr'][index]
                        if c.body is not None:
                            if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))
                            elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                                violated_constr_counter += 1
                                if detailed_print_out:
                                    print(constr_name, pyomo.value(c.body))

                for constr_name, constr_info in self.district_inequalities_n[i].items():
                    total_constr_counter += 1
                    c = constr_info['constr']
                    if hasattr(c, 'body'):
                        if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))
                        elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))
        if print_out:
            print("Violated binaries:", violated_var_counter, "of in total", total_var_counter)
            print("Violated constraints:", violated_constr_counter,  "of in total", total_constr_counter)
        return violated_var_counter, violated_constr_counter

    # Returns the objective value
    def _get_objective(self, residual=None):
        if self.mpi_interface.mpi_size > 1:
            obj_value_list = np.zeros(len(self._entities), dtype=np.float64)
            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                    # additionally impose aggregator objective function with current residual schedule:
                    if isinstance(entity, CityDistrict) and residual is not None:
                        original_p_el_values = None
                        original_p_el_import_values = None
                        original_p_el_export_values = None
                        original_max_consumption_value = None
                        if hasattr(entity.model, "p_el_vars"):
                            original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                            actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                                  in range(len(residual))}
                            entity.model.p_el_vars.set_values(actual_p_el_values)
                        if hasattr(entity.model, "p_el_import_vars"):
                            original_p_el_import_values = {idx: var.value for idx, var in
                                                           entity.model.p_el_import_vars.items()}
                            actual_p_el_import_values = {j: original_p_el_import_values.get(j, 0.0) +
                                                            max(float(residual[j]), 0.0) for j in range(len(residual))}
                            entity.model.p_el_import_vars.set_values(actual_p_el_import_values)
                        if hasattr(entity.model, "p_el_export_vars"):
                            original_p_el_export_values = {idx: var.value for idx, var in
                                                           entity.model.p_el_export_vars.items()}
                            actual_p_el_export_values = {j: original_p_el_export_values.get(j, 0.0) +
                                                            min(float(residual[j]), 0.0) for j in range(len(residual))}
                            entity.model.p_el_export_vars.set_values(actual_p_el_export_values)
                        if hasattr(entity.model, "max_consumption_var"):
                            original_max_consumption_value = pyomo.value(entity.model.max_consumption_var)
                            original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                            actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                                  in range(len(residual))}
                            actual_max_consumption_value = max(abs(v) for v in actual_p_el_values.values())
                            entity.model.max_consumption_var.set_value(actual_max_consumption_value)
                        obj_value_list[i] += pyomo.value(entity.get_objective())
                        if hasattr(entity.model, "p_el_vars"):
                            entity.model.p_el_vars.set_values(original_p_el_values)
                        if hasattr(entity.model, "p_el_import_vars"):
                            entity.model.p_el_import_vars.set_values(original_p_el_import_values)
                        if hasattr(entity.model, "p_el_export_vars"):
                            entity.model.p_el_export_vars.set_values(original_p_el_export_values)
                        if hasattr(entity.model, "max_consumption_var"):
                            entity.model.max_consumption_var.set_value(original_max_consumption_value)
                    else:
                        obj_value_list[i] += pyomo.value(entity.get_objective())
            tmp = np.zeros(len(self._entities), dtype=np.float64)
            self.mpi_interface.get_comm().Allreduce(obj_value_list, tmp, self.mpi_interface.mpi.SUM)
            obj_value_list = tmp
            obj_value = np.sum(obj_value_list)
        else:
            obj_value = 0
            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                # additionally impose aggregator objective function with current residual schedule:
                if isinstance(entity, CityDistrict) and residual is not None:
                    original_p_el_values = None
                    original_p_el_import_values = None
                    original_p_el_export_values = None
                    original_max_consumption_value = None
                    if hasattr(entity.model, "p_el_vars"):
                        original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                        actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                              in range(len(residual))}
                        entity.model.p_el_vars.set_values(actual_p_el_values)
                    if hasattr(entity.model, "p_el_import_vars"):
                        original_p_el_import_values = {idx: var.value for idx, var in
                                                       entity.model.p_el_import_vars.items()}
                        actual_p_el_import_values = {j: original_p_el_import_values.get(j, 0.0) +
                                                        max(float(residual[j]), 0.0) for j in range(len(residual))}
                        entity.model.p_el_import_vars.set_values(actual_p_el_import_values)
                    if hasattr(entity.model, "p_el_export_vars"):
                        original_p_el_export_values = {idx: var.value for idx, var in
                                                       entity.model.p_el_export_vars.items()}
                        actual_p_el_export_values = {j: original_p_el_export_values.get(j, 0.0) +
                                                        min(float(residual[j]), 0.0) for j in range(len(residual))}
                        entity.model.p_el_export_vars.set_values(actual_p_el_export_values)
                    if hasattr(entity.model, "max_consumption_var"):
                        original_max_consumption_value = pyomo.value(entity.model.max_consumption_var)
                        original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                        actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                              in range(len(residual))}
                        actual_max_consumption_value = max(abs(v) for v in actual_p_el_values.values())
                        entity.model.max_consumption_var.set_value(actual_max_consumption_value)
                    obj_value += pyomo.value(entity.get_objective())
                    if hasattr(entity.model, "p_el_vars"):
                        entity.model.p_el_vars.set_values(original_p_el_values)
                    if hasattr(entity.model, "p_el_import_vars"):
                        entity.model.p_el_import_vars.set_values(original_p_el_import_values)
                    if hasattr(entity.model, "p_el_export_vars"):
                        entity.model.p_el_export_vars.set_values(original_p_el_export_values)
                    if hasattr(entity.model, "max_consumption_var"):
                        entity.model.max_consumption_var.set_value(original_max_consumption_value)
                else:
                    obj_value += pyomo.value(entity.get_objective())
        return obj_value

    def _add_objective(self, exchange_admm_obj_terms=True, miqp_admm_obj_terms=True):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                obj = node.model.beta * entity.get_objective()
                for t in range(entity.op_horizon):
                    obj += node.model.rho_ / 2 * entity.model.p_el_vars[t] * entity.model.p_el_vars[t]

                # In the following, add the additional expressions to solve the sub-problems by Exchange ADMM.
                if exchange_admm_obj_terms:
                    # penalty term is expanded and constant is omitted
                    if isinstance(entity, CityDistrict):
                        for t in range(self.op_horizon):
                            obj += node.model.rho_ * (node.model.x_[t] - node.model.u_exch[t]) \
                                   * entity.model.p_el_vars[t]
                    else:
                        for t in range(self.op_horizon):
                            obj += node.model.rho_ * (-node.model.x_[t] + node.model.u_exch[t]) \
                                   * entity.model.p_el_vars[t]

                # In the following, add the additional expressions to solve the sub-problems by MIQP ADMM.
                if miqp_admm_obj_terms:
                    # binary variables contribution
                    vars_dict = self.district_binaries[i]
                    for var_name, var_info in vars_dict.items():
                        var = var_info['var']
                        for t in range(len(var)):
                            obj += node.model.rho_ / 2 * (var[t] - node.model.x_k[var_name, t] +
                                                          node.model.gamma_ * node.model.u_int[var_name, t]) ** 2

                    if self.x_update_mode == "unconstrained":
                        # add the contributions of the constraints (time and none indexed)
                        for constr_name, constr_info in self.district_equalities_t[i].items():
                            for t in range(len(constr_info['constr'])):
                                obj += node.model.rho_ / 2 * (
                                        constr_info['constr'][t].body + node.model.u_eq_t[constr_name, t]) ** 2

                        for constr_name, constr_info in self.district_equalities_n[i].items():
                            obj += node.model.rho_ / 2 * (
                                        constr_info['constr'].body + node.model.u_eq_n[constr_name]) ** 2

                        for constr_name, constr_info in self.district_inequalities_t[i].items():
                            for t in range(len(constr_info['constr'])):
                                obj += node.model.rho_ / 2 * (
                                        constr_info['constr'][t].body + node.model.u_ineq_t[constr_name, t] -
                                        node.model.v_k_t[constr_name, t]) ** 2

                        for constr_name, constr_info in self.district_inequalities_n[i].items():
                            obj += node.model.rho_ / 2 * (
                                        constr_info['constr'].body + node.model.u_ineq_n[constr_name] -
                                        node.model.v_k_n[constr_name]) ** 2

                # if we want to redefine the objective for a certain node, then we should first reset the old objective
                try:
                    node.model.del_component(node.model.o)
                except AttributeError:
                    pass
                node.model.o = pyomo.Objective(expr=obj)
        return

    def _presolve(self, full_update, beta, robustness, debug):
        results, params = super()._presolve(full_update, beta, robustness, debug)

        if self.x_update_mode == "unconstrained":
            self.deactivate_constraints()

        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                node.constr_update()
                node.model.beta = self._get_beta(params, entity)
                if full_update:
                    node.full_update(robustness)
        results["r_norms"] = []
        results["s_norms"] = []
        results["lower_bounds"] = []
        results["upper_bounds"] = []
        results["mip_gaps"] = []
        results["violated_var"] = []
        results["violated_constr"] = []
        results["feasible"] = []
        results["gamma_value"] = []
        results["rho_value"] = []

        if self.measure_performance and self.mpi_interface.get_size() > 1:
            self.mpi_interface.enable_profiling()
            self.mpi_interface.reset_profiling()
        results["mpi_bytes_sent"] = []
        results["mpi_bytes_received"] = []
        return results, params

    def _postsolve(self, results, params, debug):
        if self.measure_performance and self.mpi_interface.get_size() > 1:
            self.mpi_interface.disable_profiling()

        if self.x_update_mode == "unconstrained":
            self.activate_constraints()

        if self.mpi_interface.get_size() > 1:
            # Update all models across all MPI instances:
            asset_updates = np.empty(len(self._entities), dtype=np.object_)
            payload_size = np.empty(len(self._entities), dtype=np.int32)
            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                    pyomo_var_values = dict()
                    node.constr_update()
                    for asset in entity.get_all_entities():
                        for v in asset.model.component_data_objects(ctype=pyomo.Var, descend_into=True):
                            pyomo_var_values[str(v)] = v.value
                    asset_updates[i] = pyomo_var_values
                    payload_size[i] = len(pickle.dumps(asset_updates[i], protocol=pickle.HIGHEST_PROTOCOL))

            if self.mpi_interface.get_rank() == 0:
                for i in range(1, len(self._entities)):
                    payload_size = self.mpi_interface.get_comm().recv(
                        source=self.mpi_process_range[i],
                        tag=(((int(results["iterations"][-1])+1) * len(self._entities) + i) %
                             self.mpi_interface.mpi_tag_ub)
                    )
                    req = self.mpi_interface.get_comm().irecv(
                        memoryview(bytearray(payload_size)),
                        source=self.mpi_process_range[i],
                        tag=(((int(results["iterations"][-1])+2) * len(self._entities) + i) %
                             self.mpi_interface.mpi_tag_ub)
                    )
                    asset_updates[i] = req.wait()
            else:
                for i in range(1, len(self._entities)):
                    if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                        self.mpi_interface.get_comm().send(
                            payload_size[i],
                            dest=0,
                            tag=(((int(results["iterations"][-1])+1) * len(self._entities) + i) %
                                 self.mpi_interface.mpi_tag_ub)
                        )
                        req = self.mpi_interface.get_comm().isend(
                            asset_updates[i],
                            dest=0,
                            tag=(((int(results["iterations"][-1])+2) * len(self._entities) + i) %
                                 self.mpi_interface.mpi_tag_ub)
                        )
                        req.wait()
                asset_updates = np.empty(len(self._entities), dtype=np.object_)
            asset_updates = self.mpi_interface.get_comm().bcast(asset_updates, root=0)

            for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                for asset in entity.get_all_entities():
                    pyomo_var_values_map = pyomo.ComponentMap()
                    for v in asset.model.component_data_objects(ctype=pyomo.Var, descend_into=True):
                        if str(v) in asset_updates[i]:
                            pyomo_var_values_map[v] = pyomo.value(asset_updates[i][str(v)])
                    for var in pyomo_var_values_map:
                        var.set_value(pyomo_var_values_map[var], skip_validation=True)
                    asset.update_schedule()

            total_cpu_cycles = results["cpu_cycles"]
            total_cpu_instructions = results["cpu_instructions"]
            total_cpu_cycles = self.mpi_interface.get_comm().allreduce(total_cpu_cycles,
                                                                       op=self.mpi_interface.mpi.SUM)
            total_cpu_instructions = self.mpi_interface.get_comm().allreduce(total_cpu_instructions,
                                                                             op=self.mpi_interface.mpi.SUM)
            results["cpu_cycles"] = total_cpu_cycles
            results["cpu_instructions"] = total_cpu_instructions
        return

    def _is_last_iteration(self, results, params, debug):
        if super(ExchangeMIQPADMMMPI, self)._is_last_iteration(results, params, debug):
            self._check_violations()
            return True
        if results["r_norms"][-1] <= self.eps_exch_primal and results["s_norms"][-1] <= self.eps_exch_dual:
            if self.feasible:
                self._check_violations()
                return True
            else:
                return False

    def _iteration(self, results, params, debug):
        super(ExchangeMIQPADMMMPI, self)._iteration(results, params, debug)
        op_horizon = self._entities[0].op_horizon

        # fill parameters if not already present
        if "p_el" not in params:
            params["p_el"] = np.zeros((len(self._entities), op_horizon))
        if "x_" not in params:
            params["x_"] = np.zeros(op_horizon)
        if "u_exch" not in params:
            params["u_exch"] = np.zeros(op_horizon)
        last_u_exch = params["u_exch"]
        last_p_el = params["p_el"]
        last_x_ = params["x_"]

        # --------------------------
        # 1) optimize all entities
        # --------------------------

        to_solve_nodes = []
        variables = []
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                for t in range(op_horizon):
                    node.model.last_p_el_schedules[t] = last_p_el[i][t]
                    node.model.x_[t] = last_x_[t]
                    node.model.u_exch[t] = last_u_exch[t]
                node.obj_update()
                to_solve_nodes.append(node)
                variables.append([entity.model.p_el_vars[t] for t in range(op_horizon)])
        self._solve_nodes(results, params, to_solve_nodes, variables=variables, debug=debug)

        # ------------------------------------------
        # 2) Calculate incentive signal update
        # ------------------------------------------

        p_el_schedules = np.empty((len(self._entities), self.op_horizon))
        if self.mpi_interface.get_rank() == 0:
            p_el_schedules[0] = np.stack(self.city_district.p_el_schedule, axis=0)
        for j in range(1, len(self._entities)):
            if self.mpi_interface.get_rank() == 0:
                if self.mpi_interface.get_size() > 1:
                    data = np.empty(self.op_horizon, dtype=np.float64)
                    req = self.mpi_interface.get_comm().Irecv(
                        data,
                        source=self.mpi_process_range[j],
                        tag=((int(results["iterations"][-1]) * len(self._entities) + j) %
                             self.mpi_interface.mpi_tag_ub)
                    )
                    req.wait()
                    p_el_schedules[j] = np.array(data, dtype=np.float64)
                else:
                    p_el_schedules[j] = np.stack(self._entities[j].p_el_schedule, axis=0)
            else:
                if self.mpi_interface.get_rank() == self.mpi_process_range[j]:
                    p_el_schedules[j] = np.stack(self._entities[j].p_el_schedule, axis=0)
                    if self.mpi_interface.get_size() > 1:
                        req = self.mpi_interface.get_comm().Isend(
                            p_el_schedules[j],
                            dest=0,
                            tag=((int(results["iterations"][-1]) * len(self._entities) + j) %
                                 self.mpi_interface.mpi_tag_ub)
                        )
                        req.wait()

        if self.mpi_interface.get_rank() == 0:
            x_ = (-p_el_schedules[0] + sum(p_el_schedules[1:])) / len(self._entities)
        else:
            x_ = np.empty(self.op_horizon, dtype=np.float64)
        if self.mpi_interface.get_size() > 1:
            self.mpi_interface.get_comm().Bcast(x_, root=0)

        # update all MIQP ADMM parameters (first the constraints then the variables)
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                vars_dict = self.district_binaries[i]

                for var_name, var_info in vars_dict.items():
                    var = var_info['var']
                    x_val = var_info['x_val']
                    x_k = var_info['x_k']
                    u_int_k = var_info['u_int_k']

                    for t in range(len(var)):
                        # integer rounding for x_k
                        x_k[t, results["iterations"][-1]] = np.round(var[t].value + node.model.u_int[var_name, t].value)

                        # update u_int_k
                        u_int_k[t, results["iterations"][-1]] = (node.model.u_int[var_name, t].value + var[t].value -
                                                             x_k[t, results["iterations"][-1]])

                        # update x_val
                        x_val[t, results["iterations"][-1]] = var[t].value

                        # set node model parameter for ADMM
                        node.model.x_k[var_name, t] = x_k[t, results["iterations"][-1]]
                        node.model.u_int[var_name, t] = u_int_k[t, results["iterations"][-1]]

                if self.x_update_mode == "unconstrained":
                    for constr_name, constr_info in self.district_equalities_t[i].items():
                        for t in range(len(constr_info['constr'])):
                            node.model.u_eq_t[constr_name, t] = node.model.u_eq_t[constr_name, t].value + \
                                                                pyomo.value(constr_info['constr'][t].body)

                    for constr_name, constr_info in self.district_equalities_n[i].items():
                        node.model.u_eq_n[constr_name] = node.model.u_eq_n[constr_name].value + \
                                                         pyomo.value(constr_info['constr'].body)

                    for constr_name, constr_info in self.district_inequalities_t[i].items():
                        for t in range(len(constr_info['constr'])):
                            v_update = pyomo.value(constr_info['constr'][t].body) + node.model.u_ineq_t[
                                constr_name, t].value
                            node.model.v_k_t[constr_name, t] = v_update
                            node.model.u_ineq_t[constr_name, t] = node.model.u_ineq_t[constr_name, t].value + \
                                                                  pyomo.value(constr_info['constr'][t].body) - \
                                                                  node.model.v_k_t[constr_name, t].value

                    for constr_name, constr_info in self.district_inequalities_n[i].items():
                        v_update = pyomo.value(constr_info['constr'].body) + node.model.u_ineq_n[constr_name].value
                        node.model.v_k_n[constr_name] = v_update
                        node.model.u_ineq_n[constr_name] = node.model.u_ineq_n[constr_name].value + \
                                                           pyomo.value(constr_info['constr'].body) - \
                                                           node.model.v_k_n[constr_name].value

        # apply rounded variable values to entities' optimization problems
        self.set_variable_values()

        # -------------------------------------------------------
        # 3) Calculate parameters for stopping criteria and metrics
        # -------------------------------------------------------

        if self.mpi_interface.get_rank() == 0:
            r = -p_el_schedules[0] + np.sum(p_el_schedules[1:], axis=0)
            r_norm = np.linalg.norm(r, ord=self.norm_order)

            dx = x_ - last_x_
            s_norm = self.rho * np.linalg.norm(dx, ord=self.norm_order)
        else:
            r = np.empty(self.op_horizon, dtype=np.float64)
            r_norm = np.empty(1, dtype=np.float64)
            s_norm = np.empty(1, dtype=np.float64)
        if self.mpi_interface.get_size() > 1:
            self.mpi_interface.get_comm().Bcast(r, root=0)
            self.mpi_interface.get_comm().Bcast(r_norm, root=0)
            self.mpi_interface.get_comm().Bcast(s_norm, root=0)

        results["r_norms"].append(r_norm)
        results["s_norms"].append(s_norm)

        current_obj = self._get_objective(residual=r)
        upper_bound = current_obj
        if self.lower_bound is None:
            # estimation for lower bound based on current r-norm and s-norm values
            lower_bound = current_obj - results["r_norms"][-1] - results["s_norms"][-1]
        else:
            # known numerical value for lower bound (e.g., taken from another algorithm)
            lower_bound = self.lower_bound
        mip_gap = np.abs(upper_bound - lower_bound) / max(1.0, np.abs(upper_bound))
        results["lower_bounds"].append(lower_bound)
        results["upper_bounds"].append(upper_bound)
        results["mip_gaps"].append(mip_gap * 100.0)

        results["obj_value"].append(current_obj)

        # Check for feasibility of the solution:
        violated_var, violated_constr = self._check_violations(print_out=False, detailed_print_out=False)
        self.feasible = ((violated_var + violated_constr) == 0)
        results["feasible"].append(self.feasible)
        results["violated_var"].append(violated_var)
        results["violated_constr"].append(violated_constr)

        if ((results["r_norms"][-1] <= self.eps_exch_primal) and (results["s_norms"][-1] <= self.eps_exch_dual)) or \
                (results["iterations"][-1] >= self.max_iterations):
            if results["iterations"][-1] >= self.max_iterations:
                if self.feasible:
                    print("Iteration " + str(results["iterations"][-1]) + ": " +
                          "Maximum iteration limit reached. The final solution is feasible!")
                else:
                    print("Iteration " + str(results["iterations"][-1]) + ": " +
                          "Maximum iteration limit reached. The final solution is not feasible!")
            else:
                if self.feasible:
                    print("Iteration " + str(results["iterations"][-1]) + ": " +
                          "Stopping criteria satisfied. The final solution is feasible!")
                else:
                    print("Iteration " + str(results["iterations"][-1]) + ": " +
                          "Stopping criteria satisfied. The final solution is not feasible!")

        if self.measure_performance and self.mpi_interface.get_size() > 1:
            self.mpi_interface.disable_profiling()
            bytes_sent = self.mpi_interface.get_bytes_sent()
            bytes_recv = self.mpi_interface.get_bytes_received()
            results["mpi_bytes_sent"].append(bytes_sent)
            results["mpi_bytes_received"].append(bytes_recv)
            self.mpi_interface.enable_profiling()
        else:
            results["mpi_bytes_sent"].append(0)
            results["mpi_bytes_received"].append(0)

        # ------------------------------------------
        # 4) Save required parameters for another iteration
        # ------------------------------------------

        # if desired, vary the penalty parameter
        if self.varying_penalty_parameter:
            if results["r_norms"][-1] > self.mu * results["s_norms"][-1]:
                self.rho *= float(self.tau_incr)
                for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                    if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                        node.model.rho_ = self.rho
            elif results["s_norms"][-1] > self.mu * results["r_norms"][-1]:
                self.rho /= float(self.tau_decr)
                for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
                    if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                        node.model.rho_ = self.rho
        results["rho_value"].append(self.rho)

        # vary the gamma parameter (maximum value is 10e9 to avoid numerical issues):
        if self.gamma_incr > 0.0 and len(results["gamma_value"]) >= 1:
            gamma = min(float(self.gamma_incr) * results["gamma_value"][-1], 10e9)
        else:
            gamma = self.gamma
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                node.model.gamma_ = gamma
        results["gamma_value"].append(gamma)

        params["p_el"] = p_el_schedules
        params["x_"] = x_
        params["u_exch"] += x_
        return


    def set_variable_values(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                vars_dict = self.district_binaries[i]
                for var_name, var_info in vars_dict.items():
                    var = var_info['var']
                    for t in range(len(var)):
                        var[t].set_value(node.model.x_k[var_name, t].value)
        return

    def fix_variables(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                vars_dict = self.district_binaries[i]
                for var_name, var_info in vars_dict.items():
                    var = var_info['var']
                    for t in range(len(var)):
                        var[t].fix(node.model.x_k[var_name, t].value)
        return

    def release_variables(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                vars_dict = self.district_binaries[i]
                for var_name, var_info in vars_dict.items():
                    var = var_info['var']
                    for t in range(len(var)):
                        var[t].unfix()
        return

    def activate_constraints(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                for constr in node.model.component_objects(pyomo.Constraint, descend_into=True):
                    constr.activate()
        return

    def deactivate_constraints(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                for constr in node.model.component_objects(pyomo.Constraint, descend_into=True):
                    constr.deactivate()
        return

    def print_model(self):
        for i, node, entity in zip(range(len(self._entities)), self.nodes, self._entities):
            if self.mpi_interface.get_rank() == self.mpi_process_range[i]:
                # binaries
                for var_name, var_info in self.district_binaries[i].items():
                    print(f"Binary variable {var_name}:")
                    var = var_info['var']
                    for t in range(len(var)):
                        var[t].pprint()

                # Constraints
                for constr_dict in [self.district_equalities_t[i], self.district_equalities_n[i],
                                    self.district_inequalities_t[i], self.district_inequalities_n[i]]:
                    for constr_name, constr_info in constr_dict.items():
                        if isinstance(constr_info['constr'], list):
                            for c in constr_info['constr']:
                                print(f"{constr_name}:")
                                c.pprint()
                        else:
                            print(f"{constr_name}:")
                            constr_info['constr'].pprint()
