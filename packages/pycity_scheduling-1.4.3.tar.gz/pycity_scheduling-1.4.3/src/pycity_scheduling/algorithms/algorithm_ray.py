"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import numpy as np
import ray
import copy
import time

import pyomo.environ as pyomo

from pyomo.solvers.plugins.solvers.persistent_solver import PersistentSolver
from pyomo.opt import SolverStatus, TerminationCondition

from pycity_scheduling.classes import CityDistrict, Building
from pycity_scheduling.util import extract_pyomo_values
from pycity_scheduling.util.perf import Perf_Measurement
from pycity_scheduling.exceptions import NonoptimalError


def list_into_n_chunks(lst, n):
    for i in range(0, n):
        yield lst[i::n]


def get_beta(params, entity):
    """Returns the beta value for a specific entity"""
    beta = params["beta"]
    if isinstance(beta, dict):
        return beta.get(entity.id, 1.0)
    if isinstance(entity, CityDistrict):
        return 1.0
    return beta


class RaySolverNode():
    """Base class for a Ray Node which can be used to solve all entities provided to it with in a ray cluster.

    Provides an abstraction layer for algorithms, so entities can be
    assigned to nodes and optimized easily.

    Parameters
    ----------
    solver : str
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        - `__call__` is the function being called when generating an instance
          with the pyomo SolverFactory. In addition to the options provided,
          `node_ids` is passed to this call containing the IDs of the entities
          being optimized.
        - `set_instance` is called when a pyomo Model is set as an instance of
          a persistent solver.
        - `solve` is called to perform an optimization. If not set,
          `save_results` and `load_solutions` may be set to false to provide a
          speedup.
    entities : list
        List of entities which should be optimized by this node.
    mode : str, optional
        Specifies which set of constraints to use.

        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for an algorithm. This is recommended for performance benchmarking
        purposes only and requires Linux perf as well as Linux kernel setting 'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, solver, solver_options, entities, node_index = 0, op_horizon=0, mode="convex",
                 measure_performance=False, robustness=None):
        self.solvers = np.empty(len(entities), dtype=object)
        for i, entity in enumerate(entities):
            self.solvers[i] = pyomo.SolverFactory(solver,  **solver_options.get("__call__", {}))
        self.solver_options = solver_options
        self.is_persistent = False
        if len(self.solvers) > 0:
            self.is_persistent = isinstance(self.solvers[0], PersistentSolver)
        self.robustness = robustness
        self.entities = []
        for entity in entities:
            self.entities.append(copy.deepcopy(entity))
        self.mode = mode
        self.model = np.empty(len(entities), dtype=object)
        self.node_index = node_index
        self.op_horizon = op_horizon

        self._reset()
        self._prepare()

        self.measure_performance = measure_performance
        if self.measure_performance:
            try:
                self.perf = Perf_Measurement()
            except Exception as e:
                print("CPU performance measurement not possible: your system setup may not support Linux perf!")
                print("Continuing without CPU performance measurements.\n")
                self.measure_performance = False

    def _reset(self):
        """Reset, i.e., 'unpopulate', the previous optimization model"""
        for entity in self.entities:
            if isinstance(entity, CityDistrict):
                city_district = entity
                city_district.model = None
                for bd in city_district.get_lower_entities():
                    bd.model = None
                    if isinstance(bd, Building) and bd.has_bes:
                        bd.bes.model = None
                        for e in bd.bes.get_lower_entities():
                            e.model = None
                    if isinstance(bd, Building) and len(bd.apartments) == 1:
                        bd.apartments[0].model = None
                        for e in bd.apartments[0].get_lower_entities():
                            e.model = None
                    elif isinstance(bd, Building) and len(bd.apartments) > 1:
                        for ap in bd.apartments:
                            ap.model = None
                            for e in ap.get_lower_entities():
                                e.model = None
        return

    def _prepare(self):
        """Create the pyomo model for the entities and populate it"""
        for i, entity in enumerate(self.entities):
            model = pyomo.ConcreteModel()
            self._prepare_model(entity, model, robustness=self.robustness)
            self.model[i] = model
        return

    def _prepare_model(self, entity, model, robustness=None):
        """Add a single entity to a model"""
        if isinstance(entity, Building):
            entity.populate_model(model, self.mode, robustness=robustness)
            entity.update_model(self.mode, robustness=robustness)
        else:
            entity.populate_model(model, self.mode)
            entity.update_model(self.mode)
        return

    def set_model_betas(self, params):
        """Sets the model betas for every entity on the remote node"""
        for i, entity in enumerate(self.entities): 
            beta = get_beta(params, entity)
            self.model[i].beta = beta

    def full_update(self, robustness=None):
        """Execute the update_model function and propagate other model changes.

        Parameters
        ----------
        robustness : tuple, optional
            Tuple of two floats. First entry defines how many time steps are
            protected from deviations. Second entry defines the magnitude of
            deviations which are considered.
        """
        for i, entity in enumerate(self.entities):
            if isinstance(entity, Building):
                entity.update_model(mode=self.mode, robustness=robustness)
            else:
                entity.update_model(mode=self.mode)
            if self.is_persistent:
                self.solvers[i].set_instance(self.model[i], **self.solver_options.get("set_instance", {}))
        return

    def constr_update(self):
        """Only propagate the constraints update of the model"""
        for i, entity in enumerate(self.entities):
            if self.is_persistent:
                self.solvers[i].set_instance(self.model[i], **self.solver_options.get("set_instance", {}))
            else:
                pass
        return

    def obj_update(self, index):
        """Only propagate the objective value update of the model"""
        if self.is_persistent:
            self.solvers[index].set_objective(self.model[index].o)
        else:
            pass
        return

    def presolve(self):
        return

    def postsolve(self):
        """Updates the schedules of each asset and entity on the node"""
        for entity in self.entities:
            entity.update_schedule()
        return

    def get_all_schedules(self):
        """Retrives all schedules of each entity and asset on the node"""
        local_schedules = dict()
        for entity in self.entities:
            # only update the child entities when the entity is not a city district
            if isinstance(entity, CityDistrict):
                if hasattr(entity, "id") and hasattr(entity, "schedules"):
                    local_schedules.update({entity.id: entity.schedules})
            else:  
                for asset in entity.get_all_entities(): 
                    if hasattr(asset, "id") and hasattr(asset, "schedules"):
                        local_schedules.update({asset.id: asset.schedules})
        return local_schedules    

    def get_objective(self, residual=None):
        obj_value = 0
        for i, entity in enumerate(self.entities):
            # additionally impose aggregator objective function with current residual schedule:
            if isinstance(entity, CityDistrict) and residual is not None:
                original_p_el_values = None
                original_p_el_import_values = None
                original_p_el_export_values = None
                original_max_consumption_value = None
                if hasattr(entity.model, "p_el_vars"):
                    original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                    actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                          in range(len(residual))}
                    entity.model.p_el_vars.set_values(actual_p_el_values)
                if hasattr(entity.model, "p_el_import_vars"):
                    original_p_el_import_values = {idx: var.value for idx, var in
                                                   entity.model.p_el_import_vars.items()}
                    actual_p_el_import_values = {j: original_p_el_import_values.get(j, 0.0) +
                                                    max(float(residual[j]), 0.0) for j in range(len(residual))}
                    entity.model.p_el_import_vars.set_values(actual_p_el_import_values)
                if hasattr(entity.model, "p_el_export_vars"):
                    original_p_el_export_values = {idx: var.value for idx, var in
                                                   entity.model.p_el_export_vars.items()}
                    actual_p_el_export_values = {j: original_p_el_export_values.get(j, 0.0) +
                                                    min(float(residual[j]), 0.0) for j in range(len(residual))}
                    entity.model.p_el_export_vars.set_values(actual_p_el_export_values)
                if hasattr(entity.model, "max_consumption_var"):
                    original_max_consumption_value = pyomo.value(entity.model.max_consumption_var)
                    original_p_el_values = {idx: var.value for idx, var in entity.model.p_el_vars.items()}
                    actual_p_el_values = {j: original_p_el_values.get(j, 0.0) + float(residual[j]) for j
                                          in range(len(residual))}
                    actual_max_consumption_value = max(abs(v) for v in actual_p_el_values.values())
                    entity.model.max_consumption_var.set_value(actual_max_consumption_value)
                obj_value += pyomo.value(entity.get_objective())
                if hasattr(entity.model, "p_el_vars"):
                    entity.model.p_el_vars.set_values(original_p_el_values)
                if hasattr(entity.model, "p_el_import_vars"):
                    entity.model.p_el_import_vars.set_values(original_p_el_import_values)
                if hasattr(entity.model, "p_el_export_vars"):
                    entity.model.p_el_export_vars.set_values(original_p_el_export_values)
                if hasattr(entity.model, "max_consumption_var"):
                    entity.model.max_consumption_var.set_value(original_max_consumption_value)
            else:
                obj_value += pyomo.value(entity.get_objective())
        return obj_value

    def exit(self):
        ray.actor.exit_actor()
        return


@ray.remote(scheduling_strategy="SPREAD", num_cpus=1, num_gpus=0)
class RayDualDecompositionSolverNode(RaySolverNode):
    """Ray Node which can be used to solve all entities provided to it with in a ray cluster using the Dual
    Decompositon method.

    Provides an abstraction layer for algorithms, so entities can be
    assigned to nodes and optimized easily.

    Parameters
    ----------
    solver : str
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        - `__call__` is the function being called when generating an instance
          with the pyomo SolverFactory. In addition to the options provided,
          `node_ids` is passed to this call containing the IDs of the entities
          being optimized.
        - `set_instance` is called when a pyomo Model is set as an instance of
          a persistent solver.
        - `solve` is called to perform an optimization. If not set,
          `save_results` and `load_solutions` may be set to false to provide a
          speedup.
    entities : list
        List of entities which should be optimized by this node.
    mode : str, optional
        Specifies which set of constraints to use.

        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the Dual Decomposition algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, solver, solver_options, entities, node_index=0, op_horizon=0, mode="convex",
                 measure_performance=False, robustness=None):
        super().__init__(solver, solver_options, entities, node_index, op_horizon, mode, measure_performance, robustness)
        self.calc_model_params()

    def calc_model_params(self):
        """ Create the model parameters locally on the actor"""
        for i, entity in enumerate(self.entities): 
            beta = pyomo.Param(mutable=True, initialize=1)
            lambdas = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            self.model[i].beta = beta
            self.model[i].lambdas = lambdas

    def _set_model_lambdas(self, lambdas, index):
        """Sets the model lambdas for every entity on the remote node"""
        for t in range(self.op_horizon):
            self.model[index].lambdas[t] = lambdas[t]

    def add_objective(self, global_entity_indices):
        """Adds the objective to all models of every entity on the remote node"""
        for i, entity in enumerate(self.entities):
            global_index = global_entity_indices[entity.id]
            obj = self.model[i].beta * entity.get_objective()
            if global_index == 0:
                # penalty term is expanded and constant is omitted
                # invert sign of p_el_schedule and p_el_vars (omitted for quadratic term)
                for t in range(self.op_horizon):
                    obj -= self.model[i].lambdas[t] * entity.model.p_el_vars[t]
            else:
                for t in range(self.op_horizon):
                   obj += self.model[i].lambdas[t] * entity.model.p_el_vars[t]
            self.model[i].o = pyomo.Objective(expr=obj)
        return

    def _solve_single(self, lambdas, index, debug=True):
        """Call the solver to solve this nodes optimization problem for a single entity"""
        self._set_model_lambdas(lambdas, index)
        self.obj_update(index)
        model = self.model[index]
        entity = self.entities[index]
        solver = self.solvers[index]

        cpu_cycles = np.uint64(0)
        cpu_instructions = np.uint64(0)

        solve_options = self.solver_options.get("solve", {})
        if self.measure_performance:
            if self.is_persistent:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, **solve_options)
            else:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, model, **solve_options)
        else:
            if self.is_persistent:
                result = solver.solve(**solve_options)
            else:
                result = solver.solve(model, **solve_options)
        if (not (result.solver.termination_condition == TerminationCondition.optimal or
                result.solver.termination_condition == TerminationCondition.maxTimeLimit or
                result.solver.termination_condition == TerminationCondition.maxIterations) or
                not (result.solver.status == SolverStatus.ok or
                     result.solver.status == SolverStatus.warning or
                     result.solver.status == SolverStatus.aborted)):
            if debug:
                import pycity_scheduling.util.debug as debug
                debug.analyze_model(model, solver, result)
            raise NonoptimalError("Could not retrieve schedule from model.")

        entity.update_schedule()

        return self.entities[index].model.p_el_vars, cpu_cycles, cpu_instructions

    def solve(self, lambdas_ref, debug=True):
        """Call the solver to solve this nodes optimization problem for every entity on the node"""
        p_el_var_list = []
        indices_list = []

        total_cpu_cycles = np.uint64(0)
        total_cpu_instructions = np.uint64(0)

        lambdas = ray.get(lambdas_ref[0])
        for i, entity in enumerate(self.entities): 
            p_el_vars, cpu_cycles, cpu_instructions = self._solve_single(lambdas, i, debug)
            total_cpu_cycles += cpu_cycles
            total_cpu_instructions += cpu_instructions
            p_el_var_list.append(p_el_vars)
            indices_list.append(entity.id)

        # return p_el_vars with other method or cast pyomo vars on the side of the node
        numpy_vars = np.array([extract_pyomo_values(var, float) for var in p_el_var_list])
        numpy_indices = np.array(indices_list)

        return [numpy_indices, numpy_vars, total_cpu_cycles, total_cpu_instructions]

    def postsolve(self):
        """Updates the schedules of each asset and entity on the node"""
        super().postsolve()


@ray.remote(scheduling_strategy="SPREAD", num_cpus=1, num_gpus=0)
class RayADMMSolverNode(RaySolverNode):
    """Ray Node which can be used to solve all entities provided to it with in a ray cluster using the Exchange
    ADMM method.

    Provides an abstraction layer for algorithms, so entities can be
    assigned to nodes and optimized easily.

    Parameters
    ----------
    solver : str
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        - `__call__` is the function being called when generating an instance
          with the pyomo SolverFactory. In addition to the options provided,
          `node_ids` is passed to this call containing the IDs of the entities
          being optimized.
        - `set_instance` is called when a pyomo Model is set as an instance of
          a persistent solver.
        - `solve` is called to perform an optimization. If not set,
          `save_results` and `load_solutions` may be set to false to provide a
          speedup.
    entities : list
        List of entities which should be optimized by this node.
    mode : str, optional
        Specifies which set of constraints to use.

        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the Exchange ADMM algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, solver, solver_options, entities, rho, node_index = 0, op_horizon=0, mode="convex",
                 measure_performance=False, robustness=None):
        super().__init__(solver, solver_options, entities, node_index, op_horizon, mode, measure_performance, robustness)
        self.rho = rho
        self.calc_model_params()
      
    def calc_model_params(self):
        """ Create the model parameters localy on the actor"""
        for i, entity in enumerate(self.entities): 
            beta = pyomo.Param(mutable=True, initialize=1)
            xs_ = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            us = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            last_p_el_schedules = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            rho_ = pyomo.Param(mutable=True, initialize=self.rho)
            self.model[i].rho_ = rho_
            self.model[i].beta = beta
            self.model[i].xs_ = xs_
            self.model[i].us = us
            self.model[i].last_p_el_schedules = last_p_el_schedules

    def _set_model_variables(self, last_p_els, last_x_, last_u, local_index, global_index):
        """Sets the model vars for entity on the remote node"""
        for t in range(self.op_horizon):
            self.model[local_index].last_p_el_schedules[t] = last_p_els[global_index][t]
            self.model[local_index].xs_[t] = last_x_[t]
            self.model[local_index].us[t] = last_u[t]

    def add_objective(self, global_entity_indices):
        """Adds the objective to all models of every entity on the remote node"""
        for i, entity in enumerate(self.entities):
            global_index = global_entity_indices[entity.id]
            obj = self.model[i].beta * entity.get_objective()
            for t in range(self.op_horizon):
                obj += self.model[i].rho_ / 2 * entity.model.p_el_vars[t] * entity.model.p_el_vars[t]
            # penalty term is expanded and constant is omitted
            if global_index == 0:
                for t in range(self.op_horizon):
                    obj += self.model[i].rho_ * (self.model[i].xs_[t] - self.model[i].us[t]) \
                           * entity.model.p_el_vars[t]
            else:
                for t in range(self.op_horizon):
                    obj += self.model[i].rho_ * (-self.model[i].xs_[t] + self.model[i].us[t]) \
                           * entity.model.p_el_vars[t]
            self.model[i].o = pyomo.Objective(expr=obj)
        return

    def _solve_single(self, last_p_els, last_x_, last_u, local_index, global_index, debug=True):
        """Call the solver to solve this nodes optimization problem for a single entity"""
        self._set_model_variables(last_p_els, last_x_, last_u, local_index, global_index)
        self.obj_update(local_index)

        model = self.model[local_index]
        entity = self.entities[local_index]
        solver = self.solvers[local_index]

        cpu_cycles = np.uint64(0)
        cpu_instructions = np.uint64(0)

        solve_options = self.solver_options.get("solve", {})
        if self.measure_performance:
            if self.is_persistent:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, **solve_options)
            else:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, model, **solve_options)
        else:
            if self.is_persistent:
                result = solver.solve(**solve_options)
            else:
                result = solver.solve(model, **solve_options)
        if (not (result.solver.termination_condition == TerminationCondition.optimal or
                result.solver.termination_condition == TerminationCondition.maxTimeLimit or
                result.solver.termination_condition == TerminationCondition.maxIterations) or
                not (result.solver.status == SolverStatus.ok or
                     result.solver.status == SolverStatus.warning or
                     result.solver.status == SolverStatus.aborted)):
            if debug:
                import pycity_scheduling.util.debug as debug
                debug.analyze_model(model, solver, result)
            raise NonoptimalError("Could not retrieve schedule from model.")

        entity.update_schedule()

        return self.entities[local_index].model.p_el_vars, cpu_cycles, cpu_instructions

    def solve(self, variable_refs, debug=True):
        """Call the solver to solve this nodes optimization problem for every entity on the node

        Parameters
        ----------
        variable_refs : list of lists of variables, optional
            Can contain a list for each node in nodes to indicate to pyomo which
            variables should be loaded back into the model. Specifying this can
            lead to a significant speedup.
        debug : bool, optional
            Specify whether detailed debug information shall be printed. Defaults
            to true.
        """
        p_el_var_list = []
        indices_list = []

        total_cpu_cycles = np.uint64(0)
        total_cpu_instructions = np.uint64(0)

        last_p_els = ray.get(variable_refs[0])
        last_x_ = ray.get(variable_refs[1])
        last_u_ = ray.get(variable_refs[2])
        global_entity_indices = ray.get(variable_refs[3])

        for i, entity in enumerate(self.entities): 
            global_index = global_entity_indices[entity.id]
            p_el_vars, cpu_cycles, cpu_instructions = self._solve_single(last_p_els, last_x_, last_u_, i, global_index,
                                                                         debug)
            total_cpu_cycles += cpu_cycles
            total_cpu_instructions += cpu_instructions
            p_el_var_list.append(p_el_vars)
            indices_list.append(entity.id)

        # return p_el_vars with other method or cast pyomo vars on the side of the node
        numpy_vars = np.array([extract_pyomo_values(var, float) for var in p_el_var_list])
        numpy_indices = np.array(indices_list)

        return [numpy_indices, numpy_vars, total_cpu_cycles, total_cpu_instructions]

    def postsolve(self):
        """Updates the schedules of each asset and entity on the node"""
        super().postsolve()

    def update_rho(self, new_rho):
        """Updates the rho parameter for all entities on the remote node"""
        self.rho = new_rho
        for i, entity in enumerate(self.entities):
            self.model[i].rho_ = new_rho
        return


@ray.remote(scheduling_strategy="SPREAD", num_cpus=1, num_gpus=0)
class RayADMMMIQPSolverNode(RaySolverNode):
    """Ray Node which can be used to solve all entities provided to it with in a ray cluster using the Exchange
    MIQP ADMM method.

    Provides an abstraction layer for algorithms, so entities can be
    assigned to nodes and optimized easily.

    Parameters
    ----------
    solver : str
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        - `__call__` is the function being called when generating an instance
          with the pyomo SolverFactory. In addition to the options provided,
          `node_ids` is passed to this call containing the IDs of the entities
          being optimized.
        - `set_instance` is called when a pyomo Model is set as an instance of
          a persistent solver.
        - `solve` is called to perform an optimization. If not set,
          `save_results` and `load_solutions` may be set to false to provide a
          speedup.
    entities : list
        List of entities which should be optimized by this node.
    mode : str, optional
        Specifies which set of constraints to use.

        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the Exchange MIQP ADMM algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """
    def __init__(self, solver, solver_options, entities, gamma, rho, node_index=0, max_iterations=1000, op_horizon=0,
                 mode="convex", measure_performance=False, x_update_mode="constrained", robustness=None):
        super().__init__(solver, solver_options, entities, node_index, op_horizon, mode, measure_performance,
                         robustness)
        self.gamma = gamma
        self.rho = rho
        self.max_iterations = max_iterations
        self.x_update_mode = x_update_mode
        self.calc_model_params()

        self.feasible = False
        self.node_binaries = self._get_binaries()

        self.node_equalities_t, self.node_equalities_n, \
             self.node_inequalities_t, self.node_inequalities_n = self._get_constraints()

    def calc_model_params(self):
        """ Create the model parameters locally on the actor """
        for i, entity in enumerate(self.entities): 
            beta = pyomo.Param(mutable=True, initialize=1)
            x_ = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            u_exch = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            last_p_el_schedules = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            gamma_ = pyomo.Param(mutable=True, initialize=self.gamma)
            rho_ = pyomo.Param(mutable=True, initialize=self.rho)
            self.model[i].gamma_ = gamma_
            self.model[i].rho_ = rho_
            self.model[i].beta = beta
            self.model[i].x_ = x_
            self.model[i].u_exch = u_exch
            self.model[i].last_p_el_schedules = last_p_el_schedules        

    def _get_binaries(self):
        local_binaries_dict = {}

        for i, entity in enumerate(self.entities):
            # skip CityDistrict object:
            if isinstance(entity, CityDistrict):
                local_binaries_dict[i] = {}
                continue

            var_dict = {}
            for en in entity.get_all_entities():
                for var in en.model.component_objects(pyomo.Var):
                    if var[0].domain is pyomo.Binary:
                        var.domain = pyomo.Reals
                        var.setlb(0)
                        var.setub(1)
                        for index in var:
                            var[index].fixed = False
                        var_dict[var.name] = {
                            'var': var,
                            'x_val': np.zeros((len(var), self.max_iterations + 1)),
                            'x_k': np.zeros((len(var), self.max_iterations + 1)),
                            'u_int_k': np.zeros((len(var), self.max_iterations + 1))
                        }
            local_binaries_dict[i] = var_dict

        return local_binaries_dict

    def _get_constraints(self):
        local_equalities_t = {}
        local_equalities_n = {}
        local_inequalities_t = {}
        local_inequalities_n = {}

        for i, entity in enumerate(self.entities):
            eq_t_dict = {}
            eq_n_dict = {}
            ineq_t_dict = {}
            ineq_n_dict = {}

            # skip CityDistrict object:
            if isinstance(entity, CityDistrict):
                local_equalities_t[i] = {}
                local_equalities_n[i] = {}
                local_inequalities_t[i] = {}
                local_inequalities_n[i] = {}
                continue

            for en in entity.get_all_entities():
                for constr in en.model.component_objects(pyomo.Constraint):
                    equality_flag = False
                    inequality_flag = False
                    none_index_flag = False

                    # check if a constraint is indexed
                    for index in constr:
                        if index is None:
                            none_index_flag = True

                        # check if the constraint is an equality constraint and write it in the form Ax-b=0
                        if pyomo.value(constr[index].lower) == pyomo.value(constr[index].upper):
                            expr = constr[index].body - constr[index].lower
                            constr[index].set_value(expr == 0)
                            equality_flag = True

                        # if the constraint is not an equality constraint it must be an inequality constraint;
                        # the next three checks are about to write that constraint in the form Cx-d >= 0
                        elif pyomo.value(constr[index].upper) is None:
                            expr = constr[index].body - constr[index].lower
                            constr[index].set_value(expr >= 0)
                            inequality_flag = True

                        elif pyomo.value(constr[index].lower) is None:
                            expr = -constr[index].body + constr[index].upper
                            constr[index].set_value(expr >= 0)
                            inequality_flag = True

                        else:
                            # edge case: lb and ub set; print a warning
                            expr = -constr[index].body + constr[index].upper
                            expr = constr[index].body - constr[index].lower
                            print("WARNING: Constraint has both lb and ub and is not deactivated!")
                            inequality_flag = True

                    # enter constraint into the right dictionary
                    if equality_flag:
                        if none_index_flag:
                            eq_n_dict[constr.name] = {'constr': constr, 'time_indexed': False}
                        else:
                            eq_t_dict[constr.name] = {'constr': constr, 'time_indexed': True}
                    if inequality_flag:
                        if none_index_flag:
                            ineq_n_dict[constr.name] = {'constr': constr, 'time_indexed': False}
                        else:
                            ineq_t_dict[constr.name] = {'constr': constr, 'time_indexed': True}

            local_equalities_t[i] = eq_t_dict
            local_equalities_n[i] = eq_n_dict
            local_inequalities_t[i] = ineq_t_dict
            local_inequalities_n[i] = ineq_n_dict

        return local_equalities_t, local_equalities_n, local_inequalities_t, local_inequalities_n

    def set_parameters(self):
        """Sets the model parameters for an entity on the remote node"""
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]
            self.model[i].time_set = pyomo.RangeSet(0, self.op_horizon - 1)

            if vars_dict:
                var_names = list(vars_dict.keys())
                self.model[i].bin_set = pyomo.Set(initialize=var_names)

                self.model[i].x_k = pyomo.Param(self.model[i].bin_set, self.model[i].time_set, mutable=True,
                                             initialize=0)
                self.model[i].u_int = pyomo.Param(self.model[i].bin_set, self.model[i].time_set, mutable=True,
                                              initialize=0)

            if self.x_update_mode == "unconstrained":
                # Create parameters for each constraint
                eq_t_dict = self.node_equalities_t[i]
                if eq_t_dict:
                    self.model[i].eq_t_set = pyomo.Set(initialize=list(eq_t_dict.keys()))
                    self.model[i].u_eq_t = pyomo.Param(self.model[i].eq_t_set, self.model[i].time_set,
                                                    mutable=True, initialize=0)

                eq_n_dict = self.node_equalities_n[i]
                if eq_n_dict:
                    self.model[i].eq_n_set = pyomo.Set(initialize=list(eq_n_dict.keys()))
                    self.model[i].u_eq_n = pyomo.Param(self.model[i].eq_n_set, mutable=True, initialize=0)

                ineq_t_dict = self.node_inequalities_t[i]
                if ineq_t_dict:
                    self.model[i].ineq_t_set = pyomo.Set(initialize=list(ineq_t_dict.keys()))
                    self.model[i].u_ineq_t = pyomo.Param(self.model[i].ineq_t_set, self.model[i].time_set,
                                                      mutable=True, initialize=0)
                    self.model[i].v_k_t = pyomo.Param(self.model[i].ineq_t_set, self.model[i].time_set,
                                                   mutable=True, initialize=0)

                ineq_n_dict = self.node_inequalities_n[i]
                if ineq_n_dict:
                    self.model[i].ineq_n_set = pyomo.Set(initialize=list(ineq_n_dict.keys()))
                    self.model[i].u_ineq_n = pyomo.Param(self.model[i].ineq_n_set, mutable=True, initialize=0)
                    self.model[i].v_k_n = pyomo.Param(self.model[i].ineq_n_set, mutable=True, initialize=0)
        return

    def _set_model_variables(self, last_p_els, last_x_, last_u, local_index, global_index):
        """Sets the model vars for an entity on the remote node"""
        for t in range(self.op_horizon):
            self.model[local_index].last_p_el_schedules[t] = last_p_els[global_index][t]
            self.model[local_index].x_[t] = last_x_[t]
            self.model[local_index].u_exch[t] = last_u[t]

    def add_objective(self, exchange_admm_obj_terms=True, miqp_admm_obj_terms=True):
        """Adds the objective function for an entity on the remote node"""
        for i, entity in enumerate(self.entities):
            obj = self.model[i].beta * entity.get_objective()
            for t in range(entity.op_horizon):
                obj += self.model[i].rho_ / 2 * entity.model.p_el_vars[t] * entity.model.p_el_vars[t]

            # In the following, add the additional expressions to solve the sub-problems by Exchange ADMM.
            if exchange_admm_obj_terms:
                # penalty term is expanded and constant is omitted
                if isinstance(entity, CityDistrict):
                    for t in range(self.op_horizon):
                        obj += (self.model[i].rho_ * (self.model[i].x_[t] - self.model[i].u_exch[t])
                                * entity.model.p_el_vars[t])
                else:
                    for t in range(self.op_horizon):
                        obj += (self.model[i].rho_ * (-self.model[i].x_[t] + self.model[i].u_exch[t])
                                * entity.model.p_el_vars[t])

            # In the following, add the additional expressions to solve the sub-problems by MIQP ADMM.
            if miqp_admm_obj_terms:
                # binary variables contribution
                vars_dict = self.node_binaries[i]
                for var_name, var_info in vars_dict.items():
                    var = var_info['var']
                    for t in range(len(var)):
                        obj += self.model[i].rho_ / 2 * (var[t] - self.model[i].x_k[var_name, t] +
                                                         self.model[i].gamma_ * self.model[i].u_int[var_name, t]) ** 2

                if self.x_update_mode == "unconstrained":
                    # add the contributions of the constraints (time and none indexed)
                    for constr_name, constr_info in self.node_equalities_t[i].items():
                        for t in range(len(constr_info['constr'])):
                            obj += self.model[i].rho_ / 2 * (
                                    constr_info['constr'][t].body + self.model[i].u_eq_t[constr_name, t]) ** 2

                    for constr_name, constr_info in self.node_equalities_n[i].items():
                        obj += (self.model[i].rho_ / 2 *
                                (constr_info['constr'].body + self.model[i].u_eq_n[constr_name]) ** 2)

                    for constr_name, constr_info in self.node_inequalities_t[i].items():
                        for t in range(len(constr_info['constr'])):
                            obj += self.model[i].rho_ / 2 * (
                                    constr_info['constr'][t].body + self.model[i].u_ineq_t[constr_name, t] -
                                    self.model[i].v_k_t[constr_name, t]) ** 2

                    for constr_name, constr_info in self.node_inequalities_n[i].items():
                        obj += (self.model[i].rho_ / 2 *
                                ( constr_info['constr'].body + self.model[i].u_ineq_n[constr_name] -
                                  self.model[i].v_k_n[constr_name]) ** 2)

            # if we want to redefine the objective for a certain node, then we should first reset the old objective
            try:
                self.model[i].del_component(self.model[i].o)
            except AttributeError:
                pass
            self.model[i].o = pyomo.Objective(expr=obj)
        return

    def _solve_single(self, last_p_els, last_x_, last_u, local_index, global_index, debug=True):
        """Call the solver to solve this nodes optimization problem for a single entity"""
        self._set_model_variables(last_p_els, last_x_, last_u, local_index, global_index)
        self.obj_update(local_index)

        model = self.model[local_index]
        entity = self.entities[local_index]
        solver = self.solvers[local_index]

        cpu_cycles = np.uint64(0)
        cpu_instructions = np.uint64(0)

        solve_options = self.solver_options.get("solve", {})
        if self.measure_performance:
            if self.is_persistent:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, **solve_options)
            else:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, model, **solve_options)
        else:
            if self.is_persistent:
                result = solver.solve(**solve_options)
            else:
                result = solver.solve(model, **solve_options)
        if (not (result.solver.termination_condition == TerminationCondition.optimal or
                result.solver.termination_condition == TerminationCondition.maxTimeLimit or
                result.solver.termination_condition == TerminationCondition.maxIterations) or
                not (result.solver.status == SolverStatus.ok or
                     result.solver.status == SolverStatus.warning or
                     result.solver.status == SolverStatus.aborted)):
            if debug:
                import pycity_scheduling.util.debug as debug
                debug.analyze_model(model, solver, result)
            raise NonoptimalError("Could not retrieve schedule from model.")

        entity.update_schedule()

        return self.entities[local_index].model.p_el_vars, cpu_cycles, cpu_instructions

    def solve(self, variable_refs, update_constr=False, debug=True):
        """Call the solver to solve this nodes optimization problem for every entity on the node"""
        p_el_var_list = []
        indices_list = []

        total_cpu_cycles = np.uint64(0)
        total_cpu_instructions = np.uint64(0)

        last_p_els = ray.get(variable_refs[0])
        last_x_ = ray.get(variable_refs[1])
        last_u_ = ray.get(variable_refs[2])
        global_entity_indices = ray.get(variable_refs[3])

        if update_constr:
            self.constr_update()

        is_feasible = True
        for i, entity in enumerate(self.entities): 
            global_index = global_entity_indices[entity.id]
            try:
                p_el_vars, cpu_cycles, cpu_instructions = self._solve_single(last_p_els, last_x_, last_u_, i,
                                                                             global_index, debug)
                total_cpu_cycles += cpu_cycles
                total_cpu_instructions += cpu_instructions
                p_el_var_list.append(p_el_vars)
                indices_list.append(entity.id)
            except:
                is_feasible = False
                total_cpu_cycles = 0
                total_cpu_instructions = 0

        # return p_el_vars with other method or cast pyomo vars on the side of the node
        numpy_vars = np.array([extract_pyomo_values(var, float) for var in p_el_var_list])
        numpy_indices = np.array(indices_list)

        return [numpy_indices, numpy_vars, is_feasible, total_cpu_cycles, total_cpu_instructions]

    def incentive_signal_update(self, iteration_num):
        """Update all MIQP ADMM parameters (first the constraints then the variables) for every entity on the node"""
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]

            for var_name, var_info in vars_dict.items():
                var = var_info['var']
                x_val = var_info['x_val']
                x_k = var_info['x_k']
                u_int_k = var_info['u_int_k']

                for t in range(len(var)):
                    # integer rounding for x_k
                    x_k[t, iteration_num] = np.round(var[t].value + self.model[i].u_int[var_name, t].value)

                    # update u_int_k
                    u_int_k[t, iteration_num] = (self.model[i].u_int[var_name, t].value + var[t].value -
                                             x_k[t, iteration_num])

                    # update x_val
                    x_val[t, iteration_num] = var[t].value

                    # set node model parameter for ADMM
                    self.model[i].x_k[var_name, t] = x_k[t, iteration_num]
                    self.model[i].u_int[var_name, t] = u_int_k[t, iteration_num]

            if self.x_update_mode == "unconstrained":
                for constr_name, constr_info in self.node_equalities_t[i].items():
                    for t in range(len(constr_info['constr'])):
                        self.model[i].u_eq_t[constr_name, t] = (self.model[i].u_eq_t[constr_name, t].value +
                                                                pyomo.value(constr_info['constr'][t].body))

                for constr_name, constr_info in self.node_equalities_n[i].items():
                    self.model[i].u_eq_n[constr_name] = (self.model[i].u_eq_n[constr_name].value +
                                                         pyomo.value(constr_info['constr'].body))

                for constr_name, constr_info in self.node_inequalities_t[i].items():
                    for t in range(len(constr_info['constr'])):
                        v_update = (pyomo.value(constr_info['constr'][t].body) +
                                    self.model[i].u_ineq_t[constr_name, t].value)
                        self.model[i].v_k_t[constr_name, t] = v_update
                        self.model[i].u_ineq_t[constr_name, t] = (self.model[i].u_ineq_t[constr_name, t].value +
                                                                  pyomo.value(constr_info['constr'][t].body) -
                                                                  self.model[i].v_k_t[constr_name, t].value)

                for constr_name, constr_info in self.node_inequalities_n[i].items():
                    v_update = pyomo.value(constr_info['constr'].body) + self.model[i].u_ineq_n[constr_name].value
                    self.model[i].v_k_n[constr_name] = v_update
                    self.model[i].u_ineq_n[constr_name] = (self.model[i].u_ineq_n[constr_name].value +
                                                           pyomo.value(constr_info['constr'].body) -
                                                           self.model[i].v_k_n[constr_name].value)
        return

    def set_variable_values(self):
        """Set custom variable values for all entities on the remote node"""
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]
            for var_name, var_info in vars_dict.items():
                var = var_info['var']
                for t in range(len(var)):
                    var[t].set_value(self.model[i].x_k[var_name, t].value)
        return

    def fix_variables(self):
        """Fix the binary variables for all entities on the remote node"""
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]
            for var_name, var_info in vars_dict.items():
                var = var_info['var']
                for t in range(len(var)):
                    var[t].fix(self.model[i].x_k[var_name, t].value)
        return

    def release_variables(self):
        """Release the binary variables for all entities on the remote node"""
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]
            for var_name, var_info in vars_dict.items():
                var = var_info['var']
                for t in range(len(var)):
                    var[t].unfix()
        return

    def presolve(self):
        """In this step, pre-processing can be done for the remote node"""
        super().presolve()
        self.constr_update()
        pass

    def postsolve(self):
        """In this step, post-processing can be done for the remote node"""
        super().postsolve()
        self.constr_update()
        pass

    def update_gamma(self, new_gamma):
        """Updates the gamma parameter for all entities on the remote node"""
        self.gamma = new_gamma
        for i, entity in enumerate(self.entities):
            self.model[i].gamma_ = new_gamma
        return

    def update_rho(self, new_rho):
        """Updates the rho parameter for all entities on the remote node"""
        self.rho = new_rho
        for i, entity in enumerate(self.entities):
            self.model[i].rho_ = new_rho
        return

    def activate_constraints(self):
        """Activates all constraints for all entities on the remote node"""
        for i, entity in enumerate(self.entities):
            for constr in self.model[i].component_objects(pyomo.Constraint, descend_into=True):
                constr.activate()
        return

    def deactivate_constraints(self):
        """Deactivates all constraints for all entities on the remote node"""
        for i, entity in enumerate(self.entities):
            for constr in self.model[i].component_objects(pyomo.Constraint, descend_into=True):
                constr.deactivate()
        return

    # Returns True, if no constraint or binary variable violations occur
    def check_violations(self, detailed_print_out=False):
        """Checks constraint and binary variable violations for all entities on the remote node"""
        violated_var_counter = 0
        violated_constr_counter = 0
        total_var_counter = 0
        total_constr_counter = 0
        for i, entity in enumerate(self.entities):
            vars_dict = self.node_binaries[i]

            # check binaries:
            for var_name, var_info in vars_dict.items():
                var = var_info['var']

                for t in range(len(var)):
                    total_var_counter += 1
                    val = var[t].value
                    if (-0.001 < val < 0.001) or (0.999 < val < 1.001):
                        continue
                    violated_var_counter += 1
                    if detailed_print_out:
                        var[t].pprint()

            # check equality constraints:
            for constr_name, constr_info in self.node_equalities_t[i].items():
                total_constr_counter += len(constr_info['constr'])
                for index in range(len(constr_info['constr'])):
                    c = constr_info['constr'][index]
                    if c.body is not None:
                        if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))
                        elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))

            for constr_name, constr_info in self.node_equalities_n[i].items():
                total_constr_counter += 1
                c = constr_info['constr']
                if hasattr(c, 'body'):
                    if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                        violated_constr_counter += 1
                        if detailed_print_out:
                            print(constr_name, pyomo.value(c.body))
                    elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                        violated_constr_counter += 1
                        if detailed_print_out:
                            print(constr_name, pyomo.value(c.body))

            # check inequality constraints:
            for constr_name, constr_info in self.node_inequalities_t[i].items():
                total_constr_counter += len(constr_info['constr'])
                for index in range(len(constr_info['constr'])):
                    c = constr_info['constr'][index]
                    if c.body is not None:
                        if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))
                        elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                            violated_constr_counter += 1
                            if detailed_print_out:
                                print(constr_name, pyomo.value(c.body))

            for constr_name, constr_info in self.node_inequalities_n[i].items():
                total_constr_counter += 1
                c = constr_info['constr']
                if hasattr(c, 'body'):
                    if c.lower is not None and pyomo.value(c.body) < pyomo.value(c.lower) - 1e-3:
                        violated_constr_counter += 1
                        if detailed_print_out:
                            print(constr_name, pyomo.value(c.body))
                    elif c.upper is not None and pyomo.value(c.body) > pyomo.value(c.upper) + 1e-3:
                        violated_constr_counter += 1
                        if detailed_print_out:
                            print(constr_name, pyomo.value(c.body))

        return violated_var_counter, violated_constr_counter, total_var_counter, total_constr_counter


@ray.remote(scheduling_strategy="SPREAD", num_cpus=1, num_gpus=0)
class RayDerivativeFreeALADINSolverNode(RaySolverNode):
    """Ray Node which can be used to solve all entities provided to it with in a ray cluster using the derivative-free
     ALADIN method.

    Provides an abstraction layer for algorithms, so entities can be
    assigned to nodes and optimized easily.

    Parameters
    ----------
    solver : str
        Solver to use for solving (sub)problems.
    solver_options : dict, optional
        Options to pass to calls to the solver. Keys are the name of
        the functions being called and are one of `__call__`, `set_instance_`,
        `solve`.
        - `__call__` is the function being called when generating an instance
          with the pyomo SolverFactory. In addition to the options provided,
          `node_ids` is passed to this call containing the IDs of the entities
          being optimized.
        - `set_instance` is called when a pyomo Model is set as an instance of
          a persistent solver.
        - `solve` is called to perform an optimization. If not set,
          `save_results` and `load_solutions` may be set to false to provide a
          speedup.
    entities : list
        List of entities which should be optimized by this node.
    mode : str, optional
        Specifies which set of constraints to use.

        - `convex`  : Use linear constraints
        - `integer`  : May use non-linear constraints
    measure_performance : bool, optional
        Measure CPU cycles and instructions for the ALADIN algorithm. This is recommended for performance
        benchmarking purposes only and requires Linux perf as well as Linux kernel setting
        'kernel.perf_event_paranoid=0'.
    robustness : tuple, optional
        Tuple of two floats. First entry defines how many time steps are
        protected from deviations. Second entry defines the magnitude of
        deviations which are considered.
    """

    def __init__(self, solver, solver_options, entities, rho, hessian_scaling, node_index=0, op_horizon=0, mode="convex",
                 measure_performance=False, robustness=None):
        super().__init__(solver, solver_options, entities, node_index, op_horizon, mode, measure_performance, robustness)
        self.rho = rho
        self.hessian_scaling = hessian_scaling
        self.calc_model_params()

    def calc_model_params(self):
        """Create the model parameters localy on the actor"""
        for i, entity in enumerate(self.entities):
            beta = pyomo.Param(mutable=True, initialize=1)
            rho = pyomo.Param(mutable=True, initialize=self.rho)
            lambda_k = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            x_k = pyomo.Param(entity.model.t, mutable=True, initialize=0)
            self.model[i].beta = beta
            self.model[i].rho = rho
            self.model[i].lambda_k = lambda_k
            self.model[i].x_k = x_k

    def _set_model_variables(self, lambda_k, x_k, local_index, global_index):
        """Sets the model vars for entity on the remote node"""
        for t in range(self.op_horizon):
            self.model[local_index].lambda_k[t] = lambda_k[t]
            self.model[local_index].x_k[t] = x_k[global_index, t]

    def add_objective(self):
        """Adds the objective to all models of every entity on the remote node"""
        for i, entity in enumerate(self.entities):
            obj = self.model[i].beta * entity.get_objective()
            # ToDo: Attention - Currently only defined for "price", "co2", "peak-shaving" and "least-squares"
            decision_vars = entity.get_decision_var()

            # lambda penalty term
            for t in range(self.op_horizon):
                obj += self.model[i].lambda_k[t] * decision_vars[t]

            # augmented penalty term
            # ToDo: Define custom scaling...
            scaling_i = self.hessian_scaling * np.eye(self.op_horizon)
            penalty = [decision_vars[t] - self.model[i].x_k[t] for t in range(self.op_horizon)]
            for j in range(self.op_horizon):
                for k in range(self.op_horizon):
                    if scaling_i[j][k] != 0.0:
                        obj += self.model[i].rho * (penalty[j] * scaling_i[j][k] * penalty[k])
            self.model[i].o = pyomo.Objective(expr=obj)
        return

    def _solve_single(self, lambda_k, x_k, local_index, global_index, debug=True):
        """Call the solver to solve this nodes optimization problem for a single entity"""
        self._set_model_variables(lambda_k, x_k, local_index, global_index)
        self.obj_update(local_index)

        model = self.model[local_index]
        entity = self.entities[local_index]
        solver = self.solvers[local_index]

        cpu_cycles = np.uint64(0)
        cpu_instructions = np.uint64(0)

        solve_options = self.solver_options.get("solve", {})
        if self.measure_performance:
            if self.is_persistent:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, **solve_options)
            else:
                result, cpu_cycles, cpu_instructions = self.perf.measure_perf(solver.solve, model, **solve_options)
        else:
            if self.is_persistent:
                result = solver.solve(**solve_options)
            else:
                result = solver.solve(model, **solve_options)
        if result.solver.termination_condition != TerminationCondition.optimal or \
                result.solver.status != SolverStatus.ok:
            if debug:
                import pycity_scheduling.util.debug as debug
                debug.analyze_model(model, solver, result)
            raise NonoptimalError("Could not retrieve schedule from model.")

        entity.update_schedule()

        return self.entities[local_index].model.p_el_vars, cpu_cycles, cpu_instructions

    def solve(self, variable_refs, debug=True):
        """Call the solver to solve this nodes optimization problem for every entity on the node

        Parameters
        ----------
        variable_refs : list of lists of variables, optional
            Can contain a list for each node in nodes to indicate to pyomo which
            variables should be loaded back into the model. Specifying this can
            lead to a significant speedup.
        debug : bool, optional
            Specify whether detailed debug information shall be printed. Defaults
            to true.
        """
        p_el_var_list = []
        indices_list = []
        sub_times_list = []

        total_cpu_cycles = np.uint64(0)
        total_cpu_instructions = np.uint64(0)

        lambda_k = ray.get(variable_refs[0])
        x_k = ray.get(variable_refs[1])
        global_entity_indices = ray.get(variable_refs[2])

        for i, entity in enumerate(self.entities):
            global_index = global_entity_indices[entity.id]
            t_0 = time.monotonic()
            p_el_vars, cpu_cycles, cpu_instructions = self._solve_single(lambda_k, x_k, i, global_index, debug)
            t_1 = time.monotonic()
            total_cpu_cycles += cpu_cycles
            total_cpu_instructions += cpu_instructions
            sub_times_list.append(t_1 - t_0)
            p_el_var_list.append(p_el_vars)
            indices_list.append(entity.id)

        # return p_el_vars with other method or cast pyomo vars on the side of the node
        numpy_vars = np.array([extract_pyomo_values(var, float) for var in p_el_var_list])
        numpy_indices = np.array(indices_list)
        numpy_times = np.array(sub_times_list)

        return [numpy_indices, numpy_vars, numpy_times, total_cpu_cycles, total_cpu_instructions]

    def postsolve(self):
        """Updates the schedules of each asset and entity on the node"""
        super().postsolve()
