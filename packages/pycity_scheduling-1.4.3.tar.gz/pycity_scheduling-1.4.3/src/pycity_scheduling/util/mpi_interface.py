"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import os
import sys
import pickle
import numpy as np


class MPIInterface:
    """
    Supporting class that handles interactions with the Message Passing Interface (MPI) using module mpi4py.
    MPI is used to perform parallel computations on loosely coupled machines.
    """

    def __init__(self):
        self.mpi = None
        self.mpi_comm = None
        self.mpi_rank = 0
        self.mpi_size = 1
        self.mpi_tag_ub = 99999999

        self._byte_counter = MPIByteCounter()

        try:
            from mpi4py import MPI
            self.mpi = MPI
            self.mpi_comm = ByteCountingComm(MPI.COMM_WORLD, self._byte_counter)
            self.mpi_rank = self.mpi_comm.Get_rank()
            self.mpi_size = self.mpi_comm.Get_size()
            self.mpi_tag_ub = MPI.COMM_WORLD.Get_attr(MPI.TAG_UB)
        except:
            pass

    def get_rank(self):
        """
        Return the rank of the current MPI process.
        """
        return self.mpi_rank

    def get_size(self):
        """
        Return the size, i.e., number, of MPI processes.
        """
        return self.mpi_size

    def get_comm(self):
        """
        Return the MPI COMM interface.
        """
        return self.mpi_comm

    # ---- profiling control ----

    def enable_profiling(self):
        """
        Enable MPI profiling.
        """
        self._byte_counter.enabled = True

    def disable_profiling(self):
        """
        Disable MPI profiling.
        """
        self._byte_counter.enabled = False

    def reset_profiling(self):
        """
        Reset MPI profiling and counters.
        """
        self._byte_counter.reset()

    def get_bytes_sent(self):
        """
        Get MPI profiling (bytes sent).
        """
        return self._byte_counter.bytes_sent

    def get_bytes_received(self):
        """
        Get MPI profiling (bytes received).
        """
        return self._byte_counter.bytes_recv

    def get_mpi_process_range(self, n):
        """
        Determine which MPI processes are responsible for which elements in an array.

        Parameters
        ----------
        n : int
            Size of the array.

        Returns
        ----------
        mpi_process_range : np.array
            Array, in which the number inside an entry corresponds to the responsible MPI rank.
        """
        if self.get_size() > n:
            mpi_process_range = np.array([i for i in range(n)])
        elif self.get_size() < n:
            if self.get_size() == 1:
                mpi_process_range = np.array([0 for i in range(n)])
            else:
                a, b = divmod(n - 1, self.get_size() - 1)
                mpi_process_range = np.repeat(np.array([i for i in range(1, self.get_size())]), a)
                for i in range(b):
                    mpi_process_range = np.append(mpi_process_range, i + 1)
                mpi_process_range = np.concatenate([[0], mpi_process_range])
        else:
            mpi_process_range = np.array([i for i in range(n)])
        mpi_process_range = np.sort(mpi_process_range)
        return mpi_process_range

    def disable_multiple_printing(self, stdout=True, stderr=True):
        """
        Turn off printing for all MPI processes with MPI rank other than 0 and always flush prints for rank 0.

        Parameters
        ----------
        stdout : bool
            Turn off printing for stdout.
        stderr : bool
            Turn off printing for stderr.
        """
        sys.stdout = UnbufferedPrint(sys.stdout)
        sys.stderr = UnbufferedPrint(sys.stderr)
        if self.mpi is not None and self.mpi_size > 1:
            if self.mpi_rank > 0:
                if stdout:
                    sys.stdout = open(os.devnull, 'w')
                if stderr:
                    sys.stderr = open(os.devnull, 'w')


# MPI printing control:
class UnbufferedPrint(object):
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()

    def writelines(self, data):
        self.stream.writelines(data)
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)


# MPI profiling control:
class MPIByteCounter:
    def __init__(self):
        self.enabled = False
        self.bytes_sent = 0
        self.bytes_recv = 0

    def reset(self):
        self.bytes_sent = 0
        self.bytes_recv = 0


# MPI profiling wrappers:
class ByteCountingComm:
    def __init__(self, comm, counter: MPIByteCounter):
        self._comm = comm
        self._counter = counter

    def _nbytes(self, obj):
        # for numpy objects
        if isinstance(obj, (np.ndarray, memoryview)):
            return obj.nbytes
        # fallback for generic Python objects
        else:
            return len(pickle.dumps(obj))

    # ---------- point-to-point ----------
    def Send(self, buf, dest, tag=0):
        if self._counter.enabled:
            self._counter.bytes_sent += self._nbytes(buf)
        return self._comm.Send(buf, dest=dest, tag=tag)

    def send(self, buf, dest, tag=0):
        if self._counter.enabled:
            self._counter.bytes_sent += self._nbytes(buf)
        return self._comm.send(buf, dest=dest, tag=tag)

    def Recv(self, buf, source=0, tag=0):
        result = self._comm.Recv(buf, source=source, tag=tag)
        if self._counter.enabled:
            self._counter.bytes_recv += self._nbytes(buf)
        return result

    def recv(self, buf=None, source=0, tag=0):
        result = self._comm.recv(buf, source=source, tag=tag)
        if self._counter.enabled:
            self._counter.bytes_recv += self._nbytes(result)
        return result

    def Isend(self, buf, dest, tag=0):
        if self._counter.enabled:
            self._counter.bytes_sent += self._nbytes(buf)
        return self._comm.Isend(buf, dest=dest, tag=tag)

    def isend(self, buf, dest, tag=0):
        return self._comm.isend(buf, dest=dest, tag=tag)
        # For proper byte counting: call manually function count_bytes_after_wait() after wait

    def Irecv(self, buf, source=0, tag=0):
        req = self._comm.Irecv(buf, source=source, tag=tag)
        if self._counter.enabled:
            self._counter.bytes_recv += self._nbytes(buf)
        return req

    def irecv(self, buf=None, source=0, tag=0):
        return self._comm.irecv(buf, source=source, tag=tag)
        # For proper byte counting: call manually function count_bytes_after_wait() after wait

    # ---------------- collectives ----------------
    def Bcast(self, buf, root=0):
        if self._counter.enabled:
            n = self._nbytes(buf)
            if self._comm.rank == root:
                self._counter.bytes_sent += n * (self._comm.size - 1)
            else:
                self._counter.bytes_recv += n
        return self._comm.Bcast(buf, root=root)

    def bcast(self, buf, root=0):
        if self._counter.enabled:
            n = self._nbytes(buf)
            if self._comm.rank == root:
                self._counter.bytes_sent += n * (self._comm.size - 1)
            else:
                self._counter.bytes_recv += n
        return self._comm.bcast(buf, root=root)

    def Allreduce(self, sendbuf, recvbuf, op=None):
        if self._counter.enabled:
            n = self._nbytes(sendbuf)
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        if op is None:
            return self._comm.Allreduce(sendbuf, recvbuf)
        else:
            return self._comm.Allreduce(sendbuf, recvbuf, op=op)

    def allreduce(self, sendbuf, op=None):
        if self._counter.enabled:
            n = self._nbytes(sendbuf)
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        if op is None:
            return self._comm.allreduce(sendbuf)
        else:
            return self._comm.allreduce(sendbuf, op=op)

    def Allgather(self, sendbuf, recvbuf):
        if self._counter.enabled:
            n = self._nbytes(sendbuf) * self._comm.size
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        return self._comm.Allgather(sendbuf, recvbuf)

    def allgather(self, sendbuf):
        if self._counter.enabled:
            n = self._nbytes(sendbuf) * self._comm.size
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        return self._comm.allgather(sendbuf)

    def Alltoall(self, sendbuf, recvbuf):
        if self._counter.enabled:
            n = self._nbytes(sendbuf)
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        return self._comm.Alltoall(sendbuf, recvbuf)

    def alltoall(self, sendbuf):
        if self._counter.enabled:
            n = self._nbytes(sendbuf)
            self._counter.bytes_sent += n
            self._counter.bytes_recv += n
        return self._comm.alltoall(sendbuf)

    # ---------- fallback ----------
    def __getattr__(self, name):
        return getattr(self._comm, name)

    def count_bytes_after_wait(self, req, sendbuf=None):
        """
        Call this for lowercase non-blocking send/recv to update the byte counter after wait().

        Parameters
        ----------
        req : MPI request
            The request returned by isend() or irecv()
        sendbuf : object, optional
            Only for isend: the object being sent. For irecv, leave as None.

        Returns
        -------
        result : object
            For irecv, the received object. For isend, returns None.
        """
        result = req.wait()
        if self._counter.enabled:
            if sendbuf is not None:
                # Non-blocking send
                self._counter.bytes_sent += self._nbytes(sendbuf)
            else:
                # Non-blocking receive
                self._counter.bytes_recv += self._nbytes(result)
        return result