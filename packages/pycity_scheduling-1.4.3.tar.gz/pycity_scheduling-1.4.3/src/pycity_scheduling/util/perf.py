"""
The pycity_scheduling framework


Copyright (C) 2026,
Institute for Automation of Complex Power Systems (ACS),
E.ON Energy Research Center (E.ON ERC),
RWTH Aachen University

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import ctypes
import os
import re
import struct
import platform
import numpy as np


class Perf_Measurement(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_uint),
        ("size", ctypes.c_uint),
        ("config", ctypes.c_ulonglong),
        ("sample_period", ctypes.c_ulonglong),
        ("sample_type", ctypes.c_ulonglong),
        ("read_format", ctypes.c_ulonglong),
        ("flags", ctypes.c_ulonglong),
        ("wakeup_events", ctypes.c_uint),
        ("bp_type", ctypes.c_uint),
        ("bp_addr", ctypes.c_ulonglong),
        ("bp_len", ctypes.c_ulonglong),
        ("branch_sample_type", ctypes.c_ulonglong),
        ("sample_regs_user", ctypes.c_ulonglong),
        ("sample_stack_user", ctypes.c_uint),
        ("clockid", ctypes.c_int),
        ("sample_regs_intr", ctypes.c_ulonglong),
        ("aux_watermark", ctypes.c_uint),
        ("sample_max_stack", ctypes.c_ushort),
        ("__reserved_2", ctypes.c_ushort),
    ]

    def __init__(self):
        self.libc = ctypes.CDLL("libc.so.6", use_errno=True)
        self.performance_measurement_failed = False

    def get_sys_perf_event_open_locate(self):
        syscalls = {
            "x86_64": 298,  # 64-bit Intel/AMD
            "i386": 336,  # 32-bit Intel/AMD
            "i686": 336,  # 32-bit Intel/AMD
            "aarch64": 241,  # ARM 64-bit
            "armv7l": 364,  # ARM 32-bit
            "armv8l": 241,  # ARMv8 64-bit variant
            "ppc64le": 319,  # PowerPC 64-bit LE
            "ppc64": 319,  # PowerPC 64-bit BE
            "ppc": 319,  # PowerPC 32-bit
            "mips": 422,  # MIPS 32-bit
            "mips64": 422,  # MIPS 64-bit
        }

        arch = platform.machine()
        syscall_number = syscalls.get(arch, None)

        if syscall_number is None:
            raise RuntimeError("Could not resolve __NR_perf_event_open")
        else:
            return syscall_number

    def perf_event_open(self, attr, pid, cpu, group_fd, flags):
        SYS_perf_event_open = self.get_sys_perf_event_open_locate()
        return self.libc.syscall(SYS_perf_event_open, ctypes.byref(attr), pid, cpu, group_fd, flags)

    def parse_perf_event_ioctls(self, header_path="/usr/include/linux/perf_event.h"):
        """Parse PERF_EVENT_IOC_* values from perf_event.h at runtime."""
        if not os.path.exists(header_path):
            raise FileNotFoundError(f"{header_path} not found")

        ioctls = {}
        with open(header_path) as f:
            for line in f:
                m = re.match(r"#define\s+(PERF_EVENT_IOC_\w+)\s+_IO\s*\(\s*'(.?)'\s*,\s*(\d+)\s*\)", line)
                if m:
                    name, c, nr = m.groups()
                    type_val = ord(c)  # ASCII value of '$' ? 0x24
                    nr = int(nr)
                    val = (type_val << 8) | nr  # _IO(type, nr) encoding
                    ioctls[name] = val
        return ioctls

    def measure_perf(self, func, *args, **kwargs):
        """Measure CPU cycles and instructions in-process."""
        fd_cycles = -1
        fd_instr = -1

        res = 0
        cycles = 0
        instructions = 0

        try:
            # Constants for Linux perf_event
            PERF_TYPE_HARDWARE = 0
            PERF_COUNT_HW_CPU_CYCLES = 0
            PERF_COUNT_HW_INSTRUCTIONS = 1
            PERF_FLAG_FD_CLOEXEC = 8

            ioctls = self.parse_perf_event_ioctls()
            PERF_EVENT_IOC_ENABLE = ioctls["PERF_EVENT_IOC_ENABLE"]
            PERF_EVENT_IOC_DISABLE = ioctls["PERF_EVENT_IOC_DISABLE"]
            PERF_EVENT_IOC_RESET = ioctls["PERF_EVENT_IOC_RESET"]

            cycles_attr = Perf_Measurement()
            cycles_attr.type = PERF_TYPE_HARDWARE
            cycles_attr.size = ctypes.sizeof(Perf_Measurement)
            cycles_attr.config = PERF_COUNT_HW_CPU_CYCLES

            instr_attr = Perf_Measurement()
            instr_attr.type = PERF_TYPE_HARDWARE
            instr_attr.size = ctypes.sizeof(Perf_Measurement)
            instr_attr.config = PERF_COUNT_HW_INSTRUCTIONS

            fd_cycles = self.perf_event_open(
                cycles_attr, 0, -1, -1, PERF_FLAG_FD_CLOEXEC
            )
            fd_instr = self.perf_event_open(
                instr_attr, 0, -1, -1, PERF_FLAG_FD_CLOEXEC
            )

            if fd_cycles < 0 or fd_instr < 0:
                err = ctypes.get_errno()
                raise OSError(err, os.strerror(err))

            # reset and enable
            self.libc.ioctl(fd_cycles, PERF_EVENT_IOC_RESET, 0)
            self.libc.ioctl(fd_instr, PERF_EVENT_IOC_RESET, 0)
            self.libc.ioctl(fd_cycles, PERF_EVENT_IOC_ENABLE, 0)
            self.libc.ioctl(fd_instr, PERF_EVENT_IOC_ENABLE, 0)

            # run the measured function
            res = func(*args, **kwargs)

            # disable
            self.libc.ioctl(fd_cycles, PERF_EVENT_IOC_DISABLE, 0)
            self.libc.ioctl(fd_instr, PERF_EVENT_IOC_DISABLE, 0)

            # read raw bytes and unpack
            cycles_raw = os.read(fd_cycles, 8)
            instr_raw = os.read(fd_instr, 8)

            cycles = np.uint64(struct.unpack("Q", cycles_raw)[0])
            instructions = np.uint64(struct.unpack("Q", instr_raw)[0])

        except Exception as e:
            if not self.performance_measurement_failed:
                print("CPU Performance measurement failed:", e)
                print("Continuing without CPU performance measurements.\n")
                self.performance_measurement_failed = True

            res = func(*args, **kwargs)
            cycles = np.uint64(0)
            instructions = np.uint64(0)

        finally:
            # prevent FD leak
            if fd_cycles >= 0:
                try:
                    os.close(fd_cycles)
                except OSError:
                    pass

            if fd_instr >= 0:
                try:
                    os.close(fd_instr)
                except OSError:
                    pass

        return res, cycles, instructions
