"""Integration test for run_benchmark module."""

from pathlib import Path

import click
import pandas as pd
import pytest

from vivarium.profiling.tools.run_benchmark import RESULTS_SUMMARY_NAME, run_benchmark_loop

RESULTS_SUMMARY_COLUMNS = [
    "model_spec",
    "run",
    "rt_s",
    "mem_mb",
    "gather_results_cumtime",
    "gather_results_percall",
    "gather_results_ncalls",
    "pipeline_call_cumtime",
    "pipeline_call_percall",
    "pipeline_call_ncalls",
    "population_get_cumtime",
    "population_get_percall",
    "population_get_ncalls",
    "rt_setup_s",
    "rt_initialize_simulants_s",
    "rt_run_s",
    "rt_finalize_s",
    "rt_report_s",
]


@pytest.mark.slow
def test_run_benchmark_loop_integration(test_model_specs: list[Path], tmp_path: Path):
    """Integration test for run_benchmark_loop with minimal real model specs.

    This test verifies that:
    1. The benchmark runs successfully with minimal model configurations
    2. Results are generated for each simulation run
    3. The summary CSV contains the expected number of rows and columns
    4. Each model spec and run combination has a corresponding row in the results
    """
    # Use a temporary directory for output
    output_dir = str(tmp_path / "benchmark_output")
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Test parameters
    model_runs = 2
    baseline_runs = 3  # Just to be different

    # Run the benchmark
    results_dir = run_benchmark_loop(
        model_specifications=test_model_specs,
        model_runs=model_runs,
        baseline_model_runs=baseline_runs,
        output_dir=output_dir,
        verbose=0,  # Minimal logging for tests
    )

    assert Path(results_dir).exists()
    assert results_dir.startswith(output_dir)

    results_file = Path(results_dir) / RESULTS_SUMMARY_NAME
    assert results_file.exists()

    results_df = pd.read_csv(results_file)

    assert (
        list(results_df.columns) == RESULTS_SUMMARY_COLUMNS
    ), "CSV should have expected columns"

    expected_rows = baseline_runs + model_runs
    assert len(results_df) == expected_rows

    # Verify each model spec appears in results with correct number of runs
    baseline_rows = results_df[results_df["model_spec"].str.contains("baseline")]
    other_rows = results_df[results_df["model_spec"].str.contains("other")]

    assert len(baseline_rows) == baseline_runs, f"Expected {baseline_runs} baseline rows"
    assert len(other_rows) == model_runs, f"Expected {model_runs} non-baseline rows"

    # Verify run numbering is correct
    for _, group in results_df.groupby("model_spec"):
        run_numbers = sorted(group["run"].tolist())
        expected_runs = list(range(1, len(group) + 1))
        assert (
            run_numbers == expected_runs
        ), f"Run numbers should be sequential starting from 1"

    assert results_df["rt_s"].notna().all(), "All runs should have runtime recorded"

    assert "mem_mb" in results_df.columns, "Memory column should exist"

    expected_spec_dirs = ["model_spec_baseline", "model_spec_other"]

    for spec_dir in expected_spec_dirs:
        spec_path = Path(results_dir) / spec_dir
        assert spec_path.exists(), f"Model spec directory {spec_path} should exist"

        spec_contents = list(spec_path.iterdir())
        assert (
            len(spec_contents) > 0
        ), f"Model spec directory {spec_path} should contain results"
