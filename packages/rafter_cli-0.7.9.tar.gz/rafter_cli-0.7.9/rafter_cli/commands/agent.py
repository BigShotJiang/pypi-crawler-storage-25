"""Agent security commands: init, scan, audit, exec, config, install-hook, verify, audit-skill."""
from __future__ import annotations

import hashlib
import importlib.resources
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time

import yaml
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer
from rich import print as rprint

from .. import __version__
from ..core.audit_logger import AuditLogger
from ..core.command_interceptor import CommandInterceptor
from ..core.config_manager import ConfigManager
from ..core.pattern_engine import PatternEngine
from ..scanners.gitleaks import GitleaksScanner
from ..scanners.regex_scanner import RegexScanner, ScanResult
from ..scanners.secret_patterns import DEFAULT_SECRET_PATTERNS
from ..utils.formatter import fmt, is_agent_mode, print_stderr
from ..utils.skill_manager import SkillManager
from ..utils.binary_manager import BinaryManager

agent_app = typer.Typer(name="agent", help="Agent security features", no_args_is_help=True)

# ── config sub-app ───────────────────────────────────────────────────
config_app = typer.Typer(name="config", help="Manage agent configuration", no_args_is_help=True)


@config_app.command("show")
def config_show():
    """Show current configuration."""
    from dataclasses import asdict

    manager = ConfigManager()
    print(json.dumps(asdict(manager.load()), indent=2))


@config_app.command("get")
def config_get(key: str = typer.Argument(..., help="Config key (e.g. agent.risk_level)")):
    """Get a configuration value."""
    manager = ConfigManager()
    value = manager.get(key)
    if value is None:
        print(f"Key not found: {key}", file=sys.stderr)
        raise typer.Exit(code=1)
    if isinstance(value, dict):
        print(json.dumps(value, indent=2))
    else:
        print(value)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g. agent.risk_level)"),
    value: str = typer.Argument(..., help="Value to set"),
):
    """Set a configuration value."""
    manager = ConfigManager()
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, ValueError):
        parsed = value
    manager.set(key, parsed)
    rprint(fmt.success(f"Set {key} = {json.dumps(parsed)}"))


agent_app.add_typer(config_app)

# ── init helpers ─────────────────────────────────────────────────────


def _resolve_rafter_path() -> str:
    """Find the absolute path to the rafter binary for reliable hook invocation.

    Claude Code hooks run in a minimal shell environment that may not include
    the user's PATH additions (e.g. ~/.local/bin, ~/go/bin). Using the full
    path ensures hooks work regardless of the shell environment.
    """
    import shutil

    rafter_bin = shutil.which("rafter")
    if rafter_bin:
        return str(Path(rafter_bin).resolve())

    # Common installation locations as fallback
    home = Path.home()
    candidates = [
        home / ".local" / "bin" / "rafter",
        home / "go" / "bin" / "rafter",
        Path("/usr/local/bin/rafter"),
        Path("/opt/homebrew/bin/rafter"),
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return str(candidate)

    # Last resort: bare command name (may fail in restricted PATH environments)
    return "rafter"


# Skills installed by `rafter agent init` for Claude Code / Codex.
# Keep this list in sync with Node's AGENT_SKILLS and the SKILL.md files
# actually shipped under rafter_cli/resources/skills/.
_AGENT_SKILLS: list[dict[str, str]] = [
    {"name": "rafter", "description": "Rafter Remote"},
    {"name": "rafter-secure-design", "description": "Rafter Secure Design"},
    {"name": "rafter-code-review", "description": "Rafter Code Review"},
]


def _install_claude_code_hooks(root: Path) -> None:
    """Install Rafter PreToolUse hooks into <root>/.claude/settings.json."""
    claude_dir = root / ".claude"
    settings_path = claude_dir / "settings.json"

    claude_dir.mkdir(parents=True, exist_ok=True)

    # Read existing settings or start fresh
    settings: dict[str, Any] = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing settings.json was unreadable, creating new one"))

    # Merge hooks — don't overwrite existing non-Rafter hooks
    if "hooks" not in settings:
        settings["hooks"] = {}
    if "PreToolUse" not in settings["hooks"]:
        settings["hooks"]["PreToolUse"] = []

    rafter_bin = _resolve_rafter_path()
    pre_command = f"{rafter_bin} hook pretool"
    post_command = f"{rafter_bin} hook posttool"

    # Also match old bare "rafter" commands for dedup cleanup
    _old_pre = "rafter hook pretool"
    _old_post = "rafter hook posttool"

    if "PostToolUse" not in settings["hooks"]:
        settings["hooks"]["PostToolUse"] = []

    # Remove any existing Rafter hooks (old or new format) to avoid duplicates
    settings["hooks"]["PreToolUse"] = [
        entry for entry in settings["hooks"]["PreToolUse"]
        if not any(
            h.get("command", "") in (pre_command, _old_pre)
            or "rafter hook pretool" in h.get("command", "")
            for h in (entry.get("hooks") or [])
        )
    ]
    settings["hooks"]["PostToolUse"] = [
        entry for entry in settings["hooks"]["PostToolUse"]
        if not any(
            h.get("command", "") in (post_command, _old_post)
            or "rafter hook posttool" in h.get("command", "")
            for h in (entry.get("hooks") or [])
        )
    ]
    # Strip legacy SessionStart entry from <=0.7.4 installs.
    if isinstance(settings["hooks"].get("SessionStart"), list):
        settings["hooks"]["SessionStart"] = [
            entry for entry in settings["hooks"]["SessionStart"]
            if not any(
                "rafter hook session-start" in h.get("command", "")
                for h in (entry.get("hooks") or [])
            )
        ]
        if not settings["hooks"]["SessionStart"]:
            del settings["hooks"]["SessionStart"]

    # Add Rafter hooks
    pre_hook = {"type": "command", "command": pre_command}
    post_hook = {"type": "command", "command": post_command}
    settings["hooks"]["PreToolUse"].extend([
        {"matcher": "Bash", "hooks": [pre_hook]},
        {"matcher": "Write|Edit", "hooks": [pre_hook]},
    ])
    settings["hooks"]["PostToolUse"].extend([
        {"matcher": ".*", "hooks": [post_hook]},
    ])

    settings_path.write_text(json.dumps(settings, indent=2) + "\n")
    rprint(fmt.success(f"Installed PreToolUse hooks to {settings_path}"))
    rprint(fmt.success(f"Installed PostToolUse hooks to {settings_path}"))
    if rafter_bin != "rafter":
        rprint(fmt.info(f"Using resolved path: {rafter_bin}"))


# ── init ─────────────────────────────────────────────────────────────


def _copy_skill_tree(skill_name: str, dest_dir: Path, label: str) -> None:
    """Copy the full skill source tree (SKILL.md + any docs/ etc.) into dest_dir.

    Skills can ship a ``docs/`` subfolder of reference material referenced by
    SKILL.md. Copying only SKILL.md would silently strip those resources.
    """
    res = importlib.resources.files("rafter_cli.resources").joinpath("skills", skill_name)
    skill_md = res.joinpath("SKILL.md")
    if not skill_md.is_file():
        rprint(fmt.warning(f"{label} skill template not found in package resources"))
        return

    dest_dir.mkdir(parents=True, exist_ok=True)

    def _walk(node, target: Path) -> None:
        for child in node.iterdir():
            child_target = target / child.name
            if child.is_dir():
                # Skip Python package metadata that has no value at the install site.
                if child.name in {"__pycache__"}:
                    continue
                child_target.mkdir(parents=True, exist_ok=True)
                _walk(child, child_target)
            elif child.is_file():
                if child.name == "__init__.py":
                    continue
                child_target.write_bytes(child.read_bytes())

    _walk(res, dest_dir)
    rprint(fmt.success(f"Installed {label} skill to {dest_dir}"))


def _install_skills_to(skills_dir: Path) -> None:
    """Install all _AGENT_SKILLS into <skills_dir>, including any docs/ trees."""
    skills_dir.mkdir(parents=True, exist_ok=True)
    for skill in _AGENT_SKILLS:
        _copy_skill_tree(skill["name"], skills_dir / skill["name"], skill["description"])


def _install_claude_code_skills(root: Path) -> None:
    """Copy all four Rafter skills into <root>/.claude/skills/."""
    _install_skills_to(root / ".claude" / "skills")


# Sub-agents shipped by `rafter agent init --with-claude-code`. These land in
# <root>/.claude/agents/<name>.md and become first-class delegation targets
# (Agent(subagent_type='<name>')) in the calling Claude Code session — distinct
# from skills, which only surface in the activation prompt. Source files live
# in `rafter_cli/resources/agents/<name>.md`. Keep in sync with the Node installer.
_CLAUDE_CODE_SUBAGENTS: list[dict[str, str]] = [
    {"name": "rafter", "description": "Rafter Security"},
]


def _install_claude_code_subagents(root: Path) -> None:
    """Copy sub-agent definitions into <root>/.claude/agents/<name>.md."""
    agents_dir = root / ".claude" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    res = importlib.resources.files("rafter_cli.resources")
    for sub in _CLAUDE_CODE_SUBAGENTS:
        dest_path = agents_dir / f"{sub['name']}.md"
        try:
            content = res.joinpath("agents", f"{sub['name']}.md").read_text(encoding="utf-8")
            dest_path.write_text(content, encoding="utf-8")
            rprint(fmt.success(f"Installed {sub['description']} sub-agent to {dest_path}"))
        except Exception:
            rprint(fmt.warning(f"{sub['description']} sub-agent template not found in package resources"))


def _install_global_instructions(
    claude_code: bool,
    codex: bool,
    gemini: bool,
    cursor: bool,
    root: Path,
    scope: str,
    windsurf: bool = False,
) -> None:
    """Install Rafter instruction files for platforms that support them.

    Path layout:
        Claude Code — user: ~/.claude/CLAUDE.md     project: <cwd>/.claude/CLAUDE.md
        Codex CLI   — user: ~/.codex/AGENTS.md      project: <cwd>/AGENTS.md
        Gemini CLI  — user: ~/.gemini/GEMINI.md     project: <cwd>/GEMINI.md
        Cursor      — user: ~/.cursor/rules/*.mdc   project: <cwd>/.cursor/rules/*.mdc
        Windsurf    — <cwd>/AGENTS.md (read natively, workspace scope)

    AGENTS.md is the cross-platform instruction file: Codex (project scope) and
    Windsurf (any scope) both read it. When either is enabled we write it once
    at the project root; only Codex at user scope gets its own ~/.codex/AGENTS.md.
    """
    if claude_code:
        try:
            file_path = root / ".claude" / "CLAUDE.md"
            _inject_instruction_file(file_path)
            rprint(fmt.success(f"Installed Rafter instructions to {file_path}"))
        except Exception as e:
            rprint(fmt.warning(f"Failed to write Claude Code instructions: {e}"))

    if codex or windsurf:
        try:
            codex_user = scope == "user" and codex and not windsurf
            file_path = (
                root / ".codex" / "AGENTS.md" if codex_user else root / "AGENTS.md"
            )
            _inject_instruction_file(file_path)
            readers = " + ".join(
                name for name, on in [("Codex", codex), ("Windsurf", windsurf)] if on
            )
            rprint(fmt.success(f"Installed Rafter instructions for {readers} to {file_path}"))
        except Exception as e:
            rprint(fmt.warning(f"Failed to write AGENTS.md: {e}"))

    if gemini:
        try:
            file_path = root / ".gemini" / "GEMINI.md" if scope == "user" else root / "GEMINI.md"
            _inject_instruction_file(file_path)
            rprint(fmt.success(f"Installed Rafter instructions to {file_path}"))
        except Exception as e:
            rprint(fmt.warning(f"Failed to write Gemini instructions: {e}"))

    # Cursor uses per-skill rules at <root>/.cursor/rules/<skill>.mdc plus
    # the rafter sub-agent at <root>/.cursor/agents/rafter.md. Both are
    # installed in the Cursor branch of init() — see _install_cursor_rules
    # and _install_cursor_subagents (rf-svn3). The legacy consolidated
    # rafter-security.mdc was retired.
    _ = cursor  # parameter kept for call-site compatibility


def _install_openclaw_skill() -> tuple[bool, str, str, str]:
    """Install Rafter Security skill to OpenClaw. Returns (ok, source, dest, error).

    rf-zgwj: writes to the canonical ClawHub workspace location
    (~/.openclaw/workspace/skills/rafter-security/SKILL.md) so OpenClaw
    auto-discovers it at session start. Earlier versions wrote to
    ~/.openclaw/skills/rafter-security.md — that file is removed on
    reinstall as a migration step.
    """
    home = Path.home()
    openclaw_root = home / ".openclaw"
    skill_dir = openclaw_root / "workspace" / "skills" / "rafter-security"
    dest_path = skill_dir / "SKILL.md"
    legacy_path = openclaw_root / "skills" / "rafter-security.md"

    try:
        ref = importlib.resources.files("rafter_cli.resources").joinpath("rafter-security-skill.md")
        source_path = str(ref)
    except Exception:
        source_path = "(bundled resource)"

    if not openclaw_root.exists():
        return False, source_path, str(dest_path), f"OpenClaw not found: {openclaw_root}"

    skill_dir.mkdir(parents=True, exist_ok=True)

    try:
        content = importlib.resources.files("rafter_cli.resources").joinpath("rafter-security-skill.md").read_text(encoding="utf-8")
    except Exception as e:
        return False, source_path, str(dest_path), f"Source skill file not found: {e}"

    try:
        dest_path.write_text(content, encoding="utf-8")
    except Exception as e:
        return False, source_path, str(dest_path), str(e)

    # Migration: strip the rafter ≤ 0.7.7 install path (rf-zgwj). OpenClaw
    # never read that path; remove it on reinstall.
    if legacy_path.exists():
        try:
            legacy_path.unlink()
            rprint(fmt.success(f"Removed legacy {legacy_path} (superseded by ClawHub-shaped skill at {dest_path})"))
            # Drop the empty parent if we just emptied it.
            legacy_parent = legacy_path.parent
            try:
                if not any(legacy_parent.iterdir()):
                    legacy_parent.rmdir()
            except OSError:
                pass
        except OSError:
            pass

    return True, source_path, str(dest_path), ""


def _install_codex_skills(root: Path) -> tuple[bool, str]:
    """Install all Rafter skills to <root>/.agents/skills/ for Codex CLI."""
    try:
        _install_skills_to(root / ".agents" / "skills")
        return True, ""
    except Exception as e:
        return False, str(e)


def _install_gemini_skills(root: Path) -> tuple[bool, str]:
    """Install all Rafter skills to <root>/.agents/skills/ for Gemini CLI.

    Gemini shares the same skills dir as Codex — overwrite is harmless.
    """
    try:
        _install_skills_to(root / ".agents" / "skills")
        return True, ""
    except Exception as e:
        return False, str(e)


def _register_gemini_skills(skills_dir: Path) -> None:
    """Register installed skills with Gemini CLI via `gemini skills link <abs>`.

    Requires gemini CLI >= 0.35. Missing CLI / subcommand / per-skill failures
    are non-fatal: warn and continue so the on-disk install still succeeds.
    """
    gemini = shutil.which("gemini")
    if not gemini:
        rprint(fmt.warning(
            "gemini CLI not found on PATH — skipping skill registration. "
            "Skills are installed to disk; re-run after installing gemini ≥ 0.35."
        ))
        return

    # Probe `gemini skills` subcommand (added in 0.35).
    try:
        subprocess.run(
            [gemini, "skills", "--help"],
            check=True,
            capture_output=True,
            timeout=5,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
        rprint(fmt.warning(
            "gemini CLI does not support `skills` subcommand (needs ≥ 0.35). "
            "Skipping registration — skills are still installed to disk."
        ))
        return

    for skill in _AGENT_SKILLS:
        abs_path = (skills_dir / skill["name"]).resolve()
        if not abs_path.exists():
            continue
        try:
            subprocess.run(
                [gemini, "skills", "link", str(abs_path)],
                check=True,
                capture_output=True,
                timeout=10,
            )
            rprint(fmt.success(f"Registered {skill['name']} with Gemini CLI"))
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as e:
            first_line = ""
            stderr = getattr(e, "stderr", None)
            if stderr:
                try:
                    first_line = stderr.decode("utf-8", errors="replace").strip().split("\n", 1)[0]
                except Exception:
                    first_line = ""
            rprint(fmt.warning(
                f"Failed to register {skill['name']} with Gemini CLI: {first_line or 'unknown error'}"
            ))


# ── MCP server entry (shared across MCP-native clients) ──────────────

_RAFTER_MCP_ENTRY = {
    "command": "rafter",
    "args": ["mcp", "serve"],
}


def _install_claude_code_mcp(root: Path) -> bool:
    """Install MCP server config for Claude Code (<root>/.mcp.json).

    Project-scope MCP config that Claude Code auto-loads on startup.
    """
    mcp_path = root / ".mcp.json"

    config: dict[str, Any] = {}
    if mcp_path.exists():
        try:
            config = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing .mcp.json was unreadable, creating new one"))

    if "mcpServers" not in config:
        config["mcpServers"] = {}
    config["mcpServers"]["rafter"] = {**_RAFTER_MCP_ENTRY}

    mcp_path.write_text(json.dumps(config, indent=2) + "\n")
    rprint(fmt.success(f"Installed Rafter MCP server to {mcp_path}"))
    return True


def _install_gemini_mcp(root: Path) -> bool:
    """Install MCP server config for Gemini CLI (<root>/.gemini/settings.json)."""
    gemini_dir = root / ".gemini"
    settings_path = gemini_dir / "settings.json"

    gemini_dir.mkdir(parents=True, exist_ok=True)

    settings: dict[str, Any] = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing Gemini settings.json was unreadable, creating new one"))

    if "mcpServers" not in settings:
        settings["mcpServers"] = {}
    settings["mcpServers"]["rafter"] = {**_RAFTER_MCP_ENTRY}

    settings_path.write_text(json.dumps(settings, indent=2) + "\n")
    rprint(fmt.success(f"Installed Rafter MCP server to {settings_path}"))
    return True


# Cursor hook events covered by rafter (rf-svn3).
_CURSOR_HOOK_EVENTS: tuple[tuple[str, str], ...] = (
    ("preToolUse", "rafter hook pretool --format cursor"),
    ("postToolUse", "rafter hook posttool --format cursor"),
    ("beforeShellExecution", "rafter hook pretool --format cursor"),
)

# Skills shipped as both Cursor rules and Claude Code / Codex / Gemini skills.
_CURSOR_RULE_SKILLS: tuple[str, ...] = (
    "rafter",
    "rafter-secure-design",
    "rafter-code-review",
    "rafter-skill-review",
)


def _install_cursor_hooks(root: Path) -> None:
    """Install Cursor hooks at <root>/.cursor/hooks.json.

    Covers preToolUse + postToolUse + beforeShellExecution. Idempotent —
    repeated installs do not duplicate rafter entries. Non-rafter hook
    entries are preserved.
    """
    cursor_dir = root / ".cursor"
    cursor_dir.mkdir(parents=True, exist_ok=True)
    hooks_path = cursor_dir / "hooks.json"

    config: dict[str, Any] = {}
    if hooks_path.exists():
        try:
            config = json.loads(hooks_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing Cursor hooks.json was unreadable, creating new one"))

    config.setdefault("version", 1)
    config.setdefault("hooks", {})

    for event, command in _CURSOR_HOOK_EVENTS:
        entries = config["hooks"].get(event)
        if not isinstance(entries, list):
            entries = []
        entries = [
            e for e in entries
            if "rafter hook" not in (e or {}).get("command", "")
        ]
        entries.append({"command": command, "type": "command", "timeout": 5000})
        config["hooks"][event] = entries

    hooks_path.write_text(json.dumps(config, indent=2) + "\n")
    rprint(fmt.success(f"Installed hooks to {hooks_path}"))


def _install_cursor_rules(root: Path) -> None:
    """Install per-skill Cursor rule files at <root>/.cursor/rules/<skill>.mdc.

    Replaces the legacy consolidated `.cursor/rules/rafter-security.mdc`.
    Each rule is a static template shipped under
    `rafter_cli/resources/cursor-rules/`.
    """
    rules_dir = root / ".cursor" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    res = importlib.resources.files("rafter_cli.resources")
    for name in _CURSOR_RULE_SKILLS:
        try:
            content = res.joinpath("cursor-rules", f"{name}.mdc").read_text(encoding="utf-8")
        except Exception:
            rprint(fmt.warning(f"Cursor rule template missing: {name}.mdc"))
            continue
        dest = rules_dir / f"{name}.mdc"
        dest.write_text(content, encoding="utf-8")
        rprint(fmt.success(f"Installed Cursor rule to {dest}"))

    # Migrate away from the legacy consolidated rule on reinstall.
    legacy = rules_dir / "rafter-security.mdc"
    if legacy.exists():
        try:
            legacy.unlink()
            rprint(fmt.info(f"Removed legacy {legacy} (superseded by per-skill rules)"))
        except OSError:
            pass


def _install_cursor_subagents(root: Path) -> None:
    """Install the Cursor sub-agent at <root>/.cursor/agents/rafter.md.

    Reuses the rf-q7j Claude-Code sub-agent body, with Cursor-shape
    frontmatter (no `tools:` field — tools inherit from parent agent).
    """
    agents_dir = root / ".cursor" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)

    res = importlib.resources.files("rafter_cli.resources")
    try:
        raw = res.joinpath("agents", "rafter.md").read_text(encoding="utf-8")
    except Exception:
        rprint(fmt.warning("Rafter sub-agent template not found in resources/agents/"))
        return

    cursored = _strip_frontmatter_field(raw, "tools")
    dest = agents_dir / "rafter.md"
    dest.write_text(cursored, encoding="utf-8")
    rprint(fmt.success(f"Installed Cursor sub-agent to {dest}"))


def _strip_frontmatter_field(content: str, field: str) -> str:
    """Strip a single-line frontmatter field from a markdown file's frontmatter."""
    if not content.startswith("---\n"):
        return content
    fm_end = content.find("\n---", 4)
    if fm_end == -1:
        return content
    frontmatter = content[4:fm_end]
    body = content[fm_end:]
    pattern = re.compile(rf"^{re.escape(field)}:\s.*$\n?", re.MULTILINE)
    cleaned = pattern.sub("", frontmatter)
    return f"---\n{cleaned}{body}"


def _install_cursor_mcp(root: Path) -> bool:
    """Install MCP server config for Cursor (<root>/.cursor/mcp.json)."""
    cursor_dir = root / ".cursor"
    mcp_path = cursor_dir / "mcp.json"

    cursor_dir.mkdir(parents=True, exist_ok=True)

    config: dict[str, Any] = {}
    if mcp_path.exists():
        try:
            config = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing Cursor mcp.json was unreadable, creating new one"))

    if "mcpServers" not in config:
        config["mcpServers"] = {}
    config["mcpServers"]["rafter"] = {**_RAFTER_MCP_ENTRY}

    mcp_path.write_text(json.dumps(config, indent=2) + "\n")
    rprint(fmt.success(f"Installed Rafter MCP server to {mcp_path}"))
    return True


def _install_windsurf_mcp(root: Path) -> bool:
    """Install MCP server config for Windsurf (<root>/.codeium/windsurf/mcp_config.json)."""
    windsurf_dir = root / ".codeium" / "windsurf"
    mcp_path = windsurf_dir / "mcp_config.json"

    windsurf_dir.mkdir(parents=True, exist_ok=True)

    config: dict[str, Any] = {}
    if mcp_path.exists():
        try:
            config = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing Windsurf mcp_config.json was unreadable, creating new one"))

    if "mcpServers" not in config:
        config["mcpServers"] = {}
    config["mcpServers"]["rafter"] = {**_RAFTER_MCP_ENTRY}

    mcp_path.write_text(json.dumps(config, indent=2) + "\n")
    rprint(fmt.success(f"Installed Rafter MCP server to {mcp_path}"))
    return True


# Skills shipped as Windsurf rules at .windsurf/rules/<skill>.md (rf-0vr3).
_WINDSURF_RULE_SKILLS: tuple[str, ...] = (
    "rafter",
    "rafter-secure-design",
    "rafter-code-review",
    "rafter-skill-review",
)


def _install_windsurf_rules(root: Path) -> None:
    """Install per-skill Windsurf rules at <root>/.windsurf/rules/<skill>.md.

    Workspace-scope rules consumed by Windsurf's rules system (.windsurf/rules/*.md,
    12KB cap per file per docs). Each rule uses Windsurf's YAML frontmatter
    (`trigger: model_decision` + `description:`) so the agent fetches the rule
    when the description matches the task.

    Replaces the prior `~/.windsurf/hooks.json` install — Windsurf has no
    documented hook surface (rf-0vr3 prune; same pattern as Continue.dev hooks
    prune in rf-cia phase b).
    """
    rules_dir = root / ".windsurf" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    res = importlib.resources.files("rafter_cli.resources")
    for name in _WINDSURF_RULE_SKILLS:
        try:
            content = res.joinpath("windsurf-rules", f"{name}.md").read_text(encoding="utf-8")
        except Exception:
            rprint(fmt.warning(f"Windsurf rule template missing: {name}.md"))
            continue
        dest = rules_dir / f"{name}.md"
        dest.write_text(content, encoding="utf-8")
        rprint(fmt.success(f"Installed Windsurf rule to {dest}"))


# Skills shipped as Continue.dev rules at .continue/rules/<skill>.md (rf-acz0).
_CONTINUE_RULE_SKILLS: tuple[str, ...] = (
    "rafter",
    "rafter-secure-design",
    "rafter-code-review",
    "rafter-skill-review",
)


def _install_continue_dev_rules(root: Path) -> None:
    """Install per-skill Continue.dev rules at <root>/.continue/rules/<skill>.md.

    Continue.dev reads workspace rules from .continue/rules/*.md (per-rule
    files, lexicographic load order). YAML frontmatter: `name`, `description`,
    `alwaysApply`. Each rule body mirrors the Cursor / Windsurf pointer-rule
    pattern.
    """
    rules_dir = root / ".continue" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    res = importlib.resources.files("rafter_cli.resources")
    for name in _CONTINUE_RULE_SKILLS:
        try:
            content = res.joinpath("continue-rules", f"{name}.md").read_text(encoding="utf-8")
        except Exception:
            rprint(fmt.warning(f"Continue.dev rule template missing: {name}.md"))
            continue
        dest = rules_dir / f"{name}.md"
        dest.write_text(content, encoding="utf-8")
        rprint(fmt.success(f"Installed Continue.dev rule to {dest}"))


def _install_continue_dev_mcp(root: Path) -> bool:
    """Install MCP server config for Continue.dev (<root>/.continue/config.json)."""
    continue_dir = root / ".continue"
    config_path = continue_dir / "config.json"

    continue_dir.mkdir(parents=True, exist_ok=True)

    config: dict[str, Any] = {}
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text())
        except (json.JSONDecodeError, ValueError):
            rprint(fmt.warning("Existing Continue.dev config.json was unreadable, creating new one"))

    if "mcpServers" not in config:
        config["mcpServers"] = []

    # Array format (older Continue.dev) vs object format (newer)
    if isinstance(config["mcpServers"], list):
        config["mcpServers"] = [s for s in config["mcpServers"] if s.get("name") != "rafter"]
        config["mcpServers"].append({
            "name": "rafter",
            "command": _RAFTER_MCP_ENTRY["command"],
            "args": _RAFTER_MCP_ENTRY["args"],
        })
    else:
        config["mcpServers"]["rafter"] = {**_RAFTER_MCP_ENTRY}

    config_path.write_text(json.dumps(config, indent=2) + "\n")
    rprint(fmt.success(f"Installed Rafter MCP server to {config_path}"))
    return True


_AIDER_LEGACY_MCP_BLOCK_RE = re.compile(
    r"\n?#\s*Rafter security MCP server\s*\nmcp-server-command:\s*rafter\s+mcp\s+serve\s*\n?",
)
_AIDER_LEGACY_MCP_LINE_RE = re.compile(
    r"^mcp-server-command:\s*rafter\s+mcp\s+serve\s*\n?",
    flags=re.MULTILINE,
)
_AIDER_READ_ENTRY = "RAFTER.md"


def _install_aider_read(root: Path) -> bool:
    """Install Rafter context for Aider (rf-du2o).

    Aider has no native MCP support and no plugin/hook surface. Its only
    intercept-friendly persistent-context primitive is the `read:` flag in
    `.aider.conf.yml`, which injects read-only files into every session.

    Behavior:
      1. Write `<root>/RAFTER.md` with the rafter instruction block.
      2. Update `<root>/.aider.conf.yml` so `read:` includes `RAFTER.md`
         (preserves any pre-existing `read:` entries; preserves other YAML keys).
      3. Strip the legacy `mcp-server-command: rafter mcp serve` line(s) if
         present — silent no-op in earlier versions (Aider has no MCP).
    """
    rafter_md_path = root / "RAFTER.md"
    config_path = root / ".aider.conf.yml"

    # 1. Write RAFTER.md (idempotent — marker block replaced in place).
    _inject_instruction_file(rafter_md_path)

    # 2. Update .aider.conf.yml read: list.
    raw = config_path.read_text() if config_path.exists() else ""

    # 2a. Strip legacy mcp-server-command silent-no-op (rf-du2o migration).
    raw = _AIDER_LEGACY_MCP_BLOCK_RE.sub("\n", raw)
    raw = _AIDER_LEGACY_MCP_LINE_RE.sub("", raw)

    parsed: dict[str, Any] = {}
    if raw.strip():
        try:
            loaded = yaml.safe_load(raw)
            if isinstance(loaded, dict):
                parsed = loaded
        except yaml.YAMLError:
            # Unparseable YAML — append a read: section without rewriting.
            if _AIDER_READ_ENTRY not in raw:
                sep = "" if not raw or raw.endswith("\n") else "\n"
                config_path.write_text(f"{raw}{sep}read:\n  - {_AIDER_READ_ENTRY}\n")
            else:
                config_path.write_text(raw)
            rprint(fmt.success(f"Installed Rafter read-only context to {config_path}"))
            return True

    # Normalize read: to a list of strings.
    reads: list[str] = []
    raw_read = parsed.get("read")
    if isinstance(raw_read, list):
        reads = [str(p) for p in raw_read]
    elif isinstance(raw_read, str):
        reads = [raw_read]

    if _AIDER_READ_ENTRY not in reads:
        reads.append(_AIDER_READ_ENTRY)
    parsed["read"] = reads

    config_path.write_text(yaml.safe_dump(parsed, sort_keys=False))
    rprint(fmt.success(
        f"Installed Rafter read-only context to {rafter_md_path} + {config_path}"
    ))
    return True


@agent_app.command()
def init(
    risk_level: str = typer.Option("moderate", "--risk-level", help="minimal, moderate, or aggressive"),
    with_gitleaks: bool = typer.Option(False, "--with-gitleaks", help="Download and install Gitleaks binary"),
    with_openclaw: bool = typer.Option(False, "--with-openclaw", help="Install OpenClaw integration"),
    with_claude_code: bool = typer.Option(False, "--with-claude-code", help="Install Claude Code integration"),
    with_codex: bool = typer.Option(False, "--with-codex", help="Install Codex CLI integration"),
    with_gemini: bool = typer.Option(False, "--with-gemini", help="Install Gemini CLI integration"),
    with_aider: bool = typer.Option(False, "--with-aider", help="Install Aider integration"),
    with_cursor: bool = typer.Option(False, "--with-cursor", help="Install Cursor integration"),
    with_windsurf: bool = typer.Option(False, "--with-windsurf", help="Install Windsurf integration"),
    with_continue: bool = typer.Option(False, "--with-continue", help="Install Continue.dev integration"),
    all_integrations: bool = typer.Option(False, "--all", help="Install all detected integrations and download Gitleaks"),
    update: bool = typer.Option(False, "--update", help="Re-download gitleaks and reinstall integrations without resetting config"),
    local: bool = typer.Option(
        False,
        "--local",
        help=(
            "Install integration configs project-locally (in CWD) instead of user-globally. "
            "Supported for Claude Code, Codex, Gemini, Cursor. Other platforms are skipped in local mode."
        ),
    ),
):
    """Initialize agent security system."""
    rprint(fmt.header("Rafter Agent Security Setup"))
    rprint(fmt.divider())
    rprint()

    manager = ConfigManager()
    root = Path.cwd() if local else Path.home()
    scope = "project" if local else "user"
    if local:
        rprint(fmt.info(f"Project-local install — writing configs under {root}"))

    # Detect environments. In local scope, don't probe user-global paths —
    # the user must opt in explicitly via --with-<platform>.
    home = Path.home()
    has_openclaw = scope == "user" and (home / ".openclaw").exists()
    has_claude_code = scope == "user" and (home / ".claude").exists()
    has_codex = scope == "user" and (home / ".codex").exists()
    has_gemini = scope == "user" and (home / ".gemini").exists()
    has_cursor = scope == "user" and (home / ".cursor").exists()
    has_windsurf = scope == "user" and (home / ".codeium" / "windsurf").exists()
    has_continue_dev = scope == "user" and (home / ".continue").exists()
    has_aider = scope == "user" and (home / ".aider.conf.yml").exists()

    # Resolve opt-in flags. In --local scope, --all is restricted to platforms with
    # a project-local config story (claudeCode, codex, gemini, cursor).
    # OpenClaw returns to --all in rf-zgwj — the integration was rebuilt to
    # ship a ClawHub-shaped skill at the canonical workspace path
    # (~/.openclaw/workspace/skills/rafter-security/SKILL.md), so OpenClaw
    # actually auto-discovers it now. (User-scope only.)
    want_openclaw = with_openclaw or (all_integrations and not local)
    want_claude_code = with_claude_code or all_integrations
    want_codex = with_codex or all_integrations
    want_gemini = with_gemini or all_integrations
    want_cursor = with_cursor or all_integrations
    # Windsurf can install at --local scope (project rules + AGENTS.md) since
    # rf-0vr3. User scope still also installs the MCP entry.
    want_windsurf = with_windsurf or all_integrations
    # Continue.dev can install at --local scope (project rules) since rf-acz0.
    want_continue = with_continue or all_integrations
    # Aider can install at --local scope (writes RAFTER.md + .aider.conf.yml
    # in cwd) since rf-du2o.
    want_aider = with_aider or all_integrations
    want_gitleaks = with_gitleaks or (all_integrations and not local)

    # Show detected environments
    detected = []
    if has_openclaw:
        detected.append("OpenClaw")
    if has_claude_code:
        detected.append("Claude Code")
    if has_codex:
        detected.append("Codex CLI")
    if has_gemini:
        detected.append("Gemini CLI")
    if has_cursor:
        detected.append("Cursor")
    if has_windsurf:
        detected.append("Windsurf")
    if has_continue_dev:
        detected.append("Continue.dev")
    if has_aider:
        detected.append("Aider")

    if detected:
        rprint(fmt.info(f"Detected environments: {', '.join(detected)}"))
    else:
        rprint(fmt.info("No agent environments detected"))

    # Warn about requested but undetected environments (user scope only —
    # in --local scope we create the directories in CWD as needed).
    if scope == "user":
        if want_openclaw and not has_openclaw:
            rprint(fmt.warning("OpenClaw requested but not detected (~/.openclaw not found)"))
        if want_claude_code and not has_claude_code:
            rprint(fmt.warning("Claude Code requested but not detected (~/.claude not found)"))
        if want_codex and not has_codex:
            rprint(fmt.warning("Codex CLI requested but not detected (~/.codex not found)"))
        if want_gemini and not has_gemini:
            rprint(fmt.warning("Gemini CLI requested but not detected (~/.gemini not found)"))
        if want_cursor and not has_cursor:
            rprint(fmt.warning("Cursor requested but not detected (~/.cursor not found)"))
        if want_windsurf and not has_windsurf:
            rprint(fmt.warning("Windsurf requested but not detected (~/.codeium/windsurf not found)"))
        if want_continue and not has_continue_dev:
            rprint(fmt.warning("Continue.dev requested but not detected (~/.continue not found)"))
        if want_aider and not has_aider:
            rprint(fmt.warning("Aider requested but not detected (~/.aider.conf.yml not found)"))

    # Initialize
    manager.initialize()
    rprint(fmt.success("Created config at ~/.rafter/config.json"))

    # Validate + set risk level
    valid = ("minimal", "moderate", "aggressive")
    if risk_level not in valid:
        rprint(fmt.error(f"Invalid risk level: {risk_level}"))
        print(f"Valid options: {', '.join(valid)}", file=sys.stderr)
        raise typer.Exit(code=1)

    manager.set("agent.risk_level", risk_level)
    rprint(fmt.success(f"Set risk level: {risk_level}"))

    # Gitleaks check (opt-in via --with-gitleaks or --all)
    if want_gitleaks:
        _gitleaks_on_path = None if update else shutil.which("gitleaks")
        _rafter_bin = Path.home() / ".rafter" / "bin" / "gitleaks"
        if _gitleaks_on_path:
            rprint(fmt.success(f"Gitleaks available on PATH ({_gitleaks_on_path})"))
        elif not update and _rafter_bin.exists():
            rprint(fmt.success(f"Gitleaks available at {_rafter_bin}"))
        else:
            if update:
                rprint(fmt.info("Updating gitleaks binary..."))
            else:
                rprint(fmt.info("Gitleaks not found — attempting auto-download..."))
            _bm = BinaryManager()
            if _bm.is_platform_supported():
                try:
                    _bm.download_gitleaks(on_progress=typer.echo)
                    rprint(fmt.success("Gitleaks downloaded and verified."))
                except Exception as _dl_err:
                    rprint(fmt.warning(f"Auto-download failed: {_dl_err}"))
                    rprint(fmt.info(
                        "To fix: install gitleaks manually "
                        "(https://github.com/gitleaks/gitleaks/releases) "
                        "and ensure it is on PATH, then re-run 'rafter agent init'."
                    ))
            else:
                rprint(fmt.warning(
                    "Gitleaks not available for this platform — "
                    "pattern-based scanning will be used instead."
                ))
                rprint(fmt.info(
                    "To fix: install gitleaks (https://github.com/gitleaks/gitleaks/releases) "
                    "and ensure it is on PATH, then re-run 'rafter agent init'."
                ))

    # Install OpenClaw skill if opted in
    openclaw_ok = False
    if has_openclaw and want_openclaw:
        ok, source, dest, error = _install_openclaw_skill()
        openclaw_ok = ok
        if ok:
            rprint(fmt.success(f"Installed Rafter Security skill to {dest}"))
            manager.set("agent.environments.openclaw.enabled", True)
        else:
            rprint(fmt.error("Failed to install Rafter Security skill"))
            rprint(fmt.warning(f"  Source: {source}"))
            rprint(fmt.warning(f"  Destination: {dest}"))
            if error:
                rprint(fmt.warning(f"  Error: {error}"))

    def _local_unsupported(label: str) -> None:
        rprint(fmt.warning(
            f"{label} is not supported in --local mode yet. Skipping. "
            "Re-run without --local to install for this platform user-globally."
        ))

    # Install Claude Code skills + hooks if opted in
    # When --with-claude-code is explicitly passed (or --local), install even if <root>/.claude doesn't exist yet
    claude_code_ok = False
    if (has_claude_code or with_claude_code or (local and want_claude_code)) and want_claude_code:
        try:
            _install_claude_code_skills(root)
            _install_claude_code_subagents(root)
            _install_claude_code_hooks(root)
            if scope == "project":
                components = manager.get("agent.components") or {}
                if components.get("claude-code.mcp", {}).get("enabled") is False:
                    rprint(fmt.info("Skipped .mcp.json (claude-code.mcp disabled; re-enable with 'rafter agent enable claude-code.mcp')"))
                else:
                    _install_claude_code_mcp(root)
                    from datetime import datetime, timezone
                    components["claude-code.mcp"] = {
                        "enabled": True,
                        "updatedAt": datetime.now(timezone.utc).isoformat(),
                    }
                    manager.set("agent.components", components)
            if scope == "user":
                manager.set("agent.environments.claude_code.enabled", True)
            claude_code_ok = True
        except Exception as e:
            rprint(fmt.error(f"Failed to install Claude Code integration: {e}"))

    # Install Codex CLI skills + hooks if opted in
    codex_ok = False
    if (has_codex or (local and want_codex)) and want_codex:
        try:
            ok, error = _install_codex_skills(root)
            codex_ok = ok
            if ok and scope == "user":
                manager.set("agent.environments.codex.enabled", True)
            elif not ok:
                rprint(fmt.error(f"Failed to install Codex CLI skills: {error}"))
        except Exception as e:
            rprint(fmt.error(f"Failed to install Codex CLI integration: {e}"))

    # Install Gemini CLI MCP + skills if opted in
    gemini_ok = False
    if (has_gemini or (local and want_gemini)) and want_gemini:
        try:
            gemini_ok = _install_gemini_mcp(root)
            skills_ok, skills_error = _install_gemini_skills(root)
            if not skills_ok:
                rprint(fmt.error(f"Failed to install Gemini CLI skills: {skills_error}"))
            else:
                _register_gemini_skills(root / ".agents" / "skills")
            if gemini_ok and scope == "user":
                manager.set("agent.environments.gemini.enabled", True)
        except Exception as e:
            rprint(fmt.error(f"Failed to install Gemini CLI integration: {e}"))

    # Install Cursor MCP + hooks + per-skill rules + sub-agent if opted in
    cursor_ok = False
    if (has_cursor or (local and want_cursor)) and want_cursor:
        try:
            cursor_ok = _install_cursor_mcp(root)
            _install_cursor_hooks(root)
            _install_cursor_rules(root)
            _install_cursor_subagents(root)
            if cursor_ok and scope == "user":
                manager.set("agent.environments.cursor.enabled", True)
        except Exception as e:
            rprint(fmt.error(f"Failed to install Cursor integration: {e}"))

    # Install Windsurf integration if opted in (rf-0vr3).
    # - User scope: MCP entry under ~/.codeium/windsurf/ + per-skill workspace
    #   rules at .windsurf/rules/ + AGENTS.md (written below by
    #   _install_global_instructions).
    # - Project scope (--local): rules + AGENTS.md only.
    # The previous ~/.windsurf/hooks.json install was pruned: Windsurf has no
    # documented hook surface.
    windsurf_ok = False
    if want_windsurf and (has_windsurf or local):
        try:
            if has_windsurf:
                windsurf_ok = _install_windsurf_mcp(root)
                if windsurf_ok:
                    manager.set("agent.environments.windsurf.enabled", True)
            _install_windsurf_rules(root)
            if not has_windsurf:
                # Project-scope success: rules + AGENTS.md (written below).
                windsurf_ok = True
        except Exception as e:
            rprint(fmt.error(f"Failed to install Windsurf integration: {e}"))

    # Install Continue.dev integration if opted in (rf-acz0).
    # - User scope: per-skill rules (.continue/rules/) + MCP entry under
    #   ~/.continue/config.json.
    # - Project scope (--local): rules only.
    continue_ok = False
    if want_continue and (has_continue_dev or local):
        try:
            if has_continue_dev:
                continue_ok = _install_continue_dev_mcp(root)
                if continue_ok:
                    manager.set("agent.environments.continue_dev.enabled", True)
            _install_continue_dev_rules(root)
            if not has_continue_dev:
                continue_ok = True
        except Exception as e:
            rprint(fmt.error(f"Failed to install Continue.dev integration: {e}"))

    # Install Aider integration if opted in (rf-du2o).
    # Aider has no MCP and no hook surface — its only intercept is the
    # `read:` flag in .aider.conf.yml. We write RAFTER.md and ensure the
    # `read:` list includes it. Legacy mcp-server-command line is stripped.
    aider_ok = False
    if want_aider and (has_aider or local):
        try:
            aider_ok = _install_aider_read(root)
            if aider_ok and has_aider:
                manager.set("agent.environments.aider.enabled", True)
        except Exception as e:
            rprint(fmt.error(f"Failed to install Aider integration: {e}"))

    # Install global instruction files for platforms that support them
    _install_global_instructions(
        claude_code=claude_code_ok,
        codex=codex_ok,
        gemini=gemini_ok,
        cursor=cursor_ok,
        windsurf=windsurf_ok,
        root=root,
        scope=scope,
    )

    rprint()
    rprint(fmt.success("Agent security initialized!"))
    rprint()

    any_integration = openclaw_ok or claude_code_ok or codex_ok or gemini_ok or cursor_ok or windsurf_ok or continue_ok or aider_ok

    if any_integration:
        rprint("Next steps:")
        if openclaw_ok:
            rprint("  - Restart OpenClaw to load skill")
        if claude_code_ok:
            rprint("  - Restart Claude Code to load hooks")
        if codex_ok:
            rprint("  - Restart Codex CLI to load skills")
        if gemini_ok:
            rprint("  - Restart Gemini CLI to load MCP server")
        if cursor_ok:
            rprint("  - Restart Cursor to load MCP server")
        if windsurf_ok:
            rprint("  - Restart Windsurf to load MCP server")
        if continue_ok:
            rprint("  - Restart Continue.dev to load MCP server")
        if aider_ok:
            rprint("  - Restart Aider to load RAFTER.md from .aider.conf.yml read:")
    elif scope == "project":
        rprint("No integrations were installed. In --local mode, pass one or more opt-in flags:")
        rprint("  rafter agent init --local --with-claude-code")
        rprint("  rafter agent init --local --with-codex")
        rprint("  rafter agent init --local --with-gemini")
        rprint("  rafter agent init --local --with-cursor")
    elif detected:
        rprint("No integrations were installed. To install, re-run with opt-in flags:")
        rprint("  rafter agent init --all                  # Install all detected")
        if has_claude_code:
            rprint("  rafter agent init --with-claude-code     # Claude Code only")
        if has_openclaw:
            rprint("  rafter agent init --with-openclaw        # OpenClaw only")
        if has_codex:
            rprint("  rafter agent init --with-codex           # Codex CLI only")
        if has_gemini:
            rprint("  rafter agent init --with-gemini          # Gemini CLI only")
        if has_cursor:
            rprint("  rafter agent init --with-cursor          # Cursor only")
        if has_windsurf:
            rprint("  rafter agent init --with-windsurf        # Windsurf only")
        if has_continue_dev:
            rprint("  rafter agent init --with-continue        # Continue.dev only")
        if has_aider:
            rprint("  rafter agent init --with-aider           # Aider only")
    else:
        rprint("No agent environments detected. Install an agent tool and re-run with --with-<tool>.")

    rprint()
    rprint("  - Run: rafter secrets . (test secret scanning)")
    rprint("  - Configure: rafter agent config show")
    rprint()


# ── scan ─────────────────────────────────────────────────────────────


def _select_engine(preference: str, quiet: bool) -> str:
    """Return 'gitleaks' or 'patterns'."""
    valid_engines = ("auto", "gitleaks", "patterns")
    if preference not in valid_engines:
        print(f"Invalid engine: {preference}. Valid values: {', '.join(valid_engines)}", file=sys.stderr)
        raise typer.Exit(code=2)

    if preference == "patterns":
        return "patterns"

    scanner = GitleaksScanner()
    available = scanner.is_available()

    if preference == "gitleaks":
        if not available:
            if not quiet:
                print_stderr(fmt.warning("Gitleaks requested but not available, using patterns"))
            return "patterns"
        return "gitleaks"

    # auto
    return "gitleaks" if available else "patterns"


def _scan_file(file_path: str, engine: str, custom_patterns=None) -> list[ScanResult]:
    if engine == "gitleaks":
        try:
            gl = GitleaksScanner()
            result = gl.scan_file(file_path)
            return [ScanResult(file=result.file, matches=result.matches)] if result.matches else []
        except Exception:
            scanner = RegexScanner(custom_patterns)
            r = scanner.scan_file(file_path)
            return [r] if r.matches else []
    else:
        scanner = RegexScanner(custom_patterns)
        r = scanner.scan_file(file_path)
        return [r] if r.matches else []


def _scan_directory(dir_path: str, engine: str, scan_cfg=None, *, history: bool = False) -> list[ScanResult]:
    custom = None
    exclude = None
    if scan_cfg:
        custom = [{"name": p.name, "regex": p.regex, "severity": p.severity} for p in scan_cfg.custom_patterns] if scan_cfg.custom_patterns else None
        exclude = scan_cfg.exclude_paths or None

    if engine == "gitleaks":
        try:
            gl = GitleaksScanner()
            results = gl.scan_directory(dir_path, use_git=history)
            return [ScanResult(file=r.file, matches=r.matches) for r in results]
        except Exception:
            scanner = RegexScanner(custom)
            return scanner.scan_directory(dir_path, exclude_paths=exclude)
    else:
        scanner = RegexScanner(custom)
        return scanner.scan_directory(dir_path, exclude_paths=exclude)


def _output_scan_results(
    results: list[ScanResult],
    json_output: bool,
    quiet: bool,
    context: str | None = None,
    format: str = "text",
    exit_on_findings: bool = True,
    suppressions: list | None = None,
) -> None:
    from ..core.custom_patterns import apply_suppressions
    suppressions = suppressions or []
    kept_results, suppressed = apply_suppressions(results, suppressions)

    if format == "sarif":
        _output_sarif(kept_results)
        return

    if json_output or format == "json":
        files_out = [
            {"file": r.file, "matches": [
                {"pattern": {"name": m.pattern.name, "severity": m.pattern.severity, "description": m.pattern.description or ""},
                 "line": m.line, "column": m.column, "redacted": m.redacted}
                for m in r.matches
            ]}
            for r in kept_results
        ]
        out: dict = {
            "_note": (
                "Local-only scan: pattern-based detection without agentic-intelligence triage. "
                "Findings have not been evaluated for context (public exposure, key validity, "
                "deployment environment). Investigate each before acting; do not dismiss. "
                "Run 'rafter run' for backend agentic analysis."
            ),
            "scan_mode": "local",
            "triage_applied": False,
            "results": files_out,
        }
        if suppressed:
            from dataclasses import asdict
            out["_suppressed"] = [asdict(s) for s in suppressed]
        print(json.dumps(out, indent=2))
        if exit_on_findings:
            raise typer.Exit(code=1 if kept_results else 0)
        return

    if suppressed and not quiet:
        print(f"({len(suppressed)} finding(s) hidden by .rafter.yml)", file=sys.stderr)

    if not kept_results:
        if not quiet:
            msg = f"No secrets detected in {context}" if context else "No secrets detected"
            rprint(f"\n{fmt.success(msg)}\n")
        if exit_on_findings:
            raise typer.Exit(code=0)
        return

    rprint(f"\n{fmt.warning(f'Found secrets in {len(kept_results)} file(s):')}\n")

    total = 0
    for r in kept_results:
        rprint(f"\n{fmt.info(r.file)}")
        for m in r.matches:
            total += 1
            loc = f"Line {m.line}" if m.line else "Unknown location"
            rprint(f"  {fmt.severity(m.pattern.severity)} {m.pattern.name}")
            rprint(f"     Location: {loc}")
            rprint(f"     Pattern: {m.pattern.description or m.pattern.regex}")
            rprint(f"     Redacted: {m.redacted}")
            rprint()

    rprint(f"\n{fmt.warning(f'Total: {total} secret(s) detected in {len(kept_results)} file(s)')}\n")

    if context == "staged files":
        rprint(f"{fmt.error('Commit blocked. Remove secrets before committing.')}\n")
    elif exit_on_findings:
        rprint("Run 'rafter agent audit' to see the security log.\n")

    if exit_on_findings:
        raise typer.Exit(code=1)


def _watch_and_scan(
    watch_path: str,
    engine: str,
    quiet: bool,
    json_output: bool,
    format: str,
    custom_patterns,
    scan_cfg,
    suppressions: list | None = None,
) -> None:
    """Watch a path for changes and re-scan on each change. Ctrl+C exits."""
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent
    except ImportError:
        print("Error: watchdog package required for --watch mode. Install with: pip install watchdog", file=sys.stderr)
        raise typer.Exit(code=2)

    logger = AuditLogger()
    eng = _select_engine(engine, quiet)

    if not quiet:
        print_stderr(fmt.info(f"Watching {watch_path} for changes ({eng}). Press Ctrl+C to exit."))

    # Initial scan
    if os.path.isdir(watch_path):
        initial_results = _scan_directory(watch_path, eng, scan_cfg)
    else:
        initial_results = _scan_file(watch_path, eng, custom_patterns)

    if initial_results:
        rprint(fmt.warning("\n[Initial scan] Found secrets:"))
        _output_scan_results(initial_results, json_output, False, format=format, exit_on_findings=False, suppressions=suppressions)
        _log_watch_findings(logger, initial_results)
    elif not quiet:
        rprint(fmt.success("[Initial scan] No secrets detected"))

    import re as _re
    _IGNORE_PATTERN = _re.compile(r'(^|[/\\])(\.git|node_modules|\.hg|__pycache__|\.tox|\.venv)([/\\]|$)')

    class _Handler(FileSystemEventHandler):
        def _should_ignore(self, file_path: str) -> bool:
            return bool(_IGNORE_PATTERN.search(file_path))

        def _handle(self, file_path: str) -> None:
            if not os.path.isfile(file_path):
                return
            if self._should_ignore(file_path):
                return
            from datetime import datetime as _dt
            ts = _dt.now().strftime("%H:%M:%S")
            if not quiet:
                print(f"\n[{ts}] Changed: {file_path}", file=sys.stderr)
            results = _scan_file(file_path, eng, custom_patterns)
            if results:
                _output_scan_results(results, json_output, False, format=format, exit_on_findings=False, suppressions=suppressions)
                _log_watch_findings(logger, results)
            elif not quiet:
                rprint(fmt.success("  No secrets detected"))

        def on_modified(self, event):
            if not event.is_directory:
                self._handle(event.src_path)

        def on_created(self, event):
            if not event.is_directory:
                self._handle(event.src_path)

    event_handler = _Handler()
    observer = Observer()
    observer.schedule(event_handler, watch_path, recursive=True)
    observer.start()

    try:
        import time
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        observer.stop()
        if not quiet:
            rprint(fmt.info("\nWatch mode stopped."))
    observer.join()


def _log_watch_findings(logger: AuditLogger, results: list[ScanResult]) -> None:
    for result in results:
        for match in result.matches:
            logger.log_secret_detected(
                location=result.file,
                secret_type=match.pattern.name,
                action_taken="allowed",
            )


def _output_sarif(results: list[ScanResult]) -> None:
    """Emit SARIF 2.1.0 JSON for GitHub/GitLab security tab integration."""
    rules: dict[str, dict] = {}
    sarif_results = []
    for r in results:
        for m in r.matches:
            rule_id = re.sub(r"\s+", "-", m.pattern.name.lower())
            if rule_id not in rules:
                rules[rule_id] = {
                    "id": rule_id,
                    "name": m.pattern.name,
                    "shortDescription": {"text": m.pattern.description or m.pattern.name},
                }
            level = "error" if m.pattern.severity in ("critical", "high") else "warning"
            location: dict[str, Any] = {
                "artifactLocation": {"uri": r.file.replace("\\", "/"), "uriBaseId": "%SRCROOT%"},
            }
            if m.line:
                location["region"] = {"startLine": m.line, "startColumn": m.column or 1}
            sarif_results.append({
                "ruleId": rule_id,
                "level": level,
                "message": {"text": f"{m.pattern.name} detected"},
                "locations": [{"physicalLocation": location}],
            })
    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {
                "driver": {
                    "name": "rafter",
                    "informationUri": "https://rafter.so",
                    "rules": list(rules.values()),
                }
            },
            "results": sarif_results,
        }],
    }
    print(json.dumps(sarif, indent=2))
    raise typer.Exit(code=1 if results else 0)


@agent_app.command()
def scan(
    path: str = typer.Argument(".", help="File or directory to scan"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Only output if secrets found"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    format: str = typer.Option("text", "--format", help="Output format: text, json, sarif"),
    staged: bool = typer.Option(False, "--staged", help="Scan only git staged files"),
    diff: str = typer.Option(None, "--diff", help="Scan files changed since a git ref"),
    engine: str = typer.Option("auto", "--engine", help="gitleaks or patterns"),
    baseline: bool = typer.Option(False, "--baseline", help="Filter findings present in the saved baseline"),
    watch: bool = typer.Option(False, "--watch", help="Watch for file changes and re-scan on change"),
    history: bool = typer.Option(False, "--history", help="Scan git history for secrets (requires gitleaks engine)"),
):
    """Scan files or directories for secrets. [deprecated: use 'rafter secrets' instead]"""
    print(
        "Warning: rafter agent scan is deprecated and will be removed in a future major version. "
        "Use rafter secrets instead.",
        file=sys.stderr,
    )
    manager = ConfigManager()
    cfg = manager.load_with_policy()
    scan_cfg = cfg.agent.scan

    custom_patterns = (
        [{"name": p.name, "regex": p.regex, "severity": p.severity} for p in scan_cfg.custom_patterns]
        if scan_cfg.custom_patterns else None
    )

    from ..core.custom_patterns import load_suppressions, policy_ignore_to_suppressions
    suppressions = policy_ignore_to_suppressions(scan_cfg.ignore) + load_suppressions()

    baseline_entries = _load_baseline_entries() if baseline else []

    # --diff
    if diff:
        try:
            diff_output = subprocess.run(
                ["git", "diff", "--name-only", "--diff-filter=ACM", diff],
                capture_output=True, text=True, check=True,
            ).stdout.strip()
        except subprocess.CalledProcessError:
            print("Error: Not in a git repository or invalid ref", file=sys.stderr)
            raise typer.Exit(code=2)

        if not diff_output:
            if not quiet:
                rprint(fmt.success(f"No files changed since {diff}"))
            raise typer.Exit(code=0)

        changed = [f.strip() for f in diff_output.split("\n") if f.strip()]
        if not quiet:
            print(f"Scanning {len(changed)} file(s) changed since {diff}...", file=sys.stderr)

        eng = _select_engine(engine, quiet)
        all_results: list[ScanResult] = []
        for f in changed:
            resolved = os.path.abspath(f)
            if os.path.isfile(resolved):
                all_results.extend(_scan_file(resolved, eng, custom_patterns))
        filtered = _apply_baseline(all_results, baseline_entries)
        _output_scan_results(filtered, json_output, quiet, f"files changed since {diff}", format=format, suppressions=suppressions)
        return

    # --staged
    if staged:
        try:
            staged_output = subprocess.run(
                ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
                capture_output=True, text=True, check=True,
            ).stdout.strip()
        except subprocess.CalledProcessError:
            print("Error: Not in a git repository", file=sys.stderr)
            raise typer.Exit(code=2)

        if not staged_output:
            if not quiet:
                rprint(fmt.success("No files staged for commit"))
            raise typer.Exit(code=0)

        staged_files = [f.strip() for f in staged_output.split("\n") if f.strip()]
        if not quiet:
            print(f"Scanning {len(staged_files)} staged file(s)...", file=sys.stderr)

        eng = _select_engine(engine, quiet)
        all_results = []
        for f in staged_files:
            resolved = os.path.abspath(f)
            if os.path.isfile(resolved):
                all_results.extend(_scan_file(resolved, eng, custom_patterns))
        filtered = _apply_baseline(all_results, baseline_entries)
        _output_scan_results(filtered, json_output, quiet, "staged files", format=format, suppressions=suppressions)
        return

    # Default: scan path
    resolved_path = os.path.abspath(path)
    if not os.path.exists(resolved_path):
        print(f"Error: Path not found: {resolved_path}", file=sys.stderr)
        raise typer.Exit(code=2)

    # --watch
    if watch:
        _watch_and_scan(resolved_path, engine, quiet, json_output, format, custom_patterns, scan_cfg, suppressions)
        return

    eng = _select_engine(engine, quiet)

    if os.path.isdir(resolved_path):
        if not quiet:
            print(f"Scanning directory: {resolved_path} ({eng})", file=sys.stderr)
        results = _scan_directory(resolved_path, eng, scan_cfg, history=history)
    else:
        if not quiet:
            print(f"Scanning file: {resolved_path} ({eng})", file=sys.stderr)
        results = _scan_file(resolved_path, eng, custom_patterns)

    filtered = _apply_baseline(results, baseline_entries)
    _output_scan_results(filtered, json_output, quiet, format=format, suppressions=suppressions)


# ── audit ────────────────────────────────────────────────────────────

_EVENT_INDICATORS_AGENT = {
    "command_intercepted": "[INTERCEPT]",
    "secret_detected": "[SECRET]",
    "content_sanitized": "[SANITIZE]",
    "policy_override": "[OVERRIDE]",
    "scan_executed": "[SCAN]",
    "config_changed": "[CONFIG]",
}

_EVENT_INDICATORS_HUMAN = {
    "command_intercepted": "\U0001f6e1\ufe0f",
    "secret_detected": "\U0001f511",
    "content_sanitized": "\U0001f9f9",
    "policy_override": "\u26a0\ufe0f",
    "scan_executed": "\U0001f50d",
    "config_changed": "\u2699\ufe0f",
}


@agent_app.command()
def audit(
    last: int = typer.Option(10, "--last", help="Show last N entries"),
    event: str = typer.Option(None, "--event", help="Filter by event type"),
    agent_type: str = typer.Option(None, "--agent", help="Filter by agent type"),
    since: str = typer.Option(None, "--since", help="Show entries since date (YYYY-MM-DD)"),
    repo: str = typer.Option(None, "--repo", help="Filter by git repo path (substring match)"),
    cwd: str = typer.Option(None, "--cwd", help="Filter by working directory (substring match)"),
    share: bool = typer.Option(False, "--share", help="Generate a redacted excerpt for issue reports"),
    verify: bool = typer.Option(False, "--verify", help="Verify the audit log hash chain and report tampering"),
):
    """View audit log entries."""
    if share:
        _audit_share()
        return

    logger = AuditLogger()

    if verify:
        breaks = logger.verify()
        if not breaks:
            print("\u2713 Audit log hash chain intact")
            return
        plural = "" if len(breaks) == 1 else "s"
        print(f"\u2717 Audit log hash chain broken ({len(breaks)} break{plural}):", file=sys.stderr)
        for b in breaks:
            print(f"  line {b['line']}: {b['reason']}", file=sys.stderr)
        raise typer.Exit(code=1)

    since_dt = None
    if since:
        try:
            since_dt = datetime.fromisoformat(since)
        except ValueError:
            print(f"Invalid date: {since}", file=sys.stderr)
            raise typer.Exit(code=1)

    entries = logger.read(
        event_type=event,
        agent_type=agent_type,
        since=since_dt,
        limit=last,
        cwd=cwd,
        git_repo=repo,
    )

    if not entries:
        print("No audit log entries found")
        return

    print(f"\nShowing {len(entries)} audit log entries:\n")

    indicators = _EVENT_INDICATORS_AGENT if is_agent_mode() else _EVENT_INDICATORS_HUMAN

    for e in entries:
        ts = e.get("timestamp", "")
        try:
            ts = datetime.fromisoformat(ts).strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            pass
        et = e.get("eventType", e.get("event_type", "unknown"))
        ind = indicators.get(et, "[EVENT]" if is_agent_mode() else "\U0001f4dd")
        print(f"{ind} [{ts}] {et}")
        if e.get("agentType") or e.get("agent_type"):
            print(f"   Agent: {e.get('agentType') or e['agent_type']}")
        if e.get("gitRepo"):
            print(f"   Repo: {e['gitRepo']}")
        elif e.get("cwd"):
            print(f"   Cwd: {e['cwd']}")
        action = e.get("action") or {}
        if action.get("command"):
            print(f"   Command: {action['command']}")
        if action.get("riskLevel") or action.get("risk_level"):
            print(f"   Risk: {action.get('riskLevel') or action['risk_level']}")
        sc = e.get("securityCheck") or e.get("security_check") or {}
        print(f"   Check: {'PASSED' if sc.get('passed') else 'FAILED'}")
        if sc.get("reason"):
            print(f"   Reason: {sc['reason']}")
        res = e.get("resolution") or {}
        print(f"   Action: {res.get('actionTaken', res.get('action_taken', 'unknown'))}")
        if res.get("overrideReason") or res.get("override_reason"):
            print(f"   Override: {res.get('overrideReason') or res['override_reason']}")
        print()


# ── audit share helpers ───────────────────────────────────────────────


def _truncate_command(cmd: str, max_len: int = 60) -> str:
    if len(cmd) <= max_len:
        return cmd
    return cmd[:max_len] + "..."


def _format_share_detail(entry: dict) -> str:
    res = entry.get("resolution") or {}
    action = res.get("actionTaken", res.get("action_taken", "unknown"))
    suffix = f"[{action}]"
    event_type = entry.get("eventType", entry.get("event_type", ""))
    sc = entry.get("securityCheck") or entry.get("security_check") or {}
    action_block = entry.get("action") or {}

    if event_type == "secret_detected":
        reason = sc.get("reason", "")
        return f"{reason} {suffix}"

    if action_block.get("command"):
        return f"{_truncate_command(action_block['command'])} {suffix}"

    if sc.get("reason"):
        return f"{sc['reason']} {suffix}"

    return suffix


def _audit_share() -> None:
    version = __version__
    os_info = f"{platform.system().lower()}/{platform.machine()}"
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

    manager = ConfigManager()
    cfg = manager.load_with_policy()
    patterns = cfg.agent.command_policy.require_approval if cfg.agent and cfg.agent.command_policy else []
    risk_level = cfg.agent.risk_level if cfg.agent else "moderate"

    payload = json.dumps(sorted(patterns))
    policy_hash = hashlib.sha256(payload.encode()).hexdigest()[:16]

    logger = AuditLogger()
    entries = logger.read(limit=5)

    lines = [
        "Rafter Audit Excerpt",
        f"Generated: {timestamp}",
        "",
        "Environment:",
        f"  CLI:    {version}",
        f"  OS:     {os_info}",
        f"  Policy: sha256:{policy_hash} ({risk_level})",
        "",
        "Recent events (last 5):",
    ]

    if not entries:
        lines.append("  (no entries)")
    else:
        for e in entries:
            ts = e.get("timestamp", "")
            try:
                ts = datetime.fromisoformat(ts.replace("Z", "+00:00")).strftime("%Y-%m-%dT%H:%M:%S.000Z")
            except Exception:
                pass
            event_type = e.get("eventType", e.get("event_type", "unknown"))
            event_pad = event_type.ljust(20)
            risk_raw = (e.get("action") or {}).get("riskLevel", (e.get("action") or {}).get("risk_level", "low"))
            risk_pad = risk_raw.upper().ljust(8)
            detail = _format_share_detail(e)
            lines.append(f"  {ts}  {event_pad}  {risk_pad} {detail}")

    lines.append("")
    lines.append("Share this excerpt when reporting issues at https://github.com/Raftersecurity/rafter-cli/issues")

    print("\n".join(lines))


# ── exec ─────────────────────────────────────────────────────────────


@agent_app.command("exec")
def exec_cmd(
    command: str = typer.Argument(..., help="Command to execute"),
    skip_scan: bool = typer.Option(False, "--skip-scan", help="Skip pre-execution file scanning"),
    force: bool = typer.Option(False, "--force", help="Skip approval prompts"),
):
    """Execute command with security validation."""
    interceptor = CommandInterceptor()
    evaluation = interceptor.evaluate(command)

    # Blocked
    if not evaluation.allowed and not evaluation.requires_approval:
        rprint(f"\n{fmt.error('Command BLOCKED')}\n")
        print(f"Risk Level: {evaluation.risk_level.upper()}", file=sys.stderr)
        print(f"Reason: {evaluation.reason}", file=sys.stderr)
        print(f"Command: {command}\n", file=sys.stderr)
        interceptor.log_evaluation(evaluation, "blocked")
        raise typer.Exit(code=1)

    # Pre-exec scan for git commands
    if not skip_scan and command.strip().startswith(("git commit", "git push")):
        try:
            staged = subprocess.run(
                ["git", "diff", "--cached", "--name-only"],
                capture_output=True, text=True,
            ).stdout.strip().split("\n")
            staged = [f for f in staged if f]
            if staged:
                scanner = RegexScanner()
                results = scanner.scan_files(staged)
                total = sum(len(r.matches) for r in results)
                if results:
                    rprint(f"\n{fmt.warning('Secrets detected in staged files!')}\n")
                    print(f"Found {total} secret(s) in {len(results)} file(s)", file=sys.stderr)
                    rprint(f"\nRun 'rafter secrets' for details.\n")
                    interceptor.log_evaluation(evaluation, "blocked")
                    raise typer.Exit(code=1)
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

    # Requires approval
    if evaluation.requires_approval and not force:
        rprint(f"\n{fmt.warning('Command requires approval')}\n")
        print(f"Risk Level: {evaluation.risk_level.upper()}")
        print(f"Command: {command}")
        if evaluation.reason:
            print(f"Reason: {evaluation.reason}")
        print()

        answer = input("Approve this command? (yes/no): ").strip().lower()
        if answer not in ("yes", "y"):
            rprint(f"\n{fmt.error('Command cancelled')}\n")
            interceptor.log_evaluation(evaluation, "blocked")
            raise typer.Exit(code=1)

        rprint(f"\n{fmt.success('Command approved by user')}\n")
        interceptor.log_evaluation(evaluation, "overridden")
    elif force and evaluation.requires_approval:
        rprint(f"\n{fmt.warning('Forcing execution (--force flag)')}\n")
        interceptor.log_evaluation(evaluation, "overridden")
    else:
        interceptor.log_evaluation(evaluation, "allowed")

    # Execute
    try:
        import shlex
        subprocess.run(shlex.split(command), check=True)
        rprint(f"\n{fmt.success('Command executed successfully')}\n")
    except subprocess.CalledProcessError as e:
        rprint(f"\n{fmt.error(f'Command failed with exit code {e.returncode}')}\n")
        raise typer.Exit(code=e.returncode or 1)


# ── install-hook ──────────────────────────────────────────────────────


def _get_hook_template(hook_name: str = "pre-commit") -> str:
    """Read the bundled hook shell template."""
    filename = f"{hook_name}-hook.sh"
    ref = importlib.resources.files("rafter_cli.resources").joinpath(filename)
    return ref.read_text(encoding="utf-8")


@agent_app.command("install-hook")
def install_hook(
    global_: bool = typer.Option(False, "--global", help="Install globally for all repos (via git config)"),
    push: bool = typer.Option(False, "--push", help="Install pre-push hook instead of pre-commit"),
):
    """Install git hook to scan for secrets."""
    hook_name = "pre-push" if push else "pre-commit"
    if global_:
        _install_global_hook(hook_name)
    else:
        _install_local_hook(hook_name)


def _install_local_hook(hook_name: str = "pre-commit") -> None:
    """Install hook for the current repository."""
    try:
        git_dir = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
    except subprocess.CalledProcessError:
        rprint(fmt.error("Not in a git repository"))
        print("   Run this command from inside a git repository", file=sys.stderr)
        raise typer.Exit(code=1)

    hooks_dir = Path(git_dir).resolve() / "hooks"
    hook_path = hooks_dir / hook_name

    hooks_dir.mkdir(parents=True, exist_ok=True)

    if hook_path.exists():
        existing = hook_path.read_text(encoding="utf-8")
        marker = f"Rafter Security Pre-{'Push' if hook_name == 'pre-push' else 'Commit'} Hook"
        if marker in existing:
            rprint(fmt.success(f"Rafter {hook_name} hook already installed"))
            return
        import time
        backup_path = hook_path.with_name(f"{hook_name}.backup-{int(time.time() * 1000)}")
        hook_path.rename(backup_path)
        rprint(fmt.info(f"Backed up existing hook to: {backup_path.name}"))

    hook_content = _get_hook_template(hook_name)
    hook_path.write_text(hook_content, encoding="utf-8")
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    rprint(fmt.success(f"Installed Rafter {hook_name} hook"))
    rprint(f"  Location: {hook_path}")
    rprint()
    rprint("The hook will:")
    if hook_name == "pre-push":
        rprint("  - Scan commits being pushed for secrets")
        rprint("  - Block pushes if secrets are detected")
        rprint("  - Can be bypassed with: git push --no-verify (not recommended)")
    else:
        rprint("  - Scan staged files for secrets before each commit")
        rprint("  - Block commits if secrets are detected")
        rprint("  - Can be bypassed with: git commit --no-verify (not recommended)")
    rprint()


def _install_global_hook(hook_name: str = "pre-commit") -> None:
    """Install hook globally for all repositories."""
    home = Path.home()
    global_hooks_dir = home / ".rafter" / "git-hooks"
    hook_path = global_hooks_dir / hook_name

    global_hooks_dir.mkdir(parents=True, exist_ok=True)

    hook_content = _get_hook_template(hook_name)
    hook_path.write_text(hook_content, encoding="utf-8")
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    try:
        subprocess.run(
            ["git", "config", "--global", "core.hooksPath", str(global_hooks_dir)],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError:
        rprint(fmt.error("Failed to configure global git hooks"))
        print(f"   Manually run: git config --global core.hooksPath {global_hooks_dir}", file=sys.stderr)
        raise typer.Exit(code=1)

    rprint(fmt.success(f"Installed Rafter {hook_name} hook globally"))
    rprint(f"  Location: {hook_path}")
    rprint(f"  Git config: core.hooksPath = {global_hooks_dir}")
    rprint()
    rprint("The hook will apply to ALL git repositories on this machine.")
    rprint()
    rprint("To disable globally:")
    rprint("  git config --global --unset core.hooksPath")
    rprint()
    rprint("To install per-repository instead:")
    push_flag = " --push" if hook_name == "pre-push" else ""
    rprint(f"  cd <repo> && rafter agent install-hook{push_flag}")
    rprint()


# ── verify ──────────────────────────────────────────────────────────


@dataclass
class _CheckResult:
    name: str
    passed: bool
    detail: str
    optional: bool = False  # optional checks warn but don't fail exit code


def _check_gitleaks() -> _CheckResult:
    """Check if gitleaks is available and executable. Checks PATH first, then ~/.rafter/bin."""
    name = "Gitleaks"
    # Check PATH first (e.g. Homebrew), then fall back to rafter-managed binary
    gitleaks_path = shutil.which("gitleaks")
    if not gitleaks_path:
        rafter_bin = Path.home() / ".rafter" / "bin" / "gitleaks"
        if rafter_bin.exists():
            gitleaks_path = str(rafter_bin)
    if not gitleaks_path:
        return _CheckResult(name, False, f"Not found on PATH or at {Path.home() / '.rafter' / 'bin' / 'gitleaks'}")

    # Verify the found binary actually works
    bm = BinaryManager()
    result = bm.verify_gitleaks_verbose(binary_path=Path(gitleaks_path))
    if result["ok"]:
        return _CheckResult(name, True, result["stdout"] or gitleaks_path)

    detail = f"Found at {gitleaks_path} but failed to execute"
    if result["stdout"]:
        detail += f"\n   stdout: {result['stdout']}"
    if result["stderr"]:
        detail += f"\n   stderr: {result['stderr']}"
    diag = bm.collect_binary_diagnostics(binary_path=Path(gitleaks_path))
    if diag:
        detail += f"\n{diag}"
    return _CheckResult(name, False, detail)


def _check_config() -> _CheckResult:
    """Check if ~/.rafter/config.json exists and is valid."""
    name = "Config"
    config_path = Path.home() / ".rafter" / "config.json"

    if not config_path.exists():
        return _CheckResult(name, False, f"Not found: {config_path}")

    try:
        json.loads(config_path.read_text())
        return _CheckResult(name, True, str(config_path))
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Invalid: {config_path} — {e}")


def _check_claude_code() -> _CheckResult:
    """Check if Claude Code integration is healthy."""
    name = "Claude Code"
    home = Path.home()
    claude_dir = home / ".claude"

    if not claude_dir.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-claude-code' to enable", optional=True)

    settings_path = claude_dir / "settings.json"
    if not settings_path.exists():
        return _CheckResult(name, False, f"Settings file not found: {settings_path}", optional=True)

    try:
        settings = json.loads(settings_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Cannot read settings: {e}", optional=True)

    # Python install writes an absolute path (/home/foo/bin/rafter hook
    # pretool), Node writes the bare `rafter hook pretool`. Substring match
    # accepts both.
    hooks = settings.get("hooks", {}).get("PreToolUse", [])
    has_rafter = any(
        any("rafter hook pretool" in str(h.get("command", "")) for h in (entry.get("hooks") or []))
        for entry in hooks
    )
    if not has_rafter:
        return _CheckResult(name, False, "Rafter hooks not installed — run 'rafter agent init --with-claude-code'", optional=True)
    return _CheckResult(name, True, "Hooks installed")


def _check_openclaw() -> _CheckResult:
    """Check if OpenClaw integration is healthy.

    rf-zgwj: ClawHub auto-discovers skills from
    ~/.openclaw/workspace/skills/<name>/SKILL.md. Detect platform via
    ~/.openclaw, then verify the skill at the canonical path.
    """
    name = "OpenClaw"
    home = Path.home()
    openclaw_root = home / ".openclaw"

    if not openclaw_root.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-openclaw' to enable", optional=True)

    skill_path = openclaw_root / "workspace" / "skills" / "rafter-security" / "SKILL.md"
    if not skill_path.exists():
        legacy = openclaw_root / "skills" / "rafter-security.md"
        if legacy.exists():
            return _CheckResult(
                name,
                False,
                f"Legacy skill at {legacy} (not loaded by OpenClaw) — re-run 'rafter agent init --with-openclaw' to migrate to {skill_path}",
                optional=True,
            )
        return _CheckResult(name, False, "Rafter skill not installed — run 'rafter agent init --with-openclaw'", optional=True)

    version = ""
    try:
        content = skill_path.read_text(encoding="utf-8")
        match = re.search(r"^version:\s*(.+)$", content, re.MULTILINE)
        if match:
            version = match.group(1).strip()
    except OSError:
        pass

    detail = f"Rafter skill installed{f' (v{version})' if version else ''}"
    return _CheckResult(name, True, detail)


def _check_codex() -> _CheckResult:
    """Check if Codex CLI integration is healthy."""
    name = "Codex CLI"
    home = Path.home()

    if not (home / ".codex").exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-codex' to enable", optional=True)

    skill_path = home / ".agents" / "skills" / "rafter" / "SKILL.md"
    if not skill_path.exists():
        return _CheckResult(name, False, "Rafter skills not installed — run 'rafter agent init --with-codex'", optional=True)

    return _CheckResult(name, True, f"Skills installed ({home / '.agents' / 'skills'})")


def _check_gemini() -> _CheckResult:
    """Check if Gemini CLI integration is healthy (rf-65zg Python parity)."""
    name = "Gemini CLI"
    home = Path.home()
    gemini_dir = home / ".gemini"

    if not gemini_dir.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-gemini' to enable", optional=True)

    settings_path = gemini_dir / "settings.json"
    if not settings_path.exists():
        return _CheckResult(name, False, f"Settings file not found: {settings_path} — run 'rafter agent init --with-gemini'", optional=True)

    try:
        settings = json.loads(settings_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Cannot read settings: {e}", optional=True)

    if not settings.get("mcpServers", {}).get("rafter"):
        return _CheckResult(name, False, "Rafter MCP server not configured — run 'rafter agent init --with-gemini'", optional=True)
    return _CheckResult(name, True, "MCP server configured")


def _check_cursor() -> _CheckResult:
    """Check if Cursor integration is healthy (rf-65zg Python parity)."""
    name = "Cursor"
    home = Path.home()
    cursor_dir = home / ".cursor"

    if not cursor_dir.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-cursor' to enable", optional=True)

    mcp_path = cursor_dir / "mcp.json"
    if not mcp_path.exists():
        return _CheckResult(name, False, f"MCP config not found: {mcp_path} — run 'rafter agent init --with-cursor'", optional=True)

    try:
        cfg = json.loads(mcp_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Cannot read config: {e}", optional=True)

    if not cfg.get("mcpServers", {}).get("rafter"):
        return _CheckResult(name, False, "Rafter MCP server not configured — run 'rafter agent init --with-cursor'", optional=True)
    return _CheckResult(name, True, "MCP server configured")


def _check_windsurf() -> _CheckResult:
    """Check if Windsurf integration is healthy (rf-65zg Python parity)."""
    name = "Windsurf"
    home = Path.home()
    windsurf_dir = home / ".codeium" / "windsurf"

    if not windsurf_dir.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-windsurf' to enable", optional=True)

    mcp_path = windsurf_dir / "mcp_config.json"
    if not mcp_path.exists():
        return _CheckResult(name, False, f"MCP config not found: {mcp_path} — run 'rafter agent init --with-windsurf'", optional=True)

    try:
        cfg = json.loads(mcp_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Cannot read config: {e}", optional=True)

    if not cfg.get("mcpServers", {}).get("rafter"):
        return _CheckResult(name, False, "Rafter MCP server not configured — run 'rafter agent init --with-windsurf'", optional=True)
    return _CheckResult(name, True, "MCP server configured")


def _check_continue_dev() -> _CheckResult:
    """Check if Continue.dev integration is healthy (rf-65zg)."""
    name = "Continue.dev"
    home = Path.home()
    continue_dir = home / ".continue"

    if not continue_dir.exists():
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-continue' to enable", optional=True)

    config_path = continue_dir / "config.json"
    if not config_path.exists():
        return _CheckResult(name, False, f"MCP config not found: {config_path} — run 'rafter agent init --with-continue'", optional=True)

    try:
        cfg = json.loads(config_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        return _CheckResult(name, False, f"Cannot read config: {e}", optional=True)

    servers = cfg.get("mcpServers")
    has_rafter = False
    if isinstance(servers, list):
        has_rafter = any(s.get("name") == "rafter" for s in servers if isinstance(s, dict))
    elif isinstance(servers, dict):
        has_rafter = "rafter" in servers
    if not has_rafter:
        return _CheckResult(name, False, "Rafter MCP server not configured — run 'rafter agent init --with-continue'", optional=True)
    return _CheckResult(name, True, "MCP server configured")


def _check_aider() -> _CheckResult:
    """Check if Aider integration is healthy (rf-65zg).

    Aider has no platform dir; presence of .aider.conf.yml is the signal. We
    prefer a project-local config (rf-du2o ships at --local scope too); fall
    back to ~/.aider.conf.yml.
    """
    name = "Aider"
    home = Path.home()
    user_conf = home / ".aider.conf.yml"
    project_conf = Path.cwd() / ".aider.conf.yml"

    conf = project_conf if project_conf.exists() else user_conf if user_conf.exists() else None
    if conf is None:
        return _CheckResult(name, False, "Not detected — run 'rafter agent init --with-aider' to enable", optional=True)

    try:
        raw = conf.read_text()
    except OSError as e:
        return _CheckResult(name, False, f"Cannot read config: {e}", optional=True)

    try:
        parsed = yaml.safe_load(raw) or {}
    except yaml.YAMLError:
        if "RAFTER.md" not in raw:
            return _CheckResult(name, False, "RAFTER.md not in read: list — run 'rafter agent init --with-aider'", optional=True)
        return _CheckResult(name, True, "RAFTER.md in read: list (config not strict-YAML)")

    reads = parsed.get("read") if isinstance(parsed, dict) else None
    read_list: list[str] = []
    if isinstance(reads, list):
        read_list = [str(p) for p in reads]
    elif isinstance(reads, str):
        read_list = [reads]
    if "RAFTER.md" not in read_list:
        return _CheckResult(name, False, f"RAFTER.md not in read: list ({conf}) — run 'rafter agent init --with-aider'", optional=True)

    rafter_md = (project_conf.parent / "RAFTER.md") if conf == project_conf else (user_conf.parent / "RAFTER.md")
    if not rafter_md.exists():
        return _CheckResult(name, False, f"RAFTER.md missing at {rafter_md} — run 'rafter agent init --with-aider'", optional=True)

    return _CheckResult(name, True, f"RAFTER.md + read: entry in {conf}")


def _probe_claude_code() -> _CheckResult:
    """Runtime probe of the Claude Code hook integration (rf-65zg).

    Synthesizes a Claude PreToolUse stdin payload, invokes `rafter hook
    pretool`, and asserts ~/.rafter/audit.jsonl received a
    `command_intercepted` entry for the unique sentinel command. Catches
    the rf-luk-style "wrote file but the command never fires" failure
    without driving Claude Code itself.
    """
    name = "Claude Code (probe)"
    home = Path.home()
    settings_path = home / ".claude" / "settings.json"
    if not settings_path.exists():
        return _CheckResult(name, False, "Not installed — skip", optional=True)

    sentinel = f"rafter-probe-{os.getpid()}-{int(time.time() * 1000)}"
    probe_command = f"rm -rf /tmp/{sentinel}"
    payload = json.dumps({
        "session_id": sentinel,
        "transcript_path": "",
        "cwd": str(Path.cwd()),
        "permission_mode": "default",
        "hook_event_name": "PreToolUse",
        "tool_name": "Bash",
        "tool_input": {"command": probe_command},
    })

    audit_path = home / ".rafter" / "audit.jsonl"
    size_before = audit_path.stat().st_size if audit_path.exists() else 0

    try:
        result = subprocess.run(
            [sys.executable, "-m", "rafter_cli", "hook", "pretool"],
            input=payload,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        return _CheckResult(name, False, f"rafter hook pretool failed to spawn: {e}")

    if not audit_path.exists():
        return _CheckResult(name, False, f"Hook ran but {audit_path} was not created (exit={result.returncode})")

    new_content = audit_path.read_text()[size_before:]
    hit = False
    for line in new_content.splitlines():
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        # Audit logger nests the command under entry.action.command; older
        # writers may flatten — accept either shape.
        cmd = str((entry.get("action") or {}).get("command") or entry.get("command") or "")
        if entry.get("eventType") == "command_intercepted" and sentinel in cmd:
            hit = True
            break

    if not hit:
        return _CheckResult(
            name,
            False,
            f'Probe ran (exit={result.returncode}) but no command_intercepted entry for sentinel "{sentinel}" landed in {audit_path}',
        )

    return _CheckResult(name, True, f"Probe fired → command_intercepted recorded in {audit_path}")


@agent_app.command()
def verify(
    json_output: bool = typer.Option(False, "--json", help="Emit results as JSON (one object per check + summary)"),
    probe: bool = typer.Option(
        False,
        "--probe",
        help=(
            "Runtime probe: invoke rafter hook commands with synthetic platform-format "
            "payloads and assert ~/.rafter/audit.jsonl recorded the interception. "
            "Catches the 'wrote file but never fires' failure mode (rf-65zg)."
        ),
    ),
):
    """Check agent security integration status."""
    if not json_output:
        rprint(fmt.header("Rafter Agent Verify"))
        rprint(fmt.divider())
        rprint()

    results = [
        _check_config(),
        _check_gitleaks(),
        _check_claude_code(),
        _check_openclaw(),
        _check_codex(),
        _check_gemini(),
        _check_cursor(),
        _check_windsurf(),
        _check_continue_dev(),
        _check_aider(),
    ]

    if probe:
        # Only Claude Code has a probe today (rf-65zg). Codex/Cursor/Gemini
        # hook payloads can be added in follow-ups.
        results.append(_probe_claude_code())

    hard_failed = [r for r in results if not r.passed and not r.optional]
    warned = [r for r in results if not r.passed and r.optional]
    passed = [r for r in results if r.passed]

    if json_output:
        payload = {
            "checks": [
                {
                    "name": r.name,
                    "status": "pass" if r.passed else "warn" if r.optional else "fail",
                    "detail": r.detail,
                }
                for r in results
            ],
            "summary": {
                "passed": len(passed),
                "warned": len(warned),
                "failed": len(hard_failed),
                "total": len(results),
                "probe": probe,
            },
        }
        sys.stdout.write(json.dumps(payload) + "\n")
    else:
        for r in results:
            if r.passed:
                rprint(fmt.success(f"{r.name}: {r.detail}"))
            elif r.optional:
                rprint(fmt.warning(f"{r.name}: {r.detail}"))
            else:
                rprint(fmt.error(f"{r.name}: FAIL — {r.detail}"))

        rprint()
        if not hard_failed:
            warn_note = f" ({len(warned)} optional check{'s' if len(warned) != 1 else ''} not configured)" if warned else ""
            rprint(fmt.success(f"{len(passed)}/{len(results)} core checks passed{warn_note}"))
        else:
            rprint(fmt.error(f"{len(hard_failed)} check{'s' if len(hard_failed) != 1 else ''} failed"))
        rprint()

    if hard_failed:
        raise typer.Exit(code=1)


# ── audit-skill ──────────────────────────────────────────────────────

# High-risk command patterns for skill auditing
_HIGH_RISK_PATTERNS: list[dict[str, str]] = [
    {"pattern": r"rm\s+-rf\s+/(?!\w)", "name": "rm -rf /"},
    {"pattern": r"sudo\s+rm", "name": "sudo rm"},
    {"pattern": r"curl[^|]*\|\s*(?:ba)?sh", "name": "curl | sh"},
    {"pattern": r"wget[^|]*\|\s*(?:ba)?sh", "name": "wget | sh"},
    {"pattern": r"eval\s*\(", "name": "eval()"},
    {"pattern": r"exec\s*\(", "name": "exec()"},
    {"pattern": r"chmod\s+777", "name": "chmod 777"},
    {"pattern": r":\(\)\{\s*:\|:&\s*\};:", "name": "fork bomb"},
    {"pattern": r"dd\s+if=/dev/(?:zero|random)\s+of=/dev", "name": "dd to device"},
    {"pattern": r"mkfs", "name": "mkfs (format)"},
    {"pattern": r"base64\s+-d[^|]*\|\s*(?:ba)?sh", "name": "base64 decode | sh"},
]


@dataclass
class QuickScanResults:
    secrets: int
    urls: list[str]
    high_risk_commands: list[dict[str, Any]]


def _run_quick_scan(content: str) -> QuickScanResults:
    """Run deterministic security analysis on skill content."""
    # 1. Scan for secrets
    engine = PatternEngine(DEFAULT_SECRET_PATTERNS)
    secret_matches = engine.scan(content)

    # 2. Extract URLs
    url_regex = re.compile(r"https?://[^\s<>\"]+", re.IGNORECASE)
    urls = list(dict.fromkeys(url_regex.findall(content)))  # deduplicate, preserve order

    # 3. Detect high-risk commands
    commands: list[dict[str, Any]] = []
    for hp in _HIGH_RISK_PATTERNS:
        compiled = re.compile(hp["pattern"], re.IGNORECASE)
        for m in compiled.finditer(content):
            line_number = content[:m.start()].count("\n") + 1
            commands.append({"command": hp["name"], "line": line_number})

    return QuickScanResults(
        secrets=len(secret_matches),
        urls=urls,
        high_risk_commands=commands,
    )


def _display_quick_scan(scan: QuickScanResults, skill_name: str) -> None:
    """Render human-readable quick scan results."""
    print("\n\U0001f4ca Quick Scan Results")
    print("\u2550" * 60)

    # Secrets
    if scan.secrets == 0:
        print("\u2713 Secrets: None detected")
    else:
        print(f"\u26a0\ufe0f  Secrets: {scan.secrets} found")
        print("   \u2192 API keys, tokens, or credentials detected")
        print("   \u2192 Run: rafter secrets <path> for details")

    # URLs
    if not scan.urls:
        print("\u2713 External URLs: None")
    else:
        print(f"\u26a0\ufe0f  External URLs: {len(scan.urls)} found")
        for url in scan.urls[:5]:
            print(f"   \u2022 {url}")
        if len(scan.urls) > 5:
            print(f"   ... and {len(scan.urls) - 5} more")

    # High-risk commands
    if not scan.high_risk_commands:
        print("\u2713 High-risk commands: None detected")
    else:
        print(f"\u26a0\ufe0f  High-risk commands: {len(scan.high_risk_commands)} found")
        for cmd in scan.high_risk_commands[:5]:
            print(f"   \u2022 {cmd['command']} (line {cmd['line']})")
        if len(scan.high_risk_commands) > 5:
            print(f"   ... and {len(scan.high_risk_commands) - 5} more")

    print()


def _generate_manual_review_prompt(
    skill_name: str,
    skill_path: str,
    scan: QuickScanResults,
    content: str,
) -> str:
    """Construct a security assessment prompt for external AI review."""
    urls_detail = ""
    if scan.urls:
        urls_detail = "\n  " + "\n  ".join(scan.urls)

    commands_detail = ""
    if scan.high_risk_commands:
        commands_detail = "\n  " + "\n  ".join(
            f"{c['command']} (line {c['line']})" for c in scan.high_risk_commands
        )

    return f"""You are reviewing a Claude Code skill for security issues. Analyze the skill below and provide:

1. **Security Assessment**: Evaluate trustworthiness, identify risks
2. **External Dependencies**: Review URLs, APIs, network calls - are they trustworthy?
3. **Command Safety**: Analyze shell commands - any dangerous patterns?
4. **Bundled Resources**: Check for suspicious scripts, images, binaries
5. **Prompt Injection Risks**: Could malicious input exploit this skill?
6. **Data Exfiltration**: Does it send sensitive data externally?
7. **Credential Handling**: How are API keys/secrets managed?
8. **Input Validation**: Is user input properly sanitized?
9. **File System Access**: What files does it read/write?
10. **Scope Alignment**: Does behavior match stated purpose?
11. **Recommendations**: Should I install this? What precautions?

**Skill**: {skill_name}
**Path**: {skill_path}

**Quick Scan Findings**:
- Secrets detected: {scan.secrets}
- External URLs: {len(scan.urls)}{urls_detail}
- High-risk commands: {len(scan.high_risk_commands)}{commands_detail}

**Skill Content**:
```markdown
{content}
```

Provide a clear risk rating (LOW/MEDIUM/HIGH/CRITICAL) and actionable recommendations."""


@agent_app.command("audit-skill")
def audit_skill(
    skill_path: str = typer.Argument(..., help="Path to skill file to audit"),
    skip_openclaw: bool = typer.Option(False, "--skip-openclaw", help="Skip OpenClaw integration, show manual review prompt"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """[deprecated] Security audit of a Claude Code skill file — use `rafter skill review` instead."""
    if not json_output:
        print(
            "[deprecated] `rafter agent audit-skill` is deprecated; use `rafter skill review <path-or-url>` instead.",
            file=sys.stderr,
        )
    # Validate skill file exists
    resolved = Path(skill_path).resolve()
    if not resolved.exists():
        print(f"Error: Skill file not found: {skill_path}", file=sys.stderr)
        raise typer.Exit(code=2)

    skill_content = resolved.read_text(encoding="utf-8")
    skill_name = resolved.name

    # Run deterministic analysis
    if not json_output:
        print(f"\n\U0001f50d Auditing skill: {skill_name}\n")
        print("\u2550" * 60)
        print("Running quick security scan...\n")

    quick_scan = _run_quick_scan(skill_content)

    # Display quick scan results
    if not json_output:
        _display_quick_scan(quick_scan, skill_name)

    # Check OpenClaw availability
    skill_manager = SkillManager()
    openclaw_available = skill_manager.is_openclaw_installed()
    rafter_skill_installed = skill_manager.is_rafter_skill_installed()

    if json_output:
        result = {
            "skill": skill_name,
            "path": str(resolved),
            "quickScan": {
                "secrets": quick_scan.secrets,
                "urls": quick_scan.urls,
                "highRiskCommands": quick_scan.high_risk_commands,
            },
            "openClawAvailable": openclaw_available,
            "rafterSkillInstalled": rafter_skill_installed,
        }
        has_findings = quick_scan.secrets > 0 or len(quick_scan.high_risk_commands) > 0
        print(json.dumps(result, indent=2))
        raise typer.Exit(code=1 if has_findings else 0)

    # Check if we can use OpenClaw
    if openclaw_available and not skip_openclaw:
        if not rafter_skill_installed:
            print("\n\u26a0\ufe0f  Rafter Security skill not installed in OpenClaw.")
            print("   Run: rafter agent init\n")
        else:
            print("\n\U0001f916 For comprehensive security review:\n")
            print("   1. Open OpenClaw")
            print(f"   2. Run: /rafter-audit-skill {resolved}")
            print("\n   The auditor will analyze:")
            print("   \u2022 Trust & attribution")
            print("   \u2022 Network security")
            print("   \u2022 Command execution risks")
            print("   \u2022 File system access")
            print("   \u2022 Credential handling")
            print("   \u2022 Input validation & injection risks")
            print("   \u2022 Data exfiltration patterns")
            print("   \u2022 Obfuscation techniques")
            print("   \u2022 Scope & intent alignment")
            print("   \u2022 Error handling & info disclosure")
            print("   \u2022 Dependencies & supply chain")
            print("   \u2022 Environment manipulation\n")
    else:
        # OpenClaw not available or skipped — show manual review prompt
        print("\n\U0001f4cb Manual Security Review Prompt\n")
        print("\u2550" * 60)
        print("\nCopy the following to your AI assistant for review:\n")
        print("\u2500" * 60)
        print(_generate_manual_review_prompt(skill_name, str(resolved), quick_scan, skill_content))
        print("\u2500" * 60)

    print()

    if quick_scan.secrets > 0 or len(quick_scan.high_risk_commands) > 0:
        raise typer.Exit(code=1)


# ── update-gitleaks ──────────────────────────────────────────────────────


@agent_app.command("update-gitleaks")
def update_gitleaks(
    version: str = typer.Option(
        None,
        "--version",
        help="Gitleaks version to install (default: bundled version)",
    ),
):
    """Update (or reinstall) the managed gitleaks binary."""
    from ..utils.binary_manager import GITLEAKS_VERSION

    target_version = version or GITLEAKS_VERSION
    _bm = BinaryManager()

    if not _bm.is_platform_supported():
        rprint(fmt.error(
            f"Gitleaks not available for {_bm._sys_platform()}/{_bm._machine()}"
        ))
        raise typer.Exit(code=1)

    # Show current version if installed
    _rafter_bin = _bm.get_gitleaks_path()
    if _rafter_bin.exists():
        result = _bm.verify_gitleaks_verbose()
        if result["ok"]:
            rprint(fmt.info(f"Current: {result['stdout']}"))
        else:
            rprint(fmt.warning(f"Current binary at {_rafter_bin} is not working"))
    else:
        rprint(fmt.info("Gitleaks not currently installed (managed binary)"))

    rprint(fmt.info(f"Installing gitleaks v{target_version}..."))
    rprint()

    try:
        _bm.download_gitleaks(on_progress=typer.echo, version=target_version)
        rprint()
        result = _bm.verify_gitleaks_verbose()
        rprint(fmt.success(f"Gitleaks updated: {result['stdout']}"))
        rprint(fmt.info(f"  Binary: {_rafter_bin}"))
    except Exception as _err:
        rprint()
        rprint(fmt.error(f"Update failed: {_err}"))
        rprint(fmt.info(
            "To fix: install gitleaks manually "
            "(https://github.com/gitleaks/gitleaks/releases) "
            "and ensure it is on PATH."
        ))
        raise typer.Exit(code=1)


# ── agent status ─────────────────────────────────────────────────────────

@agent_app.command("status")
def status():
    """Show agent security status dashboard."""
    from ..core.config_schema import get_audit_log_path, get_rafter_dir

    rafter_dir = get_rafter_dir()
    audit_path = get_audit_log_path()

    print("Rafter Agent Status")
    print("=" * 50)

    # --- Config ---
    config_path = rafter_dir / "config.json"
    if config_path.exists():
        try:
            cfg = ConfigManager().load()
            print(f"\nConfig:       {config_path}")
            print(f"Risk level:   {cfg.agent.risk_level}")
        except Exception:
            print(f"\nConfig:       {config_path} (parse error)")
    else:
        print(f"\nConfig:       not found — run: rafter agent init")

    # --- Gitleaks ---
    gl_path = shutil.which("gitleaks") or str(rafter_dir / "bin" / "gitleaks")
    if shutil.which("gitleaks"):
        try:
            ver = subprocess.run(["gitleaks", "version"], capture_output=True, text=True, timeout=5)
            print(f"Gitleaks:     {ver.stdout.strip()} (PATH)")
        except Exception:
            print("Gitleaks:     on PATH (version check failed)")
    elif Path(gl_path).exists():
        print(f"Gitleaks:     {gl_path} (local)")
    else:
        print("Gitleaks:     not found — run: rafter agent init --with-gitleaks")

    # --- Claude Code hooks ---
    claude_dir = Path.home() / ".claude"
    settings_path = claude_dir / "settings.json"
    pretool_ok = posttool_ok = False
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
            hooks = settings.get("hooks", {})
            for hook_entry in hooks.get("PreToolUse", []):
                for h in hook_entry.get("hooks", []):
                    if "rafter hook pretool" in h.get("command", ""):
                        pretool_ok = True
            for hook_entry in hooks.get("PostToolUse", []):
                for h in hook_entry.get("hooks", []):
                    if "rafter hook posttool" in h.get("command", ""):
                        posttool_ok = True
        except Exception:
            pass
    pretool_status = "installed" if pretool_ok else "not installed — run: rafter agent init --with-claude-code"
    posttool_status = "installed" if posttool_ok else "not installed — run: rafter agent init --with-claude-code"
    print(f"PreToolUse:   {pretool_status}")
    print(f"PostToolUse:  {posttool_status}")

    # --- OpenClaw skill ---
    skill_path = Path.home() / ".openclaw" / "skills" / "rafter-security.md"
    if skill_path.exists():
        print(f"OpenClaw:     skill installed ({skill_path})")
    elif (Path.home() / ".openclaw").exists():
        print("OpenClaw:     detected but skill missing — run: rafter agent init --with-openclaw")
    else:
        print("OpenClaw:     not detected (optional)")

    # --- Codex CLI skills ---
    codex_dir = Path.home() / ".codex"
    codex_skill_path = Path.home() / ".agents" / "skills" / "rafter" / "SKILL.md"
    if codex_skill_path.exists():
        print(f"Codex CLI:    skills installed ({Path.home() / '.agents' / 'skills'})")
    elif codex_dir.exists():
        print("Codex CLI:    detected but skills missing — run: rafter agent init --with-codex")
    else:
        print("Codex CLI:    not detected (optional)")

    # --- MCP-native AI engine integrations ---
    home = Path.home()
    mcp_agents = [
        {"name": "Gemini CLI", "flag": "--with-gemini", "config_dir": home / ".gemini", "config_file": home / ".gemini" / "settings.json", "needle": "rafter"},
        {"name": "Cursor", "flag": "--with-cursor", "config_dir": home / ".cursor", "config_file": home / ".cursor" / "mcp.json", "needle": "rafter"},
        {"name": "Windsurf", "flag": "--with-windsurf", "config_dir": home / ".codeium" / "windsurf", "config_file": home / ".codeium" / "windsurf" / "mcp_config.json", "needle": "rafter"},
        {"name": "Continue.dev", "flag": "--with-continue", "config_dir": home / ".continue", "config_file": home / ".continue" / "config.json", "needle": "rafter"},
    ]

    for agent in mcp_agents:
        label = f"{agent['name']}:".ljust(14)
        config_file = agent["config_file"]
        config_dir = agent["config_dir"]
        if config_file.exists():
            try:
                content = config_file.read_text()
                if agent["needle"] in content:
                    print(f"{label}MCP installed ({config_file})")
                else:
                    print(f"{label}detected but MCP missing — run: rafter agent init {agent['flag']}")
            except OSError:
                print(f"{label}config unreadable ({config_file})")
        elif config_dir.exists():
            print(f"{label}detected but MCP missing — run: rafter agent init {agent['flag']}")
        else:
            print(f"{label}not detected (optional)")

    # --- Aider ---
    aider_config = home / ".aider.conf.yml"
    if aider_config.exists():
        try:
            content = aider_config.read_text()
            if "rafter mcp serve" in content:
                print(f"Aider:        MCP installed ({aider_config})")
            else:
                print("Aider:        detected but MCP missing — run: rafter agent init --with-aider")
        except OSError:
            print(f"Aider:        config unreadable ({aider_config})")
    else:
        print("Aider:        not detected (optional)")

    # --- Audit log summary ---
    print(f"\nAudit log:    {audit_path}")
    if audit_path.exists():
        logger = AuditLogger()
        all_entries = logger.read()
        total = len(all_entries)
        secrets = sum(1 for e in all_entries if e.get("eventType", e.get("event_type")) == "secret_detected")
        blocked = sum(1 for e in all_entries if e.get("eventType", e.get("event_type")) == "command_intercepted"
                      and (e.get("resolution") or {}).get("actionTaken", (e.get("resolution") or {}).get("action_taken")) == "blocked")
        print(f"Total events: {total}  |  Secrets detected: {secrets}  |  Commands blocked: {blocked}")

        recent = logger.read(limit=5)
        if recent:
            print("\nRecent events:")
            for e in reversed(recent):
                ts = e.get("timestamp", "")[:19].replace("T", " ")
                evt = e.get("eventType", e.get("event_type", "unknown"))
                action = (e.get("resolution") or {}).get("actionTaken", (e.get("resolution") or {}).get("action_taken", ""))
                print(f"  {ts}  {evt}  [{action}]")
    else:
        print("No events logged yet.")

    print()


# ── baseline ─────────────────────────────────────────────────────────

_BASELINE_PATH = Path.home() / ".rafter" / "baseline.json"

baseline_app = typer.Typer(name="baseline", help="Manage the findings baseline (allowlist for known findings)", no_args_is_help=True)
agent_app.add_typer(baseline_app)


def _load_baseline() -> dict:
    if not _BASELINE_PATH.exists():
        return {"version": 1, "created": "", "updated": "", "entries": []}
    try:
        return json.loads(_BASELINE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"version": 1, "created": "", "updated": "", "entries": []}


def _save_baseline(data: dict) -> None:
    _BASELINE_PATH.parent.mkdir(parents=True, exist_ok=True)
    _BASELINE_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _load_baseline_entries() -> list[dict]:
    return _load_baseline().get("entries", [])


def _apply_baseline(results: list[ScanResult], entries: list[dict]) -> list[ScanResult]:
    if not entries:
        return results
    filtered = []
    for r in results:
        kept = [
            m for m in r.matches
            if not any(
                e["file"] == r.file
                and e["pattern"] == m.pattern.name
                and (e.get("line") is None or e.get("line") == m.line)
                for e in entries
            )
        ]
        if kept:
            filtered.append(ScanResult(file=r.file, matches=kept))
    return filtered


@baseline_app.command("create")
def baseline_create(
    path: str = typer.Argument(".", help="Path to scan"),
    engine: str = typer.Option("auto", "--engine", help="gitleaks or patterns"),
):
    """Scan and save all current findings as the baseline."""
    import datetime
    resolved = os.path.abspath(path)
    if not os.path.exists(resolved):
        print(f"Error: Path not found: {resolved}", file=sys.stderr)
        raise typer.Exit(code=2)

    manager = ConfigManager()
    cfg = manager.load_with_policy()
    scan_cfg = cfg.agent.scan

    print(f"Scanning {resolved} to build baseline...", file=sys.stderr)

    eng = _select_engine(engine, quiet=False)
    if os.path.isdir(resolved):
        results = _scan_directory(resolved, eng, scan_cfg)
    else:
        custom_patterns = (
            [{"name": p.name, "regex": p.regex, "severity": p.severity} for p in scan_cfg.custom_patterns]
            if scan_cfg.custom_patterns else None
        )
        results = _scan_file(resolved, eng, custom_patterns)

    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    entries = []
    for r in results:
        for m in r.matches:
            entries.append({"file": r.file, "line": m.line, "pattern": m.pattern.name, "addedAt": now})

    existing = _load_baseline()
    data = {
        "version": 1,
        "created": existing.get("created") or now,
        "updated": now,
        "entries": entries,
    }
    _save_baseline(data)

    if not entries:
        rprint(fmt.success("No findings — baseline is empty (all clean)"))
    else:
        rprint(fmt.success(f"Baseline saved: {len(entries)} finding(s) recorded"))
        rprint(f"  Location: {_BASELINE_PATH}")
        rprint()
        rprint("Future scans with --baseline will suppress these findings.")


@baseline_app.command("show")
def baseline_show(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show current baseline entries."""
    data = _load_baseline()

    if json_out:
        print(json.dumps(data, indent=2))
        return

    entries = data.get("entries", [])
    if not entries:
        print("Baseline is empty. Run: rafter agent baseline create")
        return

    print(f"Baseline: {len(entries)} entries")
    if data.get("updated"):
        print(f"Updated: {data['updated']}")
    print()

    by_file: dict[str, list] = {}
    for e in entries:
        by_file.setdefault(e["file"], []).append(e)

    for file, file_entries in by_file.items():
        rprint(fmt.info(file))
        for e in file_entries:
            loc = f"line {e['line']}" if e.get("line") is not None else "unknown location"
            print(f"  {e['pattern']} ({loc})")
        print()


@baseline_app.command("clear")
def baseline_clear():
    """Remove all baseline entries."""
    if not _BASELINE_PATH.exists():
        print("No baseline file found — nothing to clear.")
        return
    _BASELINE_PATH.unlink()
    rprint(fmt.success("Baseline cleared"))


@baseline_app.command("add")
def baseline_add(
    file: str = typer.Option(..., "--file", help="File path"),
    pattern: str = typer.Option(..., "--pattern", help="Pattern name (e.g. 'AWS Access Key')"),
    line: int = typer.Option(None, "--line", help="Line number"),
):
    """Manually add a finding to the baseline."""
    import datetime
    data = _load_baseline()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()

    entry = {
        "file": os.path.abspath(file),
        "line": line,
        "pattern": pattern,
        "addedAt": now,
    }
    data.setdefault("entries", []).append(entry)
    data["updated"] = now
    if not data.get("created"):
        data["created"] = now
    _save_baseline(data)

    rprint(fmt.success(f"Added to baseline: {pattern} in {file}"))


# ── components: list / enable / disable ──────────────────────────────

from .agent_components import (  # noqa: E402
    _inject_instruction_file,
    get_registry as _components_get_registry,
    record_component_state as _components_record_state,
    resolve_component as _components_resolve,
    snapshot_components as _components_snapshot,
)


@agent_app.command("list")
def components_list(
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON"),
    installed_only: bool = typer.Option(False, "--installed", help="Only show installed components"),
    detected_only: bool = typer.Option(False, "--detected", help="Only show components whose platform is detected"),
):
    """List agent integration components and their state."""
    rows = _components_snapshot()
    if installed_only:
        rows = [r for r in rows if r["installed"]]
    if detected_only:
        rows = [r for r in rows if r["detected"]]

    if json_output:
        print(json.dumps({"components": rows}, indent=2))
        return

    by_platform: dict[str, list[dict]] = {}
    for r in rows:
        by_platform.setdefault(r["platform"], []).append(r)

    rprint(fmt.header("Rafter agent components"))
    rprint(fmt.divider())
    for platform, items in by_platform.items():
        detected = items[0]["detected"] if items else False
        suffix = "" if detected else " (not detected)"
        rprint(f"\n{platform}{suffix}")
        for r in items:
            label = r["id"].ljust(28)
            if r["state"] == "installed":
                marker = "● installed"
            elif r["state"] == "not-installed":
                marker = "○ not installed"
            else:
                marker = "· platform not detected"
            rprint(f"  {label} {marker}")
    rprint()
    rprint(fmt.info(
        "Use `rafter agent enable <id>` or `rafter agent disable <id>` "
        "to toggle individual components.",
    ))


def _known_component_ids_hint() -> str:
    return ", ".join(spec.id for spec in _components_get_registry())


@agent_app.command("enable")
def components_enable(
    components: list[str] = typer.Argument(..., help="Component IDs (e.g. claude-code.mcp, cursor.hooks)"),
    force: bool = typer.Option(False, "--force", help="Install even if platform is not detected"),
):
    """Install a specific agent component."""
    exit_code = 0
    seen: set[str] = set()
    for raw in components:
        if raw in seen:
            continue
        seen.add(raw)

        spec = _components_resolve(raw)
        if spec is None:
            rprint(fmt.error(f"Unknown component: {raw}"), file=sys.stderr)
            rprint(fmt.info(f"Run 'rafter agent list' to see available components. Known IDs: {_known_component_ids_hint()}"), file=sys.stderr)
            exit_code = 1
            continue

        if not spec.detect_dir.exists() and not force:
            rprint(fmt.warning(
                f"{spec.id}: platform not detected ({spec.detect_dir}). "
                f"Re-run with --force to install anyway."
            ), file=sys.stderr)
            exit_code = exit_code or 2
            continue

        try:
            spec.install()
            _components_record_state(spec.id, True)
            rprint(fmt.success(f"Enabled {spec.id} → {spec.path}"))
        except Exception as err:
            rprint(fmt.error(f"Failed to enable {spec.id}: {err}"), file=sys.stderr)
            exit_code = 1

    if exit_code:
        raise typer.Exit(code=exit_code)


@agent_app.command("disable")
def components_disable(
    components: list[str] = typer.Argument(..., help="Component IDs to uninstall"),
):
    """Uninstall a specific agent component."""
    exit_code = 0
    seen: set[str] = set()
    for raw in components:
        if raw in seen:
            continue
        seen.add(raw)

        spec = _components_resolve(raw)
        if spec is None:
            rprint(fmt.error(f"Unknown component: {raw}"), file=sys.stderr)
            rprint(fmt.info(f"Run 'rafter agent list' to see available components. Known IDs: {_known_component_ids_hint()}"), file=sys.stderr)
            exit_code = 1
            continue

        try:
            was_installed = spec.is_installed()
            spec.uninstall()
            _components_record_state(spec.id, False)
            if was_installed:
                rprint(fmt.success(f"Disabled {spec.id} (removed from {spec.path})"))
            else:
                rprint(fmt.info(f"{spec.id} was not installed — no changes"))
        except Exception as err:
            rprint(fmt.error(f"Failed to disable {spec.id}: {err}"), file=sys.stderr)
            exit_code = 1

    if exit_code:
        raise typer.Exit(code=exit_code)
