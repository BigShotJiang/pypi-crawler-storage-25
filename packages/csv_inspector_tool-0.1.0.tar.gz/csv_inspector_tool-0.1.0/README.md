# csv-inspector

A Python package that reads a CSV file and reports:
-- Table Title - derived from the file name
-- Headers - every column name found in the first row
-- Row Counts per Column - total rows, non-empty rows, empty rows, and fill-rate %


# installation

```bash
pip install .
```


# running test

```bash
python -m pytest tests/
```