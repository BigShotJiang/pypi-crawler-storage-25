__version__ = "2.3.1"
APP_TITLE = "Adbnik"
