# moonbit-schema-utils

Lightweight JSON schema validation for MoonBit toolchain configuration files.

## Installation

```bash
pip install moonbit-schema-utils
```

## Usage

```python
from moonbit_schema_utils import validate, SchemaError

schema = {
    "type": "object",
    "required": ["name", "version"],
    "properties": {
        "name": {"type": "string"},
        "version": {"type": "string"},
    },
}

data = {"name": "my-package", "version": "1.0.0"}
validate(data, schema)  # passes silently

try:
    validate({"name": 42}, schema)
except SchemaError as e:
    print(e)  # "Expected type 'string' for 'name', got 'int'"
```

## License

MIT
