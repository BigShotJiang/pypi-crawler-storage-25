"""Lightweight JSON schema validation for MoonBit toolchain configs."""
from .validator import SchemaError, validate, validate_type

__version__ = "1.1.0"
__all__ = ["SchemaError", "validate", "validate_type"]
