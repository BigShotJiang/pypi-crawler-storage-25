"""Minimal JSON schema validator (subset of JSON Schema Draft 7).

Supports: type, required, properties, items, enum, minimum, maximum,
minLength, maxLength, pattern.  Enough for validating MoonBit config
and metrics payloads without pulling in a heavy dependency.
"""
from __future__ import annotations

import re
from typing import Any


class SchemaError(Exception):
    """Raised when data does not conform to the schema."""

    def __init__(self, message: str, path: str = "") -> None:
        self.path = path
        super().__init__(f"{path}: {message}" if path else message)


_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
    "null": type(None),
}


def validate_type(value: Any, expected: str, path: str = "") -> None:
    """Check that *value* matches the JSON Schema *expected* type."""
    python_type = _TYPE_MAP.get(expected)
    if python_type is None:
        return
    if expected == "integer" and isinstance(value, bool):
        raise SchemaError(f"Expected type 'integer', got 'bool'", path)
    if not isinstance(value, python_type):
        actual = type(value).__name__
        raise SchemaError(f"Expected type '{expected}', got '{actual}'", path)


def validate(data: Any, schema: dict, path: str = "") -> None:
    """Validate *data* against a JSON Schema *schema* dict.

    Raises :class:`SchemaError` on the first violation found.
    """
    if not isinstance(schema, dict):
        return

    # type
    schema_type = schema.get("type")
    if isinstance(schema_type, str):
        validate_type(data, schema_type, path)
    elif isinstance(schema_type, list):
        if not any(_matches_type(data, t) for t in schema_type):
            actual = type(data).__name__
            raise SchemaError(
                f"Expected one of types {schema_type}, got '{actual}'", path
            )

    # enum
    if "enum" in schema:
        if data not in schema["enum"]:
            raise SchemaError(
                f"Value {data!r} not in allowed enum {schema['enum']}", path
            )

    # string constraints
    if isinstance(data, str):
        if "minLength" in schema and len(data) < schema["minLength"]:
            raise SchemaError(
                f"String length {len(data)} < minLength {schema['minLength']}",
                path,
            )
        if "maxLength" in schema and len(data) > schema["maxLength"]:
            raise SchemaError(
                f"String length {len(data)} > maxLength {schema['maxLength']}",
                path,
            )
        if "pattern" in schema and not re.search(schema["pattern"], data):
            raise SchemaError(
                f"String does not match pattern '{schema['pattern']}'", path
            )

    # numeric constraints
    if isinstance(data, (int, float)) and not isinstance(data, bool):
        if "minimum" in schema and data < schema["minimum"]:
            raise SchemaError(f"{data} < minimum {schema['minimum']}", path)
        if "maximum" in schema and data > schema["maximum"]:
            raise SchemaError(f"{data} > maximum {schema['maximum']}", path)

    # object
    if isinstance(data, dict):
        for key in schema.get("required", []):
            if key not in data:
                raise SchemaError(f"Missing required key '{key}'", path)

        properties = schema.get("properties", {})
        for key, prop_schema in properties.items():
            if key in data:
                validate(data[key], prop_schema, f"{path}.{key}" if path else key)

    # array
    if isinstance(data, list) and "items" in schema:
        item_schema = schema["items"]
        for index, item in enumerate(data):
            validate(item, item_schema, f"{path}[{index}]")


def _matches_type(value: Any, expected: str) -> bool:
    python_type = _TYPE_MAP.get(expected)
    if python_type is None:
        return True
    if expected == "integer" and isinstance(value, bool):
        return False
    return isinstance(value, python_type)
