from comate_agent_sdk.system_tools.tool_result import err


class TestErrEnvelope:
    def test_err_default_data_is_empty_dict(self):
        result = err("INTERNAL", "broken")
        assert result["data"] == {}

    def test_err_accepts_data_payload(self):
        payload = {"stdout": "partial", "exit_code": 137}
        result = err("TIMEOUT", "timed out", data=payload)
        assert result["ok"] is False
        assert result["data"] == payload

    def test_err_accepts_interrupted(self):
        assert err("INTERRUPTED", "cancelled")["error"]["code"] == "INTERRUPTED"

    def test_err_accepts_precondition_failed(self):
        assert err("PRECONDITION_FAILED", "read first")["error"]["code"] == "PRECONDITION_FAILED"

    def test_err_accepts_policy_denied(self):
        assert err("POLICY_DENIED", "blocked")["error"]["code"] == "POLICY_DENIED"
