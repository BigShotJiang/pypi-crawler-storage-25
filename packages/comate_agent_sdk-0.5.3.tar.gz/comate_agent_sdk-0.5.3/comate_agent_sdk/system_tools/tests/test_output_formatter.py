import unittest

from comate_agent_sdk.context.truncation import TruncationRecord
from comate_agent_sdk.system_tools.output_formatter import OutputFormatter, _default_truncation
from comate_agent_sdk.system_tools.tool_result import err, ok


class TestOutputFormatter(unittest.TestCase):
    def test_format_bash_preserves_preview_without_secondary_truncation(self) -> None:
        preview = "x" * 7000
        payload = ok(
            data={
                "stdout": preview,
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "interrupted": False,
                "killed": False,
                "duration_ms": 12,
                "truncated": False,
                "truncated_reason": None,
            },
            meta={
                "args": ["bash", "-lc", "echo preview"],
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Bash",
            tool_call_id="tc_bash_preview",
            result_dict=payload,
        )

        self.assertIn(preview, formatted.text)
        self.assertNotIn("...(truncated)", formatted.text)

    def test_format_bash_truncated_prefers_read_hint_for_raw_output(self) -> None:
        payload = ok(
            data={
                "stdout": "line1\nline2",
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "interrupted": False,
                "killed": False,
                "duration_ms": 12,
                "truncated": True,
                "truncated_reason": "output_too_large",
                "artifact": {
                    "relpath": ".agent_workspace/.agent/artifacts/bash/abc123.txt",
                    "mime": "text/plain",
                },
                "read_hint": "Use Read with file_path='.agent_workspace/.agent/artifacts/bash/abc123.txt'",
            },
            meta={
                "args": ["bash", "-lc", "long command"],
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Bash",
            tool_call_id="tc_bash_truncated",
            result_dict=payload,
        )

        self.assertIn(".agent_workspace/.agent/artifacts/bash/abc123.txt", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)

    def test_format_read_with_truncation_footer_and_hints(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 1200,
                "lines_returned": 2,
                "has_more": True,
                "next_offset_line": 2,
                "truncated": True,
                "artifact": {"relpath": ".agent_workspace/.artifacts/read/abc.txt"},
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 0,
                "limit_lines": 2,
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_1",
            result_dict=payload,
        )

        self.assertIn("# Read: src/main.py", formatted.text)
        self.assertIn("Lines 1-2 of 1200", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.truncation)
        self.assertIsInstance(formatted.meta.truncation, TruncationRecord)
        self.assertTrue(formatted.meta.truncation.formatter_truncated)
        self.assertEqual(formatted.meta.truncation.formatter_reason, "line_limit")
        self.assertIsNotNone(formatted.meta.retrieval_hints)
        self.assertGreaterEqual(len(formatted.meta.retrieval_hints), 2)

    def test_format_write_includes_file_ops(self) -> None:
        payload = ok(
            data={
                "bytes_written": 12,
                "file_bytes": 40,
                "created": False,
                "sha256": "after_hash",
                "relpath": "src/config.json",
            },
            meta={
                "file_path": "src/config.json",
                "operation": "overwrite",
                "sha256_before": "before_hash",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_1",
            result_dict=payload,
        )

        self.assertIn("# Write: src/config.json", formatted.text)
        self.assertIn("Operation: overwrite", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.file_ops)
        self.assertEqual(formatted.meta.file_ops["operation"], "overwrite")
        self.assertEqual(formatted.meta.file_ops["sha256_after"], "after_hash")

    def test_format_write_prefers_resolved_file_path(self) -> None:
        payload = ok(
            data={
                "bytes_written": 7,
                "file_bytes": 7,
                "created": True,
                "sha256": "after_hash",
                "relpath": "optimize-thinking-blocks-compaction.md",
            },
            meta={
                "file_path": "~/.agent/plans/optimize-thinking-blocks-compaction.md",
                "resolved_file_path": "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
                "operation": "create",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_2",
            result_dict=payload,
        )

        self.assertIn(
            "# Write: /tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
            formatted.text,
        )
        self.assertEqual(
            formatted.meta.file_ops["file_path"],
            "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
        )

    def test_format_error_includes_retry_footer(self) -> None:
        payload = err(
            "INVALID_ARGUMENT",
            "invalid path",
            field_errors=[{"field": "path", "message": "must be absolute"}],
        )
        formatted = OutputFormatter.format(
            tool_name="Grep",
            tool_call_id="tc_grep_1",
            result_dict=payload,
        )

        self.assertIn("# Grep Error", formatted.text)
        self.assertIn("Code: INVALID_ARGUMENT", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "error")
        self.assertEqual(formatted.meta.error_code, "INVALID_ARGUMENT")
        self.assertEqual(formatted.meta.error_field, "path")

    def test_format_ask_user_question(self) -> None:
        payload = ok(
            data={
                "status": "waiting_for_input",
                "questions": [
                    {
                        "question": "Which option?",
                        "header": "Choice",
                        "options": [
                            {"label": "A", "description": "Option A"},
                            {"label": "B", "description": "Option B"},
                        ],
                        "multiSelect": False,
                    }
                ],
            },
            message="Prepared 1 question(s) for user",
        )
        formatted = OutputFormatter.format(
            tool_name="AskUserQuestion",
            tool_call_id="tc_question_1",
            result_dict=payload,
        )

        self.assertIn("# AskUserQuestion", formatted.text)
        self.assertIn("Question count: 1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_default_truncation_returns_truncation_record(self) -> None:
        record = _default_truncation(
            {
                "truncated": True,
                "raw_output_truncated": True,
                "total_matches": 123,
            }
        )
        self.assertIsNotNone(record)
        assert record is not None
        self.assertIsInstance(record, TruncationRecord)
        self.assertTrue(record.formatter_truncated)
        self.assertIn("output_capture_limit", record.formatter_reason)
        self.assertEqual(record.formatter_total_estimate, 123)

    def test_format_read_no_truncation_returns_none(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 2,
                "lines_returned": 2,
                "has_more": False,
                "truncated": False,
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 0,
                "limit_lines": 2,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_no_truncation",
            result_dict=payload,
        )
        self.assertIsNone(formatted.meta.truncation)

    def test_format_read_reused_previous_result_prefers_stub_body(self) -> None:
        payload = ok(
            data={
                "content": "ignored body",
                "total_lines": 200,
                "lines_returned": 0,
                "has_more": False,
                "truncated": False,
                "reused_previous_result": True,
                "reuse_message": "File unchanged since last read. Refer to the earlier Read result.",
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 0,
                "limit_lines": 200,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_reused",
            result_dict=payload,
        )
        self.assertIn("File unchanged since last read", formatted.text)
        self.assertNotIn("ignored body", formatted.text)
        self.assertIsNone(formatted.meta.truncation)

    def test_format_read_output_too_large_error_prefers_read_retry_hint(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget.",
            field_errors=[
                {"field": "offset_line", "message": "Keep the same offset."},
                {"field": "limit_lines", "message": "Reduce the window."},
            ],
            meta={
                "file_path": "docs/wide.md",
                "suggested_offset_line": 0,
                "suggested_limit_lines": 120,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_too_large",
            result_dict=payload,
        )
        self.assertIn("Code: OUTPUT_TOO_LARGE", formatted.text)
        self.assertIn("Meaning: The selected Read slice is too large to return in one result.", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIn('Read(file_path="docs/wide.md", offset_line=0, limit_lines=120)', formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)

    def test_format_read_output_too_large_prefers_max_line_chars_recovery(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget.",
            meta={
                "file_path": "docs/unicode.md",
                "suggested_offset_line": 0,
                "suggested_max_line_chars": 5000,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_too_large_chars",
            result_dict=payload,
        )
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIn(
            'Read(file_path="docs/unicode.md", offset_line=0, limit_lines=1, max_line_chars=5000)',
            formatted.text,
        )
        self.assertNotIn('limit_lines=1)', formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)

    def test_format_task_result_with_open_tasks(self) -> None:
        payload = ok(
            data={
                "list_id": "shared",
                "total": 4,
                "by_status": {
                    "pending": 2,
                    "in_progress": 1,
                "completed": 1,
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Fix authentication bug",
                        "status": "pending",
                        "owner": "andy",
                        "description": "Investigate the auth middleware token parsing path.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "2",
                        "subject": "Add unit tests",
                        "status": "in_progress",
                        "owner": "worker-b",
                        "description": "Cover the edge cases around expired tokens.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "3",
                        "subject": "Update docs",
                        "status": "pending",
                        "owner": "",
                        "open_blocked_by": ["1"],
                    },
                    {
                        "id": "4",
                        "subject": "Refactor code",
                        "status": "completed",
                        "owner": "worker-c",
                        "open_blocked_by": [],
                    },
                ],
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskList",
            tool_call_id="tc_task_1",
            result_dict=payload,
        )

        self.assertIn("# TaskList", formatted.text)
        self.assertIn("Task Namespace: shared", formatted.text)
        self.assertIn("Total tasks: 4", formatted.text)
        self.assertIn("Open Tasks:", formatted.text)
        self.assertIn("- [pending] #1 Fix authentication bug owner=andy", formatted.text)
        self.assertIn("  Description: Investigate the auth middleware token parsing path.", formatted.text)
        self.assertIn("- [in_progress] #2 Add unit tests owner=worker-b", formatted.text)
        self.assertIn("  Description: Cover the edge cases around expired tokens.", formatted.text)
        self.assertIn("blocked_by=#1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_format_task_result_with_selected_task(self) -> None:
        payload = ok(
            data={
                "list_id": "default",
                "task": {
                    "id": "2",
                    "subject": "Finalize release checklist",
                    "status": "completed",
                    "owner": "andy",
                    "description": "Double-check release blockers.",
                    "blocked_by": ["1"],
                    "open_blocked_by": [],
                    "blocks": ["5"],
                    "metadata": {"priority": "high"},
                },
                "blocked_by_detail": [
                    {
                        "id": "1",
                        "subject": "Ship release notes",
                        "status": "completed",
                        "owner": "writer",
                        "open_blocked_by": [],
                    }
                ],
                "blocks_detail": [
                    {
                        "id": "5",
                        "subject": "Publish release",
                        "status": "pending",
                        "owner": "ops",
                        "open_blocked_by": ["2"],
                    }
                ],
                "summary": "tasks=2 pending=0 in_progress=0 completed=2",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskGet",
            tool_call_id="tc_task_2",
            result_dict=payload,
        )

        self.assertIn("# TaskGet", formatted.text)
        self.assertIn("Selected Task:", formatted.text)
        self.assertIn("Task ID: #2", formatted.text)
        self.assertIn("Status: [completed] Finalize release checklist", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn("Description: Double-check release blockers.", formatted.text)
        self.assertIn("Blocked By: #1", formatted.text)
        self.assertIn("Blocks: #5", formatted.text)
        self.assertIn('Metadata: {"priority": "high"}', formatted.text)
        self.assertIn("Blocked By Detail:", formatted.text)
        self.assertIn("- [completed] #1 Ship release notes owner=writer", formatted.text)
        self.assertIn("Blocks Detail:", formatted.text)
        self.assertIn("- [pending] #5 Publish release owner=ops blocked_by=#2", formatted.text)
        self.assertNotIn("Total tasks: 0", formatted.text)

    def test_format_task_create_result_highlights_task_id_for_follow_up(self) -> None:
        payload = ok(
            data={
                "list_id": "session-123",
                "task": {
                    "id": "1",
                    "subject": "Search TODO comments",
                    "status": "pending",
                    "owner": "andy",
                    "open_blocked_by": [],
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Search TODO comments",
                        "status": "pending",
                        "owner": "andy",
                        "open_blocked_by": [],
                    }
                ],
                "total": 1,
                "by_status": {
                    "pending": 1,
                    "in_progress": 0,
                    "completed": 0,
                },
                "summary": "tasks=1 pending=1 in_progress=0 completed=0",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskCreate",
            tool_call_id="tc_task_create",
            result_dict=payload,
        )

        self.assertIn("Task ID: #1", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn(
            "Display IDs may appear as `#1`, but use `task_id=\"1\"` for TaskGet/TaskUpdate.",
            formatted.text,
        )
        self.assertIn("Task Namespace: session-123", formatted.text)


    def test_format_error_precondition_failed_hints_read(self) -> None:
        payload = err("PRECONDITION_FAILED", "Must Read file before modifying it: /tmp/f.py", meta={"file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_pre", result_dict=payload)
        read_hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "Read"]
        self.assertEqual(read_hints[0]["args"]["file_path"], "/tmp/f.py")

    def test_format_error_conflict_external_modification_hints_read(self) -> None:
        payload = err("CONFLICT", "modified externally", meta={"conflict_type": "external_modification", "file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_ext", result_dict=payload)
        assert any(h.get("action") == "Read" for h in (formatted.meta.retrieval_hints or []))
        assert not any(h.get("args", {}).get("fix_arguments") for h in (formatted.meta.retrieval_hints or []))

    def test_format_error_conflict_ambiguous_match_hints_fix_arguments(self) -> None:
        payload = err("CONFLICT", "old_string appears 2 times", meta={"conflict_type": "ambiguous_match", "file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_amb", result_dict=payload)
        assert any(h.get("args", {}).get("fix_arguments") for h in (formatted.meta.retrieval_hints or []))

    def test_format_error_bash_timeout_shows_stdout_or_stderr_or_artifact(self) -> None:
        payload = err(
            "TIMEOUT",
            "Command timed out after 120000ms",
            data={
                "stdout": "",
                "stderr": "compiling module B failed",
                "truncated": True,
                "artifact": {"relpath": ".agent/artifacts/bash/abc123.txt", "mime": "text/plain"},
            },
            retryable=True,
            meta={"args": ["make", "build"], "cwd": "/tmp", "duration_ms": 120000},
        )
        formatted = OutputFormatter.format(tool_name="Bash", tool_call_id="tc_bash_timeout", result_dict=payload)
        self.assertIn("Partial Output", formatted.text)
        self.assertIn("compiling module B failed", formatted.text)
        self.assertIn("abc123.txt", formatted.text)

    def test_format_error_read_hard_line_limit_exposes_bash_recovery_hint(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Line 1 is too large",
            meta={
                "file_path": "/tmp/huge.txt",
                "problem_line": 1,
                "hard_limit_bytes": 20480,
                "single_line_extractable": True,
                "extract_command": "sed -n '1p' /tmp/huge.txt | head -c 20480",
            },
        )
        formatted = OutputFormatter.format(tool_name="Read", tool_call_id="tc_read_hard", result_dict=payload)
        self.assertIn("Bash(", formatted.text)

    def test_glob_truncated_hint_respects_schema_max(self) -> None:
        payload = ok(
            data={
                "matches": [f"file{i}.py" for i in range(500)],
                "count": 500,
                "count_is_lower_bound": True,
                "truncated": True,
                "truncated_reason": "head_limit_reached",
                "search_path": "/tmp",
            }
        )
        formatted = OutputFormatter.format(tool_name="Glob", tool_call_id="tc_glob", result_dict=payload)
        hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "Glob"]
        self.assertEqual(hints[0]["args"]["head_limit"], 300)

    def test_ls_truncated_hint_respects_schema_max(self) -> None:
        payload = ok(
            data={
                "entries": [{"name": f"f{i}", "type": "file", "size": 1} for i in range(500)],
                "count": 500,
                "truncated": True,
                "truncated_reason": "head_limit_reached",
                "path": "/tmp",
            }
        )
        formatted = OutputFormatter.format(tool_name="LS", tool_call_id="tc_ls", result_dict=payload)
        hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "LS"]
        self.assertEqual(hints[0]["args"]["head_limit"], 300)


if __name__ == "__main__":
    unittest.main(verbosity=2)
