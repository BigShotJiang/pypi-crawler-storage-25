"""Team 工具 — TeamCreate / TeamDelete / SendMessage。

TeamCreate/TeamDelete: 显式 Team 生命周期管理（仅主 agent 可用）。
SendMessage: Team 模式下的通信工具。

非 Team 模式下调用通信工具会返回错误提示，而非 RuntimeError。
"""

from __future__ import annotations

import logging
import os
import re
import shutil
from datetime import datetime, timezone
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from comate_agent_sdk.system_tools.team.config import TeamConfig, resolve_teams_base_dir
from comate_agent_sdk.system_tools.team.identity import (
    normalize_agent_name,
    resolve_context_team_agent_name,
)
from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType, append_team_event
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools.decorator import tool
from comate_agent_sdk.tools.depends import Depends
from comate_agent_sdk.tools.system_context import SystemToolContext, get_system_tool_context

logger = logging.getLogger(__name__)

# ── team_name 校验 ──────────────────────────────────────────────────────

_TEAM_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")
_TEAM_NAME_BLACKLIST = frozenset({"none", "null", "undefined", "true", "false"})


def validate_team_name(raw: str) -> tuple[str, str | None]:
    """校验 team_name，返回 (normalized_name, error_message)。

    error_message 为 None 表示合法。
    """
    name = raw.strip()
    if not name:
        return "", "team_name 不能为空"
    if name.lower() in _TEAM_NAME_BLACKLIST:
        return "", f"team_name '{raw}' 是保留值，不允许使用"
    if "/" in name or "\\" in name or os.sep in name:
        return "", f"team_name '{raw}' 包含路径分隔符，不允许使用"
    if not _TEAM_NAME_PATTERN.match(name):
        return "", (
            f"team_name '{raw}' 不符合命名规范。"
            f"要求：字母或数字开头，仅允许字母、数字、下划线和连字符"
        )
    return name, None


_TEAM_CREATE_USAGE_RULES = "Create a team for multi-agent coordination. After creation, detailed team protocols are injected automatically.\n\nCreates:\n- Team config at ~/.agent/teams/{team-name}/config.json\n- Task list at ~/.agent/tasks/{team-name}/\n\nNext steps after creation: spawn teammates with Agent(team_name=..., name=...), create tasks with TaskCreate, assign with TaskUpdate(owner=...)."

_TEAM_DELETE_USAGE_RULES = """Delete a team and clean up all its resources (config, inboxes, task files).

When to use:
- After all team agents have completed their work
- When you want to disband a team and release resources

This will:
- Remove team config and inbox files from ~/.agent/teams/{team_name}/
- Optionally clean up task files from ~/.agent/tasks/{team_name}.json
- Exit team namespace (switch back to session-based namespace)
"""


class TeamCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    team_name: str = Field(
        description="Team name (alphanumeric, hyphens, underscores)"
    )
    description: str = Field(
        default="",
        description="Brief team purpose (optional)",
    )


@tool(
    "Create a team for multi-agent coordination.",
    name="TeamCreate",
    usage_rules=_TEAM_CREATE_USAGE_RULES,
)
async def TeamCreate(
    params: TeamCreateInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    team_name = params.team_name
    description = params.description

    # 1. 校验 team_name
    validated_name, error = validate_team_name(team_name)
    if error:
        return err("INVALID_ARGUMENT", error)

    # 2. 创建 TeamConfig
    try:
        team_cfg = TeamConfig(team_name=validated_name)
        # 检查是否已存在
        if team_cfg.path.exists():
            return err(
                "CONFLICT",
                f"Team '{validated_name}' already exists\n"
                "Team creation failed. You are not in Team mode.\n"
                "Do not read the existing team config.\n"
                "Do not reuse the existing team implicitly.\n"
                "Do not spawn teammates with this team_name.\n"
                "Do not continue the team workflow.\n"
                "To proceed, either:\n"
                "- create a new team with a different name, or\n"
                "- delete the existing team first and then create it again.\n"
                "If the user has not specified which option to take, stop here and ask."
            )
        team_cfg.set_description(description)
        # 注册主 agent 为 leader
        leader_name = resolve_context_team_agent_name(
            agent_name=getattr(ctx, "agent_name", None),
            subagent_name=ctx.subagent_name,
        )
        normalized_leader_name = normalize_agent_name(leader_name)
        team_cfg.register_member(name=normalized_leader_name, agent_type="leader")
        # 记录 leader session 信息，供 team_events.jsonl 写入使用
        if ctx.session_root is not None:
            team_cfg.set_leader_session(
                session_id=ctx.session_id,
                session_root=str(ctx.session_root),
            )
    except Exception as exc:
        logger.error(f"TeamCreate failed to create config: {exc}", exc_info=True)
        return err("INTERNAL", f"TeamCreate failed: {exc}")

    # 3. 通过回调切换主 agent 到 team namespace
    switcher = ctx.team_namespace_switcher
    if switcher is not None:
        try:
            switcher(validated_name)
        except Exception as exc:
            logger.error(f"TeamCreate namespace switch failed: {exc}", exc_info=True)
            try:
                shutil.rmtree(team_cfg.team_dir, ignore_errors=True)
            except Exception as rollback_exc:
                logger.error(f"TeamCreate rollback failed: {rollback_exc}", exc_info=True)
            return err(
                "INTERNAL",
                f"Team creation rolled back: namespace switch failed ({exc}). Safe to retry TeamCreate with the same name.",
                retryable=True,
            )

    return ok(
        data={
            "team_name": validated_name,
            "config_path": str(team_cfg.path),
            "description": description,
        },
        meta={"leader": normalized_leader_name},
    )


@tool(
    "Delete a team and clean up all resources (config, inboxes, task files).",
    name="TeamDelete",
    usage_rules=_TEAM_DELETE_USAGE_RULES,
)
async def TeamDelete(
    team_name: str,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    """
    Args:
        team_name: 要删除的 Team 名称
    """
    # 1. 校验 team_name
    validated_name, error = validate_team_name(team_name)
    if error:
        return err("INVALID_ARGUMENT", error)

    # 2. 检查 team 是否存在
    team_cfg = TeamConfig(team_name=validated_name)
    if not team_cfg.path.exists():
        return err("NOT_FOUND", f"Team '{validated_name}' does not exist")

    team_session_lister = getattr(ctx, "team_session_lister", None)
    if callable(team_session_lister):
        active_sessions = [name for name in team_session_lister(validated_name) if str(name).strip()]
        if active_sessions:
            active_list = ", ".join(active_sessions)
            return err(
                "CONFLICT",
                (
                    f"Team '{validated_name}' still has active team sessions: {active_list}. "
                    "Send shutdown_request to those teammates before deleting the team."
                ),
                meta={"active_team_sessions": active_sessions},
            )

    cleaned: list[str] = []

    # 3. 清理 team 目录（config + inboxes）
    try:
        if team_cfg.team_dir.exists():
            shutil.rmtree(team_cfg.team_dir)
            cleaned.append(f"team_dir: {team_cfg.team_dir}")
    except Exception as exc:
        logger.warning(f"TeamDelete: 清理 team 目录失败: {exc}")

    # 4. 可选：清理 task 文件
    try:
        from comate_agent_sdk.system_tools.task.store import resolve_task_store_dir
        task_file = resolve_task_store_dir() / f"{validated_name}.json"
        if task_file.exists():
            task_file.unlink()
            cleaned.append(f"task_file: {task_file}")
    except Exception as exc:
        logger.warning(f"TeamDelete: 清理 task 文件失败: {exc}")

    # 5. 通过回调退出 team namespace
    switcher = ctx.team_namespace_switcher
    if switcher is not None:
        try:
            switcher("")  # 空字符串 → 退出 team namespace
        except Exception as exc:
            logger.warning(f"TeamDelete: namespace switch 失败: {exc}")

    return ok(
        data={
            "team_name": validated_name,
            "cleaned": cleaned,
        },
    )


def _team_context(ctx: SystemToolContext) -> tuple[str, str]:
    """返回 (team_name, agent_name)，若未处于 Team 模式则抛出 RuntimeError。"""
    team_name = ctx.team_name.strip()
    agent_name = normalize_agent_name(
        resolve_context_team_agent_name(
            agent_name=getattr(ctx, "agent_name", None),
            subagent_name=ctx.subagent_name,
        )
    )
    if not team_name:
        raise RuntimeError("不在 Team 模式下，无法使用消息工具")
    if not agent_name:
        raise RuntimeError("agent_name 未注入，无法使用消息工具")
    return team_name, agent_name


class SendMessageInput(BaseModel):
    to: str = Field(
        description="Teammate name (e.g. 'researcher-1'), or '*' to broadcast to all teammates.",
    )
    content: str = Field(
        min_length=1,
        description="Message text in plain language",
    )
    type: Literal["message", "shutdown_request"] = Field(
        default="message",
        description="message: normal message or broadcast; shutdown_request: graceful shutdown (requires to='*')",
    )

    model_config = {
        "extra": "forbid",
    }

    @model_validator(mode="after")
    def _validate_routing(self) -> "SendMessageInput":
        self.to = self.to.strip()
        if not self.to:
            raise ValueError("to must not be empty")

        if normalize_agent_name(self.to) == "all":
            raise ValueError("to='all' is reserved; use to='*' instead")

        if self.type == "shutdown_request" and self.to != "*":
            raise ValueError("shutdown_request must use to='*' (broadcast to all)")

        return self


_SEND_MESSAGE_USAGE_RULES = """Send a message to a teammate. Only available in Team mode.

Use plain text content - do NOT send structured JSON status messages.

## Delivery Rules
- Broadcast (to='*') delivers to all other **registered** team members. Returns NOT_FOUND if no other members exist.
- Unicast delivers to a specific **registered** member. Returns NOT_FOUND if the target is not registered.
- After sending, check delivered_to in the response to confirm delivery.
"""


@tool(
    "Send a message to a teammate.",
    name="SendMessage",
    usage_rules=_SEND_MESSAGE_USAGE_RULES,
    input_examples=[
        {"to": "researcher-1", "content": "Please analyze the auth module", "type": "message"},
        {"to": "*", "content": "Phase 1 is complete, moving to phase 2", "type": "message"},
        {"to": "*", "content": "All tasks done, please wrap up", "type": "shutdown_request"},
    ],
)
async def SendMessage(
    params: SendMessageInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        team_name, from_agent = _team_context(ctx)
    except RuntimeError as exc:
        return err("PRECONDITION_FAILED", str(exc))

    # to → 内部 MessageType 映射
    if params.to == "*":
        if params.type == "shutdown_request":
            msg_type = MessageType.SHUTDOWN_REQUEST
        else:
            msg_type = MessageType.BROADCAST
    else:
        msg_type = MessageType.MESSAGE

    try:
        # 读取 leader session 信息用于审计日志
        team_cfg = TeamConfig(team_name=team_name)
        leader_sid, leader_sroot = team_cfg.get_leader_session()
        registered_members = [m["name"] for m in team_cfg.list_members()]
        registered_member_set = set(registered_members)

        if from_agent not in registered_member_set:
            return err(
                "PRECONDITION_FAILED",
                (
                    f"Current agent '{from_agent}' is not a registered team member. "
                    f"Registered members: {sorted(registered_members)}."
                ),
            )

        if params.to == "*":
            # 广播路径：投递给所有已注册 team 成员（排除自己）
            recipients = [name for name in registered_members if name != from_agent]
            if not recipients:
                return err(
                    "NOT_FOUND",
                    "No recipients available for broadcast. No other registered team members exist.",
                )
            for recipient in recipients:
                inbox = Inbox(team_name=team_name, agent_name=recipient)
                inbox.append_message(
                    from_agent=from_agent,
                    message_type=msg_type,
                    content=params.content,
                )
            # 审计日志
            append_team_event(
                leader_session_id=leader_sid,
                leader_session_root=leader_sroot,
                from_agent=from_agent,
                to_agent="*",
                message_type=msg_type.value,
                content=params.content,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            return ok(
                data={
                    "to": "*",
                    "type": params.type,
                    "delivered_to": recipients,
                },
                meta={"from": from_agent, "team": team_name},
            )
        else:
            to = normalize_agent_name(params.to)
            if to not in registered_member_set:
                return err(
                    "NOT_FOUND",
                    f"Agent '{to}' is not a registered team member. Registered members: {sorted(registered_members)}.",
                )
            inbox = Inbox(team_name=team_name, agent_name=to)
            inbox.append_message(
                from_agent=from_agent,
                message_type=msg_type,
                content=params.content,
            )
            # 审计日志
            append_team_event(
                leader_session_id=leader_sid,
                leader_session_root=leader_sroot,
                from_agent=from_agent,
                to_agent=to,
                message_type=msg_type.value,
                content=params.content,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            return ok(
                data={
                    "to": to,
                    "type": params.type,
                    "delivered_to": [to],
                },
                meta={"from": from_agent, "team": team_name},
            )
    except Exception as exc:
        logger.error(f"SendMessage failed: {exc}", exc_info=True)
        return err("INTERNAL", f"SendMessage failed: {exc}")


_send_message_definition = SendMessage.definition
_send_message_definition.parameters["required"] = ["to", "content", "type"]
