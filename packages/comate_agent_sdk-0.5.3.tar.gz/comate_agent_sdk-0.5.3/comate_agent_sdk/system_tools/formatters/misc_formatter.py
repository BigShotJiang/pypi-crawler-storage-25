"""Formatters for Task tools, WebFetch, AskUserQuestion, and generic results."""
from __future__ import annotations

import json
from typing import Any

from comate_agent_sdk.context.truncation import TruncationRecord
from comate_agent_sdk.system_tools.formatters.types import FormattedToolResult, ToolExecutionMeta

from .common import _artifact_hint, _as_float, _as_int, _default_truncation, _duration_from_result, _format_hints_footer


def _truncate_text(text: str, max_chars: int = 8000) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n...(truncated)"


def _task_id_text(task_id: Any) -> str:
    normalized = str(task_id or "").strip()
    return f"#{normalized}" if normalized else "#?"


def _task_csv(values: Any) -> str:
    if not isinstance(values, list):
        return ""
    normalized = [str(item).strip() for item in values if str(item).strip()]
    return ", ".join(f"#{item}" for item in normalized)


def _task_summary_line(task: dict[str, Any]) -> str:
    task_id = _task_id_text(task.get("id"))
    status = str(task.get("status", "pending")).strip() or "pending"
    subject = str(task.get("subject", "")).strip()
    owner = str(task.get("owner", "")).strip()
    open_blocked_by = _task_csv(task.get("open_blocked_by"))

    parts = [f"- [{status}] {task_id} {subject}".rstrip()]
    if owner:
        parts.append(f"owner={owner}")
    if open_blocked_by:
        parts.append(f"blocked_by={open_blocked_by}")
    return " ".join(parts)


def _task_summary_description_line(task: dict[str, Any]) -> str:
    description = str(task.get("description", "")).strip()
    if not description:
        return ""
    return f"  Description: {description}"


def _task_detail_lines(task: dict[str, Any]) -> list[str]:
    task_id = _task_id_text(task.get("id"))
    task_status = str(task.get("status", "pending")).strip() or "pending"
    task_subject = str(task.get("subject", "")).strip()
    owner = str(task.get("owner", "")).strip()
    description = str(task.get("description", "")).strip()
    blocked_by = _task_csv(task.get("blocked_by"))
    open_blocked_by = _task_csv(task.get("open_blocked_by"))
    blocks = _task_csv(task.get("blocks"))
    metadata = task.get("metadata")

    lines = [
        "Selected Task:",
        f"- Task ID: {task_id}",
        f"- Status: [{task_status}] {task_subject}",
    ]
    if owner:
        lines.append(f"- Owner: {owner}")
    if description:
        lines.append(f"- Description: {description}")
    if blocked_by:
        lines.append(f"- Blocked By: {blocked_by}")
    if open_blocked_by:
        lines.append(f"- Open Blocked By: {open_blocked_by}")
    if blocks:
        lines.append(f"- Blocks: {blocks}")
    if isinstance(metadata, dict) and metadata:
        lines.append(f"- Metadata: {json.dumps(metadata, ensure_ascii=False, sort_keys=True)}")
    return lines


def _task_dependency_section(title: str, tasks: Any) -> list[str]:
    if not isinstance(tasks, list):
        return []
    normalized = [task for task in tasks if isinstance(task, dict)]
    if not normalized:
        return []

    lines = ["", f"{title}:"]
    lines.extend(_task_summary_line(task) for task in normalized[:8])
    return lines


def _task_lines_from_result(data: dict[str, Any]) -> list[str]:
    raw_tasks = data.get("tasks")
    has_task_list = isinstance(raw_tasks, list)
    tasks = raw_tasks if has_task_list else []

    lines = [f"Task Namespace: {data.get('list_id', 'default')}"]
    if has_task_list or "total" in data:
        lines.append(f"Total tasks: {_as_int(data.get('total'), len(tasks))}")
    by_status = data.get("by_status")
    if isinstance(by_status, dict):
        lines.append(
            "Status: "
            f"pending={_as_int(by_status.get('pending'), 0)} "
            f"in_progress={_as_int(by_status.get('in_progress'), 0)} "
            f"completed={_as_int(by_status.get('completed'), 0)}"
        )

    active_tasks = [
        task for task in tasks
        if isinstance(task, dict) and str(task.get("status", "")).strip() != "completed"
    ]
    if active_tasks:
        lines.extend(["", "Open Tasks:"])
        for task in active_tasks[:8]:
            lines.append(_task_summary_line(task))
            description_line = _task_summary_description_line(task)
            if description_line:
                lines.append(description_line)
    return lines


def format_task_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    lines = [f"# {tool_name}", ""]
    task = data.get("task")
    if isinstance(task, dict):
        task_id = str(task.get("id", "?")).strip() or "?"
        if task.get("deleted"):
            lines.extend([
                "Deleted Task:",
                f"- Task ID: #{task_id}",
                "",
            ])
        else:
            lines.extend(_task_detail_lines(task))
            if tool_name == "TaskCreate":
                lines.extend([
                    "",
                    f"Display IDs may appear as `#{task_id}`, but use `task_id=\"{task_id}\"` for TaskGet/TaskUpdate.",
                ])
            lines.append("")

    lines.extend(_task_lines_from_result(data))
    lines.extend(_task_dependency_section("Blocked By Detail", data.get("blocked_by_detail")))
    lines.extend(_task_dependency_section("Blocks Detail", data.get("blocks_detail")))
    summary = str(data.get("summary") or "").strip()
    if summary:
        lines.extend(["", summary])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_webfetch_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    final_url = str(data.get("final_url") or "unknown")
    status = _as_int(data.get("status"), 0)
    cached = bool(data.get("cached"))
    truncated_for_llm = bool(data.get("truncated_for_llm"))
    summary_text = _truncate_text(str(data.get("summary_text", "")), 6000)
    model_used = str(data.get("model_used") or "")

    lines = [
        f"# WebFetch: {final_url}",
        "",
        f"Status: {status}",
        f"Cached: {cached}",
    ]
    if model_used:
        lines.append(f"Model: {model_used}")
    lines.extend(["", "Summary:", summary_text or "(empty)"])

    hints: list[dict[str, Any]] = []
    artifact_hint = _artifact_hint(data, priority="high")
    if artifact_hint is not None:
        hints.append(artifact_hint)

    footer = _format_hints_footer(hints) if truncated_for_llm else ""
    if footer:
        lines.extend(["", footer])

    truncation: TruncationRecord | None = None
    if truncated_for_llm:
        truncation = TruncationRecord(
            formatter_truncated=True,
            formatter_reason="llm_input_limit",
            formatter_total_estimate=0,
        )

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=truncation,
        retrieval_hints=hints or None,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_ask_user_question_result(
    tool_name: str,
    tool_call_id: str,
    result: dict[str, Any],
) -> FormattedToolResult:
    data = result.get("data", {})
    questions = data.get("questions", [])
    if not isinstance(questions, list):
        questions = []

    lines = [
        "# AskUserQuestion",
        "",
        f"Status: {data.get('status', 'waiting_for_input')}",
        f"Question count: {len(questions)}",
        "",
    ]
    for idx, question in enumerate(questions, start=1):
        if not isinstance(question, dict):
            continue
        header = str(question.get("header") or "")
        text = str(question.get("question") or "")
        lines.append(f"{idx}. [{header}] {text}")

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_generic_ok(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    message = result.get("message")
    text_parts = [f"# {tool_name}", ""]
    if message:
        text_parts.extend([str(message), ""])
    text_parts.append(json.dumps(data, ensure_ascii=False, indent=2))

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=_default_truncation(data if isinstance(data, dict) else {}),
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(text_parts).strip(), meta=meta)


def format_error(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    error = result.get("error", {})
    code = str(error.get("code") or "INTERNAL")
    message = str(error.get("message") or "Unknown error")
    field_errors = error.get("field_errors", [])
    retryable = bool(error.get("retryable"))
    meta_payload = result.get("meta", {})

    lines = [
        f"# {tool_name} Error",
        "",
        f"Code: {code}",
        f"Message: {message}",
        f"Retryable: {retryable}",
    ]
    first_field: str | None = None
    if isinstance(field_errors, list) and field_errors:
        lines.append("")
        lines.append("Field errors:")
        for item in field_errors[:5]:
            if not isinstance(item, dict):
                continue
            field = str(item.get("field") or "")
            item_msg = str(item.get("message") or "")
            if field and first_field is None:
                first_field = field
            lines.append(f"- {field}: {item_msg}")

    hints: list[dict[str, Any]] = []
    if first_field:
        hints.append(
            {
                "action": tool_name,
                "priority": "high",
                "args": {
                    first_field: "<correct_value>",
                },
            }
        )
    if code == "NOT_FOUND":
        hints.append(
            {
                "action": "LS",
                "priority": "medium",
                "args": {
                    "path": "<parent_directory>",
                    "head_limit": 200,
                },
            }
        )
    if code in {"TIMEOUT", "RATE_LIMITED", "INTERNAL"} or retryable:
        hints.append(
            {
                "action": tool_name,
                "priority": "medium",
                "args": {
                    "retry": True,
                },
            }
        )
    if code == "PRECONDITION_FAILED":
        file_path = meta_payload.get("file_path") or meta_payload.get("resolved_file_path") if isinstance(meta_payload, dict) else None
        if isinstance(file_path, str) and file_path.strip():
            hints.append({"action": "Read", "priority": "high", "args": {"file_path": file_path}})

    if code == "CONFLICT" and not first_field:
        conflict_type = meta_payload.get("conflict_type") if isinstance(meta_payload, dict) else None
        if conflict_type == "external_modification":
            file_path = meta_payload.get("file_path") or meta_payload.get("resolved_file_path")
            if isinstance(file_path, str) and file_path.strip():
                hints.append({"action": "Read", "priority": "high", "args": {"file_path": file_path}})
        else:
            hints.append({"action": tool_name, "priority": "high", "args": {"fix_arguments": True}})

    if code == "INVALID_ARGUMENT" and not first_field:
        hints.append(
            {
                "action": tool_name,
                "priority": "high",
                "args": {
                    "fix_arguments": True,
                },
            }
        )

    data_payload = result.get("data", {})
    if tool_name == "Bash" and isinstance(data_payload, dict):
        preview = str(data_payload.get("stdout") or data_payload.get("stderr") or "").strip()
        artifact = data_payload.get("artifact") if isinstance(data_payload.get("artifact"), dict) else None
        if preview or artifact:
            lines.append("")
            lines.append("## Partial Output (before timeout/interruption)")
            lines.append(preview or "(output saved to artifact)")
            if artifact and artifact.get("relpath"):
                lines.append(f"Full output saved to: {artifact['relpath']}")
                hints.append({"action": "Read", "priority": "medium", "args": {"file_path": artifact["relpath"], "format": "raw"}})

    if code == "OUTPUT_TOO_LARGE":
        lines.insert(4, "Meaning: The selected Read slice is too large to return in one result.")
    if tool_name == "Read" and code == "OUTPUT_TOO_LARGE" and isinstance(meta_payload, dict):
        if meta_payload.get("single_line_extractable") and meta_payload.get("problem_line"):
            extract_cmd = str(meta_payload.get("extract_command", ""))
            if extract_cmd:
                hints.insert(
                    0,
                    {
                        "action": "Bash",
                        "priority": "high",
                        "args": {
                            "args": ["sh", "-c", extract_cmd],
                            "cwd": "<project_root>",
                        },
                    },
                )
    if tool_name == "Read" and isinstance(meta_payload, dict):
        suggested_offset_line = meta_payload.get("suggested_offset_line")
        suggested_limit_lines = meta_payload.get("suggested_limit_lines")
        suggested_max_line_chars = meta_payload.get("suggested_max_line_chars")
        file_path = meta_payload.get("file_path")
        if (
            isinstance(file_path, str)
            and file_path.strip()
            and isinstance(suggested_offset_line, int)
            and suggested_offset_line >= 0
            and isinstance(suggested_limit_lines, int)
            and suggested_limit_lines > 0
        ):
            hints.insert(
                0,
                {
                    "action": "Read",
                    "priority": "high",
                    "args": {
                        "file_path": file_path,
                        "offset_line": suggested_offset_line,
                        "limit_lines": suggested_limit_lines,
                    },
                },
            )
        elif (
            isinstance(file_path, str)
            and file_path.strip()
            and isinstance(suggested_offset_line, int)
            and suggested_offset_line >= 0
            and isinstance(suggested_max_line_chars, int)
            and suggested_max_line_chars >= 100
        ):
            hints.insert(
                0,
                {
                    "action": "Read",
                    "priority": "high",
                    "args": {
                        "file_path": file_path,
                        "offset_line": suggested_offset_line,
                        "limit_lines": 1,
                        "max_line_chars": suggested_max_line_chars,
                    },
                },
            )

    footer = _format_hints_footer(hints)
    if footer:
        lines.extend(["", footer])

    truncation_source = result.get("data", {})
    if (not isinstance(truncation_source, dict) or not truncation_source) and isinstance(
        result.get("meta"), dict
    ):
        truncation_source = result.get("meta", {})

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="error",
        truncation=_default_truncation(truncation_source if isinstance(truncation_source, dict) else {}),
        retrieval_hints=hints or None,
        duration_ms=_duration_from_result(result),
        error_code=code,
        error_field=first_field,
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)
