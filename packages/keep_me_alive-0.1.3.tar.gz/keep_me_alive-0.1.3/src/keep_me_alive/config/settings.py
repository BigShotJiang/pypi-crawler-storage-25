import json
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Any
from enum import Enum

CONFIG_FILE_PATH = Path.home() / ".keep_me_alive_config"

class JiggleStyle(str, Enum):
    STANDARD = "standard"
    CLICK = "click"
    SCROLL = "scroll"
    KEYSTROKE = "keystroke"
    MIXED = "mixed"

class JigglerSettings(BaseSettings):
    interval: int = Field(default=60, description="Seconds between jiggles")
    jitter_percentage: int = Field(default=20, ge=0, le=100, description="Randomized variance added to interval as a percentage")
    style: JiggleStyle = Field(default=JiggleStyle.STANDARD, description="Jiggle style to use")
    distance: int = Field(default=3, ge=1, le=10, description="Distance for standard jiggle scale 1 (near) to 10 (far)")
    idle_timeout: int = Field(default=0, description="Minutes of idle time required before jiggling starts (0 = always jiggle)")
    pause_on_battery: bool = Field(default=False, description="Pause jiggling when system is on battery power")
    pause_on_screen_lock: bool = Field(default=True, description="Pause jiggling when the system screen is locked")
    cpu_threshold: int = Field(default=0, description="CPU busy percentage threshold to trigger jiggling (0 = ignore)")
    active_apps: str = Field(default="", description="Comma-separated list of application names to trigger jiggling if running")
    front_apps: str = Field(default="", description="Comma-separated list of application names to pause jiggling if frontmost")
    enable_on_media: bool = Field(default=False, description="Enable jiggling if iTunes/Music/Spotify is playing")
    enable_on_drive: bool = Field(default=False, description="Enable jiggling if a removable or external drive is mounted")

    def save(self) -> None:
        """Save current settings to ~/.keep_me_alive_config"""
        try:
            with open(CONFIG_FILE_PATH, "w", encoding="utf-8") as f:
                f.write(self.model_dump_json(indent=4))
        except Exception as e:
            print(f"Error saving config: {e}")

def load_config() -> JigglerSettings:
    """Load configuration from ~/.keep_me_alive_config. Defaults used if missing."""
    if not CONFIG_FILE_PATH.exists():
        return JigglerSettings()
    
    try:
        with open(CONFIG_FILE_PATH, "r", encoding="utf-8") as f:
            user_config = json.load(f)
            
            # Filter out any keys that aren't defined in the model to gracefully drop stale entries
            valid_keys = JigglerSettings.model_fields.keys()
            filtered_config = {k: v for k, v in user_config.items() if k in valid_keys}
            
            config_obj = JigglerSettings(**filtered_config)
            
            # Automatically clean up the file if stale entries were found
            if len(filtered_config) < len(user_config):
                # Don't call .save() here because .save() writes to file, 
                # but we're just loading. It's safe to rewrite though:
                try:
                    with open(CONFIG_FILE_PATH, "w", encoding="utf-8") as f2:
                        f2.write(config_obj.model_dump_json(indent=4))
                except Exception:
                    pass

            return config_obj
    except Exception as e:
        print(f"Warning: Could not load config (possibly corrupt format). Using defaults. Error: {e}")
        return JigglerSettings()

def update_config_value(key: str, value: Any) -> None:
    """Update a single configuration key."""
    config = load_config()
    setattr(config, key, value)
    config.save()
