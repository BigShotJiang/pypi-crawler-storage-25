import os
import subprocess
import sys
from typing import Optional

import typer

from keep_me_alive.config.settings import load_config, update_config_value, JiggleStyle
from keep_me_alive.core.jiggler import run_background_loop
from keep_me_alive.core.process import (
    get_running_process,
    stop_running_jiggler,
    update_timed_quit,
)

import importlib.metadata

app = typer.Typer(help="Keep Me Alive CLI - Cross-platform sleep prevention.")

def version_callback(value: bool):
    if value:
        try:
            version = importlib.metadata.version("keep-me-alive")
        except importlib.metadata.PackageNotFoundError:
            version = "unknown"
        print(f"Keep Me Alive CLI Version: {version}")
        raise typer.Exit()

@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", callback=version_callback, is_eager=True, help="Show the application version and exit."
    )
):
    pass


@app.command()
def start():
    """Start the jiggler in the background."""
    pid, _ = get_running_process()
    if pid is not None:
        print(
            f"Keep Me Alive is already running (PID {pid}). Stop it first with `keep-me-alive stop` if you want to restart."
        )
        raise typer.Exit()

    print("Starting Keep Me Alive in the background...")

    # Load config once locally so that any validation errors are printed to the user's terminal
    load_config()

    # We will invoke this script itself but pass an internal command to run the daemon loop.
    cmd = [sys.executable, "-m", "keep_me_alive.cli.main", "internal-daemon"]

    # Cross-platform detached process
    kwargs = {}
    if os.name == "nt":
        # On Windows, try to use pythonw.exe (the windowless version)
        # to ensure no console window is even allocated.
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            pythonw = exe[:-10] + "pythonw.exe"
            if os.path.exists(pythonw):
                cmd[0] = pythonw

        # CREATE_NO_WINDOW (0x08000000)
        # We REMOVE DETACHED_PROCESS (0x00000008) because it often forces a console allocation
        kwargs.update(creationflags=0x08000000)

        # Use STARTUPINFO as a robust secondary way to hide the window
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0  # SW_HIDE
        kwargs.update(startupinfo=startupinfo)
    else:
        # Start a new session on POSIX
        kwargs.update(start_new_session=True)

    # We send stdout and stderr to DEVNULL to fully detach.
    subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        **kwargs,
    )
    print("Keep Me Alive is now running.")


@app.command()
def stop():
    """Stop any running jiggler process."""
    stop_running_jiggler()


@app.command()
def config(
    interval: Optional[int] = typer.Option(
        None, help="Seconds between jiggles (e.g. 60)"
    ),
    jitter_percentage: Optional[int] = typer.Option(
        None, help="Randomized variance added to interval as a percentage (e.g. 20)"
    ),
    style: Optional[JiggleStyle] = typer.Option(None, help="Jiggle style"),
    distance: Optional[int] = typer.Option(None, help="Distance for standard jiggle"),
    idle_timeout: Optional[int] = typer.Option(
        None, help="Minutes of idle time required before jiggling (0 = always)"
    ),
    pause_on_battery: Optional[bool] = typer.Option(
        None, help="Pause jiggling when system is on battery power"
    ),
    pause_on_screen_lock: Optional[bool] = typer.Option(
        None, help="Pause jiggling when the screen is locked"
    ),
    cpu_threshold: Optional[int] = typer.Option(
        None, help="CPU busy % threshold to trigger jiggling (0 = ignore)"
    ),
    active_apps: Optional[str] = typer.Option(
        None,
        help="Comma-separated list of application names to trigger jiggling if running",
    ),
    front_apps: Optional[str] = typer.Option(
        None,
        help="Comma-separated list of application names to pause jiggling if frontmost",
    ),
    enable_on_media: Optional[bool] = typer.Option(
        None, help="Enable jiggling if iTunes/Music is playing"
    ),
    enable_on_drive: Optional[bool] = typer.Option(
        None, help="Enable jiggling if removable drive is mounted"
    ),
):
    """Manage global configuration."""
    updated = False

    options = {
        "interval": interval,
        "jitter_percentage": jitter_percentage,
        "style": style if style else None,
        "distance": distance,
        "idle_timeout": idle_timeout,
        "pause_on_battery": pause_on_battery,
        "pause_on_screen_lock": pause_on_screen_lock,
        "cpu_threshold": cpu_threshold,
        "active_apps": active_apps,
        "front_apps": front_apps,
        "enable_on_media": enable_on_media,
        "enable_on_drive": enable_on_drive,
    }

    for key, value in options.items():
        if value is not None:
            update_config_value(key, value)
            updated = True

    if updated:
        print("Configuration updated automatically.")

    # Always print current config
    current_config = load_config()
    print("Current Configuration:")
    for k, v in current_config.model_dump().items():
        print(f"  {k}: {v}")


@app.command()
def toggle():
    """Toggle the daemon on/off."""
    pid, _ = get_running_process()
    if pid is not None:
        stop_running_jiggler()
        print("Jiggler stopped. The daemon is no longer running.")
    else:
        start()
        # The `start` function already prints "Keep Me Alive is now running."


@app.command(name="timed-quit")
def timed_quit(
    duration: str = typer.Argument(..., help="Duration format like 15m or 1h15m"),
):
    """Set a timed quit for an already running jiggler."""
    # Simple parser for the time format
    import re

    hours, minutes = 0, 0
    h_match = re.search(r"(\d+)h", duration)
    m_match = re.search(r"(\d+)m", duration)

    if h_match:
        hours = int(h_match.group(1))
    if m_match:
        minutes = int(m_match.group(1))

    total_minutes = (hours * 60) + minutes
    if total_minutes <= 0:
        print("Invalid duration. Use format like 15m or 1h15m.")
        raise typer.Exit(1)

    update_timed_quit(total_minutes)


@app.command(name="cancel-quit")
def cancel_quit():
    """Cancel any active timed quit."""
    update_timed_quit(cancel=True)


@app.command(hidden=True)
def internal_daemon():
    """Internal command to run the daemon loop. Not meant for user invocation."""
    try:
        run_background_loop()
    except Exception as e:
        import traceback
        from pathlib import Path
        log_file = Path.home() / ".keep_me_alive.log"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"\n--- Daemon Crash at {Path.home()} ---\n")
            f.write(f"Error: {e}\n")
            traceback.print_exc(file=f)
        raise


# Make it runnable via `python -m keep_me_alive.cli.main`
if __name__ == "__main__":
    app()
