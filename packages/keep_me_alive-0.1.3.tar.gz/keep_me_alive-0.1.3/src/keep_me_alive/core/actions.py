import random
import time
from pynput.mouse import Controller as MouseController, Button
from pynput.keyboard import Controller as KeyboardController, Key
from keep_me_alive.config.settings import JiggleStyle

mouse = MouseController()
keyboard = KeyboardController()

def _cubic_bezier(t: float, p0: float, p1: float, p2: float, p3: float) -> float:
    """Calculate point on a cubic bezier curve at time t (0 to 1)."""
    return (
        (1-t)**3 * p0 +
        3 * (1-t)**2 * t * p1 +
        3 * (1-t) * t**2 * p2 +
        t**3 * p3
    )

def perform_standard_jiggle(distance: int = 10):
    """Move the mouse smoothly along a human-like Bezier curve."""
    # Map distance scale 1-10 to a pixel tolerance
    tolerance = distance * 4 # e.g., 4px to 40px base tolerance
    
    # Randomize actual distance between 50% and 100% of tolerance for more variance
    actual_dist = random.randint(tolerance // 2, tolerance)
    
    start_pos = mouse.position
    
    # Generate random control points relative to start
    # P0 is start, P3 is a random destination, P1 and P2 are random control points
    p0_x, p0_y = start_pos
    
    p3_x = p0_x + random.randint(-actual_dist, actual_dist)
    p3_y = p0_y + random.randint(-actual_dist, actual_dist)
    
    p1_x = p0_x + random.randint(-actual_dist, actual_dist)
    p1_y = p0_y + random.randint(-actual_dist, actual_dist)
    
    p2_x = p3_x + random.randint(-actual_dist, actual_dist)
    p2_y = p3_y + random.randint(-actual_dist, actual_dist)
    
    # Animate along the curve
    steps = random.randint(20, 40)
    curr_x, curr_y = p0_x, p0_y
    for i in range(steps + 1):
        t = i / steps
        x = _cubic_bezier(t, p0_x, p1_x, p2_x, p3_x)
        y = _cubic_bezier(t, p0_y, p1_y, p2_y, p3_y)
        
        dx = int(x) - curr_x
        dy = int(y) - curr_y
        if dx != 0 or dy != 0:
            mouse.move(dx, dy)
            curr_x += dx
            curr_y += dy
            
        time.sleep(random.uniform(0.005, 0.015)) # slight jitter in speed

def perform_click_jiggle():
    """Simulate a mouse click without moving the cursor."""
    mouse.press(Button.left)
    time.sleep(random.uniform(0.01, 0.05))
    mouse.release(Button.left)

def perform_scroll_jiggle():
    """Simulate a tiny mouse scroll."""
    # Scroll slightly in one direction then back
    scroll_amt = random.randint(1, 2)
    mouse.scroll(0, scroll_amt)
    time.sleep(random.uniform(0.1, 0.3))
    mouse.scroll(0, -scroll_amt)

def perform_keystroke_jiggle():
    """Simulate pressing a harmless key."""
    # Use Shift as it rarely interrupts user workflows negatively
    key = random.choice([Key.shift, Key.shift_r, Key.ctrl, Key.ctrl_r])
    keyboard.press(key)
    time.sleep(random.uniform(0.02, 0.08))
    keyboard.release(key)

def perform_mixed_jiggle(distance: int):
    """Randomly select a jiggle action."""
    action = random.choice([JiggleStyle.STANDARD, JiggleStyle.CLICK, JiggleStyle.SCROLL, JiggleStyle.KEYSTROKE])
    trigger_jiggle_action(action, distance)

def trigger_jiggle_action(style: JiggleStyle, distance: int):
    """Dispatcher for the jiggling style."""
    if style == JiggleStyle.CLICK:
        perform_click_jiggle()
    elif style == JiggleStyle.SCROLL:
        perform_scroll_jiggle()
    elif style == JiggleStyle.KEYSTROKE:
        perform_keystroke_jiggle()
    elif style == JiggleStyle.MIXED:
        perform_mixed_jiggle(distance)
    else:  # default standard
        perform_standard_jiggle(distance)
