import os
import psutil
import signal
import datetime
import traceback
from pathlib import Path
from typing import Optional

PID_FILE_PATH = Path.home() / ".keep_me_alive.pid"
LOG_FILE_PATH = Path.home() / ".keep_me_alive.log"

def _log_error(context_msg: str, exc: Exception):
    """Log an error with context and traceback to ~/.keep_me_alive.log."""
    try:
        with open(LOG_FILE_PATH, "a", encoding="utf-8") as f:
            f.write(f"\n--- Process Error at {datetime.datetime.now().isoformat()} ---\n")
            f.write(f"Context: {context_msg}\n")
            f.write(f"Error: {exc}\n")
            traceback.print_exc(file=f)
    except Exception:
        # If logging itself fails, there is not much we can do safely in a background process
        pass

def _write_pid(timeout_minutes=None):
    try:
        pid = os.getpid()
        quit_time = ""
        if timeout_minutes:
            now = datetime.datetime.now()
            quit_time = (now + datetime.timedelta(minutes=timeout_minutes)).isoformat()

        with open(PID_FILE_PATH, "w") as f:
            f.write(f"{pid}\n{quit_time}")
    except Exception as e:
        _log_error("Failed to write PID file", e)

def _get_all_jiggler_pids():
    """Returns a list of all running daemon PIDs using psutil."""
    pids = set()
    for p in psutil.process_iter(["pid", "cmdline"]):
        try:
            cmdline = p.info["cmdline"]
            if (
                cmdline
                and "internal-daemon" in cmdline
                and "keep_me_alive.cli.main" in cmdline
            ):
                if p.info["pid"] != os.getpid():  # Ensure daemon doesn't kill itself during startup
                    pids.add(p.info["pid"])
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return list(pids)

def get_running_process():
    """Reads the PID file or searches processes and returns (pid, quit_time_str) or (None, '')."""
    pid = None
    quit_time = ""

    if PID_FILE_PATH.exists():
        try:
            with open(PID_FILE_PATH, "r") as f:
                lines = f.read().splitlines()
                if lines:
                    pid = int(lines[0])
                    quit_time = lines[1] if len(lines) > 1 else ""
        except Exception as e:
            _log_error("Failed to read PID file in get_running_process", e)

    is_running_via_pid_file = False
    if pid is not None:
        try:
            p = psutil.Process(pid)
            cmdline = p.cmdline()
            if (
                cmdline
                and "internal-daemon" in cmdline
                and "keep_me_alive.cli.main" in cmdline
            ):
                is_running_via_pid_file = True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    if not is_running_via_pid_file:
        pids = _get_all_jiggler_pids()
        if pids:
            pid = pids[0]
            quit_time = ""
        else:
            return None, ""

    return pid, quit_time

def stop_running_jiggler():
    """Stops all currently running daemon processes."""
    pids = _get_all_jiggler_pids()
    pid_file_pid = None

    if PID_FILE_PATH.exists():
        try:
            with open(PID_FILE_PATH, "r") as f:
                lines = f.read().splitlines()
                if lines:
                    pid_file_pid = int(lines[0])
        except Exception as e:
            _log_error("Failed to read PID file in stop_running_jiggler", e)

    if pid_file_pid and pid_file_pid not in pids and pid_file_pid != os.getpid():
        pids.append(pid_file_pid)

    if not pids:
        print("No background proxy is currently running.")
        return

    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"Stopped running keep_me_alive daemon (PID {pid}).")
        except OSError:
            pass

    try:
        if PID_FILE_PATH.exists():
            PID_FILE_PATH.unlink()
    except OSError:
        pass

def update_timed_quit(timeout_minutes: Optional[int] = None, cancel: bool = False):
    """Updates or cancels the timed-quit for the currently running jiggler."""
    pid, _ = get_running_process()
    if not pid:
        print("Keep Me Alive is not currently running. Start it first.")
        return

    if cancel:
        try:
            with open(PID_FILE_PATH, "w") as f:
                f.write(f"{pid}\n")
            print(f"Timed quit cancelled for Keep Me Alive (PID {pid}).")
        except Exception as e:
            _log_error("Failed to update PID file to cancel timed-quit", e)
        return

    if timeout_minutes is None:
        return

    now = datetime.datetime.now()
    quit_time = (now + datetime.timedelta(minutes=timeout_minutes)).isoformat()
    try:
        with open(PID_FILE_PATH, "w") as f:
            f.write(f"{pid}\n{quit_time}")
        print(f"Keep Me Alive (PID {pid}) will quit in {timeout_minutes} minutes.")
    except Exception as e:
        _log_error("Failed to update PID file for timed-quit", e)

