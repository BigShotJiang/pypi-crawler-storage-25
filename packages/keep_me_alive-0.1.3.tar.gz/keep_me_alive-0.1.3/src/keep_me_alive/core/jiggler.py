import asyncio
import datetime
import os
import random
import signal
import sys

from keep_me_alive.config.settings import load_config
from keep_me_alive.core.actions import trigger_jiggle_action
from keep_me_alive.core.os_utils import (
    begin_anti_app_nap,
    end_anti_app_nap,
    get_cpu_usage,
    get_frontmost_app,
    get_idle_time_seconds,
    has_removable_drives,
    is_media_playing,
    is_on_battery,
    is_process_running,
    is_screen_locked,
)
from keep_me_alive.core.process import (
    PID_FILE_PATH,
    _write_pid,
    stop_running_jiggler,
)


async def _check_enable_triggers(config) -> bool:
    """Evaluate ENABLE triggers concurrently using to_thread for blocking sensors."""
    tasks = []
    loop = asyncio.get_running_loop()

    if config.cpu_threshold > 0:
        tasks.append(loop.run_in_executor(None, get_cpu_usage))
    if config.active_apps:
        apps_list = [x.strip() for x in config.active_apps.split(",") if x.strip()]
        tasks.append(loop.run_in_executor(None, is_process_running, apps_list))
    if config.enable_on_media:
        tasks.append(loop.run_in_executor(None, is_media_playing))
    if config.enable_on_drive:
        tasks.append(loop.run_in_executor(None, has_removable_drives))

    if not tasks:
        return True  # If no enable triggers, implicitly allowed

    results = await asyncio.gather(*tasks)

    # Process results in order
    idx = 0
    if config.cpu_threshold > 0:
        if results[idx] >= config.cpu_threshold:
            return True
        idx += 1
    if config.active_apps:
        if results[idx]:
            return True
        idx += 1
    if config.enable_on_media:
        if results[idx]:
            return True
        idx += 1
    if config.enable_on_drive:
        if results[idx]:
            return True

    return False


async def _check_disable_triggers(config) -> bool:
    """Evaluate DISABLE triggers concurrently. If ANY is true, return True (should disable)."""
    tasks = []
    loop = asyncio.get_running_loop()

    if config.pause_on_screen_lock:
        tasks.append(loop.run_in_executor(None, is_screen_locked))
    if config.pause_on_battery:
        tasks.append(loop.run_in_executor(None, is_on_battery))
    if config.idle_timeout > 0:
        tasks.append(loop.run_in_executor(None, get_idle_time_seconds))
    if config.front_apps:
        tasks.append(loop.run_in_executor(None, get_frontmost_app))

    if not tasks:
        return False

    results = await asyncio.gather(*tasks)

    idx = 0
    if config.pause_on_screen_lock:
        if results[idx]:
            return True
        idx += 1
    if config.pause_on_battery:
        if results[idx]:
            return True
        idx += 1
    if config.idle_timeout > 0:
        if results[idx] < (config.idle_timeout * 60):
            return True
        idx += 1
    if config.front_apps:
        front_app = results[idx].lower()
        banned_apps = [
            x.strip().lower() for x in config.front_apps.split(",") if x.strip()
        ]
        if front_app in banned_apps:
            return True

    return False


async def async_run_background_loop(timeout_minutes=None):
    from keep_me_alive.config.settings import CONFIG_FILE_PATH

    _write_pid(timeout_minutes)

    activity_token = begin_anti_app_nap()

    config_changed = asyncio.Event()

    class DaemonState:
        def __init__(self, t_mins):
            self.last_config_mtime = 0
            self.config = load_config()
            self.quit_time_str = ""
            if t_mins:
                now = datetime.datetime.now()
                self.quit_time_str = (
                    now + datetime.timedelta(minutes=t_mins)
                ).isoformat()

    state = DaemonState(timeout_minutes)

    def cleanup():
        if activity_token is not None:
            end_anti_app_nap(activity_token)
        if PID_FILE_PATH.exists():
            try:
                PID_FILE_PATH.unlink()
            except OSError:
                pass
        sys.exit(0)

    if sys.platform != "win32":
        loop = asyncio.get_running_loop()
        try:
            loop.add_signal_handler(signal.SIGTERM, cleanup)
            loop.add_signal_handler(signal.SIGINT, cleanup)
        except (NotImplementedError, AttributeError):
            pass

    async def _background_file_monitor():
        """Background task for non-blocking file watch and self-heal."""
        loop = asyncio.get_running_loop()
        while True:
            # Self-heal PID file or read fresh quit time
            if not PID_FILE_PATH.exists():
                try:
                    with open(PID_FILE_PATH, "w") as f:
                        f.write(f"{os.getpid()}\n{state.quit_time_str}")
                except OSError:
                    pass
            else:
                try:
                    with open(PID_FILE_PATH, "r") as f:
                        lines = f.read().splitlines()
                        state.quit_time_str = lines[1] if len(lines) > 1 else ""
                except Exception:
                    pass

            if CONFIG_FILE_PATH.exists():
                try:
                    current_mtime = await loop.run_in_executor(
                        None, os.path.getmtime, CONFIG_FILE_PATH
                    )
                    if current_mtime > state.last_config_mtime:
                        state.config = load_config()
                        state.last_config_mtime = current_mtime
                        config_changed.set()
                except OSError:
                    pass
            await asyncio.sleep(1)

    monitor_task = asyncio.create_task(_background_file_monitor())

    try:
        while True:
            config = state.config
            base_interval = config.interval
            jitter_amt = base_interval * (config.jitter_percentage / 100.0)
            randomized_interval = random.uniform(base_interval - jitter_amt, base_interval + jitter_amt)
            
            style = config.style
            distance = config.distance

            if state.quit_time_str:
                try:
                    quit_time = datetime.datetime.fromisoformat(state.quit_time_str)
                    if datetime.datetime.now() >= quit_time:
                        break
                except ValueError:
                    pass

            # 1. Enable Triggers
            has_trigger_config = (
                config.cpu_threshold > 0
                or bool(config.active_apps)
                or config.enable_on_media
                or config.enable_on_drive
            )

            if not has_trigger_config or await _check_enable_triggers(config):
                # 2. Disable Triggers
                if not await _check_disable_triggers(config):
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(None, trigger_jiggle_action, style, distance)

            # Wait for randomized interval, but instantly wake up if config changes
            try:
                await asyncio.wait_for(config_changed.wait(), timeout=randomized_interval)
                config_changed.clear()
            except asyncio.TimeoutError:
                # Natural tick
                pass

    except Exception:
        raise
    finally:
        monitor_task.cancel()
        cleanup()



def run_background_loop(timeout_minutes=None):
    """The main loop that runs the jiggler continuously. Expected to be daemonized."""
    asyncio.run(async_run_background_loop(timeout_minutes))
