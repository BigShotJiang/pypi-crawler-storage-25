import sys
import psutil
import subprocess
from typing import List

_core_graphics = None
_app_services = None
_core_foundation = None
_objc = None

if sys.platform == 'darwin':
    import ctypes
    import ctypes.util
    try:
        _core_graphics = ctypes.cdll.LoadLibrary(ctypes.util.find_library('CoreGraphics'))
    except Exception:
        pass
    try:
        _app_services = ctypes.cdll.LoadLibrary(ctypes.util.find_library('ApplicationServices'))
    except Exception:
        pass
    try:
        _core_foundation = ctypes.cdll.LoadLibrary(ctypes.util.find_library('CoreFoundation'))
    except Exception:
        pass
    try:
        _objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
    except Exception:
        pass

def get_idle_time_seconds() -> float:
    """Returns the system idle time in seconds."""
    if sys.platform == 'darwin':
        if not _core_graphics:
            return 0.0
        import ctypes
        try:
            CGEventSourceSecondsSinceLastEventType = _core_graphics.CGEventSourceSecondsSinceLastEventType
            CGEventSourceSecondsSinceLastEventType.restype = ctypes.c_double
            CGEventSourceSecondsSinceLastEventType.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
            return CGEventSourceSecondsSinceLastEventType(1, 0xFFFFFFFF)
        except Exception:
            return 0.0
    elif sys.platform == 'win32':
        import ctypes
        class LASTINPUTINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
        lastInputInfo = LASTINPUTINFO()
        lastInputInfo.cbSize = ctypes.sizeof(lastInputInfo)
        if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lastInputInfo)):
            millis = ctypes.windll.kernel32.GetTickCount() - lastInputInfo.dwTime
            return millis / 1000.0
        return 0.0
    else:
        return 0.0

def is_on_battery() -> bool:
    """Returns True if the system is running on battery power."""
    try:
        battery = psutil.sensors_battery()
        if battery is not None:
            return not battery.power_plugged
        return False
    except Exception:
        return False

def is_screen_locked() -> bool:
    """Returns True if the system screen is currently locked."""
    if sys.platform == 'darwin':
        if not _app_services or not _core_foundation:
            return False
        import ctypes
        try:
            cg_session_copy_current_dict = _app_services.CGSessionCopyCurrentDictionary
            cg_session_copy_current_dict.restype = ctypes.c_void_p

            cf_string_create_with_cstring = _core_foundation.CFStringCreateWithCString
            cf_string_create_with_cstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
            cf_string_create_with_cstring.restype = ctypes.c_void_p

            cf_dictionary_get_value = _core_foundation.CFDictionaryGetValue
            cf_dictionary_get_value.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            cf_dictionary_get_value.restype = ctypes.c_void_p

            cf_boolean_get_value = _core_foundation.CFBooleanGetValue
            cf_boolean_get_value.argtypes = [ctypes.c_void_p]
            cf_boolean_get_value.restype = ctypes.c_bool

            kCFStringEncodingUTF8 = 0x08000100
            key_str = b"CGSSessionScreenIsLocked"
            cf_key = cf_string_create_with_cstring(None, key_str, kCFStringEncodingUTF8)

            session_dict = cg_session_copy_current_dict()
            if session_dict:
                is_locked_cfbool = cf_dictionary_get_value(session_dict, cf_key)
                if is_locked_cfbool:
                    return bool(cf_boolean_get_value(is_locked_cfbool))
            return False
        except Exception:
            return False
    elif sys.platform == 'win32':
        import ctypes
        # OpenInputDesktop returns 0 if the screen is locked or the secure desktop is active
        # DESKTOP_SWITCHDESKTOP = 0x0100
        try:
            h_desktop = ctypes.windll.user32.OpenInputDesktop(0, False, 0x0100)
            if h_desktop == 0:
                return True
            ctypes.windll.user32.CloseDesktop(h_desktop)
            return False
        except Exception:
            # Fallback to the previous method if OpenInputDesktop fails for other reasons
            return ctypes.windll.user32.GetForegroundWindow() == 0
    else:
        return False

def get_cpu_usage() -> float:
    """Returns the current CPU busy percentage."""
    try:
        return psutil.cpu_percent(interval=0.1)
    except Exception:
        return 0.0

def is_process_running(process_names: List[str]) -> bool:
    """Returns True if any of the given process names are currently running."""
    if not process_names:
        return False
    names_lower = {n.lower() for n in process_names}
    for p in psutil.process_iter(['name']):
        try:
            if p.info['name'] and p.info['name'].lower() in names_lower:
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

def get_frontmost_app() -> str:
    """Returns the name of the currently active frontmost application window."""
    if sys.platform == 'darwin':
        try:
            res = subprocess.run(
                ["osascript", "-e", 'tell application "System Events" to get name of first application process whose frontmost is true'],
                capture_output=True, text=True, timeout=2
            )
            if res.returncode == 0:
                return res.stdout.strip()
        except Exception:
            pass
    elif sys.platform == 'win32':
        import ctypes
        import psutil
        try:
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            pid = ctypes.c_ulong(0)
            ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value > 0:
                p = psutil.Process(pid.value)
                return p.name()
        except Exception:
            pass
    return ""

def is_media_playing() -> bool:
    """Returns True if iTunes, Music, or Spotify is currently playing."""
    if sys.platform == 'darwin':
        apps = ["Music", "iTunes", "Spotify"]
        for app in apps:
            script = f'tell application "System Events" to if exists process "{app}" then tell application "{app}" to get player state'
            try:
                res = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=2)
                if res.returncode == 0 and "playing" in res.stdout.strip().lower():
                    return True
            except Exception:
                pass
    elif sys.platform == 'win32':
        # Fallback: check if common media player processes are running
        # We use a broader set of names common on Windows
        win_apps = ["spotify.exe", "itunes.exe", "music.ui.exe", "vlc.exe", "wmplayer.exe"]
        return is_process_running(win_apps)
    return False

def has_removable_drives() -> bool:
    """Returns True if any removable / external writable drives are mounted."""
    try:
        if sys.platform == 'darwin':
            for part in psutil.disk_partitions(all=False):
                if part.mountpoint.startswith("/Volumes/"):
                    return True
        elif sys.platform == 'win32':
            import ctypes
            # GetLogicalDrives returns a bitmask of available drive letters
            drives = ctypes.windll.kernel32.GetLogicalDrives()
            for i in range(26):
                if drives & (1 << i):
                    drive_letter = chr(ord('A') + i)
                    # DRIVE_REMOVABLE = 2, DRIVE_CDROM = 5
                    drive_type = ctypes.windll.kernel32.GetDriveTypeW(f"{drive_letter}:\\")
                    if drive_type in (2, 5):
                        return True
            return False
    except Exception:
        pass
    return False

def begin_anti_app_nap():
    """Prevent system sleep. On macOS uses NSProcessInfo; on Windows uses SetThreadExecutionState.
    Returns a token for later cleanup, or None on failure."""
    if sys.platform == 'darwin':
        if not _objc:
            return None
        try:
            import ctypes

            _objc.objc_msgSend.restype = ctypes.c_void_p
            _objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

            _objc.objc_getClass.restype = ctypes.c_void_p
            _objc.sel_registerName.restype = ctypes.c_void_p

            NSProcessInfo = _objc.objc_getClass(b"NSProcessInfo")
            sel_processInfo = _objc.sel_registerName(b"processInfo")
            process_info = _objc.objc_msgSend(NSProcessInfo, sel_processInfo)

            NSActivityUserInitiatedAllowingIdleSystemSleep = 0x00FFFFFF

            NSString = _objc.objc_getClass(b"NSString")
            sel_stringWithUTF8 = _objc.sel_registerName(b"stringWithUTF8String:")

            _objc.objc_msgSend.restype = ctypes.c_void_p
            _objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p]
            reason_str = _objc.objc_msgSend(
                NSString, sel_stringWithUTF8, b"Keep Me Alive: No napping on the job!"
            )

            sel_beginActivity = _objc.sel_registerName(b"beginActivityWithOptions:reason:")
            _objc.objc_msgSend.restype = ctypes.c_void_p
            _objc.objc_msgSend.argtypes = [
                ctypes.c_void_p,
                ctypes.c_void_p,
                ctypes.c_uint64,
                ctypes.c_void_p,
            ]
            token = _objc.objc_msgSend(
                process_info,
                sel_beginActivity,
                NSActivityUserInitiatedAllowingIdleSystemSleep,
                reason_str,
            )

            return token
        except Exception:
            return None
    elif sys.platform == 'win32':
        import ctypes
        try:
            # ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
            # ES_CONTINUOUS (0x80000000)
            # ES_SYSTEM_REQUIRED (0x00000001)
            # ES_DISPLAY_REQUIRED (0x00000002)
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000002)
            return "win32_sleep_token"
        except Exception:
            return None
    return None

def end_anti_app_nap(token):
    """Release the anti-sleep / anti-App-Nap activity token."""
    if not token:
        return
    if sys.platform == 'darwin' and _objc:
        try:
            import ctypes
            _objc.objc_msgSend.restype = None
            _objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]

            _objc.objc_getClass.restype = ctypes.c_void_p
            _objc.sel_registerName.restype = ctypes.c_void_p

            NSProcessInfo = _objc.objc_getClass(b"NSProcessInfo")
            sel_processInfo = _objc.sel_registerName(b"processInfo")

            _objc.objc_msgSend.restype = ctypes.c_void_p
            _objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            process_info = _objc.objc_msgSend(NSProcessInfo, sel_processInfo)

            sel_endActivity = _objc.sel_registerName(b"endActivity:")
            _objc.objc_msgSend.restype = None
            _objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
            _objc.objc_msgSend(process_info, sel_endActivity, token)
        except Exception:
            pass
    elif sys.platform == 'win32' and token == "win32_sleep_token":
        import ctypes
        try:
            # ES_CONTINUOUS (0x80000000)
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        except Exception:
            pass
