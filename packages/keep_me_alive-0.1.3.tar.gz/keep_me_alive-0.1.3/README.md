# Keep Me Alive

A modern, cross-platform application that prevents system sleep by simulating activity. It features a robust Python background daemon, a powerful Command Line Interface (CLI), and a sleek Electron-based system tray graphical user interface (GUI).

## Overview

**Keep Me Alive** ensures your computer stays awake when you need it to, without requiring you to manually interact with it. It achieves this through various "jiggle" mechanisms and deep OS-level integration.

**Architecture:**
- **Background Daemon (Python):** The core engine that runs silently in the background. It monitors system state (CPU, battery, idle time, active apps) and intelligently determines when to simulate activity based on your preferences.
- **CLI (`keep-me-alive`):** A powerful terminal interface to control the daemon, manage configurations, and trigger actions.
- **System Tray GUI (Electron):** A user-friendly desktop application that lives in your system tray, providing quick access to preferences and toggle controls.

## Key Features

- **Multiple Jiggle Styles:**
  - **Standard:** Simulates natural, randomized mouse movements.
  - **Click:** Simulates left-clicks at the current cursor position.
  - **Mixed:** Combines various human-like actions including movements, clicks, and keystrokes for ultimate stealth.
- **Intelligent Trigger Conditions:** Automatically activate jiggling when specific conditions are met:
  - CPU usage exceeds a defined threshold.
  - Specific applications or processes are running.
  - Removable drives are mounted.
  - Media is currently playing.
- **Smart Pause Conditions:** Temporarily suspend jiggling to save resources or avoid interruption:
  - System is running on battery power.
  - The screen is locked.
  - Specific applications are in the foreground.
  - Only jiggle after a specified period of system idleness.
- **Timed Quit:** Automatically stop the daemon after a specified duration (e.g., `1h30m`).
- **Hot-Reloading:** Configuration changes made via the GUI or CLI are applied instantly without restarting the daemon.
- **Cross-Platform:** Supports macOS (using AppleScript/ctypes) and Windows (using Win32 APIs).

## Installation

### Prerequisites
- Python 3.8 or higher.
- Node.js and npm (if you plan to use the Electron GUI).

### 1. Install the Core Daemon & CLI

Navigate to the project root directory and install the Python package in editable mode:

```bash
pip install -e .
```

### 2. Install the GUI (Optional but Recommended)

For the easiest experience, download the pre-compiled executable for your operating system from the [GitHub Releases](../../releases) page:
- **macOS**: Download the `.dmg` file.
- **Windows**: Download the `.exe` file.

```bash
cd gui
npm install
```

## Usage

### Using the Command Line Interface (CLI)

The `keep-me-alive` CLI is the primary way to interact with the backend daemon.

```bash
# Start the background daemon
keep-me-alive start

# Stop the background daemon
keep-me-alive stop

# Toggle the daemon state (starts if stopped, stops if running)
keep-me-alive toggle

# Set a timed quit (e.g., stop the daemon in 1 hour and 15 minutes)
keep-me-alive timed-quit 1h15m

# Cancel an active timed quit
keep-me-alive cancel-quit

# Update configuration preferences
keep-me-alive config --interval 60 --style click --distance 5
```

### Using the Graphical User Interface (GUI)

The GUI provides a convenient way to manage your preferences without using the terminal.

**For Developers:**
```bash
# From the gui/ directory, start the Electron app
npm start
```

Alternatively, during development, you can use:
```bash
npm run dev
```

Once running, you will find the **Keep Me Alive** icon in your system tray (or menu bar on macOS). From there, you can easily toggle the jiggler, open preferences, or set a timed quit.

## Configuration & State Management

- **Preferences:** All configuration settings are stored persistently in `~/.keep_me_alive_config`. Both the CLI and GUI update this file directly, and the daemon watches it for real-time changes.
- **Daemon State:** The current Process ID (PID) and any active timed-quit timestamps are tracked in `~/.keep_me_alive.pid`.

## Development & Testing

Keep Me Alive is designed with a clean separation of concerns:
- `src/keep_me_alive/core/`: Contains the core logic, jiggler loop, and OS-specific hooks.
- `src/keep_me_alive/cli/`: Defines the CLI commands using Typer.
- `gui/`: Contains all HTML/CSS/JS and Electron main process code.

### Running Tests

Testing is handled via `pytest`. Execute the following from the root directory to run the test suite:

```bash
pytest
```

## License

This project is licensed under the MIT License.
