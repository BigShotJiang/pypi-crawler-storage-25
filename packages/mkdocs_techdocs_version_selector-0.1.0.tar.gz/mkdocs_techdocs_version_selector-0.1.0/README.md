# mkdocs-techdocs-version-selector

MkDocs plugin that builds versioned TechDocs static sites from a `catalog-info.yaml` versions list.

## What it does

- Reads versions from `catalog-info.yaml` (`techdocsVersions` by default)
- Builds the current docs as usual
- Builds each configured version into a dedicated subdirectory (for example `__v2`, `__v3`)
- Writes a `multiversion.json` manifest that can be consumed by a version selector UI

## Installation

```bash
pip install mkdocs-techdocs-version-selector
```

## Configuration

In your `mkdocs.yml`:

```yaml
plugins:
  - techdocs-version-selector:
      catalog_info_path: catalog-info.yaml
      versions_key: techdocsVersions
      site_subdir_prefix: "__"
      manifest_filename: multiversion.json
```

In your `catalog-info.yaml`, add a versions list (newest first):

```yaml
metadata:
  techdocsVersions:
    - latest: main
    - v2: v2
    - v1: v1
```

## Requirements

- Python 3.9+
- `mkdocs`
- `PyYAML`
- `git` available on `PATH`
- `techdocs-cli` available on `PATH`
