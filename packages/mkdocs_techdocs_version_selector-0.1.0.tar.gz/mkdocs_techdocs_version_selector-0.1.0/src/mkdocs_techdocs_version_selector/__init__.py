from .plugin import TechDocsVersionSelectorPlugin

__all__ = ["TechDocsVersionSelectorPlugin"]