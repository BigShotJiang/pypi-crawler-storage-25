from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import yaml
from mkdocs.config import config_options
from mkdocs.plugins import BasePlugin

# prevent infinite recursion in child builds by marking the environment
CHILD_BUILD_ENV = "TECHDOCS_VERSION_SELECTOR_CHILD_BUILD"


class TechDocsVersionSelectorPlugin(BasePlugin):
    config_scheme = (
        ("catalog_info_path", config_options.Type(str, default="catalog-info.yaml")),
        ("versions_key", config_options.Type(str, default="techdocsVersions")),
        ("site_subdir_prefix", config_options.Type(str, default="__")),
        ("manifest_filename", config_options.Type(str, default="multiversion.json")),
    )

    def __init__(self) -> None:
        self._versions: list[tuple[str, str]] = []
        self._workspace_root: Path | None = None
        self._config_filename: str | None = None
        self._site_dir: Path | None = None

    def on_config(self, config):
        config_file_path = Path(config.config_file_path).resolve()
        self._workspace_root = config_file_path.parent
        self._config_filename = config_file_path.name
        self._site_dir = Path(config["site_dir"]).resolve()

        if os.getenv(CHILD_BUILD_ENV) == "1":
            return config

        catalog_path = self._workspace_root / self.config["catalog_info_path"]
        if not catalog_path.exists():
            self._versions = []
            return config

        catalog_data = self._read_yaml_file(catalog_path)
        if catalog_data is None:
            self._versions = []
            return config

        versions_node = self._find_key_recursive(catalog_data, self.config["versions_key"])
        parsed_versions = self._parse_versions_node(versions_node)
        self._versions = parsed_versions if len(parsed_versions) > 1 else []
        return config

    def on_post_build(self, config):
        if os.getenv(CHILD_BUILD_ENV) == "1":
            return
        if len(self._versions) <= 1:
            return
        if self._workspace_root is None or self._site_dir is None:
            return

        self._write_manifest()
        for version_name, ref_name in self._versions:
            self._build_version_site(version_name, ref_name)

    def _write_manifest(self) -> None:
        if self._site_dir is None:
            return

        prefix = self.config["site_subdir_prefix"]
        manifest_path = self._site_dir / self.config["manifest_filename"]
        manifest: dict[str, dict[str, Any]] = {}

        for index, (version_name, ref_name) in enumerate(self._versions):
            safe_name = self._safe_folder_name(version_name)
            manifest[version_name] = {
                "name": version_name,
                "latest": index == 0,
                "ref": ref_name,
                "path": f"/{prefix}{safe_name}/",
            }

        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")

    def _build_version_site(self, version_name: str, ref_name: str) -> None:
        if self._workspace_root is None or self._config_filename is None or self._site_dir is None:
            return

        git_executable = shutil.which("git")
        if git_executable is None:
            raise RuntimeError("git executable was not found in PATH")

        safe_name = self._safe_folder_name(version_name)
        target_site_dir = self._site_dir / f"{self.config['site_subdir_prefix']}{safe_name}"
        with tempfile.TemporaryDirectory(prefix="techdocs-version-", dir=str(self._workspace_root)) as temp_dir:
            worktree_dir = Path(temp_dir)
            self._run_command(
                [git_executable, "worktree", "add", "--detach", str(worktree_dir), ref_name],
                cwd=self._workspace_root,
            )
            try:
                env = os.environ.copy()
                env[CHILD_BUILD_ENV] = "1"
                command = [
                    "techdocs-cli",
                    "generate",
                    "--no-docker",
                    "--source-dir",
                    str(worktree_dir),
                    "--output-dir",
                    str(target_site_dir),
                ]
                command = self._resolve_command(command)

                self._run_command(
                    command,
                    cwd=worktree_dir,
                    env=env,
                )
            finally:
                self._run_command(
                    [git_executable, "worktree", "remove", "--force", str(worktree_dir)],
                    cwd=self._workspace_root,
                )

    @staticmethod
    def _read_yaml_file(file_path: Path) -> Any:
        with file_path.open("r", encoding="utf-8") as file_handle:
            return yaml.safe_load(file_handle)

    @staticmethod
    def _find_key_recursive(node: Any, key_name: str) -> Any:
        if isinstance(node, dict):
            if key_name in node:
                return node[key_name]
            for value in node.values():
                nested = TechDocsVersionSelectorPlugin._find_key_recursive(value, key_name)
                if nested is not None:
                    return nested
        elif isinstance(node, list):
            for item in node:
                nested = TechDocsVersionSelectorPlugin._find_key_recursive(item, key_name)
                if nested is not None:
                    return nested
        return None

    @staticmethod
    def _parse_versions_node(versions_node: Any) -> list[tuple[str, str]]:
        if not isinstance(versions_node, list):
            return []

        parsed_versions: list[tuple[str, str]] = []
        for item in versions_node:
            if not isinstance(item, dict):
                continue
            if len(item) != 1:
                continue

            version_name, ref_name = next(iter(item.items()))
            if not isinstance(version_name, str) or not isinstance(ref_name, str):
                continue
            parsed_versions.append((version_name.strip(), ref_name.strip()))
        return [entry for entry in parsed_versions if entry[0] and entry[1]]

    @staticmethod
    def _safe_folder_name(version_name: str) -> str:
        sanitized = re.sub(r"[^A-Za-z0-9._-]", "-", version_name).strip(".-_")
        return sanitized or "version"

    @staticmethod
    def _run_command(command: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
        subprocess.run(command, cwd=str(cwd), env=env, check=True)

    @staticmethod
    def _resolve_command(command: list[str]) -> list[str]:
        if not command:
            raise RuntimeError("techdocs_cli_command cannot be empty")

        executable = command[0]
        if Path(executable).exists() or shutil.which(executable) is not None:
            return command

        raise RuntimeError(
            f"Unable to find TechDocs CLI executable '{executable}'. "
        )