# Environment-based color translation and mapping

MC_COLOR_MAP = {
    "<black>": "§0",
    "<dark_blue>": "§1",
    "<dark_green>": "§2",
    "<dark_aqua>": "§3",
    "<dark_red>": "§4",
    "<dark_purple>": "§5",
    "<gold>": "§6",
    "<gray>": "§7",
    "<dark_gray>": "§8",
    "<blue>": "§9",
    "<green>": "§a",
    "<aqua>": "§b",
    "<red>": "§c",
    "<light_purple>": "§d",
    "<yellow>": "§e",
    "<white>": "§f",
    "<reset>": "§r",
    "<bold>": "§l",
    "<italic>": "§o"
}
ASCI_COLOR_MAP = {
    "<black>": "\033[30m",
    "<dark_blue>": "\033[34m",
    "<dark_green>": "\033[32m",
    "<dark_aqua>": "\033[36m",
    "<dark_red>": "\033[31m",
    "<dark_purple>": "\033[35m",
    "<gold>": "\033[33m",
    "<gray>": "\033[37m",
    "<dark_gray>": "\033[90m",
    "<blue>": "\033[94m",
    "<green>": "\033[92m",
    "<aqua>": "\033[96m",
    "<red>": "\033[91m",
    "<light_purple>": "\033[95m",
    "<yellow>": "\033[93m",
    "<white>": "\033[97m",
    "<reset>": "\033[0m",
    "<bold>": "\033[1m",
    "<italic>": "\033[3m"
}