# Project Notes

## Next Update Candidates

- Add a safe session KV helper in core (parameterized `type::thing` patterns for save/load/delete/cleanup).
- Add an admin table reset helper in core (validated table-name deletion for setup/reset flows).
- Add FTS convenience builder(s) for multi-field OR search to reduce large `Q.raw(...)` blocks in app code.
