from setuptools import setup, find_packages

setup(
    name="ppgrns_estatistica",
    version="0.1.0",
    author="Seu Nome",
    description="Biblioteca de suporte estatístico para o PPGRNS - UTFPR",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "matplotlib",
        "seaborn",
        "scipy",
        "openpyxl",
        "odfpy",
        "numpy"
    ],
    python_requires='>=3.8',
)
