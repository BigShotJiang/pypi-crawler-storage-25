📊 A biblioteca

A ppgrns_estatistica é uma biblioteca Python desenvolvida para simplificar a análise de dados estatísticos. O seu objetivo principal é oferecer ferramentas intuitivas e em português para alunos do Programa de Pós-Graduação em Recursos Natuais e Sustentabilidade  que não possuem conhecimentos avançados em programação, automatizando a limpeza e o processamento de dados.



🚀 Funcionalidades Principais

Carregamento Inteligente: Importação facilitada de ficheiros .xlsx e .ods com suporte automático para Google Colab e computador local.

Limpeza Automática: Remoção de caracteres invisíveis (como o \u200b), conversão de vírgulas em pontos e tratamento de espaços em branco logo no carregamento.

Medidas de Posição: Cálculos rápidos de Média, Mediana, Quartis, Percentis e limites para identificação de outliers.

Medidas de Dispersão e Distribuição: Amplitude, Variância, Desvio Padrão, Coeficiente de Variação, Assimetria e Curtose com explicações didáticas no terminal.

Visualização de Dados: Geração de Boxplots e Histogramas altamente personalizáveis com suporte para gravação automática de imagens.

📦 Instalação
Pode instalar a biblioteca diretamente via PyPI:


pip install ppgrns_estatistica

ou no colab

!pip install ppgrns_estatistica  

A biblioteca instalará automaticamente as dependências necessárias, como pandas, matplotlib, numpy, scipy e suportes para planilhas.

🛠️ Como Utilizar
1. Carregar Dados:
A função detecta se está no Google Colab (abre botão de upload) ou no seu PC (abre janela de seleção).

import ppgrns_estatistica as ef

dados = ef.carregardados()

2. Análise Estatística
As funções de cálculo mostram os resultados no terminal por padrão (mostrar=True).

Python
# Cálculo de medidas de posição
Média: ef.media(dados, 'remax')

Mediana: ef.mediana(dados, 'remax')

Moda: ef.moda(dados, 'remax')

Quartil: quartil(dados, *colunas, quartil=1)

Percentil: percentil(dados, *colunas, percentil=50)

limiteinferior / limitesuperior(dados, *colunas)

ef.desviopadrao(dados, 'remax')

# Análise de assimetria e curtose com classificações automáticas
ef.assimetria(dados, 'remin')
ef.curtose(dados, 'remin')

3. Gráficos
Os gráficos são gerados de forma silenciosa e podem ser guardados como ficheiros .png.

Python
# Criar um Boxplot personalizado e guardar a imagem
ef.boxplot(dados, colunas=['remin', 'remax'], 
           titulo="Análise de Remuneração", 
           cores=['lightblue', 'lightgreen'],
           salvar='meu_boxplot')

# Criar um Histograma com intervalos automáticos
ef.histograma(dados, 'remax', numerocolunas=10, salvar='distribuicao_frequencia')



📋 Referência de Funções
Módulo de Posição
media(dados, *colunas, mostrar=False)

mediana(dados, *colunas, mostrar=False)

quartil(dados, *colunas, quartil=1, metodo='exc', mostrar=False)

percentil(dados, *colunas, percentil=50, metodo='exc')

limiteinferior / limitesuperior(dados, *colunas, metodo='exc', mostrar=False)

Módulo de Dispersão
amplitude(dados, *colunas, mostrar=True)

variancia(dados, *colunas, amostral=True, mostrar=True)

desviopadrao(dados, *colunas, amostral=True, mostrar=True)

coeficientevariacao(dados, *colunas, mostrar=True)

assimetria(dados, *colunas, mostrar=True)

curtose(dados, *colunas, mostrar=True)

Módulo de Visualização
boxplot(dados, colunas, larguras, cores, metodos, titulo, horizontal, vertical, qualidade, tamanhohorizontal, tamanhovertical, salvar)

histograma(dados, coluna, numerocolunas, cor, titulo, vertical, qualidade, tamanhohorizontal, tamanhovertical, salvar)