import matplotlib.pyplot as plt
import numpy as np
from .posicao import mediana, quartil, limiteinferior, limitesuperior, _garantir_numerico


def histograma(dados, coluna, numerocolunas=None, cor='lightblue', titulo="",
               vertical="Frequência", qualidade=100,
               tamanhohorizontal=1, tamanhovertical=1, salvar=''):
    """
    Gera um histograma de uma única coluna com rótulos de intervalo automáticos
    e opção de salvamento em arquivo.
    """
    # 1. Preparação e Limpeza
    dados_num = _garantir_numerico(dados[[coluna]], [coluna])
    serie = dados_num[coluna].dropna()

    if serie.empty:
        print(f"❌ Erro: A coluna '{coluna}' não possui dados numéricos válidos.")
        return

    # 2. Cálculo dos Bins (Intervalos)
    counts, bin_edges = np.histogram(serie, bins=numerocolunas if numerocolunas else 'auto')
    n_bins = len(counts)

    # 3. Criar os rótulos dos intervalos para o eixo X
    labels = []
    for i in range(len(bin_edges) - 1):
        labels.append(f"{bin_edges[i]:.2f} - {bin_edges[i + 1]:.2f}")

    # 4. Configuração da Figura
    plt.figure(figsize=(10 * tamanhohorizontal, 6 * tamanhovertical), dpi=qualidade)

    x_pos = np.arange(len(labels))
    plt.bar(x_pos, counts, width=0.95, color=cor, edgecolor='black', alpha=0.8)

    # 5. Lógica de Rotação Dinâmica do Eixo X
    rotacao = 0
    if 6 <= n_bins <= 12:
        rotacao = 45
    elif n_bins > 12:
        rotacao = 90

    plt.xticks(x_pos, labels, rotation=rotacao, ha='right' if rotacao > 0 else 'center')

    # 6. Estética
    if titulo:
        plt.title(titulo, fontsize=14, pad=15)
    else:
        plt.title(f"Distribuição de Frequência: {coluna.capitalize()}", fontsize=12)

    plt.ylabel(vertical, fontsize=11)
    plt.xlabel("Intervalos de Classe", fontsize=11)
    plt.grid(axis='y', linestyle='--', alpha=0.6)

    plt.tight_layout()

    # 7. Lógica de Salvamento
    if salvar:
        nome_arquivo = f"{salvar}.png"
        plt.savefig(nome_arquivo, bbox_inches='tight')
        print(f"💾 Gráfico salvo com sucesso: {nome_arquivo}")

    plt.show()