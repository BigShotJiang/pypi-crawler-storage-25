import pandas as pd
import numpy as np

def _garantir_numerico(dados, colunas):
    """
    Força a conversão das colunas para números, removendo lixo invisível.
    """
    df_limpo = dados[list(colunas)].copy()
    for col in df_limpo.columns:
        if not pd.api.types.is_numeric_dtype(df_limpo[col]):
            df_limpo[col] = (df_limpo[col].astype(str)
                             .str.replace('\u200b', '', regex=False)
                             .str.replace(',', '.', regex=False)
                             .str.strip())
            df_limpo[col] = pd.to_numeric(df_limpo[col], errors='coerce')
    return df_limpo

def _selecionar_colunas(dados, colunas):
    """
    Se o aluno não passar nomes, pegamos TODAS as colunas.
    """
    if len(colunas) == 0:
        return dados.columns.tolist()
    return list(colunas)

def media(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    res = dados_num.mean(numeric_only=True)

    if mostrar:
        print("\n--- Média ---")
        print(res.to_string())
    return res

def mediana(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    res = dados_num.median(numeric_only=True)

    if mostrar:
        print("\n--- Mediana ---")
        print(res.to_string())
    return res

def quartil(dados, *colunas, quartil=1, metodo='exc', mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    q_map = {1: 25, 2: 50, 3: 75}
    p = q_map.get(quartil, 25)
    metodo_np = 'weibull' if metodo.lower() == 'exc' else 'linear'

    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            try:
                res_dict[col] = np.percentile(serie, p, method=metodo_np)
            except:
                res_dict[col] = np.percentile(serie, p)  # Fallback

    res = pd.Series(res_dict)
    if mostrar:
        print(f"\n--- {quartil}º Quartil ({metodo.upper()}) ---")
        print(res.to_string())
    return res

def percentil(dados, *colunas, percentil=50, metodo='exc', mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    metodo_np = 'weibull' if metodo.lower() == 'exc' else 'linear'

    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            try:
                val = np.percentile(serie, percentil, method=metodo_np)
                res_dict[col] = val
            except:
                if metodo.lower() == 'exc':
                    serie_sorted = np.sort(serie)
                    n = len(serie_sorted)
                    pos = (percentil / 100) * (n + 1) - 1
                    low = int(np.floor(pos))
                    high = int(np.ceil(pos))
                    if pos < 0: res_dict[col] = serie_sorted[0]
                    elif pos >= n - 1: res_dict[col] = serie_sorted[-1]
                    else:
                        d = pos - low
                        res_dict[col] = serie_sorted[low] + (serie_sorted[high] - serie_sorted[low]) * d
                else:
                    res_dict[col] = np.percentile(serie, percentil)

    res = pd.Series(res_dict)
    if mostrar:
        print(f"\n--- Percentil {percentil} ({metodo.upper()}) ---")
        if res.empty: print("⚠️ Sem dados numéricos.")
        else: print(res.to_string())
    return res

def limiteinferior(dados, *colunas, metodo='exc', mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q1 - (1.5 * (q3 - q1))
    if mostrar:
        print(f"\n--- Limite Inferior ({metodo.upper()}) ---")
        print(res.to_string())
    return res

def limitesuperior(dados, *colunas, metodo='exc', mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q3 + (1.5 * (q3 - q1))
    if mostrar:
        print(f"\n--- Limite Superior ({metodo.upper()}) ---")
        print(res.to_string())
    return res