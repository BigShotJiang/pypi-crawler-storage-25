import pandas as pd
import numpy as np
from .posicao import _selecionar_colunas, _garantir_numerico, media, quartil

def amplitude(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    res = dados_num.max() - dados_num.min()

    if mostrar:
        print("\n--- Amplitude Total ---")
        print(res.to_string())
    return res

def variancia(dados, *colunas, amostral=True, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    graus_liberdade = 1 if amostral else 0
    res = dados_num.var(ddof=graus_liberdade)

    if mostrar:
        tipo = "Amostral" if amostral else "Populacional"
        print(f"\n--- Variância ({tipo}) ---")
        print(res.to_string())
    return res

def desviopadrao(dados, *colunas, amostral=True, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    graus_liberdade = 1 if amostral else 0
    res = dados_num.std(ddof=graus_liberdade)

    if mostrar:
        tipo = "Amostral" if amostral else "Populacional"
        print(f"\n--- Desvio Padrão ({tipo}) ---")
        print(res.to_string())
    return res

def coeficientevariacao(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    # Chamadas internas SILENCIADAS (mostrar=False)
    m = media(dados, *cols, mostrar=False)
    dp = desviopadrao(dados, *cols, amostral=True, mostrar=False)
    res = (dp / m) * 100

    if mostrar:
        print("\n--- Coeficiente de Variação (%) ---")
        print(res.to_string())
    return res

def iqr(dados, *colunas, metodo='exc', mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    # Chamadas internas SILENCIADAS (mostrar=False)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q3 - q1

    if mostrar:
        print(f"\n--- Amplitude Interquartílica (IQR - {metodo.upper()}) ---")
        print(res.to_string())
    return res

def assimetria(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    res = dados_num.skew()

    if mostrar:
        print("\n--- Assimetria (Skewness) ---")
        for col, val in res.items():
            if abs(val) < 0.5:
                classif, explica = "Simétrica", "A distribuição é aproximadamente normal."
            elif abs(val) <= 1:
                classif, explica = "Moderada", "A distribuição tem uma leve inclinação."
            else:
                classif, explica = "Forte", "A distribuição é altamente inclinada."
            sentido = (" (Positiva/Direita)" if val > 0 else " (Negativa/Esquerda)") if abs(val) >= 0.5 else ""
            print(f"{col}: {val:.4f} -> {classif}{sentido}\n   └─ {explica}")
    return res

def curtose(dados, *colunas, mostrar=True):
    cols = _selecionar_colunas(dados, colunas)
    dados_num = _garantir_numerico(dados[cols], cols)
    res = dados_num.kurt()
    if mostrar:
        print("\n--- Curtose (Kurtosis) ---")
        for col, val in res.items():
            if abs(val) < 0.5: classif, explica = "Mesocúrtica", "A curvatura é semelhante à de uma normal."
            elif val >= 0.5: classif, explica = "Leptocúrtica", "A curva é mais pontiaguda (caudas pesadas)."
            else: classif, explica = "Platicúrtica", "A curva é mais achatada (caudas leves)."
            print(f"{col}: {val:.4f} -> {classif}\n   └─ {explica}")
    return res