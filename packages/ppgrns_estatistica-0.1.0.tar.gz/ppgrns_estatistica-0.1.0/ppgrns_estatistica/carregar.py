import pandas as pd
import sys
import io
import os


def carregardados():
    """
    Detecta o ambiente e carrega um arquivo .xlsx ou .ods.
    No Colab: Abre interface de upload.
    No PC: Abre uma janela de seleção de arquivo (File Explorer).
    """

    # 1. Detecção de Ambiente
    no_colab = 'google.colab' in sys.modules
    df = None
    nome_arquivo = ""

    try:
        if no_colab:
            from google.colab import files
            print("🌐 Ambiente Detectado: Google Colab")
            uploaded = files.upload()
            if not uploaded:
                return None
            nome_arquivo = list(uploaded.keys())[0]
            conteudo = uploaded[nome_arquivo]

            # Carregamento específico para Colab (via buffer de memória)
            if nome_arquivo.endswith('.ods'):
                df = pd.read_excel(io.BytesIO(conteudo), engine='odf')
            else:
                df = pd.read_excel(io.BytesIO(conteudo))

        else:
            # Ambiente PC Local
            import tkinter as tk
            from tkinter import filedialog
            print("💻 Ambiente Detectado: Computador Local")

            # Abre o seletor de arquivos do Windows/Mac/Linux sem mostrar a janela principal do Tkinter
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)  # Garante que a janela apareça na frente
            caminho_arquivo = filedialog.askopenfilename(
                title="Selecione sua planilha",
                filetypes=[("Planilhas", "*.xlsx *.ods")]
            )
            root.destroy()

            if not caminho_arquivo:
                print("Operação cancelada.")
                return None

            nome_arquivo = os.path.basename(caminho_arquivo)
            if nome_arquivo.endswith('.ods'):
                df = pd.read_excel(caminho_arquivo, engine='odf')
            else:
                df = pd.read_excel(caminho_arquivo)

        # 2. Limpeza Padronizada (independente do ambiente)
        if df is not None:
            # Limpa nomes de colunas
            # 1. Limpa os nomes das colunas
            df.columns = (df.columns
                          .str.replace('\u200b', '', regex=False)
                          .str.strip()
                          .str.lower())

            # 2. Limpa o conteúdo das células
            for col in df.columns:
                if df[col].dtype == 'object':  # Se a coluna for lida como texto
                    df[col] = (df[col]
                               .astype(str)
                               .str.replace('\u200b', '', regex=False)  # Remove invisível das células
                               .str.replace(',', '.', regex=False)  # Troca vírgula por ponto
                               .str.strip())  # Tira espaços nas pontas

                    # Tenta converter para número, se falhar (ex: coluna de nomes), vira NaN
                    df[col] = pd.to_numeric(df[col], errors='coerce')

            return df

    except Exception as e:
        print(f"❌ Erro ao carregar: {e}")
        return None