from .carregar import carregardados
from .posicao import media, mediana, quartil, percentil, limiteinferior, limitesuperior
from .dispersao import amplitude, variancia, desviopadrao, coeficientevariacao, iqr, assimetria, curtose
from .boxplot import boxplot
from .histograma import histograma
