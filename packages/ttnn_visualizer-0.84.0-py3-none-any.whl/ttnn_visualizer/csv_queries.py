# SPDX-License-Identifier: Apache-2.0
#
# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC

import csv
import json
import logging
import os
import tempfile
import traceback
from io import StringIO
from pathlib import Path
from typing import (
    Dict,
    List,
    Literal,
    Optional,
    Union,
    overload,
)

import pandas as pd
import zstd
from tt_perf_report import perf_report
from ttnn_visualizer.exceptions import DataFormatError
from ttnn_visualizer.models import Instance

logger = logging.getLogger(__name__)

# Cell values after NaN sanitization; matches LocalCSVQueryRunner.execute_query.
CSVCell = Optional[Union[str, float, int]]
CSVQueryResult = Union[
    List[List[CSVCell]],
    List[Dict[str, CSVCell]],
]


class LocalCSVQueryRunner:
    def __init__(self, file_path: Union[str, Path], offset: int = 0):
        self.file_path = file_path
        self.offset = offset
        self.df: Optional[pd.DataFrame] = None

    def __enter__(self):
        # Load the CSV file
        self.df = pd.read_csv(self.file_path, skiprows=self.offset)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.df = None

    def get_csv_header(self) -> Dict[str, int]:
        if self.df is None:
            raise RuntimeError(
                "DataFrame is not loaded. Ensure the runner is used within a context."
            )
        return {col: idx + 1 for idx, col in enumerate(self.df.columns)}

    def execute_query(
        self,
        columns: Optional[List[str]] = None,
        filters: Optional[Dict[str, Union[str, None]]] = None,
        as_dict: bool = False,
        limit: Optional[int] = None,
    ) -> CSVQueryResult:
        """
        Executes a query on the loaded DataFrame with optional limit.
        :param columns: List of columns to select.
        :param filters: Dictionary of column-value pairs to filter the rows.
        :param as_dict: Whether to return results as a list of dictionaries.
        :param limit: Maximum number of rows to return.
        :return: List of lists or dictionaries containing the result rows.
        """
        if self.df is None:
            raise RuntimeError(
                "DataFrame is not loaded. Ensure the runner is used within a context."
            )

        # Apply filters if provided
        df_filtered = self.df
        if filters:
            for col, value in filters.items():
                if value is None:
                    df_filtered = df_filtered[df_filtered[col].isna()]
                else:
                    df_filtered = df_filtered[df_filtered[col] == value]

        # Select specified columns
        if columns:
            result_df = df_filtered[columns]
        else:
            result_df = df_filtered

        # Apply limit if specified
        if limit is not None:
            result_df = result_df.head(limit)

        # Replace NaN with None in the query results
        sanitized_df = result_df.applymap(lambda x: None if pd.isna(x) else x)

        if as_dict:
            sanitized_columns = {
                col: col.replace(" ", "_") for col in sanitized_df.columns
            }
            sanitized_df = sanitized_df.copy()
            sanitized_df.rename(columns=sanitized_columns, inplace=True)
            return sanitized_df.to_dict(orient="records")

        return sanitized_df.values.tolist()


class NPEQueries:
    NPE_FOLDER = "npe_viz"
    MANIFEST_FILE = "manifest.json"

    @staticmethod
    def get_npe_manifest(instance: Instance):
        if not instance.performance_path:
            raise ValueError("instance.performance_path is None")
        file_path = Path(
            instance.performance_path,
            NPEQueries.NPE_FOLDER,
            NPEQueries.MANIFEST_FILE,
        )
        with open(file_path, "r") as f:
            return json.load(f)

    @staticmethod
    def get_npe_timeline(instance: Instance, filename: str):
        if not filename:
            raise ValueError(
                "filename parameter is required and cannot be None or empty"
            )

        if not instance.performance_path:
            raise ValueError("instance.performance_path is None")

        file_path = Path(instance.performance_path, NPEQueries.NPE_FOLDER, filename)

        if filename.endswith(".zst"):
            with open(file_path, "rb") as file:
                compressed_data = file.read()
                uncompressed_data = zstd.uncompress(compressed_data)
                return json.loads(uncompressed_data)
        else:
            with open(file_path, "r") as f:
                return json.load(f)


class DeviceLogProfilerQueries:
    DEVICE_LOG_FILE = "profile_log_device.csv"
    DEVICE_LOG_COLUMNS = [
        "PCIe slot",
        "core_x",
        "core_y",
        "RISC processor type",
        "timer_id",
        "time[cycles since reset]",
        "stat value",
        "run ID",
        "run host ID",
        "zone name",
        "zone phase",
        "source line",
        "source file",
    ]

    def __init__(self, instance: Instance):
        """
        Initialize the profiler with a instance object.
        The instance determines whether to use a local or remote runner.
        """
        self.instance = instance
        self.runner: Optional[LocalCSVQueryRunner] = None

    def __enter__(self):
        """
        Determine the appropriate query runner based on the instance's remote connection.
        """
        if not self.instance.performance_path:
            raise ValueError("instance.performance_path is None")
        self.runner = LocalCSVQueryRunner(
            file_path=Path(self.instance.performance_path).joinpath(
                self.DEVICE_LOG_FILE
            ),
            offset=1,  # Skip the first line for device log files
        )

        self.runner.__enter__()

        self.runner.df.columns = self.DEVICE_LOG_COLUMNS
        self.runner.df.columns = self.runner.df.columns.str.strip()

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Ensure resources are cleaned up when exiting the context.
        """
        if self.runner:
            self.runner.__exit__(exc_type, exc_val, exc_tb)

    def query_by_timer_id(self, timer_id: str, as_dict: bool = False) -> CSVQueryResult:
        """
        Example query: Filter rows by a specific timer_id and optionally return results as dictionaries.
        """
        if self.runner is None:
            raise RuntimeError(
                "DeviceLogProfilerQueries must be used as a context manager"
            )
        return self.runner.execute_query(
            columns=[],
            filters={"timer_id": timer_id},
            as_dict=as_dict,
        )

    def query_zone_statistics(
        self, zone_name: str, as_dict: bool = False, limit: Optional[int] = None
    ) -> CSVQueryResult:
        """
        Example query: Retrieve statistics for a specific zone name.
        """
        if self.runner is None:
            raise RuntimeError(
                "DeviceLogProfilerQueries must be used as a context manager"
            )
        return self.runner.execute_query(
            columns=[],
            filters={"zone name": zone_name},
            as_dict=as_dict,
            limit=limit,
        )

    @overload
    def get_all_entries(
        self, as_dict: Literal[False] = False, limit: Optional[int] = None
    ) -> List[List[CSVCell]]: ...

    @overload
    def get_all_entries(
        self, as_dict: Literal[True], limit: Optional[int] = None
    ) -> List[Dict[str, CSVCell]]: ...

    def get_all_entries(
        self, as_dict: bool = False, limit: Optional[int] = None
    ) -> CSVQueryResult:
        """
        Fetch all entries from the device log.
        """
        if self.runner is None:
            raise RuntimeError(
                "DeviceLogProfilerQueries must be used as a context manager"
            )
        return self.runner.execute_query(
            columns=self.DEVICE_LOG_COLUMNS, as_dict=as_dict, limit=limit
        )

    @staticmethod
    def get_raw_csv(instance: Instance):
        if not instance.performance_path:
            raise ValueError("instance.performance_path is None")
        file_path = Path(
            instance.performance_path, DeviceLogProfilerQueries.DEVICE_LOG_FILE
        )
        with open(file_path, "r") as f:
            return f.read()


class OpsPerformanceQueries:
    PERF_RESULTS_PREFIX = "ops_perf_results"

    def __init__(self, instance: Instance):
        """
        Initialize the performance profiler with a instance object.
        """
        self.instance = instance
        self.runner: Optional[LocalCSVQueryRunner] = None

    def __enter__(self):
        """

        :return:
        """
        file_path = OpsPerformanceQueries.get_local_ops_perf_file_path(self.instance)
        self.runner = LocalCSVQueryRunner(file_path=file_path, offset=0)
        self.runner.__enter__()
        self.runner.df.columns = self.runner.df.columns.str.strip()

        return self

    @staticmethod
    def get_local_ops_perf_file_path(instance):
        if not instance.performance_path:
            raise ValueError("instance.performance_path is None")
        performance_path = Path(instance.performance_path)

        # Find the latest file with the correct prefix
        perf_files = list(
            performance_path.glob(f"{OpsPerformanceQueries.PERF_RESULTS_PREFIX}.csv")
        ) + list(
            performance_path.glob(f"{OpsPerformanceQueries.PERF_RESULTS_PREFIX}_*.csv")
        )
        if not perf_files:
            raise FileNotFoundError(
                f"No performance results file found at {performance_path}"
            )

        # Use the latest file
        latest_file = max(perf_files, key=os.path.getctime)
        return str(latest_file)

    @staticmethod
    def get_remote_ops_perf_file_path(instance):
        from ttnn_visualizer.sftp_operations import resolve_file_path

        remote_profile_folder = instance.remote_profile_folder.remotePath
        return resolve_file_path(
            instance.remote_connection,
            f"{remote_profile_folder}/{OpsPerformanceQueries.PERF_RESULTS_PREFIX}*",
        )

    @staticmethod
    def get_raw_csv(instance):
        with open(OpsPerformanceQueries.get_local_ops_perf_file_path(instance)) as f:
            return f.read()

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Clean up resources when exiting the context.
        """
        if self.runner:
            self.runner.__exit__(exc_type, exc_val, exc_tb)

    def query_by_op_code(self, op_code: str, as_dict: bool = False) -> CSVQueryResult:
        """
        Query for rows with a specific OP CODE.
        """
        if self.runner is None:
            raise RuntimeError(
                "OpsPerformanceQueries must be used as a context manager"
            )
        return self.runner.execute_query(
            filters={"OP CODE": op_code}, as_dict=as_dict, columns=None
        )

    @overload
    def get_all_entries(
        self, as_dict: Literal[False] = False, limit: Optional[int] = None
    ) -> List[List[CSVCell]]: ...

    @overload
    def get_all_entries(
        self, as_dict: Literal[True], limit: Optional[int] = None
    ) -> List[Dict[str, CSVCell]]: ...

    def get_all_entries(
        self, as_dict: bool = False, limit: Optional[int] = None
    ) -> CSVQueryResult:
        """
        Fetch all entries from the performance log.
        """
        if self.runner is None:
            raise RuntimeError(
                "OpsPerformanceQueries must be used as a context manager"
            )
        return self.runner.execute_query(columns=[], as_dict=as_dict, limit=limit)

    @staticmethod
    def get_all_folders(directory: str) -> List[str]:
        """
        Get a list of all folder names in the specified directory.

        :param directory: Path to the /profiles directory.
        :return: List of folder names.
        """
        try:
            return [
                folder.name for folder in Path(directory).iterdir() if folder.is_dir()
            ]
        except Exception as e:
            raise RuntimeError(f"Error accessing directory: {e}")


class OpsPerformanceReportQueries:
    REPORT_COLUMNS = [
        "id",
        "total_percent",
        "bound",
        "op_code",
        "device",
        "device_time",
        "op_to_op_gap",
        "cores",
        "dram",
        "dram_percent",
        "flops",
        "flops_percent",
        "math_fidelity",
        "output_datatype",
        "input_0_datatype",
        "input_1_datatype",
        "dram_sharded",
        "input_0_memory",
        "inner_dim_block_size",
        "output_subblock_h",
        "output_subblock_w",
        "global_call_count",
        "advice",
        "raw_op_code",
    ]

    STACKED_REPORT_COLUMNS = [
        "%",
        "OP Code Joined",
        "Device_Time_Sum_us",
        "Ops_count",
        "Op_Category",
        "Flops_min",
        "Flops_max",
        "Flops_mean",
        "Flops_std",
        "Flops_weighted_mean",
    ]

    STACKED_REPORT_COLUMNS_WITH_DEVICE = [
        "%",
        "OP Code Joined",
        "Device",
        "Device_Time_Sum_us",
        "Ops_count",
        "Op_Category",
        "Flops_min",
        "Flops_max",
        "Flops_mean",
        "Flops_std",
        "Flops_weighted_mean",
    ]

    PASSTHROUGH_COLUMNS = {
        "pm_ideal_ns": "PM IDEAL [ns]",
    }

    DEFAULT_START_SIGNPOST = None
    DEFAULT_END_SIGNPOST = None
    DEFAULT_IGNORE_SIGNPOSTS = True
    DEFAULT_PRINT_SIGNPOSTS = True
    DEFAULT_MIN_PERCENTAGE = 0.5
    DEFAULT_ID_RANGE = None
    DEFAULT_ARCH = None
    DEFAULT_NO_ADVICE = False
    DEFAULT_TRACING_MODE = False
    DEFAULT_RAW_OP_CODES = True
    DEFAULT_NO_HOST_OPS = False
    DEFAULT_NO_STACKED_REPORT = False
    DEFAULT_NO_STACK_BY_IN0 = True
    DEFAULT_MERGE_DEVICES = True
    DEFAULT_STACKED_CSV_FILE = None  # Stacked report CSV output file
    DEFAULT_NO_SUMMARY = False
    DEFAULT_SUMMARY_FILE = None  # Stacked report output file
    DEFAULT_CLASSIC_COLORS = False  # Colour scheme for plotted stacked report
    DEFAULT_GROUP_BY = None  # Group by method for stacked report

    @staticmethod
    def extract_signposts(csv_file):
        logger.info("Reading raw CSV for signpost extraction...")
        csv_file.seek(0)
        ops_perf_results = []
        ops_perf_results_reader = csv.DictReader(csv_file)

        for row in ops_perf_results_reader:
            ops_perf_results.append(row)

        # Returns a list of unique signposts in the order they appear
        # TODO: Signpost names are not unique but tt-perf-report treats them as such
        captured_signposts = set()
        signposts = []
        for index, row in enumerate(ops_perf_results):
            if row.get("OP TYPE") == "signpost":
                op_code = row["OP CODE"]
                op_id = index + 2  # Match IDs with row numbers in ops perf results csv
                if not any(s["op_code"] == op_code for s in signposts):
                    captured_signposts.add(op_code)
                    signposts.append(
                        {
                            "id": op_id,
                            "op_code": op_code,
                        }
                    )

        return ops_perf_results, signposts

    @staticmethod
    def set_op_type_from_results(processed_row, idx, ops_perf_results):
        if 0 <= idx < len(ops_perf_results):
            processed_row["op_type"] = ops_perf_results[idx].get("OP TYPE")
        else:
            processed_row["op_type"] = None

        return processed_row

    @staticmethod
    def set_op_type_from_signposts(processed_row, signposts):
        if "op_code" in processed_row and any(
            processed_row["op_code"] in signpost["op_code"] for signpost in signposts
        ):
            processed_row["op_type"] = "signpost"
        else:
            processed_row["op_type"] = "unknown"

        return processed_row

    @staticmethod
    def cleanup_temp_files(files):
        for file in files:
            if isinstance(file, tempfile._TemporaryFileWrapper):
                file_path = file.name
            else:
                file_path = file
            if os.path.exists(file_path):
                try:
                    os.unlink(file_path)
                    logger.info(f"Deleted temporary file: {file_path}")
                except Exception as e:
                    logger.warning(f"Could not delete temporary file {file_path}: {e}")

    @staticmethod
    def set_hash_from_results(processed_row, idx, ops_perf_results):
        if 0 <= idx < len(ops_perf_results):
            hash_value = ops_perf_results[idx].get("PROGRAM HASH")
            processed_row["hash"] = hash_value if hash_value else None

            cache_hit_value = ops_perf_results[idx].get("PROGRAM CACHE HIT")
            if cache_hit_value == "True":
                processed_row["cache_hit"] = True
            elif cache_hit_value == "False":
                processed_row["cache_hit"] = False
            else:
                processed_row["cache_hit"] = None
        else:
            processed_row["hash"] = None
            processed_row["cache_hit"] = None

        return processed_row

    @classmethod
    def generate_report(cls, instance, **kwargs):
        raw_csv = OpsPerformanceQueries.get_raw_csv(instance)
        csv_file = StringIO(raw_csv)

        # Validate that we have CSV data with rows
        csv_lines = raw_csv.strip().split("\n")
        logger.info(f"CSV has {len(csv_lines)} lines (header + data rows)")

        if len(csv_lines) < 2:
            raise DataFormatError(
                f"CSV must have at least header + 1 data row, got {len(csv_lines)} lines"
            )

        # Determine if we should skip stacked report
        data_row_count = len(csv_lines) - 1
        no_stacked_report = kwargs.get(
            "no_stacked_report", cls.DEFAULT_NO_STACKED_REPORT
        )

        if data_row_count <= 1:
            logger.info("Skipping stacked report generation: insufficient data rows")
            no_stacked_report = True

        try:
            csv_summary_file = tempfile.NamedTemporaryFile(delete=False)
            csv_output_file = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
            # The perf_report library creates files with format: {csv_summary_name}.csv and {csv_summary_name}.png
            summary_csv_path = f"{csv_summary_file.name}.csv"
            summary_png_path = f"{csv_summary_file.name}.png"
            csv_summary_file.close()
            csv_output_file.close()

            start_signpost = kwargs.get("start_signpost", cls.DEFAULT_START_SIGNPOST)
            end_signpost = kwargs.get("end_signpost", cls.DEFAULT_END_SIGNPOST)
            print_signposts = kwargs.get("print_signposts", cls.DEFAULT_PRINT_SIGNPOSTS)
            no_host_ops = kwargs.get("hide_host_ops", cls.DEFAULT_NO_HOST_OPS)
            merge_devices = kwargs.get("merge_devices", cls.DEFAULT_MERGE_DEVICES)
            tracing_mode = kwargs.get("tracing_mode", cls.DEFAULT_TRACING_MODE)
            group_by = kwargs.get("group_by", cls.DEFAULT_GROUP_BY)

            if start_signpost or end_signpost:
                ignore_signposts = False
            else:
                ignore_signposts = cls.DEFAULT_IGNORE_SIGNPOSTS

            try:
                perf_report.generate_perf_report(
                    [csv_file],
                    start_signpost,
                    end_signpost,
                    ignore_signposts,
                    print_signposts,
                    cls.DEFAULT_MIN_PERCENTAGE,
                    cls.DEFAULT_ID_RANGE,
                    cls.DEFAULT_ARCH,
                    csv_output_file.name,
                    cls.DEFAULT_NO_ADVICE,
                    tracing_mode,
                    cls.DEFAULT_RAW_OP_CODES,
                    no_host_ops,
                    cls.DEFAULT_NO_SUMMARY,
                    group_by,
                    cls.DEFAULT_CLASSIC_COLORS,
                    csv_summary_file.name,
                    no_stacked_report,
                    cls.DEFAULT_NO_STACK_BY_IN0,
                    cls.DEFAULT_STACKED_CSV_FILE,
                    not merge_devices,
                )
            except Exception as e:
                logger.error(f"Error loading report: {e}")
                logger.error(f"Full traceback:\n{traceback.format_exc()}")
                raise DataFormatError(e)

            try:
                ops_perf_results, signposts = cls.extract_signposts(csv_file)
            except Exception as e:
                logger.error(f"Error extracting signposts: {e}")
                ops_perf_results = []
                signposts = []

            logger.info(f"Found {len(signposts)} signposts...")

            report = []

            try:
                logger.info(f"Processing CSV output file: {csv_output_file.name}")
                if os.path.exists(csv_output_file.name):
                    try:
                        with open(csv_output_file.name, newline="") as csvfile:
                            reader = csv.reader(csvfile, delimiter=",")
                            header = next(reader, None)

                            if not header:
                                logger.warning(
                                    "CSV output file is empty, no report data generated"
                                )
                                report = []
                            else:
                                for row in reader:
                                    try:
                                        op_id = int(row[0])
                                        # IDs in result column one correspond to row numbers in ops perf results csv
                                        idx = op_id - 2

                                        processed_row = {
                                            column: row[index]
                                            for index, column in enumerate(
                                                cls.REPORT_COLUMNS
                                            )
                                            if index < len(row)
                                        }

                                        if (
                                            "advice" in processed_row
                                            and processed_row["advice"]
                                        ):
                                            processed_row["advice"] = processed_row[
                                                "advice"
                                            ].split(" • ")
                                        else:
                                            processed_row["advice"] = []

                                        for (
                                            key,
                                            value,
                                        ) in cls.PASSTHROUGH_COLUMNS.items():
                                            if 0 <= idx < len(ops_perf_results):
                                                processed_row[key] = ops_perf_results[
                                                    idx
                                                ].get(value)
                                            else:
                                                processed_row[key] = None

                                        # Get the op type from the raw file for this row as it is not returned from tt-perf-report
                                        cls.set_op_type_from_results(
                                            processed_row, idx, ops_perf_results
                                        )

                                        cls.set_hash_from_results(
                                            processed_row, idx, ops_perf_results
                                        )

                                        report.append(processed_row)
                                    except (ValueError, IndexError) as e:
                                        logger.error(f"Error processing row {row}: {e}")
                                        continue
                    except csv.Error as e:
                        logger.error(f"CSV parsing error: {e}")
                        raise DataFormatError() from e
                else:
                    logger.warning(
                        f"CSV output file not created: {csv_output_file.name}"
                    )
            except Exception as e:
                logger.error(f"Error processing CSV output file: {e}")
                report = []

            stacked_report = []

            if not no_stacked_report:
                try:
                    logger.info(f"Processing stacked report file: {summary_csv_path}")
                    if os.path.exists(summary_csv_path):
                        try:
                            with open(summary_csv_path, newline="") as csvfile:
                                reader = csv.reader(csvfile, delimiter=",")
                                next(reader, None)

                                # Use the appropriate column list based on merge_devices flag
                                stacked_columns = (
                                    cls.STACKED_REPORT_COLUMNS_WITH_DEVICE
                                    if not merge_devices
                                    else cls.STACKED_REPORT_COLUMNS
                                )

                                for row in reader:
                                    processed_row = {
                                        column: row[index]
                                        for index, column in enumerate(stacked_columns)
                                        if index < len(row)
                                    }

                                    # Map "OP Code Joined" to "op_code" for consistency with non-stacked report
                                    if "OP Code Joined" in processed_row:
                                        processed_row["op_code"] = processed_row[
                                            "OP Code Joined"
                                        ]
                                        del processed_row["OP Code Joined"]

                                    cls.set_op_type_from_signposts(
                                        processed_row, signposts
                                    )

                                    stacked_report.append(processed_row)
                        except csv.Error as e:
                            logger.error(f"CSV parsing error in stacked report: {e}")
                            raise DataFormatError() from e
                    else:
                        logger.warning(
                            f"Stacked report file not created: {summary_csv_path}"
                        )
                except Exception as e:
                    logger.error(f"Error processing stacked report: {e}")
                    # Don't raise, just log - stacked report is optional
            else:
                logger.info("Skipping stacked report processing as per configuration")

            return {
                "report": report,
                "stacked_report": stacked_report,
                "signposts": signposts,
            }

        finally:
            # Ensure cleanup always happens, even if exceptions are raised
            cls.cleanup_temp_files(
                [csv_output_file, summary_csv_path, summary_png_path, csv_summary_file]
            )
