# SPDX-License-Identifier: Apache-2.0
#
# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC

import dataclasses
import json
import logging
import platform
import re
import shutil
import time
import urllib
import urllib.request
from http import HTTPStatus
from pathlib import Path
from typing import List, Optional

import orjson
import yaml
import zstd
from flask import Blueprint, Response, abort, current_app, jsonify, request, session
from ttnn_visualizer.csv_queries import (
    DeviceLogProfilerQueries,
    NPEQueries,
    OpsPerformanceQueries,
    OpsPerformanceReportQueries,
)
from ttnn_visualizer.decorators import local_only, with_instance
from ttnn_visualizer.enums import ConnectionTestStates
from ttnn_visualizer.exceptions import (
    AuthenticationFailedException,
    DataFormatError,
    RemoteConnectionException,
    RemoteFileReadException,
    error_response,
    response_bad_request,
    response_forbidden,
    response_internal_server_error,
    response_not_found,
    response_unprocessable_entity,
)
from ttnn_visualizer.file_uploads import (
    extract_folder_name_from_files,
    extract_npe_name,
    save_uploaded_files,
    validate_files,
)
from ttnn_visualizer.instances import get_instances, update_instance
from ttnn_visualizer.models import (
    Instance,
    RemoteConnection,
    RemoteReportFolder,
    ReportLocation,
    StatusMessage,
)
from ttnn_visualizer.queries import DatabaseQueries
from ttnn_visualizer.serializers import (
    serialize_buffer,
    serialize_buffer_pages,
    serialize_devices,
    serialize_operation,
    serialize_operation_buffers,
    serialize_operations,
    serialize_operations_buffers,
    serialize_tensors,
)
from ttnn_visualizer.sftp_operations import (
    check_remote_path_exists,
    check_remote_path_for_reports,
    get_cluster_desc,
    get_remote_performance_folders,
    get_remote_profiler_folders,
    sync_remote_performance_folders,
    sync_remote_profiler_folders,
)
from ttnn_visualizer.ssh_client import SSHClient
from ttnn_visualizer.stack_trace_source import (
    check_stack_source_local,
    check_stack_source_remote,
    read_stack_source_local,
    read_stack_source_remote,
    stack_source_response,
)
from ttnn_visualizer.utils import (
    create_path_resolver,
    get_mesh_descriptor_paths,
    pick_profiler_config_paths,
    read_last_synced_file,
    read_profiler_config_api_payload,
    read_profiler_report_name,
    str_to_bool,
    timer,
)


def test_ssh_connection(connection) -> bool:
    """Test SSH connection by running a simple command."""
    ssh_client = SSHClient(connection)
    return ssh_client.test_connection()


logger = logging.getLogger(__name__)

api = Blueprint("api", __name__)


def _optional_rank_query_param() -> Optional[int]:
    """
    Parse optional ``?rank=`` for multi-host report DBs.
    Returns None if the parameter is absent or empty.
    """
    if "rank" not in request.args:
        return None
    raw = request.args.get("rank")
    if raw is None or raw == "":
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        abort(
            400,
            description="Invalid query parameter 'rank': expected an integer.",
        )
        return None


_NONZERO_RANK_UNSUPPORTED_MSG = (
    "This report database does not store per-rank data. "
    "Omit the rank query parameter or use rank=0 only."
)


def _reject_nonzero_rank_on_legacy_db(db: DatabaseQueries, rank: Optional[int]):
    """
    Legacy reports only represent rank 0. If the client asks for a different rank
    but the schema has no ``rank`` column, return 422 instead of returning all rows
    (which would misleadingly appear as rank 0 in the API).
    """
    if rank is None or rank == 0:
        return None
    if db.report_has_rank_column():
        return None
    return response_unprocessable_entity(_NONZERO_RANK_UNSUPPORTED_MSG)


@api.before_request
def _trim_session_report_lists():
    """Keep session cookie under size limits by capping report lists (FIFO)."""
    if not current_app.config.get("SERVER_MODE"):
        return
    max_reports = current_app.config["SESSION_MAX_UPLOADED_REPORTS"]
    for key in ("profiler_paths", "performance_paths", "npe_paths", "instances"):
        lst = session.get(key, [])
        if len(lst) > max_reports:
            session[key] = lst[-max_reports:]


@api.route("/system_capabilities", methods=["GET"])
def get_system_capabilities():
    """Return host/backend capabilities so the frontend can adapt (e.g. disable remote sync in hosted mode)."""
    capabilities = {
        "os": platform.system(),
        "processor": platform.machine(),
        "remote_sync_methods": {
            "sftp": shutil.which("sftp") is not None,
            "rsync": shutil.which("rsync") is not None,
        },
    }

    return Response(
        orjson.dumps(capabilities),
        mimetype="application/json",
    )


@api.route("/operations", methods=["GET"])
@with_instance
@timer
def operation_list(instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        operations = list(
            db.query_operations(db.merge_rank_filter("operations", None, rank))
        )
        operations.sort(key=lambda o: o.operation_id)
        operation_arguments = list(
            db.query_operation_arguments(
                db.merge_rank_filter("operation_arguments", None, rank)
            )
        )
        device_operations = list(
            db.query_device_operations(
                db.merge_rank_filter("captured_graph", None, rank)
            )
        )
        stack_traces = list(
            db.query_stack_traces(db.merge_rank_filter("stack_traces", None, rank))
        )
        outputs = list(
            db.query_output_tensors(db.merge_rank_filter("output_tensors", None, rank))
        )
        tensors = list(db.query_tensors(db.merge_rank_filter("tensors", None, rank)))
        inputs = list(
            db.query_input_tensors(db.merge_rank_filter("input_tensors", None, rank))
        )
        devices = list(db.query_devices(db.merge_rank_filter("devices", None, rank)))
        producers_consumers = list(db.query_producers_consumers(rank=rank))

        error_records = None
        if db._check_table_exists("errors"):
            error_records = list(
                db.query_error_records(db.merge_rank_filter("errors", None, rank))
            )

        serialized_operations = serialize_operations(
            inputs,
            operation_arguments,
            operations,
            outputs,
            stack_traces,
            tensors,
            devices,
            producers_consumers,
            device_operations,
            error_records,
        )
        return Response(
            orjson.dumps(serialized_operations),
            mimetype="application/json",
        )


@api.route("/operations/<operation_id>", methods=["GET"])
@with_instance
@timer
def operation_detail(operation_id, instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected

        device_id = request.args.get("device_id", None)
        operations = list(
            db.query_operations(
                db.merge_rank_filter(
                    "operations",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )

        if not operations:
            return response_not_found()

        operation = operations[0]

        buffers = list(
            db.query_buffers(
                db.merge_rank_filter(
                    "buffers",
                    {"operation_id": operation_id, "device_id": device_id},
                    rank,
                )
            )
        )
        operation_arguments = list(
            db.query_operation_arguments(
                db.merge_rank_filter(
                    "operation_arguments",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )
        stack_traces = list(
            db.query_stack_traces(
                db.merge_rank_filter(
                    "stack_traces",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )

        stack_trace = None
        for st in stack_traces:
            if st.rank == operation.rank:
                stack_trace = st
                break
        if stack_trace is None and stack_traces:
            stack_trace = stack_traces[0]

        inputs = list(
            db.query_input_tensors(
                db.merge_rank_filter(
                    "input_tensors",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )
        outputs = list(
            db.query_output_tensors(
                db.merge_rank_filter(
                    "output_tensors",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )

        input_tensor_ids = [i.tensor_id for i in inputs]
        output_tensor_ids = [o.tensor_id for o in outputs]
        tensor_ids = input_tensor_ids + output_tensor_ids
        # Empty tensor_ids: query_tensors skips empty IN lists and would return all tensors.
        if not tensor_ids:
            tensors = []
            local_comparisons = []
            global_comparisons = []
        else:
            tensors = list(
                db.query_tensors(
                    db.merge_rank_filter(
                        "tensors",
                        {"tensor_id": tensor_ids},
                        rank,
                    )
                )
            )
            local_comparisons = list(
                db.query_tensor_comparisons(filters={"tensor_id": tensor_ids})
            )
            global_comparisons = list(
                db.query_tensor_comparisons(
                    local=False, filters={"tensor_id": tensor_ids}
                )
            )

        device_operations = db.query_device_operations(
            db.merge_rank_filter(
                "captured_graph",
                {"operation_id": operation_id},
                rank,
            )
        )

        producers_consumers = list(
            filter(
                lambda pc: pc.tensor_id in tensor_ids,
                db.query_producers_consumers(rank=rank),
            )
        )

        devices = list(db.query_devices(db.merge_rank_filter("devices", None, rank)))

        error_record = None
        if db._check_table_exists("errors"):
            error_records = list(
                db.query_error_records(
                    db.merge_rank_filter(
                        "errors",
                        {"operation_id": operation_id},
                        rank,
                    )
                )
            )
            for e in error_records:
                if e.rank == operation.rank:
                    error_record = e
                    break
            if error_record is None and error_records:
                error_record = error_records[0]

        serialized_operation = serialize_operation(
            buffers,
            inputs,
            operation,
            operation_arguments,
            outputs,
            stack_trace,
            tensors,
            global_comparisons,
            local_comparisons,
            devices,
            producers_consumers,
            device_operations,
            error_record,
        )

        return Response(
            orjson.dumps(serialized_operation),
            mimetype="application/json",
        )


@api.route("/operation-history", methods=["GET"])
@with_instance
@timer
def operation_history(instance: Instance):
    operation_history_filename = "operation_history.json"
    operation_history_file = (
        Path(str(instance.profiler_path)).parent / operation_history_filename
    )
    if not operation_history_file.exists():
        return jsonify([])
    with open(operation_history_file, "r") as file:
        return Response(
            orjson.dumps(json.load(file)),
            mimetype="application/json",
        )


@api.route("/errors", methods=["GET"])
@with_instance
@timer
def errors_list(instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        if not db._check_table_exists("errors"):
            return response_unprocessable_entity(
                message="Error records table does not exist in this report database."
            )

        error_records = list(
            db.query_error_records(db.merge_rank_filter("errors", None, rank))
        )
        serialized_errors = [dataclasses.asdict(error) for error in error_records]

        return Response(
            orjson.dumps(serialized_errors),
            mimetype="application/json",
        )


@api.route("/report_metadata", methods=["GET"])
@with_instance
@timer
def report_metadata(instance: Instance):
    with DatabaseQueries(instance) as db:
        if not db._check_table_exists("report_metadata"):
            return response_unprocessable_entity(
                message="Report metadata table does not exist in this report database."
            )
        rows = db.query_report_metadata()
        payload = {row[0]: row[1] for row in rows}
        return Response(
            orjson.dumps(payload),
            mimetype="application/json",
        )


@api.route("/config")
@with_instance
@timer
def get_config(instance: Instance):
    """
    Return the profiler ``config.json`` object for this report.

    For multi-host ranked configs (``config_<n>_of_<world>.json``), the response
    is the same shape as a single config file: one JSON object. Default is
    logical rank 0 (``config_1_of_<world>.json``). Pass ``?rank=<logical_rank>``
    to read another host's file (debugging).
    """
    report_dir = Path(str(instance.profiler_path)).parent
    rank_param = _optional_rank_query_param()
    logical_rank = 0 if rank_param is None else rank_param

    payload, err = read_profiler_config_api_payload(report_dir, logical_rank)
    if err == "rank_out_of_range":
        return response_bad_request(
            f"Invalid rank for this report: {logical_rank}. "
            "Rank must be within the world size for this report's config files."
        )
    if err == "missing_rank_file":
        return response_not_found(f"No profiler config file for rank {logical_rank}.")
    if err == "parse_error":
        return {}
    if payload is None:
        return {}
    return Response(
        orjson.dumps(payload),
        mimetype="application/json",
    )


@api.route("/tensors", methods=["GET"])
@with_instance
@timer
def tensors_list(instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        device_id = request.args.get("device_id", None)
        tensor_filters: dict = {}
        if device_id is not None:
            tensor_filters["device_id"] = device_id
        tensors = list(
            db.query_tensors(db.merge_rank_filter("tensors", tensor_filters, rank))
        )
        if rank is not None and "rank" in db._get_table_columns("tensors"):
            tensor_ids = [t.tensor_id for t in tensors]
            if tensor_ids:
                local_comparisons = list(
                    db.query_tensor_comparisons(filters={"tensor_id": tensor_ids})
                )
                global_comparisons = list(
                    db.query_tensor_comparisons(
                        local=False, filters={"tensor_id": tensor_ids}
                    )
                )
            else:
                local_comparisons = []
                global_comparisons = []
        else:
            local_comparisons = list(db.query_tensor_comparisons())
            global_comparisons = list(db.query_tensor_comparisons(local=False))
        producers_consumers = list(db.query_producers_consumers(rank=rank))
        serialized_tensors = serialize_tensors(
            tensors, producers_consumers, local_comparisons, global_comparisons
        )
        return Response(
            orjson.dumps(serialized_tensors),
            mimetype="application/json",
        )


@api.route("/buffer", methods=["GET"])
@with_instance
@timer
def buffer_detail(instance: Instance):
    address = request.args.get("address")
    operation_id = request.args.get("operation_id")

    if not address or not operation_id:
        return response_bad_request()

    if operation_id and str.isdigit(operation_id):
        operation_id = int(operation_id)
    else:
        return response_bad_request()

    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        buffer = db.query_next_buffer(operation_id, address, rank=rank)
        if not buffer:
            return response_not_found()
        return Response(
            orjson.dumps(dataclasses.asdict(buffer)),
            mimetype="application/json",
        )


@api.route("/buffer-pages", methods=["GET"])
@with_instance
@timer
def buffer_pages(instance: Instance):
    address = request.args.get("address")
    operation_id = request.args.get("operation_id")
    buffer_type = request.args.get("buffer_type", "")
    device_id = request.args.get("device_id", None)

    if address:
        addresses = [addr.strip() for addr in address.split(",")]
    else:
        addresses = None

    if buffer_type and str.isdigit(buffer_type):
        buffer_type = int(buffer_type)
    else:
        buffer_type = None

    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        page_filters = {
            "operation_id": operation_id,
            "device_id": device_id,
            "address": addresses,
            "buffer_type": buffer_type,
        }
        buffers = list(
            list(
                db.query_buffer_pages(
                    db.merge_rank_filter("buffer_pages", page_filters, rank)
                )
            )
        )
        return Response(
            orjson.dumps(serialize_buffer_pages(buffers)),
            mimetype="application/json",
        )


@api.route("/tensors/<tensor_id>", methods=["GET"])
@with_instance
@timer
def tensor_detail(tensor_id, instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        tensors = list(
            db.query_tensors(
                db.merge_rank_filter("tensors", {"tensor_id": tensor_id}, rank)
            )
        )
        if not tensors:
            return response_not_found()

        return Response(
            orjson.dumps(dataclasses.asdict(tensors[0])),
            mimetype="application/json",
        )


@api.route("/buffers", methods=["GET"])
@with_instance
def get_all_buffers(instance: Instance):
    buffer_type = request.args.get("buffer_type", "")
    device_id = request.args.get("device_id", None)
    if buffer_type and str.isdigit(buffer_type):
        buffer_type = int(buffer_type)
    else:
        buffer_type = None

    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        buffers = list(
            db.query_buffers(
                db.merge_rank_filter(
                    "buffers",
                    {"buffer_type": buffer_type, "device_id": device_id},
                    rank,
                )
            )
        )
        serialized = [serialize_buffer(b) for b in buffers]
        return Response(orjson.dumps(serialized), mimetype="application/json")


@api.route("/operation-buffers", methods=["GET"])
@with_instance
def get_operations_buffers(instance: Instance):
    buffer_type = request.args.get("buffer_type", "")
    device_id = request.args.get("device_id", None)

    if buffer_type and str.isdigit(buffer_type):
        buffer_type = int(buffer_type)
    else:
        buffer_type = None

    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        buffers = list(
            db.query_buffers(
                db.merge_rank_filter(
                    "buffers",
                    {"buffer_type": buffer_type, "device_id": device_id},
                    rank,
                )
            )
        )
        operations = list(
            db.query_operations(db.merge_rank_filter("operations", None, rank))
        )
        return Response(
            orjson.dumps(serialize_operations_buffers(operations, buffers)),
            mimetype="application/json",
        )


@api.route("/operation-buffers/<operation_id>", methods=["GET"])
@with_instance
def get_operation_buffers(operation_id, instance: Instance):
    buffer_type = request.args.get("buffer_type", "")
    device_id = request.args.get("device_id", None)
    if buffer_type and str.isdigit(buffer_type):
        buffer_type = int(buffer_type)
    else:
        buffer_type = None

    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        operations = list(
            db.query_operations(
                db.merge_rank_filter(
                    "operations",
                    {"operation_id": operation_id},
                    rank,
                )
            )
        )
        if not operations:
            return response_not_found()
        operation = operations[0]
        buffers = list(
            db.query_buffers(
                db.merge_rank_filter(
                    "buffers",
                    {
                        "operation_id": operation_id,
                        "buffer_type": buffer_type,
                        "device_id": device_id,
                    },
                    rank,
                )
            )
        )
        if not operation:
            return response_not_found()

        return Response(
            orjson.dumps(serialize_operation_buffers(operation, buffers)),
            mimetype="application/json",
        )


@api.route("/profiler", methods=["GET"])
@with_instance
def get_profiler_data_list(instance: Instance):
    # Use PathResolver to get the base path for profiler reports
    resolver = create_path_resolver(current_app)

    # Note: "profiler" in app terminology maps to tt-metal's ttnn/reports
    path = resolver.get_base_report_path("profiler")

    if not path.exists():
        if resolver.is_direct_report_mode:
            logger.warning(f"TT-Metal profiler reports not found: {path}")
            return []
        else:
            path.mkdir(parents=True, exist_ok=True)

    valid_dirs = []

    if current_app.config["SERVER_MODE"]:
        session_instances = session.get("instances", [])
        instances = get_instances(session_instances)
        db_paths = [
            instance.profiler_path for instance in instances if instance.profiler_path
        ]
        db_directory_names = [str(Path(db_path).parent.name) for db_path in db_paths]
        session_paths = session.get("profiler_paths", [])
        session_directory_names = [
            str(Path(session_path).parent.name) for session_path in session_paths
        ]
        demo_directory_names = []
        demo_pattern = re.compile(r"^demo", re.IGNORECASE)
        for report in path.glob("*"):
            if demo_pattern.match(report.name):
                demo_directory_names.append(report.name)
        directory_names = list(
            set(db_directory_names + session_directory_names + demo_directory_names)
        )
    else:
        directory_names = [
            directory.name for directory in path.iterdir() if directory.is_dir()
        ]

    # Sort directory names by modified time (most recent first)
    def get_modified_time(dir_name):
        dir_path = Path(path) / dir_name
        if dir_path.exists():
            return dir_path.stat().st_mtime
        return 0

    directory_names.sort(key=get_modified_time, reverse=True)

    for dir_name in directory_names:
        dir_path = Path(path) / dir_name
        files = list(dir_path.glob("**/*"))
        report_name = None
        if pick_profiler_config_paths(dir_path):
            report_name = read_profiler_report_name(dir_path)
        else:
            report_name = dir_path.name

        # Would like to use the existing validate_files function but there's a type difference I'm not sure how to handle
        if not any(file.name == "db.sqlite" for file in files):
            continue

        valid_dirs.append({"path": dir_path.name, "reportName": report_name})

    return Response(orjson.dumps(valid_dirs), mimetype="application/json")


@api.route("/profiler/<profiler_name>", methods=["DELETE"])
@with_instance
@local_only
def delete_profiler_report(profiler_name, instance: Instance):
    is_remote = (
        instance.active_report
        and instance.active_report.profiler_location == ReportLocation.REMOTE.value
    )
    config_key = "REMOTE_DATA_DIRECTORY" if is_remote else "LOCAL_DATA_DIRECTORY"
    data_directory = Path(current_app.config[config_key])

    if not profiler_name:
        return response_bad_request("Report name is required.")

    if is_remote:
        connection = RemoteConnection.model_validate(
            instance.remote_connection, strict=False
        )
        path = (
            data_directory
            / connection.host
            / current_app.config["PROFILER_DIRECTORY_NAME"]
        )
    else:
        path = (
            data_directory
            / current_app.config["PROFILER_DIRECTORY_NAME"]
            / profiler_name
        )

    if instance.active_report and instance.active_report.profiler_name == profiler_name:
        instance_id = request.args.get("instanceId")
        update_instance(instance_id=instance_id, profiler_name="")

    if path.exists() and path.is_dir():
        shutil.rmtree(path)
    else:
        return response_not_found(f"Report does not exist: {path}")

    return Response(
        status=HTTPStatus.NO_CONTENT, response=f"Report deleted successfully: {path}"
    )


@api.route("/performance", methods=["GET"])
@with_instance
def get_performance_data_list(instance: Instance):
    # Use PathResolver to get the base path for performance reports
    resolver = create_path_resolver(current_app)

    # Note: "performance" in app terminology maps to tt-metal's profiler/reports
    path = resolver.get_base_report_path("performance")

    if not path.exists():
        if resolver.is_direct_report_mode:
            logger.warning(f"TT-Metal performance reports not found: {path}")
            return jsonify([])

    if current_app.config["SERVER_MODE"]:
        session_instances = session.get("instances", [])
        instances = get_instances(session_instances)
        db_paths = [
            instance.performance_path
            for instance in instances
            if instance.performance_path
        ]
        db_directory_names = [str(Path(db_path).name) for db_path in db_paths]
        session_paths = session.get("performance_paths", [])
        session_directory_names = [
            str(Path(session_path).name) for session_path in session_paths
        ]
        demo_directory_names = []
        demo_pattern = re.compile(r"^demo", re.IGNORECASE)
        for report in path.glob("*"):
            if demo_pattern.match(report.name):
                demo_directory_names.append(report.name)
        directory_names = list(
            set(db_directory_names + session_directory_names + demo_directory_names)
        )
    else:
        # PathResolver already handles remote vs local logic
        directory_names = (
            [directory.name for directory in path.iterdir() if directory.is_dir()]
            if path.exists()
            else []
        )

    valid_dirs = []

    # Sort directory names by modified time (most recent first)
    def get_modified_time(dir_name):
        dir_path = Path(path) / dir_name
        if dir_path.exists():
            return dir_path.stat().st_mtime
        return 0

    directory_names.sort(key=get_modified_time, reverse=True)

    for dir_name in directory_names:
        dir_path = Path(path) / dir_name
        files = list(dir_path.glob("**/*"))

        # Would like to use the existing validate_files function but there's a type difference I'm not sure how to handle
        if not any(file.name == "profile_log_device.csv" for file in files):
            continue
        if not any(file.name == "tracy_profile_log_host.tracy" for file in files):
            continue
        if not any(file.name.startswith("ops_perf_results") for file in files):
            continue

        valid_dirs.append(
            {
                "path": dir_path.name,
                "reportName": dir_path.name,
            }
        )

    return Response(orjson.dumps(valid_dirs), mimetype="application/json")


@api.route("/performance/device-log", methods=["GET"])
@with_instance
def get_performance_data(instance: Instance):
    if not instance.performance_path:
        return response_not_found()

    with DeviceLogProfilerQueries(instance) as csv:
        result = csv.get_all_entries(as_dict=True, limit=100)
        return Response(orjson.dumps(result), mimetype="application/json")


@api.route("/performance/perf-results", methods=["GET"])
@with_instance
def get_profiler_performance_data(instance: Instance):
    if not instance.performance_path:
        return response_not_found()
    with OpsPerformanceQueries(instance) as csv:
        # result = csv.query_by_op_code(op_code="(torch) contiguous", as_dict=True)
        result = csv.get_all_entries(as_dict=True, limit=100)
        return Response(orjson.dumps(result), mimetype="application/json")


@api.route("/performance/<performance_name>", methods=["DELETE"])
@with_instance
@local_only
def delete_performance_report(performance_name, instance: Instance):
    is_remote = (
        instance.active_report
        and instance.active_report.performance_location == ReportLocation.REMOTE.value
    )
    config_key = "REMOTE_DATA_DIRECTORY" if is_remote else "LOCAL_DATA_DIRECTORY"
    data_directory = Path(current_app.config[config_key])

    if not performance_name:
        return response_bad_request("Report name is required.")

    if is_remote:
        connection = RemoteConnection.model_validate(
            instance.remote_connection, strict=False
        )
        path = (
            data_directory
            / connection.host
            / current_app.config["PERFORMANCE_DIRECTORY_NAME"]
        )
    else:
        path = (
            data_directory
            / current_app.config["PERFORMANCE_DIRECTORY_NAME"]
            / performance_name
        )

    if (
        instance.active_report
        and instance.active_report.performance_name == performance_name
    ):
        instance_id = request.args.get("instanceId")
        update_instance(instance_id=instance_id, performance_name="")

    if path.exists() and path.is_dir():
        shutil.rmtree(path)
    else:
        return response_not_found(f"Report does not exist: {path}")

    return Response(
        status=HTTPStatus.NO_CONTENT, response=f"Report deleted successfully: {path}"
    )


@api.route("/performance/perf-results/raw", methods=["GET"])
@with_instance
def get_performance_results_data_raw(instance: Instance):
    if not instance.performance_path:
        return response_not_found()
    content = OpsPerformanceQueries.get_raw_csv(instance)
    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=op_perf_results.csv"},
    )


@api.route("/performance/perf-results/report", methods=["GET"])
@with_instance
def get_performance_results_report(instance: Instance):
    if not instance.performance_path:
        return response_bad_request("No performance data found for instance.")

    name = request.args.get("name", None)
    start_signpost = request.args.get("start_signpost", None)
    end_signpost = request.args.get("end_signpost", None)
    print_signposts = str_to_bool(request.args.get("print_signposts", "true"))
    hide_host_ops = str_to_bool(request.args.get("hide_host_ops", "true"))
    merge_devices = str_to_bool(request.args.get("merge_devices", "true"))
    tracing_mode = str_to_bool(request.args.get("tracing_mode", "false"))
    group_by = request.args.get("group_by", None)

    if name and not current_app.config["SERVER_MODE"]:
        performance_path = Path(instance.performance_path).parent / name
        instance.performance_path = str(performance_path)
        logger.info(f"************ Performance path set to {instance.performance_path}")

    try:
        report = OpsPerformanceReportQueries.generate_report(
            instance,
            start_signpost=start_signpost,
            print_signposts=print_signposts,
            end_signpost=end_signpost,
            hide_host_ops=hide_host_ops,
            merge_devices=merge_devices,
            tracing_mode=tracing_mode,
            group_by=group_by,
        )
    except DataFormatError as error:
        return response_unprocessable_entity(str(error))

    return Response(orjson.dumps(report), mimetype="application/json")


# this is no longer used atm. keeping for now until confirmed "not needed"
@api.route("/performance/device-log/raw", methods=["GET"])
@with_instance
def get_performance_data_raw(instance: Instance):
    if not instance.performance_path:
        return response_not_found()

    name = request.args.get("name", None)

    if name and not current_app.config["SERVER_MODE"]:
        performance_path = Path(instance.performance_path).parent / name
        instance.performance_path = str(performance_path)
        logger.info(f"************ Performance path set to {instance.performance_path}")

    content = DeviceLogProfilerQueries.get_raw_csv(instance)

    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=profile_log_device.csv"},
    )


@api.route("/performance/device-log/meta", methods=["GET"])
@with_instance
def get_performance_device_meta(instance: Instance):
    def get_first_line(file_path: Path) -> str:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.readline().strip()

    def parse_arch_and_freq(line: str):
        arch_match = re.search(r"ARCH:\s*([\w\d_]+)", line)
        freq_match = re.search(r"CHIP_FREQ\[MHz\]:\s*(\d+)", line)
        cores_match = re.search(r"Max Compute Cores:\s*(\d+)", line)

        architecture = arch_match.group(1) if arch_match else None
        frequency = int(freq_match.group(1)) if freq_match else None
        max_cores = int(cores_match.group(1)) if cores_match else None

        return {
            "architecture": architecture,
            "frequency": frequency,
            "max_cores": max_cores,
        }

    name = request.args.get("name", None)

    if not instance.performance_path:
        return response_not_found()

    if name and not current_app.config["SERVER_MODE"]:
        performance_path = Path(instance.performance_path).parent / name
        instance.performance_path = str(performance_path)
        logger.info(f"************ Performance path set to {instance.performance_path}")

    file_path = Path(
        instance.performance_path,
        DeviceLogProfilerQueries.DEVICE_LOG_FILE,
    )

    if not file_path.exists():
        return response_not_found()

    try:
        first_line = get_first_line(file_path)
        meta = parse_arch_and_freq(first_line)
        return jsonify(meta)

    except Exception as e:
        logger.exception("Failed to parse device meta")
        return response_internal_server_error(str(e))


@api.route("/performance/npe/manifest", methods=["GET"])
@with_instance
def get_npe_manifest(instance: Instance):
    if not instance.performance_path:
        return response_not_found()
    try:
        content = NPEQueries.get_npe_manifest(instance)
    except FileNotFoundError:
        return jsonify([])

    return Response(orjson.dumps(content), mimetype="application/json")


@api.route("/performance/npe/timeline", methods=["GET"])
@with_instance
def get_npe_timeline(instance: Instance):
    if not instance.performance_path:
        return response_not_found()

    filename = request.args.get("filename", default=None)

    if not filename:
        return Response(orjson.dumps({}), mimetype="application/json")

    filename = Path(filename).name

    try:
        content = NPEQueries.get_npe_timeline(instance, filename=filename)
    except FileNotFoundError:
        return Response(orjson.dumps({}), mimetype="application/json")

    return Response(orjson.dumps(content), mimetype="application/json")


@api.route("/performance/device-log/zone/<zone>", methods=["GET"])
@with_instance
def get_zone_statistics(zone, instance: Instance):
    if not instance.performance_path:
        return response_not_found()
    with DeviceLogProfilerQueries(instance) as csv:
        result = csv.query_zone_statistics(zone_name=zone, as_dict=True)
        return Response(orjson.dumps(result), mimetype="application/json")


@api.route("/devices", methods=["GET"])
@with_instance
def get_devices(instance: Instance):
    rank = _optional_rank_query_param()
    with DatabaseQueries(instance) as db:
        rejected = _reject_nonzero_rank_on_legacy_db(db, rank)
        if rejected is not None:
            return rejected
        devices = list(db.query_devices(db.merge_rank_filter("devices", None, rank)))
        return Response(
            orjson.dumps(serialize_devices(devices)),
            mimetype="application/json",
        )


@api.route("/local/upload/profiler", methods=["POST"])
def create_profiler_files():
    files = request.files.getlist("files")
    folder_name = request.form.get(
        "folderName"
    )  # Optional folder name - Used for Safari compatibility
    profiler_directory = (
        current_app.config["LOCAL_DATA_DIRECTORY"]
        / current_app.config["PROFILER_DIRECTORY_NAME"]
    )

    if not validate_files(files, {"db.sqlite"}, folder_name=folder_name):
        return StatusMessage(
            status=ConnectionTestStates.FAILED,
            message="Invalid project directory.",
        ).model_dump()

    if not profiler_directory.exists():
        profiler_directory.mkdir(parents=True, exist_ok=True)

    if folder_name:
        parent_folder_name = folder_name
    else:
        parent_folder_name = extract_folder_name_from_files(files)

    logger.info(f"Writing report files to {profiler_directory}/{parent_folder_name}")

    try:
        paths = save_uploaded_files(files, profiler_directory, folder_name)
    except DataFormatError:
        return response_unprocessable_entity()

    profiler_path = next((p for p in paths if Path(p).name == "db.sqlite"), None)

    instance_id = request.args.get("instanceId")

    update_instance(
        instance_id=instance_id,
        profiler_name=parent_folder_name,
        profiler_location=ReportLocation.LOCAL.value,
        clear_remote=True,
        profiler_path=str(profiler_path) if profiler_path else None,
    )

    report_dir = profiler_directory / parent_folder_name
    report_name = None
    if pick_profiler_config_paths(report_dir):
        report_name = read_profiler_report_name(report_dir)
    else:
        report_name = parent_folder_name

    if current_app.config["SERVER_MODE"]:
        # Set session data (FIFO cap to avoid cookie size limits)
        max_reports = current_app.config["SESSION_MAX_UPLOADED_REPORTS"]
        session["profiler_paths"] = (
            session.get("profiler_paths", []) + [str(profiler_path)]
        )[-max_reports:]
        session.permanent = True

    return {
        "path": parent_folder_name,
        "reportName": report_name,
    }


@api.route("/local/upload/performance", methods=["POST"])
def create_performance_files():
    files = request.files.getlist("files")
    folder_name = request.form.get("folderName")  # Optional folder name
    data_directory = Path(current_app.config["LOCAL_DATA_DIRECTORY"])

    if not validate_files(
        files,
        {"profile_log_device.csv", "tracy_profile_log_host.tracy"},
        pattern="ops_perf_results",
        folder_name=folder_name,
    ):
        return StatusMessage(
            status=ConnectionTestStates.FAILED,
            message="Invalid project directory.",
        ).model_dump()

    target_directory = data_directory / current_app.config["PERFORMANCE_DIRECTORY_NAME"]

    if not target_directory.exists():
        target_directory.mkdir(parents=True, exist_ok=True)

    if folder_name:
        parent_folder_name = folder_name
    else:
        parent_folder_name = extract_folder_name_from_files(files)

    logger.info(f"Saving performance report files {parent_folder_name}")

    try:
        paths = save_uploaded_files(
            files,
            target_directory,
            folder_name,
        )
    except DataFormatError:
        return response_unprocessable_entity()

    performance_path = str(paths[0].parent)

    instance_id = request.args.get("instanceId")
    update_instance(
        instance_id=instance_id,
        performance_name=parent_folder_name,
        performance_location=ReportLocation.LOCAL.value,
        clear_remote=True,
        performance_path=performance_path,
    )

    if current_app.config["SERVER_MODE"]:
        max_reports = current_app.config["SESSION_MAX_UPLOADED_REPORTS"]
        session["performance_paths"] = (
            session.get("performance_paths", []) + [str(performance_path)]
        )[-max_reports:]
        session.permanent = True

    return StatusMessage(
        status=ConnectionTestStates.OK, message="Success."
    ).model_dump()


@api.route("/local/upload/npe", methods=["POST"])
def create_npe_files():
    files = request.files.getlist("files")
    data_directory = current_app.config["LOCAL_DATA_DIRECTORY"]

    for file in files:
        if (
            not file.filename.endswith(".json")
            and not file.filename.endswith(".zst")
            and not file.filename.endswith(".npeviz")
        ):
            return StatusMessage(
                status=ConnectionTestStates.FAILED,
                message="NPE requires a valid .json or .zst file",
            ).model_dump()

    npe_name = extract_npe_name(files)
    target_directory = data_directory / current_app.config["NPE_DIRECTORY_NAME"]
    target_directory.mkdir(parents=True, exist_ok=True)

    try:
        paths = save_uploaded_files(files, target_directory)
    except DataFormatError:
        return response_unprocessable_entity()

    instance_id = request.args.get("instanceId")
    npe_path = str(paths[0])
    update_instance(
        instance_id=instance_id,
        npe_name=npe_name,
        npe_location=ReportLocation.LOCAL.value,
        clear_remote=True,
        npe_path=npe_path,
    )

    if current_app.config["SERVER_MODE"]:
        max_reports = current_app.config["SESSION_MAX_UPLOADED_REPORTS"]
        session["npe_paths"] = (session.get("npe_paths", []) + [str(npe_path)])[
            -max_reports:
        ]
        session.permanent = True

    return StatusMessage(status=ConnectionTestStates.OK, message="Success").model_dump()


@api.route("/remote/profiler", methods=["POST"])
def get_remote_folders_profiler():
    connection_data = request.get_json()

    if not connection_data:
        return response_bad_request("Missing connection data")

    connection = RemoteConnection.model_validate(connection_data, strict=False)

    try:
        remote_folders: List[RemoteReportFolder] = get_remote_profiler_folders(
            connection
        )
        if not remote_folders:
            return Response(status=HTTPStatus.NO_CONTENT)

        for rf in remote_folders:
            directory_name = Path(rf.remotePath).name
            remote_data_directory = current_app.config["REMOTE_DATA_DIRECTORY"]
            local_path = (
                remote_data_directory
                / current_app.config["PROFILER_DIRECTORY_NAME"]
                / connection.host
                / directory_name
            )
            logger.info(f"Checking last synced for {directory_name}")
            rf.lastSynced = read_last_synced_file(str(local_path))
            if not rf.lastSynced:
                logger.info(f"{directory_name} not yet synced")

        return Response(
            orjson.dumps([r.model_dump() for r in remote_folders]),
            mimetype="application/json",
        )
    except RemoteConnectionException as e:
        return error_response(e.http_status, e.message)


@api.route("/remote/performance", methods=["POST"])
def get_remote_folders_performance():
    connection_data = request.get_json()

    if not connection_data:
        return response_bad_request("Missing connection data")

    connection = RemoteConnection.model_validate(connection_data, strict=False)

    try:
        remote_performance_folders: List[RemoteReportFolder] = (
            get_remote_performance_folders(connection)
        )
        if not remote_performance_folders:
            return Response(status=HTTPStatus.NO_CONTENT)

        for rf in remote_performance_folders:
            performance_name = Path(rf.remotePath).name
            remote_data_directory = current_app.config["REMOTE_DATA_DIRECTORY"]
            local_path = (
                remote_data_directory
                / current_app.config["PERFORMANCE_DIRECTORY_NAME"]
                / connection.host
                / performance_name
            )
            logger.info(f"Checking last synced for {performance_name}")
            rf.lastSynced = read_last_synced_file(str(local_path))
            if not rf.lastSynced:
                logger.info(f"{performance_name} not yet synced")

        return Response(
            orjson.dumps([r.model_dump() for r in remote_performance_folders]),
            mimetype="application/json",
        )
    except RemoteConnectionException as e:
        return error_response(e.http_status, e.message)


@api.route("/cluster-descriptor", methods=["GET"])
@with_instance
def get_cluster_descriptor(instance: Instance):
    try:
        cluster_desc = get_cluster_desc(instance)

        if not cluster_desc:
            return response_not_found("cluster_descriptor.yaml not found")

        return jsonify(cluster_desc), HTTPStatus.OK

    except yaml.YAMLError as e:
        return response_bad_request(f"Failed to parse YAML: {str(e)}")

    except Exception as e:
        return response_internal_server_error(f"An unexpected error occurred: {str(e)}")


@api.route("/mesh-descriptor", methods=["GET"])
@with_instance
def get_mesh_descriptor(instance: Instance):
    paths = get_mesh_descriptor_paths(instance)

    if not paths:
        return response_not_found(
            "physical_chip_mesh_coordinate_mapping_1_of_1.yaml not found"
        )

    try:
        with open(paths[0], "r", encoding="utf-8") as mesh_descriptor_path:
            yaml_data = yaml.safe_load(mesh_descriptor_path)
            return jsonify(yaml_data)  # yaml_data is not compatible with orjson
    except yaml.YAMLError as e:
        return response_bad_request(f"Failed to parse YAML: {str(e)}")


@api.route("/remote/test", methods=["POST"])
def test_remote_folder():
    connection_data = request.json

    if not connection_data:
        return response_bad_request("Missing connection data")

    connection = RemoteConnection.model_validate(connection_data, strict=False)
    logger.debug(
        "test_remote_folder request identityFile=%r, connection.identityFile=%r",
        connection_data.get("identityFile"),
        getattr(connection, "identityFile", None),
    )
    statuses = []

    def add_status(status, message, detail=None):
        statuses.append(StatusMessage(status=status, message=message, detail=detail))

    def has_failures():
        return any(
            status.status == ConnectionTestStates.FAILED.value for status in statuses
        )

    # Test SSH Connection
    try:
        test_ssh_connection(connection)
        add_status(ConnectionTestStates.OK.value, "SSH connection established")
    except AuthenticationFailedException as e:
        add_status(
            ConnectionTestStates.FAILED.value, e.message, getattr(e, "detail", None)
        )
        return jsonify([status.model_dump() for status in statuses]), e.http_status
    except RemoteConnectionException as e:
        add_status(e.status.value, e.message, getattr(e, "detail", None))

    # Test Directory Configuration
    if not has_failures() and connection.profilerPath:
        try:
            check_remote_path_exists(connection, "profilerPath")
            add_status(ConnectionTestStates.OK.value, "Memory folder path exists")
        except AuthenticationFailedException as e:
            add_status(
                ConnectionTestStates.FAILED.value, e.message, getattr(e, "detail", None)
            )
            return jsonify([status.model_dump() for status in statuses]), e.http_status
        except RemoteConnectionException as e:
            add_status(e.status.value, e.message, getattr(e, "detail", None))

    # Test Directory Configuration (perf)
    if not has_failures() and connection.performancePath:
        try:
            check_remote_path_exists(connection, "performancePath")
            add_status(ConnectionTestStates.OK.value, "Performance folder path exists")
        except AuthenticationFailedException as e:
            add_status(
                ConnectionTestStates.FAILED.value, e.message, getattr(e, "detail", None)
            )
            return jsonify([status.model_dump() for status in statuses]), e.http_status
        except RemoteConnectionException as e:
            add_status(e.status.value, e.message, getattr(e, "detail", None))

    # Check for Project Configurations
    if not has_failures():
        try:
            check_remote_path_for_reports(connection)
        except AuthenticationFailedException as e:
            add_status(
                ConnectionTestStates.FAILED.value, e.message, getattr(e, "detail", None)
            )
            return jsonify([status.model_dump() for status in statuses]), e.http_status
        except RemoteConnectionException as e:
            add_status(e.status.value, e.message, getattr(e, "detail", None))

    return Response(
        orjson.dumps([status.model_dump() for status in statuses]),
        mimetype="application/json",
    )


@api.route("/remote/read", methods=["POST"])
@with_instance
def read_remote_folder(instance: Instance):
    body = request.get_json(silent=True) or {}
    file_path = body.get("filePath", None)
    # TODO: @smountenay-tt: Personally instead of a check_path_only query var, I would have made another API for checking if a remote path exists, like /api/remote/check_path?path=/path-to-check instead of having it in /remote/read.
    check_path_only = body.get("check_path_only", False)

    if not file_path or not isinstance(file_path, str):
        return response_bad_request("Missing or invalid filePath")

    remote_connection = instance.remote_connection

    if check_path_only:
        is_available = False

        if remote_connection:
            try:
                ssh_client = SSHClient(remote_connection)
                is_available = check_stack_source_remote(ssh_client, file_path)
            except RemoteConnectionException:
                return jsonify({"available": False})
        else:
            if not current_app.config.get("SERVER_MODE"):
                is_available = check_stack_source_local(file_path)

        return jsonify({"available": is_available})

    if remote_connection:
        try:
            ssh_client = SSHClient(remote_connection)
            content, resolved, remapped = read_stack_source_remote(
                ssh_client, file_path
            )
            return stack_source_response(content, resolved, remapped)
        except RemoteConnectionException as e:
            return error_response(e.http_status, e.message)
        except RemoteFileReadException as e:
            error_payload = {"error": str(e)}
            if e.detail:
                error_payload["detail"] = e.detail
            return jsonify(error_payload), e.http_status

    if current_app.config.get("SERVER_MODE"):
        return response_forbidden(
            "Local stack source reads are not available in server mode.",
        )

    try:
        content, resolved, remapped = read_stack_source_local(file_path)
        return stack_source_response(content, resolved, remapped)
    except ValueError as e:
        return response_bad_request(str(e))
    except FileNotFoundError as e:
        return response_not_found(str(e) or "File not found.")
    except PermissionError as e:
        return response_forbidden(str(e))


@api.route("/remote/sync", methods=["POST"])
def sync_remote_folder():
    remote_dir = current_app.config["REMOTE_DATA_DIRECTORY"]
    request_body = request.get_json()

    # Check if request_body is None or not a dictionary
    if not request_body or not isinstance(request_body, dict):
        return response_bad_request("Invalid or missing JSON data")

    profiler = request_body.get("profiler")
    performance = request_body.get("performance", None)
    instance_id = request.args.get("instanceId", None)
    connection = RemoteConnection.model_validate(
        request_body.get("connection"), strict=False
    )

    if performance:
        performance_folder = RemoteReportFolder.model_validate(
            performance, strict=False
        )
        try:
            sync_remote_performance_folders(
                connection,
                remote_dir,
                performance=performance_folder,
                exclude_patterns=[r"/tensors(/|$)"],
                sid=instance_id,
            )

            performance_folder.lastSynced = int(time.time())

            return performance_folder.model_dump()

        except RemoteConnectionException as e:
            return error_response(e.http_status, e.message)

    try:
        remote_profiler_folder = RemoteReportFolder.model_validate(
            profiler, strict=False
        )

        sync_remote_profiler_folders(
            connection,
            remote_profiler_folder.remotePath,
            remote_dir,
            exclude_patterns=[r"/tensors(/|$)"],
            sid=instance_id,
        )

        remote_profiler_folder.lastSynced = int(time.time())

        return Response(
            orjson.dumps(remote_profiler_folder.model_dump()),
            mimetype="application/json",
        )

    except RemoteConnectionException as e:
        return error_response(e.http_status, e.message)


@api.route("/remote/use", methods=["POST"])
def use_remote_folder():
    data = request.get_json(force=True)
    connection_data = data.get("connection")
    profiler = data.get("profiler")
    performance = data.get("performance")

    if not connection_data or not (profiler or performance):
        return response_bad_request("Missing connection or report data")

    connection = RemoteConnection.model_validate(connection_data, strict=False)

    kwargs = {
        "instance_id": request.args.get("instanceId"),
        "remote_connection": connection,
    }

    if profiler:
        remote_profiler_folder = RemoteReportFolder.model_validate(
            profiler,
            strict=False,
        )
        kwargs["remote_profiler_folder"] = remote_profiler_folder
        kwargs["profiler_name"] = remote_profiler_folder.remotePath.split("/")[-1]
        kwargs["profiler_location"] = ReportLocation.REMOTE.value

    if performance:
        remote_performance_folder = RemoteReportFolder.model_validate(
            performance,
            strict=False,
        )
        kwargs["remote_performance_folder"] = remote_performance_folder
        kwargs["performance_name"] = remote_performance_folder.reportName
        kwargs["performance_location"] = ReportLocation.REMOTE.value

    update_instance(**kwargs)

    return Response(status=HTTPStatus.OK)


@api.route("/up", methods=["GET", "POST"])
def health_check():
    return Response(status=HTTPStatus.OK)


@api.route("/instance", methods=["GET"])
@with_instance
def get_instance(instance: Instance):
    # Used to gate UI functions if no report is active
    return Response(
        orjson.dumps(instance.model_dump()),
        mimetype="application/json",
    )


@api.route("/instance", methods=["PUT"])
@with_instance
def update_current_instance(instance: Instance):
    try:
        update_data = request.get_json()

        if not update_data:
            return response_bad_request("No data provided.")

        # Use current instance unless a different one is specified
        instance_id = update_data.get("instance_id") or instance.instance_id

        update_instance(
            instance_id=instance_id,
            profiler_name=update_data["active_report"].get("profiler_name"),
            profiler_location=update_data["active_report"].get("profiler_location"),
            performance_name=update_data["active_report"].get("performance_name"),
            performance_location=update_data["active_report"].get(
                "performance_location"
            ),
            npe_name=update_data["active_report"].get("npe_name"),
            # NPE is always local right now
            npe_location=ReportLocation.LOCAL.value,
            # Doesn't handle remote at the moment
            remote_connection=None,
            remote_profiler_folder=None,
            remote_performance_folder=None,
        )

        return Response(status=HTTPStatus.OK)
    except Exception as e:
        logger.error(f"Error updating instance: {str(e)}")

        return response_internal_server_error(
            "An error occurred while updating the instance.",
        )


@api.route("/npe", methods=["GET"])
@with_instance
@timer
def get_npe_data(instance: Instance):
    if not instance.npe_path:
        logger.error("NPE path is not set in the instance.")
        return response_not_found()

    if instance.npe_path.endswith(".zst"):
        compressed_path = Path(instance.npe_path)
        uncompressed_path = None
    elif instance.npe_path.endswith(".json") or instance.npe_path.endswith(".npeviz"):
        compressed_path = None
        uncompressed_path = Path(instance.npe_path)
    else:
        compressed_path = Path(instance.npe_path)
        uncompressed_path = Path(instance.npe_path)

    if not (compressed_path and compressed_path.exists()) and not (
        uncompressed_path and uncompressed_path.exists()
    ):
        logger.error(
            f"NPE file does not exist: {compressed_path} / {uncompressed_path}"
        )
        return response_not_found()

    try:
        if compressed_path and compressed_path.exists():
            with open(compressed_path, "rb") as file:
                compressed_data = file.read()
                npe_data = zstd.uncompress(compressed_data)
        else:
            if uncompressed_path is None:
                return response_not_found()
            with open(uncompressed_path, "r") as file:
                npe_data = file.read()
    except Exception as e:
        logger.error(f"Error reading NPE file: {e}")
        return response_unprocessable_entity()

    return Response(npe_data, mimetype="application/json")


@api.route("/notify", methods=["POST"])
def notify_report_update():
    """
    Endpoint to receive notifications about report updates and broadcast them via websockets.
    """
    from ttnn_visualizer.sockets import (
        ExitStatus,
        ReportGenerated,
        emit_report_generated,
    )

    try:
        data = request.get_json()
        if not data:
            return response_bad_request("No JSON data provided")

        report_name = data.get("report_name")
        exit_status_str = data.get("exit_status")

        if not report_name:
            return response_bad_request("report_name is required")

        # Validate status
        try:
            exit_status = (
                ExitStatus(exit_status_str.upper()) if exit_status_str else None
            )
        except ValueError:
            return response_bad_request("Invalid exit_status.")

        # Create and emit the report update
        report_generated = ReportGenerated(
            report_name=report_name,
            exit_status=exit_status,
            profiler_path=data.get("profiler_path"),
            performance_path=data.get("performance_path"),
        )
        emit_report_generated(report_generated)

        logger.info(f"Report generated notification processed: {report_name}")

        return Response(
            orjson.dumps(
                {
                    "report_name": report_name,
                    "profiler_path": report_generated.profiler_path,
                    "performance_path": report_generated.performance_path,
                    "exit_status": exit_status.value if exit_status else None,
                    "timestamp": report_generated.timestamp,
                }
            ),
            mimetype="application/json",
        )

    except Exception as e:
        logger.error(f"Error processing report update notification: {str(e)}")
        return response_internal_server_error("Internal server error")


@api.route("/latest-version", methods=["GET"])
def get_latest_version():
    try:
        headers = {"Content-Type": "application/xml"}
        releases_request = urllib.request.Request(
            "https://pypi.org/rss/project/ttnn-visualizer/releases.xml",
            headers=headers,
            method="GET",
        )

        with urllib.request.urlopen(releases_request, timeout=2) as url_response:
            response = url_response.read().decode("utf-8")

        match = re.search(r"<title>(\d+\.\d+\.\d+)</title>", response)
        latest_version = match.group(1) if match else None

        return Response(
            orjson.dumps(latest_version),
            mimetype="application/json",
        )
    except Exception as e:
        logger.error(f"Error fetching releases XML: {str(e)}")
        return response_internal_server_error("Failed to fetch releases")
