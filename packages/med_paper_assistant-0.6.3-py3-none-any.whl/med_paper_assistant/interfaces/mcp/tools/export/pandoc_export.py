"""
Pandoc Export Tools — Citation-aware export using ExportPipeline.

Converts [[wikilink]] citations → [@key] → formatted citations via Pandoc --citeproc.
Generates CSL-JSON bibliography automatically from local references.
"""

import os
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .._shared import (
    ensure_project_context,
    log_tool_call,
    log_tool_error,
    log_tool_result,
)


def register_pandoc_export_tools(mcp: FastMCP):
    """Register Pandoc-based export tools."""

    def _get_pipeline():
        """Lazy-initialize ExportPipeline with current project context."""
        from med_paper_assistant.application.export_pipeline import ExportPipeline
        from med_paper_assistant.infrastructure.persistence import get_project_manager
        from med_paper_assistant.infrastructure.persistence.reference_manager import (
            ReferenceManager,
        )
        from med_paper_assistant.infrastructure.services.pandoc_exporter import PandocExporter

        pm = get_project_manager()
        ref_manager = ReferenceManager(project_manager=pm)
        pandoc = PandocExporter()
        return ExportPipeline(ref_manager, pandoc), pm

    def _run_pre_export_citation_gate(content: str, project_dir: str) -> str | None:
        """Run C5 wikilink-resolvable hook as a HARD GATE before export.

        Args:
            content: Draft markdown content (with [[wikilink]] citations).
            project_dir: Absolute path to the project directory.

        Returns:
            None if all citations resolve; error message string if any fail.
        """
        from med_paper_assistant.infrastructure.persistence.writing_hooks import (
            WritingHooksEngine,
        )

        engine = WritingHooksEngine(project_dir=Path(project_dir))
        c5_result = engine.check_wikilink_resolvable(content)

        if c5_result.passed:
            return None

        # Build a clear error message listing every unresolved wikilink
        unresolved = [iss.message for iss in c5_result.issues if iss.severity == "CRITICAL"]
        detail = "\n".join(f"  - {msg}" for msg in unresolved)
        return (
            f"❌ **Export blocked — {c5_result.stats.get('unresolved', '?')} "
            f"unresolved citation(s)**\n\n"
            f"{detail}\n\n"
            f"Fix: Save missing references with `save_reference_mcp(pmid)` "
            f"or correct the wikilinks, then retry export.\n\n"
            f"ℹ️ Hook C5 (Wikilink Resolvable) — pre-export HARD GATE"
        )

    def _run_pre_export_review_gate(project_dir: str) -> str | None:
        """Check that Phase 7 review loop was completed before allowing export.

        Returns:
            None if review is complete; error message string if not.
        """
        from med_paper_assistant.infrastructure.persistence.pipeline_gate_validator import (
            PipelineGateValidator,
        )

        validator = PipelineGateValidator(project_dir=Path(project_dir))
        passed, details = validator._check_review_completed()
        if passed:
            return None

        return (
            f"❌ **Export blocked — Review loop not completed**\n\n"
            f"📊 {details}\n\n"
            f"## 🔧 REMEDIATION REQUIRED\n\n"
            f"1. Call `start_review_round()` to begin a review round\n"
            f"2. Write a review report and author response\n"
            f"3. Call `submit_review_round()` to complete the round\n"
            f"4. Repeat until minimum rounds are met\n"
            f"5. Retry export\n\n"
            f"⚠️ This is a **Code-Enforced** hard gate. "
            f"Export cannot proceed without completing the review loop."
        )

    @mcp.tool()
    def export_docx(
        draft_filename: str,
        output_filename: Optional[str] = None,
        csl_style: str = "vancouver",
        reference_doc: Optional[str] = None,
        project: Optional[str] = None,
    ) -> str:
        """
        DEPRECATED public verb. Prefer `export_document(action="docx", ...)`.

        Export a draft to Word (.docx) with properly formatted citations.

        Converts [[wikilink]] citations → [@key] → formatted citations via Pandoc citeproc.
        Automatically builds CSL-JSON bibliography from saved references.

        Args:
            draft_filename: Draft file name (e.g., "introduction.md")
            output_filename: Output file name (default: same name with .docx extension)
            csl_style: Citation style (vancouver, apa, nature, etc.)
            reference_doc: Optional Word template for styling
            project: Project slug (uses current project if omitted)
        """
        log_tool_call(
            "export_docx",
            {
                "draft": draft_filename,
                "style": csl_style,
                "project": project,
            },
        )

        # Ensure project context
        is_valid, msg, _ = ensure_project_context(project)
        if not is_valid:
            return msg

        try:
            pipeline, pm = _get_pipeline()

            if not pipeline._pandoc or not pipeline._pandoc.available:
                return (
                    "❌ **Pandoc not available**\n\n"
                    "Install Pandoc:\n"
                    "- Windows: `winget install pandoc`\n"
                    "- macOS: `brew install pandoc`\n"
                    "- Python: `import pypandoc; pypandoc.download_pandoc()`"
                )

            # Resolve paths
            paths = pm.get_project_paths()
            drafts_dir = paths.get("drafts", "drafts")
            draft_path = os.path.join(drafts_dir, draft_filename)

            if not os.path.exists(draft_path):
                return f"❌ Draft file not found: `{draft_filename}`"

            # ── HARD GATE: C5 Wikilink Resolvable ──
            with open(draft_path, "r", encoding="utf-8") as f:
                draft_content = f.read()

            project_dir = str(Path(drafts_dir).parent)
            gate_error = _run_pre_export_citation_gate(draft_content, project_dir)
            if gate_error:
                log_tool_error(
                    "export_docx", Exception("C5 gate failed"), {"draft": draft_filename}
                )
                return gate_error

            # ── HARD GATE: Review Loop Completed ──
            review_error = _run_pre_export_review_gate(project_dir)
            if review_error:
                log_tool_error(
                    "export_docx", Exception("Review gate failed"), {"draft": draft_filename}
                )
                return review_error

            # Determine output path
            if not output_filename:
                base = os.path.splitext(draft_filename)[0]
                output_filename = f"{base}.docx"

            exports_dir = os.path.join(os.path.dirname(drafts_dir), "exports")
            os.makedirs(exports_dir, exist_ok=True)
            output_path = os.path.join(exports_dir, output_filename)

            # Extract project metadata for title/author injection
            project_info = pm.get_project_info()
            metadata = None
            if project_info.get("success"):
                authors = project_info.get("authors", [])
                metadata = {
                    "title": project_info.get("name", ""),
                    "authors": authors if authors else [],
                    "date": project_info.get("created_at", "")[:10],  # YYYY-MM-DD
                }

            # Run the export pipeline
            result = pipeline.export_docx(
                draft_path=draft_path,
                output_path=output_path,
                csl_style=csl_style,
                reference_doc=reference_doc,
                metadata=metadata,
            )

            # Build report
            output = "✅ **Document exported successfully**\n\n"
            output += f"📄 Output: `{result['output_path']}`\n"
            output += f"📚 Citations converted: {result['citations_converted']}\n"
            output += f"🎨 Citation style: {csl_style}\n"

            if result.get("citation_keys"):
                output += f"\n**Citation keys** ({len(result['citation_keys'])}):\n"
                for key in result["citation_keys"]:
                    output += f"- `{key}`\n"

            if result.get("warnings"):
                output += "\n⚠️ **Warnings:**\n"
                for w in result["warnings"]:
                    output += f"- {w}\n"

            log_tool_result("export_docx", output_path, success=True)
            return output

        except Exception as e:
            log_tool_error("export_docx", e, {"draft": draft_filename})
            return f"❌ Export failed: {e}"

    @mcp.tool()
    def export_pdf(
        draft_filename: str,
        output_filename: Optional[str] = None,
        csl_style: str = "vancouver",
        project: Optional[str] = None,
    ) -> str:
        """
        DEPRECATED public verb. Prefer `export_document(action="pdf", ...)`.

        Export a draft to PDF with properly formatted citations.

        Requires a LaTeX engine (pdflatex, xelatex, or lualatex).
        Converts [[wikilink]] citations → [@key] → formatted citations via Pandoc citeproc.

        Args:
            draft_filename: Draft file name (e.g., "manuscript.md")
            output_filename: Output file name (default: same name with .pdf extension)
            csl_style: Citation style (vancouver, apa, nature, etc.)
            project: Project slug (uses current project if omitted)
        """
        log_tool_call(
            "export_pdf",
            {"draft": draft_filename, "style": csl_style, "project": project},
        )

        is_valid, msg, _ = ensure_project_context(project)
        if not is_valid:
            return msg

        try:
            pipeline, pm = _get_pipeline()

            if not pipeline._pandoc or not pipeline._pandoc.available:
                return (
                    "❌ **Pandoc not available**\n\n"
                    "Install Pandoc:\n"
                    "- `sudo apt install pandoc texlive-latex-base`\n"
                    "- macOS: `brew install pandoc basictex`"
                )

            paths = pm.get_project_paths()
            drafts_dir = paths.get("drafts", "drafts")
            draft_path = os.path.join(drafts_dir, draft_filename)

            if not os.path.exists(draft_path):
                return f"❌ Draft file not found: `{draft_filename}`"

            # ── HARD GATE: C5 Wikilink Resolvable ──
            with open(draft_path, "r", encoding="utf-8") as f:
                draft_content = f.read()

            project_dir = str(Path(drafts_dir).parent)
            gate_error = _run_pre_export_citation_gate(draft_content, project_dir)
            if gate_error:
                log_tool_error("export_pdf", Exception("C5 gate failed"), {"draft": draft_filename})
                return gate_error

            # ── HARD GATE: Review Loop Completed ──
            review_error = _run_pre_export_review_gate(project_dir)
            if review_error:
                log_tool_error(
                    "export_pdf", Exception("Review gate failed"), {"draft": draft_filename}
                )
                return review_error

            if not output_filename:
                base = os.path.splitext(draft_filename)[0]
                output_filename = f"{base}.pdf"

            exports_dir = os.path.join(os.path.dirname(drafts_dir), "exports")
            os.makedirs(exports_dir, exist_ok=True)
            output_path = os.path.join(exports_dir, output_filename)

            # Extract project metadata for title/author injection
            project_info = pm.get_project_info()
            metadata = None
            if project_info.get("success"):
                authors = project_info.get("authors", [])
                metadata = {
                    "title": project_info.get("name", ""),
                    "authors": authors if authors else [],
                }

            result = pipeline.export_pdf(
                draft_path=draft_path,
                output_path=output_path,
                csl_style=csl_style,
                metadata=metadata,
            )

            output = "✅ **PDF exported successfully**\n\n"
            output += f"📄 Output: `{result['output_path']}`\n"
            output += f"📚 Citations converted: {result['citations_converted']}\n"
            output += f"🎨 Citation style: {csl_style}\n"

            if result.get("citation_keys"):
                output += f"\n**Citation keys** ({len(result['citation_keys'])}):\n"
                for key in result["citation_keys"]:
                    output += f"- `{key}`\n"

            if result.get("warnings"):
                output += "\n⚠️ **Warnings:**\n"
                for w in result["warnings"]:
                    output += f"- {w}\n"

            log_tool_result("export_pdf", output_path, success=True)
            return output

        except Exception as e:
            log_tool_error("export_pdf", e, {"draft": draft_filename})
            return f"❌ PDF export failed: {e}"

    @mcp.tool()
    def preview_citations(
        draft_filename: str,
        project: Optional[str] = None,
    ) -> str:
        """
        Preview how citations will be converted for Pandoc export.

        Shows the wikilink → [@key] mapping and bibliography entries
        without actually running Pandoc. Useful for checking before export.

        Args:
            draft_filename: Draft file name (e.g., "introduction.md")
            project: Project slug (uses current project if omitted)
        """
        log_tool_call("preview_citations", {"draft": draft_filename, "project": project})

        is_valid, msg, _ = ensure_project_context(project)
        if not is_valid:
            return msg

        try:
            pipeline, pm = _get_pipeline()

            # Resolve paths
            paths = pm.get_project_paths()
            drafts_dir = paths.get("drafts", "drafts")
            draft_path = os.path.join(drafts_dir, draft_filename)

            if not os.path.exists(draft_path):
                return f"❌ Draft file not found: `{draft_filename}`"

            with open(draft_path, "r", encoding="utf-8") as f:
                content = f.read()

            prepared = pipeline.prepare_for_pandoc(content)

            output = "📋 **Citation Preview**\n\n"
            output += f"📄 File: `{draft_filename}`\n"
            output += f"🔄 Citations converted: {prepared['conversion'].citations_converted}\n\n"

            if prepared["citation_keys"]:
                output += "**Citation keys found:**\n"
                for key in prepared["citation_keys"]:
                    output += f"- `[[{key}]]` → `[@{key}]`\n"

                output += f"\n**Bibliography entries resolved:** {len(prepared['bibliography'])} / {len(prepared['citation_keys'])}\n"

                if prepared["bibliography"]:
                    output += "\n**CSL-JSON preview:**\n"
                    for entry in prepared["bibliography"][:5]:
                        title = entry.get("title", "Unknown")[:80]
                        output += f"- `{entry.get('id', '?')}`: {title}\n"
                    if len(prepared["bibliography"]) > 5:
                        output += f"  ... and {len(prepared['bibliography']) - 5} more\n"
            else:
                output += "No citations found in this draft.\n"

            if prepared["warnings"]:
                output += "\n⚠️ **Warnings:**\n"
                for w in prepared["warnings"]:
                    output += f"- {w}\n"

            log_tool_result(
                "preview_citations", f"{len(prepared['citation_keys'])} citations", success=True
            )
            return output

        except Exception as e:
            log_tool_error("preview_citations", e, {"draft": draft_filename})
            return f"❌ Preview failed: {e}"

    @mcp.tool()
    def build_bibliography(
        draft_filename: str,
        output_filename: Optional[str] = None,
        project: Optional[str] = None,
    ) -> str:
        """
        Build a CSL-JSON bibliography file from a draft's citations.

        Extracts all citation keys from the draft and resolves them
        to CSL-JSON entries. The resulting file can be used with
        Pandoc --bibliography flag.

        Args:
            draft_filename: Draft file name (e.g., "introduction.md")
            output_filename: Output file name (default: bibliography.json)
            project: Project slug (uses current project if omitted)
        """
        log_tool_call("build_bibliography", {"draft": draft_filename, "project": project})

        is_valid, msg, _ = ensure_project_context(project)
        if not is_valid:
            return msg

        try:
            pipeline, pm = _get_pipeline()

            paths = pm.get_project_paths()
            drafts_dir = paths.get("drafts", "drafts")
            draft_path = os.path.join(drafts_dir, draft_filename)

            if not os.path.exists(draft_path):
                return f"❌ Draft file not found: `{draft_filename}`"

            with open(draft_path, "r", encoding="utf-8") as f:
                content = f.read()

            if not output_filename:
                output_filename = "bibliography.json"

            exports_dir = os.path.join(os.path.dirname(drafts_dir), "exports")
            os.makedirs(exports_dir, exist_ok=True)
            bib_path = os.path.join(exports_dir, output_filename)

            entries = pipeline.build_bibliography_json(content, bib_path)

            output = "✅ **Bibliography built successfully**\n\n"
            output += f"📄 Output: `{bib_path}`\n"
            output += f"📚 Entries: {len(entries)}\n\n"

            if entries:
                output += "**References:**\n"
                for entry in entries:
                    title = entry.get("title", "Unknown")[:80]
                    authors = entry.get("author", [])
                    first_author = authors[0].get("family", "?") if authors else "?"
                    year = entry.get("issued", {}).get("date-parts", [[None]])[0][0] or "?"
                    output += f"- {first_author} ({year}). {title}\n"

            log_tool_result("build_bibliography", bib_path, success=True)
            return output

        except Exception as e:
            log_tool_error("build_bibliography", e, {"draft": draft_filename})
            return f"❌ Build bibliography failed: {e}"

    return {
        "export_docx": export_docx,
        "export_pdf": export_pdf,
        "preview_citations": preview_citations,
        "build_bibliography": build_bibliography,
    }
