import importlib

from tab_cli.storage.aws import AwsAuthMethod, AwsBackend
from tab_cli.storage.az import AzAuthMethod, AzBackend
from tab_cli.storage.local import LocalBackend


class TestAwsStorageOptions:
    def test_storage_options_use_flat_region_keys(self):
        backend = AwsBackend.__new__(AwsBackend)
        backend.method = AwsAuthMethod.EXPLICIT_KEYS
        backend.access_key = "access"
        backend.secret_key = "secret"
        backend.session_token = None
        backend.region = "us-east-1"

        opts = backend.storage_options("s3://bucket/path")

        assert opts is not None
        assert opts["aws_region"] == "us-east-1"
        assert "client_kwargs" not in opts


class TestStorageBackends:
    def test_local_glob_ignores_extension_filter(self, tmp_path):
        data_dir = tmp_path / "data"
        data_dir.mkdir()
        first = data_dir / "part-00000.txt"
        second = data_dir / "part-00001.txt"
        first.write_text("a")
        second.write_text("b")

        glob_path = str(data_dir / "part-*.txt")
        files = list(LocalBackend().list_files(glob_path, "parquet"))

        assert [file_info.url for file_info in files] == [str(first), str(second)]

    def test_local_directory_listing_skips_directories(self, tmp_path):
        data_dir = tmp_path / "data"
        nested_dir = data_dir / "nested"
        nested_dir.mkdir(parents=True)
        file_path = nested_dir / "part-00000.csv"
        file_path.write_text("a,b\n1,2\n", encoding="utf-8")

        files = list(LocalBackend().list_files(str(data_dir), ""))

        assert [file_info.url for file_info in files] == [str(file_path)]


class TestAzureStorageBackend:
    def test_azure_ad_uses_async_default_credential(self, monkeypatch):
        class FakeAsyncCredential:
            async def close(self) -> None:
                return None

        class FakeAzureIdentityAioModule:
            DefaultAzureCredential = FakeAsyncCredential

        class FakeAzureBlobFileSystem:
            def __init__(self, **kwargs):
                self.credential = kwargs.get("credential")

            def ls(self, container):
                return []

        class FakeAdlfsModule:
            AzureBlobFileSystem = FakeAzureBlobFileSystem

        real_import_module = importlib.import_module

        def fake_import_module(name: str):
            if name == "adlfs":
                return FakeAdlfsModule
            if name == "azure.identity.aio":
                return FakeAzureIdentityAioModule
            return real_import_module(name)

        monkeypatch.setattr(importlib, "import_module", fake_import_module)

        backend = AzBackend(account="acct", container="container")

        assert backend.method == AzAuthMethod.AZURE_AD
        assert isinstance(backend.fs.credential, FakeAsyncCredential)
