"""Version information for gworkspace-mcp."""

__version__ = "0.3.8"
