"""Defines the immutable genetic architecture of the simulation.

This module defines static, model-level genetic elements (loci, chromosomes, species)
that serve as the authoritative blueprint for creating and validating genetic entities.

This module is responsible for:
- Representing static, model-level genetic elements (loci, chromosomes, species)
- Storing configuration and rules such as locus order, recombination rates, and chromosome IDs
- Serving as the authoritative blueprint for creating and validating genetic entities
- Optionally tracking bound entities via internal registration mechanisms

Note:
- No runtime dependency on `genetic_entities` to avoid circular imports
- Modifications to a structure after binding entities are discouraged
"""

from __future__ import annotations

import importlib
import itertools
import logging
from abc import ABC, abstractmethod
from collections.abc import Hashable, Iterable
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Literal,
    Optional,
    Set,
    Tuple,
    TypeGuard,
    TypeVar,
    Union,
    cast,
    overload,
)

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from natal.genetic_entities import Gene, Genotype, HaploidGenome, Haplotype

__all__ = [
    "Locus",
    "Chromosome", "Linkage",
    "Species", "GenomeTemplate", "Karyotype"
]

T = TypeVar("T")  # Generic type
E = TypeVar("E")  # Generic type for entities (bound at runtime)
S = TypeVar("S", bound='GeneticStructure[Any]')  # Generic type for structures

# Pattern-combination helper aliases used by Species pattern enumeration.
AlleleTuple = Tuple[str, ...]
GenotypeChromosomeCombo = Tuple[AlleleTuple, AlleleTuple]
GenotypeComboMap = Dict[int, GenotypeChromosomeCombo]
HaploidComboMap = Dict[int, AlleleTuple]


logger = logging.getLogger(__name__)  # temp logger

# Global fallback cache for structures created without a Species (backward compatibility)
# Format: {structure_type: {name: instance}}
_GLOBAL_STRUCTURE_CACHE: Dict[type, Dict[str, GeneticStructure[Any]]] = {}

def ensure_type(obj: Any, expected_type: type) -> None:
    """
    Ensures that an object is an instance of a given class, with lazy import.

    Args:
        obj (any): The object to check
        expected_type (type): The expected class type.

    Raises:
        TypeError: If obj is not an instance of the specified class.
    """
    module = importlib.import_module(expected_type.__module__) # Lazy import
    cls = getattr(module, expected_type.__name__)
    if not isinstance(obj, cls):
        raise TypeError(
            f"Expected {expected_type.__name__} from {expected_type.__module__}, got {type(obj).__name__} instead."
        )

class SexChromosomeType(Enum):
    """
    Sex chromosome type enumeration.

    Defines common sex chromosome categories and inheritance constraints used
    by chromosome-level sex-system logic.

    Attributes:
        AUTOSOME (SexChromosomeType): Autosome not involved in sex determination.
        X (SexChromosomeType): X chromosome in the XY system; can come from either parent.
        Y (SexChromosomeType): Y chromosome in the XY system; paternal only.
        Z (SexChromosomeType): Z chromosome in the ZW system; can come from either parent.
        W (SexChromosomeType): W chromosome in the ZW system; maternal only.
    """
    AUTOSOME = "autosome"  # Autosome
    X = "X"                # X chromosome in XY system
    Y = "Y"                # Y chromosome in XY system, paternal only
    Z = "Z"                # Z chromosome in ZW system
    W = "W"                # W chromosome in ZW system, maternal only

    @property
    def is_sex_chromosome(self) -> bool:
        """Whether this is a sex chromosome"""
        return self != SexChromosomeType.AUTOSOME

    @property
    def sex_system(self) -> Optional[str]:
        """Returns the sex determination system this chromosome belongs to"""
        if self in (SexChromosomeType.X, SexChromosomeType.Y):
            return "XY"
        elif self in (SexChromosomeType.Z, SexChromosomeType.W):
            return "ZW"
        return None

    @property
    def maternal_only(self) -> bool:
        """Whether it can only be inherited from mother"""
        return self == SexChromosomeType.W

    @property
    def paternal_only(self) -> bool:
        """Whether it can only be inherited from father"""
        return self == SexChromosomeType.Y

class RegistryBase(ABC, Generic[T]):
    """
    Base class for registries.

    Provides the common interface for register/unregister operations while
    delegating storage semantics to subclass hooks.

    Attributes:
        _expected_type (Optional[type[GeneticStructure[E]]]): Runtime type used to
            validate registry items when provided.
    """
    # RegistryBase intentionally separates:
    # - "single item" primitives (_single_register/_single_unregister/_single_unregister_by_key)
    # - "batch input" orchestration (register/unregister)
    #
    # This keeps subclass logic focused on storage semantics while centralizing
    # input normalization and strict runtime type checks.
    def __init__(self, expected_type: Optional[type[GeneticStructure[E]]] = None):
        self._expected_type = expected_type

    def _check_type(self, item: T) -> None:
        if self._expected_type and not isinstance(item, self._expected_type):
            raise TypeError(f"Expected type {self._expected_type.__name__}, got {type(item).__name__}")

    def _is_valid_item_type(self, item: object) -> TypeGuard[T]:
        """Runtime validator + static type narrower for generic T.

        Why this exists:
        - Pylance/Pyright often cannot narrow Union/object to T in generic code.
        - TypeGuard[T] makes the narrowing explicit after a runtime check.
        """
        if self._expected_type is None:
            return True
        return isinstance(item, self._expected_type)

    @abstractmethod
    def _get_key(self, item: T) -> Hashable:
        """Extract the key for deduplication. Override in subclass."""
        pass

    @abstractmethod
    def _single_register(self, item: T) -> None:
        """Register a single item. Override in subclass."""
        pass

    @abstractmethod
    def _single_unregister(self, item: T) -> None:
        """Unregister a single item. Override in subclass."""
        pass

    @abstractmethod
    def _single_unregister_by_key(self, key: str) -> None:
        """Unregister a single item by key. Override in subclass."""
        pass

    def register(self, item_or_items: Union[T, List[T], Tuple[T, ...], Set[T]]) -> None:
        """Register one or more items."""
        # GeneticStructure is iterable (yields children) but should be registered as single item
        # Use explicit list/tuple/set check instead of Iterable to avoid this.
        # (str / custom iterable objects should not be silently treated as batch input.)
        if isinstance(item_or_items, list):
            item_or_items = cast(List[T], item_or_items)
            for item in item_or_items:
                if self._is_valid_item_type(item):
                    self._single_register(item)
                else:
                    raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        elif isinstance(item_or_items, tuple):
            item_or_items = cast(Tuple[T, ...], item_or_items)
            for item in item_or_items:
                if self._is_valid_item_type(item):
                    self._single_register(item)
                else:
                    raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        elif isinstance(item_or_items, set):
            item_or_items = cast(Set[T], item_or_items)
            for item in item_or_items:
                if self._is_valid_item_type(item):
                    self._single_register(item)
                else:
                    raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        else:
            if self._is_valid_item_type(item_or_items):
                self._single_register(item_or_items)
            else:
                raise TypeError(f"Expected registry item type, got {type(item_or_items).__name__}")

    def unregister(
        self,
        item_or_items: Union[T, str, List[Union[T, str]], Tuple[Union[T, str], ...], Set[Union[T, str]]]
    ) -> None:
        """Unregister one or more items (by key or item object)."""
        # unregister supports mixed batch input: [item, "name", item, ...]
        # where str means key-based removal and non-str means object removal.
        if isinstance(item_or_items, list):
            item_or_items = cast(List[Union[T, str]], item_or_items)
            for item in item_or_items:
                if isinstance(item, str):
                    self._single_unregister_by_key(item)
                else:
                    if self._is_valid_item_type(item):
                        self._single_unregister(item)
                    else:
                        raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        elif isinstance(item_or_items, tuple):
            item_or_items = cast(Tuple[Union[T, str], ...], item_or_items)
            for item in item_or_items:
                if isinstance(item, str):
                    self._single_unregister_by_key(item)
                else:
                    if self._is_valid_item_type(item):
                        self._single_unregister(item)
                    else:
                        raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        elif isinstance(item_or_items, set):
            item_or_items = cast(Set[Union[T, str]], item_or_items)
            for item in item_or_items:
                if isinstance(item, str):
                    self._single_unregister_by_key(item)
                else:
                    if self._is_valid_item_type(item):
                        self._single_unregister(item)
                    else:
                        raise TypeError(f"Expected registry item type, got {type(item).__name__}")
        elif isinstance(item_or_items, str):
            self._single_unregister_by_key(item_or_items)
        else:
            if self._is_valid_item_type(item_or_items):
                self._single_unregister(item_or_items)
            else:
                raise TypeError(f"Expected registry item type, got {type(item_or_items).__name__}")

    def __len__(self) -> int:
        raise NotImplementedError

    def clear(self) -> None:
        raise NotImplementedError


class EntityRegistry(RegistryBase[E]):
    """
    Registry for entity objects. Deduplication by object identity.

    Attributes:
        _storage (List[E]): Ordered storage for deterministic iteration.
        _set (Set[E]): Identity-based membership set for O(1) deduplication checks.
    """
    # EntityRegistry is identity-based:
    # - _set provides O(1) membership uniqueness checks
    # - _storage preserves insertion order for deterministic iteration
    def __init__(self, expected_type: Optional[type] = None):
        super().__init__(expected_type)
        self._storage: List[E] = []
        self._set: Set[E] = set()

    def _get_key(self, item: E) -> E:
        return item  # Use object identity

    def _single_register(self, item: E) -> None:
        self._check_type(item)
        if item not in self._set:
            self._storage.append(item)
            self._set.add(item)

    def _single_unregister(self, item: E) -> None:
        if item in self._set:
            self._storage.remove(item)
            self._set.remove(item)

    def _single_unregister_by_key(self, key: str) -> None:
        # Entities do not have a globally unique name key in this registry layer.
        # Key-based unregister belongs to ChildStructureRegistry.
        raise TypeError(
            "EntityRegistry does not support unregistering by string key; pass entity instance(s) instead."
        )

    def __iter__(self):
        return iter(self._storage)

    def __contains__(self, item: E) -> bool:
        return item in self._set

    def __len__(self) -> int:
        return len(self._storage)

    def clear(self) -> None:
        self._storage.clear()
        self._set.clear()

    @property
    def all(self) -> List[E]:
        """Returns all registered entities."""
        return list(self._storage)


class ChildStructureRegistry(RegistryBase[S]):
    """
    Registry for child structures. Keyed by name, preserves insertion order.
    Supports both register (existing) and add (create + register).

    Attributes:
        _owner (GeneticStructure[Any]): Parent structure that owns this registry.
        _storage (Dict[str, S]): Name-to-child mapping for registered structures.
    """
    def __init__(
        self,
        owner: GeneticStructure[Any],
        expected_type: Optional[type[GeneticStructure[E]]] = None
    ):
        super().__init__(expected_type)
        self._owner = owner  # The parent structure that owns this registry
        self._storage: Dict[str, S] = {}

    def _is_expected_child(self, item: object) -> TypeGuard[S]:
        # Additional explicit narrower used when reading from heterogeneous caches.
        # Cache values are stored in broader Dict[str, GeneticStructure] maps; this
        # function safely narrows back to S for assignment into Dict[str, S].
        expected_type = self._expected_type
        return expected_type is not None and isinstance(item, expected_type)

    def _get_key(self, item: S) -> str:
        return item.name

    def _single_register(self, item: S) -> None:
        """Register an existing child structure."""
        self._check_type(item)
        if not hasattr(item, 'name'):
            raise TypeError("Child must have a 'name' attribute.")
        if item.name not in self._storage:
            self._storage[item.name] = item

    def _single_unregister(self, item: S) -> None:
        """Unregister by item."""
        self._storage.pop(item.name, None)

    def _single_unregister_by_key(self, key: str) -> None:
        """Unregister by name."""
        self._storage.pop(key, None)

    def add(self, name: str, **kwargs: Any) -> S:
        """
        Create a new child structure and register it.
        This is a convenience method: create + register.

        If a child with the same *name* already exists in this registry, the
        cached instance is returned immediately.  This makes ``add`` idempotent
        and consistent with ``GeneticStructure.__new__``, which also returns
        cached instances rather than creating duplicates.

        Uses Species-level caching to ensure uniqueness within the same Species.
        """
        assert isinstance(name, str), "Child structure name must be a string."
        if not name.strip():
            raise ValueError("Child structure name must be a non-empty string.")
        if name in self._storage:
            return self._storage[name]
        expected_type = self._expected_type
        if expected_type is None:
            raise ValueError("expected_type not set, cannot construct child structure.")

        # Get the Species from the owner
        species: Optional[Species] = self._owner.species

        # Check if structure already exists in cache (Species-scoped or global)
        if species is not None:
            # Preferred path: Species-scoped cache (isolation between species).
            if expected_type not in species.structure_cache:
                species.structure_cache[expected_type] = {}

            cache = species.structure_cache[expected_type]
            if name in cache:
                # Return cached instance
                cached_child = cache[name]
                if self._is_expected_child(cached_child):
                    # Still register it in this owner's registry if not already there
                    if name not in self._storage:
                        self._storage[name] = cached_child
                    return cached_child
                raise TypeError(
                    f"Cached structure for '{name}' has wrong type: "
                    f"expected {expected_type.__name__}, got {type(cached_child).__name__}"
                )

            # Create new child with parent (species is inherited automatically)
            created_child = expected_type(name, parent=self._owner, **kwargs)
            if not self._is_expected_child(created_child):
                raise TypeError(
                    f"Created structure for '{name}' has wrong type: "
                    f"expected {expected_type.__name__}, got {type(created_child).__name__}"
                )
            child = created_child

            # Cache it in the Species
            cache[name] = child
        else:
            # Fallback path for backward compatibility with structures not yet
            # bound into a Species context.
            if expected_type not in _GLOBAL_STRUCTURE_CACHE:
                _GLOBAL_STRUCTURE_CACHE[expected_type] = {}

            cache = _GLOBAL_STRUCTURE_CACHE[expected_type]
            if name in cache:
                # Return cached instance
                cached_child = cache[name]
                if self._is_expected_child(cached_child):
                    # Still register it in this owner's registry if not already there
                    if name not in self._storage:
                        self._storage[name] = cached_child
                    return cached_child
                raise TypeError(
                    f"Cached structure for '{name}' has wrong type: "
                    f"expected {expected_type.__name__}, got {type(cached_child).__name__}"
                )

            # Create new child with parent (no species means orphan)
            created_child = expected_type(name, parent=self._owner, **kwargs)
            if not self._is_expected_child(created_child):
                raise TypeError(
                    f"Created structure for '{name}' has wrong type: "
                    f"expected {expected_type.__name__}, got {type(created_child).__name__}"
                )
            child = created_child

            # Cache it globally
            cache[name] = child

        return child

    def get(self, name: str) -> S:
        """Get a child structure by name."""
        if name not in self._storage:
            raise KeyError(f"No child structure named '{name}' found.")
        return self._storage[name]

    def __iter__(self):
        """Iterate over child structures."""
        return iter(self._storage.values())

    def __contains__(self, name_or_item: Union[str, GeneticStructure[Any]]) -> bool:
        """Check if a child structure exists by name or instance."""
        name = name_or_item if isinstance(name_or_item, str) else name_or_item.name
        return name in self._storage

    def __len__(self) -> int:
        """Return the number of registered structures."""
        return len(self._storage)

    def clear(self) -> None:
        """Clear all registered child structures."""
        self._storage.clear()

    @property
    def all(self) -> List[S]:
        """Returns all registered child structures."""
        return list(self._storage.values())


class GeneticStructure(Generic[E]):
    """
    Base class for genetic structures.

    Structure uniqueness is now scoped to a Species, not globally.
    Within the same Species, structures of the same type must have unique names.

    Attributes:
        child_structure_type (Optional[type[GeneticStructure[Any]]]): Child structure
            class used by subclasses, or None when no child structures are supported.
        name (str): Structure identifier unique within the same structure type and species.
        species (Optional[Species]): Species this structure is currently bound to.
        all_entities (List[E]): Snapshot of currently registered runtime entities.

    Examples:
        >>> species1 = Species("Species1")
        >>> locus1 = Locus("A", species=species1)
        >>> locus2 = Locus("A", species=species1)
        >>> assert locus1 is locus2  # Same object within species1
        >>>
        >>> species2 = Species("Species2")
        >>> locus3 = Locus("A", species=species2)
        >>> assert locus1 is not locus3  # Different speciess allow same name
    """
    child_structure_type: Optional[type[GeneticStructure[Any]]] = None  # Child structure type per subclass
    _species: Optional[Species]

    @property
    def species(self) -> Optional[Species]:
        """Public accessor for the bound Species."""
        return self._species

    def __new__(
        cls,
        name: str,
        *args: Any,
        **kwargs: Any
    ):
        # Extract species and parent from kwargs
        species = kwargs.get('species')
        parent = kwargs.get('parent')

        assert isinstance(name, str), "Structure name must be a string."
        if name.strip() == "":
            raise ValueError("Structure name cannot be empty.")

        # Determine which cache to use
        target_species = None
        if species is not None:
            assert isinstance(species, Species), "species must be a Species instance."
            target_species = species
        elif parent is not None:
            assert isinstance(parent, GeneticStructure), "parent must be a GeneticStructure instance."
            target_species = parent.species

        # Get the appropriate cache
        if target_species is not None:
            # Use Species-scoped cache
            if cls not in target_species.structure_cache:
                target_species.structure_cache[cls] = {}
            cache = target_species.structure_cache[cls]
        else:
            # Use global fallback cache for structures without species
            if cls not in _GLOBAL_STRUCTURE_CACHE:
                _GLOBAL_STRUCTURE_CACHE[cls] = {}
            cache = _GLOBAL_STRUCTURE_CACHE[cls]

        # Check if instance already exists in cache
        if name in cache:
            return cache[name]

        # Create new instance (do NOT cache here - cache in __init__ after success)
        instance = super().__new__(cls)

        return instance

    def __init__(
        self,
        name: str,
        parent: Optional[GeneticStructure[Any]] = None,
        species: Optional[Species] = None
    ):
        # Prevent re-initialization of cached instances
        if hasattr(self, "_initialized") and self._initialized:
            return

        assert isinstance(name, str), "Structure name must be a string."
        if name.strip() == "":
            raise ValueError("Structure name cannot be empty.")

        # Registry wiring:
        # - _entities tracks runtime-bound entity instances (Gene/Haplotype/...)
        # - child_structures (if enabled by subclass) tracks structural children
        #   (Locus under Chromosome, Chromosome under Species, etc.)
        #
        # entity_type remains a subclass property to support lazy import and avoid
        # circular imports with natal.genetic_entities.
        self.name = name
        self._entities: EntityRegistry[E] = EntityRegistry()

        # Track the root Species for this structure
        if species is not None:
            self._species = species
        elif parent is not None:
            # Inherit species from parent
            self._species = parent.species
        else:
            # This is a Species itself
            self._species = None

        # Initialize child structures registry if applicable
        cls = self.__class__
        if cls.child_structure_type:
            self.child_structures = ChildStructureRegistry[cls.child_structure_type](
                owner=self,
                expected_type=cls.child_structure_type
            )

        # Strict constraint: must be added to a parent unless top-level
        if parent is not None:
            assert isinstance(parent, GeneticStructure), \
                "parent must be a GeneticStructure instance."
            # Register this structure as a child of the parent
            assert parent.child_structures is not None, \
                f"Parent {parent.__class__.__name__} does not support child structures."
            parent.child_structures.register(self)

        # Mark as initialized, avoiding re-initialization when created from cache
        self._initialized = True

        # Cache the instance AFTER successful initialization
        self._add_to_cache(self._species)

    def _get_cache_for_species(self, species: Optional[Species]) -> Dict[str, GeneticStructure[E]]:
        """Get the appropriate cache for the given species."""
        cls = self.__class__
        if species is not None:
            if cls not in species.structure_cache:
                species.structure_cache[cls] = {}
            return species.structure_cache[cls]
        else:
            if cls not in _GLOBAL_STRUCTURE_CACHE:
                _GLOBAL_STRUCTURE_CACHE[cls] = {}
            return _GLOBAL_STRUCTURE_CACHE[cls]

    def _remove_from_cache(self, species: Optional[Species]) -> None:
        """Remove this structure from the specified species's cache (or global cache)."""
        cache = self._get_cache_for_species(species)
        cache.pop(self.name, None)

    def _add_to_cache(self, species: Optional[Species]) -> None:
        """Add this structure to the specified species's cache (or global cache)."""
        cache = self._get_cache_for_species(species)
        cache[self.name] = self

    def _bind_to_species(self, new_species: Optional[Species]) -> None:
        """Change the species binding and update caches accordingly.

        Args:
            new_species: The new Species to bind to, or None to unbind.

        This method:
        1. Removes the structure from its current cache (old species or global)
        2. Updates _species reference
        3. Adds the structure to the new cache (new species or global)
        """
        if not hasattr(self, '_species'):
            # Not yet initialized, skip cache management
            return

        old_species = self._species

        # No change, do nothing
        if old_species is new_species:
            return

        # Remove from old cache
        self._remove_from_cache(old_species)

        # Update species reference
        self._species = new_species

        # Add to new cache
        self._add_to_cache(new_species)

    @property
    def entity_type(self) -> Optional[type]:
        """
        Override in subclass to specify the entity type.
        Using property allows lazy import to avoid circular dependencies.
        """
        return None

    @classmethod
    def clear_cache(cls) -> None:
        """
        Deprecated: Caching is now managed by Species.
        This method does nothing but is kept for backward compatibility.
        """
        pass

    def clear_all_caches(self) -> None:
        """
        Clear all caches including:
        - Global fallback cache (for structures without Species)
        - All Species-specific caches are cleared via Species.clear_all_caches()

        This method is primarily for testing and cleanup.
        """
        global _GLOBAL_STRUCTURE_CACHE
        _GLOBAL_STRUCTURE_CACHE.clear()

    def add(
        self,
        name_or_specs: Union[str, List[str], List[Tuple[str, Dict[str, Any]]]],
        **kwargs: Any,
    ) -> Union[GeneticStructure[Any], List[GeneticStructure[Any]]]:
        """
        Add child structure(s) to this structure.

        Args:
            name_or_specs: Can be:
                - str: Single child name
                - List[str]: List of child names
                - List[Tuple[str, Dict]]: List of (name, kwargs) tuples
            **kwargs: Additional keyword arguments for single child creation.

        Returns:
            Single child structure or list of child structures.

        Examples:
            >>> linkage.add("LocusA", location=100)  # Single child
            >>> linkage.add(["LocusA", "LocusB"])    # Multiple children
            >>> linkage.add([("LocusA", {"location": 100}), ("LocusB", {"location": 200})])
        """
        child_registry = self._requirechild_structures_registry()

        assert isinstance(name_or_specs, (str, list)), \
            f"Expected str, List[str], or List[Tuple[str, Dict]], got {type(name_or_specs).__name__}"

        # Single name
        if isinstance(name_or_specs, str):
            return child_registry.add(name_or_specs, **kwargs)

        # List of names or (name, kwargs) tuples
        else:
            results: List[GeneticStructure[Any]] = []
            for item in name_or_specs:
                if isinstance(item, str):
                    results.append(child_registry.add(item, **kwargs))
                elif len(item) == 2:
                    name, child_kwargs = item
                    merged_kwargs = {**kwargs, **child_kwargs}
                    results.append(child_registry.add(name, **merged_kwargs))
                else:
                    raise TypeError(f"Invalid item in list: {item}. Expected str or (str, dict) tuple.")
            return results

    def remove(
        self,
        name_or_child: Union[str, GeneticStructure[Any], List[Union[str, GeneticStructure[Any]]]],
    ) -> None:
        """
        Remove child structure(s) from this structure.

        Args:
            name_or_child: Can be:
                - str: Child name to remove
                - GeneticStructure: Child instance to remove
                - List: List of names or instances to remove

        Examples:
            >>> linkage.remove("LocusA")           # Remove by name
            >>> linkage.remove(locus_a)            # Remove by instance
            >>> linkage.remove(["LocusA", "LocusB"])  # Remove multiple
        """
        child_registry = self._requirechild_structures_registry()

        # Delegate to registry - it handles both str and object
        child_registry.unregister(name_or_child)

    def get_child(self, name: str) -> GeneticStructure[Any]:
        """
        Get a child structure by name.

        Args:
            name: Name of the child structure.

        Returns:
            The child structure instance.

        Raises:
            KeyError: If no child with that name exists.
        """
        child_registry = self._requirechild_structures_registry()
        return child_registry.get(name)

    @property
    def children(self) -> List[GeneticStructure[Any]]:
        """Returns all child structures."""
        if not hasattr(self, "child_structures"):
            return []
        child_registry = self.child_structures
        return child_registry.all

    def _requirechild_structures_registry(self) -> ChildStructureRegistry[GeneticStructure[Any]]:
        if not hasattr(self, "child_structures"):
            raise AttributeError(f"{self.__class__.__name__} does not support child structures.")
        return self.child_structures

    def register(
        self,
        entity_or_entities: Union[E, List[E], Tuple[E, ...], Set[E]]
    ) -> GeneticStructure[E]:
        """
        Register a single entity or an iterable of entities with this structure.

        EntityRegistry performs runtime type validation based on the expected type provided at construction.

        Args:
            entity_or_entities: Single entity or iterable of entities to register.

        Returns:
            The GeneticStructure instance (for chaining).
        """
        # Delegate single/batch normalization and strict type-checking to EntityRegistry.
        self._entities.register(entity_or_entities)
        return self

    def unregister(
        self,
        entity_or_entities: Union[E, str, List[Union[E, str]], Tuple[Union[E, str], ...], Set[Union[E, str]]]
    ) -> GeneticStructure[E]:
        """
        Unregister a single entity or an iterable of entities from this structure.

        Args:
            entity_or_entities: Single entity or iterable of entities to unregister.

        Returns:
            The GeneticStructure instance (for chaining).
        """
        self._entities.unregister(entity_or_entities)
        return self

    @property
    def all_entities(self) -> List[E]:
        """
        Returns a list of all entities currently registered to this structure.
        """
        return self._entities.all

    @classmethod
    def with_entities(
        cls,
        name: str,
        entity_ids: Union[str, Iterable[str]],
        **entity_kwargs: Any
    ) -> GeneticStructure[E]:
        """
        Factory method to create a GeneticStructure instance and register entities by their identifiers.

        Args:
            name (str): Name of the genetic structure.
            entity_ids (str | Iterable[str]): Single identifier or iterable of identifiers for entities to register.
            **entity_kwargs: Additional keyword arguments to pass to the entity constructor.
        """
        structure = cls(name)
        entity_type = structure.entity_type
        if entity_type is None:
            raise TypeError(f"{cls.__name__} has no entity type defined.")

        if isinstance(entity_ids, str):
            entity_ids = [entity_ids]

        entities = [entity_type(name=en, **entity_kwargs) for en in entity_ids]
        structure.register(entities)
        return structure

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.name}, {self.entity_type}={self.all_entities})"

# Locus (model-level) -> Gene (entity-level)
class Locus(GeneticStructure['Gene']):
    """
    Represents a genetic locus with its name.

    A Locus is a blueprint for a genetic position. Multiple Gene entities
    (alleles) can be bound to a single Locus.

    Attributes:
        position (Union[int, float]): The linear position on the chromosome. Used for defining
            recombination rates. If not specified, defaults to max(position) + 1
            among existing loci in the parent Linkage, or 0 if no parent.
        alleles (List[Gene]): Registered allele entities bound to this locus.
    """
    child_structure_type = None  # Locus has no child structures

    def __init__(
        self,
        name: str,
        position: Optional[Union[int, float]] = None,
        chromosome: Optional[Chromosome] = None,
        parent: Optional[Chromosome] = None,
        **kwargs: Any
    ):
        # Check if already initialized (cached instance)
        if hasattr(self, '_initialized') and self._initialized:
            return

        # Parent is alias for chromosome
        if chromosome is None:
            chromosome = parent

        # Save parent reference for cache invalidation
        self._parent_chromosome = chromosome

        # Compute default position before super().__init__
        # (since parent.register may be called)
        if position is None:
            if chromosome is not None and hasattr(chromosome, 'child_structures') and len(chromosome.child_structures) > 0:
                # Default: max position in parent + 1
                max_pos = max(
                    (loc.position for loc in chromosome.child_structures),
                    default=-1
                )
                position = max_pos + 1
            else:
                position = 0

        self._position = position

        # Store custom parameters as attributes
        for key, value in kwargs.items():
            setattr(self, key, value)

        # Locus's species is automatically inherited from parent Chromosome
        super().__init__(name, parent=chromosome)

    @property
    def position(self) -> Union[int, float]:
        """The linear position on the chromosome."""
        return self._position

    @position.setter
    def position(self, value: Union[int, float]) -> None:
        """Set the position. Triggers cache invalidation in parent Linkage."""
        self._position = value
        # Invalidate parent's cache if exists
        if hasattr(self, '_parent_chromosome') and self._parent_chromosome is not None:
            self._parent_chromosome.invalidate_recombination_map_cache()

    @property
    def entity_type(self):
        """Lazy import to avoid circular dependency."""
        from natal.genetic_entities import Gene
        return Gene

    def register(
        self,
        entity_or_entities: Union[Gene, List[Gene], Tuple[Gene, ...], Set[Gene]]
    ) -> Locus:
        """
        Register gene entities and invalidate species gene index cache.
        """
        super().register(entity_or_entities)
        if self._species is not None:
            self._species.invalidate_gene_index_cache()
        return self

    def unregister(
        self,
        entity_or_entities: Union[Gene, str, List[Union[Gene, str]], Tuple[Union[Gene, str], ...], Set[Union[Gene, str]]]
    ) -> Locus:
        """
        Unregister gene entities and invalidate species gene index cache.
        """
        super().unregister(entity_or_entities)
        if self._species is not None:
            self._species.invalidate_gene_index_cache()
        return self

    @property
    def alleles(self) -> List[Gene]:
        """Alias for all_entities - returns all registered alleles (genes)."""
        return self.all_entities

    def register_allele(self, gene: Gene) -> Locus:
        """Alias for register - register a single allele."""
        return self.register(gene)

    def unregister_allele(self, gene: Gene) -> Locus:
        """Alias for unregister - unregister a single allele."""
        return self.unregister(gene)

    def add_alleles(
        self,
        alleles_or_allele_names: Union[List[Union[Gene, str]], Gene, str],
    ) -> Locus:
        """
        Add one or more alleles (genes) to this locus.

        Args:
            alleles_or_allele_names: Single Gene instance, single allele name (str),
                or list of Gene instances and/or allele names (str).
        Returns:
            The Locus instance (for chaining). Note that for other structure-level add methods,
            the return type is the child structure(s) added. But here we return self for consistency
            with the register_allele/unregister_allele methods.
        """
        from natal.genetic_entities import Gene

        if isinstance(alleles_or_allele_names, (Gene, str)):
            alleles_or_allele_names = [alleles_or_allele_names]

        for item in alleles_or_allele_names:
            assert isinstance(item, (Gene, str)), f"Expected Gene or str, got {type(item).__name__} instead."
            if isinstance(item, Gene):
                self.register(item)
            else:
                Gene(item, locus=self)  # Auto-registers via Gene.__init__

        return self

    @classmethod
    def with_alleles(
        cls,
        name: str,
        alleles_or_allele_names: Union[List[Union[Gene, str]], Gene, str],
        position: Optional[Union[int, float]] = None
    ) -> Locus:
        """
        Factory method to create a Locus and register alleles (genes) by names.

        Args:
            name: Name of the locus.
            alleles_or_allele_names: Single Gene instance, single allele name (str),
                or list of Gene instances and/or allele names (str).
            position: Optional position on the chromosome.

        Returns:
            Locus instance with registered alleles.

        Examples:
            >>> locus = Locus.with_alleles("A", ["A1", "A2", "A3"])
            >>> locus.alleles  # -> [Gene("A1"), Gene("A2"), Gene("A3")]
        """
        return cls(name, position=position).add_alleles(alleles_or_allele_names)

    def __repr__(self) -> str:
        allele_names = [g.name for g in self.alleles]
        return f"Locus({self.name!r}, position={self.position}, alleles={allele_names})"

# Chromosome (structure-level) -> Haplotype (entity-level)
class Chromosome(GeneticStructure['Haplotype']):
    """
    Represents a chromosome structure with linkage information among loci.

    A Chromosome groups multiple Loci that are physically linked on the same
    chromosome. It also stores the recombination rates between loci.

    Attributes:
        sex_type (SexChromosomeType): Sex chromosome type.
            - None or 'autosome': Autosome (default)
            - 'X': X chromosome in XY system
            - 'Y': Y chromosome in XY system (paternal only)
            - 'Z': Z chromosome in ZW system
            - 'W': W chromosome in ZW system (maternal only)
        loci (List[Locus]): Child loci sorted by position.
        recombination_map (Chromosome.RecombinationMap): Adjacent-locus recombination map.
        recombination_matrix (Chromosome.RecombinationMap): Backward-compatible alias
            of recombination_map.
        is_sex_chromosome (bool): Whether this chromosome participates in sex determination.
        is_autosome (bool): Whether this chromosome is an autosome.
        sex_system (Optional[str]): Sex system inferred from sex_type ('XY', 'ZW', or None).

    Examples:
        >>> chr_x = Chromosome('X', sex_type='X')
        >>> chr_y = Chromosome('Y', sex_type='Y')
        >>> print(chr_x.is_sex_chromosome)  # True
        >>> print(chr_y.sex_type.paternal_only)  # True

    This class is also exported as Linkage for backward compatibility.
    """
    child_structure_type = Locus  # Chromosome contains Loci as children
    child_structures: ChildStructureRegistry[Locus]

    def __init__(
        self,
        name: str,
        loci: Optional[List[Locus]] = None,
        species: Optional[Species] = None,
        parent: Optional[Species] = None,
        recombination_rates: Optional[Union[List[float], np.ndarray]] = None,
        sex_type: Optional[Union[SexChromosomeType, str]] = None,
    ):
        # Initialize placeholders BEFORE super().__init__
        # because __iter__ may be called during parent registration
        if not hasattr(self, '_recombination_map'):
            self._recombination_map: Optional[Chromosome.RecombinationMap] = None
            self._sorted_loci_cache: Optional[List[Locus]] = None  # Cache for sorted loci
            self._sex_type: SexChromosomeType = SexChromosomeType.AUTOSOME

        # Check if already initialized (cached instance)
        if hasattr(self, '_initialized') and self._initialized:
            return

        # Parent is alias for species
        if species is None:
            species = parent

        # Set sex chromosome type
        self._set_sex_type(sex_type)

        # Chromosome's species is automatically inherited from parent Species
        super().__init__(name, parent=species)

        if loci:
            for locus in loci:
                self.add_locus(locus)

        # Initialize recombination map
        self._invalidate_recombination_map_cache()

        # Set recombination rates if provided
        if recombination_rates is not None:
            if len(self.loci) < 2:
                raise ValueError("Cannot set recombination rates with less than 2 loci.")
            if len(recombination_rates) != len(self.loci) - 1:
                raise ValueError(
                    f"Expected {len(self.loci) - 1} recombination rates for {len(self.loci)} loci, "
                    f"got {len(recombination_rates)} instead."
                )
            for i, rate in enumerate(recombination_rates):
                self.recombination_map[i] = rate

    def _set_sex_type(self, sex_type: Optional[Union[SexChromosomeType, str]]) -> None:
        """Set sex chromosome type (internal method)"""
        assert isinstance(sex_type, (SexChromosomeType, str, type(None))), f"Expected SexChromosomeType or str, got {type(sex_type).__name__}"
        if sex_type is None:
            self._sex_type = SexChromosomeType.AUTOSOME
        elif isinstance(sex_type, SexChromosomeType):
            self._sex_type = sex_type
        else:
            sex_type_upper = sex_type.upper()
            if sex_type_upper in ('AUTOSOME', 'AUTO', 'A', ''):
                self._sex_type = SexChromosomeType.AUTOSOME
            elif sex_type_upper == 'X':
                self._sex_type = SexChromosomeType.X
            elif sex_type_upper == 'Y':
                self._sex_type = SexChromosomeType.Y
            elif sex_type_upper == 'Z':
                self._sex_type = SexChromosomeType.Z
            elif sex_type_upper == 'W':
                self._sex_type = SexChromosomeType.W
            else:
                raise ValueError(
                    f"Unknown sex_type: {sex_type!r}. "
                    f"Valid values: 'X', 'Y', 'Z', 'W', 'autosome', or SexChromosomeType enum."
                )

    @property
    def sex_type(self) -> SexChromosomeType:
        """Returns the sex chromosome type"""
        return self._sex_type

    @sex_type.setter
    def sex_type(self, value: Optional[Union[SexChromosomeType, str]]) -> None:
        """Set the sex chromosome type"""
        self._set_sex_type(value)

    @property
    def is_sex_chromosome(self) -> bool:
        """Whether this is a sex chromosome"""
        return self._sex_type.is_sex_chromosome

    @property
    def is_autosome(self) -> bool:
        """Whether this is an autosome"""
        return not self.is_sex_chromosome

    @property
    def sex_system(self) -> Optional[str]:
        """Returns the sex determination system this chromosome belongs to ('XY', 'ZW', or None)"""
        return self._sex_type.sex_system

    @property
    def entity_type(self):
        """Lazy import to avoid circular dependency."""
        from natal.genetic_entities import Haplotype
        return Haplotype

    @property
    def loci(self) -> List[Locus]:
        """Returns the list of loci in this chromosome, sorted by position (cached)."""
        if self._sorted_loci_cache is None:
            self._sorted_loci_cache = sorted(
                self.child_structures.all,
                key=lambda loc: loc.position
            )
        return self._sorted_loci_cache

    def _invalidate_recombination_map_cache(self) -> None:
        """Invalidate sorted loci cache and update recombination map."""
        self._sorted_loci_cache = None
        self._update_recombination_map()

    @property
    def recombination_map(self) -> Chromosome.RecombinationMap:
        """Returns the recombination map for this chromosome.

        The recombination map stores recombination rates between adjacent loci.
        For n loci, the map has n-1 entries where entry i is the recombination
        rate between locus i and locus i+1.
        """
        if self._recombination_map is None:
            self._update_recombination_map()
        if self._recombination_map is None:
            raise ValueError("Recombination map is unavailable for chromosomes with fewer than 2 loci.")
        return self._recombination_map

    # Backward compatibility alias
    @property
    def recombination_matrix(self) -> Chromosome.RecombinationMap:
        """Deprecated: Use recombination_map instead."""
        return self.recombination_map

    def add_locus(
        self,
        locus_or_name: Union[Locus, str],
        position: Optional[Union[int, float]] = None,
        recombination_rate_with_previous: float = 0.0,
        **kwargs: Any
    ) -> Locus:
        """
        Add a locus to this chromosome.

        When inserting a new locus, it defaults to complete linkage with the previous
        locus (recombination rate = 0), and inherits the recombination rate with the
        next locus from the previous locus's rate with that next locus.

        Args:
            locus_or_name: Either a Locus instance or a name to create a new Locus.
            position: Optional position (only used when creating new Locus by name).
                If not specified, defaults to max(position) + 1 among existing loci.
            recombination_rate_with_previous: Recombination rate with the previous locus.
                Defaults to 0 (complete linkage).
            **kwargs: Additional custom parameters to pass to the Locus constructor.

        Returns:
            The added Locus instance.
        """
        # Get current sorted loci and old map before adding
        old_sorted_loci = self.loci.copy() if self._sorted_loci_cache else []
        old_map = self._recombination_map

        assert isinstance(locus_or_name, (Locus, str)), \
            f"Expected Locus instance or str, got {type(locus_or_name).__name__}"
        if isinstance(locus_or_name, str):
            # Create new Locus via base class add method with kwargs
            created = self.add(locus_or_name, position=position, **kwargs)
            assert isinstance(created, Locus), \
                f"Expected add() to return Locus, got {type(created).__name__}"
            locus = created
        else:
            locus = locus_or_name
            # Register existing Locus if not already in registry
            if locus.name not in self.child_structures:
                self.child_structures.register(locus)

        # Invalidate cache and update recombination map with insertion handling
        self._sorted_loci_cache = None
        self._update_recombination_map_on_insert(
            locus, old_sorted_loci, old_map, recombination_rate_with_previous
        )
        if self._species is not None:
            self._species.invalidate_gene_index_cache()
        return locus

    def remove_locus(self, locus_or_name: Union[Locus, str]) -> None:
        """
        Remove a locus from this chromosome.

        When removing a locus, the recombination rates are adjusted to maintain
        connectivity between the remaining loci.

        Args:
            locus_or_name: Either a Locus instance or a name.
        """
        if isinstance(locus_or_name, str):
            name = locus_or_name
        else:
            name = locus_or_name.name

        if name in self.child_structures:
            # Get old state
            old_sorted_loci = self.loci.copy()
            old_map = self._recombination_map

            # Find the index of the locus to remove
            locus_to_remove = self.child_structures.get(name)
            remove_idx = old_sorted_loci.index(locus_to_remove)

            # Unregister the locus
            self.child_structures.unregister(name)
            self._sorted_loci_cache = None

            # Update recombination map
            self._update_recombination_map_on_remove(remove_idx, old_map)
            if self._species is not None:
                self._species.invalidate_gene_index_cache()

    def _update_recombination_map(self) -> None:
        """Create a fresh recombination map (all rates = 0)."""
        if len(self.child_structures) > 1:
            self._recombination_map = Chromosome.RecombinationMap(loci=self.loci)
        else:
            self._recombination_map = None

    def invalidate_recombination_map_cache(self) -> None:
        """Public wrapper for recombination-map cache invalidation."""
        self._invalidate_recombination_map_cache()

    def _update_recombination_map_on_insert(
        self,
        new_locus: Locus,
        old_sorted_loci: List[Locus],
        old_map: Optional[Chromosome.RecombinationMap],
        recombination_rate_with_previous: float
    ) -> None:
        """Update recombination map when a new locus is inserted."""
        new_sorted_loci = self.loci
        n = len(new_sorted_loci)

        if n <= 1:
            self._recombination_map = None
            return

        # Find the new position of the inserted locus
        new_idx = new_sorted_loci.index(new_locus)

        # Create new map
        new_rates = np.zeros(n - 1)

        if old_map is not None and len(old_sorted_loci) > 1:
            # Copy old rates, adjusting for insertion
            for new_i in range(n - 1):
                if new_i == new_idx - 1:
                    # Rate between previous locus and new locus
                    new_rates[new_i] = recombination_rate_with_previous
                elif new_i == new_idx:
                    # Rate between new locus and next locus
                    # Inherit from the old rate between prev and next
                    if new_idx > 0 and new_idx - 1 < len(old_map):
                        new_rates[new_i] = old_map[new_idx - 1]
                    else:
                        new_rates[new_i] = 0.0
                else:
                    # Copy from old map
                    if new_i < new_idx:
                        new_rates[new_i] = old_map[new_i] if new_i < len(old_map) else 0.0
                    else:  # new_i > new_idx
                        old_idx = new_i - 1  # Account for insertion
                        new_rates[new_i] = old_map[old_idx] if old_idx < len(old_map) else 0.0
        else:
            # First pair of loci, set the rate
            new_rates[0] = recombination_rate_with_previous

        self._recombination_map = Chromosome.RecombinationMap(
            loci=new_sorted_loci,
            rates=new_rates
        )

    def _update_recombination_map_on_remove(
        self,
        remove_idx: int,
        old_map: Optional[Chromosome.RecombinationMap]
    ) -> None:
        """Update recombination map when a locus is removed.

        When removing locus C from [A, C, B], the new rate r(A,B) = r(A,C) + r(C,B).
        This follows the additive property of genetic distances for small rates.
        """
        new_sorted_loci = self.loci
        n = len(new_sorted_loci)

        if n <= 1:
            self._recombination_map = None
            return

        new_rates = np.zeros(n - 1)

        if old_map is not None:
            for new_i in range(n - 1):
                if new_i < remove_idx - 1:
                    # Before the pair affected by removal
                    new_rates[new_i] = old_map[new_i] if new_i < len(old_map) else 0.0
                elif new_i == remove_idx - 1:
                    # This is the new adjacent pair created by removal
                    # r(A,B) = r(A,C) + r(C,B) where C was removed
                    rate_before = old_map[remove_idx - 1] if remove_idx - 1 < len(old_map) else 0.0
                    rate_after = old_map[remove_idx] if remove_idx < len(old_map) else 0.0
                    new_rates[new_i] = min(rate_before + rate_after, 0.5)  # Cap at 0.5
                else:
                    # After the affected pair - shift by 1
                    old_idx = new_i + 1
                    new_rates[new_i] = old_map[old_idx] if old_idx < len(old_map) else 0.0

        self._recombination_map = Chromosome.RecombinationMap(
            loci=new_sorted_loci,
            rates=new_rates
        )

    def get_locus_index(self, name: str) -> int:
        """Get the index of a locus by name in the sorted loci list."""
        return self.recombination_map.name_to_index(name)

    class RecombinationMap:
        """
        A 1D container storing recombination rates between adjacent loci.

        For n loci, the map has n-1 entries where entry i is the recombination
        rate between locus i and locus i+1 (in sorted order by position).

        Attributes:
            loci_names (List[str]): Locus names in sorted positional order.
            _rates (np.ndarray): Adjacent-locus recombination rates with length n-1.

        Examples:
            For loci [A, B, C, D], the map is [r(A,B), r(B,C), r(C,D)]
            where index i = rate between locus i and locus i+1.
        """
        loci_names: List[str]
        _rates: np.ndarray
        _KeyType = Union[int, str, Locus]

        def __init__(
            self,
            loci: Optional[List[Locus]] = None,
            rates: Optional[np.ndarray] = None
        ) -> None:
            size = len(loci) - 1 if loci and len(loci) > 1 else 0
            if size <= 0:
                raise ValueError("RecombinationMap requires at least 2 loci.")

            self._rates = np.zeros(size, dtype=np.float64)
            self.loci_names = [locus.name for locus in loci] if loci else []

            if rates is not None:
                if len(rates) != size:
                    raise ValueError(f"Expected {size} rates, got {len(rates)}")
                self._rates[:] = rates

        # ---------- Name conversion ----------
        def _name_to_index(self, name: str) -> int:
            """Convert locus name to index in loci list."""
            if not self.loci_names:
                raise ValueError("No loci names defined in map.")
            try:
                return self.loci_names.index(name)
            except ValueError:
                raise KeyError(f"Locus name '{name}' not found.") from ValueError

        def name_to_index(self, name: str) -> int:
            """Public wrapper for converting locus name to locus index."""
            return self._name_to_index(name)

        def _normalize_single_key(self, key: _KeyType) -> int:
            """Normalize a single key to integer index."""
            if isinstance(key, str):
                return self._name_to_index(key)
            elif isinstance(key, Locus):
                return self._name_to_index(key.name)
            else:
                return key

        # ---------- Reading ----------
        @overload
        def __getitem__(self, key: _KeyType) -> float: ...

        @overload
        def __getitem__(self, key: Tuple[_KeyType, _KeyType]) -> float: ...

        @overload
        def __getitem__(self, key: Union[slice, NDArray[np.integer[Any]], List[int]]) -> NDArray[np.float64]: ...

        def __getitem__(
            self, key: Union[
                _KeyType,
                Tuple[_KeyType, _KeyType],
                Union[slice, NDArray[np.integer[Any]], List[int]]
            ]
        ) -> Union[float, NDArray[np.float64]]:
            """Retrieve recombination rate(s) from the map.

            Three indexing modes are supported:

            1. Single specifier: Returns the rate between the specified locus and the
            next locus. The specifier can be an integer index, locus name (str), or
            a `Locus` object.

            2. Tuple of two specifiers: Returns the cumulative recombination rate
            between the two loci (sum of all adjacent rates in the interval),
            capped at 0.5 (independent assortment).

            3. Slice or list of indices: Returns an array of rates for the specified
            positions.

            Args:
                key: A single specifier, a pair of specifiers, or a slice/array/list
                    of integer indices.

            Returns:
                A single float for single-locus or pair requests, otherwise a NumPy
                array of rates.

            Raises:
                KeyError: If a specifier does not correspond to a registered locus.
            """
            # Case 1: tuple of two specifiers -> cumulative rate
            if isinstance(key, tuple) and len(key) == 2:
                a, b = key
                idx_a = self._normalize_single_key(a)
                idx_b = self._normalize_single_key(b)
                # Ensure correct order
                if idx_a > idx_b:
                    idx_a, idx_b = idx_b, idx_a
                # Sum rates in the interval [idx_a, idx_b)
                total_rate = 0.0
                for i in range(idx_a, idx_b):
                    total_rate += float(self._rates[i])
                return float(min(total_rate, 0.5))

            # Case 2: slice or array-like -> return array
            if isinstance(key, (slice, np.ndarray, list)):
                result = self._rates[key]
                return result

            # Case 3: single specifier (int, str, Locus)
            idx = self._normalize_single_key(key)
            return float(self._rates[idx])

        # ---------- Writing ----------
        def __setitem__(
            self,
            key: Union[
                _KeyType,
                Tuple[_KeyType, _KeyType],
                slice,
                List[int],
                NDArray[np.integer[Any]]
            ],
            value: Union[float, np.ndarray]
        ) -> None:
            """
            Set recombination rate(s).

            Two forms are supported:

            - Single specifier: Sets the rate between the locus and the next locus.
            - Tuple of two specifiers: Sets the rate between two adjacent loci.
            - Slice or array indexing: Sets rates for multiple adjacent intervals.

            The specifier can be an integer index, a locus name (str), or a `Locus`
            object.

            Args:
                key: Single specifier, pair of adjacent specifiers, or slice/array index.
                value: New rate(s). A scalar value is broadcast to all selected
                    positions; an array must have the correct shape.

            Raises:
                ValueError: If any new rate is outside the [0, 0.5] range.
                KeyError: If the specifier does not correspond to a registered locus,
                    or if a pair of specifiers does not represent adjacent loci.

            Note:
                Modifying recombination rates after `Genotype.produce_gametes()`
                has been called will **not** invalidate the gamete cache. You must
                manually clear the cache: `genotype._gamete_cache = None`.
            """
            arr_val = np.asarray(value, dtype=self._rates.dtype)

            if np.any((arr_val < 0) | (arr_val > 0.5)):
                raise ValueError("Recombination rates must be in [0, 0.5]")

            if isinstance(key, tuple) and len(key) == 2:
                # Set rate between adjacent loci
                a, b = key
                idx_a = self._normalize_single_key(a)
                idx_b = self._normalize_single_key(b)
                if abs(idx_a - idx_b) != 1:
                    raise KeyError(
                        f"Loci {a!r} and {b!r} are not adjacent. "
                        f"RecombinationMap only stores rates between adjacent loci."
                    )
                self._rates[min(idx_a, idx_b)] = arr_val
            else:
                # For other keys (single specifier, slice, list, array), convert
                # specifiers to integer indices first, then assign.
                # Note: slice, list, array are passed directly to _rates; they must
                # already contain integer indices (no str/Locus conversion needed).
                idx = (self._normalize_single_key(key) if not isinstance(key, (slice, list, np.ndarray))
                       else key)
                self._rates[idx] = arr_val

        # ---------- Visualization ----------
        def __repr__(self) -> str:
            return self._formatted_repr()

        def __str__(self) -> str:
            return self._formatted_repr()

        def _formatted_repr(self) -> str:
            if self.loci_names and len(self.loci_names) > 1:
                pairs: List[str] = []
                for i in range(len(self)):
                    pairs.append(f"r({self.loci_names[i]},{self.loci_names[i+1]})={self[i]:.3f}")
                return f"RecombinationMap([{', '.join(pairs)}])"
            else:
                return f"RecombinationMap({np.array2string(self._rates, precision=3)})"

        # ---------- Utility methods ----------
        def validate(self) -> Tuple[bool, str]:
            """Validate the recombination map."""
            if np.any(self._rates < 0) or np.any(self._rates > 0.5):
                return False, "Values out of range [0, 0.5]."
            return True, "Map is valid."

        def get_adjacent_loci(self, index: int) -> Tuple[str, str]:
            """Get the names of the two loci at the given rate index."""
            if index < 0 or index >= len(self):
                raise IndexError(f"Index {index} out of range for map of size {len(self)}")
            return (self.loci_names[index], self.loci_names[index + 1])

        def __len__(self) -> int:
            return len(self._rates)

        def __iter__(self):
            return iter(self._rates)

        def __array__(self) -> np.ndarray:
            return np.asarray(self._rates)

        @property
        def dtype(self):
            return self._rates.dtype

    # Backward compatibility alias
    RecombinationMatrix = RecombinationMap

    def set_recombination(self, locus_a: Union[Locus, str], locus_b: Union[Locus, str], rate: float):
        """
        Set the recombination rate between two adjacent loci.

        Args:
            locus_a: First locus (by name or Locus object)
            locus_b: Second locus (by name or Locus object)
            rate: Recombination rate (must be in [0, 0.5])

        Raises:
            KeyError: If the loci are not adjacent
            ValueError: If rate is out of range or fewer than 2 loci
        """
        if self._recombination_map is None:
            raise ValueError("Cannot set recombination rate with fewer than 2 loci.")
        self.recombination_map[locus_a, locus_b] = rate

    def set_recombination_bulk(self, settings: Dict[Tuple[Union[Locus, str], Union[Locus, str]], float]):
        """
        Bulk set recombination rates between adjacent loci.

        Args:
            settings: Dictionary of {(locus_a, locus_b): rate}
        """
        for (a, b), rate in settings.items():
            self.set_recombination(a, b, rate)

    def set_recombination_all(self, value: float):
        """
        Set all recombination rates to the same value.

        Args:
            value: Recombination rate (must be in [0, 0.5])
        """
        if self._recombination_map is not None:
            self._recombination_map[:] = value

    # Backward compatibility alias
    def set_recombination_default(self, value: float):
        """Deprecated: Use set_recombination_all instead."""
        self.set_recombination_all(value)

    def set_recombination_rate(self, locus_a: Union[Locus, str], locus_b: Union[Locus, str], rate: float):
        """
        Deprecated: Use set_recombination instead.
        """
        self.set_recombination(locus_a, locus_b, rate)

    def set_recombination_rates(self, settings: Dict[Tuple[Union[Locus, str], Union[Locus, str]], float]):
        """
        Deprecated: Use set_recombination_bulk instead.
        """
        self.set_recombination_bulk(settings)

    def __repr__(self):
        return f"Chromosome({self.name!r}, loci={[loc.name for loc in self.loci]})"

    def __iter__(self):
        return iter(self.loci)

    def __len__(self):
        return len(self.loci)

# Species (structure-level) -> HaploidGenome (entity-level)
class Species(GeneticStructure['HaploidGenome']):
    """
    Represents the complete genetic architecture defined by chromosomes.

    A Species is the top-level structure that contains multiple Chromosomes,
    each representing a chromosome with its loci and recombination rates.

    Attributes:
        child_structures (ChildStructureRegistry[Chromosome]): Registry of chromosomes.
        structure_cache (Dict[type, Dict[str, GeneticStructure[Any]]]): Species-scoped
            structure cache grouped by structure type.
        gamete_labels (List[str]): Optional labels used to identify gamete categories.

    This class is also exported as GenomeTemplate for backward compatibility.
    """
    child_structure_type = Chromosome  # Species contains Chromosomes as children
    child_structures: ChildStructureRegistry[Chromosome]
    _sex_chromosome_groups: Optional[Dict[str, List[Chromosome]]]
    _valid_sex_genotypes: Optional[List[Tuple[Chromosome, Chromosome]]]

    def __init__(
        self,
        name: str,
        chromosomes: Optional[List[Chromosome]] = None,
        gamete_labels: Optional[list[str]] = None
    ):
        # Initialize structure caches for this Species
        # Format: {structure_type: {name: instance}}
        self._structure_cache: Dict[type, Dict[str, GeneticStructure[Any]]] = {}
        self._gene_index_cache: Optional[Dict[str, Gene]] = None

        super().__init__(name, parent=None, species=None)  # Species is top-level, no parent

        # Set self as the species
        self._species = self

        # Add initial chromosomes if provided
        if chromosomes:
            for chrom in chromosomes:
                self.add_chromosome(chrom)

        # Gamete labels for this species
        if gamete_labels is not None:
            self._gamete_labels = list(gamete_labels)
        else:
            self._gamete_labels = []

    @property
    def gamete_labels(self) -> List[str]:
        """Return the list of gamete labels for this species."""
        return self._gamete_labels

    @gamete_labels.setter
    def gamete_labels(self, labels: List[str]) -> None:
        self._gamete_labels = list(labels)

    @property
    def entity_type(self):
        """Lazy import to avoid circular dependency."""
        from natal.genetic_entities import HaploidGenome
        return HaploidGenome

    def clear_structure_cache(self) -> None:
        """
        Clear all structure caches for this Species.
        This removes all cached Structure instances (Locus, Chromosome) within this Species.
        """
        self._structure_cache.clear()
        self._invalidate_gene_index_cache()

    @property
    def structure_cache(self) -> Dict[type, Dict[str, GeneticStructure[Any]]]:
        """Public accessor for species-scoped structure caches."""
        return self._structure_cache

    def clear_entity_cache(self) -> None:
        """
        Clear all entity caches for this Species.
        This removes all cached Entity instances (Gene, Haplotype, etc.) within this Species.
        """
        from natal.genetic_entities import GeneticEntity
        GeneticEntity.clear_species_cache(id(self))

    def clear_all_caches(self) -> None:
        """
        Clear both structure and entity caches for this Species.
        """
        self.clear_structure_cache()
        self.clear_entity_cache()

    def _invalidate_gene_index_cache(self) -> None:
        """Invalidate species-level gene name lookup cache."""
        self._gene_index_cache = None

    def invalidate_gene_index_cache(self) -> None:
        """Public wrapper for invalidating the species gene-index cache."""
        self._invalidate_gene_index_cache()

    @property
    def chromosomes(self) -> List[Chromosome]:
        """Returns the list of chromosomes in this species."""
        return self.child_structures.all

    # Alias for backward compatibility
    @property
    def linkages(self) -> List[Chromosome]:
        """Alias for chromosomes (backward compatibility)."""
        return self.chromosomes

    @property
    def sex_chromosomes(self) -> List[Chromosome]:
        """Returns all sex chromosomes"""
        return [c for c in self.chromosomes if c.is_sex_chromosome]

    @property
    def autosomes(self) -> List[Chromosome]:
        """Returns all autosomes"""
        return [c for c in self.chromosomes if c.is_autosome]

    @property
    def sex_system(self) -> Optional[str]:
        """
        Returns the sex determination system ('XY', 'ZW', or None).

        Automatically inferred from Chromosome.sex_type. Raises an error if multiple systems are found.
        """
        systems: Set[str] = set()
        for chrom in self.chromosomes:
            if chrom.sex_system:
                systems.add(chrom.sex_system)

        if len(systems) == 0:
            return None
        elif len(systems) == 1:
            return systems.pop()
        else:
            raise ValueError(
                f"Multiple sex chromosome systems detected: {systems}. "
                f"A species should only have one sex determination system."
            )

    @property
    def gene_index(self) -> Dict[str, Gene]:
        """Returns a mapping from gene names to gene instances."""
        return self._build_gene_index()

    def _build_sex_chromosome_groups(self) -> Dict[str, List[Chromosome]]:
        """
        Automatically build _sex_chromosome_groups from Chromosome.sex_type.

        Returns:
            Sex chromosome group dictionary, keys are system names like 'XY' or 'ZW'
        """
        groups: Dict[str, List[Chromosome]] = {}

        for chrom in self.chromosomes:
            system = chrom.sex_system
            if system:
                if system not in groups:
                    groups[system] = []
                groups[system].append(chrom)

        return groups

    def _build_valid_sex_genotypes(self) -> List[Tuple[Chromosome, Chromosome]]:
        """
        Automatically infer valid sex chromosome genotype combinations from Chromosome.sex_type.

        Rules include:
            - XY system: X can come from either parent, Y is paternal only
                    -> Valid combinations: (X, X), (X, Y)
            - ZW system: Z can come from either parent, W is maternal only
                    -> Valid combinations: (Z, Z), (W, Z)

        Returns:
            List of valid (maternal_chrom, paternal_chrom) combinations
        """
        valid_combos: List[Tuple[Chromosome, Chromosome]] = []

        # Group chromosomes by sex determination system.
        system_chroms: Dict[str, Dict[str, Chromosome]] = {}

        for chrom in self.chromosomes:
            if not chrom.is_sex_chromosome:
                continue
            system = chrom.sex_system
            if system is None:
                continue
            if system not in system_chroms:
                system_chroms[system] = {}
            # Use sex chromosome type name as the key.
            system_chroms[system][chrom.sex_type.value] = chrom

        for system, chroms in system_chroms.items():
            if system == 'XY':
                x_chrom = chroms.get('X')
                y_chrom = chroms.get('Y')
                if x_chrom:
                    # XX (female) - X from both parents
                    valid_combos.append((x_chrom, x_chrom))
                    if y_chrom:
                        # XY (male) - X from maternal, Y from paternal
                        valid_combos.append((x_chrom, y_chrom))

            elif system == 'ZW':
                z_chrom = chroms.get('Z')
                w_chrom = chroms.get('W')
                if z_chrom:
                    # ZZ (male) - Z from both parents
                    valid_combos.append((z_chrom, z_chrom))
                    if w_chrom:
                        # ZW (female) - W from maternal, Z from paternal
                        valid_combos.append((w_chrom, z_chrom))

        return valid_combos

    def add_chromosome(
        self,
        chrom_or_name: Union[Chromosome, str],
        loci: Optional[List[Locus]] = None,
        sex_type: Optional[Union[SexChromosomeType, str]] = None
    ) -> Chromosome:
        """
        Add a chromosome to this species.

        Args:
            chrom_or_name: Either a Chromosome instance or a name to create a new one.
            loci: Optional list of loci (only used when creating new Chromosome by name).
            sex_type: Optional sex chromosome type (X', 'Y', 'Z', 'W', None).

        Returns:
            The added Chromosome instance.
        """
        assert isinstance(chrom_or_name, (Chromosome, str)), \
            f"Expected Chromosome instance or str, got {type(chrom_or_name).__name__}"

        if isinstance(chrom_or_name, str):
            # Create new Chromosome via base class add method
            created = self.add(chrom_or_name, loci=loci, sex_type=sex_type)
            assert isinstance(created, Chromosome), \
                f"Expected add() to return Chromosome, got {type(created).__name__}"
            chrom = created
        else:
            chrom = chrom_or_name
            # Update sex_type if provided
            if sex_type is not None:
                chrom.sex_type = sex_type
            # Register existing Chromosome if not already in registry
            if chrom.name not in self.child_structures:
                self.child_structures.register(chrom)

        self.invalidate_gene_index_cache()
        return chrom

    # Alias for backward compatibility
    def add_linkage(
        self,
        linkage_or_name: Union[Chromosome, str],
        loci: Optional[List[Locus]] = None
    ) -> Chromosome:
        """Alias for add_chromosome (backward compatibility)."""
        return self.add_chromosome(linkage_or_name, loci=loci)

    def remove_chromosome(self, chrom_or_name: Union[Chromosome, str]) -> None:
        """
        Remove a chromosome from this species.

        Args:
            chrom_or_name: Either a Chromosome instance or a name.
        """
        if isinstance(chrom_or_name, str):
            name = chrom_or_name
        else:
            name = chrom_or_name.name

        if name in self.child_structures:
            self.child_structures.unregister(name)
            self._invalidate_gene_index_cache()

    # Alias for backward compatibility
    def remove_linkage(self, linkage_or_name: Union[Chromosome, str]) -> None:
        """Alias for remove_chromosome (backward compatibility)."""
        return self.remove_chromosome(linkage_or_name)

    def get_all_loci(self) -> List[Locus]:
        """Returns all loci across all chromosomes."""
        all_loci: List[Locus] = []
        for chrom in self.chromosomes:
            all_loci.extend(chrom.loci)
        return all_loci

    @classmethod
    def from_dict(
        cls,
        name: str,
        structure: Dict[str, Union[List[str], Dict[str, List[str]], Dict[str, Any]]],
        gamete_labels: Optional[List[str]] = None
    ) -> Species:
        """Create a Species with complete hierarchy from a dictionary specification.

        Args:
            name: Name of the species.
            structure: Dictionary defining the structure. Format:
                {
                    'ChromName': ['Locus1', 'Locus2', ...],  # Simple: locus names only
                    # OR
                    'ChromName': {
                        'Locus1': ['allele1', 'allele2'],  # With alleles
                        'Locus2': ['allele1', 'allele2'],
                    }
                    # OR
                    'ChromName': {
                        'sex_type': 'X',
                        'loci': {
                            'Locus1': ['allele1', 'allele2'],
                        },
                    }
                }

        Returns:
            Species instance with all Chromosomes and Loci created.

        Examples:
            >>> # Simple: just loci names
            >>> species = Species.from_dict('Species', {
            ...     'Chr1': ['LocusA', 'LocusB'],
            ...     'Chr2': ['LocusC']
            ... })
            >>>
            >>> # With alleles
            >>> species = Species.from_dict('Species', {
            ...     'Chr1': {
            ...         'LocusA': ['A1', 'A2'],
            ...         'LocusB': ['B1', 'B2', 'B3']
            ...     },
            ...     'Chr2': {
            ...         'LocusC': ['C1', 'C2']
            ...     }
            ... })
        """
        from natal.genetic_entities import Gene

        species = cls(name, gamete_labels=gamete_labels)

        for chrom_name, loci_spec in structure.items():
            sex_type: Optional[Union[SexChromosomeType, str]] = None
            normalized_loci_spec: Union[List[str], Dict[str, List[str]]]

            # Extended chromosome config format:
            # {
            #   "sex_type": "X" | "Y" | "Z" | "W" | "autosome",
            #   "loci": [...]/{...}
            # }
            if isinstance(loci_spec, dict) and ("loci" in loci_spec or "sex_type" in loci_spec):
                raw_loci = loci_spec.get("loci")
                if raw_loci is None:
                    raw_loci = []
                assert isinstance(raw_loci, (list, dict)), \
                    f"Invalid loci specification for chromosome '{chrom_name}'. " \
                    f"Expected list or dict, got {type(raw_loci).__name__}"
                normalized_loci_spec = cast(Union[List[str], Dict[str, List[str]]], raw_loci)

                raw_sex_type = loci_spec.get("sex_type")
                if raw_sex_type is not None:
                    assert isinstance(raw_sex_type, (SexChromosomeType, str)), \
                        f"Invalid sex_type for chromosome '{chrom_name}'. " \
                        f"Expected SexChromosomeType or str, got {type(raw_sex_type).__name__}"
                    sex_type = raw_sex_type
            else:
                assert isinstance(loci_spec, (list, dict)), \
                    f"Invalid loci specification for chromosome '{chrom_name}'. " \
                    f"Expected list or dict, got {type(loci_spec).__name__}"
                normalized_loci_spec = cast(Union[List[str], Dict[str, List[str]]], loci_spec)

            chrom = species.add_chromosome(chrom_name, sex_type=sex_type)

            if isinstance(normalized_loci_spec, list):
                # Simple format: list of locus names
                for locus_name in normalized_loci_spec:
                    chrom.add_locus(locus_name)
            else: # Detailed format: {locus_name: [allele_names]}
                for locus_name, allele_names in normalized_loci_spec.items():
                    locus = chrom.add_locus(locus_name)
                    # Create alleles (genes)
                    for allele_name in allele_names:
                        Gene(allele_name, locus=locus)

        return species

    def get_locus(self, name: str) -> Optional[Locus]:
        """
        Get a locus by name across all chromosomes.

        Args:
            name: Name of the locus.

        Returns:
            The Locus instance or None if not found.
        """
        for chrom in self.chromosomes:
            for locus in chrom.loci:
                if locus.name == name:
                    return locus
        return None

    def get_chromosome(self, name: str) -> Optional[Chromosome]:
        """
        Get a chromosome by name.

        Args:
            name: Name of the chromosome.

        Returns:
            The Chromosome instance or None if not found.
        """
        if name in self.child_structures:
            return self.child_structures.get(name)
        return None

    # Alias for backward compatibility
    def get_linkage(self, name: str) -> Optional[Chromosome]:
        """Alias for get_chromosome (backward compatibility)."""
        return self.get_chromosome(name)

    def _build_gene_index(self) -> Dict[str, Gene]:
        """
        Build a lookup index from gene name to Gene object.

        Returns:
            Dict mapping gene name to Gene instance.

        Raises:
            ValueError: If duplicate gene names exist in the species.
        """
        if self._gene_index_cache is not None:
            return self._gene_index_cache

        gene_index: Dict[str, Gene] = {}
        for chrom in self.chromosomes:
            for locus in chrom.loci:
                for gene in locus.alleles:
                    if gene.name in gene_index:
                        raise ValueError(
                            f"Duplicate gene name '{gene.name}' found in species. "
                            f"Gene names must be unique for string-based lookups. "
                            f"Found at locus '{gene.locus.name}' and '{gene_index[gene.name].locus.name}'."
                        )
                    gene_index[gene.name] = gene
        self._gene_index_cache = gene_index
        return gene_index

    def _parse_haplotype_segment_str(
        self,
        hap_str: str,
        gene_index: Dict[str, Gene]
    ) -> Tuple[Chromosome, List[Gene]]:
        """
        Parse a haplotype segment string into (Chromosome, [Genes]).

        Args:
            hap_str: String like "ABC" or "a1/b1/c1" or "Allele1"
            gene_index: Gene name to Gene lookup

        Returns:
            Tuple of (Chromosome, list of Genes)
        """
        hap_str = hap_str.strip()
        if not hap_str:
            raise ValueError("Empty haplotype segment string")

        # Parse gene names using intelligent detection:
        # 1. If contains '/', split by it
        # 2. If entire string is a valid gene name, treat as single gene
        # 3. Otherwise, try single characters
        if '/' in hap_str:
            gene_names = [g.strip() for g in hap_str.split('/')]
        elif hap_str in gene_index:
            # Entire string is a single gene name
            gene_names = [hap_str]
        else:
            # Try single characters first
            gene_names = list(hap_str)
            # Verify all chars are valid genes
            if not all(c in gene_index for c in gene_names):
                raise ValueError(
                    f"Cannot parse haplotype segment string '{hap_str}'. "
                    f"Use '/' to separate multi-character gene names. "
                    f"Available genes: {list(gene_index.keys())}"
                )

        # Lookup genes
        genes: List[Gene] = []
        for gname in gene_names:
            if gname not in gene_index:
                raise ValueError(
                    f"Gene '{gname}' not found in species '{self.name}'. "
                    f"Available genes: {list(gene_index.keys())}"
                )
            genes.append(gene_index[gname])

        # Resolve chromosome by intersecting all candidate chromosomes of each gene locus.
        locus_to_chroms: Dict[Locus, List[Chromosome]] = {}
        for chrom in self.chromosomes:
            for locus in chrom.loci:
                locus_to_chroms.setdefault(locus, []).append(chrom)

        candidate_chroms: Optional[Set[Chromosome]] = None
        for gene in genes:
            chroms_for_locus = locus_to_chroms.get(gene.locus, [])
            if not chroms_for_locus:
                raise ValueError(
                    f"Gene '{gene.name}' at locus '{gene.locus.name}' is not assigned to any chromosome "
                    f"in species '{self.name}'."
                )
            if candidate_chroms is None:
                candidate_chroms = set(chroms_for_locus)
            else:
                candidate_chroms.intersection_update(chroms_for_locus)

            if not candidate_chroms:
                raise ValueError(
                    f"No common chromosome found for genes {[g.name for g in genes]} in species '{self.name}'."
                )

        if candidate_chroms is None or len(candidate_chroms) == 0:
            raise ValueError(f"No chromosome candidates found for genes {[g.name for g in genes]}.")
        if len(candidate_chroms) > 1:
            chrom_names = [c.name for c in self.chromosomes if c in candidate_chroms]
            raise ValueError(
                f"Multiple chromosomes match genes {[g.name for g in genes]} in species '{self.name}': {chrom_names}. "
                f"Please ensure gene names are unique across chromosomes."
            )

        chrom = next(chr for chr in self.chromosomes if chr in candidate_chroms)

        # Verify we have one gene per locus in this chromosome
        loci_with_genes = {gene.locus for gene in genes}
        expected_loci = set(chrom.loci)

        if loci_with_genes != expected_loci:
            missing = expected_loci - loci_with_genes
            if missing:
                raise ValueError(
                    f"Missing genes for loci: {[loc.name for loc in missing]} in chromosome '{chrom.name}'"
                )

        # Sort genes by locus order in chromosome
        locus_order = {locus: i for i, locus in enumerate(chrom.loci)}
        genes_sorted = sorted(genes, key=lambda g: locus_order[g.locus])

        return chrom, genes_sorted

    def get_haploid_genome_from_str(self, haploid_str: str) -> HaploidGenome:
        """
        Create or retrieve a HaploidGenome from a string representation.

        Supported syntax includes:
            - Semicolon (;) separates different chromosomes
            - Slash (/) separates genes within a chromosome
            - If all genes are single characters, slash can be omitted

        Args:
            haploid_str: String like "ABC;XY" or "a1/b1/c1;x1/y1"

        Returns:
            HaploidGenome instance

        Examples:
            >>> species = Species.from_dict("Test", {
            ...     "Chr1": {"A": ["A", "a"], "B": ["B", "b"], "C": ["C", "c"]},
            ...     "Chr2": {"X": ["X", "x"], "Y": ["Y", "y"]}
            ... })
            >>> hap = species.get_haploid_genome_from_str("ABC;XY")
            >>> hap = species.get_haploid_genome_from_str("a/b/c;x/y")  # equivalent
        """
        from natal.genetic_entities import HaploidGenome, Haplotype

        gene_index = self._build_gene_index()

        # Split by semicolon for different chromosomes
        hap_strs = [s.strip() for s in haploid_str.split(';') if s.strip()]

        # Allow sex chromosome groups: exactly one chromosome per group is required
        sex_chr_groups = getattr(self, '_sex_chromosome_groups', None)
        if sex_chr_groups:
            # Expected segments = autosomes count + number of sex groups
            autosome_count = 0
            for chrom in self.chromosomes:
                # A chromosome is considered part of a sex group if it appears in any group list
                in_sex_group = any(chrom in group for group in sex_chr_groups.values())
                if not in_sex_group:
                    autosome_count += 1
            expected_segments = autosome_count + len(sex_chr_groups)
        else:
            expected_segments = len(self.chromosomes)

        if len(hap_strs) != expected_segments:
            raise ValueError(
                f"Expected {expected_segments} haplotype segments (one per chromosome; "
                f"for sex groups: one per group), got {len(hap_strs)}. "
                f"Chromosomes: {[c.name for c in self.chromosomes]}"
            )

        # Parse each haplotype segment
        haplotypes: List[Haplotype] = []
        chroms_used: Set[Chromosome] = set()

        for hap_str in hap_strs:
            chrom, genes = self._parse_haplotype_segment_str(hap_str, gene_index)

            if chrom in chroms_used:
                raise ValueError(
                    f"Chromosome '{chrom.name}' appears multiple times in haploid genome string"
                )
            chroms_used.add(chrom)

            hap = Haplotype(chromosome=chrom, genes=genes)
            haplotypes.append(hap)

        # Sort haplotypes by chromosome order in species
        chrom_order = {chrom: i for i, chrom in enumerate(self.chromosomes)}
        haplotypes_sorted = sorted(haplotypes, key=lambda h: chrom_order[h.chromosome])

        return HaploidGenome(species=self, haplotypes=haplotypes_sorted)

    def get_haploid_genotype_from_str(self, haplotype_str: str) -> HaploidGenome:
        """Alias for get_haploid_genome_from_str."""
        return self.get_haploid_genome_from_str(haplotype_str)

    def get_genotype_from_str(self, genotype_str: str) -> Genotype:
        """
        Create or retrieve a Genotype from a string representation.

        Supported syntax includes:
            - Pipe (|) separates maternal (left) and paternal (right) haploid genomes
            - Semicolon (;) separates different chromosomes
            - Slash (/) separates genes within a chromosome
            - If all genes are single characters, slash can be omitted

        The order of chromosomes in the string does not need to match
        the internal chromosome order - matching is done by gene names.

        Args:
            genotype_str: String like "ABC|abc" or "a1/b1/c1|a2/b2/c2;X/Y|x/y"

        Returns:
            Genotype instance

        Examples:
            >>> species = Species.from_dict("Test", {
            ...     "Chr1": {"A": ["A", "a"], "B": ["B", "b"], "C": ["C", "c"]},
            ...     "Chr2": {"X": ["X", "x"], "Y": ["Y", "y"]}
            ... })
            >>>
            >>> # Simple single-char genes
            >>> gt = species.get_genotype_from_str("ABC|abc;XY|xy")
            >>>
            >>> # Multi-char genes with slash separator
            >>> gt = species.get_genotype_from_str("A1/B1/C1|A2/B2/C2;X1/Y1|X2/Y2")
            >>>
            >>> # Order doesn't matter (unordered matching)
            >>> gt = species.get_genotype_from_str("XY|xy;ABC|abc")  # Same result
        """
        from natal.genetic_entities import Genotype

        genotype_str = genotype_str.strip()

        # Split by semicolon first (different chromosomes)
        chrom_segments = [s.strip() for s in genotype_str.split(';') if s.strip()]

        # Allow sex chromosome groups: exactly one chromosome per group is required
        sex_chr_groups = getattr(self, '_sex_chromosome_groups', None)
        if sex_chr_groups:
            autosome_count = 0
            for chrom in self.chromosomes:
                in_sex_group = any(chrom in group for group in sex_chr_groups.values())
                if not in_sex_group:
                    autosome_count += 1
            expected_segments = autosome_count + len(sex_chr_groups)
        else:
            expected_segments = len(self.chromosomes)

        if len(chrom_segments) != expected_segments:
            raise ValueError(
                f"Expected {expected_segments} chromosome segments (separated by ;, and one per sex group when defined), "
                f"got {len(chrom_segments)}. Chromosomes: {[c.name for c in self.chromosomes]}"
            )

        # For each chromosome segment, split by | to get maternal/paternal
        maternal_hap_strs: List[str] = []
        paternal_hap_strs: List[str] = []

        for segment in chrom_segments:
            parts = segment.split('|')
            if len(parts) != 2:
                raise ValueError(
                    f"Each chromosome segment must have exactly 2 parts separated by '|'. "
                    f"Got: '{segment}'"
                )
            maternal_hap_strs.append(parts[0].strip())
            paternal_hap_strs.append(parts[1].strip())

        # Build haploid genome strings and parse
        maternal_str = ';'.join(maternal_hap_strs)
        paternal_str = ';'.join(paternal_hap_strs)

        maternal = self.get_haploid_genome_from_str(maternal_str)
        paternal = self.get_haploid_genome_from_str(paternal_str)

        return Genotype(species=self, maternal=maternal, paternal=paternal)

    # ========================================================================
    # GENOTYPE PATTERN MATCHING
    # ========================================================================

    def _resolve_single_genotype_selector(
        self,
        selector: Union[Genotype, str],
        all_genotypes: Optional[Iterable[Genotype]] = None,
        context: str = 'selector'
    ) -> List[Genotype]:
        """Resolve a single genotype selector atom.

        Supported forms include:
            - Genotype object: exact match
            - String exact genotype syntax
            - String genotype pattern syntax
        """
        from natal.genetic_entities import Genotype

        assert isinstance(selector, (Genotype, str)), \
            f"{context} selector must be Genotype or str, got {type(selector).__name__}"

        if all_genotypes is None:
            all_genotypes = self.get_all_genotypes()

        if isinstance(selector, Genotype):
            return [selector]

        # Keep backward compatibility: exact parser first, pattern parser fallback.
        try:
            return [self.get_genotype_from_str(selector)]
        except Exception as exact_err:
            try:
                pattern_filter = self.parse_genotype_pattern(selector)
            except Exception as pattern_err:
                raise ValueError(
                    f"Invalid {context} selector '{selector}'. "
                    f"Not an exact genotype string and not a valid genotype pattern. "
                    f"exact_error={exact_err}; pattern_error={pattern_err}"
                ) from pattern_err

        matched = [gt for gt in all_genotypes if pattern_filter(gt)]
        if not matched:
            raise ValueError(
                f"{context} pattern '{selector}' matched no genotypes in species '{self.name}'."
            )
        return matched

    def resolve_genotype_selectors(
        self,
        selector: Union[Genotype, str, Tuple[Union[Genotype, str], ...]],
        all_genotypes: Optional[Iterable[Genotype]] = None,
        context: str = 'selector'
    ) -> List[Genotype]:
        """Resolve one or more genotype selectors into concrete ``Genotype`` objects.

        Args:
            selector: Selector expression to resolve. Supported forms:
                - ``Genotype``: treated as an exact selector.
                - ``str``: resolved with exact-genotype parsing first; if exact
                  parsing fails, falls back to genotype-pattern parsing.
                - ``tuple`` of ``Genotype``/``str``: union semantics. Each atom
                  is resolved independently, then merged with de-duplication
                  while preserving first-seen order.
            all_genotypes: Optional candidate genotype iterable used by pattern
                matching. If ``None``, all genotypes of the species are used.
            context: Human-readable context label used in error messages (for
                example ``"viability"`` or ``"sexual_selection"``).

        Returns:
            A list of resolved ``Genotype`` objects.

            - For a single selector atom, returns all matches from that atom.
            - For tuple selectors, returns the de-duplicated union of all atom matches.

        Raises:
            TypeError: If a selector atom is neither ``Genotype`` nor ``str``.
            ValueError: If the selector is invalid, if pattern parsing fails, if
                a pattern matches no genotypes, or if a tuple selector is empty.
        """
        if all_genotypes is None:
            all_genotypes = self.get_all_genotypes()

        if isinstance(selector, tuple):
            if len(selector) == 0:
                raise ValueError(f"{context} selector tuple cannot be empty")

            merged: List[Genotype] = []
            for atom in selector:
                matches = self._resolve_single_genotype_selector(
                    selector=atom,
                    all_genotypes=all_genotypes,
                    context=context,
                )
                for gt in matches:
                    if gt not in merged:
                        merged.append(gt)
            return merged

        return self._resolve_single_genotype_selector(
            selector=selector,
            all_genotypes=all_genotypes,
            context=context,
        )

    def parse_genotype_pattern(self, pattern: str) -> Callable[[Genotype], bool]:
        """
        Parse a genotype pattern string and return a filter function.

        Supports regex-like syntax for flexible pattern matching:
            - ; separates chromosomes
            - | separates maternal (left) and paternal (right)
            - / separates loci within a chromosome
            - * matches any allele
            - {A,B,C} matches any allele in the set
            - !A matches any allele except A
            - :: matches unordered pair (A::B matches A|B or B|A)
            - () explicitly groups chromosome loci
            - Omitted chromosomes default to wildcard matching

        Args:
            pattern: Pattern string, e.g. "A1/B1|A2/B2; C1/C2"

        Returns:
            A filter function that takes a Genotype and returns bool.

        Examples:
            >>> filter_func = species.parse_genotype_pattern("A1/B1|A2/B2; C1::*")
            >>> genotypes = [gt for gt in pop.genotypes if filter_func(gt)]

        Raises:
            PatternParseError: If the pattern is invalid.
        """
        from natal.genetic_patterns import GenotypePatternParser
        parser = GenotypePatternParser(self)
        pattern_obj = parser.parse(pattern)
        return pattern_obj.to_filter()

    def filter_genotypes_by_pattern(
        self,
        genotypes: Iterable[Genotype],
        pattern: str
    ) -> List[Genotype]:
        """
        Filter a collection of genotypes by a pattern string.

        Args:
            genotypes: Iterable of Genotype objects to filter.
            pattern: Pattern string (see parse_genotype_pattern for syntax).

        Returns:
            List of genotypes that match the pattern.

        Examples:
            >>> matched = species.filter_genotypes_by_pattern(pop.genotypes, "A1/*|A2/B2")
        """
        pattern_filter = self.parse_genotype_pattern(pattern)
        return [gt for gt in genotypes if pattern_filter(gt)]

    def enumerate_genotypes_matching_pattern(
        self,
        pattern: str,
        max_count: Optional[int] = None
    ) -> Iterable[Genotype]:
        """
        Enumerate all genotypes matching a pattern.

        Yields all possible genotype combinations that satisfy the pattern.
        Uses the pattern's built-in matching logic to filter candidates,
        avoiding complex combination generation.

        Args:
            pattern: Pattern string (see parse_genotype_pattern for syntax).
            max_count: Maximum number of genotypes to yield (prevents explosion).
                      If None, yields all possible genotypes.

        Yields:
            Genotype objects matching the pattern.

        Examples:
            >>> for gt in species.enumerate_genotypes_matching_pattern("A1/*|A2/*; C1/C1"):
            ...     print(gt)

        Raises:
            PatternParseError: If the pattern is invalid.
        """
        from natal.genetic_patterns import GenotypePatternParser

        parser = GenotypePatternParser(self)
        pattern_obj = parser.parse(pattern)

        count = 0
        for genotype in self.iter_genotypes():
            if pattern_obj.matches(genotype):
                if max_count is not None and count >= max_count:
                    return
                yield genotype
                count += 1

    # ========================================================================
    # HAPLOIDGENOME PATTERN MATCHING
    # ========================================================================

    def parse_haploid_genome_pattern(self, pattern: str) -> Callable[[HaploidGenome], bool]:
        """
        Parse a haploid genome pattern string and return a filter function.

        Supports regex-like syntax for flexible pattern matching of haploid genomes.
        A HaploidGenome represents one complete DNA strand (all haplotypes).
        Uses same syntax as Genotype patterns but applies to single haplotypes:
            - ; separates chromosomes
            - / separates loci within a chromosome
            - * matches any allele
            - {A,B,C} matches any allele in the set
            - !A matches any allele except A
            - () explicitly groups chromosome loci
            - Omitted chromosomes default to wildcard matching

        Args:
            pattern: Pattern string, e.g. "A1/B1; C1/C2"

        Returns:
            A filter function that takes a HaploidGenome and returns bool.

        Examples:
            >>> filter_func = species.parse_haploid_genome_pattern("A1/B1; C1")
            >>> haploid_genomes = [hg for hg in pop.haploid_genomes if filter_func(hg)]

        Raises:
            PatternParseError: If the pattern is invalid.
        """
        from natal.genetic_patterns import GenotypePatternParser
        parser = GenotypePatternParser(self)
        pattern_obj = parser.parse_haploid_genome_pattern(pattern)
        return pattern_obj.to_filter()

    def filter_haploid_genomes_by_pattern(
        self,
        haploid_genomes: Iterable[HaploidGenome],
        pattern: str
    ) -> List[HaploidGenome]:
        """
        Filter a collection of haploid genomes by a pattern string.

        Args:
            haploid_genomes: Iterable of HaploidGenome objects to filter.
            pattern: Pattern string (see parse_haploid_genome_pattern for syntax).

        Returns:
            List of haploid genomes that match the pattern.

        Examples:
            >>> matched = species.filter_haploid_genomes_by_pattern(pop.haploid_genomes, "A1/*; C1")
        """
        pattern_filter = self.parse_haploid_genome_pattern(pattern)
        return [hg for hg in haploid_genomes if pattern_filter(hg)]

    def enumerate_haploid_genomes_matching_pattern(
        self,
        pattern: str,
        max_count: Optional[int] = None
    ) -> Iterable[HaploidGenome]:
        """
        Enumerate all haploid genomes matching a pattern.

        Yields all possible haploid genome combinations that satisfy the pattern.
        Uses the pattern's built-in matching logic to filter candidates,
        avoiding complex combination generation.

        Args:
            pattern: Pattern string (see parse_haploid_genome_pattern for syntax).
            max_count: Maximum number of haploid genomes to yield (prevents explosion).
                      If None, yields all possible haploid genomes.

        Yields:
            HaploidGenome objects matching the pattern.

        Examples:
            >>> for hg in species.enumerate_haploid_genomes_matching_pattern("A1/*; C1"):
            ...     print(hg)

        Raises:
            PatternParseError: If the pattern is invalid.
        """
        from natal.genetic_patterns import GenotypePatternParser

        parser = GenotypePatternParser(self)
        pattern_obj = parser.parse_haploid_genome_pattern(pattern)

        count = 0
        for haploid_genome in self.iter_haploid_genotypes():
            if pattern_obj.matches(haploid_genome):
                if max_count is not None and count >= max_count:
                    return
                yield haploid_genome
                count += 1

    def __repr__(self):
        chrom_strs: List[str] = []
        for chrom in self.chromosomes:
            loci_names = [locus.name for locus in chrom.loci]
            chrom_strs.append(f"'{chrom.name}': {loci_names}")
        return f"Species({self.name!r}, {{{', '.join(chrom_strs)}}})"

    def __iter__(self):
        return iter(self.chromosomes)

    def __len__(self):
        return len(self.chromosomes)

    # ========================================================================
    # Genotype enumeration and counting
    # ========================================================================

    def _get_sex_chromosome_groups(self) -> Optional[Dict[str, List[Chromosome]]]:
        """
        Get sex chromosome group configuration.

        Prefer explicit ``_sex_chromosome_groups`` when provided;
        otherwise infer groups from ``Chromosome.sex_type``.

        Returns:
            Sex chromosome group mapping, or ``None`` when absent.
        """
        # Prefer explicit user-defined configuration first.
        if hasattr(self, '_sex_chromosome_groups') and self._sex_chromosome_groups:
            return self._sex_chromosome_groups

        # Fall back to automatic inference from chromosome metadata.
        groups = self._build_sex_chromosome_groups()
        return groups if groups else None

    def get_sex_chromosome_groups(self) -> Optional[Dict[str, List[Chromosome]]]:
        """Public accessor for sex chromosome group configuration."""
        return self._get_sex_chromosome_groups()

    def _get_valid_sex_genotypes(self) -> Optional[List[Tuple[Chromosome, Chromosome]]]:
        """
        Get valid sex chromosome genotype combinations.

        Prefer explicit ``_valid_sex_genotypes`` when provided;
        otherwise infer combinations from ``Chromosome.sex_type``.

        Returns:
            A list of valid ``(maternal_chrom, paternal_chrom)`` pairs, or ``None``.
        """
        # Prefer explicit user-defined configuration first.
        if hasattr(self, '_valid_sex_genotypes') and self._valid_sex_genotypes:
            return self._valid_sex_genotypes

        # Fall back to automatic inference from chromosome metadata.
        valid = self._build_valid_sex_genotypes()
        return valid if valid else None

    def count_alleles(self) -> int:
        """
        Count the total number of alleles across all loci.

        Returns:
            Total allele count.
        """
        total = 0
        for chrom in self.chromosomes:
            for locus in chrom.loci:
                total += len(locus.alleles)
        return total

    def count_haploid_genotypes(self) -> int:
        """
        Calculate the total number of possible haploid genomes.

        For each locus with n alleles, the haploid genome count = product of allele counts at each locus.
        If sex chromosome groups exist, only one chromosome is selected per group.

        Returns:
            Total number of possible haploid genomes
        """
        # Resolve sex chromosome grouping (explicit config first, otherwise inferred).
        sex_chr_groups = self._get_sex_chromosome_groups()

        # Collect all chromosomes that belong to any sex chromosome group.
        sex_chroms: Set[Chromosome] = set()
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                sex_chroms.update(group_chroms)

        total = 1

        # Multiply allele counts across autosomal loci.
        for chrom in self.chromosomes:
            if chrom in sex_chroms:
                continue  # Handle sex chromosomes separately below.
            for locus in chrom.loci:
                n_alleles = len(locus.alleles)
                if n_alleles > 0:
                    total *= n_alleles

        # For each sex chromosome group, select one chromosome from the group.
        # A chromosome's haplotype count is the product of allele counts at its loci.
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                group_total = 0
                for chrom in group_chroms:
                    chrom_total = 1
                    for locus in chrom.loci:
                        n_alleles = len(locus.alleles)
                        if n_alleles > 0:
                            chrom_total *= n_alleles
                    group_total += chrom_total
                total *= group_total

        return total

    def count_genotypes(self) -> int:
        """
        Calculate the total number of possible diploid genotypes.

        If _valid_sex_genotypes is defined, only valid sex chromosome combinations are counted.

        Sex chromosome system configuration:
        - Can be automatically inferred by setting Chromosome.sex_type
        - Can also be manually set via _sex_chromosome_groups and _valid_sex_genotypes

        Returns:
            Total number of possible genotypes
        """
        # Resolve sex-system config (explicit settings first, otherwise inferred).
        sex_chr_groups = self._get_sex_chromosome_groups()
        valid_sex_gts = self._get_valid_sex_genotypes()

        if not sex_chr_groups:
            # No sex chromosomes: diploid count is haploid_count^2.
            n_haploid = self.count_haploid_genotypes()
            return n_haploid * n_haploid

        # With sex chromosomes, count autosomal and sex-system parts separately.
        sex_chroms: Set[Chromosome] = set()
        for group_chroms in sex_chr_groups.values():
            sex_chroms.update(group_chroms)

        autosome_haploid_count = 1
        for chrom in self.chromosomes:
            if chrom in sex_chroms:
                continue
            for locus in chrom.loci:
                n_alleles = len(locus.alleles)
                if n_alleles > 0:
                    autosome_haploid_count *= n_alleles

        # Autosomal diploid count = autosomal_haploid_count^2.
        autosome_genotype_count = autosome_haploid_count * autosome_haploid_count

        # Count haplotypes produced by a single chromosome.
        def count_chrom_haplotypes(chrom: Chromosome) -> int:
            count = 1
            for locus in chrom.loci:
                n_alleles = len(locus.alleles)
                if n_alleles > 0:
                    count *= n_alleles
            return count

        # Count sex chromosome genotype combinations.
        if valid_sex_gts:
            # Use explicitly defined valid combinations.
            sex_genotype_count = 0
            for mat_chrom, pat_chrom in valid_sex_gts:
                n_mat = count_chrom_haplotypes(mat_chrom)
                n_pat = count_chrom_haplotypes(pat_chrom)
                sex_genotype_count += n_mat * n_pat
        else:
            # If not constrained, all maternal/paternal pairings are treated as valid.
            sex_genotype_count = 1
            for group_chroms in sex_chr_groups.values():
                group_total = 0
                for chrom in group_chroms:
                    group_total += count_chrom_haplotypes(chrom)
                # Each group contributes maternal x paternal pairings.
                sex_genotype_count *= group_total * group_total

        return autosome_genotype_count * sex_genotype_count

    def iter_haploid_genotypes(self) -> Iterable[HaploidGenome]:
        """
        Iterate over all possible haploid genomes (HaploidGenome).

        If sex chromosome groups exist, only one chromosome is selected per group.
        Note: This method returns all possible haploid genotypes without distinguishing
        between maternal/paternal. For scenarios requiring distinction, use
        iter_maternal_haploid_genotypes() and iter_paternal_haploid_genotypes().

        Yields:
            HaploidGenome instances

        Examples:
            >>> for hg in species.iter_haploid_genotypes():
            ...     print(hg)
        """
        from natal.genetic_entities import HaploidGenome, Haplotype

        sex_chr_groups = self._get_sex_chromosome_groups()

        # Collect all chromosomes that belong to any sex chromosome group.
        sex_chroms: Set[Chromosome] = set()
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                sex_chroms.update(group_chroms)

        # Collect all possible haplotypes for autosomes.
        autosome_haplotypes: List[List[Haplotype]] = []
        for chrom in self.chromosomes:
            if chrom in sex_chroms:
                continue  # Handle sex chromosomes separately.

            locus_alleles = [list(locus.alleles) for locus in chrom.loci]
            if not locus_alleles or any(len(a) == 0 for a in locus_alleles):
                continue

            haps_for_chrom: List[Haplotype] = []
            for genes in itertools.product(*locus_alleles):
                hap = Haplotype(chromosome=chrom, genes=list(genes))
                haps_for_chrom.append(hap)
            autosome_haplotypes.append(haps_for_chrom)

        # Collect haplotype options for each sex chromosome group.
        # A group contains all haplotypes from all chromosomes in that group.
        sex_group_haplotypes: List[List[Haplotype]] = []
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                group_haps: List[Haplotype] = []
                for chrom in group_chroms:
                    locus_alleles = [list(locus.alleles) for locus in chrom.loci]
                    if not locus_alleles or any(len(a) == 0 for a in locus_alleles):
                        continue
                    for genes in itertools.product(*locus_alleles):
                        hap = Haplotype(chromosome=chrom, genes=list(genes))
                        group_haps.append(hap)
                if group_haps:
                    sex_group_haplotypes.append(group_haps)

        # Combine autosomal and sex-group haplotype option lists.
        all_haplotype_options = autosome_haplotypes + sex_group_haplotypes

        if not all_haplotype_options:
            return

        # Convert Cartesian product combinations into HaploidGenome objects.
        for haplotype_combo in itertools.product(*all_haplotype_options):
            yield HaploidGenome(species=self, haplotypes=list(haplotype_combo))

    def _iter_haploid_genotypes_for_parent(
        self,
        is_paternal: bool
    ) -> Iterable[HaploidGenome]:
        """
        Iterate haploid genomes available to one parent role.

        Availability of sex chromosomes is constrained by
        ``_valid_sex_genotypes`` when provided.

        Args:
            is_paternal: ``True`` for paternal, ``False`` for maternal.

        Yields:
            HaploidGenome instances.
        """
        from natal.genetic_entities import HaploidGenome, Haplotype

        sex_chr_groups = self._get_sex_chromosome_groups()
        valid_sex_gts = self._get_valid_sex_genotypes()

        # Collect all chromosomes that belong to any sex chromosome group.
        sex_chroms: Set[Chromosome] = set()
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                sex_chroms.update(group_chroms)

        # Determine sex chromosomes available to this parent role.
        available_sex_chroms: Set[Chromosome] = set()
        if sex_chr_groups:
            if valid_sex_gts:
                # Extract allowed chromosome side from each valid pair.
                for mat_chrom, pat_chrom in valid_sex_gts:
                    if is_paternal:
                        available_sex_chroms.add(pat_chrom)
                    else:
                        available_sex_chroms.add(mat_chrom)
            else:
                # No explicit constraint means all sex chromosomes are available.
                available_sex_chroms = sex_chroms

        # Collect all possible haplotypes for autosomes.
        autosome_haplotypes: List[List[Haplotype]] = []
        for chrom in self.chromosomes:
            if chrom in sex_chroms:
                continue

            locus_alleles = [list(locus.alleles) for locus in chrom.loci]
            if not locus_alleles or any(len(a) == 0 for a in locus_alleles):
                continue

            haps_for_chrom: List[Haplotype] = []
            for genes in itertools.product(*locus_alleles):
                hap = Haplotype(chromosome=chrom, genes=list(genes))
                haps_for_chrom.append(hap)
            autosome_haplotypes.append(haps_for_chrom)

        # Collect haplotype options for each sex chromosome group.
        sex_group_haplotypes: List[List[Haplotype]] = []
        if sex_chr_groups:
            for group_chroms in sex_chr_groups.values():
                group_haps: List[Haplotype] = []
                for chrom in group_chroms:
                    # Include only chromosomes available to this parent role.
                    if chrom not in available_sex_chroms:
                        continue

                    locus_alleles = [list(locus.alleles) for locus in chrom.loci]
                    if not locus_alleles or any(len(a) == 0 for a in locus_alleles):
                        continue
                    for genes in itertools.product(*locus_alleles):
                        hap = Haplotype(chromosome=chrom, genes=list(genes))
                        group_haps.append(hap)
                if group_haps:
                    sex_group_haplotypes.append(group_haps)

        # Combine autosomal and sex-group haplotype option lists.
        all_haplotype_options = autosome_haplotypes + sex_group_haplotypes

        if not all_haplotype_options:
            return

        # Convert Cartesian product combinations into HaploidGenome objects.
        for haplotype_combo in itertools.product(*all_haplotype_options):
            yield HaploidGenome(species=self, haplotypes=list(haplotype_combo))

    def iter_maternal_haploid_genotypes(self) -> Iterable[HaploidGenome]:
        """
        Iterate maternal haploid genomes that can be transmitted.

        Yields:
            HaploidGenome instances.
        """
        return self._iter_haploid_genotypes_for_parent(is_paternal=False)

    def iter_paternal_haploid_genotypes(self) -> Iterable[HaploidGenome]:
        """
        Iterate paternal haploid genomes that can be transmitted.

        Yields:
            HaploidGenome instances.
        """
        return self._iter_haploid_genotypes_for_parent(is_paternal=True)

    def iter_genotypes(self) -> Iterable[Genotype]:
        """
        Iterate all possible diploid genotypes.

        Maternal and paternal sides are ordered, so ``(A|B)`` and ``(B|A)``
        are distinct genotypes. When ``_valid_sex_genotypes`` or
        ``Chromosome.sex_type`` constraints are present, only valid sex
        chromosome pairings are emitted.

        Yields:
            Genotype instances.

        Examples:
            >>> for gt in species.iter_genotypes():
            ...     print(gt)
        """
        from natal.genetic_entities import Genotype

        sex_chr_groups = self._get_sex_chromosome_groups()
        valid_sex_gts = self._get_valid_sex_genotypes()

        if not sex_chr_groups:
            # No sex chromosomes: simple Cartesian product.
            all_haploid_genotypes = list(self.iter_haploid_genotypes())
            for maternal, paternal in itertools.product(all_haploid_genotypes, repeat=2):
                yield Genotype(species=self, maternal=maternal, paternal=paternal)
        elif valid_sex_gts:
            # Validate pairings against the explicitly valid chromosome pairs.
            maternal_hgs = list(self.iter_maternal_haploid_genotypes())
            paternal_hgs = list(self.iter_paternal_haploid_genotypes())

            # Build a set for fast valid-pair lookup.
            valid_chrom_pairs: Set[Tuple[Chromosome, Chromosome]] = set(valid_sex_gts)

            for maternal, paternal in itertools.product(maternal_hgs, paternal_hgs):
                # Resolve selected maternal and paternal sex chromosomes.
                mat_sex_chrom = self._get_sex_chromosome(maternal, sex_chr_groups)
                pat_sex_chrom = self._get_sex_chromosome(paternal, sex_chr_groups)

                # Keep only valid pairings.
                if (mat_sex_chrom, pat_sex_chrom) in valid_chrom_pairs:
                    yield Genotype(species=self, maternal=maternal, paternal=paternal)
        else:
            # With no explicit constraints, all pairings are valid.
            maternal_hgs = list(self.iter_maternal_haploid_genotypes())
            paternal_hgs = list(self.iter_paternal_haploid_genotypes())

            for maternal, paternal in itertools.product(maternal_hgs, paternal_hgs):
                yield Genotype(species=self, maternal=maternal, paternal=paternal)

    def _get_sex_chromosome(
        self,
        haploid_genome: HaploidGenome,
        sex_chr_groups: Dict[str, List[Chromosome]]
    ) -> Optional[Chromosome]:
        """
        Get the selected sex chromosome from a haploid genome.

        Assumes each sex chromosome group contributes at most one chromosome.

        Args:
            haploid_genome: Haploid genome to inspect.
            sex_chr_groups: Sex chromosome group definitions.

        Returns:
            The selected sex chromosome, or ``None`` when absent.
        """
        sex_chroms: Set[Chromosome] = set()
        for group_chroms in sex_chr_groups.values():
            sex_chroms.update(group_chroms)

        for hap in haploid_genome.haplotypes:
            if hap.chromosome in sex_chroms:
                return hap.chromosome
        return None

    def get_all_haploid_genotypes(self) -> List[HaploidGenome]:
        """
        Get a list of all possible haploid genomes.

        Returns:
            List of all HaploidGenome instances.
        """
        return list(self.iter_haploid_genotypes())

    def get_maternal_haploid_genotypes(self) -> List[HaploidGenome]:
        """Get all maternal-transmissible haploid genomes.

        Returns:
            List of maternal haploid genomes.
        """
        return list(self.iter_maternal_haploid_genotypes())

    def get_paternal_haploid_genotypes(self) -> List[HaploidGenome]:
        """Get all paternal-transmissible haploid genomes.

        Returns:
            List of paternal haploid genomes.
        """
        return list(self.iter_paternal_haploid_genotypes())

    def get_haploid_genotypes(
        self,
        parent: Optional[Literal["maternal", "paternal"]] = None,
    ) -> List[HaploidGenome]:
        """Get haploid genomes, optionally constrained by parent role.

        Args:
            parent: Parent role constraint. Accepted values are ``"maternal"``
                and ``"paternal"``. If omitted/None, return all haploid genomes.

        Returns:
            List of haploid genomes for the requested scope.

        Raises:
            ValueError: If ``parent`` is not one of supported values.
        """
        if parent is None:
            return self.get_all_haploid_genotypes()

        normalized = parent.strip().lower()
        if normalized == "maternal":
            return self.get_maternal_haploid_genotypes()
        if normalized == "paternal":
            return self.get_paternal_haploid_genotypes()
        raise ValueError(
            f"Unknown parent role: {parent!r}. Expected 'maternal', 'paternal', or None."
        )

    def get_all_genotypes(self) -> List[Genotype]:
        """
        Get a list of all possible diploid genotypes.

        Returns:
            List of all Genotype instances.
        """
        return list(self.iter_genotypes())


# Aliases for backward compatibility
Linkage = Chromosome
GenomeTemplate = Species
Karyotype = Species
