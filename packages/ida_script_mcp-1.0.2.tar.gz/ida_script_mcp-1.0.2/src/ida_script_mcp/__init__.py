"""IDA Script MCP - Package initialization."""

__version__ = "1.0.0"
