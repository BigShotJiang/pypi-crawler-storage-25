"""Git branch management - invisible infrastructure for agent isolation.

Each sprint gets its own branch. Agents work on the branch. The CEO never
sees git operations - they just approve or reject the sprint's work, and
the merge/abandon happens silently.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from odd.config import GIT_COMMAND_TIMEOUT, SPRINT_BRANCH_PREFIX, WORKTREE_DIR

logger = logging.getLogger(__name__)


def _validate_branch_name(name: str) -> str:
    """Reject branch names with shell metacharacters."""
    if not re.match(r'^[\w\-./]+$', name):
        raise ValueError(f"Invalid branch name: {name}")
    return name


class GitNotAvailable(Exception):
    """Project is not a git repo or git is not installed."""
    pass


class MergeConflictError(Exception):
    """Branch merge produced conflicts that need resolution."""

    def __init__(self, conflicting_files: list[str]):
        self.conflicting_files = conflicting_files
        super().__init__(f"Merge conflicts in: {', '.join(conflicting_files)}")


class GitManager:
    """Manages sprint branches - completely invisible to the CEO.

    All operations are safe: if git isn't available or the project isn't
    a repo, everything degrades gracefully to no-ops.
    """

    def __init__(self, project_root: Path | None = None):
        self.root = (project_root or Path.cwd()).resolve()
        self._available: bool | None = None

    @property
    def available(self) -> bool:
        """Check if git is usable in this project."""
        if self._available is None:
            self._available = self._check_git()
        return self._available

    def sprint_branch_name(self, sprint_number: int) -> str:
        return f"{SPRINT_BRANCH_PREFIX}-{sprint_number}"

    def main_branch(self) -> str:
        """Detect the main branch name (main, master, etc.)."""
        if not self.available:
            return "main"
        # Use the HEAD of the default remote branch
        result = self._run(["git", "symbolic-ref", "refs/remotes/origin/HEAD"], check=False)
        if result.returncode == 0 and result.stdout.strip():
            # refs/remotes/origin/main -> main
            return result.stdout.strip().split("/")[-1]
        # Fallback: check if main or master exists
        for candidate in ("main", "master"):
            result = self._run(["git", "rev-parse", "--verify", candidate], check=False)
            if result.returncode == 0:
                return candidate
        # Last resort: current branch
        result = self._run(["git", "branch", "--show-current"], check=False)
        return result.stdout.strip() or "main"

    def create_sprint_branch(self, sprint_number: int) -> str | None:
        """Create and checkout a sprint branch. Returns branch name or None if git unavailable."""
        if not self.available:
            return None
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        # If branch already exists, just check it out
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        if result.returncode == 0:
            self._run(["git", "checkout", branch])
            return branch

        # Create from main
        self._run(["git", "checkout", main])
        self._run(["git", "checkout", "-b", branch])
        return branch

    def merge_sprint(self, sprint_number: int) -> bool:
        """Merge sprint branch into main. Returns True on success.

        Raises MergeConflictError if there are conflicts.
        """
        if not self.available:
            return True  # No-op success for non-git projects

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        # Commit any uncommitted work on the sprint branch
        self._auto_commit(f"Sprint {sprint_number} - final work")

        # Switch to main
        self._run(["git", "checkout", main])

        # Attempt merge
        result = self._run(["git", "merge", branch, "--no-edit"], check=False)
        if result.returncode != 0:
            # Check for conflicts
            conflicts = self._get_conflict_files()
            if conflicts:
                raise MergeConflictError(conflicts)
            # Some other merge error - abort and report
            self._run(["git", "merge", "--abort"], check=False)
            return False

        return True

    def abandon_sprint(self, sprint_number: int) -> bool:
        """Abandon a sprint branch - switch back to main, leave branch intact."""
        if not self.available:
            return True

        main = self.main_branch()

        # Commit any work so it's not lost
        self._auto_commit(f"Sprint {sprint_number} - abandoned (work preserved)")

        self._run(["git", "checkout", main])
        return True

    def abort_merge(self) -> None:
        """Abort an in-progress merge."""
        if not self.available:
            return
        self._run(["git", "merge", "--abort"], check=False)

    def resolve_conflicts_and_commit(self, sprint_number: int) -> bool:
        """After conflicts are resolved by an agent, add and commit."""
        if not self.available:
            return True
        self._run(["git", "add", "-A"])
        result = self._run(
            ["git", "commit", "-m", f"Sprint {sprint_number} - merge conflicts resolved"],
            check=False,
        )
        return result.returncode == 0

    def get_sprint_diff_summary(self, sprint_number: int) -> str:
        """Get a summary of changes on the sprint branch vs main.

        This is for Cody to read internally when preparing the demo -
        the CEO never sees this.
        """
        if not self.available:
            return ""
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()
        diff_range = f"{main}...{branch}"

        # Stat summary (files changed, insertions, deletions)
        result = self._run(["git", "diff", diff_range, "--stat"], check=False)
        stat = result.stdout.strip() if result.returncode == 0 else ""

        # File list
        result = self._run(["git", "diff", diff_range, "--name-only"], check=False)
        files = result.stdout.strip() if result.returncode == 0 else ""

        parts = []
        if files:
            parts.append(f"Files changed:\n{files}")
        if stat:
            parts.append(f"Summary:\n{stat}")
        return "\n\n".join(parts)

    def get_task_diff_stat(self, sprint_number: int, task_id: str) -> str:
        """Get git diff --stat for a task branch vs the sprint branch.

        Used to show what a specific agent changed in their worktree,
        scoped to just their branch rather than the whole phase.
        """
        if not self.available:
            return ""
        task_branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))

        result = self._run(
            ["git", "diff", f"{sprint_branch}...{task_branch}", "--stat"],
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else ""

    def ensure_on_sprint_branch(self, sprint_number: int) -> None:
        """Make sure we're on the sprint branch (e.g., after escalation).

        Handles the case where the branch was deleted or never created.
        Attempts reflog recovery before falling back to recreating from main.
        """
        if not self.available:
            return
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        current = self._run(["git", "branch", "--show-current"], check=False).stdout.strip()
        if current != branch:
            self._auto_commit("WIP - switching branches")
            if not self.branch_exists(branch):
                recovered = self.recover_branch(branch)
                if not recovered:
                    logger.warning("Sprint branch %s missing - recreating from %s", branch, self.main_branch())
                    self.create_sprint_branch(sprint_number)
            else:
                self._run(["git", "checkout", branch])

    # ------------------------------------------------------------------
    # Rebase & divergence handling
    # ------------------------------------------------------------------

    def rebase_sprint_onto_main(self, sprint_number: int) -> bool:
        """Rebase the sprint branch onto the current tip of main.

        Keeps sprint history linear against an updated main. If conflicts
        arise during rebase, the rebase is aborted and False is returned
        so the caller can fall back to a merge strategy.
        """
        if not self.available:
            return True

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        if not self.branch_exists(branch):
            logger.warning("Cannot rebase - sprint branch %s does not exist", branch)
            return False

        # Commit any uncommitted work first
        current = self._run(["git", "branch", "--show-current"], check=False).stdout.strip()
        if current == branch:
            self._auto_commit("WIP - before rebase")

        # Switch to the sprint branch
        self._run(["git", "checkout", branch])

        # Check if rebase is needed (sprint is already up to date with main)
        merge_base = self._run(["git", "merge-base", branch, main], check=False)
        main_tip = self._run(["git", "rev-parse", main], check=False)
        if (
            merge_base.returncode == 0
            and main_tip.returncode == 0
            and merge_base.stdout.strip() == main_tip.stdout.strip()
        ):
            return True  # Already up to date

        result = self._run(["git", "rebase", main], check=False)
        if result.returncode != 0:
            logger.warning(
                "Rebase of %s onto %s failed - aborting: %s",
                branch, main, result.stderr.strip()[:200],
            )
            self._run(["git", "rebase", "--abort"], check=False)
            return False

        return True

    def check_divergence(self, sprint_number: int) -> dict[str, Any]:
        """Check how far a sprint branch has diverged from main.

        Returns a dict with:
          - ahead: commits on sprint not on main
          - behind: commits on main not on sprint
          - diverged: True if both ahead and behind are > 0
          - merge_base: the common ancestor commit
        """
        if not self.available:
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        if not self.branch_exists(branch):
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        # rev-list --left-right --count main...branch gives "behind\tahead"
        result = self._run(
            ["git", "rev-list", "--left-right", "--count", f"{main}...{branch}"],
            check=False,
        )
        if result.returncode != 0:
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        parts = result.stdout.strip().split()
        behind = int(parts[0]) if len(parts) >= 1 else 0
        ahead = int(parts[1]) if len(parts) >= 2 else 0

        merge_base_result = self._run(
            ["git", "merge-base", main, branch], check=False,
        )
        merge_base = (
            merge_base_result.stdout.strip()[:12]
            if merge_base_result.returncode == 0
            else None
        )

        return {
            "ahead": ahead,
            "behind": behind,
            "diverged": ahead > 0 and behind > 0,
            "merge_base": merge_base,
        }

    def recover_branch(self, branch: str) -> bool:
        """Try to recover a deleted branch using the reflog.

        Searches the reflog for the last known commit on the branch
        and recreates it. Returns True if recovery succeeded.
        """
        if not self.available:
            return False

        branch = _validate_branch_name(branch)

        # Search reflog for the branch name
        result = self._run(
            ["git", "reflog", "show", "--format=%H", branch],
            check=False,
        )
        if result.returncode == 0 and result.stdout.strip():
            # First line is the most recent commit on that branch
            last_commit = result.stdout.strip().splitlines()[0]
            recreate = self._run(
                ["git", "branch", branch, last_commit], check=False,
            )
            if recreate.returncode == 0:
                logger.info("Recovered branch %s from reflog at %s", branch, last_commit[:12])
                self._run(["git", "checkout", branch])
                return True

        # Fallback: search general HEAD reflog for checkout entries.
        # When we see "checkout: moving from {branch} to X", the %H on that
        # line is the destination commit (X's tip), not the branch's tip.
        # The PREVIOUS reflog entry (next line, since output is newest-first)
        # has the branch's last HEAD value.
        result = self._run(
            ["git", "reflog", "--format=%H %gs"],
            check=False,
        )
        if result.returncode == 0:
            lines = result.stdout.splitlines()
            for i, line in enumerate(lines):
                if f"checkout: moving from {branch} " in line:
                    if i + 1 < len(lines):
                        commit = lines[i + 1].split()[0]
                        recreate = self._run(
                            ["git", "branch", branch, commit], check=False,
                        )
                        if recreate.returncode == 0:
                            logger.info(
                                "Recovered branch %s from reflog at %s",
                                branch, commit[:12],
                            )
                            self._run(["git", "checkout", branch])
                            return True

        return False

    def cherry_pick_task_commits(
        self,
        sprint_number: int,
        task_id: str,
    ) -> bool:
        """Cherry-pick commits from a task branch onto the sprint branch.

        Used as a fallback when a full merge of the task branch fails.
        Picks each commit individually, skipping any that conflict, so
        partial work is salvaged rather than lost entirely.

        Returns True if at least one commit was applied.
        """
        if not self.available:
            return False

        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        task_branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))

        if not self.branch_exists(task_branch):
            return False

        # Find commits on task branch that aren't on sprint branch
        result = self._run(
            ["git", "rev-list", "--reverse", f"{sprint_branch}..{task_branch}"],
            check=False,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return False

        commits = result.stdout.strip().splitlines()

        # Make sure we're on the sprint branch
        self._run(["git", "checkout", sprint_branch])

        applied = 0
        skipped = 0
        for commit in commits:
            pick_result = self._run(
                ["git", "cherry-pick", "--no-edit", commit], check=False,
            )
            if pick_result.returncode != 0:
                # Conflict - abort this cherry-pick and skip
                self._run(["git", "cherry-pick", "--abort"], check=False)
                skipped += 1
                logger.warning(
                    "Cherry-pick of %s from task %s skipped (conflict)",
                    commit[:12], task_id,
                )
            else:
                applied += 1

        if applied > 0:
            logger.info(
                "Cherry-picked %d/%d commits from task %s (%d skipped)",
                applied, len(commits), task_id, skipped,
            )

        return applied > 0

    # ------------------------------------------------------------------
    # Task-level branching (for parallel phase execution)
    # ------------------------------------------------------------------

    def _worktree_path(self, task_id: str) -> Path:
        """Return the worktree path for a task, inside .odd/worktrees/."""
        return self.root / WORKTREE_DIR / task_id

    def task_branch_name(self, sprint_number: int, task_id: str) -> str:
        return f"{SPRINT_BRANCH_PREFIX}-{sprint_number}-task-{task_id}"

    def create_task_worktree(self, sprint_number: int, task_id: str) -> Path | None:
        """Create a git worktree for a task branch.

        Returns the worktree path, or None if git is unavailable.
        The worktree is created from the sprint branch so each task
        starts with all sprint work so far.

        Prunes stale worktrees first to avoid git errors from previous
        crashed sprints.
        """
        if not self.available:
            return None

        # Prune any leftover worktrees from previous crashes
        self._run(["git", "worktree", "prune"], check=False)

        branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        worktree_path = self._worktree_path(task_id)

        # Create branch from sprint branch
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        if result.returncode != 0:
            # Verify sprint branch exists before branching from it
            sprint_exists = self._run(
                ["git", "rev-parse", "--verify", sprint_branch], check=False,
            )
            if sprint_exists.returncode != 0:
                logger.error(
                    "Sprint branch %s does not exist - cannot create task worktree",
                    sprint_branch,
                )
                return None
            self._run(["git", "branch", branch, sprint_branch])

        # Create worktree (remove stale one if it exists)
        if worktree_path.exists():
            self._run(["git", "worktree", "remove", str(worktree_path), "--force"], check=False)

        worktree_path.parent.mkdir(parents=True, exist_ok=True)
        result = self._run(
            ["git", "worktree", "add", str(worktree_path), branch], check=False,
        )
        if result.returncode != 0:
            logger.error(
                "Failed to create worktree at %s: %s",
                worktree_path, result.stderr.strip()[:200],
            )
            return None

        return worktree_path

    def remove_task_worktree(self, task_id: str) -> None:
        """Remove a task worktree after the phase is done."""
        if not self.available:
            return
        worktree_path = self._worktree_path(task_id)
        if worktree_path.exists():
            self._run(["git", "worktree", "remove", str(worktree_path), "--force"], check=False)

    def commit_task_worktree(self, task_id: str, message: str) -> bool:
        """Commit all changes in a task worktree."""
        if not self.available:
            return False
        worktree_path = self._worktree_path(task_id)
        if not worktree_path.exists():
            return False
        # Stage all changes
        subprocess.run(
            ["git", "add", "-A"],
            shell=False, capture_output=True, text=True,
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        # Check if there's anything to commit
        diff_result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            shell=False, capture_output=True, text=True,
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        if diff_result.returncode == 0:
            return True  # Nothing to commit - that's fine
        # Commit
        result = subprocess.run(
            ["git", "commit", "-m", message],
            shell=False, capture_output=True, text=True,
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        return result.returncode == 0

    def merge_task_branches(
        self,
        sprint_number: int,
        task_ids: list[str],
    ) -> list[str]:
        """Merge all task branches back into the sprint branch.

        Returns list of files with conflicts (empty on clean merge).
        Commits each task worktree first, then merges sequentially.

        When a merge has conflicts, they are recorded and the merge is
        aborted so that subsequent task branches can still be attempted.
        Tasks whose merges conflict are collected into `failed_task_ids`
        so the caller can retry them after the clean merges land.
        """
        if not self.available:
            return []

        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))

        # Commit any remaining work in each worktree
        for task_id in task_ids:
            self.commit_task_worktree(
                task_id, f"Sprint {sprint_number} - task {task_id}",
            )

        # Switch to sprint branch
        self._run(["git", "checkout", sprint_branch])

        # Merge each task branch - clean merges first, then retry conflicts
        all_conflicts: list[str] = []
        failed_task_ids: list[str] = []

        for task_id in task_ids:
            branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
            # Verify the branch actually exists before merging
            exists = self._run(["git", "rev-parse", "--verify", branch], check=False)
            if exists.returncode != 0:
                logger.warning("Task branch %s does not exist - skipping merge", branch)
                continue
            result = self._run(["git", "merge", branch, "--no-edit"], check=False)
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                if conflicts:
                    all_conflicts.extend(conflicts)
                    failed_task_ids.append(task_id)
                    self._run(["git", "merge", "--abort"], check=False)
                elif "untracked working tree files" in result.stderr:
                    # Untracked files from a prior merge block this one.
                    # Stage them so git can merge over them, then retry.
                    self._run(["git", "merge", "--abort"], check=False)
                    self._run(["git", "add", "-A"], check=False)
                    self._run(
                        ["git", "commit", "-m", "stage untracked files before merge"],
                        check=False,
                    )
                    retry = self._run(["git", "merge", branch, "--no-edit"], check=False)
                    if retry.returncode != 0:
                        retry_conflicts = self._get_conflict_files()
                        if retry_conflicts:
                            all_conflicts.extend(retry_conflicts)
                            failed_task_ids.append(task_id)
                        self._run(["git", "merge", "--abort"], check=False)
                        logger.error(
                            "Merge of %s failed after staging untracked files: %s",
                            branch, retry.stderr.strip()[:200],
                        )
                else:
                    # Non-conflict merge failure (e.g. unrelated histories) - abort
                    self._run(["git", "merge", "--abort"], check=False)
                    logger.error(
                        "Merge of %s failed without conflicts: %s",
                        branch, result.stderr.strip()[:200],
                    )

        # Second pass: retry failed merges now that clean merges have landed.
        # The new base may resolve some conflicts automatically.
        if failed_task_ids:
            retry_conflicts: list[str] = []
            for task_id in failed_task_ids:
                branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
                result = self._run(["git", "merge", branch, "--no-edit"], check=False)
                if result.returncode != 0:
                    conflicts = self._get_conflict_files()
                    if conflicts:
                        retry_conflicts.extend(conflicts)
                    self._run(["git", "merge", "--abort"], check=False)
            # Replace first-pass conflicts with retry results - we only
            # care about the final conflict state, not what conflicted on
            # the first pass, since those were against a different base.
            if retry_conflicts:
                all_conflicts = list(dict.fromkeys(retry_conflicts))
            else:
                all_conflicts = []  # All conflicts resolved on retry

        return all_conflicts

    def cleanup_task_branches(self, sprint_number: int, task_ids: list[str]) -> None:
        """Remove task worktrees and branches after a phase is merged."""
        for task_id in task_ids:
            self.remove_task_worktree(task_id)
            branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
            self._run(["git", "branch", "-D", branch], check=False)

    def prune_stale_worktrees(self) -> list[str]:
        """Remove worktrees left behind by crashed sprints.

        Returns list of cleaned-up worktree paths.
        """
        if not self.available:
            return []

        result = self._run(["git", "worktree", "list", "--porcelain"], check=False)
        if result.returncode != 0:
            return []

        worktrees_dir = self.root / WORKTREE_DIR

        cleaned: list[str] = []
        current_path = ""
        for line in result.stdout.splitlines():
            if line.startswith("worktree "):
                current_path = line[len("worktree "):]
            elif line == "prunable" or (
                current_path
                and str(worktrees_dir) in current_path
                and not Path(current_path).exists()
            ):
                cleaned.append(current_path)

        # Prune all stale entries
        if cleaned:
            self._run(["git", "worktree", "prune"], check=False)

        # Also remove any leftover worktree directories on disk
        if worktrees_dir.exists():
            known_result = self._run(
                ["git", "worktree", "list", "--porcelain"], check=False,
            )
            known_worktrees = known_result.stdout if known_result.returncode == 0 else ""
            for d in worktrees_dir.iterdir():
                if d.is_dir() and str(d) not in known_worktrees:
                    self._run(["git", "worktree", "remove", str(d), "--force"], check=False)
                    if not d.exists():
                        cleaned.append(str(d))

        return cleaned

    def branch_exists(self, branch: str) -> bool:
        """Check whether a local branch exists."""
        if not self.available:
            return False
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        return result.returncode == 0

    def current_branch(self) -> str | None:
        """Return current branch name, or None if not in a git repo."""
        if not self.available:
            return None
        result = self._run(["git", "branch", "--show-current"], check=False)
        return result.stdout.strip() if result.returncode == 0 else None

    def has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes in the working tree."""
        if not self.available:
            return False
        result = self._run(["git", "status", "--porcelain"], check=False)
        return bool(result.stdout.strip())

    def _auto_commit(self, message: str) -> bool:
        """Stage and commit all changes if there are any. Returns True if committed."""
        if not self.has_uncommitted_changes():
            return False
        self._run(["git", "add", "-A"])
        result = self._run(["git", "commit", "-m", message], check=False)
        return result.returncode == 0

    def _get_conflict_files(self) -> list[str]:
        """List files with merge conflicts."""
        result = self._run(["git", "diff", "--name-only", "--diff-filter=U"], check=False)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()
        return []

    def _check_git(self) -> bool:
        """Check if git is available and we're in a repo."""
        try:
            result = self._run(["git", "rev-parse", "--is-inside-work-tree"], check=False)
            return result.returncode == 0 and result.stdout.strip() == "true"
        except FileNotFoundError:
            return False

    def _run(
        self,
        cmd: list[str],
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        """Run a git command as an argument list (never a shell string)."""
        result = subprocess.run(
            cmd,
            shell=False,
            capture_output=True,
            text=True,
            cwd=self.root,
            timeout=GIT_COMMAND_TIMEOUT,
        )
        # Log notable git operations (merges, branch deletes, force ops, commits)
        op = cmd[1] if len(cmd) > 1 else ""
        if op in ("merge", "branch", "commit", "checkout", "worktree", "reset"):
            logger.debug(
                "git %s → exit %d | %s",
                " ".join(cmd[1:]),
                result.returncode,
                result.stdout.strip()[:200] or result.stderr.strip()[:200],
            )
            self._write_git_log(cmd, result.returncode)
        return result

    def _write_git_log(self, cmd: list[str], exit_code: int) -> None:
        """Append git operation to .odd/logs/git.jsonl if .odd/ exists."""
        try:
            odd_dir = self.root / ".odd"
            if not odd_dir.exists():
                return  # No .odd/ directory - skip logging (e.g. in tests)
            log_path = odd_dir / "logs" / "git.jsonl"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            record = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "cmd": cmd,
                "exit_code": exit_code,
            }
            with log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception:
            pass  # Logging should never break git operations
