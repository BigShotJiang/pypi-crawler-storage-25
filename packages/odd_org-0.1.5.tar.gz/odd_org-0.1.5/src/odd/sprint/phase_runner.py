"""Parallel phase execution via git worktrees.

Owns the concurrent task lifecycle: submit to thread pool → collect results →
commit worktree work.  Declares its dependencies explicitly via __init__ and
is independently testable.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskID

from odd.agent import AgentKilledError
from odd.config import PHASE_TOKEN_DEFAULTS
from odd.display import (
    AgentOutputStream, AgentStatus, WarRoom,
    format_tool_result_line, format_tool_summary,
)
from odd.labels import escalation_label, escalation_style
from odd.models import (
    CEOGate,
    CEOStyle,
    SprintPhase,
    SprintTask,
    TaskStatus,
)
from odd.sprint.briefing import SprintBriefing

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.git import GitManager
    from odd.models import Persona, Sprint
    from odd.provider import StreamCallback
    from odd.sprint.tdd_gate import TDDGate

from odd.sprint._console import console, _tprint  # noqa: F401, E402


class PhaseRunner:
    """Parallel phase execution via git worktrees.

    Runs multiple tasks concurrently in separate worktrees with TDD gates.
    Each dependency is declared explicitly so the runner can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        git: GitManager,
        engine: AgentEngine,
        tdd: TDDGate,
        gate: Callable[[CEOGate], CEOStyle],
        streaming: bool,
        *,
        resolve_agent: Callable[[str, dict[str, Persona]], Persona | None],
        build_phase_context: Callable[[str, SprintBriefing | None, str], str],
        make_war_room_callback: Callable[[AgentOutputStream], StreamCallback | None],
        make_tool_result_callback: Callable[[AgentOutputStream | None], Callable | None] | None = None,
    ):
        self.git = git
        self.engine = engine
        self.tdd = tdd
        self._gate = gate
        self.streaming = streaming
        self._resolve_agent = resolve_agent
        self._build_phase_context = build_phase_context
        self._make_war_room_callback = make_war_room_callback
        self._make_tool_result_callback = make_tool_result_callback

    # --- Main entry point ---

    def run_phase_parallel(
        self,
        tasks: list[SprintTask],
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str = "",
        briefing: SprintBriefing | None = None,
    ) -> dict[str, Any]:
        """Run multiple tasks concurrently in separate git worktrees.

        Each worktree gets its own TDD gate after the agent finishes.
        Requires git - parallel tasks without worktree isolation would
        clobber each other's files.

        When the CEO style enables the War Room, a live multi-agent
        display is shown during execution.

        Returns:
            A ``{agent_name: forked_engine}`` dict for session ID harvesting.
        """
        if not self.git.available:
            raise RuntimeError(
                "Git is required for parallel task execution. "
                "Initialize a git repository (git init && git add -A && git commit -m 'init') "
                "before running sprints with multiple tasks per phase."
            )

        use_war_room = self._gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR and self.streaming
        streams: list[AgentOutputStream] = []
        futures: dict = {}
        forked_engines: dict[str, Any] = {}

        with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
            futures = self._submit_parallel_tasks(
                pool, tasks, sprint, team, project_context,
                notes_path, test_context, briefing, use_war_room, streams,
            )

            war_room = WarRoom(streams, console=console) if use_war_room else None
            progress, progress_tasks = self._make_progress_bar(tasks) if not use_war_room else (None, {})

            if war_room:
                war_room.start()
            elif progress:
                progress.start()

            try:
                forked_engines = self._collect_parallel_results(
                    futures, sprint, war_room, progress, progress_tasks,
                )
            finally:
                if war_room:
                    war_room.stop()
                if progress:
                    progress.stop()

        return forked_engines

    # --- Internal machinery ---

    def _submit_parallel_tasks(
        self,
        pool: ThreadPoolExecutor,
        tasks: list[SprintTask],
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str,
        briefing: SprintBriefing | None,
        use_war_room: bool,
        streams: list[AgentOutputStream],
    ) -> dict:
        """Submit all tasks to the thread pool and return futures map."""
        futures = {}
        # Share one AgentOutputStream per agent so the same agent with
        # multiple tasks doesn't get duplicate War Room panels.
        agent_streams: dict[str, AgentOutputStream] = {}
        for task in tasks:
            task.status = TaskStatus.IN_PROGRESS
            agent = self._resolve_agent(task.assigned_to, team)
            if not agent:
                agent = team["lead_dev"]

            if agent.name in agent_streams:
                aos = agent_streams[agent.name]
            else:
                aos = AgentOutputStream(agent.name)
                aos.status = AgentStatus.WORKING
                agent_streams[agent.name] = aos
                streams.append(aos)

            if not use_war_room:
                _tprint(Panel(
                    f"{agent.name} is working on: {task.description}",
                    style="green",
                ))

            worktree = self.git.create_task_worktree(sprint.number, task.id)
            forked_engine = self.engine.fork(working_dir=worktree)

            impl_prompt = self.tdd.build_impl_prompt(
                sprint.number, task.description, test_context, notes_path, agent.name,
            )
            task_context = (
                self._build_phase_context(project_context, briefing, agent.name)
                if briefing else project_context
            )
            stream_cb = self._make_war_room_callback(aos)
            tool_cb = self._make_tool_result_callback(aos) if self._make_tool_result_callback else None

            future = pool.submit(
                self._run_task_in_worktree,
                forked_engine, agent, task, sprint,
                impl_prompt, task_context, worktree,
                stream_cb, lambda s=aos: s.cancelled,
                tool_cb,
            )
            futures[future] = (task, agent, forked_engine, aos)
        return futures

    def _make_progress_bar(self, tasks: list[SprintTask]) -> tuple[Progress | None, dict[str, TaskID]]:
        """Create a delegator-style progress bar, or (None, {}) for other styles."""
        if self._gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR:
            return None, {}
        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            console=console,
            transient=True,
        )
        progress_tasks: dict[str, TaskID] = {
            "main": progress.add_task("Implementation phase", total=len(tasks), completed=0),
        }
        return progress, progress_tasks

    def _collect_parallel_results(
        self,
        futures: dict,
        sprint: Sprint,
        war_room: WarRoom | None,
        progress: Progress | None,
        progress_tasks: dict[str, TaskID],
    ) -> dict[str, Any]:
        """Collect results from completed futures, update status, commit worktrees.

        Returns:
            A ``{agent_name: forked_engine}`` dict so callers can harvest
            session IDs for crash-resume checkpoints.
        """
        forked_engines: dict[str, Any] = {}
        for future in as_completed(futures):
            task, agent, forked_engine, aos = futures[future]
            forked_engines[agent.name] = forked_engine
            try:
                future.result()
                aos.status = AgentStatus.DONE
            except AgentKilledError:
                aos.status = AgentStatus.KILLED
                task.status = TaskStatus.FAILED
                _tprint(f"[red]{agent.name} killed: {task.description}[/red]")
            except Exception as e:
                aos.status = AgentStatus.KILLED
                task.status = TaskStatus.FAILED
                _tprint(f"[red]{agent.name} failed: {task.description} - {e}[/red]")

            if war_room:
                war_room.refresh()
            if progress and "main" in progress_tasks:
                progress.advance(progress_tasks["main"])

            # Collect escalations from forked engine and forward to main
            for esc in forked_engine.get_escalations():
                deferred = esc["severity"] in ("blocker", "needs_decision", "command_request")
                suffix = (
                    "\n\n[dim italic]CEO will be prompted after this phase completes.[/dim italic]"
                    if deferred else ""
                )
                body = f"[bold]{agent.name}[/bold] - {escalation_label(esc['severity'])}:\n\n{esc['reason']}{suffix}"
                if esc.get("command"):
                    body += f"\n\n[bold]Command:[/bold] [cyan]{esc['command']}[/cyan]"
                _tprint(Panel(
                    body,
                    title="Escalation (queued for CEO)" if deferred else "Escalation",
                    style=escalation_style(esc["severity"]),
                ))
                # Forward actionable escalations to main engine for post-phase handling
                if deferred:
                    esc["agent_name"] = agent.name
                    self.engine.escalations.append(esc)

            # Forward submissions from forked engine
            for sub in forked_engine.get_submissions():
                self.engine.submissions.append(sub)

            # Commit worktree work (skip if killed/failed)
            if task.status != TaskStatus.FAILED:
                self.git.commit_task_worktree(
                    task.id,
                    f"Sprint {sprint.number} - {task.description[:60]}",
                )
        return forked_engines

    def _run_task_in_worktree(
        self,
        engine: AgentEngine,
        agent: Persona,
        task: SprintTask,
        sprint: Sprint,
        impl_prompt: str,
        project_context: str,
        worktree: Path,
        stream_cb: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        on_tool_result: Callable | None = None,
    ) -> None:
        """Execute a task in a worktree with the mechanical TDD gate."""
        self.tdd.execute(
            engine=engine,
            agent=agent,
            task=task,
            sprint=sprint,
            impl_prompt=impl_prompt,
            project_context=project_context,
            cwd=worktree,
            stream_cb=stream_cb,
            cancel_check=cancel_check,
            interactive=False,
            on_tool_result=on_tool_result,
        )

    def resolve_phase_conflicts(
        self,
        lead_dev: Persona,
        sprint: Sprint,
        phase: SprintPhase,
        conflicts: list[str],
        project_context: str,
    ) -> None:
        """Fresh Cody resolves merge conflicts after a phase completes."""
        console.print(Panel(
            "Cody is merging phase work...",
            style="dim",
        ))

        conflict_files = "\n".join(f"  - {f}" for f in conflicts)
        task_map = {t.id: t for t in sprint.tasks}
        task_summary = "\n".join(
            f"  - {task_map[tid].description}"
            for tid in phase.task_ids if tid in task_map
        )

        self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"Phase {phase.number} ({phase.description}) is complete. "
                f"Multiple tasks ran in parallel and there are merge conflicts.\n\n"
                f"Tasks in this phase:\n{task_summary}\n\n"
                f"Conflicting files:\n{conflict_files}\n\n"
                f"Resolve each conflict by reading the file, understanding what "
                f"each task intended, and combining the changes correctly. Remove "
                f"all conflict markers (<<<<<<, ======, >>>>>>).\n\n"
                f"After resolving, verify the code still works."
            ),
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["merge"],
            phase="implementation",
        )

        self.git.resolve_conflicts_and_commit(sprint.number)
