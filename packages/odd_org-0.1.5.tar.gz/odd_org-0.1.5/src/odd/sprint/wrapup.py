"""Sprint wrapup collaborator.

Owns the post-implementation lifecycle: demo, retro, ship/scrap,
changelog, backlog sweep, hiring suggestions, test change reviews,
and dependency requests. Declares its dependencies explicitly via
__init__ and is independently testable.
"""

from __future__ import annotations

import datetime
import re
import subprocess
from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt

from odd.backlog import Backlog, Priority
from odd.config import PHASE_TOKEN_DEFAULTS
from odd.git import MergeConflictError
from odd.labels import compensation_quip, model_tier_label, resolve_model_choice
from odd.models import (
    CEOGate,
    CEOStyle,
    ModelTier,
    RoleType,
    SprintCheckpoint,
    SprintStatus,
    TaskStatus,
)
from odd.parsers import parse_hire_suggestions
from odd.review import offer_code_review, run_code_review
from odd.tools import SUBMIT_HIRE_SUGGESTION, SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_TEST_REVIEW_DECISION

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.git import GitManager
    from odd.models import Persona, Sprint
    from odd.provider import StreamCallback
    from odd.state import StateManager
    from odd.sprint.tdd_gate import TDDGate

# Validate package names before installation - reject anything that could
# inject flags or smuggle extra arguments into pip/npm.
_SAFE_PACKAGE_RE = re.compile(
    r"^[a-zA-Z0-9][a-zA-Z0-9._\-]*(\[[\w,]+\])?(([=<>!~]+[\w.*]+))?$"
)

from odd.sprint._console import console  # noqa: E402
from odd.sprint.tdd_gate import _resolve_argv  # noqa: E402


class SprintWrapup:
    """Post-implementation lifecycle: demo, retro, ship, changelog, hiring.

    Each dependency is declared explicitly so the wrapup can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        engine: AgentEngine,
        get_git: Callable[[], GitManager],
        tdd: TDDGate,
        gate: Callable[[CEOGate], CEOStyle],
        build_project_context: Callable[[int], str],
        get_phase_diff_stat: Callable[[int], str],
    ):
        self.state = state
        self.engine = engine
        self._get_git = get_git
        self.tdd = tdd
        self._gate = gate
        self._build_project_context = build_project_context
        self._get_phase_diff_stat = get_phase_diff_stat

    @property
    def git(self) -> GitManager:
        return self._get_git()

    # --- Changelog & metrics ---

    def write_changelog_entry(self, sprint: Sprint) -> None:
        """Append a mechanical changelog entry for this sprint.

        Pure data - no LLM calls, no agent involvement. Built from sprint
        metadata, task statuses, git diff stats, and test results.
        """
        done = [t for t in sprint.tasks if t.status == TaskStatus.DONE]
        failed = [t for t in sprint.tasks if t.status == TaskStatus.FAILED]

        lines: list[str] = []
        date_str = datetime.date.today().isoformat()
        lines.append(f"## Sprint {sprint.number} - {date_str}")
        lines.append(f"**Goal:** {sprint.goal}")

        if done:
            lines.append("")
            lines.append("### Completed")
            for t in done:
                lines.append(f"- {t.id}: {t.description}")

        if failed:
            lines.append("")
            lines.append("### Failed")
            for t in failed:
                lines.append(f"- {t.id}: {t.description}")

        # Git diff stat
        diff_stat = self._get_phase_diff_stat(sprint.number)
        if diff_stat:
            # Extract just the summary line (e.g. "5 files changed, 120 insertions(+)")
            stat_lines = diff_stat.strip().splitlines()
            summary_line = stat_lines[-1] if stat_lines else ""
            if summary_line:
                lines.append("")
                lines.append(f"**Changes:** {summary_line.strip()}")

        # Test status derived from task outcomes (tests already ran during TDD)
        total_tasks = len(sprint.tasks)
        done_count = len(done)
        failed_count = len(failed)
        if total_tasks > 0:
            status = "passing" if failed_count == 0 else "failing"
            lines.append(f"**Tests ({status}):** {done_count}/{total_tasks} tasks passed")

        lines.append("")  # trailing newline

        entry = "\n".join(lines) + "\n"

        # Prepend to CHANGELOG.md (newest first)
        changelog_path = self.state.root / "CHANGELOG.md"
        existing = ""
        if changelog_path.exists():
            existing = changelog_path.read_text(encoding="utf-8")

        if existing:
            changelog_path.write_text(entry + "\n" + existing, encoding="utf-8")
        else:
            header = "# Changelog\n\n"
            changelog_path.write_text(header + entry, encoding="utf-8")

        console.print(f"[dim]Changelog updated - Sprint {sprint.number}[/dim]")

    def show_running_costs(self, label: str) -> None:
        """Show per-agent cost breakdown at a milestone during the sprint."""
        cfo = self.engine.cfo
        if not cfo or not cfo.has_session_activity():
            return
        by_agent = cfo.session_cost_by_agent()
        parts = [f"{agent}: ${cost:.4f}" for agent, cost in sorted(by_agent.items(), key=lambda x: -x[1])]
        total = cfo.session_cost()
        sep = " \u00b7 "
        console.print(
            f"[dim]  \U0001f4ca {label} - ${total:.4f} total | {sep.join(parts)}[/dim]"
        )

    def show_sprint_performance(self, sprint: Sprint) -> None:
        """Show a performance snapshot for consultants who worked this sprint."""
        records = self.state.all_consultant_records()
        # Filter to consultants who have outcomes in this sprint
        sprint_records = {
            name: record for name, record in records.items()
            if any(o.sprint_number == sprint.number for o in record.outcomes)
        }
        if not sprint_records:
            return

        lines = []
        for name, record in sprint_records.items():
            sprint_outcomes = [o for o in record.outcomes if o.sprint_number == sprint.number]
            first_try = sum(1 for o in sprint_outcomes if o.passed and o.retries == 0)
            total = len(sprint_outcomes)
            retries = sum(o.retries for o in sprint_outcomes)
            failed = sum(1 for o in sprint_outcomes if not o.passed)

            parts = [f"  {name}:"]
            if first_try == total and total > 0:
                parts.append(f"tests passed first try \u2713")
            else:
                parts.append(f"{first_try}/{total} first try")
            if retries:
                parts.append(f"{retries} {'retry' if retries == 1 else 'retries'}")
            if failed:
                parts.append(f"{failed} unresolved")
            lines.append("  |  ".join(parts))

        console.print(Panel(
            "\n".join(lines),
            title=f"Sprint {sprint.number} - Performance",
            style="cyan",
        ))

    # --- Core post-implementation orchestration ---

    def post_implementation(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        sprint_number: int,
    ) -> None:
        """Post-implementation phase: review -> demo -> ship -> changelog -> retro -> backlog -> hiring."""
        lead_dev = team["lead_dev"]
        secretary = team["secretary"]
        project_context = self._build_project_context(sprint_number)

        self.maybe_run_code_review(sprint, lead_dev, sprint_number, project_context)

        # Checkpoint after review so a crash during demo can resume here.
        sprint.checkpoint = SprintCheckpoint(
            stage="review",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[t.id for t in sprint.tasks if t.status == TaskStatus.DONE],
        )
        self.state.save_sprint(sprint)

        # --- Demo ---
        console.print(Panel("Sprint complete! Preparing demo...", style="bold blue"))
        demo_text = self.demo(sprint, lead_dev)
        console.print(Panel(
            Markdown(demo_text),
            title=f"Sprint {sprint_number} Demo",
            style="bold green",
        ))

        # --- Performance snapshot ---
        self.show_sprint_performance(sprint)

        # --- CFO report ---
        if self.engine.cfo:
            console.print(Panel(
                Markdown(self.engine.cfo.sprint_report(sprint_number)),
                title="Bill the CFO - Sprint Costs",
                style="yellow",
            ))

        # --- Changelog (mechanical - no agents, before ship so it's in the merge) ---
        self.write_changelog_entry(sprint)

        # --- Ship / scrap ---
        self.ship_or_scrap(sprint_number, lead_dev)

        # --- CEO feedback ---
        console.print("\nWhat do you think? (Your feedback shapes what's next)")
        feedback = Prompt.ask("[bold yellow]CEO[/bold yellow]")

        # --- Retro (secretary consolidates real agent notes) ---
        console.print(Panel("Running retrospective...", style="cyan"))
        retro_summary = self.run_retro(sprint, secretary)
        console.print(Panel(
            Markdown(retro_summary),
            title=f"Retrospective - Sprint {sprint_number}",
            style="cyan",
        ))

        # --- Backlog sweep ---
        swept = self.sweep_to_backlog(sprint)
        if swept:
            console.print(Panel(
                "\n".join(f"  \u2022 {s}" for s in swept),
                title="Backlog Updated",
                style="yellow",
            ))

        # --- Hiring suggestions ---
        self.handle_hire_suggestions(lead_dev, secretary, retro_summary, team)

    # --- Demo ---

    def demo(self, sprint: Sprint, lead_dev: Persona) -> str:
        """Sprint demo: Lead dev presents what was built to the CEO."""
        from odd.provider import StreamEvent, StreamEventType

        project_context = self._build_project_context(sprint.number)

        # Feed Cody the diff summary so he can describe changes accurately.
        diff_context = ""
        diff_summary = self.git.get_sprint_diff_summary(sprint.number) if self.git.available else ""
        if diff_summary:
            diff_context = (
                f"\n\nHere's what changed in the codebase this sprint "
                f"(use this to inform your demo, but do NOT show raw diffs "
                f"to the CEO - explain in plain language):\n\n{diff_summary}\n"
            )

        demo_prompt = (
            f"Sprint {sprint.number} is complete. Prepare a demo for the CEO.\n\n"
            f"Sprint goal: {sprint.goal}\n\n"
            f"Summarize:\n"
            f"1. What was built\n"
            f"2. How it works (brief technical overview)\n"
            f"3. How the CEO can try it out\n"
            f"4. Any known issues or incomplete items\n"
            f"5. Suggested focus for next sprint\n\n"
            f"Run the test suite and include the results."
            f"{diff_context}"
        )

        sprint.status = SprintStatus.DEMO
        self.state.save_sprint(sprint)

        # Use inline streaming (no war room for demo)
        style = self._gate(CEOGate.STREAMING)
        stream_cb: StreamCallback | None = None
        if style == CEOStyle.HANDS_ON:
            def _on_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TEXT_DELTA:
                    console.print(event.text, end="", highlight=False)
                elif event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"\n[dim]  \u21b3 {lead_dev.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
                elif event.event_type == StreamEventType.MESSAGE_STOP:
                    console.print()
            stream_cb = _on_event
        elif style == CEOStyle.BALANCED:
            def _on_summary_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"[dim]  \u21b3 {lead_dev.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
            stream_cb = _on_summary_event

        demo_result = self.engine.invoke(
            persona=lead_dev,
            user_message=demo_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["demo"],
            stream=stream_cb,
            phase="demo",
        )

        return demo_result

    # --- Retro ---

    def run_retro(self, sprint: Sprint, secretary: Persona) -> str:
        """Secretary consolidates agent notes into a retro summary."""
        notes = self.state.load_sprint_notes(sprint.number)
        if not notes:
            return "No agent notes found for this sprint."

        notes_text = "\n\n---\n\n".join(
            f"**{name}:**\n{content}" for name, content in notes.items()
        )

        project_context = self._build_project_context(sprint.number)

        summary = self.engine.invoke(
            persona=secretary,
            user_message=(
                f"Sprint {sprint.number} is complete. Here are the notes each team "
                f"member wrote about their work:\n\n"
                f"{notes_text}\n\n"
                f"Produce a retrospective report:\n"
                f"1. **Key wins** - what went well\n"
                f"2. **Pain points** - what was difficult or went wrong\n"
                f"3. **Action items** - specific changes for next sprint\n"
                f"4. **Team health** - any concerns about workload, skill gaps, or process\n\n"
                f"Save this to .odd/notes/retro_sprint{sprint.number}.md"
            ),
            project_context=project_context,
            phase="demo",
        )

        return summary

    # --- Code review ---

    def maybe_run_code_review(
        self,
        sprint: Sprint,
        lead_dev: Persona,
        sprint_number: int,
        project_context: str,
    ) -> None:
        """Run code review if CEO style and pass count warrant it."""
        from odd.config import CODE_REVIEW_THRESHOLD

        is_milestone = False
        if self.state.has_active_roadmap():
            roadmap = self.state.load_roadmap()
            for rs in roadmap.sprints:
                if rs.number == sprint_number and rs.is_milestone:
                    is_milestone = True
                    break
        review_passes = offer_code_review(
            self.state, sprint_number, lead_dev,
            ceo_style=self._gate(CEOGate.CODE_REVIEW), is_milestone=is_milestone,
        )
        if review_passes <= 0:
            return

        console.print(Panel(f"Running {review_passes}-pass code review...", style="magenta"))
        review = run_code_review(
            self.engine, self.state, self.git,
            sprint, lead_dev, review_passes, project_context,
        )
        if review.final_score is not None:
            score_style = "green" if review.final_score >= CODE_REVIEW_THRESHOLD else "yellow"
            console.print(Panel(
                f"Final score: [{score_style}]{review.final_score}/10[/{score_style}] "
                f"({len(review.passes)} pass{'es' if len(review.passes) != 1 else ''})",
                title="Code Review Complete",
                style="magenta",
            ))

    # --- Ship / scrap ---

    def ship_or_scrap(self, sprint_number: int, lead_dev: Persona) -> None:
        """CEO decides whether to merge or abandon the sprint branch."""
        if self._gate(CEOGate.SHIP_APPROVAL) == CEOStyle.DELEGATOR:
            ship_it = "y"
        else:
            ship_it = Prompt.ask(
                "\n[bold]Ship it?[/bold]",
                choices=["y", "n"],
                default="y",
            )

        if ship_it == "y":
            merge_status = self.merge_sprint_branch(sprint_number, lead_dev)
            if merge_status == "merged":
                console.print("[green]Shipped.[/green]")
            elif merge_status == "deferred":
                console.print(
                    "[yellow]Work preserved on sprint branch - "
                    "merge deferred to next sprint.[/yellow]"
                )
            else:
                console.print("[yellow]No git repo - changes are already on disk.[/yellow]")
        else:
            self.git.abandon_sprint(sprint_number)
            console.print("[yellow]Sprint work shelved. Main branch untouched.[/yellow]")

    # --- Hiring ---

    def handle_hire_suggestions(
        self,
        lead_dev: Persona,
        secretary: Persona,
        retro_summary: str,
        team: dict[str, Persona],
    ) -> None:
        """Cody suggests hires based on the retro; CEO approves/rejects each."""
        hire_suggestions = self.suggest_hires(lead_dev, retro_summary, team)
        if not hire_suggestions:
            return

        from odd.roles import recruit_consultant
        from odd.processes import generate_onboarding_brief

        recruiter = team["recruiter"]
        for suggestion in hire_suggestions:
            final_model = self.approve_hire(suggestion)
            if final_model is None:
                continue

            desc = suggestion["description"]
            quip = compensation_quip(final_model)
            comp_note = f" \u2014 [dim italic]{quip}[/dim italic]" if quip else ""
            console.print(f"[bold]Recruiting ({model_tier_label(final_model)}){comp_note}...[/bold]")
            consultant = recruit_consultant(
                self.engine, recruiter, desc, model_tier=final_model,
            )

            # Persist Cody's reasoning so he remembers why this hire was made
            config = self.state.load_config()
            hire_reason = suggestion.get("reasoning") or desc
            consultant = consultant.model_copy(update={
                "hire_reason": hire_reason,
                "hired_sprint": config.current_sprint,
            })
            self.state.save_persona(consultant)
            console.print(f"[green]\u2713 {consultant.name} is on board![/green]")

            console.print(f"[dim]Generating onboarding brief for {consultant.name}...[/dim]")
            generate_onboarding_brief(
                self.engine, secretary, self.state,
                target_persona=consultant,
            )
            console.print(f"[green]\u2713 {consultant.name} onboarded.[/green]")

    def approve_hire(self, suggestion: dict[str, Any]) -> ModelTier | None:
        """Approve or reject a single hire suggestion based on CEO style."""
        desc = suggestion["description"]
        model = suggestion["model"]
        reasoning = suggestion["reasoning"]

        model_label = model_tier_label(ModelTier.from_name(model))
        reason_text = f" - {reasoning}" if reasoning else ""

        style = self._gate(CEOGate.HIRING)

        if style == CEOStyle.DELEGATOR:
            console.print(f"[dim]Auto-hiring: {desc} ({model_label}){reason_text}[/dim]")
            return ModelTier.from_name(model)

        if style == CEOStyle.BALANCED:
            console.print(
                f"\nCody suggests: [bold]{desc}[/bold] "
                f"({model_label}){reason_text}"
            )
            approve = Prompt.ask("Approve?", choices=["y", "n"], default="y")
            return ModelTier.from_name(model) if approve == "y" else None

        # HANDS_ON: full control - CEO picks model tier
        prompt_text = (
            f"\nCody suggests: [bold]{desc}[/bold] "
            f"({model_label}){reason_text}\n"
            f"Approve? [y/1=Premium/2=Standard/3=Fast/n]"
        )
        approve = Prompt.ask(
            prompt_text,
            choices=["y", "1", "2", "3", "n"],
            default="n",
        )
        if approve == "n":
            return None
        if approve == "y":
            return ModelTier.from_name(model)
        ceo_tier = ModelTier.from_name(resolve_model_choice(approve))
        cody_tier = ModelTier.from_name(model)
        if ceo_tier != cody_tier:
            quip = compensation_quip(ceo_tier, old_tier=cody_tier)
            if quip:
                console.print(f"  [dim italic]{quip}[/dim italic]")
        return ceo_tier

    # --- Standup ---

    def run_standup_with_notes(
        self,
        prev_sprint: Sprint,
        team: dict[str, Persona],
        secretary: Persona,
        prev_notes: dict[str, str],
    ) -> str:
        """Run a standup where each agent gets their own notes from last sprint."""
        project_context = self._build_project_context(prev_sprint.number)
        reports: list[str] = []

        for role_name, persona in team.items():
            if persona.role_type == RoleType.SECRETARY:
                continue

            # Find this agent's notes from last sprint
            agent_slug = persona.name.lower().replace(" ", "_")
            my_notes = prev_notes.get(agent_slug, "")
            notes_context = ""
            if my_notes:
                notes_context = (
                    f"\n\nHere's what you noted at the end of last sprint:\n"
                    f"---\n{my_notes}\n---\n\n"
                )

            report = self.engine.invoke(
                persona=persona,
                user_message=(
                    f"It's standup time. Sprint {prev_sprint.number} is done and "
                    f"we're about to start the next one.{notes_context}"
                    f"Briefly report:\n"
                    f"1. What you accomplished\n"
                    f"2. Anything carrying over or unresolved\n"
                    f"3. Any concerns for the upcoming sprint\n\n"
                    f"Keep it concise."
                ),
                project_context=project_context,
                tools=False,
            )
            reports.append(f"**{persona.name}:**\n{report}")
            console.print(Panel(Markdown(report), title=persona.name, style="cyan"))

        # Secretary summarizes
        all_reports = "\n".join(reports)
        summary = self.engine.invoke(
            persona=secretary,
            user_message=(
                f"Here are the standup reports:\n\n{all_reports}\n\n"
                f"Produce a brief structured summary: key highlights, carryover items, "
                f"and anything the upcoming sprint should account for."
            ),
            project_context=project_context,
            tools=False,
        )

        return summary

    # --- Backlog ---

    def sweep_to_backlog(self, sprint: Sprint) -> list[str]:
        """Move failed tasks to backlog, complete matched items."""
        backlog = Backlog(self.state.odd_dir)
        messages: list[str] = []

        for task in sprint.tasks:
            if task.status == TaskStatus.FAILED:
                item = backlog.add(
                    description=f"[From Sprint {sprint.number}] {task.description}",
                    priority=Priority.HIGH,
                    added_by="system",
                )
                messages.append(f"Failed task \u2192 backlog: {task.description}")

        # Mark backlog items assigned to this sprint as done
        for item in backlog.sprint_items(sprint.number):
            if item.status == "in_sprint":
                item.status = "done"
        backlog.save()

        completed = len([t for t in sprint.tasks if t.status == TaskStatus.DONE])
        failed = len([t for t in sprint.tasks if t.status == TaskStatus.FAILED])
        if completed:
            messages.insert(0, f"{completed} task(s) completed")
        if failed:
            messages.append(f"{failed} task(s) moved to backlog")

        return messages

    # --- Hire suggestions ---

    def suggest_hires(
        self,
        lead_dev: Persona,
        retro_summary: str,
        team: dict[str, Persona],
    ) -> list[dict[str, str]]:
        """Cody analyzes skill gaps and suggests hires."""
        roster = "\n".join(
            f"  - {p.name}: {p.title}" for p in team.values()
        )

        response = self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"Sprint retrospective summary:\n{retro_summary}\n\n"
                f"Current team:\n{roster}\n\n"
                f"Based on this sprint, are there any genuine skill gaps on the team "
                f"that slowed us down or produced lower quality work? Only suggest a "
                f"hire if there's a specific, concrete gap - not a nice-to-have.\n\n"
                f"For each suggestion, also recommend a model tier based on the "
                f"complexity of work they'll do:\n"
                f"  - opus: deep reasoning, architecture, complex design\n"
                f"  - sonnet: solid implementation, standard engineering tasks\n"
                f"  - haiku: simple/repetitive tasks, boilerplate, formatting\n\n"
                f"Use the submit_hire_suggestion tool to submit your suggestions "
                f"(pass an empty suggestions array if no hires are needed).\n\n"
                f"Fallback format (if you can't use the tool):\n"
                f"HIRE: <specific expertise description>\n"
                f"MODEL: <opus|sonnet|haiku> - <one-line reasoning>\n\n"
                f"If no hires are needed, just say NONE."
            ),
            tools=False,
            extra_tools=[SUBMIT_HIRE_SUGGESTION],
            phase="demo",
        )

        # Check for structured submission, fall back to string parsing
        hire_subs = self.engine.pop_submissions("submit_hire_suggestion")
        structured = hire_subs[0]["data"] if hire_subs else None

        if structured is not None:
            return parse_hire_suggestions(response, structured_data=structured)

        if "NONE" in response.upper() and "HIRE:" not in response.upper():
            return []

        return parse_hire_suggestions(response)

    # --- Git merge ---

    def merge_sprint_branch(
        self,
        sprint_number: int,
        lead_dev: Persona,
    ) -> str:
        """Merge the sprint branch into main. Handles conflicts internally.

        Returns:
            "merged"   - merge succeeded, code is on main.
            "deferred" - merge failed, work preserved on sprint branch.
            "no_git"   - git unavailable, no-op.
        """
        if not self.git.available:
            return "no_git"

        try:
            self.git.merge_sprint(sprint_number)
            return "merged"
        except MergeConflictError as e:
            console.print(Panel(
                "Team is resolving a technical issue...",
                style="dim",
            ))

            # Let Cody resolve the conflicts
            project_context = self._build_project_context(sprint_number)
            conflict_files = "\n".join(f"  - {f}" for f in e.conflicting_files)

            self.engine.invoke(
                persona=lead_dev,
                user_message=(
                    f"There are merge conflicts in the following files:\n"
                    f"{conflict_files}\n\n"
                    f"Resolve each conflict by reading the file, choosing the "
                    f"correct version (or combining both), and editing the file "
                    f"to remove all conflict markers (<<<<<<, ======, >>>>>>).\n\n"
                    f"After resolving all conflicts, verify the code still works."
                ),
                project_context=project_context,
                phase="review",
            )

            # Try to complete the merge
            if self.git.resolve_conflicts_and_commit(sprint_number):
                return "merged"

            # If still broken, escalate to CEO
            self.git.abort_merge()
            self.git.ensure_on_sprint_branch(sprint_number)
            console.print(Panel(
                "[bold red]The team couldn't resolve a merge issue automatically.[/bold red]\n"
                "Your sprint work is preserved on a separate branch.\n"
                "The team will address this in the next sprint.",
                style="red",
            ))
            return "deferred"

    # --- Test change requests ---

    def handle_test_change_requests(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        *,
        cwd=None,
    ) -> list[dict[str, Any]]:
        """Route test change requests to Vera and return structured outcomes."""
        requests = self.engine.pop_submissions("submit_test_change_request")

        if not requests:
            return []

        qa = team.get("qa")
        if not qa:
            console.print("[red]No QA agent available to review test change requests.[/red]")
            return []

        outcomes: list[dict[str, Any]] = []

        for req in requests:
            outcome = self.review_single_test_change(
                req["data"], qa, project_context, cwd=cwd,
            )
            outcomes.append(outcome)

        return outcomes

    def review_single_test_change(
        self,
        data: dict[str, Any],
        qa: Persona,
        project_context: str,
        *,
        cwd=None,
    ) -> dict[str, Any]:
        """Have Vera review a single test change request in adversarial mode."""
        from odd.provider import StreamEvent, StreamEventType

        console.print(Panel(
            f"**Test file**: {data['test_file']}\n\n"
            f"**Reason**: {data['reason']}\n\n"
            f"**Proposed change**: {data['proposed_change']}",
            title="Test Change Request \u2192 Vera",
            style="yellow",
        ))
        console.print(
            f"[yellow]\u26a0 CEO: An implementation agent has requested changes to "
            f"{data['test_file']}. Vera is reviewing.[/yellow]"
        )

        review_prompt = (
            f"\u26a0\ufe0f ADVERSARIAL REVIEW MODE \u26a0\ufe0f\n\n"
            f"An implementation agent wants to change YOUR tests. Treat this "
            f"request with maximum skepticism - the most common reason agents "
            f"request test changes is because their implementation is wrong, "
            f"not your tests.\n\n"
            f"**Test file**: {data['test_file']}\n"
            f"**Their claimed reason**: {data['reason']}\n"
            f"**Their proposed change**: {data['proposed_change']}\n\n"
            f"Your job:\n"
            f"1. Read the test file and the relevant implementation code.\n"
            f"2. Determine: is the TEST wrong, or is the IMPLEMENTATION wrong?\n"
            f"3. Check if the proposed change would reduce coverage or weaken "
            f"assertions (e.g. assertEqual \u2192 assertAlmostEqual, removing edge "
            f"case tests, loosening expected values).\n"
            f"4. Only modify the test if it has an actual defect (wrong expected "
            f"value, testing an obsolete interface, etc.).\n"
            f"5. If the test is correct, do NOT change it. Explain why the "
            f"implementation needs to conform to the test, not vice versa.\n\n"
            f"BIAS: When in doubt, keep the test as-is. The burden of proof is "
            f"on the implementation agent.\n\n"
            f"After your review, you MUST use the submit_test_review_decision "
            f"tool to formally record your verdict (accept or reject)."
        )

        # Build inline stream callback
        style = self._gate(CEOGate.STREAMING)
        stream_cb = None
        if style == CEOStyle.HANDS_ON:
            def _on_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TEXT_DELTA:
                    console.print(event.text, end="", highlight=False)
                elif event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"\n[dim]  \u21b3 {qa.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
                elif event.event_type == StreamEventType.MESSAGE_STOP:
                    console.print()
            stream_cb = _on_event
        elif style == CEOStyle.BALANCED:
            def _on_summary(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"[dim]  \u21b3 {qa.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
            stream_cb = _on_summary

        self.engine.invoke(
            persona=qa,
            user_message=review_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS.get("qa", 16384),
            extra_tools=[SUBMIT_TEST_REVIEW_DECISION],
            stream=stream_cb,
            phase="review",
        )

        # Capture Vera's structured decision
        verdict_subs = self.engine.pop_submissions("submit_test_review_decision")

        if verdict_subs:
            decision = verdict_subs[0]["data"]
            verdict = decision.get("verdict", "reject")
            reason = decision.get("reason", "")
            test_file = decision.get("test_file", data["test_file"])
        else:
            verdict = "reject"
            reason = "No formal verdict submitted; defaulting to rejection."
            test_file = data["test_file"]

        tests_pass = False
        if verdict == "accept":
            tests_pass, _ = self.tdd.run_tests(cwd=cwd)
            status_msg = "tests passing" if tests_pass else "tests still failing"
            console.print(
                f"[green]Vera accepted the change to {test_file} "
                f"({status_msg}).[/green]"
            )
        else:
            console.print(
                f"[red]Vera rejected the change to {test_file}: {reason}[/red]"
            )

        return {
            "verdict": verdict,
            "reason": reason,
            "test_file": test_file,
            "tests_pass": tests_pass,
        }

    # --- Dependency requests ---

    def handle_dependency_requests(
        self,
        team: dict[str, Persona],
        project_context: str,
    ) -> None:
        """Route dependency requests to the CEO for approval."""
        requests = self.engine.pop_submissions("submit_dependency_request")

        if not requests:
            return

        # Flatten all dependency items from all requests
        all_deps: list[dict] = []
        for req in requests:
            all_deps.extend(req["data"].get("dependencies", []))

        if not all_deps:
            return

        # Present to CEO
        console.print(Panel(
            "[bold]Dependency Request[/bold]\n\n"
            "An agent needs the following dependencies installed:",
            style="yellow",
        ))

        for i, dep in enumerate(all_deps, 1):
            console.print(
                f"  [bold]{i}.[/bold] [cyan]{dep['package']}[/cyan] "
                f"({dep.get('ecosystem', 'pip')})\n"
                f"     {dep.get('description', '(no description)')}\n"
                f"     [dim]Why: {dep.get('reason', '(no reason given)')}[/dim]"
            )

        console.print()
        choice = Prompt.ask(
            "[bold yellow]CEO[/bold yellow]: Approve dependencies?",
            choices=["all", "none", "pick"],
            default="none",
        )

        approved: list[dict] = []
        if choice == "all":
            approved = list(all_deps)
        elif choice == "pick":
            for i, dep in enumerate(all_deps, 1):
                dep_choice = Prompt.ask(
                    f"  [{i}] {dep['package']} ({dep.get('ecosystem', 'pip')})?",
                    choices=["y", "n"],
                    default="n",
                )
                if dep_choice == "y":
                    approved.append(dep)

        if not approved:
            console.print("[yellow]No dependencies approved.[/yellow]")
            return

        # Cody installs approved dependencies
        lead_dev = team.get("lead_dev")
        if not lead_dev:
            console.print("[red]No lead dev available to install dependencies.[/red]")
            return

        for dep in approved:
            pkg = dep["package"]
            if not _SAFE_PACKAGE_RE.match(pkg):
                console.print(
                    f"[red]\u2717 Rejected '{pkg}' - invalid package name. "
                    f"Package names must be alphanumeric with hyphens/dots only. "
                    f"No flags, URLs, or special characters.[/red]"
                )
                return

        # Group by ecosystem
        pip_deps = [d["package"] for d in approved if d.get("ecosystem") == "pip"]
        npm_deps = [d["package"] for d in approved if d.get("ecosystem") == "npm"]

        # Build install commands as explicit argv lists
        install_jobs: list[tuple[str, list[str]]] = []
        if pip_deps:
            install_jobs.append(("pip", ["pip", "install"] + pip_deps))
        if npm_deps:
            install_jobs.append(("npm", ["npm", "install"] + npm_deps))

        any_failed = False
        for label, argv in install_jobs:
            resolved = _resolve_argv(argv)
            console.print(f"[green]Installing ({label}): {' '.join(argv[2:])}[/green]")
            try:
                result = subprocess.run(
                    resolved,
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=120,
                    cwd=self.state.root,
                )
                if result.returncode == 0:
                    console.print(f"[green]\u2713 Installed successfully[/green]")
                else:
                    any_failed = True
                    console.print(
                        f"[red]\u2717 Installation failed:[/red]\n{result.stderr[:500]}"
                    )
            except FileNotFoundError:
                any_failed = True
                console.print(
                    f"[red]\u2717 Command not found: {argv[0]}. "
                    f"Is {label} installed on this machine?[/red]"
                )
            except subprocess.TimeoutExpired:
                any_failed = True
                console.print(f"[red]\u2717 Installation timed out[/red]")

        names = ", ".join(d["package"] for d in approved)
        if any_failed:
            console.print(
                f"[red]Some dependencies failed to install: {names}[/red]\n"
                f"[yellow]Agents may not be able to pass tests until this is resolved.[/yellow]"
            )
        else:
            console.print(f"[green]Dependencies installed: {names}[/green]")

