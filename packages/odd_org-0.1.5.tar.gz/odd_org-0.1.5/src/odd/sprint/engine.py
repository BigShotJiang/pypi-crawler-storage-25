"""Sprint cycle engine - orchestrates the agile process.

SprintEngine is a thin orchestrator that wires collaborator objects together
and drives the sprint lifecycle (run_sprint, run_full_sprint, resume_sprint).

Collaborators (each independently testable):
- briefing.py      - SprintBriefing accumulator
- planner.py       - SprintPlanner (roadmap / sprint / phase planning)
- tdd_gate.py      - TDDGate (test/retry loop, escalations)
- phase_runner.py  - PhaseRunner (parallel worktree execution)
- wrapup.py        - SprintWrapup (demo, retro, ship, hire)
- vacation_runner.py - VacationRunner (autonomous vacation lifecycle)
"""

from __future__ import annotations

import datetime
import json
import re
import subprocess
from collections.abc import Generator
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable

from rich.panel import Panel
from rich.markdown import Markdown

from odd.agent import AgentEngine
from odd.backlog import Backlog
from odd.config import (
    PHASE_TOKEN_DEFAULTS,
    GIT_COMMAND_TIMEOUT,
)
from odd.display import (
    AgentOutputStream, AgentStatus, WarRoom,
    format_tool_result_line, format_tool_summary,
)
from odd.labels import escalation_label, escalation_style
from odd.provider import StreamCallback, StreamEvent, StreamEventType
from odd.git import GitManager
from odd.models import (
    CEOGate,
    CEOStyle,
    Persona,
    ProjectConfig,
    RoleType,
    Sprint,
    SprintCheckpoint,
    SprintPhase,
    SprintStatus,
    TaskStatus,
)
from odd.state import StateManager
from odd.sprint._console import console, _tprint  # noqa: F401

# Re-export for external consumers
from odd.sprint.briefing import SprintBriefing  # noqa: F401
from odd.sprint.tdd_gate import TDDGate  # noqa: F401
from odd.sprint.phase_runner import PhaseRunner  # noqa: F401
from odd.sprint.planner import SprintPlanner  # noqa: F401
from odd.sprint.wrapup import SprintWrapup  # noqa: F401
from odd.sprint.vacation_runner import VacationRunner, VacationPausedError  # noqa: F401


class SprintEngine:
    """Manages the lifecycle of a sprint."""

    def __init__(
        self,
        engine: AgentEngine,
        state: StateManager,
        git: GitManager | None = None,
        streaming: bool = True,
    ):
        self.engine = engine
        self.state = state
        self.git = git or GitManager(state.root)
        self.streaming = streaming
        self._consultant_cache: list[Persona] | None = None

        # Load config for CEO style resolution (default + per-gate overrides)
        try:
            self._config: ProjectConfig = state.load_config()
        except Exception:
            self._config = ProjectConfig(name="fallback", ceo_style=CEOStyle.BALANCED)

        # Collaborators
        self.tdd = TDDGate(state=state, gate=self.gate, main_engine=engine)
        self.phase_runner = PhaseRunner(
            git=self.git,
            engine=engine,
            tdd=self.tdd,
            gate=self.gate,
            streaming=streaming,
            resolve_agent=self._resolve_agent,
            build_phase_context=self._build_phase_context,
            make_war_room_callback=self._make_war_room_callback,
            make_tool_result_callback=self._make_tool_result_callback,
        )
        self.planner = SprintPlanner(
            state=state,
            engine=engine,
            build_project_context=self._build_project_context,
        )
        self.wrapup = SprintWrapup(
            state=state,
            engine=engine,
            get_git=lambda: self.git,
            tdd=self.tdd,
            gate=self.gate,
            build_project_context=self._build_project_context,
            get_phase_diff_stat=self._get_phase_diff_stat,
        )
        self.vacation = VacationRunner(
            state=state,
            engine=engine,
            git=self.git,
            planner=self.planner,
            wrapup=self.wrapup,
            build_project_context=self._build_project_context,
            run_sprint=self.run_sprint,
        )

    def gate(self, g: CEOGate) -> CEOStyle:
        """Resolve effective CEO style for a specific decision gate."""
        return self._config.style_at(g)

    # --- Streaming helpers ---

    def _make_stream_callback(self, agent_name: str) -> StreamCallback | None:
        """Build a Rich-based streaming callback for an agent, or None if disabled."""
        if not self.streaming:
            return None

        style = self.gate(CEOGate.STREAMING)

        if style == CEOStyle.DELEGATOR:
            return None

        if style == CEOStyle.BALANCED:
            def _on_summary_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"[dim]  ↳ {agent_name} → {event.tool_name}[/dim]",
                        highlight=False,
                    )
            return _on_summary_event

        # HANDS_ON: full streaming
        _last_was_text = False

        def _on_event(event: StreamEvent) -> None:
            nonlocal _last_was_text
            if event.event_type == StreamEventType.TEXT_DELTA:
                console.print(event.text, end="", highlight=False)
                _last_was_text = True
            elif event.event_type == StreamEventType.TOOL_USE_START:
                prefix = "\n" if _last_was_text else ""
                console.print(
                    f"{prefix}[dim]  ↳ {agent_name} → {event.tool_name}[/dim]",
                    highlight=False,
                )
                _last_was_text = False
            elif event.event_type == StreamEventType.MESSAGE_STOP:
                console.print()
                _last_was_text = False

        return _on_event

    def _make_war_room_callback(
        self, stream: AgentOutputStream,
    ) -> StreamCallback | None:
        """Build a StreamCallback that feeds into an AgentOutputStream."""
        style = self.gate(CEOGate.WAR_ROOM)

        if style == CEOStyle.DELEGATOR:
            return None

        if style == CEOStyle.BALANCED:
            # BALANCED: suppress text output, tool activity comes
            # through on_tool_result callback instead.
            return stream.as_summary_callback()

        # HANDS_ON: full streaming (text deltas only - tool calls
        # are shown via the on_tool_result callback with ✓/✗ status)
        return stream.as_stream_callback()

    def _make_tool_result_callback(
        self, stream: AgentOutputStream | None,
    ) -> Callable[[str, dict, str], None] | None:
        """Build an on_tool_result callback that feeds the War Room.

        Shows what actually happened on disk after each tool execution,
        e.g. '✓ Write src/app.py (312 chars)' or '✗ Write ../../evil - blocked'.
        """
        if stream is None:
            return None
        style = self.gate(CEOGate.WAR_ROOM)
        if style == CEOStyle.DELEGATOR:
            return None

        def _on_result(tool_name: str, tool_input: dict, result: str) -> None:
            line = format_tool_result_line(tool_name, tool_input, result)
            stream.append(line + "\n")

        return _on_result

    @contextmanager
    def _war_room_context(
        self, agent_names: list[str],
    ) -> Generator[dict[str, AgentOutputStream], None, None]:
        """Context manager that starts/stops a War Room for the given agents."""
        active = (
            self.gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR
            and self.streaming
        )
        streams: dict[str, AgentOutputStream] = {}
        war_room: WarRoom | None = None

        if active:
            stream_list: list[AgentOutputStream] = []
            for name in agent_names:
                aos = AgentOutputStream(name)
                aos.status = AgentStatus.WORKING
                streams[name] = aos
                stream_list.append(aos)
            war_room = WarRoom(stream_list, console=console)
            war_room.start()

        try:
            yield streams
        finally:
            if active:
                for aos in streams.values():
                    if aos.status == AgentStatus.WORKING:
                        aos.status = AgentStatus.DONE
            if war_room:
                war_room.stop()

    # --- Git utilities ---

    def _get_diff_stat(self) -> str:
        """Get git diff --stat for recent uncommitted + committed changes."""
        if not self.git.available:
            return ""
        try:
            result = subprocess.run(
                ["git", "diff", "--stat", "HEAD"],
                capture_output=True,
                text=True,
                timeout=GIT_COMMAND_TIMEOUT,
                cwd=self.state.root,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ""

    def _get_phase_diff_stat(self, sprint_number: int) -> str:
        """Get git diff --stat for all changes on the sprint branch vs main."""
        if not self.git.available:
            return ""
        return self.git.get_sprint_diff_summary(sprint_number)

    # --- Core sprint lifecycle ---

    def run_sprint(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
    ) -> Sprint:
        """Execute the sprint: QA writes tests (overlapping with phase planning),
        then phases execute sequentially with parallel tasks within each phase.
        """
        sprint.status = SprintStatus.IN_PROGRESS
        self._consultant_cache = None
        project_context = self._build_project_context(sprint.number)
        notes_path = f".odd/sprints/sprint_{sprint.number}/notes"
        briefing = SprintBriefing(sprint.number, sprint.goal)

        sprint, test_context = self._run_qa_phase(
            sprint, team, project_context, notes_path, briefing,
        )

        sprint.checkpoint = SprintCheckpoint(
            stage="qa",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[],
            test_context=test_context,
        )
        self.state.save_sprint(sprint)

        self._run_implementation_phases(
            sprint, team, project_context, notes_path, test_context, briefing,
        )

        sprint.status = SprintStatus.REVIEW
        self.state.save_sprint(sprint)
        return sprint

    def resume_sprint(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
    ) -> Sprint:
        """Resume a sprint from its last checkpoint."""
        checkpoint = sprint.checkpoint
        if not checkpoint:
            return self.run_sprint(sprint, team)

        # Planning done but QA hasn't run yet - restart from QA onward.
        if checkpoint.stage == "planning":
            return self.run_sprint(sprint, team)

        # Review already done - nothing left for resume to do.
        if checkpoint.stage == "review":
            sprint.status = SprintStatus.REVIEW
            self.state.save_sprint(sprint)
            return sprint

        sprint.status = SprintStatus.IN_PROGRESS
        self._consultant_cache = None
        project_context = self._build_project_context(sprint.number)
        notes_path = f".odd/sprints/sprint_{sprint.number}/notes"
        briefing = SprintBriefing(sprint.number, sprint.goal)
        briefing.after_planning(sprint.tasks, sprint.phases)

        test_context = checkpoint.test_context or ""
        if not test_context:
            test_files = self.tdd.discover_test_files()
            test_names = self.tdd.collect_test_names()
            _, test_output = self.tdd.run_tests()
            if test_files:
                test_context = (
                    f"\n\nQA has written these test files:\n"
                    + "\n".join(f"  - {f}" for f in test_files)
                )
                if test_names:
                    test_context += "\n\nTest names (via pytest --collect-only):\n"
                    test_context += "\n".join(f"  - {n}" for n in test_names)
                test_context += f"\n\nBaseline test output:\n```\n{test_output[:2000]}\n```"

        completed_phase_nums: set[int] = set()
        if checkpoint.stage.startswith("phase_"):
            try:
                last_done = int(checkpoint.stage.split("_", 1)[1])
                completed_phase_nums = set(range(1, last_done + 1))
            except (ValueError, IndexError):
                pass

        remaining_phases = [
            p for p in sprint.phases if p.number not in completed_phase_nums
        ]

        if remaining_phases:
            console.print(Panel(
                f"[bold]Resuming Sprint {sprint.number}[/bold]\n"
                f"Skipping {len(completed_phase_nums)} completed phase(s), "
                f"{len(remaining_phases)} remaining.",
                style="bold green",
            ))
            self._run_implementation_phases_subset(
                sprint, team, project_context, notes_path,
                test_context, briefing, remaining_phases,
            )

        sprint.status = SprintStatus.REVIEW
        self.state.save_sprint(sprint)
        return sprint

    def _run_implementation_phases_subset(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str,
        briefing: SprintBriefing,
        phases: list[SprintPhase],
    ) -> None:
        """Execute a subset of implementation phases (used by resume)."""
        lead_dev = team["lead_dev"]
        task_map = {t.id: t for t in sprint.tasks}

        for phase in phases:
            phase_tasks = [task_map[tid] for tid in phase.task_ids if tid in task_map]
            if not phase_tasks:
                continue

            console.print(Panel(
                f"[bold]Phase {phase.number}[/bold]: {phase.description}",
                style="green",
            ))

            parallel_engines: dict[str, Any] | None = None
            if len(phase_tasks) == 1:
                agent = self._resolve_agent(phase_tasks[0].assigned_to, team) or team["lead_dev"]
                phase_context = self._build_phase_context(
                    project_context, briefing, agent.name,
                )
                self._run_task(
                    phase_tasks[0], sprint, team, phase_context, notes_path,
                    test_context=test_context,
                )
            else:
                parallel_engines = self.phase_runner.run_phase_parallel(
                    phase_tasks, sprint, team, project_context, notes_path,
                    test_context=test_context,
                    briefing=briefing,
                )
                conflicts = self.git.merge_task_branches(
                    sprint.number, [t.id for t in phase_tasks],
                )
                merge_context = self._build_phase_context(
                    project_context, briefing, lead_dev.name,
                )
                if conflicts:
                    self.phase_runner.resolve_phase_conflicts(
                        lead_dev, sprint, phase, conflicts, merge_context,
                    )
                self.git.cleanup_task_branches(
                    sprint.number, [t.id for t in phase_tasks],
                )
                self.wrapup.handle_test_change_requests(sprint, team, merge_context)
                self.wrapup.handle_dependency_requests(team, merge_context)

                # Surface any escalations that were queued during parallel execution
                self._handle_post_phase_escalations(
                    phase, team, project_context, briefing,
                )

            self._capture_phase_results(phase, phase_tasks, sprint, team, briefing)

            sprint.checkpoint = SprintCheckpoint(
                stage=f"phase_{phase.number}",
                completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                completed_task_ids=[t.id for t in sprint.tasks if t.status == TaskStatus.DONE],
            )
            self.state.save_sprint(sprint)

    def _handle_post_phase_escalations(
        self,
        phase: SprintPhase,
        team: dict[str, Persona],
        project_context: str,
        briefing: SprintBriefing,
    ) -> None:
        """Interactively handle escalations queued during parallel execution.

        Called on the main thread after a parallel phase completes.
        Escalations were forwarded to self.engine.escalations by the
        PhaseRunner — now the CEO gets to act on them.
        """
        import odd.sprint as _sprint_pkg
        _Prompt = _sprint_pkg.Prompt

        escalations = self.engine.get_escalations()
        if not escalations:
            return

        console.print(Panel(
            f"[bold]Phase {phase.number} complete[/bold] — "
            f"{len(escalations)} escalation(s) need your attention.",
            style="yellow",
        ))

        for esc in escalations:
            agent_name = esc.get("agent_name", "Unknown")
            severity = esc["severity"]
            reason = esc["reason"]

            console.print(Panel(
                f"[bold]{agent_name}[/bold] - {escalation_label(severity)}:\n\n{reason}",
                title="Escalation",
                style=escalation_style(severity),
            ))

            if severity == "command_request":
                command = esc.get("command", "")
                console.print(f"\n  [bold]Command:[/bold] [cyan]{command}[/cyan]")
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow]",
                    choices=["approve", "deny"],
                    default="approve",
                )
                if ceo_response == "approve":
                    from odd.sprint.tdd_gate import _run_approved_command
                    output = _run_approved_command(command, self.state.root)
                    console.print(Panel(
                        output[:2000] + ("..." if len(output) > 2000 else ""),
                        title=f"Output: {command}",
                        style="dim",
                    ))
                else:
                    console.print("[yellow]Denied.[/yellow]")

            elif severity == "needs_decision":
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow]",
                    choices=["skip", "noted"],
                    default="noted",
                )

            elif severity == "blocker":
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow] (your input needed)"
                )

    def _run_qa_phase(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        briefing: SprintBriefing,
    ) -> tuple[Sprint, str]:
        """QA writes tests, optionally concurrent with phase planning."""
        qa = team["qa"]
        lead_dev = team["lead_dev"]

        console.print(Panel("QA is writing tests (TDD)...", style="red"))

        task_count = len(sprint.tasks)
        eco = self._detect_ecosystem()
        test_prompt = (
            f"Sprint {sprint.number} goal: {sprint.goal}\n\n"
            f"Here are the planned tasks:\n"
        )
        for task in sprint.tasks:
            test_prompt += f"- {task.description} (assigned to: {task.assigned_to})\n"
        test_prompt += (
            "\nWrite focused tests for these features BEFORE they are "
            f"implemented. {eco['test_directive']} "
            "The tests should define what 'done' looks like for each task.\n\n"
            "SCOPE CONSTRAINTS - stay lean:\n"
            f"- Write at most {max(1, task_count)} test file(s) \u2014 "
            "group related tasks into a single file when possible.\n"
            "- Each file should be under 100 lines. Focus on the core "
            "contract: happy path + 1-2 critical edge cases per task.\n"
            "- Do NOT exhaustively test every permutation, error path, or "
            "boundary condition. You can expand coverage in later sprints.\n"
            "- Prefer simple, readable assertions over elaborate fixtures.\n\n"
            f"When you're done writing all the tests, write a brief note about "
            f"what you tested, your coverage strategy, and any concerns to "
            f"{notes_path}/qa.md"
        )

        if not sprint.phases:
            qa_engine = self.engine.fork()
            phase_engine = self.engine.fork()
            with self._war_room_context([qa.name, lead_dev.name]) as streams:
                qa_cb = self._make_war_room_callback(streams[qa.name]) if streams else None
                ld_cb = self._make_war_room_callback(streams[lead_dev.name]) if streams else None
                qa_tool_cb = self._make_tool_result_callback(streams.get(qa.name)) if streams else None
                ld_tool_cb = self._make_tool_result_callback(streams.get(lead_dev.name)) if streams else None
                with ThreadPoolExecutor(max_workers=2) as pool:
                    qa_future = pool.submit(
                        qa_engine.invoke,
                        persona=qa, user_message=test_prompt,
                        project_context=project_context,
                        max_tokens=PHASE_TOKEN_DEFAULTS["qa"],
                        stream=qa_cb, phase="qa",
                        on_tool_result=qa_tool_cb,
                    )
                    phase_future = pool.submit(
                        self.planner.plan_phases_with_engine, phase_engine, lead_dev, sprint,
                        stream=ld_cb,
                    )
                    qa_future.result()
                    sprint = phase_future.result()
            self.engine.escalations.extend(qa_engine.get_escalations())
            self.engine.escalations.extend(phase_engine.get_escalations())
            self.engine.submissions.extend(qa_engine.get_submissions())
            self.engine.submissions.extend(phase_engine.get_submissions())
        else:
            with self._war_room_context([qa.name]) as streams:
                if streams:
                    qa_stream = self._make_war_room_callback(streams[qa.name])
                    qa_tool_cb = self._make_tool_result_callback(streams[qa.name])
                else:
                    qa_stream = self._make_stream_callback(qa.name)
                    qa_tool_cb = None
                self.engine.invoke(
                    persona=qa, user_message=test_prompt,
                    project_context=project_context,
                    max_tokens=PHASE_TOKEN_DEFAULTS["qa"],
                    stream=qa_stream, phase="qa",
                    on_tool_result=qa_tool_cb,
                )

        console.print("[red]QA has written the test suite.[/red]")

        briefing.after_planning(sprint.tasks, sprint.phases)

        test_files = self.tdd.discover_test_files()
        test_names = self.tdd.collect_test_names()
        test_passed, test_output = self.tdd.run_tests()
        if test_files:
            console.print(f"[dim]  Test files: {', '.join(test_files)}[/dim]")
            if test_names:
                console.print(f"[dim]  Tests collected: {len(test_names)}[/dim]")
            status = "[green]passing[/green]" if test_passed else "[yellow]failing (expected - TDD)[/yellow]"
            console.print(f"[dim]  Baseline: {status}[/dim]")

        briefing.after_qa(test_files, test_names, test_output)

        test_context = ""
        if test_files:
            test_context = (
                f"\n\nQA has written these test files:\n"
                + "\n".join(f"  - {f}" for f in test_files)
            )
            if test_names:
                test_context += "\n\nTest names (via pytest --collect-only):\n"
                test_context += "\n".join(f"  - {n}" for n in test_names)
            test_context += f"\n\nBaseline test output:\n```\n{test_output[:2000]}\n```"

        return sprint, test_context

    def _run_implementation_phases(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str,
        briefing: SprintBriefing,
    ) -> None:
        """Execute implementation phases sequentially, with parallel tasks within each."""
        self._run_implementation_phases_subset(
            sprint, team, project_context, notes_path,
            test_context, briefing, sprint.phases,
        )

    def _capture_phase_results(
        self, phase, phase_tasks, sprint, team, briefing,
    ) -> None:
        """Run post-phase tests and capture results into the briefing."""
        consultant_tasks = []
        core_outcomes = []
        for t in phase_tasks:
            agent = self._resolve_agent(t.assigned_to, team)
            if agent and agent.role_type == RoleType.CONSULTANT:
                consultant_tasks.append((t, agent))
            else:
                core_outcomes.append((t.id, t.description, t.status))

        phase_passed, phase_test_output = self.tdd.run_tests()
        phase_test_summary = ""
        if phase_test_output.strip():
            phase_test_summary = phase_test_output.strip().splitlines()[-1]
        phase_diff = self._get_phase_diff_stat(sprint.number)

        briefing.after_phase(phase.number, core_outcomes, phase_test_summary, phase_diff)

        for t, agent in consultant_tasks:
            task_diff = self.git.get_task_diff_stat(sprint.number, t.id)
            briefing.after_consultant_task(
                agent.name, t.description, t.status, task_diff or phase_diff,
            )

        self.state.save_sprint(sprint)

    def _run_task(
        self, task, sprint, team, project_context, notes_path, test_context="",
    ) -> None:
        """Run a single task on the current branch (no worktree)."""
        task.status = TaskStatus.IN_PROGRESS
        agent = self._resolve_agent(task.assigned_to, team)
        if not agent:
            console.print("[dim]Cody is picking this one up.[/dim]")
            agent = team["lead_dev"]

        console.print(Panel(f"{agent.name} is working on: {task.description}", style="green"))

        impl_prompt = self.tdd.build_impl_prompt(
            sprint.number, task.description, test_context, notes_path, agent.name,
        )

        with self._war_room_context([agent.name]) as streams:
            if streams:
                stream_cb = self._make_war_room_callback(streams[agent.name])
                tool_cb = self._make_tool_result_callback(streams[agent.name])
            else:
                stream_cb = self._make_stream_callback(agent.name)
                tool_cb = None
            self.tdd.execute(
                engine=self.engine, agent=agent, task=task, sprint=sprint,
                impl_prompt=impl_prompt, project_context=project_context,
                team=team, stream_cb=stream_cb, interactive=True,
                on_test_change_requests=self.wrapup.handle_test_change_requests,
                on_dependency_requests=self.wrapup.handle_dependency_requests,
                on_tool_result=tool_cb,
            )

    def _build_phase_context(self, project_context, briefing, agent_name):
        """Build agent-scoped project context with filtered briefing."""
        briefing_text = briefing.render_for_agent(agent_name)
        if briefing_text:
            return project_context + "\n\n" + briefing_text
        return project_context

    # --- Standup ---

    def run_standup(self, sprint, team, secretary):
        """Mechanical sprint status dashboard - no LLM calls."""
        task_lines: list[str] = []
        done = failed = pending = 0
        for t in sprint.tasks:
            marker = {TaskStatus.DONE: "\u2713", TaskStatus.FAILED: "\u2717", TaskStatus.IN_PROGRESS: "\u29d6"}.get(t.status, "\u25cb")
            task_lines.append(f"  {marker} {t.id}: {t.description} ({t.status.value})")
            if t.status == TaskStatus.DONE:
                done += 1
            elif t.status == TaskStatus.FAILED:
                failed += 1
            else:
                pending += 1

        test_passed, test_output = self.tdd.run_tests()
        test_summary = ""
        if test_output.strip():
            test_summary = test_output.strip().splitlines()[-1]

        diff_stat = self._get_phase_diff_stat(sprint.number)

        parts = [
            f"# Sprint {sprint.number} Status",
            f"**Goal**: {sprint.goal}",
            f"\n**Tasks**: {done} done, {failed} failed, {pending} remaining",
        ]
        if task_lines:
            parts.append("\n".join(task_lines))
        if test_summary:
            status_label = "passing" if test_passed else "failing"
            parts.append(f"\n**Tests** ({status_label}): {test_summary}")
        if diff_stat:
            parts.append(f"\n**Changes**:\n```\n{diff_stat}\n```")

        return "\n".join(parts)

    # --- Full sprint lifecycle ---

    def run_full_sprint(self, team, ceo_goal, sprint_number):
        """Full sprint lifecycle."""
        config = self.state.load_config()
        lead_dev = team["lead_dev"]
        qa = team["qa"]
        secretary = team["secretary"]

        # --- Standup (skip sprint 1) ---
        if sprint_number > 1:
            try:
                prev_sprint = self.state.load_sprint(sprint_number - 1)
                console.print(Panel(
                    f"[bold]Standup - catching up from Sprint {sprint_number - 1}[/bold]",
                    style="cyan",
                ))
                prev_notes = self.state.load_sprint_notes(sprint_number - 1)
                standup_summary = self.wrapup.run_standup_with_notes(
                    prev_sprint, team, secretary, prev_notes,
                )
                console.print(Panel(
                    Markdown(standup_summary), title="Standup Summary", style="cyan",
                ))
            except FileNotFoundError:
                pass

        # --- Plan ---
        sprint = self.planner.plan_sprint(
            lead_dev=lead_dev, qa=qa,
            ceo_input=ceo_goal, sprint_number=sprint_number,
        )
        self.wrapup.show_running_costs("After planning")

        # Show the plan to the CEO
        if sprint.tasks:
            task_lines = "\n".join(
                f"  {i}. {t.description} → {t.assigned_to}"
                for i, t in enumerate(sprint.tasks, 1)
            )
            console.print(Panel(
                task_lines,
                title=f"Sprint {sprint_number} Plan ({len(sprint.tasks)} tasks)",
                style="blue",
            ))

        # --- CEO approves plan ---
        # Access Prompt through the package so test patches on
        # "odd.sprint.Prompt" take effect.
        import odd.sprint as _sprint_pkg
        _Prompt = _sprint_pkg.Prompt

        if self.gate(CEOGate.PLAN_APPROVAL) == CEOStyle.DELEGATOR:
            console.print("[dim]Auto-proceeding with plan (delegator mode).[/dim]")
        else:
            proceed = _Prompt.ask(
                "\nProceed with this plan?",
                choices=["y", "n", "revise"], default="y",
            )
            if proceed == "n":
                console.print("[yellow]Sprint cancelled.[/yellow]")
                return sprint
            if proceed == "revise":
                revision = _Prompt.ask("[bold yellow]CEO[/bold yellow] What would you like changed?")
                sprint = self.planner.plan_sprint(
                    lead_dev=lead_dev, qa=qa,
                    ceo_input=f"{ceo_goal}\n\nCEO revision: {revision}",
                    sprint_number=sprint_number,
                )

        # --- Silent branch creation ---
        self.git.create_sprint_branch(sprint_number)

        # Checkpoint after planning so a crash during QA can resume here.
        sprint.checkpoint = SprintCheckpoint(
            stage="planning",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[],
        )
        self.state.save_sprint(sprint)

        # --- Pre-flight: ensure test runner is available ---
        if not self.tdd.preflight_test_runner():
            console.print("[yellow]Sprint cancelled — test runner not available.[/yellow]")
            return sprint

        try:
            console.print(Panel("Sprint is underway!", style="bold green"))
            sprint = self.run_sprint(sprint, team)
            self.wrapup.show_running_costs("After implementation")

            self.wrapup.post_implementation(sprint, team, sprint_number)

            sprint.status = SprintStatus.COMPLETE
            self.state.save_sprint(sprint)
            config.current_sprint = sprint_number
            self.state.save_config(config)
        except KeyboardInterrupt:
            sprint.status = SprintStatus.CANCELLED
            self.state.save_sprint(sprint)
            console.print(Panel(
                "[bold yellow]Sprint interrupted by CEO.[/bold yellow]\n"
                f"Work preserved on branch [cyan]sprint-{sprint_number}[/cyan].\n"
                "Run [bold]odd sprint[/bold] to start a new sprint.",
                style="yellow",
            ))

        return sprint

    # --- Shared utilities ---

    def _detect_ecosystem(self) -> dict[str, Any]:
        """Detect the target project's tech ecosystem from its root files.

        Returns a dict with:
          language: "python" | "javascript" | "typescript" | "unknown"
          framework: detected framework name or None
          test_framework: recommended test runner or None
          test_directive: ready-to-use instruction string for QA
        """
        root = self.state.root

        # --- JavaScript / TypeScript (package.json) ---
        pkg_path = root / "package.json"
        if pkg_path.exists():
            try:
                pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pkg = {}

            deps = {
                *pkg.get("dependencies", {}),
                *pkg.get("devDependencies", {}),
            }
            lang = "typescript" if "typescript" in deps or (root / "tsconfig.json").exists() else "javascript"

            # Detect framework
            framework = None
            for name in ("next", "react", "vue", "svelte", "angular", "express"):
                if name in deps:
                    framework = name
                    break

            # Detect or recommend test framework
            test_fw = None
            for name in ("vitest", "jest", "@jest/core", "mocha", "ava"):
                if name in deps:
                    test_fw = name.lstrip("@").split("/")[0]
                    break
            if not test_fw:
                test_fw = "vitest" if "vitest" in deps or "vite" in deps else "jest"

            test_dir = "__tests__" if test_fw == "jest" else "tests"
            return {
                "language": lang,
                "framework": framework,
                "test_framework": test_fw,
                "test_directive": (
                    f"Use {test_fw}. "
                    f"Create test files in the {test_dir}/ directory."
                ),
            }

        # --- Python (pyproject.toml, setup.py, requirements.txt) ---
        is_python = any(
            (root / f).exists()
            for f in ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt")
        )
        if is_python:
            return {
                "language": "python",
                "framework": None,
                "test_framework": "pytest",
                "test_directive": "Use pytest. Create test files in the tests/ directory.",
            }

        # --- Fallback ---
        return {
            "language": "unknown",
            "framework": None,
            "test_framework": None,
            "test_directive": (
                "Choose the appropriate test framework for this project. "
                "Create test files in a tests/ directory."
            ),
        }

    def _build_project_context(self, sprint_number):
        """Build shared project context for agents."""
        config = self.state.load_config()
        parts = [
            f"Project: {config.name}",
            f"Description: {config.description}",
            f"Current Sprint: {sprint_number}",
        ]

        # Include tech stack so agents know the ecosystem
        eco = self._detect_ecosystem()
        tech_parts = []
        if eco["language"] != "unknown":
            tech_parts.append(eco["language"])
        if eco["framework"]:
            tech_parts.append(eco["framework"])
        if eco["test_framework"]:
            tech_parts.append(f"tests: {eco['test_framework']}")
        if tech_parts:
            parts.append(f"Tech stack: {', '.join(tech_parts)}")

        consultants = self.state.list_consultants()
        if consultants:
            parts.append("Available consultants:")
            for c in consultants:
                reason = f" - {c.hire_reason}" if c.hire_reason else ""
                sprint_tag = f" (Sprint {c.hired_sprint})" if c.hired_sprint else ""
                record = self.state.load_consultant_record(c.name)
                track = f" [{record.summary()}]" if record.outcomes else ""
                parts.append(f"  - {c.name}: {c.title}{reason}{sprint_tag}{track}")

        backlog = Backlog(self.state.odd_dir)
        backlog_summary = backlog.summary_for_agent()
        if backlog_summary != "Backlog is empty.":
            parts.append(f"\n{backlog_summary}")

        if self.state.has_active_roadmap():
            roadmap = self.state.load_roadmap()
            parts.append(f"\nRoadmap goal: {roadmap.goal}")
            for rs in roadmap.sprints:
                marker = "→" if rs.status == "in_progress" else "✓" if rs.status == "complete" else " "
                parts.append(f"  [{marker}] Sprint {rs.number}: {rs.deliverables}")

        return "\n".join(parts)

    def _get_lead_dev_from_context(self):
        """Load the lead dev persona from state."""
        return self.state.load_persona("lead_dev")

    def _resolve_agent(self, assigned_to, team):
        """Resolve an assignment string to a persona."""
        assigned_lower = assigned_to.lower()

        for key, persona in team.items():
            if key == assigned_lower or persona.name.lower() == assigned_lower:
                return persona

        for key, persona in team.items():
            if re.search(r'\b' + re.escape(key) + r'\b', assigned_lower):
                return persona
            if re.search(r'\b' + re.escape(persona.name.lower()) + r'\b', assigned_lower):
                return persona

        if self._consultant_cache is None:
            self._consultant_cache = self.state.list_consultants()
        for c in self._consultant_cache:
            if c.name.lower() == assigned_lower:
                return c
        for c in self._consultant_cache:
            if re.search(r'\b' + re.escape(c.name.lower()) + r'\b', assigned_lower):
                return c

        return None

    # --- Delegations to collaborators ---
    # Proper methods so IDE navigation, type-checkers, and tests work cleanly.
    # Only methods that external callers (CLI, tests) reference directly.

    # Planning
    def plan_roadmap(self, *a, **kw):
        return self.planner.plan_roadmap(*a, **kw)

    def plan_sprint(self, *a, **kw):
        return self.planner.plan_sprint(*a, **kw)

    # Vacation
    def plan_vacation(self, *a, **kw):
        return self.vacation.plan_vacation(*a, **kw)

    # Wrapup
    def demo(self, *a, **kw):
        return self.wrapup.demo(*a, **kw)

    def _post_implementation(self, *a, **kw):
        return self.wrapup.post_implementation(*a, **kw)

    def _suggest_hires(self, *a, **kw):
        return self.wrapup.suggest_hires(*a, **kw)

    def _merge_sprint_branch(self, *a, **kw):
        return self.wrapup.merge_sprint_branch(*a, **kw)

    def _handle_test_change_requests(self, *a, **kw):
        return self.wrapup.handle_test_change_requests(*a, **kw)

    def _handle_hire_suggestions(self, *a, **kw):
        return self.wrapup.handle_hire_suggestions(*a, **kw)

    def _handle_dependency_requests(self, *a, **kw):
        return self.wrapup.handle_dependency_requests(*a, **kw)

    # TDD gate
    def _should_surface_escalation(self, severity):
        return self.tdd.should_surface_escalation(severity)

    def _drain_escalations(self, engine, agent, ctx, desc, interactive):
        return self.tdd.drain_escalations(engine, agent, ctx, desc, interactive)

    def _handle_escalations(self, agent, ctx, task_description=""):
        return self.tdd._handle_escalations(agent, ctx, task_description=task_description)

    @staticmethod
    def _format_review_feedback(outcomes):
        return TDDGate.format_review_feedback(outcomes)

    # Vacation
    def run_vacation(self, *a, **kw):
        return self.vacation.run_vacation(*a, **kw)
