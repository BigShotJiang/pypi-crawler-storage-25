"""Centralized configuration constants for ODD.

All magic strings and numbers live here so they can be updated in one place
when models change, pricing shifts, or operational defaults need tuning.

Pricing can be refreshed from Anthropic's docs via refresh_pricing().
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Model identifiers - update these when Anthropic releases new versions
# ---------------------------------------------------------------------------
OPUS_MODEL = "claude-opus-4-6"
SONNET_MODEL = "claude-sonnet-4-6"
HAIKU_MODEL = "claude-haiku-4-5-20251001"

# ---------------------------------------------------------------------------
# Pricing per million tokens (USD) - fallback defaults
# These are used when no cached pricing file exists. Keep them current.
# ---------------------------------------------------------------------------
_DEFAULT_PRICING: dict[str, dict[str, float]] = {
    OPUS_MODEL: {"input": 5.00, "output": 25.00},
    SONNET_MODEL: {"input": 3.00, "output": 15.00},
    HAIKU_MODEL: {"input": 1.00, "output": 5.00},
}

# ---------------------------------------------------------------------------
# Agent defaults
# ---------------------------------------------------------------------------
DEFAULT_MAX_TOKENS = 16384
SHELL_COMMAND_TIMEOUT = 120  # seconds

# Per-phase token defaults - right-sized for each context
PHASE_TOKEN_DEFAULTS = {
    "planning": 8192,
    "phase_planning": 8192,
    "standup": 8192,
    "demo": 8192,
    "qa": 16384,
    "implementation": 16384,
    "merge": 8192,
    "code_review": 16384,
    "code_review_fix": 16384,
    "recruiter": 4096,
    "resume_refinement": 4096,
}

# ---------------------------------------------------------------------------
# Code review
# ---------------------------------------------------------------------------
CODE_REVIEW_DEPTHS: dict[str, int] = {
    "quick": 1,
    "standard": 2,
    "thorough": 4,
}
CODE_REVIEW_THRESHOLD = 8  # Score 1-10 needed to pass without another round
CODE_REVIEW_NUDGE_INTERVAL = 3  # Sprints between "you should review" nudges
MAX_REVIEW_PASSES = 10  # Upper bound for review pass count

# ---------------------------------------------------------------------------
# Context window sizes (tokens) - used by DirectRunner's context guard.
# Keys can be exact model IDs or substring prefixes (matched greedily).
# ---------------------------------------------------------------------------
MODEL_CONTEXT_WINDOWS: dict[str, int] = {
    # Anthropic
    "claude-opus-4-6": 200_000,
    "claude-sonnet-4-6": 200_000,
    "claude-haiku-4-5": 200_000,
    # OpenAI
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "gpt-4-turbo": 128_000,
    "gpt-4": 8_192,
    "gpt-3.5-turbo": 16_385,
    # Open-source (common Open WebUI models)
    "llama3.1:70b": 128_000,
    "llama3.1:8b": 128_000,
    "llama3:70b": 8_192,
    "llama3:8b": 8_192,
    "mistral": 32_000,
    "mixtral": 32_000,
    "qwen": 32_000,
    "deepseek": 128_000,
    "gemma": 8_192,
    "codestral": 32_000,
    "phi": 16_000,
}
DEFAULT_CONTEXT_WINDOW = 128_000  # conservative default for unknown models


def resolve_context_window(model: str) -> int:
    """Look up the context window for a model ID.

    Tries exact match first, then prefix match (longest wins).
    Falls back to DEFAULT_CONTEXT_WINDOW.
    """
    if model in MODEL_CONTEXT_WINDOWS:
        return MODEL_CONTEXT_WINDOWS[model]
    # Prefix match: "gpt-4o-2024-05-13" matches "gpt-4o"
    best_match = ""
    for key in MODEL_CONTEXT_WINDOWS:
        if model.startswith(key) and len(key) > len(best_match):
            best_match = key
    if best_match:
        return MODEL_CONTEXT_WINDOWS[best_match]
    return DEFAULT_CONTEXT_WINDOW


MAX_AGENTIC_ITERATIONS = 40
STUCK_DETECTION_THRESHOLD = 3  # same tool call N times in a row → break
STUCK_OUTPUT_THRESHOLD = 3     # same tool *outputs* N times in a row → break

# ---------------------------------------------------------------------------
# TDD gate - mechanical test verification after implementation
# ---------------------------------------------------------------------------
TDD_MAX_RETRIES = 3            # default retries - CEO can override via config
TDD_PYTEST_TIMEOUT = 120       # seconds for the mechanical pytest run

# ---------------------------------------------------------------------------
# Budget defaults - applied on `odd init` so new users have cost protection
# ---------------------------------------------------------------------------
DEFAULT_SPRINT_BUDGET = 5.00   # USD per sprint
DEFAULT_TOTAL_BUDGET = 20.00   # USD cumulative cap
BUDGET_WARNING_THRESHOLD = 0.8  # warn at 80% of budget

# Phase budget envelopes - how the sprint budget is split across phases
DEFAULT_PHASE_ENVELOPES: dict[str, float] = {
    "planning": 0.05,       #  5% - sprint + phase planning
    "qa": 0.20,             # 20% - test writing
    "implementation": 0.60, # 60% - the actual work
    "review": 0.10,         # 10% - code review + TDD retries
    "demo": 0.05,           #  5% - demo + retro
}

# Wrap-up threshold (fraction of a limit - phase envelope, context window, etc.)
# At 85%, the agent enters wind-down mode regardless of what limit triggered it.
WRAP_UP_THRESHOLD = 0.85
WIND_DOWN_ITERATIONS = 3          # iterations allowed after soft stop signal

# ---------------------------------------------------------------------------
# API retry behaviour
# ---------------------------------------------------------------------------
API_MAX_RETRIES = 3
API_RETRY_BASE_DELAY = 1.0  # seconds, doubled each retry

# ---------------------------------------------------------------------------
# Timeouts
# ---------------------------------------------------------------------------
GIT_COMMAND_TIMEOUT = 30  # seconds
PRICING_URL_TIMEOUT = 10  # seconds


# ---------------------------------------------------------------------------
# Git branching patterns
# ---------------------------------------------------------------------------
SPRINT_BRANCH_PREFIX = "odd/sprint"
WORKTREE_DIR = ".odd/worktrees"

# ---------------------------------------------------------------------------
# Core team & directory layout
# ---------------------------------------------------------------------------
CORE_TEAM_ROLES = ["lead_dev", "qa", "recruiter", "secretary"]
CONSULTANTS_DIR_NAME = "consultants"
ARCHIVED_DIR_NAME = "_archived"
FINANCIALS_DIR = "financials"

# ---------------------------------------------------------------------------
# State file names
# ---------------------------------------------------------------------------
CONFIG_FILE = "config.json"
PERSONA_FILE = "persona.json"
JOB_DESCRIPTION_FILE = "job_description.md"
RESUME_FILE = "resume.md"
SPRINT_FILE = "sprint.json"
CODE_REVIEW_FILE = "code_review.json"
ROADMAP_FILE = "roadmap.json"
RATINGS_FILE = "ratings.json"
BACKLOG_FILE = "backlog.json"
LEDGER_FILE = "ledger.json"  # legacy - kept for migration
ACTIVITY_FILE = "activity.jsonl"
STREAM_DEBUG_FILE = "stream_debug.jsonl"
BUDGET_FILE = "budget.json"
VALUES_CONFIG_FILE = "values.json"
PRICING_CACHE_FILE = "pricing.json"
VACATION_PLAN_FILE = "vacation_plan.json"
VACATION_REPORT_FILE = "vacation_report.json"

# ---------------------------------------------------------------------------
# Backlog
# ---------------------------------------------------------------------------
BACKLOG_ITEM_ID_PREFIX = "bl_"

# ---------------------------------------------------------------------------
# UI defaults
# ---------------------------------------------------------------------------
DEFAULT_BETA_TESTER_COUNT = 3
CONVERSATION_HISTORY_THRESHOLD = 4

# ---------------------------------------------------------------------------
# Pricing URL
# ---------------------------------------------------------------------------
PRICING_URL = "https://platform.claude.com/docs/en/docs/about-claude/pricing"


def _pricing_cache_path(odd_dir: Path | None = None) -> Path | None:
    """Path to the cached pricing file inside .odd/."""
    if odd_dir is None:
        return None
    return odd_dir / FINANCIALS_DIR / PRICING_CACHE_FILE


def _parse_pricing_table(html: str) -> dict[str, dict[str, float]]:
    """Parse model pricing from the Anthropic pricing page markdown/HTML.

    Looks for rows like:
        | Claude Opus 4.6 | $5 / MTok | ... | $25 / MTok |
    and extracts the base input and output prices.
    """
    pricing: dict[str, dict[str, float]] = {}

    # Match table rows: | Model Name | $X / MTok | ... | $Y / MTok |
    # We want the first price column (base input) and the last (output).
    row_pattern = re.compile(
        r"^\|\s*Claude\s+(\w+)\s+([\d.]+(?:\s+\([^)]*\))?)\s*\|"
        r"\s*\$([\d.]+)\s*/\s*MTok\s*\|"  # base input
        r".*?\|\s*\$([\d.]+)\s*/\s*MTok\s*\|$",  # output (last price column)
        re.MULTILINE,
    )

    for match in row_pattern.finditer(html):
        family = match.group(1).lower()   # opus, sonnet, haiku
        version = match.group(2).strip()  # 4.6, 4.5, 3.5, etc.
        input_price = float(match.group(3))
        output_price = float(match.group(4))

        # Build a lookup key like "opus-4.6"
        key = f"{family}-{version}"
        pricing[key] = {"input": input_price, "output": output_price}

    return pricing


def _resolve_model_pricing(
    parsed: dict[str, dict[str, float]],
) -> dict[str, dict[str, float]]:
    """Map parsed pricing keys back to our model ID strings."""
    # Build a mapping from (family, version) to model IDs we care about
    model_ids = [OPUS_MODEL, SONNET_MODEL, HAIKU_MODEL]
    resolved: dict[str, dict[str, float]] = {}

    for model_id in model_ids:
        # Extract family and version from model ID
        # e.g. "claude-opus-4-6" -> family="opus", version-ish="4-6" -> "4.6"
        # e.g. "claude-haiku-4-5-20251001" -> family="haiku", version-ish="4-5"
        parts = model_id.replace("claude-", "").split("-")
        family = parts[0]  # opus, sonnet, haiku

        # Try version patterns: "4-6" -> "4.6", "4-5" -> "4.5"
        if len(parts) >= 3:
            version_key = f"{family}-{parts[1]}.{parts[2]}"
            if version_key in parsed:
                resolved[model_id] = parsed[version_key]
                continue

        # Try just major version: "4"
        if len(parts) >= 2:
            version_key = f"{family}-{parts[1]}"
            if version_key in parsed:
                resolved[model_id] = parsed[version_key]

    return resolved


def refresh_pricing(odd_dir: Path | None = None) -> dict[str, dict[str, float]]:
    """Fetch current pricing from Anthropic's docs and cache it.

    Returns the parsed pricing dict. Falls back to defaults on failure.
    """
    try:
        import urllib.request

        with urllib.request.urlopen(PRICING_URL, timeout=PRICING_URL_TIMEOUT) as resp:  # nosec B310 - hardcoded HTTPS URL
            content = resp.read().decode("utf-8")

        parsed = _parse_pricing_table(content)
        resolved = _resolve_model_pricing(parsed)

        if resolved:
            # Cache to disk if we have an .odd/ dir
            cache_path = _pricing_cache_path(odd_dir)
            if cache_path is not None:
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                cache_path.write_text(json.dumps(resolved, indent=2), encoding="utf-8")
            return resolved
    except Exception:
        pass

    return dict(_DEFAULT_PRICING)


def load_pricing(odd_dir: Path | None = None) -> dict[str, dict[str, float]]:
    """Load pricing from cache, falling back to defaults.

    Call refresh_pricing() to update the cache from Anthropic's docs.
    """
    cache_path = _pricing_cache_path(odd_dir)
    if cache_path is not None and cache_path.exists():
        try:
            cached: dict[str, dict[str, float]] = json.loads(cache_path.read_text(encoding="utf-8"))
            return cached
        except Exception:
            pass
    return dict(_DEFAULT_PRICING)


# Module-level export - used by CFO when no .odd/ dir context is available
MODEL_PRICING: dict[str, dict[str, float]] = dict(_DEFAULT_PRICING)
