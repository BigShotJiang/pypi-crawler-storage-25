"""Tests for GitManager - real git operations in tmp repos."""

import os
import subprocess
from pathlib import Path

import pytest

from odd.git import GitManager, MergeConflictError, _validate_branch_name


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a real git repo with an initial commit."""
    subprocess.run("git init", shell=True, cwd=tmp_path, capture_output=True)
    subprocess.run("git checkout -b main", shell=True, cwd=tmp_path, capture_output=True)
    # Configure user for CI environments that lack global git config
    subprocess.run(
        'git config user.email "test@odd.dev"', shell=True, cwd=tmp_path, capture_output=True,
    )
    subprocess.run(
        'git config user.name "ODD Test"', shell=True, cwd=tmp_path, capture_output=True,
    )
    # Initial commit
    (tmp_path / "README.md").write_text("# Test Project")
    subprocess.run("git add -A", shell=True, cwd=tmp_path, capture_output=True)
    subprocess.run('git commit -m "Initial commit"', shell=True, cwd=tmp_path, capture_output=True)
    return tmp_path


@pytest.fixture
def gm(git_repo: Path) -> GitManager:
    return GitManager(git_repo)


@pytest.fixture
def non_git_dir(tmp_path: Path) -> Path:
    """A plain directory with no git repo."""
    plain = tmp_path / "no_git"
    plain.mkdir()
    return plain


class TestAvailability:
    def test_available_in_git_repo(self, gm: GitManager):
        assert gm.available is True

    def test_not_available_outside_repo(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.available is False


class TestMainBranch:
    def test_detects_main(self, gm: GitManager):
        assert gm.main_branch() == "main"

    def test_detects_master(self, tmp_path: Path):
        repo = tmp_path / "master_repo"
        repo.mkdir(exist_ok=True)
        subprocess.run("git init", shell=True, cwd=repo, capture_output=True)
        subprocess.run("git checkout -b master", shell=True, cwd=repo, capture_output=True)
        subprocess.run(
            'git config user.email "test@odd.dev"', shell=True, cwd=repo, capture_output=True,
        )
        subprocess.run(
            'git config user.name "ODD Test"', shell=True, cwd=repo, capture_output=True,
        )
        (repo / "f.txt").write_text("x")
        subprocess.run("git add -A", shell=True, cwd=repo, capture_output=True)
        subprocess.run('git commit -m "init"', shell=True, cwd=repo, capture_output=True)
        gm = GitManager(repo)
        assert gm.main_branch() == "master"


class TestBranchLifecycle:
    def test_create_sprint_branch(self, gm: GitManager, git_repo: Path):
        branch = gm.create_sprint_branch(1)
        assert branch == "odd/sprint-1"
        # Should be on the sprint branch now
        assert gm.current_branch() == "odd/sprint-1"

    def test_create_existing_branch_checks_it_out(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        # Go back to main
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        # Create again - should just checkout, not error
        branch = gm.create_sprint_branch(1)
        assert branch == "odd/sprint-1"
        assert gm.current_branch() == "odd/sprint-1"

    def test_create_branch_returns_none_if_no_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.create_sprint_branch(1) is None


class TestMerge:
    def test_merge_sprint_into_main(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        # Do some work on the sprint branch
        (git_repo / "feature.py").write_text("print('hello')")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "Add feature"', shell=True, cwd=git_repo, capture_output=True)

        # Merge back
        assert gm.merge_sprint(1) is True
        assert gm.current_branch() == "main"
        # File should exist on main now
        assert (git_repo / "feature.py").exists()

    def test_merge_with_uncommitted_changes(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        # Leave changes uncommitted
        (git_repo / "wip.py").write_text("work in progress")

        # Merge should auto-commit first
        assert gm.merge_sprint(1) is True
        assert gm.current_branch() == "main"
        assert (git_repo / "wip.py").exists()

    def test_merge_conflict_raises(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        # Make a change on sprint branch
        (git_repo / "README.md").write_text("Sprint version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "Sprint change"', shell=True, cwd=git_repo, capture_output=True)

        # Go to main and make a conflicting change
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        (git_repo / "README.md").write_text("Main version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "Main change"', shell=True, cwd=git_repo, capture_output=True)

        # Go back to sprint branch for merge
        subprocess.run("git checkout odd/sprint-1", shell=True, cwd=git_repo, capture_output=True)

        with pytest.raises(MergeConflictError) as exc_info:
            gm.merge_sprint(1)
        assert "README.md" in exc_info.value.conflicting_files

    def test_merge_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.merge_sprint(1) is True


class TestAbandon:
    def test_abandon_returns_to_main(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        (git_repo / "abandoned.py").write_text("this gets abandoned")

        assert gm.abandon_sprint(1) is True
        assert gm.current_branch() == "main"
        # File should NOT be on main
        assert not (git_repo / "abandoned.py").exists()

    def test_abandon_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.abandon_sprint(1) is True


class TestDiffSummary:
    def test_diff_summary_shows_changes(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        (git_repo / "new_file.py").write_text("content")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "Add file"', shell=True, cwd=git_repo, capture_output=True)

        summary = gm.get_sprint_diff_summary(1)
        assert "new_file.py" in summary

    def test_diff_summary_empty_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.get_sprint_diff_summary(1) == ""


class TestAutoCommit:
    def test_auto_commit_stages_and_commits(self, gm: GitManager, git_repo: Path):
        (git_repo / "new.txt").write_text("new file")
        assert gm.has_uncommitted_changes() is True
        assert gm._auto_commit("test commit") is True
        assert gm.has_uncommitted_changes() is False

    def test_auto_commit_noop_when_clean(self, gm: GitManager):
        assert gm._auto_commit("nothing to commit") is False


class TestEnsureOnBranch:
    def test_switches_to_sprint_branch(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        assert gm.current_branch() == "main"

        gm.ensure_on_sprint_branch(1)
        assert gm.current_branch() == "odd/sprint-1"

    def test_recovers_deleted_branch_from_reflog(self, gm: GitManager, git_repo: Path):
        """When a sprint branch is deleted, ensure_on_sprint_branch recovers it."""
        gm.create_sprint_branch(1)
        (git_repo / "work.py").write_text("important work")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Sprint work"', shell=True, cwd=git_repo, capture_output=True,
        )
        # Remember what commit we were on
        sprint_commit = subprocess.run(
            "git rev-parse HEAD", shell=True, cwd=git_repo, capture_output=True, text=True,
        ).stdout.strip()

        # Delete the branch
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            "git branch -D odd/sprint-1", shell=True, cwd=git_repo, capture_output=True,
        )
        assert not gm.branch_exists("odd/sprint-1")

        # ensure_on_sprint_branch should recover it
        gm.ensure_on_sprint_branch(1)
        assert gm.current_branch() == "odd/sprint-1"
        # The recovered branch should point to the same commit
        recovered_commit = subprocess.run(
            "git rev-parse HEAD", shell=True, cwd=git_repo, capture_output=True, text=True,
        ).stdout.strip()
        assert recovered_commit == sprint_commit


class TestRebase:
    def test_rebase_onto_updated_main(self, gm: GitManager, git_repo: Path):
        """Sprint branch rebases cleanly when main has new commits."""
        gm.create_sprint_branch(1)
        (git_repo / "feature.py").write_text("sprint work")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Sprint commit"', shell=True, cwd=git_repo, capture_output=True,
        )

        # Add a commit to main that doesn't conflict
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        (git_repo / "hotfix.py").write_text("hotfix on main")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Hotfix"', shell=True, cwd=git_repo, capture_output=True,
        )

        assert gm.rebase_sprint_onto_main(1) is True
        assert gm.current_branch() == "odd/sprint-1"
        # Both files should exist after rebase
        assert (git_repo / "feature.py").exists()
        assert (git_repo / "hotfix.py").exists()

    def test_rebase_noop_when_up_to_date(self, gm: GitManager, git_repo: Path):
        """Rebase returns True immediately when sprint is already up to date."""
        gm.create_sprint_branch(1)
        (git_repo / "feature.py").write_text("work")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Work"', shell=True, cwd=git_repo, capture_output=True,
        )

        assert gm.rebase_sprint_onto_main(1) is True

    def test_rebase_aborts_on_conflict(self, gm: GitManager, git_repo: Path):
        """Rebase aborts cleanly when there are conflicts."""
        gm.create_sprint_branch(1)
        (git_repo / "README.md").write_text("sprint version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Sprint README"', shell=True, cwd=git_repo, capture_output=True,
        )

        # Conflicting change on main
        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        (git_repo / "README.md").write_text("main version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            'git commit -m "Main README"', shell=True, cwd=git_repo, capture_output=True,
        )

        assert gm.rebase_sprint_onto_main(1) is False
        # Should still be on sprint branch, repo should be clean (rebase aborted)
        assert gm.current_branch() == "odd/sprint-1"
        assert not gm.has_uncommitted_changes()

    def test_rebase_nonexistent_branch(self, gm: GitManager):
        assert gm.rebase_sprint_onto_main(99) is False

    def test_rebase_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.rebase_sprint_onto_main(1) is True


class TestDivergence:
    def test_no_divergence_on_fresh_branch(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        info = gm.check_divergence(1)
        assert info["ahead"] == 0
        assert info["behind"] == 0
        assert info["diverged"] is False

    def test_ahead_only(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        (git_repo / "f.py").write_text("new")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "ahead"', shell=True, cwd=git_repo, capture_output=True)

        info = gm.check_divergence(1)
        assert info["ahead"] == 1
        assert info["behind"] == 0
        assert info["diverged"] is False

    def test_diverged(self, gm: GitManager, git_repo: Path):
        gm.create_sprint_branch(1)
        (git_repo / "sprint.py").write_text("sprint")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "sprint"', shell=True, cwd=git_repo, capture_output=True)

        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        (git_repo / "main.py").write_text("main")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "main"', shell=True, cwd=git_repo, capture_output=True)

        info = gm.check_divergence(1)
        assert info["ahead"] == 1
        assert info["behind"] == 1
        assert info["diverged"] is True
        assert info["merge_base"] is not None

    def test_nonexistent_branch(self, gm: GitManager):
        info = gm.check_divergence(99)
        assert info["ahead"] == 0
        assert info["diverged"] is False

    def test_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        info = gm.check_divergence(1)
        assert info["ahead"] == 0


class TestRecoverBranch:
    def test_recover_from_reflog(self, gm: GitManager, git_repo: Path):
        """Deleted branch can be recovered from reflog."""
        gm.create_sprint_branch(1)
        (git_repo / "work.py").write_text("valuable")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "work"', shell=True, cwd=git_repo, capture_output=True)

        subprocess.run("git checkout main", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run(
            "git branch -D odd/sprint-1", shell=True, cwd=git_repo, capture_output=True,
        )

        assert gm.recover_branch("odd/sprint-1") is True
        assert gm.branch_exists("odd/sprint-1")
        assert gm.current_branch() == "odd/sprint-1"
        assert (git_repo / "work.py").exists()

    def test_recover_nonexistent_returns_false(self, gm: GitManager):
        assert gm.recover_branch("odd/sprint-999") is False

    def test_recover_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.recover_branch("anything") is False


class TestCherryPick:
    def test_cherry_pick_salvages_commits(self, gm: GitManager, git_repo: Path):
        """Cherry-pick applies non-conflicting commits from a task branch."""
        gm.create_sprint_branch(1)
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "base" --allow-empty', shell=True, cwd=git_repo, capture_output=True)

        # Create a task branch with two commits
        task_branch = gm.task_branch_name(1, "alpha")
        subprocess.run(
            f"git checkout -b {task_branch}", shell=True, cwd=git_repo, capture_output=True,
        )
        (git_repo / "alpha1.py").write_text("first")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "alpha commit 1"', shell=True, cwd=git_repo, capture_output=True)
        (git_repo / "alpha2.py").write_text("second")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "alpha commit 2"', shell=True, cwd=git_repo, capture_output=True)

        # Go back to sprint branch
        subprocess.run(
            "git checkout odd/sprint-1", shell=True, cwd=git_repo, capture_output=True,
        )

        assert gm.cherry_pick_task_commits(1, "alpha") is True
        assert (git_repo / "alpha1.py").exists()
        assert (git_repo / "alpha2.py").exists()

    def test_cherry_pick_skips_conflicts(self, gm: GitManager, git_repo: Path):
        """Cherry-pick skips conflicting commits but applies clean ones."""
        gm.create_sprint_branch(1)

        # Create task branch
        task_branch = gm.task_branch_name(1, "beta")
        subprocess.run(
            f"git checkout -b {task_branch}", shell=True, cwd=git_repo, capture_output=True,
        )
        # Commit 1: modify README (will conflict)
        (git_repo / "README.md").write_text("task version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "conflict"', shell=True, cwd=git_repo, capture_output=True)
        # Commit 2: add new file (won't conflict)
        (git_repo / "clean.py").write_text("clean")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "clean"', shell=True, cwd=git_repo, capture_output=True)

        # Make conflicting change on sprint branch
        subprocess.run(
            "git checkout odd/sprint-1", shell=True, cwd=git_repo, capture_output=True,
        )
        (git_repo / "README.md").write_text("sprint version")
        subprocess.run("git add -A", shell=True, cwd=git_repo, capture_output=True)
        subprocess.run('git commit -m "sprint readme"', shell=True, cwd=git_repo, capture_output=True)

        assert gm.cherry_pick_task_commits(1, "beta") is True
        # The clean commit should have been applied
        assert (git_repo / "clean.py").exists()
        # README should still have sprint version (conflict was skipped)
        assert (git_repo / "README.md").read_text() == "sprint version"

    def test_cherry_pick_nonexistent_task(self, gm: GitManager):
        gm.create_sprint_branch(1) if gm.available else None
        assert gm.cherry_pick_task_commits(1, "nonexistent") is False

    def test_cherry_pick_noop_for_non_git(self, non_git_dir: Path):
        gm = GitManager(non_git_dir)
        assert gm.cherry_pick_task_commits(1, "x") is False
