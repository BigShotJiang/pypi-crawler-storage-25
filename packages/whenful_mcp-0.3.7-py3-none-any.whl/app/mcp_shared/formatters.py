"""Text response formatters shared by MCP tools.

The MCP tool surface returns plain text (not structured JSON) because LLMs
consume it directly — these formatters produce the human-readable lines
Claude/etc. see in tool responses. Output strings are part of the MCP
behavioral contract; `tests/test_mcp.py` asserts on substrings like
"Created task", "Updated task", "[id:", "[inst:". Don't reword.

Encryption note: `safe_title` returns a placeholder when the calling
backend reports the user has E2E encryption enabled. Today only the HTTP
backend reports True (there's no other backend yet); the future stdio
backend will always report False because it decrypts client-side and
passes plaintext to the formatters. See MCP #13534 plan.
"""

from __future__ import annotations

from typing import Any

IMPACT_LABELS = {1: "high", 2: "mid", 3: "low", 4: "minimal"}
CLARITY_ICONS = {"autopilot": "\U0001f9df", "normal": "☕", "brainstorm": "\U0001f9e0"}


def format_task(t: dict) -> str:
    """Format a single task as a readable line."""
    flags: list[str] = []
    impact = t.get("impact", 4)
    if impact <= 2:
        flags.append(f"!{IMPACT_LABELS.get(impact, '?')}")
    clarity = t.get("clarity")
    if clarity and clarity != "normal":
        flags.append(CLARITY_ICONS.get(clarity, clarity) or clarity)
    if t.get("duration_minutes"):
        flags.append(f"{t['duration_minutes']}m")
    if t.get("domain_name"):
        flags.append(f"#{t['domain_name']}")
    if t.get("is_recurring"):
        flags.append("recurring")
    if t.get("parent_id"):
        flags.append(f"subtask of [id:{t['parent_id']}]")

    status_mark = "x" if t.get("status") == "completed" else " "
    line = f"[{status_mark}] [id:{t['id']}] {t['title']}"
    if flags:
        line += f"  ({', '.join(flags)})"
    if t.get("scheduled_date"):
        sched = str(t["scheduled_date"])
        if t.get("scheduled_time"):
            sched += f" {t['scheduled_time']}"
        line += f"  -> {sched}"
    if t.get("description"):
        desc = str(t["description"])[:80]
        if len(str(t["description"])) > 80:
            desc += "..."
        line += f"\n     {desc}"
    if t.get("subtasks"):
        for sub in t["subtasks"]:
            sub_mark = "x" if sub.get("status") == "completed" else " "
            line += f"\n   [{sub_mark}] [id:{sub['id']}] {sub['title']}"
    return line


def task_to_dict(task: Any, domain_name: str | None = None) -> dict:
    """Convert a Task ORM object to a dict for formatting."""
    d: dict[str, Any] = {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "domain_id": task.domain_id,
        "domain_name": domain_name or (task.domain.name if task.domain else None),
        "impact": task.impact,
        "clarity": task.clarity,
        "duration_minutes": task.duration_minutes,
        "scheduled_date": task.scheduled_date,
        "scheduled_time": task.scheduled_time,
        "status": task.status,
        "is_recurring": task.is_recurring,
        "completed_at": task.completed_at,
        "parent_id": task.parent_id,
    }
    if hasattr(task, "subtasks") and task.subtasks:
        d["subtasks"] = [{"id": s.id, "title": s.title, "status": s.status} for s in task.subtasks]
    return d


def instance_to_dict(inst: Any) -> dict:
    """Convert a TaskInstance ORM object to a dict."""
    return {
        "id": inst.id,
        "task_id": inst.task_id,
        "task_title": inst.task.title if inst.task else "Recurring task",
        "instance_date": inst.instance_date,
        "status": inst.status,
        "duration_minutes": inst.task.duration_minutes if inst.task else None,
        "impact": inst.task.impact if inst.task else 4,
        "clarity": inst.task.clarity if inst.task else None,
        "domain_name": inst.task.domain.name if inst.task and inst.task.domain else None,
    }


def format_instance(inst: dict) -> str:
    """Format a recurring task instance."""
    mark = "x" if inst["status"] == "completed" else "s" if inst["status"] == "skipped" else " "
    line = f"[{mark}] [inst:{inst['id']}] {inst.get('task_title', 'Recurring task')}"
    if inst.get("instance_date"):
        line += f"  -> {inst['instance_date']}"
    return line


def safe_title(title: str | None, encrypted: bool) -> str:
    """Return title or placeholder if encryption is enabled (title would be ciphertext).

    For the HTTP backend, `encrypted=True` means the row's title column holds
    ciphertext the server can't read, so we return "(encrypted)" rather than
    leaking ciphertext to the LLM. The future stdio backend will always pass
    `encrypted=False` because it decrypts client-side before formatting.
    """
    if encrypted or not title:
        return "(encrypted)"
    return title


def pagination_footer(
    *,
    has_more: bool,
    next_offset: int | None,
    noun: str = "row",
) -> str:
    """Render the "more data exists" footer line for paginated MCP list tools.

    Whenful #14603: MCP list tools used to truncate silently at ``limit`` —
    a caller (LLM or otherwise) couldn't tell "got everything" from "got the
    first N of M". The fix is a single trailing line so the formatted-string
    return shape is preserved:

        → has_more: true. Pass offset=50 to continue (showing first 50 of N+).

    Returns an empty string when ``has_more`` is false so callers can do
    ``"\\n".join([body, pagination_footer(...)])`` unconditionally without
    trailing blank lines on the exhaustive case.

    ``next_offset`` is omitted from the message when ``None`` — for tools
    without an ``offset`` parameter (search_tasks, list_recurring_tasks),
    the hint becomes "refine your query / raise the limit" instead.
    """
    if not has_more:
        return ""
    if next_offset is not None:
        return (
            f"\n\n→ has_more: true. Pass offset={next_offset} to fetch the next page "
            f"(showing the first batch of {noun}s, more exist)."
        )
    return (
        f"\n\n→ has_more: true. Result was truncated at the per-call cap — "
        f"narrow your filter or raise `limit` to see more {noun}s."
    )


__all__ = [
    "IMPACT_LABELS",
    "CLARITY_ICONS",
    "format_task",
    "format_instance",
    "task_to_dict",
    "instance_to_dict",
    "safe_title",
    "pagination_footer",
]
