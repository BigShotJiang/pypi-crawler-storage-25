"""Shared error-handling guard for MCP write tools.

Background — Sentry WHENFUL-33 + WHENFUL-34 (2026-04-20/21) proved that any
`DBAPIError` / `IntegrityError` that escapes an MCP tool unhandled is wrapped
by FastMCP into a `ToolError` whose payload includes SQLAlchemy's
``str(exception)`` — and that string carries the full SQL statement plus every
bound parameter. For Whenful's content tables that means **user task titles +
descriptions in plaintext** end up:

  - in the LLM's view of the tool response,
  - in Sentry events,
  - in any logs that capture the ToolError.

PRs #1532 (update_task) and #1534 (create_task) added narrow ``except
DBAPIError / except IntegrityError`` blocks at those two tool sites. This
module systematises that protection so every write tool in
`app/mcp_shared/tools/*.py` is guarded the same way without copying the
catch-block into nine more functions.

Usage
-----

Decorate any MCP tool that performs writes::

    from app.mcp_shared.error_guard import guard_db_errors

    @guard_db_errors("complete_task")
    async def complete_task(backend, user_id, task_id):
        async with backend.session() as db:
            ...
            await db.commit()
        ...

The decorator wraps the coroutine so that:

  - ``ValueError`` propagates unchanged — business-rule violations should
    still surface to the LLM as plain validation strings via each tool's
    own ``except ValueError`` blocks.
  - ``IntegrityError`` is mapped to ``"Could not complete the operation — your
    account is no longer available. Please re-authenticate."``  (mirrors the
    WHENFUL-34 messaging — FK violations on user_id are the dominant failure
    mode and the message is honest about what the user can do).
  - ``DBAPIError`` (statement timeout, deadlock, asyncpg disconnect, etc.) is
    mapped to ``"The operation failed due to a transient database issue.
    Please retry."``  (mirrors WHENFUL-33).
  - Any other unexpected exception is re-raised so genuine bugs surface in
    the traceback (with the tool name in the log) — we do not want to swallow
    AttributeErrors or KeyErrors silently.

In every case the exception type **and** ``orig`` class are logged so the
operator can find the failure in Sentry; the LLM-visible response never
contains the original ``str(exc)`` or the bound parameters.

Why a decorator instead of a context manager
--------------------------------------------

Each tool already manages its own ``async with backend.session() as db:`` and
multiple commit boundaries (create_task commits twice in the wild — once after
flush, once at the end). Wrapping the whole function gives one uniform safety
net regardless of where inside the tool the DB error fires. The cost is that
the decorator cannot ``db.rollback()`` for us (the session is private to the
inner scope); we accept that because ``async with backend.session()`` already
rolls back on exit when an exception escapes — which is what we now do.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import ParamSpec, TypeVar

logger = logging.getLogger("whenful.mcp")

P = ParamSpec("P")
# ``R`` is the inner tool's success return type. Historically every tool
# returned ``str`` (rendered output for the LLM), so ``R`` was bound to
# ``str``. The ``plan_my_day`` tool (PR 1 of MCP-distribution, 2026-05-19)
# returns ``list[dict[str, Any]] | str`` because its success payload is
# structured proposals — strings are reserved for the inline error /
# encryption-blocked surfaces. ``str`` is already in that union, so the
# decorator's sentinel-string error fallback is still a valid value in
# the widened type. ``R`` is therefore unbounded; tools whose R is ``str``
# get the same effective shape as before.
R = TypeVar("R")


# Canonical, content-free response strings. These are the only strings that
# may surface to the LLM when a DB-layer exception fires inside an MCP write
# tool. Keep them short, actionable, and free of any reference to SQL, schema
# names, column names, or user content.
_INTEGRITY_RESPONSE = "Could not complete the operation — your account is no longer available. Please re-authenticate."
_DBAPI_RESPONSE = "The operation failed due to a transient database issue. Please retry."


def resolve_sqlalchemy_exc_classes() -> tuple[type[BaseException], type[BaseException]]:
    """Lazily resolve ``(IntegrityError, DBAPIError)`` so the standalone
    whenful-mcp wheel doesn't pay the SQLAlchemy import cost.

    On the cloud server SQLAlchemy is already imported by the rest of the
    app, so the lookup is sys.modules-cached and effectively free. In the
    stdio wheel SQLAlchemy is absent — the stdio path raises
    ``httpx.HTTPStatusError`` instead, and our ``except`` clauses should
    never fire. Returns a pair of synthetic never-matching exception
    classes in that case so the decorator + tool-level catches stay
    syntactically valid.

    Public so tool modules that need the same pair (e.g. ``tools/tasks.py``
    for its in-tool ``create_task`` / ``update_task`` catches) can reuse
    the resolver instead of duplicating it.
    """
    try:
        from sqlalchemy.exc import DBAPIError, IntegrityError

        return IntegrityError, DBAPIError
    except ImportError:  # pragma: no cover — defensive for wheel runtime

        class _NeverRaised(Exception):
            """Synthetic placeholder for environments without SQLAlchemy."""

        return _NeverRaised, _NeverRaised


def guard_db_errors(tool_name: str) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R | str]]]:
    """Wrap an async MCP tool so SQL errors never leak to the LLM/Sentry.

    Args:
        tool_name: Human-readable tool name used in the log line so operators
            can correlate a Sentry hit to the right tool without parsing
            tracebacks. Use the bare function name (``"complete_task"``,
            ``"batch_complete_instances"``).

    Returns:
        Decorator producing an async wrapper with signature
        ``Awaitable[R | str]`` — on success the inner ``R`` is returned;
        on a guarded DB exception, a sentinel string. For the 19 tools
        whose ``R`` is already ``str``, ``R | str`` collapses to ``str``
        and the surface is unchanged. For tools like ``plan_my_day``
        whose ``R`` is ``list[dict] | str``, the union absorbs the
        sentinel cleanly.

    Contract:
        - ``ValueError`` propagates unchanged.
        - ``IntegrityError`` → :data:`_INTEGRITY_RESPONSE`, logged at WARNING.
        - ``DBAPIError`` → :data:`_DBAPI_RESPONSE`, logged at WARNING.
        - Other exceptions propagate (with WARNING log including ``tool_name``).
    """

    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R | str]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R | str:
            try:
                return await func(*args, **kwargs)
            except ValueError:
                # Business-rule violations stay business-rule violations.
                # Each tool already has its own `except ValueError` blocks
                # that surface a friendly string; if a ValueError ever does
                # escape, we want it to propagate so the existing tool-level
                # tests catch the regression.
                raise
            except Exception as e:  # noqa: BLE001 — handled via isinstance below
                _IntegrityError, _DBAPIError = resolve_sqlalchemy_exc_classes()
                if isinstance(e, _IntegrityError):
                    # FK violations (deleted-user case, the WHENFUL-34 shape)
                    # and any other constraint failure. The raw exception
                    # contains SQL + parameters — never include `str(e)` in
                    # the response.
                    logger.warning(
                        "MCP %s hit IntegrityError: %s (likely deleted user or constraint violation)",
                        tool_name,
                        type(e.orig).__name__ if e.orig is not None else type(e).__name__,  # type: ignore[attr-defined]
                    )
                    return _INTEGRITY_RESPONSE
                if isinstance(e, _DBAPIError):
                    # Statement timeout, deadlock, asyncpg disconnect, etc.
                    # (the WHENFUL-33 shape).
                    logger.warning(
                        "MCP %s hit DBAPIError: %s",
                        tool_name,
                        type(e.orig).__name__ if e.orig is not None else type(e).__name__,  # type: ignore[attr-defined]
                    )
                    return _DBAPI_RESPONSE
                raise

        return wrapper

    return decorator


__all__ = ["guard_db_errors", "resolve_sqlalchemy_exc_classes"]
