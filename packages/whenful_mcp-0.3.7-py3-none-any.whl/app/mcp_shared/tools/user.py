"""User context MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534.

Tool count: 2 (whoami, get_preferences).

MCP-stdio full parity migration:
- `whoami` (2026-05-16): routes through the `Backend.whoami` operation
  instead of opening a session and reading the `User` row directly.
  Output string stays byte-identical with the pre-migration SQL path on
  the cloud side; stdio path now produces the same shape via REST.
- `get_preferences` (2026-05-13): already migrated to
  `Backend.get_preferences`.

This module is import-clean — no `app.*` imports outside `app.mcp_shared.*`.
"""

from __future__ import annotations

from ..error_guard import guard_db_errors
from . import Backend


def format_whoami(payload: dict[str, object], *, user_id: int = 0) -> str:
    """Render a whoami payload as the user-visible MCP tool string.

    Shared by both transports (cloud HTTP + stdio) so the formatted
    output is transport-symmetric — no inline duplicates. Includes
    ``tier`` and ``encryption_enabled`` per the Backend.whoami protocol
    contract (P0-C in PR #1620 plus P1-MCP1 in v0.1.3).

    ``user_id`` is the LLM-visible numeric identity for the "not found"
    branch. On the stdio path the Bearer token carries identity over
    the wire and the caller passes 0; on the cloud path the caller has
    the real ``user_id`` from the session. Either way the field shows
    up in the formatted string only when the payload is empty (404).
    """
    if not payload or "email" not in payload:
        return f"Authenticated as user_id={user_id} but user not found in database!"

    email = str(payload.get("email") or "")
    name_value = payload.get("name")
    name = str(name_value) if isinstance(name_value, str) and name_value else email
    data_version = payload.get("data_version")
    tier = payload.get("tier", "?")
    encryption_enabled = payload.get("encryption_enabled", "?")

    return (
        f"email: {email}\n"
        f"name: {name}\n"
        f"data_version: {data_version}\n"
        f"encryption_enabled: {encryption_enabled}\n"
        f"tier: {tier}"
    )


@guard_db_errors("whoami")
async def whoami(backend: Backend, user_id: int) -> str:
    payload = await backend.whoami(user_id)
    return format_whoami(payload, user_id=user_id)


@guard_db_errors("get_preferences")
async def get_preferences(backend: Backend, user_id: int) -> str:
    prefs = await backend.get_preferences(user_id)

    timezone = prefs.get("timezone")
    secondary_timezone = prefs.get("secondary_timezone")
    lines = ["User preferences:"]
    lines.append(f"  timezone: {timezone or 'not set'}")
    if secondary_timezone:
        lines.append(f"  secondary_timezone: {secondary_timezone}")
    lines.append(f"  show_completed_in_planner: {prefs.get('show_completed_in_planner', False)}")
    lines.append(f"  completed_retention_days: {prefs.get('completed_retention_days', 0)}")
    lines.append(f"  show_completed_in_list: {prefs.get('show_completed_in_list', False)}")
    lines.append(f"  show_scheduled_in_list: {prefs.get('show_scheduled_in_list', False)}")
    lines.append(f"  time_format: {prefs.get('time_format', '24h')}")
    lines.append(f"  encryption_enabled: {prefs.get('encryption_enabled', False)}")

    return "\n".join(lines)
