"""MCP tool implementations, grouped by resource.

Each module re-exports its public tool functions. Tools take `backend: Backend`
and `user_id: int` as their first two arguments — see
`app/mcp_shared/__init__.py` for the protocol contract.

The encryption helper (`check_encryption`) lives here rather than in
`mcp_shared.formatters` because it queries the data layer (via
``backend.whoami``) rather than purely formatting strings.

This is Phase A of MCP #13534. The HTTP server is the only consumer today;
the future stdio client will import the same tool functions and supply its
own `Backend` implementation.
"""

from __future__ import annotations

from .. import Backend


async def is_encrypted(backend: Backend, user_id: int) -> bool:
    """Quick check if user has E2E encryption enabled.

    Routed exclusively through ``backend.whoami`` so both transports
    answer symmetrically. The cloud HTTP backend's ``whoami`` runs a
    SELECT inside ``backend.session()``; the stdio backend's hits
    ``GET /me``. Errors raised by either path propagate to the caller
    — they signal a real transport failure that the caller is in a
    better position to surface to the LLM than this helper.

    P1-MCP2 (v0.1.3): the previous version had a fallback to a raw
    ``UserPreferences`` SELECT for callers that monkey-patched the
    session machinery in tests. That fallback imported ``app.models``
    lazily — and in the standalone whenful-mcp wheel ``app.models``
    doesn't exist, so any ``backend.whoami`` failure on stdio used to
    masquerade as ``ModuleNotFoundError``, masking the original
    transport error from the LLM. The fallback was removed entirely
    because no production caller relied on it (verified via grep on
    2026-05-16) and the lookalike behavior is now strictly safer.
    """
    payload = await backend.whoami(user_id)
    if isinstance(payload, dict) and "encryption_enabled" in payload:
        return bool(payload["encryption_enabled"])
    return False


async def resolve_domain_via_backend(
    backend: Backend,
    user_id: int,
    name: str,
) -> tuple[int | None, str | None]:
    """Resolve a domain name (case-insensitive) to a domain_id via the
    Backend's ``list_domains`` operation.

    Returns ``(domain_id, None)`` on success or ``(None, error_message)``
    when the name is unknown. The error message lists available (non-
    archived) domain names so the LLM can correct itself.

    Routed through ``backend.list_domains`` so the stdio path (which
    decrypts domain names client-side) and the HTTP path (which reads
    them straight from the ORM) both work.
    """
    domains = await backend.list_domains(user_id)
    match = next(
        (d for d in domains if isinstance(d.get("name"), str) and d["name"].lower() == name.lower()),
        None,
    )
    if match is not None:
        return int(match["id"]), None
    available = ", ".join(d["name"] for d in domains if isinstance(d.get("name"), str) and not d.get("is_archived"))
    return None, f"Domain '{name}' not found. Available: {available}"


async def check_encryption(backend: Backend, user_id: int) -> str | None:
    """Check if user has E2E encryption enabled. Returns error message or None.

    HTTP server uses this as a guard at the top of any tool that reads or
    writes encrypted columns (title/description/domain.name) — those tools
    can't function under encryption today because the server doesn't hold
    the key. The error string is the user-facing explanation; it must stay
    stable because Claude/Claude Desktop surface it directly.

    Bypassed entirely when the backend reports client-side crypto capability
    (``backend.supports_client_side_crypto()`` → True). That's the stdio
    path (``mcp_stdio.WhenfulClient``) with a ``CryptoManager`` loaded — the
    user supplied their passphrase during ``whenful-mcp setup``, so the
    client encrypts on write and decrypts on read before handing plaintext
    to the LLM. Encryption-on Pro users actually CAN use every MCP tool
    through their local install — without this bypass the shared gate
    inherited the cloud limitation as if it were universal, blocking the
    exact user segment the wheel was built for.

    Routed through ``is_encrypted`` so the stdio path (which has no
    ``UserPreferences`` SQL surface) resolves via ``whoami``.
    """
    if backend.supports_client_side_crypto():
        return None
    if await is_encrypted(backend, user_id):
        return (
            "E2E encryption is enabled on your account. MCP tools cannot read or write "
            "encrypted data (task titles, descriptions, domain names are ciphertext on the server). "
            "Disable E2E encryption in whenful Settings to use MCP integration."
        )
    return None


__all__ = [
    "Backend",
    "check_encryption",
    "is_encrypted",
    "resolve_domain_via_backend",
]
