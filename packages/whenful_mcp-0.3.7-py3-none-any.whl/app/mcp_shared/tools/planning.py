"""Planning MCP tools (transport-agnostic).

PR 1 of the MCP-distribution council ship list. Per the principal override
on 2026-05-19 (artifact:
``docs/plans/2026-05-19-council-mcp-distribution-architecture.md``), the
web UI's ``Plan My Day`` button stays. Feature parity demands an MCP tool
with the same shape so an AI agent can propose placements with the same
semantics — hence ``plan_my_day``.

**Read-only.** The tool returns proposals; the caller (an agent) then
decides which to commit via subsequent ``update_task`` calls. Zero DB
writes happen inside this tool.

Tool count: 1 (``plan_my_day``).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from ..error_guard import guard_db_errors
from . import Backend, check_encryption


def _parse_iso_datetime(value: str, label: str) -> datetime | str:
    """Parse an ISO 8601 datetime. Returns the ``datetime`` or an error string.

    Accepts ``YYYY-MM-DDTHH:MM`` / ``YYYY-MM-DDTHH:MM:SS`` with optional
    timezone offset (``Z`` or ``±HH:MM``). Naive datetimes are returned
    naive — the caller is responsible for attaching the user's local
    timezone (see ``plan_my_day``). We do not accept plain ``YYYY-MM-DD``
    because ``plan_my_day`` needs an actual time window, not a date.
    """
    try:
        # ``datetime.fromisoformat`` handles offsets, ``Z``, and naive forms.
        # Normalize ``Z`` → ``+00:00`` for Python < 3.11 compatibility just
        # in case (cheap no-op on 3.11+).
        normalized = value.replace("Z", "+00:00") if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
    except (TypeError, ValueError) as exc:
        return f"Invalid {label}: {exc}. Expected ISO 8601 datetime (e.g. '2026-05-20T09:00')."
    return parsed


@guard_db_errors("plan_my_day")
async def plan_my_day(
    backend: Backend,
    user_id: int,
    start_time: str,
    end_time: str,
    energy_level: str | None = None,
    domain_ids: list[int] | None = None,
    impact_min: int = 4,
) -> list[dict[str, Any]] | str:
    """Propose a compact placement of unscheduled tasks into a time window.

    Read-only — the tool returns proposals only. The agent caller decides
    which (if any) to commit via subsequent ``update_task`` calls that the
    user can confirm.

    Args:
        backend: Transport-agnostic backend (HTTP or stdio).
        user_id: Authenticated user. All queries scope to this user.
        start_time: Window start as ISO 8601 datetime
            (``YYYY-MM-DDTHH:MM[:SS][±HH:MM]``).
        end_time: Window end as ISO 8601 datetime. Should fall on the
            same calendar day as ``start_time`` — the service layer clamps
            to end-of-day if not.
        energy_level: Optional clarity filter: ``autopilot`` / ``normal`` /
            ``brainstorm``. ``None`` admits all.
        domain_ids: Optional list of domain IDs. ``None`` admits all
            domains (including the domain-less inbox).
        impact_min: Maximum impact value (i.e. minimum priority bucket).
            Defaults to 4 (everything). Use 1 to take only the highest
            priority tasks.

    Returns:
        A list of proposal dicts on success::

            [{"task_id": 12, "scheduled_date": "2026-05-20",
              "scheduled_hour": 9, "scheduled_minutes": 30,
              "duration_minutes": 30},
             ...]

        Or an error string when input parsing fails / encryption blocks
        the call. The string return is the MCP convention for inline
        errors the LLM should surface to the user verbatim.
    """
    # Encryption gate: ``Plan My Day`` doesn't directly return task content
    # (titles/descriptions), but it consumes them server-side to filter by
    # clarity and order by impact. The proposal payload itself is
    # content-free (IDs + times), so an encryption-on user could in
    # principle still use the tool — but only via the stdio path that
    # has the user's key. Apply the standard gate; ``check_encryption``
    # bypasses itself when the backend supports client-side crypto.
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Stdio transport short-circuit. The wheel ships only ``app.mcp_shared``
    # and ``mcp_stdio`` — ``app.services.plan_my_day`` is not on the Python
    # path, so reaching the import line below would crash with
    # ``ModuleNotFoundError``. The previous version of this guard checked
    # ``supports_client_side_crypto()`` which is True only for the Pro
    # encryption-on stdio user; encryption-off stdio users fell through to
    # the import and saw the wheel crash. ``is_local()`` answers the actual
    # question — "are we running in the standalone wheel?" — and decouples
    # the discriminator from crypto state. Distinct method on purpose; see
    # the protocol docstring in ``app/mcp_shared/__init__.py``.
    if backend.is_local():
        return (
            "plan_my_day is not yet supported on the local stdio transport. "
            "Use the cloud HTTP MCP server (whenful.com/mcp), or the Plan My Day "
            "button in the Whenful web app."
        )

    start_dt = _parse_iso_datetime(start_time, "start_time")
    if isinstance(start_dt, str):
        return start_dt
    end_dt = _parse_iso_datetime(end_time, "end_time")
    if isinstance(end_dt, str):
        return end_dt

    if energy_level is not None and energy_level not in {"autopilot", "normal", "brainstorm"}:
        return "energy_level must be one of: autopilot, normal, brainstorm."
    if not isinstance(impact_min, int) or impact_min < 1 or impact_min > 4:
        return "impact_min must be an integer in [1, 4]."
    if domain_ids is not None and not all(isinstance(d, int) for d in domain_ids):
        return "domain_ids must be a list of integers."

    # F5 — naive datetimes from the LLM are interpreted as user-local time,
    # not UTC. ``datetime.fromisoformat("2026-05-20T09:00")`` returns a
    # naive datetime; the service layer's ``_to_local`` used to fall back
    # to UTC for naive inputs, which silently shifted the planning window
    # by the user's UTC offset (e.g. an LA user asking to "plan 9 AM"
    # ended up planning 9 AM UTC = 2 AM LA = empty calendar). Anchor to
    # the user's IANA timezone here so naive input matches "their" clock.
    # Aware datetimes flow through unchanged — they carry their own offset.
    #
    # Imported locally so the wheel doesn't need to ship ``app.services``
    # for the stdio short-circuit case above. We've already returned for
    # ``is_local()=True``; this import only executes on the cloud path.
    from app.services.preferences_service import PreferencesService

    async with backend.session() as db:
        if start_dt.tzinfo is None or end_dt.tzinfo is None:
            tz_name = await PreferencesService(db, user_id).get_timezone()
            try:
                user_zone = ZoneInfo(tz_name) if tz_name else ZoneInfo("UTC")
            except Exception:
                user_zone = ZoneInfo("UTC")
            if start_dt.tzinfo is None:
                start_dt = start_dt.replace(tzinfo=user_zone)
            if end_dt.tzinfo is None:
                end_dt = end_dt.replace(tzinfo=user_zone)

        # Order check happens after timezone attachment so naive+aware
        # mixes compare correctly. Both are now tz-aware (or both already
        # were).
        if end_dt <= start_dt:
            return "end_time must be after start_time."

        # Local import keeps the standalone whenful-mcp wheel buildable: the
        # service module pulls in app.models / app.services / sqlalchemy that
        # the wheel deliberately does not ship. The ``is_local()`` short-
        # circuit above guarantees we only reach this line on the cloud path.
        from app.services.plan_my_day import Proposal, propose_plan

        proposals: list[Proposal] = await propose_plan(
            db,
            user_id,
            start_dt,
            end_dt,
            energy_level=energy_level,
            domain_ids=domain_ids,
            impact_min=impact_min,
        )

    return [
        {
            "task_id": p.task_id,
            "scheduled_date": p.scheduled_date.isoformat(),
            "scheduled_hour": p.scheduled_hour,
            "scheduled_minutes": p.scheduled_minutes,
            "duration_minutes": p.duration_minutes,
        }
        for p in proposals
    ]


__all__ = ["plan_my_day"]
