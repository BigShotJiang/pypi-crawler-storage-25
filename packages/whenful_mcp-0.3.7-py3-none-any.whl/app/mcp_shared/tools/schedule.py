"""Schedule and analytics MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534.

Tool count: 4 (get_schedule, get_overdue, get_analytics, get_recent_completions).

MCP-stdio full parity migration (2026-05-13): each tool now calls the
`Backend` operation directly instead of opening a `backend.session()` and
running raw SQL. Both `_DBBackend` (HTTP) and `WhenfulClient` (stdio)
satisfy the same operation contract, so this single tool body works for
both transports. Output strings stay byte-identical with the pre-migration
SQL path.
"""

from __future__ import annotations

from ..error_guard import guard_db_errors
from ..formatters import IMPACT_LABELS, format_instance, format_task
from ..validators import parse_date
from . import Backend, check_encryption


@guard_db_errors("get_schedule")
async def get_schedule(
    backend: Backend,
    user_id: int,
    date_from: str | None = None,
    date_to: str | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Resolve "today" via the preferences operation so this tool stays
    # transport-agnostic (no direct DB access). The op call is cheap on
    # both backends — a single SELECT on HTTP and a single GET on stdio.
    if not date_from or not date_to:
        prefs = await backend.get_preferences(user_id)
        timezone = prefs.get("timezone")
        from app.mcp_shared.constants import get_user_today

        today_iso = get_user_today(timezone).isoformat()
        if not date_from:
            date_from = today_iso
        if not date_to:
            date_to = date_from

    parsed_from = parse_date(date_from, "date_from")
    if isinstance(parsed_from, str):
        return parsed_from
    parsed_to = parse_date(date_to, "date_to")
    if isinstance(parsed_to, str):
        return parsed_to

    schedule = await backend.get_schedule(user_id, date_from=date_from, date_to=date_to)
    tasks = schedule.get("tasks", []) or []
    instances = schedule.get("instances", []) or []

    lines: list[str] = []
    if date_from == date_to:
        lines.append(f"Schedule for {date_from}:")
    else:
        lines.append(f"Schedule for {date_from} -> {date_to}:")

    if tasks:
        lines.append(f"\n--- Tasks ({len(tasks)}) ---")
        for t in tasks:
            lines.append(format_task(t))

    if instances:
        lines.append(f"\n--- Recurring ({len(instances)}) ---")
        for inst in instances:
            lines.append(format_instance(inst))

    if not tasks and not instances:
        lines.append("\nNothing scheduled.")

    return "\n".join(lines)


@guard_db_errors("get_overdue")
async def get_overdue(backend: Backend, user_id: int) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    overdue_payload = await backend.get_overdue(user_id)
    today_iso = overdue_payload.get("today", "")
    overdue = overdue_payload.get("tasks", []) or []
    past_instance_count = overdue_payload.get("past_instance_count", 0) or 0

    lines = [f"Overdue summary as of {today_iso}:"]

    if overdue:
        lines.append(f"\n--- Overdue tasks ({len(overdue)}) ---")
        for t in overdue:
            lines.append(format_task(t))

    if past_instance_count > 0:
        lines.append(f"\n--- Past recurring instances: {past_instance_count} pending ---")

    if not overdue and past_instance_count == 0:
        lines.append("\nAll caught up! Nothing overdue.")

    return "\n".join(lines)


@guard_db_errors("get_analytics")
async def get_analytics(backend: Backend, user_id: int, days: int = 30) -> str:
    days = max(7, min(90, days))  # Clamp to valid range

    data = await backend.get_analytics(user_id, days=days)

    lines = [f"Analytics (last {days} days):"]

    if data.get("streaks"):
        s = data["streaks"]
        lines.append(f"\nStreaks: current={s.get('current', 0)} days, best={s.get('longest', 0)} days")

    if "total_completed" in data:
        lines.append(f"Total completed: {data['total_completed']}")
    if "total_pending" in data:
        lines.append(f"Total pending: {data['total_pending']}")

    if data.get("by_domain"):
        lines.append("\nBy domain:")
        for entry in data["by_domain"]:
            lines.append(f"  {entry.get('domain_name', 'No domain')}: {entry.get('count', 0)} completed")

    if data.get("impact_distribution"):
        lines.append("\nBy impact:")
        for entry in data["impact_distribution"]:
            label = IMPACT_LABELS.get(entry.get("impact"), "?")
            lines.append(f"  {label}: {entry.get('count', 0)}")

    return "\n".join(lines)


@guard_db_errors("get_recent_completions")
async def get_recent_completions(backend: Backend, user_id: int, limit: int = 20) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    completions = await backend.get_recent_completions(user_id, limit=limit)

    if not completions:
        return "No recent completions."

    lines = [f"Recent completions ({len(completions)}):"]
    for c in completions:
        instance_tag = " (recurring)" if c.get("is_instance") else ""
        lines.append(
            f"  [{c.get('completed_at_display', '?')}] {c['title']}{instance_tag}  #{c.get('domain_name', 'Thoughts')}"
        )

    return "\n".join(lines)
