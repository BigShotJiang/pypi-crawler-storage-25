"""Domain MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534.
Refactored in mcp-stdio-full-parity (2026-05-13) to call
``backend.{list,create,update,archive}_domain`` instead of opening a raw
``backend.session()``. The HTTP backend's operations wrap the same
``TaskService`` calls; the stdio backend wraps REST + client-side
encryption. Tool output formatting is unchanged.

Tool count: 4 (list_domains, create_domain, update_domain, archive_domain).
"""

from __future__ import annotations

import logging

from ..error_guard import guard_db_errors
from ..validators import strip_control_chars
from . import Backend, check_encryption

logger = logging.getLogger("whenful.mcp")


@guard_db_errors("list_domains")
async def list_domains(backend: Backend, user_id: int) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    domains = await backend.list_domains(user_id)

    if not domains:
        return "No domains found."

    lines = []
    for d in domains:
        archived = " (archived)" if d.get("is_archived") else ""
        lines.append(f"- [id:{d['id']}] {d['name']}{archived}")

    return f"{len(domains)} domain(s):\n\n" + "\n".join(lines)


@guard_db_errors("create_domain")
async def create_domain(
    backend: Backend,
    user_id: int,
    name: str,
    color: str | None = None,
    icon: str | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    if not name or not name.strip():
        return "Domain name cannot be empty."
    if len(name) > 255:
        return "Domain name cannot exceed 255 characters."

    domain = await backend.create_domain(
        user_id,
        name=strip_control_chars(name).strip(),
        color=color,
        icon=icon,
    )
    return f"Created domain [id:{domain['id']}]: {domain['name']}"


@guard_db_errors("update_domain")
async def update_domain(
    backend: Backend,
    user_id: int,
    domain_id: int,
    name: str | None = None,
    color: str | None = None,
    icon: str | None = None,
    position: int | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    if name is None and color is None and icon is None and position is None:
        return "Nothing to update -- provide at least one field."

    if name is not None:
        if not name.strip():
            return "Domain name cannot be empty."
        if len(name) > 255:
            return "Domain name cannot exceed 255 characters."

    clean_name = strip_control_chars(name).strip() if name else name
    domain = await backend.update_domain(
        user_id,
        domain_id,
        name=clean_name,
        color=color,
        icon=icon,
        position=position,
    )
    if domain is None:
        return f"Domain {domain_id} not found or not owned by you."

    logger.info(f"MCP update_domain: domain_id={domain_id} user_id={user_id}")
    return f"Updated domain [id:{domain_id}]: {domain['name']}"


@guard_db_errors("archive_domain")
async def archive_domain(backend: Backend, user_id: int, domain_id: int) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    domain = await backend.archive_domain(user_id, domain_id)
    if domain is None:
        return f"Domain {domain_id} not found or not owned by you."

    logger.info(f"MCP archive_domain: domain_id={domain_id} user_id={user_id}")
    return f"Archived domain [id:{domain_id}]: {domain['name']}"
