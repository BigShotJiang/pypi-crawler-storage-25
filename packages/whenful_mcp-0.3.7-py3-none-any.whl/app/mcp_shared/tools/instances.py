"""Recurring task instance MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534, and
rewritten in MCP-stdio full-parity (#13534) to consume the Backend
operations API instead of raw SQL. Each tool now delegates to one of the
9 instance operations defined on the Backend protocol — `_DBBackend`
performs the SQL + commit + GCal sync inside the operation, and
`WhenfulClient` makes the equivalent REST call. The tool layer's job
shrinks to:

1. Validate inputs (date strings, action strings, the date-only-vs-
   full-datetime parsing for ``reschedule_instance``).
2. Invoke the operation.
3. Format the returned dict via `_format_instance` / inline text.

Tool count: 9 (complete_instance, uncomplete_instance, skip_instance,
unskip_instance, reschedule_instance, batch_complete_instances,
batch_past_instances, pending_past_count, list_past_instances).

Behavior contract: zero regressions vs the prior in-tool SQL paths.
Including the date-only reschedule timezone preservation logic (C9 P1
audit fix) — kept here because the user's timezone is the input to the
fold, and operations don't see it. The operation receives an already-
resolved aware ``datetime``.
"""

from __future__ import annotations

import logging
from datetime import UTC, date, datetime, time
from typing import Literal
from zoneinfo import ZoneInfo

from ..error_guard import guard_db_errors
from ..formatters import format_instance, format_task, pagination_footer
from ..validators import parse_date
from . import Backend, check_encryption

logger = logging.getLogger("whenful.mcp")


async def _lookup_existing_wall_clock(backend: Backend, user_id: int, instance_id: int) -> tuple[time, ZoneInfo]:
    """Return ``(existing_local_time, user_tz)`` for the date-only reschedule path.

    Delegates to the ``Backend.get_instance_wall_clock`` operation so this
    helper is import-clean (no ORM imports). Cloud backend reads the DB +
    user preferences server-side; stdio backend returns ``None`` (documented
    v1 degradation: date-only reschedules from stdio drop the wall-clock,
    full-datetime reschedules are unaffected).

    On any failure (op returned ``None``, instance missing, no
    scheduled_datetime, or backend has no DB) we fall back to ``(midnight, UTC)``.
    """
    fallback_time = datetime.min.time()
    fallback_tz = ZoneInfo("UTC")

    payload = await backend.get_instance_wall_clock(user_id, instance_id)
    if payload is None:
        return fallback_time, fallback_tz

    local_time_iso, tz_name = payload
    try:
        parsed_time = time.fromisoformat(local_time_iso)
    except ValueError:
        parsed_time = fallback_time
    try:
        user_tz = ZoneInfo(tz_name) if tz_name else fallback_tz
    except (KeyError, TypeError):
        user_tz = fallback_tz
    return parsed_time, user_tz


@guard_db_errors("complete_instance")
async def complete_instance(backend: Backend, user_id: int, instance_id: int) -> str:
    instance = await backend.complete_instance(user_id, instance_id=instance_id)
    if instance is None:
        return f"Instance {instance_id} not found or not owned by you."
    return f"Completed instance [inst:{instance.get('instance_id', instance_id)}] of task [id:{instance['task_id']}]"


@guard_db_errors("skip_instance")
async def skip_instance(backend: Backend, user_id: int, instance_id: int) -> str:
    instance = await backend.skip_instance(user_id, instance_id=instance_id)
    if instance is None:
        return f"Instance {instance_id} not found or not owned by you."
    logger.info(f"MCP skip_instance: instance_id={instance_id} user_id={user_id}")
    return f"Skipped instance [inst:{instance.get('instance_id', instance_id)}] of task [id:{instance['task_id']}]"


@guard_db_errors("unskip_instance")
async def unskip_instance(backend: Backend, user_id: int, instance_id: int) -> str:
    instance = await backend.unskip_instance(user_id, instance_id=instance_id)
    if instance is None:
        return f"Instance {instance_id} not found or not owned by you."
    logger.info(f"MCP unskip_instance: instance_id={instance_id} user_id={user_id}")
    return (
        f"Unskipped instance [inst:{instance.get('instance_id', instance_id)}] "
        f"of task [id:{instance['task_id']}] — now pending"
    )


@guard_db_errors("uncomplete_instance")
async def uncomplete_instance(backend: Backend, user_id: int, instance_id: int) -> str:
    instance = await backend.uncomplete_instance(user_id, instance_id=instance_id)
    if instance is None:
        return f"Instance {instance_id} not found or not owned by you."
    logger.info(f"MCP uncomplete_instance: instance_id={instance_id} user_id={user_id}")
    return (
        f"Uncompleted instance [inst:{instance.get('instance_id', instance_id)}] "
        f"of task [id:{instance['task_id']}] — now pending"
    )


@guard_db_errors("reschedule_instance")
async def reschedule_instance(
    backend: Backend,
    user_id: int,
    instance_id: int,
    new_datetime: str,
) -> str:
    """Reschedule a recurring instance.

    ``new_datetime`` accepts:
    - ``YYYY-MM-DD`` (date-only) — preserves the existing wall-clock time
      in the user's timezone. The C9 P1 audit fix lives here: we look up
      the existing scheduled_datetime, convert it to user-local time,
      combine with the new date in user-local, then convert back to UTC.
      That avoids the double-conversion bug that previously shifted the
      wall-clock by the user's UTC offset on every date-only reschedule.
    - ``YYYY-MM-DDTHH:MM`` (full datetime) — passed through as-is.

    Validation lives in the tool layer (not the operation) because the
    operation accepts a Python ``datetime`` directly; the tool is what
    parses the wire string from the LLM and decides which branch to take.
    """
    # Accept both date-only (YYYY-MM-DD) and full datetime (YYYY-MM-DDTHH:MM).
    #
    # Note: datetime.fromisoformat("2026-05-22") succeeds on Python 3.11+ and
    # returns a midnight naive datetime, so we cannot rely on its ValueError
    # to detect date-only input. Detect by presence of the time separator.
    is_date_only = "T" not in new_datetime and " " not in new_datetime
    new_dt: datetime
    if is_date_only:
        try:
            parsed_date = date.fromisoformat(new_datetime)
        except ValueError:
            return f"Invalid new_datetime: '{new_datetime}'. Expected YYYY-MM-DD or YYYY-MM-DDTHH:MM."

        # Preserve existing scheduled WALL-CLOCK time in the USER'S timezone when
        # only a date is provided.
        #
        # Audit Group C9 P1 bug (pre-fix): the old code called existing_dt.time()
        # on a UTC-stored datetime, which strips tzinfo. Combining that naive
        # UTC time with the new date produced a naive datetime that
        # schedule_instance -> _ensure_utc -> _to_utc_datetime then re-interpreted
        # as USER-LOCAL and converted to UTC again — shifting wall-clock time by
        # the user's UTC offset on every date-only reschedule (5h shift in NY,
        # 9h in Tokyo, and compounding on repeated reschedules).
        #
        # On Python 3.11+ the bug was even worse because the prior date-only
        # branch was unreachable (datetime.fromisoformat accepts "YYYY-MM-DD"
        # and returns midnight), so date-only reschedules silently reset the
        # wall-clock time to 00:00 in the user's timezone. We fix both by
        # detecting date-only explicitly and converting through the user's TZ.
        #
        # Wall-clock preservation requires server-side state (the existing
        # ``scheduled_datetime`` plus the user's timezone). For the cloud
        # backend we read it via ``backend.session()`` — the operation API
        # doesn't currently expose a single-instance getter and we don't
        # want to bloat it just for this corner. For the stdio backend
        # (whose ``session()`` yields the client itself, not a DB), we
        # fall back to midnight in UTC: full-datetime reschedules work
        # perfectly, date-only reschedules drop the wall-clock — a
        # documented v1 stdio limitation.
        existing_local_time, user_tz = await _lookup_existing_wall_clock(backend, user_id, instance_id)
        new_local_dt = datetime.combine(parsed_date, existing_local_time, tzinfo=user_tz)
        # Tag UTC explicitly so schedule_instance -> _ensure_utc treats it as
        # already-UTC (no-op) instead of re-interpreting as user-local.
        new_dt = new_local_dt.astimezone(UTC)
    else:
        try:
            new_dt = datetime.fromisoformat(new_datetime)
        except ValueError:
            return f"Invalid new_datetime: '{new_datetime}'. Expected YYYY-MM-DD or YYYY-MM-DDTHH:MM."

    instance = await backend.reschedule_instance(user_id, instance_id=instance_id, new_datetime=new_dt)
    if instance is None:
        return f"Instance {instance_id} not found or not owned by you."
    logger.info(f"MCP reschedule_instance: instance_id={instance_id} new_datetime={new_datetime} user_id={user_id}")
    rendered_id = instance.get("instance_id") or instance.get("id") or instance_id
    return f"Rescheduled instance [inst:{rendered_id}] to {new_datetime}"


@guard_db_errors("batch_complete_instances")
async def batch_complete_instances(
    backend: Backend,
    user_id: int,
    task_id: int,
    before_date: str,
) -> str:
    parsed_date = parse_date(before_date, "before_date")
    if isinstance(parsed_date, str):
        return parsed_date

    result = await backend.batch_complete_instances(user_id, task_id=task_id, before_date=parsed_date)
    count = int(result.get("completed_count", 0))
    logger.info(f"MCP batch_complete_instances: task_id={task_id} before={before_date} count={count} user_id={user_id}")
    return f"Completed {count} instance(s) for task [id:{task_id}] before {before_date}."


@guard_db_errors("batch_past_instances")
async def batch_past_instances(backend: Backend, user_id: int, action: Literal["complete", "skip"]) -> str:
    # `action` is constrained to the two-value Literal at the MCP boundary;
    # an invalid value is rejected by FastMCP before this function runs.
    result = await backend.batch_past_instances(user_id, action=action)
    count = int(result.get("affected_count", 0))
    logger.info(f"MCP batch_past_instances: action={action} count={count} user_id={user_id}")
    verb = "Completed" if action == "complete" else "Skipped"
    return f"{verb} {count} past instance(s)."


@guard_db_errors("pending_past_count")
async def pending_past_count(backend: Backend, user_id: int) -> str:
    count = await backend.pending_past_count(user_id)
    if count == 0:
        return "No pending past instances — all caught up!"
    return f"{count} pending past instance(s). Use batch_past_instances to complete or skip them."


@guard_db_errors("list_past_instances")
async def list_past_instances(backend: Backend, user_id: int, limit: int = 50, offset: int = 0) -> str:
    """Drill into pending past recurring instances, grouped by parent task."""
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Over-fetch +1 so we can detect has_more and emit a pagination footer
    # (Whenful #14603). The backend orders by ``pending_count`` desc, so the
    # extra row would be the next-heaviest parent — safe to drop after slice.
    overfetch = limit + 1 if limit and limit > 0 else limit
    rows = await backend.list_past_instances(user_id, limit=overfetch, offset=offset)
    has_more = limit > 0 and len(rows) > limit
    if has_more:
        rows = rows[:limit]
    if not rows:
        return "No pending past instances — all caught up!"

    total = sum(int(row.get("pending_count", 0)) for row in rows)
    lines = [f"{total} pending past instance(s) across {len(rows)} task(s):\n"]
    for row in rows:
        notes: list[str] = []
        if not row.get("is_recurring", True):
            notes.append("orphan: parent not recurring")
        parent_status = row.get("parent_status", "pending")
        if parent_status != "pending":
            notes.append(f"parent {parent_status}")
        warn = f"  [{'; '.join(notes)}]" if notes else ""

        # ``format_task`` expects an "id" key — supply the parent's task_id.
        parent_dict = {
            "id": row.get("task_id"),
            "title": row.get("title", "Recurring task"),
            "is_recurring": row.get("is_recurring", True),
            "status": parent_status,
            "domain_name": row.get("domain_name"),
        }
        base = format_task(parent_dict)
        first_date = row.get("first_date")
        last_date = row.get("last_date")
        lines.append(f"{base}  ({row.get('pending_count')} pending, {first_date} -> {last_date}){warn}")
    body = "\n".join(lines)
    return body + pagination_footer(
        has_more=has_more,
        next_offset=(offset or 0) + limit if has_more else None,
        noun="parent task",
    )


# ``format_instance`` is unused now but kept on the re-export list because
# callers (test_mcp.py) may import it transitively. The shared formatter
# module is the canonical home.
_ = format_instance
