"""Task CRUD MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534. Each
function takes `backend: Backend` and `user_id: int` as its first two
parameters and runs the same business logic the HTTP MCP previously ran
inline. The HTTP server's thin wrappers in `mcp_server.py` supply a DB
backend; the future stdio client (Phase B+) will supply an HTTP-client
backend without any change to this code.

Tool count: 17 (list_tasks, list_thoughts, list_recurring_tasks,
get_task, create_task, update_task, complete_task, uncomplete_task,
toggle_complete, nuke_task, archive_task, restore_task,
get_archived_tasks, search_tasks, batch_create_tasks,
batch_update_tasks, batch_complete_tasks).

Behavior contract: zero regressions vs the inlined originals. All
user-facing strings, validation messages, and side-effect orderings
(GCal sync via fire_and_forget, materialize_instances on recurrence,
reminder_sent_at reset, etc.) are preserved 1:1. `tests/test_mcp.py`
pins this contract.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, date, datetime
from typing import Any

from pydantic import ValidationError

from ..constants import GCAL_SYNC_DEFAULT_DURATION_MINUTES
from ..error_guard import guard_db_errors, resolve_sqlalchemy_exc_classes
from ..formatters import IMPACT_LABELS, format_task, pagination_footer, safe_title
from ..schemas import RecurrenceRuleSchema
from ..validators import (
    VALID_CLARITY,
    VALID_LIST_STATUS,
    parse_date,
    parse_time,
    strip_control_chars,
    validate_task_fields,
)
from . import Backend, check_encryption, is_encrypted, resolve_domain_via_backend

logger = logging.getLogger("whenful.mcp")


def _format_validation_error(field: str, exc: ValidationError) -> str:
    """First-error one-liner for Pydantic ValidationError. MCP responses are
    in-band strings, so a flat hint beats a multi-line dump for LLM callers.
    """
    errs = exc.errors()
    if not errs:
        return f"Invalid {field}: validation failed"
    first = errs[0]
    loc = ".".join(str(p) for p in first.get("loc", ())) or "(root)"
    return f"Invalid {field}: {loc}: {first.get('msg', 'invalid')}"


def _coerce_recurrence_rule(
    raw: RecurrenceRuleSchema | dict[str, Any] | None,
    field: str = "recurrence_rule",
) -> tuple[dict[str, Any] | None, str | None]:
    """Normalize a recurrence_rule param into the dict shape the op expects.

    Accepts either a fully-validated `RecurrenceRuleSchema` (single-task tools
    that declare it directly) or a raw dict (batch_create_tasks item that
    arrives nested inside a `list[dict]`). Returns `(rule_dict, None)` on
    success or `(None, error_message)` on failure.
    """
    if raw is None:
        return None, None
    if isinstance(raw, RecurrenceRuleSchema):
        return raw.model_dump(exclude_none=True), None
    if not isinstance(raw, dict):
        return None, f"Invalid {field}: must be an object with freq/interval/days_of_week/…"
    try:
        validated = RecurrenceRuleSchema.model_validate(raw)
    except ValidationError as e:
        return None, _format_validation_error(field, e)
    return validated.model_dump(exclude_none=True), None


@guard_db_errors("list_tasks")
async def list_tasks(
    backend: Backend,
    user_id: int,
    domain: str | None = None,
    status: str = "pending",
    scheduled_date: str | None = None,
    clarity: str | None = None,
    impact: int | None = None,
    is_recurring: bool | None = None,
    parent_id: int | None = None,
    limit: int = 50,
    offset: int = 0,
) -> str:
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    if clarity is not None and clarity not in VALID_CLARITY:
        return f"Invalid clarity '{clarity}'. Must be one of: {', '.join(sorted(VALID_CLARITY))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Resolve domain name to ID via the backend's `list_domains` op so the
    # tool stays transport-agnostic.
    domain_id = None
    if domain:
        domain_id, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error

    # Validate the scheduled_date wire string up-front. The backend op also
    # accepts an ISO string and returns ``[]`` on a parse failure, but
    # surfacing a clear human-readable error here matches the pre-refactor
    # tool behavior.
    parsed_scheduled_date = None
    if scheduled_date:
        parsed = parse_date(scheduled_date, "scheduled_date")
        if isinstance(parsed, str):
            return parsed
        parsed_scheduled_date = parsed

    # "all" returns pending + completed, excludes archived (mirrors REST
    # tasks.py:498-500). The Backend protocol handles the derivation via the
    # paired `status` + `exclude_statuses` filters.
    effective_status = "all" if status == "all" else status
    effective_exclude = ["archived"] if status == "all" else None

    # Subtask listing inherits parent's domain — has_domain filter would be
    # redundant and could mask legitimate subtask rows. Only apply the
    # thoughts-exclusion when listing top-level tasks without a domain filter.
    has_domain_filter = None if (parent_id is not None or domain_id is not None) else True

    # Whenful #14603: detect "more rows exist" by over-fetching one row beyond
    # ``limit``. If the backend returns ``limit+1`` items we know there's at
    # least one more; trim back to ``limit`` for the response and emit a
    # pagination footer so the caller (often an LLM) can issue a follow-up
    # with the suggested ``next_offset``. Used uniformly across MCP list tools.
    overfetch = limit + 1 if limit and limit > 0 else None

    tasks = await backend.list_tasks(
        user_id,
        domain_id=domain_id,
        status=effective_status,
        scheduled_date=parsed_scheduled_date.isoformat() if parsed_scheduled_date else None,
        is_recurring=is_recurring,
        clarity=clarity,
        parent_id=parent_id,
        limit=overfetch,
        offset=offset if offset else None,
        top_level_only=parent_id is None,
        has_domain=has_domain_filter,
        exclude_statuses=effective_exclude,
        impact=impact,
    )

    has_more = overfetch is not None and len(tasks) > limit
    if has_more:
        tasks = tasks[:limit]

    if not tasks:
        return "No tasks found matching filters."

    lines = [format_task(t) for t in tasks]
    body = f"{len(tasks)} task(s):\n\n" + "\n".join(lines)
    return body + pagination_footer(
        has_more=has_more,
        next_offset=(offset or 0) + limit if has_more else None,
        noun="task",
    )


@guard_db_errors("list_thoughts")
async def list_thoughts(
    backend: Backend,
    user_id: int,
    status: str = "pending",
    limit: int = 50,
    offset: int = 0,
) -> str:
    """List untriaged inbox items ("thoughts") — tasks that have no domain yet."""
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Over-fetch +1 to detect has_more (Whenful #14603). See list_tasks above.
    overfetch = limit + 1 if limit and limit > 0 else limit
    thoughts = await backend.list_thoughts(user_id, status=status, limit=overfetch, offset=offset)

    has_more = limit > 0 and len(thoughts) > limit
    if has_more:
        thoughts = thoughts[:limit]

    if not thoughts:
        return "No thoughts in the inbox."

    lines = [format_task(t) for t in thoughts]
    body = f"{len(thoughts)} thought(s) in inbox:\n\n" + "\n".join(lines)
    return body + pagination_footer(
        has_more=has_more,
        next_offset=(offset or 0) + limit if has_more else None,
        noun="thought",
    )


@guard_db_errors("list_recurring_tasks")
async def list_recurring_tasks(
    backend: Backend,
    user_id: int,
    status: str = "pending",
) -> str:
    """List recurring parent tasks with pending-instance backlog summary."""
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    parents = await backend.list_recurring_tasks(user_id, status=status)

    if not parents:
        return f"No recurring tasks found (status={status})."

    # Order by pending_count desc — mirrors the original SQL path's sort.
    ordered = sorted(parents, key=lambda p: p.get("pending_count") or 0, reverse=True)

    lines = [f"{len(ordered)} recurring task(s):\n"]
    for parent in ordered:
        base = format_task(parent)
        count = parent.get("pending_count") or 0
        if count > 0:
            suffix = f"  ({count} pending, {parent.get('first_pending_date')} -> {parent.get('last_pending_date')})"
        else:
            suffix = "  (0 pending)"
        lines.append(base + suffix)
    return "\n".join(lines)


@guard_db_errors("create_task")
async def create_task(
    backend: Backend,
    user_id: int,
    title: str,
    domain: str | None = None,
    impact: int = 4,
    clarity: str = "normal",
    duration_minutes: int | None = None,
    scheduled_date: str | None = None,
    scheduled_time: str | None = None,
    description: str | None = None,
    parent_id: int | None = None,
    is_recurring: bool = False,
    recurrence_rule: RecurrenceRuleSchema | dict[str, Any] | None = None,
    recurrence_start: str | None = None,
    recurrence_end: str | None = None,
    reminder_minutes_before: int | None = None,
    is_habit: bool = False,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate inputs (mirrors REST Pydantic validation)
    validation_error = validate_task_fields(
        title=title,
        impact=impact,
        clarity=clarity,
        duration_minutes=duration_minutes,
        reminder_minutes_before=reminder_minutes_before,
        description=description,
    )
    if validation_error:
        return validation_error

    domain_id = None
    if domain:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error
        domain_id = resolved

    # Validate date/time strings before calling the op.
    # Both bounds the parsed values for downstream auto-fill / auto-populate
    # logic AND surfaces wire-format errors with the field name in-band, the
    # same shape the REST Pydantic validator produces. (PR #1555/#1594 +
    # master-side hardenings — preserved on top of branch's operations API.)
    parsed_date = None
    if scheduled_date:
        parsed_date = parse_date(scheduled_date, "scheduled_date")
        if isinstance(parsed_date, str):
            return parsed_date

    parsed_time = None
    if scheduled_time:
        parsed_time = parse_time(scheduled_time, "scheduled_time")
        if isinstance(parsed_time, str):
            return parsed_time

    # Auto-fill duration when scheduling with time (mirrors REST tasks.py:138-142)
    effective_duration = duration_minutes
    if parsed_time is not None and effective_duration is None:
        effective_duration = GCAL_SYNC_DEFAULT_DURATION_MINUTES

    # FastMCP validates `RecurrenceRuleSchema` at the boundary. Direct Python
    # callers (tests, internal call sites) may also pass a plain dict —
    # `_coerce_recurrence_rule` normalizes both forms into the dict shape the
    # backend op consumes, and produces a flat first-error string on bad input.
    parsed_rule, rule_err = _coerce_recurrence_rule(recurrence_rule)
    if rule_err:
        return rule_err

    parsed_rec_start = None
    if recurrence_start:
        parsed_rec_start = parse_date(recurrence_start, "recurrence_start")
        if isinstance(parsed_rec_start, str):
            return parsed_rec_start

    parsed_rec_end = None
    if recurrence_end:
        parsed_rec_end = parse_date(recurrence_end, "recurrence_end")
        if isinstance(parsed_rec_end, str):
            return parsed_rec_end

    # Validate recurrence consistency
    if is_recurring and not parsed_rule:
        return (
            "is_recurring=True requires recurrence_rule. Example: "
            '{"freq": "weekly", "interval": 1, "days_of_week": ["MO", "WE", "FR"]}'
        )
    if parsed_rule and not is_recurring:
        return "recurrence_rule provided but is_recurring=False. Set is_recurring=True to create a recurring task."

    # Auto-populate scheduled_date for recurring tasks (matches REST API
    # behavior — recurring tasks need a date anchor; default to the
    # recurrence_start or "today" in the user's timezone via
    # ``backend.get_preferences``, which both backends honour symmetrically).
    if is_recurring and parsed_date is None:
        from ..constants import get_user_today

        prefs = await backend.get_preferences(user_id)
        timezone = prefs.get("timezone")
        parsed_date = parsed_rec_start or get_user_today(timezone)

    # Re-serialize the final dates/times for the backend op (the op accepts
    # ISO strings and normalises internally; we pass the validated forms
    # back so auto-populated / auto-filled values flow through).
    final_scheduled_date = parsed_date.isoformat() if isinstance(parsed_date, date) else scheduled_date

    # Sanitize text fields (matches REST _strip_control_chars)
    clean_title = strip_control_chars(title).strip()
    clean_desc = strip_control_chars(description) if description else description

    try:
        payload = await backend.create_task(
            user_id,
            title=clean_title,
            domain_id=domain_id,
            impact=impact,
            clarity=clarity,
            duration_minutes=effective_duration,
            scheduled_date=final_scheduled_date,
            scheduled_time=scheduled_time,
            description=clean_desc,
            parent_id=parent_id,
            is_recurring=is_recurring,
            recurrence_rule=parsed_rule,
            recurrence_start=recurrence_start,
            recurrence_end=recurrence_end,
            reminder_minutes_before=reminder_minutes_before,
            is_habit=is_habit,
        )
    except ValueError as e:
        return str(e)
    except Exception as e:  # noqa: BLE001 — sqlalchemy.exc handled below
        # Lazy-resolve SQLAlchemy exceptions so the standalone wheel does
        # not pay the SQLAlchemy import cost (it never raises these on
        # the httpx-backed stdio path; the catches matter only on cloud).
        _IntegrityError, _DBAPIError = resolve_sqlalchemy_exc_classes()
        if isinstance(e, _IntegrityError):
            # WHENFUL-34: hard-deleted user passing auth → FK violation.
            # Type-only log; clean in-band string with NO `str(e)` (the
            # bound parameters live there). Background: PR #1534.
            logger.warning(
                "MCP create_task hit IntegrityError for user %d: %s (likely deleted user)",
                user_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return "Could not create task — your account is no longer available. Please re-authenticate."
        if isinstance(e, _DBAPIError):
            # WHENFUL-33: statement timeout / deadlock during INSERT.
            logger.warning(
                "MCP create_task hit DBAPIError for user %d: %s",
                user_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return "Task creation failed due to a transient database issue. Please retry."
        # Anything else propagates so ``guard_db_errors`` (above) catches
        # it with the leak-defended generic surface.
        raise

    task_id = payload["id"]
    task_title = payload.get("title") or ""
    logger.info(f"MCP create_task: task_id={task_id} user_id={user_id} recurring={is_recurring}")

    # Honest framing for the thought-vs-task invariant (see
    # docs/THOUGHTS-VS-TASKS.md). A row with no domain AND no parent IS a
    # thought, regardless of the tool name. Surface this clearly in the
    # response so the AI caller (and the user reading the AI's reply) can
    # tell the row landed in the Thoughts inbox, not as a scheduled task.
    landed_as_thought = payload.get("domain_id") is None and payload.get("parent_id") is None
    noun = "thought" if landed_as_thought else "task"
    result = f"Created {noun} [id:{task_id}]: {task_title}"
    if landed_as_thought:
        result += " (no domain — landed in Thoughts inbox)"
    if is_recurring:
        # The op materializes instances internally and fires bulk GCal sync;
        # ``instance_count`` carries the number of TaskInstances landed on
        # the schedule (see ``_DBBackend.create_task`` and the REST
        # ``POST /tasks`` endpoint). When absent or ``None`` — old payloads
        # or non-recurring cross-talk — fall back to the bare ``(recurring)``
        # suffix rather than fabricating a zero.
        materialized = payload.get("instance_count")
        if isinstance(materialized, int):
            result += f" (recurring, {materialized} instances created)"
        else:
            result += " (recurring)"
    return result


@guard_db_errors("update_task")
async def update_task(
    backend: Backend,
    user_id: int,
    task_id: int,
    title: str | None = None,
    domain: str | None = None,
    impact: int | None = None,
    clarity: str | None = None,
    duration_minutes: int | None = None,
    scheduled_date: str | None = None,
    scheduled_time: str | None = None,
    description: str | None = None,
    parent_id: int | None = None,
    is_recurring: bool | None = None,
    recurrence_rule: RecurrenceRuleSchema | dict[str, Any] | None = None,
    recurrence_start: str | None = None,
    recurrence_end: str | None = None,
    position: int | None = None,
    reminder_minutes_before: int | None = None,
    is_habit: bool | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate inputs (mirrors REST Pydantic validation)
    validation_error = validate_task_fields(
        title=title,
        impact=impact,
        clarity=clarity,
        duration_minutes=duration_minutes,
        reminder_minutes_before=reminder_minutes_before,
        description=description,
    )
    if validation_error:
        return validation_error

    # Build the kwargs dict the op accepts. The op normalizes ISO strings
    # for scheduled_date / recurrence_start / recurrence_end / scheduled_time
    # internally, so the tool only validates them here for error messages.
    #
    # NOTE: state-sync defenses that previously lived in the tool layer
    # (reminder_sent_at reset on schedule change, scheduled_date <->
    # recurrence_start sync, duration auto-fill, recurrence lifecycle
    # regeneration) now live inside ``_DBBackend.update_task`` so both
    # transports (HTTP + stdio) honour them symmetrically. The tool layer's
    # job is reduced to wire-format validation.
    kwargs: dict[str, Any] = {}
    if title is not None:
        kwargs["title"] = strip_control_chars(title).strip()
    if impact is not None:
        kwargs["impact"] = impact
    if clarity is not None:
        kwargs["clarity"] = clarity
    if duration_minutes is not None:
        kwargs["duration_minutes"] = duration_minutes
    if description is not None:
        kwargs["description"] = strip_control_chars(description) if description else None  # empty string clears
    if parent_id is not None:
        kwargs["parent_id"] = parent_id if parent_id != 0 else None
    if is_recurring is not None:
        kwargs["is_recurring"] = is_recurring
    if recurrence_rule is not None:
        # FastMCP validates via `RecurrenceRuleSchema`; direct callers may
        # pass a dict. `_coerce_recurrence_rule` handles both shapes.
        validated_rule, rule_err = _coerce_recurrence_rule(recurrence_rule)
        if rule_err:
            return rule_err
        kwargs["recurrence_rule"] = validated_rule
    if recurrence_start is not None:
        if recurrence_start:
            parsed_rs = parse_date(recurrence_start, "recurrence_start")
            if isinstance(parsed_rs, str):
                return parsed_rs
            kwargs["recurrence_start"] = recurrence_start  # op accepts ISO string
        else:
            kwargs["recurrence_start"] = None
    if recurrence_end is not None:
        if recurrence_end:
            parsed_re = parse_date(recurrence_end, "recurrence_end")
            if isinstance(parsed_re, str):
                return parsed_re
            kwargs["recurrence_end"] = recurrence_end
        else:
            kwargs["recurrence_end"] = None
    if position is not None:
        kwargs["position"] = position
    if reminder_minutes_before is not None:
        kwargs["reminder_minutes_before"] = reminder_minutes_before
    if is_habit is not None:
        kwargs["is_habit"] = is_habit

    if domain is not None:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error.replace(". Available:", ".").split(".")[0] + "."  # keep "not found." message stable
        kwargs["domain_id"] = resolved

    if scheduled_date is not None:
        if scheduled_date:
            parsed_sd = parse_date(scheduled_date, "scheduled_date")
            if isinstance(parsed_sd, str):
                return parsed_sd
            kwargs["scheduled_date"] = scheduled_date
        else:
            kwargs["scheduled_date"] = None

    if scheduled_time is not None:
        if scheduled_time:
            parsed_st = parse_time(scheduled_time, "scheduled_time")
            if isinstance(parsed_st, str):
                return parsed_st
            kwargs["scheduled_time"] = scheduled_time
        else:
            kwargs["scheduled_time"] = None

    if not kwargs:
        return "Nothing to update -- provide at least one field."

    try:
        payload = await backend.update_task(user_id, task_id, **kwargs)
    except ValueError as e:
        return str(e)
    except Exception as e:  # noqa: BLE001 — sqlalchemy.exc handled below
        _IntegrityError, _DBAPIError = resolve_sqlalchemy_exc_classes()
        if isinstance(e, _DBAPIError):
            # WHENFUL-33 protection (mirrors PR #1532): type-only log,
            # clean retryable message, NO `str(e)` in the response.
            logger.warning(
                "MCP update_task hit DBAPIError for user %d task %d: %s",
                user_id,
                task_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return f"Task {task_id} update timed out due to database contention. Please retry in a moment."
        # IntegrityError or anything else propagates to ``guard_db_errors``.
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."

    title_out = payload.get("title") or ""
    return f"Updated task [id:{task_id}]: {title_out}"


@guard_db_errors("complete_task")
async def complete_task(backend: Backend, user_id: int, task_id: int) -> str:
    try:
        payload = await backend.complete_task(user_id, task_id)
    except ValueError as exc:
        # Sentinel from _DBBackend.complete_task when the task is recurring.
        if str(exc) == "recurring":
            return (
                f"Task {task_id} is recurring — cannot complete directly. "
                "Use complete_instance to complete a specific instance, "
                "or use get_schedule to find instance IDs."
            )
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP complete_task: task_id={task_id} user_id={user_id}")
    return f"Completed task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


@guard_db_errors("uncomplete_task")
async def uncomplete_task(backend: Backend, user_id: int, task_id: int) -> str:
    try:
        payload = await backend.uncomplete_task(user_id, task_id)
    except ValueError as exc:
        if str(exc) == "recurring":
            return (
                f"Task {task_id} is recurring — use uncomplete_instance to undo a specific instance completion instead."
            )
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP uncomplete_task: task_id={task_id} user_id={user_id}")
    return f"Uncompleted task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)} — now pending"


@guard_db_errors("toggle_complete")
async def toggle_complete(
    backend: Backend,
    user_id: int,
    task_id: int,
    target_date: str | None = None,
) -> str:
    # Validate target_date here (operation accepts ISO string).
    if target_date:
        parsed = parse_date(target_date, "target_date")
        if isinstance(parsed, str):
            return parsed

    payload = await backend.toggle_complete(user_id, task_id, target_date=target_date)
    if payload is None:
        return f"Task {task_id} not found or not owned by you."

    completed = bool(payload.get("completed"))
    instance_id = payload.get("instance_id")
    if instance_id is not None:
        td = payload.get("target_date")
        return (
            f"{'Completed' if completed else 'Uncompleted'} instance [inst:{instance_id}] "
            f"of task [id:{task_id}] for {td}"
        )

    encrypted = await is_encrypted(backend, user_id)
    # The op already includes the task in the payload via title field; if not,
    # fall back via get_task.
    title_value = payload.get("title")
    if title_value is None:
        # Re-fetch for title (handles backends that don't include title in toggle response)
        task_payload = await backend.get_task(user_id, task_id)
        if task_payload is not None:
            title_value = task_payload.get("title")
    title = safe_title(title_value, encrypted)
    return f"{'Completed' if completed else 'Uncompleted'} task [id:{task_id}]: {title}"


@guard_db_errors("get_task")
async def get_task(backend: Backend, user_id: int, task_id: int) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    d = await backend.get_task(user_id, task_id)
    if d is None:
        return f"Task {task_id} not found or not owned by you."

    lines = [f"Task [id:{task_id}]: {d['title']}"]
    lines.append(f"  status: {d['status']}")
    if d.get("description"):
        lines.append(f"  description: {d['description']}")
    if d.get("domain_name"):
        lines.append(f"  domain: {d['domain_name']} (id:{d.get('domain_id')})")
    if d.get("parent_id"):
        lines.append(f"  parent: [id:{d['parent_id']}] (subtask)")
    lines.append(f"  impact: {IMPACT_LABELS.get(d.get('impact', 4), '?')} ({d.get('impact')})")
    lines.append(f"  clarity: {d.get('clarity', 'normal')}")
    if d.get("duration_minutes"):
        lines.append(f"  duration: {d['duration_minutes']}m")
    if d.get("scheduled_date"):
        sched = str(d["scheduled_date"])
        if d.get("scheduled_time"):
            sched += f" {d['scheduled_time']}"
        lines.append(f"  scheduled: {sched}")
    lines.append(f"  recurring: {d.get('is_recurring', False)}")
    if d.get("is_recurring") and d.get("recurrence_rule"):
        lines.append(f"  recurrence_rule: {json.dumps(d['recurrence_rule'])}")
        if d.get("recurrence_start"):
            lines.append(f"  recurrence_start: {d['recurrence_start']}")
        if d.get("recurrence_end"):
            lines.append(f"  recurrence_end: {d['recurrence_end']}")
    if d.get("reminder_minutes_before") is not None:
        lines.append(f"  reminder: {d['reminder_minutes_before']}m before")
    if d.get("position") is not None:
        lines.append(f"  position: {d['position']}")
    if d.get("completed_at"):
        lines.append(f"  completed_at: {d['completed_at']}")
    if d.get("subtasks"):
        lines.append(f"  subtasks ({len(d['subtasks'])}):")
        for sub in d["subtasks"]:
            sub_mark = "x" if sub.get("status") == "completed" else " "
            lines.append(f"    [{sub_mark}] [id:{sub['id']}] {sub['title']}")

    return "\n".join(lines)


@guard_db_errors("nuke_task")
async def nuke_task(backend: Backend, user_id: int, task_id: int) -> str:
    nuked = await backend.nuke_task(user_id, task_id)
    if not nuked:
        return f"Task {task_id} not found or not owned by you."
    logger.info(f"MCP nuke_task: task_id={task_id} user_id={user_id}")
    return f"Permanently destroyed task [id:{task_id}]"


@guard_db_errors("archive_task")
async def archive_task(backend: Backend, user_id: int, task_id: int) -> str:
    payload = await backend.archive_task(user_id, task_id)
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP archive_task: task_id={task_id} user_id={user_id}")
    return f"Archived task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


@guard_db_errors("restore_task")
async def restore_task(backend: Backend, user_id: int, task_id: int) -> str:
    payload = await backend.restore_task(user_id, task_id)
    if payload is None:
        return f"Task {task_id} not found, not owned by you, or not archived."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP restore_task: task_id={task_id} user_id={user_id}")
    return f"Restored task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


@guard_db_errors("get_archived_tasks")
async def get_archived_tasks(
    backend: Backend,
    user_id: int,
    domain: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    domain_id = None
    if domain:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error
        domain_id = resolved

    # Exclude domain-less inbox items unless caller asked for a specific
    # domain — archived thoughts belong in a dedicated triage view, not
    # the archived-work surface. (The backend op enforces this filter.)
    overfetch = limit + 1 if limit and limit > 0 else limit
    tasks = await backend.get_archived_tasks(user_id, domain_id=domain_id, limit=overfetch, offset=offset)

    has_more = limit > 0 and len(tasks) > limit
    if has_more:
        tasks = tasks[:limit]

    if not tasks:
        return "No archived tasks found."

    lines = [format_task(t) for t in tasks]
    body = f"{len(tasks)} archived task(s):\n\n" + "\n".join(lines)
    return body + pagination_footer(
        has_more=has_more,
        next_offset=(offset or 0) + limit if has_more else None,
        noun="archived task",
    )


@guard_db_errors("search_tasks")
async def search_tasks(
    backend: Backend,
    user_id: int,
    query: str,
    include_completed: bool = False,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    if not query or not query.strip():
        return "Search query cannot be empty."

    tasks = await backend.search_tasks(user_id, query=query, include_completed=include_completed)

    if not tasks:
        return f"No tasks matching '{query}'."

    lines = [format_task(t) for t in tasks]
    body = f"{len(tasks)} task(s) matching '{query}':\n\n" + "\n".join(lines)
    # search_tasks has a hard server-side cap of 100 (see
    # ``_DBBackend.search_tasks``). When we hit it, the response is
    # almost certainly truncated; signal that so callers refine the query
    # rather than acting on partial results (Whenful #14603).
    has_more = len(tasks) >= 100
    return body + pagination_footer(has_more=has_more, next_offset=None, noun="match")


@guard_db_errors("batch_create_tasks")
async def batch_create_tasks(backend: Backend, user_id: int, tasks: list[dict[str, Any]]) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    if not isinstance(tasks, list):
        return "Expected an array of task objects."

    tasks_list = tasks

    # Build the canonical list[dict] payload + per-item validation errors.
    # Domain-name resolution happens here so the operation only sees
    # domain_id (int). Per-item validation echoes the create_task semantics.
    domains = await backend.list_domains(user_id)
    domain_map: dict[str, int] = {d["name"].lower(): int(d["id"]) for d in domains if isinstance(d.get("name"), str)}
    available = ", ".join(d["name"] for d in domains if isinstance(d.get("name"), str) and not d.get("is_archived"))

    prepared: list[dict[str, Any]] = []
    errors: list[str] = []
    title_by_index: dict[int, str] = {}

    for i, task_data in enumerate(tasks_list):
        if not isinstance(task_data, dict) or "title" not in task_data:
            errors.append(f"Item {i}: missing 'title'")
            continue

        try:
            domain_id = None
            if "domain" in task_data:
                domain_id = domain_map.get(task_data["domain"].lower())
                if domain_id is None:
                    errors.append(f"Item {i}: domain '{task_data['domain']}' not found. Available: {available}")
                    continue

            if task_data.get("scheduled_date"):
                check = parse_date(task_data["scheduled_date"], "scheduled_date")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue
            if task_data.get("scheduled_time"):
                check = parse_time(task_data["scheduled_time"], "scheduled_time")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue

            val_err = validate_task_fields(
                title=task_data["title"],
                impact=task_data.get("impact"),
                clarity=task_data.get("clarity"),
                duration_minutes=task_data.get("duration_minutes"),
                reminder_minutes_before=task_data.get("reminder_minutes_before"),
                description=task_data.get("description"),
            )
            if val_err:
                errors.append(f"Item {i} '{str(task_data['title'])[:30]}': {val_err}")
                continue

            # Per-item recurrence rule validation. Each item is a dict, so
            # `recurrence_rule` lives nested inside as a dict (FastMCP can
            # only enforce the outer list[dict] shape — nested validation
            # is ours). Reuses the same `RecurrenceRuleSchema` gate as the
            # single-task tools.
            parsed_rule, rule_err = _coerce_recurrence_rule(
                task_data.get("recurrence_rule"), field=f"item {i} recurrence_rule"
            )
            if rule_err:
                errors.append(rule_err)
                continue

            if task_data.get("recurrence_start"):
                check = parse_date(task_data["recurrence_start"], "recurrence_start")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue
            if task_data.get("recurrence_end"):
                check = parse_date(task_data["recurrence_end"], "recurrence_end")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue

            is_rec = bool(task_data.get("is_recurring"))
            if is_rec and not parsed_rule:
                errors.append(f"Item {i}: is_recurring=True requires recurrence_rule")
                continue
            if parsed_rule and not is_rec:
                errors.append(f"Item {i}: recurrence_rule provided but is_recurring=False")
                continue

            clean_title = strip_control_chars(str(task_data["title"])).strip()
            clean_desc = (
                strip_control_chars(task_data["description"])
                if task_data.get("description")
                else task_data.get("description")
            )

            item: dict[str, Any] = {
                "title": clean_title,
                "domain_id": domain_id,
                "parent_id": task_data.get("parent_id"),
                "impact": task_data.get("impact", 4),
                "clarity": task_data.get("clarity", "normal"),
                "duration_minutes": task_data.get("duration_minutes"),
                "scheduled_date": task_data.get("scheduled_date"),
                "scheduled_time": task_data.get("scheduled_time"),
                "description": clean_desc,
                "is_recurring": is_rec,
                "recurrence_rule": parsed_rule,
                "recurrence_start": task_data.get("recurrence_start"),
                "recurrence_end": task_data.get("recurrence_end"),
                "reminder_minutes_before": task_data.get("reminder_minutes_before"),
                "is_habit": bool(task_data.get("is_habit", False)),
            }
            title_by_index[len(prepared)] = clean_title
            prepared.append(item)
        except ValueError as e:
            errors.append(f"Item {i}: {e}")

    op_result = await backend.batch_create_tasks(user_id, tasks=prepared)
    created_items = op_result.get("created", []) if isinstance(op_result, dict) else []
    op_errors = op_result.get("errors", []) if isinstance(op_result, dict) else []

    # Translate the op's structured error list into the legacy strings.
    for err in op_errors:
        if isinstance(err, dict):
            errors.append(f"Item {err.get('index', '?')}: {err.get('message', 'unknown error')}")

    # Differentiate rows that landed as thoughts (no domain + no parent) from
    # filed tasks — honest framing under the thought-vs-task invariant (see
    # docs/THOUGHTS-VS-TASKS.md). Counts in the header reflect both.
    thought_count = sum(
        1 for c in created_items if isinstance(c, dict) and c.get("domain_id") is None and c.get("parent_id") is None
    )
    task_count = len(created_items) - thought_count
    if thought_count and task_count:
        header = f"Created {task_count} task(s) + {thought_count} thought(s):"
    elif thought_count:
        header = f"Created {thought_count} thought(s) (no domains specified — landed in Thoughts inbox):"
    else:
        header = f"Created {task_count} task(s):"
    lines = [header]
    for c in created_items:
        if isinstance(c, dict):
            is_thought = c.get("domain_id") is None and c.get("parent_id") is None
            suffix = " (thought)" if is_thought else ""
            lines.append(f"  + [id:{c.get('id')}] {c.get('title', '')}{suffix}")
    if errors:
        lines.append(f"\n{len(errors)} error(s):")
        for e in errors:
            lines.append(f"  x {e}")

    return "\n".join(lines)


@guard_db_errors("batch_update_tasks")
async def batch_update_tasks(
    backend: Backend,
    user_id: int,
    task_ids: list[int],
    impact: int | None = None,
    clarity: str | None = None,
    domain: str | None = None,
    status: str | None = None,
    is_habit: bool | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate fields before processing
    validation_error = validate_task_fields(impact=impact, clarity=clarity, status=status)
    if validation_error:
        return validation_error

    ids = [int(x) for x in task_ids]

    if not ids:
        return "No task IDs provided."

    kwargs: dict[str, Any] = {}
    if impact is not None:
        kwargs["impact"] = impact
    if clarity is not None:
        kwargs["clarity"] = clarity
    if status is not None:
        kwargs["status"] = status
    if is_habit is not None:
        kwargs["is_habit"] = is_habit

    if domain is not None:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return f"Domain '{domain}' not found."
        kwargs["domain_id"] = resolved

    if not kwargs:
        return "Nothing to update -- provide at least one field."

    op_result = await backend.batch_update_tasks(user_id, task_ids=ids, **kwargs)
    updated = int(op_result.get("updated_count", 0))
    skipped_recurring = list(op_result.get("skipped_recurring", []))
    op_errors = op_result.get("errors", [])
    errors = [f"id:{e.get('id')} {e.get('message', 'failed')}" for e in op_errors if isinstance(e, dict)]
    logger.info(f"MCP batch_update_tasks: updated={updated} errors={len(errors)} user_id={user_id}")

    result = f"Updated {updated} task(s)."
    if skipped_recurring:
        result += f" Skipped {len(skipped_recurring)} recurring task(s) (use complete_instance instead)."
    if errors:
        result += f" {len(errors)} error(s): " + "; ".join(errors)
    return result


@guard_db_errors("batch_complete_tasks")
async def batch_complete_tasks(backend: Backend, user_id: int, task_ids: list[int]) -> str:
    ids = [int(x) for x in task_ids]

    if not ids:
        return "No task IDs provided."

    op_result = await backend.batch_complete_tasks(user_id, task_ids=ids)
    completed = int(op_result.get("completed_count", 0))
    skipped_recurring = list(op_result.get("skipped_recurring", []))
    op_errors = op_result.get("errors", [])
    errors = [f"id:{e.get('id')} {e.get('message', 'failed')}" for e in op_errors if isinstance(e, dict)]
    logger.info(f"MCP batch_complete_tasks: completed={completed} errors={len(errors)} user_id={user_id}")

    result = f"Completed {completed} task(s)."
    if skipped_recurring:
        result += (
            f" Skipped {len(skipped_recurring)} recurring task(s) (use complete_instance instead): {skipped_recurring}"
        )
    if errors:
        result += f" {len(errors)} error(s): " + "; ".join(errors)
    return result


# Re-exported intentionally: future stdio code will not import these directly,
# but linting/test consumers may.
_ = (UTC, date, datetime)
