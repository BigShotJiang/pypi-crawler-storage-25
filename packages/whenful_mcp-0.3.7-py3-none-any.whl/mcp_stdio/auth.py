"""OAuth 2.1 token auth for the local stdio MCP client.

``AuthManager`` owns the access/refresh token pair on disk and handles
silent refresh against ``POST /api/v1/oauth/token`` (grant_type=
refresh_token). It is consumed by ``WhenfulClient`` (``mcp_stdio.client``)
to attach Bearer headers to every REST call.

Token store layout
------------------

Path defaults to ``~/.whenful/tokens.json`` and may be overridden via the
``WHENFUL_TOKEN_PATH`` environment variable (primarily for tests; the
setup flow at ``mcp_stdio.setup`` writes this file after a successful
OAuth pairing).

JSON shape (translated from the cloud server's ``TokenResponse`` in
``app/routers/oauth.py``):

.. code-block:: json

    {
      "access_token": "ey...",
      "refresh_token": "ey...",
      "expires_at": 1768204800
    }

The server wire format is ``expires_in`` (seconds-from-now); we
translate to ``expires_at`` (absolute Unix timestamp) on every save so
the on-disk shape is timezone- and clock-skew-stable. The conversion is
``expires_at = int(time.time()) + expires_in`` at the moment of
persistence.

Refresh semantics
-----------------

- ``get_access_token()`` returns the current access token if ``expires_at``
  is more than ``REFRESH_LEEWAY_SECONDS`` in the future; otherwise it calls
  ``refresh()`` first.
- ``refresh()`` POSTs ``{grant_type: refresh_token, refresh_token: ...}``
  to ``/oauth/token``, persists the new tokens (translating
  ``expires_in`` → ``expires_at``), and is serialized by an
  ``asyncio.Lock`` so concurrent 401 retries do not double-refresh.
- A 401 from the refresh endpoint, or a missing token file, raises
  ``AuthExpiredError`` — the setup flow catches this and prompts the
  user to re-pair the device.

Privacy & telemetry posture
---------------------------

Zero telemetry. No Sentry, no print of tokens. ``__repr__`` redacts both
tokens. Token file is created with ``0o600`` mode and the parent
directory with ``0o700`` so other local users cannot read it.

This module must NOT import from ``app.*`` at module load time. The
``mcp_stdio`` subpackage is built as a separately publishable wheel in
Phase F, and the ``app/`` codebase is not part of that wheel.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any, Final

import httpx

#: Default URL of the Whenful REST API. Override with ``WHENFUL_API_BASE``
#: (used by both ``AuthManager`` and ``WhenfulClient``).
DEFAULT_API_BASE: Final[str] = "https://whenful.com/api/v1"

#: Default token store location. Override with ``WHENFUL_TOKEN_PATH``.
DEFAULT_TOKEN_PATH: Final[str] = "~/.whenful/tokens.json"

#: Refresh ``REFRESH_LEEWAY_SECONDS`` before the access token actually
#: expires so a request that takes a few seconds doesn't 401 mid-flight.
REFRESH_LEEWAY_SECONDS: Final[int] = 60


class AuthError(Exception):
    """Base class for auth errors raised by this module."""


class AuthExpiredError(AuthError):
    """Raised when the local token state cannot be refreshed.

    Causes include: missing ``tokens.json``, malformed token file, refresh
    endpoint returning 401 (refresh token revoked/expired), or any
    persistent network failure that prevents refresh. The setup flow
    catches this and re-pairs the device.
    """


class AuthNetworkError(AuthError):
    """Raised when refresh fails due to a transient network/transport
    error (DNS, TCP reset, TLS, etc). Distinct from ``AuthExpiredError``
    so callers can choose to retry rather than restart device pairing."""


def _resolve_token_path() -> Path:
    """Return the token-store path, honoring ``WHENFUL_TOKEN_PATH``.

    Read at every call (not cached at import time) so tests can flip the
    env var between cases without re-importing the module.
    """
    raw = os.environ.get("WHENFUL_TOKEN_PATH") or DEFAULT_TOKEN_PATH
    return Path(raw).expanduser()


def _resolve_api_base() -> str:
    """Return the API base URL, honoring ``WHENFUL_API_BASE``."""
    return os.environ.get("WHENFUL_API_BASE") or DEFAULT_API_BASE


class AuthManager:
    """Owns the access/refresh token pair for the local stdio MCP client.

    Instances are cheap; usually one per process. The ``http_client``
    parameter accepts an injected ``httpx.AsyncClient`` so tests can route
    refresh calls at an ASGI transport. When omitted, a private client is
    created on first refresh and reused for the manager's lifetime.

    Thread-safety: not thread-safe. Concurrent use within a single asyncio
    loop is safe — ``refresh()`` is serialized with ``asyncio.Lock`` so two
    simultaneous 401-triggered refreshes don't both POST.
    """

    __slots__ = (
        "_api_base",
        "_token_path_override",
        "_tokens",
        "_lock",
        "_http_client",
        "_owns_client",
    )

    def __init__(
        self,
        *,
        api_base: str | None = None,
        token_path: Path | str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_base: str = api_base or _resolve_api_base()
        # ``token_path`` argument overrides both the env var and the
        # default; useful for tests that want explicit control.
        self._token_path_override: Path | None = Path(token_path).expanduser() if token_path is not None else None
        self._tokens: dict[str, Any] | None = None
        self._lock = asyncio.Lock()
        self._http_client: httpx.AsyncClient | None = http_client
        self._owns_client: bool = http_client is None

    # ------------------------------------------------------------------
    # Path resolution
    # ------------------------------------------------------------------

    @property
    def token_path(self) -> Path:
        """Resolve the token file path at call time.

        Override priority: constructor ``token_path`` > ``WHENFUL_TOKEN_PATH``
        env > ``~/.whenful/tokens.json``. Evaluating the env on each call lets
        tests mutate it between cases without re-instantiating the manager.
        """
        if self._token_path_override is not None:
            return self._token_path_override
        return _resolve_token_path()

    # ------------------------------------------------------------------
    # Disk I/O
    # ------------------------------------------------------------------

    def load(self) -> dict[str, Any] | None:
        """Read tokens from disk, returning ``None`` if absent or malformed.

        Result is cached on the instance for the rest of the process; call
        ``save()`` to persist new tokens or mutate ``self._tokens`` and
        ``save()`` to write through.
        """
        if self._tokens is not None:
            return self._tokens
        path = self.token_path
        if not path.exists():
            return None
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(data, dict):
            return None
        if not {"access_token", "refresh_token", "expires_at"}.issubset(data):
            return None
        self._tokens = data
        return data

    def save(self, tokens: dict[str, Any]) -> None:
        """Persist ``tokens`` to disk atomically with restrictive perms.

        Creates the parent directory with ``0o700`` and the file with
        ``0o600`` so other local users cannot read the tokens. Writes to a
        ``.tmp`` sibling then ``os.replace()`` to avoid corruption if the
        process dies mid-write.
        """
        path = self.token_path
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        tmp = path.with_suffix(path.suffix + ".tmp")
        # Open with restrictive mode from the start (umask-resistant on POSIX).
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(tokens, f)
        os.replace(str(tmp), str(path))
        # Belt-and-suspenders chmod in case umask masked the open mode.
        try:
            os.chmod(str(path), 0o600)
            os.chmod(str(path.parent), 0o700)
        except OSError:
            # Best-effort on platforms that don't support POSIX permissions
            # (e.g., Windows). The tokens file is still on disk.
            pass
        self._tokens = dict(tokens)

    # ------------------------------------------------------------------
    # Token retrieval
    # ------------------------------------------------------------------

    async def get_access_token(self) -> str:
        """Return a current access token, refreshing if necessary.

        Raises ``AuthExpiredError`` if no token file exists or the refresh
        token is rejected; raises ``AuthNetworkError`` on transient
        transport failures.
        """
        tokens = self.load()
        if tokens is None:
            raise AuthExpiredError(f"No tokens at {self.token_path}; run `whenful-mcp setup` to pair.")
        now = time.time()
        expires_at = float(tokens.get("expires_at", 0))
        if expires_at - now > REFRESH_LEEWAY_SECONDS:
            return str(tokens["access_token"])
        # Pass the access token we observed as stale so concurrent
        # ``refresh()`` calls coalesce into a single POST.
        await self.refresh(triggering_token=str(tokens["access_token"]))
        # ``refresh`` updated ``self._tokens`` in place.
        refreshed = self._tokens
        if refreshed is None:
            # Defensive: refresh always populates ``self._tokens`` or raises.
            raise AuthExpiredError("Refresh returned no tokens.")
        return str(refreshed["access_token"])

    # ------------------------------------------------------------------
    # Refresh
    # ------------------------------------------------------------------

    async def refresh(self, *, triggering_token: str | None = None) -> None:
        """POST the refresh token to ``/oauth/token`` and persist the
        new token pair.

        OAuth 2.1 wire format (per ``app/routers/oauth.py::TokenResponse``):

        - Request body: ``{grant_type: refresh_token, refresh_token: ...}``
        - Success response: ``{access_token, refresh_token, token_type,
          expires_in, scope}`` — note ``expires_in`` is seconds-from-now,
          NOT an absolute timestamp. We translate to ``expires_at`` on
          save (``int(time.time()) + expires_in``) so the on-disk shape
          stays consistent with ``setup.py``'s output.

        Serialized via ``asyncio.Lock`` so concurrent 401-triggered
        refreshes don't double-POST. The lock is released whether refresh
        succeeds, fails, or raises.

        Coalescing rule: pass ``triggering_token`` set to the access
        token whose use just produced a 401 (or whose imminent expiry
        triggered this refresh). After acquiring the lock we re-load and
        compare against ``triggering_token``; if the current on-disk
        access token differs, a parallel ``refresh()`` already rotated
        the credentials and we short-circuit. If ``triggering_token`` is
        ``None`` (caller is explicitly forcing a refresh), we always
        POST.

        We deliberately do NOT short-circuit on remaining-TTL alone — a
        server-invalidated token can look "fresh" locally yet still need
        a real refresh round-trip.

        Raises ``AuthExpiredError`` on 4xx (refresh token rejected) and
        ``AuthNetworkError`` on transport errors. 5xx is treated as
        transient (network).
        """
        async with self._lock:
            # Re-load tokens after lock acquisition in case a parallel
            # refresh already wrote new ones.
            tokens = self.load()
            if tokens is None:
                raise AuthExpiredError(f"No tokens at {self.token_path}; run `whenful-mcp setup` to pair.")
            if triggering_token is not None and tokens.get("access_token") != triggering_token:
                # Another coroutine rotated the tokens between when the
                # caller observed ``triggering_token`` and when we
                # acquired the lock — nothing more for us to do.
                return

            client = self._ensure_client()
            url = f"{self._api_base.rstrip('/')}/oauth/token"
            try:
                response = await client.post(
                    url,
                    json={
                        "grant_type": "refresh_token",
                        "refresh_token": tokens["refresh_token"],
                    },
                )
            except httpx.HTTPError as exc:
                raise AuthNetworkError(f"Refresh request to {url} failed: {exc!r}") from exc

            if response.status_code in (401, 403):
                raise AuthExpiredError(f"Refresh token rejected ({response.status_code}); re-pair the device.")
            if response.status_code >= 500:
                raise AuthNetworkError(f"Refresh endpoint returned {response.status_code}.")
            if response.status_code != 200:
                raise AuthExpiredError(f"Refresh endpoint returned {response.status_code}: {response.text[:200]}")
            try:
                payload = response.json()
            except ValueError as exc:
                raise AuthExpiredError("Refresh response was not JSON.") from exc
            if not isinstance(payload, dict) or not {
                "access_token",
                "refresh_token",
                "expires_in",
            }.issubset(payload):
                raise AuthExpiredError("Refresh response missing required fields.")
            # Translate wire format (expires_in seconds-from-now) into
            # on-disk format (expires_at absolute Unix seconds). Done at
            # the persistence boundary so the rest of the codebase only
            # ever sees absolute timestamps.
            #
            # We preserve any non-canonical fields the caller wrote
            # alongside the token tuple (notably ``email``, written by
            # setup.py for keystore labeling) by starting from the
            # existing on-disk dict and overlaying the freshly-rotated
            # token triple. Without this, the first refresh after pairing
            # would wipe ``email`` and downstream code (serve, logout)
            # would fall back to the legacy sha256 label.
            preserved = dict(tokens) if isinstance(tokens, dict) else {}
            preserved.update(
                {
                    "access_token": payload["access_token"],
                    "refresh_token": payload["refresh_token"],
                    "expires_at": int(time.time()) + int(payload["expires_in"]),
                }
            )
            self.save(preserved)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=30.0)
            self._owns_client = True
        return self._http_client

    async def aclose(self) -> None:
        """Close the internally-owned httpx client, if any.

        Safe to call multiple times. Does nothing if the client was
        injected by the caller (they're responsible for closing it).
        """
        if self._http_client is not None and self._owns_client:
            await self._http_client.aclose()
            self._http_client = None

    # ------------------------------------------------------------------
    # Safety
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"AuthManager(api_base={self._api_base!r}, token_path={str(self.token_path)!r})"


__all__ = [
    "AuthError",
    "AuthExpiredError",
    "AuthNetworkError",
    "AuthManager",
    "DEFAULT_API_BASE",
    "DEFAULT_TOKEN_PATH",
    "REFRESH_LEEWAY_SECONDS",
]
