"""``whenful-mcp logout`` — clear the local pairing and force a fresh setup.

Removes the persisted device state so the next ``whenful-mcp serve``
exits with the standard "no tokens / no key" hint pointing the user
back at ``whenful-mcp setup``:

1. The OAuth token file at ``~/.whenful/tokens.json`` (overridable via
   ``WHENFUL_TOKEN_PATH``) is unlinked.
2. The derived AES key stored in the keystore under the account label
   read from those tokens is deleted. Backend is auto-detected the
   same way as setup/serve (1Password CLI → OS keychain → opt-in
   plaintext) — we never silently downgrade to plaintext, so logout
   refuses to clear a plaintext key unless the user explicitly passes
   ``--insecure-key-storage`` (mirrors the setup gate).

Exit codes mirror ``mcp_stdio.setup`` to keep the wheel's CLI
consistent. Partial failures (e.g. tokens missing but keystore had a
stale entry, or vice versa) are treated as success with a warning —
the user's goal ("get me back to a fresh state") is met either way.

Privacy & telemetry posture
---------------------------

Zero telemetry. The account label is printed to stdout as a status
anchor so the user can confirm what was cleared, but the actual key
bytes and tokens are never logged. The keystore backend's name is
printed only on success.
"""

from __future__ import annotations

import sys
from typing import Final

from .auth import AuthManager
from .client_wire import WireOutcome, detect_clients, unwire_client
from .keystore import KeyStore, KeyStoreError, get_keystore
from .setup import _account_label_from_tokens

#: Exit codes — kept numerically distinct from setup's exit codes
#: (setup uses 1-5, 130) so shell wrappers can disambiguate failure
#: origin from the exit status alone.
EXIT_OK: Final[int] = 0
EXIT_KEYSTORE_ERROR: Final[int] = 4  # parity with setup.EXIT_KEYSTORE_ERROR


def _stderr(msg: str) -> None:
    print(msg, file=sys.stderr)


def _stdout(msg: str) -> None:
    print(msg)


def run_logout(
    *,
    auth: AuthManager | None = None,
    keystore: KeyStore | None = None,
    insecure_plaintext: bool = False,
) -> int:
    """Synchronous logout. Returns a process exit code.

    Collaborators are dependency-injected so unit tests can swap in a
    pre-constructed ``AuthManager`` pointed at a tmp_path and a fake
    ``KeyStore`` without touching the real macOS Keychain.

    Partial-failure policy: missing tokens, missing keystore entry, or
    unreachable keystore backend are all treated as "already partly
    logged out" — we log a warning and return EXIT_OK. The user's
    intent (fresh state) is satisfied either way. The only condition
    that returns a non-zero exit is a keystore *delete* that raises an
    explicit ``KeyStoreError`` (corrupt state, permission denied, etc).
    """
    owns_auth = auth is None
    if auth is None:
        auth = AuthManager()

    token_path = auth.token_path

    # ----- Step 1: figure out the keystore account label ----------------
    # We MUST resolve the label BEFORE deleting the tokens file, because
    # the email-based label lives inside that file. If tokens are
    # already gone, the label is None and we skip the keystore step
    # (nothing to look up against).
    tokens = auth.load() if token_path.exists() else None
    account: str | None = _account_label_from_tokens(tokens) if tokens is not None else None

    # ----- Step 2: clear the keystore entry ------------------------------
    keystore_cleared = False
    keystore_skipped_reason: str | None = None
    if account is not None:
        if keystore is None:
            try:
                keystore = get_keystore(insecure_plaintext=insecure_plaintext)
            except KeyStoreError as exc:
                # No backend available — nothing to clear. Treat as soft
                # warning, not failure.
                keystore_skipped_reason = str(exc)
        if keystore is not None:
            try:
                keystore.delete(account)
                keystore_cleared = True
            except KeyStoreError as exc:
                _stderr(f"Could not delete keystore entry for {account!r}: {exc}")
                return EXIT_KEYSTORE_ERROR
    else:
        keystore_skipped_reason = f"No tokens at {token_path}; nothing to look up in the keystore."

    # ----- Step 3: unwire MCP client configs ----------------------------
    # v0.3.2 — symmetric inverse of setup's auto-wire. If we don't
    # remove the `mcpServers.whenful` entry from the user's MCP client
    # config, the next Claude Code / Claude Desktop session will keep
    # trying to launch a server that now exits with "no tokens, run
    # setup". The wire-up was added implicitly by setup; the tear-down
    # should be implicit here too.
    unwired_clients: list[str] = []
    for client in detect_clients():
        result = unwire_client(client)
        if result.outcome is WireOutcome.REMOVED:
            unwired_clients.append(f"{client.display_name} ({client.path})")
        elif result.outcome in (WireOutcome.INVALID_JSON, WireOutcome.PERMISSION_DENIED):
            # Bad-state file: surface the problem but don't fail logout.
            # The user's goal (tokens/key gone) is still achievable.
            _stderr(f"Warning: could not unwire {client.display_name}: {result.detail}")

    # ----- Step 4: unlink the token file --------------------------------
    token_file_removed = False
    if token_path.exists():
        try:
            token_path.unlink()
            token_file_removed = True
        except OSError as exc:
            # Don't fail logout for an unlink error — the keystore entry
            # is already gone (or was already absent). Print and continue.
            _stderr(f"Warning: could not remove {token_path}: {exc!r}")
    # ----- Step 5: status output ----------------------------------------
    if keystore_cleared and account is not None:
        _stdout(f"Cleared keystore entry for account {account!r}.")
    if token_file_removed:
        _stdout(f"Removed token file {token_path}.")
    for entry in unwired_clients:
        _stdout(f"Unwired from {entry}.")
    if keystore_skipped_reason is not None:
        _stderr(f"Note: {keystore_skipped_reason}")
    if not keystore_cleared and not token_file_removed and not unwired_clients:
        _stdout("Nothing to do — no tokens, keystore entry, or wired clients found.")
    _stdout("Logged out. Run 'whenful-mcp setup' to re-pair.")

    if owns_auth:
        # AuthManager owns no async resources in the sync path. Nothing
        # to close — aclose() is only relevant when an httpx client was
        # constructed for refresh. Defensive cleanup is a no-op here.
        pass

    return EXIT_OK


def main(argv: list[str] | None = None) -> int:
    """CLI entrypoint for ``whenful-mcp logout``.

    Accepts ``--insecure-key-storage`` so users who paired with that
    flag can also tear down via the same path (the plaintext file
    backend won't be detected by ``get_keystore()`` without the opt-in).
    """
    args = argv if argv is not None else sys.argv[1:]
    if "--help" in args or "-h" in args:
        _stdout(
            "usage: whenful-mcp logout [--insecure-key-storage]\n\n"
            "Clear local pairing state: deletes the keystore entry holding\n"
            "your derived AES key and removes ~/.whenful/tokens.json.\n\n"
            "Pass --insecure-key-storage if you originally paired with that\n"
            "flag (so the plaintext-file backend is reachable for delete).\n\n"
            "Logout is idempotent — running it twice has no extra effect.",
        )
        return EXIT_OK
    insecure = "--insecure-key-storage" in args
    return run_logout(insecure_plaintext=insecure)


if __name__ == "__main__":
    sys.exit(main())


__all__ = [
    "EXIT_KEYSTORE_ERROR",
    "EXIT_OK",
    "main",
    "run_logout",
]
