"""Native macOS keychain binding via ctypes, working around the legacy ACL shim.

Replaces the ``keyring`` library's macOS backend with a direct binding
to ``Security.framework``. The library's existing backend uses
``keyring.set_password`` → delete-then-add, which hits the legacy
keychain's filename-based ACL shim and fails with
``errSecInvalidOwnerEdit`` (-25244) any time the calling binary's
path changes (every pip upgrade rewrites the ``whenful-mcp``
entry-point script). Apple Technical Note TN3137 ("On Mac
keychains") documents this as a known bug in
``SecKeychainItemDelete`` / ``SecItemDelete`` — and prescribes the
exact workaround we implement here:

  1. **For writes** — use ``SecItemAdd``; on ``errSecDuplicateItem``
     (-25299, the entry already exists), fall back to
     ``SecItemUpdate``. **Never** delete-then-add. ``SecItemUpdate``
     is documented as not subject to the shim.

  2. **For deletes** — try ``SecItemDelete`` first; on
     ``errSecInvalidOwnerEdit`` (-25244), fall back to a subprocess
     invocation of Apple's bundled ``security(1)`` CLI. The CLI
     talks to ``securityd`` via XPC and bypasses the C API's ACL
     shim entirely — it can delete entries the C API refuses to
     touch (this is exactly what ``security(1)`` exists for; not a
     workaround we invented). TN3137 also suggests
     ``SecItemUpdate``-with-empty-data here, but empirical testing
     shows ``SecItemUpdate`` no-ops on empty ``kSecValueData``
     (presumably because the SecItem layer treats empty as
     "leave attribute unchanged"). The CLI fallback is the only
     path that actually removes the entry.

Why we don't use the Data Protection Keychain (DPK)
---------------------------------------------------

The DPK (``kSecUseDataProtectionKeychain=true``) would be the
architecturally cleaner answer — it has no legacy ACL shim — but it
requires the calling binary to have the ``keychain-access-groups``
entitlement. Unsigned Python interpreters (which is what pip /
Homebrew / pyenv ship) don't have entitlements at all, so DPK refuses
with ``errSecMissingEntitlement`` (-34018). The legacy keychain via
the workaround above is the only path that works for an
end-user-installable Python wheel on macOS without forcing the user
into a code-signed Python build.

Why ctypes instead of pyobjc
----------------------------

``pyobjc-framework-Security`` would be the obvious "use the official
Python bindings" path, but it (plus its ``pyobjc-framework-Cocoa``
transitive dependency) adds ~30 MB to the wheel's install footprint.
The Security framework's surface we actually need is four functions
and a handful of constants — fewer than 250 LOC of ctypes wraps the
whole thing. Net install size: zero new bytes.

Why CFType helpers in-module
----------------------------

Same reasoning. Wrapping ``CFString`` / ``CFData`` / ``CFDictionary``
via ctypes is repetitive but mechanical, and our needs are narrow
enough (a single dict shape, ASCII service/account names, bytes data)
that a 30-line helper module beats a 5 MB dep.

Privacy posture
---------------

Zero telemetry. Read and happy-path delete happen entirely in-process
via ``Security.framework``. The delete fallback shells out to
``security(1)`` (which already runs everywhere — it's bundled with
the OS), passing only the service and account names on the command
line, never the secret bytes. We never log the key, never phone home,
and ``security(1)`` itself doesn't either. Errors surface through
``MacKeychainError`` with a human-readable mapping of the underlying
``OSStatus``.

Cross-platform safety
---------------------

This module is **macOS-only**. Importing it on Linux / Windows raises
``ImportError`` at first use. Callers gate via ``sys.platform`` before
importing — see ``keystore.KeychainKeyStore`` for the dispatch.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import sys
from ctypes import (
    POINTER,
    c_char_p,
    c_int32,
    c_long,
    c_uint32,
    c_void_p,
)
from typing import Final

if sys.platform != "darwin":
    raise ImportError("macos_keychain is darwin-only; use the keyring fallback on other platforms")


# ---------------------------------------------------------------------------
# Framework loading
# ---------------------------------------------------------------------------

#: Absolute paths to the two frameworks we bind. ``ctypes.util.find_library``
#: returns the right .dylib for both on every macOS release back through
#: 10.15. We fail loud at import time if either is missing (it shouldn't be;
#: both ship with the OS) so callers don't get cryptic ``OSError: symbol not
#: found`` deep in a keychain call later.
_security_path = ctypes.util.find_library("Security")
_cf_path = ctypes.util.find_library("CoreFoundation")
if _security_path is None or _cf_path is None:
    raise ImportError(
        "macOS Security.framework or CoreFoundation.framework not found via "
        "ctypes.util.find_library — this should never happen on a real macOS "
        "install. Check $DYLD_LIBRARY_PATH and your Python build."
    )
_Security = ctypes.CDLL(_security_path, use_errno=False)
_CF = ctypes.CDLL(_cf_path, use_errno=False)


# ---------------------------------------------------------------------------
# CoreFoundation primitives
# ---------------------------------------------------------------------------

#: Opaque pointer that stands in for every ``CFTypeRef``-derived CF type.
#: All CF APIs traffic in opaque pointers, so we don't need separate
#: ``CFStringRef`` / ``CFDataRef`` / ``CFDictionaryRef`` ctypes — the
#: function signatures below distinguish them by call site.
CFTypeRef = c_void_p

#: ``CFIndex`` is ``long`` on macOS — verified per Apple's CFBase.h.
CFIndex = c_long

#: ``OSStatus`` is signed 32-bit. Apple-defined errno codes (errSecSuccess,
#: errSecItemNotFound, etc.) all live in this range.
OSStatus = c_int32

# kCFStringEncodingUTF8 = 0x08000100 per CFString.h. Used when bridging
# Python str → CFString.
_kCFStringEncodingUTF8: Final[c_uint32] = c_uint32(0x08000100)

# CFAllocatorRef NULL → defaults to kCFAllocatorDefault. We never need a
# non-default allocator; pass NULL throughout.
_kCFAllocatorDefault: Final[c_void_p] = c_void_p(None)

# CoreFoundation function signatures. Each declaration mirrors the C
# prototype from Apple's headers verbatim — getting any of these wrong
# silently corrupts arguments at the FFI boundary, so they're worth
# stating explicitly even when ctypes would otherwise default to int.
_CF.CFStringCreateWithCString.restype = CFTypeRef
_CF.CFStringCreateWithCString.argtypes = [c_void_p, c_char_p, c_uint32]

_CF.CFDataCreate.restype = CFTypeRef
_CF.CFDataCreate.argtypes = [c_void_p, c_char_p, CFIndex]

_CF.CFDataGetLength.restype = CFIndex
_CF.CFDataGetLength.argtypes = [CFTypeRef]

_CF.CFDataGetBytePtr.restype = POINTER(ctypes.c_char)
_CF.CFDataGetBytePtr.argtypes = [CFTypeRef]

_CF.CFDictionaryCreateMutable.restype = CFTypeRef
_CF.CFDictionaryCreateMutable.argtypes = [c_void_p, CFIndex, c_void_p, c_void_p]

_CF.CFDictionarySetValue.restype = None
_CF.CFDictionarySetValue.argtypes = [CFTypeRef, CFTypeRef, CFTypeRef]

_CF.CFRelease.restype = None
_CF.CFRelease.argtypes = [CFTypeRef]

# kCFTypeDictionaryKeyCallBacks / kCFTypeDictionaryValueCallBacks are
# globals exported from CoreFoundation. We need their *addresses* (passed
# by reference to CFDictionaryCreateMutable). ``in_dll`` reaches into the
# loaded dylib and grabs the symbol's address — exactly what we want.
_kCFTypeDictionaryKeyCallBacks = c_void_p.in_dll(_CF, "kCFTypeDictionaryKeyCallBacks")
_kCFTypeDictionaryValueCallBacks = c_void_p.in_dll(_CF, "kCFTypeDictionaryValueCallBacks")

# kCFBooleanTrue / kCFBooleanFalse are CFBoolean singletons. We need True
# for kSecUseDataProtectionKeychain.
_kCFBooleanTrue = c_void_p.in_dll(_CF, "kCFBooleanTrue")


# ---------------------------------------------------------------------------
# Security.framework — function signatures + constants
# ---------------------------------------------------------------------------

_Security.SecItemAdd.restype = OSStatus
_Security.SecItemAdd.argtypes = [CFTypeRef, POINTER(CFTypeRef)]

_Security.SecItemCopyMatching.restype = OSStatus
_Security.SecItemCopyMatching.argtypes = [CFTypeRef, POINTER(CFTypeRef)]

_Security.SecItemUpdate.restype = OSStatus
_Security.SecItemUpdate.argtypes = [CFTypeRef, CFTypeRef]

_Security.SecItemDelete.restype = OSStatus
_Security.SecItemDelete.argtypes = [CFTypeRef]

# Security.framework exports a bunch of CFStringRef globals that act as
# the canonical keys for the kSec* attribute dictionary. We pull the
# pointers in once at import time and reference them throughout.
_kSecClass = c_void_p.in_dll(_Security, "kSecClass")
_kSecClassGenericPassword = c_void_p.in_dll(_Security, "kSecClassGenericPassword")
_kSecAttrService = c_void_p.in_dll(_Security, "kSecAttrService")
_kSecAttrAccount = c_void_p.in_dll(_Security, "kSecAttrAccount")
_kSecValueData = c_void_p.in_dll(_Security, "kSecValueData")
_kSecReturnData = c_void_p.in_dll(_Security, "kSecReturnData")


# ---------------------------------------------------------------------------
# OSStatus → human-readable mapping
# ---------------------------------------------------------------------------

#: The OSStatus codes we care about, mapped to user-facing messages.
#: Anything not in this table surfaces as ``f"keychain error {status}"``;
#: the human-readable mapping is best-effort, not exhaustive.
#:
#: Sources: Apple's SecBase.h, TN3137, and the public OSStatus.com index.
_OSSTATUS_NAMES: Final[dict[int, str]] = {
    0: "errSecSuccess",
    -25291: "errSecNotAvailable — no keychain is available",
    -25292: "errSecReadOnly — keychain is read-only",
    -25293: "errSecAuthFailed — keychain authentication failed",
    -25294: "errSecNoSuchKeychain — the keychain does not exist",
    -25299: "errSecDuplicateItem — entry already exists (we handle this internally)",
    -25300: "errSecItemNotFound — entry not present",
    -25308: "errSecInteractionNotAllowed — UI interaction is required but not available",
    -25244: (
        "errSecInvalidOwnerEdit — keychain ACL rejected the write. "
        "This is the legacy-keychain bug DPK was supposed to avoid; "
        "report it if you see it here."
    ),
    -34018: "errSecMissingEntitlement — Security.framework refused due to missing entitlement",
}


class MacKeychainError(Exception):
    """Wrap a Security.framework ``OSStatus`` with a readable message.

    Attributes:
      - ``status`` — the raw ``OSStatus`` integer (negative for errors).
      - ``name`` — Apple's symbolic name when known, otherwise empty.
    """

    __slots__ = ("status", "name")

    def __init__(self, status: int, context: str = "") -> None:
        self.status = status
        self.name = _OSSTATUS_NAMES.get(status, "")
        detail = f"OSStatus {status} ({self.name})" if self.name else f"OSStatus {status}"
        if context:
            detail = f"{context}: {detail}"
        super().__init__(detail)


# ---------------------------------------------------------------------------
# Python ↔ CoreFoundation bridging helpers
# ---------------------------------------------------------------------------


def _cf_string(value: str) -> c_void_p:
    """Bridge ``str`` → ``CFStringRef``. Caller must release.

    UTF-8 encoding via ``kCFStringEncodingUTF8`` (0x08000100). The
    keychain accepts any printable Unicode for service / account names;
    we encode ASCII-or-UTF8 with no quoting / normalization beyond what
    Python's ``str.encode("utf-8")`` does.
    """
    encoded = value.encode("utf-8")
    cf = _CF.CFStringCreateWithCString(_kCFAllocatorDefault, encoded, _kCFStringEncodingUTF8)
    if not cf:
        raise MacKeychainError(-1, f"CFStringCreateWithCString returned NULL for {value!r}")
    return c_void_p(cf)


def _cf_data(value: bytes) -> c_void_p:
    """Bridge ``bytes`` → ``CFDataRef``. Caller must release.

    Empty ``bytes`` are legal — ``CFDataCreate`` accepts ``length=0``
    with any pointer. We pass an empty C string in that case to keep
    the type system happy.
    """
    cf = _CF.CFDataCreate(_kCFAllocatorDefault, value or b"", len(value))
    if not cf:
        raise MacKeychainError(-1, "CFDataCreate returned NULL")
    return c_void_p(cf)


def _cf_dict(pairs: list[tuple[c_void_p, c_void_p]]) -> c_void_p:
    """Build a ``CFMutableDictionaryRef`` from ``(key, value)`` pairs.

    All keys and values must be ``CFTypeRef``-equivalent ``c_void_p``.
    Caller must release the returned dictionary AND each non-global
    value it contains (the dictionary retains them, but we still need
    to balance our own initial Create reference).
    """
    capacity = CFIndex(len(pairs))
    d = _CF.CFDictionaryCreateMutable(
        _kCFAllocatorDefault,
        capacity,
        ctypes.byref(_kCFTypeDictionaryKeyCallBacks),
        ctypes.byref(_kCFTypeDictionaryValueCallBacks),
    )
    if not d:
        raise MacKeychainError(-1, "CFDictionaryCreateMutable returned NULL")
    for key, value in pairs:
        _CF.CFDictionarySetValue(d, key, value)
    return c_void_p(d)


def _bytes_from_cfdata(cf_data: c_void_p) -> bytes:
    """Copy a ``CFDataRef`` into a Python ``bytes``.

    ``CFDataGetBytePtr`` returns a pointer into the data's internal
    buffer — we ``string_at`` it with the length to copy the bytes
    into a Python-owned buffer before the CFData is released.
    """
    length = _CF.CFDataGetLength(cf_data)
    if length == 0:
        return b""
    ptr = _CF.CFDataGetBytePtr(cf_data)
    return ctypes.string_at(ptr, length)


def _release_all(*refs: c_void_p) -> None:
    """Release a sequence of CFTypeRefs, ignoring NULL entries.

    Used in ``finally`` blocks to balance every Create/Copy. CFRelease
    on NULL is undefined behavior per Apple's docs, so we guard.
    """
    for ref in refs:
        if ref and ref.value:
            _CF.CFRelease(ref)


# ---------------------------------------------------------------------------
# Public API: add_or_update / get / delete
# ---------------------------------------------------------------------------


def _build_query(cf_service: c_void_p, cf_account: c_void_p, *, with_return_data: bool = False) -> c_void_p:
    """Construct the standard lookup dict for an ``(service, account)`` pair.

    Used by ``get`` / ``delete`` / the duplicate-fallback path in
    ``add_or_update``. Setting ``with_return_data=True`` adds the
    ``kSecReturnData`` flag for the read path.
    """
    pairs: list[tuple[c_void_p, c_void_p]] = [
        (_kSecClass, _kSecClassGenericPassword),
        (_kSecAttrService, cf_service),
        (_kSecAttrAccount, cf_account),
    ]
    if with_return_data:
        pairs.append((_kSecReturnData, _kCFBooleanTrue))
    return _cf_dict(pairs)


def add_or_update(service: str, account: str, data: bytes) -> None:
    """Persist ``data`` under ``(service, account)`` in the macOS keychain.

    Implements the TN3137-prescribed safe-write pattern:

      1. ``SecItemAdd`` with the full attribute set (class + service +
         account + data).
      2. On ``errSecDuplicateItem`` (-25299), switch to ``SecItemUpdate``
         — which the same TN documents as NOT affected by the legacy
         ACL shim that breaks delete-then-add.

    The ``keyring`` library does delete-then-add, which is the
    one-true-broken pattern we're working around. Users whose v0.3.2
    install left a stale entry will land in the ``-25299 → update``
    branch on their first v0.3.3 setup; ``SecItemUpdate`` overwrites
    the broken entry's payload cleanly and the user is unblocked
    forever after.
    """
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(f"data must be bytes, got {type(data).__name__}")

    cf_service = _cf_string(service)
    cf_account = _cf_string(account)
    cf_data = _cf_data(bytes(data))
    cf_query: c_void_p | None = None
    cf_add_attrs: c_void_p | None = None
    cf_update_attrs: c_void_p | None = None
    try:
        cf_add_attrs = _cf_dict(
            [
                (_kSecClass, _kSecClassGenericPassword),
                (_kSecAttrService, cf_service),
                (_kSecAttrAccount, cf_account),
                (_kSecValueData, cf_data),
            ]
        )
        status = _Security.SecItemAdd(cf_add_attrs, None)
        if status == 0:
            return
        if status != -25299:
            raise MacKeychainError(status, context=f"SecItemAdd({service!r}, {account!r})")

        # Duplicate exists — overwrite via SecItemUpdate. Per TN3137
        # this path is immune to the -25244 shim that bites
        # SecItemDelete on rename, so the v0.3.2 stale-entry case
        # heals automatically on first run of v0.3.3.
        cf_query = _build_query(cf_service, cf_account)
        cf_update_attrs = _cf_dict([(_kSecValueData, cf_data)])
        status = _Security.SecItemUpdate(cf_query, cf_update_attrs)
        if status != 0:
            raise MacKeychainError(status, context=f"SecItemUpdate({service!r}, {account!r})")
    finally:
        _release_all(cf_service, cf_account, cf_data, cf_add_attrs, cf_query, cf_update_attrs)


def get(service: str, account: str) -> bytes | None:
    """Look up ``(service, account)``; return raw bytes or ``None`` if absent.

    No base64 decoding — callers own their own on-the-wire encoding.
    Returns ``None`` on ``errSecItemNotFound`` (-25300) per the
    idempotent-getter contract; raises ``MacKeychainError`` on any
    other failure.
    """
    cf_service = _cf_string(service)
    cf_account = _cf_string(account)
    cf_query: c_void_p | None = None
    cf_result = c_void_p(None)
    try:
        cf_query = _build_query(cf_service, cf_account, with_return_data=True)
        status = _Security.SecItemCopyMatching(cf_query, ctypes.byref(cf_result))
        if status == -25300:
            return None
        if status != 0:
            raise MacKeychainError(status, context=f"SecItemCopyMatching({service!r}, {account!r})")
        if not cf_result.value:
            return None
        return _bytes_from_cfdata(cf_result)
    finally:
        _release_all(cf_service, cf_account, cf_query, cf_result)


def delete(service: str, account: str) -> None:
    """Remove ``(service, account)`` from the keychain; no-op if absent.

    Two-step delete:

      1. ``SecItemDelete`` — works in the common case (entry created
         by this same binary, or by a binary with a matching ACL).
      2. On ``errSecInvalidOwnerEdit`` (-25244 — the legacy keychain's
         ACL shim rejecting the delete because the entry was created
         by a binary with a different signing identity), fall back
         to ``security(1)``'s ``delete-generic-password``. The CLI
         talks to ``securityd`` via XPC and isn't subject to the
         C-API ACL shim, so it can remove the entry cleanly.

    Idempotent: ``errSecItemNotFound`` (-25300) is treated as success.

    Why not ``SecItemUpdate`` with empty data (TN3137's other suggestion)?
    Empirical testing on macOS 14+ shows ``SecItemUpdate`` no-ops on
    empty ``kSecValueData`` — the SecItem layer apparently treats
    "empty attribute value" as "leave this attribute alone". The CLI
    fallback is the only path that actually removes the entry from
    the keychain.
    """
    cf_service = _cf_string(service)
    cf_account = _cf_string(account)
    cf_query: c_void_p | None = None
    try:
        cf_query = _build_query(cf_service, cf_account)
        status = _Security.SecItemDelete(cf_query)
        if status in (0, -25300):
            return
        if status != -25244:
            raise MacKeychainError(status, context=f"SecItemDelete({service!r}, {account!r})")
    finally:
        _release_all(cf_service, cf_account, cf_query)

    # ACL shim rejected the in-process delete. Fall back to securityd
    # via Apple's bundled ``security(1)``. Subprocess runs outside the
    # ``finally`` above so the CF refs are already released before we
    # shell out.
    import subprocess

    try:
        result = subprocess.run(
            ["security", "delete-generic-password", "-s", service, "-a", account],
            check=False,
            capture_output=True,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MacKeychainError(
            -25244,
            context=f"SecItemDelete returned -25244; security(1) fallback failed: {exc!r}",
        ) from exc
    if result.returncode != 0:
        # security(1) returns 44 (errSecItemNotFound mapped) when there's
        # nothing to delete. Idempotent contract: treat as success.
        stderr_text = result.stderr.decode("utf-8", errors="replace").strip()
        if "could not be found" in stderr_text:
            return
        raise MacKeychainError(
            -25244,
            context=(
                f"SecItemDelete returned -25244; "
                f"security(1) fallback also failed (rc={result.returncode}): {stderr_text[:200]}"
            ),
        )


__all__ = [
    "MacKeychainError",
    "add_or_update",
    "delete",
    "get",
]
