"""OS-level keystore backends for the local stdio MCP client.

Phase D of MCP issue #13534. Stores the user's AES-256 *derived key*
(32 bytes, produced once by ``CryptoManager._derive_key`` from the
passphrase + server salt) so subsequent MCP sessions don't have to
re-prompt for the passphrase or pay the ~300ms PBKDF2 cost on every
start.

We deliberately store the derived key, not the passphrase, because:

- The key, once derived, is the only thing the runtime actually needs.
- Re-deriving PBKDF2-HMAC-SHA256 at 600,000 iterations is ~200-500ms on
  modern laptops — a noticeable per-session tax for a tool that opens
  twice per Claude/ChatGPT spin-up.
- The passphrase is also useful for the user (they may type it from
  memory); the derived key is not. Storing the less-recoverable secret
  in the keystore minimizes blast radius if someone exfiltrates the
  on-disk store.

Backends (priority order — see ``get_keystore()``):

1. **1Password CLI** (``OnePasswordKeyStore``) — if the ``op`` binary is
   on PATH and is signed in. Best UX: Touch ID via 1Password's own
   biometric gate, syncs across the user's devices, audit log via
   1Password's web console.
2. **OS keychain** (``KeychainKeyStore``) — wraps the ``keyring`` library.
   On macOS, that's the system Keychain (Touch-ID-gated by default for
   the user's login keychain). On Linux, GNOME Keyring / KWallet via
   Secret Service.
3. **Plaintext file** (``PlaintextKeyStore``) — last resort, opt-in only
   via ``insecure_plaintext=True``. Writes ``~/.whenful/key.b64`` with
   ``0o600`` permissions. Documented as a security downgrade.

All three are documented as user-selectable in the plan doc §11 Q3 —
locked as MUST-haves by Alex on the 2026-04-09 plan.

Privacy & telemetry posture
---------------------------

Zero telemetry. The ``op`` subprocess is invoked with ``stdin``-piped
input so the key never appears on the process command line (and thus
never lands in shell history or ``ps`` output). ``__repr__`` redacts the
backend's name only — not any payload. ``KeyStoreError`` carries no
secret material in its message.

This module must NOT import from ``app.*``. The ``mcp_stdio`` subpackage
ships as a separately publishable wheel in Phase F.
"""

from __future__ import annotations

import base64
import contextlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Final, Protocol, runtime_checkable

#: Service identifier used for ``keyring`` lookups. The ``keyring`` library
#: treats this as the namespace under which an "account" key is stored.
#: Stable across versions — changing it orphans existing keychain entries.
KEYRING_SERVICE: Final[str] = "whenful-mcp"

#: Default 1Password item title. Users can override by passing a custom
#: ``item_title`` to ``OnePasswordKeyStore`` if they share a vault and need
#: disambiguation; the default is fine for the common single-user case.
ONEPASSWORD_ITEM_TITLE: Final[str] = "Whenful MCP Encryption Key"

#: Default 1Password field name on the stored item. Items of category
#: ``password`` ship with a ``password`` field by default; we reuse it
#: rather than creating a custom one so ``op item get --fields password``
#: works without extra schema.
ONEPASSWORD_FIELD: Final[str] = "password"

#: Default plaintext-fallback path. Override at construction time for
#: tests or unusual setups.
DEFAULT_PLAINTEXT_PATH: Final[str] = "~/.whenful/key.b64"


class KeyStoreError(Exception):
    """Base class for keystore errors raised by this module.

    The message never contains the key material itself — only the
    backend-level cause (e.g., "op exited with status 1", "permission
    denied on ~/.whenful/key.b64"). Callers should surface the message
    verbatim to the user without further redaction.
    """


@runtime_checkable
class KeyStore(Protocol):
    """Protocol every keystore backend satisfies.

    Methods are intentionally synchronous: keystore I/O is fast (single
    keychain query or one ``op`` shell-out) and the stdio MCP client is
    not in a hot loop. An async wrapper can sit on top in Phase E if the
    main event loop needs it.

    ``account`` is the user-identifying key — typically the email of the
    Whenful account paired to this device. Multiple accounts on the same
    machine round-trip independently.
    """

    def save(self, account: str, key: bytes) -> None:
        """Persist ``key`` under ``account``. Overwrites any prior value."""

    def load(self, account: str) -> bytes | None:
        """Return ``key`` for ``account``, or ``None`` if not present."""

    def delete(self, account: str) -> None:
        """Remove the entry for ``account``. Idempotent — no error if absent."""


# ---------------------------------------------------------------------------
# Backend 1: keyring (OS keychain / Secret Service)
# ---------------------------------------------------------------------------


class KeychainKeyStore:
    """OS keychain backend — native ``Security.framework`` on macOS, ``keyring`` elsewhere.

    On macOS we use a direct ctypes binding to ``Security.framework``
    (``mcp_stdio.macos_keychain``) instead of the ``keyring`` library.
    The reason is documented in detail there, but the short version:
    ``keyring.set_password`` does delete-then-add, which hits Apple's
    legacy keychain ACL shim and fails with ``errSecInvalidOwnerEdit``
    (-25244) on every wheel upgrade. The native binding follows Apple
    TN3137's prescribed safe pattern (``SecItemAdd`` with
    ``SecItemUpdate`` fallback on duplicate, ``SecItemDelete`` with
    ``SecItemUpdate``-to-empty-data fallback on -25244). This survives
    pip-upgrades transparently and is the only path that actually
    works for an end-user-installable Python wheel on macOS.

    On Linux that's GNOME Keyring / KWallet via the Secret Service
    D-Bus protocol (via ``keyring``). On Windows, the Credential
    Manager (via ``keyring``). Neither platform has the legacy ACL
    shim, so ``keyring`` is the right tool there.

    Stored value on every backend is the **base64 encoding** of the
    derived-key bytes. macOS Security.framework would accept raw
    bytes, but Linux/Windows ``keyring`` accepts only ``str``; we
    use the same base64 wrapping everywhere so the storage layout
    is portable and the on-disk representation stays
    human-inspectable (the user can verify with Keychain Access.app
    that *some* opaque-looking string is stored).
    """

    __slots__ = ("_service",)

    def __init__(self, service: str = KEYRING_SERVICE) -> None:
        self._service: str = service

    @staticmethod
    def is_available() -> bool:
        """Return whether a usable keychain backend exists on this host.

        On macOS this is always ``True`` — ``Security.framework`` is
        shipped with the OS and our ctypes binding has no runtime
        dependencies the OS lacks.

        On Linux / Windows we delegate to ``keyring`` and check
        whether it resolves anything other than the ``fail`` /
        ``null`` no-op backend (which is what ``keyring`` returns
        when there's no Secret Service / Credential Manager
        reachable).
        """
        if sys.platform == "darwin":
            try:
                import mcp_stdio.macos_keychain  # noqa: F401 — import probes ctypes load
            except (ImportError, OSError):
                return False
            return True
        try:
            import keyring
            from keyring.backends import fail as _fail_backend
        except ImportError:
            return False
        try:
            backend = keyring.get_keyring()
        except Exception:  # noqa: BLE001 — keyring init can raise anything
            return False
        return not isinstance(backend, _fail_backend.Keyring)

    def save(self, account: str, key: bytes) -> None:
        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")

        if sys.platform == "darwin":
            from . import macos_keychain

            try:
                macos_keychain.add_or_update(self._service, account, encoded.encode("ascii"))
            except macos_keychain.MacKeychainError as exc:
                raise KeyStoreError(f"macOS keychain write failed: {exc}") from exc
            return

        import keyring

        try:
            keyring.set_password(self._service, account, encoded)
        except Exception as exc:  # noqa: BLE001 — keyring raises platform-specific errors
            raise KeyStoreError(f"keyring set_password failed: {exc!r}") from exc

    def load(self, account: str) -> bytes | None:
        if sys.platform == "darwin":
            from . import macos_keychain

            try:
                raw = macos_keychain.get(self._service, account)
            except macos_keychain.MacKeychainError as exc:
                raise KeyStoreError(f"macOS keychain read failed: {exc}") from exc
            if raw is None or len(raw) == 0:
                # Empty payload = TN3137's delete-via-update-with-empty
                # fallback was used at some point. The slot still exists
                # in the keychain but its semantic is "no key" — the next
                # ``save`` will hit the SecItemAdd → -25299 duplicate
                # path and overwrite via SecItemUpdate. Self-healing.
                return None
            try:
                return base64.b64decode(raw, validate=True)
            except (ValueError, TypeError) as exc:
                raise KeyStoreError(f"stored keychain value is not valid base64: {exc!r}") from exc

        import keyring

        try:
            encoded = keyring.get_password(self._service, account)
        except Exception as exc:  # noqa: BLE001
            raise KeyStoreError(f"keyring get_password failed: {exc!r}") from exc
        if encoded is None:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored keyring value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:
        if sys.platform == "darwin":
            from . import macos_keychain

            try:
                macos_keychain.delete(self._service, account)
            except macos_keychain.MacKeychainError as exc:
                raise KeyStoreError(f"macOS keychain delete failed: {exc}") from exc
            return

        import keyring
        from keyring.errors import PasswordDeleteError

        try:
            keyring.delete_password(self._service, account)
        except PasswordDeleteError:
            # Not present — idempotent contract; swallow.
            return
        except Exception as exc:  # noqa: BLE001
            raise KeyStoreError(f"keyring delete_password failed: {exc!r}") from exc

    def __repr__(self) -> str:
        return f"KeychainKeyStore(service={self._service!r})"


# ---------------------------------------------------------------------------
# Backend 2: 1Password CLI (op)
# ---------------------------------------------------------------------------


class OnePasswordKeyStore:
    """Shells out to the 1Password ``op`` CLI.

    Requires the user to have ``op`` installed (Homebrew: ``brew install
    1password-cli``) and to have run ``op signin`` for the relevant
    account. ``is_available()`` checks both conditions.

    The key bytes round-trip through base64 (same as ``KeychainKeyStore``)
    so the stored value is opaque-ASCII rather than binary. The key is
    passed to ``op`` via **stdin**, not via the command line — this keeps
    it out of ``ps`` output and the user's shell history.

    Item lookup is by title (default ``ONEPASSWORD_ITEM_TITLE``) inside
    the user's default 1Password account; passing ``vault=...`` to the
    constructor narrows lookup to a specific vault.
    """

    __slots__ = ("_item_title", "_vault", "_op_binary")

    def __init__(
        self,
        *,
        item_title: str = ONEPASSWORD_ITEM_TITLE,
        vault: str | None = None,
        op_binary: str = "op",
    ) -> None:
        self._item_title: str = item_title
        self._vault: str | None = vault
        self._op_binary: str = op_binary

    @staticmethod
    def is_available(op_binary: str = "op") -> bool:
        """Return whether ``op`` is on PATH AND a signed-in account exists.

        We run ``op account list`` and check exit status — a non-zero
        exit (no accounts configured, or auth required) makes this
        backend unusable for the current process.
        """
        if shutil.which(op_binary) is None:
            return False
        try:
            result = subprocess.run(  # noqa: S603 — op is the user's installed CLI, no shell
                [op_binary, "account", "list", "--format=json"],
                capture_output=True,
                timeout=5.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        if result.returncode != 0:
            return False
        # ``op account list`` returns ``[]`` (empty JSON array) when the
        # binary is installed but no account has been added yet. Anything
        # non-empty plus a 0 exit means at least one account is
        # configured — that's good enough; ``op item get`` will prompt
        # for biometric/Touch ID at use time.
        stdout = result.stdout.decode("utf-8", errors="ignore").strip()
        return bool(stdout) and stdout != "[]"

    def save(self, account: str, key: bytes) -> None:
        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")
        # Write the key via a documented secret-safe channel: ``op item
        # create --template=PATH`` reading a JSON template from a 0o600
        # tempfile. The argv-based assignment syntax ``password=VALUE``
        # exposes secrets in ``ps aux``, ``proc_pidinfo``, EDR agent
        # process logs, and screen-shared sessions. The ``field=@FILE``
        # assignment syntax is documented for ``file``-type attachments
        # only, not for ``CONCEALED`` password fields (1Password CLI v2
        # treats ``@/path`` as "upload this file as an attachment"). The
        # JSON-template path is the documented secret-safe pattern
        # (1Password CLI reference §"item create" → ``--template``).
        #
        # Tempfile is created with mode 0o600 via ``mkstemp`` (POSIX
        # default), written, passed to ``op``, and unlinked in ``finally``.
        # On-disk window is ~50ms with restrictive permissions, much
        # smaller blast radius than argv exposure (which lives for the
        # subprocess lifetime + lingers in any audit/EDR snapshot).
        #
        # ``op item edit`` lacks ``--template`` flag in CLI v2, so we
        # delete-then-create on update. Item history is sacrificed for
        # correctness; the only data lost is the prior key, which the
        # user just replaced anyway. ``op item delete`` is idempotent
        # via our ``_exists()`` precheck.
        if self._exists(account):
            self._delete_item()
        self._create_item_from_template(account=account, encoded=encoded)

    def _delete_item(self) -> None:
        """Delete the existing item if present. Idempotent on ``isn't an item``."""
        cmd = [self._op_binary, "item", "delete", self._item_title]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=10.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item delete (pre-save) failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip().lower()
            if "isn't an item" in stderr or "doesn't exist" in stderr or "not found" in stderr:
                return  # idempotent
            raise KeyStoreError(f"op item delete (pre-save) exited {result.returncode}: {stderr}")

    def _create_item_from_template(self, *, account: str, encoded: str) -> None:
        """Create the password item via ``op item create --template=PATH``.

        Writes the JSON template to a 0o600 tempfile, runs ``op`` against
        it, and unlinks the tempfile in ``finally``. The on-disk window
        is short (~50ms) and the permissions restrict reads to the
        invoking user. Compare to argv assignment which exposes the key
        for the full subprocess lifetime to ``ps``, EDR agents, etc.
        """
        template: dict[str, Any] = {
            "title": self._item_title,
            "category": "PASSWORD",
            "fields": [
                {
                    "id": "password",
                    "type": "CONCEALED",
                    "purpose": "PASSWORD",
                    "label": "password",
                    "value": encoded,
                },
                {
                    "id": "username",
                    "type": "STRING",
                    "purpose": "USERNAME",
                    "label": "username",
                    "value": account,
                },
            ],
        }
        fd, template_path = tempfile.mkstemp(suffix=".json", prefix="whenful-mcp-")
        try:
            try:
                # mkstemp creates with 0o600 by default on POSIX; explicit
                # chmod is belt-and-suspenders against umask weirdness.
                os.fchmod(fd, 0o600)
                os.write(fd, json.dumps(template).encode("utf-8"))
            finally:
                os.close(fd)
            cmd = [self._op_binary, "item", "create", f"--template={template_path}"]
            if self._vault is not None:
                cmd.append(f"--vault={self._vault}")
            try:
                result = subprocess.run(  # noqa: S603
                    cmd,
                    capture_output=True,
                    timeout=30.0,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise KeyStoreError(f"op item create failed: {exc!r}") from exc
            if result.returncode != 0:
                stderr = result.stderr.decode("utf-8", errors="ignore").strip()
                raise KeyStoreError(f"op item create exited {result.returncode}: {stderr}")
        finally:
            # Best-effort cleanup; tempfile may already be gone if
            # something else raced us. Not a security issue —
            # permissions are 0o600.
            with contextlib.suppress(OSError):
                os.unlink(template_path)

    def load(self, account: str) -> bytes | None:  # noqa: ARG002 — account encoded as username; lookup is by title
        cmd = [
            self._op_binary,
            "item",
            "get",
            self._item_title,
            f"--fields={ONEPASSWORD_FIELD}",
            "--reveal",
        ]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=30.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item get failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip().lower()
            # ``op`` returns non-zero with "isn't an item" / "doesn't exist"
            # when the title isn't present in the vault — treat as "no
            # value stored" per the KeyStore.load contract.
            if "isn't an item" in stderr or "doesn't exist" in stderr or "not found" in stderr:
                return None
            raise KeyStoreError(f"op item get exited {result.returncode}: {stderr}")
        encoded = result.stdout.decode("utf-8", errors="ignore").strip()
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored 1Password value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:  # noqa: ARG002
        cmd = [self._op_binary, "item", "delete", self._item_title]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=30.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item delete failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip().lower()
            if "isn't an item" in stderr or "doesn't exist" in stderr or "not found" in stderr:
                return
            raise KeyStoreError(f"op item delete exited {result.returncode}: {stderr}")

    def _exists(self, account: str) -> bool:  # noqa: ARG002
        cmd = [self._op_binary, "item", "get", self._item_title, "--format=json"]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=10.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        return result.returncode == 0

    def __repr__(self) -> str:
        return f"OnePasswordKeyStore(item_title={self._item_title!r}, vault={self._vault!r})"


# ---------------------------------------------------------------------------
# Backend 3: plaintext file (escape hatch)
# ---------------------------------------------------------------------------


class PlaintextKeyStore:
    """Last-resort backend that writes the key to a 0o600 file.

    Use only when neither 1Password nor the OS keychain is available
    (e.g., headless Linux with no Secret Service, CI without keychain).
    Users must opt in explicitly via ``get_keystore(insecure_plaintext=True)``
    — the factory never selects this silently.

    File format: base64(key) on a single line, UTF-8, no trailing
    newline. The parent directory is created with ``0o700`` and the file
    with ``0o600`` so other local users cannot read either.
    """

    __slots__ = ("_path",)

    def __init__(self, path: str | Path = DEFAULT_PLAINTEXT_PATH) -> None:
        self._path: Path = Path(path).expanduser()

    @property
    def path(self) -> Path:
        return self._path

    def save(self, account: str, key: bytes) -> None:  # noqa: ARG002 — single-account file
        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            # Restrictive mode at open time so umask can't loosen it.
            fd = os.open(str(self._path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(encoded)
            # Belt-and-suspenders chmod in case umask masked the open mode.
            try:
                os.chmod(str(self._path), 0o600)
                os.chmod(str(self._path.parent), 0o700)
            except OSError:
                # Best effort on platforms without POSIX modes.
                pass
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore write to {self._path} failed: {exc!r}") from exc

    def load(self, account: str) -> bytes | None:  # noqa: ARG002
        if not self._path.exists():
            return None
        try:
            with self._path.open("r", encoding="utf-8") as f:
                encoded = f.read().strip()
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore read from {self._path} failed: {exc!r}") from exc
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored plaintext value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:  # noqa: ARG002
        try:
            self._path.unlink(missing_ok=True)
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore unlink of {self._path} failed: {exc!r}") from exc

    def __repr__(self) -> str:
        return f"PlaintextKeyStore(path={str(self._path)!r})"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_keystore(
    *,
    insecure_plaintext: bool = False,
    plaintext_path: str | Path = DEFAULT_PLAINTEXT_PATH,
    op_binary: str = "op",
    keyring_service: str = KEYRING_SERVICE,
) -> KeyStore:
    """Auto-detect the best available keystore for this machine.

    Priority order (locked by plan §11 Q3):

    1. **1Password CLI** — if ``op`` is installed and at least one
       account is configured. Touch ID lives in 1Password's own gate.
    2. **OS keychain** — via the ``keyring`` library. macOS Keychain
       (Touch ID gated), Linux Secret Service (GNOME Keyring / KWallet),
       Windows Credential Manager.
    3. **Plaintext file** — only if ``insecure_plaintext=True``. The
       caller is expected to have shown the user a security warning and
       gotten an affirmative opt-in.

    If 1 and 2 are unavailable AND ``insecure_plaintext=False``, this
    raises ``KeyStoreError`` rather than silently downgrading.
    """
    if OnePasswordKeyStore.is_available(op_binary=op_binary):
        return OnePasswordKeyStore(op_binary=op_binary)
    if KeychainKeyStore.is_available():
        return KeychainKeyStore(service=keyring_service)
    if insecure_plaintext:
        return PlaintextKeyStore(path=plaintext_path)
    raise KeyStoreError(
        "No secure keystore backend available "
        "(1Password CLI not signed in, OS keychain unreachable). "
        "Re-run with insecure_plaintext=True to opt into ~/.whenful/key.b64 "
        "(0o600 plaintext) as a last resort."
    )


__all__ = [
    "DEFAULT_PLAINTEXT_PATH",
    "KEYRING_SERVICE",
    "KeyStore",
    "KeyStoreError",
    "KeychainKeyStore",
    "ONEPASSWORD_FIELD",
    "ONEPASSWORD_ITEM_TITLE",
    "OnePasswordKeyStore",
    "PlaintextKeyStore",
    "get_keystore",
]
