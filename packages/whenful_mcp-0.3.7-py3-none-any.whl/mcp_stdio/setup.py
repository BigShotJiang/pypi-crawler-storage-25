"""Interactive first-run setup for the local stdio MCP client.

Run as ``python -m mcp_stdio.setup`` (a console-script entrypoint
comes in Phase F).

What it does
------------

1. Runs the OAuth 2.1 PKCE pairing flow against the Whenful cloud
   server (``mcp_stdio.oauth_flow.run_oauth_flow``). The user's browser
   opens at ``/oauth/authorize``; after consent the loopback listener
   captures the authorization code, exchanges it for tokens, and
   ``AuthManager`` persists the resulting ``{access_token,
   refresh_token, expires_at}`` to ``~/.whenful/tokens.json``.
2. Fetches ``GET /api/v1/preferences/encryption`` with the freshly-
   issued bearer token to retrieve the user's encryption salt + the
   server-stored test ciphertext.
3. If encryption is disabled on the account, prints a clear message and
   exits cleanly — no key to store.
4. Otherwise, prompts the user for their passphrase via ``getpass``,
   derives the AES-256 key with ``CryptoManager``, and verifies the
   passphrase by decrypting the test ciphertext and comparing the
   plaintext to ``ENCRYPTION_TEST_VALUE``.
5. Wrong passphrase → reprompt (up to ``MAX_PASSPHRASE_ATTEMPTS``);
   exhausted retries → exit non-zero.
6. Right passphrase → persist the **derived key bytes** into the best
   available keystore (1Password CLI → OS keychain → opt-in plaintext).

Why OAuth 2.1 PKCE instead of token-paste
-----------------------------------------

The Phase D shape (paste DevTools tokens) was a stopgap while the
cloud OAuth surface stabilised. Now that ``app/routers/oauth.py``
ships the full RFC 7591 + RFC 7636 + RFC 8414 stack, the standalone
CLI can pair the same way Claude Desktop and Claude Code do — via a
loopback redirect into a dynamically-registered client. No more
copy-pasting bearer tokens out of DevTools, no more re-pasting after
the refresh window expires.

Privacy & telemetry posture
---------------------------

Zero telemetry. The passphrase is read with ``getpass.getpass`` so it
never echoes to the terminal. The OAuth flow's secrets (verifier,
state, authorization code) live in flow locals and drop on return.
The derived key is held in memory only as long as needed to call
``KeyStore.save`` and then dropped. No ``print()`` of secrets —
printed strings are limited to user-visible status and a final
summary that names the keystore backend (never the key itself).

This module must NOT import from ``app.*`` at module load time. We
defer the ``ENCRYPTION_TEST_VALUE`` import to inside the call chain via
``CryptoManager.verify_passphrase`` (which already does the lazy
import) so the ``mcp_stdio`` package stays standalone-wheel-friendly
for Phase F.
"""

from __future__ import annotations

import asyncio
import getpass
import json
import sys
from collections.abc import Callable
from typing import Any, Final

import httpx

from .auth import AuthManager, _resolve_api_base
from .client_wire import (
    WHENFUL_ENTRY,
    WireOutcome,
    detect_clients,
    wire_client,
)
from .crypto import CryptoManager
from .keystore import KeyStore, KeyStoreError, get_keystore
from .oauth_flow import OAuthFlowError, run_oauth_flow

#: How many times to reprompt for the passphrase before aborting. Keeps
#: typo-recovery cheap without giving an attacker who has stolen the
#: bearer token unlimited guesses against the local PBKDF2.
MAX_PASSPHRASE_ATTEMPTS: Final[int] = 3

#: Exit codes from the CLI entrypoint. Standard convention — main()
#: returns these and ``sys.exit()`` propagates them.
#:
#: Note on numbering: 2 was previously ``EXIT_TOKEN_PASTE_INVALID``,
#: retired alongside the paste-tokens setup path. The slot is left
#: vacant rather than re-used so any external automation that captured
#: the historical exit code can recognize "this version no longer
#: prompts" without confusing the new semantics. New codes append
#: above the gap.
EXIT_OK: Final[int] = 0
EXIT_WRONG_PASSPHRASE: Final[int] = 1
# (2 reserved — formerly EXIT_TOKEN_PASTE_INVALID, removed with OAuth flow)
EXIT_NETWORK_ERROR: Final[int] = 3
EXIT_KEYSTORE_ERROR: Final[int] = 4
EXIT_OAUTH_FAILED: Final[int] = 5
EXIT_USER_CANCELLED: Final[int] = 130  # POSIX SIGINT exit code


def _stderr(msg: str) -> None:
    """Print to stderr with a single trailing newline. Cheap shim so
    tests can monkeypatch ``sys.stderr`` and capture user-visible output
    without colliding with whatever ``capsys`` does to stdout.
    """
    print(msg, file=sys.stderr)


def _stdout(msg: str) -> None:
    """Symmetric counterpart to ``_stderr`` for normal status messages."""
    print(msg)


async def _fetch_encryption_status(
    auth: AuthManager,
    *,
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """``GET /api/v1/preferences/encryption`` and return the parsed body.

    Raises ``httpx.HTTPError`` on transport failure (handled upstream by
    ``run_setup``). Returns a dict with ``enabled``, ``salt``, and
    ``test_value`` (the last two are ``None`` if encryption is off).
    """
    base = _resolve_api_base().rstrip("/")
    token = await auth.get_access_token()
    owns_client = http_client is None
    client = http_client or httpx.AsyncClient(timeout=30.0)
    try:
        response = await client.get(
            f"{base}/preferences/encryption",
            headers={"Authorization": f"Bearer {token}"},
        )
    finally:
        if owns_client:
            await client.aclose()
    response.raise_for_status()
    body = response.json()
    if not isinstance(body, dict):
        raise httpx.DecodingError(
            f"/preferences/encryption returned non-dict payload: {type(body).__name__}",
        )
    return body


async def _fetch_user_email(
    auth: AuthManager,
    *,
    http_client: httpx.AsyncClient | None = None,
) -> str | None:
    """``GET /api/v1/me`` and return the user's email, or ``None`` on error.

    Used to label the keystore entry with the user's actual email
    address instead of an opaque token-derived hash, so Keychain Access
    / 1Password display a recognizable owner and future multi-account
    support is trivial (different accounts → different labels).

    Best-effort: callers should tolerate ``None`` and fall back to the
    legacy sha256-based label. Network failures and missing/malformed
    fields all return ``None`` rather than raising — we'd rather pair
    the device with a hash label than abort setup on a flaky network.
    """
    base = _resolve_api_base().rstrip("/")
    try:
        token = await auth.get_access_token()
    except Exception:  # noqa: BLE001 — auth failure is the caller's problem; we only fail soft
        return None
    owns_client = http_client is None
    client = http_client or httpx.AsyncClient(timeout=30.0)
    try:
        try:
            response = await client.get(
                f"{base}/me",
                headers={"Authorization": f"Bearer {token}"},
            )
        except httpx.HTTPError:
            return None
        if response.status_code != 200:
            return None
        try:
            body = response.json()
        except ValueError:
            return None
    finally:
        if owns_client:
            await client.aclose()
    if not isinstance(body, dict):
        return None
    email = body.get("email")
    if not isinstance(email, str) or not email:
        return None
    return email


def _prompt_passphrase(
    *,
    salt: bytes,
    encrypted_test_value: str,
    getpass_fn: Callable[[str], str] = getpass.getpass,
) -> CryptoManager | None:
    """Loop until the user types a correct passphrase OR exhausts retries.

    Returns a constructed ``CryptoManager`` on success, ``None`` on
    exhausted attempts. ``getpass_fn`` is dependency-injected for tests.
    """
    for attempt in range(1, MAX_PASSPHRASE_ATTEMPTS + 1):
        try:
            passphrase = getpass_fn(f"Passphrase (attempt {attempt}/{MAX_PASSPHRASE_ATTEMPTS}): ")
        except (EOFError, KeyboardInterrupt):
            _stderr("\nAborted.")
            return None
        if not passphrase:
            _stderr("Empty passphrase. Try again.")
            continue
        crypto = CryptoManager(passphrase, salt)
        # ``verify_passphrase`` returns False on any decryption failure
        # — wrong key, corrupted ciphertext, etc. We don't differentiate
        # because (a) the user can't act on the difference, and (b) the
        # error messages would themselves leak structural info about
        # the test-value layout to a future attacker reading stderr.
        if crypto.verify_passphrase(encrypted_test_value):
            return crypto
        _stderr("Wrong passphrase.")
    return None


async def run_setup(
    *,
    auth: AuthManager | None = None,
    keystore: KeyStore | None = None,
    insecure_plaintext: bool = False,
    http_client: httpx.AsyncClient | None = None,
    input_fn: Callable[[str], str] = input,
    getpass_fn: Callable[[str], str] = getpass.getpass,
    oauth_runner: Callable[..., Any] | None = None,
) -> int:
    """Run the interactive first-run setup, returning an exit code.

    All collaborators (``auth``, ``keystore``, ``http_client``,
    ``oauth_runner``, the passphrase prompt) are dependency-injected so
    the function is unit-testable without touching the real keychain,
    real httpx network, or real browser. The CLI ``main()`` wires the
    defaults.

    The ``input_fn`` parameter feeds the auto-wire confirmation prompt
    (one yes/no per detected MCP client) so tests can deterministically
    drive the wiring step. When stdin is not a tty, the wiring prompt
    is skipped and manual instructions are printed instead — "do no
    harm" default for non-interactive contexts.

    Returns:
      - ``EXIT_OK`` (0) on success.
      - ``EXIT_OAUTH_FAILED`` (5) if the OAuth flow didn't yield tokens
        (user denial, 5-minute timeout, or protocol-level failure).
      - ``EXIT_NETWORK_ERROR`` (3) on transport failure to /preferences/encryption.
      - ``EXIT_WRONG_PASSPHRASE`` (1) if all passphrase attempts failed.
      - ``EXIT_KEYSTORE_ERROR`` (4) if persisting the key failed.
      - ``EXIT_USER_CANCELLED`` (130) on Ctrl-C / EOF at the prompt.
    """
    owns_auth = auth is None
    if auth is None:
        auth = AuthManager()

    if oauth_runner is None:
        oauth_runner = run_oauth_flow

    try:
        # -- Step 1: OAuth 2.1 PKCE pairing ----------------------------
        _stdout("Step 1/2 — Pairing this device with Whenful via OAuth.")
        _stdout("  Your browser will open at the consent page; complete sign-in and approve.")
        try:
            # The oauth flow takes its own http_client (or makes one).
            # If the caller supplied one, thread it through so the tests
            # can route /oauth/* at their MockTransport while the
            # encryption-status step uses the same client.
            tokens = await oauth_runner(
                api_base=_resolve_api_base(),
                http_client=http_client,
            )
        except OAuthFlowError as exc:
            _stderr(f"OAuth pairing failed: {exc}")
            return EXIT_OAUTH_FAILED
        except (EOFError, KeyboardInterrupt):
            _stderr("\nAborted during OAuth pairing.")
            return EXIT_USER_CANCELLED

        if tokens is None:
            _stderr(
                "OAuth pairing did not complete (timeout, user denial, or no callback). "
                "Re-run setup and approve the consent page within 5 minutes.",
            )
            return EXIT_OAUTH_FAILED

        # Persist tokens first so ``auth.get_access_token()`` works for the
        # /me lookup below. We then enrich the token blob with the user's
        # email and re-save so subsequent invocations (serve, logout) can
        # label the keystore entry with a recognizable identifier.
        auth.save(tokens)
        _stdout(f"Tokens saved to {auth.token_path}.")

        # Fetch user email for keystore labeling. Best-effort: if /me is
        # unreachable, we fall back to the legacy sha256-hash label later.
        email = await _fetch_user_email(auth, http_client=http_client)
        if email is not None:
            tokens_with_email = dict(tokens)
            tokens_with_email["email"] = email
            auth.save(tokens_with_email)
            tokens = tokens_with_email

        # -- Step 2: fetch encryption status ----------------------------
        _stdout("Step 2/2 — Verifying encryption passphrase.")
        try:
            status = await _fetch_encryption_status(auth, http_client=http_client)
        except httpx.HTTPStatusError as exc:
            _stderr(f"Server returned {exc.response.status_code} on /preferences/encryption.")
            return EXIT_NETWORK_ERROR
        except httpx.HTTPError as exc:
            _stderr(f"Could not reach Whenful API: {exc!r}")
            return EXIT_NETWORK_ERROR

        if not status.get("enabled"):
            _stdout(
                "Encryption is disabled on this account. No key to store; setup is complete.",
            )
            # P1-MCP5: surface the Claude Desktop config snippet even on
            # the encryption-disabled path — pipx users who skipped the
            # README would otherwise hit a dead end.
            _wire_or_hint(_account_label_from_tokens(tokens), input_fn=input_fn)
            return EXIT_OK

        salt_b64 = status.get("salt")
        encrypted_test_value = status.get("test_value")
        if not isinstance(salt_b64, str) or not isinstance(encrypted_test_value, str):
            _stderr(
                "/preferences/encryption returned encryption_enabled but missing salt or "
                "test_value. Cannot verify; aborting.",
            )
            return EXIT_NETWORK_ERROR
        try:
            import base64

            salt = base64.b64decode(salt_b64, validate=True)
        except (ValueError, TypeError) as exc:
            _stderr(f"Server-side encryption salt is not valid base64: {exc!r}")
            return EXIT_NETWORK_ERROR

        # -- Step 3: passphrase prompt loop -----------------------------
        crypto = _prompt_passphrase(
            salt=salt,
            encrypted_test_value=encrypted_test_value,
            getpass_fn=getpass_fn,
        )
        if crypto is None:
            _stderr(f"Failed to verify passphrase after {MAX_PASSPHRASE_ATTEMPTS} attempts.")
            return EXIT_WRONG_PASSPHRASE

        # -- Step 4: persist derived key into keystore ------------------
        if keystore is None:
            try:
                keystore = get_keystore(insecure_plaintext=insecure_plaintext)
            except KeyStoreError as exc:
                _stderr(str(exc))
                return EXIT_KEYSTORE_ERROR
        # Pull the user's email out of the tokens or, failing that, fall
        # back to a stable opaque identifier so the keystore "account"
        # field has *something* to namespace by. We don't reach into
        # ``/me`` for the email because the user has just paired and we
        # want one fewer round-trip; the access_token's signature is the
        # canonical identity.
        account = _account_label_from_tokens(tokens)
        try:
            keystore.save(account, crypto._key)  # noqa: SLF001 — by design, this module is the key's sink
        except KeyStoreError as exc:
            _stderr(f"Could not save key to keystore: {exc}")
            return EXIT_KEYSTORE_ERROR

        _stdout(f"Key saved into {type(keystore).__name__} under account {account!r}.")
        _stdout("Setup complete.")
        # v0.3.2 — auto-wire the entry into detected MCP clients (with
        # consent), falling back to the manual-instructions snippet only
        # when no client is detected. Replaces the v0.3.1 hardcoded
        # "edit claude_desktop_config.json" hint that misled Claude Code
        # users.
        _wire_or_hint(account, input_fn=input_fn)
        return EXIT_OK
    finally:
        if owns_auth:
            await auth.aclose()


#: One-line JSON snippet rendered in the manual-instructions fallback
#: (printed only when no MCP client was auto-detected). Derived from
#: ``client_wire.WHENFUL_ENTRY`` so the auto-wired payload and the
#: manually-pasted payload can never drift.
_MANUAL_SNIPPET: Final[str] = '{"mcpServers": {"whenful": ' + json.dumps(dict(WHENFUL_ENTRY)) + "}}"


def _prompt_yes_no(question: str, *, default_yes: bool, input_fn: Callable[[str], str]) -> bool | None:
    """Ask a yes/no question.

    Returns:
      - ``True`` for "yes" (explicit or default).
      - ``False`` for "no" (explicit, or EOF / Ctrl-C interpreted as "no").
      - ``None`` when stdin is not a tty — callers treat this as
        "skip the prompt entirely, print manual instructions instead".
        Non-interactive setup runs (CI, ``setup < /dev/null``) should
        never edit a user's MCP client config without consent; auto-skip
        is the conservative default.
    """
    if not sys.stdin.isatty():
        return None
    suffix = " [Y/n] " if default_yes else " [y/N] "
    try:
        answer = input_fn(question + suffix).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    if not answer:
        return default_yes
    return answer in ("y", "yes")


def _print_wire_result(client_display: str, result_path: str, outcome: WireOutcome, detail: str) -> None:
    """Render a single wire result to stdout/stderr.

    Three buckets:
      - SUCCESS (WROTE_NEW / MERGED / ALREADY_WIRED) → stdout, calm tone.
      - SKIPPED (CONFLICT / INVALID_JSON / PERMISSION_DENIED) → stderr,
        plus a "what to do next" hint specific to the failure mode.
      - Anything else falls through to a generic line; defensive only.
    """
    if outcome is WireOutcome.WROTE_NEW:
        _stdout(f"  Wired {client_display}: created {result_path}")
    elif outcome is WireOutcome.MERGED:
        _stdout(f"  Wired {client_display}: merged into {result_path}")
    elif outcome is WireOutcome.ALREADY_WIRED:
        _stdout(f"  {client_display}: already wired at {result_path}")
    elif outcome is WireOutcome.CONFLICT:
        _stderr(f"  Skipped {client_display}: {detail}")
        _stderr(f"  → Edit {result_path} by hand if you want to overwrite.")
    elif outcome is WireOutcome.INVALID_JSON:
        _stderr(f"  Skipped {client_display}: {detail}")
        _stderr("  → Fix the JSON and re-run `whenful-mcp setup`.")
    elif outcome is WireOutcome.PERMISSION_DENIED:
        _stderr(f"  Skipped {client_display}: {detail}")
        _stderr("  → Check file permissions and re-run `whenful-mcp setup`.")
    else:
        _stdout(f"  {client_display}: {outcome.value} ({detail})")


def _print_manual_instructions() -> None:
    """Fallback: print the copy-pasteable snippet + canonical config paths.

    Used in two cases:
      - No MCP client detected on this machine (user installs one later).
      - Every detected client was skipped by the user / non-interactive.
    """
    _stdout("")
    _stdout("To wire whenful into your MCP client, add this to its config file:")
    _stdout("")
    _stdout(f"  {_MANUAL_SNIPPET}")
    _stdout("")
    _stdout("Common config-file locations:")
    _stdout("  Claude Code:    ~/.claude.json")
    if sys.platform == "darwin":
        _stdout("  Claude Desktop: ~/Library/Application Support/Claude/claude_desktop_config.json")
    elif sys.platform == "win32":
        _stdout("  Claude Desktop: %APPDATA%/Claude/claude_desktop_config.json")
    else:
        _stdout("  Claude Desktop: ~/.config/Claude/claude_desktop_config.json")
    _stdout("")
    _stdout("Restart the client after editing.")


def _wire_or_hint(account: str, *, input_fn: Callable[[str], str]) -> None:
    """Auto-wire detected MCP clients (with per-client consent), else print instructions.

    Replaces the v0.3.1 ``_print_claude_desktop_hint`` which hardcoded
    Claude Desktop — that hint was actively misleading for the Claude
    Code-only audience (the work-PC dogfood case).

    Behaviour:
      - Detect installed MCP clients via ``client_wire.detect_clients``.
      - For each one, ask the user "wire whenful into <client>?"
        (default Y, since they just ran ``whenful-mcp setup`` — clearly
        they want this to work).
      - Wire any client they say yes to, atomically and preserving the
        rest of the config.
      - When nothing is detected OR every detection was declined, fall
        back to the manual-instructions snippet.
      - Always close with the ``Paired account label`` line so users
        with multiple Whenful accounts can confirm which one this is.
    """
    _stdout("")
    _stdout("==============================================================================")
    _stdout("Next step — wire whenful into your MCP client:")
    _stdout("")

    clients = detect_clients()
    if not clients:
        _stdout("No MCP client detected on this machine.")
        _print_manual_instructions()
    else:
        wired_count = 0
        skipped_for_manual = 0
        for client in clients:
            decision = _prompt_yes_no(
                f"  Detected {client.display_name} at {client.path} — wire whenful in?",
                default_yes=True,
                input_fn=input_fn,
            )
            if decision is None:
                # Non-interactive: don't auto-edit configs without
                # explicit consent. Fall back to instructions.
                skipped_for_manual += 1
                continue
            if decision is False:
                _stdout(f"  Skipped {client.display_name} (user declined).")
                continue
            result = wire_client(client)
            _print_wire_result(client.display_name, result.detail, result.outcome, result.detail)
            if result.outcome in (WireOutcome.WROTE_NEW, WireOutcome.MERGED, WireOutcome.ALREADY_WIRED):
                wired_count += 1
        if wired_count > 0:
            _stdout("")
            _stdout(
                "Restart your MCP client to pick up the new server, then test by asking it: `list my whenful domains`."
            )
        if skipped_for_manual == len(clients):
            # Non-tty case — all clients were skipped. Print
            # manual instructions so the user has something
            # actionable.
            _print_manual_instructions()

    _stdout("")
    _stdout(f"  Paired account label: {account!r}")
    _stdout("==============================================================================")


def _account_label_from_tokens(tokens: dict[str, Any]) -> str:
    """Derive a stable account identifier from the token blob.

    Used as the "username" field in the keystore. Not a security
    boundary — anybody who can read the keystore already wins; this is
    purely for the user to recognize which Whenful account a stored
    key belongs to when they have multiple.

    Preference order:

    1. ``tokens["email"]`` if present and non-empty. Setup writes the
       user's email into the tokens blob after pairing (see
       ``_fetch_user_email``). This makes the keystore entry
       recognizable in Keychain Access / 1Password and trivially
       supports multi-account on the same machine.
    2. Legacy sha256-prefix fallback. Tokens written by older setups
       (pre-email-enrichment) won't carry an ``email`` field; we hash
       the access token as a last-resort label so SOMETHING namespaces
       the keystore entry. CAVEAT: this label is NOT stable across
       refreshes — the access token (a signed itsdangerous payload with
       ``iat``) rotates on every ``/oauth/token`` round-trip, so the
       digest rotates with it. Legacy installs lose their original
       keystore entry the first time the access token refreshes and
       must re-run ``whenful-mcp setup`` to upgrade to the email label;
       at that point the new entry lands under the stable email key.
       This self-heals via friction — the user is forced into setup
       once, then they're on the stable path. New installs hit the
       email branch above on first pair and never see this fallback.
    """
    email = tokens.get("email")
    if isinstance(email, str) and email:
        return email

    import hashlib

    raw = str(tokens.get("access_token", ""))
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"whenful-{digest[:12]}"


# ---------------------------------------------------------------------------
# CLI entrypoint
# ---------------------------------------------------------------------------


def _confirm_insecure_keystore() -> bool:
    """Interactive scary-confirm before allowing the plaintext keystore.

    Returns ``True`` when the user explicitly types ``yes`` (case-
    insensitive), ``False`` otherwise (including EOF / Ctrl-D and
    typing literally anything else).

    P1-MCP7 (v0.1.3) — defends against the forum-copy-paste vector
    where a user pastes a command that includes
    ``--insecure-key-storage`` without understanding what that means.
    The plaintext file (``~/.whenful/key.b64``) is mode 0o600 but
    that's only OS-level — any process running as the user can read
    it. The prompt makes the trade-off explicit at the moment of
    decision.

    When stdin is not a tty (CI, scripted, ``setup < /dev/null``),
    the prompt is SKIPPED with a warning printed instead — automation
    must explicitly opt-in via the flag, and the warning still names
    the risk. Without this carve-out, CI smoke tests that exercise
    the plaintext keystore would silently hang on the prompt.

    Uses ``builtins.input`` looked up at call time (not a default
    argument bound at module load) so tests can monkey-patch the
    builtin and have the redirection take effect.
    """
    import builtins

    if not sys.stdin.isatty():
        _stderr(
            "WARNING: --insecure-key-storage active in non-interactive "
            "context. The encryption key will be saved as a plaintext file "
            "at ~/.whenful/key.b64 (mode 0o600). Only continue on disposable "
            "VMs or systems where you accept the local-attacker risk."
        )
        return True

    _stderr("")
    _stderr("==============================================================================")
    _stderr("WARNING: --insecure-key-storage is active.")
    _stderr("")
    _stderr("This stores your encryption key as a plaintext file at:")
    _stderr("    ~/.whenful/key.b64   (file mode 0o600 — owner-readable)")
    _stderr("")
    _stderr("Any process running as your user can read this file. There is no")
    _stderr("OS-level secret-store protection, no master-password gate, no")
    _stderr("Touch ID / Face ID prompt on each access. Use this only on:")
    _stderr("  - disposable VMs you destroy after the session, or")
    _stderr("  - hardened laptops where you accept the local-attacker risk.")
    _stderr("")
    _stderr("If you have 1Password CLI (`op`) installed or a working OS Keychain,")
    _stderr("re-run WITHOUT --insecure-key-storage to use a secure backend.")
    _stderr("==============================================================================")
    _stderr("")
    try:
        answer = builtins.input("Type 'yes' to continue with plaintext storage: ").strip().lower()
    except (EOFError, KeyboardInterrupt, OSError):
        # OSError covers pytest's "reading from stdin while output is captured"
        # case — treat it as an abort.
        _stderr("\nAborted.")
        return False
    return answer == "yes"


def main(argv: list[str] | None = None) -> int:
    """Synchronous CLI shim for ``whenful-mcp setup``.

    Accepts an optional ``--insecure-key-storage`` flag (exact name
    spelled in the brief). All other behavior is interactive — there
    are intentionally no flags for token values or passphrases so we
    don't end up with secrets in shell history.

    When ``--insecure-key-storage`` is supplied AND stdin is a tty,
    the shim prompts for an explicit "yes" before continuing — see
    ``_confirm_insecure_keystore`` for the rationale (P1-MCP7).
    """
    args = argv if argv is not None else sys.argv[1:]
    insecure = "--insecure-key-storage" in args
    if "--help" in args or "-h" in args:
        _stdout(
            "usage: whenful-mcp setup [--insecure-key-storage]\n\n"
            "Interactive first-run setup for the Whenful stdio MCP client.\n"
            "Pass --insecure-key-storage to allow ~/.whenful/key.b64 plaintext\n"
            "as a fallback when neither 1Password CLI nor the OS keychain are\n"
            "available. Without it, the setup aborts with a clear error in\n"
            "that case.\n\n"
            "With --insecure-key-storage, you'll be prompted for explicit\n"
            "confirmation before any plaintext key file is written. CI / non-\n"
            "interactive shells skip the prompt with a warning log instead.",
        )
        return EXIT_OK
    if insecure and not _confirm_insecure_keystore():
        _stderr("Aborted: re-run without --insecure-key-storage to use 1Password CLI or the OS Keychain instead.")
        return EXIT_KEYSTORE_ERROR
    try:
        return asyncio.run(run_setup(insecure_plaintext=insecure))
    except KeyboardInterrupt:
        _stderr("\nAborted.")
        return EXIT_USER_CANCELLED


if __name__ == "__main__":
    sys.exit(main())


__all__ = [
    "EXIT_KEYSTORE_ERROR",
    "EXIT_NETWORK_ERROR",
    "EXIT_OAUTH_FAILED",
    "EXIT_OK",
    "EXIT_USER_CANCELLED",
    "EXIT_WRONG_PASSPHRASE",
    "MAX_PASSPHRASE_ATTEMPTS",
    "main",
    "run_setup",
]
