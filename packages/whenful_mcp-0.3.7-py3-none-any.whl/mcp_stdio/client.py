"""HTTP client for the local stdio MCP backend.

``WhenfulClient`` is the stdio side's implementation of the ``Backend``
protocol from ``app/mcp_shared/__init__.py``. It wraps ``httpx.AsyncClient``
to talk to ``whenful.com/api/v1/*``, attaches Bearer tokens via
``AuthManager``, and retries once on 401 after a silent refresh.

This is Phase C of MCP #13534. Phase E will wire ``WhenfulClient`` to a
FastMCP stdio bootstrap; Phase D will inject a ``CryptoManager`` so task
content is decrypted client-side. For Phase C the client accepts
``crypto: CryptoManager | None = None`` and skips encryption when ``None``.

Architectural notes
-------------------

The Phase A docstring on ``app/mcp_shared/__init__.py::Backend`` explicitly
authorized widening the protocol additively if the REST shim needed a
different shape than ``async with backend.session() as db:`` allows. Phase C
takes that authorization and adds explicit operations
(``whoami``, ``list_tasks``, ``get_task``) that return native Python dicts.
The HTTP ``_DBBackend`` implements the same operations as thin SQL
wrappers; both backends now satisfy the widened protocol.

``WhenfulClient.session()`` still returns an async context manager for
protocol satisfaction, but yields the ``WhenfulClient`` itself rather than
an ``AsyncSession``. Tool code that depends on raw SQL will fail loudly
when invoked through stdio — which is correct, because those tools need
migration to the operations API in a future phase. Phase E's stdio smoke
test only calls the new operations, so the symbolic ``session()`` is
sufficient for end-to-end coverage today.

``fire_and_forget()`` is a true no-op: the cloud server already schedules
GCal sync when REST writes land, so the stdio client has nothing to do.

Privacy & telemetry posture
---------------------------

Zero telemetry. No Sentry, no OTel, no ``print()`` of secrets. Tokens are
fetched from ``AuthManager`` per request; ``__repr__`` redacts the auth
manager and crypto manager. The client never logs request bodies or
response payloads.

This module must NOT import from ``app.*`` at module load time. The
``mcp_stdio`` subpackage is built as a separately publishable wheel in
Phase F, and the ``app/`` codebase is not part of that wheel.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Coroutine
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, Final

import httpx

from .auth import AuthExpiredError, AuthManager, AuthNetworkError, _resolve_api_base
from .crypto import CryptoError

if TYPE_CHECKING:
    from .crypto import CryptoManager


#: Default ``httpx`` connection timeout (seconds). Generous because the
#: stdio client typically runs on the user's laptop with variable network
#: conditions, and a slow refresh shouldn't immediately error out.
DEFAULT_TIMEOUT_SECONDS: Final[float] = 30.0


class WhenfulClientError(Exception):
    """Base class for ``WhenfulClient`` errors."""


class WhenfulNetworkError(WhenfulClientError):
    """Raised when an HTTP request to the Whenful API fails at the
    transport layer (DNS, TCP, TLS, etc.). Wraps ``httpx.HTTPError`` to
    give callers a stable exception class without depending on httpx
    internals."""


class WhenfulServerError(WhenfulClientError):
    """Raised when the Whenful API returns a 5xx response or an
    otherwise-unexpected status code that callers must surface to the
    user instead of silently swallowing."""


class WhenfulAuthError(WhenfulClientError):
    """Raised when ``AuthManager`` cannot produce a valid access token
    after refresh. Mirrors ``AuthExpiredError`` at the client layer so
    Phase D's setup flow can catch a single exception type."""


def _sanitize_response_text(text: str, *, limit: int = 200) -> str:
    """Strip user-content echoes (``input`` field on FastAPI 422 bodies)
    from a response body before it lands in a ``WhenfulServerError``.

    The cloud server already strips the field via the
    ``RequestValidationError`` handler in ``app/main.py`` (P1-MCP4,
    v0.1.3). This is the defense-in-depth layer for the stdio path:
    older server builds, PR-preview environments, or any non-Whenful
    server that proxies the API could still emit a FastAPI default
    body. We never want the user's rejected task title to appear in
    a ToolError string that the LLM consumes.

    The function parses the body as JSON, recursively drops any
    ``input`` keys (the canonical Pydantic v2 422 leak surface), and
    re-serializes. On JSON parse failure (HTML error page, plain
    text), the input string is truncated as-is — those bodies don't
    typically carry user content, but the ``limit`` cap bounds blast
    radius. Returns a string at most ``limit`` chars long.
    """
    import json

    truncated = text[:limit] if isinstance(text, str) else ""
    try:
        parsed = json.loads(text)
    except (ValueError, TypeError):
        return truncated

    def _strip_input(obj: object) -> object:
        if isinstance(obj, dict):
            return {k: _strip_input(v) for k, v in obj.items() if k != "input"}
        if isinstance(obj, list):
            return [_strip_input(v) for v in obj]
        return obj

    sanitized = _strip_input(parsed)
    try:
        rendered = json.dumps(sanitized, default=str)
    except (TypeError, ValueError):
        return truncated
    return rendered[:limit]


class WhenfulClient:
    """REST-backed ``Backend`` for the local stdio MCP client.

    Construct with an ``AuthManager`` (which handles tokens + refresh). The
    optional ``crypto`` parameter will be wired by Phase D; for Phase C it
    is accepted but unused — tests pass ``None``.

    ``base_url`` defaults to ``WHENFUL_API_BASE`` env var, then
    ``https://whenful.com/api/v1``. Pass ``base_url`` explicitly in tests
    to route at an ASGI transport.

    ``http_client`` may be injected for tests; otherwise the client owns
    its own ``httpx.AsyncClient`` and closes it via ``aclose()``.
    """

    __slots__ = (
        "_auth",
        "_crypto",
        "_base_url",
        "_http_client",
        "_owns_client",
        "_domain_cache",
    )

    def __init__(
        self,
        auth: AuthManager,
        *,
        crypto: CryptoManager | None = None,
        base_url: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._auth: AuthManager = auth
        self._crypto: CryptoManager | None = crypto
        self._base_url: str = (base_url or _resolve_api_base()).rstrip("/")
        self._http_client: httpx.AsyncClient | None = http_client
        self._owns_client: bool = http_client is None
        # Memoized {name.lower(): domain_id} populated lazily on first
        # _resolve_domain_name_to_id() call. The cache invalidates only on
        # explicit reset() — domain create/update/archive should reset it.
        # For Phase tasks-ops scope, only reads use it, so memoization is
        # safe; subsequent agents wiring create/update/archive_domain
        # should call reset_domain_cache() in their post-write path.
        self._domain_cache: dict[str, int] | None = None

    # ------------------------------------------------------------------
    # Backend protocol — low-level hooks
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def session(self) -> AsyncIterator[WhenfulClient]:
        """Yield self as the "session" for protocol compatibility.

        Tool code that still depends on raw SQL will fail loudly when
        invoked through the stdio path — those tools need to migrate to
        the operations API. Phase E's smoke test calls only the
        operations, so this is sufficient.
        """
        yield self

    def fire_and_forget(self, coro: Coroutine[Any, Any, None]) -> None:
        """No-op: the cloud server triggers GCal sync from REST routes."""
        # Close the coroutine to avoid "coroutine was never awaited"
        # warnings if tool code passes one in.
        coro.close()

    def supports_client_side_crypto(self) -> bool:
        # True when a CryptoManager is loaded — encryption-on users with
        # their passphrase on this machine CAN read and write every encrypted
        # field. WhenfulClient encrypts on POST (_encrypt_field_in_place)
        # and decrypts on the way back (_decrypt_field_in_place). The shared
        # encryption gate must skip its lockout for this path.
        return self._crypto is not None

    def is_local(self) -> bool:
        # WhenfulClient lives in the standalone whenful-mcp wheel, which ships
        # only `app/mcp_shared` and `mcp_stdio`. `app.services`, `app.routers`,
        # `app.models` are not on the Python path. Tools that need server-side
        # imports must guard with this flag and short-circuit before they hit
        # the import line.
        return True

    # ------------------------------------------------------------------
    # Backend protocol — high-level operations
    # ------------------------------------------------------------------

    async def whoami(self, user_id: int) -> dict[str, Any]:  # noqa: ARG002
        """``GET /me`` and return identity metadata.

        The ``user_id`` parameter is ignored — the Bearer token carries
        identity over the wire. The argument exists to keep the call shape
        symmetric with ``_DBBackend.whoami`` so tool code stays
        transport-agnostic.
        """
        payload = await self._get("/me")
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/me returned non-dict payload: {type(payload).__name__}")
        return payload

    async def list_tasks(
        self,
        user_id: int,  # noqa: ARG002
        *,
        domain_id: int | None = None,
        status: str = "pending",
        scheduled_date: str | None = None,
        is_recurring: bool | None = None,
        clarity: str | None = None,
        parent_id: int | None = None,
        source: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
        # Added 2026-05-16 — see Backend protocol docstring for rationale.
        top_level_only: bool = True,  # noqa: ARG002 — derived server-side from parent_id
        has_domain: bool | None = None,
        exclude_statuses: list[str] | None = None,
        impact: int | None = None,
    ) -> list[dict[str, Any]]:
        """``GET /tasks`` with optional filters; returns a list of task dicts.

        REST exposes ``parent_id``, ``status``, ``domain_id``,
        ``scheduled_date``, ``is_recurring``, ``clarity``, ``source``,
        ``limit``, ``offset`` directly. The MCP-only filters
        (``top_level_only``, ``has_domain``, ``exclude_statuses``,
        ``impact``) are applied client-side after the REST call:

        - ``top_level_only`` is derived server-side from ``parent_id`` (REST
          enforces ``top_level_only = parent_id is None``), so we don't
          send it. The arg is accepted for protocol symmetry only.
        - ``has_domain``: dict-key filter on ``domain_id``.
        - ``exclude_statuses``: dict-key filter on ``status``.
        - ``impact``: dict-key filter on ``impact``.
        """
        params: dict[str, Any] = {"status": status}
        if domain_id is not None:
            params["domain_id"] = domain_id
        if scheduled_date is not None:
            params["scheduled_date"] = scheduled_date
        if is_recurring is not None:
            # httpx serializes Python booleans as "True"/"False"; FastAPI
            # accepts those for bool query params via Pydantic coercion.
            # Lower-case "true"/"false" works equally; we pass as-is.
            params["is_recurring"] = is_recurring
        if clarity is not None:
            params["clarity"] = clarity
        if parent_id is not None:
            params["parent_id"] = parent_id
        if source is not None:
            params["source"] = source
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        payload = await self._get("/tasks", params=params)
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/tasks returned non-list payload: {type(payload).__name__}")
        if self._crypto is not None:
            for task in payload:
                if isinstance(task, dict):
                    self._decrypt_task_in_place(task)

        # Client-side MCP filters — applied after decryption so they see the
        # same data the cloud HTTP backend's TaskService.get_tasks() would
        # return.
        if has_domain is True:
            payload = [t for t in payload if isinstance(t, dict) and t.get("domain_id") is not None]
        elif has_domain is False:
            payload = [t for t in payload if isinstance(t, dict) and t.get("domain_id") is None]
        if exclude_statuses:
            excl = set(exclude_statuses)
            payload = [t for t in payload if isinstance(t, dict) and t.get("status") not in excl]
        if impact is not None:
            payload = [t for t in payload if isinstance(t, dict) and t.get("impact") == impact]

        return payload

    async def get_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """``GET /tasks/{task_id}``; returns ``None`` on 404."""
        payload = await self._get(f"/tasks/{task_id}", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/tasks/{task_id} returned non-dict payload: {type(payload).__name__}")
        if self._crypto is not None:
            self._decrypt_task_in_place(payload)
        return payload

    # ------------------------------------------------------------------
    # Recurring instance operations (MCP-stdio full-parity, #13534)
    # ------------------------------------------------------------------
    #
    # Each maps to a single REST endpoint under ``/instances/...``. The
    # ``user_id`` argument is accepted (Protocol symmetry) but ignored —
    # the Bearer token carries identity. Instance fields have no
    # at-rest-encrypted columns, so we never call ``_decrypt_*`` here.

    async def complete_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """``POST /instances/{instance_id}/complete``; ``None`` on 404."""
        payload = await self._post(f"/instances/{instance_id}/complete", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/complete returned non-dict payload: {type(payload).__name__}"
            )
        return payload

    async def skip_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """``POST /instances/{instance_id}/skip``; ``None`` on 404."""
        payload = await self._post(f"/instances/{instance_id}/skip", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/skip returned non-dict payload: {type(payload).__name__}"
            )
        return payload

    async def unskip_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """``POST /instances/{instance_id}/unskip``; ``None`` on 404."""
        payload = await self._post(f"/instances/{instance_id}/unskip", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/unskip returned non-dict payload: {type(payload).__name__}"
            )
        return payload

    async def uncomplete_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """``POST /instances/{instance_id}/uncomplete``; ``None`` on 404."""
        payload = await self._post(f"/instances/{instance_id}/uncomplete", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/uncomplete returned non-dict payload: {type(payload).__name__}"
            )
        return payload

    async def get_instance_wall_clock(
        self,
        user_id: int,  # noqa: ARG002
        instance_id: int,
    ) -> tuple[str, str] | None:
        """``GET /instances/{instance_id}/wall-clock`` — returns the
        instance's local wall-clock time + IANA timezone, or ``None``
        on 404.

        P1-MCP9 (v0.1.3) closed the v1 stdio degradation that returned
        ``None`` unconditionally and lost the time-of-day on every
        date-only reschedule. The new REST endpoint at
        ``app/routers/instances.py::get_instance_wall_clock`` mirrors
        the cloud HTTP backend's ``_DBBackend.get_instance_wall_clock``
        implementation byte-for-byte so the protocol contract holds.
        """
        payload = await self._get(f"/instances/{instance_id}/wall-clock", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/wall-clock returned non-dict payload: {type(payload).__name__}"
            )
        local_time_iso = payload.get("local_time_iso")
        timezone_name = payload.get("timezone")
        if not isinstance(local_time_iso, str) or not isinstance(timezone_name, str):
            raise WhenfulServerError(
                f"/instances/{instance_id}/wall-clock missing local_time_iso or timezone: {payload!r}"
            )
        return local_time_iso, timezone_name

    async def reschedule_instance(
        self,
        user_id: int,  # noqa: ARG002
        instance_id: int,
        *,
        new_datetime: Any,
    ) -> dict[str, Any] | None:
        """``PUT /instances/{instance_id}/schedule``; ``None`` on 404.

        ``new_datetime`` is a Python ``datetime`` — serialized via
        ``.isoformat()`` for the JSON body. Tool callers do the date-only
        vs full-datetime parsing before this method is invoked.
        """
        body = {"scheduled_datetime": new_datetime.isoformat() if new_datetime is not None else None}
        payload = await self._put(f"/instances/{instance_id}/schedule", json_body=body, allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"/instances/{instance_id}/schedule returned non-dict payload: {type(payload).__name__}"
            )
        return payload

    async def batch_complete_instances(
        self,
        user_id: int,  # noqa: ARG002
        *,
        task_id: int,
        before_date: Any,
    ) -> dict[str, Any]:
        """``POST /instances/batch-complete`` — returns ``{"completed_count": int}``.

        ``before_date`` is a Python ``date`` — serialized via ``.isoformat()``.
        """
        body = {
            "task_id": task_id,
            "before_date": before_date.isoformat() if hasattr(before_date, "isoformat") else before_date,
        }
        payload = await self._post("/instances/batch-complete", json_body=body)
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/instances/batch-complete returned non-dict payload: {type(payload).__name__}")
        return payload

    async def batch_past_instances(self, user_id: int, *, action: str) -> dict[str, Any]:  # noqa: ARG002
        """``POST /instances/batch-past`` — returns ``{"affected_count": int}``."""
        payload = await self._post("/instances/batch-past", json_body={"action": action})
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/instances/batch-past returned non-dict payload: {type(payload).__name__}")
        return payload

    async def pending_past_count(self, user_id: int) -> int:  # noqa: ARG002
        """``GET /instances/pending-past-count`` — returns the integer count.

        The REST endpoint wraps it in ``{"pending_count": int}``; we
        unwrap so the operation contract returns a plain ``int``
        symmetrically with ``_DBBackend.pending_past_count``.
        """
        payload = await self._get("/instances/pending-past-count")
        if not isinstance(payload, dict) or "pending_count" not in payload:
            raise WhenfulServerError(f"/instances/pending-past-count returned unexpected payload: {payload!r}")
        count = payload["pending_count"]
        if not isinstance(count, int):
            raise WhenfulServerError(f"/instances/pending-past-count returned non-int count: {count!r}")
        return count

    async def list_past_instances(
        self,
        user_id: int,  # noqa: ARG002
        *,
        limit: int,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """``GET /instances/past?limit=N`` — returns the aggregated list.

        Each row mirrors REST ``PastInstanceAggregate``: ``task_id``,
        ``pending_count``, ``first_date``, ``last_date``, ``title``,
        ``is_recurring``, ``parent_status``, ``domain_name``.

        ``offset`` is applied client-side after the REST round-trip — the
        REST endpoint exposes ``limit`` but not ``offset``, so we
        over-fetch ``limit + offset`` rows and slice locally. Aggregates
        in this endpoint are bounded (one row per recurring parent with
        a backlog), so the over-fetch ceiling stays modest in practice.

        Encrypted-task users: the parent ``title`` and ``domain_name``
        fields here will be ciphertext (the REST endpoint doesn't go
        through the stdio decrypt path). The cloud-side tool currently
        gates this tool behind ``check_encryption`` for encryption-on
        users, so the encryption miss isn't user-visible until that
        gate is removed in a future phase.
        """
        # Over-fetch enough to honor the requested offset client-side.
        fetch_limit = limit + offset if limit and limit > 0 else limit
        payload = await self._get("/instances/past", params={"limit": fetch_limit})
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/instances/past returned non-list payload: {type(payload).__name__}")
        if offset:
            return payload[offset:]
        return payload

    # ------------------------------------------------------------------
    # Domain operations (encrypt-on-write for ``name``)
    # ------------------------------------------------------------------

    async def list_domains(self, user_id: int) -> list[dict[str, Any]]:  # noqa: ARG002
        """``GET /domains?include_archived=true``; returns a list of dicts.

        Decrypts ``name`` in each dict in place when ``CryptoManager``
        is loaded. Mirrors the cloud HTTP backend's
        ``_DBBackend.list_domains``.
        """
        payload = await self._get("/domains", params={"include_archived": True})
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/domains returned non-list payload: {type(payload).__name__}")
        if self._crypto is not None:
            for domain in payload:
                if isinstance(domain, dict):
                    self._decrypt_domain_in_place(domain)
        return payload

    async def create_domain(
        self,
        user_id: int,  # noqa: ARG002
        *,
        name: str,
        color: str | None = None,
        icon: str | None = None,
    ) -> dict[str, Any]:
        """``POST /domains``; encrypts ``name`` first when crypto is loaded.

        This is the primary regression surface for the "stdio leaks
        plaintext to server" failure mode — the body sent over the wire
        MUST be ciphertext when ``CryptoManager`` is present. The
        response is decrypted in place on the way back so callers see
        plaintext regardless.
        """
        body: dict[str, Any] = {"name": name}
        if color is not None:
            body["color"] = color
        if icon is not None:
            body["icon"] = icon

        if self._crypto is not None:
            self._encrypt_field_in_place(body, "name")

        payload = await self._post("/domains", json_body=body)
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/domains returned non-dict payload: {type(payload).__name__}")
        if self._crypto is not None:
            self._decrypt_domain_in_place(payload)
        return payload

    async def update_domain(
        self,
        user_id: int,  # noqa: ARG002
        domain_id: int,
        *,
        name: str | None = None,
        color: str | None = None,
        icon: str | None = None,
        position: int | None = None,
    ) -> dict[str, Any] | None:
        """``PUT /domains/{id}``; encrypts ``name`` first when crypto is loaded.

        Returns ``None`` on 404. Only includes fields that are
        explicitly non-``None`` so the server's ``model_fields_set``
        check treats them as updates (and unspecified fields as
        "not provided" rather than "clear to null").
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if color is not None:
            body["color"] = color
        if icon is not None:
            body["icon"] = icon
        if position is not None:
            body["position"] = position

        if not body:
            # Nothing to update — match _DBBackend's "no-op returns the
            # current state" by re-fetching. Simpler to surface as None
            # so tool code can early-return with a helpful string.
            return None

        if self._crypto is not None and "name" in body:
            self._encrypt_field_in_place(body, "name")

        payload = await self._put(f"/domains/{domain_id}", json_body=body, allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/domains/{domain_id} returned non-dict payload: {type(payload).__name__}")
        if self._crypto is not None:
            self._decrypt_domain_in_place(payload)
        return payload

    async def archive_domain(self, user_id: int, domain_id: int) -> dict[str, Any] | None:
        """``DELETE /domains/{id}`` (server returns 204) then synthesize
        the archived dict from a pre-delete ``GET``.

        The REST endpoint archives via 204 with no body, so we fetch
        first to snapshot the domain, then issue the DELETE. Returns
        ``None`` if the domain doesn't exist (either the GET 404s or
        the DELETE 404s — both signal the same outcome to the caller).
        """
        # Snapshot first so we can return the archived dict shape.
        snapshot = await self._get(f"/domains/{domain_id}", allow_404=True)
        if snapshot is None:
            return None
        if not isinstance(snapshot, dict):
            raise WhenfulServerError(f"/domains/{domain_id} returned non-dict payload: {type(snapshot).__name__}")

        deleted = await self._delete(f"/domains/{domain_id}", allow_404=True)
        if deleted is False:
            # 404 between GET and DELETE — race with concurrent archive.
            # Treat as not-found, since the post-condition (archived)
            # holds either way.
            return None

        # Flip is_archived to True for the caller's view of the world.
        snapshot["is_archived"] = True
        if self._crypto is not None:
            self._decrypt_domain_in_place(snapshot)
        # Forward-compat: leave user_id arg untouched (Bearer carries identity).
        del user_id
        return snapshot

    # ------------------------------------------------------------------
    # Schedule operations (MCP-stdio full parity, 2026-05-13)
    # ------------------------------------------------------------------

    async def get_schedule(
        self,
        user_id: int,  # noqa: ARG002
        *,
        date_from: str,
        date_to: str,
    ) -> dict[str, Any]:
        """Combine ``GET /tasks`` and ``GET /instances`` for a date range.

        The schedule operation contract returns ``{"tasks": [...],
        "instances": [...]}``. Over REST these live on two separate
        endpoints, so the stdio implementation issues two GETs and
        merges. Both decrypt task-shape fields when ``crypto`` is loaded.

        Tasks: the REST list endpoint doesn't accept a date *range*
        (only an exact ``scheduled_date``). We issue one GET per day in
        the range. For the common single-day case this is a single
        round-trip; the range case (multi-day) trades extra GETs for
        correctness without changing the wire contract.

        Domain-less thoughts are filtered client-side to match the
        cloud HTTP MCP behaviour (the REST endpoint returns them).
        """
        from datetime import date as _date
        from datetime import timedelta as _timedelta

        # Defensive parse — matches the _DBBackend contract.
        start = _date.fromisoformat(date_from)
        end = _date.fromisoformat(date_to)
        if end < start:
            return {"tasks": [], "instances": []}

        # Walk the range one day at a time. Capped at 100 to mirror the
        # SQL path's ``.limit(100)`` and prevent runaway ranges.
        tasks_out: list[dict[str, Any]] = []
        cursor = start
        while cursor <= end and len(tasks_out) < 100:
            day_payload = await self._get(
                "/tasks",
                params={"status": "pending", "scheduled_date": cursor.isoformat()},
            )
            if not isinstance(day_payload, list):
                raise WhenfulServerError(f"/tasks returned non-list payload: {type(day_payload).__name__}")
            for task in day_payload:
                if not isinstance(task, dict):
                    continue
                # Match HTTP path: exclude thoughts, exclude recurring.
                if task.get("domain_id") is None:
                    continue
                if task.get("is_recurring"):
                    continue
                if self._crypto is not None:
                    self._decrypt_task_in_place(task)
                tasks_out.append(task)
                if len(tasks_out) >= 100:
                    break
            cursor += _timedelta(days=1)

        # Instances accept a date range natively.
        instance_payload = await self._get(
            "/instances",
            params={
                "start_date": date_from,
                "end_date": date_to,
                "status": "pending",
            },
        )
        if not isinstance(instance_payload, list):
            raise WhenfulServerError(f"/instances returned non-list payload: {type(instance_payload).__name__}")
        instances_out: list[dict[str, Any]] = []
        for inst in instance_payload[:100]:
            if not isinstance(inst, dict):
                continue
            if self._crypto is not None:
                # InstanceResponse has task_title + domain_name — both
                # at-rest-encrypted columns when the parent task /
                # domain were created by an encryption-on user.
                self._decrypt_field_in_place(inst, "task_title")
                self._decrypt_field_in_place(inst, "domain_name")
            instances_out.append(inst)

        return {"tasks": tasks_out, "instances": instances_out}

    async def get_overdue(self, user_id: int) -> dict[str, Any]:  # noqa: ARG002
        """Return overdue tasks + past pending instance count.

        REST has no native "overdue" filter, so the stdio path mirrors
        the SQL service path: pull all pending tasks (capped at 200),
        filter client-side to those with ``scheduled_date < today``,
        and fetch the past-instance count via the dedicated REST
        endpoint. ``today`` is derived from the user's preferences
        (``GET /preferences`` + timezone), with UTC as fallback so a
        user without a timezone preference still gets a sensible cutoff.
        """
        from datetime import UTC as _UTC
        from datetime import datetime as _datetime
        from zoneinfo import ZoneInfo

        prefs_payload = await self._get("/preferences")
        if not isinstance(prefs_payload, dict):
            raise WhenfulServerError(f"/preferences returned non-dict payload: {type(prefs_payload).__name__}")
        tz_name = prefs_payload.get("timezone")
        tz: Any
        if tz_name:
            try:
                tz = ZoneInfo(tz_name)
            except Exception:
                tz = _UTC
        else:
            tz = _UTC
        today = _datetime.now(tz).date()
        today_iso = today.isoformat()

        # Pull pending tasks (cap matches the SQL path).
        task_payload = await self._get("/tasks", params={"status": "pending", "limit": 200})
        if not isinstance(task_payload, list):
            raise WhenfulServerError(f"/tasks returned non-list payload: {type(task_payload).__name__}")

        overdue: list[dict[str, Any]] = []
        for task in task_payload:
            if not isinstance(task, dict):
                continue
            # Mirror SQL filter: has_domain=True (excludes thoughts).
            if task.get("domain_id") is None:
                continue
            sched = task.get("scheduled_date")
            if not isinstance(sched, str):
                continue
            try:
                sched_date = _datetime.fromisoformat(sched).date()
            except ValueError:
                continue
            if sched_date >= today:
                continue
            if self._crypto is not None:
                self._decrypt_task_in_place(task)
            overdue.append(task)
        overdue.sort(key=lambda t: t.get("scheduled_date") or today_iso)

        count_payload = await self._get("/instances/pending-past-count")
        if not isinstance(count_payload, dict):
            raise WhenfulServerError(
                f"/instances/pending-past-count returned non-dict payload: {type(count_payload).__name__}"
            )
        past_count = count_payload.get("pending_count")
        if not isinstance(past_count, int):
            past_count = 0

        return {
            "today": today_iso,
            "tasks": overdue,
            "past_instance_count": past_count,
        }

    async def get_analytics(self, user_id: int, *, days: int) -> dict[str, Any]:  # noqa: ARG002
        """``GET /analytics?days=N`` — comprehensive analytics payload."""
        payload = await self._get("/analytics", params={"days": days})
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"/analytics returned non-dict payload: {type(payload).__name__}")
        return payload

    async def get_recent_completions(
        self,
        user_id: int,  # noqa: ARG002
        *,
        limit: int,
    ) -> list[dict[str, Any]]:
        """``GET /analytics/recent-completions?limit=N`` — recent completed tasks/instances."""
        payload = await self._get("/analytics/recent-completions", params={"limit": limit})
        if not isinstance(payload, list):
            raise WhenfulServerError(
                f"/analytics/recent-completions returned non-list payload: {type(payload).__name__}"
            )
        if self._crypto is not None:
            for entry in payload:
                if isinstance(entry, dict):
                    # ``title`` and ``domain_name`` are at-rest-encrypted
                    # for encryption-on users; the server emits ciphertext
                    # and the client decrypts in place.
                    self._decrypt_field_in_place(entry, "title")
                    self._decrypt_field_in_place(entry, "domain_name")
        return payload

    # ------------------------------------------------------------------
    # User preferences operations (MCP-stdio full parity, 2026-05-13)
    # ------------------------------------------------------------------

    async def get_preferences(self, user_id: int) -> dict[str, Any]:  # noqa: ARG002
        """Combine ``GET /preferences`` with ``GET /preferences/encryption``.

        The REST ``PreferencesResponse`` does not include
        ``encryption_enabled``; the encryption flag lives on a separate
        endpoint. The Backend contract guarantees that field, so the
        stdio path performs a second GET and merges the result. Returns
        the merged dict.
        """
        prefs_payload = await self._get("/preferences")
        if not isinstance(prefs_payload, dict):
            raise WhenfulServerError(f"/preferences returned non-dict payload: {type(prefs_payload).__name__}")
        enc_payload = await self._get("/preferences/encryption")
        if not isinstance(enc_payload, dict):
            raise WhenfulServerError(f"/preferences/encryption returned non-dict payload: {type(enc_payload).__name__}")
        prefs_payload["encryption_enabled"] = bool(enc_payload.get("enabled"))
        return prefs_payload

    # ------------------------------------------------------------------
    # Backend protocol — task operations (extended, MCP-stdio full-parity)
    # ------------------------------------------------------------------
    #
    # REST endpoint coverage notes (see
    # docs/plans/2026-05-13-22-00-mcp-stdio-full-parity.md):
    #   - list_thoughts / get_archived_tasks: filter client-side because
    #     REST has no has_domain query parameter.
    #   - list_recurring_tasks: returns parents only; per-parent pending
    #     instance aggregates are omitted because REST has no
    #     "aggregate by task" endpoint. The tool layer formats without
    #     them on stdio; the HTTP path still includes them.
    #   - search_tasks: ILIKE client-side. Acceptable for the typical
    #     low-thousands task count on a personal account.
    #   - nuke_task: DELETE /tasks/{id}/permanent (added during the
    #     full-parity migration; distinct path from the archive
    #     endpoint so accidental hits aren't catastrophic).
    #   - batch_create_tasks / batch_update_tasks: iterate client-side
    #     because REST has no batch-create endpoint and batch-update is
    #     content-only (encryption flow). batch_complete_tasks uses the
    #     existing batch-action endpoint.

    async def list_thoughts(
        self,
        user_id: int,  # noqa: ARG002
        *,
        status: str = "pending",
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Fetch tasks and filter to domain-less, top-level rows client-side.

        Status semantics mirror the HTTP path: ``"all"`` excludes archived,
        anything else filters to that status. Decrypts encrypted fields in
        place when crypto is loaded.
        """
        # REST has no has_domain filter, so fetch all candidates and filter.
        # We over-fetch within the requested limit because some of the
        # returned rows will have domains and get filtered out; the
        # over-fetch factor is a heuristic.
        params: dict[str, Any] = {"status": status if status != "all" else "all"}
        # Bias fetch size upward to compensate for client-side filtering.
        # Realistic accounts have far more domained tasks than thoughts,
        # so an over-fetch factor of 4 is enough for typical inboxes.
        params["limit"] = max(limit * 4, 200)
        payload = await self._get("/tasks", params=params)
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/tasks returned non-list payload: {type(payload).__name__}")

        thoughts: list[dict[str, Any]] = []
        for row in payload:
            if not isinstance(row, dict):
                continue
            if row.get("domain_id") is not None:
                continue
            if row.get("parent_id") is not None:
                continue
            if status == "all" and row.get("status") == "archived":
                continue
            thoughts.append(row)
        thoughts = thoughts[offset : offset + limit] if offset else thoughts[:limit]
        if self._crypto is not None:
            for t in thoughts:
                self._decrypt_task_in_place(t)
        return thoughts

    async def list_recurring_tasks(
        self,
        user_id: int,  # noqa: ARG002
        *,
        status: str = "pending",
    ) -> list[dict[str, Any]]:
        """Fetch recurring parents. Pending-instance aggregates are omitted
        because REST has no aggregate endpoint — the tool layer formats
        without them on stdio."""
        params: dict[str, Any] = {"is_recurring": True}
        if status != "all":
            params["status"] = status
        payload = await self._get("/tasks", params=params)
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/tasks returned non-list payload: {type(payload).__name__}")
        parents: list[dict[str, Any]] = []
        for row in payload:
            if not isinstance(row, dict):
                continue
            if row.get("parent_id") is not None:
                continue
            if status != "all" and row.get("status") != status:
                continue
            # Aggregate placeholders so the tool-layer formatter has
            # consistent keys regardless of transport.
            row.setdefault("pending_count", 0)
            row.setdefault("first_pending_date", None)
            row.setdefault("last_pending_date", None)
            parents.append(row)
        if self._crypto is not None:
            for p in parents:
                self._decrypt_task_in_place(p)
        return parents

    async def create_task(
        self,
        user_id: int,  # noqa: ARG002
        *,
        title: str,
        domain_id: int | None = None,
        impact: int = 4,
        clarity: str = "normal",
        duration_minutes: int | None = None,
        scheduled_date: str | None = None,
        scheduled_time: str | None = None,
        description: str | None = None,
        parent_id: int | None = None,
        is_recurring: bool = False,
        recurrence_rule: dict[str, Any] | None = None,
        recurrence_start: str | None = None,
        recurrence_end: str | None = None,
        reminder_minutes_before: int | None = None,
    ) -> dict[str, Any]:
        """POST /tasks with encrypt-on-write for title and description."""
        body: dict[str, Any] = {
            "title": title,
            "domain_id": domain_id,
            "parent_id": parent_id,
            "impact": impact,
            "clarity": clarity,
            "duration_minutes": duration_minutes,
            "scheduled_date": scheduled_date,
            "scheduled_time": scheduled_time,
            "description": description,
            "is_recurring": is_recurring,
            "recurrence_rule": recurrence_rule,
            "recurrence_start": recurrence_start,
            "recurrence_end": recurrence_end,
            "reminder_minutes_before": reminder_minutes_before,
        }
        # Drop keys whose values are None so the server's Pydantic defaults
        # kick in. Critical for fields like ``is_habit`` etc. that the
        # contract doesn't expose.
        body = {k: v for k, v in body.items() if v is not None}
        self._encrypt_task_body_in_place(body)
        payload = await self._post("/tasks", json_body=body)
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"POST /tasks returned non-dict payload: {type(payload).__name__}")
        if self._crypto is not None:
            self._decrypt_task_in_place(payload)
        return payload

    async def update_task(
        self,
        user_id: int,  # noqa: ARG002
        task_id: int,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """PUT /tasks/{id} with encrypt-on-write. Returns None on 404."""
        body = {k: v for k, v in fields.items() if v is not None}
        # Encrypt title/description if crypto is loaded. domain_name is
        # not part of the update wire (REST uses domain_id), but if a
        # caller passes it we encrypt for defense in depth.
        self._encrypt_task_body_in_place(body)
        payload = await self._put(f"/tasks/{task_id}", json_body=body, allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(f"PUT /tasks/{task_id} returned non-dict payload: {type(payload).__name__}")
        if self._crypto is not None:
            self._decrypt_task_in_place(payload)
        return payload

    async def complete_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """POST /tasks/{id}/complete. The REST endpoint returns a thin
        ``{status, task_id}`` envelope; we re-fetch the full task to
        match the operations API contract.
        """
        envelope = await self._post(f"/tasks/{task_id}/complete", allow_404=True)
        if envelope is None:
            return None
        return await self.get_task(user_id=user_id, task_id=task_id)

    async def uncomplete_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """POST /tasks/{id}/uncomplete. Re-fetches the full task."""
        envelope = await self._post(f"/tasks/{task_id}/uncomplete", allow_404=True)
        if envelope is None:
            return None
        return await self.get_task(user_id=user_id, task_id=task_id)

    async def toggle_complete(
        self,
        user_id: int,  # noqa: ARG002
        task_id: int,
        *,
        target_date: str | None = None,
    ) -> dict[str, Any] | None:
        """POST /tasks/{id}/toggle-complete. Returns the structured dict
        the operations contract specifies."""
        body: dict[str, Any] = {}
        if target_date is not None:
            body["target_date"] = target_date
        envelope = await self._post(f"/tasks/{task_id}/toggle-complete", json_body=body or None, allow_404=True)
        if envelope is None:
            return None
        if not isinstance(envelope, dict):
            raise WhenfulServerError(f"toggle-complete returned non-dict payload: {type(envelope).__name__}")
        return {
            "task_id": envelope.get("task_id", task_id),
            "completed": bool(envelope.get("completed", False)),
            "instance_id": envelope.get("instance_id"),
            "target_date": target_date,
            "cascaded_subtask_ids": list(envelope.get("cascaded_subtask_ids") or []),
        }

    async def nuke_task(self, user_id: int, task_id: int) -> bool:  # noqa: ARG002
        """Hard-delete a task. Maps to ``DELETE /tasks/{id}/permanent``.

        Returns ``True`` on success, ``False`` if the task is missing or
        not owned by the user. The REST endpoint was introduced as part
        of MCP-stdio full-parity so both transports expose the same
        capability surface (the cloud HTTP MCP has had ``nuke_task``
        natively all along).
        """
        return await self._delete(f"/tasks/{task_id}/permanent", allow_404=True)

    async def archive_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Soft-delete a task. REST's DELETE returns 204 with no body, so
        we re-fetch the (now archived) task to satisfy the operations
        contract.
        """
        # Pre-fetch to detect missing-task → return None.
        before = await self.get_task(user_id=user_id, task_id=task_id)
        if before is None:
            return None
        deleted = await self._delete(f"/tasks/{task_id}", allow_404=True)
        if deleted is False:
            return None
        # The row is now archived; re-fetch to surface the updated status.
        return await self.get_task(user_id=user_id, task_id=task_id)

    async def restore_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:  # noqa: ARG002
        """POST /tasks/{id}/restore. Returns the restored task dict or
        None on 404."""
        payload = await self._post(f"/tasks/{task_id}/restore", allow_404=True)
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise WhenfulServerError(
                f"POST /tasks/{task_id}/restore returned non-dict payload: {type(payload).__name__}"
            )
        if self._crypto is not None:
            self._decrypt_task_in_place(payload)
        return payload

    async def get_archived_tasks(
        self,
        user_id: int,  # noqa: ARG002
        *,
        domain_id: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /tasks?status=archived, with client-side has_domain filter.

        REST has no has_domain query parameter, so we filter the response
        client-side to mirror the HTTP-tool semantics (exclude domain-less
        archived tasks unless ``domain_id`` is explicitly set).

        ``offset`` is applied client-side after the has_domain filter so
        pagination respects the post-filtered row order (Whenful #14603).
        """
        params: dict[str, Any] = {"status": "archived"}
        if domain_id is not None:
            params["domain_id"] = domain_id
        # Over-fetch enough rows that ``offset + limit`` post-filtered items
        # still fit in the slice. The client-side has_domain filter drops
        # an unknown fraction of rows, so we double the post-filter need.
        post_filter_need = (limit + offset) if limit and limit > 0 else max(limit, 100)
        params["limit"] = max(post_filter_need * 2, 100)
        payload = await self._get("/tasks", params=params)
        if not isinstance(payload, list):
            raise WhenfulServerError(f"/tasks returned non-list payload: {type(payload).__name__}")
        tasks: list[dict[str, Any]] = []
        for row in payload:
            if not isinstance(row, dict):
                continue
            if domain_id is None and row.get("domain_id") is None:
                # Mirror HTTP "exclude inbox thoughts from archived view".
                continue
            tasks.append(row)
        if offset:
            tasks = tasks[offset:]
        tasks = tasks[:limit]
        if self._crypto is not None:
            for t in tasks:
                self._decrypt_task_in_place(t)
        return tasks

    async def search_tasks(
        self,
        user_id: int,  # noqa: ARG002
        *,
        query: str,
        include_completed: bool = False,
    ) -> list[dict[str, Any]]:
        """Client-side substring search across decrypted title/description.

        REST has no full-text-search endpoint; the stdio transport
        fetches the user's pending (and optionally completed) tasks and
        does the substring match in the client. This keeps plaintext
        out of the server's query logs on encryption-on accounts —
        searching ciphertext is impossible by design — and matches the
        privacy posture documented in `feedback_privacy_philosophy.md`.
        """
        q = (query or "").strip().lower()
        if not q:
            return []

        async def _fetch(status: str) -> list[dict[str, Any]]:
            payload = await self._get("/tasks", params={"status": status, "limit": 200})
            if not isinstance(payload, list):
                raise WhenfulServerError(f"/tasks returned non-list payload: {type(payload).__name__}")
            return [row for row in payload if isinstance(row, dict)]

        rows: list[dict[str, Any]] = await _fetch("pending")
        if include_completed:
            rows.extend(await _fetch("completed"))

        # Decrypt before matching so plaintext substrings hit on
        # encryption-on accounts.
        if self._crypto is not None:
            for r in rows:
                self._decrypt_task_in_place(r)

        matches: list[dict[str, Any]] = []
        for row in rows:
            # Mirror HTTP: exclude inbox thoughts.
            if row.get("domain_id") is None:
                continue
            title = row.get("title")
            desc = row.get("description")
            if (isinstance(title, str) and q in title.lower()) or (isinstance(desc, str) and q in desc.lower()):
                matches.append(row)
        return matches[:100]

    async def batch_create_tasks(
        self,
        user_id: int,
        *,
        tasks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Client-side iteration over create_task. REST has no
        batch-create endpoint.

        On encryption-on accounts each iteration's title/description is
        encrypted via the same ``_encrypt_task_body_in_place`` path as
        the single-task create.
        """
        created: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []
        for i, item in enumerate(tasks):
            if not isinstance(item, dict) or not item.get("title"):
                errors.append({"index": i, "message": "missing 'title'"})
                continue
            try:
                result = await self.create_task(
                    user_id=user_id,
                    title=item["title"],
                    domain_id=item.get("domain_id"),
                    impact=item.get("impact", 4),
                    clarity=item.get("clarity", "normal"),
                    duration_minutes=item.get("duration_minutes"),
                    scheduled_date=item.get("scheduled_date"),
                    scheduled_time=item.get("scheduled_time"),
                    description=item.get("description"),
                    parent_id=item.get("parent_id"),
                    is_recurring=bool(item.get("is_recurring")),
                    recurrence_rule=item.get("recurrence_rule"),
                    recurrence_start=item.get("recurrence_start"),
                    recurrence_end=item.get("recurrence_end"),
                    reminder_minutes_before=item.get("reminder_minutes_before"),
                )
                # Surface domain_id + parent_id so the MCP tool layer can
                # honestly frame the response under the thought-vs-task
                # invariant (see docs/THOUGHTS-VS-TASKS.md).
                created.append(
                    {
                        "id": result.get("id"),
                        "title": result.get("title"),
                        "domain_id": result.get("domain_id"),
                        "parent_id": result.get("parent_id"),
                    }
                )
            except WhenfulClientError as exc:
                errors.append({"index": i, "message": str(exc)})
        return {"created": created, "errors": errors}

    async def batch_update_tasks(
        self,
        user_id: int,
        *,
        task_ids: list[int],
        impact: int | None = None,
        clarity: str | None = None,
        domain_id: int | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Client-side iteration over update_task. REST has no
        batch-update content endpoint suitable for partial-field updates
        — the existing /tasks/batch-update is content-only (encryption
        flow). Recurring tasks are skipped on status=completed to match
        HTTP behavior.
        """
        completing = status == "completed"
        kwargs: dict[str, Any] = {}
        if impact is not None:
            kwargs["impact"] = impact
        if clarity is not None:
            kwargs["clarity"] = clarity
        if status is not None:
            kwargs["status"] = status
        if domain_id is not None:
            kwargs["domain_id"] = domain_id

        updated = 0
        skipped_recurring: list[int] = []
        errors: list[dict[str, Any]] = []

        for tid in task_ids:
            try:
                if completing:
                    task = await self.get_task(user_id=user_id, task_id=tid)
                    if task is None:
                        errors.append({"id": tid, "message": "not found"})
                        continue
                    if task.get("is_recurring"):
                        skipped_recurring.append(tid)
                        continue
                result = await self.update_task(user_id, tid, **kwargs)
                if result is None:
                    errors.append({"id": tid, "message": "not found"})
                else:
                    updated += 1
            except WhenfulClientError as exc:
                errors.append({"id": tid, "message": str(exc)})

        return {
            "updated_count": updated,
            "skipped_recurring": skipped_recurring,
            "errors": errors,
        }

    async def batch_complete_tasks(
        self,
        user_id: int,
        *,
        task_ids: list[int],
    ) -> dict[str, Any]:
        """Client-side iteration over complete_task. We avoid the REST
        /tasks/batch-action endpoint here because it does not surface
        per-task error reasons in the response — iterating gives us
        granular error tracking that matches the HTTP tool's output.
        Recurring tasks are skipped.
        """
        completed = 0
        skipped_recurring: list[int] = []
        errors: list[dict[str, Any]] = []

        for tid in task_ids:
            try:
                task = await self.get_task(user_id=user_id, task_id=tid)
                if task is None:
                    errors.append({"id": tid, "message": "not found"})
                    continue
                if task.get("is_recurring"):
                    skipped_recurring.append(tid)
                    continue
                result = await self.complete_task(user_id=user_id, task_id=tid)
                if result is None:
                    errors.append({"id": tid, "message": "completion failed"})
                else:
                    completed += 1
            except WhenfulClientError as exc:
                errors.append({"id": tid, "message": str(exc)})

        return {
            "completed_count": completed,
            "skipped_recurring": skipped_recurring,
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # Decryption (Phase D)
    # ------------------------------------------------------------------

    #: Task dict keys that carry ciphertext when the server-side user has
    #: ``encryption_enabled = True``. Matches CLAUDE.md §5 (the three
    #: encrypted-at-rest fields). Keys absent from a payload are ignored.
    _ENCRYPTED_TASK_FIELDS: Final[tuple[str, ...]] = ("title", "description", "domain_name")

    #: Subtask dict keys that carry ciphertext. ``SubtaskResponse`` in
    #: ``app/routers/tasks.py`` mirrors the task shape minus ``domain_name``
    #: (subtasks inherit their parent's domain).
    _ENCRYPTED_SUBTASK_FIELDS: Final[tuple[str, ...]] = ("title", "description")

    #: Domain dict keys that carry ciphertext. ``DomainResponse`` in
    #: ``app/routers/domains.py`` — only ``name`` is at-rest-encrypted per
    #: CLAUDE.md §5; ``color`` / ``icon`` / ``position`` / ``is_archived``
    #: stay plaintext for server-side filtering.
    _ENCRYPTED_DOMAIN_FIELDS: Final[tuple[str, ...]] = ("name",)

    def _decrypt_domain_in_place(self, domain: dict[str, Any]) -> None:
        """Decrypt the at-rest-encrypted ``name`` on a domain dict.

        Best-effort: a value that isn't a non-empty string or that fails
        AES-GCM authentication is left untouched, matching the
        legacy-plaintext fall-through contract used by tasks.
        """
        if self._crypto is None:
            return
        for field in self._ENCRYPTED_DOMAIN_FIELDS:
            self._decrypt_field_in_place(domain, field)

    def _decrypt_task_in_place(self, task: dict[str, Any]) -> None:
        """Decrypt the three at-rest-encrypted fields on a task dict.

        Best-effort: a value that isn't a non-empty string, or that
        fails AES-GCM authentication, is left untouched. Two scenarios
        rely on this:

        - **Legacy plaintext** (tasks created before encryption was
          enabled, or by an encryption-off user) — these are not
          base64-IV-ciphertext-tag blobs, so ``decrypt`` raises and we
          pass through.
        - **Server returned an unexpected type** (e.g. ``None`` for a
          missing ``description``) — we don't crash on it.

        Recursive into ``subtasks`` if present.
        """
        if self._crypto is None:  # belt + braces; callers gate already
            return
        for field in self._ENCRYPTED_TASK_FIELDS:
            self._decrypt_field_in_place(task, field)
        subtasks = task.get("subtasks")
        if isinstance(subtasks, list):
            for sub in subtasks:
                if isinstance(sub, dict):
                    for field in self._ENCRYPTED_SUBTASK_FIELDS:
                        self._decrypt_field_in_place(sub, field)

    def _decrypt_field_in_place(self, obj: dict[str, Any], field: str) -> None:
        """Decrypt ``obj[field]`` if present and AES-GCM authenticates.

        Side-effects only — no return value. Crypto is guaranteed non-
        None by the caller. Any decryption failure leaves the value
        unchanged, matching the legacy-plaintext fall-through contract.
        """
        if self._crypto is None:
            return
        value = obj.get(field)
        if not isinstance(value, str) or not value:
            return
        try:
            obj[field] = self._crypto.decrypt(value)
        except CryptoError:
            # Legacy plaintext or otherwise non-ciphertext value;
            # pass through unchanged. No log line — the stdio client
            # is silent by policy (zero telemetry).
            return

    # ------------------------------------------------------------------
    # Encryption on writes (mirrors browser path)
    # ------------------------------------------------------------------

    def _encrypt_field_in_place(self, obj: dict[str, Any], field: str) -> None:
        """Encrypt ``obj[field]`` in place if present and a non-empty
        string. Symmetric to ``_decrypt_field_in_place``.

        Called on every outbound write body before POST/PUT for the three
        encrypted-at-rest fields (``title``, ``description``,
        ``domain_name``). If ``self._crypto is None``, this is a no-op —
        the user has encryption off, the server is happy to store
        plaintext, and the field passes through unchanged.

        A ``None`` value is left as ``None``; an empty string is left as
        ``""`` (the server uses both to signal "no description"). Only
        non-empty plaintext gets encrypted.
        """
        if self._crypto is None:
            return
        value = obj.get(field)
        if not isinstance(value, str) or not value:
            return
        obj[field] = self._crypto.encrypt(value)

    def _encrypt_task_body_in_place(self, body: dict[str, Any]) -> None:
        """Encrypt the three at-rest-encrypted task fields on an outbound
        create/update body. ``domain_name`` is normally not sent on
        ``/api/v1/tasks`` writes (the wire uses ``domain_id``), but we
        encrypt it defensively if present so future routes that take a
        name don't accidentally leak.
        """
        if self._crypto is None:
            return
        self._encrypt_field_in_place(body, "title")
        self._encrypt_field_in_place(body, "description")
        self._encrypt_field_in_place(body, "domain_name")

    # ------------------------------------------------------------------
    # Domain-name resolution
    # ------------------------------------------------------------------

    async def _resolve_domain_name_to_id(self, name: str) -> int | None:
        """Map a plaintext domain ``name`` (case-insensitive) to its
        ``domain_id``, fetching + caching the full domain list on first
        use.

        Routes through ``self.list_domains()`` so the operation API is
        the single source for domain enumeration. The operation already
        decrypts encrypted names in place via ``_decrypt_domain_in_place``,
        so the cache keys are always plaintext on both legacy- and
        encryption-enabled accounts.

        Returns ``None`` when no domain matches — callers (the tool
        layer) format the "domain not found" message.

        Cache invalidation is *opt-in*: callers that mutate domains
        (create/update/archive) must call ``reset_domain_cache()`` after
        the write. Reads are memoized; the cache lifetime matches the
        ``WhenfulClient`` instance.
        """
        if not name:
            return None
        if self._domain_cache is None:
            # ``user_id`` is ignored by the stdio path (Bearer token
            # carries identity) — pass 0 as a placeholder.
            payload = await self.list_domains(user_id=0)
            cache: dict[str, int] = {}
            for d in payload:
                if not isinstance(d, dict):
                    continue
                decrypted_name = d.get("name")
                did = d.get("id")
                if isinstance(decrypted_name, str) and isinstance(did, int):
                    cache[decrypted_name.lower()] = did
            self._domain_cache = cache
        return self._domain_cache.get(name.lower())

    def reset_domain_cache(self) -> None:
        """Invalidate the memoized domain-name → id mapping. Called by
        future domain write operations after a mutation; safe to call
        from anywhere if the caller suspects the cache is stale.
        """
        self._domain_cache = None

    # ------------------------------------------------------------------
    # HTTP plumbing
    # ------------------------------------------------------------------

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=DEFAULT_TIMEOUT_SECONDS,
            )
            self._owns_client = True
        return self._http_client

    async def _auth_headers(self) -> dict[str, str]:
        token = await self._auth.get_access_token()
        return {"Authorization": f"Bearer {token}"}

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
        allow_404: bool = False,
    ) -> Any:
        """Issue an HTTP request and return the JSON-decoded body.

        Method-agnostic core used by ``_get``/``_post``/``_put``.

        - ``params``: query parameters serialized by httpx.
        - ``json_body``: optional dict serialized to JSON.
        - ``allow_404``: when True, returns ``None`` on 404 instead of raising.
          Used by the get-or-mutate operations whose REST endpoints treat
          "no such instance" as a value, not an error.
        - ``AuthExpiredError`` / ``AuthNetworkError`` from ``AuthManager``
          are re-raised as ``WhenfulAuthError`` / ``WhenfulNetworkError``
          so callers depend only on this module's exceptions.
        """
        client = self._ensure_client()
        try:
            response = await self._request_with_auth_retry(client, method, path, params=params, json_body=json_body)
        except (AuthExpiredError, WhenfulAuthError) as exc:
            raise WhenfulAuthError(str(exc)) from exc
        except AuthNetworkError as exc:
            raise WhenfulNetworkError(str(exc)) from exc
        except httpx.HTTPError as exc:
            raise WhenfulNetworkError(f"{path} request failed: {exc!r}") from exc

        if response.status_code == 404 and allow_404:
            return None
        if response.status_code >= 500:
            raise WhenfulServerError(
                f"{path} returned {response.status_code}: {_sanitize_response_text(response.text)}"
            )
        if response.status_code >= 400:
            raise WhenfulServerError(
                f"{path} returned {response.status_code}: {_sanitize_response_text(response.text)}"
            )
        # 204 No Content (or any empty body) → return None instead of crashing
        # on the JSON parse. None of our endpoints currently 204, but the
        # check is cheap and protects future endpoints.
        if not response.content:
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise WhenfulServerError(f"{path} response was not JSON: {_sanitize_response_text(response.text)}") from exc

    async def _get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        allow_404: bool = False,
    ) -> Any:
        """GET ``path`` (relative to ``base_url``), retry once on 401."""
        return await self._request("GET", path, params=params, allow_404=allow_404)

    async def _post(
        self,
        path: str,
        *,
        json_body: Any | None = None,
        params: dict[str, Any] | None = None,
        allow_404: bool = False,
        allow_204: bool = False,
    ) -> Any:
        """POST ``path`` with optional JSON body. Symmetric to ``_get``.

        - ``allow_404``: return ``None`` on 404 instead of raising.
        - ``allow_204``: return ``None`` on 204 (the REST DELETE/restore
          patterns return 204 with no body).
        """
        return await self._send_with_body(
            "POST", path, json_body=json_body, params=params, allow_404=allow_404, allow_204=allow_204
        )

    async def _put(
        self,
        path: str,
        *,
        json_body: Any | None = None,
        allow_404: bool = False,
        allow_204: bool = False,
    ) -> Any:
        """PUT ``path`` with JSON body. Used by ``update_task`` and
        ``reschedule_instance`` / ``update_domain``."""
        return await self._send_with_body("PUT", path, json_body=json_body, allow_404=allow_404, allow_204=allow_204)

    async def _patch(
        self,
        path: str,
        *,
        json_body: Any | None = None,
        allow_404: bool = False,
    ) -> Any:
        """PATCH ``path`` with JSON body. Reserved for resources that use
        PATCH semantics (currently none in tasks scope, but kept symmetric
        for the integration agent)."""
        return await self._send_with_body("PATCH", path, json_body=json_body, allow_404=allow_404)

    async def _delete(
        self,
        path: str,
        *,
        allow_404: bool = False,
    ) -> bool:
        """DELETE ``path``. Returns ``True`` on 2xx, ``False`` on 404 when
        ``allow_404`` is set."""
        result = await self._send_with_body(
            "DELETE", path, allow_404=allow_404, allow_204=True, return_none_on_2xx=True
        )
        return result is not False

    async def _send_with_body(
        self,
        method: str,
        path: str,
        *,
        json_body: Any | None = None,
        params: dict[str, Any] | None = None,
        allow_404: bool = False,
        allow_204: bool = False,
        return_none_on_2xx: bool = False,
    ) -> Any:
        """Common implementation for POST/PUT/PATCH/DELETE.

        Returns:
        - 2xx with JSON body: parsed dict/list
        - 2xx with no body / 204: None (when ``allow_204`` is True) or empty dict
        - 404: None when ``allow_404`` is True
        - 4xx/5xx: WhenfulServerError
        - For ``_delete``: ``return_none_on_2xx`` causes ``True`` on 2xx, ``False`` on 404.
        """
        client = self._ensure_client()
        try:
            response = await self._request_with_auth_retry(client, method, path, params=params, json_body=json_body)
        except (AuthExpiredError, WhenfulAuthError) as exc:
            raise WhenfulAuthError(str(exc)) from exc
        except AuthNetworkError as exc:
            raise WhenfulNetworkError(str(exc)) from exc
        except httpx.HTTPError as exc:
            raise WhenfulNetworkError(f"{path} request failed: {exc!r}") from exc

        if response.status_code == 404 and allow_404:
            return None if not return_none_on_2xx else False
        if response.status_code == 204:
            if return_none_on_2xx:
                return True
            if allow_204:
                return None
            # 204 with no body for an op that expects JSON: degrade to {}.
            return {}
        if response.status_code >= 500:
            raise WhenfulServerError(
                f"{path} returned {response.status_code}: {_sanitize_response_text(response.text)}"
            )
        if response.status_code >= 400:
            raise WhenfulServerError(
                f"{path} returned {response.status_code}: {_sanitize_response_text(response.text)}"
            )
        if return_none_on_2xx:
            return True
        try:
            return response.json()
        except ValueError as exc:
            raise WhenfulServerError(f"{path} response was not JSON: {_sanitize_response_text(response.text)}") from exc

    async def _request_with_auth_retry(
        self,
        client: httpx.AsyncClient,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
    ) -> httpx.Response:
        """Issue a request, retrying once on 401 after a forced refresh.

        The retry is unconditional on 401 — even if the access token was
        fresh, the server may have invalidated it (token blocklist,
        token-epoch bump). A single refresh + retry is the contract; a
        second 401 propagates as an auth failure to the caller.
        """
        stale_token = await self._auth.get_access_token()
        headers = {"Authorization": f"Bearer {stale_token}"}
        response = await client.request(method, path, params=params, json=json_body, headers=headers)
        if response.status_code != 401:
            return response

        # 401: try a refresh, then retry once. Pass the access token that
        # produced the 401 so concurrent refreshes coalesce.
        try:
            await self._auth.refresh(triggering_token=stale_token)
        except AuthExpiredError:
            # Refresh hard-failed; surface the original 401 as auth error.
            raise WhenfulAuthError(f"{path} returned 401 and refresh was rejected; re-pair the device.") from None
        headers = await self._auth_headers()
        retry = await client.request(method, path, params=params, json=json_body, headers=headers)
        if retry.status_code == 401:
            raise WhenfulAuthError(f"{path} returned 401 even after refresh; re-pair the device.")
        return retry

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def aclose(self) -> None:
        """Close the internally-owned httpx client, if any.

        Does nothing if the client was injected. Always closes the
        AuthManager's internal client too (if it owns one).
        """
        if self._http_client is not None and self._owns_client:
            await self._http_client.aclose()
            self._http_client = None
        await self._auth.aclose()

    # ------------------------------------------------------------------
    # Safety
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        crypto = "with crypto" if self._crypto is not None else "no crypto"
        return f"WhenfulClient(base_url={self._base_url!r}, {crypto})"


__all__ = [
    "DEFAULT_TIMEOUT_SECONDS",
    "WhenfulAuthError",
    "WhenfulClient",
    "WhenfulClientError",
    "WhenfulNetworkError",
    "WhenfulServerError",
]
