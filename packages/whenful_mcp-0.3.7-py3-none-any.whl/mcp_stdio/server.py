"""Stdio MCP server entry point for the Whenful local client.

Phase E of MCP issue #13534. Ties together Phases A-D into a single
runnable MCP server that speaks the stdio transport (line-delimited
JSON-RPC over stdin/stdout) and proxies all reads/writes to the cloud
REST API over HTTPS while holding the user's encryption key locally.

Boot pipeline
-------------

1. Read the user's AES-256 derived key from the OS keystore via
   ``mcp_stdio.keystore.get_keystore()`` (1Password → OS keychain →
   opt-in plaintext). The key was put there by ``mcp_stdio.setup`` after
   a passphrase verification round-trip; we never see the passphrase here.
2. Rebuild a ``CryptoManager`` from the stored key via
   ``CryptoManager.from_key()``. Skips PBKDF2 — we already paid that cost
   once in setup.
3. Construct an ``AuthManager``. It loads ``~/.whenful/tokens.json`` on
   first use and silently refreshes the access token via
   ``POST /api/v1/device/refresh`` whenever needed.
4. Construct a ``WhenfulClient`` (the stdio side's ``Backend``
   implementation). It owns the ``httpx.AsyncClient``, attaches Bearer
   headers per request, and decrypts the three at-rest-encrypted task
   fields (title, description, domain_name) using the ``CryptoManager``.
5. Construct a ``FastMCP("whenful")`` and register the stdio-capable
   tools. Phase E shipped 3 (``whoami``, ``list_tasks``, ``get_task``);
   MCP-stdio full-parity added the 9 recurring-instance tools, all of
   which now consume Backend operations rather than raw SQL via
   ``backend.session()``. The other 21 tools (task CRUD, domains, schedule,
   analytics) still depend on raw SQL and remain unregistered on stdio
   until they're migrated onto the operations API.
6. ``await mcp.run_stdio_async()``. FastMCP's stdio transport reads
   line-delimited JSON-RPC ``initialize`` / ``tools/list`` / ``tools/call``
   from stdin and writes responses to stdout.

Tool-registration scope (Approach 1 from the Phase E brief)
-----------------------------------------------------------

Only ported operations are registered. Approach 2 (register all 33
with a graceful-degradation wrapper) was rejected because it pollutes the
``tools/list`` surface with tools that don't work, forcing the LLM to
discover failures by trial. Cleanly hiding the unported tools is the
honest contract; subsequent phases expand the registered set as
operations land. MCP-stdio full-parity (this phase) widens the set from
3 to 12 by porting the recurring-instance category.

Test-only escape hatches
------------------------

Two environment variables are honoured for tests/CI ONLY. They are
documented here so a curious operator does not enable them without
understanding the security trade-off:

- ``WHENFUL_KEY_B64`` — if set, the server uses these base64-decoded
  bytes as the AES-256 key instead of reading the OS keystore. **Never
  set this in production**: it bypasses every keystore protection
  (Touch ID, 1Password biometric, file permissions). The subprocess e2e
  test sets it under a ``tmp_path``-scoped subprocess to avoid touching
  the real keychain.
- The existing ``WHENFUL_API_BASE`` and ``WHENFUL_TOKEN_PATH`` vars
  from ``mcp_stdio.auth`` are honoured for the same reason (already
  documented there).

The production path does NOT read either ``WHENFUL_KEY_B64`` setter
unless a test explicitly sets it — so production users carry no risk
from this hook.

Account selection
-----------------

Phase D's keystore takes ``account: str`` to namespace multiple
Whenful accounts on one machine. Phase E uses
``_account_label_from_tokens`` from ``mcp_stdio.setup`` to derive the
same label setup persisted under. Multi-account stdio (a runtime
"which account" prompt or flag) is post-launch.

Privacy & telemetry posture
---------------------------

Zero telemetry. No Sentry, no OTel, no ``print()`` of secrets. The
single user-visible ``stderr`` line on startup is a one-line "starting"
status with no key/token data; failures print the cause without
including secret material. This module imports from ``app.*`` only
inside function bodies — never at import time — so ``mcp_stdio`` stays
buildable as a standalone wheel when Phase F lands.
"""

from __future__ import annotations

import asyncio
import base64
import os
import sys
from typing import Any, Final

from mcp.server.fastmcp import FastMCP

from .auth import AuthExpiredError, AuthManager
from .client import WhenfulClient
from .crypto import CryptoManager
from .keystore import KeyStore, KeyStoreError, get_keystore
from .setup import _account_label_from_tokens, _fetch_encryption_status

#: Exit codes — same convention as ``mcp_stdio.setup``. Stable for shell
#: scripts and the future ``whenful-mcp`` console-script wrapper.
EXIT_OK: Final[int] = 0
EXIT_NO_KEY: Final[int] = 1
EXIT_NO_TOKENS: Final[int] = 2
EXIT_KEYSTORE_ERROR: Final[int] = 4

#: Test-only escape hatch. Setting this base64-encoded AES key in the env
#: makes ``_load_key`` return its bytes verbatim — bypassing every
#: keystore backend. Documented at module top. Never set in production.
_TEST_KEY_ENV: Final[str] = "WHENFUL_KEY_B64"

#: Names of the tools we register on stdio. Names match the HTTP MCP path
#: (``app/routers/mcp_server.py``) so client UX is transport-symmetric.
#:
#: Phase E (#13534) shipped the first 3 ports. MCP-stdio full-parity then
#: added the 9 recurring-instance tools, the 4 domain tools, the 4
#: schedule/analytics tools, the user-preferences tool, and the 15 task
#: tools — every one of which now consumes the Backend operations API
#: rather than ``backend.session()`` raw SQL, so they all work cleanly
#: on stdio.
STDIO_TOOL_NAMES: Final[tuple[str, ...]] = (
    # Identity
    "whoami",
    # Tasks reads
    "list_tasks",
    "list_thoughts",
    "list_recurring_tasks",
    "get_task",
    "get_archived_tasks",
    "search_tasks",
    # Tasks writes
    "create_task",
    "update_task",
    "complete_task",
    "uncomplete_task",
    "toggle_complete",
    "nuke_task",
    "archive_task",
    "restore_task",
    "batch_create_tasks",
    "batch_update_tasks",
    "batch_complete_tasks",
    # Recurring instances (9)
    "complete_instance",
    "skip_instance",
    "unskip_instance",
    "uncomplete_instance",
    "reschedule_instance",
    "batch_complete_instances",
    "batch_past_instances",
    "pending_past_count",
    "list_past_instances",
    # Domains (4)
    "list_domains",
    "create_domain",
    "update_domain",
    "archive_domain",
    # Schedule + analytics (4)
    "get_schedule",
    "get_overdue",
    "get_analytics",
    "get_recent_completions",
    # Planning (1) — registered for tools/list parity; the shared tool returns
    # a "not yet supported on stdio" string until the service is ported off
    # ``backend.session()`` raw SQL onto the Backend operations API.
    "plan_my_day",
    # User preferences (1)
    "get_preferences",
)


# ---------------------------------------------------------------------------
# Key loading
# ---------------------------------------------------------------------------


def _load_key(
    account: str,
    *,
    insecure_plaintext: bool = False,
    keystore: KeyStore | None = None,
) -> bytes | None:
    """Return the 32-byte AES-256 key for ``account``, or ``None`` if absent.

    Resolution order:

    1. ``WHENFUL_KEY_B64`` env var (test-only escape hatch). If set,
       base64-decode and return — never touches the real keystore.
    2. The supplied ``keystore`` (Phase D's ``KeyStore.load(account)``).
    3. If ``keystore`` is ``None``, construct one via
       ``get_keystore(insecure_plaintext=insecure_plaintext)`` and call
       ``load(account)``.

    Raises ``KeyStoreError`` propagated from the keystore backend
    (subprocess failure, permission errors, malformed stored value).
    Returns ``None`` when nothing is stored under ``account`` — callers
    decide whether that's fatal.
    """
    raw_b64 = os.environ.get(_TEST_KEY_ENV)
    if raw_b64:
        try:
            return base64.b64decode(raw_b64, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"{_TEST_KEY_ENV} is not valid base64: {exc!r}") from exc

    if keystore is None:
        keystore = get_keystore(insecure_plaintext=insecure_plaintext)
    return keystore.load(account)


# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


def register_stdio_tools(mcp: FastMCP, client: WhenfulClient) -> None:
    """Register all stdio-capable tools on ``mcp``.

    After the MCP-stdio full-parity migration (#13534), every tool the
    cloud HTTP MCP exposes is also available locally — identity,
    task CRUD, recurring instances, domains, schedule queries, analytics,
    and preferences. The shared tool implementations in
    ``app/mcp_shared/tools/*.py`` consume the Backend operations API so
    they work transport-symmetrically: the HTTP transport supplies a
    ``_DBBackend`` that talks SQL, and the stdio transport supplies a
    ``WhenfulClient`` that talks REST.

    Wrappers below format the dict/list payloads ``WhenfulClient`` returns
    into human-readable strings — symmetric with the cloud HTTP path,
    whose tool wrappers in ``app/routers/mcp_server.py`` also return
    strings. LLM clients receive identically-shaped string responses
    regardless of transport.
    """

    @mcp.tool(name="whoami")
    async def _whoami() -> str:
        """Show the authenticated user's identity. Useful for debugging."""
        # Route through the shared whoami tool so the cloud HTTP and stdio
        # transports produce identical user-facing strings. The shared
        # implementation handles the empty-payload case and renders all
        # five fields (email, name, data_version, encryption_enabled,
        # tier) — see ``app/mcp_shared/tools/user.py::format_whoami``.
        from app.mcp_shared.tools import user as _user_tools

        return await _user_tools.whoami(client, user_id=0)

    @mcp.tool(name="list_tasks")
    async def _list_tasks(
        domain_id: int | None = None,
        status: str = "pending",
        scheduled_date: str | None = None,
        is_recurring: bool | None = None,
        clarity: str | None = None,
        parent_id: int | None = None,
        source: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> str:
        """List tasks from Whenful with optional filters.

        Args:
            domain_id: Filter by domain ID.
            status: Task status: pending (default), completed, archived, or all.
            scheduled_date: Filter by exact date (YYYY-MM-DD).
            is_recurring: Filter recurring (true) or one-off (false) tasks.
            clarity: Energy mode filter: autopilot, normal, brainstorm.
            parent_id: List subtasks of a specific parent task ID.
            source: Filter by source (e.g. "todoist", "manual").
            limit: Max results.
            offset: Pagination offset.
        """
        tasks = await client.list_tasks(
            user_id=0,
            domain_id=domain_id,
            status=status,
            scheduled_date=scheduled_date,
            is_recurring=is_recurring,
            clarity=clarity,
            parent_id=parent_id,
            source=source,
            limit=limit,
            offset=offset,
        )
        if not tasks:
            return "No tasks found."
        return _format_task_list(tasks)

    @mcp.tool(name="get_task")
    async def _get_task(task_id: int) -> str:
        """Get full details of a single task by ID.

        Args:
            task_id: The task ID to inspect.
        """
        task = await client.get_task(user_id=0, task_id=task_id)
        if task is None:
            return f"Task {task_id} not found."
        return _shared_format_task()(task)

    # ------------------------------------------------------------------
    # Recurring instances (9) — MCP-stdio full-parity (#13534)
    #
    # Each tool delegates straight to the shared implementation in
    # ``app/mcp_shared/tools/instances.py``. The shared functions consume
    # the Backend operations API rather than raw SQL, so they're
    # transport-symmetric. We pass ``user_id=0`` as a documented
    # sentinel — the Bearer token carries identity on the stdio path.
    # ------------------------------------------------------------------

    @mcp.tool(name="complete_instance")
    async def _complete_instance(instance_id: int) -> str:
        """Complete a specific recurring task instance.

        Args:
            instance_id: The instance ID (shown as inst:ID in schedule output).
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.complete_instance(client, user_id=0, instance_id=instance_id)

    @mcp.tool(name="skip_instance")
    async def _skip_instance(instance_id: int) -> str:
        """Skip a specific recurring task instance.

        Args:
            instance_id: The instance ID to skip (shown as inst:ID in schedule output).
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.skip_instance(client, user_id=0, instance_id=instance_id)

    @mcp.tool(name="unskip_instance")
    async def _unskip_instance(instance_id: int) -> str:
        """Unskip a recurring task instance (revert to pending).

        Args:
            instance_id: The instance ID to unskip (shown as inst:ID in schedule output).
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.unskip_instance(client, user_id=0, instance_id=instance_id)

    @mcp.tool(name="uncomplete_instance")
    async def _uncomplete_instance(instance_id: int) -> str:
        """Undo instance completion — mark a completed recurring instance as pending again.

        Args:
            instance_id: The instance ID to uncomplete (shown as inst:ID in schedule output).
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.uncomplete_instance(client, user_id=0, instance_id=instance_id)

    @mcp.tool(name="reschedule_instance")
    async def _reschedule_instance(instance_id: int, new_datetime: str) -> str:
        """Reschedule a recurring task instance to a different date/time.

        Args:
            instance_id: The instance ID to reschedule.
            new_datetime: New date or datetime. Accepts YYYY-MM-DD (date only)
                or YYYY-MM-DDTHH:MM (full datetime, e.g. "2026-03-25T14:30").
                Date-only reschedules on stdio default to midnight in UTC —
                full-datetime reschedules preserve the wall-clock correctly.
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.reschedule_instance(
            client, user_id=0, instance_id=instance_id, new_datetime=new_datetime
        )

    @mcp.tool(name="batch_complete_instances")
    async def _batch_complete_instances(task_id: int, before_date: str) -> str:
        """Complete all pending instances for a specific recurring task before a given date.

        Args:
            task_id: The recurring task ID whose instances to complete.
            before_date: Complete all pending instances before this date (YYYY-MM-DD).
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.batch_complete_instances(
            client, user_id=0, task_id=task_id, before_date=before_date
        )

    @mcp.tool(name="batch_past_instances")
    async def _batch_past_instances(action: str) -> str:
        """Complete or skip all pending past instances across all recurring tasks.

        Args:
            action: What to do with past instances: "complete" or "skip".
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.batch_past_instances(client, user_id=0, action=action)

    @mcp.tool(name="pending_past_count")
    async def _pending_past_count() -> str:
        """Count pending recurring task instances from past days. Useful to check if there's a backlog."""
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.pending_past_count(client, user_id=0)

    @mcp.tool(name="list_past_instances")
    async def _list_past_instances(limit: int = 50, offset: int = 0) -> str:
        """Drill into pending past recurring instances, grouped by parent task.

        Use this BEFORE `batch_past_instances` to see which recurring tasks
        contributed to the backlog and how many instances each has.

        Args:
            limit: Max number of parent tasks to surface, default 50.
            offset: Pagination offset, default 0. When the response footer
                includes ``has_more: true``, advance by ``next_offset``.
        """
        from app.mcp_shared.tools import instances as _instance_tools

        return await _instance_tools.list_past_instances(client, user_id=0, limit=limit, offset=offset)

    # ------------------------------------------------------------------
    # Task tools (15) — MCP-stdio full-parity (#13534)
    #
    # Each tool delegates to ``app.mcp_shared.tools.tasks``. The shared
    # tools call the Backend operations API, so they work transport-
    # symmetrically on the cloud HTTP and local stdio paths.
    # ------------------------------------------------------------------

    @mcp.tool(name="list_thoughts")
    async def _list_thoughts(status: str = "pending", limit: int = 50, offset: int = 0) -> str:
        """List untriaged inbox items (tasks without a domain).

        Args:
            status: Status filter — pending, completed, archived, or all.
            limit: Maximum number of results.
            offset: Pagination offset.
        """
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.list_thoughts(client, user_id=0, status=status, limit=limit, offset=offset)

    @mcp.tool(name="list_recurring_tasks")
    async def _list_recurring_tasks(status: str = "pending") -> str:
        """List recurring parent tasks with pending-instance backlog summary.

        Args:
            status: Status filter — pending (default), completed, archived, or all.
        """
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.list_recurring_tasks(client, user_id=0, status=status)

    @mcp.tool(name="create_task")
    async def _create_task(
        title: str,
        domain: str | None = None,
        impact: int = 4,
        clarity: str = "normal",
        duration_minutes: int | None = None,
        scheduled_date: str | None = None,
        scheduled_time: str | None = None,
        description: str | None = None,
        parent_id: int | None = None,
        is_recurring: bool = False,
        recurrence_rule: str | None = None,
        recurrence_start: str | None = None,
        recurrence_end: str | None = None,
        reminder_minutes_before: int | None = None,
    ) -> str:
        """Create a new task.

        Args:
            title: Task title (required).
            domain: Domain name (resolved to domain_id on the client).
            impact: Impact tier 1 (highest) to 4 (minimal).
            clarity: Energy mode — autopilot, normal, or brainstorm.
            duration_minutes: Estimated duration.
            scheduled_date: YYYY-MM-DD.
            scheduled_time: HH:MM.
            description: Long-form description.
            parent_id: Parent task ID for subtasks.
            is_recurring: True for recurring tasks (requires recurrence_rule).
            recurrence_rule: JSON object — see existing docs.
            recurrence_start: YYYY-MM-DD.
            recurrence_end: YYYY-MM-DD.
            reminder_minutes_before: Minutes before scheduled_time to remind.
        """
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.create_task(
            client,
            user_id=0,
            title=title,
            domain=domain,
            impact=impact,
            clarity=clarity,
            duration_minutes=duration_minutes,
            scheduled_date=scheduled_date,
            scheduled_time=scheduled_time,
            description=description,
            parent_id=parent_id,
            is_recurring=is_recurring,
            recurrence_rule=recurrence_rule,
            recurrence_start=recurrence_start,
            recurrence_end=recurrence_end,
            reminder_minutes_before=reminder_minutes_before,
        )

    @mcp.tool(name="update_task")
    async def _update_task(
        task_id: int,
        title: str | None = None,
        domain: str | None = None,
        impact: int | None = None,
        clarity: str | None = None,
        duration_minutes: int | None = None,
        scheduled_date: str | None = None,
        scheduled_time: str | None = None,
        description: str | None = None,
        parent_id: int | None = None,
        is_recurring: bool | None = None,
        recurrence_rule: str | None = None,
        recurrence_start: str | None = None,
        recurrence_end: str | None = None,
        position: int | None = None,
        reminder_minutes_before: int | None = None,
    ) -> str:
        """Update an existing task. Only fields you pass are changed."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.update_task(
            client,
            user_id=0,
            task_id=task_id,
            title=title,
            domain=domain,
            impact=impact,
            clarity=clarity,
            duration_minutes=duration_minutes,
            scheduled_date=scheduled_date,
            scheduled_time=scheduled_time,
            description=description,
            parent_id=parent_id,
            is_recurring=is_recurring,
            recurrence_rule=recurrence_rule,
            recurrence_start=recurrence_start,
            recurrence_end=recurrence_end,
            position=position,
            reminder_minutes_before=reminder_minutes_before,
        )

    @mcp.tool(name="complete_task")
    async def _complete_task(task_id: int) -> str:
        """Mark a non-recurring task as completed."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.complete_task(client, user_id=0, task_id=task_id)

    @mcp.tool(name="uncomplete_task")
    async def _uncomplete_task(task_id: int) -> str:
        """Revert a completed non-recurring task back to pending."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.uncomplete_task(client, user_id=0, task_id=task_id)

    @mcp.tool(name="toggle_complete")
    async def _toggle_complete(task_id: int, target_date: str | None = None) -> str:
        """Toggle completion state. For recurring tasks toggles a specific instance.

        Args:
            task_id: Task ID.
            target_date: YYYY-MM-DD (only for recurring tasks; defaults to today).
        """
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.toggle_complete(client, user_id=0, task_id=task_id, target_date=target_date)

    @mcp.tool(name="nuke_task")
    async def _nuke_task(task_id: int) -> str:
        """Permanently delete a task. No recovery possible."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.nuke_task(client, user_id=0, task_id=task_id)

    @mcp.tool(name="archive_task")
    async def _archive_task(task_id: int) -> str:
        """Archive (soft-delete) a task."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.archive_task(client, user_id=0, task_id=task_id)

    @mcp.tool(name="restore_task")
    async def _restore_task(task_id: int) -> str:
        """Restore an archived task."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.restore_task(client, user_id=0, task_id=task_id)

    @mcp.tool(name="get_archived_tasks")
    async def _get_archived_tasks(domain: str | None = None, limit: int = 50, offset: int = 0) -> str:
        """List archived tasks, optionally filtered by domain name.

        Args:
            domain: Filter by domain name (case-insensitive).
            limit: Max results, default 50.
            offset: Pagination offset, default 0. When the response footer
                includes ``has_more: true``, advance by ``next_offset``.
        """
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.get_archived_tasks(client, user_id=0, domain=domain, limit=limit, offset=offset)

    @mcp.tool(name="search_tasks")
    async def _search_tasks(query: str, include_completed: bool = False) -> str:
        """Search task titles + descriptions (case-insensitive substring match)."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.search_tasks(client, user_id=0, query=query, include_completed=include_completed)

    @mcp.tool(name="batch_create_tasks")
    async def _batch_create_tasks(tasks_json: str) -> str:
        """Create many tasks at once. ``tasks_json`` is a JSON array of task objects."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.batch_create_tasks(client, user_id=0, tasks_json=tasks_json)

    @mcp.tool(name="batch_update_tasks")
    async def _batch_update_tasks(
        task_ids: str,
        impact: int | None = None,
        clarity: str | None = None,
        domain: str | None = None,
        status: str | None = None,
    ) -> str:
        """Apply a uniform partial update to many tasks. ``task_ids`` is comma-separated."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.batch_update_tasks(
            client,
            user_id=0,
            task_ids=task_ids,
            impact=impact,
            clarity=clarity,
            domain=domain,
            status=status,
        )

    @mcp.tool(name="batch_complete_tasks")
    async def _batch_complete_tasks(task_ids: str) -> str:
        """Complete many non-recurring tasks at once. Skips recurring tasks."""
        from app.mcp_shared.tools import tasks as _task_tools

        return await _task_tools.batch_complete_tasks(client, user_id=0, task_ids=task_ids)

    # ------------------------------------------------------------------
    # Domain tools (4)
    # ------------------------------------------------------------------

    @mcp.tool(name="list_domains")
    async def _list_domains() -> str:
        """List all domains (projects / life areas), including archived."""
        from app.mcp_shared.tools import domains as _domain_tools

        return await _domain_tools.list_domains(client, user_id=0)

    @mcp.tool(name="create_domain")
    async def _create_domain(name: str, color: str | None = None, icon: str | None = None) -> str:
        """Create a new domain. ``color`` is a hex string like ``#ff0000``."""
        from app.mcp_shared.tools import domains as _domain_tools

        return await _domain_tools.create_domain(client, user_id=0, name=name, color=color, icon=icon)

    @mcp.tool(name="update_domain")
    async def _update_domain(
        domain_id: int,
        name: str | None = None,
        color: str | None = None,
        icon: str | None = None,
        position: int | None = None,
    ) -> str:
        """Update a domain."""
        from app.mcp_shared.tools import domains as _domain_tools

        return await _domain_tools.update_domain(
            client,
            user_id=0,
            domain_id=domain_id,
            name=name,
            color=color,
            icon=icon,
            position=position,
        )

    @mcp.tool(name="archive_domain")
    async def _archive_domain(domain_id: int) -> str:
        """Archive (soft-delete) a domain."""
        from app.mcp_shared.tools import domains as _domain_tools

        return await _domain_tools.archive_domain(client, user_id=0, domain_id=domain_id)

    # ------------------------------------------------------------------
    # Schedule + analytics (4)
    # ------------------------------------------------------------------

    @mcp.tool(name="get_schedule")
    async def _get_schedule(date_from: str, date_to: str) -> str:
        """Return scheduled tasks + recurring instances for a date range.

        Args:
            date_from: Range start (YYYY-MM-DD).
            date_to: Range end (YYYY-MM-DD).
        """
        from app.mcp_shared.tools import schedule as _schedule_tools

        return await _schedule_tools.get_schedule(client, user_id=0, date_from=date_from, date_to=date_to)

    @mcp.tool(name="get_overdue")
    async def _get_overdue() -> str:
        """Return overdue tasks + past pending recurring-instance count."""
        from app.mcp_shared.tools import schedule as _schedule_tools

        return await _schedule_tools.get_overdue(client, user_id=0)

    @mcp.tool(name="get_analytics")
    async def _get_analytics(days: int = 30) -> str:
        """Return completion analytics over the last ``days`` days (clamped 7-90)."""
        from app.mcp_shared.tools import schedule as _schedule_tools

        return await _schedule_tools.get_analytics(client, user_id=0, days=days)

    @mcp.tool(name="get_recent_completions")
    async def _get_recent_completions(limit: int = 20) -> str:
        """Return the most recently completed tasks and instances."""
        from app.mcp_shared.tools import schedule as _schedule_tools

        return await _schedule_tools.get_recent_completions(client, user_id=0, limit=limit)

    # ------------------------------------------------------------------
    # Planning (1) — stdio surface is the "not yet supported" string the
    # shared tool returns. Registered here so ``tools/list`` is symmetric
    # with the cloud HTTP transport; a future PR can port the service off
    # raw SQL onto the Backend operations API for real stdio support.
    # ------------------------------------------------------------------

    @mcp.tool(name="plan_my_day")
    async def _plan_my_day(
        start_time: str,
        end_time: str,
        energy_level: str | None = None,
        domain_ids: list[int] | None = None,
        impact_min: int = 4,
    ) -> list[dict[str, Any]] | str:
        """Propose how to fill a time window with unscheduled tasks (read-only).

        Mirrors the web UI's "Plan My Day" button. Returns proposals only.

        Args:
            start_time: Window start as ISO 8601 (e.g. "2026-05-20T09:00").
            end_time: Window end as ISO 8601 (same day as start_time).
            energy_level: Optional clarity filter: autopilot, normal, brainstorm.
            domain_ids: Optional list of domain IDs to restrict candidates.
            impact_min: Maximum impact value (1=highest, 4=lowest). Default 4.
        """
        from app.mcp_shared.tools import planning as _planning_tools

        return await _planning_tools.plan_my_day(
            client,
            user_id=0,
            start_time=start_time,
            end_time=end_time,
            energy_level=energy_level,
            domain_ids=domain_ids,
            impact_min=impact_min,
        )

    # ------------------------------------------------------------------
    # User preferences (1)
    # ------------------------------------------------------------------

    @mcp.tool(name="get_preferences")
    async def _get_preferences() -> str:
        """Return the authenticated user's preferences."""
        from app.mcp_shared.tools import user as _user_tools

        return await _user_tools.get_preferences(client, user_id=0)


def _shared_format_task() -> Any:
    """Return ``app.mcp_shared.formatters.format_task``, imported lazily.

    The lazy import preserves the "no ``app.*`` at module load time" rule
    from this module's docstring (Phase F wheel-buildability). The cost
    is one dict lookup per call — negligible against an HTTP round-trip.

    Output format is byte-identical to what the cloud HTTP MCP transport
    sends to the LLM, so the stdio surface is transport-symmetric.
    ``tests/test_mcp.py`` asserts on the same substrings (``[id:``,
    ``[inst:`` etc.) — see the shared formatter's docstring for the
    behavioral contract.
    """
    from app.mcp_shared.formatters import format_task as _format_task

    return _format_task


def _format_task_list(tasks: list[dict[str, Any]]) -> str:
    """Render a list of task dicts using the shared MCP formatter.

    Each task is formatted via ``app.mcp_shared.formatters.format_task``
    (the same one the cloud HTTP MCP tools use) so output is byte-
    identical across transports. A short header line carries the count;
    each task occupies its own block (multi-line if it has a description
    or subtasks).
    """
    fmt = _shared_format_task()
    lines = [f"Found {len(tasks)} task(s):"]
    lines.extend(fmt(task) for task in tasks)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------


async def amain(
    *,
    insecure_plaintext: bool = False,
    auth: AuthManager | None = None,
    keystore: KeyStore | None = None,
) -> int:
    """Async entry point — used directly by unit tests, and by ``main()``
    via ``asyncio.run()``.

    Returns an exit code instead of raising. The CLI shim translates
    the exit code into ``sys.exit``.

    Collaborators are dependency-injected so unit tests can swap in a
    pre-constructed ``AuthManager`` or a fake ``KeyStore`` without
    going through ``get_keystore()``.
    """
    # AuthManager owns the token file; load tokens first so we can derive
    # the account label from them. If the file is missing, abort cleanly
    # with a stderr hint pointing at ``mcp_stdio.setup``.
    owns_auth = auth is None
    if auth is None:
        auth = AuthManager()
    try:
        tokens = auth.load()
        if tokens is None:
            sys.stderr.write(f"No tokens found at {auth.token_path}. Run `whenful-mcp setup` first.\n")
            return EXIT_NO_TOKENS

        account = _account_label_from_tokens(tokens)

        # Pull the AES key out of the keystore (or the test env hook).
        try:
            key = _load_key(account, insecure_plaintext=insecure_plaintext, keystore=keystore)
        except KeyStoreError as exc:
            sys.stderr.write(f"Keystore error: {exc}\n")
            return EXIT_KEYSTORE_ERROR
        if key is None:
            sys.stderr.write("No encryption key found in keystore. Run `whenful-mcp setup` first.\n")
            return EXIT_NO_KEY

        crypto: CryptoManager | None = CryptoManager.from_key(key)

        # P1-MCP8 (v0.1.3): re-check server-side encryption state at boot.
        # The wheel was paired when the server reported encryption ON; if
        # the user has since toggled encryption OFF in Whenful Settings,
        # we MUST NOT encrypt outbound writes — otherwise the server
        # stores ciphertext blobs (``enc:v1:9j8K...``) as if they were
        # plaintext task titles, and the user sees garbage on the web.
        # On any transient error reaching the server we keep the locally
        # paired crypto (fail-closed: prefer encrypting writes over
        # silently sending plaintext on a flaky network).
        try:
            status = await _fetch_encryption_status(auth)
        except Exception as exc:  # noqa: BLE001 — best-effort, don't crash boot
            sys.stderr.write(
                f"Could not verify server encryption state (network error: {exc!r}). "
                "Boot continuing with locally paired key — outbound writes will be encrypted.\n"
            )
        else:
            if not status.get("enabled"):
                sys.stderr.write(
                    "Server reports encryption is disabled on this account. "
                    "Wheel will skip client-side encryption on outbound writes. "
                    "Re-pair (`whenful-mcp setup`) if you re-enable encryption.\n"
                )
                crypto = None

        # Build the REST-backed Backend and the FastMCP server. We do NOT
        # call ``app.routers.mcp_server`` here — the stdio path is a
        # parallel transport with its own slim FastMCP construction.
        whenful = WhenfulClient(auth=auth, crypto=crypto)
        try:
            mcp = FastMCP(
                "whenful",
                instructions=(
                    "Whenful task management (local stdio MCP). Full parity with the "
                    "cloud HTTP MCP — read and write tasks, manage recurring instances, "
                    "domains, schedule queries, analytics, and preferences. Plaintext "
                    "content (titles, descriptions, domain names) is encrypted client-"
                    "side before reaching the server; the server stores ciphertext."
                ),
            )
            register_stdio_tools(mcp, whenful)

            # Touch the access token once before entering the stdio loop
            # so a missing-refresh-token or expired-refresh-token is
            # surfaced as a clean exit instead of a deep stack trace
            # mid-tool-call. Best-effort: a network error here is not
            # fatal because stdio clients can retry tool calls.
            try:
                await auth.get_access_token()
            except AuthExpiredError as exc:
                sys.stderr.write(f"Auth error: {exc}\n")
                return EXIT_NO_TOKENS

            sys.stderr.write("whenful-mcp stdio server started (Phase E).\n")
            sys.stderr.flush()
            await mcp.run_stdio_async()
            return EXIT_OK
        finally:
            await whenful.aclose()
    finally:
        if owns_auth:
            await auth.aclose()


# ---------------------------------------------------------------------------
# CLI shim
# ---------------------------------------------------------------------------


_USAGE: Final[str] = (
    "usage: python -m mcp_stdio.server [--insecure-key-storage] [--help]\n\n"
    "Run the Whenful local stdio MCP server.\n\n"
    "On startup the server reads the user's AES-256 encryption key from\n"
    "the OS keystore (1Password CLI -> system Keychain -> opt-in plaintext)\n"
    "and the device tokens from ~/.whenful/tokens.json. Both are set up by\n"
    "`python -m mcp_stdio.setup`. The server then speaks the MCP stdio\n"
    "transport (line-delimited JSON-RPC on stdin/stdout).\n\n"
    "Flags:\n"
    "  --insecure-key-storage   Allow the plaintext-file keystore fallback\n"
    "                           when no secure backend is available. Mirror\n"
    "                           of `mcp_stdio.setup --insecure-key-storage`.\n"
    "  --help, -h               Show this message and exit.\n"
)


def main(argv: list[str] | None = None) -> int:
    """Synchronous CLI shim for ``python -m mcp_stdio.server``.

    Argument parsing mirrors ``mcp_stdio.setup`` for symmetry — a single
    ``--insecure-key-storage`` flag plus ``--help``.
    """
    args = argv if argv is not None else sys.argv[1:]
    if "--help" in args or "-h" in args:
        sys.stdout.write(_USAGE)
        return EXIT_OK
    insecure = "--insecure-key-storage" in args
    try:
        return asyncio.run(amain(insecure_plaintext=insecure))
    except KeyboardInterrupt:
        sys.stderr.write("\nAborted.\n")
        return 130  # POSIX SIGINT convention


if __name__ == "__main__":
    sys.exit(main())


__all__ = [
    "EXIT_KEYSTORE_ERROR",
    "EXIT_NO_KEY",
    "EXIT_NO_TOKENS",
    "EXIT_OK",
    "STDIO_TOOL_NAMES",
    "amain",
    "main",
    "register_stdio_tools",
]
