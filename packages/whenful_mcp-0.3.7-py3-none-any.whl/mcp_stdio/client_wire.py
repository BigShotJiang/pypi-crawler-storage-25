"""Auto-detect MCP clients and safely wire / unwire the ``whenful`` entry.

Replaces the v0.3.1 "manual edit ~/Library/.../claude_desktop_config.json"
hint that was the last copy-paste cliff in the setup flow. The wheel
now:

  1. Scans for installed MCP clients on the current OS (Claude Code via
     CLI on PATH, Claude Desktop via the well-known config directory).
  2. Asks the user once per detected client whether to wire it.
  3. Writes the ``mcpServers.whenful`` entry into the client's JSON
     config atomically (tempfile + ``os.replace``), preserving every
     other entry the user already has.
  4. On logout: the symmetric unwire — same detection, same atomic
     write, removes only the ``mcpServers.whenful`` key.

Why a dedicated module
-----------------------

The detect / write surface is the riskiest add to the wheel — any bug
here corrupts a user's MCP client config and the next Claude Code
session is broken. Putting it in its own module gives us:

  - A clear test seam (mock ``shutil.which`` + ``Path`` fixtures only,
    not the full setup flow).
  - One place to audit the atomic-write contract.
  - One place to add new clients later (Cursor, Continue, etc) without
    touching ``setup.py`` / ``logout.py``.

Safety contract
---------------

  - Every config-write is atomic: ``write tmp → fsync → os.replace``.
    Power-loss or SIGKILL mid-write never leaves a half-corrupt config
    in place — either the old file is intact or the new one is.
  - Existing keys are preserved. If the user already has
    ``mcpServers.someone-else``, ``other-top-level-key``, etc., we
    deep-merge our entry in and leave everything else untouched.
  - Malformed JSON in the existing file is fatal-for-this-client but
    non-fatal-for-setup. The user sees a clear "your foo.json has
    invalid JSON at line X" message and the setup flow continues; we
    refuse to "fix" by overwriting because we'd silently delete user
    state.
  - Permission denied returns a typed result, not a Python traceback.
    The setup flow translates it into a user-readable message.
  - Conflicts (existing ``mcpServers.whenful`` with a different shape)
    are surfaced — we never silently overwrite a user-customized entry.

Privacy posture
---------------

Zero telemetry. Detection reads only the local filesystem and
``shutil.which``; we do not network out, fingerprint installed
software, or report anything anywhere.
"""

from __future__ import annotations

import contextlib
import json
import os
import shutil
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Final

#: Canonical config payload we write under ``mcpServers.whenful``.
#: One source of truth — also referenced by setup.py's README hint
#: text. If the entrypoint name changes in pyproject.toml, update
#: this dict in lockstep.
WHENFUL_ENTRY: Final[dict[str, Any]] = {
    "command": "whenful-mcp",
    "args": ["serve"],
}


class ClientKind(str, Enum):
    """The MCP clients we know how to detect and wire."""

    CLAUDE_CODE = "claude_code"
    CLAUDE_DESKTOP = "claude_desktop"


@dataclass(frozen=True)
class ClientInfo:
    """A detected MCP client and its config-file location.

    ``display_name`` is what we show to the user in prompts. ``path``
    is the absolute file path we will read/write. ``kind`` is the
    enum tag, used to look up icons / per-client behaviors if we ever
    add them.
    """

    kind: ClientKind
    display_name: str
    path: Path


class WireOutcome(str, Enum):
    """Discriminator for what happened during a wire / unwire call.

    Each value maps to a distinct user-visible message in setup.py /
    logout.py — callers branch on this rather than parsing error
    strings.
    """

    WROTE_NEW = "wrote_new"  # file didn't exist; created it.
    MERGED = "merged"  # file existed; we added/updated our entry.
    ALREADY_WIRED = "already_wired"  # file already had the exact entry; no-op.
    REMOVED = "removed"  # unwire: deleted our entry from the file.
    NOT_PRESENT = "not_present"  # unwire: nothing to remove.
    CONFLICT = "conflict"  # wire: existing entry has a different shape.
    INVALID_JSON = "invalid_json"  # file existed but isn't parseable JSON.
    PERMISSION_DENIED = "permission_denied"  # read/write blocked by OS.


@dataclass(frozen=True)
class WireResult:
    """What happened when we tried to wire or unwire a client.

    ``detail`` is a human-readable elaboration (e.g. the conflicting
    existing entry serialized, or the JSON parse error message). It
    is safe to surface verbatim to the user — it never contains
    bearer tokens or keys.
    """

    outcome: WireOutcome
    detail: str = ""


def _home() -> Path:
    """Return ``Path.home()`` indirected so tests can monkey-patch.

    Direct ``Path.home()`` calls bypass ``HOME`` env override on some
    platforms, which makes tmp_path-based tests brittle. We honour
    ``HOME`` explicitly so ``monkeypatch.setenv("HOME", str(tmp_path))``
    just works.
    """
    home = os.environ.get("HOME") or os.environ.get("USERPROFILE")
    if home:
        return Path(home)
    return Path.home()


def _claude_code_config_path() -> Path:
    """Where Claude Code stores its global MCP config.

    Same path on every OS — Claude Code is a Node app and follows
    the same ``~/.claude.json`` convention everywhere. This is the
    GLOBAL config; project-scoped ``.mcp.json`` is intentionally not
    a wire target because it would version-control the wheel command
    into a repo, which is the wrong default for a per-user MCP server.
    """
    return _home() / ".claude.json"


def _claude_desktop_config_path() -> Path:
    """Per-OS path to ``claude_desktop_config.json``.

    Mirrors the mapping in ``setup.py::_claude_desktop_config_path``
    but returns a ``Path`` (not a display string) — actual I/O happens
    against the result, so we use real paths, not ``~`` shorthand.
    """
    if sys.platform == "darwin":
        return _home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
        return _home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json"
    return _home() / ".config" / "Claude" / "claude_desktop_config.json"


def _detect_claude_code() -> ClientInfo | None:
    """Detect Claude Code via ``claude`` binary on PATH OR existing config.

    Both signals are evidence; PATH is the strong one (the CLI is
    installed) while file existence is the soft one (the user has
    used it before). Either is sufficient — we don't require both,
    because a fresh Claude Code install may not have created the
    file yet.
    """
    has_binary = shutil.which("claude") is not None
    config_path = _claude_code_config_path()
    has_config = config_path.exists()
    if has_binary or has_config:
        return ClientInfo(
            kind=ClientKind.CLAUDE_CODE,
            display_name="Claude Code",
            path=config_path,
        )
    return None


def _detect_claude_desktop() -> ClientInfo | None:
    """Detect Claude Desktop via the well-known config directory.

    We probe the DIRECTORY (not the file) because a fresh Claude
    Desktop install creates the directory before the user has ever
    edited a config — so directory-only is a reliable "installed but
    untouched" signal. If the directory is absent, Claude Desktop is
    almost certainly not installed.
    """
    config_path = _claude_desktop_config_path()
    if config_path.parent.exists():
        return ClientInfo(
            kind=ClientKind.CLAUDE_DESKTOP,
            display_name="Claude Desktop",
            path=config_path,
        )
    return None


def detect_clients() -> list[ClientInfo]:
    """Return every MCP client detected on this machine.

    Order is stable: Claude Code first, then Claude Desktop. Callers
    iterate in order so the user sees prompts in the same sequence
    every time. Returns an empty list when nothing is detected —
    callers should fall back to printing manual instructions.
    """
    found: list[ClientInfo] = []
    code = _detect_claude_code()
    if code is not None:
        found.append(code)
    desktop = _detect_claude_desktop()
    if desktop is not None:
        found.append(desktop)
    return found


def _read_existing_config(path: Path) -> tuple[dict[str, Any] | None, WireResult | None]:
    """Read and parse the client's config file.

    Returns ``(config_dict, None)`` on success, or
    ``(None, WireResult)`` on a failure that callers should surface
    to the user (invalid JSON, permission denied). When the file
    doesn't exist, returns ``({}, None)`` — that's not an error, it's
    "fresh config to create".

    Refuses to parse a non-object top-level (e.g. a JSON array). MCP
    client configs are always JSON objects; an array at top level is
    a sign the user opened the wrong file and we should not pretend
    to understand it.
    """
    if not path.exists():
        return {}, None
    try:
        raw = path.read_text(encoding="utf-8")
    except PermissionError as exc:
        return None, WireResult(
            outcome=WireOutcome.PERMISSION_DENIED,
            detail=f"Cannot read {path}: {exc}",
        )
    except OSError as exc:
        return None, WireResult(
            outcome=WireOutcome.PERMISSION_DENIED,
            detail=f"Cannot read {path}: {exc}",
        )
    if not raw.strip():
        # Empty file is treated as an empty config — common when the
        # client created the file but the user has never edited it.
        return {}, None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, WireResult(
            outcome=WireOutcome.INVALID_JSON,
            detail=f"{path} is not valid JSON: {exc.msg} at line {exc.lineno}",
        )
    if not isinstance(parsed, dict):
        return None, WireResult(
            outcome=WireOutcome.INVALID_JSON,
            detail=f"{path} top-level is not a JSON object — refusing to modify.",
        )
    return parsed, None


def _atomic_write_json(path: Path, data: dict[str, Any]) -> WireResult | None:
    """Atomically write ``data`` as pretty JSON to ``path``.

    Pattern: ``mkstemp`` in the same directory → ``write`` → ``fsync``
    → ``os.replace``. Same-directory tempfile guarantees the rename
    is atomic (cross-FS renames degrade to copy+delete). 0o600 perms
    on the tempfile because MCP client configs can reference local
    paths and command lines that we don't want world-readable.

    Returns ``None`` on success or a ``WireResult`` describing the
    failure. The caller wraps it.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".whenful-tmp")
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
    except PermissionError as exc:
        # Best-effort tempfile cleanup; ignore if it never landed.
        with contextlib.suppress(OSError):
            tmp.unlink()
        return WireResult(
            outcome=WireOutcome.PERMISSION_DENIED,
            detail=f"Cannot write {path}: {exc}",
        )
    except OSError as exc:
        with contextlib.suppress(OSError):
            tmp.unlink()
        return WireResult(
            outcome=WireOutcome.PERMISSION_DENIED,
            detail=f"Cannot write {path}: {exc}",
        )
    return None


def wire_client(client: ClientInfo) -> WireResult:
    """Add or update the ``mcpServers.whenful`` entry in ``client.path``.

    Preserves every other key in the config. Returns a ``WireResult``
    describing what happened — callers surface the outcome to the
    user via ``setup.py`` / ``logout.py`` message tables.

    Idempotent: re-running against a file that already has the
    correct entry returns ``ALREADY_WIRED`` without touching the
    file. Re-running against a CONFLICT requires the user to either
    remove the existing entry by hand or accept overwrite by
    calling with ``force=True`` (not implemented in v0.3.2 — the
    conflict path prints instructions and bails).
    """
    config, err = _read_existing_config(client.path)
    if err is not None:
        return err
    assert config is not None  # contract: err is None ⇒ config is not None

    file_existed = client.path.exists() and bool(config)
    mcp_servers = config.get("mcpServers")
    if not isinstance(mcp_servers, dict):
        # Either missing or wrong type — replace with a fresh dict.
        # If it was wrong type (e.g. user wrote an array), preserve
        # by stashing under a backup key so the user can recover.
        if mcp_servers is not None:
            config["mcpServers_invalid_was"] = mcp_servers
        mcp_servers = {}
        config["mcpServers"] = mcp_servers

    existing = mcp_servers.get("whenful")
    if existing == WHENFUL_ENTRY:
        return WireResult(outcome=WireOutcome.ALREADY_WIRED, detail=str(client.path))
    if isinstance(existing, dict) and existing.get("command") != WHENFUL_ENTRY["command"]:
        # User has a custom command (maybe pointing at a dev wheel /
        # local path / wrapper script). Don't clobber.
        return WireResult(
            outcome=WireOutcome.CONFLICT,
            detail=(
                f"{client.path} already has a custom `mcpServers.whenful` entry: "
                f"{json.dumps(existing)}. Refusing to overwrite — remove it by hand "
                "if you want the default wheel wiring."
            ),
        )

    mcp_servers["whenful"] = dict(WHENFUL_ENTRY)
    write_err = _atomic_write_json(client.path, config)
    if write_err is not None:
        return write_err
    return WireResult(
        outcome=WireOutcome.MERGED if file_existed else WireOutcome.WROTE_NEW,
        detail=str(client.path),
    )


def unwire_client(client: ClientInfo) -> WireResult:
    """Remove the ``mcpServers.whenful`` entry from ``client.path``.

    The symmetric inverse of ``wire_client``. Preserves every other
    key (including other ``mcpServers`` entries). If the entry isn't
    there, returns ``NOT_PRESENT`` — a no-op, not an error. Used by
    ``whenful-mcp logout`` so users come out of logout with a clean
    config, not a stale entry that Claude Code keeps trying to
    launch.

    Edge case: if our removal empties ``mcpServers`` entirely, we
    leave it as ``{}`` rather than deleting the key. Some clients
    treat a missing ``mcpServers`` differently from an empty one
    (auto-populating defaults), and we'd rather not surprise the
    user by triggering that branch.
    """
    if not client.path.exists():
        return WireResult(outcome=WireOutcome.NOT_PRESENT, detail=str(client.path))
    config, err = _read_existing_config(client.path)
    if err is not None:
        return err
    assert config is not None

    mcp_servers = config.get("mcpServers")
    if not isinstance(mcp_servers, dict) or "whenful" not in mcp_servers:
        return WireResult(outcome=WireOutcome.NOT_PRESENT, detail=str(client.path))

    del mcp_servers["whenful"]
    write_err = _atomic_write_json(client.path, config)
    if write_err is not None:
        return write_err
    return WireResult(outcome=WireOutcome.REMOVED, detail=str(client.path))


__all__ = [
    "WHENFUL_ENTRY",
    "ClientInfo",
    "ClientKind",
    "WireOutcome",
    "WireResult",
    "detect_clients",
    "unwire_client",
    "wire_client",
]
