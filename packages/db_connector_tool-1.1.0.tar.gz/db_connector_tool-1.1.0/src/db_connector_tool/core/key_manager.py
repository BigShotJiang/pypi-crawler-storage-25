"""密钥管理模块 (KeyManager)

提供加密密钥的安全管理功能，包括密钥的创建、加载、存储和轮换，
支持多种密钥存储方式（操作系统密钥环、环境变量、文件），
确保加密密钥的安全性和可用性。

Example:
>>> from db_connector_tool import KeyManager
>>>
>>> key_manager = KeyManager("my_app")
>>>
>>> key_manager.load_or_create_key()
>>>
>>> crypto_manager = key_manager.get_crypto_manager()
>>>
>>> key_manager.rotate_key()
"""

import hashlib
import json
import os
import secrets
import threading
import tomllib
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import tomli_w

from ..utils.logging_utils import get_logger
from ..utils.path_utils import PathHelper
from .crypto import CryptoManager
from .exceptions import ConfigError, CryptoError

keyring_available = False  # pylint: disable=invalid-name
keyring_module = None  # pylint: disable=invalid-name
try:
    import keyring

    keyring_available = True  # pylint: disable=invalid-name
    keyring_module = keyring
except ImportError:
    pass

logger = get_logger(__name__)

_module_lock = threading.Lock()


class KeyManager:
    """密钥管理器类 (Key Manager)

    管理加密密钥的安全存储和操作，支持多种密钥存储方式，
    提供统一的密钥管理接口，与 CryptoManager 无缝集成。

    Example:
    >>> key_manager = KeyManager("my_app")
    >>>
    >>> key_manager.load_or_create_key()
    >>>
    >>> crypto = key_manager.get_crypto_manager()
    >>>
    >>> key_manager.rotate_key()
    >>>
    >>> hmac_key = key_manager.get_secure_hmac_key()
    >>>
    >>> key_manager.close()
    """

    _env_key = None
    _env_key_available = None
    _dependencies_checked = False
    _dependency_check_lock = None

    def __init__(self, app_name: str = "db_connector_tool") -> None:
        """初始化密钥管理器

        创建新的密钥管理器实例，用于管理加密密钥的安全存储和操作。

        Args:
            app_name: 应用名称，用于确定配置目录和密钥存储标识

        Raises:
            ConfigError: 初始化失败

        Example:
            >>> key_manager = KeyManager()

            >>> key_manager = KeyManager("my_application")
        """

        self.app_name = app_name
        self.config_dir = PathHelper.get_user_config_dir(app_name)
        self.crypto: Optional[CryptoManager] = None

        self._ensure_dependencies_checked()

    def _ensure_dependencies_checked(self) -> None:
        """确保依赖检查已完成（线程安全）

        确保类级别的依赖检查只执行一次，使用双重检查锁定模式确保线程安全。
        """
        if not KeyManager._dependencies_checked:
            if KeyManager._dependency_check_lock is None:
                with _module_lock:
                    if KeyManager._dependency_check_lock is None:
                        KeyManager._dependency_check_lock = threading.RLock()

            if KeyManager._dependency_check_lock is not None:
                with KeyManager._dependency_check_lock:
                    if not KeyManager._dependencies_checked:
                        KeyManager._check_dependencies()

    def close(self) -> None:
        """关闭密钥管理器，清理敏感数据

        清理内存中的敏感数据，确保密钥信息不会被泄露。

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager.close()
        """

        if self.crypto is not None:
            self.crypto.close()
            self.crypto = None
        logger.debug("密钥管理器已关闭")

    @staticmethod
    def handle_config_operation(operation_name: str) -> Callable:
        """配置操作异常处理装饰器

        捕获并处理配置操作中的异常，提供统一的错误处理和日志记录。

        Args:
            operation_name: 操作名称，用于错误消息和日志记录

        Returns:
            Callable: 装饰器函数

        Example:
            >>> @handle_config_operation("配置文件保存")
            ... def _save_config(self, config):
            ...     pass
        """

        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(self, *args, **kwargs):
                try:
                    return func(self, *args, **kwargs)
                except OSError as error:
                    logger.error("配置文件操作失败: %s", str(error))
                    raise ConfigError(f"{operation_name}失败: {str(error)}") from error
                except (TypeError, ValueError) as error:
                    logger.error("配置数据处理失败: %s", str(error))
                    raise ConfigError(f"{operation_name}失败: {str(error)}") from error
                except (AttributeError, RuntimeError, MemoryError) as error:
                    logger.error("%s失败: %s", operation_name, str(error))
                    raise ConfigError(f"{operation_name}失败: {str(error)}") from error
                except Exception as error:
                    logger.error("%s失败: %s", operation_name, str(error))
                    raise ConfigError(f"{operation_name}失败: {str(error)}") from error

            return wrapper

        return decorator

    @handle_config_operation("安全密钥管理")
    def load_or_create_key(self) -> None:
        """加载或创建加密密钥

        加载现有的加密密钥，如果不存在则创建新的密钥，
        按照安全层次结构选择密钥存储方式。

        Raises:
            ConfigError: 密钥加载或创建失败

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager.load_or_create_key()
        """

        if keyring_available and keyring_module is not None:
            self._load_or_create_key_from_keyring()
        elif KeyManager._env_key_available and KeyManager._env_key:
            try:
                key_data = json.loads(KeyManager._env_key)
                self._load_crypto_from_key_data(key_data)
                logger.debug("使用环境变量中的加密密钥")
            except (json.JSONDecodeError, TypeError, ConfigError) as error:
                logger.error(
                    "环境变量密钥格式错误: %s，请检查 DB_CONNECTOR_TOOL_ENCRYPTION_KEY 环境变量的格式",
                    str(error),
                )
                logger.warning("环境变量密钥加载失败，使用文件存储方案")
                self._load_or_create_key_from_file()
        else:
            logger.warning("keyring库和环境变量都不可用，使用文件权限保护方案")
            self._load_or_create_key_from_file()

    def _load_or_create_key_from_keyring(self) -> None:
        """从操作系统密钥环加载或创建密钥

        从操作系统的密钥环中加载现有的加密密钥，
        如果不存在则创建新的密钥并存储到密钥环。

        Raises:
            ConfigError: 密钥操作失败

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager._load_or_create_key_from_keyring()
        """

        assert keyring_module is not None, "keyring库可用"

        service_name = self.app_name
        username = "master_key"

        stored_key = keyring_module.get_password(service_name, username)

        if stored_key:
            self._load_crypto_from_key_data(json.loads(stored_key))
            logger.debug("从操作系统密钥存储加载密钥成功")
        else:
            key_data = self._create_new_crypto_key()
            keyring_module.set_password(service_name, username, json.dumps(key_data))
            logger.info("新加密密钥已安全存储到操作系统密钥环")

    def _load_crypto_from_key_data(self, key_data: Dict[str, Any]) -> None:
        """从密钥数据加载加密管理器

        从包含密码、盐值和迭代次数的密钥数据中加载加密管理器。

        Args:
            key_data: 包含password、salt和iterations的密钥数据字典

        Raises:
            ConfigError: 密钥数据无效

        Example:
            >>> key_data = {
            ...     "password": "secure_password",
            ...     "salt": "random_salt",
            ...     "iterations": 480000
            ... }
            >>> key_manager._load_crypto_from_key_data(key_data)
        """

        if "password" not in key_data or "salt" not in key_data:
            raise ConfigError("密钥数据格式无效")

        self.crypto = CryptoManager.from_saved_key(
            key_data["password"],
            key_data["salt"],
            key_data["iterations"],
        )
        logger.debug("加密密钥加载成功")

    def _create_new_crypto_key(self) -> Dict[str, str]:
        """创建新的加密密钥

        创建新的加密密钥并初始化加密管理器。

        Returns:
            Dict[str, str]: 包含password和salt的密钥数据

        Example:
            >>> key_data = key_manager._create_new_crypto_key()
            >>> print("password" in key_data)
            True
            >>> print("salt" in key_data)
            True
        """

        self.crypto = CryptoManager()
        key_data = self.crypto.get_key_info()
        logger.debug("新加密密钥创建成功")
        return key_data

    def _load_or_create_key_from_file(self) -> None:
        """从文件加载或创建密钥（回退方案）

        从文件中加载现有的加密密钥，
        如果不存在则创建新的密钥文件。

        Raises:
            ConfigError: 密钥加载或创建失败

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager._load_or_create_key_from_file()
        """

        key_file_path = self.config_dir / "encryption.key"
        if key_file_path.exists():
            try:
                self._load_existing_key(key_file_path)
                logger.warning(
                    "警告: 使用文件存储加密密钥（安全性较低）。\n"
                    "安全风险: 文件存储的密钥可能被本地攻击者获取，导致加密数据被解密。\n"
                    "建议: 1. 安装keyring库 (pip install keyring)，使用操作系统密钥环存储\n"
                    "      2. 或设置环境变量 DB_CONNECTOR_TOOL_ENCRYPTION_KEY，使用环境变量存储\n"
                    "      3. 确保密钥文件权限设置正确，仅允许所有者访问"
                )
            except (OSError, tomllib.TOMLDecodeError, ConfigError) as error:
                logger.error("加载密钥文件失败: %s，创建新的密钥文件", str(error))
                self._create_new_key(key_file_path)
        else:
            self._create_new_key(key_file_path)
            logger.warning(
                "警告: 使用文件存储加密密钥（安全性较低）。\n"
                "安全风险: 文件存储的密钥可能被本地攻击者获取，导致加密数据被解密。\n"
                "建议: 1. 安装keyring库 (pip install keyring)，使用操作系统密钥环存储\n"
                "      2. 或设置环境变量 DB_CONNECTOR_TOOL_ENCRYPTION_KEY，使用环境变量存储\n"
                "      3. 确保密钥文件权限设置正确，仅允许所有者访问"
            )

    def _load_existing_key(self, key_file_path: Path) -> None:
        """加载现有的加密密钥文件

        加载现有的加密密钥文件，并设置安全的文件权限。

        Args:
            key_file_path: 密钥文件路径

        Raises:
            ConfigError: 密钥加载失败

        Example:
            >>> key_file = Path("/path/to/encryption.key")
            >>> key_manager._load_existing_key(key_file)
        """

        try:
            self._set_secure_file_permissions(key_file_path)

            with open(key_file_path, "rb") as file:
                key_data = tomllib.load(file)

            self._load_crypto_from_key_data(key_data)
        except CryptoError as error:
            self._handle_crypto_error(key_file_path, error)

    def _create_new_key(self, key_file_path: Path) -> None:
        """创建新的加密密钥文件

        创建新的加密密钥文件，并设置安全的文件权限。

        Args:
            key_file_path: 密钥文件路径

        Example:
            >>> key_file = Path("/path/to/encryption.key")
            >>> key_manager._create_new_key(key_file)
        """

        key_data = self._create_new_crypto_key()

        with open(key_file_path, "wb") as file:
            file.write(tomli_w.dumps(key_data).encode("utf-8"))

        self._set_secure_file_permissions(key_file_path)

        logger.info("新加密密钥文件创建成功")

    def _set_secure_file_permissions(self, file_path: Path) -> None:
        """设置文件安全权限（最小权限原则）

        设置文件的安全权限，确保只有所有者可以访问。

        Args:
            file_path: 文件路径

        Example:
            >>> key_file = Path("/path/to/encryption.key")
            >>> key_manager._set_secure_file_permissions(key_file)
        """

        success = PathHelper.set_secure_file_permissions(file_path)
        if success:
            logger.debug("设置文件权限成功: %s", file_path)
        else:
            logger.warning("设置文件权限失败 %s", file_path)

    def _handle_crypto_error(
        self, key_file_path: Path, crypto_error: CryptoError
    ) -> None:
        """处理加密错误：删除旧密钥并创建新的

        处理加密错误，删除旧的密钥文件并创建新的密钥。

        Args:
            key_file_path: 密钥文件路径
            crypto_error: 加密错误异常

        Raises:
            ConfigError: 删除旧密钥文件失败

        Example:
            >>> key_file = Path("/path/to/encryption.key")
            >>> crypto_error = CryptoError("解密失败")
            >>> key_manager._handle_crypto_error(key_file, crypto_error)
        """

        logger.warning("解密密钥文件失败: %s，将创建新的密钥文件", str(crypto_error))
        try:
            key_file_path.unlink()
            logger.info("已删除旧的密钥文件")
            self._create_new_key(key_file_path)
        except Exception as error:
            logger.error("删除旧密钥文件失败: %s", str(error))
            raise ConfigError(
                f"加密密钥加载失败: {str(crypto_error)}"
            ) from crypto_error

    def get_secure_hmac_key(self) -> bytes:
        """获取安全的HMAC密钥（从主加密密钥派生）

        获取用于生成HMAC签名的安全密钥，优先从主加密密钥派生。

        Returns:
            bytes: 安全的HMAC密钥

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager.load_or_create_key()
            >>> hmac_key = key_manager.get_secure_hmac_key()
            >>> print(len(hmac_key))
            32
        """

        if self.crypto is not None:
            key_info = self.crypto.get_key_info()
            hmac_key_input = f"{key_info['password']}:{key_info['salt']}:hmac".encode(
                "utf-8"
            )
            return hashlib.sha256(hmac_key_input).digest()

        hmac_env_key = os.environ.get("DB_CONNECTOR_TOOL_HMAC_KEY")
        if hmac_env_key:
            logger.debug("使用环境变量中的HMAC密钥")
            return bytes.fromhex(hmac_env_key)

        logger.warning("主加密密钥未初始化，使用临时生成的HMAC密钥")
        return secrets.token_bytes(32)

    def rotate_key(self) -> Dict[str, str]:
        """轮换加密密钥

        生成新的加密密钥并按照安全层次结构保存。

        Returns:
            Dict[str, str]: 新的密钥数据

        Raises:
            ConfigError: 密钥轮换失败

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager.load_or_create_key()
            >>> new_key = key_manager.rotate_key()
            >>> print("password" in new_key)
            True
        """

        key_data = self._create_new_crypto_key()

        self._save_new_key_secure(key_data)

        return key_data

    def _save_new_key_secure(self, key_data: Dict[str, str]) -> None:
        """按照安全层次结构保存新密钥：keyring > 环境变量 > 文件

        按照安全优先级保存新的加密密钥。

        Args:
            key_data: 包含新密钥信息的字典

        Example:
            >>> key_data = {"password": "new_password", "salt": "new_salt"}
            >>> key_manager._save_new_key_secure(key_data)
        """

        if keyring_available and keyring_module is not None:
            service_name = self.app_name
            username = "master_key"

            keyring_module.set_password(service_name, username, json.dumps(key_data))
            logger.info("轮换加密密钥已安全存储到操作系统密钥环")
            return

        if KeyManager._env_key_available:
            logger.warning(
                "建议将新密钥设置为环境变量: %s",
                f"DB_CONNECTOR_TOOL_ENCRYPTION_KEY={json.dumps(key_data)}",
            )

        key_file = self.config_dir / "encryption.key"

        with open(key_file, "wb") as file:
            file.write(tomli_w.dumps(key_data).encode("utf-8"))

        self._set_secure_file_permissions(key_file)

        logger.warning(
            "轮换密钥已保存到文件（安全性较低）。建议使用keyring或环境变量存储"
        )
        logger.debug("轮换密钥文件保存成功: %s", key_file)

    def get_crypto_manager(self) -> CryptoManager:
        """获取加密管理器实例

        获取当前密钥管理器关联的加密管理器实例，
        如果加密管理器未初始化，则会自动初始化。

        Returns:
            CryptoManager: 加密管理器实例

        Raises:
            ConfigError: 加密管理器初始化失败

        Example:
            >>> key_manager = KeyManager()
            >>> key_manager.load_or_create_key()
            >>> crypto_manager = key_manager.get_crypto_manager()
        """

        if self.crypto is None:
            raise ConfigError("加密管理器初始化失败")
        return self.crypto

    @classmethod
    def _check_dependencies(cls) -> None:
        """检查依赖项可用性（类方法，只执行一次）

        检查密钥存储相关的依赖项可用性，包括keyring库和环境变量。

        Example:
            >>> KeyManager._check_dependencies()
        """

        cls._env_key = os.environ.get("DB_CONNECTOR_TOOL_ENCRYPTION_KEY")
        cls._env_key_available = False

        if cls._env_key:
            try:
                key_data = json.loads(cls._env_key)
                if "password" in key_data and "salt" in key_data:
                    cls._env_key_available = True
                    logger.debug("环境变量中的加密密钥可用")
                else:
                    logger.warning("环境变量中的加密密钥格式无效，缺少必要字段")
            except (json.JSONDecodeError, TypeError) as error:
                logger.warning("环境变量中的加密密钥格式无效: %s", str(error))
        else:
            logger.debug("环境变量中无加密密钥")

        if not keyring_available and not cls._env_key_available:
            logger.warning(
                "警告: 未找到安全的密钥存储方案。\n"
                "建议: 1. 安装keyring库 (pip install keyring)\n"
                "      2. 或设置环境变量 DB_CONNECTOR_TOOL_ENCRYPTION_KEY"
            )

        cls._dependencies_checked = True
