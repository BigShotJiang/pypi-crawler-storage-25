"""Source-Delete: Originalvideo + .settings.toml nach verifiziertem Publish löschen.

Seit v0.9.0 opt-in (``PublishRequest.delete_source_after_publish``). Voraussetzung
wird im Publisher geprüft: alle aktiven Kanäle erfolgreich **und** das Archiv
hat den Size-Verify bestanden (die archivierte Datei ist byte-gleich mit dem
Original). Im Desasterfall existiert zusätzlich das Videoschnittprojekt —
daher braucht es hier kein weiteres Safety-Net.

Gelöscht wird:
- das Originalvideo selbst
- die ``.settings.toml`` daneben (falls vorhanden) — ist ohne Video wertlos

Nicht gelöscht werden andere Sidecar-Typen (``.fcpxml``, ``.lfpackage``):
die gehören zum Editing-Projekt und sind der User-seitige Disaster-Recovery-
Fallback. Der User kann sie separat entfernen, wenn gewünscht.
"""

from __future__ import annotations

from pathlib import Path

from familienfilm_manager.core._rclone import run_rclone_with_retry
from familienfilm_manager.core.source_ref import SourceRef


def delete_source(
    source_ref: SourceRef,
    rclone_path: str = "rclone",
) -> list[str]:
    """Löscht das Originalvideo + ``.settings.toml`` an der Quell-Location.

    Returns:
        Liste der gelöschten URIs/Pfade (für Logging).

    Raises:
        Unterliegende Fehler (OSError, subprocess.CalledProcessError) werden
        durchgereicht. Der Caller entscheidet über Fehlerbehandlung.
    """
    deleted: list[str] = []

    if source_ref.is_rclone:
        # rclone deletefile entfernt genau eine Datei (keine rekursiven
        # Überraschungen wie bei 'rclone delete' auf einem Verzeichnis).
        run_rclone_with_retry([rclone_path, "deletefile", source_ref.uri])
        deleted.append(source_ref.uri)

        # Parallele .settings.toml löschen (Fehler tolerieren — Datei
        # existiert evtl. nicht).
        if source_ref.stem:
            sidecar_uri = source_ref.parent_uri().rstrip("/") + f"/{source_ref.stem}.settings.toml"
            try:
                run_rclone_with_retry([rclone_path, "deletefile", sidecar_uri])
                deleted.append(sidecar_uri)
            except Exception:
                pass
        return deleted

    # Lokal
    local = source_ref.as_local_path()
    local.unlink()
    deleted.append(str(local))
    sidecar = local.parent / f"{local.stem}.settings.toml"
    if sidecar.exists():
        sidecar.unlink()
        deleted.append(str(sidecar))
    return deleted
