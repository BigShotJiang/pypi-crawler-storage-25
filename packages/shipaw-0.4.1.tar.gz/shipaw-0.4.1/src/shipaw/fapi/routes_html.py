import os
from functools import wraps
from pathlib import Path
from urllib.parse import unquote

from fastapi import APIRouter, Body, Form
from fastapi.params import Depends
from loguru import logger
from starlette.responses import HTMLResponse, JSONResponse

from shipaw.fapi.alerts import Alerts
from shipaw.fapi.app_custom import ShipawRequest
from shipaw.fapi.emailer import send_label_email
from shipaw.fapi.form_data import shipment_request_form, shipment_request_form_json
from shipaw.fapi.requests import ShipmentRequest
from shipaw.fapi.responses import ShipawTemplateResponse
from shipaw.fapi.routes_api import order_results_api, order_summary_api, shipping_form_api
from shipaw.models.shipment import Shipment, sample_shipment

router = APIRouter()


def render_template_response(request: ShipawRequest, resp: ShipawTemplateResponse) -> HTMLResponse:
    context = resp.template.context
    context['alerts'] = context.get('alerts', Alerts.empty()) + resp.alerts
    if resp.alerts.errors:
        # return request.ship_setting('templates').TemplateResponse(
        return request.app.state.settings.shipaw.templates.TemplateResponse(
            request=request,
            name='alerts.html',
            context=context,
        )

    return request.app.state.settings.shipaw.templates.TemplateResponse(
        request=request,
        name=resp.template.template_path,
        context=context,
    )

    # return request.app.shipaw_settings.templates.TemplateResponse(
    #     request=request,
    #     name=resp.template.template_path,
    #     context=context,
    # )
    #


def html_from_json(json_endpoint):
    @wraps(json_endpoint)
    async def wrapper(request: ShipawRequest, *args, **kwargs):
        resp = await json_endpoint(request, *args, **kwargs)

        return request.app.state.settings.shipaw.templates.TemplateResponse(
            request=request, name=resp.template_path, context=resp.context
        )

    return wrapper


@router.post('/shipping_form', response_class=HTMLResponse)
async def shipping_form(request: ShipawRequest, shipment: Shipment = Body(...)) -> HTMLResponse:
    res = await shipping_form_api(request, shipment)
    return render_template_response(request, res)


@router.post('/order_summary', response_class=HTMLResponse)
async def order_summary(
    request: ShipawRequest,
    shipment_request: ShipmentRequest = Depends(shipment_request_form),
) -> HTMLResponse:
    res = await order_summary_api(shipment_request)
    # res = await order_summary_api(request, shipment_request)
    return render_template_response(request, res)


@router.post('/order_results', response_class=HTMLResponse)
async def order_results(
    request: ShipawRequest,
    shipment_request: ShipmentRequest = Depends(shipment_request_form_json),
) -> HTMLResponse:
    template_response = await order_results_api(request, shipment_request)
    return render_template_response(request, template_response)


@router.get('/home_mobile_phone', response_class=HTMLResponse)
async def home_mobile_phone(request: ShipawRequest) -> HTMLResponse:
    mobile_phone = request.app.state.settings.shipaw.mobile_phone
    return HTMLResponse(f"""
    <input type="tel" id="mobile_phone" name="mobile_phone" value="{mobile_phone}" required>
    """)


@router.get('/open-file/{filepath}', response_class=HTMLResponse)
async def open_file(filepath: str):
    os.startfile(filepath)
    return HTMLResponse(content='<span>Re</span>')


@router.get('/print-file/{filepath}', response_class=HTMLResponse)
async def print_file(filepath: str):
    os.startfile(filepath, 'print')
    return HTMLResponse(content='<span>Re</span>')


@router.post('/email-label', response_class=HTMLResponse)
async def email_label(
    label_path: str = Form(...), shipment_request: ShipmentRequest = Depends(shipment_request_form_json)
):
    label_path = Path(unquote(label_path))
    logger.info(f'Emailing {label_path=} to {shipment_request.shipment.remote_full_contact.contact.email}')
    await send_label_email(shipment_request, label_path)
    return HTMLResponse(content='<span>Re</span>')


@router.get('/health', response_class=JSONResponse)
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@router.get('/test', response_class=HTMLResponse)
async def test_route(request: ShipawRequest) -> HTMLResponse:
    shipment = sample_shipment()
    res = await shipping_form_api(request, shipment)
    return render_template_response(request, res)


@router.get('/', response_class=HTMLResponse)
async def test_route2(request: ShipawRequest) -> HTMLResponse:
    shipment = sample_shipment()
    res = await shipping_form_api(request, shipment)
    return render_template_response(request, res)
