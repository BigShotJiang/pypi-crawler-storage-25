"""Tests for AnthropicAdapter — the divergent-provider grounding.

Each test exercises a place where Anthropic diverges from the OpenAI shape, to
prove the protocol absorbs the divergence in the adapter layer (not the standard).
Uses httpx.MockTransport (no live keys).
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable

import httpx
import pytest
from keel_llm_protocol import (
    AuthenticationError,
    BadRequestError,
    ContextLengthError,
    ModelAdapter,
    RateLimitError,
    StreamingModelAdapter,
    ToolCallingModelAdapter,
    ToolSpec,
    TransientError,
    assistant,
    system,
    tool,
    user,
)
from keel_llm_protocol.errors import AdapterTimeoutError

from keel_llm_adapter_anthropic import AnthropicAdapter

Handler = Callable[[httpx.Request], httpx.Response]


def make_adapter(handler: Handler) -> AnthropicAdapter:
    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(base_url="https://api.test", transport=transport)
    return AnthropicAdapter(model="claude-x", provider="anthropic", client=client)


def _message(text: str = "hello", *, stop: str = "end_turn") -> dict[str, object]:
    return {
        "id": "msg_1",
        "type": "message",
        "role": "assistant",
        "model": "claude-x-20250101",
        "content": [{"type": "text", "text": text}],
        "stop_reason": stop,
        "usage": {"input_tokens": 12, "output_tokens": 5},
    }


# --------------------------------------------------------------------------- #
# Conformance
# --------------------------------------------------------------------------- #


def test_conforms_to_all_protocols() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_message()))
    assert isinstance(a, ModelAdapter)
    assert isinstance(a, StreamingModelAdapter)
    assert isinstance(a, ToolCallingModelAdapter)


# --------------------------------------------------------------------------- #
# Response parsing + stop_reason mapping
# --------------------------------------------------------------------------- #


def test_generate_parses_content_blocks() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_message("hi there")))
    resp = asyncio.run(a.generate([user("hello")]))
    assert resp.text == "hi there"
    assert resp.model_key == "anthropic:claude-x"
    assert resp.model_id == "claude-x-20250101"
    assert resp.finish_reason == "stop"
    assert resp.usage.input_tokens == 12
    assert resp.usage.output_tokens == 5


def test_stop_reason_mapping() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_message(stop="max_tokens")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "length"
    a2 = make_adapter(lambda req: httpx.Response(200, json=_message(stop="tool_use")))
    assert asyncio.run(a2.generate([user("x")])).finish_reason == "tool_calls"


# --------------------------------------------------------------------------- #
# Divergence #1 — system prompt becomes a top-level field, not a message
# --------------------------------------------------------------------------- #


def test_system_message_lifted_to_top_level() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_message())

    a = make_adapter(handler)
    asyncio.run(a.generate([system("be terse"), user("hello")]))
    assert captured["system"] == "be terse"
    # Only the user message remains in `messages`; system is NOT a message.
    assert captured["messages"] == [{"role": "user", "content": "hello"}]


# --------------------------------------------------------------------------- #
# Divergence #2 — max_tokens is required; default is supplied
# --------------------------------------------------------------------------- #


def test_max_tokens_default_supplied() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_message())

    a = make_adapter(handler)
    asyncio.run(a.generate([user("hello")]))
    assert captured["max_tokens"] == 4096  # default
    asyncio.run(a.generate([user("hello")], max_tokens=256))
    assert captured["max_tokens"] == 256


# --------------------------------------------------------------------------- #
# Divergence #3 — tool input is a dict; normalized to a JSON string
# --------------------------------------------------------------------------- #


def test_tool_use_input_dict_normalized_to_json_string() -> None:
    tool_msg = {
        "id": "msg_2",
        "type": "message",
        "role": "assistant",
        "model": "claude-x",
        "content": [
            {"type": "text", "text": "let me check"},
            {"type": "tool_use", "id": "tu_1", "name": "get_weather", "input": {"city": "SF"}},
        ],
        "stop_reason": "tool_use",
        "usage": {"input_tokens": 20, "output_tokens": 10},
    }
    a = make_adapter(lambda req: httpx.Response(200, json=tool_msg))
    spec = ToolSpec(name="get_weather", description="w", parameters={"type": "object"})
    resp = asyncio.run(a.generate_with_tools([user("weather?")], [spec]))
    assert resp.text == "let me check"
    assert resp.finish_reason == "tool_calls"
    assert resp.tool_calls[0].id == "tu_1"
    assert resp.tool_calls[0].name == "get_weather"
    # Anthropic gave a dict; the protocol's ToolCall.arguments is a JSON string.
    assert json.loads(resp.tool_calls[0].arguments) == {"city": "SF"}


def test_tools_serialized_with_input_schema() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_message(stop="tool_use"))

    a = make_adapter(handler)
    spec = ToolSpec(name="f", description="d", parameters={"type": "object"})
    asyncio.run(a.generate_with_tools([user("go")], [spec], tool_choice="required"))
    tools = captured["tools"]
    assert isinstance(tools, list)
    assert tools[0]["name"] == "f"
    assert tools[0]["input_schema"] == {"type": "object"}  # NOT "parameters"
    assert captured["tool_choice"] == {"type": "any"}  # "required" -> "any"


def test_tool_result_message_becomes_user_block() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_message())

    a = make_adapter(handler)
    convo = [
        user("weather?"),
        assistant("checking"),
        tool("72F and sunny", tool_call_id="tu_1"),
    ]
    asyncio.run(a.generate(convo))
    messages = captured["messages"]
    assert isinstance(messages, list)
    # tool message -> user message carrying a tool_result block
    assert messages[-1]["role"] == "user"
    assert messages[-1]["content"][0]["type"] == "tool_result"
    assert messages[-1]["content"][0]["tool_use_id"] == "tu_1"


# --------------------------------------------------------------------------- #
# Error taxonomy — including Anthropic's 529 overloaded
# --------------------------------------------------------------------------- #


def _err(status: int, message: str, etype: str = "invalid_request_error") -> Handler:
    return lambda req: httpx.Response(status, json={"type": "error", "error": {"type": etype, "message": message}})


def test_429_maps_to_rate_limit() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            429,
            headers={"retry-after": "5"},
            json={"type": "error", "error": {"type": "rate_limit_error", "message": "slow"}},
        )
    )
    with pytest.raises(RateLimitError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retry_after == 5.0
    assert exc.value.retryable is True


def test_401_maps_to_authentication() -> None:
    a = make_adapter(_err(401, "bad key", "authentication_error"))
    with pytest.raises(AuthenticationError):
        asyncio.run(a.generate([user("x")]))


def test_400_context_maps_to_context_length() -> None:
    a = make_adapter(_err(400, "prompt is too long: 250000 tokens"))
    with pytest.raises(ContextLengthError):
        asyncio.run(a.generate([user("x")]))


def test_400_other_maps_to_bad_request() -> None:
    a = make_adapter(_err(400, "missing field"))
    with pytest.raises(BadRequestError):
        asyncio.run(a.generate([user("x")]))


def test_500_maps_to_transient() -> None:
    a = make_adapter(_err(500, "api error", "api_error"))
    with pytest.raises(TransientError):
        asyncio.run(a.generate([user("x")]))


def test_529_overloaded_maps_to_transient() -> None:
    # Anthropic-specific overloaded status — must be treated as retryable backpressure.
    a = make_adapter(_err(529, "overloaded", "overloaded_error"))
    with pytest.raises(TransientError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is True


def test_timeout_maps_to_adapter_timeout() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("timed out", request=req)

    a = make_adapter(handler)
    with pytest.raises(AdapterTimeoutError):
        asyncio.run(a.generate([user("x")]))


# --------------------------------------------------------------------------- #
# Divergence #4 — Anthropic's distinct streaming event protocol
# --------------------------------------------------------------------------- #


def _sse(*events: dict[str, object]) -> bytes:
    out = []
    for e in events:
        out.append(f"event: {e['type']}\n")
        out.append(f"data: {json.dumps(e)}\n\n")
    return "".join(out).encode()


def test_stream_assembles_anthropic_events() -> None:
    events = [
        {"type": "message_start", "message": {"usage": {"input_tokens": 9}}},
        {"type": "content_block_start", "index": 0},
        {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "Hel"}},
        {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "lo"}},
        {"type": "content_block_stop", "index": 0},
        {"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 3}},
        {"type": "message_stop"},
    ]
    a = make_adapter(lambda req: httpx.Response(200, content=_sse(*events)))

    async def collect() -> list[object]:
        return [c async for c in a.stream([user("hi")])]

    chunks = asyncio.run(collect())
    assert "".join(c.delta for c in chunks) == "Hello"  # type: ignore[attr-defined]
    final = chunks[-1]
    assert final.finish_reason == "stop"  # type: ignore[attr-defined]
    assert final.usage is not None  # type: ignore[attr-defined]
    assert final.usage.input_tokens == 9  # from message_start  # type: ignore[attr-defined]
    assert final.usage.output_tokens == 3  # from message_delta  # type: ignore[attr-defined]


def test_stream_raises_taxonomy_on_error_status() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            429, json={"type": "error", "error": {"type": "rate_limit_error", "message": "slow"}}
        )
    )

    async def drain() -> None:
        async for _ in a.stream([user("hi")]):
            pass

    with pytest.raises(RateLimitError):
        asyncio.run(drain())


# --------------------------------------------------------------------------- #
# Health
# --------------------------------------------------------------------------- #


def test_health_check_ok() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json={"data": []}))
    assert asyncio.run(a.health_check()).healthy is True


# --------------------------------------------------------------------------- #
# No-silent-degradation — capabilities honestly exclude json (Anthropic's gap)
# --------------------------------------------------------------------------- #


def test_capabilities_exclude_native_json() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_message()))
    assert "streaming" in a.capabilities
    assert "tools" in a.capabilities
    # Anthropic has no native response_format — declared honestly, not silently ignored.
    assert "json_object" not in a.capabilities
    assert "json_schema" not in a.capabilities


def test_structured_output_degradation_is_visible() -> None:
    from keel_llm_protocol import ResponseFormat

    a = make_adapter(lambda req: httpx.Response(200, json=_message()))
    resp = asyncio.run(
        a.generate(
            [user("x")],
            response_format=ResponseFormat(type="json_schema", json_schema={"type": "object"}),
        )
    )
    # The consumer SEES that schema output was not honored, instead of trusting
    # text that was never constrained.
    assert resp.structured_output_honored is False


def test_unknown_stop_reason_surfaced() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_message(stop="some_future_reason")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "unknown"
