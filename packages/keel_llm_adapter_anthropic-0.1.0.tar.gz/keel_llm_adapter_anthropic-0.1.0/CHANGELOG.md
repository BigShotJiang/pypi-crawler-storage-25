# Changelog

All notable changes to `keel-llm-adapter-anthropic` are documented here, following
[Keep a Changelog](https://keepachangelog.com/). In `0.x`; pin exact versions.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- `AnthropicAdapter` for Anthropic's `POST /v1/messages` API. Implements
  `ModelAdapter`, `StreamingModelAdapter`, and `ToolCallingModelAdapter`.
- Handles Anthropic's divergences from the OpenAI shape entirely in the adapter
  layer: system prompt lifted to the top-level `system` field; `tool` messages →
  `tool_result` blocks and assistant `tool_calls` → `tool_use` blocks; tool input
  dict ↔ `ToolCall.arguments` JSON-string normalization; `input_schema` + Anthropic
  `tool_choice` mapping; required `max_tokens` default; the `message_start` /
  `content_block_delta` / `message_delta` SSE protocol → `StreamChunk`; `529
  overloaded` → retryable `TransientError`; the `{"type":"error",...}` envelope and
  `stop_reason` values → the standard error taxonomy + `FinishReason`.
- PEP 561 `py.typed`; `mypy --strict` clean. Tested against `httpx.MockTransport`.

### Notes

- This is the **divergent-provider grounding**: it validates that
  `keel-llm-protocol` generalizes beyond the OpenAI-compatible family without
  changing the standard.
- Finding: Anthropic has no native `response_format`, so the adapter treats it as
  a best-effort hint. Confirms that `response_format` in the standard is a request,
  not a guarantee.
