"""Reference ``keel-llm-protocol`` adapter for Anthropic's Messages API.

This is the **divergent-provider grounding** for the protocol standard. Where
``keel-llm-adapter-openai`` proves the standard against the OpenAI-compatible
family, this proves it against an API that diverges deliberately:

- the system prompt is a top-level ``system`` field, not a ``system`` message;
- tool inputs arrive as parsed ``dict`` objects, not JSON strings;
- streaming uses a distinct event protocol (``message_start`` /
  ``content_block_delta`` / ``message_delta``);
- there's an Anthropic-specific ``529 overloaded`` status;
- the error envelope is ``{"type":"error","error":{"type","message"}}``.

Every one of those is absorbed *here, in the adapter* — the protocol's types
(``Message`` roles, ``ToolCall.arguments`` as a JSON string, ``StreamChunk``, the
error taxonomy, ``FinishReason``) accommodate Anthropic without changing. That is
the standard generalizing.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator, Sequence
from typing import Any

import httpx
from keel_llm_protocol import (
    AdapterResponse,
    AuthenticationError,
    BadRequestError,
    Capability,
    ContextLengthError,
    HealthStatus,
    Message,
    RateLimitError,
    ResponseFormat,
    StreamChunk,
    ToolCall,
    ToolSpec,
    TransientError,
)
from keel_llm_protocol.errors import AdapterTimeoutError, ProviderError
from keel_llm_protocol.responses import FinishReason, Usage

__all__ = ["AnthropicAdapter"]

# Anthropic honors streaming + tools, but has NO native response_format — so
# json_object / json_schema are deliberately absent. A consumer checking
# `capabilities` sees this up front instead of silently getting unconstrained text.
_DEFAULT_CAPABILITIES: frozenset[Capability] = frozenset({"streaming", "tools"})

_DEFAULT_BASE_URL = "https://api.anthropic.com"
_DEFAULT_VERSION = "2023-06-01"

# Anthropic stop_reason -> keel FinishReason
_STOP: dict[str, FinishReason] = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
}


class AnthropicAdapter:
    """Adapter for Anthropic's ``POST /v1/messages`` API."""

    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        anthropic_version: str = _DEFAULT_VERSION,
        default_max_tokens: int = 4096,
        provider: str = "anthropic",
        timeout: float = 60.0,
        capabilities: frozenset[Capability] | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._model = model
        self._model_key = f"{provider}:{model}"
        self._default_max_tokens = default_max_tokens
        self._capabilities = (
            capabilities if capabilities is not None else _DEFAULT_CAPABILITIES
        )
        if client is not None:
            self._client = client
        else:
            headers = {"anthropic-version": anthropic_version}
            if api_key:
                headers["x-api-key"] = api_key
            self._client = httpx.AsyncClient(
                base_url=base_url.rstrip("/"), timeout=timeout, headers=headers
            )

    @property
    def model_key(self) -> str:
        return self._model_key

    @property
    def capabilities(self) -> frozenset[Capability]:
        return self._capabilities

    async def aclose(self) -> None:
        await self._client.aclose()

    def _honored(self, rf: ResponseFormat | None) -> bool | None:
        if rf is None or rf.type == "text":
            return None
        needed: Capability = "json_object" if rf.type == "json_object" else "json_schema"
        return needed in self._capabilities

    # -- ModelAdapter -------------------------------------------------------

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        # Anthropic has no native response_format — structured output is via tools
        # or prompt. Rather than silently ignore it, we don't claim json capability
        # (see capabilities) and surface the degradation via structured_output_honored.
        resp = await self._complete(self._body(messages, temperature, max_tokens, stop))
        resp.structured_output_honored = self._honored(response_format)
        return resp

    async def health_check(self) -> HealthStatus:
        t0 = time.monotonic()
        try:
            resp = await self._client.get("/v1/models")
        except httpx.HTTPError as exc:
            return HealthStatus(self._model_key, healthy=False, error=str(exc))
        latency = int((time.monotonic() - t0) * 1000)
        ok = resp.status_code < 400
        return HealthStatus(
            self._model_key,
            healthy=ok,
            latency_ms=latency,
            error="" if ok else f"HTTP {resp.status_code}",
        )

    # -- ToolCallingModelAdapter -------------------------------------------

    async def generate_with_tools(
        self,
        messages: Sequence[Message],
        tools: Sequence[ToolSpec],
        *,
        tool_choice: str = "auto",
        temperature: float | None = None,
        max_tokens: int | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        body = self._body(messages, temperature, max_tokens, None)
        body["tools"] = [
            {"name": t.name, "description": t.description, "input_schema": t.parameters}
            for t in tools
        ]
        if tool_choice == "auto":
            body["tool_choice"] = {"type": "auto"}
        elif tool_choice == "required":
            body["tool_choice"] = {"type": "any"}
        elif tool_choice != "none":
            body["tool_choice"] = {"type": "tool", "name": tool_choice}
        resp = await self._complete(body)
        resp.structured_output_honored = self._honored(response_format)
        return resp

    # -- StreamingModelAdapter ---------------------------------------------

    async def stream(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        body = self._body(messages, temperature, max_tokens, stop)
        body["stream"] = True
        input_tokens = 0
        async with self._client.stream("POST", "/v1/messages", json=body) as resp:
            if resp.status_code >= 400:
                await resp.aread()
                self._raise(resp)
            async for line in resp.aiter_lines():
                line = line.strip()
                if not line.startswith("data:"):
                    continue
                payload = line[len("data:") :].strip()
                if not payload:
                    continue
                event: dict[str, Any] = json.loads(payload)
                kind = event.get("type")
                if kind == "message_start":
                    input_tokens = (
                        event.get("message", {}).get("usage", {}).get("input_tokens", 0)
                    )
                elif kind == "content_block_delta":
                    delta: dict[str, Any] = event.get("delta", {})
                    if delta.get("type") == "text_delta":
                        yield StreamChunk(delta=delta.get("text", ""))
                elif kind == "message_delta":
                    stop_reason = event.get("delta", {}).get("stop_reason")
                    out_tokens = event.get("usage", {}).get("output_tokens", 0)
                    yield StreamChunk(
                        finish_reason=_STOP.get(stop_reason, "unknown") if stop_reason else None,
                        usage=Usage(input_tokens=input_tokens, output_tokens=out_tokens),
                    )

    # -- internals ----------------------------------------------------------

    def _body(
        self,
        messages: Sequence[Message],
        temperature: float | None,
        max_tokens: int | None,
        stop: Sequence[str] | None,
    ) -> dict[str, Any]:
        # Anthropic divergence #1: system is top-level, not a message.
        system_parts = [m.content for m in messages if m.role == "system" and m.content]
        body: dict[str, Any] = {
            "model": self._model,
            "messages": [self._wire_message(m) for m in messages if m.role != "system"],
            # Anthropic divergence #2: max_tokens is required.
            "max_tokens": max_tokens if max_tokens is not None else self._default_max_tokens,
        }
        if system_parts:
            body["system"] = "\n\n".join(system_parts)
        if temperature is not None:
            body["temperature"] = temperature
        if stop:
            body["stop_sequences"] = list(stop)
        return body

    @staticmethod
    def _wire_message(m: Message) -> dict[str, Any]:
        # Anthropic has only user/assistant roles; tool results and tool calls
        # are content blocks, not roles.
        if m.role == "tool":
            return {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": m.tool_call_id, "content": m.content}
                ],
            }
        if m.role == "assistant" and m.tool_calls:
            blocks: list[dict[str, Any]] = []
            if m.content:
                blocks.append({"type": "text", "text": m.content})
            for tc in m.tool_calls:
                # Anthropic divergence #3: tool input is a dict, not a JSON string.
                blocks.append(
                    {
                        "type": "tool_use",
                        "id": tc.id,
                        "name": tc.name,
                        "input": json.loads(tc.arguments) if tc.arguments else {},
                    }
                )
            return {"role": "assistant", "content": blocks}
        return {"role": m.role, "content": m.content}

    async def _complete(self, body: dict[str, Any]) -> AdapterResponse:
        t0 = time.monotonic()
        try:
            resp = await self._client.post("/v1/messages", json=body)
        except httpx.TimeoutException as exc:
            raise AdapterTimeoutError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        except httpx.HTTPError as exc:
            raise TransientError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        if resp.status_code >= 400:
            self._raise(resp)
        return self._parse_response(resp.json(), int((time.monotonic() - t0) * 1000))

    def _parse_response(self, data: dict[str, Any], latency_ms: int) -> AdapterResponse:
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text_parts.append(block.get("text", ""))
            elif block.get("type") == "tool_use":
                # Normalize Anthropic's dict input to the protocol's JSON-string arguments.
                tool_calls.append(
                    ToolCall(
                        id=block.get("id", ""),
                        name=block.get("name", ""),
                        arguments=json.dumps(block.get("input", {})),
                    )
                )
        usage_raw: dict[str, Any] = data.get("usage") or {}
        raw_stop = data.get("stop_reason")
        # Present-but-unmapped stop reasons surface as "unknown", never as "stop".
        finish: FinishReason = _STOP.get(raw_stop, "unknown") if raw_stop else "stop"
        return AdapterResponse(
            text="".join(text_parts),
            model_key=self._model_key,
            model_id=data.get("model", self._model),
            finish_reason=finish,
            usage=Usage(
                input_tokens=usage_raw.get("input_tokens", 0),
                output_tokens=usage_raw.get("output_tokens", 0),
            ),
            tool_calls=tool_calls,
            latency_ms=latency_ms,
            raw_response=data,
        )

    def _raise(self, resp: httpx.Response) -> None:
        status = resp.status_code
        message = self._error_message(resp)
        kw: dict[str, Any] = {
            "model_key": self._model_key,
            "status_code": status,
            "provider_error": _safe_text(resp),
        }
        if status == 429:
            raise RateLimitError(message, retry_after=_retry_after(resp), **kw)
        if status in (401, 403):
            raise AuthenticationError(message, **kw)
        if status == 400:
            lowered = message.lower()
            if "prompt is too long" in lowered or "context" in lowered and "long" in lowered:
                raise ContextLengthError(message, **kw)
            raise BadRequestError(message, **kw)
        # 529 is Anthropic's "overloaded" — transient backpressure, retryable.
        if status >= 500:
            raise TransientError(message, **kw)
        raise ProviderError(message or f"HTTP {status}", **kw)

    @staticmethod
    def _error_message(resp: httpx.Response) -> str:
        try:
            body: dict[str, Any] = resp.json()
        except (ValueError, json.JSONDecodeError):
            return _safe_text(resp)
        err = body.get("error")
        if isinstance(err, dict):
            msg = err.get("message")
            if msg:
                return str(msg)
        return _safe_text(resp)


def _retry_after(resp: httpx.Response) -> float | None:
    raw = resp.headers.get("retry-after")
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _safe_text(resp: httpx.Response) -> str:
    try:
        return resp.text
    except Exception:  # pragma: no cover - defensive
        return ""
