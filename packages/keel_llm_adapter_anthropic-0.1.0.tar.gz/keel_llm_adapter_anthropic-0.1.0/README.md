# keel-llm-adapter-anthropic

> A reference [`keel-llm-protocol`](https://github.com/keelplatform/keel/tree/main/py/packages/llm-protocol) adapter for Anthropic's Messages API (Claude).

This package is the **divergent-provider grounding** for the protocol standard. Where [`keel-llm-adapter-openai`](https://github.com/keelplatform/keel/tree/main/py/packages/llm-adapter-openai) proves the standard against the OpenAI-compatible family, this proves it against an API that diverges on purpose — and the protocol absorbs every difference *in the adapter*, without changing the standard. That is the standard generalizing.

## Install

```bash
pip install keel-llm-adapter-anthropic     # pulls in keel-llm-protocol + httpx
```

## Use

```python
from keel_llm_adapter_anthropic import AnthropicAdapter
from keel_llm_protocol import system, user

adapter = AnthropicAdapter(model="claude-sonnet-4-5", api_key="...", provider="anthropic")
resp = await adapter.generate([system("Be terse."), user("What is a circuit breaker?")])
print(resp.text, resp.usage.total_tokens, resp.finish_reason)
```

Same `keel-llm-protocol` types as every other adapter — swap `AnthropicAdapter` for `OpenAIAdapter` and your code is unchanged. It implements `ModelAdapter`, `StreamingModelAdapter`, and `ToolCallingModelAdapter`.

## How Anthropic diverges — and where it's handled

Every divergence below is absorbed inside the adapter; the protocol's types are untouched:

| Anthropic divergence | Protocol stays the same because… |
|---|---|
| System prompt is a top-level `system` field, not a message | the adapter lifts `Message(role="system")` into the `system` param |
| Only `user` / `assistant` roles exist | `tool` messages → `tool_result` content blocks; assistant `tool_calls` → `tool_use` blocks |
| Tool input arrives as a parsed `dict` | the adapter `json.dumps` it into `ToolCall.arguments` (a JSON string) |
| Tools use `input_schema` + `tool_choice: {type: auto\|any\|tool}` | the adapter maps `ToolSpec` / `tool_choice` accordingly |
| `max_tokens` is required | the adapter supplies `default_max_tokens` (4096) when unset |
| Distinct SSE events (`message_start` / `content_block_delta` / `message_delta`) | the adapter maps them onto `StreamChunk` |
| `529 overloaded` status | mapped to retryable `TransientError` |
| `{"type":"error","error":{...}}` envelope + `stop_reason` values | mapped to the standard error taxonomy + `FinishReason` |

## Known limitation

Anthropic has no native `response_format` parameter — structured output is done via tools or prompt instructions. This adapter therefore treats `ResponseFormat` as a best-effort hint and does not enforce it. (A finding worth keeping: in the standard, `response_format` is a request, not a guarantee — provider support varies.)

## Status

`0.1.0` — first release. Pin exact versions while in `0.x`. Source: [Keel monorepo](https://github.com/keelplatform/keel/tree/main/py/packages/llm-adapter-anthropic).

## License

MIT — see [LICENSE](https://github.com/keelplatform/keel/blob/main/LICENSE).
