"""Tests for RFControl"""
