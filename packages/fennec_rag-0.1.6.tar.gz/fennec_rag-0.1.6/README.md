# 🦊 fennec-rag

A comprehensive, production-ready **Retrieval-Augmented Generation (RAG)** framework with first-class **Arabic language support**.

[![PyPI version](https://badge.fury.io/py/fennec-rag.svg)](https://badge.fury.io/py/fennec-rag)
[![Python](https://img.shields.io/pypi/pyversions/fennec-rag)](https://pypi.org/project/fennec-rag/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

- 🌍 **Arabic-first NLP** — dedicated Arabic chunker, embedder, and prompt templates
- 🔌 **Multi-provider LLMs** — OpenAI, Anthropic, Gemini, Mistral, HuggingFace, Ollama
- 🗄️ **Multiple vector databases** — FAISS, ChromaDB, Pinecone
- 🧩 **Advanced RAG strategies** — Conversational, Agentic, Graph, Multi-hop, Federated, Self-improving, Streaming
- 🛡️ **Hallucination Guard** — built-in hallucination detection and grounding
- 📊 **Observability & Evaluation** — tracing, metrics, dashboards, evaluation suite
- 📄 **Rich document loaders** — PDF, DOCX, HTML, CSV, JSON, Excel, Web, Directory

## 📦 Installation

```bash
# Basic
pip install fennec-rag

# With specific providers
pip install "fennec-rag[openai,faiss]"
pip install "fennec-rag[anthropic,chroma]"
pip install "fennec-rag[gemini,pinecone]"

# Arabic NLP
pip install "fennec-rag[arabic]"

# Full install
pip install "fennec-rag[all]"
```

## 🚀 Quick Start

```python
from fennec.rag.core import RAGSystem, RAGConfig
from fennec.embeddings import OpenAIEmbedder
from fennec.vector_database import FAISSVectorDatabase
from fennec.llm import OpenAIInterface

embedder = OpenAIEmbedder(api_key="your-key")
vector_db = FAISSVectorDatabase(embedder=embedder)
llm = OpenAIInterface(api_key="your-key")

config = RAGConfig(chunk_size=512, overlap=128, top_k=5)
rag = RAGSystem(config=config, vector_db=vector_db, llm=llm)

rag.load_documents(["document.pdf"])
response = rag.query("What is the main topic?")
print(response)
```

## 🗂️ Modules

| Module | Description |
|--------|-------------|
| `fennec.rag.core` | RAGSystem, MultiDocRAG, Reranker, PromptRouter |
| `fennec.rag.conversational_rag` | Multi-turn conversation RAG |
| `fennec.rag.agentic_rag` | Agent-based RAG |
| `fennec.rag.graph_rag` | Knowledge graph RAG |
| `fennec.rag.hybrid_search` | BM25 + semantic hybrid search |
| `fennec.rag.multi_hop` | Multi-hop question decomposition |
| `fennec.rag.self_improving_rag` | HyDE + recursive refinement |
| `fennec.rag.streaming_rag` | Token streaming |
| `fennec.embeddings` | OpenAI, Gemini, HuggingFace, Mistral, Ollama, Arabic |
| `fennec.vector_database` | FAISS, ChromaDB, Pinecone |
| `fennec.llm` | OpenAI, Anthropic, Gemini, Mistral, HuggingFace, Ollama |
| `fennec.llm.hallucination` | HallucinationGuard, ProtectedLLMInterface |
| `fennec.chunks` | Arabic & multilingual text chunkers |
| `fennec.document_loaders` | PDF, DOCX, HTML, CSV, JSON, Excel, Web, Directory |
| `fennec.memory` | Buffer, Window, Summary, Entity memory |
| `fennec.router` | SemanticRouter |
| `fennec.prompt` | PromptTemplate, ChatTemplate, FewShotTemplate |
| `fennec.output_parser` | JSON, YAML, CSV, Pydantic parsers |
| `fennec.evaluator` | RAG evaluation & reporting |
| `fennec.observability` | Tracing, metrics, dashboards |
| `fennec.cache` | Multi-level cache |
| `fennec.persistence` | State persistence & backup |
| `fennec.plugins` | Extensible plugin system |

## 📝 License

MIT License
