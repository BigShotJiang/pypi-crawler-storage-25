"""
fennec-rag: A comprehensive RAG framework with Arabic language support.

Install:  pip install fennec-rag
Import:   import fennec
"""

__version__ = "0.1.1"
__author__ = "fennec-rag"
__license__ = "MIT"
