"""chatgame 通用工具模块。"""
