from abc import ABC, abstractmethod
from typing import Any


class ConfigContract(ABC):

    @abstractmethod
    def get(self, key: str, default: Any = None) -> Any: ...

    @abstractmethod
    def set(self, key: str, value: Any) -> None: ...

    @abstractmethod
    def has(self, key: str) -> bool: ...

    @abstractmethod
    def integer(self, key: str, default: int = 0) -> int: ...

    @abstractmethod
    def boolean(self, key: str, default: bool = False) -> bool: ...

    @abstractmethod
    def string(self, key: str, default: str = "") -> str: ...

    @abstractmethod
    def all(self) -> dict: ...
