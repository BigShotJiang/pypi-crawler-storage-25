def map_key(name: str, separator: str = "_", depth: int = 1) -> str:
    """Convert an environment variable name to a dot-notation config key.

    Examples (depth=1):
        DATABASE_HOST   -> database.host
        REDIS_CACHE_TTL -> redis.cache_ttl
        APP_DEBUG       -> app.debug
        PATH            -> path

    Examples (depth=2):
        CACHE_REDIS_HOST -> cache.redis.host
    """
    lower = name.lower()
    parts = lower.split(separator)

    if len(parts) <= depth:
        return ".".join(parts)

    namespace_parts = parts[:depth]
    key_parts = parts[depth:]

    namespace = ".".join(namespace_parts)
    leaf = separator.join(key_parts)
    return f"{namespace}.{leaf}"
