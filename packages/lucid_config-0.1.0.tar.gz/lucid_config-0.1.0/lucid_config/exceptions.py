class MissingConfigError(Exception):
    """Raised when required config keys are missing."""


class ConfigFrozenError(Exception):
    """Raised when attempting to mutate a frozen config."""
