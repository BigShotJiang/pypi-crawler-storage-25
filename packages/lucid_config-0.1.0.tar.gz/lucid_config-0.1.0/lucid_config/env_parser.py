import os
import re


def parse_env_file(path: str) -> dict[str, str]:
    """Parse a .env file and return a flat dict of string key-value pairs."""
    with open(path, "r") as f:
        content = f.read()
    return parse_env_string(content)


def parse_env_string(content: str) -> dict[str, str]:
    """Parse .env-formatted content and return a flat dict."""
    result: dict[str, str] = {}
    lines = content.splitlines(keepends=True)
    i = 0

    while i < len(lines):
        line = lines[i].rstrip("\n").rstrip("\r")
        stripped = line.strip()

        # Skip blank lines and comments
        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        # Strip export prefix
        if stripped.startswith("export ") or stripped.startswith("export\t"):
            stripped = stripped[7:].strip()

        # Must contain =
        if "=" not in stripped:
            i += 1
            continue

        key, _, value = stripped.partition("=")
        key = key.strip()
        value = value.strip()

        # Handle quoted values
        if value and value[0] in ('"', "'"):
            quote_char = value[0]
            # Try to find closing quote on the same line
            end_idx = value.find(quote_char, 1)
            if end_idx != -1:
                # Single-line quoted value
                value = value[1:end_idx]
            else:
                # Multiline quoted value
                multiline_parts = [value[1:]]  # Remove opening quote
                i += 1
                while i < len(lines):
                    next_line = lines[i].rstrip("\n").rstrip("\r")
                    if quote_char in next_line:
                        close_idx = next_line.index(quote_char)
                        multiline_parts.append(next_line[:close_idx])
                        break
                    else:
                        multiline_parts.append(next_line)
                    i += 1
                value = "\n".join(multiline_parts)

            # Variable interpolation only for double-quoted and unquoted values
            if quote_char == '"':
                value = _interpolate(value, result)
        else:
            # Unquoted value — strip inline comments
            if " #" in value:
                value = value[: value.index(" #")].rstrip()

            # Variable interpolation
            value = _interpolate(value, result)

        result[key] = value
        i += 1

    return result


def _interpolate(value: str, loaded: dict[str, str]) -> str:
    """Replace ${VAR} references with values from loaded dict or os.environ."""

    def _replace(match: re.Match[str]) -> str:
        var_name = match.group(1)
        if var_name in loaded:
            return loaded[var_name]
        return os.environ.get(var_name, "")

    return re.sub(r"\$\{([^}]+)\}", _replace, value)
