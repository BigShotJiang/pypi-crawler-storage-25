from __future__ import annotations

import copy
import json
import os
from typing import Any

from .contract import ConfigContract
from .exceptions import ConfigFrozenError, MissingConfigError
from .key_mapper import map_key


class Config(ConfigContract):
    """Cascading configuration with dot-notation access and type casting."""

    def __init__(self, initial: dict | None = None) -> None:
        self._store: dict = {}
        self._frozen: bool = False
        if initial is not None:
            self._deep_merge(self._store, initial)

    # ------------------------------------------------------------------
    # Core access
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        if not isinstance(key, str):
            raise TypeError(
                f"Config key must be a string, got {type(key).__name__}"
            )
        keys = key.split(".")
        current: Any = self._store
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return default
        return current

    def set(self, key: str, value: Any) -> None:
        self._check_frozen()
        keys = key.split(".")
        current = self._store
        for k in keys[:-1]:
            if k not in current or not isinstance(current[k], dict):
                current[k] = {}
            current = current[k]
        current[keys[-1]] = value

    def has(self, key: str) -> bool:
        keys = key.split(".")
        current: Any = self._store
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return False
        return True

    def all(self) -> dict:
        return copy.deepcopy(self._store)

    def forget(self, key: str) -> None:
        self._check_frozen()
        keys = key.split(".")
        current: Any = self._store
        for k in keys[:-1]:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return
        if isinstance(current, dict) and keys[-1] in current:
            del current[keys[-1]]

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------

    def merge(self, data: dict) -> None:
        self._check_frozen()
        self._deep_merge(self._store, data)

    # ------------------------------------------------------------------
    # Type casting
    # ------------------------------------------------------------------

    def string(self, key: str, default: str = "") -> str:
        value = self.get(key)
        if value is None:
            return default
        return str(value)

    def integer(self, key: str, default: int = 0) -> int:
        value = self.get(key)
        if value is None:
            return default
        return int(value)

    def float(self, key: str, default: float = 0.0) -> float:
        value = self.get(key)
        if value is None:
            return default
        return float(value)

    def boolean(self, key: str, default: bool = False) -> bool:
        value = self.get(key)
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.lower() in ("true", "1", "yes", "on"):
                return True
            if value.lower() in ("false", "0", "no", "off", ""):
                return False
        return bool(value)

    def list(self, key: str, default: Any = None, delimiter: str = ",") -> Any:
        value = self.get(key)
        if value is None:
            return default
        if isinstance(value, list):
            return value
        if isinstance(value, str):
            return [item.strip() for item in value.split(delimiter)]
        return [value]

    # ------------------------------------------------------------------
    # Environment loading
    # ------------------------------------------------------------------

    def load_env(
        self,
        path: str,
        override: bool = True,
        separator: str = "_",
        depth: int = 1,
    ) -> None:
        self._check_frozen()
        from .env_parser import parse_env_file

        raw = parse_env_file(path)
        for env_key, env_value in raw.items():
            config_key = map_key(env_key, separator=separator, depth=depth)
            if override or not self.has(config_key):
                self.set(config_key, env_value)

    def load_env_vars(self, prefix: str | None = None) -> None:
        self._check_frozen()
        for env_key, env_value in os.environ.items():
            if prefix is not None:
                if not env_key.startswith(prefix + "_"):
                    continue
            config_key = map_key(env_key)
            self.set(config_key, env_value)

    def load_env_prefix(self, prefix: str) -> None:
        self.load_env_vars(prefix=prefix)

    # ------------------------------------------------------------------
    # File loading
    # ------------------------------------------------------------------

    def load_dict(self, data: dict) -> None:
        self._check_frozen()
        self._deep_merge(self._store, data)

    def load_json(self, path: str) -> None:
        self._check_frozen()
        with open(path, "r") as f:
            data = json.load(f)
        self._deep_merge(self._store, data)

    def load_toml(self, path: str) -> None:
        self._check_frozen()
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[no-redef]
            except ImportError:
                raise ImportError(
                    "TOML support requires Python 3.11+ or the 'tomli' package. "
                    "Install it with: pip install tomli"
                )
        with open(path, "rb") as f:
            data = tomllib.load(f)
        self._deep_merge(self._store, data)

    def load_yaml(self, path: str) -> None:
        self._check_frozen()
        try:
            import yaml  # type: ignore[import-untyped]
        except ImportError:
            raise ImportError(
                "YAML support requires the 'pyyaml' package. "
                "Install it with: pip install pyyaml"
            )
        with open(path, "r") as f:
            data = yaml.safe_load(f)
        self._deep_merge(self._store, data)

    # ------------------------------------------------------------------
    # Immutability
    # ------------------------------------------------------------------

    def freeze(self) -> None:
        self._frozen = True

    @property
    def is_frozen(self) -> bool:
        return self._frozen

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def require(self, *keys: str) -> None:
        missing = [key for key in keys if not self.has(key)]
        if missing:
            raise MissingConfigError(
                f"Missing required config keys: {', '.join(missing)}"
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _check_frozen(self) -> None:
        if self._frozen:
            raise ConfigFrozenError("Cannot modify frozen config")

    def _deep_merge(self, base: dict, override: dict) -> dict:
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
        return base
