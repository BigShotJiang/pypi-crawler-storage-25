from lucid_config.key_mapper import map_key


class TestKeyMapping:
    def test_single_word(self):
        assert map_key("PATH") == "path"

    def test_two_parts(self):
        assert map_key("DATABASE_HOST") == "database.host"

    def test_three_parts_depth_1(self):
        assert map_key("REDIS_CACHE_TTL") == "redis.cache_ttl"

    def test_three_parts_depth_2(self):
        assert map_key("CACHE_REDIS_HOST", depth=2) == "cache.redis.host"

    def test_app_prefix(self):
        assert map_key("APP_DEBUG") == "app.debug"
        assert map_key("APP_NAME") == "app.name"

    def test_case_insensitive(self):
        assert map_key("DATABASE_HOST") == map_key("database_host")

    def test_myapp_prefix(self):
        assert map_key("MYAPP_DB_HOST") == "myapp.db_host"

    def test_many_underscores_depth_1(self):
        assert map_key("APP_SOME_LONG_KEY_NAME") == "app.some_long_key_name"

    def test_depth_3(self):
        assert map_key("A_B_C_D_E", depth=3) == "a.b.c.d_e"

    def test_fewer_parts_than_depth(self):
        assert map_key("APP_DEBUG", depth=5) == "app.debug"
