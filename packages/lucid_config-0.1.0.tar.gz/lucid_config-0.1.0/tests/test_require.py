import pytest

from lucid_config import Config, MissingConfigError


class TestRequire:
    def test_all_present_no_raise(self):
        config = Config({
            "database": {"host": "localhost", "name": "mydb"},
            "app": {"secret_key": "secret"},
        })
        config.require("database.host", "database.name", "app.secret_key")

    def test_one_missing_raises(self):
        config = Config({"database": {"host": "localhost"}})
        with pytest.raises(MissingConfigError, match="database.name"):
            config.require("database.host", "database.name")

    def test_multiple_missing_lists_all(self):
        config = Config()
        with pytest.raises(MissingConfigError) as exc_info:
            config.require("database.host", "database.name", "app.secret_key")
        message = str(exc_info.value)
        assert "database.host" in message
        assert "database.name" in message
        assert "app.secret_key" in message

    def test_checks_dot_notation(self):
        config = Config({"database": {"host": "localhost"}})
        config.require("database.host")  # should not raise
        with pytest.raises(MissingConfigError):
            config.require("database.port")
