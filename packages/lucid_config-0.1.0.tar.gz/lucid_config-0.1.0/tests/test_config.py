from lucid_config import Config


class TestGet:
    def test_get_top_level_key(self):
        config = Config({"name": "my-app"})
        assert config.get("name") == "my-app"

    def test_get_nested_dot_notation_key(self):
        config = Config({"database": {"host": "localhost"}})
        assert config.get("database.host") == "localhost"

    def test_get_returns_default_when_missing(self):
        config = Config()
        assert config.get("missing", "fallback") == "fallback"

    def test_get_returns_none_when_missing_no_default(self):
        config = Config()
        assert config.get("missing") is None

    def test_get_namespace_returns_sub_dict(self):
        config = Config({"database": {"host": "localhost", "port": 5432}})
        result = config.get("database")
        assert result == {"host": "localhost", "port": 5432}


class TestSet:
    def test_set_top_level_key(self):
        config = Config()
        config.set("name", "my-app")
        assert config.get("name") == "my-app"

    def test_set_creates_nested_key_with_intermediates(self):
        config = Config()
        config.set("services.payment.timeout", 60)
        assert config.get("services.payment.timeout") == 60

    def test_set_overwrites_existing_value(self):
        config = Config({"name": "old"})
        config.set("name", "new")
        assert config.get("name") == "new"


class TestHas:
    def test_has_returns_true_for_existing(self):
        config = Config({"name": "app"})
        assert config.has("name") is True

    def test_has_returns_true_for_none_value(self):
        config = Config({"key": None})
        assert config.has("key") is True

    def test_has_returns_true_for_false_value(self):
        config = Config({"debug": False})
        assert config.has("debug") is True

    def test_has_returns_false_for_missing(self):
        config = Config()
        assert config.has("missing") is False

    def test_has_works_with_dot_notation(self):
        config = Config({"database": {"host": "localhost"}})
        assert config.has("database.host") is True
        assert config.has("database.port") is False


class TestForget:
    def test_forget_removes_key(self):
        config = Config({"name": "app", "debug": True})
        config.forget("debug")
        assert config.has("debug") is False
        assert config.has("name") is True

    def test_forget_removes_namespace_and_children(self):
        config = Config({"database": {"host": "localhost", "port": 5432}})
        config.forget("database")
        assert config.has("database") is False
        assert config.has("database.host") is False

    def test_forget_missing_key_is_noop(self):
        config = Config({"name": "app"})
        config.forget("missing")  # should not raise
        assert config.get("name") == "app"


class TestAll:
    def test_all_returns_complete_dict(self):
        data = {"app": {"name": "test"}, "db": {"host": "localhost"}}
        config = Config(data)
        assert config.all() == data

    def test_all_returns_copy_not_reference(self):
        config = Config({"app": {"name": "test"}})
        result = config.all()
        result["app"]["name"] = "mutated"
        assert config.get("app.name") == "test"
