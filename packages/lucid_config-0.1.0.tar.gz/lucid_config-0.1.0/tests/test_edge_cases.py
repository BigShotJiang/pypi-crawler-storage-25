import pytest

from lucid_config import Config


class TestEmptyConfig:
    def test_get_returns_default(self):
        config = Config()
        assert config.get("anything") is None
        assert config.get("anything", "default") == "default"

    def test_all_returns_empty_dict(self):
        config = Config()
        assert config.all() == {}


class TestSpecialValues:
    def test_none_value(self):
        config = Config({"key": None})
        assert config.get("key") is None
        assert config.has("key") is True

    def test_false_value(self):
        config = Config({"key": False})
        assert config.get("key") is False
        assert config.has("key") is True

    def test_zero_value(self):
        config = Config({"key": 0})
        assert config.get("key") == 0
        assert config.has("key") is True

    def test_empty_string_value(self):
        config = Config({"key": ""})
        assert config.get("key") == ""
        assert config.has("key") is True

    def test_dots_in_value(self):
        config = Config({"url": "https://example.com"})
        assert config.get("url") == "https://example.com"


class TestSettingDictValue:
    def test_set_dict_enables_dot_access(self):
        config = Config()
        config.set("database", {"host": "localhost", "port": 5432})
        assert config.get("database.host") == "localhost"
        assert config.get("database.port") == 5432


class TestTypeErrors:
    def test_non_string_key_raises(self):
        config = Config()
        with pytest.raises(TypeError):
            config.get(123)  # type: ignore[arg-type]


class TestDeeplyNested:
    def test_ten_plus_levels(self):
        config = Config()
        config.set("a.b.c.d.e.f.g.h.i.j.k.l", "deep")
        assert config.get("a.b.c.d.e.f.g.h.i.j.k.l") == "deep"


class TestUnicode:
    def test_unicode_keys_and_values(self):
        config = Config({"grüße": {"名前": "テスト"}})
        assert config.get("grüße.名前") == "テスト"


class TestMutationSafety:
    def test_all_does_not_expose_internal_store(self):
        config = Config({"app": {"name": "test"}})
        snapshot = config.all()
        snapshot["app"]["name"] = "mutated"
        snapshot["new_key"] = "injected"
        assert config.get("app.name") == "test"
        assert config.has("new_key") is False
