import os

import pytest

from lucid_config.env_parser import parse_env_file, parse_env_string


class TestBasicParsing:
    def test_key_value(self):
        result = parse_env_string("KEY=value")
        assert result == {"KEY": "value"}

    def test_double_quoted(self):
        result = parse_env_string('KEY="hello world"')
        assert result == {"KEY": "hello world"}

    def test_single_quoted(self):
        result = parse_env_string("KEY='hello world'")
        assert result == {"KEY": "hello world"}

    def test_blank_lines_ignored(self):
        result = parse_env_string("A=1\n\n\nB=2")
        assert result == {"A": "1", "B": "2"}

    def test_comment_lines_ignored(self):
        result = parse_env_string("# comment\nKEY=value\n  # indented comment")
        assert result == {"KEY": "value"}

    def test_export_prefix_stripped(self):
        result = parse_env_string("export KEY=value")
        assert result == {"KEY": "value"}

    def test_inline_comment(self):
        result = parse_env_string("KEY=value # this is ignored")
        assert result == {"KEY": "value"}

    def test_hash_inside_quotes_not_comment(self):
        result = parse_env_string('KEY="value # not a comment"')
        assert result == {"KEY": "value # not a comment"}


class TestMultiline:
    def test_multiline_double_quotes(self):
        content = 'KEY="line one\nline two\nline three"'
        result = parse_env_string(content)
        assert result == {"KEY": "line one\nline two\nline three"}

    def test_multiline_single_quotes(self):
        content = "KEY='line one\nline two\nline three'"
        result = parse_env_string(content)
        assert result == {"KEY": "line one\nline two\nline three"}


class TestInterpolation:
    def test_interpolation_from_loaded(self):
        content = "HOST=localhost\nPORT=8080\nURL=https://${HOST}:${PORT}/api"
        result = parse_env_string(content)
        assert result["URL"] == "https://localhost:8080/api"

    def test_interpolation_missing_var_empty(self):
        content = "KEY=prefix-${MISSING_VAR_XYZ}-suffix"
        result = parse_env_string(content)
        assert result["KEY"] == "prefix--suffix"

    def test_interpolation_from_os_environ(self, monkeypatch):
        monkeypatch.setenv("TEST_ENV_VAR_ABC", "from_env")
        content = "KEY=${TEST_ENV_VAR_ABC}"
        result = parse_env_string(content)
        assert result["KEY"] == "from_env"

    def test_no_interpolation_in_single_quotes(self):
        content = "HOST=localhost\nKEY='${HOST}'"
        result = parse_env_string(content)
        assert result["KEY"] == "${HOST}"


class TestFileOperations:
    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_env_file("/nonexistent/.env")

    def test_empty_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("")
        result = parse_env_file(str(env_file))
        assert result == {}

    def test_values_not_in_os_environ(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("MY_SECRET_TEST_KEY=secret_value")
        parse_env_file(str(env_file))
        assert "MY_SECRET_TEST_KEY" not in os.environ

    def test_parse_real_file(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "APP_NAME=my-project\n"
            "APP_DEBUG=false\n"
            "DATABASE_HOST=localhost\n"
            "# a comment\n"
            "\n"
            'DATABASE_URL="postgres://localhost/mydb"\n'
        )
        result = parse_env_file(str(env_file))
        assert result["APP_NAME"] == "my-project"
        assert result["APP_DEBUG"] == "false"
        assert result["DATABASE_HOST"] == "localhost"
        assert result["DATABASE_URL"] == "postgres://localhost/mydb"
