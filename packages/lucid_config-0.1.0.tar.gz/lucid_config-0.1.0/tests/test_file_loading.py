import json
import sys

import pytest

from lucid_config import Config


class TestLoadJson:
    def test_loads_valid_json(self, tmp_path):
        json_file = tmp_path / "config.json"
        json_file.write_text(json.dumps({
            "app": {"name": "my-project", "port": 8000},
            "database": {"host": "localhost"},
        }))
        config = Config()
        config.load_json(str(json_file))
        assert config.get("app.name") == "my-project"
        assert config.get("app.port") == 8000
        assert config.get("database.host") == "localhost"

    def test_missing_file_raises(self):
        config = Config()
        with pytest.raises(FileNotFoundError):
            config.load_json("/nonexistent/config.json")


class TestLoadToml:
    def test_loads_valid_toml(self, tmp_path):
        toml_file = tmp_path / "config.toml"
        toml_file.write_text(
            '[app]\nname = "my-project"\nport = 8000\n\n'
            '[database]\nhost = "localhost"\n'
        )
        config = Config()
        config.load_toml(str(toml_file))
        assert config.get("app.name") == "my-project"
        assert config.get("app.port") == 8000
        assert config.get("database.host") == "localhost"

    def test_missing_tomllib_raises_import_error(self, monkeypatch):
        # Temporarily make both tomllib and tomli unimportable
        import importlib

        original_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __import__

        def mock_import(name, *args, **kwargs):
            if name in ("tomllib", "tomli"):
                raise ImportError(f"No module named '{name}'")
            return original_import(name, *args, **kwargs)

        config = Config()
        toml_mod = sys.modules.pop("tomllib", None)
        tomli_mod = sys.modules.pop("tomli", None)
        try:
            monkeypatch.setattr("builtins.__import__", mock_import)
            with pytest.raises(ImportError, match="tomli"):
                config.load_toml("config.toml")
        finally:
            if toml_mod is not None:
                sys.modules["tomllib"] = toml_mod
            if tomli_mod is not None:
                sys.modules["tomli"] = tomli_mod


class TestLoadYaml:
    def test_loads_valid_yaml(self, tmp_path):
        yaml = pytest.importorskip("yaml")
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text("app:\n  name: my-project\n  port: 8000\n")
        config = Config()
        config.load_yaml(str(yaml_file))
        assert config.get("app.name") == "my-project"
        assert config.get("app.port") == 8000

    def test_missing_pyyaml_raises_import_error(self, monkeypatch):
        original_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __import__

        def mock_import(name, *args, **kwargs):
            if name == "yaml":
                raise ImportError("No module named 'yaml'")
            return original_import(name, *args, **kwargs)

        config = Config()
        yaml_mod = sys.modules.pop("yaml", None)
        try:
            monkeypatch.setattr("builtins.__import__", mock_import)
            with pytest.raises(ImportError, match="pyyaml"):
                config.load_yaml("config.yaml")
        finally:
            if yaml_mod is not None:
                sys.modules["yaml"] = yaml_mod


class TestMultipleFileLoads:
    def test_deep_merge_across_files(self, tmp_path):
        json1 = tmp_path / "base.json"
        json1.write_text(json.dumps({"app": {"name": "base", "port": 8000}}))

        json2 = tmp_path / "override.json"
        json2.write_text(json.dumps({"app": {"port": 9000, "debug": True}}))

        config = Config()
        config.load_json(str(json1))
        config.load_json(str(json2))
        assert config.get("app.name") == "base"
        assert config.get("app.port") == 9000
        assert config.get("app.debug") is True
