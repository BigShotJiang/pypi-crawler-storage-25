from lucid_config import Config


class TestMerge:
    def test_adds_new_top_level_keys(self):
        config = Config({"a": 1})
        config.merge({"b": 2})
        assert config.get("a") == 1
        assert config.get("b") == 2

    def test_adds_nested_keys_without_removing_siblings(self):
        config = Config({"database": {"host": "localhost", "port": 5432}})
        config.merge({"database": {"name": "mydb"}})
        assert config.get("database.host") == "localhost"
        assert config.get("database.port") == 5432
        assert config.get("database.name") == "mydb"

    def test_overwrites_leaf_values(self):
        config = Config({"database": {"port": 5432}})
        config.merge({"database": {"port": 3306}})
        assert config.get("database.port") == 3306

    def test_recursive_merge(self):
        config = Config({"a": {"b": {"c": 1, "d": 2}}})
        config.merge({"a": {"b": {"c": 10, "e": 3}}})
        assert config.get("a.b.c") == 10
        assert config.get("a.b.d") == 2
        assert config.get("a.b.e") == 3

    def test_dict_over_non_dict_replaces(self):
        config = Config({"key": "string"})
        config.merge({"key": {"nested": "value"}})
        assert config.get("key.nested") == "value"

    def test_non_dict_over_dict_replaces(self):
        config = Config({"key": {"nested": "value"}})
        config.merge({"key": "string"})
        assert config.get("key") == "string"

    def test_load_dict_deep_merges(self):
        config = Config()
        config.load_dict({"app": {"name": "my-project"}})
        config.load_dict({"app": {"version": "1.0"}})
        assert config.get("app.name") == "my-project"
        assert config.get("app.version") == "1.0"
