from lucid_config import Config


class TestDotNotation:
    def test_single_level(self):
        config = Config({"name": "app"})
        assert config.get("name") == "app"

    def test_two_levels(self):
        config = Config({"database": {"host": "localhost"}})
        assert config.get("database.host") == "localhost"

    def test_three_levels(self):
        config = Config({"cache": {"redis": {"host": "127.0.0.1"}}})
        assert config.get("cache.redis.host") == "127.0.0.1"

    def test_deeply_nested(self):
        data = {"a": {"b": {"c": {"d": {"e": {"f": "deep"}}}}}}
        config = Config(data)
        assert config.get("a.b.c.d.e.f") == "deep"

    def test_set_creates_intermediate_dicts(self):
        config = Config()
        config.set("a.b.c", "value")
        assert config.get("a.b.c") == "value"
        assert config.get("a.b") == {"c": "value"}
        assert config.get("a") == {"b": {"c": "value"}}

    def test_has_returns_false_when_intermediate_missing(self):
        config = Config()
        assert config.has("a.b.c") is False

    def test_very_long_dot_path(self):
        config = Config()
        config.set("a.b.c.d.e.f.g.h.i.j.k", "deep")
        assert config.get("a.b.c.d.e.f.g.h.i.j.k") == "deep"
