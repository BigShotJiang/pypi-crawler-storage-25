import pytest

from lucid_config import Config, ConfigFrozenError


class TestFreeze:
    def test_set_raises_after_freeze(self):
        config = Config({"key": "value"})
        config.freeze()
        with pytest.raises(ConfigFrozenError):
            config.set("key", "new")

    def test_merge_raises_after_freeze(self):
        config = Config()
        config.freeze()
        with pytest.raises(ConfigFrozenError):
            config.merge({"key": "value"})

    def test_forget_raises_after_freeze(self):
        config = Config({"key": "value"})
        config.freeze()
        with pytest.raises(ConfigFrozenError):
            config.forget("key")

    def test_load_dict_raises_after_freeze(self):
        config = Config()
        config.freeze()
        with pytest.raises(ConfigFrozenError):
            config.load_dict({"key": "value"})

    def test_load_env_raises_after_freeze(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=value")
        config = Config()
        config.freeze()
        with pytest.raises(ConfigFrozenError):
            config.load_env(str(env_file))

    def test_get_still_works_after_freeze(self):
        config = Config({"key": "value"})
        config.freeze()
        assert config.get("key") == "value"

    def test_is_frozen_property(self):
        config = Config()
        assert config.is_frozen is False
        config.freeze()
        assert config.is_frozen is True
