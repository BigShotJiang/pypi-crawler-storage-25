import pytest

from lucid_config import Config


class TestString:
    def test_casts_int_to_string(self):
        config = Config({"port": 8000})
        assert config.string("port") == "8000"

    def test_returns_default_for_missing(self):
        config = Config()
        assert config.string("missing") == ""
        assert config.string("missing", "fallback") == "fallback"

    def test_returns_string_as_is(self):
        config = Config({"name": "app"})
        assert config.string("name") == "app"


class TestInteger:
    def test_casts_string_to_int(self):
        config = Config({"port": "5432"})
        assert config.integer("port") == 5432

    def test_returns_int_as_is(self):
        config = Config({"port": 5432})
        assert config.integer("port") == 5432

    def test_returns_default_for_missing(self):
        config = Config()
        assert config.integer("missing") == 0
        assert config.integer("missing", 3000) == 3000

    def test_raises_for_non_numeric_string(self):
        config = Config({"key": "abc"})
        with pytest.raises(ValueError):
            config.integer("key")


class TestFloat:
    def test_casts_string_to_float(self):
        config = Config({"rate": "3.14"})
        assert config.float("rate") == 3.14

    def test_casts_int_to_float(self):
        config = Config({"rate": 3})
        assert config.float("rate") == 3.0

    def test_returns_default_for_missing(self):
        config = Config()
        assert config.float("missing") == 0.0
        assert config.float("missing", 1.5) == 1.5


class TestBoolean:
    @pytest.mark.parametrize(
        "value",
        [True, "true", "True", "TRUE", "1", "yes", "on"],
    )
    def test_truthy_values(self, value):
        config = Config({"flag": value})
        assert config.boolean("flag") is True

    @pytest.mark.parametrize(
        "value",
        [False, "false", "False", "FALSE", "0", "no", "off", ""],
    )
    def test_falsy_values(self, value):
        config = Config({"flag": value})
        assert config.boolean("flag") is False

    def test_returns_default_for_missing(self):
        config = Config()
        assert config.boolean("missing") is False
        assert config.boolean("missing", True) is True

    def test_none_returns_default(self):
        config = Config({"flag": None})
        assert config.boolean("flag") is False
        assert config.boolean("flag", True) is True


class TestList:
    def test_splits_comma_string(self):
        config = Config({"hosts": "a,b,c"})
        assert config.list("hosts") == ["a", "b", "c"]

    def test_strips_whitespace(self):
        config = Config({"hosts": "a, b, c"})
        assert config.list("hosts") == ["a", "b", "c"]

    def test_returns_existing_list(self):
        config = Config({"hosts": ["a", "b"]})
        assert config.list("hosts") == ["a", "b"]

    def test_custom_delimiter(self):
        config = Config({"values": "a|b|c"})
        assert config.list("values", delimiter="|") == ["a", "b", "c"]

    def test_returns_default_for_missing(self):
        config = Config()
        assert config.list("missing") is None
        assert config.list("missing", []) == []
        assert config.list("missing", ["default"]) == ["default"]
