from lucid_config import Config


class TestLoadEnvVars:
    def test_loads_all_environ(self, monkeypatch):
        monkeypatch.setenv("DATABASE_HOST", "prod-db")
        monkeypatch.setenv("DATABASE_PORT", "5432")
        config = Config()
        config.load_env_vars()
        assert config.get("database.host") == "prod-db"
        assert config.get("database.port") == "5432"

    def test_loads_with_prefix(self, monkeypatch):
        monkeypatch.setenv("APP_NAME", "my-app")
        monkeypatch.setenv("APP_DEBUG", "true")
        monkeypatch.setenv("DATABASE_HOST", "localhost")
        config = Config()
        config.load_env_vars(prefix="APP")
        assert config.get("app.name") == "my-app"
        assert config.get("app.debug") == "true"
        # DATABASE_HOST should be ignored
        assert config.has("database.host") is False

    def test_key_mapping(self, monkeypatch):
        monkeypatch.setenv("DATABASE_HOST", "localhost")
        config = Config()
        config.load_env_vars()
        assert config.get("database.host") == "localhost"

    def test_overrides_previous_values(self, monkeypatch):
        monkeypatch.setenv("APP_NAME", "from-env")
        config = Config({"app": {"name": "from-dict"}})
        config.load_env_vars(prefix="APP")
        assert config.get("app.name") == "from-env"


class TestLoadEnvPrefix:
    def test_shorthand_for_load_env_vars(self, monkeypatch):
        monkeypatch.setenv("MYAPP_DB_HOST", "localhost")
        config = Config()
        config.load_env_prefix("MYAPP")
        assert config.get("myapp.db_host") == "localhost"
