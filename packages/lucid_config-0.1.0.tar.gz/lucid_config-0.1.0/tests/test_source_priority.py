from lucid_config import Config


class TestSourcePriority:
    def test_env_file_overrides_dict(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_NAME=from-env")

        config = Config()
        config.load_dict({"app": {"name": "from-dict"}})
        config.load_env(str(env_file))
        assert config.get("app.name") == "from-env"

    def test_dict_after_env_file_wins(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_NAME=from-env")

        config = Config()
        config.load_env(str(env_file))
        config.load_dict({"app": {"name": "from-dict"}})
        assert config.get("app.name") == "from-dict"

    def test_env_local_overrides_env(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_DEBUG=false")

        env_local = tmp_path / ".env.local"
        env_local.write_text("APP_DEBUG=true")

        config = Config()
        config.load_env(str(env_file))
        config.load_env(str(env_local))
        assert config.get("app.debug") == "true"

    def test_set_overrides_everything(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_NAME=from-env")

        config = Config()
        config.load_dict({"app": {"name": "from-dict"}})
        config.load_env(str(env_file))
        config.set("app.name", "from-set")
        assert config.get("app.name") == "from-set"

    def test_env_vars_override_env_file(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_NAME=from-file")

        monkeypatch.setenv("APP_NAME", "from-environ")
        config = Config()
        config.load_env(str(env_file))
        config.load_env_vars(prefix="APP")
        assert config.get("app.name") == "from-environ"

    def test_override_false_only_fills_missing(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("APP_NAME=from-env\nAPP_VERSION=1.0")

        config = Config()
        config.load_dict({"app": {"name": "from-dict"}})
        config.load_env(str(env_file), override=False)
        assert config.get("app.name") == "from-dict"  # preserved
        assert config.get("app.version") == "1.0"  # filled
