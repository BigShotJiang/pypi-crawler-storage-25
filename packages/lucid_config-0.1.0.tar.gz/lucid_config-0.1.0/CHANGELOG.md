# Changelog

## 0.1.0 — Initial Release

- Config class with dot-notation get/set/has/forget/all
- Type casting: string, integer, float, boolean, list
- `.env` file parser with quotes, multiline, interpolation, inline comments
- Environment variable loading with prefix filtering
- Key mapping from `ENV_VAR_NAME` to `dot.notation`
- Deep merge via `merge()` and `load_dict()`
- File loading: JSON, TOML, YAML
- `freeze()` for immutability after boot
- `require()` for startup validation
- `ConfigContract` ABC for dependency injection
- Zero required dependencies
