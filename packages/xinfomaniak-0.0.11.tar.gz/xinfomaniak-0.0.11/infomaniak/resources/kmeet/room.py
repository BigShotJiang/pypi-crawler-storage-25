from infomaniak.resource import Resouce, AsyncResource


class Room(Resouce):
    """kMeet resource for room setting endpoints."""

    def get_room_settings(self) -> None:
        """Placeholder for room settings endpoints."""
        # https://developer.infomaniak.com/docs/api/get/1/kmeet/rooms/%7Broom_id%7D/settings
        raise NotImplementedError("kMeet room endpoints are not implemented yet.")


class AsyncRoom(AsyncResource):
    """Async kMeet resource for room setting endpoints."""

    async def get_room_settings(self) -> None:
        """Placeholder for room settings endpoints."""
        raise NotImplementedError("kMeet room endpoints are not implemented yet.")
