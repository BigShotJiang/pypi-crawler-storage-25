"""Internal tooling for porting from legacy contentctl objects to contentctl-ng objects."""

import json
import logging
import pprint
import re
import shutil
from datetime import date
from functools import cache
from importlib import resources
from io import StringIO
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

import git
from pydantic import BaseModel, ValidationError
from ruamel.yaml import YAML, CommentedMap, YAMLError

from contentctl_ng.objects.content import DeprecationInfo
from contentctl_ng.objects.validated_strings import EsTokenString
from contentctl_ng.utilities import common_io

port_files_that_require_manual_review = True
MANUAL_REVIEW_KEY_NAME = "MANUAL_REVIEW"


detection_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "status",
    "deprecation_info",
    "type",
    "description",
    "data_source",
    "search",
    "how_to_implement",
    "known_false_positives",
    "references",
    "drilldown_searches",
    "finding",
    "intermediate_findings",
    "threat_objects",
    "analytic_story",
    "threat_group",
    "asset_type",
    "cve",
    "atomic_guid",
    "mitre_attack_id",
    "product",
    "category",
    "security_domain",
    "baselines",
    "tests",
    "MANUAL_REVIEW",
]

baseline_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "type",
    "status",
    "description",
    "search",
    "how_to_implement",
    "known_false_positives",
    "references",
    "product",
    "security_domain",
    "schedule",
    "custom_schedule",
    "MANUAL_REVIEW",
]

dashboard_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "description",
]

story_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "status",
    "description",
    "narrative",
    "references",
    "cve",
    "threat_group",
    "category",
    "product",
    "usecase",
    "MANUAL_REVIEW",
]

schedule_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "description",
    "cron_schedule",
    "earliest_time",
    "latest_time",
    "schedule_window",
]

data_source_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "description",
    "mitre_components",
    "source",
    "sourcetype",
    "separator",
    "separator_value",
    "configuration",
    "supported_TA",
    "fields",
    "output_fields",
    "field_mappings",
    "convert_to_log_source",
    "references",
    "example_log",
]

macro_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "description",
    "definition",
    "arguments",
]

lookup_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "lookup_type",
    "description",
    "default_match",
    "fields",
    "match_type",
    "min_matches",
    "max_matches",
    "case_sensitive_match",
]

playbook_key_ordering = [
    "name",
    "id",
    "version",
    "creation_date",
    "modification_date",
    "author",
    "type",
    "description",
    "playbook",
    "how_to_implement",
    "references",
    "app_list",
    "labels",
    "playbook_outputs",
    "platform_tags",
    "playbook_type",
    "vpe_type",
    "playbook_fields",
    "product",
    "use_cases",
    "defend_technique_id",
    "analytic_story",
    "detections",
]


def force_ruamel_key_value_at_index(
    data: CommentedMap, index: int, key: str, value: Any
) -> None:
    """Force a key-value pair to be at a specific index in a ruamel.yaml CommentedMap.

    This is useful for ensuring that certain keys are always at the beginning of the file.
    Note that if -1 is used, the pair will be placed at the end of the value.

    Args:
        data: The CommentedMap to modify
        index: The index to insert the key-value pair at. -1 indicates the end of the file.
        key: The key to insert
        value: The value to insert

    Raises:
        ValueError: If the index is out of range. To put it another way, we are trying to insert
        a key-value pair at an index that is beyond the number of indexes in the file.
    """
    if index == -1:
        # Place the value at the end of the file
        # Determine the index to use here
        index = len(list(data.keys()))
    elif index > len(list(data.keys())):
        # Place the value at the end of the file
        raise ValueError(
            f"Index {index} is out of range for data with length {len(list(data.keys()))}"
        )

    data.insert(index, key, value)


def insert_key_value_into_ruamel_yaml_after_other_key(
    data: CommentedMap, key: str, value: Any, after_keys_list: list[str]
) -> None:
    """Insert a key-value pair into a ruamel.yaml CommentedMap after the first key found in the list.

    This function allows us to maintain a consistent, desirable ordering of the YML file when
    it is reserialized in the future.

    Args:
        data: The CommentedMap to modify
        key: The key to insert
        value: The value to insert
        after_keys_list: List of keys to search for. Insert after the first one found and return.

    Raises:
        ValueError: If none of the keys in after_keys_list are found in the data. We raise
        this exception because it is unclear where to insert this key and we do not want to
        silently fail or simply insert it at the end.
    """
    for after_key in after_keys_list:
        keys = list(data.keys())
        if after_key in keys:
            data.insert(keys.index(after_key) + 1, key, value)
            return

    raise ValueError(
        f"Could not insert the key '{key}' after any of the following values - they do not exist: {after_keys_list}"
    )


# This does not maintain state and will be called VERY often when performing
# I/O operations on CommentMap objects. Define it here as a cached
# function for performance reasons
@cache
def common_ruamel_yaml_reader_writer_config() -> YAML:
    """Return a common reader/writer for interacting with serialized yml objects.

    These constants are intentionally not exposed as function arguments because
    we do not want callers to be able to change them. They MUST be constant based
    on customer preference.
    """
    # Set a huge maximum permitted line length to avoid breaking strings that
    # by user request should be serialized to a single line
    MAXIMUM_LINE_WIDTH = 32768

    # Indent settings based on user preferences
    MAPPING_INDENT_LEVEL = 4
    SEQUENCE_INDENT_LEVEL = 6
    OFFSET_INDENT_LEVEL = 4

    ruamel_yaml_object = YAML()
    ruamel_yaml_object.preserve_quotes = True
    ruamel_yaml_object.width = MAXIMUM_LINE_WIDTH
    ruamel_yaml_object.indent(
        mapping=MAPPING_INDENT_LEVEL,
        sequence=SEQUENCE_INDENT_LEVEL,
        offset=OFFSET_INDENT_LEVEL,
    )
    return ruamel_yaml_object


def load_yml_file_to_ruamel_yaml(file_path: Path) -> CommentedMap:
    """Load a YML file and return its contents as a ruamel.yaml object.

    We use ruamel.yaml to preserve comments and formatting in the YML file.
    However, certain formatting inconsistences, such in level of intentation,
    may not be consistent.  These will need to be readded during serialization
    but to the updated YML file.

    For information on these formatting intricacies, please refer to the
    function update_ruamel_yaml_attack_data_section.

    Args:
        file_path (pathlib.Path): The path to the YML file.

    Raises:
        ruamel.yaml.YAMLError: If the file cannot be loaded or parsed.
        FileNotFoundError: If the file cannot be found.
        OSError: If the file cannot be opened.
        Exception: If the file cannot be loaded or parsed.

    Returns:
        YAML: The contents of the YML file.
    """
    if file_path.suffix != common_io.YML_FILE_EXTENSION:
        raise ValueError(
            f"Error attempting to load YML file {file_path}, but the file "
            f"does not have the .yml extension."
        )

    try:
        with open(file_path, "r") as f:
            data: CommentedMap = common_ruamel_yaml_reader_writer_config().load(f)  # type: ignore
            # Ensure that the data is a YAML object
            assert isinstance(data, CommentedMap)
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Error attempting to load YML file {file_path}, but the file was not found."
        )
    except YAMLError as e:
        raise ValueError(
            f"Error attempting to load YML file {file_path}, but the file could not be parsed: {e!s}"
        )
    except OSError as e:
        raise OSError(
            f"Error attempting to load YML file {file_path}, but the file could not be opened: {e!s}"
        )
    except Exception as e:
        raise Exception(
            f"Error attempting to load YML file {file_path}, but an unexpected error occurred: {e!s}"
        )

    if not isinstance(data, dict):
        raise ValueError(
            f"Error attempting to load YML file {file_path}, but the file could be successfully parsed "
            f"but is not a dictionary."
        )

    return data


def write_ruamel_yaml_to_yml_file(
    path: Path,
    data: CommentedMap,
    field_ordering: list[str] | None,
    create_parent_directory: bool = False,
    fix_attack_data_indentation: bool = False,
) -> None:
    """Write a ruamel.yaml object to a YML file.

    Raises:
        Exception: Exception if there was an issue creating the file
        or writing to the output file.

    Args:
        path (Path): The path to the file.
        data (Any): The data to write to the file.
        field_ordering (list[str] | None): The ordering of fields in the file.
        create_parent_directory (bool, optional): Whether to
        create the parent directory if it does not exist. Defaults to False.
        fix_attack_data_indentation (bool, optional): Whether to fix the indentation of the attack data. Defaults to False.
        Note that ONLY "detections"" have attack data that needs indentation fixes.
    """
    # Check to ensure that the parent directory exists.
    # If not and appropriate, create it.
    common_io.ensure_parent_directory_exists(path, create_parent_directory)

    # Because we may need to fix up the structure of the attack_data
    # section at the file level, we dump it to memory so that we
    # can potentially perform edits before writing it to disk.
    buf = StringIO()
    if field_ordering:
        # first check to make sure that an ordering is defined for all fields
        # It IS acceptable for a field defined in ordering to be missing from data,
        # since some of these fields are optional. However, if a key is defined in
        # data, it MUST be defined in the ordering.
        for key in data.keys():
            if key not in field_ordering:
                raise ValueError(
                    f"Field '{key}' not found in field ordering for {path}"
                )
        # now sort the data according to the field ordering
        insertion_index = 0
        for key in field_ordering:
            if key in data:
                force_ruamel_key_value_at_index(
                    data, insertion_index, key, data.pop(key)
                )
                insertion_index += 1
            else:
                # This field is not in the data, which is okay
                # skip it and do not increment the insertion index.
                pass
    else:
        # No custom field ordering was provided, so we will keep the ordering
        # in the CommentedMap without modification
        pass

    common_ruamel_yaml_reader_writer_config().dump(data, buf)
    raw = buf.getvalue()

    # We must run a second pass on the content of this buffer, per-line.
    # ruamel alone does not provide the specificity to apply different serialization
    # rules to certain keys
    # If the line starts with whitespace followed by any of the keys which can
    # appear in the attack_data section, then remove two spaces from the beginning
    # of the block to maintain consistency with the state of the YML before porting.
    pattern = re.compile(r"^(\s+)(- data:|source:|sourcetype:|index:)")
    lines: list[str] = []
    for line in raw.splitlines(True):
        # If there are 2 or more spaces AND we match the regex,
        # then this line is part of the attack_data block.
        # Apply the custom formatting, removing the two leading
        # spaces.
        if (
            pattern.match(line)
            and line.startswith("  ")
            and fix_attack_data_indentation
        ):
            line = line[2:]
        lines.append(line)
    result = "".join(lines)

    path.parent.mkdir(parents=create_parent_directory, exist_ok=True)
    try:
        # Write out the plan string, keeping order and spacing consistent.
        with open(path, "w") as f:
            f.write(result)

    except Exception as e:
        raise Exception(f"Error writing YML file {path}: {e!s}")


def add_manual_review_key(data: CommentedMap, rationale: str, path: Path) -> None:
    """Add a manual review key to the data dictionary if EMIT_MANUAL_REVIEW_KEYS is True.

    This indicates that a human review is required for the content because it could not
    be ported automatically.

    Args:
        data (CommentedMap): The data dictionary to add the manual review key to
        rationale (str): The rationale for the manual review requirement
        path (Path): The path to the content file
    """
    manual_review_rationale = "manual_review_rationale"

    # Check if there already is a requirement for manual_review
    if data.get(MANUAL_REVIEW_KEY_NAME, None):
        # Yes, there was already a requirement for manual_review on this content.

        # We do not need to set the RBA section again, but we
        # do need to update it with an additional rationale, if applicable.

        manual_review_data = data.get(MANUAL_REVIEW_KEY_NAME, {})
        # If the rationale is exactly the same, we don't need to add it more than
        # once.
        # But we do need to add any unique rationales.
        if rationale not in manual_review_data.get(manual_review_rationale, ""):
            # the new rationale did not exist, so update it
            manual_review_data[manual_review_rationale] = (
                manual_review_data[manual_review_rationale] + " AND " + rationale
            )

    # There is NOT already a manual review requirement.
    # Create the key and set it to the provided rationale.
    else:
        data[MANUAL_REVIEW_KEY_NAME] = {
            "rba": data.get("rba", {}),
            manual_review_rationale: rationale,
        }

    # Track all unique rationales, and files, which will be written out
    # to a separate file later for documentation.
    if rationale not in RBA_UPGRADE_TRACKING["Detailed Messages"]:
        RBA_UPGRADE_TRACKING["Detailed Messages"][rationale] = []
    RBA_UPGRADE_TRACKING["Detailed Messages"][rationale].append(str(path))
    # Clunky and redundant to sort this every time, but the list is short enough
    # it does not matter.
    RBA_UPGRADE_TRACKING["Detailed Messages"][rationale].sort()


logger = logging.getLogger(__name__)

MISSING_AUTHOR = "Splunk Threat Research Team"
MISSING_VERSION = 0
# This is a callable, so make sure it is called!
# We can't just statically assign a uuid4 value because
# then the same id would be used for all pieces of content
MISSING_ID_FUNC = uuid4

# A global dict to support tracking of the RBA/Finding/Intermediate Finding porting process

RBA_UPGRADE_TRACKING: dict[str, dict[str, int | dict[str, list[str]]]] = {
    "TTP": {
        "count": 0,
        "exactly_one_user": 0,
        "no_user_exactly_one_entity": 0,
        "no_user_multiple_entities": 0,
        "multiple_users": 0,
        "flagged_for_review": 0,
    },
    # All legacy risk_objects become intermediate_findings
    "Anomaly": {"count": 0, "flagged_for_review": 0},
    # Should not have any finding or intermediate finding fields
    "Hunting": {"count": 0, "flagged_for_review": 0},
    # flag all correlation for review
    "Correlation": {"count": 0, "flagged_for_review": 0},
    "Detailed Messages": {},
}

_DEFAULT_SCHEDULE_DICTS: CommentedMap = CommentedMap(
    {
        "default_baseline.yml": CommentedMap(
            {
                "name": "Default Baseline",
                "description": "This configuration file applies to all detections of type Baseline.",
                "creation_date": date.today().isoformat(),
                "modification_date": date.today().isoformat(),
                "cron_schedule": "10 0 * * *",
                "earliest_time": "-1450m@m",
                "latest_time": "-10m@m",
                "schedule_window": "auto",
            }
        ),
        "default_eventbaseddetection.yml": CommentedMap(
            {
                "name": "Default EventBasedDetection",
                "description": "This configuration file applies to all detections of type EventBasedDetection.",
                "creation_date": date.today().isoformat(),
                "modification_date": date.today().isoformat(),
                "cron_schedule": "0 * * * *",
                "earliest_time": "-70m@m",
                "latest_time": "-10m@m",
                "schedule_window": "auto",
            }
        ),
    }
)

# Create a map where detections are extracted from baselines
# The name of each detection will map to a list of baselines that it uses.
baseline_detection_map: dict[str, list[str]] = {}

# Set of all detection names that exist in the source corpus (populated in port_all
# before baselines are ported). Used to validate baseline->detection references.
# Removed detections are excluded; deprecated detections are included.
all_detection_names: set[str] = set()

# Set of baseline names that were flagged for manual review due to dangling
# detection references. Used in port_detection to suppress detections that
# would reference a baseline that was not emitted.
flagged_baseline_names: set[str] = set()

removed_investigation_object_map: dict[str, DeprecationInfo] = {}
removed_story_object_map: dict[str, DeprecationInfo] = {}
removed_detection_object_map: dict[str, DeprecationInfo] = {}
removed_baseline_object_map: dict[str, DeprecationInfo] = {}

logger.warning("WARNING - THIS TOOL IGNORE MLMODEL FILES")


def get_user_entities(rba_data: CommentedMap) -> list[CommentedMap]:
    """Get the list of user entities from the content.

    Args:
        rba_data (CommentedMap): The content to get user entities from

    Returns:
        list[CommentedMap]: The list of user entities
    """
    # TODO: Implement user entity extraction logic here
    # For now, just return an empty list
    return [entity for entity in rba_data if entity.get("type") == "user"]


def update_threat_objects(
    data: CommentedMap, threat_objects: list[CommentedMap]
) -> None:
    """Update the threat objects in the data with the sorted threat objects.

    Args:
        data (CommentedMap): The data to update - the entire detection
        threat_objects (list[CommentedMap]): The threat objects to update with
    """
    to = sorted(threat_objects, key=lambda t: t.get("field"))
    # if there are any threat objects, make sure that the
    # data object is updated do reflect that.
    if len(to) > 0:
        data["threat_objects"] = to


def get_system_or_other_entities(
    rba_data: list[CommentedMap],
) -> list[CommentedMap]:
    """Get the list of system or other entities from the content.

    Args:
        rba_data (list[CommentedMap]): The content to get system entities from

    Returns:
        list[CommentedMap]: The list of system entities
    """
    # TODO: Implement system entity extraction logic here
    # For now, just return an empty list
    return [entity for entity in rba_data if entity.get("type") in ["system", "other"]]


def port_ttp(data: CommentedMap, path: Path) -> None:
    """Port the TTP section from the old format to the new format.

    Args:
        data (CommentedMap): The content to port
        path (Path): The path to the content file
    """
    tracking = RBA_UPGRADE_TRACKING["TTP"]
    # Porting a TTP so track it
    tracking["count"] += 1

    # TODO: Implement TTP porting logic here
    # For now, just pass
    rba_section = data["rba"]

    if len(rba_section.get("risk_objects", [])) == 0:
        raise ValueError(
            f"No risk objects found in RBA section of {data.get('name')} - this is required for TTP porting"
        )

    update_threat_objects(data, threat_objects=rba_section.get("threat_objects", []))

    intermediate_findings_entities: list[dict[str, Any]] = []
    finding_entity = None
    if len(get_user_entities(rba_section.get("risk_objects", []))) > 0:
        # Handle when there is at least one user entity
        # Take the first (and possibly only) user as the finding
        finding_entity = get_user_entities(rba_section.get("risk_objects", []))[0]
        if len(get_user_entities(rba_section.get("risk_objects", []))) == 1:
            # For exactly one user entity, make it the finding and everything else is an intermediate finding
            tracking["exactly_one_user"] += 1
        else:
            # For multiple user entities, flag for review
            tracking["flagged_for_review"] += 1
            tracking["multiple_users"] += 1
            add_manual_review_key(
                data,
                "Multiple user-type entities found. We have picked the first "
                "one and flagged this detection for manual review.",
                path,
            )
            # Take the first user entity as the finding

        intermediate_findings_entities = get_user_entities(
            rba_section.get("risk_objects", [])
        )[1:] + get_system_or_other_entities(rba_section.get("risk_objects", []))

    elif len(rba_section.get("risk_objects", [])) > 0:
        # Handle when there are no user entities but there are other entities
        finding_entity = rba_section.get("risk_objects", [])[0]
        if len(rba_section.get("risk_objects", [])) == 1:
            tracking["no_user_exactly_one_entity"] += 1
        else:
            tracking["no_user_multiple_entities"] += 1
            tracking["flagged_for_review"] += 1
            add_manual_review_key(
                data,
                "Multiple non-user-type entities found, but no user-type entities. "
                "We have picked the first non-user type entity "
                "and flagged this detection for manual review.",
                path,
            )

        intermediate_findings_entities = rba_section.get("risk_objects", [])[1:]

    else:
        raise ValueError(
            "No risk objects found in RBA section of TTP - this should not be possible"
        )

    data["finding"] = {
        "title": rba_section["message"],
        "entity": {
            "field": finding_entity["field"],
            "type": finding_entity["type"],
            "score": finding_entity["score"],
        },
    }
    if len(intermediate_findings_entities) > 0:
        intermediate_findings: list[dict[str, str | int]] = []

        for intermediate_finding in intermediate_findings_entities:
            intermediate_findings.append(
                {
                    "field": intermediate_finding["field"],
                    "type": intermediate_finding["type"],
                    "score": int(intermediate_finding["score"]),
                    "message": rba_section["message"],
                }
            )
        data["intermediate_findings"] = {"entities": intermediate_findings}


def port_anomaly(data: CommentedMap, path: Path) -> None:
    """Port the Anomaly section from the old format to the new format.

    All anomaly risk objects become intermediate_findings

    Args:
        data (CommentedMap): The content to port
        path (Path): The path to the content file


    """
    tracking = RBA_UPGRADE_TRACKING["Anomaly"]
    tracking["count"] += 1
    rba_section = data["rba"]

    if len(rba_section.get("risk_objects", [])) == 0:
        raise ValueError(
            "No risk objects found in RBA section of Anomaly - this should not be possible"
        )

    update_threat_objects(data, threat_objects=rba_section.get("threat_objects", []))
    intermediate_findings: list[dict[str, str | int]] = []

    for risk_object in rba_section["risk_objects"]:
        intermediate_findings.append(
            {
                "field": risk_object["field"],
                "type": risk_object["type"],
                "score": int(risk_object["score"]),
                "message": rba_section["message"],
            }
        )

    data["intermediate_findings"] = {"entities": intermediate_findings}


def port_correlation(data: CommentedMap, path: Path) -> None:
    """Port the Correlation section from the old format to the new format.

    Args:
        data (CommentedMap): The content to port
        path (Path): The path to the content file
    """
    rba_section = data.get("rba", None)

    if rba_section is not None:
        raise ValueError("Correlation MUST NOT have an rba section, but one was found.")

    tracking = RBA_UPGRADE_TRACKING["Correlation"]
    tracking["count"] += 1
    tracking["flagged_for_review"] += 1
    add_manual_review_key(
        data,
        "Legacy Correlation detections have no rba section "
        "(and therefore no entities), but the new format requires a finding with at least "
        "one entity. A content author must supply the finding entity for each Correlation detection. "
        "Additionally, evaluate whether any Threat Objects are appropriate.",
        path,
    )


def port_hunting(data: CommentedMap, path: Path) -> None:
    """Port the Hunting section from the old format to the new format.

    Args:
        data (CommentedMap): The content to port
        path (Path): The path to the content file

    """
    tracking = RBA_UPGRADE_TRACKING["Hunting"]
    tracking["count"] += 1

    rba_section = data.get("rba", {})
    if len(rba_section.get("risk_objects", [])) != 0:
        raise ValueError(
            "Hunting must not have any risk_objects - this should not be possible"
        )
    if len(rba_section.get("threat_objects", [])) != 0:
        raise ValueError(
            "Hunting must not have any threat_objects - this should not be possible"
        )


def port_rba_section(data: CommentedMap, path: Path) -> None:
    """Port the RBA section from the old format to the new format.

    Documentation on the new behaviors for these types can
    be found at the following link:
    https://splunk.atlassian.net/browse/TR-4421


    Args:
        data (CommentedMap): The content to port
        path (Path): The path to the content file
    """
    # First and foremost, type must be present and one of the following:
    if data["type"] not in ["Hunting", "TTP", "Anomaly", "Correlation"]:
        raise Exception(f"Unknown type: {data['type']} for detection {data['name']}")

    if (
        len(get_user_entities(data.get("rba", {}).get("risk_objects", [])))
        + len(get_system_or_other_entities(data.get("rba", {}).get("risk_objects", [])))
    ) != len(data.get("rba", {}).get("risk_objects", [])):
        raise Exception(
            f"Non-user/system risk objects found in RBA section of {data['name']}. This is invalid."
        )

    # Now, port the RBA section
    # Each of these has slightly different logic,
    # so handle them accordingly
    if data["type"] == "TTP":
        port_ttp(data, path)
    elif data["type"] == "Anomaly":
        port_anomaly(data, path)
    elif data["type"] == "Correlation":
        port_correlation(data, path)
    elif data["type"] == "Hunting":
        port_hunting(data, path)
    else:
        raise ValueError(
            f"Unknown detection type {data.get('type', 'no_type')}. Cannot port RBA section."
        )

    # If a finding exists, then validate the content of its finding.title field
    if data.get("finding", None):
        finding = data.get("finding", {})
        try:
            EsTokenString(root=finding.get("title", ""))
        except ValidationError as e:
            add_manual_review_key(
                data,
                "The following error was found while validating "
                f"the finding title: {e}",
                path,
            )
    # For each intermediate finding, validate the contents of its
    # intermediate_finding[N].message field.
    # Flag it if it fails this validation
    for intermediate_finding in data.get("intermediate_findings", {}).get(
        "entities", []
    ):
        try:
            EsTokenString(root=intermediate_finding.get("message", ""))
        except ValidationError as e:
            add_manual_review_key(
                data,
                "The following error was found while validating "
                f"the intermediate finding message: {e}",
                path,
            )

    # Remove the RBA section if it exists.
    # it has been migrated to finding/intermediate findings.

    data.pop("rba", None)


def error_on_deprecated_content_missing_deprecation_info(
    data: CommentedMap, removed_info_map: dict[str, Any] | None = None
) -> None:
    """Throw an error if the content is deprecated.

    Args:
        data (CommentedMap): The content to check
        removed_info_map (dict[str, Any] | None): The removed info map to check.
        Some types of content, such as detections, baselines, and stories,
        may still exist in the app but don't have deprecation_info added
        into their YMLs yet.  Support the porting of this content over
        by loading the deprecation_info for them from the mapping at runtime.

    Returns:
        None
    """
    if (
        "status" in data
        and data["status"] == "deprecated"
        and "deprecation_info" not in data
    ):
        if removed_info_map is None:
            raise Exception(
                "Content is deprecated but does not have deprecation_info. "
                "Additionally, no removed_info_map was provided for this content."
            )
        # Check to see if this exists in the removed_info_map
        if removed_info_map.get(data["name"], None) is None:
            raise Exception(
                "Content is deprecated but does not have deprecation_info. "
                "While a removed_info_map was provided, it did not contain information for this content."
            )

        data["deprecation_info"] = removed_info_map[data["name"]].__dict__

    # Not deprecated content, so nothing to do
    return None


def add_common_missing_header_fields_and_update_version(
    data: CommentedMap,
) -> None:
    """Add common missing header fields id, author, and version to dict content.

    If version already exists, then the version is bumped by 1.

    Args:
        data (CommentedMap): The content to add missing fields to

    Returns:
        None - changes are made in place
    """
    if "id" not in data:
        data["id"] = str(MISSING_ID_FUNC())
    data["version"] = int(data.pop("version", 0)) + 1

    if "author" not in data:
        data["author"] = MISSING_AUTHOR


def port_macro(data: CommentedMap, path: Path) -> CommentedMap:
    """Port macro from legacy format to new format.

    Macro is only missing a few fields.  Existing fields
    do not require any changes.

    Args:
        data (CommentedMap): The macro to port (in legacy format)
        path (Path): The path to the macro file

    Returns:
        CommentedMap: The ported macro (in new format)
    """
    error_on_deprecated_content_missing_deprecation_info(data)

    return data


def port_story(data: CommentedMap, path: Path) -> CommentedMap:
    """Port story from legacy format to new format.

    This involves flattening out the tags.

    Args:
        data (CommentedMap): The story to port (in legacy format)
        path (Path): The path to the story file

    Returns:
        CommentedMap: The ported story (in new format)
    """
    error_on_deprecated_content_missing_deprecation_info(data, removed_story_object_map)

    data["usecase"] = data["tags"]["usecase"]

    data["category"] = data["tags"]["category"]

    data["product"] = data["tags"]["product"]

    # Remove "Splunk Security Analytics for AWS" from the product list if it exists
    # This comes at the direction of the user. This is no longer a valid "enum"
    # value for story products.
    if "Splunk Security Analytics for AWS" in data["product"]:
        data["product"].remove("Splunk Security Analytics for AWS")
        if not data["product"]:
            add_manual_review_key(
                data,
                "This story's product list is empty after removing "
                "'Splunk Security Analytics for AWS', which is no longer a valid product. "
                "At least one valid product must be specified.",
                path,
            )

    # If there are nonempty CVEs, the port them over
    # If CVE is an empty list, then remove it.
    if "cve" in data["tags"]:
        if len(data["tags"]["cve"]) > 0:
            data["cve"] = data["tags"]["cve"]

    if "group" in data["tags"]:
        data["threat_group"] = data["tags"]["group"]

    data.pop("tags", None)
    # tags.mitre_attack_enrichments, tags.mitre_attack_tactics, tags.datamodels, and
    # tags.kill_chain_phases are intentionally not ported. In legacy contentctl these
    # were enrichment-time fields derived at build time and never serialised to YAML.
    # The new Story schema derives equivalent data from associated detections at runtime.

    # detections and investigations are enrichment-time fields in legacy contentctl
    # and are never present in source YAMLs — these pops are purely defensive.
    data.pop("detections", None)
    data.pop("investigations", None)

    return data


def port_detection(data: CommentedMap, path: Path) -> CommentedMap:
    """Port detection from legacy format to new format.

    Args:
        data (CommentedMap): The detection to port (in legacy format)
        path (Path): The path to the detection file

    Returns:
        CommentedMap: The ported detection (in new format)
    """
    error_on_deprecated_content_missing_deprecation_info(
        data, removed_detection_object_map
    )

    # do not error on non-production content.
    # we will handle this differently

    # We previously updated the typing of the data_source objects
    # from list[str], where each str was AND'd together
    # if multiple datasources were required for a detection,
    # into list[list[str]]. This was out of line with user
    # request, so that has been removed from the porting logic.
    # However, when a detection is being ported, it MUST define a data_source
    # object, even if it is an empty list.
    # There is one instance where a detection does not declare a data_source
    # key today and we must handle it.
    if data.get("data_source", None) is None:
        add_manual_review_key(
            data,
            "This detection is missing a data_source: section.  "
            "Even if it has value 'data_source: []', "
            "every detection MUST include the data_source key/value.",
            path,
        )

    data["category"] = path.parent.name

    data["analytic_story"] = data["tags"]["analytic_story"]
    if not data["analytic_story"]:
        add_manual_review_key(
            data,
            "This detection has an empty analytic_story list. "
            "Every detection must belong to at least one Analytic Story.",
            path,
        )
    data["asset_type"] = data["tags"]["asset_type"]
    if "cve" in data["tags"] and data["tags"]["cve"]:
        # only port over the cve field if it is nonempty.
        data["cve"] = data["tags"]["cve"]

    # If atomic_guid is nonempty, port it over. Otherwise, set it to an empty list.
    if data.get("tags", {}).get("atomic_guid", None) is not None:
        # If atomic guid exists, then port it over if it is nonempty.
        # If it is empty, then strip it from the file since it is not meaningful.
        tags: dict[str, Any] = data.get("tags")
        if tags.get("atomic_guid", []):
            # Only get this value and port it over if it is nonempty.
            data["atomic_guid"] = tags.get("atomic_guid")

    if "group" in data["tags"] and data["tags"]["group"]:
        # only port over the group field if it is nonempty.
        data["threat_group"] = data["tags"]["group"]

    # If not MITRE ATTACK IDs are declared, or this key is missing
    # from the file, set it to an empty list. There is no default
    # value for MITRE ATTACK IDs, so they must be an empty list rather
    # than omitted.
    data["mitre_attack_id"] = data["tags"].get("mitre_attack_id", [])
    data["product"] = data["tags"]["product"]

    # tags.research_site_url, tags.event_schema, and tags.mappings are intentionally
    # not ported. The new EventBasedDetection schema has no equivalent fields.
    # Zero corpus instances on escu-production.
    data["security_domain"] = data["tags"]["security_domain"]

    # tags.throttling is intentionally not ported. The new Search schema has no
    # throttling field — this is a deliberate schema simplification. Zero detections
    # in the current corpus have throttling set.

    port_rba_section(data, path)

    # For any test that declares a 'custom_index', remove
    #'custom_index' and replace it with 'index'
    for test in data.get("tests", []):
        for attack_data in test.get("attack_data", []):
            if "custom_index" in attack_data:
                attack_data["index"] = attack_data.pop("custom_index")

    # Tests must be handled and converted in line with
    # the new structure of the detection field
    if "manual_test" in data["tags"]:
        if "tests" not in data:
            data["tests"] = []

        # Compose a clear description that will be used when constructing
        # the new test objects
        manual_test_message = f"PORTED MANUAL TEST - {data['tags']['manual_test']}"

        if len(data["tests"]) == 0:
            # There must be at least one test, so we will create a placeholder
            data["tests"].append(
                {
                    "name": "Auto Created Manual Test Entry",
                    "test_type": "experimental",
                    "description": f"{manual_test_message} This entry was "
                    "automatically created because the legacy detection did "
                    "not have any tests.",
                }
            )
        else:
            # convert all manual test tests to experimental tests
            for test in data["tests"]:
                test["name"] = test["name"]
                test["description"] = manual_test_message
                test["test_type"] = "experimental"
                # need to set the detection to experimental as well since
                # the parsing below cares about this value
                # we will keep the attack_data field if it was included
    elif "tests" in data:
        # do this check before removing status field!
        for test in data["tests"]:
            # set the test type in line with the status of the detection
            test["test_type"] = data["status"]
            # presently, the only test types supported are experimental and unit. deprecated tests are still unit tests
            if test["test_type"] not in ["experimental", "production", "deprecated"]:
                raise Exception("Unknown test type: " + test["test_type"])
            elif test["test_type"] == "production":
                if data.get("manual_test", None) is not None:
                    raise Exception(
                        f"Manual test found for production detection {data['name']} - this should have been handled earlier!"
                    )
                else:
                    test["test_type"] = "unit"

            elif test["test_type"] == "deprecated":
                # deprecated tests are still unit tests until the content has actually been removed
                test["test_type"] = "unit"

            elif test["test_type"] == "experimental":
                test["description"] = (
                    "This test is a legacy experimental test and may not be accurate."
                )

    else:
        # Do not add anything representing an experimental test.
        pass

    # get rid of tags once we have used manual_test (if applicable)
    data.pop("tags", None)

    # Map all the baselines that this detection uses into the detection object.
    # If any of those baselines were flagged for manual review due to dangling
    # detection references, flag this detection too so that it is suppressed
    # when --no-emit-manual-review is passed (the flagged baseline will not be
    # emitted in that case, so this detection must not reference it).
    if baseline_detection_map.get(data["name"]):
        data["baselines"] = baseline_detection_map[data["name"]]
        flagged = [b for b in data["baselines"] if b in flagged_baseline_names]
        if flagged:
            flagged_str = ", ".join(sorted(flagged))
            add_manual_review_key(
                data,
                f"Detection references baseline(s) flagged for manual review: {flagged_str}",
                path,
            )
    return data


def port_baseline(data: CommentedMap, path: Path) -> CommentedMap:
    """Port detection from legacy format to new format.

    Args:
        data (CommentedMap): The detection to port (in legacy format)
        path (Path): The path to the detection file

    Returns:
        CommentedMap: The ported detection (in new format)
    """
    error_on_deprecated_content_missing_deprecation_info(
        data, removed_baseline_object_map
    )
    data.pop("type", None)

    data["product"] = data["tags"]["product"]
    data["security_domain"] = data["tags"]["security_domain"]

    # note that analytic_story is also in tags, but it has since been removed from the new baseline object

    # replace the deployment object with a custom schedule if it exists
    if "deployment" in data:
        data["custom_schedule"] = data["deployment"]["scheduling"]
        data.pop("deployment", None)
    else:
        # This should have a regular schedule, so replace it with that
        # "Default Baseline" must resolve to a ScheduleEnum member at parse time.
        # This schedule file is written by port_all before baselines are ported,
        # so this dependency is always satisfied as long as that ordering is maintained.
        data["schedule"] = "Default Baseline"

    # For every detection this baseline maps to, be sure to add it
    # to a dictionary that will then be used when reserializing
    # detection objects to the new format.
    # Also validate that each referenced detection actually exists in the corpus.
    dangling_refs: list[str] = []
    for detection in data["tags"]["detections"]:
        if detection not in all_detection_names:
            dangling_refs.append(detection)
        else:
            if detection in baseline_detection_map:
                baseline_detection_map[detection].append(data["name"])
            else:
                baseline_detection_map[detection] = [data["name"]]

    if dangling_refs:
        flagged_baseline_names.add(data["name"])
        dangling_str = ", ".join(sorted(dangling_refs))
        add_manual_review_key(
            data,
            f"Baseline references detections that do not exist in the corpus: {dangling_str}",
            path,
        )

    data.pop("tags")
    return data


def port_data_source(data: CommentedMap, path: Path) -> CommentedMap:
    """Port datasource from legacy format to new format.

    Args:
        data (CommentedMap): The datasource to port (in legacy format)
        path (Path): The path to the datasource file

    Returns:
        CommentedMap: The ported datasource (in new format)
    """
    error_on_deprecated_content_missing_deprecation_info(data)

    # status is not present in any legacy data_source YAMLs in the current corpus —
    # this pop is purely defensive. Note: date removal and creation_date/modification_date
    # injection are handled upstream by port_date in port_directory, which is called
    # before this function.
    data.pop("status", None)
    return data


def port_playbook(data: CommentedMap, path: Path) -> CommentedMap:
    """Port playbook from legacy format to new format.

    The legacy format stores several fields inside a nested 'tags' block.
    This function flattens those fields to the top level, matching the new
    Playbook schema in contentctl-ng.

    Mapping from legacy tags:
      tags.playbook_type  -> playbook_type
      tags.vpe_type       -> vpe_type
      tags.platform_tags  -> platform_tags
      tags.playbook_fields -> playbook_fields
      tags.product        -> product
      tags.use_cases      -> use_cases
      tags.defend_technique_id -> defend_technique_id
      tags.analytic_story -> analytic_story
      tags.detections     -> detections
      tags.playbook_outputs -> playbook_outputs
      tags.labels         -> labels

    Note that even if these fields are empty list in the legacy
    content, these values are persisted to minimize changes in
    the porting process.

    Args:
        data (CommentedMap): The playbook to port (in legacy format)
        path (Path): The path to the playbook file

    Returns:
        CommentedMap: The ported playbook (in new format)
    """
    tags: CommentedMap = data.pop("tags", CommentedMap())

    # Only persist tags fields trhat
    playbook_type = tags.get("playbook_type", None)
    if playbook_type is not None:
        data["playbook_type"] = playbook_type

    vpe_type = tags.get("vpe_type", None)
    if vpe_type is not None:
        data["vpe_type"] = vpe_type

    platform_tags = tags.get("platform_tags", None)
    if platform_tags is not None:
        data["platform_tags"] = platform_tags

    playbook_fields = tags.get("playbook_fields", None)
    if playbook_fields is not None:
        data["playbook_fields"] = playbook_fields

    product = tags.get("product", None)
    if product is not None:
        data["product"] = product

    use_cases = tags.get("use_cases", None)
    if use_cases is not None:
        data["use_cases"] = use_cases

    # Intentionally persist any of these fields, even if they are empty.
    # Do not add any new fields.
    defend = tags.get("defend_technique_id", None)
    if defend is not None:
        data["defend_technique_id"] = defend

    analytic_story = tags.get("analytic_story", None)
    if analytic_story is not None:
        data["analytic_story"] = analytic_story

    detections = tags.get("detections", None)
    if detections is not None:
        data["detections"] = detections

    playbook_outputs = tags.get("playbook_outputs", None)
    if playbook_outputs is not None:
        data["playbook_outputs"] = playbook_outputs

    labels = tags.get("labels", None)
    if labels is not None:
        data["labels"] = labels

    return data


def port_dashboard(data: CommentedMap, path: Path) -> CommentedMap:
    """Port dashboard from legacy format to new format.

    Args:
        data (CommentedMap): The dashboard to port (in legacy format)
        path (Path): The path to the dashboard file

    Returns:
        CommentedMap: The ported dashboard (in new format)
    """
    return data


def get_file_creation_date(repo: git.Repo, file_path: Path) -> date:
    """Get the creation date of a file from git history.

    Uses git log --follow to trace through renames and find the oldest commit
    that first introduced the file under any name. Falls back to raising an
    exception if the file is not found in git history (e.g. untracked file or
    empty repository).

    If a shallow checkout has been performed, for example as is done in
    GitHub Actions, then this function will not return exceptions - however the
    WRONG creation_date will be returned.  The date returned in this case
    is EXPECTED to be today's date, or similar.
    Porting MUST always be done on a full checkout of the repo.


    Args:
        repo (git.Repo): The git repository containing the file.
        file_path (Path): The absolute path to the file.

    Note: This was generated by AI [Claude Sonnet 4.6]

    Returns:
        date: The date of the first commit that introduced the file,
              following any renames back to the original file name.
    """
    try:
        relative_path = file_path.resolve().relative_to(repo.working_dir)
        # --follow traces renames; %ct is the committed
        # Unix timestamp. git log outputs newest-first, so the last line is
        # the original creation commit.
        log_output = repo.git.log(
            "--follow",
            "--format=%ct",
            "--",
            str(relative_path),
        )
        if not log_output.strip():
            # Try without --follow to see if the file exists at all
            # In some cases, presumably when there are no renames/moves
            # to the file the --follow argument can fail.
            log_output = repo.git.log(
                "--format=%ct",
                "--",
                str(relative_path),
            )

        if not log_output.strip():
            raise Exception(
                f"Unable to determine creation date for [{file_path}] - no commits for file found in Git History (with or without --follow). "
                "It is highly likely this file has NOT been committed to the git repo. Are you trying to port the repo with new files or unsaved changes? "
                "This is NOT supported!"
            )
        timestamps = log_output.strip().splitlines()
        oldest_timestamp = int(timestamps[-1])
        return date.fromtimestamp(oldest_timestamp)
    except git.GitError as e:
        raise Exception(
            f"Git error while retrieving creation date for {file_path}: {e}"
        )
    except Exception as e:
        raise Exception(
            f"Unknown Error while retrieving creation date for {file_path}: {e}"
        )


def port_date(
    data: CommentedMap, creation_date: date, todays_date: date = date.today()
) -> CommentedMap:
    """Port date from legacy format to new format.

    This involves removing the date field and creating
    two new fields, creation_date and modification_date.
    creation_date will have a best-effort guess at the
    original creation date of the content, determined
    automatically from git history. modification_date
    will be today's date, when the content was ported.

    Args:
        data (CommentedMap): The data to port (in legacy format)
        creation_date (date): The creation date sourced from git history.
        todays_date (date): The date to use as the modification date. Defaults to today.

    Returns:
        CommentedMap: The ported data (in new format)
    """
    data.pop("date", None)
    insert_key_value_into_ruamel_yaml_after_other_key(
        data, "creation_date", creation_date.isoformat(), ["version"]
    )
    insert_key_value_into_ruamel_yaml_after_other_key(
        data, "modification_date", todays_date.isoformat(), ["creation_date"]
    )
    return data


def port_lookup(data: CommentedMap, path: Path) -> CommentedMap:
    """Port lookup from legacy format to new format.

    The only change here is to ensure that the 'default_match' field is
    a string and not interpreted as a boolean.

    Args:
        data (CommentedMap): The lookup to port (in legacy format)
        path (Path): The path to the lookup file

    Returns:
        CommentedMap: The ported lookup (in new format)
    """
    # The optional field named "default_match" exists in many lookup YMLs.
    # While this is a STRING field, it is very often defined as
    # default_match: false
    # Which naive yml parsing logic interprets as a boolean.

    # We provide logic below to handle both cases, where it is interpreted as
    # a string (correctly) and where it is interpreted as a boolean

    if "default_match" not in data:
        # This is the only field that receives special handling or changes,
        # so just return the original object
        pass

    # Check for the case where it was read as a string
    elif isinstance(data["default_match"], str):
        # do nothing with this field, it was read correctly as a string
        pass

    elif isinstance(data["default_match"], bool):
        # If it was read as a boolean, convert it to a string
        # In all 3 cases where this occurred, the value is exactly
        # case_sensitive_match: false
        # so we expliclty convert the value for this field to the string "false"
        data["default_match"] = str(data["default_match"]).lower()

    else:
        raise ValueError(
            "Unknown supported type for default_match: "
            + str(type(data["default_match"]))
            + " - "
            + str(data["default_match"])
        )

    return data


def port_directory(
    input_root_directory: Path,
    ported_content_dir: Path,
    old_directory_name: str,
    new_directory_name: str,
    port_function: Callable[[CommentedMap, Path], CommentedMap],
    field_ordering: list[str],
    other_allowed_extensions: list[str] = [],
) -> None:
    """Recursively port a directory of files from legacy format to new format.

    Args:
        input_root_directory (Path): The root directory of the app
        ported_content_dir (Path): The directory to write the ported content to
        old_directory_name (str): The name of the directory to port
        new_directory_name (str): The name of the directory to port to
        port_function (Callable[[CommentedMap, Path], CommentedMap]): The function to use to port the files
        field_ordering (list[str]): The ordering of fields in the file
        other_allowed_extensions (list[str]): A list of other file extensions to allow in the directory

    Returns:
        None (as a result, ported content is created in new_directory_name)
    """
    # Get a handle to the repository
    repo = git.Repo(input_root_directory)

    ported_content_dir.mkdir(exist_ok=True)
    # always make sure that this directory exists, even if empty
    (ported_content_dir / new_directory_name).mkdir(exist_ok=True)

    old_directory_path = input_root_directory / old_directory_name
    logger.info(f"Porting {old_directory_path}")
    if not old_directory_path.is_dir():
        logger.warning(
            f"Warning - the directory {old_directory_path} does not exist. Skipping porting of {old_directory_name}"
        )
        return
    counter = 0
    print(
        f"Porting all files in directory {old_directory_path}. "
        "Digging through Git History to find creation date is a slow process, "
        "this may take several minutes. Please be patient."
    )
    for content_file in common_io.get_all_files_by_suffix(
        ".yml", old_directory_path, other_allowed_extensions
    ):
        if content_file.name.startswith("__mlspl"):
            logger.info(f"Skipping {content_file}")
            continue
        counter += 1
        try:
            # Load this as ruamel.yaml to preserve formatting to the greatest
            # extent possible
            data = load_yml_file_to_ruamel_yaml(content_file)

            add_common_missing_header_fields_and_update_version(data)
            data = port_date(data, get_file_creation_date(repo, content_file))
            # Special case for KVSTORE vs CSV Lookups
            if old_directory_name == "lookups":
                if data.get("lookup_type") == "kvstore":
                    output_file_name = (
                        ported_content_dir
                        / new_directory_name
                        / "kvstore"
                        / content_file.name
                    )
                    write_ruamel_yaml_to_yml_file(
                        output_file_name,
                        port_function(data, output_file_name),
                        field_ordering,
                        create_parent_directory=True,
                    )
                elif data.get("lookup_type") == "csv":
                    output_file_name = (
                        ported_content_dir
                        / new_directory_name
                        / "csv"
                        / content_file.name
                    )
                    write_ruamel_yaml_to_yml_file(
                        output_file_name,
                        port_function(data, output_file_name),
                        field_ordering=field_ordering,
                        create_parent_directory=True,
                    )
                else:
                    raise Exception("Invalid lookup_type: " + data.get("lookuptype"))
            else:
                # Ensure that we preserve the appropriate folder structure in these content directories
                # For instance, this will preserve the endpoints/cloud/application/deprecated folders in detections/
                relative_path_in_new_directory: Path = content_file.relative_to(
                    old_directory_path
                )
                output_file_name = (
                    ported_content_dir
                    / new_directory_name
                    / relative_path_in_new_directory
                )

                ported_data = port_function(data, output_file_name)
                if (
                    ported_data.get(MANUAL_REVIEW_KEY_NAME, None) is None
                    or port_files_that_require_manual_review
                ):
                    write_ruamel_yaml_to_yml_file(
                        output_file_name,
                        ported_data,
                        field_ordering=field_ordering,
                        create_parent_directory=True,
                        fix_attack_data_indentation=old_directory_name
                        == "detections",  # if we are in the detections folder, fix attack_data indentation. otherwise do not
                    )
                else:
                    logger.warning(
                        f"Skipping conversion of {content_file} - port function marked as needing manual review. "
                        "Files requiring manual review, which have a MANUAL_REVIEW key at the end of their YMLs,  "
                        "will not be emitted so that the smoketest job may execute in GitHub actions or similar workflows. "
                        "Otherwise, this critical testing workflow would fail."
                    )

        except Exception as e:
            logger.error(f"Failed to port {content_file}: {e}")
            raise Exception(f"Unrecoverable error during porting file {content_file}.")

    # Update to allow YML extensions as well when copying other files
    all_allowed_extensions = [*other_allowed_extensions, ".yml"]
    all_allowed_extensions.append(".yml")
    for ext in other_allowed_extensions:
        for allowed_file in common_io.get_all_files_by_suffix(
            ext,
            input_root_directory / old_directory_name,
            other_allowed_suffixes=all_allowed_extensions,
        ):
            if allowed_file.suffix == ".csv":
                logger.info(f"Skipping {allowed_file} - it is ported separately")
                continue
            elif allowed_file.suffix == ".mlmodel":
                print(f"Skipping {allowed_file} - it is NOT SUPPORTED")
                continue
            shutil.copyfile(
                allowed_file,
                ported_content_dir / new_directory_name / allowed_file.name,
            )

    logger.info(f"Ported {counter} files\n")


def port_app_template(content_dir: Path, ported_content_dir: Path) -> None:
    """Port app template from old directory to new directory.

    Args:
        content_dir (Path): The root directory of the app
        ported_content_dir (Path): The directory to write the ported content to

    Returns:
        None (as a result, ported content is created in ported directory)
    """
    app_template_dir = content_dir / "app_template"
    ported_app_template = ported_content_dir / "app_template"

    shutil.copytree(app_template_dir, ported_app_template, dirs_exist_ok=True)
    logger.info(f"Ported app_template to {ported_app_template}")


# NOTE: this will be removed once FBDs have proper support in contentctl-ng
def port_static_configs(content_dir: Path, ported_content_dir: Path) -> None:
    """Port static_configs/savedsearches_fbd.conf file from old directory to new directory.

    Args:
        content_dir (Path): The root directory of the app
        ported_content_dir (Path): The directory to write the ported content to

    Returns:
        None (as a result, ported content is created in ported directory)
    """
    static_configs_file = content_dir / "static_configs" / "savedsearches_fbd.conf"
    ported_static_configs_dir = ported_content_dir / "static_configs"
    ported_static_configs_file = ported_static_configs_dir / "savedsearches_fbd.conf"

    if not static_configs_file.is_file():
        print(
            f"Warning - the file {static_configs_file} does not exist. Skipping porting of static_configs/savedsearches_fbd.conf"
        )
        return

    ported_static_configs_dir.mkdir(exist_ok=True, parents=True)
    shutil.copyfile(static_configs_file, ported_static_configs_file)
    print(
        f"Ported static_configs/savedsearches_fbd.conf to {ported_static_configs_file}"
    )


def port_contentctl_yml_to_build_yml_and_install_yml(
    content_dir: Path, ported_content_dir: Path
) -> None:
    """Create a build.yml in line with the contentctl.yml. Copy both into the new directory.

    Args:
        content_dir (Path): The root directory of the app
        ported_content_dir (Path): The directory to write the ported content to

    Returns:
        None (as a result, build.yml, contentctl.yml, install.yml are added to the build dir
    """
    contentctl_yml_source_path = content_dir / "contentctl.yml"
    contentctl_yml_dest_path = ported_content_dir / "contentctl.yml"
    if not contentctl_yml_source_path.is_file():
        raise FileNotFoundError(f"Failed to find contentctl.yml in {content_dir}")

    # Copy the contentctl.yml file into the ported directory. It is presently required for testing
    contentctl_yml_source_path.copy(contentctl_yml_dest_path)

    # open the build.yml from the resources directory

    with resources.as_file(
        resources.files("contentctl_ng") / "resources" / "port_build_template.yml"
    ) as build_yml_source_path:
        build_yml_dict = load_yml_file_to_ruamel_yaml(build_yml_source_path)

    build_yml_dest_path = ported_content_dir / "build.yml"
    install_yml_dest_path = ported_content_dir / "install.yml"

    # load the contentctl yml file
    contentctl_yml_dict = load_yml_file_to_ruamel_yaml(contentctl_yml_source_path)

    # Update the version in the build.yml with the version from contentctl.yml
    build_yml_dict["app_version"] = contentctl_yml_dict["app"]["version"]

    # Write out the updated build yml dict
    write_ruamel_yaml_to_yml_file(build_yml_dest_path, build_yml_dict, None)

    # Write out the updated install yml dict
    assert isinstance(build_yml_dict.get("id"), str), (
        "build.yml must have an 'id' field"
    )

    install_yml_contents: CommentedMap = CommentedMap(
        {
            "apps": [
                {
                    "appid": build_yml_dict["id"],
                    "hardcoded_path": f"dist/{build_yml_dict['id']}.tar.gz",
                }
            ]
        }
    )
    write_ruamel_yaml_to_yml_file(install_yml_dest_path, install_yml_contents, None)

    print(f"Ported contentctl.yml and build.yml to {ported_content_dir}")


def port_all(
    content_dir: Path,
    ported_content_dir: Path,
    port_files_that_require_manual_review_from_cli: bool,
) -> None:
    """Port all content from legacy format to new format.

    If manual review is required, it will emit a special key, with the
    name identified in MANUAL_REVIEW_KEY_NAME, making it clear that
    these ported detections need manual review. This will cause them, intentionally,
    to fail validation during `contentctl build` operations until the
    key has been removed and the conditions requiring manual review have
    been addressed.

    Args:
        content_dir (Path): The root directory of the app
        ported_content_dir (Path): The directory to write the ported content to
        port_files_that_require_manual_review_from_cli (bool): Whether or not file that contain the manual
        review key should be ported. This is controllable so that we can have the smoketest run even when some
        files are not yet in the correct format.

    Returns:
        None (as a result, ported content is created in ported directory)
    """
    global port_files_that_require_manual_review
    port_files_that_require_manual_review = (
        port_files_that_require_manual_review_from_cli
    )

    # Port all the removed content first. We must do this because it
    # updates a global deprecation mapping file that is used by other ports
    port_removed(content_dir, ported_content_dir / "removed")

    port_directory(
        content_dir,
        ported_content_dir,
        "macros",
        "macros",
        port_macro,
        macro_key_ordering,
    )
    port_directory(
        content_dir,
        ported_content_dir,
        "dashboards",
        "dashboards",
        port_dashboard,
        dashboard_key_ordering,
        other_allowed_extensions=[".json"],
    )

    # Copy all of the JSON files into the dashboards directory
    for f in (content_dir / "dashboards").glob("*.json"):
        shutil.copyfile(
            f,
            ported_content_dir / "dashboards/" / f.name,
        )

    # because they are a special case, make sure lookups/kvstore and lookups/csv exist, even if there are no kvstore or csvlookups to port
    (ported_content_dir / "lookups/kvstore").mkdir(parents=True, exist_ok=True)
    (ported_content_dir / "lookups/csv").mkdir(parents=True, exist_ok=True)
    port_directory(
        content_dir,
        ported_content_dir,
        "lookups",
        "lookups",
        port_lookup,
        lookup_key_ordering,
        other_allowed_extensions=[".csv", ".mlmodel"],
    )
    # Copy all of the CSV files into the csv/lookups directory
    for f in (content_dir / "lookups").glob("*.csv"):
        shutil.copyfile(
            f,
            ported_content_dir / "lookups/csv/" / f.name,
        )

    # Write the two default schedule files directly from hardcoded dicts
    schedules_dir = ported_content_dir / "schedules"
    schedules_dir.mkdir(exist_ok=True)
    for dest_name, schedule_data in _DEFAULT_SCHEDULE_DICTS.items():
        add_common_missing_header_fields_and_update_version(schedule_data)
        write_ruamel_yaml_to_yml_file(
            schedules_dir / dest_name,
            schedule_data,
            schedule_key_ordering,
            create_parent_directory=True,
        )

    port_directory(
        content_dir,
        ported_content_dir,
        "stories",
        "stories",
        port_story,
        story_key_ordering,
    )
    # Pre-scan all detection YAMLs to build the set of valid detection names.
    # This is used by port_baseline to validate baseline->detection references.
    # Removed detections are excluded (their names are in removed_detection_object_map).
    # Deprecated detections are included.
    global all_detection_names
    yaml_loader = YAML()
    for detection_file in (content_dir / "detections").rglob("*.yml"):
        try:
            with detection_file.open() as f:
                detection_data = yaml_loader.load(f)
            if isinstance(detection_data, dict):
                name = detection_data.get("name")
                if name and name not in removed_detection_object_map:
                    all_detection_names.add(name)
        except Exception:
            pass

    port_directory(
        content_dir,
        ported_content_dir,
        "baselines",
        "baselines",
        port_baseline,
        baseline_key_ordering,
    )
    port_directory(
        content_dir,
        ported_content_dir,
        "data_sources",
        "data_sources",
        port_data_source,
        data_source_key_ordering,
    )
    port_directory(
        content_dir,
        ported_content_dir,
        "detections",
        "detections",
        port_detection,
        detection_key_ordering,
    )
    port_directory(
        content_dir,
        ported_content_dir,
        "playbooks",
        "playbooks",
        port_playbook,
        playbook_key_ordering,
        other_allowed_extensions=[".json", ".png", ".py"],
    )
    port_app_template(content_dir, ported_content_dir)
    port_static_configs(content_dir, ported_content_dir)
    port_contentctl_yml_to_build_yml_and_install_yml(content_dir, ported_content_dir)

    # Make sure all the following directories got created - otherwise we encounter
    # errors during parsing since we expect every content folder has at least one
    # piece of content in it!
    for dir in [
        "macros",
        "dashboards",
        "lookups",
        "lookups/csv",
        "lookups/kvstore",
        "schedules",
        "stories",
        "baselines",
        "data_sources",
        "detections",
        "playbooks",
    ]:
        (ported_content_dir / dir).mkdir(exist_ok=True, parents=True)

    detailed_manual_tracking_log_path = ported_content_dir / "rba_upgrade_tracking.json"
    with open(detailed_manual_tracking_log_path, "w") as f:
        json.dump(RBA_UPGRADE_TRACKING, f, indent=3)
    del RBA_UPGRADE_TRACKING["Detailed Messages"]
    pprint.pprint(RBA_UPGRADE_TRACKING)
    print(
        f"Detailed manual tracking log written to: {detailed_manual_tracking_log_path}"
    )


class DeprecationInfoFromYml(BaseModel):
    """Loosely defined and unvalidated to support porting."""

    content: str
    removed_in_version: str
    reason: str
    replacement_content: list[str] = []


def port_removed(input_root_directory: Path, ported_content_dir: Path):
    """Port all removed content from legacy format to new format.

    This will involve extracting the deprecation info from the standalone YML
    and writing it into individual files
    """
    # load all deprecation info from YML
    # TODO: Remove this once we have migrated to using yml file for
    # the deprecation mapping. We are intentionally strict with case
    # sensitivity to ensure that content files do not have wrong capitalization,
    # but this one special YML file is an exception. As a workaround, copy it
    # to a lowercased version for porting purposes.

    removed_dir = input_root_directory / "removed"
    logger.info(f"Porting REMOVED content from {removed_dir}")
    ported_content_dir.mkdir(exist_ok=True, parents=True)

    # Collect a list of all supported deprecated content from all the deprecation
    # files that we find
    removed_detection_objects: list[DeprecationInfoFromYml] = []
    removed_baseline_objects: list[DeprecationInfoFromYml] = []
    removed_investigation_objects: list[DeprecationInfoFromYml] = []
    removed_story_objects: list[DeprecationInfoFromYml] = []

    # If we are working off of the escu-production branch, then there will be more than
    # one deprecation mapping file. We need to collect all of them.
    # The capitalization of the file extension is important here.
    for deprecation_mapping_file in list(
        Path(removed_dir).glob("deprecation_mapping*.YML")
    ):
        print(f"Found deprecation mapping file: {deprecation_mapping_file}")
        # we do not use the load_yml_file_to_ruamel_yaml here because
        # that will (intentionally) throw an error if the file extension is
        # YML, which is intentionally is for the deprecation_mapping*.YML files.
        # So we just open and load the file directly
        with open(deprecation_mapping_file, "r") as f:
            deprecation_info: CommentedMap = (
                common_ruamel_yaml_reader_writer_config().load(f)
            )  # type: ignore
            # Ensure that the data is a YAML object
            assert isinstance(deprecation_info, CommentedMap)

        removed_detection_objects.extend(
            [
                DeprecationInfoFromYml.model_validate(d)
                for d in deprecation_info["detections"]
            ]
        )

        removed_baseline_objects.extend(
            [
                DeprecationInfoFromYml.model_validate(d)
                for d in deprecation_info["baselines"]
            ]
        )

        removed_investigation_objects.extend(
            [
                DeprecationInfoFromYml.model_validate(d)
                for d in deprecation_info["investigations"]
            ]
        )

        removed_story_objects.extend(
            [
                DeprecationInfoFromYml.model_validate(d)
                for d in deprecation_info["stories"]
            ]
        )

    searches = (
        removed_detection_object_map,
        removed_detection_objects,
        "detections",
    )
    baselines = (
        removed_baseline_object_map,
        removed_baseline_objects,
        "baselines",
    )
    investigations = (
        removed_investigation_object_map,
        removed_investigation_objects,
        "investigations",
    )
    stories = (
        removed_story_object_map,
        removed_story_objects,
        "stories",
    )

    # Construct appropriate mappings from the raw data in the deprecation mapping file
    # to the new-style DeprecationInfo objects
    for (
        new_format_deprecation_info,
        deprecation_info_from_legacy_file,
        _,
    ) in [
        searches,
        baselines,
        investigations,
        stories,
    ]:
        for deprecated_content in deprecation_info_from_legacy_file:
            di = DeprecationInfo.model_construct(
                removed_in_version=deprecated_content.removed_in_version,
                reason=deprecated_content.reason,
                replacement_content=deprecated_content.replacement_content,
            )
            new_format_deprecation_info[deprecated_content.content] = di

    # Get a handle to the Repo, which will be used for calculating creation_date
    repo = git.Repo(input_root_directory)
    for new_format_deprecation_info, _, directory in [
        searches,
        baselines,
        investigations,
        stories,
    ]:
        for content_file in (removed_dir / directory).rglob("*.yml"):
            data = load_yml_file_to_ruamel_yaml(content_file)
            data = port_date(data, get_file_creation_date(repo, content_file))
            if data["name"] not in new_format_deprecation_info:
                raise Exception(
                    f"No deprecation info found for removed ['{data['name']}']"
                )

            data["deprecation_info"] = new_format_deprecation_info[
                data["name"]
            ].__dict__
            write_ruamel_yaml_to_yml_file(
                ported_content_dir / directory / content_file.name,
                data,
                None,
                create_parent_directory=True,
            )
            logger.info(f"wrote {ported_content_dir / directory / content_file.name}")
