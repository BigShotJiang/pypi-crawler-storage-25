"""Commonly used  I/O functions.

Most notably, this is used for YML
and JSON serialization and deserialization.

YML, JSON and other file IO operations are extremely
common throughout the codebase, so this module
provides a single place to define these functions.

We have wrapped functions with meaningful, and
sufficient error messages to make debugging easier.

If you need to create any IO functions which you feel
will be useful in more than one place in the entire codebase,
please consider adding them to this module instead of defining
them locally where they are used!
"""

import json
import logging
from pathlib import Path
from typing import Any, Type, TypeVar

import requests
import yaml
from pydantic import BaseModel

YML_FILE_EXTENSION = ".yml"

logger = logging.getLogger(__name__)


# Explicitly add a flag to allow unicode characters in YML output.
# This setting should be used globally when serializing YML files using
# dumpers that explicitly allow or require enabling or disabling unicode.
# As a concrete example, the PYYAML Dumper, by default, does NOT serialize
# unicode characters and instead uses an escape sequence to write them in
# ASCII which we do not want.  This has very negative impacts on file
# readability.
CONTENTCTL_GLOBAL_ALLOW_UNICODE = True


def dump_with_block_scaler_if_newlines_in_text(dumper: yaml.BaseDumper, str_data: str):
    r"""If a string field has one or more newlines in it, dump using | scaler.

    Note: this comment is a regex string due to a ruff warning triggered by
    the intentional inclusion of BACKSLASHES in the comment.

    We want a field like:
    search: |
        something
        here and there

    to be serialized like that, not like
    search: "something \n\
           here and there"

    Which pyyaml may do for a number of reasons.
    The technique below comes from the following suggestion:
    https://stackoverflow.com/a/33300001
    """
    """
    if "\u2014" in str_data:
        str_data = str_data.replace("\u2014", "-")
    if "\u2011" in str_data:
        str_data = str_data.replace("\u2011", "-")
    if "\u2018" in str_data:
        str_data = str_data.replace("\u2018", "'")
    if "\u2019" in str_data:
        str_data = str_data.replace("\u2019", "'")
    """
    if "\n" in str_data:
        k = [
            line.strip() if len(line.strip()) > 0 else ""
            for line in str_data.split("\n")
        ]
        str_data = "\n".join(k)

    if "\n" in str_data:
        return dumper.represent_scalar(
            "tag:yaml.org,2002:str", str_data.strip(), style="|"
        )
    return dumper.represent_scalar("tag:yaml.org,2002:str", str_data)


# TODO: Keep this as we will want a "yaml-lint" type job which
# reloads, parses, validates, and re-emits YML files to be in a consistent, pretty format.
# yaml.add_representer(str, dump_with_block_scaler_if_newlines_in_text)
# yaml.representer.SafeRepresenter.add_representer(
#     str, dump_with_block_scaler_if_newlines_in_text
# )


def get_all_files_by_suffix(
    suffix: str,
    root_directory: Path,
    other_allowed_suffixes: list[str] = [],
    allow_extra_files: bool = False,
) -> list[Path]:
    """Get a list of all files in a directory with a specific suffix (extension).

    This function is INTENTIONALLY prescriptive. It prevents the inclusion
    of additional files which are not parsed into objects.

    Note that suffixes MUST begin with ., so .txt and .yml
    are allowed, but txt and yml are not.

    Args:
        suffix (str): The file suffix (extension) to look for.
        root_directory (pathlib.Path): The directory to search.
        other_allowed_suffixes (list[str]): Any other suffixes that are allowed
        to be present in the directory, but not parsed into objects.
        allow_extra_files (bool): If True, then allow any extra files
        to be present in the directory. Otherwise, generate execeptions
        for extra files.

    Returns:
        list[pathlib.Path]: A list of file paths that match the given suffix.
    """
    # Ensure that all extensions start with a .
    if not suffix.startswith("."):
        raise ValueError(
            f"Attempting to get files with extension {suffix} "
            "in directory {root_directory}, but the extension does not start with a dot."
        )
    for ext in other_allowed_suffixes:
        if not ext.startswith("."):
            raise ValueError(
                f"Attempting to get files with extension {ext} "
                "in directory {root_directory}, but the extension does not start with a dot."
            )

    if not root_directory.is_dir():
        raise NotADirectoryError(
            f"Attempting to get files with extension {suffix} "
            f"in directory {root_directory}, but the directory does not exist."
        )

    # Ensure that all extensions (after the initial leading .) are alphanumeric
    if not suffix[1:].isalnum():
        raise ValueError(
            f"Attempting to get files with extension {suffix} "
            f"in directory {root_directory}, but {suffix} is not alphanumeric."
        )

    for ext in other_allowed_suffixes:
        if not ext[1:].isalnum():
            raise ValueError(
                f"Attempting to ignore files with extension {ext} "
                f"in directory {root_directory}, but {ext} is not alphanumeric."
            )

    # get the list of all files in this directory
    # if there are any extensions which are not included in either
    # the specific extension we are looking for or the other allowed extensions,
    # raise an error
    matched_files: list[Path] = []
    extra_allowed_files: list[Path] = []
    extra_disallowed_files: list[Path] = []

    for file in root_directory.rglob("*"):
        if file.is_dir():
            continue
        if file.suffix == suffix:
            matched_files.append(file)
        elif file.suffix in other_allowed_suffixes:
            extra_allowed_files.append(file)
        elif file.name.startswith("."):
            # .gitkeep is a special file (and .gitkeep is the NAME, not a suffix).
            # Any other files that start with a '.' are also special.
            # We will intentionally allow these to be present
            continue
        else:
            extra_disallowed_files.append(file)

    if len(extra_disallowed_files):
        raise ValueError(
            f"Error attempting to get files with extension {suffix} "
            f"in directory {root_directory}, but the following files have extensions "
            f"that are not included in either the specific extension "
            f"we are looking for or the other allowed extensions: {other_allowed_suffixes}:\n"
            f"{extra_disallowed_files}"
        )

    return matched_files


def load_yml_file_to_dict(file_path: Path) -> dict[str, Any]:
    """Load a YML file and return its contents as a dictionary.

    The return dict is intentionally untyped and should then
    be passed to pydantic model validation, or similar.

    This function is INTENTIONALLY prescriptive for a number of reasons:
    1. We ALWAYS require the use of the .yml file extension. While this
    is counter to the official recommendation (https://yaml.org/faq.html),
    we intentionally choose .yml for the sake of legacy compatibility
    with other tools that leverageESCU content.
    2. We ALWAYS require that YML files deserialize to a dictionary.
    While it is allowed to serialize lists to YML, we do not have
    any reason in contentctl to do this today - and treating it as
    an error simplifies our error handling workflow.
    3.


    Args:
        file_path (pathlib.Path): The path to the YML file.

    Raises:
        ValueError: If the file is not a YML file.
        FileNotFoundError: If the file is not found.
        ValueError: If the could be successfully parsed but is not a dictionary.
        OSError: If the file cannot be opened.
        Exception: If an unexpected error occurs.
        YAMLError: If the file cannot be parsed for unknown reasons.

    Returns:
        dict[str,Any]: The contents of the YML file.
    """
    if file_path.suffix != YML_FILE_EXTENSION:
        raise ValueError(
            f"File {file_path} is not a YML file. "
            f"Please provide a file with a {YML_FILE_EXTENSION} extension."
        )

    if not file_path.is_file():
        raise FileNotFoundError(f"YML file not found: {file_path}")

    try:
        with file_path.open("r", encoding="utf-8") as file_data:
            yml_data: dict[str, Any] = yaml.load(
                file_data.read(), Loader=yaml.CSafeLoader
            )
    except yaml.YAMLError as e:
        raise ValueError(f"Error parsing YML file {file_path}: {e}")
    except OSError as e:
        raise OSError(f"Error opening the YML file {file_path}: {e}")
    except Exception as e:
        raise Exception(
            f"An unexpected error occurred while loading the YML file {file_path}: {e}"
        )

    if not isinstance(yml_data, dict):
        raise ValueError(
            f"YML file {file_path} was parsed in the following format: {type(yml_data)}.\n"
            "All YML files in this project MUST be parsed as a dictionary."
            "Please ensure that the file is formatted correctly "
            "and contains a valid dictionary structure. The following site"
            "may be helpful in debugging YML formatting and parsing issues:\n"
            "https://jsonformatter.org/yaml-validator"
        )

    return yml_data


def ensure_parent_directory_exists(
    path: Path, create_parent_directory: bool = False
) -> None:
    """Ensure that the parent directory exists.

    Raises:
        FileNotFoundError: Error if the parent directory does
        not exist and create_parent_directory is False.

    Args:
        path (Path): The path to the file.
        create_parent_directory (bool, optional): Whether to
        create the parent directory if it does not exist. Defaults to False.
    """
    if not path.parent.exists():
        if create_parent_directory:
            path.parent.mkdir(parents=True, exist_ok=True)
        else:
            raise FileNotFoundError(
                f"Parent directory {path.parent} does not exist, "
                "so the file {path} cannot be written."
            )


def write_dict_to_yml(
    path: Path, data: dict[str, Any], create_parent_directory: bool = False
) -> None:
    """Write a dictionary to a YML file.

    Raises:
        Exception: Exception if there was an issue creating the file
        or writing to the output file.

    Args:
        path (Path): The path to the file.
        data (dict[str, Any]): The data to write to the file.
        create_parent_directory (bool, optional): Whether to
        create the parent directory if it does not exist. Defaults to False.
    """
    # Check to ensure that the parent directory exists.
    # If not and appropriate, create it.
    ensure_parent_directory_exists(path, create_parent_directory)

    try:
        with open(path, "w") as f:
            # In an attempt to maintain the order of keys,
            # we intentionally disable sorting
            yaml.safe_dump(
                data,
                f,
                indent=4,
                sort_keys=False,
                allow_unicode=CONTENTCTL_GLOBAL_ALLOW_UNICODE,
            )

    except Exception as e:
        raise Exception(f"Error writing YML file {path}: {e!s}")


def write_dict_to_json(
    path: Path, data: dict[str, Any], create_parent_directory: bool = False
) -> None:
    """Write a dictionary to a JSON file.

    Raises:
        Exception: Exception if there was an issue creating the file
        or writing to the output file.

    Args:
        path (Path): The path to the file.
        data (dict[str, Any]): The data to write to the file.
        create_parent_directory (bool, optional): Whether to
        create the parent directory if it does not exist. Defaults to False.
    """
    # Check to ensure that the parent directory exists.
    # If not and appropriate, create it.
    ensure_parent_directory_exists(path, create_parent_directory)

    try:
        with open(path, "w") as f:
            # In an attempt to maintain the order of keys,
            # we intentionally disable sorting
            json.dump(data, f, indent=3, sort_keys=False)
    except Exception as e:
        raise Exception(f"Error writing JSON file {path}: {e!s}")


def write_basemodel_to_YML_file(
    path: Path,
    obj: BaseModel,
    create_parent_directory: bool = False,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    exclude_unset: bool = False,
    exclude_defaults: bool = True,
) -> None:
    """Write a BaseModel to a YML file.

    Args:
        path (Path): The path to the YML file.
        obj (BaseModel): The BaseModel to write to the YML file.
        create_parent_directory (bool, optional): Whether to create the parent directory if it does not exist. Defaults to False.
        include (list[str] | None, optional): A list of fields to include in the YML file. Defaults to None.
        exclude (list[str] | None, optional): A list of fields to exclude from the YML file. Defaults to None.
        exclude_unset (bool, optional): Whether to exclude unset fields from the YML file. Defaults to False.
        exclude_defaults (bool, optional): Whether to exclude default fields from the YML file. Defaults to True.
    """
    try:
        dumped_dict_data = obj.model_dump(
            mode="json",
            include=include,
            exclude=exclude,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
        )
    except Exception as e:
        raise Exception(f"Error dumping BaseModel of type {type(obj)} to dict: {e!s}")

    write_dict_to_yml(path, dumped_dict_data, create_parent_directory)


# Define a generic type for constructing a BaseModel
# This TypeVar allows us to properly define the Type Annotation
# for the function below, load_yml_file_to_base_model.
# Without this, the return typing would need to be overly generic,
# creating subsequent type issues for callers of this function
GenericBaseModelType = TypeVar("GenericBaseModelType", bound=BaseModel)


def load_yml_file_to_base_model(
    path: Path, model: Type[GenericBaseModelType]
) -> GenericBaseModelType:
    """Load a YML file to a BaseModel.

    Args:
        path (Path): The path to the YML file.
        model (Type[GenericBaseModelType]): The BaseModel to load the YML file into.
        TypeVar is used to ensure the return type matches the model input type.

    Returns:
        GenericBaseModelType: The BaseModel loaded from the YML file.
    """
    dict_data = load_yml_file_to_dict(path)

    # The following will raise ValidationError/ValueError, or similar,
    # if the data is not valid during construction. We intentionally do
    # not catch this exception here, as it should be bubbled up to the caller.
    return model.model_validate(dict_data)


def fetch_file_data_from_url_with_fallback(url: str, fallback_path: Path) -> bytes:
    """Fetch a file from a URL and return the contents as bytes. Use a fallback file if the URL fails.

    Args:
        url (str): The URL to fetch the file from.
        fallback_path (Path): The path to the fallback file.

    Returns:
        bytes: The contents of the file as bytes.

    Raises:
        FileNotFoundError: If the fallback file does not exist. This error is only raised if
        the URL fails first AND the fallback file does not exist.
        Exception: If fetching the file via URL fails and the fallback file DOES exist, but
        there is some other error in reading it.
    """
    DOES_FILE_EXIST = (
        "FILE EXISTS" if fallback_path.is_file() else "FILE DOES NOT EXIST"
    )
    logger.info(
        f"Fetching file from URL: [{url}].\nIf this fails, we will attempt to use the fallback file: [{fallback_path} - {DOES_FILE_EXIST}]"
    )

    try:
        return fetch_file_data_from_url(url)
    except (requests.HTTPError, requests.ConnectionError, requests.Timeout) as e:
        logger.error(
            f"Error fetching file from [{url}]:\n\n - {e!s}\n\n"
            "This could be due to a lack of internet connectivity in this runner, flakiness or "
            "rate-limiting by the webserver, or some other issue."
        )
    if not fallback_path.is_file():
        raise FileNotFoundError(
            f"Download failed and Fallback file does not exist: [{fallback_path.absolute()}]. "
            "You must resolve the HTTP Error or include a copy of the "
            "file at this path as a fallback."
        )
    logger.info(f"Fallback file for url {url} found at: [{fallback_path.absolute()}]")
    try:
        return fallback_path.read_bytes()
    except Exception as e:
        raise Exception(
            f"Error reading fallback file [{fallback_path.absolute()}]: {e!s}"
        )


def fetch_file_data_from_url(url: str) -> bytes:
    """Fetch a file from a URL and return the contents as bytes.

    Args:
        url (str): The URL to fetch the file from.

    Returns:
        bytes: The contents of the file as bytes.

    Raises:
        Exception: If the file cannot be fetched.

    Note:  If the file cannot be fetched, this will generate an exception.
    This request is intentionally not caught in this function so that
    it can be handled by the caller.
    """
    req = requests.get(url)
    req.raise_for_status()
    return req.content
