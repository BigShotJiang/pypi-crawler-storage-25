"""Logic for running Appinspect, ensuring proper metadata is present, and ensuring detections are not inadvertently removed."""

import datetime
import json
import logging
import pathlib
import time
import timeit
from io import BufferedReader

from pydantic import Field, FilePath
from pydantic_settings import SettingsConfigDict
from requests import Session, get, post
from requests.auth import HTTPBasicAuth

from contentctl_ng.contentctl_legacy_ported.objects.errors import (
    DetectionIDError,
    DetectionMissingError,
    MetadataValidationError,
    MissingMetadataError,
    VersionBumpingError,
    VersionBumpingTooFarError,
    VersionDecrementedError,
)
from contentctl_ng.contentctl_legacy_ported.objects.savedsearches_conf import (
    SavedsearchesConf,
)
from contentctl_ng.settings import ContentSettings, SplunkbaseSettings

logger = logging.getLogger(__name__)

"""
The following list includes all appinspect tags available from:
https://dev.splunk.com/enterprise/reference/appinspect/appinspecttagreference/

This allows contentctl to be as forward-leaning as possible in catching
any potential issues on the widest variety of stacks.
"""
INCLUDED_TAGS_LIST = [
    "aarch64_compatibility",
    "ast",
    "cloud",
    "future",
    "manual",
    "packaging_standards",
    "private_app",
    "private_classic",
    "private_victoria",
    "splunk_appinspect",
]
INCLUDED_TAGS_STRING = ",".join(INCLUDED_TAGS_LIST)


class Inspector(SplunkbaseSettings, ContentSettings):
    """Run Appinspect validation and detection metadata checks.

    This class orchestrates the Appinspect API validation process and optionally
    performs detection metadata validation by comparing current and previous builds.

    Args:
        SplunkbaseSettings (SplunkbaseSettings): Settings for connecting to an authenticated splunkbase session.
        ContentSettings (ContentSettings): Settings for loading content.
    """

    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", populate_by_name=True
    )

    # TODO: determine if we want to keep this behavior or have a different opt-in or opt-out field and/or automatically fetch the latest app from splunkbase
    # currently this field is used to skip detection metadata validation if not provided, or perform validation if provided.
    old_app_path: FilePath | None = Field(
        description="Provide the path to the old fully-built content app for comparison. If this is not provided, detection metadata validation will be skipped.",
        alias="old-app-path",
        default=None,
    )

    def getElapsedTime(self, startTime: float) -> datetime.timedelta:
        """Get the elapsed time since the start time.

        Args:
            startTime (float): the start time

        Returns:
            datetime.timedelta: the elapsed time since the start time
        """
        return datetime.timedelta(seconds=round(timeit.default_timer() - startTime))

    def inspectAppAPI(self) -> str:
        """Run Appinspect against the API.

        Raises:
            Exception: if the API fails or AppInspect indicates there is an issue with the app

        Returns:
            str: the Appinspect API token
        """
        print("Running Appinspect against the API...")
        session = Session()
        session.auth = HTTPBasicAuth(
            self.splunkbase_username,
            self.splunkbase_password.get_secret_value(),
        )

        APPINSPECT_API_LOGIN = "https://api.splunk.com/2.0/rest/login/splunk"

        res = session.get(APPINSPECT_API_LOGIN)
        # If login failed or other failure, raise an exception
        res.raise_for_status()

        authorization_bearer = res.json().get("data", {}).get("token", None)
        APPINSPECT_API_VALIDATION_REQUEST = (
            "https://appinspect.splunk.com/v1/app/validate"
        )

        """
        Some documentation on "files" argument for requests.post exists here:
        https://docs.python-requests.org/en/latest/api/
        The type (None, INCLUDED_TAGS_STRING) is intentional, and the None is important.
        In curl syntax, the request we make below is equivalent to
        curl -X POST \
            -H "Authorization: bearer <TOKEN>" \
            -H "Cache-Control: no-cache" \
            -F "app_package=@<PATH/APP-PACKAGE>" \
            -F "included_tags=cloud" \
            --url "https://appinspect.splunk.com/v1/app/validate"

        This is confirmed by the great resource:
        https://curlconverter.com/
        """
        data: dict[str, tuple[None, str] | BufferedReader] = {
            "app_package": open(self.build_output_app_package_path, "rb"),
            "included_tags": (
                None,
                INCLUDED_TAGS_STRING,
            ),  # tuple with None is intentional here
        }

        headers = {
            "Authorization": f"bearer {authorization_bearer}",
            "Cache-Control": "no-cache",
        }

        res = post(APPINSPECT_API_VALIDATION_REQUEST, files=data, headers=headers)

        res.raise_for_status()

        request_id = res.json().get("request_id", None)
        APPINSPECT_API_VALIDATION_STATUS = (
            f"https://appinspect.splunk.com/v1/app/validate/status/{request_id}"
        )

        startTime = timeit.default_timer()
        # the first time, wait for 40 seconds. subsequent times, wait for less.
        # this is because appinspect takes some time to return, so there is no sense
        # checking many times when we know it will take at least 40 seconds to run.
        iteration_wait_time = 40
        while True:
            res = get(APPINSPECT_API_VALIDATION_STATUS, headers=headers)
            res.raise_for_status()
            status = res.json().get("status", None)
            if status in ["PROCESSING", "PREPARING"]:
                print(
                    f"[{self.getElapsedTime(startTime)}] Appinspect API is {status}..."
                )
                time.sleep(iteration_wait_time)
                iteration_wait_time = 1
                continue
            elif status == "SUCCESS":
                print(
                    f"[{self.getElapsedTime(startTime)}] Appinspect API has finished!"
                )
                break
            else:
                raise Exception(f"Error - Unknown Appinspect API status '{status}'")

        # We have finished running appinspect, so get the report
        APPINSPECT_API_REPORT = (
            f"https://appinspect.splunk.com/v1/app/report/{request_id}"
        )
        # Get human-readable HTML report
        headers = headers = {
            "Authorization": f"bearer {authorization_bearer}",
            "Content-Type": "text/html",
        }
        res = get(APPINSPECT_API_REPORT, headers=headers)
        res.raise_for_status()
        report_html = res.content

        # Get JSON report for processing
        headers = headers = {
            "Authorization": f"bearer {authorization_bearer}",
            "Content-Type": "application/json",
        }
        res = get(APPINSPECT_API_REPORT, headers=headers)
        res.raise_for_status()
        report_json = res.json()

        # Just get app path here to avoid long function calls in the open() calls below
        appPath = self.build_output_app_package_path
        appinpect_html_path = appPath.with_suffix(
            appPath.suffix + ".appinspect_api_results.html"
        )
        appinspect_json_path = appPath.with_suffix(
            appPath.suffix + ".appinspect_api_results.json"
        )
        # Use the full path of the app, but update the suffix to include info about appinspect
        with open(appinpect_html_path, "wb") as report:
            report.write(report_html)
        with open(appinspect_json_path, "w") as report:
            json.dump(report_json, report)

        self.parseAppinspectJsonLogFile(appinspect_json_path)

        return authorization_bearer

    def parseAppinspectJsonLogFile(
        self,
        logfile_path: pathlib.Path,
        status_types: list[str] = ["error", "failure", "manual_check", "warning"],
        exception_types: list[str] = ["error", "failure", "manual_check"],
    ) -> None:
        """Parse the appinspect JSON log file and raise Exception if any issues are found.

        Raises:
            Exception: if any issues are found in parsing the JSON file or
            with the appinspect results.

        Args:
            logfile_path (pathlib.Path): the path to the appinspect JSON log file
            status_types (list[str]): the list of status types to check for
            exception_types (list[str]): the list of exception types to check for

        Returns:
            None
        """
        if not set(exception_types).issubset(set(status_types)):
            raise Exception(
                f"Error - exception_types {exception_types} MUST be a subset of status_types {status_types}, but it is not"
            )
        with open(logfile_path, "r+") as logfile:
            j = json.load(logfile)
            # Seek back to the beginning of the file. We don't need to clear
            # it sice we will always write AT LEAST the same number of characters
            # back as we read (due to the addition of whitespace)
            logfile.seek(0)
            json.dump(
                j,
                logfile,
                indent=3,
            )

        reports = j.get("reports", [])
        if len(reports) != 1:
            raise Exception("Expected to find one appinspect report but found 0")
        verbose_errors = []

        for group in reports[0].get("groups", []):
            for check in group.get("checks", []):
                if check.get("result", "") in status_types:
                    verbose_errors.append(
                        f" - {check.get('result', '')} [{group.get('name', 'NONAME')}: {check.get('name', 'NONAME')}]"
                    )
        verbose_errors.sort()

        summary = j.get("summary", None)
        if summary is None:
            raise Exception("Missing summary from appinspect report")
        msgs = []
        generated_exception = False
        for key in status_types:
            if summary.get(key, 0) > 0:
                msgs.append(f" - {summary.get(key, 0)} {key}s")
                if key in exception_types:
                    generated_exception = True
        if len(msgs) > 0 or len(verbose_errors):
            summary = "\n".join(msgs)
            details = "\n".join(verbose_errors)
            summary = f"{summary}\nDetails:\n{details}"
            if generated_exception:
                raise Exception(
                    f"AppInspect found [{','.join(exception_types)}] that MUST be addressed to pass AppInspect API:\n{summary}"
                )
            else:
                print(
                    f"AppInspect found [{','.join(status_types)}] that MAY cause a failure during AppInspect API:\n{summary}"
                )
        else:
            print("AppInspect was successful!")

        return

    def check_detection_metadata(self) -> None:
        """Ensure correctness of the action.correlatonsearch.metadata value.

        Using a previous build, compare the savedsearches.conf files to detect any issues w/
        detection metadata. **NOTE**: Detection metadata validation can only be performed between
        two builds with the appropriate metadata structure. In ESCU, this was added as of release
        v4.39.0, so all current and previous builds for use with this feature must be this version
        or greater.

        """
        # TODO (#282): We should be inspect the same artifact we're passing around from the
        #   build stage ideally
        # Unpack the savedsearch.conf of each app package
        current_build_conf = SavedsearchesConf.init_from_package(
            package_path=self.build_output_app_package_path,
            app_name=self.content.app._shared_app_settings.content_prefix,
            appid=self.content.app._shared_app_settings.id,
        )
        previous_build_conf = SavedsearchesConf.init_from_package(
            package_path=self.old_app_path,
            app_name=self.content.app._shared_app_settings.content_prefix,
            appid=self.content.app._shared_app_settings.id,
        )

        # Compare the conf files
        validation_errors: dict[str, list[MetadataValidationError]] = {}

        for rule_name in previous_build_conf.savedsearch_stanzas:
            validation_errors[rule_name] = []
            # No detections should be removed from build to build
            if rule_name not in current_build_conf.savedsearch_stanzas:
                # It is okay if a detection has been removed. Just ensure that
                # it is supposed to be a removed piece of content.
                if rule_name in [rc.stanza_name for rc in self.content.removed_content]:
                    print(
                        f"[REMOVED INTENTIONALLY VIA DEPRECATION/REMOVAL PROCESS] - '{rule_name}'"
                    )
                    continue

                else:
                    validation_errors[rule_name].append(
                        DetectionMissingError(rule_name=rule_name)
                    )
                continue
            # Pull out the individual stanza for readability
            previous_stanza = previous_build_conf.savedsearch_stanzas[rule_name]
            current_stanza = current_build_conf.savedsearch_stanzas[rule_name]

            # Check to see if one or more of the stanzas does not have metadata. In
            # some cases, this is explicitly allowed.

            # It is allowed for neither stanza to have metadata
            if current_stanza.metadata is None and previous_stanza.metadata is None:
                # We don't need to enforce metadata here. It is a savedsearch
                # without metadata, so not a "Detection" which means it is not versioned.
                continue

            # It is forbidden for exactly one stanza (previous or current) to have metadata
            elif current_stanza.metadata is None or previous_stanza.metadata is None:
                if current_stanza.metadata:
                    current_stanza_metadata_dict = current_stanza.metadata.__dict__
                else:
                    current_stanza_metadata_dict = None
                if previous_stanza.metadata:
                    previous_stanza_metadata_dict = previous_stanza.metadata.__dict__
                else:
                    previous_stanza_metadata_dict = None

                # Raise the appropriate exception
                validation_errors[rule_name].append(
                    MissingMetadataError(
                        rule_name=rule_name,
                        current_stanza_metadata=current_stanza_metadata_dict,
                        previous_stanza_metadata=previous_stanza_metadata_dict,
                    )
                )

                # Since some metadata is missing, we can't continue with the rest of the checks.
                continue

            # Check to see if the detection_id has changed. If so, raise an exception.
            if (
                current_stanza.metadata.detection_id
                != previous_stanza.metadata.detection_id
            ):
                validation_errors[rule_name].append(
                    DetectionIDError(
                        rule_name=rule_name,
                        current_id=current_stanza.metadata.detection_id,
                        previous_id=previous_stanza.metadata.detection_id,
                    )
                )

            # Versions should never decrement in successive builds
            if (
                current_stanza.metadata.detection_version
                < previous_stanza.metadata.detection_version
            ):
                validation_errors[rule_name].append(
                    VersionDecrementedError(
                        rule_name=rule_name,
                        current_version=current_stanza.metadata.detection_version,
                        previous_version=previous_stanza.metadata.detection_version,
                    )
                )

            # Versions need to be bumped if the stanza changes at all
            if current_stanza.version_should_be_bumped(previous_stanza):
                validation_errors[rule_name].append(
                    VersionBumpingError(
                        rule_name=rule_name,
                        current_version=current_stanza.metadata.detection_version,
                        previous_version=previous_stanza.metadata.detection_version,
                    )
                )

            # Versions should never increase more than one version between releases
            if (
                current_stanza.metadata.detection_version
                > previous_stanza.metadata.detection_version + 1
            ):
                validation_errors[rule_name].append(
                    VersionBumpingTooFarError(
                        rule_name=rule_name,
                        current_version=current_stanza.metadata.detection_version,
                        previous_version=previous_stanza.metadata.detection_version,
                    )
                )

        # Convert our dict mapping to a flat list of errors for use in reporting
        validation_error_list = [
            x for inner_list in validation_errors.values() for x in inner_list
        ]

        # Report failure/success
        print("\nDetection Metadata Validation:")
        if len(validation_error_list) > 0:
            # Iterate over each rule and report the failures
            for rule_name in validation_errors:
                if len(validation_errors[rule_name]) > 0:
                    print(f"\t❌ {rule_name}")
                    for error in validation_errors[rule_name]:
                        print(f"\t\t🔸 {error.short_message}")
        else:
            # If no errors in the list, report success
            print(
                "\t✅ Detection metadata looks good and all versions were bumped appropriately :)"
            )

        # Raise an ExceptionGroup for all validation issues
        if len(validation_error_list) > 0:
            raise ExceptionGroup(
                "Validation errors when comparing detection stanzas in current and previous build:",
                validation_error_list,
            )

    def run(self) -> None:
        """Run Appinspect and metadata validation, if applicable."""
        # We always run appinspect against the api
        self.inspectAppAPI()

        if self.old_app_path is not None:
            self.check_detection_metadata()
        else:
            logger.info(
                "🟡 Detection metadata validation disabled "
                "since no previous version was provided. Skipping metadata validation."
            )
