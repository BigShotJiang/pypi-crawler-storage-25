"""Tool for porting a legacy security content directory to a new security content directory."""

import logging
import sys
import traceback
from pathlib import Path

from contentctl_ng.utilities.port_yml_file import port_all

logger = logging.getLogger(__name__)

PORT_HELP = "Usage: python demo_main.py PORT <original_security_content_dir> <port_security_content_dir> [--no-emit-manual-review]"
"original_security_content_dir: path to a 'legacy' security content directory. This must exist, and can be the results of a direct clone of github.com/splunk/security_content"
"port_security_content_dir: path to a 'new' security content directory. This directory will be created."


def port_command(port_args: list[str]) -> None:
    """Port content from a legacy security content directory to a new security content directory.

    Args:
        port_args (list[str]): The arguments to the PORT command. This should be a list of two strings:
            - The path to the original security content directory
            - The path to the ported security content directory
            - Optional: --dont_port_files_that_require_manual_review to skip emitting manual review files
    Returns:
        None - but as a result the ported security content directory will be created
    """
    if len(port_args) < 2 or len(port_args) > 3 or "--help" in port_args:
        logger.error(
            f"Invalid number of arguments to the PORT command. We received the following arguments: {port_args}"
        )
        logger.error(PORT_HELP)
        sys.exit(1)

    legacy_security_content_path = Path(port_args[0])
    ported_security_content_path = Path(port_args[1])
    if len(port_args) == 3:
        if port_args[2] != "--dont_port_files_that_require_manual_review":
            logger.error(
                f"Invalid argument to the PORT command. We received the following arguments: {port_args}"
            )
            logger.error(PORT_HELP)
            sys.exit(1)
        port_files_that_require_manual_review = False
    else:
        port_files_that_require_manual_review = True

    logger.info(
        f"Porting content from {legacy_security_content_path} to {ported_security_content_path}"
    )

    if not legacy_security_content_path.is_dir():
        logger.error(
            f"Original security content directory MUST exist at the following path, but it does not:{legacy_security_content_path.absolute()}"
        )
        sys.exit(1)

    if ported_security_content_path.exists():
        logger.error(
            f"Ported security content directory MUST NOT exist at the following path, but it does:{ported_security_content_path.absolute()}.\n"
            "Please manually remove this directory and run the PORT command again."
        )
        sys.exit(1)

    try:
        port_all(
            legacy_security_content_path,
            ported_security_content_path,
            port_files_that_require_manual_review,
        )
        logger.info(
            f"Successfully ported content from {legacy_security_content_path} to {ported_security_content_path}"
        )
    except Exception as e:
        # Because this is a dev workflow, we want to explicitly print the entire stacktrace
        # for debugging purposes
        traceback.print_exc(e)

        logger.error(f"Failed to port all content: {e}")
        sys.exit(1)
