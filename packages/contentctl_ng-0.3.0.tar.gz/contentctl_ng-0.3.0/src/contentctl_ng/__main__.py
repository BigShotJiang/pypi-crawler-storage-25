"""Allows the main cli entry to be invoked when running contentctl_ng as a module.

i.e.:
python -m contentctl_ng install
"""

from contentctl_ng.cli import main

if __name__ == "__main__":
    main()
