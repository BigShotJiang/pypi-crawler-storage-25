"""Run a test on your content."""

import logging
import os
from enum import StrEnum
from functools import cached_property
from pathlib import Path
from typing import Annotated, Any

import git
from pydantic import (
    AnyUrl,
    DirectoryPath,
    Field,
    FilePath,
    HttpUrl,
    SecretStr,
    UrlConstraints,
    model_validator,
)
from pydantic_settings import SettingsConfigDict

from contentctl_ng import TQDM_DISABLE_ENV_VAR
from contentctl_ng.contentctl_legacy_ported.contentctl import test_common_func
from contentctl_ng.contentctl_legacy_ported.objects.config import (
    All,
    Changes,
    Selected,
    test_servers,
)
from contentctl_ng.objects.macro import FilebackedMacro
from contentctl_ng.settings import (
    ContentSettings,
    SplunkSettings,
)
from contentctl_ng.utilities.common_io import load_yml_file_to_dict

logger = logging.getLogger(__name__)

SplunkUrl = Annotated[
    AnyUrl,
    UrlConstraints(allowed_schemes=["splunk"], host_required=True),
]


class TestType(StrEnum):
    """Enumeration of test types used in TestSettings."""

    # TODO: implement parse-only mode which roundtrips to services/search/parser to make sure spl is valid
    # PARSE = "parse"
    UNIT = "unit"
    # TODO: determine how "integration" testing will behave. Will it only run an integration test and fall back to unit if it fails? etc.
    INTEGRATION = "integration"
    ALL = "all"


class PostTestBehavior(StrEnum):
    """Enumeration of post-test behaviors used in TestSettings."""

    ALWAYS_PAUSE = "always_pause"
    PAUSE_ON_FAILURE = "pause_on_failure"
    NEVER_PAUSE = "never_pause"


class DetectionChoiceMode(StrEnum):
    """Enumeration of detection choice modes used in TestSettings."""

    CHANGED = "changed"
    ALL = "all"
    SELECTED = "selected"


class Tester(ContentSettings):
    """Object that handles running tests on the content app.

    Args:
        ContentSettings (ContentSettings): Settings for loading content.

    """

    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", populate_by_name=True
    )

    test_type: TestType = Field(
        description="Provide the type of test to run (unit, integration, all). 'integration' and 'all' options will be treated the same and will run a unit test followed by an integration test until testing is implemented without using legacy contentctl.",
        default=TestType.UNIT,
        alias="test-type",
    )

    post_test_behavior: PostTestBehavior = Field(
        description="Provide the post-test behavior regarding pausing of detections (always_pause, pause_on_failure, never_pause).",
        default=PostTestBehavior.PAUSE_ON_FAILURE,
        alias="post-test-behavior",
    )

    splunk_connection_strings: list[SplunkUrl] = Field(  # pyright: ignore[reportUnknownVariableType] - known issue with type checking Annotated types https://github.com/microsoft/pyright/issues/7126
        description='Provide a list of Splunk connection URLs for testing multiple Splunk instances. Each URL should be in the format splunk://username:password@host:port. If username, password, or host are not provided, their defaults will be used. Multiple URLs can be provided separated by commas (e.g. --splunk-connection-strings splunk://user1:pass1@host1:port1,splunk://user2:pass2@host2:port2), by specifying the argument multiple times (e.g. --splunk-connection-strings splunk://user1:pass1@host1:port1 --splunk-connection-strings splunk://user2:pass2@host2:port2), or in a JSON-style array of strings (e.g. --splunk-connection-strings \'["splunk://user1:pass1@host1:port1","splunk://user2:pass2@host2:port2"]\').',
        default=[
            SplunkUrl(  # pyright: ignore[reportUnknownArgumentType, reportCallIssue] - known issue with type checking Annotated types https://github.com/microsoft/pyright/issues/7126
                f"splunk://{SplunkSettings.model_fields['splunk_username'].default}:{SplunkSettings.model_fields['splunk_password'].default.get_secret_value()}@{SplunkSettings.model_fields['splunk_host'].default}:{SplunkSettings.model_fields['splunk_api_port'].default}"
            )
        ],
        alias="splunk-connection-strings",
    )

    mode: DetectionChoiceMode = Field(
        description=f"Choose which detections to run tests on ({', '.join(set(DetectionChoiceMode))}). For 'changed' mode, tests will be run on detections that have changed compared to a provided git ref. For 'all' mode, tests will be run on all detections in the content directories. For 'selected' mode, tests will be run on detections found in provided file or directory paths.",
        default=DetectionChoiceMode.CHANGED,
    )

    git_ref: str | None = Field(
        description="(For 'changed' mode) Provide a git ref (branch, tag, commit) to compare against. If 'changed' mode is selected, this will instead default to 'HEAD'.",
        default=None,
        alias="git-ref",
    )

    detection_paths: list[FilePath | DirectoryPath] | None = Field(
        description="(For 'selected' mode) Provide a list of files or directories to search through for detections to test. Paths can be provided separated by commas (e.g. --detection-paths path1,path2), by specifying the argument multiple times (e.g. --detection-paths path1 --detection-paths path2), or in a JSON-style array of strings (e.g. --detection-paths '[\"path1\",\"path2\"]'). Space-separated filenames (e.g. --detection-paths path1 path2) and wildcard expansion (e.g. --detection-paths path*) are not supported since this is a named argument.",
        default=None,
        alias="detection-paths",
    )

    @classmethod
    def _validate_changed_mode(cls, values: dict[str, Any]) -> dict[str, Any]:
        if values.get("detection_paths") is not None:
            raise ValueError(
                "For 'changed' mode, detection paths should not be provided. Please provide a git ref to compare against instead."
            )
        if values.get("git_ref") is None:
            values["git_ref"] = "HEAD"
        if len(values.get("content_dirs", [])) > 1:
            # TODO: support detection testing using changed mode with multiple content directories
            raise NotImplementedError(
                "Detection testing using 'changed' mode with multiple content directories is not supported yet."
            )
        try:
            repo = git.Repo(Path.cwd())
            repo.commit(values["git_ref"])
        except git.BadName:
            raise ValueError(
                f"The provided git ref '{values['git_ref']}' is not a valid branch, tag, or commit in the current repository."
            )
        except git.InvalidGitRepositoryError:
            raise ValueError(
                "The current working directory is not the root of a git repository."
            )
        return values

    @classmethod
    def _validate_all_mode(cls, values: dict[str, Any]) -> dict[str, Any]:
        if (
            values.get("git_ref") is not None
            or values.get("detection_paths") is not None
        ):
            raise ValueError(
                "For 'all' mode, git refs or detection paths should not be provided."
            )
        return values

    @classmethod
    def _validate_selected_mode(cls, values: dict[str, Any]) -> dict[str, Any]:
        if values.get("git_ref") is not None:
            raise ValueError(
                "For 'selected' mode, git refs should not be provided. Please provide a list of files or directories to search through for detections to test instead."
            )
        # effectively checks for None or empty list the same way and satisfies static type checkers that expect a list
        detection_list = values.get("detection_paths", [])
        # filter out empty strings in detection list
        detection_list = [x for x in detection_list if x]
        if len(detection_list) == 0:
            raise ValueError(
                "For 'selected' mode, provide a list of files or directories to search through for detections to test."
            )
        return values

    @model_validator(mode="before")
    def validate_detection_choice(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Validate the detection choice based on the selected mode."""
        # convert applicable hyphenated CLI args to snake_case so they can be checked by a single field name in the before validator
        if "git-ref" in values:
            values["git_ref"] = values.pop("git-ref")
        if "detection-paths" in values:
            values["detection_paths"] = values.pop("detection-paths")
        if "content-dirs" in values:
            values["content_dirs"] = values.pop("content-dirs")
        mode = values.get("mode", DetectionChoiceMode.CHANGED)
        if mode not in set(DetectionChoiceMode):
            raise ValueError(
                f"Mode must be one of ({', '.join(set(DetectionChoiceMode))})."
            )
        if mode == DetectionChoiceMode.CHANGED:
            values = cls._validate_changed_mode(values)
        elif mode == DetectionChoiceMode.ALL:
            values = cls._validate_all_mode(values)
        elif mode == DetectionChoiceMode.SELECTED:
            values = cls._validate_selected_mode(values)
        return values

    @cached_property
    def splunk_settings_list(self) -> list[SplunkSettings]:
        """Parse the splunk_url and return a list of SplunkSettings objects.

        Returns:
            list[SplunkSettings]: List of SplunkSettings objects.
        """
        splunk_settings_list: list[SplunkSettings] = []
        for splunk_connection_string in self.splunk_connection_strings:
            splunk_settings = {}
            if splunk_connection_string.host is not None:
                splunk_settings["splunk_host"] = splunk_connection_string.host
            if splunk_connection_string.port is not None:
                splunk_settings["splunk_api_port"] = splunk_connection_string.port
            if splunk_connection_string.username is not None:
                splunk_settings["splunk_username"] = splunk_connection_string.username
            if splunk_connection_string.password is not None:
                splunk_settings["splunk_password"] = SecretStr(
                    splunk_connection_string.password
                )
            splunk_settings_list.append(SplunkSettings.model_validate(splunk_settings))
        return splunk_settings_list

    @cached_property
    def legacy_splunk_settings_list_string(self) -> str:
        """Return a string in the server_info format expected by legacy contentctl."""
        return ";".join(
            [
                f"{s.splunk_host},{s.splunk_username},{s.splunk_password.get_secret_value()},{HttpUrl(s.splunk_web_session.base_url).port},{HttpUrl(s.splunk_hec_session.base_url).port},{s.splunk_api_port}"
                for s in self.splunk_settings_list
            ]
        )

    @cached_property
    def detection_file_paths(self) -> list[FilePath] | None:
        """Return a list of file paths for detections to test based on the selected mode and associated parameters."""
        if self.detection_paths is not None:
            detection_file_paths: list[FilePath] = []
            for path in self.detection_paths:
                if path.is_file():
                    detection_file_paths.append(path)
                elif path.is_dir():
                    detection_file_paths.extend(path.rglob("*.yml"))
            return detection_file_paths

    @cached_property
    def legacy_testing_mode_object(self) -> Selected | All | Changes:
        """Return an object representing the testing mode in a format expected by legacy contentctl."""
        # we need a couple extra not-None checks to make the type checker happy, even though those are guaranteed by the model validators
        if self.mode == DetectionChoiceMode.CHANGED and self.git_ref is not None:
            return Changes(mode_name="Changes", target_branch=self.git_ref)
        elif self.mode == DetectionChoiceMode.ALL:
            return All(mode_name="All")
        elif (
            self.mode == DetectionChoiceMode.SELECTED
            and self.detection_file_paths is not None
        ):
            return Selected(mode_name="Selected", files=self.detection_file_paths)
        else:
            # should be unreachable with model validator, just for type checker satisfaction
            raise ValueError(
                f"Invalid mode: {self.mode}. Mode must be one of ({', '.join(set(DetectionChoiceMode))})."
            )

    def run(self) -> None:
        """Tests the content app."""
        if self.test_type in (TestType.INTEGRATION, TestType.ALL):
            logger.info(
                f"Running with test type {self.test_type}. Both unit and integration tests will be run."
            )

        # TODO: Open and parse the contentctl.yml file. It is presently
        # required for support via the LEGACY test workflow. This dependency
        # will be removed in the near future as this workflow matures and
        # is updated.

        logger.debug(
            f"Looking for contentctl.yml file at: {self.legacy_contentctl_yml_file}"
        )
        try:
            config_dict = load_yml_file_to_dict(self.legacy_contentctl_yml_file)
            logger.debug(
                f"Successfully loaded contentctl.yml file at: {self.legacy_contentctl_yml_file}"
            )
        except FileNotFoundError:
            logger.error(
                f"contentctl.yml file not found at {self.legacy_contentctl_yml_file}. It must be present there as it is required for the LEGACY contentctl test workflow."
            )
            raise

        logger.debug("Building legacy contentctl test args")
        legacy_test_args: dict[str, Any] = {
            # TODO: Tie this up to incoming CLI updates. For now, this comment is provided as inline documentation for what this string looks like
            # "server_info": "127.0.0.1,admin,password,8000,8088,8089;127.0.0.2,admin,password,8000,8088,8089",
            "server_info": self.legacy_splunk_settings_list_string,
            "disable_tqdm": bool(
                os.getenv(TQDM_DISABLE_ENV_VAR)
            ),  # treat disable_tqdm with the same logic as TQDM's own disable logic based on its global env var
            "post_test_behavior": self.post_test_behavior.value,
            "path": self.root_dir,
            "enable_integration_testing": self.test_type
            in {TestType.INTEGRATION, TestType.ALL},
            "mode": self.legacy_testing_mode_object,
        }
        logger.debug("Successfully built legacy contentctl test args")

        # In dictA | dictB, dictB takes precedence
        config_object = test_servers.model_validate(config_dict | legacy_test_args)
        logger.debug("Successfully validated legacy contentctl test args")

        # Check for the presence of test data caches and, if they are missing, print some info
        # about how to get them
        logger.debug("Checking for the existence of Attack Data Cache(s)")
        config_object.check_test_data_caches()

        # Actually run the test, including conversion of contentctl-ng style objects to
        # legacy contentctl objects
        test_common_func(
            config_object,
            self.content.detections,
            # Filter out all of the InlineMacros, which cannot impact tests since
            # they are not backed by files that may have changed
            [
                macro
                for macro in self.content.macros
                if isinstance(macro, FilebackedMacro)
            ],
            self.content.csv_lookups + self.content.kvstore_lookups,  # pyright: ignore[reportArgumentType] - doesn't comply with test_common_func typing, but this is the expected format for legacy contentctl and it works fine, so we will ignore the type checker here
            self.content.data_sources,
        )
