"""Very simple demo that will parse security content objects."""

import logging
import sys
from pathlib import Path

from contentctl_ng.port import PORT_HELP, port_command

logger = logging.getLogger(__name__)

APP_DOT_YAML_FILE = Path("app.yml")
USAGE_STATEMENT = f"Usage: python demo_main.py [PORT]:\n{PORT_HELP}\n"
if len(sys.argv) < 2 or "--help" in sys.argv:
    logger.info(USAGE_STATEMENT)
    sys.exit(0)

if sys.argv[1] == "PORT":
    port_command(sys.argv[2:])
else:
    print(f"Invalid command: {sys.argv[1]}. Valid commands are only 'PORT'.")
    print(USAGE_STATEMENT)
    sys.exit(1)
