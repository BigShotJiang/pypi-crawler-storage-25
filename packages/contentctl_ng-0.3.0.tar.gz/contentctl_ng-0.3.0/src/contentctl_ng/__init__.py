"""Allows contentctl_ng to be used as a package."""

import os
import sys

TQDM_DISABLE_ENV_VAR = "TQDM_DISABLE"

if not sys.stderr.isatty() and TQDM_DISABLE_ENV_VAR not in os.environ:
    # If stderr is not a terminal and the envvar is not already set, disable tqdm progress bars to avoid messy output
    os.environ[TQDM_DISABLE_ENV_VAR] = "true"
