"""Legacy contentctl entry point functions.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import logging

from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.GitService import (
    GitService,
)
from contentctl_ng.contentctl_legacy_ported.actions.test import Test, TestInputDto
from contentctl_ng.contentctl_legacy_ported.objects.config import (
    test_common,
)
from contentctl_ng.contentctl_legacy_ported.objects.errors import (
    AttackDataMissingFromRepoError,
)
from contentctl_ng.contentctl_legacy_ported.objects.rba import (
    RBAObject as LegacyRBAObject,
)
from contentctl_ng.contentctl_legacy_ported.objects.rba import (
    RiskObject as LegacyRiskObject,
)
from contentctl_ng.contentctl_legacy_ported.objects.rba import (
    ThreatObject as LegacyThreatObject,
)
from contentctl_ng.contentctl_legacy_ported.objects.TestOnlyDetection import (
    ContentStatus,
    TestOnlyDetection,
)

# Some Secuirty Content NG imports
from contentctl_ng.objects.data_source import DataSource as ng_DataSource
from contentctl_ng.objects.lookup import Lookup as ng_Lookup
from contentctl_ng.objects.macro import FilebackedMacro as ng_FilebackedMacro
from contentctl_ng.objects.searches.detection import EventBasedDetection as ng_Detection
from contentctl_ng.objects.searches.search import (
    ExperimentalTest as ng_ExperimentalTest,
)
from contentctl_ng.objects.searches.search import UnitTest as ng_UnitTest

logger = logging.getLogger(__name__)


def test_common_func(
    config: test_common,
    ng_detections: list[ng_Detection],
    ng_macros: list[ng_FilebackedMacro],
    ng_lookups: list[ng_Lookup],
    ng_datasources: list[ng_DataSource],
):
    """Execute common test workflow for security content.

    Args:
        config: Test configuration.
        ng_detections: List of detections to test.
        ng_macros: List of macros.
        ng_lookups: List of lookups.
        ng_datasources: List of data sources.

    Raises:
        Exception: If any test fails.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """
    logger.debug("Beginning legacy contentctl test workflow")

    gitServer = GitService(
        detections=ng_detections,
        macros=ng_macros,
        lookups=ng_lookups,
        datasources=ng_datasources,
        config=config,
    )
    detections_to_test = gitServer.getContent()

    logger.info(
        f"Found {len(detections_to_test)} detections to test. They will be converted to legacy format for testing."
    )
    # Detections must be converted from the contentctl-ng EventBasedDetection format to th
    # Legacy TestOnlyDetection format. This is required so that they can run in the context
    # of the largely unmodified legacy contentctl test code workflow.
    detections_converted: list[TestOnlyDetection] = []

    # Iterate through all the contentctl-ng EventBased Detections, alphabetically,
    # for the sake of consistency.
    collected_exceptions: list[tuple[str, Exception]] = []
    for detection in sorted(detections_to_test):
        try:
            ported_rba_object = None
            # Only intermediate finding entities generate action.risk events; those are the
            # only events the legacy risk event validator checks against rba.risk_objects.
            # The finding entity (if any) generates action.notable — validated separately via
            # NotableEvent.validate_against_detection (see notable_event.py).
            # Detections with no intermediate findings (TTP w/ no IFs, Correlation, Hunting)
            # emit no risk events, so rba stays None for those.
            if detection.intermediate_findings is not None:
                sorted_entities = sorted(detection.intermediate_findings.entities)
                ported_rba_object = LegacyRBAObject(
                    # RBAObject.message is no longer read by the legacy test validator;
                    # validate_risk_message resolves the message from the matched entity
                    # directly via get_matched_risk_object. Populated here because
                    # RBAObject.message is a required field with no default.
                    message=sorted_entities[0].message.root,
                    risk_objects={
                        LegacyRiskObject(
                            field=e.field,
                            type=e.type,
                            score=e.score,
                            # message intentionally not passed; falls back to default "".
                            # The legacy validator resolves each entity's message directly
                            # via get_matched_risk_object — this field is unused.
                        )
                        for e in sorted_entities
                    },
                    threat_objects={
                        LegacyThreatObject(
                            field=t.field,
                            type=t.type,
                        )
                        for t in detection.threat_objects
                    },
                )

            # All tests must also be converted.  Legacy contentctl does not have a notion of
            # and "experimental" test type - effectively all tests annotated in legacy contentctl
            # detection objects are "unit" tests according to contentctl-ng.
            ported_tests_object = []

            # Track whether or not we found at least one unit test.  This is essentially an analog
            # for setting the content of the "manual_test" field in the legacy contentctl detection.
            # In legacy contentctl, if a detection was marked production:
            # 1. It required at least one test
            # 2. We would, of course, actually run that test...
            # UNLESS it had a manual_test field which was not None (and contained a string).
            # In that case, the we would not require a test and, if one was provided, it would be skipped.
            # In contentctl-ng, production detection needs at least one test. If the test is intended to be
            # run, it is marked as a unit test. If it is intended to be skipped, it is marked as experimental.
            # Thusly, all legacy production manual_test detections with tests were ported to
            # production detections with experimental tests.
            at_least_one_unit_test_present = False

            for detection_test in detection.tests:
                if isinstance(detection_test, ng_ExperimentalTest) or isinstance(
                    detection_test, ng_UnitTest
                ):
                    # These should still be converted to legacy tests and will be skipped during actual testing time.
                    # They will either be skipped because their detection's status is experimental (not production)
                    # OR because they are intended to be a manual test.

                    if isinstance(detection_test, ng_UnitTest):
                        at_least_one_unit_test_present = True

                    # Explicitly get the name and tests
                    test_name: str = detection_test.name
                    legacy_attack_data_dicts: list[dict[str, str]] = []

                    # Explicitly convert the attack data to the legacy format
                    for attack_data in detection_test.attack_data:
                        legacy_test_object: dict[str, str] = {}

                        legacy_test_object["source"] = attack_data.source
                        legacy_test_object["sourcetype"] = attack_data.sourcetype
                        # Explicitly convert the index to the custom_index field, even if
                        # it is the "default" index.  This is required because contentctl-ng
                        # does have an explicit index vs. custom_index field, so by the time
                        # we have parsed the content we are unsure if it is the default index
                        # or a truly custom one. Since it does not impact functionality at test
                        # time, this is okay.
                        legacy_test_object["custom_index"] = attack_data.index
                        legacy_test_object["data"] = attack_data.data

                        legacy_attack_data_dicts.append(legacy_test_object)

                    ported_tests_object.append(
                        {"name": test_name, "attack_data": legacy_attack_data_dicts}
                    )

                else:
                    raise ValueError(
                        f"Unknown test type for {detection.name} of test type: {type(detection_test)}. "
                        f"Only the types {type(ng_ExperimentalTest)} and {type(ng_UnitTest)} are supported and should exist."
                    )

            if detection.status == ContentStatus.production:
                if at_least_one_unit_test_present:
                    # No need to generate a manual_test description.
                    # This is a regular production detection with regular test(s)
                    manual_test_description = None
                else:
                    # This is a production detection with only experimental tests.  Generate some legacy manual_test
                    # string to pass to TestOnlyDetection Constructor
                    experimental_test_descriptions = ";".join(
                        [test.description or "" for test in detection.tests]
                    )

                    manual_test_description = (
                        "This detection is marked as production, but does not have any unit tests. "
                        f"It has [{len(detection.tests)}] experimental test(s). This is the equivalent of a manual test in legacy contentctl. "
                        f"The text of the experimental test(s) is as follows: [{experimental_test_descriptions}]"
                    )

            elif detection.status in (
                ContentStatus.experimental,
                ContentStatus.deprecated,
            ):
                # This is an experimental or deprecated detection, and would not be tested anyway.
                # As such we should not supply manual_test information as it changes the generation
                # of the test_results/summary.yml file from the legacy behavior.
                manual_test_description = None
            else:
                raise ValueError(
                    f"Unexpected Status for contentctl-ng detection [{detection.name}]: [{detection.status}]. This should never happen!"
                )

            # We build this into a dictionary, then use model_validate rather than a direct constructor for two reasons:
            # 1. Primarily, we need to be able to pass context to the constructor.
            # This is most relevant for mapping attack_data to local attack_data files.
            # 2. Secondly, this more closely mirrors the way theat content constructions
            # works in legacy contentctl test (read a dict from a file and then model_validate it)
            detection_info_dict = {
                "name": detection.name,
                "id": detection.id,
                "full_conf_stanza_name": detection.stanza_name,
                "type": detection.type,
                "version": detection.version,
                "status": detection.status,
                "search": detection.search.root,
                "rba": ported_rba_object,
                # Populated from detection.finding.entity for use by
                # NotableEvent.validate_against_detection.
                # None for Anomaly/Hunting detections which have no finding.
                "notable_entity": LegacyRiskObject(
                    field=detection.finding.entity.field,
                    type=detection.finding.entity.type,
                    score=detection.finding.entity.score,
                )
                if detection.finding is not None
                else None,
                # Populated from detection.finding.title.root for use by
                # NotableEvent.validate_against_detection.
                # Stored as a plain str — EsTokenString is not needed in the legacy layer.
                # None for Anomaly/Hunting detections which have no finding.
                "finding_title": detection.finding.title.root
                if detection.finding is not None
                else None,
                "manual_test": manual_test_description,
                "file_path": detection._path,
                "baselines": [b.name for b in detection.baselines],
                # Do not pass through experimental tests
                "tests": ported_tests_object,
                "security_domain": detection.security_domain,
                "analytic_story": [story.name for story in detection.analytic_story],
                "mitre_attack_id": [
                    mitre_attack_id for mitre_attack_id in detection.mitre_attack_id
                ],
                "data_source": [
                    " AND ".join(ds_pair) for ds_pair in detection.data_source
                ],
                "source": detection.category,
            }
            t = TestOnlyDetection.model_validate(
                detection_info_dict, context={"config": config}
            )

            detections_converted.append(t)
        except AttackDataMissingFromRepoError as e:
            collected_exceptions.append((detection._path.name, e))

        except Exception as e:
            collected_exceptions.append((detection._path.name, e))

    # If there we any exceptions, print them out here and raise an exception
    # that is handled by the caller.
    if len(collected_exceptions):
        all_exceptions = "\n".join(
            [f"{name}: {e!s}" for name, e in collected_exceptions]
        )
        raise Exception(
            f"There were exceptions during detection conversion:\n{all_exceptions}"
        )

    logger.info(
        f"Successfully ported [{len(detections_converted)}] detections to legacy format."
    )
    # Counter-intuitively, we want this in reverse order because of how these are added
    # removed from the testing queue (using .pop() to remove from the end).
    # Reversing this list here means that we will test in alphabetical order.
    detections_converted.reverse()

    # At this point, the only content that is needed is the detections!
    test_input_dto = TestInputDto(detections_converted, config)

    t = Test()
    t.filter_tests(test_input_dto)

    if config.plan_only:
        # Emit the test plan and quit. Do not actually run the test
        config.dumpCICDPlanAndQuit(gitServer.getHash(), test_input_dto.detections)
        return

    success = t.execute(test_input_dto)

    if success:
        # Everything passed!
        logger.info("All tests have run successfully or been marked as 'skipped'")
        return
    raise Exception("There was at least one unsuccessful test")
