"""YAML file writer utilities for security content objects.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from enum import IntEnum, StrEnum
from typing import Any

import yaml

# Set the following so that we can write StrEnum and IntEnum
# to files. Otherwise, we will get the following errors when trying
# to write to files:
# yaml.representer.RepresenterError: ('cannot represent an object',.....
yaml.SafeDumper.add_multi_representer(
    StrEnum, yaml.representer.SafeRepresenter.represent_str
)

yaml.SafeDumper.add_multi_representer(
    IntEnum, yaml.representer.SafeRepresenter.represent_int
)


class YmlWriter:
    """Utility class for writing security content objects to YAML files.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    @staticmethod
    def writeYmlFile(file_path: str, obj: dict[Any, Any]) -> None:
        """Write a dictionary object to a YAML file.

        Args:
            file_path: Path where the YAML file will be written.
            obj: Dictionary object to serialize to YAML.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        with open(file_path, "w") as outfile:
            yaml.safe_dump(obj, outfile, default_flow_style=False, sort_keys=False)

    @staticmethod
    def writeDetection(file_path: str, obj: dict[Any, Any]) -> None:
        """Write a detection object to a YAML file with standardized field ordering.

        Args:
            file_path: Path where the detection YAML file will be written.
            obj: Detection dictionary containing fields like name, id, version, search, etc.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        output = dict()
        output["name"] = obj["name"]
        output["id"] = obj["id"]
        output["version"] = obj["version"]
        output["date"] = obj["date"]
        output["author"] = obj["author"]
        output["type"] = obj["type"]
        output["status"] = obj["status"]
        output["data_source"] = obj["data_sources"]
        output["description"] = obj["description"]
        output["search"] = obj["search"]
        output["how_to_implement"] = obj["how_to_implement"]
        output["known_false_positives"] = obj["known_false_positives"]
        output["references"] = obj["references"]
        output["tags"] = obj["tags"]
        output["tests"] = obj["tags"]

        YmlWriter.writeYmlFile(file_path=file_path, obj=output)

    @staticmethod
    def writeStory(file_path: str, obj: dict[Any, Any]) -> None:
        """Write a story object to a YAML file with standardized field ordering.

        Args:
            file_path: Path where the story YAML file will be written.
            obj: Story dictionary containing fields like name, id, version, narrative, etc.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        output = dict()
        output["name"] = obj["name"]
        output["id"] = obj["id"]
        output["version"] = obj["version"]
        output["date"] = obj["date"]
        output["author"] = obj["author"]
        output["description"] = obj["description"]
        output["narrative"] = obj["narrative"]
        output["references"] = obj["references"]
        output["tags"] = obj["tags"]

        YmlWriter.writeYmlFile(file_path=file_path, obj=output)
