"""Base test result classes and status enums.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from enum import StrEnum
from typing import Any, Union

from pydantic import BaseModel, ConfigDict
from splunklib.data import Record  # type: ignore

from contentctl_ng.contentctl_legacy_ported.helper.utils import Utils


# TODO (#267): Align test reporting more closely w/ status enums (as it relates to "untested")
# TODO (PEX-432): add status "UNSET" so that we can make sure the result is always of this enum
#   type; remove mypy ignores associated w/ these typing issues once we do
class TestResultStatus(StrEnum):
    """Enum for test status (e.g. pass/fail).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # Test failed (detection did NOT fire appropriately)
    FAIL = "fail"

    # Test passed (detection fired appropriately)
    PASS = "pass"

    # Test skipped (nothing testable at present)
    SKIP = "skip"

    # Error/exception encountered during testing (e.g. network error); considered a failure as well
    # for the purpose aggregate metric gathering
    ERROR = "error"

    def __str__(self) -> str:
        """Return string representation of test result status.

        Returns:
            Status value as string.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return self.value


# TODO (#225): add validator to BaseTestResult which makes a lack of exception incompatible
#   with status ERROR
class BaseTestResult(BaseModel):
    """Base class for test results.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # Message for the result
    message: Union[None, str] = None

    # Any exception that was raised (may be None)
    exception: Union[Exception, None] = None

    # The status (PASS, FAIL, SKIP, ERROR)
    status: Union[TestResultStatus, None] = None

    # The duration of the test in seconds
    duration: float = 0

    # The search job metadata
    job_content: Union[Record, None] = None

    # The Splunk endpoint URL
    sid_link: Union[None, str] = None

    # Needed to allow for embedding of Exceptions in the model
    model_config = ConfigDict(validate_assignment=True, arbitrary_types_allowed=True)

    @property
    def passed(self) -> bool:
        """Return True if status is PASS; False otherwise (SKIP, FAIL, ERROR).

        Returns:
            Bool indicating success/failure.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return self.status == TestResultStatus.PASS

    @property
    def success(self) -> bool:
        """Return True if status is PASS or SKIP; False otherwise (FAIL, ERROR).

        Returns:
            Bool indicating success/failure.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return self.status in [TestResultStatus.PASS, TestResultStatus.SKIP]

    @property
    def failed(self) -> bool:
        """Return True if status is FAIL or ERROR; False otherwise (PASS, SKIP).

        Returns:
            Bool indicating failure if True.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            self.status == TestResultStatus.FAIL
            or self.status == TestResultStatus.ERROR
        )

    @property
    def complete(self) -> bool:
        """Return True when a test is complete (i.e. the result has been given a status).

        Returns:
            Bool indicating the test is complete (has a status) if True.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return self.status is not None

    def get_summary_dict(
        self,
        model_fields: list[str] = [
            "success",
            "exception",
            "message",
            "sid_link",
            "status",
            "duration",
            "wait_duration",
        ],
        job_fields: list[str] = ["search", "resultCount", "runDuration"],
    ) -> dict[str, Any]:
        """Aggregate a dictionary summarizing the test result model.

        Args:
            model_fields: The fields of the test result to gather.
            job_fields: The fields of the job content to gather.

        Returns:
            A dict summary.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Init the summary dict
        summary_dict: dict[str, Any] = {}

        # Grab the fields required
        for field in model_fields:
            if getattr(self, field, None) is not None:
                # Exceptions and enums cannot be serialized, so convert to str
                if isinstance(getattr(self, field), Exception):
                    summary_dict[field] = str(getattr(self, field))
                elif isinstance(getattr(self, field), StrEnum):
                    summary_dict[field] = str(getattr(self, field))
                else:
                    summary_dict[field] = getattr(self, field)
            else:
                # If field can't be found, set it to None (useful as unit and integration tests have
                # small differences in the number of fields they share)
                summary_dict[field] = None

        # Grab the job content fields required
        for field in job_fields:
            if self.job_content is not None:
                value: Any = self.job_content.get(field, None)  # type: ignore

                # convert runDuration to a fixed width string representation of a float
                if field == "runDuration":
                    try:
                        value = Utils.getFixedWidth(float(value), 3)
                    except Exception:
                        value = Utils.getFixedWidth(0, 3)
                summary_dict[field] = value
            else:
                # If no job content, set all fields to None
                summary_dict[field] = None

        # Return the summary_dict
        return summary_dict
