"""Integration test model for detection testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from pydantic import Field

from contentctl_ng.contentctl_legacy_ported.objects.base_test import BaseTest, TestType
from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    TestResultStatus,
)
from contentctl_ng.contentctl_legacy_ported.objects.integration_test_result import (
    IntegrationTestResult,
)
from contentctl_ng.contentctl_legacy_ported.objects.unit_test import UnitTest


class IntegrationTest(BaseTest):
    """An integration test for a detection against ES.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # The test type (integration)
    test_type: TestType = Field(default=TestType.INTEGRATION)

    # The test result
    result: IntegrationTestResult | None = None

    @classmethod
    def derive_from_unit_test(cls, unit_test: UnitTest) -> "IntegrationTest":
        """Construct an IntegrationTest from a UnitTest.

        Args:
            unit_test: The UnitTest.

        Returns:
            IntegrationTest instance.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return cls(
            name=unit_test.name,
            earliest_time=unit_test.earliest_time,
            latest_time=unit_test.latest_time,
        )

    def skip(self, message: str) -> None:
        """Skip the test by setting its result status.

        Args:
            message: The reason for skipping.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        self.result = IntegrationTestResult(  # type: ignore
            message=message, status=TestResultStatus.SKIP
        )
