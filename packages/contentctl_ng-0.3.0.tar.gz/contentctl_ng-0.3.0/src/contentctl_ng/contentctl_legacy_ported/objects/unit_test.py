"""Unit test model for detection testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from __future__ import annotations

from pydantic import Field

from contentctl_ng.contentctl_legacy_ported.objects.base_test import BaseTest, TestType
from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    TestResultStatus,
)
from contentctl_ng.contentctl_legacy_ported.objects.test_attack_data import (
    TestAttackData,
)
from contentctl_ng.contentctl_legacy_ported.objects.unit_test_result import (
    UnitTestResult,
)


class UnitTest(BaseTest):
    """A unit test for a detection.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # contentType: SecurityContentType = SecurityContentType.unit_tests

    # The test type (unit)
    test_type: TestType = Field(default=TestType.UNIT)

    # The attack data to be ingested for the unit test
    attack_data: list[TestAttackData]

    # The result of the unit test
    result: UnitTestResult | None = None

    def skip(self, message: str) -> None:
        """Skip the test by setting its result status.

        Args:
            message: The reason for skipping.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        self.result = UnitTestResult(  # type: ignore
            message=message, status=TestResultStatus.SKIP
        )
