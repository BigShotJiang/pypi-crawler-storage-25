"""Notable action model for Adaptive Response Actions.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from typing import Any

from pydantic import BaseModel


class NotableAction(BaseModel):
    """Representation of a notable action.

    Note:
        This is NOT a representation of notable generated as a result of detection firing, but rather of the Adaptive
        Response Action that generates the notable.

    Args:
        rule_name: The name of the rule (detection/search) associated with the notable action (e.g. "ESCU -
            Windows Modify Registry EnableLinkedConnections - Rule").
        rule_description: A description of the rule (detection/search) associated with the notable action.
        security_domain: The domain associated with the notable action and related rule (detection/search).
        severity: Severity (e.g. "high") associated with the notable action and related rule (detection/search).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    rule_name: str
    rule_description: str
    security_domain: str
    severity: str

    @classmethod
    def parse_from_dict(cls, dict_: dict[str, Any]) -> "NotableAction":
        """Parse specific keys from a dictionary to construct the instance.

        Args:
            dict_: A dictionary with the expected keys.

        Returns:
            An instance of NotableAction.

        Raises:
            KeyError: If the dictionary given does not contain a required key.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return cls(
            rule_name=dict_["action.notable.param.rule_title"],
            rule_description=dict_["action.notable.param.rule_description"],
            security_domain=dict_["action.notable.param.security_domain"],
            severity=dict_["action.notable.param.severity"],
        )
