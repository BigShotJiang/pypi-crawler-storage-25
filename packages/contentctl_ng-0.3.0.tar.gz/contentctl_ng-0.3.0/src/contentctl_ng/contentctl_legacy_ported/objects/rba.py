"""Risk-Based Alerting (RBA) models and types.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Annotated, Set

from pydantic import BaseModel, Field, model_serializer

RiskScoreValue_Type = Annotated[int, Field(ge=1, le=100)]


class RiskObjectType(str, Enum):
    """Risk object type enumeration.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    SYSTEM = "system"
    USER = "user"
    OTHER = "other"


class ThreatObjectType(str, Enum):
    """Threat object type enumeration.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    CERTIFICATE_COMMON_NAME = "certificate_common_name"
    CERTIFICATE_ORGANIZATION = "certificate_organization"
    CERTIFICATE_SERIAL = "certificate_serial"
    CERTIFICATE_UNIT = "certificate_unit"
    COMMAND = "command"
    DOMAIN = "domain"
    EMAIL_ADDRESS = "email_address"
    EMAIL_SUBJECT = "email_subject"
    FILE_HASH = "file_hash"
    FILE_NAME = "file_name"
    FILE_PATH = "file_path"
    HTTP_USER_AGENT = "http_user_agent"
    IP_ADDRESS = "ip_address"
    PROCESS = "process"
    PROCESS_NAME = "process_name"
    PARENT_PROCESS = "parent_process"
    PARENT_PROCESS_NAME = "parent_process_name"
    PROCESS_HASH = "process_hash"
    REGISTRY_PATH = "registry_path"
    REGISTRY_VALUE_NAME = "registry_value_name"
    REGISTRY_VALUE_TEXT = "registry_value_text"
    SERVICE = "service"
    SIGNATURE = "signature"
    SYSTEM = "system"
    TLS_HASH = "tls_hash"
    URL = "url"


class RiskObject(BaseModel):
    """Risk object model for RBA.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    field: str
    type: RiskObjectType
    score: RiskScoreValue_Type
    # Per-entity risk message. No longer read by the legacy test validator —
    # validate_risk_message resolves the message directly from the matched entity
    # via get_matched_risk_object rather than reading it from here. Retained as a
    # constructor field for consistency; can be removed when RBAObject is retired.
    # Not written to conf (excluded from serializer).
    message: str = ""

    def __hash__(self):
        """Return hash of risk object.

        Returns:
            Hash of field, type, and score tuple.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return hash((self.field, self.type, self.score))

    def __lt__(self, other: RiskObject) -> bool:
        """Compare risk objects for sorting.

        Args:
            other: Other RiskObject to compare.

        Returns:
            True if this object is less than other.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        if (
            f"{self.field}{self.type}{self.score}"
            < f"{other.field}{other.type}{other.score}"
        ):
            return True
        return False

    @model_serializer
    def serialize_risk_object(self) -> dict[str, str | int]:
        """We define this explicitly for two reasons, even though the automatic serialization works correctly.

        First we want to enforce a specific
        field order for reasons of readability. Second, some of the fields
        actually have different names than they do in the object.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return {
            "risk_object_field": self.field,
            "risk_object_type": self.type,
            "risk_score": self.score,
        }


class ThreatObject(BaseModel):
    """Threat object model for RBA.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    field: str
    type: ThreatObjectType

    def __hash__(self):
        """Return hash of threat object.

        Returns:
            Hash of field and type tuple.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return hash((self.field, self.type))

    def __lt__(self, other: ThreatObject) -> bool:
        """Compare threat objects for sorting.

        Args:
            other: Other ThreatObject to compare.

        Returns:
            True if this object is less than other.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        if f"{self.field}{self.type}" < f"{other.field}{other.type}":
            return True
        return False

    @model_serializer
    def serialize_threat_object(self) -> dict[str, str]:
        """We define this explicitly for two reasons, even though the automatic serialization works correctly.

        First we want to enforce a specific
        field order for reasons of readability. Second, some of the fields
        actually have different names than they do in the object.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return {
            "threat_object_field": self.field,
            "threat_object_type": self.type,
        }


class RBAObject(BaseModel, ABC):
    """Base RBA object model.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    message: str
    risk_objects: Annotated[Set[RiskObject], Field(min_length=1)]
    threat_objects: Set[ThreatObject]

    @model_serializer
    def serialize_rba(self) -> dict[str, str | list[dict[str, str | int]]]:
        """Serialize RBA object to dictionary.

        Returns:
            Dictionary representation of RBA object.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return {
            "message": self.message,
            "risk_objects": [obj.model_dump() for obj in sorted(self.risk_objects)],
            "threat_objects": [obj.model_dump() for obj in sorted(self.threat_objects)],
        }
