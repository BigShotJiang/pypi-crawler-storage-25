"""Unit test baseline model for detection testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from typing import Union

from pydantic import BaseModel, ConfigDict


class UnitTestBaseline(BaseModel):
    """Unit test baseline configuration model.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    model_config = ConfigDict(extra="forbid")
    name: str
    file: str
    pass_condition: str
    earliest_time: Union[str, None] = None
    latest_time: Union[str, None] = None
