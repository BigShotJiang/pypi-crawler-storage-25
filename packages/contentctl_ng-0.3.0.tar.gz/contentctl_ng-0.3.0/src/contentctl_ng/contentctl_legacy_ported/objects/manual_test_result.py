"""Manual test result model.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    BaseTestResult,
)


class ManualTestResult(BaseTestResult):
    """A manual test result.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    pass
