"""Test group model for organizing related tests.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from pydantic import BaseModel

from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    TestResultStatus,
)
from contentctl_ng.contentctl_legacy_ported.objects.integration_test import (
    IntegrationTest,
)
from contentctl_ng.contentctl_legacy_ported.objects.test_attack_data import (
    TestAttackData,
)
from contentctl_ng.contentctl_legacy_ported.objects.unit_test import UnitTest


class TestGroup(BaseModel):
    """Groups of different types of tests relying on the same attack data.

    Args:
        name: Name of the TestGroup (typically derived from a unit test as
            "{detection.name}:{test.name}").
        unit_test: A UnitTest.
        integration_test: An IntegrationTest.
        attack_data: The attack data associated with tests in the TestGroup.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    name: str
    unit_test: UnitTest
    integration_test: IntegrationTest
    attack_data: list[TestAttackData]

    @classmethod
    def derive_from_unit_test(
        cls, unit_test: UnitTest, name_prefix: str
    ) -> "TestGroup":
        """Construct a TestGroup with an IntegrationTest corresponding to the UnitTest.

        Args:
            unit_test: The UnitTest.
            name_prefix: The prefix to be used for the TestGroup name (typically the Detection name).

        Returns:
            TestGroup instance.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # construct the IntegrationTest
        integration_test = IntegrationTest.derive_from_unit_test(unit_test)

        # contruct and return the TestGroup
        return cls(
            name=f"{name_prefix}:{unit_test.name}",
            unit_test=unit_test,
            integration_test=integration_test,
            attack_data=unit_test.attack_data,
        )

    def unit_test_skipped(self) -> bool:
        """Return true if the unit test has been skipped.

        Returns:
            Bool indicating if unit test was skipped.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Return True if skipped
        if self.unit_test.result is not None:
            return self.unit_test.result.status == TestResultStatus.SKIP

        # If no result yet, it has not been skipped
        return False

    def integration_test_skipped(self) -> bool:
        """Return true if the integration test has been skipped.

        Returns:
            Bool indicating if integration test was skipped.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Return True if skipped
        if self.integration_test.result is not None:
            return self.integration_test.result.status == TestResultStatus.SKIP

        # If no result yet, it has not been skipped
        return False

    def all_tests_skipped(self) -> bool:
        """Return true if both the unit test and integration test have been skipped.

        Returns:
            Bool indicating if all tests were skipped.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return self.unit_test_skipped() and self.integration_test_skipped()
