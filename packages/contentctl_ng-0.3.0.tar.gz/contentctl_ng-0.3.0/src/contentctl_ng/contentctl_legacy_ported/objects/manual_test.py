"""Manual test model for detection testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from __future__ import annotations

from pydantic import Field

from contentctl_ng.contentctl_legacy_ported.objects.base_test import BaseTest, TestType
from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    TestResultStatus,
)
from contentctl_ng.contentctl_legacy_ported.objects.manual_test_result import (
    ManualTestResult,
)
from contentctl_ng.contentctl_legacy_ported.objects.test_attack_data import (
    TestAttackData,
)


class ManualTest(BaseTest):
    """A manual test for a detection.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # The test type (manual)
    test_type: TestType = Field(default=TestType.MANUAL)

    # The attack data to be ingested for the manual test
    attack_data: list[TestAttackData]

    # The result of the manual test
    result: ManualTestResult | None = None

    def skip(self, message: str) -> None:
        """Skip the test by setting its result status.

        Args:
            message: The reason for skipping.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        self.result = ManualTestResult(  # type: ignore
            message=message, status=TestResultStatus.SKIP
        )
