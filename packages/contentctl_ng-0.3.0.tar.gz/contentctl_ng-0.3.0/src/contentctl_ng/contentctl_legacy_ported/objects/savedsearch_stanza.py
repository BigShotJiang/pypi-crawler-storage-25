"""SavedSearch stanza model for savedsearches.conf.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import hashlib
import json
from functools import cached_property
from typing import Any, ClassVar

from pydantic import BaseModel, Field, computed_field

from contentctl_ng.contentctl_legacy_ported.objects.detection_metadata import (
    DetectionMetadata,
)
from contentctl_ng.contentctl_legacy_ported.objects.errors import MissingMetadataError


class SavedSearchStanza(BaseModel):
    """A model representing a stanza for a savedsearch in savedsearches.conf."""

    # The lines that comprise this stanza, in the order they appear in the conf
    lines: list[str] = Field(...)

    # The full name of the detection (e.g. "ESCU - My Detection - Rule")
    name: str = Field(...)

    # The key prefix indicating the metadata attribute
    METADATA_LINE_PREFIX: ClassVar[str] = "action.correlationsearch.metadata = "
    DETECTION_TYPE_LINE_PREFIX: ClassVar[str] = (
        "action.correlationsearch.detection_type = "
    )

    @computed_field
    @cached_property
    def metadata(self) -> DetectionMetadata | None:
        """The metadata extracted from the stanza. Using the provided lines, parse out the metadata.

        Stanzas may or may not have metadata section - meaning they may be savedsearches or Detections.
        Detections (EBDs and FBDs) require metadata, while baselines, which are just regular
        savedsearches, do not. If the stanza represents a detection (has `action.correlationsearch.detection_type`)
        then metadata is required and an exception is raised in its absence. Likewise, if a stanza has metadata but is
        not a detection (missing `action.correlationsearch.detection_type`), an exception is raised.

        Returns:
            DetectionMetadata | None: the detection stanza's metadata or None if no metadata is present

        Raises:
            Exception: If metadata or detection_type is found more than once in the stanza.
            action.correlationsearch.metadata OR
            action.correlationsearch.detection_type
            is present in a stanza, but not both. They are co-dependent.


        """
        # Set a variable to store the metadata line in
        meta_line: str | None = None
        # Set a variable to store the detection_type line in
        detection_type_line: str | None = None

        # Iterate over the lines to look for the metadata line
        for line in self.lines:
            if line.startswith(SavedSearchStanza.METADATA_LINE_PREFIX):
                # If we find a matching line more than once, we've hit an error
                if meta_line is not None:
                    raise Exception(
                        f"Metadata for detection '{self.name}' found twice in stanza."
                    )
                meta_line = line
            if line.startswith(SavedSearchStanza.DETECTION_TYPE_LINE_PREFIX):
                # If we find a matching line more than once, we've hit an error
                if detection_type_line is not None:
                    raise Exception(
                        f"Detection type for detection '{self.name}' found twice in stanza."
                    )
                detection_type_line = line

        # Checking the metadata field is only valid if a stanza either has:
        # BOTH meta_line AND detection_type_line; OR;
        # NEITHER meta_line NOR detection_type_line

        if detection_type_line is None and meta_line is None:
            # This is acceptable, neither of these lines was defined
            return None

        elif detection_type_line is None or meta_line is None:
            # This is not acceptable, only one of these lines was defined
            if detection_type_line is None:
                raise Exception(
                    f"[METADATA VALIDATION FAILED - METADATA FOUND FOR NON-EBD/FBD SEARCH (DETECTION_TYPE MISSING)]"
                    f" - '{self.name}' contains  '{SavedSearchStanza.METADATA_LINE_PREFIX}'. "
                    f"However, it is missing '{SavedSearchStanza.DETECTION_TYPE_LINE_PREFIX}' "
                    "so it does not qualify as an EBD or FBD search and CANNOT have metadata."
                )
            else:
                raise Exception(
                    f"[METADATA VALIDATION FAILED - EBD/FBD SEARCH MISSING REQUIRED METADATA]"
                    f" - '{self.name}' contains '{SavedSearchStanza.DETECTION_TYPE_LINE_PREFIX}'. "
                    f"However, it is missing '{SavedSearchStanza.METADATA_LINE_PREFIX}'. "
                    "This is an EBD/FBD search and MUST have metadata."
                )
        # If we get here, both detection_type_line and meta_line are not None
        # This is the expected, normal case for EBD/FBD detections

        # Parse out the detection_type
        detection_type = detection_type_line[
            len(SavedSearchStanza.DETECTION_TYPE_LINE_PREFIX) :
        ].strip()

        raw_data = meta_line[len(SavedSearchStanza.METADATA_LINE_PREFIX) :].strip()
        try:
            # Both the detection type AND metadata must be present. Combine them into a single JSON object
            # Parse the metadata JSON into a model

            metadata_as_dict: dict[str, Any] = json.loads(raw_data)
            assert isinstance(metadata_as_dict, dict), (
                f"[METADATA JSON IS NOT A VALID JSON DICTIONARY] - '{self.name}' was parsed into "
                f"{type(metadata_as_dict)} from '{meta_line[len(SavedSearchStanza.METADATA_LINE_PREFIX) :].strip()}'"
            )
            # Add the type that was parsed out earlier
            metadata_as_dict["detection_type"] = detection_type
            return DetectionMetadata.model_validate(
                metadata_as_dict,
            )
        except json.JSONDecodeError as e:
            raise Exception(
                f"[FAILED TO PARSE METADATA JSON - JSON PARSING ERROR] - '{self.name}' with raw metadata: '{raw_data}' - {e}"
            )
        except Exception as e:
            raise Exception(
                f"[FAILED TO PARSE METADATA] - '{self.name}' in stanza: {e}"
            )

    @computed_field
    @cached_property
    def hash(self) -> str:
        """The SHA256 hash of the lines of the stanza, excluding the metadata line.

        Returns:
            str: The SHA256 hash of the lines of the stanza, excluding the metadata line.
        """
        hash = hashlib.sha256()
        for line in self.lines:
            if not line.startswith(SavedSearchStanza.METADATA_LINE_PREFIX):
                hash.update(line.encode("utf-8"))
        return hash.hexdigest()

    def can_enforce_metadata(self, previous: "SavedSearchStanza") -> bool:
        """Determine if metadata enforcement is required and possible for this detection.

        Metadata enforcement can proceed if:
        1. The previous version of the detection has metadata;
        2. AND the current version of the detection has metadata.

        Metadata enforcement is not possible if:
        1. Both the previous version AND current version do not have metadata.

        Args:
            previous (SavedSearchStanza): The previous version of the detection stanza.

        Raises:
            Exception: If metadata enforcement is not possible. This occurs if:
            1. The previous version has metadata and the current does not.
            2. The current version has metadata and the previous does not.

        Returns:
            bool: True if metadata enforcement is possible, False otherwise.
        """
        if self.metadata is None and previous.metadata is None:
            # metadata is not populated in this or previous, so no need to enforce
            return False

        if previous.metadata is not None and self.metadata is not None:
            # metadata is populated in both this and previous, so we can enforce
            return True

        raise Exception(
            f"Metadata enforcement is not possible for detection '{self.name}'. Either the previous or current version is missing metadata. "
            f"Previous version has metadata [{previous.metadata}], and current version has metadata [{self.metadata}]."
        )

    def version_should_be_bumped(self, previous: SavedSearchStanza) -> bool:
        """A helper method that compares this stanza against the same stanza from a previous build.

        Returns True if the version still needs to be bumped (e.g. the detection was changed but
        the version was not), False otherwise.

        Args:
            previous (SavedSearchStanza): The previous version of the detection stanza.

        Returns:
            bool: True if the version still needs to be bumped, False otherwise.

        """
        if self.metadata is None or previous.metadata is None:
            # We cannot check for version bumps unless BOTH have metadata
            # In the future, we could allow the previous version to be missing
            # metadata and if the current version DOES have metadata, enforce
            # that it is version 1.
            raise (
                MissingMetadataError(
                    rule_name=self.name,
                    current_stanza_metadata=self.metadata.__dict__
                    if self.metadata
                    else None,
                    previous_stanza_metadata=previous.metadata.__dict__
                    if previous.metadata
                    else None,
                )
            )

        return (self.hash != previous.hash) and (
            self.metadata.detection_version <= previous.metadata.detection_version
        )
