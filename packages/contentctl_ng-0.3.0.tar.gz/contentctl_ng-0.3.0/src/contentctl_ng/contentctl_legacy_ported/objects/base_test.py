"""Base test classes and types for detection testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Union

from pydantic import BaseModel, ConfigDict

from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    BaseTestResult,
)


class TestType(StrEnum):
    """Types of tests.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    UNIT = "unit"
    INTEGRATION = "integration"
    MANUAL = "manual"

    def __str__(self) -> str:
        """Return string representation of test type.

        Returns:
            Test type value as string.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return self.value


# TODO (#224): enforce distinct test names w/in detections
class BaseTest(BaseModel, ABC):
    """Base class for detection test cases.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    model_config = ConfigDict(extra="forbid")
    """
    A test case for a detection
    """
    # Test name
    name: str

    # The test type
    test_type: TestType

    # Search window start time
    earliest_time: Union[str, None] = None

    # Search window end time
    latest_time: Union[str, None] = None

    # The test result
    result: Union[None, BaseTestResult] = None

    @abstractmethod
    def skip(self, message: str) -> None:
        """Skip a test.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        raise NotImplementedError(
            "BaseTest test is an abstract class; skip must be implemented by subclasses"
        )
