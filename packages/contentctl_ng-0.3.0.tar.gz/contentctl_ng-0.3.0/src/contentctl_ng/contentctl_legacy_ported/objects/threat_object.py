"""Threat object model for risk analysis.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from pydantic import BaseModel


class ThreatObject(BaseModel):
    """Representation of a threat object associated with a risk analysis action.

    Detections define observables with a role of "attacker" with which the risk analysis gets associated. On the
    Enterprise Security side, these translate to threat objects. Each threat object has a field from which it draws its
    name and a type.

    Note:
        It is unclear whether a threat object will have a corresponding risk event, or perhaps a
        corresponding threat event.

    Args:
        field: The name of the field from which the risk object will get its name.
        type: The type of the risk object (e.g. "system").

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    field: str
    type: str
