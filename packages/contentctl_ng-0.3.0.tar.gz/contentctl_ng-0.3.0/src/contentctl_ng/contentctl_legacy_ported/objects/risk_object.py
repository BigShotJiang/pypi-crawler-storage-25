"""Risk object model for risk analysis.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from pydantic import BaseModel


class RiskObject(BaseModel):
    """Representation of a risk object associated with a risk analysis action.

    Detections define observables (e.g. a user) with a role of "victim" with which the risk analysis and scoring gets
    associated. On the Enterprise Security side, these translate to risk objects. Each risk object has a field from
    which it draws its name and a type (e.g. user, system, etc.). A risk event will be generated for each risk
    object accordingly.

    Note:
        Observables without an explicit role MAY default to being a risk object; it is not clear
        at the time of writing.

    Args:
        field: The name of the field from which the risk object will get its name.
        type: The type of the risk object (e.g. "system").
        score: The risk score associated with the observable (e.g. 64).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    field: str
    type: str
    score: int
