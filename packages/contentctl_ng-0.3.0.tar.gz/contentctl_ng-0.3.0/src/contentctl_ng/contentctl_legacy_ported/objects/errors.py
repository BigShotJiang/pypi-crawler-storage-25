"""Custom exception classes for security content validation and testing.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from abc import ABC, abstractmethod
from typing import Any
from uuid import UUID

from pydantic.networks import HttpUrl
from requests import RequestException


class ValidationFailed(Exception):
    """Indicates not an error in execution, but a validation failure.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    pass


class IntegrationTestingError(Exception):
    """Base exception class for integration testing.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    pass


class ServerError(IntegrationTestingError):
    """An error encountered during integration testing, as provided by the server (Splunk instance).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    pass


class ClientError(IntegrationTestingError):
    """An error encountered during integration testing, on the client's side (locally).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    pass


class MetadataValidationError(Exception, ABC):
    """Base class for any errors arising from savedsearches.conf detection metadata validation.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # The name of the rule the error relates to
    rule_name: str

    @property
    @abstractmethod
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        raise NotImplementedError()

    @property
    @abstractmethod
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        raise NotImplementedError()


class AttackDataMissingFromRepoError(RequestException):
    """An error indicating a detection's attack data file did not exist at a given URL in the attack_data repo.

    This docstring was generated manually.
    """

    def __init__(self, url: HttpUrl, *args: object) -> None:
        """Initialize AttackDataMissingFromRepoError.

        Args:
            url: URL of the missing attack data file.
            *args: Additional exception arguments.
        """
        self.url = url
        super().__init__(self.long_message, *args)

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.
        """
        return f"{self.url} Does not exist in the Attack Data Cache (if applicable) nor at the URL."

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        """
        return f"[{self.url}] does not exist in at URL"


class DetectionMissingError(MetadataValidationError):
    """An error indicating a detection in the prior build could not be found in the current build.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    def __init__(self, rule_name: str, *args: object) -> None:
        """Initialize DetectionMissingError.

        Args:
            rule_name: Name of the missing detection rule.
            *args: Additional exception arguments.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.rule_name = rule_name
        super().__init__(self.long_message, *args)

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' in previous build not found in current build; "
            "detection may have been removed or renamed."
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return "Detection from previous build not found in current build."


class MissingMetadataError(MetadataValidationError):
    """An error indicating a detection which declared Metadata in a prior build is missing Metadata in the current build."""

    # The ID from the current build
    current_stanza_metadata: dict[str, Any] | None

    # The ID from the previous build
    previous_stanza_metadata: dict[str, Any] | None

    def __init__(
        self,
        rule_name: str,
        current_stanza_metadata: dict[str, Any] | None,
        previous_stanza_metadata: dict[str, Any] | None,
        *args: object,
    ) -> None:
        """Initialize MissingMetadataError.

        Args:
            rule_name: Name of the detection rule.
            current_stanza_metadata: Metadata from current build stanza.
            previous_stanza_metadata: Metadata from previous build stanza.
            *args: Additional exception arguments.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.rule_name = rule_name
        self.current_stanza_metadata = current_stanza_metadata
        self.previous_stanza_metadata = previous_stanza_metadata
        super().__init__(self.long_message, *args)

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' in the current build is missing the "
            " metadata in either its current and/or previous stanzas. "
            "It must be present in either neither or both versions.\n"
            f"Current stanza metadata  (if any): {self.current_stanza_metadata}\n"
            f"Previous stanza metadata (if any): {self.previous_stanza_metadata}\n"
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        missing_in = []
        if self.current_stanza_metadata is not None:
            missing_in.append("current build")
        if self.previous_stanza_metadata is not None:
            missing_in.append("previous build")
        return (
            f"Detection Name {self.rule_name} is missing metadata in "
            + " and ".join(missing_in)
            + "."
        )


class DetectionIDError(MetadataValidationError):
    """An error indicating the detection ID may have changed between builds.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # The ID from the current build
    current_id: UUID

    # The ID from the previous build
    previous_id: UUID

    def __init__(
        self, rule_name: str, current_id: UUID, previous_id: UUID, *args: object
    ) -> None:
        """Initialize DetectionIDError.

        Args:
            rule_name: Name of the detection rule.
            current_id: Detection ID from current build.
            previous_id: Detection ID from previous build.
            *args: Additional exception arguments.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.rule_name = rule_name
        self.current_id = current_id
        self.previous_id = previous_id
        super().__init__(self.long_message, *args)

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' has ID {self.current_id} in current build "
            f"and {self.previous_id} in previous build; detection IDs and "
            "names should not change for the same detection between releases."
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return f"Detection ID {self.current_id} in current build does not match ID {self.previous_id} in previous build."


class VersioningError(MetadataValidationError, ABC):
    """A base class for any metadata validation errors relating to detection versioning.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # The version in the current build
    current_version: int

    # The version in the previous build
    previous_version: int

    def __init__(
        self, rule_name: str, current_version: int, previous_version: int, *args: object
    ) -> None:
        """Initialize VersioningError.

        Args:
            rule_name: Name of the detection rule.
            current_version: Detection version from current build.
            previous_version: Detection version from previous build.
            *args: Additional exception arguments.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.rule_name = rule_name
        self.current_version = current_version
        self.previous_version = previous_version
        super().__init__(self.long_message, *args)


class VersionDecrementedError(VersioningError):
    """An error indicating the version number went down between builds.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' has version {self.current_version} in "
            f"current build and {self.previous_version} in previous build; "
            "detection versions cannot decrease in successive builds."
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Detection version ({self.current_version}) in current build is less than version "
            f"({self.previous_version}) in previous build."
        )


class VersionBumpingError(VersioningError):
    """An error indicating the detection changed but its version wasn't bumped appropriately.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' has changed in current build compared to previous "
            "build (stanza hashes differ); the detection version should be bumped "
            f"to {self.previous_version + 1}."
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return f"Detection version in current build should be bumped to {self.previous_version + 1}."


class VersionBumpingTooFarError(VersioningError):
    """An error indicating the detection changed but its version was bumped too far.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    @property
    def long_message(self) -> str:
        """A long-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return (
            f"Rule '{self.rule_name}' has changed in current build compared to previous "
            "build (stanza hashes differ); however the detection version increased too much"
            f"The version should be reduced to {self.previous_version + 1}."
        )

    @property
    def short_message(self) -> str:
        """A short-form error message.

        Returns:
            A str, the message.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        return f"Detection version in current build should be reduced to {self.previous_version + 1}."
