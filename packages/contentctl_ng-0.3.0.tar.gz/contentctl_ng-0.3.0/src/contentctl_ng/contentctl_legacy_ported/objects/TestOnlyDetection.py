"""Simplified detection model for legacy testing infrastructure.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from __future__ import annotations

import pathlib
from enum import StrEnum
from typing import TYPE_CHECKING, Annotated, Any, List, Union
from uuid import UUID

from pydantic import BaseModel, Field, FilePath

if TYPE_CHECKING:
    pass


from contentctl_ng.contentctl_legacy_ported.objects.base_test_result import (
    TestResultStatus,
)
from contentctl_ng.contentctl_legacy_ported.objects.constants import (
    CONTENTCTL_MAX_STANZA_LENGTH,
    ES_MAX_STANZA_LENGTH,
    ES_SEARCH_STANZA_NAME_FORMAT_AFTER_CLONING_IN_PRODUCT_TEMPLATE,
)
from contentctl_ng.contentctl_legacy_ported.objects.enums import (
    AnalyticsType,
    ContentStatus,
    SecurityDomain,
)
from contentctl_ng.contentctl_legacy_ported.objects.integration_test import (
    IntegrationTest,
)
from contentctl_ng.contentctl_legacy_ported.objects.manual_test import ManualTest
from contentctl_ng.contentctl_legacy_ported.objects.rba import RBAObject, RiskObject
from contentctl_ng.contentctl_legacy_ported.objects.test_group import TestGroup
from contentctl_ng.contentctl_legacy_ported.objects.unit_test import UnitTest

# Those AnalyticsTypes that we do not test via contentctl
SKIPPED_ANALYTICS_TYPES: set[str] = {AnalyticsType.Correlation}

if TYPE_CHECKING:
    from contentctl_ng.contentctl_legacy_ported.objects.config import CustomApp


# REally Detections, and many of the fields associated with them are the only things we need to
# actually do a test. And we don't even need most of the detection fields! Strip this down
# to its simplest possible definition - one that can be constructed at runttime from
# new EventBasedDetection Objects, to facilitate the use of legacy testing code.
class TestOnlyDetection(BaseModel):
    """Simplified detection model with minimal fields required for testing.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    name: str = Field(...)
    id: UUID = Field(...)
    full_conf_stanza_name: str = Field(
        description="The full name of the conf stanza for this detection. "
        "This is likely to be ESCU - {name} - Rule and is calculated by contentctl-ng. It should just be treated as a regular string."
    )
    version: int = Field(...)
    # contentType: SecurityContentType = SecurityContentType.detections
    # This can be dervied based on presence of rba and generate_notable fields
    type: AnalyticsType = Field(...)
    # Can be derived based on the presence of one or more Production tests (or if we do decide to include this as a field in the yml)
    status: ContentStatus
    search: str = Field(...)
    rba: None | RBAObject = Field(default=None)
    # The finding entity for this detection, if any. Populated from detection.finding.entity
    # in the contentctl.py conversion loop. Used by NotableEvent.validate_against_detection
    # to check the observed entity field/type against the expected finding entity.
    # None for Anomaly and Hunting detections (which have no finding).
    notable_entity: None | RiskObject = Field(default=None)
    # The finding title template for this detection, if any. Populated from
    # detection.finding.title.root in the contentctl.py conversion loop. Used by
    # NotableEvent.validate_against_detection to validate the observed orig_rule_title
    # against the expected pattern (tokens substituted, structure preserved).
    # None for Anomaly and Hunting detections (which have no finding).
    finding_title: None | str = Field(default=None)
    baselines: list[str] = Field(
        default_factory=list,
        description="Just let this be a list of the names, if present. We don't actually try to run them, so don't need to fully support the objects.",
    )
    # Manual test detections were NOT all converted to experimental, which is a departure from the original implementation.
    # They may still be production. We will use the presence of UnitTests vs ExperimentalTests during conversion to determine
    # if this field should be set or not.
    manual_test: str | None = None
    file_path: FilePath
    # We can construct this from the contentctl-ng paths, even though they
    # are in a different format
    security_domain: SecurityDomain = Field(...)
    analytic_story: list[str] = Field(default_factory=list)
    mitre_attack_id: list[str] = Field(default_factory=list)
    source: str = Field(...)
    data_source: list[str] = Field(default_factory=list)
    tests: List[
        Annotated[
            Union[UnitTest, IntegrationTest, ManualTest],
            Field(union_mode="left_to_right"),
        ]
    ] = []
    # test_groups are constructed dynamically at runtime by validators/functions,
    # so as long as we get the tests right, these should be good!
    # A list of groups of tests, relying on the same data
    test_groups: list[TestGroup] = []

    def adjust_tests_and_groups(self) -> None:
        """Converts UnitTest to ManualTest as needed, builds the `test_groups` field, constructing the model from the list of unit tests.

        Also, preemptively skips all manual tests, as well as
        tests for experimental/deprecated detections and Correlation type detections.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Since ManualTest and UnitTest are not differentiable without looking at the manual_test
        # tag, Pydantic builds all tests as UnitTest objects. If we see the manual_test flag, we
        # convert these to ManualTest
        tmp: list[UnitTest | IntegrationTest | ManualTest] = []
        # manual_test were all converted to experimental - keep this here as a stub just in case
        if self.manual_test is not None:
            for test in self.tests:
                if not isinstance(test, UnitTest):
                    raise ValueError(
                        "At this point of intialization, tests should only be UnitTest objects, "
                        f"but encountered a {type(test)}."
                    )
                # Create the manual test and skip it upon creation (cannot test via contentctl)
                manual_test = ManualTest(name=test.name, attack_data=test.attack_data)
                tmp.append(manual_test)
            self.tests = tmp

        # iterate over the tests and create a TestGroup (and as a result, an IntegrationTest) for
        # each unit test
        self.test_groups = []
        for test in self.tests:
            # We only derive TestGroups from UnitTests (ManualTest is ignored and IntegrationTests
            # have not been created yet)
            if isinstance(test, UnitTest):
                test_group = TestGroup.derive_from_unit_test(test, self.name)
                self.test_groups.append(test_group)

        # now add each integration test to the list of tests
        for test_group in self.test_groups:
            self.tests.append(test_group.integration_test)

        # Skip all manual tests
        self.skip_manual_tests()

        # NOTE: we ignore the type error around self.status because we are using Pydantic's
        # use_enum_values configuration
        # https://docs.pydantic.dev/latest/api/config/#pydantic.config.ConfigDict.populate_by_name

        # Skip tests for non-production detections
        if self.status != ContentStatus.production:
            self.skip_all_tests(
                f"TEST SKIPPED: Detection is non-production ({self.status})"
            )

        # Skip tests for detecton types like Correlation which are not supported via contentctl
        if self.type in SKIPPED_ANALYTICS_TYPES:
            self.skip_all_tests(
                f"TEST SKIPPED: Detection type {self.type} cannot be tested by contentctl"
            )

    @property
    def test_status(self) -> TestResultStatus | None:
        """Returns the collective status of the detections tests.

        If any test status has yet to be set,
        None is returned. If any test failed or errored, FAIL is returned. If all tests were skipped,
        SKIP is returned. If at least one test passed and the rest passed or skipped, PASS is
        returned.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # If the detection has no tests, we consider it to have been skipped (only non-production,
        # non-manual, non-correlation detections are allowed to have no tests defined)
        if len(self.tests) == 0:
            return TestResultStatus.SKIP

        passed = 0
        skipped = 0
        for test in self.tests:
            # If the result/status of any test has not yet been set, return None
            if test.result is None or test.result.status is None:
                return None
            elif (
                test.result.status == TestResultStatus.ERROR
                or test.result.status == TestResultStatus.FAIL
            ):
                # If any test failed or errored, return fail (we don't return the error state at
                # the aggregate detection level)
                return TestResultStatus.FAIL
            elif test.result.status == TestResultStatus.SKIP:
                skipped += 1
            elif test.result.status == TestResultStatus.PASS:
                passed += 1
            else:
                raise ValueError(
                    f"Undefined test status for test ({test.name}) in detection ({self.name})"
                )

        # If at least one of the tests passed and the rest passed or skipped, report pass
        if passed > 0 and (passed + skipped) == len(self.tests):
            return TestResultStatus.PASS
        elif skipped == len(self.tests):
            # If all tests skipped, return skip
            return TestResultStatus.SKIP

        raise ValueError(f"Undefined overall test status for detection: {self.name}")

    def model_post_init(self, __context: Any) -> None:
        """Post-initialization hook to derive test groups and adjust test types.

        Args:
            __context: Pydantic context (unused).

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        # Derive TestGroups and IntegrationTests, adjust for ManualTests, skip as needed
        self.adjust_tests_and_groups()

        # Ensure that if there is at least 1 drilldown, at least
        # 1 of the drilldowns contains the string Drilldown.SEARCH_PLACEHOLDER.
        # This is presently a requirement when 1 or more drilldowns are added to a detection.
        # Note that this is only required for production searches that are not hunting

    def skip_all_tests(self, message: str = "TEST SKIPPED") -> None:
        """Skip all tests for this detection with the given message.

        Args:
            message: The message to set in the test result.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        for test in self.tests:
            test.skip(message=message)

    def skip_manual_tests(self) -> None:
        """Skip all ManualTests if the manual_test flag is set; raise error for other test types.

        Raises:
            ValueError: If non-ManualTest types are found for a manual_test detection.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Skip all ManualTest
        if self.manual_test is not None:
            for test in self.tests:
                if isinstance(test, ManualTest):
                    test.skip(
                        message=(
                            "TEST SKIPPED (MANUAL): Detection marked as 'manual_test' with "
                            f"explanation: {self.manual_test}"
                        )
                    )
                else:
                    raise ValueError(
                        "A detection with the manual_test flag should only have tests of type "
                        "ManualTest"
                    )

    def all_tests_successful(self) -> bool:
        """Check that all tests in the detection succeeded.

        Returns:
            Bool where True indicates all tests succeeded (they existed, complete and were PASS/SKIP).
            False if no tests defined, any test fails (FAIL, ERROR), or any test has no result/status.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # If no tests are defined, we consider it a success for the detection (this detection was
        # skipped for testing). Note that the existence of at least one test is enforced by Pydantic
        # validation already, with a few specific exceptions
        if len(self.tests) == 0:
            return True

        # Iterate over tests
        for test in self.tests:
            # Check that test.result is not None
            if test.result is not None:
                # Check status is set (complete)
                if test.result.complete:
                    # Check for failure (FAIL, ERROR)
                    if test.result.failed:
                        return False
                else:
                    # If no stauts, return False
                    return False
            else:
                # If no result, return False
                return False

        # If all tests are successful (PASS/SKIP), return True
        return True

    def get_summary(
        self,
        detection_fields: list[str] = [
            "name",
            "type",
            "status",
            "test_status",
            "source",
            "data_source",
            "search",
            "file_path",
            "manual_test",
        ],
        detection_field_aliases: dict[str, str] = {
            "status": "production_status",
            "test_status": "status",
            "source": "source_category",
        },
        tags_fields: list[str] = [],
        test_result_fields: list[str] = [
            "success",
            "message",
            "exception",
            "status",
            "duration",
            "wait_duration",
        ],
        test_job_fields: list[str] = ["resultCount", "runDuration"],
    ) -> dict[str, Any]:
        """Aggregate a dictionary summarizing the detection model, including all test results.

        Args:
            detection_fields: The fields of the top level detection to gather.
            detection_field_aliases: Mapping of field names to aliases.
            tags_fields: The fields from tags to gather.
            test_result_fields: The fields of the test result(s) to gather.
            test_job_fields: The fields of the test result(s) job content to gather.

        Returns:
            A dict summary.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        # Init the summary dict
        summary_dict: dict[str, Any] = {}

        # Grab the top level detection fields
        for field in detection_fields:
            value = getattr(self, field)

            # Enums and Path objects cannot be serialized directly, so we convert it to a string
            if isinstance(value, StrEnum) or isinstance(value, pathlib.Path):
                value = str(value)

            # Alias any fields as needed
            if field in detection_field_aliases:
                summary_dict[detection_field_aliases[field]] = value
            else:
                summary_dict[field] = value

        # Grab fields from the tags - manual test has been moved from tag into root of detection
        # No tags_fields are supported
        for field in tags_fields:
            raise Exception("Tags fields are not supported for TestOnlyDetection")
        #      summary_dict[field] = getattr(self.tags, field)

        # Set success based on whether all tests passed
        summary_dict["success"] = self.all_tests_successful()

        # Aggregate test results
        summary_dict["tests"] = []
        for test in self.tests:
            # Initialize the dict as a mapping of strings to str/bool
            result: dict[str, Union[str, bool]] = {
                "name": test.name,
                "test_type": test.test_type,
            }

            # If result is not None, get a summary of the test result w/ the requested fields
            if test.result is not None:
                result.update(
                    test.result.get_summary_dict(
                        model_fields=test_result_fields,
                        job_fields=test_job_fields,
                    )
                )
            else:
                # If no test result, consider it a failure
                result["success"] = False
                result["message"] = "NO RESULT - Test not run"

            # Add the result to our list
            summary_dict["tests"].append(result)  # type: ignore

        # Return the summary

        return summary_dict

    # Some dependencies all just to get the stanza name
    @classmethod
    def static_get_conf_stanza_name(cls, name: str, app: CustomApp) -> str:
        """Get configuration stanza name for detection (must be implemented by subclasses).

        Args:
            name: Detection name.
            app: Custom app configuration.

        Returns:
            Configuration stanza name.

        Raises:
            NotImplementedError: This method must be implemented by subclasses.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        raise NotImplementedError(
            "{cls.__name__} does not have an implementation for static_get_conf_stanza_name"
        )

    def check_conf_stanza_max_length(
        self, stanza_name: str, max_stanza_length: int = CONTENTCTL_MAX_STANZA_LENGTH
    ) -> None:
        """Validate that configuration stanza name doesn't exceed maximum length.

        Args:
            stanza_name: Configuration stanza name to validate.
            max_stanza_length: Maximum allowed length.

        Raises:
            ValueError: If stanza name exceeds maximum length.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        if len(stanza_name) > max_stanza_length:
            raise ValueError(
                f"conf stanza may only be {max_stanza_length} characters, "
                f"but stanza was actually {len(stanza_name)} characters: '{stanza_name}' "
            )

    def get_conf_stanza_name(self, app: CustomApp) -> str:
        """Get validated configuration stanza name for this detection.

        Args:
            app: Custom app configuration.

        Returns:
            Validated configuration stanza name.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        # This has replaced the call to static_get_full_conf_stanza_name
        # since it is now passed in to the constructor.
        stanza_name = self.full_conf_stanza_name
        self.check_conf_stanza_max_length(stanza_name)
        return stanza_name

    # This function is required by the content versioning service test cases
    def get_action_dot_correlationsearch_dot_label(
        self, app: CustomApp, max_stanza_length: int = ES_MAX_STANZA_LENGTH
    ) -> str:
        """Get action.correlationsearch.label stanza name for Enterprise Security.

        Args:
            app: Custom app configuration.
            max_stanza_length: Maximum allowed stanza length for ES.

        Returns:
            ES-formatted stanza name.

        Raises:
            ValueError: If ES stanza name exceeds maximum length.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        stanza_name = self.get_conf_stanza_name(app)
        stanza_name_after_saving_in_es = (
            ES_SEARCH_STANZA_NAME_FORMAT_AFTER_CLONING_IN_PRODUCT_TEMPLATE.format(
                security_domain_value=self.security_domain, search_name=stanza_name
            )
        )

        if len(stanza_name_after_saving_in_es) > max_stanza_length:
            raise ValueError(
                f"label may only be {max_stanza_length} characters to allow updating in-product, "
                f"but stanza was actually {len(stanza_name_after_saving_in_es)} characters: '{stanza_name_after_saving_in_es}' "
            )

        return stanza_name
