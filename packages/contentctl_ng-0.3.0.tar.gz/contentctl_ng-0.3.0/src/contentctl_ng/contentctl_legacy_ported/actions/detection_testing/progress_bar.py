"""Progress bar utilities for detection testing reporting.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import datetime
import time
from enum import StrEnum

from tqdm import tqdm


class TestReportingType(StrEnum):
    """5-char identifiers for the type of testing being reported on.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    # Reporting around general testing setup (e.g. infra, role configuration)
    SETUP = "SETUP"

    # Reporting around a group of tests
    GROUP = "GROUP"

    # Reporting around a unit test
    UNIT = "UNIT "

    # Reporting around an integration test
    INTEGRATION = "INTEG"


class TestingStates(StrEnum):
    """Defined testing states.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    BEGINNING_GROUP = "Beginning Test Group"
    BEGINNING_TEST = "Beginning Test"
    DOWNLOADING = "Downloading Data"
    REPLAYING = "Replaying Data"
    PROCESSING = "Waiting for Processing"
    SEARCHING = "Running Search"
    DELETING = "Deleting Data"
    DONE_GROUP = "Test Group Done"
    PRE_CLEANUP = "Pre-run Cleanup"
    POST_CLEANUP = "Post-run Cleanup"
    FORCE_RUN = "Forcing Detection Run"
    VALIDATING = "Validating Risks/Notables"


# the longest length of any state
LONGEST_STATE = max(len(w) for w in TestingStates)


class FinalTestingStates(StrEnum):
    """The possible final states for a test (for pbar reporting).

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """

    FAIL = "\x1b[0;30;41m" + "FAIL ".ljust(LONGEST_STATE) + "\x1b[0m"
    ERROR = "\x1b[0;30;41m" + "ERROR".ljust(LONGEST_STATE) + "\x1b[0m"
    PASS = "\x1b[0;30;42m" + "PASS ".ljust(LONGEST_STATE) + "\x1b[0m"
    SKIP = "\x1b[0;30;47m" + "SKIP ".ljust(LONGEST_STATE) + "\x1b[0m"


# max length of a test name
# TODO: this max size is declared, and it is used appropriately w/ .ljust, but nothing truncates
#   test names to makes them the appropriate size
MAX_TEST_NAME_LENGTH = 70

# The format string used for pbar reporting
PBAR_FORMAT_STRING = "[{test_reporting_type}] {test_name} >> {state} | Time: {time}"


def format_pbar_string(
    pbar: tqdm,
    test_reporting_type: TestReportingType,
    test_name: str,
    state: str,
    start_time: float,
    set_pbar: bool = True,
) -> str:
    """Log testing information via pbar and return a formatted string.

    Optionally updates the existing progress bar.

    Args:
        pbar: A tqdm instance to use for updating.
        test_reporting_type: The type of reporting to be done (e.g. unit, integration, group).
        test_name: The name of the test to be logged.
        state: The state/message of the test to be logged.
        start_time: The start_time of this progress bar.
        set_pbar: Bool indicating whether pbar.update should be called.

    Returns:
        A formatted string for use with pbar.

    Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
    """
    # Extract and ljust our various fields
    field_one = test_reporting_type
    field_two = test_name.ljust(MAX_TEST_NAME_LENGTH)
    field_three = state.ljust(LONGEST_STATE)
    field_four = datetime.timedelta(seconds=round(time.time() - start_time))

    # Format the string
    new_string = PBAR_FORMAT_STRING.format(
        test_reporting_type=field_one,
        test_name=field_two,
        state=field_three,
        time=field_four,
    )

    # Update pbar if set
    if set_pbar:
        pbar.bar_format = new_string
        pbar.update()

    # Return formatted string
    return new_string
