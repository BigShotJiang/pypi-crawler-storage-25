"""Git service for detecting changed content and selecting detections to test.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import logging
import pathlib
from typing import TYPE_CHECKING, List, Optional

import pygit2
from pydantic import BaseModel, FilePath
from pygit2.enums import DeltaStatus

if TYPE_CHECKING:
    pass

from contentctl_ng.contentctl_legacy_ported.objects.config import (
    All,
    Changes,
    Selected,
    test_common,
)

# Some Secuirty Content NG imports
from contentctl_ng.objects.content import SecurityContent as ng_SecurityContentObject
from contentctl_ng.objects.data_source import DataSource as ng_DataSource
from contentctl_ng.objects.lookup import CSVLookup as ng_CSVLookup
from contentctl_ng.objects.lookup import Lookup as ng_Lookup
from contentctl_ng.objects.macro import FilebackedMacro as ng_FilebackedMacro
from contentctl_ng.objects.searches.detection import EventBasedDetection as ng_Detection

logger = logging.getLogger(__name__)


class GitService(BaseModel):
    """Service for managing git-based detection selection and change detection.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    detections: list[ng_Detection]
    macros: list[ng_FilebackedMacro]
    lookups: list[ng_Lookup]
    datasources: list[ng_DataSource]
    config: test_common
    gitHash: Optional[str] = None

    def getHash(self) -> str:
        """Get the git hash of the repository.

        Returns:
            Git hash string.

        Raises:
            Exception: If git hash was not set.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        if self.gitHash is None:
            raise Exception("Cannot get hash of repo, it was not set")
        return self.gitHash

    def getContent(self) -> List[ng_Detection]:
        """Get detections to test based on the configured mode.

        Returns:
            List of detections to test.

        Raises:
            Exception: If unsupported test mode is configured.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        logger.debug("Getting content to test")
        if isinstance(self.config.mode, Selected):
            return self.getSelected(self.config.mode.files)
        elif isinstance(self.config.mode, Changes):
            return self.getChanges(self.config.mode.target_branch)
        if isinstance(self.config.mode, All):
            return self.getAll()
        else:
            raise Exception(
                f"Could not get content to test. Unsupported test mode '{self.config.mode}'"
            )

    def getAll(self) -> list[ng_Detection]:
        """Get all detections.

        Returns:
            List of all detections.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        logger.debug("Getting [ALL] content")
        return self.detections

    def getChanges(self, target_branch: str) -> list[ng_Detection]:
        """Get detections that have changed compared to target branch.

        Args:
            target_branch: Git branch to compare against.

        Returns:
            List of changed detections and detections with changed dependencies.

        Raises:
            Exception: If target branch cannot be parsed or does not exist.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        logger.debug("Getting [CHANGED] content")
        logger.debug(
            f"Loading git repository at [{self.config.path}] and calculating diff against target ref [{target_branch}]"
        )
        repo = pygit2.Repository(path=str(self.config.path))
        try:
            target_tree = repo.revparse_single(target_branch).tree
            self.gitHash = target_tree.id
            diffs = repo.index.diff_to_tree(target_tree)
        except Exception:
            raise Exception(
                f"Error parsing diff target_branch '{target_branch}'. Are you certain that it exists?"
            )
        logger.debug(
            f"Found [{len(diffs)}] changed files from diff against target ref [{target_branch}]"
        )
        # Get the uncommitted changes in the current directory
        diffs2 = repo.index.diff_to_workdir()
        logger.debug(
            f"Found [{len(diffs2)}] uncommitted changes in the current directory."
        )

        # Combine the uncommitted changes with the committed changes
        all_diffs = list(diffs) + list(diffs2)

        # Make a filename to content map
        filepath_to_content_map = self.create_filepath_to_content_map(
            self.detections + self.macros + self.lookups + self.datasources
        )

        updated_detections: set[ng_Detection] = set()
        updated_macros: set[ng_FilebackedMacro] = set()
        updated_lookups: set[ng_Lookup] = set()
        updated_datasources: set[ng_DataSource] = set()

        for diff in all_diffs:
            if type(diff) is pygit2.Patch:
                if diff.delta.status in (
                    DeltaStatus.ADDED,
                    DeltaStatus.MODIFIED,
                    DeltaStatus.RENAMED,
                ):
                    # This path is only a fragment relative to the current working directory, NOT the repo root!
                    # Normalize it so that it is relative to the repo root
                    decoded_path = pathlib.Path(
                        self.config.path / diff.delta.new_file.raw_path.decode("utf-8")
                    )

                    # Note that we only handle updates to detections, lookups, and macros at this time. All other changes are ignored.
                    if (
                        decoded_path.is_relative_to(
                            self.config.path / ng_Detection.content_folder()
                        )
                        and decoded_path.suffix == ".yml"
                    ):
                        detectionObject = filepath_to_content_map.get(
                            decoded_path, None
                        )
                        if isinstance(detectionObject, ng_Detection):
                            updated_detections.add(detectionObject)
                        else:
                            raise Exception(
                                f"Error getting detection object for file {decoded_path!s}"
                            )

                    elif (
                        decoded_path.is_relative_to(
                            self.config.path / ng_FilebackedMacro.content_folder()
                        )
                        and decoded_path.suffix == ".yml"
                    ):
                        macroObject = filepath_to_content_map.get(decoded_path, None)
                        if isinstance(macroObject, ng_FilebackedMacro):
                            updated_macros.add(macroObject)
                        else:
                            raise Exception(
                                f"Error getting macro object for file {decoded_path!s}"
                            )

                    elif (
                        decoded_path.is_relative_to(
                            self.config.path / ng_DataSource.content_folder()
                        )
                        and decoded_path.suffix == ".yml"
                    ):
                        datasourceObject = filepath_to_content_map.get(
                            decoded_path, None
                        )
                        if isinstance(datasourceObject, ng_DataSource):
                            updated_datasources.add(datasourceObject)
                        else:
                            raise Exception(
                                f"Error getting data source object for file {decoded_path!s}"
                            )

                    elif decoded_path.is_relative_to(self.config.path / "lookups"):
                        # We need to convert this to a yml. This means we will catch
                        # both changes to a csv AND changes to the YML that uses it
                        if decoded_path.suffix == ".yml":
                            updatedLookup = filepath_to_content_map.get(
                                decoded_path, None
                            )
                            if not isinstance(updatedLookup, ng_Lookup):
                                raise Exception(
                                    f"Expected {decoded_path} to be type {type(ng_Lookup)}, but instead if was {(type(updatedLookup))}"
                                )
                            updated_lookups.add(updatedLookup)

                        elif decoded_path.suffix == ".csv":
                            # If the CSV was updated, we want to make sure that we
                            # add the correct corresponding Lookup object.
                            # Filter to find the Lookup Object the references this CSV
                            matched = list(
                                filter(
                                    lambda x: (
                                        isinstance(x, ng_CSVLookup)
                                        and x._path == decoded_path
                                    ),
                                    self.lookups,
                                )
                            )
                            if len(matched) == 0:
                                raise Exception(
                                    f"Failed to find any lookups that reference the modified CSV file  '{decoded_path}'"
                                )
                            elif len(matched) > 1:
                                raise Exception(
                                    f"More than 1 Lookup reference the modified CSV file '{decoded_path}': {[match._path for match in matched]}"
                                )
                            else:
                                updatedLookup = matched[0]
                        elif decoded_path.suffix == ".mlmodel":
                            # Detected a changed .mlmodel file. However, since we do not have testing for these detections at
                            # this time, we will ignore this change.
                            updatedLookup = None

                        else:
                            raise Exception(
                                f"Detected a changed file in the lookups/ directory '{decoded_path!s}'.\n"
                                "Only files ending in .csv, .yml, or .mlmodel are supported in this "
                                "directory. This file must be removed from the lookups/ directory."
                            )

                        if (
                            updatedLookup is not None
                            and updatedLookup not in updated_lookups
                        ):
                            # It is possible that both the CSV and YML have been modified for the same lookup,
                            # and we do not want to add it twice.
                            updated_lookups.add(updatedLookup)

                    else:
                        pass
                        # print(
                        #     f"Ignore changes to file {decoded_path} since it is not a detection, macro, or lookup."
                        # )
            else:
                raise Exception(f"Unrecognized diff type {type(diff)}")

        # If a detection has at least one dependency on changed content,
        # then we must test it again
        changed_macros_and_lookups_and_datasources: set[
            ng_FilebackedMacro | ng_Lookup | ng_DataSource
        ] = updated_macros.union(updated_lookups, updated_datasources)

        for detection in self.detections:
            if detection in updated_detections:
                # we are already planning to test it, don't need
                # to add it again
                continue

            # list out the potential dependencies for this detection
            dependencies = set(detection._macros | detection._lookups)

            for ds in detection.data_source:
                for atomic_ds in ds:
                    # Remember that data sources map to an ENUM, so we need to deference
                    # the object for the actual object when accessing it.
                    dependencies.add(atomic_ds.obj)

            for obj in changed_macros_and_lookups_and_datasources:
                # TODO For some reason, hashes for the same object obj and
                # that object in the set appear to be different for FileBackedMacros. I am unsure
                # why at this time. This means obj in dependencies does not work when dependencies is
                # a set. However, it does work when dependencies is a list, which checks for object equality.
                # This makes the operation O(n) rather than O(1). Should troubleshoot the hash functions for
                # these objects.
                if obj in list(dependencies):
                    updated_detections.add(detection)
                    break

        # Print out the names of all modified/new content

        modifiedAndNewContentString = "\n - ".join(
            sorted([d.name for d in updated_detections])
        )

        print(
            f"[{len(updated_detections)}] Pieces of modifed and new content (this may include experimental/deprecated/manual_test content):\n - {modifiedAndNewContentString}"
        )
        return sorted(list(updated_detections))

    def getSelected(self, detectionFilenames: List[FilePath]) -> list[ng_Detection]:
        """Get specific selected detections by file path.

        Args:
            detectionFilenames: List of file paths to detections.
            If these paths are relative paths, they will be converted to
            absolute paths automatically which is required for comparison
            purposes in this function.

        Returns:
            List of selected detections.

        Raises:
            Exception: If detection files not found or are wrong type.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        # Create a mapping from content to that content's file path if it is a
        # File Backed object. Note that not all macros or lookups are backed by files.
        logger.debug("Getting [SELECTED] content")
        filepath_to_content_map = self.create_filepath_to_content_map(self.detections)

        errors = []
        detections: list[ng_Detection] = []

        for detection_path in detectionFilenames:
            logger.debug(
                f"Mapping detection path: {detection_path} to content object..."
            )
            # Because the map contains absolute paths,
            # we MUST convert the detection path to an absolute path.
            # Otherwise, this lookup WILL FAIL.
            # resolve() is used over absolute() to resolve symlinks
            # as well as ./ and ../ references.
            obj = filepath_to_content_map.get(detection_path.resolve(), None)
            if obj is None:
                errors.append(
                    f"There is no detection file or security_content_object at '{detection_path}'"
                )
            elif not isinstance(obj, ng_Detection):
                errors.append(
                    f"The security_content_object at '{detection_path}' is of type '{type(obj).__name__}', NOT '{ng_Detection.__name__}'"
                )
            else:
                logger.debug(f"Found Detection: {obj.name}")
                detections.append(obj)

        if errors:
            errorsString = "\n - ".join(errors)
            raise Exception(
                f"The following errors were encountered while getting selected detections to test:\n - {errorsString}"
            )
        return detections

    def create_filepath_to_content_map(
        self, security_content_objects: list[ng_SecurityContentObject]
    ) -> dict[FilePath, ng_SecurityContentObject]:
        """Create a mapping from FilePath to ng-style Security Content Object.

        This function is required because not all objects have a _path, for example _filter macros
        or lookups that are created at runtime.  Instead of creating this mapping for all content,
        only create the mapping for the specific content that is passed in to the function.

        Args:
            security_content_objects (list[ng_SecurityContentObject]): List of all security content objects to map.

        Returns:
            dict[FilePath, ng_SecurityContentObject]: Mapping of FilePath to ng-style Security Content Object. These objects MUST have _path attribute.
        """
        filepath_to_content_map = {
            obj._path: obj
            for obj in security_content_objects
            if getattr(obj, "_path", None) is not None
        }

        return filepath_to_content_map
