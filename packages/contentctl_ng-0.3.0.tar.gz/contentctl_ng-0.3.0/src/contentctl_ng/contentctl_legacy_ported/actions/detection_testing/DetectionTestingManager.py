"""Detection testing manager for orchestrating test execution across infrastructure.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import concurrent.futures
import datetime
import logging
import signal
import traceback
from dataclasses import dataclass
from typing import List, Union

from pydantic import BaseModel

from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.infrastructures.DetectionTestingInfrastructure import (
    DetectionTestingInfrastructure,
    DetectionTestingManagerOutputDto,
)
from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.infrastructures.DetectionTestingInfrastructureServer import (
    DetectionTestingInfrastructureServer,
)
from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.views.DetectionTestingView import (
    DetectionTestingView,
)
from contentctl_ng.contentctl_legacy_ported.objects.config import (
    Container,
    Infrastructure,
    test,
    test_servers,
)
from contentctl_ng.contentctl_legacy_ported.objects.enums import PostTestBehavior
from contentctl_ng.contentctl_legacy_ported.objects.TestOnlyDetection import (
    TestOnlyDetection,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=False)
class DetectionTestingManagerInputDto:
    """Input data transfer object for DetectionTestingManager.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    config: Union[test, test_servers]
    detections: List[TestOnlyDetection]
    views: list[DetectionTestingView]


class DetectionTestingManager(BaseModel):
    """Manager for orchestrating detection testing across multiple infrastructure instances.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    input_dto: DetectionTestingManagerInputDto
    output_dto: DetectionTestingManagerOutputDto
    detectionTestingInfrastructureObjects: list[DetectionTestingInfrastructure] = []

    def setup(self):
        """Set up the testing manager and create infrastructure objects.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        # Some views, such as the Web View, will require some initial setup.
        # for view in self.input_dto.views:
        #    view.setup()

        # for content in self.input_dto.testContent.detections:
        #    self.pending_queue.put(content)
        self.output_dto.inputQueue = self.input_dto.detections
        self.create_DetectionTestingInfrastructureObjects()

    def execute(self) -> DetectionTestingManagerOutputDto:
        """Execute detection tests across all configured infrastructure instances.

        Returns:
            DetectionTestingManagerOutputDto with test results.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """

        def sigint_handler(signum, frame):
            print("SIGINT (Ctrl-C Received.  Shutting down test...)")
            self.output_dto.terminate = True
            if self.input_dto.config.post_test_behavior in [
                PostTestBehavior.always_pause,
                PostTestBehavior.pause_on_failure,
            ]:
                # It is possible that we are stuck waiting at in input() prompt, so inject
                # a newline '\r\n' which will cause that wait to stop
                print("*******************************")
                print(
                    "If testing is paused and you are debugging a detection, you MUST hit CTRL-D "
                    "at the prompt to complete shutdown."
                )
                print("*******************************")

        signal.signal(signal.SIGINT, sigint_handler)

        # TODO (#337): futures can be hard to maintain/debug; let's consider alternatives
        with (
            concurrent.futures.ThreadPoolExecutor(
                max_workers=len(self.input_dto.config.test_instances),
            ) as instance_pool,
            concurrent.futures.ThreadPoolExecutor(
                max_workers=len(self.input_dto.views)
            ) as view_runner,
            concurrent.futures.ThreadPoolExecutor(
                max_workers=len(self.input_dto.config.test_instances),
            ) as view_shutdowner,
        ):
            # Capture any errors for reporting at the end after all threads have been gathered
            errors: dict[str, list[Exception]] = {
                "INSTANCE SETUP ERRORS": [],
                "TESTING ERRORS": [],
                "ERRORS DURING VIEW SHUTDOWN": [],
                "ERRORS DURING VIEW EXECUTION": [],
            }

            # Start all the views
            logger.debug(
                f"Starting views {[view.__class__.__name__ for view in self.input_dto.views]}"
            )
            future_views = {
                view_runner.submit(view.setup): view for view in self.input_dto.views
            }

            # Configure all the instances
            logger.debug(
                f"Starting configuration of test instance {len(self.detectionTestingInfrastructureObjects)}"
            )
            future_instances_setup = {
                instance_pool.submit(instance.setup): instance
                for instance in self.detectionTestingInfrastructureObjects
            }

            # Wait for all instances to be set up
            for future in concurrent.futures.as_completed(future_instances_setup):
                try:
                    future.result()
                except Exception as e:
                    self.output_dto.terminate = True
                    # Output the traceback if we encounter errors in verbose mode
                    if self.input_dto.config.verbose:
                        tb = traceback.format_exc()
                        print(tb)
                    errors["INSTANCE SETUP ERRORS"].append(e)
            logger.debug("Completed configuration of test instances")

            # Start and wait for all tests to run
            if not self.output_dto.terminate:
                self.output_dto.start_time = datetime.datetime.now()
                future_instances_execute = {
                    instance_pool.submit(instance.execute): instance
                    for instance in self.detectionTestingInfrastructureObjects
                }
                # Wait for execution to finish
                logger.debug("All tests instances have started consuming tests.")
                for future in concurrent.futures.as_completed(future_instances_execute):
                    try:
                        future.result()
                    except Exception as e:
                        self.output_dto.terminate = True
                        # Output the traceback if we encounter errors in verbose mode
                        if self.input_dto.config.verbose:
                            tb = traceback.format_exc()
                            print(tb)
                        errors["TESTING ERRORS"].append(e)

            logger.info("All tests have finished executing.")
            self.output_dto.terminate = True

            # Shut down all the views and wait for the shutdown to finish
            future_views_shutdowner = {
                view_shutdowner.submit(view.stop): view for view in self.input_dto.views
            }
            for future in concurrent.futures.as_completed(future_views_shutdowner):
                try:
                    future.result()
                except Exception as e:
                    # Output the traceback if we encounter errors in verbose mode
                    if self.input_dto.config.verbose:
                        tb = traceback.format_exc()
                        print(tb)
                    errors["ERRORS DURING VIEW SHUTDOWN"].append(e)

            # Wait for original view-related threads to complete
            for future in concurrent.futures.as_completed(future_views):
                try:
                    future.result()
                except Exception as e:
                    # Output the traceback if we encounter errors in verbose mode
                    if self.input_dto.config.verbose:
                        tb = traceback.format_exc()
                        print(tb)
                    errors["ERRORS DURING VIEW EXECUTION"].append(e)

            # Log any errors
            for error_type in errors:
                if len(errors[error_type]) > 0:
                    print()
                    print(f"[{error_type}]:")
                    for error in errors[error_type]:
                        print(f"\t❌ {error!s}")
                        if isinstance(error, ExceptionGroup):
                            for suberror in error.exceptions:  # type: ignore
                                print(f"\t\t❌ {suberror!s}")  # type: ignore
                    print()

        return self.output_dto

    def create_DetectionTestingInfrastructureObjects(self):
        """Create detection testing infrastructure objects for each configured instance.

        Raises:
            Exception: If container testing is attempted (not yet supported).
            Exception: If unsupported infrastructure type is configured.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        # Make sure that, if we need to, we pull the appropriate container
        for infrastructure in self.input_dto.config.test_instances:
            if isinstance(self.input_dto.config, test) and isinstance(
                infrastructure, Container
            ):
                raise Exception("Container testing is not yet supported")
                # NOTE: commenting out this code to suppress ruff errors; we will not be supporting
                # container-specific testing in contentctl-ng, but leaving the legacy code in place
                # for reference until we remove it entirely
                # try:
                #     client = docker.from_env()
                # except Exception:
                #     raise Exception(
                #         "Unable to connect to docker.  Are you sure that docker is running on this host?"
                #     )
                # try:
                #     parts = (
                #         self.input_dto.config.container_settings.full_image_path.split(
                #             ":"
                #         )
                #     )
                #     if len(parts) != 2:
                #         raise Exception(
                #             "Expected to find a name:tag in "
                #             f"{self.input_dto.config.container_settings.full_image_path}, "
                #             f"but instead found {parts}. Note that this path MUST include the "
                #             "tag, which is separated by ':'"
                #         )

                #     print(
                #         "Getting the latest version of the container image "
                #         f"[{self.input_dto.config.container_settings.full_image_path}]...",
                #         end="",
                #         flush=True,
                #     )
                #     client.images.pull(parts[0], tag=parts[1], platform="linux/amd64")
                #     print("done!")
                #     break
                # except Exception as e:
                #     raise Exception(
                #         "Failed to pull docker container image "
                #         f"[{self.input_dto.config.container_settings.full_image_path}]: {e!s}"
                #     )

        # NOTE: commenting out this code to suppress ruff errors; we will not be supporting
        # container-specific testing in contentctl-ng, but leaving the legacy code in place
        # for reference until we remove it entirely
        # already_staged_container_files = False
        for infrastructure in self.input_dto.config.test_instances:
            if isinstance(self.input_dto.config, test) and isinstance(
                infrastructure, Container
            ):
                raise NotImplementedError("Container testing is not supported")
                # NOTE: commenting out this code to suppress ruff errors; we will not be supporting
                # container-specific testing in contentctl-ng, but leaving the legacy code in place
                # for reference until we remove it entirely
                # # Stage the files in the apps dir so that they can be passed directly to
                # # subsequent containers. Do this here, instead of inside each container, to
                # # avoid duplicate downloads/moves/copies
                # if not already_staged_container_files:
                #     self.input_dto.config.getContainerEnvironmentString(stage_file=True)
                #     already_staged_container_files = True

                # self.detectionTestingInfrastructureObjects.append(
                #     DetectionTestingInfrastructureContainer(
                #         global_config=self.input_dto.config,
                #         infrastructure=infrastructure,
                #         sync_obj=self.output_dto,
                #     )
                # )

            elif isinstance(self.input_dto.config, test_servers) and isinstance(
                infrastructure, Infrastructure
            ):
                self.detectionTestingInfrastructureObjects.append(
                    DetectionTestingInfrastructureServer(
                        global_config=self.input_dto.config,
                        infrastructure=infrastructure,
                        sync_obj=self.output_dto,
                    )
                )

            else:
                raise Exception(
                    f"Unsupported target infrastructure '{infrastructure}' and config type {self.input_dto.config}"
                )
