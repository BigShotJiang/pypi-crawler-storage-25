"""Server-based detection testing infrastructure implementation.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.infrastructures.DetectionTestingInfrastructure import (
    DetectionTestingInfrastructure,
)


class DetectionTestingInfrastructureServer(DetectionTestingInfrastructure):
    """Detection testing infrastructure using remote Splunk servers.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    def start(self):
        """Start the server instance (no-op for pre-existing servers).

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        pass

    def finish(self):
        """Finish testing and clean up resources.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        super().finish()

    def get_name(self):
        """Get the name of this server instance.

        Returns:
            Server instance name.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        return self.infrastructure.instance_name
