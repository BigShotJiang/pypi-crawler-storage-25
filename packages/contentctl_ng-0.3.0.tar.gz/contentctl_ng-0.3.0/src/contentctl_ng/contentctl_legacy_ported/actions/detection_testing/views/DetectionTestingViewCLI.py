"""CLI-based detection testing view with progress bar.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import time

import tqdm

from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.views.DetectionTestingView import (
    DetectionTestingView,
)


class DetectionTestingViewCLI(DetectionTestingView, arbitrary_types_allowed=True):
    """CLI view for detection testing with tqdm progress bar.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    pbar: tqdm.tqdm = None
    previous_output_queue_length: int = 0

    def format_pbar(self, completed_detections: int, total_detections: int):
        """Format the progress bar with detection counts and timing info.

        Args:
            completed_detections: Number of completed detections.
            total_detections: Total number of detections to test.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        ratio = f"{completed_detections}/{total_detections}".ljust(9)
        try:
            et = str(self.getRuntime()).ljust(8)
        except Exception as e:
            et = str(e).ljust(8)

        try:
            etr = str(self.getETA()).ljust(8)
        except Exception as e:
            etr = str(e).ljust(8)

        bar = "{percentage:3.2f}%[{bar:30}]"
        self.pbar.bar_format = (
            f"Completed {ratio} {bar} | Elapsed: {et} | Remaining: {etr}"
        )
        self.pbar.reset(total=total_detections)
        self.pbar.update(completed_detections)

    def setup(self):
        """Set up the CLI view and initialize progress bar.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.previous_output_queue_length = len(self.sync_obj.outputQueue)
        self.pbar = tqdm.tqdm(
            total=len(self.sync_obj.inputQueue),
            initial=0,
            bar_format="",
            miniters=0,
            mininterval=0,
        )
        self.format_pbar(len(self.sync_obj.outputQueue), len(self.sync_obj.inputQueue))

        self.showStatus()

    # TODO (#267): Align test reporting more closely w/ status enums (as it relates to "untested")
    def showStatus(self, interval: int = 1):
        """Show current testing status in progress bar.

        Args:
            interval: Update interval in seconds.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        while True:
            summary = self.getSummaryObject()

            # TODO (#338): there's a 1-off error here I think (we show one more than we
            #   actually have during testing)
            total = len(
                summary.get("tested_detections", [])
                + summary.get("untested_detections", [])
                + self.getCurrent()
            )
            self.format_pbar(len(summary.get("tested_detections", [])), total)

            for _ in range(interval):
                if self.sync_obj.terminate:
                    return
                time.sleep(1)

    def showResults(self):
        """Show test results (not implemented for CLI view).

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        pass

    def createReport(self):
        """Create test report (not implemented for CLI view).

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        pass

    def stop(self):
        """Stop the CLI view and close progress bar.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        self.pbar.close()
        pass
