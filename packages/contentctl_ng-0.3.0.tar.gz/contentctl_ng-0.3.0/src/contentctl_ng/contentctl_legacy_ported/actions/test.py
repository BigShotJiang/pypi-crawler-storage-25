"""Entry point for the test command.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""

import logging
import pathlib
from dataclasses import dataclass
from typing import List

from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.DetectionTestingManager import (
    DetectionTestingManager,
    DetectionTestingManagerInputDto,
)
from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.infrastructures.DetectionTestingInfrastructure import (
    DetectionTestingManagerOutputDto,
)
from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.views.DetectionTestingViewCLI import (
    DetectionTestingViewCLI,
)
from contentctl_ng.contentctl_legacy_ported.actions.detection_testing.views.DetectionTestingViewFile import (
    DetectionTestingViewFile,
)
from contentctl_ng.contentctl_legacy_ported.objects.config import (
    Changes,
    Selected,
    test_servers,
)
from contentctl_ng.contentctl_legacy_ported.objects.config import test as test_
from contentctl_ng.contentctl_legacy_ported.objects.integration_test import (
    IntegrationTest,
)
from contentctl_ng.contentctl_legacy_ported.objects.TestOnlyDetection import (
    TestOnlyDetection,
)

MAXIMUM_CONFIGURATION_TIME_SECONDS = 600


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TestInputDto:
    """Input data transfer object for test command.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    detections: List[TestOnlyDetection]
    config: test_ | test_servers


class Test:
    """Service for executing detection tests.

    Note: Docstrings in this file were auto-generated in bulk by Claude.
    """

    def filter_tests(self, input_dto: TestInputDto) -> None:
        """Filter integration tests based on configuration.

        If integration testing has NOT been enabled, then skip
        all of the integration tests. Otherwise, do nothing.

        Args:
            input_dto (TestInputDto): A configuration of the test and all of the
                tests to be run.

        Note: Docstrings in this file were edited in bulk by Claude for stylistic compliance.
        """
        if not input_dto.config.enable_integration_testing:
            # Skip all integraiton tests if integration testing is not enabled:
            for detection in input_dto.detections:
                for test in detection.tests:
                    if isinstance(test, IntegrationTest):
                        test.skip("TEST SKIPPED: Skipping all integration tests")

    def execute(self, input_dto: TestInputDto) -> bool:
        """Execute detection tests and return success status.

        Args:
            input_dto: Test input configuration and detections.

        Returns:
            True if all tests passed, False otherwise.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        output_dto = DetectionTestingManagerOutputDto()
        cli = DetectionTestingViewCLI(config=input_dto.config, sync_obj=output_dto)
        file = DetectionTestingViewFile(config=input_dto.config, sync_obj=output_dto)

        manager_input_dto = DetectionTestingManagerInputDto(
            config=input_dto.config,
            detections=input_dto.detections,
            views=[cli, file],
        )

        manager = DetectionTestingManager(
            input_dto=manager_input_dto, output_dto=output_dto
        )

        if len(input_dto.detections) == 0:
            print(
                f"With Detection Testing Mode '{input_dto.config.mode.mode_name}', there were "
                "[0] detections found to test.\nAs such, we will quit immediately."
            )
            # Directly call stop so that the summary.yml will be generated. Of course it will not
            # have any test results, but we still want it to contain a summary showing that now
            # detections were tested.
            file.stop()
        else:
            logger.info(
                f"MODE: [{input_dto.config.mode.mode_name}] - Test [{len(input_dto.detections)}] detections"
            )
            if isinstance(input_dto.config.mode, Selected) or isinstance(
                input_dto.config.mode, Changes
            ):
                files_string = "\n- ".join(
                    [
                        str(pathlib.Path(detection.file_path).absolute())
                        for detection in input_dto.detections
                    ]
                )
                logger.info(f"Detections:\n- {files_string}")

            logger.debug("Setting up test environment...")
            manager.setup()
            manager.execute()

        try:
            summary_results = file.getSummaryObject()
            summary = summary_results.get("summary", {})
            if not isinstance(summary, dict):
                raise ValueError(
                    f"Summary in results was an unexpected type ({type(summary)}): {summary}"
                )

            print(f"Test Summary (mode: {summary.get('mode', 'Error')})")
            print(f"\tSuccess                      : {summary.get('success', False)}")
            print(
                f"\tSuccess Rate                 : {summary.get('success_rate', 'ERROR')}"
            )
            print(
                f"\tTotal Detections             : {summary.get('total_detections', 'ERROR')}"
            )
            print(
                f"\tTotal Tested Detections      : {summary.get('total_tested_detections', 'ERROR')}"
            )
            print(
                f"\t  Passed Detections          : {summary.get('total_pass', 'ERROR')}"
            )
            print(
                f"\t  Failed Detections          : {summary.get('total_fail', 'ERROR')}"
            )
            print(
                f"\tSkipped Detections           : {summary.get('total_skipped', 'ERROR')}"
            )
            print("\tProduction Status            :")
            print(
                f"\t  Production Detections      : {summary.get('total_production', 'ERROR')}"
            )
            print(
                f"\t  Experimental Detections    : {summary.get('total_experimental', 'ERROR')}"
            )
            print(
                f"\t  Deprecated Detections      : {summary.get('total_deprecated', 'ERROR')}"
            )
            print(
                f"\tManually Tested Detections : {summary.get('total_manual', 'ERROR')}"
            )
            print(
                f"\tUntested Detections          : {summary.get('total_untested', 'ERROR')}"
            )
            print(f"\tTest Results File            : {file.getOutputFilePath()}")
            print(
                "\nNOTE: skipped detections include non-production, manually tested, and certain\n"
                "detection types (e.g. Correlation), but there may be overlap between these\n"
                "categories."
            )
            return summary.get("success", False)

        except Exception as e:
            print(f"Error determining if whole test was successful: {e!s}")
            return False
