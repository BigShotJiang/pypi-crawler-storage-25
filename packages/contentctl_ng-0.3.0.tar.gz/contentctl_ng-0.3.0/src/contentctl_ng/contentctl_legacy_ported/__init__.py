"""Legacy ported contentctl package.

Note: Docstrings in this file were auto-generated in bulk by Claude.
"""
