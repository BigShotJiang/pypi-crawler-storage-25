"""Given a splunk instance and content, the installer installs content and configures the instance to bring it to a test-ready state."""

import json
import logging
import os
import sys
import tempfile
import time
from configparser import ConfigParser
from importlib import resources
from pathlib import Path
from typing import Any

import requests
import yaml
from pydantic import (
    BaseModel,
    Field,
    FilePath,
    HttpUrl,
    field_validator,
)
from pydantic_core import InitErrorDetails, ValidationError
from pydantic_settings import CliImplicitFlag, SettingsConfigDict
from splunklib import results
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    retry_if_result,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential,
    wait_fixed,
)
from tqdm import tqdm

from contentctl_ng.settings import ContentSettings, SplunkbaseSettings, SplunkSettings
from contentctl_ng.utilities.common_io import load_yml_file_to_dict
from contentctl_ng.version import PydanticVersion

logger = logging.getLogger(__name__)


class AppNotInstalledError(Exception):
    """Raised when app upload succeeds but app is not installed in Splunk after verification."""

    pass


class _SplunkApp(BaseModel, frozen=True):
    """Represents a Splunk app to be installed. Avoid declaring this directly. Try SplunkAppList instead!"""

    appid: str = Field(
        description="""The "Folder name" as shown in the splunk app management page, e.g. "SplunkEnterpriseSecuritySuite" for the Splunk Enterprise Security app.
            This is primarily used for comparisons against existing apps, so even if it doesn't correspond exactly to the provided app file
            (like SplunkEnterpriseSecurityInstaller), it should be set to the value that will exist once installed."""
    )
    version: PydanticVersion | None = Field(
        default=None,
        description="""The semantic version of the app to install. Must be a valid version string like "1.2.3" or "1.0". This is a PydanticVersion object that can be compared to other versions using standard comparison operators.""",
    )
    hardcoded_path: HttpUrl | FilePath | None = Field(
        default=None,
        description="""A hardcoded URL or local path to the app package. Optional. If provided, this will be used instead of downloading from splunkbase using the below url field.""",
    )
    url: HttpUrl | None = Field(
        default=None,
        description="""The splunkbase URL for the app, like "https://splunkbase.splunk.com/app/1621". Optional.""",
    )

    source_file_path: FilePath | None = Field(
        default=None,
        description="Path to the original source where this splunkapp was loaded from (e.g. a datasource yml file, contentctl-provided install.yml, or user-provided install.yml). Used for logging and error messages.",
    )

    source_index: int = Field(
        description="The index of the app in the list where this splunkapp was loaded from. If multiple lists of apps are combined, it should be set according to its index in each separate list, not the combined list. Used for logging and error messages.",
    )

    @classmethod
    def get_splunkbase_id_from_url(cls, url: str) -> str:
        """Extract the splunkbase ID from a splunkbase URL.

        Also performs splunkbase URL validation. This is a classmethod so it can be used in the model validator before an app object is created.

        Args:
            url (str): The splunkbase URL, like "https://splunkbase.splunk.com/app/1621".

        Returns:
            str: The splunkbase ID, like "1621".

        """
        parsed_url = HttpUrl(url.rstrip("/"))
        if not (
            parsed_url.scheme == "https"
            and parsed_url.host == "splunkbase.splunk.com"
            and parsed_url.path
            and len(parsed_url.path.split("/")) == 3
            and parsed_url.path.split("/")[1] == "app"
            and parsed_url.path.split("/")[2].isdecimal()
        ):
            raise ValueError(
                f"Invalid splunkbase url {url}, url must be like https://splunkbase.splunk.com/app/<id>"
            )
        return parsed_url.path.split("/")[2]

    @property
    def splunkbase_download_url(self) -> str:
        """Provides the full splunkbase download URL.

        Returns:
            str: The splunkbase download URL for the app.

        """
        if self.url and self.version:
            return f"{self.url}/release/{self.version}/download"
        else:
            raise ValueError(
                "Must have a splunkbase URL and version to generate a download URL."
            )

    def __lt__(self, other: Any) -> bool:
        """Compares two SplunkApp objects based on their appid.

        The definition of this method is required for being able to
        sort SplunkApp objects which is useful for increasing readability
        when printing lists of apps.

        Args:
            other (SplunkApp): The other SplunkApp object to compare to.

        Raises:
            ValueError: If the other object is not a SplunkApp object.

        Returns:
            bool: True if this SplunkApp object is less than the other SplunkApp object, False otherwise.
        """
        if not isinstance(other, _SplunkApp):
            raise ValueError("Cannot compare SplunkApp with non-SplunkApp object.")
        return self.appid < other.appid


class SplunkAppList(BaseModel):
    """A list of Splunk apps, used for loading default and user-provided apps from install.yml files."""

    apps: list[_SplunkApp] = Field(
        description="A list of SplunkApp objects representing the apps."
    )

    @classmethod
    def get_init_error_details(cls, app: dict[str, Any], msg: str) -> InitErrorDetails:
        """Helper method to create InitErrorDetails for validation errors in the apps list."""
        return InitErrorDetails(
            input=app,
            ctx={"error": ValueError(msg)},
            loc=(str(app["source_file_path"]), app["source_index"]),  # type: ignore[reportUnknownMemberType]
            type="value_error",
            msg=msg,
        )

    @field_validator("apps", mode="before")
    def validate_apps_list(cls, value: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Validate the list of apps to ensure there are no duplicate appids and all combinations of fields are valid.

        Removes duplicate apps, favoring rightmost entries in the list (so user-provided install.yml apps override content-provided apps which override default apps).
        Checks the entire list of apps against splunkbase and errors if any don't exist, etc.

        Valid options:
        1. url -> get appid + latest version
        2. url + version -> get appid
        3. appid + hardcoded_path with no version or version=None -> version uses field default None and app will be force installed
        4. appid + version + hardcoded_path -> use as-is
        """
        splunkbase_ids: set[str] = set()
        for i, app in enumerate(value):
            if "url" in app and app["url"] is not None:
                splunkbase_id = _SplunkApp.get_splunkbase_id_from_url(str(app["url"]))
                splunkbase_ids.add(splunkbase_id)
            if len(splunkbase_ids) > 100:
                raise ValueError(
                    f"Too many apps with splunkbase URLs provided ({len(splunkbase_ids)}), the splunkbase API only allows checking 100 at a time. Please reduce the number of apps with splunkbase URLs to 100 or fewer."
                )
            # explicitly declare this as None if it's missing so we can use it for logging later in this validator
            if "source_file_path" not in app:
                app["source_file_path"] = None
            # provide a source index based on the combined app list if it is not provided based on the original list it came from
            if "source_index" not in app:
                app["source_index"] = i
        r = requests.get(
            "https://splunkbase.splunk.com/api/v2/apps",
            params={
                "ids": ",".join(splunkbase_ids),
                "include": "releases",
                "limit": 100,
                "archive": "all",
                "product": "all",
            },
        )
        r.raise_for_status()
        splunkbase_data = {str(item["id"]): item for item in r.json()["results"]}
        # first pass just maps all apps to their appid (aka folder name) and stores them in a dict to remove duplicates and establish precedence (rightmost wins, so user-provided install.yml overrides content-provided install.yml which overrides defaults)
        deduplicated_apps: dict[str, dict[str, Any]] = {}
        errors: list[InitErrorDetails] = []
        for app in value:
            if "hardcoded_path" in app and app["hardcoded_path"] is not None:
                if "appid" not in app:
                    errors.append(
                        cls.get_init_error_details(
                            app,
                            "App with hardcoded_path must have an appid provided. Even if the app will be overwritten, if we cannot determine its appid then it won't be possible to know which app is being overwritten.",
                        )
                    )
                    continue
            if "url" in app and app["url"] is not None:
                splunkbase_id = _SplunkApp.get_splunkbase_id_from_url(str(app["url"]))
                try:
                    if "appid" not in app:
                        app["appid"] = splunkbase_data[splunkbase_id]["app_id"]
                except KeyError:
                    errors.append(
                        cls.get_init_error_details(
                            app,
                            f"App with url {app['url']} not found on splunkbase. Please remove the app or provide a valid splunkbase URL. Even if the app will be overwritten, if we cannot determine its appid from its splunkbase URL then it won't be possible to know which app is being overwritten.",
                        )
                    )
                    continue
            if app["appid"] in deduplicated_apps:
                logger.info(
                    f"Appid {app['appid']} from {deduplicated_apps[app['appid']]['source_file_path']}.{deduplicated_apps[app['appid']]['source_index']} will instead use its definition in {app['source_file_path']}.{app['source_index']}."
                )
            deduplicated_apps[app["appid"]] = app

        for app in deduplicated_apps.values():
            if ("hardcoded_path" not in app or app["hardcoded_path"] is None) and (
                "url" not in app or app["url"] is None
            ):
                errors.append(
                    cls.get_init_error_details(
                        app,
                        "One of hardcoded_path or url must be provided.",
                    )
                )
                continue
            if "hardcoded_path" in app and app["hardcoded_path"] is not None:
                # We check for double (e.g. .tar.gz) and single (e.g. .spl)file extensions differently
                path = Path(app["hardcoded_path"])
                if path.suffixes[-1:] not in (
                    [".spl"],
                    [".tar"],
                    [".tgz"],
                ) and path.suffixes[-2:] != [".tar", ".gz"]:
                    errors.append(
                        cls.get_init_error_details(
                            app,
                            f"Invalid hardcoded path file extension for {app['hardcoded_path']}, must be one of .spl, .tar, .tar.gz, .tgz",
                        )
                    )
                if not path.is_file():
                    try:
                        url = HttpUrl(app["hardcoded_path"])
                        if not url.scheme == "https":
                            errors.append(
                                cls.get_init_error_details(
                                    app,
                                    f"Hardcoded path {app['hardcoded_path']} is a URL but not HTTPS, only HTTPS URLs are supported.",
                                )
                            )
                    except ValidationError:
                        errors.append(
                            cls.get_init_error_details(
                                app,
                                f"Hardcoded path {app['hardcoded_path']} is neither an existing file nor a valid URL.",
                            )
                        )

            if "url" in app and app["url"] is not None:
                splunkbase_id = _SplunkApp.get_splunkbase_id_from_url(str(app["url"]))
                if len(splunkbase_data[splunkbase_id]["releases"]) == 0:
                    errors.append(
                        cls.get_init_error_details(
                            app,
                            f"App with url {app['url']} exists on splunkbase but has no versions available.",
                        )
                    )
                elif "version" not in app or app["version"] is None:
                    app["version"] = sorted(
                        splunkbase_data[splunkbase_id]["releases"],
                        key=lambda r: r["release_name"],
                        reverse=True,
                    )[0]["release_name"]
                    logger.info(
                        f"No version provided for app {app['appid']} with url {app['url']}, defaulted to {app['version']} which was the most recent on Splunkbase."
                    )
                else:
                    if app["version"] not in [
                        release["release_name"]
                        for release in splunkbase_data[splunkbase_id]["releases"]
                    ]:
                        errors.append(
                            cls.get_init_error_details(
                                app,
                                f"Specified version {app['version']} for app {app['appid']} with url {app['url']} not found on splunkbase.",
                            )
                        )
        if len(errors) > 0:
            raise ValidationError.from_exception_data("Splunk app list errors", errors)
        return list(deduplicated_apps.values())


class Installer(SplunkbaseSettings, SplunkSettings, ContentSettings):
    """Object that performs the installation of content and configuration of the splunk instance.

    Args:
        SplunkbaseSettings (SplunkbaseSettings): Settings for connecting to Splunkbase.
        SplunkSettings (SplunkSettings): Settings for connecting to a Splunk instance.
        ContentSettings (ContentSettings): Settings for loading content.

    """

    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", populate_by_name=True
    )

    dry_run: CliImplicitFlag[bool] = Field(
        default=False,
        description=(
            "Perform a dry-run: download apps to cache and generate install.yml without installing "
            "to Splunk."
        ),
        alias="dry-run",
    )
    read_only_cache: CliImplicitFlag[bool] = Field(
        default=False,
        description=(
            "Read-only cache mode for thread-safe parallel installations. If True, apps not in "
            "cache will be downloaded to temporary file instead of writing to cache."
        ),
        alias="read-only-cache",
    )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=5),
        retry=retry_if_exception_type((TimeoutError, ConnectionError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _install_cim_datamodel(
        self, datamodel_name: str, name: str, value: str
    ) -> None:
        """Configure single CIM datamodel property with retry on network errors.

        Retry behavior: Retries up to 3 times on network errors (TimeoutError,
        ConnectionError) with exponential backoff (5s, 10s between attempts). Non-network errors
        fail immediately without retry.

        Args:
            datamodel_name: Name of the datamodel (e.g., "Malware", "Authentication")
            name: Property name (e.g., "acceleration.allow_old_summaries")
            value: Property value to set
        """
        self.splunk_api_service.post(
            f"properties/datamodels/{datamodel_name}/{name}",
            app="Splunk_SA_CIM",
            value=value,
        )

    def install_cim_datamodels(self) -> None:
        """Perform special CIM datamodel installation steps."""
        logger.info("Installing CIM datamodels...")
        parser = ConfigParser()
        with resources.as_file(
            resources.files("contentctl_ng") / "resources" / "datamodels_cim.conf"
        ) as cim_acceleration_datamodels_path:
            if cim_acceleration_datamodels_path.exists():
                parser.read(cim_acceleration_datamodels_path)
            if not cim_acceleration_datamodels_path.exists():
                logger.warning(
                    f"CIM acceleration datamodels file not found at {cim_acceleration_datamodels_path}, skipping CIM datamodel installation."
                )
                return
            else:
                logger.info("Installing default datamodels for CIM.")
                parser.read(cim_acceleration_datamodels_path)

        for datamodel_name in parser:
            if datamodel_name == "DEFAULT":
                # Skip the DEFAULT section for configparser
                continue
            for name, value in parser[datamodel_name].items():
                try:
                    self._install_cim_datamodel(datamodel_name, name, value)
                except Exception as e:
                    logger.error(
                        f"Error creating the conf Datamodel {datamodel_name} key/value {name}/{value}: {e!s}"
                    )

    # TODO: we should have some kind of clean up mechanism for files in the cache that may be
    #   corrupted (e.g. force re-download when a download may have been interrupted in progress)
    def get_from_cache_or_download_dumb(
        self,
        download_session: requests.Session,
        url: HttpUrl,
        app: _SplunkApp,
    ) -> Path:
        """Get a file from cache or download it if not present, without checking etags.

        In read_only_cache mode, if file not in cache, downloads to temporary file
        to maintain thread safety.
        """
        cache_dir = Path().home() / ".contentctl"
        cache_dir.mkdir(parents=True, exist_ok=True)

        # Replace dots in version with underscores to avoid confusion with file extensions
        version_str = str(app.version).replace(".", "_") if app.version else "unknown"
        filename = f"{app.appid}-{version_str}.tgz"
        cache_path = cache_dir / filename

        # If in cache and not a None version app, return cached version
        if app.version is not None and cache_path.exists():
            logger.debug(
                f"Cache hit for {app.appid}: using cached app file: {cache_path}"
            )
            return cache_path
        logger.debug(f"Cache miss for {app.appid}: downloading cached app from: {url}")

        # Need to download
        download_response = download_session.get(str(url), stream=True)
        download_response.raise_for_status()

        content_length_header = download_response.headers.get("Content-Length")
        total_bytes: int | None = None
        if content_length_header:
            try:
                total_bytes = int(content_length_header)
            except TypeError, ValueError:
                total_bytes = None

        progress_bar = tqdm(
            total=total_bytes,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
            desc=f"Downloading {filename}",
            leave=False,
            file=sys.stderr,
        )

        try:
            # In read-only cache mode, download to temp file instead of cache
            if self.read_only_cache:
                logger.warning(
                    f"{app.appid} not in cache. Downloading to temporary location (read-only cache mode)."
                )
                temp_file = tempfile.NamedTemporaryFile(
                    delete=False, suffix=f"-{filename}"
                )
                write_path = Path(temp_file.name)
                file_to_write = temp_file
            else:
                # Otherwise, open a file in the cache directory for writing
                write_path = cache_path
                file_to_write = open(cache_path, "wb")

            # Write to the file in chunks and ensure we close it
            try:
                for chunk in download_response.iter_content(chunk_size=1024 * 1024):
                    if not chunk:
                        continue
                    file_to_write.write(chunk)
                    progress_bar.update(len(chunk))
            finally:
                file_to_write.close()

        # Ensure we close the progress bar
        finally:
            progress_bar.close()

        # Return the path to the downloaded file (in cache or temp location)
        return write_path

    # TODO: catch something less broad than Exception here
    @retry(
        stop=stop_after_delay(60),
        wait=wait_fixed(2),
        retry=retry_if_result(lambda result: result is False),
        retry_error_callback=lambda retry_state: retry_state.outcome.result(),  # type: ignore[union-attr]
        before_sleep=before_sleep_log(logger, logging.DEBUG),
    )
    def is_app_installed(self, app_name: str) -> bool:
        """Check if app is installed in Splunk, with polling for installation delay.

        After uploading an app via the web interface, Splunk needs time to
        process and register the app. This method polls the API until the
        app appears in the installed apps list or timeout is reached (60s).

        Args:
            app_name: The app ID to check for

        Returns:
            True if app is installed, False if not found within 60 seconds
        """
        try:
            self.splunk_api_service.apps.get(app_name)  # type: ignore[reportUnknownMemberType]
            logger.debug(f"App {app_name} installed")
            return True
        except Exception:
            return False

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=10),
        retry=retry_if_exception_type(AppNotInstalledError),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _upload_and_verify_app(
        self,
        app: _SplunkApp,
        endpoint: str,
        upload_files: dict[str, tuple[str, Any, str]],
        force_field: str,
    ) -> None:
        """POST app upload and verify installation with retry on verification failure.

        Retry behavior: Retries up to 3 times if app is not installed after upload
        and verification polling (AppNotInstalledError only). Uses exponential
        backoff (10s, 20s between attempts). All other errors fail immediately.

        Note: HTTP errors during POST are already handled by splunk_web_session retry adapter.
        Registration polling is already handled by is_app_installed() (60s timeout).
        This retry is only for cases where upload succeeds but app never installs.

        Args:
            app: The SplunkApp to install
            endpoint: The upload endpoint (version-specific)
            upload_files: The files dict for the POST request
            force_field: The force override field name (version-specific)

        Raises:
            AppNotInstalledError: If app not installed after upload within timeout
        """
        # Note: We use force=1 for uploads, so this may overwrite existing apps.
        response = self.splunk_web_session.post(
            endpoint,
            files=upload_files,
            data={force_field: 1},
        )
        response.raise_for_status()

        logger.debug(f"Verifying {app.appid} is installed via Splunk API...")

        # Verify app installation via Splunk API
        # The API can only confirm the app exists, not that it was successfully overwritten.
        # The web UI response varies by Splunk version and is unreliable for validation.
        # Check if app is installed (with polling for registration delay)
        if not self.is_app_installed(app.appid):
            logger.error(
                f"App {app.appid} upload failed - app not found in Splunk after upload"
            )
            logger.debug(f"Upload response body: {response.text}")
            raise AppNotInstalledError(
                f"Failed to install app {app.appid}. "
                f"Upload returned success but app not installed within 60 seconds."
            )

        logger.debug(f"Verified {app.appid} is installed")

    def install_app(self, app: _SplunkApp) -> None:
        """Install an app from a hardcoded URL or local path via the splunkweb upload endpoint."""
        if not app.hardcoded_path and not app.url:
            logger.warning(
                f"{app.appid} has no hardcoded_path or url, it will be skipped."
            )
            return

        if app.hardcoded_path:
            path_or_url = app.hardcoded_path
        else:
            path_or_url = HttpUrl(app.splunkbase_download_url)

        response = self.splunk_web_session.get("en-US/manager/search/apps/local")
        response.raise_for_status()

        self.splunk_web_session.headers["X-Requested-With"] = "XMLHttpRequest"
        try:
            splunkweb_csrf_token_8000 = self.splunk_web_session.cookies[
                "splunkweb_csrf_token_8000"
            ]
        except KeyError:
            raise ValueError(
                "Could not upload an app via the web upload, no CSRF token was found in the existing cookies."
            )
        self.splunk_web_session.headers["X-Splunk-Form-Key"] = splunkweb_csrf_token_8000

        if isinstance(path_or_url, HttpUrl):
            download_session = requests.Session()
            # load artifactory credentials if a URL is detected
            if path_or_url.host == "repo.splunkdev.net":
                # TODO: create an ArtifactorySettings model to handle this
                # Try and use the config file first
                artifactory_config_path = Path().home() / ".artifactory" / "config"
                if artifactory_config_path.exists():
                    with open(artifactory_config_path, "r") as config_file:
                        artifactory_config = json.load(config_file)
                    artifactory_username = artifactory_config["username"]
                    artifactory_token = artifactory_config["token"]
                else:
                    # Then, try to load from env vars
                    artifactory_authorization = os.getenv(
                        "ARTIFACTORY_AUTHORIZATION", None
                    )
                    if artifactory_authorization is None:
                        raise ValueError(
                            "Artifactory credentials not provided in environment variables and "
                            f"{artifactory_config_path} does not exist, cannot download app from "
                            "artifactory."
                        )
                    artifactory_username, artifactory_token = (
                        artifactory_authorization.split(":")
                    )
                download_session.auth = (
                    artifactory_username,
                    artifactory_token,
                )
            elif path_or_url.host == "splunkbase.splunk.com":
                if not self.splunkbase_username or not self.splunkbase_password:
                    raise ValueError(
                        "Splunkbase credentials not provided in environment variables, cannot download app from splunkbase."
                    )
                download_session.cookies["sessionid"] = self.splunkbase_token
            local_file_path = self.get_from_cache_or_download_dumb(
                download_session, path_or_url, app
            )
        else:
            local_file_path = Path(path_or_url)

        # In dry-run mode, we only download to cache and return
        if self.dry_run:
            logger.info(f"Dry-run: {app.appid} cached at {local_file_path}")
            return

        # Detect Splunk version and set upload parameters accordingly
        splunk_version = self.splunk_api_service.splunk_version[0]  # type: ignore[reportUnknownVariableType]
        if splunk_version >= 10:
            # Splunk 10+ uses upload_app endpoint
            app_field = "appPackage"
            endpoint = "en-US/manager/appinstall/upload_app"
            force_field = "forceOverride"
            logger.debug(
                f"Using Splunk 10+ upload endpoint for version {splunk_version}"
            )
        else:
            # Splunk <10 uses _upload endpoint
            app_field = "appfile"
            endpoint = "en-US/manager/appinstall/_upload"
            force_field = "force"
            logger.debug(
                f"Using Splunk <10 upload endpoint for version {splunk_version}"
            )

        file_handle = open(local_file_path, "rb")

        upload_files = {
            app_field: (
                local_file_path.name
                if local_file_path
                else Path(str(path_or_url)).name,
                file_handle,
                "application/octet-stream",
            )
        }

        try:
            self._upload_and_verify_app(app, endpoint, upload_files, force_field)
        finally:
            if file_handle:
                file_handle.close()
            # Clean up temp file if it was created in read-only cache mode
            if local_file_path.parent == Path(tempfile.gettempdir()):
                try:
                    if local_file_path.exists():
                        local_file_path.unlink()
                        logger.debug(f"Cleaned up temporary file: {local_file_path}")
                # TODO: catch something more specific than Exception here
                except Exception as e:
                    logger.warning(
                        f"Failed to clean up temporary file {local_file_path}: {e}"
                    )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=10),
        retry=retry_if_exception_type((TimeoutError, ConnectionError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def install_ess(self) -> None:
        """Perform special Splunk Enterprise Security install search command and stream results back.

        Retry behavior: Retries up to 3 times on network errors (TimeoutError,
        ConnectionError) with exponential backoff (10s, 20s between attempts). Non-network errors
        fail immediately without retry.
        """
        logger.info("Performing special ES install step...")
        job = self.splunk_api_service.jobs.create(
            "| essinstall --ssl_enablement ignore", exec_mode="normal", preview=True
        )

        while not job.is_ready():
            pass

        # TODO: port over my result iterator class from old contentctl
        logged_results: set[str] = set()
        # silly little hack to get us an extra iteration for reading the final results
        oncemore = iter([True, False])
        while not job.is_done() or next(oncemore):
            preview = job.preview(output_mode="json")
            reader = results.JSONResultsReader(preview)
            try:
                for result in reader:
                    if isinstance(result, results.Message):
                        message = result.message
                        # Handle diagnostic messages
                        if message not in logged_results:
                            logger.warning(message)
                            logged_results.add(message)
                    else:
                        # Handle normal result events
                        message = result["_raw"]
                        if message not in logged_results:
                            logger.debug(message)
                            logged_results.add(message)

            except Exception as e:
                logger.warning(f"Error reading preview results: {e}")
                raise e

            # Wait before next poll
            time.sleep(1)

    def _generate_install_yml(self, apps_to_install: dict[str, _SplunkApp]) -> None:
        """Generate dry-run-install.yml file with apps pointing to cached or local paths.

        Args:
            apps_to_install: Dictionary of apps to include in dry-run-install.yml.
                Apps downloaded from URLs will point to cache, apps with local file paths remain unchanged.
        """
        cache_dir = Path().home() / ".contentctl"
        updated_apps: list[dict[str, Any]] = []

        for app in apps_to_install.values():
            # TODO: Currently install_app() skips these, but we should consider deriving url from
            # appid in SplunkApp, for raising validation errors if neither url or hardcoded_path is
            # provided in user-defined install.yml
            if not app.hardcoded_path and not app.url:
                logger.debug(
                    f"Skipping {app.appid} in dry-run-install.yml generation - no url or hardcoded_path"
                )
                continue

            # Build dict for SplunkApp construction
            app_data: dict[str, Any] = {"appid": app.appid}

            if app.version is not None:
                app_data["version"] = app.version

            # Determine hardcoded_path
            if app.hardcoded_path and isinstance(app.hardcoded_path, Path):
                # Local file, keep as-is
                app_data["hardcoded_path"] = app.hardcoded_path
            else:
                # URL (either hardcoded_path URL or splunkbase URL), should be in cache
                # Replace dots in version with underscores to match cache filename format
                version_str = (
                    str(app.version).replace(".", "_") if app.version else "unknown"
                )
                cache_path = cache_dir / f"{app.appid}-{version_str}.tgz"
                if not cache_path.exists():
                    raise FileNotFoundError(
                        f"Expected {app.appid} to be in cache at {cache_path} after download, but file not found."
                    )
                app_data["hardcoded_path"] = cache_path

            app_data["source_file_path"] = app.source_file_path
            app_data["source_index"] = app.source_index

            # Create new SplunkApp with updated paths
            updated_apps.append(app_data)

        # Use SplunkAppList for validation and serialization
        app_list = SplunkAppList.model_validate({"apps": updated_apps})

        # Write dry-run-install.yml to current directory
        install_yml_path = Path().cwd() / "dry-run-install.yml"
        with open(install_yml_path, "w") as f:
            yaml.dump(
                app_list.model_dump(mode="json", exclude_none=True),
                f,
                default_flow_style=False,
                sort_keys=False,
            )

        logger.info(f"Generated dry-run-install.yml at {install_yml_path}")

    def load_install_yml_apps_list(
        self, install_yml_path: Path
    ) -> list[dict[str, Any]]:
        """Load apps from an install.yml file.

        Args:
            install_yml_path: Path to the install.yml file to load.
        """
        # defer to load_yml_file_to_dict for most of the error raising around file not found, invalid yaml, etc.
        try:
            install_yml_dict = load_yml_file_to_dict(install_yml_path)
            apps_list = install_yml_dict["apps"]
        except ValueError:
            raise ValueError(
                f"The content of {install_yml_path} is not a dictionary. The yml must be a dictionary with a key called 'apps' with a value of a list of apps to install. 'apps' can be an empty list, like 'apps: []'."
            )
        except KeyError:
            raise ValueError(
                f"The dictionary loaded from {install_yml_path} must contain a key called 'apps' with a value of a list of apps to install. 'apps' can be an empty list, like 'apps: []'."
            )
        for i, app in enumerate(apps_list):
            app["source_file_path"] = install_yml_path.absolute()
            app["source_index"] = i
        logger.info(f"Loaded {len(apps_list)} apps from {install_yml_path}")
        return apps_list

    def run(self) -> None:
        """Run the installation process."""
        logger.debug("Settings:")
        for key, value in self.model_dump().items():
            logger.debug(f"{key}: {value}")

        # load default apps
        logger.info("Parsing default required apps from contentctl...")
        with resources.as_file(
            resources.files("contentctl_ng") / "resources" / "install.yml"
        ) as default_apps_path:
            default_apps = self.load_install_yml_apps_list(default_apps_path)
        logger.info("Parsed default required apps from contentctl.")

        logger.info("Parsing required apps from content...")
        # deduplicate content_apps by their app name since the same one will show up in many datasources (different from appid/folder name)
        deduplicated_content_apps: dict[str, dict[str, Any]] = {}
        for detection in self.content.detections:
            for data_source in detection.all_possible_datasources:
                for i, content_app_TA in enumerate(data_source.supported_TA):
                    content_app = content_app_TA.model_dump(include={"version", "url"})
                    content_app["source_file_path"] = data_source._path  # pyright: ignore[reportPrivateUsage] - guaranteed to exist and be a Path for DataSource
                    content_app["source_index"] = i
                    deduplicated_content_apps[content_app_TA.name] = content_app
        content_apps: list[dict[str, Any]] = list(deduplicated_content_apps.values())
        logger.info(f"Parsed {len(content_apps)} required apps from content.")

        # load user-provided apps from install.yml in current directory
        user_apps_path = Path().cwd() / "install.yml"
        logger.info("Parsing user-provided required apps from install.yml...")
        user_apps = self.load_install_yml_apps_list(user_apps_path)
        if not user_apps:
            logger.info(
                "User-provided install.yml is empty, only using apps from content dirs and default apps provided by contentctl_ng."
            )

        # check required apps against splunkbase to fetch latest versions and look for invalid specific versions
        required_apps = SplunkAppList.model_validate(
            {"apps": default_apps + content_apps + user_apps}
        )

        logger.info("Getting installed apps from splunkd...")
        # using the splunklib service .list() func gets us everything in one round trip to splunkd
        splunklib_apps = self.splunk_api_service.apps.list()
        installed_apps: dict[str, dict[str, Any]] = {}
        for splunklib_app in splunklib_apps:
            app_name = splunklib_app.name
            installed_apps[app_name] = {
                "appid": app_name,
                "version": PydanticVersion(getattr(splunklib_app, "version", "0.0.0")),
            }

        force_apps: dict[str, _SplunkApp] = {}
        new_apps: dict[str, _SplunkApp] = {}
        upgrade_apps: dict[str, _SplunkApp] = {}
        downgrade_apps: dict[str, _SplunkApp] = {}
        skipped_apps: dict[str, _SplunkApp] = {}
        for required_app in required_apps.apps:
            if required_app.version is None:
                force_apps[required_app.appid] = required_app
            else:
                if required_app.appid not in installed_apps:
                    new_apps[required_app.appid] = required_app
                else:
                    if (
                        required_app.version
                        > installed_apps[required_app.appid]["version"]
                    ):
                        upgrade_apps[required_app.appid] = required_app
                    elif (
                        required_app.version
                        < installed_apps[required_app.appid]["version"]
                    ):
                        downgrade_apps[required_app.appid] = required_app
                    elif (
                        required_app.version
                        == installed_apps[required_app.appid]["version"]
                    ):
                        skipped_apps[required_app.appid] = required_app

        logger.info(
            f"{len(skipped_apps)} apps are already installed and will be skipped."
        )

        logger.info(f"{len(force_apps)} apps will be force installed.")
        for force_app in sorted(force_apps.values()):
            logger.debug(f"- {force_app.appid}")

        logger.info(f"{len(new_apps)} apps will be newly installed.")
        for new_app in sorted(new_apps.values()):
            logger.debug(f"- {new_app.appid} ({new_app.version})")

        logger.info(f"{len(upgrade_apps)} apps will be upgraded.")
        for upgrade_app in sorted(upgrade_apps.values()):
            logger.debug(
                f"- {upgrade_app.appid} ({installed_apps[upgrade_app.appid]['version']} -> {upgrade_app.version})"
            )

        logger.info(f"{len(downgrade_apps)} apps will be downgraded.")
        for downgrade_app in sorted(downgrade_apps.values()):
            logger.debug(
                f"- {downgrade_app.appid} ({installed_apps[downgrade_app.appid]['version']} -> {downgrade_app.version})"
            )

        # create combined list of apps to install
        apps_to_install = force_apps | new_apps | upgrade_apps | downgrade_apps

        # TODO: Refactor to extract methods for installation and dry-run paths
        # to make it easier to maintain parallel workflows
        if self.dry_run:
            # Dry-run mode: download apps to cache and generate install.yml
            logger.info("Dry-run mode: downloading apps to cache...")
            for i, app in enumerate(apps_to_install.values()):
                logger.info(
                    f"({i + 1}/{len(apps_to_install)}) Downloading {app.appid} ({app.version})..."
                )
                self.install_app(app)
            logger.info("Generating dry-run-install.yml with cached app paths...")
            self._generate_install_yml(apps_to_install)
            logger.info("Dry-run completed successfully!")
            return

        # configure hec session by making a first reference to the cached property
        self.splunk_hec_session

        roles: list[str] = ["user", "power", "can_delete"]
        for i, app in enumerate(sorted(apps_to_install.values())):
            logger.info(
                f"({i + 1}/{len(apps_to_install)}) Installing {app.appid} ({app.version})..."
            )

            self.install_app(app)

            if app.appid == "SplunkEnterpriseSecuritySuite":
                self.install_ess()
                roles.extend(["ess_admin", "ess_analyst", "ess_user"])
            elif app.appid == "Splunk_SA_CIM":
                self.install_cim_datamodels()

            logger.info(
                f"({i + 1}/{len(apps_to_install)}) Installation of {app.appid} ({app.version}) completed successfully!"
            )

        # configure roles
        logger.info("Configuring roles and indexes...")
        indexes = self.splunk_api_service.indexes.list()
        all_indexes = ";".join([index.name for index in indexes])
        self.splunk_api_service.roles.post(
            self.splunk_username,
            imported_roles=roles,
            srchIndexesAllowed=all_indexes,
            srchIndexesDefault="contentctl_testing_index",
        )
        self.splunk_api_service.post(
            "/services/properties/authorize/default/deleteIndexesAllowed",
            value=all_indexes,
        )
        logger.info("Configured roles and indexes.")
        logger.info("Installation completed successfully!")

        # Restart Splunk if required after app installation
        self.restart_splunk_if_required()
