"""Custom Pydantic model for handling packaging.version.Version objects."""

from typing import Any, Callable, Union

from packaging.version import InvalidVersion, Version
from pydantic_core import CoreSchema, core_schema


class PydanticVersion(Version):
    """A Pydantic-compatible version class that extends packaging.version.Version.

    This class provides proper serialization, deserialization, and validation
    for version strings while maintaining all the functionality of packaging.version.Version.

    Examples:
        >>> v = PydanticVersion("1.2.3")
        >>> str(v)
        '1.2.3'
        >>> v > PydanticVersion("1.2.0")
        True
        >>> v.major
        1
    """

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: Any) -> CoreSchema:
        """Generate the core schema for Pydantic validation."""
        return core_schema.with_info_after_validator_function(
            cls._validate,
            core_schema.union_schema(
                [
                    core_schema.is_instance_schema(
                        cls
                    ),  # Accept existing PydanticVersion objects
                    core_schema.str_schema(),  # Accept string inputs
                ]
            ),
            serialization=core_schema.to_string_ser_schema(),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema: CoreSchema, handler: Callable[..., dict[str, Any]]
    ) -> dict[str, Any]:
        """Generate the JSON schema for this type."""
        return {
            "type": "string",
            "format": "version",
            "description": "A semantic version string (e.g., '1.2.3', '2.0.0-alpha.1')",
            "examples": ["1.0.0", "2.1.3", "1.0.0-beta.1"],
        }

    @classmethod
    def _validate(
        cls, value: Union[str, "PydanticVersion"], _info: Any
    ) -> "PydanticVersion":
        """Validate and convert input to PydanticVersion."""
        if isinstance(value, cls):
            return value
        if isinstance(value, str):
            try:
                return cls(value)
            except InvalidVersion as e:
                raise ValueError(f"Invalid version string '{value}': {e}")
        raise TypeError(f"Expected str or PydanticVersion, got {type(value)}")

    def __str__(self) -> str:
        """Return the string representation of the version."""
        return super().__str__()

    def __repr__(self) -> str:
        """Return the repr of the version."""
        return f"PydanticVersion('{self}')"
