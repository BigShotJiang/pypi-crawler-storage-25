"""Generate markdown-formatted release notes showing new and modified content."""

import logging
import re
from pathlib import Path
from typing import Annotated

import yaml
from git import Repo
from pydantic import (
    AnyUrl,
    DirectoryPath,
    Field,
    UrlConstraints,
)
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

SplunkUrl = Annotated[
    AnyUrl,
    UrlConstraints(allowed_schemes=["splunk"], host_required=True),
]

# This regex match the final component of a URL,
# from the last / to the end of the line. This means
# if the input is
# https://research.splunk.com/detections/application/m365_copilot_agentic_jailbreak_attack.yml
# it would match m365_copilot_agentic_jailbreak_attack.yml
# Similarly
# https://research.splunk.com/detections/application/some_extra_component/m365_copilot_agentic_jailbreak_attack.yml
# also matches m365_copilot_agentic_jailbreak_attack.yml.
# However the path
# https://research.splunk.com/detections/application/m365_copilot_agentic_jailbreak_attack.yml/
# would match ""
# This is the intended behavior of the string, as it is used to substitute the last component of the
# url from the name of the content to its UUID for linking to the research site.
FINAL_URL_PATH_COMPONENT_REGEX = re.compile(r"(?<=/)[^/]*$")


class ReleaseNoteSettings(BaseSettings):
    """Settings pertaining to connecting to a Splunk instance.

    Information to help calculate changes between the new_git_ref
    and the old_git_ref.

    Attributes:
        content_dir (str): directory where the app is rooted
        new_git_ref (str): New commit hash, branch, or tag for one side of the diff
        old_git_ref (str): Old commit hash, branch, or tag for one side of the diff
    """

    model_config = SettingsConfigDict(populate_by_name=True)

    content_dir: DirectoryPath = Field(
        description="Provide the root of the repo to generate release_notes for. Defaults to the current directory",
        default=Path.cwd(),
        alias="content-dir",
    )

    new_git_ref: str = Field(
        description="(For 'changed' mode) Provide a git ref (branch, tag, commit) to compare against. If 'changed' mode is selected, this will instead default to 'HEAD'.",
        alias="new-git-ref",
    )

    old_git_ref: str = Field(
        description="(For 'changed' mode) Provide a git ref (branch, tag, commit) to compare against. If 'changed' mode is selected, this will instead default to 'HEAD'.",
        alias="old-git-ref",
    )


class ReleaseNoteGenerator(ReleaseNoteSettings):
    """Service for generating release notes from repository changes.

    This logic was mostly a port over of the ReleaseNotes code from
    legacy contentctl, but has some modifications for cleaner code and
    to remove reliance on the legacy CONFIG objects.

    Note: Docstrings in this file were auto-generated in bulk by Claude.

    """

    def run(self) -> None:
        """Tests the content app."""
        # Placeholder for test logic
        logger.info(
            f"Generating release notes between new_gitref: [{self.new_git_ref}] and old_gitref: [{self.old_git_ref}]"
        )
        self.release_notes(self.content_dir, self.new_git_ref, self.old_git_ref)

    def create_notes(
        self, repo_path: Path, file_paths: list[Path], header: str
    ) -> dict[str, list[str] | str]:
        """Create release notes for a list of changed files.

        Args:
            repo_path: Path to the git repository.
            file_paths: List of file paths to process.
            header: Header text for the notes section.

        Returns:
            Dictionary with headers, changes, and warnings.

        Raises:
            Exception: If YAML parsing fails.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        updates: list[str] = []
        warnings: list[str] = []
        for file_path in file_paths:
            # Check if the file exists
            if file_path.exists() and file_path.is_file():
                # Check if the file is a YAML file
                if file_path.suffix in [".yaml", ".yml"]:
                    # Read and parse the YAML file
                    with open(file_path, "r") as file:
                        try:
                            data = yaml.safe_load(file)
                            # Check and create story link
                            if "name" in data and "stories" in file_path.parts:
                                story_link = (
                                    "https://research.splunk.com/stories/"
                                    + data["name"]
                                )
                                story_link = story_link.replace(" ", "_")
                                story_link = story_link.lower()
                                updates.append(
                                    "- "
                                    + "["
                                    + f"{data['name']}"
                                    + "]"
                                    + "("
                                    + story_link
                                    + ")"
                                )

                            if "name" in data and "playbooks" in file_path.parts:
                                playbook_link = "https://research.splunk.com/" + str(
                                    file_path
                                ).replace(str(repo_path), "")
                                playbook_link = playbook_link.replace(
                                    "yml", "/"
                                ).lower()
                                updates.append(
                                    "- "
                                    + "["
                                    + f"{data['name']}"
                                    + "]"
                                    + "("
                                    + playbook_link
                                    + ")"
                                )

                            if "name" in data and "macros" in file_path.parts:
                                updates.append("- " + f"{data['name']}")

                            if "name" in data and "lookups" in file_path.parts:
                                updates.append("- " + f"{data['name']}")

                            # Create only SSA link when its production
                            if (
                                "name" in data
                                and "id" in data
                                and "ssa_detections" in file_path.parts
                            ):
                                if data["status"] == "production":
                                    temp_link = "https://research.splunk.com/" + str(
                                        file_path
                                    ).replace(str(repo_path), "")

                                    detection_link = FINAL_URL_PATH_COMPONENT_REGEX.sub(
                                        data["id"],
                                        temp_link,
                                    )
                                    detection_link = detection_link.replace(
                                        "detections", ""
                                    )
                                    detection_link = detection_link.replace("ssa_/", "")
                                    updates.append(
                                        "- "
                                        + "["
                                        + f"{data['name']}"
                                        + "]"
                                        + "("
                                        + detection_link
                                        + ")"
                                    )

                                if data["status"] == "validation":
                                    updates.append(
                                        "- " + f"{data['name']}" + " (Validation Mode)"
                                    )

                            # Check and create detection link
                            if (
                                "name" in data
                                and "id" in data
                                and "detections" in file_path.parts
                                and "ssa_detections" not in file_path.parts
                                and "detections/deprecated" not in file_path.parts
                            ):
                                if (
                                    data["status"] == "production"
                                    or data["status"] == "experimental"
                                ):
                                    temp_link = "https://research.splunk.com" + str(
                                        file_path
                                    ).replace(str(repo_path), "")

                                    detection_link = FINAL_URL_PATH_COMPONENT_REGEX.sub(
                                        data["id"],
                                        temp_link,
                                    )
                                    detection_link = detection_link.replace(
                                        "detections", ""
                                    )
                                    detection_link = detection_link.replace(
                                        ".com//", ".com/"
                                    )
                                    updates.append(
                                        "- "
                                        + "["
                                        + f"{data['name']}"
                                        + "]"
                                        + "("
                                        + detection_link
                                        + ")"
                                    )

                                if data["status"] == "deprecated":
                                    temp_link = "https://research.splunk.com" + str(
                                        file_path
                                    ).replace(str(repo_path), "")

                                    detection_link = FINAL_URL_PATH_COMPONENT_REGEX.sub(
                                        data["id"],
                                        temp_link,
                                    )
                                    detection_link = detection_link.replace(
                                        "detections", ""
                                    )
                                    detection_link = detection_link.replace(
                                        ".com//", ".com/"
                                    )
                                    updates.append(
                                        "- "
                                        + "["
                                        + f"{data['name']}"
                                        + "]"
                                        + "("
                                        + detection_link
                                        + ")"
                                    )

                        except yaml.YAMLError as exc:
                            raise Exception(
                                f"Error parsing YAML file for release_notes {file_path}: {exc!s}"
                            )
            else:
                warnings.append(
                    f"Error parsing YAML file for release_notes. File not found or is not a file: {file_path}"
                )
        # print out all updates at once
        success_header = f"### {header} - [{len(updates)}]"
        warning_header = f"### {header} - [{len(warnings)}]"
        return {
            "header": success_header,
            "changes": sorted(updates),
            "warning_header": warning_header,
            "warnings": warnings,
        }

    def release_notes(self, path: Path, new_git_ref: str, old_git_ref: str) -> None:
        """Generate release notes comparing two git references.

        Args:
            path (Path): Path to the repository.
            new_git_ref (str): New git reference (tag, branch, or commit).
            old_git_ref (str): Old git reference (tag, branch, or commit).

        Raises:
            Exception: If there are other issues parsing YMLS/creating release notes
            ValueError: If tags/branches/commits don't exist in repository.

        Note: Docstrings in this file were auto-generated in bulk by Claude.
        """
        ### Remove hard coded path
        directories: list[Path] = [
            path / "detections",
            path / "stories",
            path / "macros",
            path / "lookups",
            path / "playbooks",
            path / "ssa_detections",
        ]

        repo = Repo(path)
        # Ensure that both the new_gitref and the old_gitref are both in the repo.
        # Report errors if they are not. Check both, don't just fail on the first one.

        missing_ref_messages: list[str] = []
        try:
            _ = repo.commit(old_git_ref)
        except Exception as e:
            missing_ref_messages.append(f"old_git_ref {old_git_ref} missing: {e!s}")

        try:
            _ = repo.commit(new_git_ref)
        except Exception as e:
            missing_ref_messages.append(f"new_git_ref {new_git_ref} missing: {e!s}")

        if missing_ref_messages:
            raise ValueError(
                f"{len(missing_ref_messages)} errors encountered while resolving git_refs. These MUST point to either a commit, tag, or branch:\n - "
                + "\n - ".join(missing_ref_messages)
            )

        # We get these here again, instead of using the results above, because
        # pyright complains that old_commit and new_commit are possibly undefined
        # Since it is a cheap operation, it's easier to do this again than add
        # a clunky pyright:ignore
        old_commit = repo.commit(old_git_ref)  # type: ignore[unreachable]
        new_commit = repo.commit(new_git_ref)  # type: ignore[unreachable]

        diff_index = old_commit.diff(new_commit)

        modified_files: list[Path] = []
        added_files: list[Path] = []
        for diff in diff_index:
            file_path = Path(diff.a_path or "").absolute()

            # Check if the file is in the specified directories
            if any(file_path.is_relative_to(directory) for directory in directories):
                # Check if a file is Modified
                if diff.change_type == "M":
                    modified_files.append(file_path)

                # Check if a file is Added
                elif diff.change_type == "A":
                    added_files.append(file_path)
                    # print(added_files)
        detections_added: list[Path] = []
        ba_detections_added: list[Path] = []
        stories_added: list[Path] = []
        macros_added: list[Path] = []
        lookups_added: list[Path] = []
        playbooks_added: list[Path] = []
        detections_modified: list[Path] = []
        ba_detections_modified: list[Path] = []
        stories_modified: list[Path] = []
        macros_modified: list[Path] = []
        lookups_modified: list[Path] = []
        playbooks_modified: list[Path] = []
        detections_deprecated: list[Path] = []

        print(f"Added files length: {len(added_files)}")
        print(f"Modified files length: {len(modified_files)}")
        for file in modified_files:
            file = path / file
            if (
                "detections" in file.parts
                and "ssa_detections" not in file.parts
                and "deprecated" not in file.parts
            ):
                detections_modified.append(file)
            if (
                "detections" in file.parts
                and "ssa_detections" not in file.parts
                and "deprecated" in file.parts
            ):
                detections_deprecated.append(file)
            if "stories" in file.parts:
                stories_modified.append(file)
            if "macros" in file.parts:
                macros_modified.append(file)
            if "lookups" in file.parts:
                lookups_modified.append(file)
            if "playbooks" in file.parts:
                playbooks_modified.append(file)
            if "ssa_detections" in file.parts:
                ba_detections_modified.append(file)

        for file in added_files:
            file = path / file
            if "detections" in file.parts and "ssa_detections" not in file.parts:
                detections_added.append(file)
            if "stories" in file.parts:
                stories_added.append(file)
            if "macros" in file.parts:
                macros_added.append(file)
            if "lookups" in file.parts:
                lookups_added.append(file)
            if "playbooks" in file.parts:
                playbooks_added.append(file)
            if "ssa_detections" in file.parts:
                ba_detections_added.append(file)

        print(f"Generating release notes       - \033[92m{new_git_ref}\033[0m")
        print(f"Compared against               - \033[92m{old_git_ref}\033[0m")
        print(f"\n## Release notes for ESCU {new_git_ref}")

        notes = [
            self.create_notes(path, stories_added, header="New Analytic Story"),
            self.create_notes(path, stories_modified, header="Updated Analytic Story"),
            self.create_notes(path, detections_added, header="New Analytics"),
            self.create_notes(path, detections_modified, header="Updated Analytics"),
            self.create_notes(path, macros_added, header="Macros Added"),
            self.create_notes(path, macros_modified, header="Macros Updated"),
            self.create_notes(path, lookups_added, header="Lookups Added"),
            self.create_notes(path, lookups_modified, header="Lookups Updated"),
            self.create_notes(path, playbooks_added, header="Playbooks Added"),
            self.create_notes(path, playbooks_modified, header="Playbooks Updated"),
            self.create_notes(
                path, detections_deprecated, header="Deprecated Analytics"
            ),
        ]

        # generate and show ba_notes in a different section
        ba_notes = [
            self.create_notes(path, ba_detections_added, header="New BA Analytics"),
            self.create_notes(
                path, ba_detections_modified, header="Updated BA Analytics"
            ),
        ]

        def printNotes(
            notes: list[dict[str, list[str] | str]],
            outfile: Path | None = None,
        ):
            num_changes = sum([len(note["changes"]) for note in notes])
            num_warnings = sum([len(note["warnings"]) for note in notes])
            lines: list[str] = []
            lines.append(f"Total New and Updated Content: [{num_changes}]")
            for note in notes:
                lines.append("")
                lines.append(note["header"])
                lines += note["changes"]

            lines.append(f"\n\nTotal Warnings: [{num_warnings}]")
            for note in notes:
                if len(note["warnings"]) > 0:
                    lines.append(note["warning_header"])
                    lines += note["warnings"]
            text_blob = "\n".join(lines)
            print(text_blob)
            if outfile is not None:
                with open(outfile, "w") as writer:
                    writer.write(text_blob)

        printNotes(notes, path / "dist" / "release_notes.md")

        print("\n\n### Other Updates\n-\n")
        print("\n## BA Release Notes")
        printNotes(ba_notes, path / "dist" / "ba_release_notes.md")
        print("Release notes completed successfully")
