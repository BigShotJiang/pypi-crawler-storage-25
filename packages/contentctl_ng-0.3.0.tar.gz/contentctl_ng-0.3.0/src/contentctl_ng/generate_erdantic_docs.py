"""Generate ERDantic docs for the contentctl-ng project."""

# to get erdantic installed, I needed to do the following,
# even after brew install graphviz:
# https://stackoverflow.com/a/78286211

import code
from pathlib import Path

import erdantic as erd

from contentctl_ng.objects import macro

obj_docs_path = Path("docs/object_documentation/")
e = erd.create(macro.FilebackedMacro)


code.interact(local=locals())
# erd.draw(macro.Macro, out=obj_docs_path / "macro.png")
# erd.draw(lookup.Lookup, out=obj_docs_path / "lookup.png")
# erd.draw(data_source.DataSource, out=obj_docs_path / "data_source.png")
# erd.draw(story.Story, out=obj_docs_path / "story.png")
# erd.draw(content.SecurityContent, out=obj_docs_path / "security_content.png")
# erd.draw(dashboard.Dashboard, out=obj_docs_path / "dashboard.png")
