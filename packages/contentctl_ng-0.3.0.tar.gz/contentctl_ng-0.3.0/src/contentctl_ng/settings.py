"""Settings that can be mixed into other top-level objects (i.e. Installer)."""

import json
import logging
import time
from functools import cached_property
from pathlib import Path
from typing import ClassVar

import requests
from bs4 import BeautifulSoup
from pydantic import DirectoryPath, Field, FilePath, SecretStr
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)
from requests.adapters import HTTPAdapter, Retry
from requests_toolbelt.sessions import BaseUrlSession
from splunklib import client
from splunklib.binding import HTTPError
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential,
    wait_fixed,
)

from contentctl_ng.objects.object_parser import AppFactory, AppRoot

logger = logging.getLogger(__name__)

# These have been intentionally removed, along with a redefinition of the 'content' property of ContentSettings,
# to remove dependency on legacy contentctl.
# from contentctl import api
# from contentctl.contentctl import validate_func
# from contentctl.input.director import DirectorOutputDto


class ContentSettings(BaseSettings):
    """Settings pertaining to loading content.

    Attributes:
        content_dirs (list[DirectoryPath]): The paths to the content directories (i.e. the ESCU repo root).

    """

    model_config = SettingsConfigDict(populate_by_name=True)

    content_dirs: list[DirectoryPath] = Field(
        description="Provide the paths to the content directories. Defaults to the current working directory.",
        default=[Path.cwd()],
        alias="content-dirs",
    )

    # root dir from which build.yml loading, build output, and json schemas output are derived
    # can be the same as a content dir (likely for running in the same cwd as a single content dir)
    # or can be separate (ideal for multiple content dirs where cwd is the parent dir above the content dirs)
    root_dir: ClassVar[DirectoryPath] = Path.cwd()
    # path where fully-built content app will be output as a directory and as a tar.gz
    # TODO: when hooking inspect up to CLI, use build_output_dir to derive latest app build in inspect as default behavior if new_app_path is not provided
    build_output_dir: ClassVar[DirectoryPath] = root_dir / "dist"
    # path where json schemas will be output from build
    schemas_dir: ClassVar[DirectoryPath] = root_dir / "schemas"
    # path to the new-schema build.yml file that defines the built app metadata
    build_yml_file: ClassVar[FilePath] = root_dir / "build.yml"
    # path to the legacy contentctl.yml file
    legacy_contentctl_yml_file: ClassVar[FilePath] = root_dir / "contentctl.yml"

    @cached_property
    def content(self) -> AppFactory:
        """Load and validate security content from the provided directories."""
        if not self.schemas_dir.is_dir():
            if self.schemas_dir.exists():
                raise FileExistsError(
                    f"schemas directory: {self.schemas_dir} exists, but is not a directory!"
                )
        self.schemas_dir.mkdir(parents=True, exist_ok=True)

        if not self.build_yml_file.is_file():
            raise FileNotFoundError(
                f"build.yml MUST exist at the following path, but it does not:{self.build_yml_file.absolute()}"
            )

        try:
            app_factory = AppFactory(
                app=AppRoot(
                    build_dot_yml_path=self.build_yml_file,
                    schemas_directory=self.schemas_dir,
                    directories=self.content_dirs,
                ),
                validation_fast_fail=True,
            )
            return app_factory
        except ExceptionGroup as e:
            for sub_exception in e.exceptions:
                logger.error(type(sub_exception))
                if len(sub_exception.__notes__) > 0:
                    # The first note store here is the full path to the file
                    # The full path makes it very deterministic and CMD-Click
                    # takes you directly to it in most shells.
                    logger.error(f"File: {sub_exception.__notes__[0]}")
                # Print the exception text and pad it with a newline
                logger.error(str(sub_exception) + "\n")
            raise RuntimeError(
                "One or more errors occurred while loading content. See previous logs for details."
            )

    @cached_property
    def build_output_app_dir(self) -> DirectoryPath:
        """Get the output directory for the built content app, which is derived from the build_output_dir and the content app name from build.yml."""
        return self.build_output_dir / self.content.app._shared_app_settings.id

    @cached_property
    def build_output_app_package_path(self) -> FilePath:
        """Get the output file path for the built content app package (tar.gz), which is derived from the build_output_app_path."""
        return self.build_output_app_dir.with_suffix(".tar.gz")


class SplunkSettings(BaseSettings):
    """Settings pertaining to connecting to a Splunk instance.

    Attributes:
        splunk_host (str): The hostname for the Splunk server.
        splunk_api_port (int): The API port for the Splunk server [1-65535].
        splunk_username (str): The username for the Splunk server.
        splunk_password (SecretStr): The password for the Splunk server.

    """

    model_config = SettingsConfigDict(populate_by_name=True)

    MAX_UPLOAD_SIZE_MB: ClassVar[int] = 2048
    SPLUNKD_CONNECTION_TIMEOUT_SECONDS: ClassVar[int] = 300

    splunk_host: str = Field(
        description="Provide a hostname for the Splunk server.",
        default="localhost",
        alias="splunk-host",
    )
    splunk_api_port: int = Field(
        description="Provide the API port for the Splunk server [1-65535].",
        default=8089,
        ge=1,
        le=65535,
        alias="splunk-api-port",
    )
    splunk_username: str = Field(
        description="Provide the username for the Splunk server.",
        default="admin",
        alias="splunk-username",
    )
    splunk_password: SecretStr = Field(
        description="Provide the password for the Splunk server. This defaults to 'Chang3d!', but it will be hidden with asterisks when logged.",
        default=SecretStr("Chang3d!"),
        alias="splunk-password",
    )
    restart_timeout: int = Field(
        default=240,
        description="Timeout in seconds for Splunk restart operations.",
        ge=1,
        alias="restart-timeout",
    )

    @cached_property
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=5),
        retry=retry_if_exception_type((TimeoutError, ConnectionError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def splunk_api_service(self) -> client.Service:
        """Connect to Splunk API service with retry logic.

        Retry behavior: Retries up to 3 times on network errors (TimeoutError,
        ConnectionError) with exponential backoff (5s, 10s between attempts). Non-network errors
        fail immediately without retry.

        Note: client.connect() does not accept a timeout parameter, so we rely on
        OS TCP timeout (~2-3 minutes per attempt).

        Returns:
            client.Service: The Splunk SDK client service instance.
        """
        logger.debug("Connecting to the Splunk API service...")
        service = client.connect(
            host=self.splunk_host,
            port=self.splunk_api_port,
            username=self.splunk_username,
            password=self.splunk_password.get_secret_value(),
        )
        logger.debug("Connected to the Splunk API service.")
        return service

    def restart_splunk_if_required(self, restart_required: bool | None = None) -> None:
        """Check if Splunk restart is required and perform restart if needed.

        After installing apps or changing configuration, Splunk may set restart_required=True
        to indicate that a restart is needed. This method checks the flag, restarts if needed,
        and verifies the restart completed successfully.

        Args:
            restart_required: Optional override for the restart_required flag.
                If None, uses self.splunk_api_service.restart_required.
                If True, forces a restart. If False, skips restart.

        Raises:
            RuntimeError: If restart fails or times out.
        """
        logger.info("Checking if Splunk restart is required...")

        # Use provided value or check the service flag
        if restart_required is None:
            restart_required = self.splunk_api_service.restart_required  # type: ignore[reportUnknownMemberType]

        if not restart_required:
            logger.info("No restart required. Instance ready for use.")
            return

        logger.info("Restart required. Restarting Splunk...")

        try:
            self.splunk_api_service.restart(timeout=self.restart_timeout)
            # Give the API a few seconds to begin restart before polling
            # This avoids immediate connection refused errors on first attempt
            logger.debug("Waiting for Splunk API to stabilize after restart...")
            time.sleep(5)
            # Wait for API readiness
            self.wait_for_splunk_ready()
            logger.info("Splunk restarted successfully.")

        except TimeoutError as e:
            logger.error(
                f"Splunk restart timed out after {self.restart_timeout} seconds: {e}"
            )
            raise RuntimeError(
                f"Splunk failed to restart within {self.restart_timeout} second timeout period. "
                "Instance may be in inconsistent state."
            ) from e
        except ConnectionError as e:
            logger.error(f"Lost connection to Splunk during restart: {e}")
            raise RuntimeError(
                "Cannot reconnect to Splunk after restart attempt. "
                "Instance may require manual restart."
            ) from e
        except Exception as e:
            logger.error(f"Unexpected error during Splunk restart: {e}")
            raise RuntimeError(
                "Splunk restart failed. "
                "Instance may be in inconsistent state and require manual restart."
            ) from e

        # Verify restart cleared the restart_required flag (critical check)
        # NOTE: SDK's restart() already validates this internally, but we explicitly
        # check here for defensive programming and clearer logging/diagnostics
        # This happens outside try/except so it doesn't get caught and re-wrapped
        if self.splunk_api_service.restart_required:  # type: ignore[reportUnknownMemberType]
            logger.error("Restart completed but restart_required flag is still True")
            raise RuntimeError(
                "Splunk restart completed but restart_required flag did not clear. "
                "Instance is not ready for use. Manual investigation required."
            )

        logger.debug("Confirmed restart_required flag cleared after restart.")

    @retry(
        stop=stop_after_delay(180),
        wait=wait_fixed(5),
        retry=retry_if_exception_type((HTTPError, ConnectionError, TimeoutError)),
        before_sleep=before_sleep_log(logger, logging.DEBUG),
        reraise=True,
    )
    def wait_for_splunk_ready(self) -> None:
        """Wait for Splunk API to be ready after restart.

        Polls the Splunk API info endpoint until it responds, indicating
        the Splunk service has completed restart and is ready for operations.

        Retries every 5 seconds for up to 180 seconds on network-related errors.

        Raises:
            HTTPError: If Splunk API returns HTTP errors (500s, 503s) after retry exhaustion
            ConnectionError: If connection fails (ConnectionRefusedError, etc.) after retry exhaustion
            TimeoutError: If requests timeout after retry exhaustion

        Note:
            Web interface readiness (port 8000) is handled by splunk_web_session
            HTTP retry adapter, which provides 62 seconds of tolerance via
            exponential backoff (6 attempts: 0s, 2s, 6s, 14s, 30s, 62s).
            This method only verifies API readiness (port 8089).
        """
        info = self.splunk_api_service.info  # type: ignore[reportUnknownMemberType]
        logger.debug(f"Splunk API responded with info: {info}")
        logger.debug("Splunk API ready after restart")

    @cached_property
    def splunk_web_session(self) -> BaseUrlSession:
        """Connect to splunkweb and provide a requests session.

        Returns:
            BaseUrlSession: The requests session for splunkweb.
        """
        logger.debug("Configuring Splunkweb session...")

        restart_required = False
        try:
            max_upload_size = int(
                self.splunk_api_service.confs["web"]["settings"]["max_upload_size"]
            )
        except AttributeError:
            logger.info(
                "No max upload size has been explicitly set, assuming that it's the default 512 MB."
            )
            max_upload_size = 512
        if max_upload_size < self.MAX_UPLOAD_SIZE_MB:
            logger.info(
                f"Splunkweb max upload size is set to {max_upload_size} MB, which may be too small for some app uploads."
            )
            """Increases the max upload size of a splunk instance to self.MAX_UPLOAD_SIZE_MB."""
            max_upload_size = self.MAX_UPLOAD_SIZE_MB
            logger.info(
                f"Increasing max_upload_size in web.conf to {self.MAX_UPLOAD_SIZE_MB}MB..."
            )
            self.splunk_api_service.post(
                "properties/web/settings/max_upload_size", value=self.MAX_UPLOAD_SIZE_MB
            )
            restart_required = True
            logger.info(
                f"Increased max_upload_size to {self.MAX_UPLOAD_SIZE_MB}MB in web.conf, restart will be required for changes to take effect."
            )

        try:
            connection_timeout = int(
                self.splunk_api_service.confs["web"]["settings"][
                    "splunkdConnectionTimeout"
                ]
            )
        except AttributeError:
            logger.info(
                "No splunkd connection timeout has been explicitly set, assuming that it's the default 30 seconds."
            )
            connection_timeout = 30
        if connection_timeout < self.SPLUNKD_CONNECTION_TIMEOUT_SECONDS:
            logger.info(
                f"Splunkweb splunkd connection timeout is set to {connection_timeout} seconds, which may be too small for some app uploads."
            )
            logger.info(
                f"Increasing splunkd connection timeout to {self.SPLUNKD_CONNECTION_TIMEOUT_SECONDS} seconds..."
            )
            self.splunk_api_service.post(
                "properties/web/settings/splunkdConnectionTimeout",
                value=self.SPLUNKD_CONNECTION_TIMEOUT_SECONDS,
            )
            restart_required = True
            logger.info(
                f"Increased splunkd connection timeout to {self.SPLUNKD_CONNECTION_TIMEOUT_SECONDS} seconds in web.conf, restart will be required for changes to take effect."
            )

        self.restart_splunk_if_required(restart_required=restart_required)

        try:
            web_port = self.splunk_api_service.confs["web"]["settings"]["httpport"]
        except AttributeError:
            raise ValueError("Could not determine splunkweb port from API.")
        try:
            web_protocol = (
                "https"
                if self.splunk_api_service.confs["web"]["settings"][
                    "enableSplunkWebSSL"
                ]
                == "1"
                else "http"
            )
        except AttributeError:
            raise ValueError("Could not determine splunkweb protocol from API.")

        # Construct base URL once for reuse
        base_url = f"{web_protocol}://{self.splunk_host}:{web_port}"

        # Create BaseUrlSession
        session = BaseUrlSession(base_url=base_url)

        # Configure retry strategies
        # Strategy 1: Idempotent operations (safe to retry POST)
        idempotent_retry = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST"],
            raise_on_status=True,
        )
        idempotent_adapter = HTTPAdapter(max_retries=idempotent_retry)

        # Strategy 2: Conservative (GET/HEAD only for unknown endpoints)
        conservative_retry = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET"],
            raise_on_status=True,
        )
        conservative_adapter = HTTPAdapter(max_retries=conservative_retry)

        # Register idempotent POST endpoints (safe to retry)
        # These endpoints are explicitly idempotent or only called during initialization
        idempotent_post_endpoints = [
            "en-US/account/login",  # Session login (initialization only, safe to retry)
            "en-US/manager/appinstall/",  # App upload endpoints (force=1 makes idempotent)
        ]

        for endpoint in idempotent_post_endpoints:
            session.mount(f"{base_url}/{endpoint}", idempotent_adapter)

        # Default: conservative retry for all other paths (no POST retry)
        session.mount(f"{base_url}/", conservative_adapter)

        response = session.get("en-US/account/login")
        response.raise_for_status()

        soup = BeautifulSoup(response.content, "html.parser")
        partials_element = soup.find(id="splunkd-partials")
        if partials_element is None or partials_element.text is None:
            raise ValueError(
                "Could not login to the splunk web interface. Please check your connection details."
            )
        partials = json.loads(partials_element.text)
        cval = partials["/services/session"]["entry"][0]["content"]["cval"]

        response = session.post(
            "en-US/account/login",
            data={
                "cval": cval,
                "username": self.splunk_username,
                "password": self.splunk_password.get_secret_value(),
                "set_has_logged_in": False,
            },
        )
        response.raise_for_status()

        response = session.get("en-US/app/launcher/home")
        response.raise_for_status()

        logger.debug("Configured Splunkweb session.")
        return session

    @cached_property
    def splunk_hec_session(self) -> BaseUrlSession:
        """Connect to the Splunk HEC endpoint and provide a requests session.

        Returns:
            BaseUrlSession: The requests session for the Splunk HEC endpoint.
        """
        # use an instantiated splunklib service object
        service = self.splunk_api_service

        logger.info("Configuring HEC session...")
        logger.debug("Checking for existing testing index...")
        # get testing index or create if it doesn't exist
        # we only use it by name later, not Index() object
        contentctl_testing_index_name = "contentctl_testing_index"
        try:
            service.indexes[contentctl_testing_index_name]
            logger.debug("Found existing testing index.")
        except KeyError:
            logger.debug("Testing index not found, creating...")
            service.indexes.create(name=contentctl_testing_index_name)
            logger.debug("Created testing index.")

        # get hec details or create if it doesn't exist
        logger.debug("Checking for global HEC...")
        # need to do this icky workaround because accessing by key here breaks after installing es due to bug in splunklib, so we use get() and _load_list() instead
        try:
            global_hec = service.inputs._load_list(
                service.get("data/inputs/http/http")
            )[0]
        except Exception:
            raise Exception("Global HEC input not found, splunk is broken.")

        if global_hec.disabled == "1":
            logger.info("Global HEC input is disabled, enabling it...")
            service.inputs.post("http/http", disabled=0)
            logger.info("Enabled global HEC input.")

        hec_port = global_hec.port
        logger.debug("Found existing global HEC input.")
        hec_protocol = "https" if global_hec.enableSSL == "1" else "http"

        logger.debug("Checking for existing testing HEC input...")
        hec_token_name = "DETECTION_TESTING_HEC"
        try:
            detection_testing_input = service.inputs._load_list(
                service.get(f"data/inputs/http/{hec_token_name}")
            )[0]
            logger.debug("Found existing testing HEC input.")
        except HTTPError as e:
            if e.status == 404:
                logger.debug("Testing HEC input not found, creating...")
                indexes = service.indexes.list()
                index_names = [x.name for x in indexes]
                detection_testing_input = service.inputs.create(
                    name=hec_token_name,
                    kind="http",
                    index=contentctl_testing_index_name,
                    indexes=",".join(index_names),
                    useACK=True,
                )
                logger.debug("Created testing HEC input.")
            else:
                raise e

        # use hec token and port to configure hec session
        logger.debug("Checking HEC health...")
        session = BaseUrlSession(
            base_url=f"{hec_protocol}://{self.splunk_host}:{hec_port}/services/collector/"
        )
        session.verify = False
        session.headers.update(
            {"Authorization": f"Splunk {detection_testing_input['token']}"}
        )
        retries = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504],
        )
        session.mount("https://", HTTPAdapter(max_retries=retries))
        response = session.get("health")
        response.raise_for_status()

        logger.info("Configured HEC session.")
        return session


class SplunkbaseSettings(BaseSettings):
    """Settings pertaining to connecting to Splunkbase.

    Attributes:
        splunkbase_username (str): The username for Splunkbase.
        splunkbase_password (SecretStr): The password for Splunkbase.
    """

    model_config = SettingsConfigDict(populate_by_name=True)

    splunkbase_username: str = Field(
        description="Provide the username for Splunkbase. For inspect, this can be a low privilege account. For install, privileges should be enough for the apps you need.",
        alias="splunkbase-username",
    )
    splunkbase_password: SecretStr = Field(
        description="Provide the password for Splunkbase.", alias="splunkbase-password"
    )

    @cached_property
    def splunkbase_token(self) -> str:
        """Connect to splunkbase and obtain an auth token for use in splunkd's REST API app installation.

        Returns:
            str: The Splunkbase auth token.
        """
        logger.debug("Obtaining Splunkbase token...")
        response = requests.post(
            "https://splunkbase.splunk.com/api/account:login",
            data={
                "username": self.splunkbase_username,
                "password": self.splunkbase_password.get_secret_value(),
            },
        )
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "xml")
        splunkbase_id_element = soup.find("id")
        if splunkbase_id_element is None or splunkbase_id_element.text is None:
            raise ValueError(
                "Could not obtain Splunkbase token, check your credentials."
            )
        splunkbase_id = splunkbase_id_element.text
        logger.debug("Obtained Splunkbase token.")
        return splunkbase_id


# TODO: This is not implemented in the build/test code and exists here as a stub for future work
# class AttackDataSettings(BaseSettings):
#     """Settings pertaining to loading splunk attack data.
#
#     Attributes:
#         attack_data_dir (DirectoryPath): The path to the splunk attack data directory. Defaults to ../attack_data.
#
#     """
#
#     model_config = SettingsConfigDict(populate_by_name=True)
#
#     attack_data_dir: DirectoryPath = Field(
#         description="Provide the path to the splunk attack data directory. Defaults to ../attack_data.",
#         default=Path.cwd().parent / "attack_data",
#         alias="attack-data-dir",
#     )
