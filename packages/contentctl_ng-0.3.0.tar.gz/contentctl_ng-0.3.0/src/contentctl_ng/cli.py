"""CLI entrypoint for contentctl_ng, using pydantic_settings for argument parsing and validation."""

import logging
import sys

from pydantic import Field, ValidationError
from pydantic_settings import (
    BaseSettings,
    CliApp,
    CliImplicitFlag,
    CliSubCommand,
    SettingsConfigDict,
    SettingsError,
)

from contentctl_ng.build import Builder
from contentctl_ng.inspect_ import Inspector
from contentctl_ng.install import Installer
from contentctl_ng.release_notes import ReleaseNoteGenerator
from contentctl_ng.test import Tester

logger = logging.getLogger("contentctl_ng")
logger.propagate = False  # prevent contentctl from doubling contentctl_ng logs


class CliSettings(BaseSettings):
    """Shared settings and logic for the CLI subcommands.

    Attributes:
        verbose (CliImplicitFlag[bool]): Enable verbose logging by typing "--verbose". Defaults to false.

    """

    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", populate_by_name=True
    )

    def run(self) -> None:
        """Placeholder run method to be implemented by the other mixed-in class."""
        raise NotImplementedError("Subclasses must implement the run method.")

    verbose: CliImplicitFlag[bool] = Field(
        default=False, description="Enable verbose logging."
    )

    def cli_cmd(self) -> None:
        """cli_cmd is required by pydantic_settings to run a subcommand as a CLI. Configures logging and runs the command from its mixed object's run method."""
        if self.verbose:
            logger.setLevel(logging.DEBUG)
        self.run()


class InstallerCli(Installer, CliSettings):
    """Install content to a Splunk instance."""

    pass


class BuilderCli(Builder, CliSettings):
    """Build security content into a distributable format."""

    pass


class InspectorCli(Inspector, CliSettings):
    """Inspect differences between two versions of a content app."""

    pass


class TesterCli(Tester, CliSettings):
    """Run a test on your content."""

    pass


class ReleaseNoteGeneratorCli(ReleaseNoteGenerator, CliSettings):
    """Run a test on your content."""

    pass


class RootCli(
    BaseSettings, cli_parse_args=True, cli_exit_on_error=False, cli_avoid_json=True
):
    """Pick a subcommand."""

    install: CliSubCommand[InstallerCli] = Field(
        description="Install content to a Splunk instance."
    )
    build: CliSubCommand[BuilderCli] = Field(
        description="Build security content into a distributable format."
    )
    inspect: CliSubCommand[InspectorCli] = Field(
        description="Inspect differences between two versions of a content app."
    )
    test: CliSubCommand[TesterCli] = Field(description="Run a test on your content.")

    release_notes: CliSubCommand[ReleaseNoteGeneratorCli] = Field(
        description="Generate release notes by comparing two git references to show content which has changed.",
        alias="release-notes",
    )

    def cli_cmd(self) -> None:
        """cli_cmd with run_subcommand is required by pydantic_settings to run a subcommand as a CLI."""
        CliApp.run_subcommand(self)


def main() -> None:
    """Acts as main entrypoint for contentctl_ng CLI."""
    # configure logger with default level INFO (normal logging, not verbose)
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s %(name)s: %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    # obtain settings using pydantic_settings
    # if error, print all var names/descriptions & exit
    try:
        CliApp.run(RootCli)
    except SettingsError as e:
        if "error parsing CLI: unrecognized argument" in str(e):
            logger.error(e)
        elif "Error: CLI subcommand is required" in str(e) or "invalid choice" in str(
            e
        ):
            logger.error("Pick a subcommand:")
            for key, value in RootCli.model_fields.items():
                logger.error(f"{key}: {value.description}")
        else:
            logger.error(str(e))
        sys.exit(1)
    except ValidationError as e:
        logger.error("Errors found:")
        for error in e.errors():
            logger.error(
                f"{'.'.join([str(x) for x in error['loc'] if not str(x).startswith('function-after[')])}: {error['msg']}"
            )
        sys.exit(1)
    except Exception as e:
        logger.error(f"Encountered an error while running: {e}")
        sys.exit(1)
