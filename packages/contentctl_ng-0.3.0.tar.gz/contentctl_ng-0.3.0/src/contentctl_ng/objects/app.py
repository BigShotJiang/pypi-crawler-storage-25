"""This module contains the App class, which represents an application that can be configured with a conf file."""

from datetime import datetime
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    DirectoryPath,
    Field,
    FilePath,
    PrivateAttr,
    computed_field,
)

from contentctl_ng.utilities import common_io
from contentctl_ng.version import PydanticVersion


class ExternalAppContent(BaseModel):
    """Defines content which is used in your app but is defined in another app.

    This is used to enable your custom app to use macros and lookups defined in
    other apps without needing to redefine them in your custom app to pass validation.
    These apps are NOT parsed to ensure the content you SAY exists in them actually
    exists.
    Make sure that these definitions are correct!


    The object is intentionally prescriptive and only macros and lookups are supported.
    If additional types of external content must be referenced,
    the contentctl-ng team will need to add support for it.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    app_name: str = Field(
        description="The name of the app. This should map to a real app, but "
        "this value is not validated, so it is for documentation purposes only."
    )

    # TODO: While it it a significant amount of work, parsing
    # Macro and Lookup defintions directly from the list of app dependencies,
    # for instance parsing macros.conf/collections.conf from the Enterprise Security App,
    # would be the most conclusive way to do this.
    # For now, these are simply static annotations.
    macros: frozenset[str] = Field(
        default_factory=frozenset,
        description="The names of any macros you want to "
        "be able to use which are defined in this app. Note that macros are intentionally typed as frozenset[str] for the following reasons:\n"
        "1. frozenset - the list of externally defined macros should NOT be mutable at runtime."
        "2. str (instead of Macro): typing these as Macro would require knowledge of the "
        "contents/fields of the macro. Defining these  as full Macros significantly expands "
        "the size of the file AND requires the user to keep these defintions up to date.",
    )
    lookups: frozenset[str] = Field(
        default_factory=frozenset,
        description="The names of any lookups you want to "
        "be able to use which are defined in this app. Note that lookups are intentionally typed as frozenset[str] for the following reasons:\n"
        "1. frozenset - the list of externally defined lookups should NOT be mutable at runtime."
        "2. str (instead of Lookup): typing these as Lookup would require knowledge of the "
        "contents/fields of the lookup. Defining these as full Lookups significantly expands "
        "the size of the file AND requires the user to keep these defintions up to date.",
    )

    def check_if_content_is_defined(
        self,
        content_name: str,
        # TODO: Convert Consider conversion of Literal to StrEnum
        content_type: Literal["macro", "lookup"],
    ) -> bool:
        """Check if the content is defined in this app.

        Args:
            content_name (str): The name of the content to check.
            content_type (Literal["macro", "lookup"]): The type of content to check.

        Returns:
            bool: True if the content is defined in this app, False otherwise.
        """
        if content_type == "macro":
            return content_name in self.macros
        elif content_type == "lookup":
            return content_name in self.lookups
        else:
            # This code block should nver be reached, but keeping it for future proofing
            raise ValueError(f"Invalid Externally Defined Content type: {content_type}")


class CustomAppSettings(BaseModel):
    """Represents a custom app file.

    At this time, these settings are loaded from a
    build.yml file.

    TODO: Consider converting this to use PydanticSettings
    This content is far more in line with "settings" than "content"
    and represents cleaner architecture, also enabling us to pass
    some changes via ENV or Command Line (if we so desire).
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    author: str = Field(description="The name of the author of the application.")
    author_email: str = Field(
        description="The email address of the author of the application. "
    )

    id: str = Field(
        description="The id of the app. It cannot contain spaces or special characters.",
        pattern=r"^[a-zA-Z0-9_-]+$",
    )

    content_prefix: str = Field(
        description="The prefix to use for searches in this app. "
        "For instance, if this is ESCU - , a number of pieces of "
        "content such as savedsearch will we written to stanzas "
        "in the format 'ESCU - Search Name Here - Rule'"
    )

    label: str = Field(
        description="The label of the app. This is used to identify the app in the Splunk User Interface to the user."
    )

    description: str = Field(description="A description of the app.")

    app_version: PydanticVersion = Field(description="The version of the app.")

    external_app_content: list[ExternalAppContent] = Field(
        description="A list of external object definitions for this app. "
        "This enables your custom app to use macros and lookups defined in "
        "other apps without needing to redefine them in your custom "
        "app to pass validation.",
        default_factory=list,
    )

    # Set at runtime, this is the time that the app was actually built.
    # This is important as it will be used later as a field when constructing
    # the app.conf file as well as comments on autogenerated conf files.
    _build_time: datetime = PrivateAttr(default_factory=datetime.now)

    @computed_field
    @property
    def build(self) -> int:
        """Build time of the app in YYYYMMDDHHMMSS format.

        Note: This is intentionally called build, and not build_time,
        because the key that it populates in the app.conf install
        stanza has the name "build".
        """
        return int(self._build_time.strftime("%Y%m%d%H%M%S"))

    def __eq__(self, other: CustomAppSettings | Any) -> bool:
        """Check if two CustomAppFile objects are equal.

        Args:
            other (CustomAppFile | Any): The other CustomAppFile (or any other object) to compare to.

        Raises:
            ValueError: If the other object is not a CustomAppFile.

        Returns:
            bool: True if the two objects are equal, False otherwise.
        """
        if not isinstance(other, CustomAppSettings):
            raise ValueError(
                "Cannot compare CustomAppFile to non-CustomAppFile object."
            )
        return (
            self.author == other.author
            and self.author_email == other.author_email
            and self.label == other.label
            and self.id == other.id
            and self.app_version == other.app_version
            and self.external_app_content == other.external_app_content
        )

    # TODO: Convert literal to enum since it is used in multiple places
    def check_if_content_is_defined_in_external_app(
        self,
        content_name: str,
        # TODO: Convert Consider conversion of Literal to StrEnum
        content_type: Literal["macro", "lookup"],
    ) -> bool:
        """Check if the content is defined in an external app.

        This function is used when validating the Lookups and Macros
        used in an SPLString. If we fail to find the definition of
        a Macro or Lookup in the Content Repo itself, we fall back
        to checking if it is defined in an external app.

        Args:
            content_name (str): The name of the content to check.
            content_type (Literal["macro", "lookup"]): The type of content to check.

        Returns:
            bool: True if the content is defined in an external app, False otherwise.
        """
        for external_app in self.external_app_content:
            if external_app.check_if_content_is_defined(content_name, content_type):
                return True
        return False


class ContentDirectory(BaseModel):
    """Represents a content directory within an app.

    We want an app which we build to be able to made up of
    one or more different directories.

    Multiple directories allow us to support building an
    app from multiple sources, such as the security_content
    GITHUB and security_content GITLAB repositories.  This allows
    us to do a build without heavy-handed or custom logic that combines
    two repositories in separate tooling - contentctl-ng is able to simply
    parse these two directories and build the app from them directly.
    It also handles things like deconfliction/deduplication and reporting
    error when there are conflicts.

    In the future, each of these directories may have their own, unique build.yml,
    but that flexibility is INTENTIONALLY not exposed or supported yet.

    """

    app_settings: CustomAppSettings = Field(
        description="The app settings, read from a build.yml for this directory."
    )

    path: DirectoryPath = Field(
        description="The root path of the content directory. "
        "For instance, this could be ./security_content_github or ./security_content_gitlab "
        "or a different directory."
    )


# TODO: The naming of AppRoot has a number of issues:
# 1. If this is intended to be the parent of all content directions,
# then that MUST be clear and we must enforce that all content
# directories occur under/are relative to this directory.
# 2. This doesn't have a _path field, itself.
# 3. Given the comments above, we should reconsider the name and purpose of this class.
class AppRoot(BaseModel):
    """Represents the root of an app that is built with contentctl.

    Each app is to be composed of one or more directories.
    However, only a single configuration file is allowed. This allows
    for building an app from both the security_content GITHUB and
    security_content GITLAB repositories without needing extra code
    to combine them and resolve conflicts if the same content/changes
    exist in both.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    build_dot_yml_path: FilePath = Field(
        description="The path to the build.yml file. "
        "At this time, this is intentionally passed in as a "
        "parameter rather than a constructed object to make this class easier to instantiate. "
        "We also allow multiple directions to be passed in but a single config_file "
        "to enforce that each directory is built with the same build.yml file."
    )

    schemas_directory: DirectoryPath = Field(
        description="The path to the schemas directory. The schemas/ directory will contain"
        "unified schemas built from all directories passed to AppRoot. The previous contents "
        "of the schemas directory will be overwritten with the latest schemas upon a successful "
        "run of contentctl-ng. ",
    )

    # TODO: Verify that the ordering of directories is still important after the
    # introduction of deferred content errors in the object_parser.py code.
    # If the ordering is no longer important, then update the comment to reflect this.
    # TODO: If these directories are supposed to be children of an AppRoot directory,
    # then we must enforce that they are.
    # TODO: We should more formally track the dependencies between different repos.
    # for instance, the security_content_gitlab repo REQUIRES the security_content_github
    # repo for a successful build.  This should be more formally tracked and enforced.
    # For instance, build.yml could specify the repo(s)  (and hashes?)
    # required to build the app it describes.
    directories: list[DirectoryPath] = Field(
        description="Directories containing app content. The order of these "
        "directories is important, so if directoryB contains content "
        "that relies on directoryA, then this should be: "
        "['directoryA', 'directoryB']. At least one directory must be provided.",
        min_length=1,
    )

    # _app_settings to be loaded from the config_file that was passed in
    # These settings are to be shared among all content_directories.
    # At this time, unique settings for different directories are, intentionally,
    # not supported. This must not be accessed directly, as it is intended
    # to be used for constructing the list of all app directories.
    # This is a private attribute (prefixed with _) because we
    # require it to be set dynamically by model_post_init and NOT
    # be passed in to the constructor.
    # In pydantic, using PrivateAttr() and NOT prefixing the name
    # of the variable with an _ causes an exception.
    _shared_app_settings: CustomAppSettings = PrivateAttr()

    # _content_directories are created from the CustomAppSettings and the
    # list of directories that were passed in. This is constructed at runtime
    # as separate objects as a method of enforcing the all ContentDirectory
    # use the same build.yml file.
    # We construct this as a PrivateAttr to EXPLICITLY prevent a content_directory
    # from being passed in with a different build.yml file (different _app_settings).
    # TODO: Determine if a single app should ever be allowed to be built from multiple
    # build.yml files which seems unlikely.
    _content_directories: list[ContentDirectory] = PrivateAttr(default_factory=list)

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context: None = None) -> None:
        """Initialize handles to the directories that make up this app and loads the app.yml file.

        Args:
            __context (None, optional): This is the default signature
            for model_post_init, but context SHOULD NOT be used in this
            function. Defaults to None.

        Raises:
            ValueError: If the app.yml file cannot be loaded or is invalid.

        Returns:
            None - Function makes some changes to the object
        """
        # Load the settings from the app.yml file and validate them.
        # TODO: Instead of treating this like a "content" file, we should
        # probably use PydanticSettings to treat this like a settings file.
        # This also allows certain values to be overridden via ENV or CLI
        # variables. It also prevents us having a more manual loading process
        # like we see here.

        try:
            shared_app_settings = common_io.load_yml_file_to_dict(
                self.build_dot_yml_path
            )

            self._shared_app_settings = CustomAppSettings.model_validate(
                shared_app_settings
            )

        except Exception as e:
            raise ValueError(f"Failed to load {self.build_dot_yml_path} file: {e}")

        for directory in self.directories:
            # Today, apps are always built with the same app_settings file.
            # However, since an app is built from 1 or more app directories,
            # it may be possible in the future to build a combined app from very
            # disparate sources, for example an app that combines UEBA and ESCU content
            # into one content package which reference each other!

            # Construct the individual content directories, which are the combination
            # of Shared App Settings and the path of the directory

            content_dir = ContentDirectory(
                app_settings=self._shared_app_settings, path=directory
            )
            self._content_directories.append(content_dir)
