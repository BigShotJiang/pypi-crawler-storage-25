"""This module contains information for parsing Security Content Objects."""

import logging
from typing import Any, Sequence

from pydantic import ValidationError, computed_field
from yaml import YAMLError

from contentctl_ng.objects.app import AppRoot
from contentctl_ng.objects.atomic_guid import AtomicRedTeamIndex
from contentctl_ng.objects.content import (
    AllContentEnum,
    DeprecationInfo,
    RemovedContent,
    SecurityContent,
)
from contentctl_ng.objects.dashboard import Dashboard
from contentctl_ng.objects.data_source import DataSource
from contentctl_ng.objects.lookup import CSVLookup, KVStoreLookup
from contentctl_ng.objects.macro import FilebackedMacro, Macro, MacroEnum
from contentctl_ng.objects.mitre_enrichment import MitreEnterpriseAttackInfo
from contentctl_ng.objects.playbook import Playbook
from contentctl_ng.objects.schedule import FilebackedSchedule
from contentctl_ng.objects.searches.baseline import Baseline
from contentctl_ng.objects.searches.detection import EventBasedDetection
from contentctl_ng.objects.story import Story
from contentctl_ng.objects.validated_strings import SplString
from contentctl_ng.utilities import common_io

logger = logging.getLogger(__name__)


class AppFactory:
    """Construct a factory that can parse all content in one or more repo directories.

    This means that we can actually combine multiple repos into a single apps, which
    simplifies for example merging both a public and a private repo together to build
    a single app. Because the tooling can do this, it means that the merging does not
    need to happen externally in a CI/CD workflow.
    This also support dependencies between repos, so that a detection in Repo A
    can leverage a macro in Repo B, for example.
    """

    def __init__(self, app: AppRoot, validation_fast_fail: bool = True):
        """Parse all content in the repo into objects.

        This also performs enrichment, for instance fetching
        Atomic Red Tema and Mitre Repo Info.

        Args:
            app (App): The app to parse.
            validation_fast_fail (bool, optional):  Causes the validation to stop
             and return an Exception as soon as the first validation
             exception is encounted. Defaults to True.

        Raises:
            ValueError: Generates an exception if no repo paths are provided.
        """
        MitreEnterpriseAttackInfo.parse_mitre_enterprise_info_url_to_enum()
        AtomicRedTeamIndex.parse_art_url_to_enum()

        self.app = app
        self.validation_fast_fail = validation_fast_fail

        # Pase each type of content.
        self.schedules: list[FilebackedSchedule] = self.parse_content_of_specific_model(
            FilebackedSchedule
        )
        self.csv_lookups: list[CSVLookup] = self.parse_content_of_specific_model(
            CSVLookup
        )
        self.kvstore_lookups: list[KVStoreLookup] = (
            self.parse_content_of_specific_model(KVStoreLookup)
        )

        # The typing for this field is actually Macro,
        # which is a PARENT class of FilebackedMacro, because this property will also contain
        # _filter macros. As these are declared at runtime, they do not have fields
        # like immutable UUID. As such, we have to be aware of typing so that no errors
        # are thrown during serialization.
        # Until such time as all objects are tracked as SecurityContent Ojects and
        # backed by files, we will need to treat them like this.
        self.macros: list[Macro] = self.parse_content_of_specific_model(FilebackedMacro)

        # Now that macros and lookups are parsed, we must validate that
        # all macros are valid SPL strings based on their potential
        # usage of macros or lookups
        # These types of issues are likely rare, but still something
        # we should catch!
        # This is a pretty rare error case - so the handling is not
        # as elegant as the the normal content parsing code.
        try:
            # None of these macros are allowed to reference _filter macros.
            # This is intentional.
            # Filter macros have not been created until detections are parsed later
            # on in this function. This is an intentional limitation.
            for macro in self.macros:
                macro_spl = SplString(macro.definition)
                # These calls are made to validate that the macro is valid SPL
                # based on its potential usage of macros or lookups.
                macro_spl.extract_lookups(self.app._shared_app_settings)
                macro_spl.extract_macros(self.app._shared_app_settings, False)
        except Exception as e:
            # TODO: Implement Exception-type specific error handling, where appropriate, for specific exceptions
            # we feel to be likely.  Instead of trying to capture generic exceptions, let them fall back to
            # the highest level error handler (such as at the CLI level).

            raise ValueError(
                f"Error validating macro [{macro.name}]:\n"
                f" definition: [{macro.definition}]\n      error: {e!s}"
            )

        self.stories: list[Story] = self.parse_content_of_specific_model(Story)
        self.dashboards: list[Dashboard] = self.parse_content_of_specific_model(
            Dashboard
        )
        self.data_sources: list[DataSource] = self.parse_content_of_specific_model(
            DataSource
        )
        self.baselines: list[Baseline] = self.parse_content_of_specific_model(Baseline)
        self.detections: list[EventBasedDetection] = (
            self.parse_content_of_specific_model(EventBasedDetection)
        )

        self.playbooks: list[Playbook] = self.parse_content_of_specific_model(Playbook)
        # Because creating detections has created _filter macros and written
        # then into the MacroEnum, we now need to pull those out.
        # This is clunky, but can't think of a better way to do it.
        # TODO: Find a better way to update the list of all macros.
        self.macros = [macro.obj for macro in MacroEnum]

        self.removed_content: list[RemovedContent] = (
            self.parse_content_of_specific_model(RemovedContent)
        )

        # Enum Creation, which is called during the content_parsing process,
        # forces unique names for pieces of the "same" type of content.
        # Right now, we explicitly allow different types of content (like macros and lookups)
        # to have the same name
        self.ensure_no_duplicate_ids_or_names(enforce_names=False)

    def parse_content_of_specific_model(
        self, model: SecurityContent
    ) -> list[SecurityContent]:
        """Parse all content of a single type, for instance Stories, and update associated Enums.

        Note that because some pieces of content may reference each other, such as Detections
        referencing other deprecated detections, we may need to iteratively try to rebuild
        the content model and resolve linkages.

        Args:
            model (SecurityContent): The SecurityContent Object type we are trying to parse

        Raises:
            ExceptionGroup: If we encounter any issues while parsing the content

        Returns:
            list[SecurityContent]: The fully parsed content objects
        """
        # Get all content files, from all directories that make up this app.
        content_to_parse = self.get_content_files(model)
        errors: list[Exception] = []
        validated_content: list[SecurityContent] = []

        while len(content_to_parse) > 0:
            deferred_validations: list[
                tuple[dict[str, Any], dict[str, Any], Exception]
            ] = []
            model.model_rebuild(force=True)
            new_content: list[SecurityContent] = []
            SUCCESSFULLY_PARSED_AT_LEAST_ONE = False
            for yml_dict, context in content_to_parse:
                try:
                    o = model.model_validate(yml_dict, context=context)
                    new_content.append(o)
                    SUCCESSFULLY_PARSED_AT_LEAST_ONE = True
                except YAMLError as e:
                    e.add_note(f"{context['_path']}")
                    errors.append(e)
                except ValidationError as e:
                    # Check if this could be due to an undefined Enum
                    # These deffered errors always have a ValidationError
                    # with type 'enum'
                    e.add_note(f"{context['_path']}")
                    deferred_error = True
                    for error in e.errors():
                        if error["type"] != "enum":
                            # Only enum-related errors can be deferred. If there is
                            # another errors associated with this content, it
                            # cannot be deferred.
                            deferred_error = False
                    if deferred_error:
                        # This error can be deferred, so we will try to parse the
                        # content again in another iteration after updating
                        # the object and enum(s)
                        deferred_validations.append((yml_dict, context, e))
                    else:
                        errors.append(e)

                    # Keep track of the object, the context to construct it, and
                    # the error that was generated. We may need to try to rebuild
                    # the content model and try building again.

                except Exception as e:
                    # general catch-all exception
                    e.add_note(f"{context['_path']}")
                    errors.append(e)
                if self.validation_fast_fail and len(errors) > 0:
                    # Intentionally only return errors here. Do not consider
                    # deferred validations to be errors.
                    # Do not try to parse any more content. This is
                    # sufficient to break us out of the loop
                    content_to_parse = []

            if not SUCCESSFULLY_PARSED_AT_LEAST_ONE:
                # Tried to iteratively parse content, but performed an entire
                # pass without successfully validating anything. We must quit
                # and return validation errors for content that could not be parsed.
                errors.extend([e[2] for e in deferred_validations])

            # If there are any errors after a pass, raise them
            # (even if validation_fast_fail is set to False)
            if len(errors):
                raise ExceptionGroup(
                    f"A number of exceptions occurred while parsing file(s) for {model.__name__} "
                    f"with extension {model._content_file_suffix}: ",
                    errors,
                )

            AllContentEnum.__update_everything_dangerous__(AllContentEnum, new_content)
            DeprecationInfo.model_rebuild(force=True)
            model.update_dynamic_status(new_content)
            validated_content += new_content
            content_to_parse = [(c[0], c[1]) for c in deferred_validations]

        # Write out completed schemas as a results of parsing
        schema_file_name = self.app.schemas_directory / f"{model.__name__}.schema.json"
        common_io.write_dict_to_json(
            schema_file_name,
            model.model_json_schema(),
            create_parent_directory=True,
        )

        logger.info(
            f"Parsed [{len(validated_content):>4} {model.__name__:>20} ] objects"
        )
        return validated_content

    def get_content_files(
        self, model: SecurityContent
    ) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        """Get all content files for a given model type.

        This will just be the associated YML files which we will need to parse.
        This will not return SupportingFiles, such as json files for Dashboards
        or CSV files for CSVLookup, as those are resolved at SecurityContent Object
        parsing time.

        Args:
            model (SecurityContent): The SecurityContent Object type we are trying to parse

        Returns:
            list[tuple[dict[str, Any], dict[str, Any]]]: A list of tuples containing the
            dictionary data and context for each file. Note that the context will contain
            the path to the file and the app settings for the app.

        """
        # get all of the content files that live in the given directory/directories
        all_content_files: list[tuple[dict[str, Any], dict[str, Any]]] = []

        # TODO: Should we have a layer of abstraction the defines something like
        # DashboardDirectory, DetectionDirectory, LookupDirectory, etc which contains
        # much of this relevant information as opposed to making it properties that
        # are part of the Content Classes?
        for directory in self.app._content_directories:
            file_paths = common_io.get_all_files_by_suffix(
                model._content_file_suffix,
                directory.path / model.content_folder(),
                other_allowed_suffixes=model._other_allowed_file_suffixes,
            )
            for file_path in file_paths:
                dict_data = common_io.load_yml_file_to_dict(file_path)
                context = {
                    "_path": file_path,
                    "_content_dir": directory,
                }

                all_content_files.append((dict_data, context))

        return all_content_files

    @computed_field
    @property
    # TODO: fix typing since not everything in this derives from SecurityContent
    # Most notable, macros are typed as Macro, not FilebackMacros, due to the
    # existence of _filter macros created at runtime which do not have
    # fields like id and _path and version.  So Macros are not SecurityContent
    # objects, but FilebackedMacros (which inherit from Macro) are.
    def all_content(self) -> Sequence[SecurityContent | Macro]:
        """Get all content from the app.

        This is useful if, for some reason, you need a list of all
        the content rather than just a single type of content.
        This does NOT include removed content. If you need that
        content as well, please use property all_content_with_removed.
        Please note that Playbooks are INTENTIONALLY EXCLUDED
        from this list.  Playbooks are not objects present in a
        Splunk App and are included in contentctl-ng for legacy reasons.

        Returns:
            Sequence[SecurityContent | Macro]: All content from the app.
        """
        return (
            self.macros
            + self.csv_lookups
            + self.kvstore_lookups
            + self.stories
            + self.dashboards
            + self.data_sources
            + self.baselines
            + self.detections
        )

    @property
    def all_content_including_removed(self) -> Sequence[SecurityContent | Macro]:
        """Get all content from the app, including removed content.

        Returns:
            Sequence[SecurityContent | Macro]: All content from the app.
        """
        return list(self.all_content) + self.removed_content

    def ensure_no_duplicate_ids_or_names(self, enforce_names: bool = False):
        """Ensure that no two objects have the same id or name.

        By default, we DO NOT enforce uniqueness here for names. This is because
        we currently allow duplicate names for DIFFERENT types of content.
        For example, it is allowed for a Macro and Lookup to have the
        same name as they are different types of content.

        The construction of the Enums already prevents objects of the same type
        from having the same name - for example we cannot have 2 Macros
        with the same name nor 2 Detections with the same name.

        However, we cannot allow content with duplicate uuids/ids to
        exist. These MUST be unique.


        Note that there are a number of intentional weird workarounds
        to support content that is lacking a _path or id because it
        is generated at runtime, such as Macros  which are not
        FilebackedMacros (_filter macros) or Schedules which are not
        FilebackedSchedules (defined in individual detections).

        Raises:
            ValueError: If any two objects have the same id or name.
        """
        # Because inline objects, such as  _filter Macros do not have
        # id, we will exclude them from this list.
        all_security_content_objects = [
            o
            for o in self.all_content_including_removed
            if isinstance(o, SecurityContent)
        ]

        # Only SecurityContentObjects have ids
        content_ids = [o.id for o in all_security_content_objects]

        # All objects have names
        content_names = [o.name.lower() for o in self.all_content_including_removed]

        # Handle some edge cases for both of these types since
        # not everything in the enum may have a path or id -
        # most notable Macros and Schedules that are not
        # FilebackedMacros or FilebackedSchedules.
        if len(content_ids) != len(set(content_ids)):
            duplicate_id_errors: list[str] = []
            for content_id in set(content_ids):
                if content_ids.count(content_id) > 1:
                    formatted_names = "\n - ".join(
                        [
                            str(o._path)
                            if hasattr(o, "_path")
                            else o.name + " (Inline)"
                            for o in all_security_content_objects
                            if hasattr(o, "id") and o.id == content_id
                        ]
                    )
                    duplicate_id_errors.append(
                        f"UUID: [{content_id}]:\n - {formatted_names}"
                    )

            joined_errors = "\n".join(duplicate_id_errors)
            raise Exception(
                "The following pieces of content share the same UUIDs. "
                f"Content MUST have unique UUIDs:\n{joined_errors}"
            )
        # Again, handle some edge cases for content missing path or id
        if (len(content_names) != len(set(content_names))) and enforce_names:
            duplicate_name_errors: list[str] = []
            for content_name in content_names:
                if content_names.count(content_name.lower()) > 1:
                    formatted_names = "\n - ".join(
                        [
                            str(o._path)
                            if isinstance(o, SecurityContent)
                            else o.name + " (Inline)"
                            for o in self.all_content_including_removed
                            if o.name.lower() == content_name
                        ]
                    )
                    duplicate_name_errors.append(
                        f"Name: [{content_name.lower()}]:\n - {formatted_names}"
                    )

            joined_errors = "\n".join(duplicate_name_errors)
            logger.error(
                "The following pieces of content share the same names. "
                "Content MUST have unique names. Note that a difference in "
                f"capitalization alone does NOT make a name unique:\n{joined_errors}"
            )
