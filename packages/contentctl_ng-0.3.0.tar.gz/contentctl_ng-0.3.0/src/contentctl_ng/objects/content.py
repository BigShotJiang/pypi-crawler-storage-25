"""High level abstract definition for any Security Content Object.

All other Security Content Objects such as Macros, Lookups, Detections,
Stories, Dashboards, etc. inherit from this class.
"""

import abc
import datetime
from collections.abc import Sequence
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Any, ClassVar, Literal, Self
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FilePath,
    PrivateAttr,
    computed_field,
    field_validator,
    model_validator,
)
from pydantic.networks import HttpUrl
from pydantic.types import PositiveInt

from contentctl_ng.objects.app import ContentDirectory
from contentctl_ng.utilities import common_io
from contentctl_ng.version import PydanticVersion

# CVE_TYPE is used by multiple tpyes of content - at the very least
# EventBasedDetection and Story, so it is defined here
CVE_TYPE = Annotated[str, Field(pattern=r"^CVE-\d{4}-\d{4,7}$")]


class ContentEnum(StrEnum):
    """Generic Enum for Security Content.

    This should NEVER be populated directly. Instead, it should be
    updated by calling the __update_everything_dangerous__ method.
    We use an unconventional method for creating enums at runtime,
    which may be revised in the future. This method may be improved
    in the future.

    TODO: Can we make this more specific, for example with Type[T] or
    similar, so that the type of the obj field is correct for each
    specific SecurityContentUpdate?  Or can we move more common
    definitions into this class and out of individual Security Content
    objects?
    """

    # Declaring the additional attributes here keeps mypy happy.
    obj: SecurityContent

    @classmethod
    def enum_set_to_names_set(cls, objs: frozenset[ContentEnum]) -> frozenset[str]:
        """Return a set of the names of the enum members."""
        return frozenset([obj.name for obj in objs])

    def __new__(cls, my_obj: SecurityContent) -> ContentEnum:
        """Create a new ContentEnum object.

        This should NEVER be called directly and is instead called
        automatically when a new ContentEnum object is created.
        For example:

        ContentEnum("EnumName", [(o.name, o) for o in objects])

        Args:
            my_obj (SecurityContent): The object that will be added to the enum.

        Returns:
            ContentEnum: The enum object that was added
        """
        obj = str.__new__(cls, my_obj.name)
        obj._value_ = my_obj.name
        obj.obj = my_obj
        return obj

    def __update_everything_dangerous__(self, my_objs: list[SecurityContent]) -> None:
        """Update an existing enum in-place, overwriting all existing values.

        WARNING - this is a potentially dangerous method because in Python,
        Enums are immutable.  However, this is a reasonable way to Dyanamically
        update the Enums which are used for defining, for example, the valid
        Stories, Macros, DataSources, etc that a Detection can reference.
        It also allows us to use the enum to generate a dynamic JsonSchema.
        So, it is largely a necessary evil.

        TODO: Is there a nicer way to do this? It seems to work, but it
        quite messy.
        Link: https://myuan.fun/dynamic-enum-with-fastapi/

        Args:
            my_objs (list[SecurityContent]): The list of objects to construct a new enum from.
            Note that
        """
        # Try to catch if there is a duplicate early on rather than later when
        # updating the enum. It may be a duplicate in the new items themselves, or
        # a new item that is already in the old items.

        obj_names = [obj.name for obj in my_objs + list(self)]
        duplicates = list(
            filter(lambda my_obj: obj_names.count(my_obj.name) > 1, my_objs)
        )
        if duplicates:
            duplicate_tuples = sorted(
                [
                    (d.name, getattr(d, "_path", "Defined at runtime"))
                    for d in duplicates
                ],
                key=lambda x: x[0],
            )
            joined_dups = "\n- ".join(f"{d[0]} - {d[1]}" for d in duplicate_tuples)
            raise ValueError(
                f"Trying to create multiple objects of type {type(my_objs[0]).__name__} with the name(s):\n- {joined_dups}"
            )

        # if we are only adding one object to the enum, we can just add it
        # and be done with it. When adding one object at a time, such as
        # we do with filter macros, it is REALLY slow to recreate the entire
        # enum each time.
        if len(my_objs) == 1:
            # it is a very common use care to add one object to the enum
            # if that is the case, instead of regenerating the entire enum, which
            # is quite expensive, we can just add the object to the enum
            # and be done with it.
            # For instance, this is a common use case when we are adding
            # a filter macro to a search.
            my_obj = my_objs[0]

            newEnum = ContentEnum("tempEnum", [(my_obj.name, my_obj)])
            self._member_map_.update(newEnum._member_map_)
            self._member_names_.extend(newEnum._member_names_)
            self._value2member_map_.update(newEnum._value2member_map_)

            return

        # Grab all of the old content as well. Otherwise, we will
        # wind up overwriting it which is bad! This is an issue
        # when a single high level type of content, like Lookup
        # (which can be both a CSVLookup or a KVStoreLookup),
        # is constructed by two different factories.
        old_content = [(oc.obj.name, oc.obj) for oc in self]
        new_content = [(o.name, o) for o in my_objs]
        all_content = old_content + new_content
        # Make sure that the enum is sorted by name for
        # the sake of readability
        all_content.sort(key=lambda x: x[0])

        # Now update the enum using a combination of both the old and new content
        newEnum = ContentEnum("tempEnum", all_content)

        self._member_map_ = newEnum._member_map_
        self._member_names_ = newEnum._member_names_
        self._value2member_map_ = newEnum._value2member_map_


class AllContentEnum(ContentEnum):
    """Enum for Security Content that is used in production.

    NOTE: This enum is dynamically populated at runtime.
    """

    pass


class DeprecationInfo(BaseModel):
    """Information required for the deprecation and removal of a Security Content Object."""

    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    reason: str = Field(description="The reason this content is scheduled for removal")
    removed_in_version: PydanticVersion = Field(
        description="The version in which this content will be removed. "
        "That means it should be present in older versions, but no longer "
        "present starting with this version. If it is still present in this "
        "version of the app, a validation error will be generated at build time."
    )
    replacement_content: frozenset[AllContentEnum] = Field(
        description="Any appropriate content that may replace this piece of content.",
        default_factory=frozenset,
    )


class SupportingFile(BaseModel):
    """A supporting file for a Security Content Object.

    For instance:
    - Dashboard objects require a JSON file to define the dashboard itself.
    - CSVLookup objects require a CSV file to define the lookup itself.

    The naming of the supporting file is intentionally VERY strict.
    Only the suffix of the file may be defined. For instance, if the
    name of the content file is "my_dashboard.yml", then the path
    must be "my_dashboard.json" (and located in the exact same
    directory as the content file).
    """

    input_path: FilePath = Field(
        description="The path to the supporting file in the source directory"
    )

    output_path: Path = Field(
        description="The path to the supporting file in the build directory. "
        "This is relative to the app root, so if a lookup should go into "
        "DA-ESS-ContentUpdate/lookups/my_lookup20250101.csv, then this should be "
        "'lookups/my_lookup20250101.csv'"
    )

    # The file extension for all of the supporting objects of this type
    # This must be defined so we know what files to parse!
    _content_file_suffix: ClassVar[str]

    @computed_field
    @property
    def content(self) -> str:
        """Return the content of the supporting file.

        This may be overridden by subclasses to provide additional
        functionality or do additional transforms or wrap additional
        information about this contnet
        """
        return self.input_path.read_text()

    def write_to_file(self, output_root: Path) -> None:
        """Write the supporting file to the output root directory."""
        full_output_path = output_root / self.output_path
        if not full_output_path.parent.is_dir():
            if full_output_path.parent.exists():
                raise FileExistsError(
                    f"The path {full_output_path.parent} exists, but is not a directory. "
                    f"Cannot write out supporting file {self.input_path} to {full_output_path}."
                )
            full_output_path.parent.mkdir(parents=True, exist_ok=True)

        if full_output_path.exists():
            raise FileExistsError(
                f"The path {full_output_path} exists, so we cannot serialize the file "
                f"{self.input_path} to {full_output_path}. There should be no collisions between supporting files."
            )
        full_output_path.write_text(self.content)


class DeprecatableContentType(StrEnum):
    """List the types of content which can be deprecated.

    Note that at this time, we INTENTIONALLY do not support the
    'deprecation workflow' for content like macros, dashboards, etc.
    """

    Detection = "Detection"
    Baseline = "Baseline"
    Investigation = "Investigation"
    Story = "Story"


class SecurityContent(BaseModel, abc.ABC):
    """Abstract Base class for all security content objects.

    This class defines a number of fields which are MANDATORY
    for every object. These fields include relevant information
    for naming objects, ensuring uniqueness, documenting objects,
    and providing for the scalable, correct deprecation/removal of objects.

    Bringing all these requirements into a common, high level base class
    reduces duplication and allows us to enforce the same levels of quality
    and documentation (including support for content versioning needs for
    objects besides searches) in a more scalable way.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    name: str = Field(
        description="Each Security Content Object must have a unique name. "
        "Due to issues with how local/default stanzas are merged in "
        "the Splunk products, these names MUST NOT change between "
        "subsequent releases of content packs."
    )

    id: UUID = Field(
        description="Each Security Content Object must have a unique identifier. "
        "This is particularly important when leveraging many of the "
        "Content Versioning features built into Enterprise Security 8+. "
        "Unique ids may be generated with a python command such as "
        "`uuid.uuid4()` or similar."
    )

    version: PositiveInt = Field(
        description="The version of this object. "
        "This number MUST be incremented in the following circumstances:\n"
        "1. Any time the object in this file is modified\n"
        "2. Any time that the serialization logic for this object changes, "
        "changing what is written in its conf file stanza(s)\n"
        "3. Any time that an object this object references, for example via enrichment,"
        " causes a change in its associated conf file stanzas(s).\n"
        "This final determination is challenging to make manually, so the "
        "`contentctl inspect command` will help identify when this a version "
        "increment is required."
    )

    creation_date: datetime.date = Field(
        description="The date that this object was created. "
        "This should NEVER be updated."
    )

    modification_date: datetime.date = Field(
        description="The date that this object was last modified. "
        "This should be updated whenever the object is modified."
    )

    # TODO: Consider a more structured list of contributors instead of
    # a simple author string. However, this is out of scope for now.
    author: str = Field(
        description="The author of this object. This is a freeform string "
        "that can be used to identify the author of the object. It will eventually "
        "be replaced by a more detailed Contributors list."
    )

    description: str = Field(
        description="A description of the Security Content Object. This should "
        "be a human-readable description of the object, including its purpose."
    )

    references: frozenset[HttpUrl] = Field(
        description="A list of references to external resources "
        "that are relevant to this object. This can include links "
        "to documentation, blog posts, or other resources that provide "
        "additional context or information about the object.",
        default_factory=frozenset,
        min_length=0,
    )

    # The following items will be enriched or added at runtime, and are intentionally
    # not to be part of the JSON Schema. They should NOT be added in YML files. It will
    # be set manually after the object is constructed.
    # Note that these cannot have description=... set since that field does not
    # exists for PrivateAttr.

    # Information about the directory and app this
    # content resides in. This information is required
    # during validation or generation of things like the
    # name of the content's stanza. As an example, EBD Content
    # has a stanza name of [ESCU - Deteciton Name - Rule] where
    # the prefix is "ESCU" comes from the
    # _content_dir.label field.
    _content_dir: ContentDirectory = PrivateAttr()

    _content_file_suffix: Annotated[
        ClassVar[str],
        Field(
            description="This must be defined so that we "
            "know which file types define this object. "
            "This will almost certainly always be YML and should "
            "likely never be overridden by a child class.",
            pattern=r"^\.\w+$",
        ),
    ] = ".yml"

    # TODO: Should these be defined at the class level? Or should there be another
    # layer of abstraction that define a directory, such as DashboardDirectory or
    # DetectionDirectory or LookupDirectory, that defines
    # things like allowed/required suffixes, content_folders, etc?
    _other_allowed_file_suffixes: Annotated[
        ClassVar[list[str]],
        Field(
            description="Any other file extensions that you would like to allow to be present "
            "in this directory, but not parse into objects.  Any files with extensions that are "
            "not present in this list, or the single extension you are parsing into objects, "
            "will result in the generation of an exception. The intent of this field and exception "
            "is to avoid the accidental inclusion of extra files in content directories or misnaming of files. "
            "For example, this will generate an exception if it detects a .history file in the directory or"
            "a file named content.yaml instead of content.yml.",
            pattern=r"^\.\w+$",
        ),
    ] = []

    # Some content, such as CSV backed lookups or Dashboards,
    # require the presence of additional file(s). Allow that
    # as a possibility here.
    _supporting_file: SupportingFile | None = PrivateAttr(default=None)

    # The path to the file that the piece of content was loaded from.
    # This path should be relative to where the tool
    # is run, not relative to the path or the _repo object.
    # Please note that all SecurityContent objects are created
    # from files, not at runtime. This is so that certain fields
    # like version/id must be defined in a permanent way.
    _path: FilePath = PrivateAttr()

    def __hash__(self) -> int:
        """Generate a hash for this object.

        Returns:
            int: The hash for this object
        """
        return hash((self.name, self.id, self.version))

    # TODO: Review the proper used of @property and @abstractmethod
    @classmethod
    @abc.abstractmethod
    def content_folder(cls) -> Path:
        """Return the path to the content folder for this object.

        Note this path is relative to the root of a content directory.

        This is intentionally not implemented for this objects since this
        object does not actually have a folder that contains any content.

        This is also - strangely but intentionally, a function instead of
        a property since there is not idea of an "abstract property" in
        Python/Pydantic. Making this an abstract_method allows us to
        REQUIRE implementation in children which inherit from the class.
        """
        raise NotImplementedError(
            f"Content Folder is not implemented for SecurityContent object of type [{cls.__name__}]. "
            "It MUST be defined in the class definition."
        )

    # TODO: Review the proper used of @property and @abstractmethod
    # TODO: Discuss with STRT what should/MUST be documented on the
    # research site. It is unclear why some objects are not documented
    # on the site and instead point directly to GitHub.
    @computed_field
    @property
    def research_site_root(self) -> HttpUrl:
        """Return the root of the research site."""
        return HttpUrl(url="https://research.splunk.com")

    # TODO: Review the proper used of @property and @abstractmethod
    # TODO: Discuss with STRT what should/MUST be documented on the
    # research site. It is unclear why some objects are not documented
    # on the site and instead point directly to GitHub.
    @computed_field
    @property
    def research_site_path(self) -> str:
        """Return the path of this object.

        By default, this is not implemented and
        will raise a NotImplementedError. Individual
        pieces of content which are documented on the
        research site must implement this method.

        Raises:
            NotImplementedError: If this is not implemented.

        Returns:
            str: The path of this object. This method must be implemented
            by any child class that documents content on the research site.
        """
        raise NotImplementedError(
            f"research_site_path is not implemented for SecurityContent object of type [{type(self).__name__}]. "
            "All objects documented on the research site must have a path defined. "
        )

    # TODO: Review the proper used of @property and @abstractmethod
    # TODO: Discuss with STRT what should/MUST be documented on the
    # research site. It is unclear why some objects are not documented
    # on the site and instead point directly to GitHub.
    @computed_field
    @property
    def research_site_url(self) -> HttpUrl:
        """Return the full url for this object.

        If the research_site_path is not implemented, this will return None.

        TODO: We should consider documenting EVERy object on the site. We could
        also use a link to GitHub as a fallback, however since we store some
        things internally in Gitlab this would not work for every piece of content.

        Raises:
            NotImplementedError: If the research_site_path is not implemented.

        Returns:
            HttpUrl: The full url for this object.
        """
        return HttpUrl.build(
            scheme=self.research_site_root.scheme,
            host=self.research_site_root.host,
            path=self.research_site_path,
        )

    @computed_field
    @property
    @abc.abstractmethod
    def stanza_name(self) -> str:
        """Return the name of this object when serialized to a stanza.

        Classes which inherit from SecurityContent MUST override this method, since
        it is an abstractmethod.  This is required to serialize the object into a conf file.
        If an object is not directly serializable into a conf stanza, such as a Schedule,
        then it should raise a NotImplementedError when overriding the method.

        Returns:
            str: The name of this object when serialized to a stanza.
        """
        raise NotImplementedError(
            f"stanza_name is not implemented for SecurityContent object of type [{self.__name__}]. "
            "It MUST be defined in the class definition."
        )

    @classmethod
    def update_dynamic_status(cls, content: Sequence[ContentEnum]) -> None:
        """Update the dynamic enum for the content."""
        ContentEnum.__update_everything_dangerous__(ContentEnum, content)

    def __lt__(self, other: Any) -> bool:
        """Compare this object to another object.

        The comparison is based on the names of the objects,
        since it does not make sense to sort by anothe rother field.
        This also gives the best user experience, since it is the most
        obvious resulted of a sort.
        """
        if isinstance(other, SecurityContent):
            return self.name < other.name
        raise NotImplementedError(
            "Cannot compare SecurityContent to non-SecurityContent "
            f"object of type [{type(other)}]"
        )

    def enforce_name_and_filename_alignment(self) -> None:
        """Ensure that the name of this file aligns with the value of the name field.

        TODO: As noted in the model_post_init docstring, some of this logic
        should likely be moved to model_validators instead of model_post_init.


        The filename is based on the name of the object, but is transformed to be
        all lowercase and replace spaces, dashes, and periods with underscores.

        For example, an object with the name "My Detection-1.0" would have an expected
        file name of "my_detection_1_0.yml".

        This is NOT a model_validator because it requires the _path field to be set,
        which is not the case until after model initialization.

        Please note that for content which has some custom naming requirements,
        such as playbooks, this function may be over-ridden to implement that logic.

        Raises:
            ValueError: If the name of the file does not align with the name field of the object.
        """
        expected_filename = (
            self.name.lower().replace(" ", "_").replace("-", "_").replace(".", "_")
            + self._content_file_suffix
        )

        if expected_filename != self._path.name:
            raise ValueError(
                f"\nBased on the name of the object: [{self.name}] \n"
                f"the filename MUST be           : [{expected_filename}]\n"
                f"However, the actual filename is: [{self._path.name}]"
            )

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context__: Any) -> None:
        """Forces the setting of special fields _repo and _path.

        Args:
            __context__ (Any): The context dictionary that
            contains the _repo and _path fields.

        Raises:
            ValueError: If __context__ is not a dictionary.
            ValueError: If _path is not present in __context__.
            ValueError: If _repo is not present in __context__.
        """
        if not isinstance(__context__, dict):
            raise ValueError("__context__ must be a dictionary")

        content_path = __context__.get("_path", None)
        if content_path is None:
            raise ValueError(
                "_path is required for all SecurityContent objects, but it was missing from __context__."
            )
        elif not isinstance(content_path, Path):
            raise ValueError(
                f"_path is required for all SecurityContent objects and MUST be a Path object, but it was a [{type(content_path).__name__}]"
            )
        self._path = content_path

        # Ensure that the name of the object matches the name of the file
        self.enforce_name_and_filename_alignment()

        content_dir = __context__.get("_content_dir", None)
        if content_dir is None:
            raise ValueError(
                "_content_dir is required for all SecurityContent objects, but it was missing from __context__."
            )
        elif not isinstance(content_dir, ContentDirectory):
            raise ValueError(
                f"_content_dir is required for all SecurityContent objects and MUST be a ContentDir object, but it was a [{type(content_dir).__name__}]"
            )
        self._content_dir = content_dir

    def write_to_file(self, output_root: Path) -> None:
        """Write the Parsed object back out to a file.

        If the object has a supporting file, it will also be written to the file.

        Args:
            output_root (Path): The root of the directory where this object should be written.


        """
        path_relative_to_original_root = self._path.relative_to(self._content_dir.path)

        common_io.write_basemodel_to_YML_file(
            output_root / path_relative_to_original_root,
            self,
            create_parent_directory=True,
            exclude_defaults=True,
        )
        if self._supporting_file:
            self._supporting_file.write_to_file(output_root)

    @field_validator("creation_date", "modification_date", mode="after")
    @classmethod
    def ensure_date_is_not_in_future(cls, value: datetime.date) -> datetime.date:
        """Ensure that a date field is not in the future.

        Args:
            value (datetime.date): A date field of content, read from the YML.

        Raises:
            ValueError: A date field in the content is in the future.

        Returns:
            datetime.date: The validated date of the content, read from the YML.
        """
        todays_date = datetime.datetime.now(datetime.UTC).date()
        if value > todays_date:
            raise ValueError(
                f"Content date field [{value}], is in the future. The date of content must be today [{todays_date}] or earlier. "
                "Note that this date is relative to UTC, not your current locale."
            )
        return value

    @model_validator(mode="after")
    def ensure_modification_date_not_before_creation_date(self) -> Self:
        """Ensure that the modification date is not before the creation date.

        It is INTENTIONALLY allowed that the modification date be the same as the creation date,
        as this is a valid state for content that has not been modified since its creation.

        Args:
            self (Content): The content object being validated.

        Raises:
            ValueError: If the modification date is before the creation date.

        Returns:
            Self: The validated content object.
        """
        if self.modification_date < self.creation_date:
            raise ValueError(
                f"Modification date [{self.modification_date}] is before creation date [{self.creation_date}]."
            )
        return self


class Product(StrEnum):
    """Enum for products.

    TODO: Have discussions to determine the final set of values to
    allow here. At this time, Stories and Searches have different
    allowed values, which is intentional per user input.
    Stories allow all four values, but Searches DO NOT
    allow SPLUNK_BEHAVIORAL_ANALYTICS..
    Should these be unified to a single common set?
    """

    SPLUNK_ENTERPRISE = "Splunk Enterprise"
    SPLUNK_ENTERPRISE_SECURITY = "Splunk Enterprise Security"
    SPLUNK_CLOUD = "Splunk Cloud"

    # This product is ONLY allowed to be used in Stories. It is intentionally
    # omitted from the SearchProduct enum in Search.py
    SPLUNK_BEHAVIORAL_ANALYTICS = "Splunk Behavioral Analytics"


class ContentStatus(StrEnum):
    """Enum to communicate the deprecation status of content.

    Only content which supports deprecation today with declare
    this type.  This deprecatable content may also narrow the
    supported status values. For instance:
    1. Detections can be [production,deprecated,experimental]
    2. Stories can only be [production,deprecated]
    3. RemovedContent can only be [removed]

    This is used by the deprecation process and is used during
    normalization of the status fields in Searches vs Stories,
    which actually use different enums as they have different
    supported functionality (Searches can be experimental)


    """

    production = "production"
    deprecated = "deprecated"
    # At this time, only detections support experimental
    experimental = "experimental"
    # Only RemovedContent may be removed
    removed = "removed"


class DeprecatableSecurityContent(SecurityContent):
    """Abstract Base class for all security content objects that can be deprecated."""

    # TODO: Consider adding a helper method like self.is_deprecated() to determine
    # whether or not content is deprecated as an alternative to checking
    # if content.deprecation_info is not None
    # However, we should determine the semantic of this behavior. What should
    # is_deprecated() return if deprecation_info not None AND status is removed?
    deprecation_info: DeprecationInfo | None = Field(
        default=None, description="Information about the deprecation of this object."
    )

    status: ContentStatus = Field(
        frozen=True,
        description="The status of this content. All DeprecatableContent must expose "
        "a value for 'status' however some of those values may not be allowed "
        "for certain types of content. They should narrow the allowed types using "
        "Literal[ContentStatus.production, ...other allowed values]",
    )

    @computed_field
    @property
    def deprecation_status(
        self,
    ) -> Literal[
        ContentStatus.production,
        ContentStatus.deprecated,
        ContentStatus.removed,
    ]:
        """Return the type of deprecation status of the content.

        This is intentionally narrowed because from a Deprecation Perspective,
        "experimental" content is treated just like production content. This addresses
        the ability of EventBasedDetection/Baseline content to support experimental
        status.
        """
        if self.status in [ContentStatus.production, ContentStatus.experimental]:
            return ContentStatus.production
        if self.status == ContentStatus.deprecated:
            return self.status
        if self.status == ContentStatus.removed:
            return self.status
        raise ValueError(f"Invalid status: {self.status}")

    @computed_field
    @property
    @abc.abstractmethod
    def deprecatable_content_type(
        self,
    ) -> DeprecatableContentType:
        """Return the type of content that can be deprecated.

        Note that this is an Enum, instead of directly deriving it from
        the class.__name__ parameter (for instance) because there is a disconnected
        between the name of the class, such as "EventBasedDetection", and how we
        categorize the content from a deprecation perspective, where we consider it
        to be a "Detection"
        """
        raise NotImplementedError("Subclasses must implement this method")

    @computed_field
    @property
    def deprecated_content_directory(self) -> Path:
        """Return the path to the deprecated folder for this content type."""
        return self._content_dir.path / self.content_folder() / "deprecated"

    @model_validator(mode="after")
    def check_deprecation_info_if_present(self) -> Self:
        """If object includes deprecation info, ensure it is valid.

        Note that RemovedContent overrides this method with its own,
        intentionally different logic.
        """
        file_in_deprecated_folder: bool = self._path.is_relative_to(
            self.deprecated_content_directory
        )
        has_status_deprecated: bool = (
            self.deprecation_status == ContentStatus.deprecated
        )

        if not (
            self.deprecation_info or file_in_deprecated_folder or has_status_deprecated
        ):
            # If none of these are true, then this content is not deprecated
            # and all of the checks are consistent. Do not do anything
            return self

        elif (
            self.deprecation_info
            and file_in_deprecated_folder
            and has_status_deprecated
        ):
            # All of these checks are true. This content is deprecated (not removed) and
            # all of the checks are consistent.

            # Ensure that the version numbers are correct
            if (
                self.deprecation_info.removed_in_version
                <= self._content_dir.app_settings.app_version
            ):
                raise ValueError(
                    f"Removal version [{self.deprecation_info.removed_in_version}] "
                    f"is earlier than app version {self._content_dir.app_settings.app_version}. "
                    "This content must be removed."
                )
            return self

        # If we get here, then there is an inconsitency in these fields.
        raise ValueError(
            f"Inconsistent deprecation information for content in file {self._path}\n"
            f"When a [{self.deprecatable_content_type.value}] is deprecated it must meet all three constraints:\n"
            f"[CONSTRAINT {'NOT' if not self.deprecation_info else '   '} MET] Contain a 'deprecation_info' field\n"
            f"[CONSTRAINT {'NOT' if not has_status_deprecated else '   '} MET] Have 'status: deprecated' field\n"
            f"[CONSTRAINT {'NOT' if not file_in_deprecated_folder else '   '} MET] Must be in the folder '{self.deprecated_content_directory}'\n"
            "Otherwise, it must meet NONE of these constraints."
        )

    @computed_field
    @property
    def deprecation_info_csv_row(self) -> dict[str, str] | None:
        """Generate a dict of values required for building the deprecation info csv.

        Returns:
            dict[str, str]: A dict of values required for building the deprecation info csv
        """
        if self.deprecation_info is None:
            return None

        return {
            "Name": self.stanza_name,
            "Content Type": self.deprecatable_content_type,
            "Removed in Version": str(self.deprecation_info.removed_in_version),
            "Reason": self.deprecation_info.reason,
            "Replacement Content": "\n".join(
                [str(x.obj.name) for x in self.deprecation_info.replacement_content]
            )
            or "No Replacement Content Available",
            "Replacement Content Link": "\n".join(
                [
                    str(x.obj.research_site_url)
                    for x in self.deprecation_info.replacement_content
                ]
            )
            or "No Content Link Available",
        }


class RemovedContent(DeprecatableSecurityContent):
    """Removed Content is a special type of content that has been deprecated and removed.

    It still requires a number of fields for tracking purposes, but is intentionally more
    permissive about extra fields to support different types of content created against
    different versions of the content specifications.
    """

    model_config = ConfigDict(extra="ignore", validate_assignment=True)

    deprecation_info: DeprecationInfo = Field(  # type: ignore[override]
        description="Removed content REQUIRES deprecation info."
    )

    # The following field is marked as frozen to prevent it from being changed
    # after the object is created. Pyright should not be throwing an issue here
    # as the field is marked as frozen, but it does so we ignore it.
    status: Literal[ContentStatus.removed] = Field(  # pyright: ignore[reportIncompatibleVariableOverride]
        frozen=True,
        description="The status of this RemovedContent. It must be 'removed'.  "
        "Even though a single value is possible for this field, it must always "
        "be provided explicitly in the YML.",
    )

    # Map the type of removed content to the directory under removed/ that
    # it must live in.
    allowed_folder_mappings: ClassVar[dict[str, DeprecatableContentType]] = {
        "detections": DeprecatableContentType.Detection,
        "baselines": DeprecatableContentType.Baseline,
        "stories": DeprecatableContentType.Story,
        "investigations": DeprecatableContentType.Investigation,
    }

    @model_validator(mode="after")
    def validate_content_lives_in_allowed_folder(self) -> RemovedContent:
        """Validate that the status is always 'removed'.

        Call the deprecatable_content_type field to exercise the
        computed_field, which includes error handling for invalid folders.
        Otherwise, we would have to reimplement the logic here from scratch.
        """
        _ = self.deprecatable_content_type

        return self

    @computed_field
    @property
    def deprecatable_content_type(self) -> DeprecatableContentType:
        """Return the type of deprecatable content.

        This is determined by the folder it is contained in,
        not the type of the object itself. This is because by the
        time it has been removed, we can no longer determine the type
        based on what fields are contained in the YML.

        Please note that the content type here will also be used to determine the
        stanza_name for generation of the deprecation info CSV lookup.

        WARNING: PLACING REMOVED CONTENT IN THE WRONG FOLDER UNDER THE
        "removed/{content_type}/ directory will result in incorrect
        deprecation information being generated, in particular in the
        deprecation info CSV.

        Returns:
            DeprecatableContentType: The type of the content.
        """
        removed_base_path = self._content_dir.path / self.content_folder()

        for allowed_folder, content_type in self.allowed_folder_mappings.items():
            checked_path = removed_base_path / allowed_folder
            if self._path.is_relative_to(checked_path):
                return content_type

        # We should never encounter this because of the model validator, but it
        # is kept here in case of an update the introduces a new type of deprecatable
        # content
        raise ValueError(
            "Removed content must be stored in one of the following directories: "
            f"{[str(self.content_folder() / directory) for directory in self.allowed_folder_mappings.keys()]}\n"
        )

    @computed_field
    @property
    def stanza_name(self) -> str:
        """Return the name of the stanza for this content.

        This stanza is derived from from a combination of the name of the content
        and the content_type, which itself is derived from the folder that
        the content is located in.

        Returns:
            str: The name of the stanza for this content.
        """
        if self.deprecatable_content_type is DeprecatableContentType.Detection:
            return (
                f"{self._content_dir.app_settings.content_prefix} - {self.name} - Rule"
            )

        elif self.deprecatable_content_type is DeprecatableContentType.Baseline:
            return f"{self._content_dir.app_settings.content_prefix} - {self.name}"
        elif self.deprecatable_content_type is DeprecatableContentType.Investigation:
            # Investigations, which are no longer supported as objects in
            # security_content, follow the following format
            return f"ESCU - {self.name} - Response Task"
        elif self.deprecatable_content_type is DeprecatableContentType.Story:
            # Stories are just the name of the story
            return self.name
        else:
            raise ValueError(
                f"Unable to generate stanza name for unknown RemovedContent content_type: {self.deprecatable_content_type}"
            )

    @model_validator(mode="after")
    def check_deprecation_info_if_present(self) -> Self:
        """Ensure that content was slated for removal in this app version or an earlier one.

        Note that this intentionally overrides the function by
        the same name in DeprecatableSecurityContent class.

        Returns:
            Self: The object itself.

        Raises:
            ValueError: If the removal version is later than the app version.
        """
        if (
            self.deprecation_info.removed_in_version
            > self._content_dir.app_settings.app_version
        ):
            raise ValueError(
                f"Removal version set for [{self.deprecation_info.removed_in_version}] but "
                f"current version of app is [{self._content_dir.app_settings.app_version}]. This content cannot be removed yet."
            )
        return self

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the dashboards directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("removed")
