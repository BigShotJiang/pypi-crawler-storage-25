"""Validated string primitives.

RootModel-based string types that enforce domain-specific constraints beyond
what bare str provides. Each type captures a distinct string contract used
across the content model:

- SplString: SPL search strings (no leading/trailing whitespace, macro/lookup
  resolution)
- EsTokenString: ES risk message and finding title strings ($field$ token
  substitution syntax)
"""

import logging
import re
from enum import StrEnum
from functools import cached_property
from typing import Self

from pydantic import ConfigDict, Field, RootModel, computed_field, model_validator

from contentctl_ng.objects.app import CustomAppSettings
from contentctl_ng.objects.lookup import Lookup, LookupEnum
from contentctl_ng.objects.macro import Macro, MacroEnum

logger = logging.getLogger(__name__)


class ProvidingTechnology(StrEnum):
    """Enum of technologies that provide the data for this search."""

    AMAZON_SECURITY_LAKE = "Amazon Security Lake"
    AMAZON_WEB_SERVICES_CLOUDTRAIL = "Amazon Web Services - Cloudtrail"
    AZURE_AD = "Azure AD"
    CARBON_BLACK_RESPONSE = "Carbon Black Response"
    CROWDSTRIKE_FALCON = "CrowdStrike Falcon"
    ENTRA_ID = "Entra ID"
    GOOGLE_CLOUD_PLATFORM = "Google Cloud Platform"
    GOOGLE_WORKSPACE = "Google Workspace"
    KUBERNETES = "Kubernetes"
    MICROSOFT_DEFENDER = "Microsoft Defender"
    MICROSOFT_OFFICE_365 = "Microsoft Office 365"
    MICROSOFT_SYSMON = "Microsoft Sysmon"
    MICROSOFT_WINDOWS = "Microsoft Windows"
    OKTA = "Okta"
    PING_ID = "Ping ID"
    SPLUNK_INTERNAL_LOGS = "Splunk Internal Logs"
    SYMANTEC_ENDPOINT_PROTECTION = "Symantec Endpoint Protection"
    ZEEK = "Zeek"


logger.info("TODO: Fix up errors on leading or trailing whitespace for SPLString")


class SplString(RootModel[str]):
    """Represents a SPL String, which is a string that contains SPL.

    This places additional requirements on string fields representing
    and SPL search and also provides functionality for extracting
    and validating other content referenced by the search, such as
    macros and lookups.
    """

    model_config = ConfigDict(frozen=True)

    # This pattern ensures that the search does not begin or end with whitespace
    # TODO: This regex seems insufficient to capture a potentially multiline string that
    # does not begin or end with whitespace
    # (and will generate exceptions when there is leading or trailing whitespace, which is what we want).
    # Please review and improve this regex when possible.
    root: str = Field(
        pattern=r"[^\s].+[^\s]",
        description="The SPL string itself. Ensure it cannot begin or end with whitespace.",
    )

    @computed_field
    @property
    def providing_technologies(self) -> frozenset[ProvidingTechnology]:
        """Get the set of providing_technologies that provide the data for this search.

        TODO: These should likely be annotations on a datasource rather than something
        calculated from the search string.

        Args:
            search_string (str): The search string to extract the providing technologies from.
            The providing_technologies_mapping provides keywords, macros, etc that can be updated
            with new mappings.  If that substring appears in the search, then its list of providing
            technologies is added.

        Returns:
            List[ProvidingTechnology]: List of providing technologies (with no duplicates because
            it is derived from a set) calculated from the search string.
        """
        matched_technologies: set[ProvidingTechnology] = set()
        # As there are many different sources that use google logs, we define the set once
        google_logs = set(
            [
                ProvidingTechnology.GOOGLE_WORKSPACE,
                ProvidingTechnology.GOOGLE_CLOUD_PLATFORM,
            ]
        )
        providing_technologies_mapping = {
            "`amazon_security_lake`": set([ProvidingTechnology.AMAZON_SECURITY_LAKE]),
            "audit_searches": set([ProvidingTechnology.SPLUNK_INTERNAL_LOGS]),
            "`azure_monitor_aad`": set(
                [ProvidingTechnology.AZURE_AD, ProvidingTechnology.ENTRA_ID]
            ),
            "`cloudtrail`": set([ProvidingTechnology.AMAZON_WEB_SERVICES_CLOUDTRAIL]),
            # Endpoint is NOT a Macro (and this is intentional since it is to capture Endpoint Datamodel usage)
            "Endpoint": set(
                [
                    ProvidingTechnology.MICROSOFT_SYSMON,
                    ProvidingTechnology.MICROSOFT_WINDOWS,
                    ProvidingTechnology.CARBON_BLACK_RESPONSE,
                    ProvidingTechnology.CROWDSTRIKE_FALCON,
                    ProvidingTechnology.SYMANTEC_ENDPOINT_PROTECTION,
                ]
            ),
            "`google_": google_logs,
            "`gsuite": google_logs,
            "`gws_": google_logs,
            "`kube": set([ProvidingTechnology.KUBERNETES]),
            "`ms_defender`": set([ProvidingTechnology.MICROSOFT_DEFENDER]),
            "`o365_": set([ProvidingTechnology.MICROSOFT_OFFICE_365]),
            "`okta": set([ProvidingTechnology.OKTA]),
            "`pingid`": set([ProvidingTechnology.PING_ID]),
            "`powershell`": set(set([ProvidingTechnology.MICROSOFT_WINDOWS])),
            "`splunkd_": set([ProvidingTechnology.SPLUNK_INTERNAL_LOGS]),
            "`sysmon`": set([ProvidingTechnology.MICROSOFT_SYSMON]),
            "`wineventlog_security`": set([ProvidingTechnology.MICROSOFT_WINDOWS]),
            "`zeek_": set([ProvidingTechnology.ZEEK]),
        }
        for key in providing_technologies_mapping:
            if key in self.root:
                matched_technologies.update(providing_technologies_mapping[key])
        return frozenset(matched_technologies)

    def extract_macros(
        self: SplString,
        app_settings: CustomAppSettings,
        require_filter_macro: bool,
        search_name: str | None = None,
    ) -> frozenset[Macro]:
        """Ensure that any macros used in the search exist.

        If this search requires a filter macro, but but the "
        "object does not exist, then it will also create one "
        "and update the Macros Enum

        Args:
            self (SplString): The SPL Search String itself
            search_name (str): The name of the search using this SPL String
            app_settings (CustomAppSettings): The app settings for the app. This is used
            to resolve any externally defined macros.
            require_filter_macro (bool, optional): Whether or not a filter "
            "macro is required to exist at the end of this search. Defaults to True.

        Raises:
            ValueError: A macro which was referenced in the search does not exist.
            ValueError: If the search contains four or more '`' characters in a row, "
            "which is invalid SPL. This may have occurred when a macro was commented out."
            "Please ammend your search to remove the substring '````'."

        Returns:
            set[Macro]: All of the macros used in the search
        """
        if require_filter_macro and search_name is None:
            raise ValueError(
                "search_name argument was [None]. "
                "Search MUST be provided to require filter_macros."
            )

        spl_string: str = self.root
        if re.findall(r"\`\`\`\`", spl_string):
            raise ValueError(
                "Search contained four or more '`' characters in a row "
                "which is invalid SPL. This may have occurred when a "
                "macro was commented out.\n"
                "Please ammend your search to remove the substring '````'"
            )

        # Replace all the comments with a space.
        # This prevents a comment from looking like a macro to the parser below
        cls = re.sub(r"\`\`\`[\s\S]*?\`\`\`", " ", spl_string)

        # Find all the macros, which start and end with a '`' character
        macros_to_get = re.findall(r"`([^\s]+)`", cls)

        # If macros take arguments, stop at the first argument.
        # We will not validate that the proper number of arguments
        # are passed to the macro to avoid additional complexity.
        #
        # TODO: Consider adding a validation step to ensure that
        # the proper number of arguments

        macro_names: set[str] = set(
            [
                macro[: macro.find("(")] if macro.find("(") != -1 else macro
                for macro in macros_to_get
            ]
        )

        if require_filter_macro:
            filter_macro_name = Macro.search_name_to_filter_macro_name(search_name)
            filter_macro_with_backticks = f"`{filter_macro_name}`"
            # if not cls.endswith(filter_macro_with_backticks):
            if filter_macro_with_backticks not in cls:
                # TODO: We should consider enforcing that the search
                # MUST end with a filter macro - including now whitespace at the end.
                # This should be a ValueError, but we need to update the
                # There is exactly one search today,
                # Detect Windows DNS SIGRED Via Zeek (experimental)
                # that has the filter macro in a different place. We should
                # either update the search or remove it for the sake of consistency.
                actual_search_end = cls.split(" ")[-1]
                raise ValueError(
                    f"Search MUST end with a filter macro:\n"
                    f"REQUIRED_FILTER_MACRO: '{filter_macro_with_backticks}'\n"
                    f"ACTUAL_SEARCH_ENDING : '{actual_search_end}'\n"
                    "Please add a filter macro to the search."
                )
            # If the filter macro does not exist, then create the macro and
            # update the enum accordingly
            try:
                # Check to see if the filter macro exists
                MacroEnum[filter_macro_name]
            except KeyError:
                # Filter macro does not exist, so create it.
                Macro.generate_filter_macro_and_update_enum(search_name)

        macro_objects: set[Macro] = set()
        for macro_name in macro_names:
            try:
                macro_objects.add(MacroEnum[macro_name].obj)
            except KeyError:
                # It is possible that this macro is defined externally in a
                # dependency.  Check and see if it is and error if it is not.
                if not app_settings.check_if_content_is_defined_in_external_app(
                    macro_name, "macro"
                ):
                    raise ValueError(
                        f"Macro [`{macro_name}`] does not exist in this app or "
                        "in an external app (e.g. a dependency like CIM). "
                        "If this definition is supposed to exist in an external app, "
                        "please add the definition to your app.yml file under "
                        "'external_app_content' section."
                    )

        return frozenset(macro_objects)

    def extract_lookups(
        self: SplString, app_settings: CustomAppSettings
    ) -> frozenset[Lookup]:
        """Extract all lookups used in the search.

        Args:
            self (SplString): The SPL String itself
            app_settings (CustomAppSettings): The app settings for the app. This is used
            to resolve any externally defined lookups.

        Returns:
            list[str]: List of lookups used in the search
        """
        spl_string: str = self.root
        INPUT_LOOKUP_REGEX = r"[^\w]inputlookup(?:\s*(?:(?:append|strict|start|max)\s*=\s*(?:true|t|false|f))){0,4}\s+([\w]+)"
        OUTPUT_LOOKUP_REGEX = r"[^\w]outputlookup(?:\s*(?:(?:append|create_empty|override_if_empty|max|key_field|allow_updates|createinapp|create_context|output_format)\s*=\s*[^\s]*))*\s+([\w]+)"
        PLAIN_LOOKUP_REGEX = r"[^\w](?:(?<!output)(?<!input))lookup(?:\s*(?:(?:local|update)\s*=\s*(?:true|t|false|f))){0,2}\s+([\w]+)"

        # Use regexes to match the inputlookup, outputlookup,
        # and plain lookups that are used in the search
        inputLookups = set(
            re.findall(
                INPUT_LOOKUP_REGEX,
                spl_string,
                re.IGNORECASE,
            )
        )
        outputLookups = set(
            re.findall(
                OUTPUT_LOOKUP_REGEX,
                spl_string,
                re.IGNORECASE,
            )
        )
        plainLookups = set(
            re.findall(
                PLAIN_LOOKUP_REGEX,
                spl_string,
                re.IGNORECASE,
            )
        )

        all_lookups: set[str] = inputLookups | outputLookups | plainLookups
        found_lookups: set[Lookup] = set()
        for lookup in all_lookups:
            try:
                found_lookups.add(LookupEnum[lookup].obj)
            except KeyError:
                # It is possible that this lookup is defined externally in a
                # dependency.  Check and see if it is and error if it is not.
                if not app_settings.check_if_content_is_defined_in_external_app(
                    lookup, "lookup"
                ):
                    raise ValueError(
                        f"Lookup [{lookup}] does not exist in this app or "
                        "in an external app (e.g. a dependency like CIM). "
                        "If this definition is supposed to exist in an external app, "
                        "please add the definition to your app.yml file under "
                        "'external_app_content' section."
                    )
        return frozenset(found_lookups)


# Matches $field_name$ tokens. Captures the field name (without the $ delimiters).
# Field names may not contain whitespace, dots, or $ characters.
_ES_TOKEN_PATTERN = re.compile(r"\$([^\s.$]+)\$")


class EsTokenString(RootModel[str]):
    """An ES token substitution string used in risk messages and finding titles.

    Supports $field_name$ token substitution, where each token is resolved at
    alert-firing time to the value of the named field in the triggering event.
    Serializes to action.risk.param._risk[*].risk_message and
    action.notable.param.rule_title in savedsearches.conf.

    Validation enforces that $ delimiters are balanced — an odd number of $
    characters indicates an orphaned delimiter that ES cannot resolve, which
    would be silently ignored or cause unexpected behaviour at runtime. At
    least one $field_name$ token must be present; a static string with no
    tokens provides no contextual information about the triggering event.
    """

    model_config = ConfigDict(frozen=True)

    root: str = Field(
        description="The token string. May contain $field_name$ substitution tokens "
        "resolved at alert-firing time. $ delimiters must be balanced."
    )

    @model_validator(mode="after")
    def validate_token_structure(self) -> Self:
        """Validate that $ delimiters are balanced and all token names are well-formed.

        Splits on $ to parse the token structure directly rather than relying on
        a count check. Segments at odd indices are token names; segments at even
        indices are literal text. An even number of $ characters (odd-length split
        list) is required, at least one token must be present, and each token name
        must be non-empty and contain no whitespace.

        Raises:
            ValueError: If the number of $ characters is odd (orphaned delimiter),
                no tokens are present (plain string), a token name is empty (e.g. $$),
                or a token name contains whitespace (e.g. "$ user $"), any of which
                would produce a malformed or uninformative string in ES.

        Returns:
            Self: The validated instance.
        """
        parts = self.root.split("$")
        if len(parts) % 2 == 0:
            raise ValueError(
                f"Unbalanced $ delimiter in token string: {self.root!r}. "
                "Each $ must be part of a $field_name$ token pair."
            )
        if len(parts) == 1:
            raise ValueError(
                f"No $field_name$ tokens found in token string: {self.root!r}. "
                "At least one token is required."
            )
        for token_name in parts[1::2]:
            if not token_name:
                raise ValueError(
                    f"Empty token name ($$) in token string: {self.root!r}. "
                    "Token names must be non-empty SPL field names."
                )
            if re.search(r"\s", token_name):
                raise ValueError(
                    f"Token name {token_name!r} in token string {self.root!r} "
                    "contains whitespace. Token names must be valid SPL field names."
                )
        return self

    @cached_property
    def extract_token_fields(self) -> frozenset[str]:
        """Return the set of field names referenced by $field_name$ tokens.

        Used by validators on EventBasedDetection to check that each token
        field name appears in the detection's search string.

        Returns:
            frozenset[str]: Lowercased field names extracted from all
                $field_name$ tokens in this string.
        """
        return frozenset(
            match.lower() for match in _ES_TOKEN_PATTERN.findall(self.root)
        )
