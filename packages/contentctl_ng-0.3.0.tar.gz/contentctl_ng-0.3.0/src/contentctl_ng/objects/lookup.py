"""This module contains information supporting Lookup objects.

It contains a number of subclasses that support both
CSV-backed Lookups as well as KVStore Lookups.  Since
these types have a lot in common, they are both defiend
in the same file
"""

import abc
import csv
from pathlib import Path
from typing import Annotated, Any, ClassVar, Literal

from pydantic import (
    Field,
    NonNegativeInt,
    PrivateAttr,
    computed_field,
    model_validator,
)

from contentctl_ng.objects.conf import ConfStanza
from contentctl_ng.objects.content import ContentEnum, SecurityContent, SupportingFile


class Lookup(SecurityContent, abc.ABC):
    """Represents a Basic Lookup object.

    Lookups are used to enrich data with additional
    information based on matching values from field(s).
    Each lookup will also create a corresponding entries
    in the transforms.conf file.
    """

    # TODO: Convert Consider conversion of Literal to StrEnum
    lookup_type: Literal["kvstore", "csv"] = Field(
        description="The type of lookup. This will needed to be "
        "broken down more specifically into KVStore vs CSV, along with "
        "additional class definitions for these types."
    )
    # Per the documentation for transforms.conf, EXACT should not be specified in this list,
    # so we include only WILDCARD and CIDR
    match_type: list[Annotated[str, Field(pattern=r"(^WILDCARD|CIDR)\(.+\)$")]] = Field(
        default_factory=list,
    )
    min_matches: None | NonNegativeInt = Field(default=None)
    max_matches: None | Annotated[NonNegativeInt, Field(ge=1, le=1000)] = Field(
        default=None
    )
    default_match: None | str = Field(
        default=None,
        description="Warning - we often use the string 'false' for this field. "
        "This can cause some confusion as pyyaml read this from the file as the "
        "boolean value false. Be sure to wrap the value false in quotes in the "
        "yml file to prevent this. So instead of 'default_match: false' "
        "use 'default_match: \"false\"'.",
    )

    case_sensitive_match: None | bool = Field(default=None)

    @classmethod
    def update_dynamic_status(cls, content: list[Lookup]) -> None:
        """Update the dynamic enum for the lookups.

        Args:
            content (list[Lookup]): The content to update the enum with.
        """
        LookupEnum.__update_everything_dangerous__(LookupEnum, content)

    @computed_field
    @property
    def stanza_name(self) -> str:
        """Return the name of the stanza for this lookup.

        Returns:
            str: The name of the stanza for this lookup.
        """
        return self.name

    @computed_field
    @property
    def match_type_conf_formatted(self) -> str:
        """Return the match type as a string for the conf file."""
        return ", ".join(self.match_type)

    def emit_ConfStanza(self) -> ConfStanza:
        """Emit a ConfStanza object for this lookup."""
        stanza = ConfStanza(name=self.stanza_name)

        # This line INTENTIONALLY uses the conf key '# description' because
        # the description field is not supported in a transforms.conf stanza.
        # This allows us to still include some useful documentation in the file
        # to improve human-readability
        stanza.add_line(self, "# description", "description")
        if self.min_matches is not None:
            stanza.add_line(self, "min_matches", "min_matches")
        if self.max_matches is not None:
            stanza.add_line(self, "max_matches", "max_matches")
        if self.default_match is not None:
            stanza.add_line(self, "default_match", "default_match")
        if self.case_sensitive_match is not None:
            stanza.add_line(self, "case_sensitive_match", "case_sensitive_match")
        if self.match_type:
            stanza.add_line(self, "match_type", "match_type_conf_formatted")
        return stanza


class KVStoreLookup(Lookup):
    """Represents a KVStore Lookup object."""

    # TODO: Convert Consider conversion of Literal to StrEnum
    lookup_type: Literal["kvstore"] = "kvstore"

    fields: list[str] = Field(
        description="The names of the fields/headings for the KVStore.",
        min_length=1,
        default_factory=list,
    )

    @computed_field
    @property
    def fields_conf_formatted(self) -> str:
        """Return the match type as a string for the conf file."""
        return ", ".join(self.fields)

    @computed_field
    @property
    def enforceTypes(self) -> str:
        """Return properly formatted enforceTypes field for collections.conf.

        Returns:
            str: The enforceTypes field for the KVStore Lookup. This is a string,
            and not a bool, because we want to to be serialized to 'false' and not
            'False'.
        """
        return "false"

    @computed_field
    @property
    def replicate(self) -> str:
        """Return properly formatted replicate field for collections.conf.

        Returns:
            str: The replicate field for the KVStore Lookup. This is a string,
            and not a bool, because we want to to be serialized to 'false' and not
            'False'.
        """
        return "false"

    def emit_ConfStanza_collections(self) -> str:
        """Emit a ConfStanza object for this lookup."""
        stanza = ConfStanza(name=self.stanza_name)
        stanza.add_line(self, "enforceTypes")
        stanza.add_line(self, "replicate")
        return stanza

    def emit_ConfStanza(self) -> ConfStanza:
        """Generate an confStanza for KVStore Lookup.

        KvStoreLookup must include at least 1 field in the fields list.

        Returns:
            ConfStanza: The confStanza for the KVStore Lookup.
        """
        super_fields = super().emit_ConfStanza()
        super_fields.add_line(self, "external_type", "lookup_type")
        super_fields.add_line(self, "fields_list", "fields_conf_formatted")
        return super_fields

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the lookups directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("lookups/kvstore")


class LookupCSVFile(SupportingFile):
    """Represents a CSV File which supports a CSV Lookup."""

    # All lookup csv  files MUST end in .csv.
    # This is used for calculating their names as well
    # as the fact that they are allowed to be in the lookups/csv/ folder.
    _content_file_suffix: ClassVar[str] = ".csv"

    @model_validator(mode="after")
    def ensure_correct_csv_structure(self):
        """Ensure that the CSV file has the correct structure.

        This was ported over from the legacy contentctl codebase.
        There does not appear to be a much better way to do this,
        so we keep the same logic as before.
        """
        # https://docs.python.org/3/library/csv.html#csv.DictReader
        # Column Names (fieldnames) determine by the number of columns in the first row.
        # If a row has MORE fields than fieldnames, they will be dumped in a list under the key 'restkey' - this should throw an Exception
        # If a row has LESS fields than fieldnames, then the field should contain None by default. This should also throw an exception.
        csv_errors: list[str] = []

        RESTKEY = "extra_fields_in_a_row"
        with open(self.input_path, "r") as handle:
            csv_dict = csv.DictReader(handle, restkey=RESTKEY)

            if csv_dict.fieldnames is None:
                raise ValueError(
                    f"Error validating the CSV file:  {self.input_path}:\n\t"
                    "Unable to read fieldnames from CSV. Is the CSV empty?\n"
                    "Please try opening the file with a CSV Editor to ensure that it is correct."
                )
            # Remember that row 1 has the headers and we do not iterate over it in the loop below
            # CSVs are typically indexed starting a row 1 for the header.
            for row_index, data_row in enumerate(csv_dict):
                row_index += 2
                if len(data_row.get(RESTKEY, [])) > 0:
                    csv_errors.append(
                        f"row [{row_index}] should have [{len(csv_dict.fieldnames)}] columns,"
                        f" but instead had [{len(csv_dict.fieldnames) + len(data_row.get(RESTKEY, []))}]."
                    )

                for column_index, column_name in enumerate(data_row):
                    if data_row[column_name] is None:
                        csv_errors.append(
                            f"row [{row_index}] should have [{len(csv_dict.fieldnames)}] columns, "
                            f"but instead had [{column_index}]."
                        )
        if len(csv_errors) > 0:
            err_string = "\n\t".join(csv_errors)
            raise ValueError(
                f"Error validating the CSV file {self.input_path}:\n\t{err_string}\n"
                f"  Please try opening the file with a CSV Editor to ensure that it is correct."
            )

        return self


class CSVLookup(Lookup):
    """Represents a CSV-backed Lookup object."""

    # TODO: Convert Consider conversion of Literal to StrEnum
    lookup_type: Literal["csv"] = "csv"

    _other_allowed_file_suffixes: ClassVar[list[str]] = [
        LookupCSVFile._content_file_suffix
    ]

    # All CSV Lookups require the presence of a corresponding
    # CSV file.  The name and existence of this file is verified
    # automatically at parse time.
    _supporting_file: LookupCSVFile = PrivateAttr()

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the lookups directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("lookups/csv")

    @computed_field
    @property
    def app_filename(self) -> str:
        """Return the name of the file to be used when the app is built, including a datestamp at the end.

        This suffix to the name of the CSV file is included to ensure appropriate
        replication of updated CSV files in all Splunk environments, especially
        Splunk Cloud.  For more detail, see the behavior documented here - in some
        Splunk Cloud environments, it is not possible to update/replace an existing
        CSV file - so when we update the file lookup we ship an entirely new file
        with a YYYYMMDD suffix appended to it.
        https://help.splunk.com/en/splunk-cloud-platform/administer/admin-manual/10.0.2503/manage-apps-and-add-ons-in-splunk-cloud-platform/manage-private-apps-on-your-splunk-cloud-platform-deployment#ariaid-title7

        Returns:
            str: The name of the app file with appropriate datestamp
            suffix based on the modification_date of the content.
        """
        content_time_string = self.modification_date.strftime("%Y%m%d")

        return f"{self._path.stem}_{content_time_string}{LookupCSVFile._content_file_suffix}"

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context__: Any) -> None:
        """Forces the setting of special fields _repo and _path.

        This also ensures the existence of the relevant csv file.

        Args:
            __context__ (Any): The context dictionary that
            contains the _repo and _path fields.

        Raises:
            ValueError: If __context__ is not a dictionary.
            ValueError: If _path is not present in __context__.
            ValueError: If _repo is not present in __context__.
            FileNotFoundError: If the CSV file does not exist.
        """
        # Super method already checks to ensure that context is a dict
        super().model_post_init(__context__)

        # CSV file must have exactly the same name as the lookup,
        # with the exception that the file extensions must be csv.
        self._supporting_file = LookupCSVFile(
            input_path=self._path.with_suffix(LookupCSVFile._content_file_suffix),
            output_path=Path(f"lookups/{self.app_filename}"),
        )

    def emit_ConfStanza(self) -> ConfStanza:
        """Generate an confStanza for CSV Lookup.

        CsvLookup must include the name of the lookup csv file.

        Returns:
            ConfStanza: The confStanza for the CSV Lookup.
        """
        super_fields = super().emit_ConfStanza()
        super_fields.add_line(self, "filename", "app_filename")
        return super_fields


class LookupEnum(ContentEnum):
    """Empty Placeholder Enum for lookups.

    NOTE: This enum is dynamically populated at runtime by the Lookup.UpdateDynamicEnum method.
    """

    pass
