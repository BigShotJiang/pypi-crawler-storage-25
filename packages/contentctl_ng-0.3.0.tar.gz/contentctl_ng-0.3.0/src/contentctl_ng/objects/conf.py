"""Handles the creation and serialization of conf files in a safe a scalable way."""

import importlib.metadata
import inspect
import json
import logging
import re
import uuid
from datetime import date
from enum import StrEnum
from typing import Any, Self

from pydantic import (
    BaseModel,
    DirectoryPath,
    Field,
    HttpUrl,
    computed_field,
    field_validator,
    model_validator,
)

from contentctl_ng.objects.app import CustomAppSettings
from contentctl_ng.version import PydanticVersion

logger = logging.getLogger(__name__)

logger.warning(
    "WARNING - WE ARE NOT CHECKING FOR NEWLINES IN CONF VALUES. "
    "THIS IS COMMENTED OUT AT THE MOMENT PENDING MORE WORK. "
    "CHECK THE 'check_value_validity' FUNCTION FOR MORE DETAIL"
)


class ConfValueObjectSerializer(json.JSONEncoder):
    """Custom JSON encoder for serializing values."""

    def default(self, obj):
        """Serializes different values that require custom logic.

        This function provides custom dumping logic for a number of objects
        that are not JSON serializable by default and these datatypes
        exists in the context of frozenset, list, and dict values which
        are also dumped during JSON serialization.

        1. UUIDs
        2. HttpUrls


        It also provides:
        1. logic for serializing frozensets in a deterministic order.
        2. default serialization logic for Drilldown (a call to model_dump()).
        At this time, attempts to serialize other BaseModel objects will
        intentionally raise a ValueError.

        Raises:
            ValueError: If the object is not explicitly supported here as JSON serializable.
            Recall that all the default values which may be nested in these objects are
            serializable with their own default logic.

        Returns:
            str: The serialized value of the object. This is in JSON serialized format, so
            it should not contain extraneous whitespace/newlines or quoting.
        """
        # TODO: Remove this deferred import. This work will likely be covered
        # by the larger conf serialization work.
        from contentctl_ng.objects.searches.detection import Drilldown

        if isinstance(obj, uuid.UUID):
            # Without this definition, attempting to serialize a UUID will fail
            # with a TypeError:
            # Object of type UUID is not JSON serializable
            # This logic lives here because UUIDs are embedded in some of the list, frozenset, and dict
            # values that are serialized.
            dumped = str(obj)

        elif isinstance(obj, frozenset):
            # Sets are unordered and from a "correctness" perspective, their order is not meaningful.
            # at a functional level. Additionally, conf files do not support anything like a "set",
            # they only support things that look like lists (for example JSON formatted lists).
            # If sets are serialized and wind up being in a different order:
            # 1. It negatively impacts the readability/diffability or files
            # 2. Most importantly, it can result in a stanza being serialized differently:
            # action.field_which_is_a_set_in_contentctl: ["first", "second", "third"]
            # action.field_which_is_a_set_in_contentctl: ["second", "first", "third"]
            # According to our logic for enforcing versioning, this would result in two different
            # stanzas with two different hashes and necessitate a version bump.
            # To prevent this, we intentionally impose a deterministic ordering on sets
            # for consistency in serialization.
            dumped = sorted(list(obj))

        elif isinstance(obj, HttpUrl):
            # Without this definition, attempting to serialize HttpUrl will fail
            # with a TypeError:
            # Object of type date is not HttpUrl serializable
            # this logic is embedded here as HttpUrl is embedded in frozensets
            dumped = str(obj)

        elif isinstance(obj, Drilldown):
            # TODO: If required, allow dumping of any BaseModel objects.
            # This may be covered by the larger work around updating conf serialization logic.
            # Explicitly only provide dumping logic for Drilldowns, not generic
            # BaseModels, because we have only validated that the dumping of Drilldowns
            # is correct. In the future if we try to dump other BaseModel objects,
            # we will explicitly fail with error until that exact Object is supported.
            dumped = obj.model_dump()
        else:
            raise ValueError(
                f"Unable to serialize data the following data type to conf file: {type(obj)}. "
                "This type does not have default serialization logic and is a new type. "
                "Please define its serialization logic explicitly in the ConfValueObjectSerializer function."
            )

        return dumped


class DuplicateConfKeyError(Exception):
    """Exception raised when a duplicate key is added to a set."""

    pass


class ConfKeySyntaxError(Exception):
    """Exception raised when a conf key is invalid."""

    pass


class ConfValueSyntaxError(Exception):
    """Exception raised when a conf value is invalid."""

    pass


class ObjectKeySyntaxError(Exception):
    """Exception raised when an object key is invalid."""


class ConfDuplicateStanzaError(Exception):
    """Exception raised when a duplicate stanza is added to a conf file."""

    pass


class ConfLine(BaseModel):
    """This class represents a key/value pair in a conf file.

    It is used to serialize and deserialize key/value pairs to and from a conf file.
    Note that, at their simplest, conf lines look like:
    conf_key = value
    But there is significant complexity and type checking that is required for this
    """

    sourceObject: object = Field(
        description="The Python object that this key/value pair is associated with.  "
        "Note that this is intentionally untyped to support arbitrary objects, "
        "but may be typed as something more complex in the future. "
        "Rather than accessing fields directly, hasattr/getattr will be used to access their fields."
        "Defining this in the line, rather than in the stanza the line belongs to, allows for "
        "more flexibility as some complex stanzas may require multiple different objects, or"
        "types of objects, for their serialization. This is a common pattern in Splunk conf files."
    )

    conf_key: str = Field(
        description="The key in the key/value pair. This is used to identify the setting in the conf file."
    )

    object_key: str = Field(
        description="The key that is used to identify the field in the object. "
        "This does not need to be the same as the conf_key, but it may be the same. This allows"
        "us to clearly generate a direct mapping between fields in the python object and fields in the conf file."
        "Additionally, many fields in the conf file, such as 'action.correlationsearch/enabled, CANNOT map directly"
        "to properties of an object due to the presence of '.' characters in the conf_key."
    )

    description: str | None = Field(
        default=None,
        description="This optional field can be used to provide more information about a setting in a conf file. "
        "Since conf files can become complex, this can be quite useful in explaining the underlying meaning/purpose of "
        "a key/value in conf file. You may wish to include links to authoritative documentation here. "
        "This field will NOT be serialized to the conf file, so it is not required to be filled out.",
    )

    @computed_field
    @property
    def value(self) -> str:
        """Dynamically retrieves the value from the sourceObject using the object_key.

        Returns:
            str: The string representation of the value from the source object.
        """
        if not hasattr(self.sourceObject, "__dict__"):
            raise AttributeError(
                f"Conf serialization error for Object of type [{type(self.sourceObject).__name__}]. "
                f"You are attempting to serialize the attribute '{self.object_key}' from the object '<{type(self.sourceObject).__name__}>{self.sourceObject}'."
                f"However, an object of the type <{type(self.sourceObject).__name__}> does not have attributes."
            )

        if not hasattr(self.sourceObject, self.object_key):
            # get computed properties
            if isinstance(self.sourceObject, BaseModel):
                computed_properties: set[str] = set(
                    self.sourceObject.__class__.model_computed_fields.keys()
                )

            else:
                computed_properties: set[str] = set()

            # This is a basic python type, such as dict or int (probably)
            attrs: set[str] = set(vars(self.sourceObject).keys())

            available_attributes: set[str] = "\n - ".join(
                sorted(attrs | computed_properties)
            )

            raise AttributeError(
                f"Conf serialization error for Object of type [{type(self.sourceObject).__name__}]\n"
                f"[{type(self.sourceObject).__name__}] is missing an attribute named '{self.object_key}'. "
                f"Available attributes are: \n - {available_attributes}\n"
                f"Please consider referencing one of these attributes or defining a new attribute in the following class:\n"
                f"{inspect.getsourcefile(type(self.sourceObject))}->{self.sourceObject.__class__.__name__}."
            )

        # Get the raw value. However, since we need a number of transformations
        # (for example sorting, escaping newlines, or similar), we will perform them now
        raw_value = getattr(self.sourceObject, self.object_key)

        # Use custom serialization logic defined above suitable for conf file values
        # If the value is a string, json.dumps will wrap it in a "". For instance,
        # the plain string 'hello' becomes the dumped json string '"wow"'. We need
        # to strip out the leading and trailing ""

        # Atomic datatypes, such as int/str/bool/enum should be handled here and NOT by JSON serialization
        if isinstance(raw_value, str):
            serialized_value = raw_value.strip().replace("\n", " \\\n")
        elif isinstance(raw_value, bool):
            # TODO decide if there is a most proper/accepted representation for booleans
            # Ordering here is extremely important - in fact isinstance(False,int)
            # and isinstance(True, int) both return True as bool is a subclass of it.
            # we must check the value for bool first.
            # Please note that conf files are supposed to
            # treat all the following as equals:
            # "true", "True", "TRUE", and "1"
            # "false", "False", "FALSE", and "0"
            # serialized_value = str(raw_value).lower()

            # We intentionally have this as its own explicit case
            # to make extremely clear how booleans should be serialized.
            if raw_value:
                serialized_value = "1"
            else:
                serialized_value = "0"

        elif isinstance(raw_value, int):
            serialized_value = str(raw_value)
        elif isinstance(raw_value, StrEnum):
            serialized_value = raw_value.name

        elif isinstance(raw_value, date):
            serialized_value = raw_value.strftime("%Y-%m-%d")
        elif isinstance(raw_value, PydanticVersion):
            serialized_value = str(raw_value)

        elif type(raw_value) in (
            frozenset,
            list,
            dict,
        ):
            # There does not need to be any additional grooming or special handling of JSON serialized values.
            # For instance, there will be no literal newlines or leading/trailing whitespaces or extra quotes
            # after frozenset, list, or dict are serialized.
            serialized_value = json.dumps(
                raw_value,
                # compact JSON without spaces. This is required
                # for the way ES reads back and rewrites these fields
                separators=(",", ":"),
                sort_keys=True,
                cls=ConfValueObjectSerializer,
            )
        else:
            raise ValueError(
                f"Invalid type for conf value: {type(raw_value)}. "
                "Only str, int, bool, StrEnum, date, PydanticVersion, frozenset, list, dict are supported. "
                "This is a new datatype which must have serialization logic explicitly defined in "
                "the 'value()' function for ConfLine."
            )
        return serialized_value

    @field_validator("conf_key", mode="after")
    @classmethod
    def check_key_validity(cls, value: str) -> str:
        """Checks the validity of the key field based on conf file format requirements.

        Raises:
            ConfKeySyntaxError: Conf Key has failed validation.
        """
        if "\n" in value or "\r" in value:
            raise ConfKeySyntaxError(
                f"Invalid conf_key: {value}. It cannot contain newlines."
            )
        return value

    @model_validator(mode="after")
    def check_value_validity(self) -> Self:
        """Checks the validity of the value field based on conf file format requirements.

        As the value is a computed field, this is NOT a field validator, but
        a model validator instead. This is because it it needs access to
        some of the other fields, like the object passed in, to compute
        the self.value

        Raises:
            ConfValueSyntaxError: Conf value has failed validation

        """
        if re.findall(r"[^ \\]\n", self.value):
            raise ConfValueSyntaxError(
                f"Invalid conf_value for stanza: {self.value}. It cannot contain newlines that are not escaped with a the following on the prior line: ' \\'."
            )

        return self

    def serialize_to_conf_format(self) -> str:
        """Serializes a single key/value pair to a string that can be written to a conf file.

        This string has been properly checked/escaped as required by Splunk's conf file format, ensuring
        that anything serialized is safe and valid for inclusion in the conf file. This avoids the
        need to perform additional validations/escaping when writing to the conf file.

        Raises:
            ConfKeySyntaxError: Conf key has failed validation
            ConfValueSyntaxError: Conf value has failed validation

        Returns:
            str: A string representation of the key/value pair in the format "key = value".
        """
        # print(
        #     "WARNING - we are lacking conf key/value checks here. "
        #     "This warning will remain until the appropriate checks are added. "
        #     "Consider whether this will be done when the key/value pair is added as "
        #     "well instead of just at serialization time."
        # )

        return f"{self.conf_key} = {self.value}"

    def __hash__(self) -> int:
        """Returns a hash of the conf key.

        Returns:
            int: Hash of the conf key
        """
        return hash((self.conf_key,))

    def __eq__(self, other: object) -> bool:
        """Determines if two ConfLine objects are equal based on their key.

        This function does not take into  account the value or sourceObject.
        The CANNOT be two ConfLines that have the same key in the same ConfStanza.

        Args:
            other (object): The object to compare against

        Returns:
            bool: True if the objects are equal, False otherwise.
        """
        if isinstance(other, ConfLine):
            return self.conf_key == other.conf_key

        return False

    def __lt__(self, other: object) -> bool:
        """Determine lexicographical order of two ConfLine objects based on their key.

        Args:
            other (object): Object to compare agianst

        Raises:
            NotImplementedError: If the other object is not a ConfLine

        Returns:
            bool: True if this key is less than the other key, False otherwise.
        """
        if isinstance(other, ConfLine):
            return self.conf_key < other.conf_key
        raise (
            NotImplementedError(
                f"Cannot compare ConfLine with non-ConfLine object of type {type(other)}"
            )
        )

    def generate_jinja2_template(self) -> str:
        """Generates a Jinja2 template string for the ConfLine object.

        This is useful for rendering the ConfLine in a Jinja2 template.
        It also serves a useful documentation purpose, and enables dynamic template
        generation which is useful for documentation purposes as well as use
        in other tools

        TODO: This function is currently not used in the codebase.
        Discuss with threat research team whether or not generation of Jinja2
        templates for the sake of easily understanding stanza
        format/documentation is valuable. As context, legacy contentctl
        used Jinja2 templates for generating conf files. Given the conditional
        complexity of Conf files, this is likely not useful at scale.

        Returns:
            str: A Jinja2 template string representing the ConfLine. If a a description of the field
            was provided, it will be included as a comment in the template.
        """
        commentLine = f"{{# {self.description} #}}\n" if self.description else ""
        kv_line = f"{self.conf_key} = {{{{ {type(self.sourceObject).__name__}.{self.object_key} }}}}"
        return f"{commentLine}{kv_line}"


class ConfStanza(BaseModel):
    """This class is a basis for a conf stanza.

    It will include logic for serializing
    key/value pairs to a conf file. It will also include logic (eventually) for
    deserializaing kev/value pairs from a conf file into Python objects
    """

    name: str = Field(description="The name of the stanza in the conf file.")
    lines: set[ConfLine] = Field(
        default_factory=set,
        description="This is a list of key value pairs that are part of the stanza. Each key value pair is a Conf_Key_Value object.",
    )

    def add_line(
        self,
        sourceObject: object,
        conf_key: str,
        object_key: str | None = None,
        description: str | None = None,
    ) -> None:
        """Adds a key/value pair to the stanza.

        Args:
            sourceObject (object): The source object is the underling object
            we will extract the associated value from.
            conf_key (str): The key in the key/value pair.
            object_key (str | None): The key that is used to identify the field in
            the object. If None, the conf_key will be used.
            description (str | None): An optional description for the key/value pair.

        Raises:
            DuplicateConfKeyError: If the key already exists in the stanza,
            the function will raise a DuplicateConfKeyError. We should not allow
            duplicate keys in a stanza.

        Returns:
            None: This function does not return anything.
        """
        if any(kv.conf_key == conf_key for kv in self.lines):
            raise DuplicateConfKeyError(
                f"Key '{conf_key}' already exists in stanza [{self.name}]"
            )

        if object_key is None:
            object_key = conf_key

        # Throw an error if th key for an object contains a dot,
        # because it is invalid.
        if "." in object_key:
            raise ObjectKeySyntaxError(
                f"Object key '{object_key}' contains a dot which cannot "
                "be used in the name of an object property."
            )

        self.lines.add(
            ConfLine(
                sourceObject=sourceObject,
                conf_key=conf_key,
                object_key=object_key,
                description=description,
            )
        )

    @classmethod
    def parse_stanza(cls, raw_data: str) -> ConfStanza:
        """Parse a raw string into a ConfStanza Object.

        Args:
            raw_data (str): raw data representing a conf stanza.

        Raises:
            NotImplementedError: This method is not yet implemented.

        Returns:
            ConfStanza: A ConfStanza object representing the parsed data.
        """
        raise NotImplementedError("This method is not yet implemented.")

    def serialize_to_stanza(self) -> str:
        """Serializes the ConfStanza object into a string.

        If desired, this string can be written to a conf file.

        Returns:
            str: A string representation of the ConfStanza object. The stanza will ALWAYS end in a single newline character.
        """
        stanza_header = f"[{self.name}]"
        stanza_kvs: list[str] = []
        for kv in sorted(self.lines):
            stanza_kvs.append(kv.serialize_to_conf_format())

        joined_kvs = "\n".join(stanza_kvs)

        return f"{stanza_header}\n{joined_kvs}\n"

    def __hash__(self) -> int:
        """Generate a hash for this object.

        Returns:
            int: Hash of the object
        """
        return hash((self.name,))

    def generate_jinja2_template(self) -> str:
        """Generates a Jinja2 template string for the ConfStanza object.

        This is useful for rendering the ConfStanza in a Jinja2 template.
        It also serves a useful documentation purpose, and enables dynamic template
        generation which is useful for documentation purposes as well as use
        in other tools

        Returns:
            str: A Jinja2 template string representing the ConfStanza.
        """
        stanza_header = f"[{self.name}]\n"
        kv_lines = [line.generate_jinja2_template() for line in sorted(self.lines)]
        return stanza_header + "\n".join(kv_lines)


class ConfFile(BaseModel):
    """This class is a basis for a conf file.

    It will include logic for serializing
    key/value pairs to a conf file. It will also include logic (eventually) for
    deserializaing key/value pairs from a conf file into Python objects
    """

    directory_path: DirectoryPath = Field(
        description="The path to the directory where the conf file is located. "
        "Note that the directory path MUST exist when generating the conf file object."
    )
    file_name: str = Field(
        description="The name of the conf file. This must not include any directory information "
        "and must end in .conf. The file must not already exist in the directory. "
        "This matches any filename which ends in .conf and does not include a subdirectory.",
        pattern=r"^[^\/]+\.conf$",
    )
    app_settings: CustomAppSettings = Field(
        description="The app that this conf file belongs to. This is used to provide "
        "context for the comment section of the file. Note that it is possible for a single"
        "conf file to have multiple comments, since it might be composed of multiple "
        "underling apps."
    )
    stanzas: set[ConfStanza] = Field(
        default_factory=set, description="A set of stanzas in the conf file."
    )

    @computed_field
    @property
    def comment(self) -> str:
        """Returns a comment that can be used to describe the conf file.

        It is used to provide context for the conf file and can be used to explain
        the purpose of the conf file or any other relevant information. It also
        provides traceability for how, and when, the conf file was generated.

        Returns:
            str: A comment that describes the conf file.
        """
        return (
            """#############\n"""
            f"""# Automatically generated by https://github.com/splunk/contentctl-ng v{importlib.metadata.version("contentctl_ng")}\n"""
            f"""# On Date: {self.app_settings._build_time} UTC\n"""
            f"""# Author: {self.app_settings.author}\n"""
            f"""# Contact: {self.app_settings.author_email}\n"""
            """#############\n\n"""
        )

    def add_stanza(self, stanza: ConfStanza) -> None:
        """Add a new stanza to the conf file.

        Args:
            stanza (ConfStanza): The stanza to add to the conf file.

        Raises:
            ConfDuplicateStanzaError: This stanza already exists in the conf file.
            Duplicate stanzas are not allowed.
        """
        if stanza in self.stanzas:
            raise ConfDuplicateStanzaError(
                f"Stanza [{stanza.name}] already exists in conf file '{self.file_name}'"
            )

        self.stanzas.add(stanza)

    def serialize_to_string(self) -> str:
        """Serialize the entire conf file to a string.

        All stanzas are sorted alphabetically by stanza name to
        improve readability and diffability of the conf file.

        Returns:
            str: The entire conf file as a string.
        """
        # Sort all the keys alphabetically by stanza name to improve readability of the conf file.
        serialized_stanzas = [
            stanza.serialize_to_stanza()
            for stanza in sorted(self.stanzas, key=lambda s: s.name)
        ]

        return self.comment + "\n".join(serialized_stanzas)

    def serialize_to_file(self) -> None:
        """Write out the conf file to the corresponding file.

        The after affect of this function will be the existinace
        of the conf file on disk
        """
        self.directory_path.mkdir(parents=True, exist_ok=True)
        file_contents = self.serialize_to_string()
        full_path = self.directory_path / self.file_name
        with open(full_path, "w") as f:
            f.write(file_contents)
            logger.info(f"Conf file written to {full_path}")


class ReloadSetting(StrEnum):
    """This enum represents the possible values for the reload setting in an app.conf file."""

    simple = "simple"
    never = "never"


class AppDotConf(ConfFile):
    """This class represents an app.conf file."""

    file_name: str = "app.conf"

    @computed_field
    @property
    def install_stanza(self) -> ConfStanza:
        """Generat the install stanza."""
        stanza = ConfStanza(name="install")
        stanza.add_line(self, "is_configured")
        stanza.add_line(self, "state")
        stanza.add_line(self, "state_change_requires_restart")
        stanza.add_line(self, "build")
        return stanza

    @computed_field
    @property
    def is_configured(self) -> bool:
        """Generate the is_configured value."""
        return False

    @computed_field
    @property
    def state(self) -> str:
        """Generate the state value."""
        return "enabled"

    @computed_field
    @property
    def state_change_requires_restart(self) -> bool:
        """Generate the state_change_requires_restart value."""
        return False

    @computed_field
    @property
    def build(self) -> int:
        """Generate the build value."""
        return self.app_settings._build_time

    @computed_field
    @property
    def triggers_stanza(self) -> ConfStanza:
        """Generate the triggers stanza."""
        stanza = ConfStanza(name="triggers")
        stanza.add_line(self, "reload.analyticstories", "reload_analyticstories")
        stanza.add_line(self, "reload.content-version", "reload_content_version")
        stanza.add_line(self, "reload.es_investigations", "reload_es_investigations")
        return stanza

    @computed_field
    @property
    def reload_analyticstories(self) -> ReloadSetting:
        """Generate the reload_analyticstories values."""
        return ReloadSetting.simple

    @computed_field
    @property
    def reload_content_version(self) -> ReloadSetting:
        """Generate the reload_content_version value."""
        return ReloadSetting.simple

    @computed_field
    @property
    def reload_es_investigations(self) -> ReloadSetting:
        """Generate the reload_es_investigations value."""
        return ReloadSetting.simple

    @computed_field
    @property
    def launcher_stanza(self) -> ConfStanza:
        """Generate the launcher stanza."""
        stanza = ConfStanza(name="launcher")
        stanza.add_line(self.app_settings, "author")
        stanza.add_line(self.app_settings, "version", "app_version")
        stanza.add_line(self.app_settings, "description", "description")
        return stanza

    @computed_field
    @property
    def ui_stanza(self) -> ConfStanza:
        """Generate the ui stanza."""
        stanza = ConfStanza(name="ui")
        stanza.add_line(self, "is_visible")
        stanza.add_line(self.app_settings, "label")
        return stanza

    @computed_field
    @property
    def is_visible(self) -> bool:
        """Generate the is_visible value."""
        return True

    @computed_field
    @property
    def package_stanza(self) -> ConfStanza:
        """Generate the package stanza."""
        stanza = ConfStanza(name="package")
        stanza.add_line(self.app_settings, "id")
        stanza.add_line(self, "check_for_updates")
        return stanza

    @computed_field
    @property
    def check_for_updates(self) -> bool:
        """Generate the check_for_updates value."""
        return True

    @computed_field
    @property
    def id_stanza(self) -> ConfStanza:
        """Generate the id stanza."""
        stanza = ConfStanza(name="id")
        stanza.add_line(self.app_settings, "version", "app_version")
        stanza.add_line(self.app_settings, "name", "id")
        return stanza

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, context: Any) -> None:
        """Construct the app.conf file stanza(s)."""
        self.add_stanza(self.install_stanza)
        self.add_stanza(self.triggers_stanza)
        self.add_stanza(self.launcher_stanza)
        self.add_stanza(self.ui_stanza)
        self.add_stanza(self.package_stanza)
        self.add_stanza(self.id_stanza)
        self.serialize_to_file()


class DistSearchDotConf(ConfFile):
    """Model for generating the distsearch.conf file."""

    file_name: str = "distsearch.conf"

    @computed_field
    @property
    def exclude_apps_appname_lookups(self) -> str:
        """Generate the excludeESCU value."""
        return f"apps[/\\]{self.app_settings.id}[/\\]lookups[/\\]..."

    @computed_field
    @property
    def replicationDenylist_stanza(self) -> ConfStanza:
        """Generate the replicationDenyList stanza."""
        stanza = ConfStanza(name="replicationDenylist")
        stanza.add_line(self, "exclude_apps_appname_lookups")

        return stanza

    @computed_field
    @property
    def replicate_analytic_stories(self) -> bool:
        """Generate the replicate_analytic_stories value."""
        return False

    @computed_field
    @property
    def replicationSettings_refineConf_stanza(self) -> ConfStanza:
        """Generate the replicationSettings:refineConf stanza."""
        stanza = ConfStanza(name="replicationSettings:refineConf")
        stanza.add_line(
            self, "replicate.analytic_stories", "replicate_analytic_stories"
        )
        return stanza

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, context: Any) -> None:
        """Construct the distsearch.conf file stanza(s)."""
        self.add_stanza(self.replicationSettings_refineConf_stanza)
        self.add_stanza(self.replicationDenylist_stanza)


class ContentVersionDotConf(ConfFile):
    """Model for generating the content-version.conf file."""

    file_name: str = "content-version.conf"

    @computed_field
    @property
    def content_version_stanza(self) -> ConfStanza:
        """Generate the content-version stanza."""
        stanza = ConfStanza(name="content-version")
        stanza.add_line(self.app_settings, "version", "app_version")
        return stanza

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, context: Any) -> None:
        """Construct the content-version.conf file stanza(s)."""
        self.add_stanza(self.content_version_stanza)


class ServerDotConf(ConfFile):
    """Model for generating the server.conf file."""

    file_name: str = "server.conf"

    @computed_field
    @property
    def conf_replication_include_analyticstories(self) -> bool:
        """Generate the conf_replication_include.analyticstories value."""
        return True

    @computed_field
    @property
    def conf_replication_include_content_version(self) -> bool:
        """Generate the conf_replication_include_content_version value."""
        return True

    @computed_field
    @property
    def conf_replication_include_es_investigations(self) -> bool:
        """Generate the conf_replication_include_es_investigations value."""
        return True

    @computed_field
    @property
    def shclustering_stanza(self) -> ConfStanza:
        """Generate the shclustering stanza."""
        stanza = ConfStanza(name="shclustering")
        stanza.add_line(
            self,
            "conf_replication_include.analyticstories",
            "conf_replication_include_analyticstories",
        )
        stanza.add_line(
            self,
            "conf_replication_include.content-version",
            "conf_replication_include_content_version",
        )
        stanza.add_line(
            self,
            "conf_replication_include.es_investigations",
            "conf_replication_include_es_investigations",
        )

        return stanza

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, context: Any) -> None:
        """Construct the server.conf file stanza(s)."""
        self.add_stanza(self.shclustering_stanza)
