"""This module contains information supporting Dashboard objects."""

import json
from enum import StrEnum
from pathlib import Path
from string import Template
from typing import Any, ClassVar

from pydantic import Field, PrivateAttr, computed_field

from contentctl_ng.objects.content import ContentEnum, SecurityContent, SupportingFile


class DashboardTheme(StrEnum):
    """The theme to use for the dashboard."""

    LIGHT = "light"
    DARK = "dark"


DASHBOARD_TEMPLATE_STRING = Template("""<dashboard version="2" theme="${dashboard_theme}">
    <label>${dashboard_name}</label>
    <description></description>
    <definition><![CDATA[
${dashboard_pretty_json}
    ]]></definition>
    <meta type="hiddenElements"><![CDATA[
{
    "hideEdit": false,
	"hideOpenInSearch": false,
	"hideExport": false
}
    ]]></meta>
</dashboard>""")


class DashboardJSONFile(SupportingFile):
    """Represents a Dashboard JSON file object."""

    name: str = Field(description="The name of the dashboard, NOT the filename.")
    # All dashboard JSON files MUST end in .json.
    # This is used for calculating their names as well
    # as the fact that they are allowed to be in the dashboards/ folder.
    _content_file_suffix: ClassVar[str] = ".json"

    @computed_field
    @property
    def content(self) -> str:
        """Return the content of the dashboard file.

        This file will be written out as an XML file.
        """
        # Get the raw text of the dashboard file
        raw_text = self.input_path.read_text()
        json_obj = json.loads(raw_text)

        return DASHBOARD_TEMPLATE_STRING.substitute(
            dashboard_theme=DashboardTheme.LIGHT,
            dashboard_name=self.name,
            dashboard_pretty_json=json.dumps(json_obj, indent=2),
        )


class Dashboard(SecurityContent):
    """Represents a Dashboard object.

    Dashboards are used to visualize data in a way that is easy to understand.
    They are built in product using the Dashboard Editor/Creator:
    https://help.splunk.com/en/splunk-enterprise/create-dashboards-and-reports/simple-xml-dashboards/10.0/introduction/getting-started

    These dashboards are then exported from the product as *.json files.
    """

    # All dashboards require a corresponding JSON file that actually
    # defines the content of the Dashboard
    _supporting_file: DashboardJSONFile = PrivateAttr()

    # The directories that contain dashboard YML definitions
    # may (or more accurately MUST) also contain JSON
    # files.
    _other_allowed_file_suffixes: ClassVar[list[str]] = [
        DashboardJSONFile._content_file_suffix
    ]

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context__: Any) -> None:
        """Forces the setting of special fields _repo and _path.

        This also ensures the existence of the relevant json file.

        Args:
            __context__ (Any): The context dictionary that
            contains the _repo and _path fields.

        Raises:
            ValueError: If __context__ is not a dictionary.
            ValueError: If _path is not present in __context__.
            ValueError: If _repo is not present in __context__.
            FileNotFoundError: If the JSON file does not exist.
        """
        # Super method already checks to ensure that context is a dict
        super().model_post_init(__context__)

        # Dashboard file must have exactly the same name as the lookup,
        # with the exception that the file extensions must be csv.
        # The output file must be an xml file with some substitutions.
        label = self._content_dir.app_settings.content_prefix
        stem = self._path.stem
        output_filename = f"{label}__{stem}.xml".lower().replace(" ", "_")

        self._supporting_file = DashboardJSONFile(
            input_path=self._path.with_suffix(DashboardJSONFile._content_file_suffix),
            name=self.name,
            output_path=f"default/data/ui/views/{output_filename}",
        )

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the dashboards directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("dashboards")

    @computed_field
    @property
    def stanza_name(self) -> str:
        """WARNING - Produces an exception since Dashboards cannot be serialized to a conf file.

        Since this method is an abstract_method for EVERY conf file, we must also declare
        it here, even though Dashboards cannot be serialized to a conf file. Therefore,
        they do not have a stanza_name.
        This will always raise an Exception, but it still makes sense to have
        this method be defined as abstract in SecurityContent.

        Raises:
            NotImplementedError: Always raised since dashboards cannot be serialized to a conf file.


        """
        raise NotImplementedError(
            "Cannot serialize Dashboard Stanza Name. Dashboards cannot be serialized to a conf file."
        )

    @classmethod
    def update_dynamic_status(cls, content: list[Dashboard]) -> None:
        """Update the dynamic enum for the dashboards."""
        DashboardEnum.__update_everything_dangerous__(DashboardEnum, content)


class DashboardEnum(ContentEnum):
    """Empty Placeholder Enum for dashboards.

    NOTE: This enum is dynamically populated at runtime by the Dashboard.UpdateDynamicEnum method.
    """

    pass
