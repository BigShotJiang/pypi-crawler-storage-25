"""Module for parsing the atomic-red-team index file."""

import logging
import uuid
from enum import StrEnum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from contentctl_ng.utilities.common_io import fetch_file_data_from_url_with_fallback

logger = logging.getLogger(__name__)

ATOMIC_RED_TEAM_INDEX_URL = "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/refs/heads/master/atomics/Indexes/index.yaml"
# The following file may be placed in the directory where contentctl-ng is run so that, even if there
# ar issues downloading the file above, contentctl-ng can still run. This removes internet access
# as a strict requirement for contentctl-ng and provides a minor speedup during operations.
ATOMIC_RED_TEAM_INDEX_URL_FALLBACK_PATH = Path("ART_index_fallback.yml")


class AtomicRedTeamAtomicTest(BaseModel):
    """Represents a single atomic test in the index file.

    While this object contains significant information relevant to actually
    executing a test such as description, commands, dependencies, etc, the
    only portion relevant to us at this time is the auto_generated_guid.
    This is all we require as we use it for validation when these
    atomic_guids are referenced in security_content searches/detections.
    """

    model_config = ConfigDict(extra="ignore")
    name: str = Field(description="The name of the atomic test.")
    auto_generated_guid: uuid.UUID = Field(
        description="The auto-generated GUID for the atomic test."
    )


class AtomicRedTeamMitreTactic(BaseModel):
    """Represents a MITRE tactic list index the index file.

    This object contains a list of atomic tests for a specific MITRE tactic.
    While we don't really care about this category and only care about the
    auto_generated_guids of the tests it contains, we must define this for
    the sake of parsing logic.
    """

    model_config = ConfigDict(extra="ignore")
    atomic_tests: list[AtomicRedTeamAtomicTest] = Field(
        description="List of atomic tests for this tactic.", default_factory=list
    )


class AtomicRedTeamIndex(BaseModel):
    """Represents the atomic-red-team index file.

    This is a large JSON file hosted in the AtomicRedTeam Repo.
    We define the structure here to enable use to parse the file,
    ultimately, into AtomicRedTeamAtomicTests so that we can pull
    out their auto_generated_guid fields for use in validating to
    atomic_guids: field of Search/Detection content.
    """

    model_config = ConfigDict(extra="forbid")

    # This was removed in MITRE ATT&CK v19.0.  We include it here, commented out,
    # intentionally for documentation purposes
    # defense_evasion: dict[str, AtomicRedTeamMitreTactic] = Field(
    #     description="List of all defense evasion tactics.", alias="defense-evasion"
    # )

    # This field was added in MITRE ATT&CK v19.0
    stealth: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all stealth tactics.", alias="stealth"
    )
    # This field was added in MITRE ATT&CK v19.0
    defense_impairment: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all defense impairment tactics.",
        alias="defense-impairment",
    )

    privilege_escalation: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all privilege escalation tactics.",
        alias="privilege-escalation",
    )
    execution: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all execution tactics.", alias="execution"
    )
    persistence: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all persistence tactics.", alias="persistence"
    )
    command_and_control: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all command and control tactics.",
        alias="command-and-control",
    )
    collection: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all collection tactics.", alias="collection"
    )
    lateral_movement: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all lateral movement tactics.", alias="lateral-movement"
    )
    credential_access: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all credential access tactics.", alias="credential-access"
    )
    discovery: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all discovery tactics.", alias="discovery"
    )
    resource_development: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all resource development tactics.",
        alias="resource-development",
    )
    reconnaissance: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all reconnaissance tactics.", alias="reconnaissance"
    )
    impact: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all impact tactics.", alias="impact"
    )
    initial_access: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all initial access tactics.", alias="initial-access"
    )
    exfiltration: dict[str, AtomicRedTeamMitreTactic] = Field(
        description="List of all exfiltration tactics.", alias="exfiltration"
    )

    # This is the set of guids that have been parsed from all atomic tests. At this time, this
    # is the only aspect of the Atomic Red Team Data that we use from a validation perspective.
    # This may change in the future, but no need to do extra work at this time.
    _auto_generated_guid_set: frozenset[uuid.UUID] = PrivateAttr()

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context: None = None) -> None:
        """Set _auto_generate_guid field values.

        Args:
            __context (None, optional): This is the default signature
            for model_post_init, but context SHOULD NOT be used in this
            function. Defaults to None.

        Raises:
            ValueError: If a duplicate auto generated guid is found.
        """
        auto_generated_guid_list: list[uuid.UUID] = []

        for category in [
            self.privilege_escalation,
            self.execution,
            self.persistence,
            self.command_and_control,
            self.collection,
            self.lateral_movement,
            self.credential_access,
            self.discovery,
            self.resource_development,
            self.reconnaissance,
            self.impact,
            self.initial_access,
            self.exfiltration,
            self.stealth,
            self.defense_impairment,
        ]:
            for tactic in category.values():
                for atomic_test in tactic.atomic_tests:
                    auto_generated_guid_list.append(atomic_test.auto_generated_guid)

        self._auto_generated_guid_set = frozenset(auto_generated_guid_list)
        # The index file intentionally contains duplicate guids since tests are repeated.
        # This is because a single atomic may cover multiple MITRE tactics.

    @classmethod
    def parse_art_url_to_enum(
        cls, FALLBACK_PATH: Path = ATOMIC_RED_TEAM_INDEX_URL_FALLBACK_PATH
    ) -> AtomicRedTeamIndex:
        """Parse the atomic-red-team index file from the URL and return an ART_Index object.

        Args:
            FALLBACK_PATH (Path, optional): Path to the fallback file that can be included,
            but that must be manually downloaded and placed there by a user of contentctl-ng.
            Defaults to Path("ART_index_fallback.yml").

        Returns:
            None: Nothing is returned, but the AtomicGuidEnum is populated

        Raises:
            Exception: If the atomic-red-team index file cannot be fetched or parsed. There
            is a fallback file that can be included, but that must be manually downloaded and
            placed there by a user of contentctl-ng
        """
        try:
            logger.info("Fetching the latest atomic-red-team data.")
            art_index_data_bytes: bytes = fetch_file_data_from_url_with_fallback(
                ATOMIC_RED_TEAM_INDEX_URL, FALLBACK_PATH
            )

            art_index_data_str: str = art_index_data_bytes.decode("utf-8")

            art_index_data: dict[str, Any] = yaml.load(
                art_index_data_str, Loader=yaml.CSafeLoader
            )
            art_index_object = AtomicRedTeamIndex.model_validate(art_index_data)

            newEnum = StrEnum(
                "tempEnum",
                [(str(x), str(x)) for x in art_index_object._auto_generated_guid_set],
            )
            AtomicGuidEnum._member_map_.update(newEnum._member_map_)
            AtomicGuidEnum._member_names_.extend(newEnum._member_names_)
            AtomicGuidEnum._value2member_map_.update(newEnum._value2member_map_)

            return art_index_object
        except Exception as e:
            # TODO: Implement Exception-type specific error handling, where appropriate, for specific exceptions
            # we feel to be likely.  Instead of trying to capture generic exceptions, let them fall back to
            # the highest level error handler (such as at the CLI level).

            raise Exception(
                f"Failed to fetch atomic-red-team index file or failure during parsing: {e!s}"
            )


class AtomicGuidEnum(StrEnum):
    """Enum of all atomic guids.

    NOTE: This enum is dynamically populated at runtime.
    """

    pass
