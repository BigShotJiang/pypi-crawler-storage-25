"""This module contains information supporting Analytic Story objects."""

from pathlib import Path
from typing import Annotated

from cron_validator import CronValidator
from pydantic import BaseModel, Field, computed_field, field_validator

from contentctl_ng.objects.content import ContentEnum, SecurityContent

# The time format is defined in the following Splunk Documentation:
# https://help.splunk.com/en/splunk-enterprise/search/spl-search-reference/9.4/time-format-variables-and-modifiers/time-modifiers
# This format is VERy challenging to validate with a regex.
# We have intentionally constrained this format - if this format must be expanded or improved,
# please reach out to the contentctl-ng maintainers.
"""
SPLUNK_SPECIFIC_TIME_AMOUNTS = (
    r"("
    r"us|ms|cs|ds|"
    r"s|sec|secs|second|seconds|"
    r"m|min|minute|minutes|"
    r"h|hr|hrs|hour|hours|"
    r"d|day|days|"
    r"w|week|weeks|"
    r"mon|month|months|"
    r"q|qtr|qtrs|quarter|quarters|"
    r"y|yr|yrs|year|years"
    r")"
)
"""
CONSTRAINED_SPLUNK_SPECIFIC_TIME_AMOUNTS = r"(s|m|h|d|w|mon|q|y)"
SPLUNK_RELATIVE_TIME_TYPE = Annotated[
    str,
    Field(
        pattern=r"^[+-]\d+"
        + CONSTRAINED_SPLUNK_SPECIFIC_TIME_AMOUNTS
        + r"(@"
        + CONSTRAINED_SPLUNK_SPECIFIC_TIME_AMOUNTS
        + r")?$"
    ),
]

SPLUNK_SCHEDULE_WINDOW_TYPE = Annotated[str, Field(pattern=r"^(auto|\d+)$")]


class Schedule(BaseModel):
    """This class defines an inline schedule.

    Since this is not an object tracked in the content repository,
    it is not a SecurityContent object. This means it lacks certain
    fields like name, description, uuid, etc.
    """

    cron_schedule: str = Field(
        description="The cron schedule for the schedule.  "
        "Validating this with a regex (and JsonSchema) is extremely difficult, "
        "so this is intentionally validated with a field_validator function."
    )
    schedule_window: SPLUNK_SCHEDULE_WINDOW_TYPE = Field(
        description="The schedule window to use for the search. "
        "It is highly recommended to use 'auto' for this field. "
        "Alternatively, an integer may be used according to the "
        "following documentation: "
        "https://docs.splunk.com/Documentation/Splunk/9.4.2/Admin/Savedsearchesconf"
    )

    earliest_time: SPLUNK_RELATIVE_TIME_TYPE = Field(
        description="Beginning of the time window to search against. "
        "Note that this is artificially constrained from the broader set of time "
        "values available here: "
        "https://help.splunk.com/en/splunk-cloud-platform/search/spl2-search-manual/dates-and-time/specifying-relative-time. "
        "Please contact the contentctl-ng team if additional time formats must be supported."
    )
    latest_time: SPLUNK_RELATIVE_TIME_TYPE = Field(
        description="End of the time window to search against. "
        "Note that this is artificially constrained from the broader set of time "
        "values available here: "
        "https://help.splunk.com/en/splunk-cloud-platform/search/spl2-search-manual/dates-and-time/specifying-relative-time. "
        "Please contact the contentctl-ng team if additional time formats must be supported."
    )

    @field_validator("cron_schedule")
    def validate_cron_schedule(cls, v: str) -> str:
        """Validate that the cron expression is well-formed.

        Args:
            v (str): cron expression to validate

        Raises:
            ValueError: if the cron expression is not well-formed

        Returns:
            str: the cron expression if it is well-formed
        """
        try:
            CronValidator.parse(v)
            return v
        except ValueError:
            raise ValueError(
                f"Invalid cron schedule {v}. "
                "Try checking this against https://crontab.guru/ for help"
            )

    @computed_field
    @property
    def digest_mode(self) -> bool:
        """Return the digest mode for this schedule."""
        return True

    @computed_field
    @property
    def disabled(self) -> bool:
        """Return the disabled flag for this schedule."""
        return True

    @computed_field
    @property
    def enableSched(self) -> bool:
        """Return the enableSched flag for this schedule."""
        return True

    @computed_field
    @property
    def allow_skew(self) -> str:
        """Return the allow_skew flag for this schedule."""
        return "100%"

    @computed_field
    @property
    def counttype(self) -> str:
        """Return the counttype flag for this schedule."""
        return "number of events"

    @computed_field
    @property
    def relation(self) -> str:
        """Return the relation flag for this schedule."""
        return "greater than"

    @computed_field
    @property
    def quantity(self) -> int:
        """Return the quantity flag for this schedule."""
        return 0

    @computed_field
    @property
    def realtime_schedule(self) -> bool:
        """Return the realtime_schedule flag for this schedule."""
        return False

    @computed_field
    @property
    def is_visible(self) -> bool:
        """Return the is_visible flag for this schedule."""
        return False


class FilebackedSchedule(SecurityContent, Schedule):
    """Represents a Schedule object.

    This is an inline object with additional enrichments for tracking
    as a piece of content in the content repository.
    """

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the stories directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("schedules")

    @computed_field
    @property
    def stanza_name(self) -> str:
        """WARNING - Produces an exception since schedules cannot be serialized to a conf file.

        Since this method is an abstract_method for EVERY conf file, we must also declare
        it here, even though Schedules cannot be serialized to a conf file. Therefore,
        they do not have a stanza_name.
        This will always raise an Exception, but it still makes sense to have
        this method be defined as abstract in SecurityContent.

        Raises:
            NotImplementedError: Always raised since schedules cannot be serialized to a conf file.


        """
        raise NotImplementedError(
            "Cannot serialize schedule Stanza Name. schedules cannot be serialized to a conf file."
        )

    @classmethod
    def update_dynamic_status(update_dynamic_status, content: list[Schedule]) -> None:
        """Update the dynamic enum for the stories."""
        ScheduleEnum.__update_everything_dangerous__(ScheduleEnum, content)


class ScheduleEnum(ContentEnum):
    """Empty Placeholder Enum for stories.

    NOTE: This enum is dynamically populated at runtime by the Schedule.UpdateDynamicEnum method.
    """

    pass
