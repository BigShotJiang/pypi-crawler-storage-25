"""This module contains information supporting Macro objects."""

from pathlib import Path

from pydantic import BaseModel, Field, computed_field

from contentctl_ng.objects.conf import ConfStanza
from contentctl_ng.objects.content import ContentEnum, SecurityContent


class Macro(BaseModel):
    """This class defines a macro.

    Note that macros may be defined at runtime, such as _filter
    macros, or backed by YML files on disk like other content.
    For macros backed by files, please see FilebackedMacro.

    TODO: Since these Macros are defined at runtime, if a feature
    like verioning (with a requirement to have consistent metadata)
    is extended to macros, we will need to determine a way to have
    consistent fields like date/id/version etc for Macro objects
    which are defined at runtime.
    """

    name: str = Field(description="The name of the macro.")

    # At this time, nested macros are not validated at
    # Macro object validation time.
    # This would require inclusion of SPLString, which would create circular
    # import issues since SPLString also imports Macro
    # As a workaround, object_parser.py explicitly checks every macro,
    # after it has been parsed and validation, by creating and SPLString
    # from the macro.definition.

    definition: str = Field(
        description="The definition of the macro.\n"
        "WARNING - NESTED MACROS ARE NOT VALIDATED - "
        "USE THEM AT YOUR OWN RISK. ",
        min_length=1,
    )
    arguments: list[str] = Field(
        description="A list of arguments for the macro. These are the names of the "
        "arguments that are expected to be passed to the macro. Note that not every "
        "macro requires 1 or more arguments.",
        default_factory=list,
    )
    description: str = Field(
        description="The description of the macro. This can be either human-generated, "
        "in the case of FilebackedMacros, "
        "or is a static string in the case of filter macros.",
    )

    def __hash__(self) -> int:
        """Generate a hash for this object.

        Returns:
            int: The hash for this object
        """
        # Because the normal hash for content is as follows, we will return as close
        # as possible to that here.  We hardcode the id to 0 and version to 1.
        # In this way, there will be hash collisions as long if names match.

        # Hash definition for SecurityContent Object
        # return hash((self.name, self.id, self.version))
        return hash((self.name, "0", "1"))

    @classmethod
    def search_name_to_filter_macro_name(cls, search_name: str) -> str:
        """Convert a search name to a filter macro name.

        This value will be used to determine ensure that, if appropriate,
        a filter macro is present in a search. Additionally, it will be
        used for created of new filter macros at runtime.

        Args:
            search_name (str): The name of the search. Note that this
            name should NOT include the wrapper, for instance the
            search_name should be 'My Test Search' and NOT,
            'ESCU - My Test Search - Rule'

        Returns:
            str: The name of the filter macro. This is a lowercased
            string with all spaces/hyphens/periods replaced with
            underscores and a '_filter' suffix.

        """
        return (
            search_name.lower().replace(" ", "_").replace("-", "_").replace(".", "_")
            + "_filter"
        )

    @classmethod
    def generate_filter_macro_and_update_enum(
        cls,
        search_name: str,
        definition: str = "search *",
        description: str = "Update this macro to limit the output results to filter out false positives.",
        arguments: list[str] = [],
    ) -> None:
        """Generate an inline macro."""
        filter_macro = Macro(
            name=cls.search_name_to_filter_macro_name(search_name),
            definition=definition,
            arguments=arguments,
            description=description,
        )
        MacroEnum.__update_everything_dangerous__(MacroEnum, [filter_macro])

    @property
    def args(self) -> str:
        """Formats args into the format required for macros.conf.

        macros.conf requires that multiple arguments be separated by
        a comma followed by a space.
        Source: https://help.splunk.com/en/splunk-enterprise/administer/admin-manual/9.2/configuration-file-reference/9.2.6-configuration-file-reference/macros.conf

        Returns:
            str: The args formatted for macros.conf
        """
        return ", ".join(self.arguments)

    @computed_field
    @property
    def stanza_name(self) -> str:
        """Return the name of the stanza for the macro."""
        # If the macro has 0 arguments, then the name of the stanza is simply the name of the macro.
        # However, if the macro has argument(s), then the the number of arguments must be included in
        # the name of the macro. For instance:
        # [macro_with_no_args]
        # vs
        # [macro_with_three_args(3)]
        return (
            self.name if not self.arguments else f"{self.name}({len(self.arguments)})"
        )

    def emit_ConfStanza(self) -> ConfStanza:
        """Generate a ConfStanza object for the macro.

        This must be defined for Macro, rather than FilebackedMacro,
        because we must be able to generate ConfStanzas for
        objects which are missing certain fields like
        version, id, etc due to the presence of filter macros
        generated at runtime.

        Returns:
            ConfStanza: The ConfStanza object for the macro.

        """
        stanza = ConfStanza(name=self.stanza_name)
        stanza.add_line(self, "definition", "definition")
        stanza.add_line(self, "description", "description")
        if len(self.arguments):
            stanza.add_line(self, "args", "args")

        return stanza


class FilebackedMacro(Macro, SecurityContent):
    """Represents a Macro object. The macro objects are backed by YML files.

    Macros may be used in SPL searches and, if they exist in searches,
    they are found and ensured to exist at runtime validation time.

    TODO: At this time, 'nested' macros are not validated.
    This means that contentctl will not validate macros that
    are used within other macros.
    """

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the macros directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("macros")

    @classmethod
    def update_dynamic_status(cls, content: list[Macro]) -> None:
        """Update the dynamic enum for the macros."""
        MacroEnum.__update_everything_dangerous__(MacroEnum, content)

    def __hash__(self) -> int:
        """Generate a hash for this object.

        Returns:
            int: The hash for this object
        """
        return super(SecurityContent).__hash__()


class MacroEnum(ContentEnum):
    """Empty Placeholder Enum for macros.

    NOTE: This enum is dynamically populated at runtime by the Macro.UpdateDynamicEnum method.
    """

    pass
