"""This module contains information supporting Data Source objects.

TODO: The state of this object may evolve as we continue to work with
the DLX Team.  Data Sources are highly likely to become first-class
citizens in DLX and contentctl should represent them in a way that is
in line with how they will be represented in DLX to avoid costly and
complex transformations/mappings.
"""

import logging
from enum import StrEnum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, computed_field

from contentctl_ng.objects.content import ContentEnum, SecurityContent

logger = logging.getLogger(__name__)

"""
TODO: This type is not well defined or documented.
As such, it has been given an intentionally generic type.
We should seek to improve this defintion in the future.
"""
MAPPING_TYPE = dict[str, str]


class FieldMappingDataModel(StrEnum):
    """The data model for this mapping.

    For legacy reasons, the naming of this field, 'data model' is a bit
    overloaded.  'data models' here are not the same as 'CIM Data Models'.
    We anticipate that this naming may change as as certain DLX requirements
    continue to evolve.
    """

    CIM = "cim"
    OCSF = "ocsf"
    CUSTOM_CIM = "custom_cim"


class DataModelsAndSubmodels(StrEnum):
    """Non-exhaustive list of datamodels/submodels currently in use for data sources.

    TODO: Determine how we want to define all the datamodels for data_sources.
    Is All_Traffic a valid datamodel, or should it be Network_Traffic.All_Traffic?
    What about DNS vs Network_Resolution?
    This will likely come from continued discussion with the DLX team as well.
    """

    DNS = "DNS"
    All_Traffic = "All_Traffic"
    # This is only a subset of all datamodels, but it is a selection of the ones
    # that we use today.  Should we exhaustive enumerate the structures in the CIM
    # app to populate this?
    Endpoint_Processes = "Endpoint.Processes"
    Endpoint_Registry = "Endpoint.Registry"
    Endpoint_Filesystem = "Endpoint.Filesystem"
    Web = "Web"
    Change = "Change"
    Network_Traffic = "Network_Traffic"
    Network_Traffic_All_Traffic = "Network_Traffic.All_Traffic"
    Risk_All_Risk = "Risk.All_Risk"
    Network_Resolution = "Network_Resolution"
    Authentication = "Authentication"


class FieldMapping(BaseModel):
    """Represents a field mapping for a data source.

    This object uses some overloaded terminology for legacy purposes
    in the naming of the data_set vs data_model fields.

    The "mapping" object, specifically, maps a field in the raw
    data to a field in the target data_set.  For instance,
    this can be used to convert a fields in a RAW data_source
    to equivalent fields in CIM or OCSF.
    """

    model_config = ConfigDict(extra="forbid")
    data_set: None | DataModelsAndSubmodels = Field(
        description="The Common Information Model (CIM) datamodel that these fields in the mappings below map to.",
        default=None,
    )
    data_model: FieldMappingDataModel = Field(
        description="The data mode for this mapping. "
        "This is used to determine how the data should be mapped.",
    )

    mapping: MAPPING_TYPE = Field(
        description="The KEY represents the name of the field in this datasource. "
        "The VALUE represents the name of the filed in the target datasource."
    )


class ConvertToLogSource(BaseModel):
    """Represents a conversion of a data source to a log source.

    These conversions allow raw events from a given data_source to
    be converted to a another 'compatible' log source. For instance,
    this may be used to map:
    Sysmon Event ID 1
    to one of
    [Windows Event Log Security 4688, Crowdstrike Process]
    """

    model_config = ConfigDict(extra="forbid")
    data_source: str = Field(description="The data source to convert to a log source.")
    mapping: MAPPING_TYPE = Field(
        description="The KEY represents the name of the field in this datasource. "
        "The VALUE represents the name of the filed in the target datasource."
    )


class MITREComponent(StrEnum):
    """Represents a MITRE Component.

    MITRE Components are derived exhaustively from the following list:
    https://misp-galaxy.org/mitre-data-component/"

    TODO: As indicated by the print statement below, we have some annotations that
    do not exist in the list above. Should these be removed or re-mapped?
    This print out should continue to occur at runtime until we have
    resolved this TODO.
    """

    logger.warning(
        "THE MITRE COMPONENTS BELOW ARE IN DATA_SOURCE FILES TODAY,"
        "BUT ARE NOT VALID PER THE FOLLOWING LIST: https://misp-galaxy.org/mitre-data-component/"
    )
    Configuration_Modification = "Configuration Modification"
    Cloud_Service_Creation = "Cloud Service Creation"
    Scheduled_Job_Execution = "Scheduled Job Execution"
    Email_Metadata = "Email Metadata"
    Certificate_Metadata = "Certificate Metadata"
    System_Configuration_Changes = "System Configuration Changes"
    Cloud_Service_Usage = "Cloud Service Usage"
    Cloud_Service_Discovery = "Cloud Service Discovery"
    Security_Policy_Modification = "Security Policy Modification"

    # These are all proper MITRE components from https://misp-galaxy.org/mitre-data-component/
    API_Calls = "API Calls"
    Active_DNS = "Active DNS"
    Active_Directory_Credential_Request = "Active Directory Credential Request"
    Active_Directory_Object_Access = "Active Directory Object Access"
    Active_Directory_Object_Creation = "Active Directory Object Creation"
    Active_Directory_Object_Deletion = "Active Directory Object Deletion"
    Active_Directory_Object_Modification = "Active Directory Object Modification"
    Application_Assets = "Application Assets"
    Application_Log_Content = "Application Log Content"
    Certificate_Registration = "Certificate Registration"
    Cloud_Service_Disable = "Cloud Service Disable"
    Cloud_Service_Enumeration = "Cloud Service Enumeration"
    Cloud_Service_Metadata = "Cloud Service Metadata"
    Cloud_Service_Modification = "Cloud Service Modification"
    Cloud_Storage_Access = "Cloud Storage Access"
    Cloud_Storage_Creation = "Cloud Storage Creation"
    Cloud_Storage_Deletion = "Cloud Storage Deletion"
    Cloud_Storage_Enumeration = "Cloud Storage Enumeration"
    Cloud_Storage_Metadata = "Cloud Storage Metadata"
    Cloud_Storage_Modification = "Cloud Storage Modification"
    Cluster_Metadata = "Cluster Metadata"
    Command_Execution = "Command Execution"
    Container_Creation = "Container Creation"
    Container_Enumeration = "Container Enumeration"
    Container_Metadata = "Container Metadata"
    Container_Start = "Container Start"
    Domain_Registration = "Domain Registration"
    Drive_Access = "Drive Access"
    Drive_Creation = "Drive Creation"
    Drive_Modification = "Drive Modification"
    Driver_Load = "Driver Load"
    Driver_Metadata = "Driver Metadata"
    File_Access = "File Access"
    File_Creation = "File Creation"
    File_Deletion = "File Deletion"
    File_Metadata = "File Metadata"
    File_Modification = "File Modification"
    Firewall_Disable = "Firewall Disable"
    Firewall_Enumeration = "Firewall Enumeration"
    Firewall_Metadata = "Firewall Metadata"
    Firewall_Rule_Modification = "Firewall Rule Modification"
    Firmware_Modification = "Firmware Modification"
    Group_Enumeration = "Group Enumeration"
    Group_Metadata = "Group Metadata"
    Group_Modification = "Group Modification"
    Host_Status = "Host Status"
    Image_Creation = "Image Creation"
    Image_Deletion = "Image Deletion"
    Image_Metadata = "Image Metadata"
    Image_Modification = "Image Modification"
    Instance_Creation = "Instance Creation"
    Instance_Deletion = "Instance Deletion"
    Instance_Enumeration = "Instance Enumeration"
    Instance_Metadata = "Instance Metadata"
    Instance_Modification = "Instance Modification"
    Instance_Start = "Instance Start"
    Instance_Stop = "Instance Stop"
    Kernel_Module_Load = "Kernel Module Load"
    Logon_Session_Creation = "Logon Session Creation"
    Logon_Session_Metadata = "Logon Session Metadata"
    Malware_Content = "Malware Content"
    Malware_Metadata = "Malware Metadata"
    Module_Load = "Module Load"
    Named_Pipe_Metadata = "Named Pipe Metadata"
    Network_Communication = "Network Communication"
    Network_Connection_Creation = "Network Connection Creation"
    Network_Share_Access = "Network Share Access"
    Network_Traffic_Content = "Network Traffic Content"
    Network_Traffic_Flow = "Network Traffic Flow"
    OS_API_Execution = "OS API Execution"
    Passive_DNS = "Passive DNS"
    Permissions_Request = "Permissions Request"
    Permissions_Requests = "Permissions Requests"
    Pod_Creation = "Pod Creation"
    Pod_Enumeration = "Pod Enumeration"
    Pod_Metadata = "Pod Metadata"
    Pod_Modification = "Pod Modification"
    Process_Access = "Process Access"
    Process_Creation = "Process Creation"
    Process_Metadata = "Process Metadata"
    Process_Modification = "Process Modification"
    Process_Termination = "Process Termination"
    Protected_Configuration = "Protected Configuration"
    Response_Content = "Response Content"
    Response_Metadata = "Response Metadata"
    Scheduled_Job_Creation = "Scheduled Job Creation"
    Scheduled_Job_Metadata = "Scheduled Job Metadata"
    Scheduled_Job_Modification = "Scheduled Job Modification"
    Script_Execution = "Script Execution"
    Service_Creation = "Service Creation"
    Service_Metadata = "Service Metadata"
    Service_Modification = "Service Modification"
    Snapshot_Creation = "Snapshot Creation"
    Snapshot_Deletion = "Snapshot Deletion"
    Snapshot_Enumeration = "Snapshot Enumeration"
    Snapshot_Metadata = "Snapshot Metadata"
    Snapshot_Modification = "Snapshot Modification"
    Social_Media = "Social Media"
    System_Notifications = "System Notifications"
    System_Settings = "System Settings"
    User_Account_Authentication = "User Account Authentication"
    User_Account_Creation = "User Account Creation"
    User_Account_Deletion = "User Account Deletion"
    User_Account_Metadata = "User Account Metadata"
    User_Account_Modification = "User Account Modification"
    Volume_Creation = "Volume Creation"
    Volume_Deletion = "Volume Deletion"
    Volume_Enumeration = "Volume Enumeration"
    Volume_Metadata = "Volume Metadata"
    Volume_Modification = "Volume Modification"
    WMI_Creation = "WMI Creation"
    Web_Credential_Creation = "Web Credential Creation"
    Web_Credential_Usage = "Web Credential Usage"
    Windows_Registry_Key_Access = "Windows Registry Key Access"
    Windows_Registry_Key_Creation = "Windows Registry Key Creation"
    Windows_Registry_Key_Deletion = "Windows Registry Key Deletion"
    Windows_Registry_Key_Modification = "Windows Registry Key Modification"


class TA(BaseModel):
    """Represents a TA object that is required to process this data source.

    This TA, and its specific version, are what the test environment
    should use for testing purposes.  Content must be tested against
    specific, known versions of given apps/TAs.

    TODO: Is there any additional information that we want to include here?
    Or do we want to enrich it further with even more information?  A simple
    API endpoint that provides lots of Splunkbase infromation is:
    https://cdn.splunkbase.splunk.com/public/report/apps_dump.json
    Which could be used for quick/immediate validations.

    TODO: Do we need to support "local" apps in data sources that are
    NOT available/validatable via Splunkbase?
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    name: str = Field(
        description="The name of the TA. In proper Splunkbase Terminology, "
        "this is the 'title' of the app."
    )
    url: HttpUrl = Field(
        description="The URL of the TA. For instance, for the Microsoft Sysmon TA"
        " this would be https://splunkbase.splunk.com/app/5709/."
    )
    version: str = Field(
        description="The version of the TA. While most things on "
        "Splunkbase are Semantic Versioned, this is not a strict requirement. "
        "Via the API at https://splunkbase.splunk.com/app/5709/, "
        "this falls under the releases[0][title] field."
    )


class DataSource(SecurityContent):
    """Represents a DataSource object.

    DataSources are highly specific, raw data that can power detections in ESCU.
    They are far more specific than mapping to a specific Data Model.  For example,
    an Endpoint.Processes mapping Data Model mapping does not account for whether
    a detection only works on Windows, Linux, macOS, or another platform.  But a
    DataSource mapping to 'Windows Sysmon EventID 1' for instance, is VERY specific
    and gives high confidence of the EXACT data a detection should work against.
    """

    mitre_components: list[MITREComponent] = Field(
        default_factory=list,
        description="The list of MITRE components that this data is related to.",
    )

    source: str = Field(description="The Splunk 'source' field for this data.")
    sourcetype: str = Field(description="The Splunk 'sourcetype' field for this data.")
    separator: str | None = Field(
        description="The separator used to parse the data.", default=None
    )
    separator_value: None | str = None
    configuration: Optional[str] = None
    supported_TA: list[TA] = Field(
        description="The list of Splunk TA(s) that can parse this data. "
        "It is STRONGLY suggested to include at least 1 TA here, however "
        "some raw data does not have a supporting TA to parse it. "
        "In that case, it is acceptable not to populate this list.",
        default_factory=list,
    )
    fields: None | list[str] = Field(
        default=None,
        description="The list of fields in this data. While populating this "
        "list is STRONGLY suggested, it is not required.",
    )

    output_fields: list[str] = []

    field_mappings: None | list[FieldMapping] = Field(
        default=None,
        description="The list of mappings from this type of data to another "
        "type of data such as cim or OCSF.",
    )

    convert_to_log_source: list[ConvertToLogSource] = []

    example_log: None | str = Field(
        description="An example log for this data. This is helpful, "
        "additional documentation so that users can immedaitely "
        "understand what the raw data looks like.",
        default=None,
    )

    @classmethod
    def content_folder(self) -> Path:
        """Return the path to the data sources directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("data_sources")

    @computed_field
    @property
    def stanza_name(self) -> str:
        """WARNING - Produces an exception since data_source cannot be serialized to a conf file.

        Since this method is an abstract_method for EVERY conf file, we must also declare
        it here, even though DataSources cannot be serialized to a conf file. Therefore,
        they do not have a stanza_name.
        This will always raise an Exception, but it still makes sense to have
        this method be defined as abstract in SecurityContent.

        Raises:
            NotImplementedError: Always raised since data_source cannot be serialized to a conf file.


        """
        raise NotImplementedError(
            "Cannot serialize data_source Stanza Name. data_source cannot be serialized to a conf file."
        )

    @classmethod
    def update_dynamic_status(cls, content: list[DataSource]) -> None:
        """Update the dynamic enum for the data sources."""
        DataSourceEnum.__update_everything_dangerous__(DataSourceEnum, content)

    @computed_field
    @property
    def research_site_path(self) -> str:
        """Return the path of this object."""
        return f"sources/{self._path.stem}"

    @computed_field
    @property
    def datasource_csv_row(self) -> dict[str, str]:
        """Generate a dict of values required for building the datasource csv.

        Returns:
            dict[str,Any]: A dict of values required for building the datasource csv
        """
        return {
            "name": self.name,
            "id": self.id,
            "author": self.author,
            "source": self.source,
            "sourcetype": self.sourcetype,
            "separator": self.separator
            or "",  # separator is optional, so if it is not set, use an empty string
            "supported_TA_name": self.supported_TA[0].name
            if len(self.supported_TA) > 0
            else "",
            "supported_TA_version": self.supported_TA[0].version
            if len(self.supported_TA) > 0
            else "",
            "supported_TA_url": self.supported_TA[0].url
            if len(self.supported_TA) > 0
            else "",
            "description": self.description,
        }


class DataSourceEnum(ContentEnum):
    """Empty Placeholder Enum for data sources.

    NOTE: This enum is dynamically populated at runtime by the DataSource.UpdateDynamicEnum method.
    """

    pass
