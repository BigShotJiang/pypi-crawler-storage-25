"""This module contains information supporting Analytic Story objects."""

from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from pydantic import Field, computed_field

from contentctl_ng.objects.conf import ConfStanza
from contentctl_ng.objects.content import (
    CVE_TYPE,
    ContentEnum,
    ContentStatus,
    DeprecatableContentType,
    DeprecatableSecurityContent,
    Product,
)

if TYPE_CHECKING:
    from contentctl_ng.objects.searches.detection import EventBasedDetection


class StoryCategory(StrEnum):
    """Enum for story categories.

    TODO: Provide information and authoritative documentation around where these are defined in Enterprise Security or how they render.
    """

    ABUSE = "Abuse"
    ADVERSARY_TACTICS = "Adversary Tactics"
    BEST_PRACTICES = "Best Practices"
    CLOUD_SECURITY = "Cloud Security"
    COMPLIANCE = "Compliance"
    MALWARE = "Malware"
    UNCATEGORIZED = "Uncategorized"
    VULNERABILITY = "Vulnerability"

    # The following categories are currently used in
    # security_content stories but do not appear
    # to have mappings in the current version of ES
    # Should they be removed and the stories which
    # reference them updated?
    # TODO: Question to bring up the the Team
    ACCOUNT_COMPROMSE = "Account Compromise"
    DATA_DESTRUCTION = "Data Destruction"
    LATERAL_MOVEMENT = "Lateral Movement"
    PRIVILEGE_ESCALATION = "Privilege Escalation"
    RANSOMWARE = "Ransomware"
    UNAUTHORIZED_SOFTWARE = "Unauthorized Software"


class StoryUseCase(StrEnum):
    """Enum for story use cases.

    TODO: Provide information and authoritative documentation around where these
    are defined in Enterprise Security or how they render.
    """

    FRAUD_DETECTION = "Fraud Detection"
    COMPLIANCE = "Compliance"
    APPLICATION_SECURITY = "Application Security"
    SECURITY_MONITORING = "Security Monitoring"
    ADVANCED_THREAT_DETECTION = "Advanced Threat Detection"
    INSIDER_THREAT = "Insider Threat"
    OTHER = "Other"


class Story(DeprecatableSecurityContent):
    """Represents an Analytic Story object.

    Analytic Stories are collections of related detections around a common theme.
    For example, they may help with finding evidence of exploitation around a common
    category, like Ransomware or Powershell abuse, or related actions by a
    Threat Actor or CVE.
    """

    narrative: str = Field(
        description="The narrative is a much more verbose than just the "
        "description field (which tends to be more brief). "
        "It gives far more detail about the Analytic Story."
    )

    # The following field is marked as frozen to prevent it from being changed
    # after the object is created. Pyright should not be throwing an issue here
    # as the field is marked as frozen, but it does so we ignore it.

    status: Literal[  #  pyright: ignore[reportIncompatibleVariableOverride]
        ContentStatus.production, ContentStatus.deprecated
    ] = Field(
        frozen=True,
        description="The status of this Story. It may only be 'production' or 'deprecated'. "
        "Only RemovedContent will have status 'removed' and there is no notion of an 'experimental' story.",
    )

    # TODO: This is a temporary workaround to handle the fact that the category
    # field is a single string in the analyticstories.conf file, but it is stored
    # as a list in the YAML file. We should validate that all of these are proper
    # stories, but we cannot expose all of them to contentctl-ng as they are not
    # serializable to the conf file.
    # The specific spec for this field is as follows:
    # category = <string>
    # Category best describes this analytic story. If unset, it will be displayed
    # as "Uncategorized".
    # Optional. (Note - this is required for contentctl)

    category: list[StoryCategory] = Field(
        description="The category of the story. WARNING - due to limitations in the allowed "
        "values in analyticstories.conf, only the first category will be serialized into "
        "analyticstories.conf. This behavior was present in legacy contentctl as well. This single "
        "value can be accessed via the 'category_single_value' property, which returns the first "
        "value in this list.",
        min_length=1,
    )

    @computed_field
    @property
    def category_single_value(self) -> StoryCategory:
        """Return the first category as a single string.

        This is a temporary workaround to handle the fact that the category
        field is a single-valued string in the analyticstories.conf file, but it is stored
        as a list in the YAML file.
        """
        return self.category[0]

    usecase: StoryUseCase = Field(description="The use case of the story.")

    threat_group: list[str] = Field(
        default_factory=list,
        description="A list of groups who leverage the techniques list in this Analytic Story.",
    )

    # TODO: Even though all values in Product are included in the list of literals below,
    # these products may change based on Platforms. We do not want to automatically allow
    # these new products be be allowed in stories, so we set this as a list of literals instead.
    product: frozenset[
        Literal[
            Product.SPLUNK_ENTERPRISE,
            Product.SPLUNK_ENTERPRISE_SECURITY,
            Product.SPLUNK_CLOUD,
            Product.SPLUNK_BEHAVIORAL_ANALYTICS,
        ]
    ] = Field(
        min_length=1,
        description="A set of Splunk products where this story is applicable.",
    )

    # TODO: Are we sure we do not want this associated with a DETECTION and not a story?
    cve: frozenset[CVE_TYPE] = Field(
        default_factory=frozenset,
        description="A set of one or more CVEs that are associated with this Detection.",
        min_length=0,
    )

    @computed_field
    @property
    def deprecatable_content_type(self) -> DeprecatableContentType:
        """Return the deprecatable content type for this object."""
        return DeprecatableContentType.Story

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the stories directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("stories")

    @computed_field
    @property
    def research_site_path(self) -> str:
        """Return the path of this object."""
        return f"stories/{self._path.stem}"

    @classmethod
    def update_dynamic_status(cls, content: list[Story]) -> None:
        """Update the dynamic enum for the stories."""
        StoryEnum.__update_everything_dangerous__(StoryEnum, content)

    @computed_field
    @property
    def spec_version(self) -> int:
        """Return the spec version (according to Enterprise Security) of the story.

        Note that this is a number used internally by Enterprise Security and
        is NOT the same as the self.version field, which is a version-controlled
        version of the story content.

        Returns:
            str: The spec version of the story.
        """
        return 3

    @computed_field
    @property
    def stanza_name(self) -> str:
        """Return the name of the stanza for the macro."""
        return f"analytic_story://{self.name}"

    @computed_field
    @property
    def maintainers(self) -> list[dict[str, str]]:
        """Return the searches associated with the story.

        Since dict is not hashable, we do the sorting here
        and return a sorted list already.
        """
        maintainers = [
            {
                "company": "Splunk",
                "email": "research@splunk.com",
                "name": "Splunk Threat Research Team",
            }
        ]
        return sorted(maintainers, key=lambda x: x["name"])

    # TODO: This really should be a computed field, but it causes
    # issues with building the schema due to circular dependencies.
    # There is not a similar issue when using JUST @property, but
    # this is something we should fix.
    @property
    def search_objects(self) -> frozenset[EventBasedDetection]:
        """Return the searches associated with the story."""
        # TODO: This should not be declared here, but I'm otherwise we get
        # circular dependencies issues.
        from contentctl_ng.objects.searches.detection import EventBasedDetectionEnum

        # TODO: This is a pretty slow function call.
        # In fact it's the slowest part of all parsing and construction logic!
        # In the scale of things, it's probably not a big deal, but something to consider.
        return frozenset(
            filter(
                lambda detection: self in [s.obj for s in detection.obj.analytic_story],
                EventBasedDetectionEnum,
            )
        )

    @computed_field
    @property
    def searches(self) -> frozenset[str]:
        """Return the searches associated with the story."""
        return frozenset(d.obj.stanza_name for d in self.search_objects)

    def emit_ConfStanza(self) -> ConfStanza:
        """Generate a ConfStanza object for the story."""
        stanza = ConfStanza(name=self.stanza_name)
        stanza.add_line(self, "category", "category_single_value")
        stanza.add_line(self, "last_updated", "modification_date")
        stanza.add_line(self, "version", "version")
        stanza.add_line(self, "references", "references")
        stanza.add_line(self, "maintainers", "maintainers")
        stanza.add_line(self, "spec_version", "spec_version")
        stanza.add_line(self, "searches", "searches")
        stanza.add_line(self, "description", "description")
        stanza.add_line(self, "narrative", "narrative")
        return stanza


class StoryEnum(ContentEnum):
    """Empty Placeholder Enum for stories.

    NOTE: This enum is dynamically populated at runtime by the Story.UpdateDynamicEnum method.
    """

    pass
