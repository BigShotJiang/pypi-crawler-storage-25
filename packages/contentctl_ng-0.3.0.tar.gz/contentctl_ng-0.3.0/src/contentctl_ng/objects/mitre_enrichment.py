"""Parse the MITRE ATT&CK dataset using the mitreattack library.

This is a simpler, lighter approach of how we used to do this
in legacy contentctl.  While that approach more fully parsed the
objects, we do not have a use today for all of those additonal
properties. If needed, we can always add this complexity back.
"""

import json
import logging
from enum import StrEnum
from pathlib import Path
from typing import Annotated

from mitreattack.stix20 import MitreAttackData
from pydantic import BaseModel, Field
from stix2.datastore.memory import MemoryStore

from contentctl_ng.objects.content import ContentEnum
from contentctl_ng.utilities.common_io import fetch_file_data_from_url_with_fallback

logger = logging.getLogger(__name__)

# Set some constraints on what makes a valid MITRE ATTACK Tactic
MITRE_ATTACK_ID_TYPE = Annotated[
    str,
    Field(
        description="MITRE ATT&CK Tactic",
        pattern=r"^T1\d{3}(\.\d{3})?$",
    ),
]


MITRE_ENTERPRISE_ATTACK_URL = "https://raw.githubusercontent.com/mitre/cti/ATT%26CK-v19.0/enterprise-attack/enterprise-attack.json"
MITRE_ENTERPRISE_ATTACK_URL_FALLBACK_PATH = Path(
    "MITRE_enterprise_attack_fallback.json"
)


class EnterpriseSecurityKillChainPhase(StrEnum):
    """Enum for Enterprise Security Kill Chain Phases.

    Note that these are a subset of those that are used in MITRE Attack.
    """

    RECONNAISSANCE = "reconnaissance"
    WEAPONIZATION = "weaponization"
    DELIVERY = "Delivery"
    INSTALLATION = "Installation"
    EXPLOITATION = "Exploitation"
    COMMAND_AND_CONTROL = "Command and Control"
    ACTIONS_ON_OBJECTIVES = "Actions on Objectives"


class MitreKillChainPhase(StrEnum):
    """Enum for of MITRE Attack Kill Chain Phases."""

    COLLECTION = "collection"
    COMMAND_AND_CONTROL = "command-and-control"
    CREDENTIAL_ACCESS = "credential-access"

    # defense-evasion was removed in MITRE ATT&CK v19.0
    # We intentionally maintain it here, commented out,
    # for documentation purposes
    # DEFENSE_EVASION = "defense-evasion"

    # Added in MITRE ATT&CK v19.0
    STEALTH = "stealth"
    # Added in MITRE ATT&CK v19.0
    DEFENSE_IMPAIRMENT = "defense-impairment"

    DISCOVERY = "discovery"
    EXECUTION = "execution"
    EXFILTRATION = "exfiltration"
    IMPACT = "impact"
    INITIAL_ACCESS = "initial-access"
    LATERAL_MOVEMENT = "lateral-movement"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege-escalation"
    RECONNAISSANCE = "reconnaissance"
    RESOURCE_DEVELOPMENT = "resource-development"

    @staticmethod
    def map_mitre_kill_chain_to_enterprise_security_killchain(
        tactic: MitreKillChainPhase,
    ) -> EnterpriseSecurityKillChainPhase:
        """Map MITRE Kill Chain Phases to Enterprise Security Kill Chain Phases.

        This function exists because the Kill Chain Phases used in MITRE Attack
        do not map directly to the Kill Chain Phases used in Enterprise Security.

        Args:
            tactic (MitreKillChainPhase): The MITRE Kill Chain Phase to map.

        Returns:
            EnterpriseSecurityKillChainPhase: The Equivalent Enterprise Security
            Kill Chain Phase.
        """
        # TODO: Convert this to a mapping for two reasons:
        # 1. Giant Code block is hard to read and poorly formatted and hard to read.
        # 2. Giant code block has poor performance.
        # This if/else block is O(n) whereas a mapping is O(1)
        if tactic == MitreKillChainPhase.RECONNAISSANCE:
            return EnterpriseSecurityKillChainPhase.RECONNAISSANCE
        if tactic == MitreKillChainPhase.RESOURCE_DEVELOPMENT:
            return EnterpriseSecurityKillChainPhase.WEAPONIZATION
        if tactic == MitreKillChainPhase.INITIAL_ACCESS:
            return EnterpriseSecurityKillChainPhase.DELIVERY
        if tactic == MitreKillChainPhase.EXECUTION:
            return EnterpriseSecurityKillChainPhase.INSTALLATION
        if tactic == MitreKillChainPhase.PERSISTENCE:
            return EnterpriseSecurityKillChainPhase.INSTALLATION
        if tactic == MitreKillChainPhase.PRIVILEGE_ESCALATION:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.CREDENTIAL_ACCESS:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.DISCOVERY:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.LATERAL_MOVEMENT:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.COLLECTION:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.COMMAND_AND_CONTROL:
            return EnterpriseSecurityKillChainPhase.COMMAND_AND_CONTROL
        if tactic == MitreKillChainPhase.EXFILTRATION:
            return EnterpriseSecurityKillChainPhase.ACTIONS_ON_OBJECTIVES
        if tactic == MitreKillChainPhase.IMPACT:
            return EnterpriseSecurityKillChainPhase.ACTIONS_ON_OBJECTIVES
        if tactic == MitreKillChainPhase.STEALTH:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        if tactic == MitreKillChainPhase.DEFENSE_IMPAIRMENT:
            return EnterpriseSecurityKillChainPhase.EXPLOITATION
        raise ValueError(f"Unknown MITRE Kill Chain Phase: {tactic}")


class SupportedMitreAttackEnrichments(BaseModel):
    """Class for MITRE Enterprise Attack enrichments.

    While this only has one property at this time, it may be expanded in the
    future if we need to parse out additional information from the MITRE Enterprise
    Attack data into a more complex object.
    """

    # This receives the value of "name" even though 'mitre_attack_id' would
    # be better so that it works with the ContentEnum dynamic enum generation
    name: MITRE_ATTACK_ID_TYPE = Field(description="The MITRE ATT&CK ID, such as T1003")
    enterpriseSecurityKillChainPhases: frozenset[EnterpriseSecurityKillChainPhase] = (
        Field(
            description="The set of Enterprise Security Kill Chain Phases that are mapped by this object"
        )
    )


class MitreEnterpriseAttackInfo(BaseModel):
    """Class for MITRE Enterprise Attack data."""

    mitre_attack_id_to_technique: dict[
        MITRE_ATTACK_ID_TYPE, SupportedMitreAttackEnrichments
    ] = Field(description="MITRE ATT&CK ID to SupposedMitreAttackEnrichments mapping.")

    @classmethod
    def parse_mitre_enterprise_info_url_to_enum(
        cls, fallback_path: Path = MITRE_ENTERPRISE_ATTACK_URL_FALLBACK_PATH
    ) -> None:
        """Parse the MITRE Enterprise Attack data and return a MitreEnterpriseAttackInfo object.

        Args:
            fallback_path (Path, optional): Path to the fallback file that can be included,
            but that must be manually downloaded and placed there by a user of contentctl-ng.
            Defaults to MITRE_ENTERPRISE_ATTACK_URL_FALLBACK_PATH.

        Returns:
            None: Nothing is returned, but the SupportedMitreAttackEnrichmentsEnum is populated.

        Raises:
            Exception: If the MITRE Enterprise Attack data cannot be fetched or parsed. There
            is a fallback file that can be included, but that must be manually downloaded and
            placed there by a user of contentctl-ng
        """
        try:
            logger.info("Fetching the latest MITRE Enterprise Attack data.")
            data = fetch_file_data_from_url_with_fallback(
                MITRE_ENTERPRISE_ATTACK_URL, fallback_path
            )

            mitre_data_str: str = data.decode("utf-8")

            json_data = json.loads(mitre_data_str)

            mitre_attack_data = MitreAttackData(
                stix_filepath=None, src=MemoryStore(stix_data=json_data)
            )

            # Get all of the techniques
            techniques = mitre_attack_data.get_techniques(
                remove_revoked_deprecated=False
            )

            objects = []
            for technique in techniques:
                # Map the phases first. Thisd is required due to the
                # mismatch in MITRE Techniques vs those used by Enterprise Security
                enterprise_security_kill_chain_phases = [
                    MitreKillChainPhase.map_mitre_kill_chain_to_enterprise_security_killchain(
                        phase.phase_name
                    )
                    for phase in technique.kill_chain_phases
                ]

                objects.append(
                    SupportedMitreAttackEnrichments(
                        name=mitre_attack_data.get_attack_id(technique.id),
                        enterpriseSecurityKillChainPhases=enterprise_security_kill_chain_phases,
                    )
                )

            SupportedMitreAttackEnrichmentsEnum.__update_everything_dangerous__(
                SupportedMitreAttackEnrichmentsEnum, objects
            )
        except Exception as e:
            # TODO: Implement Exception-type specific error handling, where appropriate, for specific exceptions
            # we feel to be likely.  Instead of trying to capture generic exceptions, let them fall back to
            # the highest level error handler (such as at the CLI level).

            raise Exception(
                f"Failed to fetch or parse MITRE Enterprise Attack data: {e!s}"
            )


class SupportedMitreAttackEnrichmentsEnum(ContentEnum):
    """Empty Placeholder Enum for macros.

    NOTE: This enum is dynamically populated at runtime by the MitreEnterpriseAttack.parse_mitre_enterprise_info_url_to_enum method.
    """

    pass
