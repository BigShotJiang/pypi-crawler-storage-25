"""Define a detection. For now this is just EBD, but maybe FBD in the future?

There are lots of fields defined in here that exist here instead of in separate
files.  Do we want them to be defined here, or defined in some supporting files?

TODO: Note that some TTP detections may no longer generate risk events, but
notable events only (which contribute risk); is there any impact on testing
with this?
"""

import itertools
import logging
from abc import ABC
from collections import Counter
from collections.abc import Sequence
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Any, Self, cast

import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    computed_field,
    field_validator,
    model_validator,
)

from contentctl_ng.objects.conf import ConfStanza
from contentctl_ng.objects.content import (
    CVE_TYPE,
    ContentEnum,
    ContentStatus,
    DeprecatableContentType,
)
from contentctl_ng.objects.data_source import DataSource
from contentctl_ng.objects.mitre_enrichment import (
    MITRE_ATTACK_ID_TYPE,
    EnterpriseSecurityKillChainPhase,
    SupportedMitreAttackEnrichments,
    SupportedMitreAttackEnrichmentsEnum,
)
from contentctl_ng.objects.searches.baseline import BaselineEnum
from contentctl_ng.objects.searches.search import (
    ExperimentalTest,
    Search,
    Severity,
    UnitTest,
)
from contentctl_ng.objects.story import StoryEnum
from contentctl_ng.objects.validated_strings import EsTokenString, SplString

logger = logging.getLogger(__name__)


class DetectionType(StrEnum):
    """This enum defines the type of detection."""

    EBD = "ebd"
    FBD = "fbd"


class DetectionAnalyticsType(StrEnum):
    """This enum defines the analytics type of an event-based detection.

    This is a separate axis from DetectionType (EBD/FBD), which describes the
    detection mechanism. DetectionAnalyticsType describes the alerting and risk
    scoring behaviour of the detection:

    - TTP: Generates a finding (action.notable) and intermediate findings
      (action.risk). Intermediate findings are optional (0+).
    - Anomaly: Generates intermediate findings only (action.risk). No finding.
    - Correlation: Generates a finding only (action.notable). No intermediate
      findings.
    - Hunting: No finding, no intermediate findings, no threat objects.
    """

    TTP = "TTP"
    ANOMALY = "Anomaly"
    CORRELATION = "Correlation"
    HUNTING = "Hunting"


class RiskObjectType(StrEnum):
    """This enum defines the type of risk object.

    TODO: Where is this enumeration documented in product?
    """

    SYSTEM = "system"
    USER = "user"
    OTHER = "other"


class NistCategory(StrEnum):
    """NIST categories."""

    ID_AM = "ID.AM"
    ID_BE = "ID.BE"
    ID_GV = "ID.GV"
    ID_RA = "ID.RA"
    ID_RM = "ID.RM"
    PR_AC = "PR.AC"
    PR_AT = "PR.AT"
    PR_DS = "PR.DS"
    PR_IP = "PR.IP"
    PR_MA = "PR.MA"
    PR_PT = "PR.PT"
    DE_AE = "DE.AE"
    DE_CM = "DE.CM"
    DE_DP = "DE.DP"
    RS_RP = "RS.RP"
    RS_CO = "RS.CO"
    RS_AN = "RS.AN"
    RS_MI = "RS.MI"
    RS_IM = "RS.IM"
    RC_RP = "RC.RP"
    RC_IM = "RC.IM"
    RC_CO = "RC.CO"


class ThreatObjectType(StrEnum):
    """This enum defines the type of threat object.

    TODO: Where is this enumeration documented in product?
    """

    CERTIFICATE_COMMON_NAME = "certificate_common_name"
    CERTIFICATE_ORGANIZATION = "certificate_organization"
    CERTIFICATE_SERIAL = "certificate_serial"
    CERTIFICATE_UNIT = "certificate_unit"
    COMMAND = "command"
    DOMAIN = "domain"
    EMAIL_ADDRESS = "email_address"
    EMAIL_SUBJECT = "email_subject"
    FILE_HASH = "file_hash"
    FILE_NAME = "file_name"
    FILE_PATH = "file_path"
    HTTP_USER_AGENT = "http_user_agent"
    IP_ADDRESS = "ip_address"
    PROCESS = "process"
    PROCESS_NAME = "process_name"
    PARENT_PROCESS = "parent_process"
    PARENT_PROCESS_NAME = "parent_process_name"
    PROCESS_HASH = "process_hash"
    REGISTRY_PATH = "registry_path"
    REGISTRY_VALUE_NAME = "registry_value_name"
    REGISTRY_VALUE_TEXT = "registry_value_text"
    SERVICE = "service"
    SIGNATURE = "signature"
    SYSTEM = "system"
    TLS_HASH = "tls_hash"
    URL = "url"


class ThreatObject(BaseModel):
    """This class defines a threat object.

    TODO: Where is this class documented in product? Are there
    committed changes around this in upcoming version(s) of ES?
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    field: str = Field(description="The name of the threat object.", min_length=1)
    type: ThreatObjectType = Field(description="The type of the threat object.")

    def __hash__(self):
        """Provide a hash for threat objects.

        Returns:
            int: Hash of the threat object.
        """
        return hash((self.field, self.type))

    def __lt__(self, other: ThreatObject) -> bool:
        """Provide a lexicographic ordering for threat objects.

        Args:
            other (ThreatObject): Other object to compare to.

        Returns:
            bool: True if this object is less than the other object, False otherwise.
        """
        if f"{self.field}{self.type}" < f"{other.field}{other.type}":
            return True
        return False


class RiskScoredEntity(BaseModel, ABC):
    """Abstract base class for entities that carry a risk score.

    Both FindingEntity and IntermediateFindingEntity share the same core
    fields (field, type, score). This base class defines those fields once
    and provides concrete __hash__ and __lt__ implementations that
    automatically include all fields defined on the concrete subclass.
    Subclasses can be placed in frozensets and sorted deterministically
    during serialization without any additional implementation.

    __hash__ and __lt__ are derived from Pydantic's __iter__, which yields
    (field_name, value) pairs in field definition order, with parent class
    fields preceding subclass fields. This means any field added to a
    subclass is automatically included in ordering and hashing in definition
    order — FindingEntity produces (field, type, score) and
    IntermediateFindingEntity produces (field, type, score, message).
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    field: str = Field(
        description="The name of the entity field (risk_object_field).", min_length=1
    )
    type: RiskObjectType = Field(
        description="The type of the entity (risk_object_type)."
    )
    score: int = Field(
        description="The risk score for this entity (risk_score).",
        ge=0,
        le=100,
    )

    def __hash__(self) -> int:
        """Return a hash derived from all fields on the concrete subclass.

        Uses Pydantic's __iter__ to collect field values in definition order
        (parent fields first, then subclass fields), ensuring that subclasses
        with additional fields (e.g. IntermediateFindingEntity.message) are
        hashed over their full set of fields without any override required.
        """
        return hash(tuple(v for _, v in self))

    def __lt__(self, other: RiskScoredEntity) -> bool:
        """Return True if this entity is less than other.

        Compares tuples of field values in definition order via Pydantic's
        __iter__, so ordering is consistent with __hash__ and automatically
        covers any fields added to a subclass.
        """
        return tuple(v for _, v in self) < tuple(v for _, v in other)


class FindingEntity(RiskScoredEntity):
    """The primary alert subject for a Finding.

    Represents the single entity that a Finding is attributed to. Serializes
    to action.notable.param._entities in savedsearches.conf.

    Defined explicitly rather than aliased so it can be extended independently
    in future if needed. __hash__ and __lt__ are inherited from RiskScoredEntity
    and cover (field, type, score) automatically.
    """


class IntermediateFindingEntity(RiskScoredEntity):
    """An entity within an IntermediateFindings block.

    Extends RiskScoredEntity with a per-entity risk message, replacing the
    single shared message that existed on the legacy RBA class. Each entity
    serializes to an entry in action.risk.param._risk in savedsearches.conf,
    with risk_message included per entry.

    __hash__ and __lt__ are inherited from RiskScoredEntity and automatically
    cover (field, type, score, message) — message is included because it is
    defined on this subclass and Pydantic's __iter__ yields fields in
    definition order with parent fields first.
    """

    message: EsTokenString = Field(
        description="The per-entity risk message for this intermediate finding entity. "
        "Supports $field_name$ token substitution. $ delimiters must be balanced."
    )


class Finding(BaseModel):
    """Maps to the ES Finding concept: a risk-contributing primary alert (formerly notable).

    In ES8+, a Finding is the successor to the notable event. It generates a
    direct alert and also contributes risk scoring to its primary entity via
    the notable action. Presence of a Finding on a detection implies that
    action.notable is enabled.

    title is placed at the finding level rather than inside entity, reflecting
    that it is a property of the finding action as a whole (serializing to
    action.notable.param.rule_title) rather than of the individual entity.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    title: EsTokenString = Field(
        description="The title of the finding. Serializes to "
        "action.notable.param.rule_title in savedsearches.conf. "
        "Supports $field_name$ token substitution. $ delimiters must be balanced."
    )
    entity: FindingEntity = Field(
        description="The primary alert subject for this finding. Exactly one entity "
        "per finding is enforced: any additional entities belong in intermediate_findings."
    )

    @computed_field
    @property
    def _entities(self) -> list[dict[str, str | int]]:
        """Serialized finding entity for action.notable.param._entities in savedsearches.conf.

        Returns a single-element list containing the finding entity serialized as a
        risk object dict (risk_object_field, risk_object_type, risk_score). Replaces
        the legacy N/A placeholder that was hardcoded for all notable-generating
        detections.
        """
        return [
            {
                "risk_object_field": self.entity.field,
                "risk_object_type": self.entity.type,
                "risk_score": self.entity.score,
            }
        ]


class IntermediateFindings(BaseModel):
    """Maps to the ES Intermediate Finding concept: a risk-contributing action with no direct alert (formerly risk).

    In ES8+, intermediate findings are the successor to standalone risk events.
    They contribute risk scoring to their entities without generating a primary
    alert. Each entity carries its own per-entity risk message. Presence of an
    IntermediateFindings block on a detection implies that action.risk is
    enabled.

    min_length=1 is enforced on entities: an IntermediateFindings block that
    is present must contain at least one entity.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    entities: frozenset[IntermediateFindingEntity] = Field(
        description="The set of intermediate finding entities. Must contain at least "
        "one entity when present.",
        min_length=1,
    )

    @computed_field
    @property
    def _risk(self) -> list[dict[str, str | int]]:
        """Serialized intermediate finding entities for action.risk.param._risk.

        Each entity is serialized with risk_object_field, risk_object_type, risk_score,
        and risk_message. Entries are sorted deterministically by (field, type, score).

        IMPORTANT: This property covers intermediate finding entities only. Threat
        objects must be appended by the caller. Use EventBasedDetection._risk when
        serializing to savedsearches.conf, as it delegates here and then appends the
        detection's threat_objects.
        """
        return sorted(
            [
                {
                    "risk_object_field": e.field,
                    "risk_object_type": e.type,
                    "risk_score": e.score,
                    "risk_message": e.message.root,
                }
                for e in self.entities
            ],
            key=lambda x: (
                x["risk_object_field"],
                x["risk_object_type"],
                x["risk_score"],
            ),
        )

    @computed_field
    @property
    def _risk_score(self) -> int:
        """Hardcoded top-level risk score for action.risk.param._risk_score in savedsearches.conf.

        Retained for ES 7 compatibility. ES 8 reads per-entity risk scores from within
        each entry in action.risk.param._risk rather than from this top-level key.

        TODO: Remove once ES 7 support is no longer required.
        NOTE: Confirmed on ES 8 — this top-level field is silently ignored. ES 8 reads
            risk_score exclusively from per-entity entries in action.risk.param._risk.
            No conflict or override occurs.

        Returns:
            int: Always 0.
        """
        return 0

    @computed_field
    @property
    def verbose(self) -> bool:
        """Hardcoded verbose flag for action.risk.param.verbose in savedsearches.conf.

        Retained for ES 7 compatibility. ES 8 does not emit this field when creating
        a detection in the UI.

        TODO: Remove once ES 7 support is no longer required.

        Returns:
            bool: Always False.
        """
        return False


class AssetType(StrEnum):
    """This enum defines the type of asset.

    TODO: Where is this used in product? And which products?
    This seems to be a large set of values that has continuously
    grown over time, but does not have a constrained definition anywhere.
    """

    ACCOUNT = "Account"
    AMAZON_EKS_KUBERNETES_CLUSTER = "Amazon EKS Kubernetes cluster"
    AMAZON_EKS_KUBERNETES_CLUSTER_POD = "Amazon EKS Kubernetes cluster Pod"
    AMAZON_ELASTIC_CONTAINER_REGISTRY = "Amazon Elastic Container Registry"
    AWS_ACCOUNT = "AWS Account"
    AWS_FEDERATED_ACCOUNT = "AWS Federated Account"
    AWS_INSTANCE = "AWS Instance"
    AZURE_ACTIVE_DIRECTORY = "Azure Active Directory"
    AZURE_TENANT = "Azure Tenant"
    CIRCLECI = "CircleCI"
    CLOUD_COMPUTE_INSTANCE = "Cloud Compute Instance"
    CLOUD_INSTANCE = "Cloud Instance"
    DATABASE_SERVER = "Database Server"
    DNS_SERVERS = "DNS Servers"
    EC2_SNAPSHOT = "EC2 Snapshot"
    ENDPOINT = "Endpoint"
    GCP = "GCP"
    GCP_ACCOUNT = "GCP Account"
    GCP_KUBERNETES_CLUSTER = "GCP Kubernetes cluster"
    GCP_STORAGE_BUCKET = "GCP Storage Bucket"
    GDRIVE = "GDrive"
    GITHUB = "GitHub"
    GOOGLE_CLOUD_PLATFORM_TENANT = "Google Cloud Platform tenant"
    GSUITE = "GSuite"
    IDENTITY = "Identity"
    INFRASTRUCTURE = "Infrastructure"
    KUBERNETES = "Kubernetes"
    NETWORK = "Network"
    O365_TENANT = "O365 Tenant"
    OKTA_TENANT = "Okta Tenant"
    S3_BUCKET = "S3 Bucket"
    SPLUNK_SERVER = "Splunk Server"
    VPN_APPLIANCE = "VPN Appliance"
    WEB_APPLICATION = "Web Application"
    WEB_PROXY = "Web Proxy"
    WEB_SERVER = "Web Server"
    WINDOWS = "Windows"


class Drilldown(BaseModel):
    """Drilldown searches for an event based detection."""

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    name: str = Field(description="The name of the drilldown search.")
    search: SplString = Field(
        description="The search to run when the drilldown is clicked."
    )
    # TODO: earliest_offset and latest_offset accept any string today. These fields
    # support a range of SPL time formats (e.g. "$info_min_time$", "-70m@m", "0"),
    # and validating them requires consulting the SPL time modifier spec to define
    # the full set of allowable patterns before a validator can be implemented.
    # Note: SPLUNK_RELATIVE_TIME_TYPE in schedule.py covers the relative time
    # subset (e.g. "-70m@m"), but these fields also accept $token$ strings and
    # bare values (e.g. "0") that fall outside that pattern, so that type cannot
    # be applied directly here without a union or a broader pattern.
    earliest_offset: str = Field(
        description="The earliest offset for the drilldown search."
    )
    latest_offset: str = Field(
        description="The latest offset for the drilldown search."
    )

    @classmethod
    def generate_default_drilldowns(
        cls, detection: EventBasedDetection
    ) -> list[Drilldown]:
        """Generate default drilldowns for a detection.

        As most EBD will have drilldowns in the same format, provide a way to generate these
        defaults automatically. These will be used for validation purposes.

        Args:
            detection (EventBasedDetection): The detection for which to generate the drilldowns.

        Returns:
            list[Drilldown]: Automatically generated drilldowns for the detection.
        """
        return [
            cls.generate_default_detection_results(detection),
            cls.generate_default_risk_events(detection),
        ]

    @classmethod
    def generate_default_risk_events(cls, detection: EventBasedDetection) -> Drilldown:
        """Generate a default drilldown for risk events.

        Args:
            detection (EventBasedDetection): The detection for which to generate the drilldown.

        Raises:
            NotImplementedError: If neither a finding nor intermediate findings are
                present on the detection (e.g. Hunting), so no entity fields are
                available to build the drilldown.

        Returns:
            Drilldown: The risk events drilldown for the detection.
        """
        if detection.finding is None and detection.intermediate_findings is None:
            raise NotImplementedError(
                "No finding or intermediate findings are present for this detection, "
                "so risk event drilldowns cannot be generated."
            )

        entity_fields: list[str] = []
        if detection.finding is not None:
            entity_fields.append(detection.finding.entity.field)
        if detection.intermediate_findings is not None:
            entity_fields.extend(
                sorted(e.field for e in detection.intermediate_findings.entities)
            )

        name_template = """View the risk events for the last 7 days for - {fields}"""
        name_fields = " and ".join([f'"${f}$"' for f in entity_fields])
        name_composed = name_template.format(fields=name_fields)
        search_template = (
            "| from datamodel Risk.All_Risk "
            "| search normalized_risk_object IN ({search_fields}) starthoursago=168  "
            "| stats count min(_time) as firstTime max(_time) as lastTime "
            'values(search_name) as "Search Name" values(risk_message) as "Risk Message" '
            'values(analyticstories) as "Analytic Stories" '
            'values(annotations._all) as "Annotations" '
            'values(annotations.mitre_attack.mitre_tactic) as "ATT&CK Tactics" by normalized_risk_object '
            "| `security_content_ctime(firstTime)` "
            "| `security_content_ctime(lastTime)`"
        )

        search_fields = ",".join([f'"${f}$"' for f in entity_fields])
        search_composed = search_template.format(
            search_fields=search_fields,
        )

        return cls(
            name=name_composed,
            search=SplString(search_composed),
            earliest_offset="$info_min_time$",
            latest_offset="$info_max_time$",
        )

    @classmethod
    def generate_default_detection_results(
        cls, detection: EventBasedDetection
    ) -> Drilldown:
        """Generate a default drilldown for detection results.

        Args:
            detection (EventBasedDetection): The detection for which to generate the drilldown.

        Raises:
            NotImplementedError: If neither a finding nor intermediate findings are
                present on the detection (e.g. Hunting), so no entity fields are
                available to build the drilldown.

        Returns:
            Drilldown: The detection results drilldown for the detection.
        """
        if detection.finding is None and detection.intermediate_findings is None:
            raise NotImplementedError(
                "No finding or intermediate findings are present for this detection, "
                "so detection result drilldowns cannot be generated."
            )

        entity_fields: list[str] = []
        if detection.finding is not None:
            entity_fields.append(detection.finding.entity.field)
        if detection.intermediate_findings is not None:
            entity_fields.extend(
                sorted(e.field for e in detection.intermediate_findings.entities)
            )

        name_template = """View the detection results for - {fields}"""
        name_fields = " and ".join([f'"${f}$"' for f in entity_fields])
        name_composed = name_template.format(fields=name_fields)

        search_template = (
            """| savedsearch "{search_stanza_name}" | search  {search_fields}"""
        )
        search_fields = " ".join([f'{f} = "${f}$"' for f in entity_fields])
        search_composed = search_template.format(
            search_stanza_name=detection.stanza_name,
            search_fields=search_fields,
        )

        return cls(
            name=name_composed,
            search=SplString(search_composed),
            earliest_offset="$info_min_time$",
            latest_offset="$info_max_time$",
        )


class DetectionCategory(StrEnum):
    """The category of the detection.

    Note that because Deprecated is now communicated
    via a different field, DeprecationInfo, it SHOULD
    NOT be included as a category.
    """

    APPLICATION = "application"
    CLOUD = "cloud"
    ENDPOINT = "endpoint"
    NETWORK = "network"
    WEB = "web"
    # TODO: Remove this as a category.
    DEPRECATED = "deprecated"


class EventBasedDetection(Search):
    """This class extends the Search class to represent a detection.

    It includes all common fields that are required or optional
    for a detection.
    """

    type: DetectionAnalyticsType = Field(
        description="The analytics type of this detection. Determines the expected "
        "combination of finding, intermediate_findings, and threat_objects fields. "
        "See DetectionAnalyticsType for the full matrix of constraints.",
    )

    finding: Finding | None = Field(
        default=None,
        description="The primary alert for this detection. When present, action.notable "
        "is enabled and a Finding is generated on each firing. Required for TTP and "
        "Correlation detections; must be absent for Anomaly and Hunting.",
    )

    intermediate_findings: IntermediateFindings | None = Field(
        default=None,
        description="The set of risk-contributing entities for this detection. When "
        "present, action.risk is enabled and each entity is risk-scored on each firing "
        "without generating a direct alert. Required for Anomaly detections; optional "
        "for TTP; must be absent for Correlation and Hunting.",
    )

    threat_objects: frozenset[ThreatObject] = Field(
        default_factory=lambda: frozenset[ThreatObject](),
        description="The set of threat objects associated with this detection. Serialized "
        "into action.risk.param._risk alongside intermediate finding entities. Allowed for "
        "TTP, Anomaly, and Correlation detections; must be empty for Hunting.",
        min_length=0,
    )

    analytic_story: frozenset[StoryEnum] = Field(
        description="A set of one or more Analytic Stories that this "
        "Detection belongs to. Note that a detection MUST belong to "
        "at least one Analytic Story.",
        min_length=1,
    )

    baselines: list[BaselineEnum] = Field(
        description="A list of baselines that this search is associated with.",
        default_factory=lambda: list[BaselineEnum](),
        min_length=0,
    )

    mitre_attack_id: frozenset[SupportedMitreAttackEnrichmentsEnum] = Field(
        description="A set of zero or more MITRE ATT&CK Tactics that are "
        "associated with this Detection.  In most cases, this should "
        "contain AT LEAST 1 Attack ID. Note that this matches patterns "
        "like T1000, T1234.023, etc. It intentionally does "
        "not match patterns like T0123 or T1234.1 or similar.",
        min_length=0,
    )

    asset_type: AssetType = Field(
        description="The type of asset that this detection is designed to run against."
    )

    cve: frozenset[CVE_TYPE] = Field(
        default_factory=frozenset,
        description="A set of one or more CVEs that are associated with this Detection.",
        min_length=0,
    )

    drilldown_searches: list[Drilldown] = Field(
        default_factory=lambda: list[Drilldown](),
        description="A list of drilldowns that are associated with this Detection.",
        min_length=0,
    )

    threat_group: frozenset[str] = Field(
        default_factory=frozenset,
        description="A list of MITRE Threat Groups relevant to this detection.",
        min_length=0,
    )

    category: DetectionCategory = Field(description="The category of the detection.")

    @computed_field
    @property
    def deprecatable_content_type(self) -> DeprecatableContentType:
        """Return the deprecatable content type for this object."""
        return DeprecatableContentType.Detection

    @computed_field
    @property
    def severity(self) -> Severity:
        """Derive severity from the detection's risk scores.

        Priority order:
        - If a finding is present, severity is derived solely from finding.entity.score.
          Since severity is serialized to action.notable.param.severity, it should
          reflect the score of the entity the finding is attributed to.
        - If no finding is present but intermediate findings are, severity is derived
          from the highest score across all intermediate finding entities.
        - If neither is present (e.g. Hunting), falls through to the base class
          default of Severity.HIGH.

        TODO: severity should raise NotImplementedError for detections without a
        finding, since severity is only serialized to action.notable.param.severity
        and returning a value for finding-less detections (Anomaly, Hunting) produces
        a value that is never written to conf. Raising here would require gating the
        serialization call in emit_ConfStanza_savedsearches on `self.finding is not None`
        rather than the current approach of gating the entire notable block. Not making
        this change now — need to validate the impact on ES 8 and ES 7 behaviour first.

        Raises:
            Exception: If the resolved score is not between 0 and 100.

        Returns:
            Severity: The severity for the search.
        """
        if self.finding is not None:
            score = self.finding.entity.score
        elif self.intermediate_findings is not None:
            score = max(e.score for e in self.intermediate_findings.entities)
        else:
            return super().severity

        if 0 <= score <= 20:
            return Severity.INFORMATIONAL
        elif 20 < score <= 40:
            return Severity.LOW
        elif 40 < score <= 60:
            return Severity.MEDIUM
        elif 60 < score <= 80:
            return Severity.HIGH
        elif 80 < score <= 100:
            return Severity.CRITICAL
        else:
            raise Exception(
                f"Error getting severity - risk_score must be between 0-100, "
                f"but was actually {score}"
            )

    tests: list[
        Annotated[
            ExperimentalTest | UnitTest,
            Field(discriminator="test_type"),
        ]
    ] = Field(
        description="A list of tests that can be run against this search. "
        "Each test should contain a name and a set of test data that will be used "
        "to validate the search. EBDs MUST have at least one test.  This test MAY be "
        "an experimental test (for instance, replacing the 'manual_test' tag in legacy contentctl).  "
        "If a Detection is experimental, then you MUST create an experimental_test object explaining "
        "why it is experimental and, ideally, instructions to replicate the conditions to facilitate "
        "re-testing of this detection.",
        default_factory=lambda: list[
            Annotated[ExperimentalTest | UnitTest, Field(discriminator="test_type")]
        ](),
    )

    @model_validator(mode="after")
    def production_detections_have_at_least_one_test(self) -> EventBasedDetection:
        """Production detections must have at least one test.

        If there is not at least one test, we throw an exception
        and report that a test is required to the user.
        This means that experimental and deprecated detections MAY
        have tests, but do not require them.



        Args:
            self (EventBasedDetection): The detection object.

        Returns:
            EventBasedDetection: The detection object.

        Raises:
            ValueError: If the detection is production and has no tests.
        """
        if (
            self.status != ContentStatus.production
            or self.type == DetectionAnalyticsType.CORRELATION
        ):
            # Only production searches need test(s).
            # Additionally, even though most correlation searches
            # do have tests defined for them, they are not required.
            return self

        # If we get here, then the status must be production
        # and it is not a Correlation Search.
        # Therefore, we MUST have at least one test. It is acceptable
        # if that is an experimental test.
        if len(self.tests) == 0:
            raise ValueError(
                "No tests defined for a production detection. "
                "Production detections MUST have at least one test."
            )

        # The detection had at least one test. Return successfully
        return self

    @field_validator("mitre_attack_id", mode="after")
    def mitre_attack_id_does_not_include_parent_and_child(
        cls,
        value: frozenset[SupportedMitreAttackEnrichmentsEnum],
    ) -> frozenset[SupportedMitreAttackEnrichmentsEnum]:
        """Throws an exception if, for instance, both T1003 and T1003.001 are included in the set.

        At the request of STRT, if a "child"/"more specific" attack ID is included,
        then the parent attack ID MUST NOT be included.

        Args:
            value (frozenset[SupportedMitreAttackEnrichmentsEnum]): The set of attack IDs.

        Returns:
            frozenset[SupportedMitreAttackEnrichmentsEnum]: The set of attack IDs.

        Raises:
            ValueError: If the set contains both a parent and a child of the same attack ID.

        """
        for attack_id in value:
            if "." not in attack_id:
                # This is a parent attack ID. Make sure there are no children that have the same parent.

                possible_children = [
                    possible_child_id
                    for possible_child_id in value
                    if possible_child_id.startswith(attack_id + ".")
                ]
                if len(possible_children) > 0:
                    raise ValueError(
                        f"Both attack_id '{attack_id}' and sub attack_id(s) "
                        f"{possible_children} are included in the set. "
                        "If you are definining sub attack_ids, "
                        "you cannot also define their attack_id."
                    )
        return value

    @field_validator("tests", mode="before")
    @classmethod
    def validate_tests(cls, v: Any) -> Any:
        """Ensure the tests list is non-empty before Pydantic coerces its elements.

        Every EBD must have at least one test. Normally this will be a unit test
        that is dynamically run during contentctl-ng test, but the tests section
        also covers what were previously called 'experimental' and 'manual_test'
        detections. For those, an experimental test must be defined with
        test_type: experimental, describing why the detection cannot be
        automatically tested and providing replication instructions to facilitate
        manual re-testing.

        Runs before field coercion (mode="before"). Returns v unchanged in all
        non-error cases — Pydantic handles type coercion of the elements after
        this validator completes. Non-list inputs are passed through without error
        so Pydantic's normal type validation can surface the appropriate message.

        Args:
            v: The raw pre-coercion value for the tests field.

        Raises:
            ValueError: If v is an empty list.

        Returns:
            Any: The original value, unchanged.
        """
        if not isinstance(v, list):
            # This will be caught by the normal validation logic,
            # so don't try to handle this. Just let it fall through
            return v
        if len(v) == 0:  # type: ignore[reportUnknownArgumentType]
            example_experimental_test = {  # type: ignore[reportUnknownVariableType]
                "tests": [
                    {
                        "name": "Name of manual or experimental test.",
                        "attack_data": [],
                        "description": "Non-optional description of why this detection lacks a unit test.",
                        "test_type": "experimental",
                    }
                ]
            }

            example_experimental_test_yaml = yaml.dump(
                example_experimental_test, indent=3
            )

            raise ValueError(
                "At least one test is required for a detection, "
                "including for experimental detections. You must provide information "
                "to facilitate manual or interactive testing of the detection or an "
                "explanation of why this detection is experimental.\n"
                "A simple example is shown below:\n\n"
                f"{example_experimental_test_yaml}\n"
            )
        return v  # type: ignore[reportUnknownVariableType]

    @model_validator(mode="after")
    def validate_type_field_constraints(self) -> Self:
        """Enforce the type/field constraint matrix for detection analytics types.

        Each DetectionAnalyticsType implies a specific combination of finding,
        intermediate_findings, and threat_objects:

        - TTP:         finding required; intermediate_findings optional (0+);
                       threat_objects allowed
        - Anomaly:     finding must be absent; intermediate_findings required;
                       threat_objects allowed
        - Correlation: finding required; intermediate_findings must be absent;
                       threat_objects allowed
        - Hunting:     finding must be absent; intermediate_findings must be absent;
                       threat_objects must be empty

        Raises:
            ValueError: If any field combination violates the constraint for the
                declared analytics type.

        Returns:
            Self: The validated instance.
        """
        t = self.type
        errors: list[str] = []

        if t == DetectionAnalyticsType.TTP:
            if self.finding is None:
                errors.append("TTP detections require a finding.")

        elif t == DetectionAnalyticsType.ANOMALY:
            if self.finding is not None:
                errors.append("Anomaly detections must not have a finding.")
            if self.intermediate_findings is None:
                errors.append("Anomaly detections require intermediate_findings.")

        elif t == DetectionAnalyticsType.CORRELATION:
            if self.finding is None:
                errors.append("Correlation detections require a finding.")
            if self.intermediate_findings is not None:
                errors.append(
                    "Correlation detections must not have intermediate_findings."
                )

        elif t == DetectionAnalyticsType.HUNTING:
            if self.finding is not None:
                errors.append("Hunting detections must not have a finding.")
            if self.intermediate_findings is not None:
                errors.append("Hunting detections must not have intermediate_findings.")
            if self.threat_objects:
                errors.append("Hunting detections must not have threat_objects.")

        if errors:
            raise ValueError(
                f"Detection type [{t}] has invalid field combination:\n"
                + "\n".join(f"  - {e}" for e in errors)
            )
        return self

    @model_validator(mode="after")
    def validate_entity_field_uniqueness(self) -> Self:
        """Enforce that entity field names are unique across finding and intermediate_findings.

        Two distinct uniqueness constraints are enforced:

        1. No field name in intermediate_findings.entities[*].field may appear more
           than once within that set. Because IntermediateFindingEntity.__hash__ covers
           all fields (field, type, score, message), two entities with the same field
           name but different other attributes are not deduplicated by the frozenset,
           and would double-score the same risk object on a single firing.

        2. finding.entity.field must not appear in any intermediate_findings.entities[*].field.
           A shared name would score the same risk object twice — once via action.notable
           and once via action.risk.

        Both checks apply only when intermediate_findings is present. The cross-field
        check (2) additionally requires finding to be present.

        Raises:
            ValueError: If any field name appears more than once within
                intermediate_findings.entities, or appears in both finding.entity
                and intermediate_findings.entities.

        Returns:
            Self: The validated instance.
        """
        if self.intermediate_findings is not None:
            # Counter is O(n) vs the naive list.count() approach which is O(n²).
            # In practice n is always tiny (1-5 entities), so the speedup is
            # theoretical only - Counter is used here for correctness, not performance.
            field_counts = Counter(e.field for e in self.intermediate_findings.entities)
            duplicate_fields = {f for f, count in field_counts.items() if count > 1}
            if duplicate_fields:
                raise ValueError(
                    f"Entity field(s) {sorted(duplicate_fields)} appear more than once "
                    "in intermediate_findings.entities. Each field name must be unique "
                    "within intermediate_findings to avoid double-scoring the same "
                    "risk object on a single detection firing."
                )

        if self.finding is not None and self.intermediate_findings is not None:
            finding_field = self.finding.entity.field
            intermediate_fields = {e.field for e in self.intermediate_findings.entities}
            if finding_field in intermediate_fields:
                raise ValueError(
                    f"Entity field {finding_field!r} appears in both finding.entity "
                    "and intermediate_findings.entities. Each field name must be unique "
                    "across finding and intermediate_findings to avoid double-scoring "
                    "the same risk object on a single detection firing."
                )
        return self

    @model_validator(mode="after")
    def validate_fields_present_in_search(self) -> Self:
        """Heuristic check that entity/threat fields and token fields appear in the search.

        Collects two categories of field names and checks each against the search string
        using a case-insensitive substring match:

        1. Entity and threat object field names - fields declared in finding.entity,
           intermediate_findings.entities[*], and threat_objects[*].
        2. Token fields - field names extracted from $field_name$ tokens in
           finding.title and intermediate_findings.entities[*].message via
           EsTokenString.extract_token_fields.

        Errors for each category are reported separately to help authors identify
        which kind of reference is missing.

        Production-only: skipped for experimental and deprecated detections, as
        work-in-progress content may reference fields not yet present in the search.

        TODO: Consider expanding this check to all detection statuses. Expanding
        validation would catch known-broken field references in experimental content
        earlier, but requires: (1) STRT buy-in, as it would require content changes
        across the experimental corpus; and (2) measuring the false-positive rate
        of the heuristic against that corpus before committing to the expansion.

        TODO: This is a heuristic - substring matching cannot distinguish a
        field name appearing as an SPL output field from one appearing incidentally in
        a string literal or comment. Replace with proper SPL field parsing when available.

        Raises:
            ValueError: If any entity/threat field or token field does not appear as
                a substring in the search string, for production detections only.

        Returns:
            Self: The validated instance.
        """
        if self.status != ContentStatus.production:
            return self

        search_lower = self.search.root.lower()

        entity_fields: set[str] = set()
        if self.finding is not None:
            entity_fields.add(self.finding.entity.field.lower())
        if self.intermediate_findings is not None:
            entity_fields.update(
                e.field.lower() for e in self.intermediate_findings.entities
            )
        entity_fields.update(t.field.lower() for t in self.threat_objects)

        token_fields: set[str] = set()
        if self.finding is not None:
            token_fields.update(self.finding.title.extract_token_fields)
        if self.intermediate_findings is not None:
            for e in self.intermediate_findings.entities:
                token_fields.update(e.message.extract_token_fields)

        errors: list[str] = []

        missing_entity_fields = sorted(
            f for f in entity_fields if f not in search_lower
        )
        if missing_entity_fields:
            errors.append(
                "The following entity/threat fields are declared but do not appear "
                f"in the search: {missing_entity_fields}"
            )

        missing_token_fields = sorted(f for f in token_fields if f not in search_lower)
        if missing_token_fields:
            errors.append(
                "The following token fields referenced in risk messages or finding "
                f"titles do not appear in the search: {missing_token_fields}"
            )

        if errors:
            raise ValueError(
                "Field references do not appear in the search string "
                "(heuristic substring check):\n" + "\n".join(f"  - {e}" for e in errors)
            )
        return self

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the lookups directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("detections")

    @classmethod
    def update_dynamic_status(  # type: ignore[reportIncompatibleMethodOverride]
        cls, content: Sequence[Search]
    ) -> None:
        """Update the dynamic enum for event-based detections.

        Sequence is used over list because this method only iterates over content
        and never mutates it, making Sequence the more accurate contract.

        The reportIncompatibleMethodOverride suppression is intentional: the base
        class declares Sequence[ContentEnum], but this override narrows to
        Sequence[Search]. Search and ContentEnum are on different inheritance
        branches (Search extends SecurityContent; ContentEnum is a StrEnum), so
        the narrowing cannot be expressed as an LSP-compliant override. The
        runtime behaviour is correct — callers always pass Sequence[Search] to
        this override.
        """
        EventBasedDetectionEnum.__update_everything_dangerous__(
            EventBasedDetectionEnum,  # type: ignore[reportArgumentType]
            content,  # type: ignore[reportArgumentType]
        )

    @computed_field
    @property
    def all_possible_datasources(self) -> set[DataSource]:
        """Returns a flattened list of all possible datasources used by this detection.

        This is different than the data_source field because it is flattened and does not include any duplicates.

        Args:
            None

        Returns:
            set[DataSource]: A set of all possible datasources used by this detection.

        TODO: Consider returning set[DataSourceEnum] instead of set[DataSource] to be
        consistent with how self.data_source is typed (frozenset[frozenset[DataSourceEnum]]).
        Currently, callers like install.py access DataSource-specific attributes (e.g.
        supported_TA) directly on the returned objects, so any change here would require
        updating those call sites as well. Revisit once we rethink the "dynamic" enum approach
        """
        # Recall that since elements in the data_source field are enums, we must also fetch
        # the individual objects.
        # cast() is used here because ContentEnum.obj is typed as SecurityContent (the base),
        # but DataSourceEnum is only ever populated with DataSource objects — enforced by
        # DataSource.update_dynamic_status. The correct long-term fix is making ContentEnum
        # generic (see the TODO in ContentEnum's docstring).
        return cast(
            set[DataSource],
            set(ds.obj for ds in itertools.chain.from_iterable(self.data_source)),
        )

    @computed_field
    @property
    def research_site_path(self) -> str:
        """Return the category of this object."""
        return f"{self.category.value}/{self.id}"

    @computed_field
    @property
    def stanza_name(self) -> str:
        """Return the spec version (according to Enterprise Security) of the detection."""
        return f"{self._content_dir.app_settings.content_prefix} - {self.name} - Rule"

    @computed_field
    @property
    def kill_chain_phases(self) -> frozenset[EnterpriseSecurityKillChainPhase]:
        """Return the set of Enterprise Security kill chain phases associated with this detection.

        Returns:
            frozenset[EnterpriseSecurityKillChainPhase]: Set of Enterprise Security kill chain phases.
        """
        phases: set[EnterpriseSecurityKillChainPhase] = set()
        for mitre_attack_id in self.mitre_attack_id:
            # cast() is used here for the same reason as all_possible_datasources:
            # ContentEnum.obj is typed as SecurityContent, but SupportedMitreAttackEnrichmentsEnum
            # is only ever populated with SupportedMitreAttackEnrichments objects.
            enrichment = cast(SupportedMitreAttackEnrichments, mitre_attack_id.obj)
            phases.update(enrichment.enterpriseSecurityKillChainPhases)

        return frozenset(phases)

    @computed_field
    @property
    def mitre_attack_ids_names_only(self) -> frozenset[MITRE_ATTACK_ID_TYPE]:
        """Return the set of MITRE attack IDs (names only) associated with this detection.

        Returns:
            frozenset[MITRE_ATTACK_ID_TYPE]: Set of MITRE attack ID names.
        """
        return frozenset(attack.obj.name for attack in self.mitre_attack_id)

    @computed_field
    @property
    def nist(self) -> frozenset[NistCategory]:
        """Return the set of NIST controls associated with this detection.

        TTP detections map to DE_CM; all other types map to DE_AE. This
        preserves the legacy contentctl mapping where TTP detections
        (notable + risk) map to DE_CM.
        """
        if self.type == DetectionAnalyticsType.TTP:
            return frozenset({NistCategory.DE_CM})
        return frozenset({NistCategory.DE_AE})

    @computed_field
    @property
    def intermediate_finding_enabled(self) -> bool:
        """True when intermediate findings are present on this detection.

        Maps directly to action.risk = 1 in savedsearches.conf. In ES8+, a
        finding (via action.notable) also contributes risk scoring to its primary
        entity, so intermediate_finding_enabled=False does not mean the detection
        produces no risk — it means the ES risk action specifically is not enabled.

        SERIALIZATION USE ONLY: This property exists so that emit_ConfStanza_savedsearches
        can reference it by name via add_line's object_key parameter. For conditional
        access to self.intermediate_findings elsewhere, check
        `self.intermediate_findings is not None` directly to preserve type narrowing.
        """
        return self.intermediate_findings is not None

    @computed_field
    @property
    def finding_enabled(self) -> bool:
        """True when a finding is present on this detection.

        Maps directly to action.notable = 1 in savedsearches.conf. In ES8+,
        action.notable is responsible for both generating the finding and for risk
        scoring the finding's primary entity — so finding_enabled=True implies both
        a finding will be generated and that entity will receive risk scoring, even
        when intermediate_finding_enabled is False.

        SERIALIZATION USE ONLY: This property exists so that emit_ConfStanza_savedsearches
        can reference it by name via add_line's object_key parameter. For conditional
        access to self.finding elsewhere, check `self.finding is not None` directly
        to preserve type narrowing.
        """
        return self.finding is not None

    @computed_field
    @property
    def correlationsearch_enabled(self) -> bool:
        """True if this is a correlationsearch.

        All EBD have correlationsearch enabled, so this is always True
        """
        return True

    @computed_field
    @property
    def annotations_analytic_story(self) -> dict[str, frozenset[str]]:
        """Return the annotations needed for this detection in analyticstories.conf."""
        return {
            "cis20": self.cis20,
            "kill_chain_phases": self.kill_chain_phases,
            "mitre_attack": self.mitre_attack_ids_names_only,
            "nist": self.nist,
        }

    @computed_field
    @property
    def annotations(self) -> dict[str, frozenset[str]]:
        """Return the annotations needed for this detection in savedsearches.conf.

        Note that, specifically, the data type of data_source has been updated. Instead of
        a list of DataSources, where if a detection requires two data sources at once they
        were separated by ' AND ' , data_sources is now a set of sets.

        Returns:
            dict[str, frozenset[str]]: The annotations needed for this detection in savedsearches.conf.

        """
        return {
            "analytic_story": StoryEnum.enum_set_to_names_set(self.analytic_story),
            # TODO: This is a temporary fix since self.all_possible_datasources returns DataSource
            # objects and not the enums (whuich enum_set_to_names_set expects); revisit when we
            # rethink the dynamic enum approach
            "data_source": frozenset([ds.name for ds in self.all_possible_datasources]),
        } | self.annotations_analytic_story

    @computed_field
    @property
    def detection_type(self) -> DetectionType:
        """Return the detection type for the search.

        Returns:
            DetectionType: The detection type for the search.
        """
        return DetectionType.EBD

    @computed_field
    @property
    def _risk(self) -> list[dict[str, str | int]]:
        """Serialized risk entries for action.risk.param._risk in savedsearches.conf.

        Delegates to IntermediateFindings._risk for the entity entries, then appends
        serialized threat objects. Threat objects are sorted deterministically by
        (threat_object_field, threat_object_type). An empty threat_objects frozenset
        produces no threat object entries, suppressing them from conf output naturally.

        Use this property (not IntermediateFindings._risk) when serializing to conf,
        as IntermediateFindings._risk does not have access to threat_objects.
        """
        entries: list[dict[str, str | int]] = []
        if self.intermediate_findings is not None:
            entries.extend(self.intermediate_findings._risk)  # type: ignore[reportPrivateUsage]
        entries.extend(
            sorted(
                [
                    {
                        "threat_object_field": t.field,
                        "threat_object_type": t.type,
                    }
                    for t in self.threat_objects
                ],
                key=lambda x: (x["threat_object_field"], x["threat_object_type"]),
            )
        )
        return entries

    @computed_field
    @property
    def nes_fields(self) -> str:
        """Hardcoded NES fields for action.notable.param.nes_fields in savedsearches.conf.

        Retained for ES 7 compatibility. ES 8 does not emit this field when creating a
        detection in the UI.

        TODO: Remove once ES 7 support is no longer required.

        Returns:
            str: The hardcoded NES fields value.
        """
        return "user,dest"

    @computed_field
    @property
    def _risk_message(self) -> str | None:
        """Top-level risk message for action.risk.param._risk_message in savedsearches.conf.

        Returns the message from the first intermediate finding entity, sorted
        deterministically using the entity ordering defined by __lt__. This field
        is retained for ES 7 compatibility: ES 8 embeds per-entity messages within
        each entry in action.risk.param._risk, but ES 7 reads a single shared
        message from this top-level key.

        TODO: Remove once ES 7 support is no longer required.
        NOTE: Confirmed on ES 8 — this top-level field is silently ignored. ES 8 reads
            risk_message exclusively from per-entity entries in action.risk.param._risk.
            No conflict or override occurs.

        Returns:
            str: The message from the first intermediate finding entity, or None if
                intermediate findings are absent (Correlation/Hunting and some TTP detections).
                When None, the field is suppressed from conf output by the ES7_COMPAT
                gating block in emit_ConfStanza_savedsearches.
        """
        if self.intermediate_findings is None:
            return None
        return sorted(self.intermediate_findings.entities)[0].message.root

    @model_validator(mode="after")
    def enforce_correct_detection_folder(self) -> Self:
        """Ensure that a detection is in the correct folder in detections/ path.

        This function enforces two related contraints:
        1. If a detection has status: deprecated, it MUST be in a subfolder of
        the paths detections/deprecated.
        2. Otherwise, a detection must be in a subfolder of detections/{category}/,
        for instance detections/endpoint/windows, detections/endpoint,
        detections/cloud/aws, or detections/application
        Any number of arbitrary folder under detections/{category}/...
        are permitted.


        Returns:
            Self: A detection objects whose category/path have been validated.
        """
        if self.status is ContentStatus.deprecated:
            # This is a deprecated detection.
            # We must enforce that it occurs in the deprecated/ folder.
            # It may have any value for the category field.
            expected_folder = self.content_folder() / "deprecated"
            if not self._path.is_relative_to(self._content_dir.path / expected_folder):
                raise ValueError(
                    f"{self._path} has [status: deprecated] and MUST exist under the {expected_folder} directory"
                )
            # This is in the correct folder
            return self

        # Otherwise, this is a normal detection. We must ensure that its category matches the
        # folder that it lives in
        expected_folder = self.content_folder() / self.category
        if not self._path.is_relative_to(self._content_dir.path / expected_folder):
            raise ValueError(
                f"{self._path} has [category: {self.category}] and MUST exist under the [{expected_folder}] directory. BTW the status is: [{type(self.status)} {self.status}]"
            )

        return self

    @model_validator(mode="after")
    def update_drilldown_search_fields(self) -> Self:
        """Return the drilldowns written for this detection in savedsearches.conf.

        If the search field of a drilldown contains the string '%original_detection_search%',
        it will be replaced with a call to | savedsearch "<savedsearch_name>".

        This is important because if the original search is updated, it means that
        the drilldown will 'automatically' use the updated version of the search.
        If we do not make this change, then instead the original search is replicated
        into the drilldown and any updates to the original search will need to be
        manually reflected into the drilldown.

        Returns:
            Self [Detection]: The updated detection with drilldowns updated.
        """
        for drilldown in self.drilldown_searches:
            if "%original_detection_search%" in drilldown.search.root:
                drilldown.search = SplString(
                    drilldown.search.root.replace(
                        "%original_detection_search%",
                        f'| savedsearch "{self.stanza_name}"',
                    ),
                )
        return self

    def emit_ConfStanza_savedsearches(self) -> ConfStanza:
        """Generate the conf stanza for the search to be used in savedsearches.conf."""
        stanza = super().emit_ConfStanza_savedsearches()

        # Controls whether ES 7 compatibility fields are emitted. Set to False to
        # validate the impact of dropping _risk_message, _risk_score, verbose, and
        # nes_fields before removing them and their associated properties entirely.
        # See individual property docstrings for details on each field.
        ES7_COMPAT = True

        # intermediate_finding_enabled maps to action.risk in savedsearches.conf.
        if self.intermediate_findings is not None:
            stanza.add_line(self, "action.risk", "intermediate_finding_enabled")
            stanza.add_line(self, "action.risk.param._risk", "_risk")
            if ES7_COMPAT:
                # ES 7 compat: see _risk_message property.
                # _risk_message returns None when intermediate_findings is None, but
                # the enclosing `if self.intermediate_findings is not None` already
                # guarantees it is non-None here — no additional null check needed.
                stanza.add_line(
                    self, "action.risk.param._risk_message", "_risk_message"
                )
                # ES 7 compat: see _risk_score property.
                stanza.add_line(
                    self.intermediate_findings,
                    "action.risk.param._risk_score",
                    "_risk_score",
                )
                # ES 7 compat: see verbose property.
                stanza.add_line(
                    self.intermediate_findings, "action.risk.param.verbose", "verbose"
                )
        # finding_enabled maps to action.notable in savedsearches.conf.
        if self.finding is not None:
            stanza.add_line(self, "action.notable", "finding_enabled")
            stanza.add_line(
                self.finding.title, "action.notable.param.rule_title", "root"
            )
            stanza.add_line(self.finding, "action.notable.param._entities", "_entities")
            if ES7_COMPAT:
                # ES 7 compat: see nes_fields property.
                stanza.add_line(self, "action.notable.param.nes_fields", "nes_fields")
            stanza.add_line(
                self, "action.notable.param.rule_description", "description"
            )
            stanza.add_line(
                self, "action.notable.param.security_domain", "security_domain"
            )
            stanza.add_line(self, "action.notable.param.severity", "severity")
        if self.correlationsearch_enabled:
            stanza.add_line(
                self, "action.correlationsearch.enabled", "correlationsearch_enabled"
            )
            stanza.add_line(
                self, "action.correlationsearch.detection_type", "detection_type"
            )
            stanza.add_line(self, "action.correlationsearch.label", "stanza_name")
            stanza.add_line(self, "action.correlationsearch.annotations", "annotations")
            stanza.add_line(self, "action.correlationsearch.metadata", "metadata")
        if self.drilldown_searches:
            stanza.add_line(
                self, "action.notable.param.drilldown_searches", "drilldown_searches"
            )

        return stanza


class EventBasedDetectionEnum(ContentEnum):
    """Empty Placeholder Enum for baselines.

    NOTE: This enum is dynamically populated at runtime by the EventBasedDetection.UpdateDynamicEnum method.
    """

    pass
