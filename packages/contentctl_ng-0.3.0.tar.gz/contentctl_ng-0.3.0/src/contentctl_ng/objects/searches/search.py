"""This module contains information supporting Search objects.

The definition of a search is intentionally broad and, at this time,
this class will be used to define Simple SPL Searches, EBD, FBD,
and potentially other types of searches. As this complexity and
understanding increases, we may split this class into multiple
different files for logicial separation and simplicity.
"""

import abc
import datetime
from enum import StrEnum, auto
from typing import Annotated, Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FilePath,
    HttpUrl,
    NonNegativeInt,
    PrivateAttr,
    WithJsonSchema,
    computed_field,
    field_validator,
)

from contentctl_ng.objects.atomic_guid import AtomicGuidEnum
from contentctl_ng.objects.conf import ConfStanza
from contentctl_ng.objects.content import (
    ContentStatus,
    DeprecatableSecurityContent,
    Product,
)
from contentctl_ng.objects.data_source import DataSourceEnum
from contentctl_ng.objects.lookup import Lookup
from contentctl_ng.objects.macro import Macro
from contentctl_ng.objects.schedule import Schedule, ScheduleEnum
from contentctl_ng.objects.validated_strings import SplString


class Cis18Value(StrEnum):
    """This enum defines the CIS 18 values."""

    CIS_0 = "CIS 0"
    CIS_1 = "CIS 1"
    CIS_2 = "CIS 2"
    CIS_3 = "CIS 3"
    CIS_4 = "CIS 4"
    CIS_5 = "CIS 5"
    CIS_6 = "CIS 6"
    CIS_7 = "CIS 7"
    CIS_8 = "CIS 8"
    CIS_9 = "CIS 9"
    CIS_10 = "CIS 10"
    CIS_11 = "CIS 11"
    CIS_12 = "CIS 12"
    CIS_13 = "CIS 13"
    CIS_14 = "CIS 14"
    CIS_15 = "CIS 15"
    CIS_16 = "CIS 16"
    CIS_17 = "CIS 17"
    CIS_18 = "CIS 18"


class Severity(StrEnum):
    """This enum defines the severity values for notables."""

    INFORMATIONAL = "informational"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class TestData(BaseModel):
    """This class defines a test data structure that can be used to test the Search class.

    It contains a link to the file and what is required to replay that file, most
    notable the source, sourcetype, and index
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    data: HttpUrl | FilePath = Field(
        description="The path to the file to be used for the test. This can be a local file path or a URL."
    )

    source: str = Field(
        description="The source to use when the data is replayed via HTTP Event Collector (HEC)"
    )
    sourcetype: str = Field(
        description="The sourcetype to use when the data is replayed via HTTP Event Collector (HEC) endpoint"
    )

    # TODO: In what location should the default and replay indices be tracked and
    # how (and when) should contentctl test ensure the presence of all the indices?
    # At the beginning of a test, does contentctl test or contentctl infrastructure need
    # to iterate over all content and get all indexes and ensure they exist? Or check
    # at the beginning of an individual test? Or something else?
    index: str = Field(
        default="contentctl_testing_index",
        description="The index to use when the data is replayed via HTTP Event Collector (HEC) endpoint.",
    )


class SearchTest(BaseModel):
    """This class defines a test for the Search class.

    Any Search object can be tested using some test data and the search should
    be expected to return some number of results (at least one).
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    name: str = Field(
        description="The name of this test.  Names within a test section MUST be unique."
    )

    attack_data: list[TestData] = Field(
        description="A list of test data that will be used to test the search.",
        default_factory=list,
    )

    expected_results: NonNegativeInt = Field(
        description="The number of results that are expected to be "
        "returned by the search when this test data is used. Note "
        "that this value CAN be zero because test data may represent "
        "a case where we intentionally DO NOT want a test to "
        "return results, for example in a false positive test.",
        default=1,
    )

    description: str | None = Field(
        description="A description for the test. "
        "Please refer to specific test types for more information."
    )


class ExperimentalTest(SearchTest):
    """This class defines an experimental test for the Search class.

    An experimental test, if defined, will not be run 'by default' during
    testing. The reasons it will not be run MUST be documented in the
    description field, which is NOT optional for this test type.

    However, we should still make every effort to provide test data, when
    possible, to enable interactive testing and for documentation purposes.
    """

    # TODO: Convert Consider conversion of Literal to StrEnum
    test_type: Literal["experimental"]
    description: str = Field(
        description="The description field is mandatory if for an experimental test. "
        "We MUST document why this search is experimental so that authors and users can "
        "understand the limitations of this search and any future plans to migrate the test "
        "to a unit test. Note that there may be still test data files available for the search, "
        "but they are not required."
    )


class UnitTest(SearchTest):
    """This class defines a unit test for the Search class.

    A unit test, if defined, MUST be one that is run AND succeeds.
    If a unit test ultimately fails, then the search should not
    pass testing.
    """

    # TODO: Convert Consider conversion of Literal to StrEnum
    test_type: Literal["unit"]
    description: str | None = Field(
        description="The description field is optional for a unit test."
        "However, a content developer may find it useful to give some extra"
        "context or other information about the test.",
        default=None,
    )
    attack_data: list[TestData] = Field(
        description="A list of test data that will be used to test the search.",
        min_length=1,
    )


class SecurityDomain(StrEnum):
    """This enum defines the security domain that this search is associated with.

    TODO: Where are these defined in product?
    """

    access = auto()
    audit = auto()
    endpoint = auto()
    identity = auto()
    network = auto()
    threat = auto()


class Search(DeprecatableSecurityContent, abc.ABC):
    """The Search class defines the simplest type of search we want to support.

    This class is meant to be very high level and generic,
    with many optional fields and few requirements outside
    of what any Security Content Object requires.
    From here, we will derive more specific types of searches
    that are more specialized and have more specific requirements.
    """

    search: SplString = Field(
        description="This field contains valid SPL query. "
        "This has a relaxed constraint such that a search does "
        "NOT need to start with '| tstats' or a macro. However, it"
        "DOES require that the search does NOT begin or end with "
        "white space such as a space or newline",
    )
    how_to_implement: str = Field(
        description="This field included implementation details for this "
        "specific search.  This may include things like how to collect a "
        "given type of data, how to ingest that data (such as the Splunk "
        "Technical Add-on required to process it), or other details. "
        "This field will likely be moved into the Data Sources objects "
        "directly in the future."
    )

    # The following field is marked as frozen since the field is also frozen
    # in the parents.  Search content supports all possible statuses.
    # TODO: Provide some level of runtime testing for experimental, production,
    # and deprecated searches, even if those searches are lacking UnitTests. This
    # could be as simple as executing the SPL to ensure it is valid.

    # ContentStatus.experimental searches have a lower implied quality (according to the the Content Developer)
    # than production searches. A high-quality experimental search should be considered
    # for promotion to a production search by the Content Developer.
    # Experimental Searches:
    # 1. Do not REQUIRE a UnitTest (but one may be provided).
    # 2. Require an ExperimentalTest with a description as to why the detection is Experimental.

    # ContentStatus.production searches are the highest quality searches (according to the Content Developer).
    # 1. Content Developers should make every effort to provide a UnitTest (but it is not required).
    # If a UnitTest is provided, it will be tested and must pass.
    # 2. If a UnitTest is not provided, an ExperimentalTest with description must be provided,
    # explaining why the search is not testable.  This is similar functionality to the
    # "manual_test" field in legacy contentctl.

    # ContentStatus.deprecated searches are those which are marked for future removal in upcoming
    # releases of the app.  They likely still declare UnitTest and ExperimentalTest,
    # but at this time are not tested during contentctl test runs.  Deprecated detections
    # may be deprecated for a number of reasons - for install they perform poorly, are low
    # quality/no longer relevant, or no longer work.

    # Note: removed is INTENTIONALLY absent from this enum as noted above in the description
    # of this enum.

    # The following field is marked as frozen to prevent it from being changed
    # after the object is created. Pyright should not be throwing an issue here
    # as the field is marked as frozen, but it does so we ignore it.
    status: Literal[  # pyright: ignore[reportIncompatibleVariableOverride]
        ContentStatus.production, ContentStatus.experimental, ContentStatus.deprecated
    ] = Field(
        frozen=True,
        description="The status of this piece of content. Note that it intentionally "
        "cannot be 'removed' as only RemovedContent may be 'removed'.",
    )

    known_false_positives: str = Field(
        description="This field contains known false positives for this "
        "detection. This field should include advice on how to tune "
        "or improve this detections to reduce false positives that"
        "may be specific to a user's given environment but, for some"
        "reason, have not been included in the Detection itself."
    )

    security_domain: SecurityDomain = Field(
        description="The security domain that this detection is designed "
        "to run against."
    )

    data_source: Annotated[
        frozenset[frozenset[DataSourceEnum]],
        WithJsonSchema(
            {
                "type": "array",
                "description": "A list of data sources that this search is expected to "
                "query. Each entry in this list should be one or more data sources in "
                "in the formats such as the following, where if more than 1 datasource "
                "must be defined because of a JOIN or subsearch operation, they are AND'd "
                "together:\n"
                "- SysmonEvent ID 1\n"
                "- Sysmon EventID 2 AND Sysmon EventID 3\n",
                "items": {"type": "string"},
            }
        ),
    ] = Field(
        description="A list of data sources that this search is expected to "
        "query. Each entry in this list should be one or more data sources in "
        "in the formats such as the following, where if more than 1 datasource "
        "must be defined because of a JOIN or subsearch operation, they are AND'd "
        "together:\n"
        "- SysmonEvent ID 1\n"
        "- Sysmon EventID 2 AND Sysmon EventID 3\n",
    )

    @field_validator("data_source", mode="before")
    def split_ANDED_data_source_string_to_set(cls, v: Any) -> list[list[str]]:
        """Split an AND'd data source string into a frozenset of DataSourceEnum objects.

        The purpose of this is to allow requested format of the YML file for multiple
        data sources separated by AND while maintaining the internal frozenset implementation
        for data_source field.

        This function INTENTIONALLY does not ensure that each string is a proper DataSourceEnum,
        not does it perform deduplication of values.  The automatic handling of the field typing
        will handle that.

        Args:
            v (list[str]): A string like "SysmonEvent ID 1 AND Sysmon EventID 2" or a string
            with a single datasource like "SysmonEvent ID 1" with no AND.

        Returns:
            list[list[str]]: A list of lists of data source strings. Note that these strings are NOT
            validated by this function to be valid DataSourceEnum values.
        """
        if not isinstance(v, list):
            raise ValueError(
                f"data_source must be a list of strings, but instead was {type(v)}: {v}"
            )

        constructed_list_of_datasource_strings: list[list[str]] = []
        for index, element in enumerate(v):
            if isinstance(element, list):
                # If the element is a list, it must be a list of strings.
                if all(isinstance(item, str) for item in element):
                    # If so, simply append that to the constructed list
                    constructed_list_of_datasource_strings.append(element)
                    continue
                else:
                    # If not, raise an error - this is not in a supported format
                    element_types = [type(item).__name__ for item in element]
                    raise ValueError(
                        f"data_source  elemnt {index} was, itself, a list. But it was not a list of strings. Instead, it contains {element_types}"
                    )
            elif not isinstance(element, str):
                raise ValueError(
                    f"data_source must be a list of strings, but instead element {index} was {type(element).__name__}: {element}"
                )
            constructed_list_of_datasource_strings.append(element.split(" AND "))
        return constructed_list_of_datasource_strings

    product: frozenset[
        Literal[
            Product.SPLUNK_ENTERPRISE,
            Product.SPLUNK_ENTERPRISE_SECURITY,
            Product.SPLUNK_CLOUD,
        ]
    ] = Field(
        description="The product(s) that this search is designed to run on. "
        "At this time this is a required field, but to the best of our knowledge the "
        "following three products should always be listed.  If this changes in the "
        "future, please reach out to the contentctl-ng maintainers:"
        "\n- Splunk Enterprise"
        "\n- Splunk Enterprise Security"
        "\n- Splunk Cloud",
        min_length=3,
        max_length=3,
    )

    schedule: ScheduleEnum | None = Field(
        default=None,
        description="The schedule for this search, derived from Schedule objects. "
        "Most commonly, this will be used. For custom scheduling behavior, see "
        "custom_schedule. Note: Exactly one of 'schedule' and 'custom_schedule' "
        "should be defined.",
    )

    custom_schedule: Schedule | None = Field(
        default=None,
        description="The custom schedule for this search. This is an Inline "
        "Schedule Object and should be used when this search requires special "
        "scheduling behavior. NOTE: Exactly one of 'schedule' and 'custom_schedule' "
        "should be defined.",
    )

    atomic_guid: list[AtomicGuidEnum] = Field(
        description="The atomic guid(s) for this search.",
        default_factory=list,
        min_length=0,
    )

    tests: list[
        Annotated[
            ExperimentalTest | UnitTest,
            Field(discriminator="test_type"),
        ]
    ] = Field(
        description="A list of tests that can be run against this search. "
        "Tests should contain information to automatically validate the search during "
        "unit testing or information about why it cnanot be automatically validated.",
        default_factory=list,
        min_length=0,
    )

    # When validating the search string, determine whether or
    # not a _filter macro must be present in the search.
    # Our EBDs will require this, but it is explicitly set to
    # False in Baselines.
    _require_filter_macro: bool = True

    # In order to track and validate the dependencies of
    # content, after parsing and validating the content we
    # must ensure that we enrich + validate any references
    # they may have to macros and lookups. This is also important
    # during the contentctl-ng test mode:changes workflow - when a
    # dependency like a macro or lookup is changed, we must test all
    # the content that uses it.
    _macros: frozenset[Macro] = PrivateAttr()
    _lookups: frozenset[Lookup] = PrivateAttr()

    @computed_field
    @property
    def severity(self) -> Severity:
        """Generate the severity for the search to be used in savedsearches.conf.

        The severity is based on the highest risk score of the objects in the search.
        If an object does not have an RBA section, then the severity has a default
        value of Severity.HIGH. Since Searches do not have an RBA section,
        this will always return Severity.HIGH.

        Raises:
            NotImplementedError: If the search has an RBA section, but the `severity` computed_field is not defined.

        Returns:
            Severity: The severity for the search. Always returns Severity.HIGH for base searches.
        """
        if getattr(self, "rba", None) is None:
            # Return Severity of high if there are no risk objects
            return Severity.HIGH

        raise NotImplementedError(
            f"Search object with name {self.name} has an RBA section.  "
            f"Please define the `severity` computed_field for {type(self).__name__}, which is a child class that has inherited from `Search`"
        )

    @computed_field
    @property
    def _schedule(self) -> Schedule:
        """Method for normalizing the format of the schedule field.

        Because the schedule field can be either an Schedule or a
        ScheduleEnum, this method provides a consistent way to access
        the schedule as an Schedule.


        Returns:
            Schedule: The schedule as an Schedule object
        """
        if self.schedule is None:
            return self.custom_schedule
        return self.schedule.obj

    # TODO: Can some of the logic in model_post_inits be moved into field_validators?
    def model_post_init(self, __context__: Any) -> None:
        """Ensures existence of any macros/lookups referenced by the search.

        If filter macros are used by not explicitly defined, this will create
        the filter appropriate macro and update the enum accordingly.

        Args:
            __context__ (Any): Additional context provided by pydantic

        Returns:
            _type_: None
        """
        super().model_post_init(__context__)

        # If neither schedule nor custom_schedule is set, try to derive a default
        # schedule from the class name (e.g. "default_eventbaseddetection").
        if self.schedule is None and self.custom_schedule is None:
            default_name = f"Default {type(self).__name__}"
            default_filename = f"default_{type(self).__name__.lower()}.yml"
            try:
                self.schedule = ScheduleEnum[default_name]
            except KeyError:
                raise ValueError(
                    f"No 'schedule' or 'custom_schedule' was provided for this "
                    f"{type(self).__name__} and the default schedule '{default_name}' "
                    f"does not exist. Either specify a 'schedule' key or add a "
                    f"schedule file named '{default_filename}'."
                )

        # Ensure that EXACTLY one of schedule and custom_schedule is defined
        if self.schedule is not None and self.custom_schedule is not None:
            raise ValueError(
                "Exactly one of 'schedule' or 'custom_schedule' must be defined"
            )

        # Get all the macros used in the search
        self._macros = self.search.extract_macros(
            self._content_dir.app_settings,
            self._require_filter_macro,
            search_name=self.name,
        )

        # Get all the lookups used in the search
        self._lookups = self.search.extract_lookups(self._content_dir.app_settings)

    # Properties for constructing the conf file below
    @computed_field
    @property
    def stanza_name(self) -> str:
        """Generate the name for the search.

        For example:
        [ESCU - Common Ransomware Extensions - Rule]
        or
        [ESCU - Baseline of blocked outbound traffic from AWS]

        for that reason, we only prepen the app label to the name and do
        not include the postfix.
        """
        return f"{self._content_dir.app_settings.content_prefix} - {self.name}"

    @computed_field
    @property
    def type_analytic_story(self) -> str:
        """Generate the type for the search to be used in analyticstories.conf."""
        return "detection"

    @computed_field
    @property
    def confidence(self) -> str:
        """Generate the asset type for the search to be used in analyticstories.conf."""
        return "medium"

    @computed_field
    @property
    def cis20(self) -> frozenset[Cis18Value]:
        """Generate the CIS 20 controls for the search to be used in analyticstories.conf.

        The enum is intentionally Cis18 even though the field is named cis20 for legacy reasons.

        Returns:
            list[Cis18Value]: List of CIS 20 controls applicable to this search.
        """
        if self.security_domain == SecurityDomain.network:
            values = [Cis18Value.CIS_13]
        else:
            values = [Cis18Value.CIS_10]
        return frozenset(values)

    @computed_field
    @property
    def metadata(self) -> dict[str, str | float]:
        """Return the metadata for the search.

        TODO: Legacy contentctl uses publish time of midnight.
        To support multiple releases in a day, we should probably include the exact time.
        https://github.com/splunk/contentctl/blob/8369512b65e4d61da0535d4c46ec6884ae163ddb/contentctl/objects/abstract_security_content_objects/detection_abstract.py#L487
        Is there a reason NOT to include exact time?

        Returns:
            dict[str, str]: The metadata for the search.
        """
        return {
            "deprecated": "1" if self.deprecation_info else "0",
            "detection_id": str(self.id),
            "detection_version": str(self.version),
            "publish_time": datetime.datetime(
                self.modification_date.year,
                self.modification_date.month,
                self.modification_date.day,
                0,
                0,
                0,
                0,
                tzinfo=datetime.timezone.utc,
            ).timestamp(),
        }

    def emit_ConfStanza_analyticstories(self) -> ConfStanza:
        """Generate the conf stanza for the search to be used in analyticstories.conf."""
        stanza = ConfStanza(name=f"savedsearch://{self.stanza_name}")
        stanza.add_line(self, "type", "type_analytic_story")
        stanza.add_line(self, "asset_type")
        stanza.add_line(self, "confidence")
        stanza.add_line(self, "how_to_implement")
        stanza.add_line(self, "annotations", "annotations_analytic_story")
        stanza.add_line(self, "known_false_positives", "known_false_positives")
        stanza.add_line(self.search, "providing_technologies", "providing_technologies")
        stanza.add_line(self, "explanation", "description")

        return stanza

    def emit_ConfStanza_savedsearches(self) -> ConfStanza:
        """Generate the conf stanza for the search to be used in savedsearches.conf.

        This method also enforces a max length of 81 characters of the stanzaname.
        This is a unique limitation for entires in savedsearches.conf due to
        Enterprise Security Cloning behavior documented below.

        Returns:
            ConfStanza: The conf stanza for the search.
        """
        # Because of the way that savedsearhces.conf is updated when a search is cloned,
        # there is a unique restriction on the length of the stanza name. As such, it
        # does not make sense to enforce the max_length in the ConfStanza class itself.
        # We harcode this check here.
        # For instance, when a detection is cloned, like the search:
        # ESCU - Test Search - Rule
        # It will be cloned to the new name in the format:
        # "{security_domain_value} - {search_name} - Rule"
        # generating something like
        # "Endpoint - ESCU - Test Search - Rule - Rule"
        # The additiona of "Endpoint -  - Rule" is 18 characters, and
        # ES Correlation Searches cannot be longer than 99 characters, so we
        # put a limit on savedsearches.conf entries at 81 characters to
        # allow appropriate cloning.

        if len(self.stanza_name) > 81:
            raise ValueError(
                f"Stanza name '{self.stanza_name}' is longer than 81 characters (length: {len(self.stanza_name)}). "
                "This limitation exists because when a Search is cloned, "
                "the new name has 18 characters added to it, "
                "and Enterprise Security validation fails when a "
                "search has more than 99 characters.\n"
                "Please update the search name field in the YML to be "
                f"{81 - len(self.stanza_name.replace(self.name, ''))} characters or less."
            )

        stanza = ConfStanza(name=self.stanza_name)

        stanza.add_line(self, "description")

        stanza.add_line(self._schedule, "cron_schedule")
        stanza.add_line(self._schedule, "dispatch.earliest_time", "earliest_time")
        stanza.add_line(self._schedule, "dispatch.latest_time", "latest_time")
        stanza.add_line(self._schedule, "schedule_window")
        stanza.add_line(self._schedule, "alert.digest_mode", "digest_mode")
        stanza.add_line(self._schedule, "disabled")
        stanza.add_line(self._schedule, "enableSched")
        stanza.add_line(self._schedule, "allow_skew")
        stanza.add_line(self._schedule, "counttype")
        stanza.add_line(self._schedule, "relation")
        stanza.add_line(self._schedule, "quantity")
        stanza.add_line(self._schedule, "realtime_schedule")
        stanza.add_line(self._schedule, "is_visible")
        stanza.add_line(self.search, "search", "root")

        return stanza
