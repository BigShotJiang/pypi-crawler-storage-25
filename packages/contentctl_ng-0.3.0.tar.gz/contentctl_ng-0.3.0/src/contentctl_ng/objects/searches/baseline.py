"""Define the baseline class.

This is not particularly complicated today, since they
are just a search without testing or other relevant complexity.
"""

from pathlib import Path
from typing import Annotated

from pydantic import Field, WithJsonSchema, computed_field

from contentctl_ng.objects.content import ContentEnum, DeprecatableContentType
from contentctl_ng.objects.searches.search import DataSourceEnum, Search


class Baseline(Search):
    """The Baseline class defines a baseline search.

    It is meant to serve as a search which generates some dependencies,
    such as populating or updating a Lookup, for another piece of content.
    This other piece of Content could be a Detection or another Baseline.
    """

    # Baselines are not supposed to have _filter macros, so these
    # are disabled. We cannot put this as a field annotation
    # because fields with leading _ are not fields and it raises
    # a Pydantic Error
    _require_filter_macro: bool = False

    data_source: Annotated[
        frozenset[frozenset[DataSourceEnum]],
        WithJsonSchema(
            {
                "type": "array",
                "description": "Note: Baselines do not require data_source at this time, "
                "but it may be optionally provided. "
                "A list of data sources that this search is expected to "
                "query. Each entry in this list should be one or more data sources in "
                "in the formats such as the following, where if more than 1 datasource "
                "must be defined because of a JOIN or subsearch operation, they are AND'd "
                "together:\n"
                "- SysmonEvent ID 1\n"
                "- Sysmon EventID 2 AND Sysmon EventID 3\n",
                "items": {"type": "string"},
            }
        ),
    ] = Field(
        default_factory=frozenset,
        description="Note: Baselines do not require data_source at this time, "
        "but it may be optionally provided. "
        "A list of data sources that this search is expected to "
        "query. Each entry in this list should be one or more data sources in "
        "in the formats such as the following, where if more than 1 datasource "
        "must be defined because of a JOIN or subsearch operation, they are AND'd "
        "together:\n"
        "- SysmonEvent ID 1\n"
        "- Sysmon EventID 2 AND Sysmon EventID 3\n",
    )

    @computed_field
    @property
    def deprecatable_content_type(self) -> DeprecatableContentType:
        """Return the deprecatable content type for this object."""
        return DeprecatableContentType.Baseline

    @classmethod
    def content_folder(cls) -> Path:
        """Return the path to the baselines directory.

        Note this path is relative to the root of a content directory.
        """
        return Path("baselines")

    @classmethod
    def update_dynamic_status(cls, content: list[Search]) -> None:
        """Update the dynamic enum for the baselines."""
        BaselineEnum.__update_everything_dangerous__(BaselineEnum, content)


class BaselineEnum(ContentEnum):
    """Empty Placeholder Enum for baselines.

    NOTE: This enum is dynamically populated at runtime by the Baseline.UpdateDynamicEnum method.
    """

    pass
