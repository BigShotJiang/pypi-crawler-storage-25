# contentctl
<p align="center">
<img src="https://github.com/splunk/contentctl-ng/raw/refs/heads/main/docs/contentctl_logo_white.png" title="In case you're wondering, it's a capybara" alt="" width="250" height="250"></p>
</p>