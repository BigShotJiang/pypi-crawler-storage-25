"""Ultrasonic Audio Steganography Engine.

Embeds data in ultrasonic frequencies (17-20kHz) that are:
- Inaudible to most humans (adult hearing typically cuts off at 16-17kHz)
- Recordable by standard computer audio hardware (up to Nyquist frequency)
- Survivable through AAC/MP3 compression at sufficient bitrates

Critical Frequency Analysis:
- Human hearing range: 20Hz - 20kHz (young), 20Hz - 16kHz (adults)
- 44.1kHz sample rate -> Nyquist = 22.05kHz (max recordable)
- 48kHz sample rate -> Nyquist = 24kHz
- AAC 64kbps cutoff: ~14kHz
- AAC 128kbps cutoff: ~16kHz
- AAC 192kbps cutoff: ~18-20kHz
- AAC 320kbps cutoff: ~20kHz

Optimal embedding band: 17-19.5kHz
- Above most adult hearing thresholds
- Below Nyquist for 44.1kHz sampling
- Survives high-bitrate AAC compression
"""

import numpy as np
from scipy.signal import butter, filtfilt, hilbert, medfilt


class UltrasonicEngine:
    """Core ultrasonic steganography operations."""

    ULTRASONIC_BANDS = {
        'conservative': {'dot': 17000, 'dash': 18500},
        'standard': {'dot': 17500, 'dash': 19000},
        'aggressive': {'dot': 18000, 'dash': 19500},
        'maximum': {'dot': 18500, 'dash': 20000},
    }

    @staticmethod
    def find_optimal_frequencies(sample_rate: int, target_bitrate: int = 128,
                                  mode: str = 'standard') -> tuple:
        """Calculate optimal carrier frequencies based on sample rate and target bitrate.

        Args:
            sample_rate: Audio sample rate (44100, 48000, etc.)
            target_bitrate: Expected AAC/MP3 bitrate in kbps
            mode: 'conservative', 'standard', 'aggressive', or 'maximum'

        Returns:
            (freq_dot, freq_dash) tuple in Hz
        """
        nyquist = sample_rate / 2.0

        bands = UltrasonicEngine.ULTRASONIC_BANDS.get(mode, UltrasonicEngine.ULTRASONIC_BANDS['standard'])
        freq_dot = bands['dot']
        freq_dash = bands['dash']

        if target_bitrate >= 192:
            freq_dot = min(freq_dot, nyquist - 1000)
            freq_dash = min(freq_dash, nyquist - 500)
        elif target_bitrate >= 128:
            freq_dot = min(freq_dot, 17500)
            freq_dash = min(freq_dash, 18500)
        elif target_bitrate >= 64:
            freq_dot = min(freq_dot, 15000)
            freq_dash = min(freq_dash, 16000)
        else:
            freq_dot = min(freq_dot, 13000)
            freq_dash = min(freq_dash, 14000)

        freq_dot = min(freq_dot, nyquist - 2000)
        freq_dash = min(freq_dash, nyquist - 1000)

        return int(freq_dot), int(freq_dash)

    @staticmethod
    def analyze_hearing_threshold(age: int = 30) -> float:
        """Estimate upper hearing threshold based on age.

        Approximate formula: max_freq = 20000 - (age - 20) * 200
        """
        return max(8000, 20000 - (age - 20) * 200)

    @staticmethod
    def generate_ultrasonic_wave(text: str, wpm: float, freq_dot: int, freq_dash: int,
                                  sample_rate: int, volume: float = 0.1,
                                  redundancy: int = 1) -> np.ndarray:
        """Generate ultrasonic Morse waveform.

        Uses FSK modulation with two ultrasonic carriers.
        """
        dot_len = 1.2 / wpm
        dash_len = dot_len * 3

        envelope_len = int(0.003 * sample_rate)
        if envelope_len < 2:
            envelope_len = 2

        def create_tone(duration: float, f_tone: float) -> np.ndarray:
            num_samples = int(duration * sample_rate)
            if num_samples < 1:
                return np.array([], dtype=np.float32)
            t = np.linspace(0, duration, num_samples, False)
            tone = np.sin(2 * np.pi * f_tone * t)
            actual_env = min(envelope_len, len(tone) // 3)
            if actual_env > 1:
                env = np.linspace(0, 1, actual_env)
                tone[:actual_env] *= env
                tone[-actual_env:] *= env[::-1]
            return tone.astype(np.float32)

        silence_dot = np.zeros(int(dot_len * sample_rate), dtype=np.float32)
        silence_char = np.zeros(int(dash_len * sample_rate), dtype=np.float32)
        silence_word = np.zeros(int(dot_len * 7 * sample_rate), dtype=np.float32)

        audio_segments = []

        morse_chars = text.split()
        words = []
        current_word = []
        for char in morse_chars:
            if char == '':
                if current_word:
                    words.append(''.join(current_word))
                    current_word = []
                words.append('')
            else:
                current_word.append(char)
        if current_word:
            words.append(''.join(current_word))

        for i, word in enumerate(words):
            if word == '':
                if i < len(words) - 1:
                    audio_segments.append(silence_word)
                continue

            for j, symbol in enumerate(word):
                if symbol == '.':
                    audio_segments.append(create_tone(dot_len, freq_dot) * volume)
                elif symbol == '-':
                    audio_segments.append(create_tone(dash_len, freq_dash) * volume)

                if j < len(word) - 1:
                    audio_segments.append(silence_dot)

            if i < len(words) - 1 and word != '':
                audio_segments.append(silence_char)

        if not audio_segments:
            return np.array([], dtype=np.float32)

        return np.concatenate(audio_segments).astype(np.float32)

    @staticmethod
    def generate_protocol_wave(text: str, wpm: float, freq_dot: int, freq_dash: int,
                                sample_rate: int, volume: float = 0.1,
                                redundancy: int = 3) -> np.ndarray:
        """Generate ultrasonic wave with protocol framing (KA...AR)."""
        from morse_transceiver.morse_logic import MorseLogic

        morse_code = MorseLogic.text_to_morse(text, use_protocol=True)

        if redundancy > 1:
            gap = "   "
            repeated_morse = (morse_code + gap) * redundancy
            morse_code = repeated_morse.strip()

        return UltrasonicEngine.generate_ultrasonic_wave(
            morse_code, wpm, freq_dot, freq_dash, sample_rate, volume
        )

    @staticmethod
    def extract_ultrasonic_signal(data: np.ndarray, sample_rate: int,
                                   freq_dot: int, freq_dash: int,
                                   wpm: float, bandwidth: int = 200) -> tuple:
        """Extract ultrasonic Morse signal from audio data.

        Uses dual bandpass filtering + Hilbert envelope detection.

        Returns:
            (morse_string, status_message)
        """
        if len(data.shape) > 1:
            data = np.mean(data, axis=1)

        data = data - np.mean(data)

        nyquist = 0.5 * sample_rate

        def bandpass_extract(signal, center_freq, bw):
            low = max(0.001, (center_freq - bw) / nyquist)
            high = min(0.999, (center_freq + bw) / nyquist)
            if low >= high:
                return np.zeros_like(signal)
            b, a = butter(4, [low, high], btype='band')
            filtered = filtfilt(b, a, signal)
            envelope = np.abs(hilbert(filtered))
            return envelope

        env_dot = bandpass_extract(data, freq_dot, bandwidth)
        env_dash = bandpass_extract(data, freq_dash, bandwidth)

        def get_binary(envelope):
            if len(envelope) == 0:
                return np.array([], dtype=bool)
            floor = np.percentile(envelope, 1)
            ceil = np.percentile(envelope, 99.5)
            if ceil < 0.0001:
                return np.zeros_like(envelope, dtype=bool)
            thresh = floor + (ceil - floor) * 0.3
            thresh = max(thresh, 0.01)
            binary = envelope > thresh
            kernel = max(3, int(0.002 * sample_rate))
            if kernel % 2 == 0:
                kernel += 1
            return medfilt(binary.astype(float), kernel).astype(bool)

        bin_dot = get_binary(env_dot)
        bin_dash = get_binary(env_dash)

        events = []

        def find_runs(binary, symbol):
            if len(binary) < 2:
                return
            changes = np.diff(binary.astype(int))
            idx = np.where(changes != 0)[0]
            if len(idx) > 0 and binary[0]:
                idx = np.insert(idx, 0, 0)

            for i in range(0, len(idx) - 1, 2):
                start = idx[i]
                end = idx[i + 1]
                events.append((start, end, symbol))

        find_runs(bin_dot, '.')
        find_runs(bin_dash, '-')

        events.sort(key=lambda x: x[0])

        unit_samples = int((1.2 / wpm) * sample_rate)

        morse_str = ""
        last_end = 0

        for start, end, symbol in events:
            gap_samples = start - last_end
            gap_units = gap_samples / unit_samples if unit_samples > 0 else 0

            if gap_units > 4.5:
                morse_str += "   "
            elif gap_units > 1.6 and last_end > 0:
                morse_str += " "

            dur_units = (end - start) / unit_samples if unit_samples > 0 else 1
            if dur_units > 0.3:
                morse_str += symbol
                last_end = end

        status = f"Success (Ultrasonic: dot={freq_dot}Hz, dash={freq_dash}Hz)"
        return morse_str, status

    @staticmethod
    def verify_ultrasonic_inaudibility(freq_dot: int, freq_dash: int,
                                        age: int = 30) -> dict:
        """Verify that chosen frequencies are inaudible for target age group."""
        threshold = UltrasonicEngine.analyze_hearing_threshold(age)

        return {
            'freq_dot': freq_dot,
            'freq_dash': freq_dash,
            'hearing_threshold': threshold,
            'dot_inaudible': freq_dot > threshold,
            'dash_inaudible': freq_dash > threshold,
            'both_inaudible': freq_dot > threshold and freq_dash > threshold,
            'age_group': 'young' if age < 25 else ('adult' if age < 50 else 'senior')
        }
