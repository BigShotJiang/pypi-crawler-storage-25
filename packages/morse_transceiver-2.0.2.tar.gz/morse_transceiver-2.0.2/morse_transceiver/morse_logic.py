"""Morse code encoding/decoding with protocol framing and checksum verification."""

import hashlib

LATIN_DICT = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.',
    'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---',
    'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---',
    'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-',
    'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--',
    'Z': '--..',
    '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....',
    '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----',
    ',': '--..--', '.': '.-.-.-', '?': '..--..', '/': '-..-.', '-': '-....-',
    '(': '-.--.', ')': '-.--.-', ' ': ' '
}

CYRILLIC_DICT = {
    'А': '.-', 'Б': '-...', 'В': '.--', 'Г': '--.', 'Д': '-..',
    'Е': '.', 'Ж': '...-', 'З': '--..', 'И': '..', 'Й': '.---',
    'К': '-.-', 'Л': '.-..', 'М': '--', 'Н': '-.', 'О': '---',
    'П': '.--.', 'Р': '.-.', 'С': '...', 'Т': '-', 'У': '..-',
    'Ф': '..-.', 'Х': '....', 'Ц': '-.-.', 'Ч': '---.', 'Ш': '----',
    'Щ': '--.-', 'Ъ': '--.--', 'Ы': '-.--', 'Ь': '-..-', 'Э': '..-..',
    'Ю': '..--', 'Я': '.-.-'
}

MORSE_CODE_DICT = {**LATIN_DICT, **CYRILLIC_DICT}
REVERSE_LATIN = {v: k for k, v in LATIN_DICT.items()}
REVERSE_CYRILLIC = {v: k for k, v in CYRILLIC_DICT.items()}

ACCENT_MAP = {
    'À': 'A', 'Á': 'A', 'Â': 'A', 'Ã': 'A', 'Ä': 'A', 'Å': 'A',
    'È': 'E', 'É': 'E', 'Ê': 'E', 'Ë': 'E',
    'Ì': 'I', 'Í': 'I', 'Î': 'I', 'Ï': 'I',
    'Ò': 'O', 'Ó': 'O', 'Ô': 'O', 'Õ': 'O', 'Ö': 'O',
    'Ù': 'U', 'Ú': 'U', 'Û': 'U', 'Ü': 'U',
    'Ý': 'Y', 'Ñ': 'N', 'Ç': 'C'
}


class MorseLogic:
    """Morse code encoding/decoding with protocol framing."""

    PREAMBLE = "KA"
    POSTAMBLE = "AR"

    @staticmethod
    def calculate_checksum(text: str) -> str:
        text = text.upper()
        hash_obj = hashlib.md5(text.encode())
        return hash_obj.hexdigest()[:2].upper()

    @staticmethod
    def text_to_morse(text: str, use_protocol: bool = False) -> str:
        if use_protocol:
            checksum = MorseLogic.calculate_checksum(text)
            full_text = f"{MorseLogic.PREAMBLE} {text} {checksum} {MorseLogic.POSTAMBLE}"
        else:
            full_text = text

        morse = []
        for char in full_text.upper():
            if char in ACCENT_MAP:
                char = ACCENT_MAP[char]
            if char in MORSE_CODE_DICT:
                morse.append(MORSE_CODE_DICT[char])
            else:
                morse.append(' ')
        return ' '.join(morse)

    @staticmethod
    def morse_to_text(morse_code: str, lang: str = 'latin') -> str:
        words = morse_code.strip().split('   ')
        decoded_words = []
        target_dict = REVERSE_CYRILLIC if lang == 'cyrillic' else REVERSE_LATIN

        for word in words:
            chars = word.split(' ')
            decoded_chars = []
            for char in chars:
                if char in target_dict:
                    decoded_chars.append(target_dict[char])
                elif char in REVERSE_LATIN:
                    decoded_chars.append(REVERSE_LATIN[char])
            decoded_words.append(''.join(decoded_chars))
        return ' '.join(decoded_words)

    @staticmethod
    def parse_packet(decoded_text: str) -> tuple:
        parts = decoded_text.split(MorseLogic.PREAMBLE)

        for part in parts:
            clean = part.strip()
            idx_ar = clean.find(MorseLogic.POSTAMBLE)
            if idx_ar == -1:
                continue

            content = clean[:idx_ar].strip()
            if not content:
                continue

            if ' ' in content:
                subparts = content.rsplit(' ', 1)
                payload = subparts[0]
                received_sum = subparts[1]
            else:
                if len(content) < 3:
                    continue
                payload = content[:-2]
                received_sum = content[-2:]

            calc_sum = MorseLogic.calculate_checksum(payload)

            if calc_sum == received_sum:
                return payload, "Success: Verified (Redundancy Check Passed)"

        return decoded_text, "Warning: No valid packet found or Checksum Mismatch"
