"""Morse Transceiver - Ultrasonic Audio Steganography for Cross-Modal Information Embedding.

A framework for embedding hidden data into audio/video files using ultrasonic
frequency carriers (17-20kHz) that are inaudible to humans but recordable by
standard computer audio hardware.
"""

__version__ = "2.0.2"
__author__ = "Morse Transceiver Contributors"
__license__ = "GPL-3.0-or-later"

from morse_transceiver.morse_logic import MorseLogic

__all__ = ["MorseLogic"]
