#!/usr/bin/env python3
"""Morse Transceiver CLI - Command-line interface for ultrasonic steganography."""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stego_engine import UltrasonicStegoEngine
from morse_transceiver.morse_logic import MorseLogic


def embed_command(args):
    """Embed ultrasonic Morse signal into audio/video file."""
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found.")
        sys.exit(1)

    print(f"Embedding message into: {args.input}")
    print(f"Message: '{args.message}'")
    print(f"Frequency mode: {args.mode}")
    print(f"WPM: {args.wpm}")
    print(f"Redundancy: {args.redundancy}")
    print(f"Volume: {args.volume}")

    try:
        output = UltrasonicStegoEngine.embed_signal(
            args.input,
            args.output,
            args.message,
            wpm=args.wpm,
            freq=args.freq,
            volume=args.volume,
            redundancy=args.redundancy,
            use_dual_tone=not args.single_tone,
            freq_mode=args.mode
        )
        print(f"\nSuccess! Output saved to: {output}")
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


def extract_command(args):
    """Extract ultrasonic Morse signal from audio/video file."""
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found.")
        sys.exit(1)

    print(f"Extracting from: {args.input}")
    print(f"Frequency: {args.freq} Hz")
    print(f"WPM: {args.wpm}")

    try:
        morse, status = UltrasonicStegoEngine.extract_signal(
            args.input,
            freq=args.freq,
            wpm=args.wpm,
            bandwidth=args.bandwidth,
            use_dual_tone=not args.single_tone
        )

        print(f"\nExtraction Status: {status}")
        print(f"Detected Morse: {morse}")

        decoded = MorseLogic.morse_to_text(morse)
        print(f"Decoded Text: {decoded}")

        payload, proto_status = MorseLogic.parse_packet(decoded)
        print(f"Payload: {payload}")
        print(f"Protocol: {proto_status}")

    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


def verify_command(args):
    """Verify frequency inaudibility for target age group."""
    threshold = UltrasonicStegoEngine.analyze_hearing_threshold(args.age)
    freq_dot, freq_dash = UltrasonicStegoEngine.find_optimal_frequencies(
        args.sample_rate, args.bitrate, args.mode
    )

    verification = UltrasonicStegoEngine.verify_inaudibility(
        freq_dot, freq_dash, args.age
    )

    print(f"Age Group: {args.age} years old ({verification['age_group']})")
    print(f"Estimated Hearing Limit: {threshold:.0f} Hz")
    print(f"\nOptimal Frequencies ({args.mode} mode):")
    print(f"  Dot carrier: {freq_dot} Hz - {'Inaudible' if verification['dot_inaudible'] else 'Audible'}")
    print(f"  Dash carrier: {freq_dash} Hz - {'Inaudible' if verification['dash_inaudible'] else 'Audible'}")
    print(f"\nOverall: {'✓ Both frequencies inaudible' if verification['both_inaudible'] else '⚠ One or both frequencies may be audible'}")


def main():
    parser = argparse.ArgumentParser(
        description="Morse Transceiver - Ultrasonic Audio Steganography",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  morse-embed input.mp4 -m "SECRET MESSAGE" -o output.mp4
  morse-extract output.mp4 -f 17500
  morse-verify --age 40
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Embed command
    embed_parser = subparsers.add_parser("embed", help="Embed ultrasonic signal")
    embed_parser.add_argument("input", help="Input audio/video file")
    embed_parser.add_argument("-m", "--message", required=True, help="Message to embed")
    embed_parser.add_argument("-o", "--output", help="Output file path")
    embed_parser.add_argument("--freq", type=int, default=17500, help="Base frequency (Hz)")
    embed_parser.add_argument("--wpm", type=float, default=15, help="Morse speed (WPM)")
    embed_parser.add_argument("--volume", type=float, default=0.1, help="Mixing volume (0-1)")
    embed_parser.add_argument("--redundancy", type=int, default=5, help="Repetition count")
    embed_parser.add_argument("--mode", choices=["conservative", "standard", "aggressive", "maximum"],
                               default="standard", help="Frequency mode")
    embed_parser.add_argument("--single-tone", action="store_true", help="Use single-tone mode")
    embed_parser.set_defaults(func=embed_command)

    # Extract command
    extract_parser = subparsers.add_parser("extract", help="Extract ultrasonic signal")
    extract_parser.add_argument("input", help="Input audio/video file")
    extract_parser.add_argument("-f", "--freq", type=int, default=17500, help="Base frequency (Hz)")
    extract_parser.add_argument("--wpm", type=float, default=15, help="Expected WPM")
    extract_parser.add_argument("--bandwidth", type=int, default=300, help="Filter bandwidth (Hz)")
    extract_parser.add_argument("--single-tone", action="store_true", help="Use single-tone mode")
    extract_parser.set_defaults(func=extract_command)

    # Verify command
    verify_parser = subparsers.add_parser("verify", help="Verify frequency inaudibility")
    verify_parser.add_argument("--age", type=int, default=30, help="Target age")
    verify_parser.add_argument("--sample-rate", type=int, default=44100, help="Audio sample rate")
    verify_parser.add_argument("--bitrate", type=int, default=128, help="Target AAC bitrate")
    verify_parser.add_argument("--mode", choices=["conservative", "standard", "aggressive", "maximum"],
                                default="standard", help="Frequency mode")
    verify_parser.set_defaults(func=verify_command)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "embed" and not args.output:
        base, ext = os.path.splitext(args.input)
        args.output = f"{base}_embedded{ext}"

    args.func(args)


def embed_main():
    sys.argv = ["morse-embed"] + sys.argv[1:]
    main()


def extract_main():
    sys.argv = ["morse-extract"] + sys.argv[1:]
    main()


if __name__ == "__main__":
    main()
