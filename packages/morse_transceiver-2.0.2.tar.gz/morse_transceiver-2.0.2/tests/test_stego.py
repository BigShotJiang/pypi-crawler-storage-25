"""Tests for ultrasonic steganography engine."""

import os
import sys
import numpy as np
import soundfile as sf
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stego_engine import UltrasonicStegoEngine
from morse_transceiver.morse_logic import MorseLogic


class TestMorseLogic:
    """Tests for Morse code logic."""

    def test_text_to_morse_basic(self):
        assert MorseLogic.text_to_morse("SOS") == "... --- ..."

    def test_morse_to_text(self):
        assert MorseLogic.morse_to_text("... --- ...") == "SOS"

    def test_checksum(self):
        checksum = MorseLogic.calculate_checksum("TEST")
        assert len(checksum) == 2
        assert checksum.isalnum()

    def test_parse_packet_valid(self):
        text = "HELLO"
        morse = MorseLogic.text_to_morse(text, use_protocol=True)
        decoded = MorseLogic.morse_to_text(morse)
        payload, status = MorseLogic.parse_packet(decoded)
        assert "Success" in status
        assert payload.upper() == text.upper()


class TestUltrasonicEngine:
    """Tests for ultrasonic steganography engine."""

    def test_wave_generation(self):
        sr = 44100
        wpm = 20
        text = "HELLO"

        freq_dot, freq_dash = UltrasonicStegoEngine.find_optimal_frequencies(sr, 128, 'standard')
        wave = UltrasonicStegoEngine.generate_dual_tone_wave(
            text, wpm, freq_dot, freq_dash, sr, volume=0.1, redundancy=1
        )

        assert isinstance(wave, np.ndarray)
        assert len(wave) > 0

    def test_hearing_threshold(self):
        threshold_20 = UltrasonicStegoEngine.analyze_hearing_threshold(20)
        threshold_50 = UltrasonicStegoEngine.analyze_hearing_threshold(50)

        assert threshold_20 > threshold_50
        assert threshold_20 == 20000
        assert threshold_50 == 14000

    def test_frequency_optimization(self):
        sr = 44100
        freq_dot, freq_dash = UltrasonicStegoEngine.find_optimal_frequencies(sr, 128, 'standard')

        assert freq_dot < sr / 2
        assert freq_dash < sr / 2
        assert freq_dot < freq_dash

    def test_audio_stego_roundtrip(self):
        sr = 44100
        duration = 3.0
        t = np.linspace(0, duration, int(sr*duration), False)
        audio = 0.3 * np.sin(2 * np.pi * 440 * t)

        src_path = "test_audio_roundtrip.wav"
        out_path = "test_audio_embedded.wav"

        sf.write(src_path, audio, sr)

        text = "TEST"
        try:
            UltrasonicStegoEngine.embed_signal(
                src_path, out_path, text, wpm=20, freq=17500, volume=0.1,
                redundancy=3, use_dual_tone=True
            )

            morse_raw, status = UltrasonicStegoEngine.extract_signal(
                out_path, freq=17500, wpm=20, use_dual_tone=True
            )

            decoded = MorseLogic.morse_to_text(morse_raw)
            payload, p_status = MorseLogic.parse_packet(decoded)

            assert text in payload.upper()
            assert "Success" in p_status
        finally:
            if os.path.exists(src_path):
                os.remove(src_path)
            if os.path.exists(out_path):
                os.remove(out_path)
