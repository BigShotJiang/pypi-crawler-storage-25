"""VD3 JSON format importer — reads .vd3.json files into annotation layer data.

The VD3 JSON format is a multi-layer container:
{
  "layers": [
    {
      "layer": "det/yolov8n",
      "display_name": "YOLOv8n Detections",
      "layer_type": "detections",
      "frames": {
        "0": [{"class_name": "person", "confidence": 0.92, "bbox": [10, 20, 30, 40]}],
        ...
      }
    },
    ...
  ]
}
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import orjson

logger = logging.getLogger(__name__)


@dataclass
class ImportedLayer:
    """A single annotation layer parsed from a VD3 JSON file."""

    layer: str
    display_name: str
    layer_type: str  # "detections" or "tracks"
    frames: dict[int, list[dict[str, Any]]] = field(default_factory=dict)
    # frames maps frame_number -> list of annotation objects


def parse_vd3_json(path: str | Path) -> list[ImportedLayer]:
    """Parse a VD3 JSON file and return a list of imported layers.

    Args:
        path: Path to the .vd3.json file.

    Returns:
        List of ImportedLayer objects, one per layer in the file.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        ValueError: If the file format is invalid.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"VD3 JSON file not found: {path}")

    data = orjson.loads(path.read_bytes())

    if not isinstance(data, dict) or "layers" not in data:
        raise ValueError(f"Invalid VD3 JSON format: expected top-level 'layers' key in {path}")

    layers_data = data["layers"]
    if not isinstance(layers_data, list):
        raise ValueError(f"Invalid VD3 JSON format: 'layers' must be a list in {path}")

    result: list[ImportedLayer] = []
    for i, layer_data in enumerate(layers_data):
        if not isinstance(layer_data, dict):
            raise ValueError(f"Invalid VD3 JSON format: layer {i} must be an object")

        layer = layer_data.get("layer")
        if not layer:
            raise ValueError(f"Invalid VD3 JSON format: layer {i} missing 'layer' key")

        display_name = layer_data.get("display_name", layer)
        layer_type = layer_data.get("layer_type", "detections")

        if layer_type not in ("detections", "tracks"):
            raise ValueError(f"Invalid layer_type '{layer_type}' in layer '{layer}'. Must be 'detections' or 'tracks'.")

        frames_data = layer_data.get("frames", {})
        if not isinstance(frames_data, dict):
            raise ValueError(f"Invalid VD3 JSON format: 'frames' in layer '{layer}' must be an object")

        # Convert string frame keys to integers
        frames: dict[int, list[dict[str, Any]]] = {}
        for frame_key, objects in frames_data.items():
            try:
                frame_num = int(frame_key)
            except ValueError:
                raise ValueError(f"Invalid frame key '{frame_key}' in layer '{layer}'. Must be an integer.") from None

            if not isinstance(objects, list):
                raise ValueError(f"Frame {frame_num} in layer '{layer}' must be a list of objects")

            # Validate each object has required fields
            for j, obj in enumerate(objects):
                if "class_name" not in obj:
                    raise ValueError(f"Object {j} in frame {frame_num} of layer '{layer}' missing 'class_name'")
                if "bbox" not in obj:
                    raise ValueError(f"Object {j} in frame {frame_num} of layer '{layer}' missing 'bbox'")
                bbox = obj["bbox"]
                if not isinstance(bbox, list) or len(bbox) != 4:
                    raise ValueError(
                        f"Object {j} in frame {frame_num} of layer '{layer}': 'bbox' must be [xmin, ymin, xmax, ymax]"
                    )

            frames[frame_num] = objects

        result.append(
            ImportedLayer(
                layer=layer,
                display_name=display_name,
                layer_type=layer_type,
                frames=frames,
            )
        )

    logger.info("Parsed %d layers from %s", len(result), path)
    return result
