"""Annotation store — read/write annotation layer JSON files.

Each annotation layer is stored as a separate JSON file:
    db/metadata/videos/{datasource}/{name}/annotations/{sanitized_layer}.json

The layer key (e.g., "det/yolov8n") is encoded in the filename by replacing
'/' with '--' (e.g., "det--yolov8n.json"). The canonical layer key is stored
inside the JSON file itself.

Layer-key convention
--------------------
Layer keys follow ``<type>/<run>``:

* ``<type>`` ∈ {``det``, ``track``} encodes the file's ``layer_type``.
* ``<run>`` is a free-form name describing the producer (e.g. ``yolov8n``,
  ``ground_truth``).

``track/ground_truth`` and ``det/ground_truth`` are reserved sibling pairs for
human-reviewed annotations. Any layer ending in ``/ground_truth`` MUST be
written with ``source="human"``.

Schema
------
Each annotation-layer JSON has these top-level fields:

* ``layer``: the canonical layer key (string).
* ``display_name``: human-readable name (string).
* ``layer_type``: ``"detections"`` or ``"tracks"`` — when ``"tracks"``, every
  bbox must carry a ``track_id``.
* ``source``: ``"human"`` or ``"machine"`` — who produced these annotations.
* ``frames``: ``{frame_index: [{class_name, bbox, ...}]}``.
* ``reviewed_frames`` (optional): sorted list of frame indices reviewed by a
  human. Required iff ``source == "human"``; forbidden when
  ``source == "machine"``.

Schema violations raise ``ValueError`` at write time. ``source`` is a required
keyword argument on :func:`write_annotation_layer`.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import orjson

logger = logging.getLogger(__name__)

ANNOTATIONS_DIR = "annotations"
VALID_SOURCES = frozenset({"human", "machine"})


def layer_to_filename(layer: str) -> str:
    """Convert a layer key to a safe filename.

    Args:
        layer: Layer key, e.g., "gt", "det/yolov8n", "track/bytetrack".

    Returns:
        Filename like "gt.json", "det--yolov8n.json", "track--bytetrack.json".
    """
    return layer.replace("/", "--") + ".json"


def filename_to_layer(filename: str) -> str:
    """Convert a filename back to a layer key.

    Args:
        filename: e.g., "det--yolov8n.json"

    Returns:
        Layer key, e.g., "det/yolov8n".
    """
    return filename.removesuffix(".json").replace("--", "/")


def _check_layer_schema(data: dict[str, Any]) -> list[str]:
    """Return a list of human-readable schema-violation messages. Empty list = valid."""
    issues: list[str] = []

    source = data.get("source")
    if source not in VALID_SOURCES:
        issues.append(f"invalid source {source!r}; expected one of {sorted(VALID_SOURCES)}")

    has_reviewed = "reviewed_frames" in data and data["reviewed_frames"] is not None
    if source == "human" and not has_reviewed:
        issues.append("source='human' requires 'reviewed_frames'")
    if source == "machine" and has_reviewed:
        issues.append("source='machine' must not have 'reviewed_frames'")

    layer = data.get("layer", "")
    if layer.endswith("/ground_truth") and source != "human":
        issues.append(
            f"layer {layer!r} ends in '/ground_truth' (reserved for human-reviewed data) "
            f"but source={source!r}"
        )

    return issues


def write_annotation_layer(
    metadata_dir: Path,
    layer: str,
    display_name: str,
    layer_type: str,
    frames: dict[int, list[dict[str, Any]]],
    *,
    source: str,
    reviewed_frames: list[int] | None = None,
) -> Path:
    """Write an annotation layer to a JSON file.

    Args:
        metadata_dir: The asset's metadata directory
                      (e.g., db/metadata/videos/{datasource}/{name}/).
        layer: Layer key (e.g., "track/ground_truth", "det/yolov8n").
        display_name: Human-readable name for the layer.
        layer_type: "detections" or "tracks".
        frames: Mapping of frame_number -> list of annotation objects.
                Each object has: class_name, bbox, optional confidence, track_id.
        source: ``"human"`` or ``"machine"``. Required.
        reviewed_frames: Optional sorted list of frame indices that have been
                         reviewed by a human. Required iff ``source == "human"``;
                         must be ``None`` when ``source == "machine"``. Frames
                         in this list but not in ``frames`` were reviewed and
                         found to contain no objects.

    Returns:
        Path to the written JSON file.

    Raises:
        ValueError: If the resulting layer JSON would violate the schema rules
            (invalid source, source/reviewed_frames mismatch, or
            ``*/ground_truth`` reservation violation).
    """
    annotations_dir = metadata_dir / ANNOTATIONS_DIR
    annotations_dir.mkdir(parents=True, exist_ok=True)

    filename = layer_to_filename(layer)
    json_path = annotations_dir / filename

    # Convert int frame keys to string for JSON
    string_frames: dict[str, list[dict[str, Any]]] = {str(k): v for k, v in sorted(frames.items())}

    data: dict[str, Any] = {
        "layer": layer,
        "display_name": display_name,
        "layer_type": layer_type,
        "source": source,
        "frames": string_frames,
    }

    if reviewed_frames is not None:
        data["reviewed_frames"] = sorted(reviewed_frames)

    issues = _check_layer_schema(data)
    if issues:
        raise ValueError(
            f"annotation-layer schema violation at {json_path}: " + "; ".join(issues)
        )

    json_path.write_bytes(orjson.dumps(data, option=orjson.OPT_INDENT_2) + b"\n")
    logger.info("Wrote annotation layer '%s' (%d frames, source=%s) to %s", layer, len(frames), source, json_path)

    return json_path


def read_annotation_layer(json_path: Path) -> dict[str, Any]:
    """Read a single annotation layer JSON file.

    Args:
        json_path: Path to the annotation JSON file.

    Returns:
        Dict with keys: layer, display_name, layer_type, frames.
        The frames dict has string keys (frame numbers) and list values.

    Raises:
        FileNotFoundError: If the file does not exist.
    """
    if not json_path.exists():
        raise FileNotFoundError(f"Annotation file not found: {json_path}")
    return orjson.loads(json_path.read_bytes())


def list_annotation_layers(metadata_dir: Path) -> list[dict[str, Any]]:
    """List all annotation layers in an asset's metadata directory.

    Scans the annotations/ subdirectory for JSON files and returns
    summary info for each layer.

    Args:
        metadata_dir: The asset's metadata directory.

    Returns:
        List of dicts, each with: layer, display_name, layer_type, source,
        frame_count, annotated_frame_count, and (when present)
        reviewed_frame_count. Sorted by layer name.
    """
    annotations_dir = metadata_dir / ANNOTATIONS_DIR
    if not annotations_dir.exists():
        return []

    layers: list[dict[str, Any]] = []
    for json_path in sorted(annotations_dir.glob("*.json")):
        try:
            data = orjson.loads(json_path.read_bytes())
            reviewed_frames = data.get("reviewed_frames")
            annotated_count = len(data.get("frames", {}))
            summary: dict[str, Any] = {
                "layer": data.get("layer", filename_to_layer(json_path.name)),
                "display_name": data.get("display_name", ""),
                "layer_type": data.get("layer_type", "detections"),
                "source": data.get("source"),
                "frame_count": len(reviewed_frames) if reviewed_frames is not None else annotated_count,
                "annotated_frame_count": annotated_count,
            }
            if reviewed_frames is not None:
                summary["reviewed_frame_count"] = len(reviewed_frames)
            layers.append(summary)
        except Exception:
            logger.warning("Failed to read annotation file: %s", json_path, exc_info=True)

    return layers


def read_annotations_for_frame(
    metadata_dir: Path,
    layer: str,
    frame_number: int,
) -> dict[str, Any] | None:
    """Read annotations for a specific frame from a layer file.

    Args:
        metadata_dir: The asset's metadata directory.
        layer: Layer key (e.g., "gt", "det/yolov8n").
        frame_number: 0-based frame index.

    Returns:
        Dict with frame_number and objects, or None if no annotations for that frame.
    """
    filename = layer_to_filename(layer)
    json_path = metadata_dir / ANNOTATIONS_DIR / filename

    if not json_path.exists():
        return None

    data = orjson.loads(json_path.read_bytes())
    frames = data.get("frames", {})
    frame_key = str(frame_number)

    if frame_key not in frames:
        return None

    return {
        "frame_number": frame_number,
        "objects": frames[frame_key],
    }
