"""vd3 list — list assets, datasources, layers."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console, print_assets_table, print_layers_table

list_app = typer.Typer(name="list", help="List assets, datasources, and annotation layers", no_args_is_help=True)


@list_app.command("assets")
def list_assets(
    workset: str | None = typer.Option(None, "--workset", "-w", help="Filter by workset slug"),
    package: str | None = typer.Option(None, "--package", "-k", help="Filter by package within workset"),
    datasource: str | None = typer.Option(None, "--datasource", "-d", help="Filter by datasource"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List assets in the content database."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                raise typer.Exit(1)
            assets = storage.list_workset_assets(ws.workset_id, package=package)
        else:
            assets = storage.list_assets(datasource=datasource)

        if not assets:
            console.print("[dim]No assets found[/]")
            return

        print_assets_table(assets)


@list_app.command("datasources")
def list_datasources(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List all datasources in the content database."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        result = storage.execute_sql(
            'SELECT "datasource", COUNT(*) as count FROM assets GROUP BY "datasource" ORDER BY "datasource"'
        )
        if not result:
            console.print("[dim]No datasources found[/]")
            return

        from rich.table import Table

        table = Table(title="Datasources")
        table.add_column("Datasource", style="bold")
        table.add_column("Assets", justify="right")

        for row in result:
            table.add_row(row["datasource"], str(row["count"]))

        console.print(table)


@list_app.command("layers")
def list_layers(
    asset: str = typer.Option(..., "--asset", "-a", help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List annotation layers for an asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                console.print(f"[red]Multiple assets named '{asset}'. Use the asset ID instead.[/]")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        layers = storage.list_annotation_layers(target.asset_id)
        if not layers:
            console.print("[dim]No annotation layers[/]")
            return

        print_layers_table(layers)
