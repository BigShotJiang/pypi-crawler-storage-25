"""vd3 info — show database stats."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import print_info_panel
from vd3storage.cli.utils import open_storage


def info_command(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show content database information."""
    with open_storage(path) as storage:
        print_info_panel(storage)
