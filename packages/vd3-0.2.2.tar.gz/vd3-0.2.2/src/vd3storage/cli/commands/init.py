"""vd3 init — initialize a new content database."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console


def init_command(
    path: Path = typer.Argument(".", help="Path to create the content database (default: current directory)"),
    dev: bool = typer.Option(False, "--dev", help="Add local vd3storage source override for development"),
    no_git: bool = typer.Option(False, "--no-git", help="Skip git initialization"),
    no_dvc: bool = typer.Option(False, "--no-dvc", help="Skip DVC initialization"),
    force: bool = typer.Option(
        False, "--force", "-f", help="Reinitialize even if already initialized (destroys existing data)"
    ),
) -> None:
    """Initialize a new VD3 content database."""
    from vd3storage import VD3Storage
    from vd3storage.storage import AlreadyInitializedError

    try:
        storage = VD3Storage.init(path, git_init=not no_git, dvc_init=not no_dvc, dev=dev, force=force)
    except AlreadyInitializedError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1) from None

    console.print(f"[green]Created content database at[/] [bold]{storage.path}[/]")
    storage._engine.close()
