"""vd3 add — add videos, imagesets, and results."""

from __future__ import annotations

import glob as globmod
from pathlib import Path

import typer

from vd3storage.cli.formatters import console, print_asset_detail

add_app = typer.Typer(name="add", help="Add videos, imagesets, and results", no_args_is_help=True)


def _resolve_video_paths(patterns: list[str]) -> list[Path]:
    """Expand glob patterns and return sorted, deduplicated list of video file paths."""
    paths: dict[Path, None] = {}  # ordered set
    for pattern in patterns:
        matches = sorted(globmod.glob(pattern, recursive=True))
        if not matches:
            console.print(f"[yellow]Warning: no files matched '{pattern}'[/]")
        for m in matches:
            p = Path(m)
            if p.is_file():
                paths[p] = None
    return list(paths)


def _find_existing_asset(storage: object, video_path: Path) -> object | None:
    """Hash a video file and look up the existing asset by content hash."""
    import hashlib

    sha256 = hashlib.sha256()
    with open(video_path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            sha256.update(chunk)
    return storage.get_asset_by_hash(sha256.hexdigest())


@add_app.command("video")
def add_video(
    files: list[str] = typer.Argument(..., help="Video file paths or glob patterns"),
    datasource: str = typer.Option(..., "--datasource", "-d", help="Data source (required)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to filename, single file only)"),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate video exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import video files into the content database. Supports glob patterns."""
    from rich.progress import Progress

    from vd3storage.cli.utils import open_storage

    video_paths = _resolve_video_paths(files)
    if not video_paths:
        console.print("[red]No video files found[/]")
        raise typer.Exit(1)

    if name and len(video_paths) > 1:
        console.print("[red]--name can only be used with a single file[/]")
        raise typer.Exit(1)

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        succeeded = 0
        linked = 0
        failed = 0
        with Progress(console=console) as progress:
            task = progress.add_task("Importing videos...", total=len(video_paths))

            for video_path in video_paths:
                progress.update(task, description=f"Importing {video_path.name}...")
                try:
                    asset = storage.import_video(
                        video_path,
                        datasource=datasource,
                        name=name,
                        force=force,
                        sensor_type=sensor_type,
                        environment=environment,
                        spectrum=spectrum,
                    )
                except FileNotFoundError as e:
                    console.print(f"[red]Skipping {video_path.name}: {e}[/]")
                    failed += 1
                    progress.advance(task)
                    continue
                except ValueError:
                    # Duplicate video — if a workset was requested, link the existing asset
                    if ws:
                        existing = _find_existing_asset(storage, video_path)
                        if existing:
                            storage.add_asset_to_workset(ws.workset_id, existing.asset_id, package=package)
                            console.print(
                                f"[dim]Linked existing[/] [bold]{existing.datasource}/{existing.name}[/]"
                                f" [dim]to workset[/] [bold]{workset}[/]"
                            )
                            linked += 1
                            progress.advance(task)
                            continue
                    console.print(f"[dim]Skipping {video_path.name}: already imported[/]")
                    progress.advance(task)
                    continue

                if ws:
                    storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

                succeeded += 1
                progress.advance(task)

                if len(video_paths) == 1:
                    layers = storage.list_annotation_layers(asset.asset_id)
                    print_asset_detail(asset, layers)

        # Summary
        if len(video_paths) == 1 and succeeded:
            console.print(f"\n[green]Imported {video_paths[0].name}[/]")
        else:
            parts = [f"[green]{succeeded} imported[/]"]
            if linked:
                parts.append(f"[blue]{linked} linked to workset[/]")
            if failed:
                parts.append(f"[red]{failed} failed[/]")
            console.print(f"\nDone: {', '.join(parts)} (of {len(video_paths)} files)")


@add_app.command("imageset")
def add_imageset(
    source: Path = typer.Argument(..., help="Directory of images or .tar archive"),
    datasource: str = typer.Option(..., "--datasource", "-d", help="Data source (required)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to directory/archive name)"),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import an imageset (directory of images or .tar archive)."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        try:
            asset = storage.import_imageset(
                source,
                datasource=datasource,
                name=name,
                force=force,
                sensor_type=sensor_type,
                environment=environment,
                spectrum=spectrum,
            )
        except (ValueError, FileNotFoundError) as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        if ws:
            storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

        layers = storage.list_annotation_layers(asset.asset_id)
        print_asset_detail(asset, layers)
        console.print(f"\n[green]Imported imageset with {asset.frame_count} images[/]")


@add_app.command("result")
def add_result(
    file: Path = typer.Argument(..., help="Path to the VD3 JSON result file"),
    asset: str = typer.Option(..., "--asset", "-a", help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import a VD3 JSON result file (detections + tracks) into an asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        # Resolve asset by ID or by name
        target = storage.get_asset_by_id(asset)
        if target is None:
            # Try to find by name across all datasources
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                console.print(f"[red]Multiple assets named '{asset}'. Use the asset ID instead.[/]")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        imported = storage.import_result(target.asset_id, file)
        console.print(f"[green]Imported {len(imported)} annotation layers:[/]")
        for layer in imported:
            frame_count = len(layer.get("frames", {}))
            console.print(f"  {layer['layer']}: {layer['display_name']} ({layer['layer_type']}, {frame_count} frames)")


@add_app.command("coco")
def add_coco(
    file: Path = typer.Argument(..., help="Path to the COCO JSON annotation file"),
    asset: str = typer.Option(..., "--asset", "-a", help="Imageset asset name or ID"),
    layer: str = typer.Option("gt", "--layer", "-l", help="Layer key for imported annotations"),
    display_name: str = typer.Option("COCO Annotations", "--display-name", help="Human-readable layer name"),
    source: str = typer.Option("machine", "--source", help="Annotation source: 'human' or 'machine'"),
    reviewed_all: bool = typer.Option(
        False, "--reviewed-all", help="Mark every frame as reviewed (only valid with --source human)"
    ),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import COCO annotations into an existing imageset asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                console.print(f"[red]Multiple assets named '{asset}'. Use the asset ID instead.[/]")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        try:
            imported = storage.import_coco(
                target.asset_id,
                file,
                layer=layer,
                display_name=display_name,
                source=source,
                reviewed_all=reviewed_all,
            )
        except ValueError as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        frame_count = len(imported.get("frames", {}))
        total_anns = sum(len(objs) for objs in imported.get("frames", {}).values())
        console.print(
            f"[green]Imported COCO annotations:[/] {imported['layer']}: "
            f"{imported['display_name']} ({total_anns} annotations across {frame_count} frames)"
        )


@add_app.command("coco-dataset")
def add_coco_dataset(
    file: Path = typer.Argument(..., help="Path to COCO JSON file (images resolved relative to its directory)"),
    datasource: str = typer.Option(..., "--datasource", "-d", help="Data source (required)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to parent directory name)"),
    image_root: Path | None = typer.Option(None, "--image-root", help="Base dir for image paths (default: JSON dir)"),
    layer: str = typer.Option("gt", "--layer", "-l", help="Layer key for imported annotations"),
    display_name: str = typer.Option("COCO Annotations", "--display-name", help="Human-readable layer name"),
    source: str = typer.Option("machine", "--source", help="Annotation source: 'human' or 'machine'"),
    reviewed_all: bool = typer.Option(
        False, "--reviewed-all", help="Mark every frame as reviewed (only valid with --source human)"
    ),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import a COCO dataset: creates an imageset from the images and imports annotations."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        try:
            asset, ann_result = storage.import_coco_dataset(
                file,
                datasource=datasource,
                name=name,
                image_root=image_root,
                layer=layer,
                display_name=display_name,
                source=source,
                reviewed_all=reviewed_all,
                force=force,
                sensor_type=sensor_type,
                environment=environment,
                spectrum=spectrum,
            )
        except (ValueError, FileNotFoundError) as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        if ws:
            storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

        layers = storage.list_annotation_layers(asset.asset_id)
        print_asset_detail(asset, layers)

        total_anns = sum(len(objs) for objs in ann_result.get("frames", {}).values())
        console.print(
            f"\n[green]Imported COCO dataset:[/] {asset.frame_count} images + "
            f"{total_anns} annotations ({ann_result['layer']})"
        )
