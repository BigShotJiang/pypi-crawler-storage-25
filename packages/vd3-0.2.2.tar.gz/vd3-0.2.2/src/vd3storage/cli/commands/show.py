"""vd3 show — show detailed asset info."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console, print_asset_detail


def show_command(
    asset: str = typer.Argument(..., help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show detailed information about an asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                console.print(f"[red]Multiple assets named '{asset}'. Specify by ID:[/]")
                for m in matches:
                    console.print(f"  {m.asset_id}  {m.datasource}/{m.name}")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        layers = storage.list_annotation_layers(target.asset_id)
        print_asset_detail(target, layers)

        # Show availability
        if target.media_path:
            available = storage.is_media_available(target.asset_id)
            if available:
                console.print("[green]Media: locally available[/]")
            else:
                console.print("[yellow]Media: not fetched (run 'vd3 pull' to download)[/]")
