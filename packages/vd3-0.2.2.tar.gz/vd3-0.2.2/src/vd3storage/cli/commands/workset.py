"""vd3 workset — workset management commands."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console, print_worksets_table

workset_app = typer.Typer(name="workset", help="Manage worksets", no_args_is_help=True)


@workset_app.command("create")
def workset_create(
    name: str = typer.Argument(..., help="Workset name"),
    slug: str | None = typer.Option(None, "--slug", help="URL-safe slug (auto-generated from name if omitted)"),
    description: str = typer.Option("", "--description", "-d", help="Workset description"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Create a new workset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = storage.create_workset(name, slug=slug, description=description)
        console.print(f"[green]Created workset[/] [bold]{ws.slug}[/] ({ws.name})")


@workset_app.command("list")
def workset_list(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List all worksets."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        rows = storage.list_worksets_with_stats()
        if not rows:
            console.print("[dim]No worksets[/]")
            return
        print_worksets_table(rows)


@workset_app.command("show")
def workset_show(
    slug: str = typer.Argument(..., help="Workset slug"),
    packages_flag: bool = typer.Option(False, "--packages", help="List all packages (default: count + preview)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show workset details."""
    from rich.panel import Panel
    from rich.table import Table

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = storage.get_workset(slug)
        if ws is None:
            console.print(f"[red]Workset '{slug}' not found[/]")
            raise typer.Exit(1)

        assets = storage.list_workset_assets(ws.workset_id)
        packages = [p for p in storage.list_workset_packages(ws.workset_id) if p]
        layers = storage.list_workset_layers(ws.workset_id)

        header_lines = [
            f"[bold]Name:[/] {ws.name}",
            f"[bold]Slug:[/] {ws.slug}",
            f"[bold]Description:[/] {ws.description or '(none)'}",
            f"[bold]Assets:[/] {len(assets):,}",
            f"[bold]Packages:[/] {len(packages):,}",
            f"[bold]Layers:[/] {len(layers):,}",
            f"[bold]Updated:[/] {ws.updated_at}",
        ]
        console.print(Panel("\n".join(header_lines), title=f"Workset: {ws.slug}", border_style="blue"))

        if layers:
            layers_table = Table(title="Annotation Layers", show_lines=False)
            layers_table.add_column("Layer", style="bold")
            layers_table.add_column("Types")
            layers_table.add_column("Assets", justify="right")
            layers_table.add_column("% of workset", justify="right")
            total_assets = len(assets) or 1
            for row in layers:
                pct = 100.0 * row["asset_count"] / total_assets
                layers_table.add_row(
                    row["layer"],
                    ", ".join(row["layer_types"]),
                    f"{row['asset_count']:,}",
                    f"{pct:5.1f}%",
                )
            console.print(layers_table)
        else:
            console.print("[dim]No annotation layers[/]")

        if packages:
            if packages_flag or len(packages) <= 10:
                pkg_lines = [f"  • {p}" for p in packages]
                console.print(
                    Panel(
                        "\n".join(pkg_lines),
                        title=f"Packages ({len(packages):,})",
                        border_style="cyan",
                    )
                )
            else:
                preview = ", ".join(packages[:5])
                console.print(
                    Panel(
                        f"{len(packages):,} packages\n[dim]e.g. {preview}, ...[/]\n"
                        "[dim]pass --packages to list all[/]",
                        title="Packages",
                        border_style="cyan",
                    )
                )


def _resolve_assets(storage: object, patterns: list[str], db_path: Path) -> list[object]:
    """Resolve asset patterns to a list of Asset objects.

    Patterns can be:
    - Asset name or UUID
    - File path (absolute or relative to cwd) to a video under the database
    - Glob pattern matching video files under the database
    """
    import glob as globmod

    all_assets = storage.list_assets()
    # Build lookup by media_path (relative to db root)
    by_video: dict[str, object] = {}
    by_name: dict[str, list[object]] = {}
    by_id: dict[str, object] = {}
    for a in all_assets:
        if a.media_path:
            by_video[a.media_path] = a
        by_name.setdefault(a.name, []).append(a)
        by_id[a.asset_id] = a

    results: dict[str, object] = {}  # asset_id -> asset, preserves order and dedupes

    for pattern in patterns:
        matched = False

        # Try as glob/path against files on disk
        glob_matches = sorted(globmod.glob(pattern, recursive=True))
        if glob_matches:
            for match in glob_matches:
                match_path = Path(match).resolve()
                try:
                    rel = str(match_path.relative_to(db_path.resolve()))
                except ValueError:
                    continue
                if rel in by_video:
                    asset = by_video[rel]
                    results[asset.asset_id] = asset
                    matched = True

        if matched:
            continue

        # Try as asset ID
        if pattern in by_id:
            asset = by_id[pattern]
            results[asset.asset_id] = asset
            continue

        # Try as asset name
        if pattern in by_name:
            name_matches = by_name[pattern]
            if len(name_matches) == 1:
                results[name_matches[0].asset_id] = name_matches[0]
                continue
            console.print(f"[yellow]Multiple assets named '{pattern}', use ID or path instead[/]")
            continue

        console.print(f"[yellow]No asset matched '{pattern}'[/]")

    return list(results.values())


@workset_app.command("add-asset")
def workset_add_asset(
    slug: str = typer.Argument(..., help="Workset slug"),
    assets: list[str] = typer.Argument(..., help="Asset names, IDs, or media file paths/globs"),
    package: str = typer.Option("", "--package", "-k", help="Package (folder) within workset"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Add assets to a workset. Supports glob patterns on media paths."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = storage.get_workset(slug)
        if ws is None:
            console.print(f"[red]Workset '{slug}' not found[/]")
            raise typer.Exit(1)

        resolved = _resolve_assets(storage, assets, storage.path)
        if not resolved:
            console.print("[red]No assets matched[/]")
            raise typer.Exit(1)

        for target in resolved:
            storage.add_asset_to_workset(ws.workset_id, target.asset_id, package=package)
            console.print(
                f"[green]Added[/] [bold]{target.datasource}/{target.name}[/] to workset [bold]{slug}[/]"
                + (f" (package: {package})" if package else "")
            )

        if len(resolved) > 1:
            console.print(f"\n{len(resolved)} assets added")


@workset_app.command("remove-asset")
def workset_remove_asset(
    slug: str = typer.Argument(..., help="Workset slug"),
    asset: str = typer.Argument(..., help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Remove an asset from a workset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = storage.get_workset(slug)
        if ws is None:
            console.print(f"[red]Workset '{slug}' not found[/]")
            raise typer.Exit(1)

        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        storage.remove_asset_from_workset(ws.workset_id, target.asset_id)
        console.print(f"[green]Removed[/] [bold]{target.name}[/] from workset [bold]{slug}[/]")


@workset_app.command("delete")
def workset_delete(
    slug: str = typer.Argument(..., help="Workset slug"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Delete a workset (does not delete its assets)."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = storage.get_workset(slug)
        if ws is None:
            console.print(f"[red]Workset '{slug}' not found[/]")
            raise typer.Exit(1)

        storage.delete_workset(ws.workset_id)
        console.print(f"[green]Deleted workset[/] [bold]{slug}[/]")
