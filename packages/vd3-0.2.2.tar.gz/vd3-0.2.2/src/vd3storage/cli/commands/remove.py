"""vd3 remove — delete an asset."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console


def remove_command(
    asset: str = typer.Argument(..., help="Asset name or ID"),
    media: bool = typer.Option(False, "--media", help="Also delete the media file"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Delete an asset from the content database."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                console.print(f"[red]Multiple assets named '{asset}'. Use the asset ID.[/]")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        storage.delete_asset(target.asset_id, delete_media=media)
        console.print(f"[green]Deleted asset[/] [bold]{target.datasource}/{target.name}[/]")
        if media:
            console.print("[dim]Media file also deleted[/]")
