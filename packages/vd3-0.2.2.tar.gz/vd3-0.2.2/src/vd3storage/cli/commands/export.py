"""vd3 export — export frames/images from assets."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console

export_app = typer.Typer(name="export", help="Export data from the content database", no_args_is_help=True)


@export_app.command("frames")
def export_frames(
    asset: str = typer.Argument(..., help="Asset name or ID"),
    output: Path = typer.Option(..., "--output", "-o", help="Output directory"),
    format: str = typer.Option("jpeg", "--format", "-f", help="Image format (jpeg or png)"),
    start: int = typer.Option(0, "--start", help="Start frame/image number"),
    end: int | None = typer.Option(None, "--end", help="End frame/image number (exclusive)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Extract frames from a video or images from an imageset to image files."""
    from PIL import Image

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = storage.get_asset_by_id(asset)
        if target is None:
            all_assets = storage.list_assets()
            matches = [a for a in all_assets if a.name == asset]
            if len(matches) == 1:
                target = matches[0]
            else:
                console.print(f"[red]Asset '{asset}' not found[/]")
                raise typer.Exit(1)

        output.mkdir(parents=True, exist_ok=True)
        ext = "jpg" if format.lower() == "jpeg" else format.lower()

        reader = (
            storage.open_imageset(target.asset_id)
            if target.asset_type == "imageset"
            else storage.open_video(target.asset_id)
        )
        with reader:
            count = 0
            for frame_num, frame_bytes in reader.iter_frames(start=start, end=end):
                import io

                img = Image.open(io.BytesIO(frame_bytes))
                out_path = output / f"{frame_num:06d}.{ext}"
                img.save(out_path)
                count += 1

            console.print(f"[green]Exported {count} frames to[/] {output}")
