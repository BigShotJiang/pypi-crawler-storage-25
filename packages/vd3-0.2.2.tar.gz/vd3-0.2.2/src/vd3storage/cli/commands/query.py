"""vd3 query — run raw DuckDB SQL queries."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console


def query_command(
    sql: str = typer.Argument(..., help="SQL query to execute"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Run a raw DuckDB SQL query against the CSV tables."""
    from rich.table import Table

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        try:
            rows = storage.execute_sql(sql)
        except Exception as e:
            console.print(f"[red]Query error:[/] {e}")
            raise typer.Exit(1) from None

        if not rows:
            console.print("[dim]No results[/]")
            return

        table = Table(show_lines=False)
        for col in rows[0]:
            table.add_column(col)

        for row in rows:
            table.add_row(*[str(v) for v in row.values()])

        console.print(table)
