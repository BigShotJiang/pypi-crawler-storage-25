"""Rich formatting helpers for CLI output."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def print_info_panel(storage) -> None:
    """Print a database info panel."""
    assets = storage.list_assets()
    worksets = storage.list_worksets()
    status = storage.remote_status()

    lines = [
        f"[bold]Path:[/] {storage.path}",
        f"[bold]Assets:[/] {len(assets)}    [bold]Worksets:[/] {len(worksets)}",
        f"[bold]Media:[/] {status['available']} locally available, {status['unavailable']} remote-only",
    ]

    datasources = set()
    for a in assets:
        datasources.add(a.datasource)
    if datasources:
        lines.append(f"[bold]Datasources:[/] {', '.join(sorted(datasources))}")

    console.print(Panel("\n".join(lines), title="Database Info", border_style="cyan"))


def print_assets_table(assets: list, show_datasource: bool = True) -> None:
    """Print assets in a Rich table."""
    table = Table(title="Assets", show_lines=False)
    table.add_column("Name", style="bold")
    if show_datasource:
        table.add_column("Datasource", style="dim")
    table.add_column("Type", width=8)
    table.add_column("Frames", justify="right")
    table.add_column("FPS", justify="right")
    table.add_column("Resolution")
    table.add_column("Sensor")
    table.add_column("Environment")

    for asset in assets:
        row = [asset.name]
        if show_datasource:
            row.append(asset.datasource)
        row.extend(
            [
                asset.asset_type,
                f"{asset.frame_count:,}" if asset.frame_count else "-",
                f"{asset.nominal_fps:.1f}" if asset.nominal_fps else "-",
                f"{asset.width}x{asset.height}" if asset.width else "-",
                asset.sensor_type,
                asset.environment,
            ]
        )
        table.add_row(*row)

    console.print(table)


def print_worksets_table(rows: list) -> None:
    """Print worksets in a Rich table.

    Accepts either plain Workset objects or stats dicts from
    ``Storage.list_worksets_with_stats`` (distinguished by dict vs attr access).
    """
    is_stats = bool(rows) and isinstance(rows[0], dict)

    table = Table(title="Worksets", show_lines=False)
    table.add_column("Slug", style="bold")
    table.add_column("Name")
    if is_stats:
        table.add_column("Assets", justify="right")
        table.add_column("Packages", justify="right")
        table.add_column("Layers", justify="right")
        table.add_column("Updated", style="dim")
    table.add_column("Description")

    for row in rows:
        if is_stats:
            updated = row.get("updated_at")
            updated_str = str(updated)[:19] if updated else ""
            table.add_row(
                row["slug"],
                row["name"],
                f"{row['assets']:,}",
                f"{row['packages']:,}",
                f"{row['layers']:,}",
                updated_str,
                row.get("description") or "",
            )
        else:
            table.add_row(row.slug, row.name, row.description or "")

    console.print(table)


def print_layers_table(layers: list[dict]) -> None:
    """Print annotation layers in a Rich table."""
    table = Table(title="Annotation Layers", show_lines=False)
    table.add_column("Layer", style="bold")
    table.add_column("Display Name")
    table.add_column("Type")
    table.add_column("Frames", justify="right")

    for layer in layers:
        table.add_row(
            layer.get("layer", ""),
            layer.get("display_name", ""),
            layer.get("layer_type", ""),
            str(layer.get("frame_count", "")),
        )

    console.print(table)


def print_asset_detail(asset, layers: list[dict]) -> None:
    """Print detailed asset info."""
    lines = [
        f"[bold]Name:[/] {asset.name}",
        f"[bold]Datasource:[/] {asset.datasource}",
        f"[bold]Type:[/] {asset.asset_type}",
        f"[bold]ID:[/] {asset.asset_id}",
        "",
    ]

    if asset.asset_type == "video":
        lines.extend(
            [
                f"[bold]Resolution:[/] {asset.width}x{asset.height}",
                f"[bold]Frames:[/] {asset.frame_count:,}",
                f"[bold]FPS:[/] {asset.nominal_fps:.1f}",
                f"[bold]Duration:[/] {asset.duration_ms / 1000:.1f}s",
            ]
        )
    else:
        lines.append(f"[bold]Images:[/] {asset.frame_count:,}")

    lines.extend(
        [
            "",
            f"[bold]Sensor:[/] {asset.sensor_type} ({asset.sensor_mount})",
            f"[bold]Spectrum:[/] {asset.spectrum}",
            f"[bold]Environment:[/] {asset.environment}",
            f"[bold]Time of day:[/] {asset.time_of_day}",
        ]
    )

    if asset.asset_type == "video" and asset.codec:
        lines.append(f"[bold]Codec:[/] {asset.codec}")

    if asset.comments:
        lines.append(f"[bold]Comments:[/] {asset.comments}")

    if asset.media_path:
        lines.append(f"\n[bold]Media:[/] {asset.media_path}")

    console.print(Panel("\n".join(lines), title=f"{asset.datasource}/{asset.name}", border_style="green"))

    if layers:
        print_layers_table(layers)
    else:
        console.print("[dim]No annotation layers[/]")
