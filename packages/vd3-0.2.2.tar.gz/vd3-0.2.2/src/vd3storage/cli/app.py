"""VD3Storage CLI — Typer application."""

import typer

from vd3storage.cli.commands.add import add_app
from vd3storage.cli.commands.export import export_app
from vd3storage.cli.commands.info import info_command
from vd3storage.cli.commands.init import init_command
from vd3storage.cli.commands.list_ import list_app
from vd3storage.cli.commands.media import media_app
from vd3storage.cli.commands.query import query_command
from vd3storage.cli.commands.remove import remove_command
from vd3storage.cli.commands.show import show_command
from vd3storage.cli.commands.workset import workset_app

app = typer.Typer(
    name="vd3",
    help="VD3Storage — DVC-backed media database for computer vision and ML developers",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

# Top-level commands
app.command("init")(init_command)
app.command("info")(info_command)
app.command("show")(show_command)
app.command("query")(query_command)
app.command("remove")(remove_command)

# Sub-command groups
app.add_typer(add_app, name="add")
app.add_typer(list_app, name="list")
app.add_typer(workset_app, name="workset")
app.add_typer(export_app, name="export")
app.add_typer(media_app, name="media")


def cli() -> None:
    from dotenv import find_dotenv, load_dotenv

    load_dotenv(find_dotenv(usecwd=True))
    app()
