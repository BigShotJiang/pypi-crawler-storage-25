"""VD3Storage — DVC-backed media database for computer vision and ML developers."""

try:
    from vd3storage._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"

from vd3storage.storage import AlreadyInitializedError, VD3Storage

__all__ = ["AlreadyInitializedError", "VD3Storage", "__version__"]
