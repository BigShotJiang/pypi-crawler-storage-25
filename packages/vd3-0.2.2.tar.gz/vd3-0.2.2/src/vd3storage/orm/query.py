"""Fluent query builder for VD3 models."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Generic, TypeVar, get_args, get_origin

from vd3storage.models.base import VD3Model

if TYPE_CHECKING:
    from vd3storage.orm.engine import Engine

T = TypeVar("T", bound=VD3Model)


class Query(Generic[T]):
    """Fluent query builder that produces typed model instances.

    Usage:
        results = Query(engine, Asset).filter(datasource="dashcam-2024").order_by("name").all()
    """

    def __init__(self, engine: Engine, model_cls: type[T]) -> None:
        self._engine = engine
        self._model_cls = model_cls
        self._table = model_cls.csv_filename().replace(".csv", "")
        self._wheres: list[str] = []
        self._params: list[object] = []
        self._order_by: str | None = None
        self._limit_val: int | None = None
        self._offset_val: int | None = None

    def filter(self, **kwargs: object) -> Query[T]:
        """Add equality filters: query.filter(datasource="dashcam-2024", sensor_type="rgb")."""
        for col, val in kwargs.items():
            self._wheres.append(f'"{col}" = ?')
            self._params.append(val)
        return self

    def filter_sql(self, condition: str, *params: object) -> Query[T]:
        """Add raw SQL condition: query.filter_sql("frame_count > ?", 100)."""
        self._wheres.append(condition)
        self._params.extend(params)
        return self

    def order_by(self, column: str, desc: bool = False) -> Query[T]:
        """Set ordering."""
        direction = "DESC" if desc else "ASC"
        self._order_by = f'"{column}" {direction}'
        return self

    def limit(self, n: int) -> Query[T]:
        """Limit number of results."""
        self._limit_val = n
        return self

    def offset(self, n: int) -> Query[T]:
        """Skip first n results."""
        self._offset_val = n
        return self

    def _build_sql(self, select: str = "*") -> tuple[str, list[object]]:
        """Build the SQL query string and parameters."""
        sql = f"SELECT {select} FROM {self._table}"
        if self._wheres:
            sql += " WHERE " + " AND ".join(self._wheres)
        if self._order_by:
            sql += f" ORDER BY {self._order_by}"
        if self._limit_val is not None:
            sql += f" LIMIT {self._limit_val}"
        if self._offset_val is not None:
            sql += f" OFFSET {self._offset_val}"
        return sql, list(self._params)

    def all(self) -> list[T]:
        """Execute query, return list of model instances."""
        sql, params = self._build_sql()
        result = self._engine.execute(sql, params)
        columns = [desc[0] for desc in result.description]
        rows = result.fetchall()
        return [_row_to_model(self._model_cls, columns, row) for row in rows]

    def first(self) -> T | None:
        """Return first result or None."""
        self._limit_val = 1
        results = self.all()
        return results[0] if results else None

    def count(self) -> int:
        """Return count of matching rows."""
        sql, params = self._build_sql(select="COUNT(*)")
        result = self._engine.execute(sql, params)
        return result.fetchone()[0]

    def delete(self) -> int:
        """Delete matching rows, return count deleted."""
        count = self.count()
        sql = f"DELETE FROM {self._table}"
        if self._wheres:
            sql += " WHERE " + " AND ".join(self._wheres)
        self._engine.execute(sql, list(self._params))
        return count


def _row_to_model(model_cls: type[T], columns: list[str], row: tuple) -> T:
    """Convert a DuckDB result row to a model instance.

    Handles:
    - DuckDB datetime strings -> Python datetime objects
    - NULL values for non-Optional str fields -> field default (CSV round-trip loses empty strings)
    """
    data: dict[str, Any] = {}
    for col, val in zip(columns, row, strict=False):
        if val is None and col in model_cls.model_fields:
            # If the field is not Optional (doesn't accept None), skip it
            # so Pydantic uses the field default value instead
            field = model_cls.model_fields[col]
            annotation = field.annotation
            # Check if None is accepted by looking at the origin type
            origin = get_origin(annotation)
            args = get_args(annotation) if origin else ()
            if type(None) not in args and annotation is not type(None):
                # Field doesn't accept None — let Pydantic use default
                continue
            data[col] = val
        elif isinstance(val, datetime):
            data[col] = val
        elif isinstance(val, str) and len(val) > 18 and val[4:5] == "-" and val[10:11] == " ":
            try:
                data[col] = datetime.fromisoformat(val)
            except ValueError:
                data[col] = val
        else:
            data[col] = val
    return model_cls(**data)
