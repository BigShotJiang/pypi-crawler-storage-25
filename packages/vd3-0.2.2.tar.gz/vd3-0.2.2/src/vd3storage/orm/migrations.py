"""Schema migration support."""

SCHEMA_VERSION = 7

# Each migration is a list of SQL statements applied sequentially.
# The version file (tables/.schema_version) tracks what has been applied.
MIGRATIONS: dict[int, list[str]] = {
    # Version 2: Replace MCAP with raw MP4 + JSON metadata
    2: ["ALTER TABLE assets RENAME COLUMN mcap_path TO video_path"],
    # Version 3: Rename collection to datasource
    3: ["ALTER TABLE assets RENAME COLUMN collection TO datasource"],
    # Version 4: Rename workspace(s) to workset(s)
    4: [
        "ALTER TABLE workspaces RENAME TO worksets",
        "ALTER TABLE worksets RENAME COLUMN workspace_id TO workset_id",
        "ALTER TABLE workspace_assets RENAME TO workset_assets",
        "ALTER TABLE workset_assets RENAME COLUMN workspace_id TO workset_id",
    ],
    # Version 5: Rename video_path to media_path
    5: ["ALTER TABLE assets RENAME COLUMN video_path TO media_path"],
    # Version 6: Add spectrum and codec columns to assets
    6: [
        "ALTER TABLE assets ADD COLUMN spectrum VARCHAR DEFAULT 'unknown'",
        "ALTER TABLE assets ADD COLUMN codec VARCHAR DEFAULT ''",
    ],
    # Version 7: Drop unused weather_* and starred columns from assets.
    # All were 0% populated across the fc-17k audit and had no external consumers.
    7: [
        "ALTER TABLE assets DROP COLUMN weather_fog",
        "ALTER TABLE assets DROP COLUMN weather_rain",
        "ALTER TABLE assets DROP COLUMN weather_snow",
        "ALTER TABLE assets DROP COLUMN weather_overcast",
        "ALTER TABLE assets DROP COLUMN weather_glare",
        "ALTER TABLE assets DROP COLUMN weather_wind",
        "ALTER TABLE assets DROP COLUMN weather_high_contrast",
        "ALTER TABLE assets DROP COLUMN starred",
    ],
}
