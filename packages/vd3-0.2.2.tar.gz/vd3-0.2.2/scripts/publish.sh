#!/usr/bin/env bash
# Build and publish to PyPI.
#
# Usage:
#   ./scripts/publish.sh              # publish to PyPI
#   ./scripts/publish.sh --test       # publish to Test PyPI
#   VD3_TEST=1 ./scripts/publish.sh   # publish to Test PyPI (env var)
#
# Requires ~/.pypirc or TWINE_USERNAME/TWINE_PASSWORD env vars.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

# Load .env if present
if [[ -f .env ]]; then
    set -a
    source .env
    set +a
fi

REPO_FLAG=()
TEST_MODE=false

# Use project-level .pypirc if present, otherwise ~/.pypirc
if [[ -f .pypirc ]]; then
    REPO_FLAG+=(--config-file .pypirc)
fi

if [[ "${1:-}" == "--test" ]] || [[ "${VD3_TEST:-}" == "1" ]]; then
    REPO_FLAG+=(--repository testpypi)
    TEST_MODE=true
    echo "Publishing to Test PyPI"
else
    echo "Publishing to PyPI"
fi

# Clean previous builds
rm -rf dist/

# Lint
echo "Running ruff..."
uv run ruff check src/

# Bake TEST_RELEASE flag and dev version for test publishes
RELEASE_FILE="src/vd3storage/_release.py"
PYPROJECT="pyproject.toml"
if [[ "$TEST_MODE" == true ]]; then
    sed -i 's/TEST_RELEASE = False/TEST_RELEASE = True/' "$RELEASE_FILE"
    # Append .devN timestamp to avoid version conflicts on Test PyPI
    DEV_SUFFIX=".dev$(date +%Y%m%d%H%M%S)"
    sed -i "s/^version = \"\(.*\)\"/version = \"\1${DEV_SUFFIX}\"/" "$PYPROJECT"
fi

# Build
echo "Building..."
uv run python -m build

# Restore modified files to default
git checkout -- "$RELEASE_FILE" "$PYPROJECT"

# Show what we built
echo ""
echo "Built:"
ls -lh dist/

# Confirm
PKG_INFO=$(uv run python -c "
import re, pathlib
whl = next(pathlib.Path('dist').glob('*.whl'))
m = re.match(r'(.+?)-(.+?)-.+\.whl', whl.name)
print(m.group(1), m.group(2))
")
PKG_NAME="${PKG_INFO% *}"
VERSION="${PKG_INFO#* }"
echo ""
read -rp "Publish ${PKG_NAME} v${VERSION}? [y/N] " confirm
if [[ "$confirm" != [yY] ]]; then
    echo "Aborted."
    exit 1
fi

# Upload (the ${arr[@]+"${arr[@]}"} idiom is safe under `set -u` when arr is empty)
uv run twine upload ${REPO_FLAG[@]+"${REPO_FLAG[@]}"} dist/*

echo ""
echo "Published ${PKG_NAME} v${VERSION}"

# Tag the release (skip in test mode — dev-suffixed versions aren't real releases)
if [[ "$TEST_MODE" == false ]]; then
    TAG="v${VERSION}"
    if git rev-parse "$TAG" >/dev/null 2>&1; then
        echo "Tag ${TAG} already exists; skipping tag creation."
    else
        git tag -a "$TAG" -m "Release ${TAG}"
        git push origin "$TAG"
        echo "Tagged and pushed ${TAG}"
    fi
fi
