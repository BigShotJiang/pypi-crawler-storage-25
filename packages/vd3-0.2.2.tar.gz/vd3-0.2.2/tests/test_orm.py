"""Tests for the DuckDB ORM layer."""

from vd3storage.models import Asset


class TestEngine:
    def test_register_and_flush(self, tmp_storage):
        """Tables should be registered and flushable."""
        # The fixture already initialized tables
        csv_path = tmp_storage.tables_dir / "assets.csv"
        assert csv_path.exists()
        assert csv_path.stat().st_size > 0  # Has at least headers

    def test_execute_sql(self, tmp_storage):
        """Should be able to execute raw SQL."""
        result = tmp_storage.execute_sql("SELECT COUNT(*) AS cnt FROM assets")
        assert result == [{"cnt": 0}]


class TestTable:
    def test_insert_and_query(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024", sensor_type="rgb")
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found is not None
        assert found.asset_id == asset.asset_id
        assert found.sensor_type == "rgb"

    def test_update(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024")
        asset.sensor_type = "thermal"
        tmp_storage.update_asset(asset)
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found.sensor_type == "thermal"

    def test_delete(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024")
        tmp_storage.delete_asset(asset.asset_id)
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found is None


class TestQuery:
    def test_filter(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "dashcam-2024", environment="urban")
        tmp_storage.add_asset("cam02.mp4", "dashcam-2024", environment="rural")
        tmp_storage.add_asset("cam03.mp4", "drone-2024", environment="urban")

        urban = tmp_storage.query(Asset).filter(environment="urban").all()
        assert len(urban) == 2

        dashcam = tmp_storage.query(Asset).filter(datasource="dashcam-2024").all()
        assert len(dashcam) == 2

    def test_filter_sql(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1", frame_count=100)
        tmp_storage.add_asset("cam02.mp4", "col1", frame_count=5000)
        tmp_storage.add_asset("cam03.mp4", "col1", frame_count=10000)

        large = tmp_storage.query(Asset).filter_sql('"frame_count" > ?', 1000).all()
        assert len(large) == 2

    def test_order_by(self, tmp_storage):
        tmp_storage.add_asset("bravo.mp4", "col1")
        tmp_storage.add_asset("alpha.mp4", "col1")
        tmp_storage.add_asset("charlie.mp4", "col1")

        assets = tmp_storage.query(Asset).order_by("name").all()
        assert [a.name for a in assets] == ["alpha.mp4", "bravo.mp4", "charlie.mp4"]

    def test_limit_offset(self, tmp_storage):
        for i in range(10):
            tmp_storage.add_asset(f"cam{i:02d}.mp4", "col1")

        page = tmp_storage.query(Asset).order_by("name").limit(3).offset(2).all()
        assert len(page) == 3
        assert page[0].name == "cam02.mp4"

    def test_count(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset("cam02.mp4", "col1")
        assert tmp_storage.query(Asset).count() == 2
        assert tmp_storage.query(Asset).filter(name="cam01.mp4").count() == 1
