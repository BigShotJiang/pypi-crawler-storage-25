"""Tests for the VD3 CLI."""

import subprocess
from pathlib import Path

import orjson
import pytest
from typer.testing import CliRunner

from vd3storage.cli.app import app

runner = CliRunner()


@pytest.fixture
def db_path(tmp_path) -> Path:
    """Create a temp content database for CLI tests."""
    db = tmp_path / "test-db"
    result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
    assert result.exit_code == 0
    return db


@pytest.fixture
def sample_video(tmp_path) -> Path:
    """Create a small test video."""
    video_path = tmp_path / "test_input.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=0.5:size=64x48:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(video_path),
        ],
        check=True,
        capture_output=True,
    )
    return video_path


class TestInitCommand:
    def test_init(self, tmp_path):
        db = tmp_path / "new-db"
        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0
        assert "Created content database" in result.output
        assert (db / "db" / "tables" / "assets.csv").exists()

    def test_init_dev(self, tmp_path):
        db = tmp_path / "dev-db"
        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc", "--dev"])
        assert result.exit_code == 0
        assert "[tool.uv.sources]" in (db / "pyproject.toml").read_text()

    def test_init_already_initialized(self, tmp_path):
        """Re-running init on same directory should fail with clear error."""
        db = tmp_path / "existing-db"
        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0

        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 1
        assert "already initialized" in result.output

    def test_init_force(self, tmp_path):
        """--force should allow reinitializing."""
        db = tmp_path / "force-db"
        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0

        result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc", "--force"])
        assert result.exit_code == 0
        assert "Created content database" in result.output


class TestInfoCommand:
    def test_info(self, db_path):
        result = runner.invoke(app, ["info", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Assets" in result.output
        assert "Worksets" in result.output


class TestAddCommands:
    def test_add_video(self, db_path, sample_video):
        result = runner.invoke(
            app,
            [
                "add",
                "video",
                str(sample_video),
                "--datasource",
                "test-col",
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "Imported" in result.output

    def test_add_video_to_workset(self, db_path, sample_video):
        # Create workset first
        runner.invoke(app, ["workset", "create", "MyProject", "--path", str(db_path)])

        result = runner.invoke(
            app,
            [
                "add",
                "video",
                str(sample_video),
                "--datasource",
                "test-col",
                "--workset",
                "myproject",
                "--package",
                "training",
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "test_in" in result.output  # Asset was imported

    def test_add_result(self, db_path, sample_video, tmp_path):
        # Import a video first
        runner.invoke(
            app,
            [
                "add",
                "video",
                str(sample_video),
                "--datasource",
                "col1",
                "--path",
                str(db_path),
            ],
        )

        # Create result file
        vd3_json = tmp_path / "results.vd3.json"
        vd3_json.write_bytes(
            orjson.dumps(
                {
                    "layers": [
                        {
                            "layer": "det/test",
                            "display_name": "Test Detections",
                            "layer_type": "detections",
                            "frames": {"0": [{"class_name": "x", "confidence": 0.9, "bbox": [1, 2, 3, 4]}]},
                        }
                    ]
                }
            )
        )

        result = runner.invoke(
            app,
            [
                "add",
                "result",
                str(vd3_json),
                "--asset",
                "test_input",
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "Imported 1 annotation" in result.output


class TestListCommands:
    def test_list_assets(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        result = runner.invoke(app, ["list", "assets", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_in" in result.output  # May be truncated by Rich table in narrow terminal
        assert "col1" in result.output

    def test_list_assets_empty(self, db_path):
        result = runner.invoke(app, ["list", "assets", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No assets" in result.output

    def test_list_datasources(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "dashcam", "--path", str(db_path)])
        result = runner.invoke(app, ["list", "datasources", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "dashcam" in result.output

    def test_list_layers(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        result = runner.invoke(app, ["list", "layers", "--asset", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0  # No layers yet, but shouldn't error


class TestShowCommand:
    def test_show(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        result = runner.invoke(app, ["show", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "col1" in result.output
        assert "64x48" in result.output or "64" in result.output

    def test_show_not_found(self, db_path):
        result = runner.invoke(app, ["show", "nonexistent", "--path", str(db_path)])
        assert result.exit_code == 1


class TestQueryCommand:
    def test_query(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        result = runner.invoke(app, ["query", "SELECT name, datasource FROM assets", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_input" in result.output


class TestRemoveCommand:
    def test_remove(self, db_path, sample_video):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        result = runner.invoke(app, ["remove", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Deleted" in result.output


class TestWorksetCommands:
    def test_workset_crud(self, db_path):
        # Create
        result = runner.invoke(app, ["workset", "create", "My Project", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "my-project" in result.output

        # List
        result = runner.invoke(app, ["workset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "my-project" in result.output

        # Show
        result = runner.invoke(app, ["workset", "show", "my-project", "--path", str(db_path)])
        assert result.exit_code == 0

        # Delete
        result = runner.invoke(app, ["workset", "delete", "my-project", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Deleted" in result.output


class TestStatusCommand:
    def test_status(self, db_path):
        result = runner.invoke(app, ["media", "status", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Total" in result.output


class TestExportCommand:
    def test_export_frames(self, db_path, sample_video, tmp_path):
        runner.invoke(app, ["add", "video", str(sample_video), "--datasource", "col1", "--path", str(db_path)])
        output_dir = tmp_path / "exported"
        result = runner.invoke(
            app,
            [
                "export",
                "frames",
                "test_input",
                "--output",
                str(output_dir),
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output
        assert len(list(output_dir.glob("*.jpg"))) > 0
