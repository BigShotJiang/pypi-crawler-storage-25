"""Test COCO export for VD3 annotation layers.

Verifies:
1. VD3 -> COCO export produces valid COCO format
2. Bbox conversion: [x1,y1,x2,y2] -> [x,y,w,h] is correct
3. Category mapping: class_name -> category_id
4. Annotation counts are preserved
5. Optional fields (confidence, track_id) are preserved
6. Integration with real fc-100 data from vd3_rzdata (if available)
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Unit tests (no database required)
# ---------------------------------------------------------------------------


def test_bbox_export() -> None:
    """VD3 [x1,y1,x2,y2] -> COCO [x,y,w,h] is correct."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "detections",
        "frames": {
            "0": [{"class_name": "person", "bbox": [10.5, 20.3, 50.7, 60.9], "area": 100}],
        },
    }

    categories = [{"id": 0, "name": "person"}]
    coco = export_annotation_layer_as_coco(layer_data, width=640, height=480, categories=categories)

    coco_bbox = coco["annotations"][0]["bbox"]
    assert len(coco_bbox) == 4
    assert coco_bbox[0] == 10.5  # x = x1
    assert coco_bbox[1] == 20.3  # y = y1
    assert abs(coco_bbox[2] - 40.2) < 1e-9  # w = x2 - x1
    assert abs(coco_bbox[3] - 40.6) < 1e-9  # h = y2 - y1

    print("  PASS: bbox export [x1,y1,x2,y2] -> [x,y,w,h]")


def test_category_mapping() -> None:
    """class_name -> category_id mapping is correct."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    categories = [
        {"id": 0, "name": "person"},
        {"id": 1, "name": "vehicle"},
        {"id": 2, "name": "package"},
        {"id": 3, "name": "animal"},
    ]

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "detections",
        "frames": {
            "0": [
                {"class_name": "person", "bbox": [0, 0, 10, 10]},
                {"class_name": "vehicle", "bbox": [20, 20, 30, 30]},
            ],
            "5": [
                {"class_name": "animal", "bbox": [40, 40, 50, 50]},
                {"class_name": "package", "bbox": [60, 60, 70, 70]},
            ],
        },
    }

    coco = export_annotation_layer_as_coco(layer_data, width=100, height=100, categories=categories)

    anns = coco["annotations"]
    assert anns[0]["category_id"] == 0  # person
    assert anns[1]["category_id"] == 1  # vehicle
    assert anns[2]["category_id"] == 3  # animal
    assert anns[3]["category_id"] == 2  # package

    print("  PASS: category mapping class_name -> category_id")


def test_annotation_count_preserved() -> None:
    """Total annotation count matches input."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    categories = [{"id": 0, "name": "person"}, {"id": 1, "name": "vehicle"}]

    frames: dict[str, list[dict[str, Any]]] = {}
    total_input = 0
    for i in range(10):
        n_objects = (i % 3) + 1
        frames[str(i)] = [
            {"class_name": "person" if j % 2 == 0 else "vehicle", "bbox": [j * 10, 0, j * 10 + 5, 5]}
            for j in range(n_objects)
        ]
        total_input += n_objects

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "detections",
        "frames": frames,
    }

    coco = export_annotation_layer_as_coco(layer_data, width=100, height=100, categories=categories)
    assert len(coco["annotations"]) == total_input
    assert len(coco["images"]) == 10

    print(f"  PASS: annotation count preserved ({total_input} annotations, 10 frames)")


def test_optional_fields_preserved() -> None:
    """confidence and track_id are preserved in export."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    categories = [{"id": 0, "name": "person"}]

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "tracks",
        "frames": {
            "0": [{"class_name": "person", "bbox": [10, 20, 50, 60], "confidence": 0.95, "track_id": 7}],
        },
    }

    coco = export_annotation_layer_as_coco(layer_data, width=640, height=480, categories=categories)
    ann = coco["annotations"][0]
    assert ann["confidence"] == 0.95
    assert ann["track_id"] == 7

    print("  PASS: confidence and track_id preserved in export")


def test_coco_images_have_correct_dims() -> None:
    """COCO image entries have correct width/height and frame_index."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "detections",
        "frames": {
            "0": [{"class_name": "person", "bbox": [0, 0, 10, 10]}],
            "42": [{"class_name": "person", "bbox": [0, 0, 10, 10]}],
        },
    }

    coco = export_annotation_layer_as_coco(
        layer_data, width=1920, height=1080, categories=[{"id": 0, "name": "person"}]
    )

    for img in coco["images"]:
        assert img["width"] == 1920
        assert img["height"] == 1080

    assert coco["images"][0]["frame_index"] == 0
    assert coco["images"][1]["frame_index"] == 42

    print("  PASS: COCO images have correct dimensions and frame indices")


def test_info_block_passthrough() -> None:
    """Custom info block is included in output."""
    from vd3storage.exporters.coco import export_annotation_layer_as_coco

    layer_data: dict[str, Any] = {
        "layer": "test",
        "display_name": "Test",
        "layer_type": "detections",
        "frames": {"0": [{"class_name": "person", "bbox": [0, 0, 10, 10]}]},
    }

    info = {"video_id": "abc-123", "camera_id": "CAM01", "custom_field": 42}
    coco = export_annotation_layer_as_coco(
        layer_data, width=100, height=100, categories=[{"id": 0, "name": "person"}], info=info
    )

    assert coco["info"]["video_id"] == "abc-123"
    assert coco["info"]["camera_id"] == "CAM01"
    assert coco["info"]["custom_field"] == 42

    print("  PASS: custom info block passed through")


# ---------------------------------------------------------------------------
# Integration test with real vd3_rzdata
# ---------------------------------------------------------------------------


def test_real_fc100_export(db_path: str) -> None:
    """Read a ground_truth layer from fc-100, export to COCO, verify structure."""
    from vd3storage import VD3Storage

    storage = VD3Storage(db_path)

    # Find the fc-100 workset
    worksets = storage.list_worksets()
    fc100 = next((w for w in worksets if w.slug == "fc-100"), None)
    if fc100 is None:
        print("  SKIP: fc-100 workset not found")
        return

    # Get annotated assets
    assets = storage.list_workset_assets(fc100.workset_id)
    annotated = [a for a in assets if '"ground_truth"' in a.annotation_layers_json]
    if not annotated:
        print("  SKIP: no annotated assets in fc-100")
        return

    asset = annotated[0]
    print(f"  Testing with asset: {asset.name} ({asset.width}x{asset.height})")

    # Read original VD3 layer
    original_layer = storage.read_annotation_layer(asset.asset_id, "ground_truth")
    original_frames = original_layer["frames"]
    original_count = sum(len(objs) for objs in original_frames.values())
    print(f"  Original: {len(original_frames)} frames, {original_count} annotations")

    # Export to COCO via the storage convenience method
    coco = storage.export_coco(asset.asset_id, "ground_truth")
    print(f"  COCO export: {len(coco['images'])} images, {len(coco['annotations'])} annotations")

    # Counts match
    assert len(coco["images"]) == len(original_frames)
    assert len(coco["annotations"]) == original_count

    # Info block has asset metadata
    assert coco["info"]["asset_id"] == asset.asset_id
    assert coco["info"]["camera_id"] == asset.camera_id
    assert coco["info"]["width"] == asset.width
    assert coco["info"]["height"] == asset.height

    # Categories present
    assert len(coco["categories"]) == 4  # default categories

    # Spot-check bbox conversion on first annotation
    if coco["annotations"]:
        ann = coco["annotations"][0]
        x, y, w, h = ann["bbox"]
        assert w > 0 and h > 0, f"Invalid COCO bbox dimensions: w={w}, h={h}"
        assert ann["category_id"] in {0, 1, 2, 3}

    # Test resolve_media_path
    media_path = storage.resolve_media_path(asset.asset_id)
    print(f"  Media path: {media_path}")
    assert str(media_path).endswith(".mp4") or str(media_path).endswith(".mp4.dvc")

    # Test add_annotation_layer (the proper write path) with a small test
    storage.add_annotation_layer(
        asset.asset_id,
        layer="test/export_verify",
        display_name="Export Verify",
        annotations={0: [{"class_name": "person", "bbox": [10, 20, 50, 60]}]},
        layer_type="detections",
    )

    # Verify it's readable
    layers = storage.list_annotation_layers(asset.asset_id)
    assert any(l["layer"] == "test/export_verify" for l in layers)

    # Clean up test layer
    metadata_dir = storage._metadata_dir_for_asset(asset)
    test_layer_path = metadata_dir / "annotations" / "test--export_verify.json"
    if test_layer_path.exists():
        test_layer_path.unlink()
    storage._update_annotation_layers_cache(asset)
    storage.save()

    print("  PASS: real fc-100 export + add_annotation_layer verified")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print("=" * 60)
    print("VD3 COCO Export Tests")
    print("=" * 60)

    print("\nUnit tests:")
    test_bbox_export()
    test_category_mapping()
    test_annotation_count_preserved()
    test_optional_fields_preserved()
    test_coco_images_have_correct_dims()
    test_info_block_passthrough()

    # Integration test if vd3_rzdata path provided
    db_path = sys.argv[1] if len(sys.argv) > 1 else None
    if db_path is None:
        default = Path(__file__).parent.parent.parent.parent / "vd3_rzdata"
        if default.exists():
            db_path = str(default)

    if db_path and Path(db_path).exists():
        print(f"\nIntegration test (using {db_path}):")
        test_real_fc100_export(db_path)
    else:
        print("\nIntegration test: SKIPPED (no vd3_rzdata found)")
        print("  Run with: uv run python tests/test_coco_roundtrip.py /path/to/vd3_rzdata")

    print("\n" + "=" * 60)
    print("All tests passed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
