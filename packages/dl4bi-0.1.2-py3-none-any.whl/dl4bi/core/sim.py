"""Similarity and distance helpers."""

from functools import partial

import jax
import jax.numpy as jnp
from jax import jit
from dl4bi_sps.kernels import great_circle_dist, l2_dist


@partial(jit, static_argnames=("causal",))
def delta_time(
    q: jax.Array,  # [Q, 1]
    r: jax.Array,  # [R, 1]
    causal: bool = True,
):
    """Compute pairwise time differences between reference and query points.

    Args:
        q: Query timestamps of shape ``[Q, 1]``.
        r: Reference timestamps of shape ``[R, 1]``.
        causal: Whether to mask future reference times with ``inf``.

    Returns:
        Pairwise time deltas with shape ``[Q, R]``.
    """
    d = r.T - q
    if causal:
        return jnp.where(d <= 0, d, jnp.inf)
    return d  # [Q, R]
