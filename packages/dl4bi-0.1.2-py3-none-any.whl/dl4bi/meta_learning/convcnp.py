"""Convolutional Conditional Neural Process model."""

from dataclasses import field
from typing import Callable, List, Optional

import flax.linen as nn
import jax
import jax.numpy as jnp
from dl4bi_sps.utils import build_grid

from ..core.conv import ConvCNPNet, ConvDeepSet
from ..core.mlp import MLP
from ..core.model_output import DiagonalMVNOutput
from .steps import likelihood_train_step, likelihood_valid_step


class ConvCNP(nn.Module):
    """[The Convolutional Conditional Neural Process](https://arxiv.org/abs/1910.13556).

    Based on Yann Dubois' implementation [here](https://github.com/YannDubs/Neural-Process-Family/blob/master/npf/neuralproc/convnp.py#L26).

    Args:
        s_lower: Lower coordinate bound of grid.
        s_upper: Upper coordinate bound of grid.
        points_per_unit: Number of points per unit interval on input, which is
            used to discretize the function.
        enc: An encoder module that uses context points to infer function values
            on a grid.
        conv_net: A convolutional network used for the function representation
            on a grid.
        dec: A module that decodes grid values to test locations.
        head: Transforms the decoder output into model output.
        output_fn: A function that transforms the model output into
            a form that can be consumed by loss functions.
        train_step: What training step to use.
        valid_step: What validation step to use.
    Returns:
        An instance of `ConvCNP`.
    """

    s_lower: List[float] = field(default_factory=lambda: [-2.5])
    s_upper: List[float] = field(default_factory=lambda: [2.5])
    points_per_unit: int = 128
    enc: nn.Module = ConvDeepSet()
    conv_net: nn.Module = ConvCNPNet()
    dec: nn.Module = ConvDeepSet()
    head: nn.Module = MLP([128] * 3 + [2])
    output_fn: Callable = DiagonalMVNOutput.from_activations
    train_step: Callable = likelihood_train_step
    valid_step: Callable = likelihood_valid_step

    @nn.compact
    def __call__(
        self,
        s_ctx: jax.Array,  # [B, L_ctx, D_s]
        f_ctx: jax.Array,  # [B, L_ctx, D_f]
        s_test: jax.Array,  # [B, L_test, D_s]
        mask_ctx: Optional[jax.Array] = None,  # [B, L_ctx]
        training: bool = False,
        **kwargs,
    ):
        """Predict test outputs with the ConvCNP architecture."""
        B = s_ctx.shape[0]
        s_dim = len(self.s_lower)
        s_grid = build_grid(
            [
                dict(start=lo, stop=up, num=int(self.points_per_unit * (up - lo)))
                for (lo, up) in zip(self.s_lower, self.s_upper)
            ]
        )  # [*P..., s_dim]
        s_grid = jnp.repeat(s_grid[None, :], B, axis=0)  # [B, *P..., s_dim]
        conv_dims = s_grid.shape[:-1]  # [B, *P...]
        s_vec = s_grid.reshape(B, -1, s_dim)  # [B, L_grid, s_dim]
        h = self.enc(s_ctx, f_ctx, s_vec, mask_ctx)  # [B, L_grid, D]
        h = self.conv_net(h.reshape(conv_dims + (-1,)))  # [B, *P..., D]
        h = self.dec(s_vec, h.reshape(B, s_vec.shape[1], -1), s_test)  # [B, L_grid, D]
        f_dist = self.head(h)
        return self.output_fn(f_dist)
