# Knowledge Base Ingestion

This module provides configuration and processing utilities for ingesting documents from directories into knowledge bases. It supports markdown, JSON, and JSONL files with configurable chunking, patterns, and metadata.

The pipeline is **async-primary** and **storage-agnostic**. See
[DirectoryProcessor](directory-processor.md) for the async API and
[DocumentSource](document-source.md) for the protocol that lets it
drive any storage backend (local, in-memory, S3).

## Overview

The ingestion system has three primary components:

1. **KnowledgeBaseConfig**: Configuration for how documents should be processed
2. **DirectoryProcessor**: Async-primary processor (sync wrapper available)
3. **DocumentSource**: Async protocol for file enumeration and reads —
   decouples the processor from the local filesystem so the same
   pipeline drives local directories, in-memory backends, and S3

## Key Features

- **Pattern-based file selection**: Glob patterns for including/excluding files
- **Per-pattern configuration**: Different chunking/text extraction per file type
- **Config file support**: Load configuration from `knowledge_base.json` or `.yaml`
- **Streaming for large files**: JSONL files processed without loading into memory
- **Automatic type detection**: Handles markdown, JSON, and JSONL automatically
- **Document-level metadata**: Attach metadata to all chunks from a file
- **Storage-agnostic**: Any `DocumentSource` — local, backend, custom

## Installation

```bash
uv pip install dataknobs-xization
```

## Quick Start

### Basic Directory Processing

```python
from dataknobs_xization.ingestion import process_directory

# Process all files in directory
for doc in process_directory("./docs"):
    print(f"{doc.source_file}: {doc.chunk_count} chunks")
    for chunk in doc.chunks:
        print(f"  - {chunk['text'][:50]}...")
```

### With Configuration

```python
from dataknobs_xization.ingestion import (
    DirectoryProcessor,
    KnowledgeBaseConfig,
    FilePatternConfig,
)

config = KnowledgeBaseConfig(
    name="product-docs",
    default_chunking={
        "max_chunk_size": 500,
    },
    patterns=[
        FilePatternConfig(
            pattern="api/**/*.json",
            text_fields=["title", "description"],
        ),
        FilePatternConfig(
            pattern="**/*.md",
        ),
    ],
    exclude_patterns=["**/drafts/**", "**/test/**"],
)

processor = DirectoryProcessor(config, "./docs")

for doc in processor.process():
    if doc.has_errors:
        print(f"Error processing {doc.source_file}: {doc.errors}")
    else:
        print(f"Processed {doc.source_file}: {doc.chunk_count} chunks")
```

### Loading Config from File

```python
from dataknobs_xization.ingestion import KnowledgeBaseConfig, DirectoryProcessor

# Loads from ./docs/knowledge_base.json or knowledge_base.yaml
config = KnowledgeBaseConfig.load("./docs")

processor = DirectoryProcessor(config, "./docs")
```

## Configuration

### KnowledgeBaseConfig

```python
from dataknobs_xization.ingestion import KnowledgeBaseConfig

config = KnowledgeBaseConfig(
    # Identity
    name="my-knowledge-base",

    # Default chunking for all files
    default_chunking={
        "max_chunk_size": 500,
        "combine_under_heading": True,
    },

    # Quality filtering (optional)
    default_quality_filter={
        "min_content_length": 50,
        "min_word_count": 10,
    },

    # File patterns (optional - defaults to **/*.md, **/*.json, **/*.jsonl)
    patterns=[
        FilePatternConfig(pattern="**/*.md"),
        FilePatternConfig(pattern="api/**/*.json", text_fields=["title"]),
    ],

    # Exclusions
    exclude_patterns=[
        "**/drafts/**",
        "**/.git/**",
        "*.tmp",
    ],

    # Default metadata for all chunks
    default_metadata={
        "version": "1.0",
        "source": "documentation",
    },
)
```

### FilePatternConfig

```python
from dataknobs_xization.ingestion import FilePatternConfig

pattern_config = FilePatternConfig(
    # Required
    pattern="api/**/*.json",          # Glob pattern

    # Optional
    enabled=True,                      # Enable/disable this pattern
    chunking={                         # Override default chunking
        "max_chunk_size": 800,
    },
    text_template="{{ title }}: {{ description }}",  # Jinja2 template for JSON
    text_fields=["title", "body"],     # Fields to extract for text
    metadata_fields=["author", "date"], # Fields to include in metadata
)
```

### Config File Format

Create `knowledge_base.json` or `knowledge_base.yaml` in your docs directory:

**JSON:**
```json
{
  "name": "product-docs",
  "default_chunking": {
    "max_chunk_size": 500
  },
  "patterns": [
    {
      "pattern": "api/**/*.json",
      "text_fields": ["title", "description"]
    },
    {
      "pattern": "**/*.md"
    }
  ],
  "exclude_patterns": ["**/drafts/**"]
}
```

**YAML:**
```yaml
name: product-docs
default_chunking:
  chunker: markdown_tree     # default, can be omitted
  max_chunk_size: 500

patterns:
  - pattern: "api/**/*.json"
    text_fields:
      - title
      - description
  - pattern: "**/*.md"

exclude_patterns:
  - "**/drafts/**"
```

## API Reference

### KnowledgeBaseConfig

```python
class KnowledgeBaseConfig:
    @classmethod
    def load(cls, directory: str | Path) -> KnowledgeBaseConfig:
        """Load config from directory's knowledge_base.json/yaml file.

        If no config file exists, returns default configuration.
        """

    @classmethod
    def from_dict(cls, data: dict) -> KnowledgeBaseConfig:
        """Create config from dictionary."""

    def to_dict(self) -> dict:
        """Convert config to dictionary."""

    def get_pattern_config(self, file_path: str | Path) -> FilePatternConfig | None:
        """Get the matching pattern config for a file path."""

    def is_excluded(self, file_path: str | Path) -> bool:
        """Check if a file should be excluded."""

    def get_chunking_config(self, file_path: str | Path) -> dict:
        """Get chunking config for a file (pattern override + defaults)."""

    def get_metadata(self, file_path: str | Path) -> dict:
        """Get metadata for a file including default metadata."""
```

### DirectoryProcessor

```python
class DirectoryProcessor:
    def __init__(
        self,
        config: KnowledgeBaseConfig,
        root_dir: str | Path,
    ):
        """Initialize processor.

        Args:
            config: Knowledge base configuration
            root_dir: Root directory to process
        """

    def process(self) -> Iterator[ProcessedDocument]:
        """Process all documents in the directory.

        Yields ProcessedDocument for each file. Uses streaming
        for large JSON files to avoid memory exhaustion.

        Yields:
            ProcessedDocument for each processed file
        """
```

### ProcessedDocument

```python
@dataclass
class ProcessedDocument:
    source_file: str              # Path to source file
    document_type: str            # "markdown", "json", or "jsonl"
    chunks: list[dict[str, Any]]  # List of processed chunks
    metadata: dict[str, Any]      # Document-level metadata
    errors: list[str]             # Errors encountered during processing

    @property
    def chunk_count(self) -> int:
        """Number of chunks in this document."""

    @property
    def has_errors(self) -> bool:
        """Whether processing encountered errors."""
```

### Chunk Format

Each chunk in `ProcessedDocument.chunks` contains:

```python
{
    "text": "The chunk text content",
    "embedding_text": "Optimized text for embeddings",
    "chunk_index": 0,
    "source_path": "[0].items[1]",  # For JSON
    "metadata": {
        "heading_path": "Section > Subsection",  # For markdown
        "headings": ["Section", "Subsection"],
        # ... additional metadata
    }
}
```

## Use Cases

### RAG Knowledge Base Loading

```python
from dataknobs_bots.knowledge import RAGKnowledgeBase, KnowledgeBaseConfig

# Create knowledge base
kb = await RAGKnowledgeBase.from_config(config)

# Load documents using ingestion config
kb_config = KnowledgeBaseConfig(
    name="docs",
    patterns=[
        FilePatternConfig(pattern="**/*.md"),
        FilePatternConfig(pattern="api/*.json", text_fields=["title", "body"]),
    ],
)

results = await kb.load_from_directory("./docs", config=kb_config)
print(f"Loaded {results['total_chunks']} chunks from {results['total_files']} files")
```

### Batch Processing with Progress

```python
from dataknobs_xization.ingestion import DirectoryProcessor, KnowledgeBaseConfig

config = KnowledgeBaseConfig.load("./docs")
processor = DirectoryProcessor(config, "./docs")

total_chunks = 0
for doc in processor.process():
    total_chunks += doc.chunk_count
    print(f"[{total_chunks:,} chunks] {doc.source_file}")

print(f"Total: {total_chunks:,} chunks")
```

### Custom Processing Pipeline

```python
from dataknobs_xization.ingestion import process_directory

async def process_documents(directory: str):
    for doc in process_directory(directory):
        # Skip documents with errors
        if doc.has_errors:
            log_errors(doc.source_file, doc.errors)
            continue

        # Process chunks
        for chunk in doc.chunks:
            # Generate embedding
            embedding = await embed(chunk["embedding_text"] or chunk["text"])

            # Store in database
            await db.insert({
                "id": f"{doc.source_file}_{chunk['chunk_index']}",
                "text": chunk["text"],
                "embedding": embedding,
                "source": doc.source_file,
                "type": doc.document_type,
                **chunk["metadata"],
                **doc.metadata,
            })
```

## File Type Handling

### Markdown Files

- Chunked via the pluggable `Chunker` abstraction (default: `MarkdownTreeChunker`)
- Parsed into tree structure preserving heading hierarchy
- Chunked with configurable size and smart boundary detection
- Quality filtering available
- Heading metadata preserved
- Custom chunker selectable via the `chunker` key in chunking config

### JSON Files

- Arrays: Each item becomes one or more chunks
- Objects: Flattened or template-based text generation
- Supports text_template and text_fields configuration

### JSONL/NDJSON Files

- Streamed line-by-line for memory efficiency
- Supports gzipped files (`.jsonl.gz`)
- Each line becomes one or more chunks

## Testing

```bash
cd packages/xization
uv run pytest tests/test_ingestion.py -v
```

## Custom Chunkers

The `DirectoryProcessor` uses the pluggable `Chunker` abstraction for markdown
files.  The `chunker` key in the chunking config selects the implementation:

```yaml
default_chunking:
  chunker: markdown_tree          # built-in default
  max_chunk_size: 500

# Or use a custom chunker via dotted import path:
default_chunking:
  chunker: my_project.chunkers.RFCChunker
  max_chunk_size: 1200
```

### Transform Pipeline

Add a `transforms` key to apply post-processing after chunking:

```yaml
default_chunking:
  chunker: markdown_tree
  max_chunk_size: 800
  transforms:
    - merge_small:
        min_size: 200
    - split_large:
        max_size: 1000
```

Built-in transforms: `merge_small`, `split_large`, `quality_filter`.

### Source Positions

Chunk metadata includes `char_start` and `char_end` — character offsets
into the source document.  These are forwarded in each chunk dict's
`metadata` field for use in citation and source highlighting.

See [Markdown Chunking — Pluggable Chunker Abstraction](../markdown/MARKDOWN_CHUNKING.md#pluggable-chunker-abstraction)
for how to write and register custom chunkers and transforms.

## Related

- [DirectoryProcessor](directory-processor.md) - Async-primary API
- [DocumentSource](document-source.md) - Storage-agnostic protocol
- [JSON Chunking](../json/JSON_CHUNKING.md) - JSON-specific chunking
- [Markdown Chunking](../markdown/MARKDOWN_CHUNKING.md) - Markdown-specific chunking
- [Quality Filtering](../markdown/RAG_QUALITY_FILTERING.md) - Filtering low-quality chunks
