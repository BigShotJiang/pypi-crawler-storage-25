"""Text normalization and tokenization tools."""

from dataknobs_xization import (
    annotations,
    authorities,
    content_transformer,
    html,
    ingestion,
    json,
    lexicon,
    markdown,
    masking_tokenizer,
    normalize,
)
from dataknobs_xization.content_transformer import (
    ContentTransformer,
    csv_to_markdown,
    json_to_markdown,
    yaml_to_markdown,
)
from dataknobs_xization.html import (
    HTMLConverter,
    HTMLConverterConfig,
    html_to_markdown,
)
from dataknobs_xization.markdown import (
    AdaptiveStreamingProcessor,
    Chunk,
    ChunkFormat,
    ChunkMetadata,
    ChunkQualityConfig,
    ChunkQualityFilter,
    EnrichedChunkData,
    HeadingInclusion,
    MarkdownChunker,
    MarkdownNode,
    MarkdownParser,
    StreamingMarkdownProcessor,
    build_enriched_text,
    chunk_markdown_tree,
    format_heading_display,
    get_dynamic_heading_display,
    is_multiword,
    parse_markdown,
    stream_markdown_file,
    stream_markdown_string,
)
from dataknobs_xization.chunking import (
    ChunkTransform,
    Chunker,
    CompositeChunker,
    DocumentInfo,
    MarkdownTreeChunker,
    MergeSmallChunks,
    QualityFilterTransform,
    SplitLargeChunks,
    chunker_registry,
    create_chunker,
    register_chunker,
    register_transform,
    split_text,
    transform_registry,
)
from dataknobs_xization.masking_tokenizer import CharacterFeatures, TextFeatures
from dataknobs_xization.json import (
    JSONChunk,
    JSONChunkConfig,
    JSONChunker,
)
from dataknobs_xization.ingestion import (
    DirectoryProcessor,
    FilePatternConfig,
    IngestionConfigError,
    KnowledgeBaseConfig,
    ProcessedDocument,
    process_directory,
)

__version__ = "1.3.5"

__all__ = [
    # Existing exports
    "CharacterFeatures",
    "TextFeatures",
    "annotations",
    "authorities",
    "content_transformer",
    "lexicon",
    "masking_tokenizer",
    "normalize",
    # Content transformation
    "ContentTransformer",
    "csv_to_markdown",
    "json_to_markdown",
    "yaml_to_markdown",
    # HTML conversion
    "html",
    "HTMLConverter",
    "HTMLConverterConfig",
    "html_to_markdown",
    # JSON module
    "json",
    "JSONChunk",
    "JSONChunkConfig",
    "JSONChunker",
    # Markdown module
    "markdown",
    # Markdown chunking classes and functions
    "AdaptiveStreamingProcessor",
    "Chunk",
    "ChunkFormat",
    "ChunkMetadata",
    "ChunkQualityConfig",
    "ChunkQualityFilter",
    "EnrichedChunkData",
    "HeadingInclusion",
    "MarkdownChunker",
    "MarkdownNode",
    "MarkdownParser",
    "StreamingMarkdownProcessor",
    "build_enriched_text",
    "chunk_markdown_tree",
    "format_heading_display",
    "get_dynamic_heading_display",
    "is_multiword",
    "parse_markdown",
    "stream_markdown_file",
    "stream_markdown_string",
    # Chunking abstraction
    "ChunkTransform",
    "Chunker",
    "CompositeChunker",
    "DocumentInfo",
    "MarkdownTreeChunker",
    "MergeSmallChunks",
    "QualityFilterTransform",
    "SplitLargeChunks",
    "chunker_registry",
    "create_chunker",
    "register_chunker",
    "register_transform",
    "split_text",
    "transform_registry",
    # Ingestion module
    "ingestion",
    "DirectoryProcessor",
    "FilePatternConfig",
    "IngestionConfigError",
    "KnowledgeBaseConfig",
    "ProcessedDocument",
    "process_directory",
]
