"""Bundled default Hydra configs."""
