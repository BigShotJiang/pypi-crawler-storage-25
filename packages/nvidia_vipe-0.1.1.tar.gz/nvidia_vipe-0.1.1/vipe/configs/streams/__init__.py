"""Stream config package marker."""
