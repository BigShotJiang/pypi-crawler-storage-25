"""SLAM config package marker."""
