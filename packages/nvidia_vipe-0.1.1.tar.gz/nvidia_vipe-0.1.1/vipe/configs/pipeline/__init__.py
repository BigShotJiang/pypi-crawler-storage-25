"""Pipeline config package marker."""
