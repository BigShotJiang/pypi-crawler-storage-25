﻿from setuptools import setup, find_packages
import os

# Leemos el contenido de README.md para la descripción larga
# Esto asegura que lo que ves en el Canvas sea lo mismo que aparece en PyPI
ruta_readme = os.path.join(os.path.dirname(__file__), "README.md")
with open(ruta_readme, "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="ComicScript",
    version="1.0.6",
    author="Emiliano (emicics)",
    author_email="emicicsmaker@gmail.com", # Puedes cambiar esto por el tuyo
    description="A library that turns boring Python errors into hilarious roasts.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tu_usuario/ComicScript", # O tu link preferido
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'Emilve', 'rich'
    ],
)