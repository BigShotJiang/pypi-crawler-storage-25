# Doctrine: Shadow Genome Countermeasures

Canonical inventory of recurring failure patterns surfaced during audit tribunals and the mechanical countermeasures that prevent their recurrence. Cited by `qor/skills/sdlc/qor-plan/SKILL.md` Step 2b (Grounding Protocol) and consulted during `/qor-audit` adversarial sweeps.

Each entry names the failure pattern, the countermeasure rule, and a verification hint (grep/read/test) an agent can run to detect the antipattern.

## SG-016: generic-convention paths without grounding

Writing `src/migrations/versions/` because "most repos use that" without checking `alembic.ini` or `ls tests/` or `ls infra/`.

**Countermeasure**: Before citing any file path, run the specific grep/read that proves the path exists in this repo. Tag unverified paths with `{{verify: <mechanism>}}` in the draft pass.

**Verification hint**: `ls <proposed_root>` or `grep <symbol> --include=*.toml` before the plan cites a path.

## SG-017 / SG-020: inventing security controls without surveying existing mechanism

Claiming "role-based privilege" or `SECURITY DEFINER` enforces tenant isolation without reading the schema or existing policies.

**Countermeasure**: Grep the existing schema/code for the concrete security mechanism before proposing one. If the mechanism is absent, state that clearly — do not invent one that sounds plausible.

**Verification hint**: `grep -rn "SECURITY DEFINER\|REVOKE\|RLS_POLICIES" src/` before any security claim.

## SG-019: CLI flag portability assumption

Assuming `-k` works on both `ruff` and `mypy` because pytest accepts it. Tool CLIs disagree on flag semantics.

**Countermeasure**: Read each tool's `--help` output before citing any flag. Do not generalize across tool families.

**Verification hint**: `<tool> --help | grep <flag>` for every flag cited.

## SG-021: multi-layer edit compression

Writing "add to `RLS_POLICIES`" in a plan, which compresses "edit these 4 files" into a single verb that hides which files actually receive the edit.

**Countermeasure**: Enumerate every file that receives the edit before writing the verb. Map "add to X" → "edit `path1.py` line N; edit `path2.py` line M; ..." with grep evidence.

**Verification hint**: `grep -rn "<target_symbol>" --include=*.py` produces the file list; the plan disposes of each.

## SG-032: batch-split-write coverage gap

Lookup-table-based write-back (e.g., `src_map.get(e["id"])`) drops records created mid-cycle. Newly minted records have no prior identity in the lookup and silently fall through the filter.

**Countermeasure**: Either (a) classify records at creation time with explicit file/bucket assignment; or (b) add a default bucket in the split for unmatched records. Never rely on a post-hoc lookup to assign records that didn't exist when the lookup was built.

**Verification hint**: review-time question — "can any record in this batch have no prior identity in the lookup?" If yes, the plan must specify the fallback. Source incident: Phase 14 v2 (Entry #32 V-1).

## SG-033: positional-to-keyword breakage

Changing a function signature from `(x, y=None)` to `(x, *, y=None)` (keyword-only) without updating existing positional callers. Runtime breaks silently until called.

**Countermeasure**: Before introducing `*` in a signature, grep all call sites (production + tests) and update positional calls to keyword form in the same commit. "Existing body unchanged" does not mean "existing callers unchanged."

**Verification hint**: `grep "<fn_name>(" --include=*.py` after the signature change. Enforced by `tests/test_shadow_genome_doctrine.py::test_no_positional_calls_to_keyword_only_functions` (AST-based). Source incident: Phase 14 v2 (Entry #32 V-2).

## SG-034: AST walker node-family omission

AST-based code analysis walkers that check only `ast.FunctionDef` miss `ast.AsyncFunctionDef`; walkers that count `Call.args` by length miss `ast.Starred` unpacking. Either omission produces false positives or false negatives.

**Countermeasure**: Enumerate every relevant node family: `FunctionDef + AsyncFunctionDef`; `Call.args` filtered for `Starred`; `Call.func` dispatched between `Name` and `Attribute`. A walker that misses a family produces unreliable results.

**Verification hint**: ast-based tests should include a Rule-4 negative-path test with each family (e.g., `test_star_unpack_call_not_flagged`, `test_async_keyword_only_functions_detected`). Source incident: Phase 15 v1 (Entry #36 V-1 + V-4).

## SG-035: doctrine-content test unanchored

Tests asserting `"keyword-only" in body` pass when the doctrine section they claim to verify is missing entirely but the keyword co-occurs elsewhere. Violates W-1 literal-keyword discipline.

**Countermeasure**: Anchor keyword checks to the section header (regex proximity or markdown header parsing). A doctrine test that passes with its subject section removed does not enforce what it claims.

**Verification hint**: use `re.search(r"<SG-ID>.{0,500}<keyword>", body, re.DOTALL)` or parse headers. Include a negative-path test (e.g., `test_proximity_anchor_fails_when_section_missing`) that strips the section and proves the test fails. Source incident: Phase 15 v1 (Entry #36 V-2).

## SG-036: doctrine adoption grace period

A doctrine codified in phase N does not become automatically load-bearing in phase N+1 unless the author treats it as active. "I'll verify during implementation" is a deferral, not compliance. The Grounding Protocol requires inline citation at plan-authoring time, not implementation time.

**Countermeasure**: Treat newly codified doctrine as active immediately. Run all grep/read verifications inline with date-stamped provenance. No grace period.

**Verification hint**: plan body contains phrases like "grounded via `wc -l`" or "verified 2026-MM-DD" for every file-size/phrase-location claim. Source incident: Phase 16 v1 (Entry #40 V-1).

## SG-037: knowledge-surface drift

Doctrine tests anchored to a single file produce false negatives when refactoring moves knowledge across files. The test asserts `"phase/" in SKILL_A.read_text()`; refactor extracts the content to a companion references file; test fails even though the knowledge surface was preserved.

**Countermeasure**: Doctrine tests must check the combined knowledge surface (skill + declared companion references), not a single file. When a skill declares its companions (via `Read:` pointers or `See <path>` citations), tests should read the union.

**Verification hint**: test reads `skill_body + extensions_body` before asserting. When a skill moves content to a reference file, update the associated doctrine tests in the same commit. Source incident: Phase 16 Track C refactor (Entry #42 implementation note).

## SG-038: prose-code mismatch in plans

A plan document encodes the same spec in two places: prose descriptions and code blocks. These drift independently when the author edits mid-draft. Prose says "test covers 11 IDs"; code block lists 9; implementer following the code produces partial coverage while prose claims full.

**Countermeasure**: When a plan updates a list, enumeration, or count, grep the plan for every occurrence of that element and update all copies in lockstep. Prose, code blocks, and success criteria must cite the same values.

**Verification hint**: Judge cross-checks prose claims against code blocks during audit; any mismatch is VETO-grade. Optional future enforcement: lint plans for prose+code consistency on named enumerations. Source incident: Phase 17a v1 (Entry #44 V-1).

## SG-InfrastructureMismatch: plan claims contradict current repository infrastructure

A plan references filesystem paths, gate artifact glob patterns, event types, cross-module function signatures, or skill-step anchors that current code does not actually provide. Plan-internal consistency passes (prose matches code blocks, tests match implementation) but plan-to-infrastructure alignment fails silently. The defect only surfaces at implement-time or (worse) at ship-time when the intended behavior is mechanically impossible.

**Source incident**: Phase 36 Pass 4 V10. Original `plan-qor-phase36-planaudit-loop-countermeasures.md` built a stall-detection mechanism on the assumption that `.qor/gates/<sid>/audit*.json` globbing would yield multiple audit artifacts per session. Verified against actual code: `gate_chain.write_gate_artifact` writes singleton and overwrites on re-emission. The entire mechanism would have shipped as dead code. The Judge missed this across four audit passes because verification was limited to plan-internal consistency.

**Countermeasure** (codified in Phase 37): `/qor-audit` gains a seventh adversarial pass — Infrastructure Alignment Pass — that grep-verifies every plan claim against current repository code before PASS verdict. Violations map to the `infrastructure-mismatch` finding category (Phase 37 `findings_categories` enum). `/qor-plan` Step 2b Grounding Protocol also gains an infrastructure alignment sub-check: every `{{verify: <claim> }}` tag that survives to plan submission must be resolved before audit can clear it.

**Verification hint**: for every filesystem path cited, run `ls -la <path>` or `git ls-files <path>`. For every glob pattern, verify against a live session's gate directory shape. For every event type, grep `qor/gates/schema/shadow_event.schema.json` for the literal enum value. For every cross-module function cited, `grep -n "def <name>" <module>`. Unresolved → VETO.

## Phase 24-26 narrative SG entries (see `docs/SHADOW_GENOME.md`)

The following pattern IDs were surfaced as narrative Shadow Genome entries during audit tribunals in Phases 24, 25, and 26. Promotion into full structured countermeasure form (with grep/test verification hint) is queued; in the meantime, citing the pattern by ID in a plan or audit report references the narrative entry in `docs/SHADOW_GENOME.md`.

- **SG-Phase24-A**: cumulative razor creep in CLI harness (additive edits to an already-over-limit file without a companion refactor). Mitigation shipped: Phase 24 `/qor-refactor` extracted `qor/install.py`.
- **SG-Phase24-B**: unsafe deserializer defaults (plan introduces YAML parsing without naming `yaml.safe_load`). Mitigation shipped: `tests/test_yaml_safe_load_discipline.py` scans `qor/` and `tests/**/*.py` (widened in Phase 25).
- **SG-Phase24-C**: reflexive dependency introduction for trivial serializers (proposing `tomli_w` when a <15-line vanilla writer suffices). Mitigation shipped: dependency-shape test locks `pyproject.toml` runtime deps.
- **SG-Phase24-D**: remediation target mismatch (running `/qor-refactor` to address plan-text VETO grounds). Mitigation shipped in Phase 26: per-ground `**Required next action:**` directives in audit reports (`qor/references/doctrine-audit-report-language.md`).
- **SG-Phase25-A**: A08 discipline scope gap (lint test root not covering new usage directory). Mitigation shipped: widened walk + planted-call negative test.
- **SG-Phase25-B**: ghost feature via metadata-only declaration (frontmatter flag without backing behavior). Mitigation shipped: canonical section markers + lint (`test_tone_skill_frontmatter.py`) + pinned example (`test_tone_rendering_example.py`).

No narrative SG entries surfaced during Phase 26 audit tribunals; pattern `repeated_veto_pattern` is a Shadow Genome *event* (structured, in `PROCESS_SHADOW_GENOME.md`), not a narrative failure pattern.

## SG-SkillProtocolBypass: skill markdown executed without runtime provenance

Skills are markdown documents under `qor/skills/**/SKILL.md`. Helper functions (`gate_chain.write_gate_artifact`, `intent_lock.capture`, etc.) accept payloads from any caller. Pre-Phase-52 there was no runtime check that a skill protocol was actually executed vs a hand-written audit/seal pasted into the ledger.

**Source incidents**: Phases 46, 48, 49, 50 (one operator session). All sealed without writing `.qor/gates/<sid>/*.json` artifacts. `git log --diff-filter=A --name-only --all -- ".qor/gates/"` returned 0 hits across the entire repo history pre-Phase-52.

**Countermeasure** (codified Phase 52): `gate_chain.write_gate_artifact` requires `QOR_SKILL_ACTIVE=<phase>` env var matching the `phase` argument. `qor.reliability.gate_chain_completeness.check()` walks ledger SESSION SEAL entries and asserts all four gate artifacts exist for sealed phases ≥ 52. Wired into `/qor-substantiate` Step 7.8 + `.github/workflows/ci.yml` `gate-chain-completeness` job (blocks PR merges to main).

**Verification hint**: `git log --diff-filter=A --name-only --all -- ".qor/gates/"` should be non-empty for any sealed phase ≥ 52. CI job `gate-chain-completeness` blocks merge on violation. Bypass via `QOR_GATE_PROVENANCE_OPTIONAL=1` is for tests only (autouse fixture in `tests/conftest.py`).

## SG-VacuousLint: self-exempting cutoff in commit-walking lints

A lint that walks `git log` and applies a "phase >= N: continue # grandfathered" cutoff at the same N where the lint was introduced is structurally vacuous on first run — there are no inputs that could fail. The lint passes by definition until a violator commits *after* the cutoff in some future phase.

**Source incident**: Phase 49's `tests/test_attribution_tiered_usage.py` lines 128, 147 (`if phase_num < 49: continue`). Authored at Phase 49 itself; only Phase 49 commits in scope at write time, all of which the same author wrote to comply.

**Countermeasure** (codified Phase 52): every cutoff lint MUST be paired with a fixture-based negative-path test that fabricates a synthetic violating input and asserts the lint catches it. The negative-path test does NOT walk real git history — it constructs a synthetic input and exercises the lint regex/parser directly. See `tests/test_attribution_tiered_negative_paths.py` for canonical pattern.

**Verification hint**: for any test using `if phase_num < N: continue # grandfathered`, search the same test file (or its companion `_negative_paths.py`) for a sibling test with a fabricated synthetic input (no `git log` invocation). If absent, the lint is presence-only on its own subject.

## SG-RecursiveBashInjection: plan that forbids shell-interpolation reintroduces it

A plan whose `non_goals` or doctrine citation forbids `python -c "..."${VAR}"` patterns (per SG-Phase47-A) but whose `## Changes` section specifies bash that interpolates shell variables into a `python -c` literal. The pattern is recursive: the plan's text correctly identifies the anti-pattern and then commits it.

**Source incident**: Phase 51 WIP (`docs/plan-qor-phase51-ssdf-tag-emission.md`) §"Source surfaces" §2 specified `python -c " ... json.loads('''${FILES_TOUCHED_JSON}''') ... "`. Plan was VETO'd retroactively by /qor-audit before merge.

**Countermeasure** (codified Phase 52): `/qor-audit` Step 3 Infrastructure Alignment Pass adds an explicit grep against the plan body: `python -c "[^"]*\$\{` patterns; any hit is an automatic VETO with `infrastructure-mismatch` category citing SG-RecursiveBashInjection. Implemented as a wiring test (`tests/test_substantiate_step_7_4_ssdf_emission.py::test_step_7_4_does_not_use_python_c_shell_interpolation`).

**Verification hint**: `grep -E 'python -c "[^"]*\$\{' docs/plan-qor-phase*.md` should be empty for any post-Phase-52 plan. If any hit, the plan recursively reintroduces SG-Phase47-A and must be amended.

## SG-PromptInjection-A: governance markdown read into LLM context without canary scan

`/qor-audit`, `/qor-implement`, and `/qor-substantiate` read `docs/ARCHITECTURE_PLAN.md`, `docs/META_LEDGER.md`, `docs/CONCEPT.md`, and the current plan file verbatim into LLM context as part of state verification. When the trust boundary spans multiple authors (open-source PRs, CI-driven invocations, multi-author working directories), an attacker with write access to any of these files can embed instructions that subvert the audit. Pre-Phase-53 there was no canary scan and no commit-time forbid rule for governance-classified resources; the only defense was operator vigilance and the host-LLM provider's own injection resistance.

**Source incident**: Phase 53 research brief (`docs/research-brief-prompt-logic-frameworks-2026-04-30.md` §A.LLM01) classified the gap as HIGH. Self-application Phase 4 of the Phase 53 plan exercises the new canary scan against the plan, brief, and doctrine to verify the meta-coherence property "the system that defends against prompt injection does not itself contain a prompt injection."

**Countermeasure** (codified Phase 53): `qor.scripts.prompt_injection_canaries` exposes a `CANARIES` tuple and `scan(content) -> list[CanaryHit]` API. `/qor-audit` Step 3 invokes the CLI argv-form and VETOs on any non-zero exit with `findings_categories: ["prompt-injection", ...]`. `qor/policies/owasp_enforcement.cedar` carries a parallel `forbid` rule on `Code::"governance"` resources whose `has_prompt_injection_canary` attribute is True; the attribute is computed by `qor/policy/resource_attributes.compute_governance_attributes`. Two enforcement points (audit-time + commit-time), single source of truth (`CANARIES`).

**Verification hint**: `python -m qor.scripts.prompt_injection_canaries --files docs/ARCHITECTURE_PLAN.md docs/META_LEDGER.md docs/CONCEPT.md docs/plan-qor-phase*.md` should exit 0 for any clean repository state. If any hit, the audit refuses to PASS and the operator must amend the offending file. Audit-pass insertion point: `/qor-audit` SKILL.md Step 3 `#### Prompt Injection Pass` immediately before `#### Security Pass (L3 Violations)`. Per `qor/references/doctrine-prompt-injection.md`.

## SG-PreAuditLintGap-A: presence-only test descriptions + infrastructure-mismatch citations recur across plan authoring

Cross-session observation: Phase 53/54/55 first audits each issued Pass-1 VETO with the same finding combination — `test-failure` (presence-only test descriptions disguised as "co-occurrence behavior invariants") + `infrastructure-mismatch` (hedged or stale Python module / file path citations). The doctrine that should have caught these (Phase 46 test-functionality + Phase 37 infrastructure-alignment audit pass) only fires at Step 3 of `/qor-audit`; the Pass-1 VETO consumed an audit cycle each time the operator could have been warned earlier.

**Source incidents**: Phase 53 Pass 1 (5 presence-only tests + 3 infrastructure mismatches), Phase 54 Pass 1 (3 + 1), Phase 55 Pass 1 (3 + 1). Same operator authoring style across three consecutive phases; doctrine alone insufficient.

**Countermeasure** (codified Phase 55): two pre-audit lints invoked at `/qor-audit` Step 0.6 (and `/qor-repo-audit` Step 0.6 as best-effort): `qor.scripts.plan_test_lint` greps plan files for the four canonical presence-only patterns (substring-presence, section-exists, substring-in-file, path-exists); `qor.scripts.plan_grep_lint` walks plan files for cited Python module / skill paths and verifies each resolves at HEAD (excluding paths declared as NEW in Affected Files blocks). Both WARN-only — the existing Test Functionality Pass and Infrastructure Alignment Pass at Step 3 issue binding VETOs; the lints catch these classes earlier so the Governor can amend without consuming an audit cycle.

**Verification hint**: `python -m qor.scripts.plan_test_lint --plan docs/plan-qor-phase*.md` should exit 0 with no stderr warnings for any plan ready for audit. Same for `plan_grep_lint`. Pre-Phase-55 plans are not retroactively scanned (forward-only enforcement).

## SG-SecretLeakAtSeal-A: dormant Cedar attribute without scanner

Historical risk: the Cedar `forbid` rule on `Code::"production"` keyed on `resource.has_hardcoded_secrets` has existed since Phase 23, but no scanner drove the boolean. Pre-Phase-56 seal commits could have committed secrets undetected; the policy enforced nothing.

**Source incident**: Phase 56 audit gap discovery (research brief `docs/research-brief-prompt-logic-frameworks-2026-04-30.md` Priority 6 / NIST AI 600-1 §2.10 / OWASP LLM06).

**Countermeasure** (codified Phase 56): `qor.scripts.secret_scanner` provides regex-pattern detection (frozen `PATTERNS` tuple) with literal-substring `_ALLOWLIST` for the known false-positive class (Cedar/schema attribute names). `compute_production_attributes(path, content)` in `qor/policy/resource_attributes.py` returns the `has_hardcoded_secrets` boolean for the Cedar evaluator. `/qor-substantiate` Step 4.6.5 invokes `python -m qor.scripts.secret_scanner --staged --out dist/secrets.findings.json || ABORT` before seal — fail-closed BLOCK on any finding. Findings JSON follows gitleaks v8 schema; redacted match form (`<first4>...<last2>`) prevents leakage in the findings file itself.

**Verification hint**: `python -m qor.scripts.secret_scanner --files <path>...` should exit 0 with empty findings JSON for clean files; exit 1 with populated JSON for files containing secrets. Retroactive remediation of historical seals is operator-driven (e.g., `gitleaks detect --source . --log-opts="--all"` for full-history sweep). Forward-only enforcement starting Phase 56.

## SG-BareExceptionSwallowsSignals-A: `except BaseException` swallows SIGINT/SystemExit

Historical risk class: a `try/except BaseException` clause (with or without `# noqa: BLE001`) catches `KeyboardInterrupt` and `SystemExit` along with the intended `Exception` class. Operators lose Ctrl-C control over the running process. With long-timeout subprocess calls, indefinitely-spinning hooks, or daemon-style worker loops, the only escape is SIGKILL — which bypasses cleanup, leaves files in inconsistent states, and obscures the original failure cause from logs.

**Source incident**: Phase 57 audit of PR #12 `feat/b24-gate-written-hooks` (Entry #186 VETO). The PR's `gate_hooks._invoke_hook_safely` and `gate_chain._fire_gate_written_hook` both used `except BaseException` (with `# noqa: BLE001`). With the proposed 30-second per-subprocess-hook timeout AND swallow-on-callable-hook, a misbehaving Python entry-point hook could spin indefinitely with SIGKILL the only escape. PR #12 design rationale was correct (hook errors must never break the authoritative write path) but the catch was over-broad.

**Countermeasure** (codified Phase 57): use `except Exception` (NOT `except BaseException`) anywhere a "swallow and log" pattern is intentional. Reserve `BaseException` only for cleanup-then-reraise patterns where the cleanup itself must run regardless of signal class:

```python
# CORRECT: swallow + log; signals propagate
try:
    user_callable()
except Exception:
    log_error()

# CORRECT: cleanup-then-reraise (use sparingly; usually try/finally is enough)
try:
    user_callable()
except BaseException:
    cleanup()
    raise

# WRONG: signals swallowed; operator loses Ctrl-C
try:
    user_callable()
except BaseException:  # noqa: BLE001
    log_error()
```

Phase 57 anchors the discipline with two regression tests:
- `tests/test_gate_hooks_swallow.py::test_swallow_uses_except_exception_not_baseexception` — AST-anchored static check that the `_invoke_hook_safely` function source has `Exception` (not `BaseException`) in any `except` clause.
- `tests/test_gate_hooks_sigint_propagates.py::test_keyboard_interrupt_in_callable_hook_propagates` and `::test_system_exit_in_callable_hook_propagates` — behavioral check that `KeyboardInterrupt` and `SystemExit` raised inside hook callables propagate through dispatch.

**Verification hint**: search source for `except BaseException` excluding cleanup-then-reraise patterns: `rg "except BaseException" qor/ --type py | grep -v "raise"` should return zero hits in observer/swallow paths. False positives in `try/finally`-equivalent reraise patterns are acceptable.

## SG-DocSurfaceUncovered-A: skill / script / doctrine / schema changes without system-tier doc update

Historical risk class: a seal commit modifies skill bodies, helper scripts, doctrines, or gate schemas but does not update any of the four system-tier docs (`docs/SYSTEM_STATE.md`, `docs/operations.md`, `docs/architecture.md`, `docs/lifecycle.md`). Operators reading the SDLC narrative on a future date see stale documentation and either misunderstand the current state or have to reconstruct it from the META_LEDGER seal entries directly. /qor-substantiate Step 6 mandates SYSTEM_STATE.md update, but pre-Phase-58 the seal flow had no structural enforcement — only operator review of the PR caught the omission.

**Source incident**: Phase 57 substantiate cycle (2026-05-01). Phase 57 shipped the gate_written observer channel, modified `qor/scripts/gate_hooks.py` (NEW), `qor/scripts/gate_chain.py`, `qor/references/doctrine-hook-contract.md` (NEW), and the substantiate skill body (existing Step 4.6.5 was unchanged but the new public API surface should have surfaced in operator-facing docs). All three system-tier docs (SYSTEM_STATE, operations, architecture) were initially omitted; the operator caught the gap on PR review and required a follow-up commit (`9aa1d84` "docs: phase 57 surface coverage + B23 future-phase note") that added the entries.

**Countermeasure** (codified Phase 58):
1. **Procedural-fidelity check at substantiate Step 4.6.6** (`qor/scripts/procedural_fidelity.py:_detect_doc_surface_coverage`): static-analysis pass over the implement-gate `files_touched` set. Skill / script / doctrine / schema changes without at least one system-tier doc update emit a severity-2 `doc-surface-uncovered` Deviation. WARN posture in v1 (no abort); future phase may tighten to BLOCK once false-positive rate is characterized.
2. **SYSTEM_STATE drift-prevention test** (`tests/test_system_state_phase_coverage.py`): forward-only enforcement at every test run. Every META_LEDGER `Phase N feature substantiated` entry must have a corresponding `## Phase N (vX.Y.Z)` heading in `docs/SYSTEM_STATE.md`, modulo the explicit `_NO_SEAL_PHASES` set (phases 42-44 absorbed by Phase 41+45; Phase 51 absorbed by Phase 52).
3. **Severity-2 events** appended to the Process Shadow Genome (`docs/PROCESS_SHADOW_GENOME_UPSTREAM.md`) per deviation, providing a JSONL audit trail.

Phase 58 also backfilled SYSTEM_STATE.md entries for 12 sealed phases (41, 45-50, 52-56) that had accumulated drift pre-Phase-58. Forward-only enforcement starts at Phase 58.

**Verification hint**: `python -m qor.scripts.procedural_fidelity --session "$SESSION_ID"` after each implement gate write should emit no `doc-surface-uncovered` deviations for any seal commit touching skill / script / doctrine / schema surface. `python -m pytest tests/test_system_state_phase_coverage.py` enforces no future seal can land without the corresponding SYSTEM_STATE.md entry.

## SG-PrematureSolutioning-A: spark becomes solution before problem is framed

Historical risk class: an operator's spark of inspiration is structured as a solution shape (build a dashboard, ship a script, design a workflow) before the underlying problem is fully framed. Downstream planning then anchors on the solution shape; the actual problem (e.g., operational visibility, friction in workflow handoff, recurring incident class) is inferred from the solution rather than driving it. By the time `/qor-audit` pushes back, the plan has accumulated structural commitments to the wrong solution shape — premature decomposition has already split the work into tasks that match the inferred problem rather than the actual one.

**Source incident**: Issue #20 ("Future Concept: Add governed ideation readiness phase before research and planning") explicitly catalogs this and 7 other "natural unraveling points" — premature solutioning being the canonical case. The original Phase 58 plan (later renamed to Phase 59 in Phase 58's tech-debt wrap-up) was authored to introduce a structural countermeasure rather than relying on adversarial audit at Step 3 of `/qor-audit` to catch the pattern after-the-fact.

**Countermeasure** (codified Phase 59):
1. **`/qor-ideate` skill** at `qor/skills/sdlc/qor-ideate/SKILL.md`. Pre-research SDLC phase; advisory-gate posture matching Phase 8.
2. **Section 2 (Problem Frame) gate**: skill REFUSES to advance to Section 3 (Transformation Statement) until `problem_frame.affected_actors`, `problem_frame.failure_mode`, and `problem_frame.cost_of_failure` are all populated. Schema enforcement: `qor/gates/schema/ideation.schema.json` declares all three required.
3. **Section 7 (Options Matrix) gate**: skill REFUSES to advance to Section 8 (Governance Profile) until `options[]` contains ≥2 entries with at least one selected and rejection_reason populated for non-selected options.
4. **Predecessor recognition**: `gate_chain.check_prior_artifact` extension recognizes `ideation.json` as a valid prior for both `/qor-research` and `/qor-plan` phases. Hotfixes MAY skip ideation.
5. **Doctrine catalog**: `qor/references/doctrine-ideation-readiness.md` documents all 8 unraveling points with structural countermeasures.

The doctrine catalogs all 8 unraveling points (Premature Solutioning, Language Drift, Assumption Laundering, Scope Seepage, Research Asymmetry, Failure Blindness, Premature Decomposition, Validation Collapse) with the per-section guard mechanism that prevents each.

**Verification hint**: a hand-authored ideation artifact with `problem_frame: {}` (empty object) MUST fail schema validation against `qor/gates/schema/ideation.schema.json` with a `'affected_actors' is a required property` error. Tests at `tests/test_ideation_schema_validation.py::test_rejects_artifact_missing_required_field` enforce this.
