#!/usr/bin/env python3
"""Memledger smoke test — OSS suite (default) + opt-in AWS suite.

OSS gates (no AWS required):
  L1 — Package import (memledger + evaluators)
  L2 — Local fastembed embedding (requires [local] extra)
  L3 — OSS PostgreSQL + pgvector roundtrip
       (requires MEMLEDGER_TEST_PG_DSN, e.g.
        postgresql://postgres:postgres@localhost:5432/memledger_test)
  L4 — Eval gate: deterministic MAI (always) + RAGAS LLM-as-judge
       (requires [eval] extra and $MEMLEDGER_JUDGE_MODEL)

AWS gates (opt-in via --with-aws or --aws-only):
  A1 — Bedrock invoke (primary AWS LLM path)
  A2 — OpenSearch SigV4 backend (requires ENGRAM_TEST_OS_ENDPOINT)
  A3 — Aurora Postgres + pgvector (requires ENGRAM_TEST_AURORA_DSN)
  A4 — AgentCore Evaluations API

Usage:
  python scripts/smoke_test.py                # OSS suite only (default)
  python scripts/smoke_test.py --with-aws     # OSS + AWS suites
  python scripts/smoke_test.py --aws-only     # AWS suite only
  python scripts/smoke_test.py --mode eks     # in-pod AWS check (implies --aws-only)

Trace + eval visualization (OSS): run Arize Phoenix locally —
  docker run -p 6006:6006 -p 4317:4317 arizephoenix/phoenix:latest
  export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
  # then re-run this smoke script; traces + evals appear at http://localhost:6006
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


# ──────────────────────────────────────────────────────────────────
# Generic helpers
# ──────────────────────────────────────────────────────────────────

def _run(cmd: list[str], timeout: int = 30, env: dict | None = None) -> tuple[int, str, str]:
    """Run a command, return (returncode, stdout, stderr)."""
    run_env = os.environ.copy()
    if env:
        run_env.update(env)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=run_env)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except subprocess.TimeoutExpired:
        return 1, "", "TIMEOUT"
    except FileNotFoundError:
        return 1, "", f"Command not found: {cmd[0]}"


def _pass(name: str, details: str = "") -> dict:
    return {"name": name, "passed": True, "skipped": False, "details": details}


def _fail(name: str, details: str = "", remediation: str = "") -> dict:
    return {"name": name, "passed": False, "skipped": False, "details": details, "remediation": remediation}


def _skip(name: str, reason: str) -> dict:
    return {"name": name, "passed": False, "skipped": True, "details": reason}


# ──────────────────────────────────────────────────────────────────
# OSS gates (L1–L4)
# ──────────────────────────────────────────────────────────────────

def gate_l1_import() -> dict:
    name = "L1: Package import"
    try:
        import memledger  # noqa: F401
        from memledger.memledger import Memledger  # noqa: F401
        from evaluators import evaluate_attribution_integrity  # noqa: F401
        return _pass(name, "memledger + evaluators import OK")
    except Exception as e:
        return _fail(name, str(e), "Run: pip install -e .")


def gate_l2_local_embedding() -> dict:
    name = "L2: Local fastembed embedding"
    try:
        from memledger.embeddings import EmbeddingProvider
        from memledger.models import EmbeddingConfig
    except Exception as e:
        return _fail(name, f"import error: {e}", "Run: pip install -e .")

    try:
        provider = EmbeddingProvider(EmbeddingConfig())  # default = local
        vectors = asyncio.run(provider.embed(["hello", "world"]))
    except ImportError as e:
        return _skip(name, f"fastembed not installed ({e}). Run: pip install memledger[local]")
    except Exception as e:
        return _fail(name, f"embed failed: {e}")

    if len(vectors) == 2 and len(vectors[0]) == 384:
        return _pass(name, "2 vectors × 384 dims (BAAI/bge-small-en-v1.5)")
    return _fail(name, f"unexpected shape: {len(vectors)} x {len(vectors[0]) if vectors else 0}")


def gate_l3_pgvector() -> dict:
    name = "L3: OSS PostgreSQL + pgvector roundtrip"
    dsn = os.environ.get("MEMLEDGER_TEST_PG_DSN", "")
    if not dsn:
        return _skip(
            name,
            "MEMLEDGER_TEST_PG_DSN not set. "
            "Run: docker run -p 5432:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16; "
            "export MEMLEDGER_TEST_PG_DSN=postgresql://postgres:postgres@localhost:5432/postgres",
        )

    async def _run_gate():
        from memledger.backends.pgvector import PgVectorBackend
        from memledger.embeddings import EmbeddingProvider
        from memledger.models import EmbeddingConfig, MemoryRecord

        backend = PgVectorBackend()
        # Use the default `agent_memory` table; CREATE_TABLE_SQL currently
        # hardcodes that name (separate issue tracked in backend cleanup).
        await backend.initialize({
            "connection_string": dsn,
            "dimensions": 384,
        })
        embedder = EmbeddingProvider(EmbeddingConfig())
        vec = (await embedder.embed(["smoke test memory"]))[0]
        rec = MemoryRecord(
            id="smoke-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"),
            content="smoke test memory",
            embedding=vec,
            namespace="/smoke",
        )
        await backend.add([rec])
        hits = await backend.search_vector(vec, top_k=1, namespace="/smoke")
        await backend.close()
        return hits

    try:
        hits = asyncio.run(_run_gate())
        if hits:
            return _pass(name, f"write + search returned {len(hits)} hit(s)")
        return _fail(name, "search returned 0 hits after write")
    except Exception as e:
        return _fail(name, f"{type(e).__name__}: {str(e)[:200]}",
                     "Verify DSN, pgvector extension present, table-create perms")


def gate_l4_eval() -> dict:
    name = "L4: Eval gate (deterministic MAI + optional RAGAS)"
    details: list[str] = []

    # 4a — deterministic MAI (always available)
    try:
        from evaluators import evaluate_attribution_integrity
        sample = [
            {"id": "a", "content": "x", "created_by": "agent-a", "confidence": 0.9, "session_id": "s1"},
            {"id": "b", "content": "y", "created_by": "agent-b", "confidence": 0.85, "session_id": "s1"},
        ]
        det = evaluate_attribution_integrity("d", sample)
        details.append(f"deterministic MAI score={det.score:.3f} passed={det.passed}")
    except Exception as e:
        return _fail(name, f"deterministic MAI failed: {e}")

    # 4b — RAGAS LLM-as-judge (optional)
    judge = os.environ.get("MEMLEDGER_JUDGE_MODEL")
    if not judge:
        details.append("RAGAS: skipped (set MEMLEDGER_JUDGE_MODEL to enable)")
    else:
        try:
            from evaluators import evaluate_mai_ragas
            ragas_result = evaluate_mai_ragas([
                {"id": "a", "content": "x", "created_by": "agent-a", "confidence": 0.9, "session_id": "s1"},
            ])
            details.append(f"RAGAS judge={judge} score={ragas_result.score:.3f}")
        except ImportError as e:
            details.append(f"RAGAS: skipped ([eval] extra missing: {e})")
        except Exception as e:
            details.append(f"RAGAS: error — {type(e).__name__}: {str(e)[:120]}")

    # Phoenix hint
    if not os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"):
        details.append("Phoenix: set OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006 to view traces+evals")

    return _pass(name, " | ".join(details))


# ──────────────────────────────────────────────────────────────────
# AWS gates (A1–A4)
# ──────────────────────────────────────────────────────────────────

def gate_a1_bedrock(mode: str = "local") -> dict:
    name = "A1: Bedrock invoke"
    if mode == "eks":
        pod_cmd = [
            "kubectl", "exec", "-n", "kagent",
            "deployment/eks-ops-agent", "--",
            "python", "-c",
            "import boto3,json,os; "
            "c=boto3.client('bedrock-runtime',region_name=os.getenv('AWS_REGION','us-west-2')); "
            "r=c.invoke_model(modelId='us.anthropic.claude-sonnet-4-20250514-v1:0',"
            "body=json.dumps({'anthropic_version':'bedrock-2023-05-31','max_tokens':20,"
            "'messages':[{'role':'user','content':'Say OK'}]})); "
            "b=json.loads(r['body'].read()); "
            "print('OK:',b['content'][0]['text'][:30])"
        ]
        rc, out, err = _run(pod_cmd, timeout=60)
        if rc == 0 and "OK:" in out:
            return _pass(name, f"Bedrock from pod: {out}")
        return _fail(name, f"pod exec failed: {err[:200]}")

    try:
        import boto3
        client = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION", "us-west-2"))
        resp = client.invoke_model(
            modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 20,
                "messages": [{"role": "user", "content": "Say OK"}],
            }),
        )
        body = json.loads(resp["body"].read())
        return _pass(name, f"Bedrock response: '{body['content'][0]['text'][:30]}'")
    except ImportError:
        return _skip(name, "boto3 not installed. Run: pip install memledger[aws]")
    except Exception as e:
        return _fail(name, f"Bedrock invoke failed: {e}",
                     "Check AWS credentials + bedrock:InvokeModel IAM permission")


def gate_a2_opensearch() -> dict:
    name = "A2: OpenSearch SigV4 backend"
    endpoint = os.environ.get("ENGRAM_TEST_OS_ENDPOINT", "")
    if not endpoint:
        return _skip(name, "ENGRAM_TEST_OS_ENDPOINT not set")

    async def _run_gate():
        from memledger.backends.opensearch import OpenSearchBackend
        backend = OpenSearchBackend()
        await backend.initialize({
            "hosts": [endpoint],
            "auth_type": "aws_sigv4",
            "index_name": "memledger_smoke",
            "dimensions": 1024,
            "verify_certs": True,
        })
        return True

    try:
        asyncio.run(_run_gate())
        return _pass(name, f"OpenSearch init OK at {endpoint[:40]}...")
    except ImportError as e:
        return _skip(name, f"opensearch-py/boto3 missing: {e}. pip install memledger[aws]")
    except Exception as e:
        return _fail(name, f"{type(e).__name__}: {str(e)[:200]}")


def gate_a3_aurora() -> dict:
    name = "A3: Aurora Postgres + pgvector"
    dsn = os.environ.get("ENGRAM_TEST_AURORA_DSN", "")
    if not dsn:
        return _skip(name, "ENGRAM_TEST_AURORA_DSN not set")

    async def _run_gate():
        from memledger.backends.pgvector import PgVectorBackend
        backend = PgVectorBackend()
        await backend.initialize({
            "connection_string": dsn,
            "dimensions": 1024,
            "table_name": "memledger_smoke_aurora",
        })
        await backend.close()
        return True

    try:
        asyncio.run(_run_gate())
        return _pass(name, "Aurora pgvector init OK")
    except Exception as e:
        return _fail(name, f"{type(e).__name__}: {str(e)[:200]}",
                     "Confirm Aurora endpoint reachable + pgvector extension installed")


def gate_a4_agentcore() -> dict:
    name = "A4: AgentCore Evaluations"
    try:
        import bedrock_agentcore  # noqa: F401
        sdk_version = getattr(bedrock_agentcore, "__version__", "unknown")
    except ImportError:
        return _skip(name, "bedrock-agentcore SDK not installed. pip install memledger[aws]")

    rc, out, err = _run(
        ["agentcore", "eval", "evaluator", "list"],
        timeout=30,
        env={"AWS_DEFAULT_REGION": os.getenv("AWS_REGION", "us-west-2")},
    )
    cli_ok = rc == 0 and "Builtin" in out
    builtin_count = out.count("Builtin.") if cli_ok else 0

    if cli_ok:
        return _pass(name, f"SDK v{sdk_version}, {builtin_count} built-in evaluators")
    return _fail(name, f"SDK v{sdk_version} OK but CLI failed: {err[:120]}",
                 "Install bedrock-agentcore-starter-toolkit and configure AWS creds")


# ──────────────────────────────────────────────────────────────────
# Orchestration
# ──────────────────────────────────────────────────────────────────

def _print_gate(g: dict) -> None:
    if g.get("skipped"):
        status = "○ SKIP"
    elif g["passed"]:
        status = "✓ PASS"
    else:
        status = "✗ FAIL"
    print(f"  {status}: {g['name']}")
    if g.get("details"):
        print(f"         {g['details']}")
    if not g["passed"] and not g.get("skipped") and g.get("remediation"):
        print(f"         ↳ {g['remediation']}")


def run_oss_suite() -> list[dict]:
    print("\n▸ OSS suite")
    gates = [gate_l1_import(), gate_l2_local_embedding(), gate_l3_pgvector(), gate_l4_eval()]
    for g in gates:
        _print_gate(g)
    return gates


def run_aws_suite(mode: str) -> list[dict]:
    print("\n▸ AWS suite")
    gates = [gate_a1_bedrock(mode), gate_a2_opensearch(), gate_a3_aurora(), gate_a4_agentcore()]
    for g in gates:
        _print_gate(g)
    return gates


def _verdict(gates: list[dict], suite: str) -> str:
    active = [g for g in gates if not g.get("skipped")]
    if not active:
        return f"{suite}_NO_GATES_RAN"
    if all(g["passed"] for g in active):
        return f"{suite}_READY"
    return f"{suite}_PARTIAL"


def run_smoke_test(mode: str, run_oss: bool, run_aws: bool) -> dict:
    header_mode = []
    if run_oss:
        header_mode.append("OSS")
    if run_aws:
        header_mode.append(f"AWS({mode})")
    header = " + ".join(header_mode) or "NONE"

    print(f"\n{'='*64}")
    print(f"  MEMLEDGER SMOKE TEST — {header}")
    print(f"  {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"{'='*64}")

    results: dict = {"timestamp": datetime.now(timezone.utc).isoformat(), "verdicts": {}}

    if run_oss:
        oss_gates = run_oss_suite()
        results["oss_gates"] = oss_gates
        results["verdicts"]["oss"] = _verdict(oss_gates, "OSS")

    if run_aws:
        aws_gates = run_aws_suite(mode)
        results["aws_gates"] = aws_gates
        results["verdicts"]["aws"] = _verdict(aws_gates, "AWS")

    print(f"\n{'='*64}")
    for suite, v in results["verdicts"].items():
        print(f"  {suite.upper()} VERDICT: {v}")
    print(f"{'='*64}\n")

    out_path = Path(__file__).parent.parent / "smoke_test_results.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"Results: {out_path}")
    return results


def _parse_args(argv: list[str]) -> tuple[str, bool, bool]:
    mode = "local"
    with_aws = False
    aws_only = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--mode" and i + 1 < len(argv):
            mode = argv[i + 1]
            i += 2
            continue
        if a == "--with-aws":
            with_aws = True
        elif a == "--aws-only":
            aws_only = True
        i += 1
    if mode == "eks":
        aws_only = True
    run_oss = not aws_only
    run_aws = aws_only or with_aws
    return mode, run_oss, run_aws


if __name__ == "__main__":
    mode, run_oss, run_aws = _parse_args(sys.argv[1:])
    run_smoke_test(mode, run_oss, run_aws)
