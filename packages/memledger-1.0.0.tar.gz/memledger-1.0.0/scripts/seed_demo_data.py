#!/usr/bin/env python3
"""Seed Aurora with linked memories for the demo trust graph.

Creates a realistic provenance chain:
  research-agent (low conf) → triage-agent (escalation) → ops-agent (diagnosis)
  → ops-agent (fix applied, supersedes research) → compliance-agent (runbook)

Run via kubectl exec on EKS:
    kubectl exec -n kagent deployment/eks-ops-agent -- python3 -c "$(cat scripts/seed_demo_data.py)"

Or locally if MEMLEDGER_PG_DSN is set.
"""

import asyncio
import os
import sys


async def seed():
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig

    dsn = os.environ.get("MEMLEDGER_PG_DSN", "") or os.environ.get("ENGRAM_PG_URL", "")
    if not dsn:
        print("Set MEMLEDGER_PG_DSN")
        sys.exit(1)

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=dsn,
        embedding_config=EmbeddingConfig(
            provider="bedrock", model="amazon.titan-embed-text-v2:0", dimensions=1024,
        ),
    )

    print("Seeding demo data...")

    # 1. Research-agent: low-confidence memory from unverified source
    id_bad = await ml.add(
        content="max_connections should be set to 8 for PostgreSQL (from outdated 2019 runbook, not load-tested)",
        record_type=RecordType.SEMANTIC,
        namespace="/ops/incidents/payment-svc",
        created_by="research-agent",
        confidence=0.25,
        importance=0.25,
        session_id="demo-seed",
        triggered_by="web-scrape:random-blog-2024",
        metadata={"source": "outdated-runbook-2019", "verified": False},
    )
    print(f"  1. research-agent bad fact [{id_bad[:8]}] conf=0.25")

    # 2. Triage-agent: escalation derived from research finding
    id_triage = await ml.add(
        content="Alert: payment-service may have connection pool misconfiguration based on research finding. Needs ops review.",
        record_type=RecordType.EPISODIC,
        namespace="/triage/alerts/payment-svc",
        created_by="triage-agent",
        confidence=0.45,
        importance=0.45,
        session_id="demo-seed",
        derived_from=[id_bad],
        triggered_by="alert:payment-svc-oom",
    )
    print(f"  2. triage-agent escalation [{id_triage[:8]}] conf=0.45, derived from [{id_bad[:8]}]")

    # 3. Ops-agent: investigates, finds different root cause
    id_diagnosis = await ml.add(
        content="Payment-service OOM caused by HikariCP connection pool leak. maxPoolSize was 10 (too low). Root cause: connections not returned to pool under load.",
        record_type=RecordType.SEMANTIC,
        namespace="/ops/incidents/payment-svc",
        created_by="ops-agent",
        confidence=0.85,
        importance=0.85,
        session_id="demo-seed",
        derived_from=[id_triage],
        supersedes=id_bad,
        workflow_id="incident-response-001",
    )
    print(f"  3. ops-agent diagnosis [{id_diagnosis[:8]}] conf=0.85, supersedes [{id_bad[:8]}]")

    # 4. Ops-agent: applies fix, records outcome
    id_fix = await ml.add(
        content="Applied fix: set HikariCP maxPoolSize=50 on payment-service. Verified: no OOM kills after 24h observation.",
        record_type=RecordType.EPISODIC,
        namespace="/ops/incidents/payment-svc",
        created_by="ops-agent",
        confidence=0.90,
        importance=0.90,
        session_id="demo-seed",
        derived_from=[id_diagnosis],
        workflow_id="incident-response-001",
        outcome="Fix verified — no OOM kills in 24h",
    )
    print(f"  4. ops-agent fix [{id_fix[:8]}] conf=0.90, derived from [{id_diagnosis[:8]}]")

    # Record outcome on the fix
    await ml.record_outcome(record_id=id_fix, success=True, description="maxPoolSize=50 fix verified")
    print(f"     outcome recorded: success=True")

    # 5. Compliance-agent: runbook derived from the fix
    id_runbook = await ml.add(
        content="Runbook: HikariCP connection pool fix. 1) Check maxPoolSize in config 2) Set to 50 3) kubectl rollout restart 4) Monitor for 24h 5) Verify no OOM kills",
        record_type=RecordType.PROCEDURAL,
        namespace="/compliance/runbooks",
        created_by="compliance-agent",
        confidence=0.88,
        importance=0.88,
        session_id="demo-seed",
        derived_from=[id_fix],
        steps=[
            "Check maxPoolSize in payment-service config",
            "Set maxPoolSize=50",
            "kubectl rollout restart deployment/payment-service",
            "Monitor pod health for 24h",
            "Verify no OOM kills in kubectl events",
        ],
    )
    print(f"  5. compliance-agent runbook [{id_runbook[:8]}] conf=0.88, derived from [{id_fix[:8]}]")

    # 6. Another low-conf memory (for contrast in the graph)
    id_bad2 = await ml.add(
        content="PostgreSQL max_connections should be 200 for high-traffic services (from StackOverflow answer, 2019)",
        record_type=RecordType.SEMANTIC,
        namespace="/shared/knowledge",
        created_by="research-agent",
        confidence=0.30,
        importance=0.30,
        session_id="demo-seed",
        metadata={"source": "stackoverflow", "year": 2019, "verified": False},
    )
    print(f"  6. research-agent second bad fact [{id_bad2[:8]}] conf=0.30 (isolated, no edges)")

    await ml.close()

    print(f"\nSeeded 6 memories with provenance chain:")
    print(f"  research(0.25) → triage(0.45) → ops-diagnosis(0.85) → ops-fix(0.90) → compliance-runbook(0.88)")
    print(f"  + isolated low-conf memory (0.30)")
    print(f"  + supersession: ops-diagnosis supersedes research bad fact")
    print(f"\nTrust graph should show:")
    print(f"  - Red node (research, 0.25) with dashed supersedes edge")
    print(f"  - Yellow node (triage, 0.45) with derived edge")
    print(f"  - Green nodes (ops + compliance, 0.85-0.90) with derived chain")
    print(f"  - Isolated red node (0.30, no edges)")


if __name__ == "__main__":
    asyncio.run(seed())
