#!/usr/bin/env bash
# OSS-path CLI smoke. Exercises every public memledger CLI command against
# a running pgvector + Phoenix stack. No LLM required for init/add/search/
# get/status; `eval` runs only when MEMLEDGER_JUDGE_MODEL is set to a
# reachable provider.
#
# Usage:
#   docker compose up -d   # in examples/multi-agent/
#   ./scripts/oss_cli_smoke.sh
#
# Exits 0 on success, non-zero on the first failed assertion.

set -euo pipefail

DSN="${MEMLEDGER_PG_DSN:-postgresql://postgres:postgres@localhost:5433/memledger}"
SUFFIX="$(uuidgen | tr '[:upper:]' '[:lower:]' | cut -c1-8)"
NS="/test/cli-smoke-$SUFFIX"
SESSION_ID="cli-smoke-$SUFFIX"
TMPDIR_X=$(mktemp -d)
trap 'rm -rf "$TMPDIR_X"' EXIT

export MEMLEDGER_PG_DSN="$DSN"

say()  { printf "\n\033[1;36m== %s ==\033[0m\n" "$1"; }
ok()   { printf "  \033[1;32mok\033[0m: %s\n" "$1"; }
fail() { printf "  \033[1;31mFAIL\033[0m: %s\n" "$1"; exit 1; }

# --- init -------------------------------------------------------------------
say "memledger init"
cd "$TMPDIR_X"
memledger init > init.log
test -f memledger.yaml || fail "init did not produce memledger.yaml"
ok "init wrote memledger.yaml"

# --- add --------------------------------------------------------------------
say "memledger add"
ADD_OUT=$(memledger add "HikariCP maxPoolSize=50 fixes payment-service OOM" \
  --namespace "$NS" --agent-id ops --confidence 0.9 --session-id "$SESSION_ID")
echo "$ADD_OUT"
ID1=$(echo "$ADD_OUT" | grep -oE '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' | head -1)
test -n "$ID1" || fail "add did not print a memory id"
ok "add returned id=$ID1"

memledger add "connection pool exhaustion triggers JVM heap pressure" \
  --namespace "$NS" --agent-id ops --confidence 0.85 --session-id "$SESSION_ID" > /dev/null
memledger add "Recipe: chocolate chip cookies, 350F, 12 min" \
  --namespace "$NS" --agent-id cook --confidence 0.5 --session-id "$SESSION_ID" > /dev/null
ok "added 2 more records"

# --- search -----------------------------------------------------------------
say "memledger search"
SEARCH_OUT=$(memledger search "connection pool fix" --namespace "$NS" --confidence-min 0.6)
echo "$SEARCH_OUT" | head -20
echo "$SEARCH_OUT" | grep -qi "hikari\|pool" || fail "top result should mention pool/hikari"
ok "search returned ops-related top hit"

# --- get --chain ------------------------------------------------------------
say "memledger get --chain"
GET_OUT=$(memledger get "$ID1" --chain)
echo "$GET_OUT" | head -20
echo "$GET_OUT" | grep -q "$ID1" || fail "get did not echo the id"
ok "get rendered record + chain"

# --- status -----------------------------------------------------------------
say "memledger status"
STATUS_OUT=$(memledger status)
echo "$STATUS_OUT" | head -10
echo "$STATUS_OUT" | grep -qiE "memories|postgres|component|status" || fail "status output missing expected fields"
ok "status returned health info"

# --- eval (skipped without judge model) ------------------------------------
say "memledger eval"
if [ -n "${MEMLEDGER_JUDGE_MODEL:-}" ]; then
  EVAL_OUT=$(memledger eval "$SESSION_ID" 2>&1 || true)
  echo "$EVAL_OUT" | head -30
  echo "$EVAL_OUT" | grep -qiE "score|attribution|mai" || fail "eval output missing score"
  ok "eval ran against MEMLEDGER_JUDGE_MODEL=$MEMLEDGER_JUDGE_MODEL"
else
  printf "  \033[1;33mskip\033[0m: MEMLEDGER_JUDGE_MODEL not set; set to ollama/llama3.1:8b or similar to exercise eval\n"
fi

printf "\n\033[1;32mOSS CLI smoke: PASS\033[0m\n"
