# Contributing to memledger

Thanks for your interest. This repo holds the Python SDK, MCP server, and Helm chart. Until v1.0.0 the API surface may shift — open an issue before a large PR so we can align.

By participating you agree to the [Code of Conduct](CODE_OF_CONDUCT.md). For security issues see [SECURITY.md](SECURITY.md) — do not file a public issue.

## Development setup

memledger targets **Python 3.11+** with hatchling as the build backend.

```bash
git clone https://github.com/memledger-ai/memledger-core
cd memledger-core
python -m venv .venv && source .venv/bin/activate
pip install --pre -e '.[dev,local,pgvector,eval,mcp]'
docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16
pytest
```

AWS-gated tests skip by default; export `AWS_REGION` plus valid credentials to opt in.

## Workflow

- Branch off `main` (`feat-...`, `fix-...`, `docs-...`).
- One logical change per PR; include a Test plan section.
- Public SDK surface changes (anything exported from `memledger.__init__`) must land in `CHANGELOG.md`.
- Type hints on public functions; `ruff` + `mypy` must pass.
- Never commit secrets, account IDs, or `.env` files.

## Telemetry

New SDK operations that emit OTEL spans must follow `src/memledger/telemetry/instrument.py`: set `openinference.span.kind`, propagate `session.id`, and record `memledger.*` trust attributes so Phoenix categorizes them.

## Releases

Maintainers cut releases via the GitHub Releases UI, which triggers `.github/workflows/release.yml` to publish via PyPI trusted publishing.

Open a [Discussion](https://github.com/memledger-ai/memledger-core/discussions) for design questions, or an issue for anything actionable.
