"""Tests for batch APIs — lifecycle management and consolidation workflows."""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import EmbeddingConfig, MemoryStatus

CONN_STRING = os.environ.get(
    "ENGRAM_TEST_PG_DSN",
    "postgresql://localhost:5432/memledger_test",
)

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="local",
    model="BAAI/bge-small-en-v1.5",
    dimensions=384,
)

pytestmark = pytest.mark.asyncio


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    e = await Memledger.create(
        backend_name="pgvector",
        connection_string=CONN_STRING,
        embedding_config=EMBEDDING_CONFIG,
    )
    yield e
    await e.close()


async def test_get_by_session(memledger: Memledger):
    """Retrieve all memories from a specific session."""
    ns = _unique_ns()
    session_id = f"sess-{uuid.uuid4().hex[:8]}"

    await memledger.add(content="Memory 1 in session", namespace=ns, session_id=session_id)
    await memledger.add(content="Memory 2 in session", namespace=ns, session_id=session_id)
    await memledger.add(content="Memory in different session", namespace=ns, session_id="other-session")

    results = await memledger.get_by_session(session_id)
    assert len(results) == 2
    assert all(r.session_id == session_id for r in results)


async def test_get_stale(memledger: Memledger):
    """Find memories not accessed recently."""
    ns = _unique_ns()

    # Store a memory — it will have no last_accessed_at (never searched)
    record_id = await memledger.add(content="Stale memory", namespace=ns)

    # Should appear as stale (never accessed, 0 days threshold)
    stale = await memledger.get_stale(days=0, namespace=ns)
    assert any(r.id == record_id for r in stale)


async def test_bulk_update_status(memledger: Memledger):
    """Batch status transition."""
    ns = _unique_ns()

    id1 = await memledger.add(content="Expire me 1", namespace=ns)
    id2 = await memledger.add(content="Expire me 2", namespace=ns)
    id3 = await memledger.add(content="Keep me active", namespace=ns)

    count = await memledger.bulk_update_status([id1, id2], "expired")
    assert count == 2

    # Expired memories should not appear in search
    results = await memledger.search(query="expire", namespace=ns, top_k=10)
    result_ids = [r.id for r in results.records]
    assert id1 not in result_ids
    assert id2 not in result_ids
    assert id3 in result_ids


async def test_bulk_archive(memledger: Memledger):
    """Batch archival (soft delete)."""
    ns = _unique_ns()

    id1 = await memledger.add(content="Archive me", namespace=ns)

    count = await memledger.bulk_archive([id1])
    assert count == 1

    # Archived record still exists via get()
    record = await memledger.get(id1)
    assert record is not None
    assert record.status == MemoryStatus.ARCHIVED

    # But not in search results
    results = await memledger.search(query="archive", namespace=ns, top_k=5)
    assert all(r.id != id1 for r in results.records)


async def test_get_by_status(memledger: Memledger):
    """Retrieve memories by lifecycle status."""
    ns = _unique_ns()

    id1 = await memledger.add(content="Active memory", namespace=ns)
    id2 = await memledger.add(content="Will be deprecated", namespace=ns)

    await memledger.bulk_update_status([id2], "deprecated")

    active = await memledger.get_by_status("active", namespace=ns)
    assert any(r.id == id1 for r in active)
    assert not any(r.id == id2 for r in active)

    deprecated = await memledger.get_by_status("deprecated", namespace=ns)
    assert any(r.id == id2 for r in deprecated)


async def test_supersession_flow(memledger: Memledger):
    """Full supersession workflow: new memory deprecates old."""
    ns = _unique_ns()

    old_id = await memledger.add(
        content="max_connections should be 50",
        namespace=ns,
    )

    new_id = await memledger.add(
        content="max_connections should be 200 (updated after load testing)",
        namespace=ns,
        supersedes=old_id,
    )

    # Old memory should be deprecated
    old = await memledger.get(old_id)
    assert old.status == MemoryStatus.DEPRECATED

    # New memory should be active with supersedes link
    new = await memledger.get(new_id)
    assert new.status == MemoryStatus.ACTIVE
    assert new.supersedes == old_id

    # Search should return only the new memory
    results = await memledger.search(query="max_connections", namespace=ns, top_k=5)
    result_ids = [r.id for r in results.records]
    assert new_id in result_ids
    assert old_id not in result_ids


async def test_lifecycle_workflow(memledger: Memledger):
    """Simulate the full lifecycle: active → expired → archived."""
    ns = _unique_ns()

    record_id = await memledger.add(content="Lifecycle test", namespace=ns)

    # Step 1: Active
    record = await memledger.get(record_id)
    assert record.status == MemoryStatus.ACTIVE

    # Step 2: Expire
    await memledger.bulk_update_status([record_id], "expired")
    record = await memledger.get(record_id)
    assert record.status == MemoryStatus.EXPIRED

    # Step 3: Archive
    await memledger.bulk_archive([record_id])
    record = await memledger.get(record_id)
    assert record.status == MemoryStatus.ARCHIVED

    # Archived memory not in search
    results = await memledger.search(query="lifecycle", namespace=ns, top_k=5)
    assert all(r.id != record_id for r in results.records)
