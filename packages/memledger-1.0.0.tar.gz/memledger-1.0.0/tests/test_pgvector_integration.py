"""Integration test: add → search end-to-end against real Postgres+pgvector.

Works with:
  - Local Homebrew Postgres: pytest tests/test_pgvector_integration.py -v
  - Docker compose (port 5433): ENGRAM_TEST_PG_DSN=postgresql://memledger:memledger@localhost:5433/memledger pytest ...

Uses Bedrock Titan V2 for embeddings (requires AWS credentials).
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import (
    EmbeddingConfig,
    EpisodicRecord,
    ProceduralRecord,
    RecordType,
    SemanticRecord,
)

# Default: local Homebrew Postgres (current user, no password, unix socket)
# Override with ENGRAM_TEST_PG_DSN for Docker or remote instances
CONN_STRING = os.environ.get(
    "ENGRAM_TEST_PG_DSN",
    "postgresql://localhost:5432/memledger_test",
)

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="local",
    model="BAAI/bge-small-en-v1.5",
    dimensions=384,
)

pytestmark = pytest.mark.asyncio


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    e = await Memledger.create(
        backend_name="pgvector",
        connection_string=CONN_STRING,
        embedding_config=EMBEDDING_CONFIG,
    )
    yield e
    await e.close()


# ── Core CRUD ────────────────────────────────────────────────────


async def test_add_and_search(memledger: Memledger):
    """Core flow: store a memory, then find it via semantic search."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="OOM kills in payment-service caused by connection pool leak. "
        "Fix: set max_connections=50 in the database config.",
        namespace=ns,
        metadata={"severity": "P1", "resolved": True},
    )
    assert record_id

    results = await memledger.search(
        query="payment service memory issues",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    top = results.records[0]
    assert top.id == record_id
    assert "payment-service" in top.content
    assert top.score is not None and top.score > 0.4


async def test_add_multiple_and_rank(memledger: Memledger):
    """Verify that the most relevant memory ranks first."""
    ns = _unique_ns()

    await memledger.add(
        content="Redis cache TTL set to 300 seconds for session tokens.",
        namespace=ns,
    )
    target_id = await memledger.add(
        content="Kubernetes pod CrashLoopBackOff due to missing config map mount.",
        namespace=ns,
    )
    await memledger.add(
        content="Grafana dashboard for API latency is at grafana.internal/d/api-latency.",
        namespace=ns,
    )

    results = await memledger.search(
        query="pod crashing because of missing configmap",
        namespace=ns,
        top_k=3,
    )
    assert results.records[0].id == target_id


async def test_namespace_isolation(memledger: Memledger):
    """Memories in different namespaces don't leak into each other."""
    ns_a = _unique_ns()
    ns_b = _unique_ns()

    await memledger.add(content="Secret fact only in namespace A", namespace=ns_a)
    await memledger.add(content="Different fact in namespace B", namespace=ns_b)

    results = await memledger.search(query="secret fact", namespace=ns_a, top_k=5)
    assert all(r.namespace.startswith(ns_a) for r in results.records)


async def test_update_and_delete(memledger: Memledger):
    """CRUD: update metadata, then delete the record."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Test record for update/delete",
        namespace=ns,
        metadata={"status": "new"},
    )

    updated = await memledger.update(record_id, metadata={"status": "reviewed"})
    assert updated is True

    record = await memledger.get(record_id)
    assert record is not None
    assert record.metadata["status"] == "reviewed"

    deleted = await memledger.delete(record_id)
    assert deleted is True

    # Soft delete: record still exists but status is archived
    archived = await memledger.get(record_id)
    assert archived is not None
    assert archived.status.value == "archived"

    # Archived records should NOT appear in search results
    results = await memledger.search(query="update/delete", namespace=ns, top_k=5)
    assert all(r.id != record_id for r in results.records)


async def test_health_check(memledger: Memledger):
    assert await memledger.health() is True


# ── Typed Records ────────────────────────────────────────────────


async def test_semantic_record(memledger: Memledger):
    """Store and retrieve a SemanticRecord with typed fields."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="HikariCP default max pool size is 10 connections.",
        record_type=RecordType.SEMANTIC,
        namespace=ns,
        source="HikariCP documentation",
        confidence=0.95,
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, SemanticRecord)
    assert record.record_type == RecordType.SEMANTIC
    assert record.source == "HikariCP documentation"
    assert record.confidence == 0.95


async def test_episodic_record(memledger: Memledger):
    """Store and retrieve an EpisodicRecord with typed fields."""
    ns = _unique_ns()
    from datetime import datetime, timezone

    event_time = datetime(2026, 3, 15, 3, 0, 0, tzinfo=timezone.utc)

    record_id = await memledger.add(
        content="Payment service pod crashed due to OOM at 3am. "
        "Root cause: unbounded connection pool. Restarted after fix.",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        event_time=event_time,
        duration_ms=45000,
        outcome="Resolved by setting max_connections=50",
        actors=["sre-agent", "platform-agent"],
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, EpisodicRecord)
    assert record.record_type == RecordType.EPISODIC
    assert record.outcome == "Resolved by setting max_connections=50"
    assert record.duration_ms == 45000
    assert "sre-agent" in record.actors


async def test_procedural_record(memledger: Memledger):
    """Store and retrieve a ProceduralRecord with typed fields."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="How to fix OOM kills in Java services on Kubernetes.",
        record_type=RecordType.PROCEDURAL,
        namespace=ns,
        steps=[
            "Check pod memory limits with kubectl describe pod",
            "Inspect heap usage via JVM metrics in Grafana",
            "Identify leak source (connection pool, cache, etc.)",
            "Apply fix and restart pod",
            "Monitor for 30 minutes to confirm resolution",
        ],
        preconditions=["kubectl access to cluster", "Grafana dashboard available"],
        tools_required=["kubectl", "grafana", "jstack"],
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, ProceduralRecord)
    assert record.record_type == RecordType.PROCEDURAL
    assert len(record.steps) == 5
    assert "kubectl" in record.tools_required
    assert "kubectl access to cluster" in record.preconditions


async def test_add_record_direct(memledger: Memledger):
    """Test add_record() with a pre-built typed record object."""
    ns = _unique_ns()

    record = ProceduralRecord(
        content="Rollback a Helm release to previous revision.",
        namespace=ns,
        steps=["helm history <release>", "helm rollback <release> <revision>"],
        tools_required=["helm"],
    )

    record_id = await memledger.add_record(record)
    assert record_id

    retrieved = await memledger.get(record_id)
    assert isinstance(retrieved, ProceduralRecord)
    assert retrieved.steps == ["helm history <release>", "helm rollback <release> <revision>"]


async def test_filter_by_record_type(memledger: Memledger):
    """Verify search can filter by record_type."""
    ns = _unique_ns()

    await memledger.add(
        content="Fact: Postgres max_connections default is 100",
        record_type=RecordType.SEMANTIC,
        namespace=ns,
    )
    episodic_id = await memledger.add(
        content="On March 20 we hit Postgres max_connections limit during load test",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Increased to 200",
    )

    # Search only for episodic records
    results = await memledger.search(
        query="postgres connection limit",
        namespace=ns,
        record_type=RecordType.EPISODIC,
    )
    assert len(results.records) >= 1
    assert all(r.record_type == RecordType.EPISODIC for r in results.records)


# ── Context Manager ──────────────────────────────────────────────


async def test_context_manager():
    """Test async context manager usage."""
    async with await Memledger.create(
        backend_name="pgvector",
        connection_string=CONN_STRING,
        embedding_config=EMBEDDING_CONFIG,
    ) as eng:
        ns = _unique_ns()
        rid = await eng.add(content="Context manager test", namespace=ns)
        assert rid
        result = await eng.search(query="context manager", namespace=ns, top_k=1)
        assert len(result.records) == 1
