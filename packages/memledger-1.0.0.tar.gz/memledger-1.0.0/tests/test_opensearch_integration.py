"""Integration test: add → search end-to-end against AWS OpenSearch.

Requires:
  - ENGRAM_TEST_OS_ENDPOINT env var (e.g. https://search-memledger-dev-xxx.us-west-2.es.amazonaws.com)
  - AWS credentials configured (for SigV4 auth + Bedrock embeddings)

Run:
  export ENGRAM_TEST_OS_ENDPOINT=$(./scripts/opensearch-create.sh endpoint)
  pytest tests/test_opensearch_integration.py -v

Skip:
  Tests are skipped automatically if ENGRAM_TEST_OS_ENDPOINT is not set.
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import (
    EmbeddingConfig,
    EpisodicRecord,
    ProceduralRecord,
    RecordType,
    SemanticRecord,
)

OS_ENDPOINT = os.environ.get("ENGRAM_TEST_OS_ENDPOINT", "")

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="bedrock",
    model="amazon.titan-embed-text-v2:0",
    dimensions=1024,
)

pytestmark = [
    pytest.mark.aws,
    pytest.mark.asyncio,
    pytest.mark.skipif(not OS_ENDPOINT, reason="ENGRAM_TEST_OS_ENDPOINT not set"),
]


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


def _unique_index() -> str:
    return f"memledger-test-{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    index_name = _unique_index()
    e = await Memledger.create(
        backend_name="opensearch",
        backend_config={
            "hosts": [OS_ENDPOINT],
            "auth_type": "aws_sigv4",
            "region": os.environ.get("AWS_REGION", "us-west-2"),
            "index_name": index_name,
            "dimensions": 1024,
            "verify_certs": True,
        },
        embedding_config=EMBEDDING_CONFIG,
    )
    yield e
    # Cleanup: delete the test index
    try:
        e._backend._client.indices.delete(index=index_name)
    except Exception:
        pass
    await e.close()


# ── Core CRUD ────────────────────────────────────────────────────


async def test_add_and_search(memledger: Memledger):
    """Core flow: store a memory, then find it via vector search."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="OOM kills in payment-service caused by connection pool leak. "
        "Fix: set max_connections=50 in the database config.",
        namespace=ns,
        metadata={"severity": "P1", "resolved": True},
    )
    assert record_id

    results = await memledger.search(
        query="payment service memory issues",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    top = results.records[0]
    assert top.id == record_id
    assert "payment-service" in top.content


async def test_add_multiple_and_rank(memledger: Memledger):
    """Verify that the most relevant memory ranks first."""
    ns = _unique_ns()

    await memledger.add(
        content="Redis cache TTL set to 300 seconds for session tokens.",
        namespace=ns,
    )
    target_id = await memledger.add(
        content="Kubernetes pod CrashLoopBackOff due to missing config map mount.",
        namespace=ns,
    )
    await memledger.add(
        content="Grafana dashboard for API latency is at grafana.internal/d/api-latency.",
        namespace=ns,
    )

    results = await memledger.search(
        query="pod crashing because of missing configmap",
        namespace=ns,
        top_k=3,
    )
    assert results.records[0].id == target_id


async def test_namespace_isolation(memledger: Memledger):
    """Memories in different namespaces don't leak into each other."""
    ns_a = _unique_ns()
    ns_b = _unique_ns()

    await memledger.add(content="Secret fact only in namespace A", namespace=ns_a)
    await memledger.add(content="Different fact in namespace B", namespace=ns_b)

    results = await memledger.search(query="secret fact", namespace=ns_a, top_k=5)
    assert all(r.namespace.startswith(ns_a) for r in results.records)


async def test_update_and_delete(memledger: Memledger):
    """CRUD: update metadata, then delete the record."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Test record for update/delete",
        namespace=ns,
        metadata={"status": "new"},
    )

    updated = await memledger.update(record_id, metadata={"status": "reviewed"})
    assert updated is True

    record = await memledger.get(record_id)
    assert record is not None

    deleted = await memledger.delete(record_id)
    assert deleted is True

    # Soft delete: record still exists but status is archived
    archived = await memledger.get(record_id)
    assert archived is not None
    assert archived.status.value == "archived"


async def test_health_check(memledger: Memledger):
    assert await memledger.health() is True


# ── Typed Records ────────────────────────────────────────────────


async def test_semantic_record(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(
        content="HikariCP default max pool size is 10 connections.",
        record_type=RecordType.SEMANTIC,
        namespace=ns,
        source="HikariCP documentation",
        confidence=0.95,
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, SemanticRecord)
    assert record.source == "HikariCP documentation"


async def test_episodic_record(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Payment service pod crashed due to OOM at 3am.",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Resolved by setting max_connections=50",
        actors=["sre-agent"],
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, EpisodicRecord)
    assert record.outcome == "Resolved by setting max_connections=50"


async def test_procedural_record(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(
        content="How to fix OOM kills in Java services.",
        record_type=RecordType.PROCEDURAL,
        namespace=ns,
        steps=["Check pod limits", "Inspect heap", "Apply fix"],
        tools_required=["kubectl", "grafana"],
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert isinstance(record, ProceduralRecord)
    assert len(record.steps) == 3
    assert "kubectl" in record.tools_required


# ── Hybrid Search ────────────────────────────────────────────────


async def test_hybrid_search(memledger: Memledger):
    """Test RRF hybrid search (vector + BM25)."""
    ns = _unique_ns()

    await memledger.add(
        content="Redis cache TTL configuration for session management.",
        namespace=ns,
    )
    target_id = await memledger.add(
        content="Kubernetes CrashLoopBackOff error caused by missing ConfigMap volume mount in deployment spec.",
        namespace=ns,
    )
    await memledger.add(
        content="Grafana alerting rules for CPU utilization.",
        namespace=ns,
    )

    results = await memledger.search_hybrid(
        query="pod CrashLoopBackOff configmap",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    assert results.records[0].id == target_id


async def test_filter_by_record_type(memledger: Memledger):
    ns = _unique_ns()

    await memledger.add(
        content="Fact: Postgres max_connections default is 100",
        record_type=RecordType.SEMANTIC,
        namespace=ns,
    )
    await memledger.add(
        content="On March 20 we hit Postgres max_connections limit during load test",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Increased to 200",
    )

    results = await memledger.search(
        query="postgres connection limit",
        namespace=ns,
        record_type=RecordType.EPISODIC,
    )
    assert len(results.records) >= 1
    assert all(r.record_type == RecordType.EPISODIC for r in results.records)
