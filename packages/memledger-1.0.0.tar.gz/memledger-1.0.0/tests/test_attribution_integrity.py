"""Unit tests for the deterministic MAI evaluator (Tier 1).

These tests require no extras — they run on a base `pip install memledger`
install with no AWS, no LiteLLM, no RAGAS. They must always be green.
"""

from __future__ import annotations

from evaluators import (
    AttributionIntegrityResult,
    evaluate_attribution_integrity,
)


def _mem(**overrides):
    base = {
        "id": "m1",
        "content": "x",
        "created_by": "agent-a",
        "confidence": 0.9,
        "session_id": "s1",
        "derived_from": [],
    }
    base.update(overrides)
    return base


def test_returns_result_dataclass():
    result = evaluate_attribution_integrity("d", [_mem()])
    assert isinstance(result, AttributionIntegrityResult)
    assert 0.0 <= result.score <= 1.0
    assert isinstance(result.passed, bool)


def test_empty_retrieved_memories_fails():
    result = evaluate_attribution_integrity("d", [])
    assert result.passed is False
    assert result.score == 0.0
    assert "no_retrieved_memories" in result.details.get("error", "")


def test_well_attributed_high_confidence_passes():
    memories = [
        _mem(id="a", created_by="agent-a", confidence=0.9, session_id="s1"),
        _mem(id="b", created_by="agent-b", confidence=0.85, session_id="s1"),
    ]
    result = evaluate_attribution_integrity("d", memories)
    assert result.passed is True
    assert result.score >= 0.7


def test_missing_attribution_penalized():
    memories = [
        _mem(id="a", created_by="agent-a", confidence=0.9),
        _mem(id="b", created_by=None, confidence=0.9),  # no source
    ]
    bad = evaluate_attribution_integrity("d", memories)

    good = evaluate_attribution_integrity(
        "d",
        [
            _mem(id="a", created_by="agent-a", confidence=0.9),
            _mem(id="b", created_by="agent-b", confidence=0.9),
        ],
    )
    assert bad.score < good.score


def test_low_confidence_unhedged_penalized():
    memories = [_mem(confidence=0.2, hedged=False)]
    result = evaluate_attribution_integrity("d", memories)
    assert result.score < 1.0


def test_threshold_arg_changes_pass_fail():
    # confidence < 0.4 + hedged=False triggers a penalty, score < 1.0
    memories = [_mem(confidence=0.2, hedged=False)]
    res = evaluate_attribution_integrity("d", memories)
    assert res.score < 1.0  # confirm the penalty actually fired
    low_bar = evaluate_attribution_integrity("d", memories, threshold=0.0)
    high_bar = evaluate_attribution_integrity("d", memories, threshold=res.score + 0.01)
    assert low_bar.passed is True
    assert high_bar.passed is False
