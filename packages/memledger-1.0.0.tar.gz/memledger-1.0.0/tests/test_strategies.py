"""Tests for the pluggable strategy framework (v0.3.1).

Covers:
  - Each deterministic strategy returns the expected default behavior
  - Each LLM strategy with a mocked LiteLLM call
  - Registry / factory builds the right thing from YAML config
  - Memledger core invokes the strategy at the right point
  - Fallback behavior when LLM calls fail (graceful degradation)
  - Defaults preserve v0.3.0 behavior (no behavioral regression)

Unit tests do not require any LLM credentials. The LiteLLM call is patched
out via monkeypatch in every LLM-strategy test. The Memledger-core integration
tests use a deterministic fake embedder so they don't hit real embedding APIs.
"""

from __future__ import annotations

import hashlib
from unittest.mock import AsyncMock, MagicMock

import pytest

from memledger.embeddings import EmbeddingProvider
from memledger.models import EmbeddingConfig, SemanticRecord
from memledger.strategies import (
    AlwaysStore,
    FixedImportance,
    HookOnly,
    PolicyRerank,
    WriteDecision,
    build_strategies,
    register_strategy,
)
from memledger.strategies.llm import (
    LLMGated,
    LLMImportance,
    LLMRerank,
    LLMResolver,
    _extract_json,
)


def _make_record(content: str = "test fact", **kwargs) -> SemanticRecord:
    return SemanticRecord(content=content, namespace="/test", **kwargs)


class _FakeEmbedder(EmbeddingProvider):
    """Deterministic hash-based embedder so integration tests don't hit
    a real embedding provider. Mirrors tests/test_sqlite_integration.py."""

    def __init__(self, dimensions: int = 64) -> None:
        config = EmbeddingConfig(provider="fake", model="fake", dimensions=dimensions)
        super().__init__(config)
        self._dimensions = dimensions

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._hash_embed(t) for t in texts]

    async def embed_single(self, text: str) -> list[float]:
        return self._hash_embed(text)

    def _hash_embed(self, text: str) -> list[float]:
        h = hashlib.sha256(text.encode()).digest()
        # Repeat / truncate the digest into a vector of the right length
        floats = []
        i = 0
        while len(floats) < self._dimensions:
            floats.append((h[i % len(h)] / 255.0) - 0.5)
            i += 1
        return floats


async def _make_memledger(tmp_path):
    """Build an Memledger instance with the SQLite backend and the fake embedder.

    Returns a fresh memledger each call so integration tests don't share state.
    """
    from memledger import Memledger

    db_path = str(tmp_path / "test.db")
    memledger = await Memledger.create(
        backend_name="sqlite",
        backend_config={"path": db_path, "dimensions": 64},
        embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=64),
    )
    memledger._embedder = _FakeEmbedder(dimensions=64)
    return memledger


# ── Deterministic strategy tests ───────────────────────────────────


class TestFixedImportance:
    @pytest.mark.asyncio
    async def test_default_is_half(self):
        s = FixedImportance()
        assert await s.score(_make_record()) == 0.5

    @pytest.mark.asyncio
    async def test_custom_default(self):
        s = FixedImportance(default=0.9)
        assert await s.score(_make_record()) == 0.9

    def test_rejects_invalid_default(self):
        with pytest.raises(ValueError):
            FixedImportance(default=1.5)
        with pytest.raises(ValueError):
            FixedImportance(default=-0.1)


class TestAlwaysStore:
    @pytest.mark.asyncio
    async def test_always_returns_true(self):
        s = AlwaysStore()
        decision = await s.should_store(_make_record())
        assert decision.should_store is True
        assert "always-store" in decision.reason


class TestHookOnly:
    @pytest.mark.asyncio
    async def test_always_store_anyway(self):
        s = HookOnly()
        new = _make_record("new fact")
        existing = _make_record("similar fact")
        resolution = await s.resolve(new, existing, similarity=0.95)
        assert resolution.action == "store_anyway"
        assert "0.950" in resolution.reason


class TestPolicyRerank:
    @pytest.mark.asyncio
    async def test_calls_injected_rerank(self):
        called_with = []

        def fake_rerank(records):
            called_with.append(records)
            return list(reversed(records))  # reversed so we can detect a call

        s = PolicyRerank(rerank_fn=fake_rerank)
        records = [_make_record(f"fact {i}", id=str(i)) for i in range(3)]
        result = await s.rerank("query", records)
        assert called_with == [records]
        assert [r.id for r in result] == ["2", "1", "0"]

    @pytest.mark.asyncio
    async def test_handles_async_rerank_fn(self):
        async def async_rerank(records):
            return records

        s = PolicyRerank(rerank_fn=async_rerank)
        records = [_make_record("a", id="1")]
        result = await s.rerank("q", records)
        assert result == records


# ── LLM strategy tests (mocked LiteLLM) ────────────────────────────


@pytest.fixture
def mock_litellm(monkeypatch):
    """Patch litellm.acompletion across all strategies."""
    fake_response = MagicMock()
    fake_response.choices = [MagicMock(message=MagicMock(content=""))]
    mock = AsyncMock(return_value=fake_response)

    # Patch the import inside _llm_call
    import litellm  # may be a stub if not installed; that's fine for tests

    monkeypatch.setattr(litellm, "acompletion", mock)
    return mock, fake_response


class TestLLMImportance:
    @pytest.mark.asyncio
    async def test_parses_integer(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "8"
        s = LLMImportance(model="anthropic/claude-haiku-4-5")
        score = await s.score(_make_record("a meaningful event"))
        assert score == 0.8

    @pytest.mark.asyncio
    async def test_parses_integer_with_text(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "I would rate this 7 out of 10"
        s = LLMImportance(model="anthropic/claude-haiku-4-5")
        score = await s.score(_make_record())
        assert score == 0.7

    @pytest.mark.asyncio
    async def test_clamps_above_ten(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "15"
        s = LLMImportance(model="anthropic/claude-haiku-4-5")
        score = await s.score(_make_record())
        assert score == 1.0

    @pytest.mark.asyncio
    async def test_falls_back_on_no_integer(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "I cannot rate this"
        s = LLMImportance(model="anthropic/claude-haiku-4-5", fallback=0.42)
        score = await s.score(_make_record())
        assert score == 0.42

    @pytest.mark.asyncio
    async def test_falls_back_on_exception(self, monkeypatch):
        import litellm

        monkeypatch.setattr(litellm, "acompletion", AsyncMock(side_effect=RuntimeError("boom")))
        s = LLMImportance(model="anthropic/claude-haiku-4-5", fallback=0.3)
        score = await s.score(_make_record())
        assert score == 0.3

    def test_provider_prefix_added(self):
        s = LLMImportance(model="claude-haiku-4-5", provider="anthropic")
        assert s.model == "anthropic/claude-haiku-4-5"

    def test_provider_prefix_not_doubled(self):
        s = LLMImportance(model="anthropic/claude-haiku-4-5", provider="anthropic")
        assert s.model == "anthropic/claude-haiku-4-5"


class TestLLMGated:
    @pytest.mark.asyncio
    async def test_parses_store_true(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '{"store": true, "reason": "fact"}'
        s = LLMGated(model="anthropic/claude-haiku-4-5")
        decision = await s.should_store(_make_record())
        assert decision.should_store is True
        assert decision.reason == "fact"

    @pytest.mark.asyncio
    async def test_parses_store_false(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '{"store": false, "reason": "trivial"}'
        s = LLMGated(model="anthropic/claude-haiku-4-5")
        decision = await s.should_store(_make_record())
        assert decision.should_store is False
        assert decision.reason == "trivial"

    @pytest.mark.asyncio
    async def test_falls_back_to_store_true(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "garbage non-json"
        s = LLMGated(model="anthropic/claude-haiku-4-5", fallback_store=True)
        decision = await s.should_store(_make_record())
        assert decision.should_store is True

    @pytest.mark.asyncio
    async def test_falls_back_to_store_false(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = "garbage"
        s = LLMGated(model="anthropic/claude-haiku-4-5", fallback_store=False)
        decision = await s.should_store(_make_record())
        assert decision.should_store is False


class TestLLMResolver:
    @pytest.mark.asyncio
    async def test_supersede(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '{"action": "supersede", "reason": "newer is correct"}'
        s = LLMResolver(model="anthropic/claude-haiku-4-5")
        new = _make_record("new", id="new-id")
        existing = _make_record("old", id="existing-id")
        resolution = await s.resolve(new, existing, similarity=0.9)
        assert resolution.action == "supersede"
        assert resolution.supersede_id == "existing-id"

    @pytest.mark.asyncio
    async def test_merge(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[
            0
        ].message.content = '{"action": "merge", "reason": "complementary", "merged_content": "combined"}'
        s = LLMResolver(model="anthropic/claude-haiku-4-5")
        new = _make_record("a")
        existing = _make_record("b")
        resolution = await s.resolve(new, existing, similarity=0.9)
        assert resolution.action == "merge"
        assert resolution.merged_content == "combined"

    @pytest.mark.asyncio
    async def test_invalid_action_falls_back(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '{"action": "yolo", "reason": "?"}'
        s = LLMResolver(model="anthropic/claude-haiku-4-5", fallback_action="store_anyway")
        resolution = await s.resolve(_make_record(), _make_record(), 0.9)
        assert resolution.action == "store_anyway"

    @pytest.mark.asyncio
    async def test_falls_back_on_exception(self, monkeypatch):
        import litellm

        monkeypatch.setattr(litellm, "acompletion", AsyncMock(side_effect=Exception("nope")))
        s = LLMResolver(model="anthropic/claude-haiku-4-5", fallback_action="store_anyway")
        resolution = await s.resolve(_make_record(), _make_record(), 0.9)
        assert resolution.action == "store_anyway"

    def test_invalid_fallback_action_rejected(self):
        with pytest.raises(ValueError):
            LLMResolver(model="anthropic/claude-haiku-4-5", fallback_action="bogus")


class TestLLMRerank:
    @pytest.mark.asyncio
    async def test_reorders_by_id(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '["b", "c", "a"]'
        records = [
            _make_record("first", id="a"),
            _make_record("second", id="b"),
            _make_record("third", id="c"),
        ]
        s = LLMRerank(model="anthropic/claude-haiku-4-5", rerank_fn=lambda x: x)
        result = await s.rerank("query", records)
        assert [r.id for r in result] == ["b", "c", "a"]

    @pytest.mark.asyncio
    async def test_appends_missing_ids(self, mock_litellm):
        mock, response = mock_litellm
        response.choices[0].message.content = '["b"]'  # forgot a and c
        records = [
            _make_record("a content", id="a"),
            _make_record("b content", id="b"),
            _make_record("c content", id="c"),
        ]
        s = LLMRerank(model="anthropic/claude-haiku-4-5", rerank_fn=lambda x: x)
        result = await s.rerank("query", records)
        assert "b" in [r.id for r in result]
        assert len(result) == 3  # all three present

    @pytest.mark.asyncio
    async def test_falls_back_to_policy_on_exception(self, monkeypatch):
        import litellm

        monkeypatch.setattr(litellm, "acompletion", AsyncMock(side_effect=Exception("boom")))
        records = [_make_record(f"f{i}", id=str(i)) for i in range(3)]

        def fake_rerank(rs):
            # Reverse so we can verify policy rerank ran
            return list(reversed(rs))

        s = LLMRerank(model="anthropic/claude-haiku-4-5", rerank_fn=fake_rerank)
        result = await s.rerank("query", records)
        assert [r.id for r in result] == ["2", "1", "0"]

    @pytest.mark.asyncio
    async def test_empty_records_returns_empty(self, mock_litellm):
        s = LLMRerank(model="anthropic/claude-haiku-4-5", rerank_fn=lambda x: x)
        result = await s.rerank("query", [])
        assert result == []


# ── JSON extraction helper ─────────────────────────────────────────


class TestExtractJson:
    def test_plain_object(self):
        assert _extract_json('{"a": 1}') == {"a": 1}

    def test_plain_array(self):
        assert _extract_json('["a", "b"]') == ["a", "b"]

    def test_with_prose(self):
        assert _extract_json('Here is the answer: {"x": 5}') == {"x": 5}

    def test_in_fenced_code_block(self):
        text = '```json\n{"a": 1}\n```'
        assert _extract_json(text) == {"a": 1}

    def test_returns_none_on_garbage(self):
        assert _extract_json("not json at all") is None

    def test_returns_none_on_empty(self):
        assert _extract_json("") is None


# ── Registry / factory ─────────────────────────────────────────────


class TestBuildStrategies:
    def test_defaults_match_v030(self):
        strats = build_strategies(None, rerank_fn=lambda x: x)
        assert isinstance(strats.importance, FixedImportance)
        assert isinstance(strats.write_policy, AlwaysStore)
        assert isinstance(strats.conflict_resolver, HookOnly)
        assert isinstance(strats.reranker, PolicyRerank)

    def test_empty_dict_matches_defaults(self):
        strats = build_strategies({}, rerank_fn=lambda x: x)
        assert isinstance(strats.importance, FixedImportance)

    def test_partial_opt_in(self):
        strats = build_strategies(
            {
                "importance": {
                    "provider": "llm",
                    "config": {"model": "anthropic/claude-haiku-4-5"},
                },
            },
            rerank_fn=lambda x: x,
        )
        assert isinstance(strats.importance, LLMImportance)
        # Other three are still defaults
        assert isinstance(strats.write_policy, AlwaysStore)
        assert isinstance(strats.conflict_resolver, HookOnly)
        assert isinstance(strats.reranker, PolicyRerank)

    def test_full_llm_opt_in(self):
        strats = build_strategies(
            {
                "importance": {
                    "provider": "llm",
                    "config": {"model": "anthropic/claude-haiku-4-5"},
                },
                "write_policy": {
                    "provider": "llm",
                    "config": {"model": "anthropic/claude-haiku-4-5"},
                },
                "conflict_resolver": {
                    "provider": "llm",
                    "config": {"model": "anthropic/claude-haiku-4-5"},
                },
                "reranker": {
                    "provider": "llm",
                    "config": {"model": "anthropic/claude-haiku-4-5"},
                },
            },
            rerank_fn=lambda x: x,
        )
        assert isinstance(strats.importance, LLMImportance)
        assert isinstance(strats.write_policy, LLMGated)
        assert isinstance(strats.conflict_resolver, LLMResolver)
        assert isinstance(strats.reranker, LLMRerank)

    def test_unknown_provider_raises(self):
        with pytest.raises(ValueError, match="Unknown importance"):
            build_strategies(
                {"importance": {"provider": "nonsense"}},
                rerank_fn=lambda x: x,
            )

    def test_register_third_party(self):
        from memledger.strategies.policies import ImportanceStrategy

        class CustomImportance(ImportanceStrategy):
            async def score(self, record):
                return 0.42

        register_strategy("importance", "custom_test", CustomImportance)
        strats = build_strategies(
            {"importance": {"provider": "custom_test"}},
            rerank_fn=lambda x: x,
        )
        assert isinstance(strats.importance, CustomImportance)


# ── Memledger core integration ────────────────────────────────────────


class TestMemledgerIntegration:
    """Verify that memledger.add() and memledger.search() invoke the strategies."""

    @pytest.mark.asyncio
    async def test_add_skipped_when_write_policy_blocks(self, tmp_path):
        """A WritePolicyStrategy returning should_store=False causes add() to skip."""
        from memledger.strategies.policies import WritePolicyStrategy

        class BlockEverything(WritePolicyStrategy):
            async def should_store(self, record):
                return WriteDecision(should_store=False, reason="blocked for test")

        memledger = await _make_memledger(tmp_path)
        memledger._strategies.write_policy = BlockEverything()
        try:
            result = await memledger.add(content="should be blocked", namespace="/t")
            assert result == ""
        finally:
            await memledger.close()

    @pytest.mark.asyncio
    async def test_add_uses_importance_strategy(self, tmp_path):
        """A non-Fixed ImportanceStrategy should override the record's importance."""
        from memledger.strategies.policies import ImportanceStrategy

        class FixedAt09(ImportanceStrategy):
            async def score(self, record):
                return 0.9

        memledger = await _make_memledger(tmp_path)
        memledger._strategies.importance = FixedAt09()
        try:
            record_id = await memledger.add(content="hello", namespace="/t")
            stored = await memledger._backend.get(record_id)
            assert stored.importance == 0.9
        finally:
            await memledger.close()

    @pytest.mark.asyncio
    async def test_default_memledger_has_v030_behavior(self, tmp_path):
        """An memledger with no strategy config behaves identically to v0.3.0."""
        memledger = await _make_memledger(tmp_path)
        try:
            assert isinstance(memledger._strategies.importance, FixedImportance)
            assert isinstance(memledger._strategies.write_policy, AlwaysStore)
            assert isinstance(memledger._strategies.conflict_resolver, HookOnly)
            assert isinstance(memledger._strategies.reranker, PolicyRerank)

            record_id = await memledger.add(content="default behavior", namespace="/t")
            assert record_id != ""
            stored = await memledger._backend.get(record_id)
            assert stored.importance == 0.5  # FixedImportance default
        finally:
            await memledger.close()
