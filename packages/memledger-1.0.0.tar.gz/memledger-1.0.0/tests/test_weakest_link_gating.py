"""B10 — weakest-link confidence + gate-through-effective-confidence.

The contract under test: a memory's *effective* confidence (used by
`search()` confidence gating) is `min(declared, upstream_chain_min)`.
A 0.9-confidence claim derived from a 0.3-confidence ancestor must
gate at 0.3.

These tests:
  - exercise `compute_effective_confidence` directly with a stub
    ChainStore (no DB),
  - exercise the full `search()` gate path against the running
    pgvector backend when ENGRAM_TEST_PG_DSN is set; otherwise the
    integration test skips and the pure-logic tests still run.
"""

from __future__ import annotations

import os
import uuid
from types import SimpleNamespace

import pytest
import pytest_asyncio

from memledger.policies.confidence_policy import (
    ConfidencePolicy,
    apply_confidence_gating,
)
from memledger.provenance.effective_confidence import (
    compute_effective_confidence,
    compute_effective_confidence_map,
)
from memledger.provenance.models import AttributionChain, ChainHop


# ──────────────────────────────────────────────────────────────────
# Stub ChainStore: lets us test logic without touching a database
# ──────────────────────────────────────────────────────────────────

class _StubChainStore:
    def __init__(self, min_conf_by_id: dict[str, float]):
        self._min = min_conf_by_id
        self.calls: list[str] = []

    async def min_confidence_upstream(self, memory_id: str, *, max_hops: int = 5) -> float:
        self.calls.append(memory_id)
        return self._min.get(memory_id, 1.0)

    async def build_chain(self, memory_id: str, *, direction: str = "upstream", max_hops: int = 5):
        return AttributionChain(
            root_memory_id=memory_id,
            chain=[ChainHop(memory_id=memory_id, agent_id="a", confidence=self._min.get(memory_id, 1.0),
                            timestamp="", hop_number=0, action="origin")],
            chain_depth=1,
            min_confidence=self._min.get(memory_id, 1.0),
            agents_involved=["a"],
            truncated=False,
            full_chain_json="[]",
        )


def _record(rid: str, *, confidence: float, derived_from: list[str] | None = None):
    """Minimal MemoryRecord-shaped stub."""
    return SimpleNamespace(
        id=rid,
        confidence=confidence,
        derived_from=derived_from or [],
        metadata=None,
        created_by="test-agent",
    )


# ──────────────────────────────────────────────────────────────────
# 1. compute_effective_confidence — logic-only tests
# ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_no_chain_returns_declared_and_skips_walk():
    """A record with no derived_from must NOT trigger a chain walk."""
    store = _StubChainStore({})
    r = _record("m1", confidence=0.85, derived_from=[])
    eff = await compute_effective_confidence(r, store)
    assert eff == 0.85
    assert store.calls == []  # invariant: no chain walk when no provenance


@pytest.mark.asyncio
async def test_weak_ancestor_drags_down_strong_descendant():
    """The multi-agent scenario: diag-agent claims 0.9 from a 0.3 triage hunch."""
    store = _StubChainStore({"diag-002": 0.30})
    r = _record("diag-002", confidence=0.85, derived_from=["tri-001"])
    eff = await compute_effective_confidence(r, store)
    assert eff == 0.30


@pytest.mark.asyncio
async def test_chain_min_above_declared_does_not_raise_score():
    """min(0.6, 0.9) = 0.6 — the chain cannot increase a record's confidence."""
    store = _StubChainStore({"m1": 0.9})
    r = _record("m1", confidence=0.6, derived_from=["parent"])
    eff = await compute_effective_confidence(r, store)
    assert eff == 0.6


@pytest.mark.asyncio
async def test_resolve_declared_hook_is_used():
    """B12 (v2) decay seam — resolve_declared can override declared conf."""
    store = _StubChainStore({"m1": 0.9})
    r = _record("m1", confidence=0.8, derived_from=[])  # empty chain → uses resolver
    eff = await compute_effective_confidence(r, store, resolve_declared=lambda x: 0.4)
    assert eff == 0.4


@pytest.mark.asyncio
async def test_batch_helper_returns_id_map():
    store = _StubChainStore({"m1": 0.3, "m2": 0.7})
    recs = [
        _record("m1", confidence=0.9, derived_from=["p1"]),
        _record("m2", confidence=0.5, derived_from=["p2"]),
    ]
    eff = await compute_effective_confidence_map(recs, store)
    assert eff == {"m1": 0.3, "m2": 0.5}


# ──────────────────────────────────────────────────────────────────
# 2. apply_confidence_gating with the effective_confidence map
# ──────────────────────────────────────────────────────────────────

def test_gating_uses_effective_when_provided():
    policy = ConfidencePolicy(min_threshold=0.5, flag_threshold=0.7)
    r = _record("diag", confidence=0.85, derived_from=["tri"])
    # declared 0.85 would PASS; effective 0.30 must FILTER.
    passed, flagged, filtered = apply_confidence_gating(
        [r], policy, effective_confidence={"diag": 0.30},
    )
    assert passed == []
    assert flagged == []
    assert filtered == [r]


def test_gating_falls_back_to_declared_when_map_missing():
    """Backward compat: callers passing only (records, policy) get old behavior."""
    policy = ConfidencePolicy(min_threshold=0.5, flag_threshold=0.7)
    r = _record("m1", confidence=0.85, derived_from=[])
    passed, flagged, filtered = apply_confidence_gating([r], policy)
    assert passed == [r] and not flagged and not filtered


def test_gating_uses_effective_map_partial_coverage():
    """If a record's id isn't in the map, fall back to declared confidence."""
    policy = ConfidencePolicy(min_threshold=0.5, flag_threshold=0.7)
    r1 = _record("a", confidence=0.85, derived_from=["x"])
    r2 = _record("b", confidence=0.85, derived_from=[])
    passed, flagged, filtered = apply_confidence_gating(
        [r1, r2], policy, effective_confidence={"a": 0.30},
    )
    assert r1 in filtered  # mapped to 0.30
    assert r2 in passed    # falls back to declared 0.85


# ──────────────────────────────────────────────────────────────────
# 3. Integration — full search() path through pgvector + chain walk
#    Skipped unless ENGRAM_TEST_PG_DSN is configured.
# ──────────────────────────────────────────────────────────────────

_DSN = os.environ.get("ENGRAM_TEST_PG_DSN", "")
_DSN_AVAILABLE = bool(_DSN)


@pytest_asyncio.fixture
async def memledger_with_chain():
    """Creates a Memledger with a 2-hop chain: tri-001 (conf=0.3) → diag-002 (conf=0.85)."""
    if not _DSN_AVAILABLE:
        pytest.skip("ENGRAM_TEST_PG_DSN not set")
    from memledger.memledger import Memledger
    from memledger.models import EmbeddingConfig

    ns = f"/test/b10/{uuid.uuid4().hex[:8]}"
    ml = await Memledger.create(
        backend_name="pgvector",
        backend_config={"connection_string": _DSN, "dimensions": 384},
        embedding_config=EmbeddingConfig(),
    )
    # Triage agent: low confidence
    tri_id = await ml.add(
        content="DB latency spike likely caused by connection pool exhaustion",
        namespace=ns,
        created_by="triage-agent",
        confidence=0.30,
    )
    # Diagnosis agent: high local confidence, derived from triage
    diag_id = await ml.add(
        content="HikariCP maxPoolSize=10 is too small; recommend bump to 50",
        namespace=ns,
        created_by="diagnosis-agent",
        confidence=0.85,
        derived_from=[tri_id],
    )
    yield ml, ns, tri_id, diag_id
    await ml.close()


@pytest.mark.asyncio
@pytest.mark.skipif(not _DSN_AVAILABLE, reason="ENGRAM_TEST_PG_DSN not set")
async def test_search_with_gate_filters_weak_chain(memledger_with_chain):
    ml, ns, _tri_id, _diag_id = memledger_with_chain
    result = await ml.search(
        query="connection pool issue",
        namespace=ns,
        confidence_policy={"min_threshold": 0.5, "flag_threshold": 0.7},
    )
    diag = next((r for r in result.records if r.created_by == "diagnosis-agent"), None)
    # diag declared 0.85 but its chain min is 0.30 → effective 0.30 → must be filtered out
    assert diag is None, (
        "B10 contract: diagnosis memory was returned despite weak upstream "
        "chain. Effective confidence gating did not engage."
    )
    # gating metadata surfaced
    assert result.metadata["confidence_gating"]["uses_effective_confidence"] is True


@pytest.mark.asyncio
@pytest.mark.skipif(not _DSN_AVAILABLE, reason="ENGRAM_TEST_PG_DSN not set")
async def test_search_without_gate_returns_everything(memledger_with_chain):
    ml, ns, _tri_id, _diag_id = memledger_with_chain
    result = await ml.search(query="connection pool", namespace=ns)
    # No confidence_policy passed → no chain walk, no filtering
    assert any(r.created_by == "diagnosis-agent" for r in result.records)
    assert "confidence_gating" not in (result.metadata or {})
