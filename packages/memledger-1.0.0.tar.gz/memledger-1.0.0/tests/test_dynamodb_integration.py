"""Integration test: DynamoDB backend — key-value operations, lifecycle, batch APIs.

Requires:
  - AWS credentials configured
  - DynamoDB table created: ./scripts/dynamodb-test.sh create
  - Set ENGRAM_TEST_DDB_TABLE env var (default: memledger-test)

Run:
  ./scripts/dynamodb-test.sh create
  pytest tests/test_dynamodb_integration.py -v

Skip:
  Tests are skipped if ENGRAM_TEST_DDB_TABLE is not set.

Note: DynamoDB does NOT support vector search. search_vector() returns empty.
      Use multi-backend composition with OpenSearch for semantic search.
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.models import MemoryStatus, RecordType

DDB_TABLE = os.environ.get("ENGRAM_TEST_DDB_TABLE", "")

pytestmark = [
    pytest.mark.aws,
    pytest.mark.asyncio,
    pytest.mark.skipif(not DDB_TABLE, reason="ENGRAM_TEST_DDB_TABLE not set"),
]


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def backend():
    """Create a raw DynamoDB backend (no Memledger wrapper, no embeddings needed)."""
    from memledger.backends.dynamodb import DynamoDBBackend

    b = DynamoDBBackend()
    await b.initialize(
        {
            "table_name": DDB_TABLE,
            "region": os.environ.get("AWS_REGION", "us-west-2"),
            "create_table": False,  # table already exists
        }
    )
    yield b
    await b.close()


def _make_record(content: str, namespace: str, **kwargs):
    """Create a MemoryRecord for testing (no embedding needed for DynamoDB)."""
    from memledger.models import MemoryRecord

    return MemoryRecord(content=content, namespace=namespace, **kwargs)


# ── Core CRUD ────────────────────────────────────────────────


async def test_add_and_get(backend):
    """Store and retrieve a memory."""
    ns = _unique_ns()
    record = _make_record("DynamoDB test memory", ns)

    ids = await backend.add([record])
    assert len(ids) == 1

    retrieved = await backend.get(ids[0])
    assert retrieved is not None
    assert retrieved.content == "DynamoDB test memory"
    assert retrieved.namespace == ns
    assert retrieved.status == MemoryStatus.ACTIVE


async def test_update(backend):
    """Update metadata on a record."""
    ns = _unique_ns()
    record = _make_record("Update test", ns, metadata={"version": "1"})

    ids = await backend.add([record])
    updated = await backend.update(ids[0], metadata='{"version": "2"}')
    assert updated is True


async def test_soft_delete(backend):
    """Delete sets status to archived, doesn't physically remove."""
    ns = _unique_ns()
    record = _make_record("Delete test", ns)

    ids = await backend.add([record])
    deleted = await backend.delete(ids[0])
    assert deleted is True

    # Record still exists
    retrieved = await backend.get(ids[0])
    assert retrieved is not None
    assert retrieved.status == MemoryStatus.ARCHIVED


async def test_search_vector_returns_empty(backend):
    """DynamoDB cannot do vector search — returns empty."""
    results = await backend.search_vector(
        embedding=[0.1] * 1024,
        top_k=5,
        namespace="/test",
    )
    assert results == []


# ── Typed Records ────────────────────────────────────────────


async def test_episodic_record(backend):
    """Store and retrieve an episodic record."""
    from memledger.models import EpisodicRecord

    ns = _unique_ns()
    record = EpisodicRecord(
        content="Pod crashed at 3am",
        namespace=ns,
        outcome="Fixed by restart",
        actors=["sre-agent"],
    )

    ids = await backend.add([record])
    retrieved = await backend.get(ids[0])

    assert retrieved is not None
    assert retrieved.record_type == RecordType.EPISODIC
    assert retrieved.outcome == "Fixed by restart"


async def test_procedural_record(backend):
    """Store and retrieve a procedural record."""
    from memledger.models import ProceduralRecord

    ns = _unique_ns()
    record = ProceduralRecord(
        content="How to fix OOM",
        namespace=ns,
        steps=["Check limits", "Increase memory"],
        tools_required=["kubectl"],
    )

    ids = await backend.add([record])
    retrieved = await backend.get(ids[0])

    assert retrieved is not None
    assert retrieved.record_type == RecordType.PROCEDURAL
    assert len(retrieved.steps) == 2


# ── Scoring ──────────────────────────────────────────────────


async def test_record_access(backend):
    """Track access count."""
    ns = _unique_ns()
    record = _make_record("Access test", ns)

    ids = await backend.add([record])
    await backend.record_access(ids)
    await backend.record_access(ids)

    retrieved = await backend.get(ids[0])
    assert retrieved.access_count >= 2


async def test_record_outcome(backend):
    """Track success/failure outcomes."""
    ns = _unique_ns()
    record = _make_record("Outcome test", ns)

    ids = await backend.add([record])
    await backend.record_outcome(ids[0], success=True)
    await backend.record_outcome(ids[0], success=False)

    retrieved = await backend.get(ids[0])
    assert retrieved.success_count == 1
    assert retrieved.failure_count == 1


# ── Batch APIs ───────────────────────────────────────────────


async def test_get_by_session(backend):
    """Retrieve memories by session ID."""
    ns = _unique_ns()
    session_id = f"sess-{uuid.uuid4().hex[:8]}"

    r1 = _make_record("Session mem 1", ns, session_id=session_id)
    r2 = _make_record("Session mem 2", ns, session_id=session_id)
    r3 = _make_record("Other session", ns, session_id="other")

    await backend.add([r1, r2, r3])

    results = await backend.get_by_session(session_id)
    assert len(results) == 2
    assert all(r.session_id == session_id for r in results)


async def test_bulk_update_status(backend):
    """Batch status transition."""
    ns = _unique_ns()
    r1 = _make_record("Expire me", ns)
    r2 = _make_record("Keep me", ns)

    ids = await backend.add([r1, r2])
    count = await backend.bulk_update_status([ids[0]], "expired")
    assert count == 1

    retrieved = await backend.get(ids[0])
    assert retrieved.status == MemoryStatus.EXPIRED


async def test_get_by_status(backend):
    """Retrieve by lifecycle status."""
    ns = _unique_ns()
    r1 = _make_record("Active", ns)
    r2 = _make_record("Will deprecate", ns)

    ids = await backend.add([r1, r2])
    await backend.bulk_update_status([ids[1]], "deprecated")

    deprecated = await backend.get_by_status("deprecated")
    deprecated_ids = [r.id for r in deprecated]
    assert ids[1] in deprecated_ids


async def test_lifecycle_workflow(backend):
    """Full lifecycle: active → expired → archived."""
    ns = _unique_ns()
    record = _make_record("Lifecycle test", ns)

    ids = await backend.add([record])

    # Active
    r = await backend.get(ids[0])
    assert r.status == MemoryStatus.ACTIVE

    # Expire
    await backend.bulk_update_status(ids, "expired")
    r = await backend.get(ids[0])
    assert r.status == MemoryStatus.EXPIRED

    # Archive
    await backend.bulk_archive(ids)
    r = await backend.get(ids[0])
    assert r.status == MemoryStatus.ARCHIVED


# ── Health ───────────────────────────────────────────────────


async def test_health_check(backend):
    assert await backend.health_check() is True
