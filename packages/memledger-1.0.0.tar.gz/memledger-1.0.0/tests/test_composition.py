"""Tests for multi-backend composition router.

Uses pgvector as both primary and search for local testing.
In production, primary would be DynamoDB and search would be OpenSearch.
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import EmbeddingConfig, MemoryStatus

CONN_STRING = os.environ.get(
    "ENGRAM_TEST_PG_DSN",
    "postgresql://localhost:5432/memledger_test",
)

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="local",
    model="BAAI/bge-small-en-v1.5",
    dimensions=384,
)

pytestmark = pytest.mark.asyncio


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    """Create memledger with composition router (pgvector as both primary and search)."""
    from memledger.backends.pgvector import PgVectorBackend

    # Initialize two separate pgvector instances (simulates primary + search)
    primary = PgVectorBackend()
    await primary.initialize(
        {
            "connection_string": CONN_STRING,
            "dimensions": 384,
            "table_name": "agent_memory",
        }
    )

    search = PgVectorBackend()
    await search.initialize(
        {
            "connection_string": CONN_STRING,
            "dimensions": 384,
            "table_name": "agent_memory",  # same table for testing
        }
    )

    from memledger.backends.composition import CompositionRouter

    router = CompositionRouter()
    await router.initialize(
        {
            "primary_backend": primary,
            "search_backend": search,
            "sync": "inline",
        }
    )

    from memledger.embeddings import EmbeddingProvider

    embedder = EmbeddingProvider(EMBEDDING_CONFIG)

    from memledger.models import MemledgerConfig

    config = MemledgerConfig(embeddings=EMBEDDING_CONFIG, default_backend="composition")

    e = Memledger(backend=router, embedder=embedder, config=config)
    yield e
    await e.close()


async def test_composition_add_and_search(memledger: Memledger):
    """Write via composition, search returns results."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Composition test: OOM fix via connection pool tuning",
        namespace=ns,
        metadata={"severity": "P1"},
    )
    assert record_id

    results = await memledger.search(
        query="connection pool OOM",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    assert results.records[0].id == record_id


async def test_composition_get_from_primary(memledger: Memledger):
    """Get routes to primary (source of truth)."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Get test via composition",
        namespace=ns,
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert record.id == record_id
    assert record.content == "Get test via composition"


async def test_composition_soft_delete(memledger: Memledger):
    """Delete syncs to both backends."""
    ns = _unique_ns()

    record_id = await memledger.add(content="Delete me", namespace=ns)

    deleted = await memledger.delete(record_id)
    assert deleted is True

    # Still exists in primary (soft delete)
    record = await memledger.get(record_id)
    assert record is not None
    assert record.status == MemoryStatus.ARCHIVED

    # Not in search results
    results = await memledger.search(query="delete me", namespace=ns, top_k=5)
    assert all(r.id != record_id for r in results.records)


async def test_composition_lifecycle(memledger: Memledger):
    """Lifecycle operations go through composition."""
    ns = _unique_ns()

    id1 = await memledger.add(content="Active memory", namespace=ns)
    id2 = await memledger.add(content="Will expire", namespace=ns)

    count = await memledger.bulk_update_status([id2], "expired")
    assert count == 1

    # Search only returns active
    results = await memledger.search(query="memory", namespace=ns, top_k=10)
    result_ids = [r.id for r in results.records]
    assert id1 in result_ids
    assert id2 not in result_ids


async def test_composition_batch_apis(memledger: Memledger):
    """Batch APIs route to primary."""
    ns = _unique_ns()
    session_id = f"sess-{uuid.uuid4().hex[:8]}"

    await memledger.add(content="Session memory 1", namespace=ns, session_id=session_id)
    await memledger.add(content="Session memory 2", namespace=ns, session_id=session_id)

    results = await memledger.get_by_session(session_id)
    assert len(results) == 2


async def test_composition_health(memledger: Memledger):
    """Health check verifies primary is up."""
    assert await memledger.health() is True
