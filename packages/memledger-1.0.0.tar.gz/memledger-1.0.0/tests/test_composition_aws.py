"""Integration test: Multi-backend composition with real DynamoDB + OpenSearch.

Validates the composition pattern from the book (Ch7):
  - Writes route to DynamoDB (primary, source of truth)
  - Searches route to OpenSearch (search index, hybrid vector + keyword)
  - Inline sync keeps both in sync
  - Batch operations route to primary
  - Supersession works through the composition layer

Requires:
  - ENGRAM_TEST_DDB_TABLE env var (DynamoDB table, created via scripts/dynamodb-test.sh)
  - ENGRAM_TEST_OS_ENDPOINT env var (OpenSearch endpoint)
  - AWS credentials configured

Run:
  export ENGRAM_TEST_DDB_TABLE=memledger-test
  export ENGRAM_TEST_OS_ENDPOINT=$(./scripts/opensearch-create.sh endpoint)
  pytest tests/test_composition_aws.py -v
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.models import EmbeddingConfig, MemoryStatus, RecordType

DDB_TABLE = os.environ.get("ENGRAM_TEST_DDB_TABLE", "")
OS_ENDPOINT = os.environ.get("ENGRAM_TEST_OS_ENDPOINT", "")

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="bedrock",
    model="amazon.titan-embed-text-v2:0",
    dimensions=1024,
)

pytestmark = [
    pytest.mark.aws,
    pytest.mark.asyncio,
    pytest.mark.skipif(
        not DDB_TABLE or not OS_ENDPOINT,
        reason="ENGRAM_TEST_DDB_TABLE and ENGRAM_TEST_OS_ENDPOINT both required",
    ),
]


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


def _unique_index() -> str:
    return f"memledger-comp-{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    """Create Memledger with DynamoDB primary + OpenSearch search via composition."""
    from memledger.backends.composition import CompositionRouter
    from memledger.backends.dynamodb import DynamoDBBackend
    from memledger.backends.opensearch import OpenSearchBackend
    from memledger.embeddings import EmbeddingProvider
    from memledger.memledger import Memledger
    from memledger.models import MemledgerConfig

    index_name = _unique_index()

    # Initialize DynamoDB as primary
    primary = DynamoDBBackend()
    await primary.initialize(
        {
            "table_name": DDB_TABLE,
            "region": os.environ.get("AWS_REGION", "us-west-2"),
            "create_table": False,
        }
    )

    # Initialize OpenSearch as search
    search = OpenSearchBackend()
    await search.initialize(
        {
            "hosts": [OS_ENDPOINT],
            "auth_type": "aws_sigv4",
            "region": os.environ.get("AWS_REGION", "us-west-2"),
            "index_name": index_name,
            "dimensions": 1024,
            "verify_certs": True,
        }
    )

    # Compose them
    router = CompositionRouter()
    await router.initialize(
        {
            "primary_backend": primary,
            "search_backend": search,
            "sync": "inline",
        }
    )

    embedder = EmbeddingProvider(EMBEDDING_CONFIG)
    config = MemledgerConfig(embeddings=EMBEDDING_CONFIG, default_backend="composition")

    e = Memledger(backend=router, embedder=embedder, config=config)
    yield e

    # Cleanup: delete the test OpenSearch index
    try:
        search._client.indices.delete(index=index_name)
    except Exception:
        pass
    await e.close()


# ── Core: Write to DynamoDB, Search via OpenSearch ───────────


async def test_write_primary_search_secondary(memledger):
    """Write goes to DynamoDB, search goes to OpenSearch. Both work."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Composition test: OOM caused by HikariCP pool leak on EKS",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        metadata={"cluster": "eks-prod"},
        outcome="Fixed by setting maxPoolSize=50",
    )
    assert record_id

    # Search via OpenSearch
    results = await memledger.search(
        query="OOM pool leak",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    assert results.records[0].id == record_id


async def test_get_routes_to_primary(memledger):
    """Get by ID routes to DynamoDB (source of truth)."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Primary lookup test via composition",
        namespace=ns,
    )

    record = await memledger.get(record_id)
    assert record is not None
    assert record.id == record_id
    assert record.content == "Primary lookup test via composition"


# ── Typed Records Through Composition ────────────────────────


async def test_typed_records_through_composition(memledger):
    """Typed records survive the composition write-read cycle."""
    ns = _unique_ns()

    # Episodic
    eid = await memledger.add(
        content="Pod crashed at 3am during deployment",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Rolled back",
        actors=["deploy-agent"],
    )

    # Procedural
    pid = await memledger.add(
        content="Rollback procedure for failed deployments",
        record_type=RecordType.PROCEDURAL,
        namespace=ns,
        steps=["helm history", "helm rollback", "verify health"],
        tools_required=["helm", "kubectl"],
    )

    # Verify from primary (DynamoDB)
    episode = await memledger.get(eid)
    assert episode is not None
    assert episode.record_type == RecordType.EPISODIC
    assert episode.outcome == "Rolled back"

    procedure = await memledger.get(pid)
    assert procedure is not None
    assert procedure.record_type == RecordType.PROCEDURAL
    assert len(procedure.steps) == 3


# ── Supersession Through Composition ─────────────────────────


async def test_supersession_through_composition(memledger):
    """New memory deprecates old through the composition layer."""
    ns = _unique_ns()

    old_id = await memledger.add(
        content="Set max_connections to 50 for payment-service",
        namespace=ns,
    )

    new_id = await memledger.add(
        content="Set max_connections to 200 for payment-service (updated after load test)",
        namespace=ns,
        supersedes=old_id,
    )

    # Old memory should be deprecated in primary (DynamoDB)
    old = await memledger.get(old_id)
    assert old is not None
    assert old.status == MemoryStatus.DEPRECATED

    # New memory should be active
    new = await memledger.get(new_id)
    assert new is not None
    assert new.status == MemoryStatus.ACTIVE
    assert new.supersedes == old_id

    # Search (OpenSearch) should return only the new memory
    results = await memledger.search(
        query="max_connections payment-service",
        namespace=ns,
        top_k=5,
    )
    result_ids = [r.id for r in results.records]
    assert new_id in result_ids
    assert old_id not in result_ids


# ── Lifecycle Through Composition ────────────────────────────


async def test_lifecycle_through_composition(memledger):
    """Lifecycle transitions sync across both backends."""
    ns = _unique_ns()

    id_keep = await memledger.add(content="Keep this active", namespace=ns)
    id_expire = await memledger.add(content="This will expire", namespace=ns)

    # Expire one
    count = await memledger.bulk_update_status([id_expire], "expired")
    assert count == 1

    # Primary (DynamoDB) should reflect the status
    expired = await memledger.get(id_expire)
    assert expired.status == MemoryStatus.EXPIRED

    # Search (OpenSearch) should only return active
    results = await memledger.search(query="active expire", namespace=ns, top_k=10)
    result_ids = [r.id for r in results.records]
    assert id_keep in result_ids
    assert id_expire not in result_ids


# ── Soft Delete Through Composition ──────────────────────────


async def test_soft_delete_through_composition(memledger):
    """Soft delete syncs to both backends."""
    ns = _unique_ns()

    record_id = await memledger.add(content="Delete me through composition", namespace=ns)

    deleted = await memledger.delete(record_id)
    assert deleted is True

    # Still in primary (DynamoDB) as archived
    record = await memledger.get(record_id)
    assert record is not None
    assert record.status == MemoryStatus.ARCHIVED

    # Not in search results (OpenSearch)
    results = await memledger.search(query="delete composition", namespace=ns, top_k=5)
    assert all(r.id != record_id for r in results.records)


# ── Batch Routes to Primary ──────────────────────────────────


async def test_batch_routes_to_primary(memledger):
    """Batch operations (get_by_session) route to DynamoDB."""
    ns = _unique_ns()
    session_id = f"sess-{uuid.uuid4().hex[:8]}"

    await memledger.add(content="Session mem 1", namespace=ns, session_id=session_id)
    await memledger.add(content="Session mem 2", namespace=ns, session_id=session_id)

    results = await memledger.get_by_session(session_id)
    assert len(results) == 2
    assert all(r.session_id == session_id for r in results)


# ── Health Check ─────────────────────────────────────────────


async def test_composition_health(memledger):
    """Health check verifies primary backend."""
    assert await memledger.health() is True
