"""Tests for memory scoring and composite retrieval."""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import EmbeddingConfig, RecordType
from memledger.strategies.scoring import ScoringConfig, compute_final_score, compute_policy_score

CONN_STRING = os.environ.get(
    "ENGRAM_TEST_PG_DSN",
    "postgresql://localhost:5432/memledger_test",
)

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="local",
    model="BAAI/bge-small-en-v1.5",
    dimensions=384,
)

pytestmark = pytest.mark.asyncio


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    e = await Memledger.create(
        backend_name="pgvector",
        connection_string=CONN_STRING,
        embedding_config=EMBEDDING_CONFIG,
    )
    yield e
    await e.close()


# ── Unit tests for scoring functions ─────────────────────────


def test_policy_score_no_data():
    """Neutral score when no usage data exists."""
    score = compute_policy_score()
    assert 0.0 <= score <= 1.0
    # With no data: success_rate=0.5, recency=0.5, frequency=0.0
    assert abs(score - 0.35) < 0.1  # approximately


def test_policy_score_high_success():
    """High success rate dominates score."""
    score = compute_policy_score(
        success_count=10,
        failure_count=0,
        access_count=50,
        last_accessed_at=datetime.now(timezone.utc),
    )
    assert score > 0.7


def test_policy_score_recent_access():
    """Recently accessed memory scores higher than old one."""
    recent = compute_policy_score(
        last_accessed_at=datetime.now(timezone.utc),
    )
    old = compute_policy_score(
        last_accessed_at=datetime.now(timezone.utc) - timedelta(days=60),
    )
    assert recent > old


def test_policy_score_high_frequency():
    """Frequently accessed memory scores higher."""
    frequent = compute_policy_score(access_count=80)
    rare = compute_policy_score(access_count=2)
    assert frequent > rare


def test_final_score_combines():
    """Final score blends cosine similarity with policy score."""
    config = ScoringConfig(similarity_weight=0.5, policy_weight=0.5)

    # High cosine, low policy
    score1 = compute_final_score(
        cosine_score=0.9,
        success_count=0,
        failure_count=5,
        config=config,
    )

    # Low cosine, high policy
    score2 = compute_final_score(
        cosine_score=0.3,
        success_count=10,
        failure_count=0,
        access_count=50,
        last_accessed_at=datetime.now(timezone.utc),
        config=config,
    )

    # Both should be in valid range
    assert 0.0 <= score1 <= 1.0
    assert 0.0 <= score2 <= 1.0


def test_custom_weights():
    """Custom scoring config changes behavior."""
    config = ScoringConfig(
        success_rate_weight=0.8,
        recency_weight=0.1,
        frequency_weight=0.1,
    )
    # Success-heavy config should reward high success rate
    score = compute_policy_score(
        success_count=10,
        failure_count=0,
        config=config,
    )
    assert score > 0.7


# ── Integration tests for scoring tracking ───────────────────


async def test_access_tracking(memledger: Memledger):
    """Searching for a memory increments its access_count."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Access tracking test memory",
        namespace=ns,
    )

    # Search twice to trigger access tracking
    await memledger.search(query="access tracking", namespace=ns, top_k=1)
    await memledger.search(query="access tracking", namespace=ns, top_k=1)

    record = await memledger.get(record_id)
    assert record is not None
    assert record.access_count >= 2
    assert record.last_accessed_at is not None


async def test_record_outcome(memledger: Memledger):
    """Recording outcomes updates success/failure counts."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Outcome tracking test memory",
        namespace=ns,
    )

    await memledger.record_outcome(record_id, success=True)
    await memledger.record_outcome(record_id, success=True)
    await memledger.record_outcome(record_id, success=False)

    record = await memledger.get(record_id)
    assert record is not None
    assert record.success_count == 2
    assert record.failure_count == 1


# ── Integration tests for composite retrieval ────────────────


async def test_recall_context(memledger: Memledger):
    """Composite retrieval returns episodes, procedures, and failures."""
    ns = _unique_ns()

    # Store an episodic memory
    await memledger.add(
        content="Pod crashed due to OOM in payment-service at 3am",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Fixed by increasing memory limit",
    )

    # Store a procedural memory
    await memledger.add(
        content="How to fix OOM kills in Kubernetes pods",
        record_type=RecordType.PROCEDURAL,
        namespace=ns,
        steps=["Check pod limits", "Increase memory", "Restart"],
    )

    # Store a failure memory
    await memledger.add(
        content="Tried restarting pod without fixing memory limit — failed",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="failure",
    )

    context = await memledger.recall_context(
        query="pod OOM kill",
        namespace=ns,
        top_k=3,
    )

    assert context.has_results
    assert len(context.similar_episodes) >= 1
    assert len(context.suggested_procedures) >= 1
    # Failures matched via metadata filter
    summary = context.summary()
    assert "Similar Episodes" in summary or "Suggested Procedures" in summary


async def test_recall_context_empty(memledger: Memledger):
    """Composite retrieval returns empty when no memories exist."""
    ns = _unique_ns()

    context = await memledger.recall_context(
        query="something that was never stored",
        namespace=ns,
    )

    assert not context.has_results
    assert context.total_count == 0
    assert "No relevant memories" in context.summary()
