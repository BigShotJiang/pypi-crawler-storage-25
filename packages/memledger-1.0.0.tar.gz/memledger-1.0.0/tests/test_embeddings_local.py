"""Unit tests for the local (fastembed) embedding path.

Skipped automatically if fastembed isn't installed (i.e. on a clean
`pip install memledger` without the `[local]` extra). Run with:

    pip install memledger[local]
    pytest tests/test_embeddings_local.py

The Bedrock embedding path is exercised separately by the integration
tests under tests/test_composition_aws.py — both providers must stay
green per the workflow rule.
"""

from __future__ import annotations

import pytest

from memledger.embeddings import EmbeddingProvider
from memledger.models import EmbeddingConfig

fastembed = pytest.importorskip("fastembed")


@pytest.mark.asyncio
async def test_local_embedding_default_config():
    """Default EmbeddingConfig is the local fastembed path."""
    cfg = EmbeddingConfig()
    assert cfg.provider == "local"
    assert cfg.model == "BAAI/bge-small-en-v1.5"
    assert cfg.dimensions == 384


@pytest.mark.asyncio
async def test_local_embedding_shape():
    """fastembed returns vectors of the configured dimension."""
    provider = EmbeddingProvider(EmbeddingConfig())
    vectors = await provider.embed(["hello world", "memledger trust layer"])
    assert len(vectors) == 2
    assert all(len(v) == 384 for v in vectors)
    assert all(isinstance(x, float) for x in vectors[0])


@pytest.mark.asyncio
async def test_local_embedding_single():
    provider = EmbeddingProvider(EmbeddingConfig())
    vec = await provider.embed_single("single text")
    assert len(vec) == 384


@pytest.mark.asyncio
async def test_local_model_is_cached_across_instances():
    """Model load is expensive; second instance reuses the cached model."""
    EmbeddingProvider._local_model_cache.clear()
    p1 = EmbeddingProvider(EmbeddingConfig())
    await p1.embed(["warm up"])
    cache_size_after_first = len(EmbeddingProvider._local_model_cache)
    p2 = EmbeddingProvider(EmbeddingConfig())
    await p2.embed(["second instance"])
    assert len(EmbeddingProvider._local_model_cache) == cache_size_after_first
