"""B11 — namespace RBAC auto-enforcement in Memledger.add() and search().

Two test classes:

  TestRbacGateUnits — exercise the helpers (_check_rbac_or_raise,
    _rbac_filter_records) on a minimal Memledger-shaped harness. No
    DB required. Runs anywhere.

  TestRbacWireup — full end-to-end against pgvector. Skipped if
    ENGRAM_TEST_PG_DSN is not set; passes against the local docker
    pgvector container in dev.

v1 RBAC contract under test:
  - When RBAC is not configured: all operations allowed (no-op).
  - When RBAC is configured but agent_id is None: bypass.
  - When RBAC is configured AND agent_id is provided:
      add() raises NamespaceAccessDenied on forbidden write
      search() filters out denied records and logs an audit event
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.policies import (
    AccessRule,
    NamespacePolicy,
    NamespaceRBAC,
)
from memledger.memledger import NamespaceAccessDenied


def _build_rbac_team_a_only() -> NamespaceRBAC:
    """Allow only team-a agents to read+write /team-a/*; deny everyone else.

    NamespaceRBAC is default-allow when no policy matches — RBAC in v1 is
    opt-in. To express "deny all except /team-a/*" we add a root-pattern
    policy with deny-all defaults; the more-specific /team-a/* policy
    wins for those paths via the longest-prefix match in get_policy().
    """
    rbac = NamespaceRBAC()
    # Catch-all root: deny everything by default.
    rbac.set_policy(NamespacePolicy(
        namespace="*",
        rules=[AccessRule(agent_pattern="*", permissions=set())],
        default_permissions=set(),
    ))
    # Specific /team-a/* allows team-a-* agents to read+write; others denied.
    rbac.set_policy(NamespacePolicy(
        namespace="/team-a/*",
        rules=[
            AccessRule(agent_pattern="team-a-*", permissions={"read", "write"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    return rbac


# ──────────────────────────────────────────────────────────────────
# Unit tests against the helpers — no DB
# ──────────────────────────────────────────────────────────────────

class _StubMemledger:
    """Minimal stand-in for Memledger so the helper methods can be called."""
    def __init__(self, rbac):
        self._rbac = rbac
        from memledger.strategies.audit import AuditLog
        self.audit = AuditLog()

    # Pull the actual helpers off Memledger so we test the real code
    from memledger.memledger import (
        Memledger as _M,
    )
    _check_rbac_or_raise = _M._check_rbac_or_raise
    _rbac_filter_records = _M._rbac_filter_records


class TestRbacGateUnits:
    def test_no_rbac_configured_bypasses_everything(self):
        ml = _StubMemledger(rbac=None)
        # Should not raise even though "intruder" wouldn't be allowed.
        ml._check_rbac_or_raise("intruder", "/team-a/foo", "write")

    def test_no_agent_id_bypasses(self):
        rbac = _build_rbac_team_a_only()
        ml = _StubMemledger(rbac=rbac)
        # agent_id is None → bypass (preserves v0.4 behavior for callers
        # that don't pass an agent_id even when RBAC is configured).
        ml._check_rbac_or_raise(None, "/team-a/foo", "write")

    def test_write_denied_raises_typed_exception(self):
        rbac = _build_rbac_team_a_only()
        ml = _StubMemledger(rbac=rbac)
        with pytest.raises(NamespaceAccessDenied) as exc_info:
            ml._check_rbac_or_raise("team-b-agent", "/team-a/foo", "write")
        # Decision is attached to the exception for downstream handling.
        assert exc_info.value.decision.agent_id == "team-b-agent"
        assert exc_info.value.decision.namespace == "/team-a/foo"
        assert exc_info.value.decision.operation == "write"

    def test_write_allowed_no_raise(self):
        rbac = _build_rbac_team_a_only()
        ml = _StubMemledger(rbac=rbac)
        ml._check_rbac_or_raise("team-a-foo", "/team-a/bar", "write")  # no raise

    def test_read_filter_drops_denied_records(self):
        from types import SimpleNamespace
        rbac = _build_rbac_team_a_only()
        ml = _StubMemledger(rbac=rbac)
        recs = [
            SimpleNamespace(id="r1", namespace="/team-a/foo"),
            SimpleNamespace(id="r2", namespace="/team-b/secret"),
            SimpleNamespace(id="r3", namespace="/team-a/bar"),
        ]
        allowed, denied = ml._rbac_filter_records(recs, "team-a-agent")
        # Allowed within /team-a/*
        assert {r.id for r in allowed} == {"r1", "r3"}
        # Denied /team-b
        assert {r.id for r in denied} == {"r2"}

    def test_read_filter_noop_when_agent_id_missing(self):
        from types import SimpleNamespace
        rbac = _build_rbac_team_a_only()
        ml = _StubMemledger(rbac=rbac)
        recs = [SimpleNamespace(id="r1", namespace="/team-b/secret")]
        allowed, denied = ml._rbac_filter_records(recs, None)
        assert allowed == recs and denied == []


# ──────────────────────────────────────────────────────────────────
# Full wire-up — pgvector required
# ──────────────────────────────────────────────────────────────────

_DSN = os.environ.get("ENGRAM_TEST_PG_DSN", "")
_DSN_AVAILABLE = bool(_DSN)


@pytest_asyncio.fixture
async def ml_with_rbac():
    if not _DSN_AVAILABLE:
        pytest.skip("ENGRAM_TEST_PG_DSN not set")
    from memledger.memledger import Memledger
    from memledger.models import EmbeddingConfig

    rbac = _build_rbac_team_a_only()
    ml = await Memledger.create(
        backend_name="pgvector",
        backend_config={"connection_string": _DSN, "dimensions": 384},
        embedding_config=EmbeddingConfig(),
    )
    ml._rbac = rbac  # inject after create (Memledger.create doesn't take rbac kwarg today)
    yield ml
    await ml.close()


@pytest.mark.asyncio
@pytest.mark.skipif(not _DSN_AVAILABLE, reason="ENGRAM_TEST_PG_DSN not set")
async def test_forbidden_write_raises(ml_with_rbac):
    ml = ml_with_rbac
    with pytest.raises(NamespaceAccessDenied):
        await ml.add(
            content="secret memory",
            namespace="/team-a/inc-1",
            agent_id="team-b-agent",  # not allowed in /team-a/*
            confidence=0.9,
        )


@pytest.mark.asyncio
@pytest.mark.skipif(not _DSN_AVAILABLE, reason="ENGRAM_TEST_PG_DSN not set")
async def test_allowed_write_succeeds_and_search_filters_for_outsider(ml_with_rbac):
    ml = ml_with_rbac
    ns_unique = f"/team-a/{uuid.uuid4().hex[:8]}"
    # team-a-foo is allowed to write
    await ml.add(
        content="team-a internal note about HikariCP",
        namespace=ns_unique,
        agent_id="team-a-foo",
        confidence=0.9,
    )
    # team-b-agent must NOT see /team-a/* results
    result = await ml.search(
        query="HikariCP",
        agent_id="team-b-agent",
        top_k=10,
    )
    assert all(not r.namespace.startswith("/team-a/") for r in result.records)
