"""Unit tests for the Phoenix eval-logging helper.

The helper is intentionally best-effort and deployment-agnostic:
- no PHOENIX_BASE_URL / OTEL_EXPORTER_OTLP_ENDPOINT  → no-op
- arize-phoenix-client not installed                  → no-op
- no active OTEL span and no span_id arg              → no-op
- client.spans.add_span_annotation raises              → swallowed, returns False
- happy path                                          → calls add_span_annotation
                                                        with the expected args

These tests mock `phoenix.client.Client`; they do not require a running
Phoenix server.
"""

from __future__ import annotations

import importlib
import sys
import types
from unittest.mock import MagicMock

import pytest


def _reload_phoenix_helper(monkeypatch, env: dict[str, str]):
    """Reload the phoenix helper module with a fresh client cache + env."""
    for k in ("PHOENIX_BASE_URL", "PHOENIX_COLLECTOR_ENDPOINT", "OTEL_EXPORTER_OTLP_ENDPOINT", "PHOENIX_API_KEY"):
        monkeypatch.delenv(k, raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, v)
    if "memledger.telemetry.phoenix" in sys.modules:
        del sys.modules["memledger.telemetry.phoenix"]
    return importlib.import_module("memledger.telemetry.phoenix")


def test_log_evaluation_noop_when_no_endpoint(monkeypatch):
    phx = _reload_phoenix_helper(monkeypatch, env={})
    assert phx.log_evaluation("any", 0.5) is False


def test_log_evaluation_noop_when_client_missing(monkeypatch):
    """Simulate `arize-phoenix-client` not being installed."""
    # Insert a sentinel that raises ImportError when phoenix.client is imported.
    fake_phoenix = types.ModuleType("phoenix")
    monkeypatch.setitem(sys.modules, "phoenix", fake_phoenix)
    monkeypatch.delitem(sys.modules, "phoenix.client", raising=False)
    # Make `from phoenix.client import Client` raise ImportError.
    import builtins
    real_import = builtins.__import__

    def fake_import(name, *a, **kw):
        if name == "phoenix.client":
            raise ImportError("simulated: arize-phoenix-client not installed")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    phx = _reload_phoenix_helper(monkeypatch, env={"PHOENIX_BASE_URL": "http://x:6006"})
    assert phx.log_evaluation("any", 0.5) is False


def test_log_evaluation_noop_when_no_span(monkeypatch):
    """Endpoint set, client installed, but no active OTEL span and no span_id."""
    pytest.importorskip("phoenix.client")
    phx = _reload_phoenix_helper(monkeypatch, env={"PHOENIX_BASE_URL": "http://x:6006"})

    fake_client = MagicMock()
    monkeypatch.setattr(phx, "_get_client", lambda: fake_client)
    monkeypatch.setattr(phx, "_current_otel_span_id_hex", lambda: None)

    assert phx.log_evaluation("any", 0.5) is False
    fake_client.spans.add_span_annotation.assert_not_called()


def test_log_evaluation_happy_path_with_explicit_span_id(monkeypatch):
    pytest.importorskip("phoenix.client")
    phx = _reload_phoenix_helper(monkeypatch, env={"PHOENIX_BASE_URL": "http://x:6006"})

    fake_client = MagicMock()
    monkeypatch.setattr(phx, "_get_client", lambda: fake_client)

    ok = phx.log_evaluation(
        "memory_attribution_integrity",
        0.82,
        label="passed",
        explanation="ok",
        span_id="0123456789abcdef",
        annotator_kind="CODE",
        metadata={"k": "v"},
    )
    assert ok is True
    fake_client.spans.add_span_annotation.assert_called_once_with(
        span_id="0123456789abcdef",
        annotation_name="memory_attribution_integrity",
        annotator_kind="CODE",
        score=0.82,
        label="passed",
        explanation="ok",
        metadata={"k": "v"},
    )


def test_log_evaluation_swallows_client_exception(monkeypatch):
    pytest.importorskip("phoenix.client")
    phx = _reload_phoenix_helper(monkeypatch, env={"PHOENIX_BASE_URL": "http://x:6006"})

    fake_client = MagicMock()
    fake_client.spans.add_span_annotation.side_effect = RuntimeError("boom")
    monkeypatch.setattr(phx, "_get_client", lambda: fake_client)

    # Never raises; returns False.
    assert phx.log_evaluation("any", 0.5, span_id="0123456789abcdef") is False
