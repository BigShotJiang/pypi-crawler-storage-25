"""Tests for `memledger eval-report` chart generator."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

# Skip the entire module if matplotlib isn't installed — eval-report is
# behind the `memledger[eval]` extra and shouldn't break the rest of the suite
# for users who haven't installed it.
matplotlib = pytest.importorskip("matplotlib")

from memledger.cli.eval_report import (  # noqa: E402  (import after skip)
    ConfigStats,
    _color_for,
    _load_summary,
    _write_cost_chart,
    _write_latency_chart,
    _write_markdown_report,
    _write_success_chart,
)


def _write_summary(path: Path, entries: list[dict]) -> None:
    path.write_text(json.dumps(entries))


@pytest.fixture
def session_dir(tmp_path):
    """A fake session directory with a populated summary.json."""
    d = tmp_path / "fake-session"
    d.mkdir()
    _write_summary(
        d / "summary.json",
        [
            {
                "config_name": "no_memory",
                "reps": 30,
                "success_count": 21,
                "failure_count": 9,
                "success_rate": 0.7,
                "duration_p50": 240.0,
                "duration_p95": 480.0,
                "duration_mean": 270.0,
                "timeout_count": 0,
                "error_count": 9,
            },
            {
                "config_name": "deterministic",
                "reps": 30,
                "success_count": 27,
                "failure_count": 3,
                "success_rate": 0.9,
                "duration_p50": 245.0,
                "duration_p95": 470.0,
                "duration_mean": 260.0,
                "timeout_count": 0,
                "error_count": 3,
                "cost_total_usd": 0.012,
                "cost_total_input_tokens": 1234,
                "cost_total_output_tokens": 567,
            },
            {
                "config_name": "llm_sonnet",
                "reps": 30,
                "success_count": 28,
                "failure_count": 2,
                "success_rate": 0.9333,
                "duration_p50": 280.0,
                "duration_p95": 520.0,
                "duration_mean": 300.0,
                "timeout_count": 0,
                "error_count": 2,
                "cost_total_usd": 1.45,
                "cost_total_input_tokens": 50000,
                "cost_total_output_tokens": 15000,
            },
        ],
    )
    return d


# ── Loading ────────────────────────────────────────────────────────


def test_load_summary_parses_all_fields(session_dir):
    stats = _load_summary(session_dir)
    assert len(stats) == 3
    assert stats[0].name == "no_memory"
    assert stats[0].cost_total_usd is None
    assert stats[1].cost_total_usd == 0.012
    assert stats[2].success_rate > 0.93


def test_load_summary_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        _load_summary(tmp_path)


def test_load_summary_wrong_shape(tmp_path):
    d = tmp_path / "bad"
    d.mkdir()
    (d / "summary.json").write_text('{"not": "a list"}')
    with pytest.raises(ValueError):
        _load_summary(d)


# ── Color picker ───────────────────────────────────────────────────


def test_color_for_known_names():
    assert _color_for("no_memory", 0) == "#8b94a8"
    assert _color_for("deterministic", 1) == "#7aa2f7"
    assert _color_for("llm_sonnet", 2) == "#bb9af7"


def test_color_for_prefix_match():
    # llm_anything_else should fall back to the llm color group
    color = _color_for("llm_haiku", 0)
    assert color == "#9ece6a"


def test_color_for_unknown_falls_back():
    c0 = _color_for("totally_unknown_config", 0)
    c1 = _color_for("another_unknown", 1)
    # Both should be valid hex colors from the fallback palette
    assert c0.startswith("#")
    assert c1.startswith("#")


# ── Chart writers ──────────────────────────────────────────────────


def test_success_chart_writes_png(session_dir, tmp_path):
    stats = _load_summary(session_dir)
    out = tmp_path / "s.png"
    _write_success_chart(stats, out)
    assert out.exists()
    assert out.stat().st_size > 1000  # PNG should be at least 1KB


def test_latency_chart_writes_png(session_dir, tmp_path):
    stats = _load_summary(session_dir)
    out = tmp_path / "l.png"
    _write_latency_chart(stats, out)
    assert out.exists()
    assert out.stat().st_size > 1000


def test_cost_chart_writes_when_data_present(session_dir, tmp_path):
    stats = _load_summary(session_dir)
    out = tmp_path / "c.png"
    written = _write_cost_chart(stats, out)
    assert written is True
    assert out.exists()


def test_cost_chart_skipped_when_no_data(tmp_path):
    stats = [
        ConfigStats(
            name="no_memory",
            reps=10,
            success_rate=1.0,
            success_count=10,
            failure_count=0,
            duration_p50=1.0,
            duration_p95=2.0,
            duration_mean=1.5,
            timeout_count=0,
            error_count=0,
            cost_total_usd=None,
        ),
    ]
    out = tmp_path / "c.png"
    written = _write_cost_chart(stats, out)
    assert written is False
    assert not out.exists()


# ── Markdown report ────────────────────────────────────────────────


def test_markdown_report_includes_all_configs(session_dir, tmp_path):
    stats = _load_summary(session_dir)
    out_dir = tmp_path / "out"
    out_dir.mkdir()
    md_path = _write_markdown_report(session_dir, out_dir, stats, cost_chart_written=True)
    assert md_path.exists()
    text = md_path.read_text()
    assert "no_memory" in text
    assert "deterministic" in text
    assert "llm_sonnet" in text
    assert "70.0%" in text  # no_memory success rate
    assert "$0.0120" in text or "$0.012" in text  # deterministic cost
    assert "![Cost](cost.png)" in text


def test_markdown_report_omits_cost_image_when_no_cost(session_dir, tmp_path):
    stats = _load_summary(session_dir)
    out_dir = tmp_path / "out"
    out_dir.mkdir()
    md_path = _write_markdown_report(session_dir, out_dir, stats, cost_chart_written=False)
    text = md_path.read_text()
    assert "![Cost]" not in text
    # Success and latency are still there
    assert "![Success rate]" in text
    assert "![Latency]" in text
