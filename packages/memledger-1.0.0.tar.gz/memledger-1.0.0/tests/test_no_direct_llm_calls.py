"""B1 invariant: core memledger code routes every LLM/embedding call
through LiteLLM (via memledger.embeddings or memledger.strategies.llm).

Direct usage of provider SDKs is forbidden inside `src/memledger/` —
the user picks the provider via a LiteLLM model string, not by which
library is installed.

Allowed exceptions:
- `src/memledger/backends/dynamodb.py`  — storage backend, boto3 for DynamoDB
- `src/memledger/backends/opensearch.py` — storage backend, boto3 for SigV4 auth

This test does a static AST + text scan; it does not import any code,
so it stays cheap and dependency-light. If a regression sneaks in,
this test fails loudly with the offending file and line.
"""

from __future__ import annotations

import ast
from pathlib import Path

SRC_ROOT = Path(__file__).resolve().parent.parent / "src" / "memledger"

# Files where boto3 is legitimate (storage backends, not LLM/embedding).
BOTO3_ALLOWLIST = {
    SRC_ROOT / "backends" / "dynamodb.py",
    SRC_ROOT / "backends" / "opensearch.py",
}

FORBIDDEN_IMPORTS = {
    "openai",
    "anthropic",
    "langchain_aws",
    "google.generativeai",
    "cohere",
    "mistralai",
}

FORBIDDEN_STRING_LITERALS = (
    "bedrock-runtime",
    "bedrock-agent-runtime",
    "bedrock-agentcore",
    "bedrock-agentcore-control",
)


def _all_src_files():
    return sorted(p for p in SRC_ROOT.rglob("*.py") if "__pycache__" not in p.parts)


def test_no_forbidden_provider_imports():
    """No direct OpenAI/Anthropic/langchain_aws/etc imports anywhere in src/memledger/."""
    violations = []
    for py in _all_src_files():
        tree = ast.parse(py.read_text(), filename=str(py))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    if root in FORBIDDEN_IMPORTS or alias.name in FORBIDDEN_IMPORTS:
                        violations.append(f"{py.relative_to(SRC_ROOT.parent.parent)}:{node.lineno} `import {alias.name}`")
            elif isinstance(node, ast.ImportFrom) and node.module:
                root = node.module.split(".")[0]
                if root in FORBIDDEN_IMPORTS or node.module in FORBIDDEN_IMPORTS:
                    violations.append(f"{py.relative_to(SRC_ROOT.parent.parent)}:{node.lineno} `from {node.module} import ...`")
    assert not violations, (
        "Direct LLM-provider imports are forbidden in core memledger code; "
        "route through LiteLLM via memledger.embeddings / memledger.strategies.llm.\n  - "
        + "\n  - ".join(violations)
    )


def test_no_boto3_outside_storage_backends():
    """boto3 may appear only in DynamoDB / OpenSearch storage backends."""
    violations = []
    for py in _all_src_files():
        if py in BOTO3_ALLOWLIST:
            continue
        tree = ast.parse(py.read_text(), filename=str(py))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "boto3" or alias.name.startswith("boto3."):
                        violations.append(f"{py.relative_to(SRC_ROOT.parent.parent)}:{node.lineno} `import {alias.name}`")
            elif isinstance(node, ast.ImportFrom) and node.module == "boto3":
                violations.append(f"{py.relative_to(SRC_ROOT.parent.parent)}:{node.lineno} `from boto3 import ...`")
    assert not violations, (
        "boto3 may only appear in storage backends (dynamodb.py, opensearch.py); "
        "LLM/embedding calls must route through LiteLLM.\n  - "
        + "\n  - ".join(violations)
    )


def test_no_bedrock_service_strings_outside_storage_backends():
    """No `bedrock-runtime` / `bedrock-agentcore` service-name strings in non-backend code."""
    violations = []
    for py in _all_src_files():
        if py in BOTO3_ALLOWLIST:
            continue
        text = py.read_text()
        for needle in FORBIDDEN_STRING_LITERALS:
            if needle in text:
                # Find first line number for the error message
                for i, line in enumerate(text.splitlines(), 1):
                    if needle in line:
                        violations.append(f"{py.relative_to(SRC_ROOT.parent.parent)}:{i} contains '{needle}'")
                        break
    assert not violations, (
        "Bedrock service-name strings indicate a direct AWS call bypassing LiteLLM.\n  - "
        + "\n  - ".join(violations)
    )
