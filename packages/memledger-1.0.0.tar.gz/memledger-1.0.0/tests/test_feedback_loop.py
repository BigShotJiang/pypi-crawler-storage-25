"""Integration test: the feedback loop — memory as a learning system.

Validates the core thesis from the book (Ch6):
  Store → Recall → Use → Record Outcome → Future Recall Ranks Better

This test proves that record_outcome() feeds back into scoring
and changes retrieval ranking over time.
"""

from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio

from memledger.memledger import Memledger
from memledger.models import EmbeddingConfig, RecordType
from memledger.strategies.scoring import compute_final_score

CONN_STRING = os.environ.get(
    "ENGRAM_TEST_PG_DSN",
    "postgresql://localhost:5432/memledger_test",
)

EMBEDDING_CONFIG = EmbeddingConfig(
    provider="local",
    model="BAAI/bge-small-en-v1.5",
    dimensions=384,
)

pytestmark = pytest.mark.asyncio


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger():
    e = await Memledger.create(
        backend_name="pgvector",
        connection_string=CONN_STRING,
        embedding_config=EMBEDDING_CONFIG,
    )
    yield e
    await e.close()


async def test_feedback_loop_improves_ranking(memledger: Memledger):
    """The core feedback loop: outcomes change future retrieval ranking.

    Three memories about the same topic are stored. After recording
    different outcomes, the proven memory should rank higher than
    the unproven one, even though cosine similarity is similar.
    """
    ns = _unique_ns()

    # Step 1: Store 3 memories about the same topic (similar cosine scores)
    id_proven = await memledger.add(
        content="Fix OOM kills by setting maxPoolSize=50 in HikariCP configuration",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="success",
    )

    id_mixed = await memledger.add(
        content="Fix OOM kills by increasing pod memory limits to 2Gi",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="partial",
    )

    id_unproven = await memledger.add(
        content="Fix OOM kills by restarting the pod and monitoring",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="unknown",
    )

    # Step 2: Record outcomes — simulate the agent using these memories
    # Memory A: used 5 times, all successful
    for _ in range(5):
        await memledger.record_outcome(id_proven, success=True)

    # Memory B: used 5 times, mixed results
    for _ in range(3):
        await memledger.record_outcome(id_mixed, success=True)
    for _ in range(2):
        await memledger.record_outcome(id_mixed, success=False)

    # Memory C: never used — no outcome data

    # Step 3: Verify the outcome data was recorded
    proven = await memledger.get(id_proven)
    mixed = await memledger.get(id_mixed)
    unproven = await memledger.get(id_unproven)

    assert proven.success_count == 5
    assert proven.failure_count == 0
    assert mixed.success_count == 3
    assert mixed.failure_count == 2
    assert unproven.success_count == 0
    assert unproven.failure_count == 0

    # Step 4: Compute policy scores — proven should score highest
    score_proven = compute_final_score(
        cosine_score=0.85,
        access_count=proven.access_count,
        success_count=proven.success_count,
        failure_count=proven.failure_count,
        last_accessed_at=proven.last_accessed_at,
        importance=proven.importance,
    )

    score_mixed = compute_final_score(
        cosine_score=0.85,  # same cosine
        access_count=mixed.access_count,
        success_count=mixed.success_count,
        failure_count=mixed.failure_count,
        last_accessed_at=mixed.last_accessed_at,
        importance=mixed.importance,
    )

    score_unproven = compute_final_score(
        cosine_score=0.85,  # same cosine
        access_count=unproven.access_count,
        success_count=unproven.success_count,
        failure_count=unproven.failure_count,
        last_accessed_at=unproven.last_accessed_at,
        importance=unproven.importance,
    )

    # Proven (5/5 success) should rank higher than mixed (3/5) and unproven (0/0)
    assert score_proven > score_mixed, f"Proven ({score_proven:.3f}) should rank higher than mixed ({score_mixed:.3f})"
    assert score_proven > score_unproven, (
        f"Proven ({score_proven:.3f}) should rank higher than unproven ({score_unproven:.3f})"
    )


async def test_feedback_loop_demotes_failures(memledger: Memledger):
    """Memories that consistently lead to failures should rank lower."""
    ns = _unique_ns()

    id_good = await memledger.add(
        content="Resolve connection timeout by adjusting pool settings",
        namespace=ns,
    )
    id_bad = await memledger.add(
        content="Resolve connection timeout by restarting all pods",
        namespace=ns,
    )

    # Good memory: 4 successes
    for _ in range(4):
        await memledger.record_outcome(id_good, success=True)

    # Bad memory: 4 failures
    for _ in range(4):
        await memledger.record_outcome(id_bad, success=False)

    good = await memledger.get(id_good)
    bad = await memledger.get(id_bad)

    score_good = compute_final_score(
        cosine_score=0.80,
        access_count=good.access_count,
        success_count=good.success_count,
        failure_count=good.failure_count,
        last_accessed_at=good.last_accessed_at,
        importance=good.importance,
    )
    score_bad = compute_final_score(
        cosine_score=0.80,
        access_count=bad.access_count,
        success_count=bad.success_count,
        failure_count=bad.failure_count,
        last_accessed_at=bad.last_accessed_at,
        importance=bad.importance,
    )

    assert score_good > score_bad, (
        f"Good memory ({score_good:.3f}) should rank higher than bad memory ({score_bad:.3f})"
    )


async def test_importance_emerges_from_usage(memledger: Memledger):
    """Importance should shift from the write-time hint to usage evidence."""
    ns = _unique_ns()

    # Store with low importance hint but it will be used successfully
    record_id = await memledger.add(
        content="Use kubectl drain before node maintenance",
        namespace=ns,
        importance=0.3,  # low initial hint
    )

    # Simulate heavy successful usage
    for _ in range(10):
        await memledger.record_outcome(record_id, success=True)

    record = await memledger.get(record_id)

    # With 10 successes and 0 failures, effective importance should be high
    # despite the low initial hint of 0.3
    from memledger.strategies.scoring import _importance_score

    effective = _importance_score(
        importance_hint=record.importance,
        access_count=record.access_count,
        success_count=record.success_count,
        failure_count=record.failure_count,
    )

    # Effective importance should be much higher than the 0.3 hint
    # because usage evidence (10/10 = 1.0 success rate) overrides it
    assert effective > 0.6, (
        f"Effective importance ({effective:.3f}) should be > 0.6 "
        f"despite hint of 0.3, because 10/10 success rate should override"
    )


async def test_access_count_tracks_searches(memledger: Memledger):
    """Every search that returns a memory should increment its access_count."""
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Access tracking validation memory",
        namespace=ns,
    )

    # Search 3 times — each should increment access_count
    for _ in range(3):
        await memledger.search(query="access tracking", namespace=ns, top_k=1)

    record = await memledger.get(record_id)
    assert record.access_count >= 3, f"Expected access_count >= 3 after 3 searches, got {record.access_count}"
    assert record.last_accessed_at is not None, "last_accessed_at should be set after searches"
