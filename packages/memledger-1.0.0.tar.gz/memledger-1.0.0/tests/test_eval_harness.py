"""Tests for the memledger eval harness CLI internals.

Covers scoring functions, JSON loading, summarization, markdown rendering,
and an end-to-end async session driven by a fake shell-script runner.
"""

from __future__ import annotations

import pytest

from memledger.cli.eval import (
    ConfigSummary,
    RunResult,
    SessionResult,
    _expand_env,
    _render_markdown,
    _run_session,
    _score_files_exist,
    _score_files_valid_json,
    _score_run,
    _summarize,
)

# ── Scoring tests ──────────────────────────────────────────────────


class TestFilesExist:
    def test_all_present(self, tmp_path):
        (tmp_path / "a.json").write_text('{"a": 1}')
        (tmp_path / "b.json").write_text('{"b": 2}')
        success, reason, details = _score_files_exist(tmp_path, {"required_files": ["a.json", "b.json"]})
        assert success is True
        assert "all required" in reason
        assert details["sizes"] == {"a.json": 8, "b.json": 8}

    def test_missing_file(self, tmp_path):
        (tmp_path / "a.json").write_text('{"a": 1}')
        success, reason, details = _score_files_exist(tmp_path, {"required_files": ["a.json", "b.json"]})
        assert success is False
        assert "b.json" in reason
        assert details["missing"] == ["b.json"]

    def test_too_small(self, tmp_path):
        (tmp_path / "a.json").write_text("x")  # 1 byte
        success, reason, details = _score_files_exist(tmp_path, {"required_files": ["a.json"], "min_size_bytes": 100})
        assert success is False
        assert "too small" in reason

    def test_no_required_files(self, tmp_path):
        success, reason, _ = _score_files_exist(tmp_path, {})
        assert success is False


class TestFilesValidJson:
    def test_valid_dict(self, tmp_path):
        (tmp_path / "a.json").write_text('{"k": "v"}')
        success, _, details = _score_files_valid_json(tmp_path, {"required_files": ["a.json"], "min_records": 1})
        assert success is True
        assert details["counts"]["a.json"] == 1

    def test_valid_list_with_min(self, tmp_path):
        (tmp_path / "a.json").write_text("[1, 2, 3, 4, 5]")
        success, _, _ = _score_files_valid_json(tmp_path, {"required_files": ["a.json"], "min_records": 5})
        assert success is True

    def test_invalid_json(self, tmp_path):
        (tmp_path / "a.json").write_text("not json")
        success, _, details = _score_files_valid_json(tmp_path, {"required_files": ["a.json"]})
        assert success is False
        assert details["invalid"][0]["file"] == "a.json"

    def test_too_few_records(self, tmp_path):
        (tmp_path / "a.json").write_text("[1, 2]")
        success, _, _ = _score_files_valid_json(tmp_path, {"required_files": ["a.json"], "min_records": 5})
        assert success is False


class TestScoreRunDispatch:
    def test_files_exist(self, tmp_path):
        (tmp_path / "a.json").write_text("{}")
        success, _, _ = _score_run(tmp_path, {"type": "files_exist", "required_files": ["a.json"]})
        assert success is True

    def test_unknown_type(self, tmp_path):
        success, reason, _ = _score_run(tmp_path, {"type": "made_up"})
        assert success is False
        assert "unknown" in reason.lower()


# ── Env expansion ──────────────────────────────────────────────────


class TestExpandEnv:
    def test_simple(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "hello")
        assert _expand_env("path=${MY_VAR}/x") == "path=hello/x"

    def test_default(self, monkeypatch):
        monkeypatch.delenv("MISSING_VAR", raising=False)
        assert _expand_env("${MISSING_VAR:fallback}") == "fallback"

    def test_unset_no_default(self, monkeypatch):
        monkeypatch.delenv("MISSING_VAR", raising=False)
        # No default → leave the placeholder as-is
        assert _expand_env("${MISSING_VAR}") == "${MISSING_VAR}"


# ── Summarization ──────────────────────────────────────────────────


def _mk_run(name: str, idx: int, success: bool, dur: float, **extra) -> RunResult:
    return RunResult(
        config_name=name,
        rep_index=idx,
        run_id=f"{name}-{idx}",
        output_dir="/tmp/x",
        started_at="2026-04-09T00:00:00+00:00",
        finished_at="2026-04-09T00:00:01+00:00",
        duration_seconds=dur,
        exit_code=0 if success else 1,
        timed_out=False,
        timeout_seconds=60.0,
        success=success,
        success_reason="ok" if success else "fail",
        **extra,
    )


class TestSummarize:
    def test_empty(self):
        s = _summarize("none", [])
        assert s.reps == 0
        assert s.success_rate == 0.0

    def test_all_success(self):
        runs = [_mk_run("c", i, True, 1.0 + i * 0.5) for i in range(5)]
        s = _summarize("c", runs)
        assert s.reps == 5
        assert s.success_count == 5
        assert s.success_rate == 1.0
        assert s.duration_p50 == 2.0

    def test_mixed(self):
        runs = [
            _mk_run("c", 0, True, 1.0),
            _mk_run("c", 1, False, 2.0),
            _mk_run("c", 2, True, 1.5),
        ]
        s = _summarize("c", runs)
        assert s.success_count == 2
        assert s.failure_count == 1
        assert abs(s.success_rate - 0.6667) < 0.001

    def test_cost_aggregation(self):
        runs = [
            _mk_run(
                "c",
                0,
                True,
                1.0,
                cost={"input_tokens": 100, "output_tokens": 50, "total_usd": 0.001},
            ),
            _mk_run(
                "c",
                1,
                True,
                1.0,
                cost={"input_tokens": 200, "output_tokens": 100, "total_usd": 0.002},
            ),
        ]
        s = _summarize("c", runs)
        assert s.cost_total_usd == 0.003
        assert s.cost_total_input_tokens == 300
        assert s.cost_total_output_tokens == 150

    def test_no_cost_data(self):
        runs = [_mk_run("c", 0, True, 1.0)]
        s = _summarize("c", runs)
        assert s.cost_total_usd is None


# ── Markdown rendering ────────────────────────────────────────────


class TestMarkdownRendering:
    def test_includes_summary_table(self):
        session = SessionResult(
            session_id="test",
            started_at="2026-04-09T00:00:00+00:00",
            finished_at="2026-04-09T00:00:01+00:00",
            task_spec_path="/x.yaml",
            eval_config_path="/y.yaml",
            total_runs=2,
            summaries=[
                ConfigSummary(
                    config_name="alpha",
                    reps=2,
                    success_count=2,
                    failure_count=0,
                    success_rate=1.0,
                    duration_p50=1.0,
                    duration_p95=1.5,
                    duration_mean=1.2,
                    timeout_count=0,
                    error_count=0,
                ),
            ],
            runs=[],
        )
        md = _render_markdown(session)
        assert "# Memledger eval session" in md
        assert "| alpha |" in md
        assert "100.0%" in md
        assert "no failures" in md


# ── End-to-end async session ───────────────────────────────────────


class TestRunSessionEndToEnd:
    @pytest.mark.asyncio
    async def test_fake_runner_two_configs(self, tmp_path):
        """Drive _run_session with a tiny fake script and two configurations."""
        # Fake shell runner — emits two files into RUN_OUTPUT_DIR
        runner_path = tmp_path / "fake.sh"
        runner_path.write_text(
            "#!/usr/bin/env bash\n"
            "set -e\n"
            'echo "{\\"x\\": 1}" > "$RUN_OUTPUT_DIR/a.json"\n'
            'echo "{\\"y\\": 2}" > "$RUN_OUTPUT_DIR/b.json"\n'
            "exit 0\n"
        )
        runner_path.chmod(0o755)

        task_spec = {
            "runner": {
                "command": [str(runner_path)],
                "timeout_seconds": 10,
            },
            "success_criteria": {
                "type": "files_exist",
                "required_files": ["a.json", "b.json"],
                "min_size_bytes": 1,
            },
        }
        eval_config = {
            "reps_per_config": 2,
            "configurations": {
                "no_memory": {"env": {"ENABLE_MEMORY": "false"}},
                "deterministic": {"env": {"ENABLE_MEMORY": "true"}},
            },
        }

        out_root = tmp_path / "out"
        session = await _run_session(
            task_spec=task_spec,
            eval_config=eval_config,
            output_root=out_root,
            task_spec_path="task.yaml",
            eval_config_path="eval.yaml",
        )

        assert session.total_runs == 4
        assert len(session.summaries) == 2
        for s in session.summaries:
            assert s.success_count == 2
            assert s.failure_count == 0

        # Persisted artifacts
        session_dir = out_root / session.session_id
        assert (session_dir / "results.json").exists()
        assert (session_dir / "summary.json").exists()
        assert (session_dir / "report.md").exists()

        # report.md is non-trivial
        report = (session_dir / "report.md").read_text()
        assert "no_memory" in report
        assert "deterministic" in report

    @pytest.mark.asyncio
    async def test_failure_scoring(self, tmp_path):
        """A runner that doesn't write the expected files should be scored failed."""
        runner_path = tmp_path / "noop.sh"
        runner_path.write_text("#!/usr/bin/env bash\nexit 0\n")
        runner_path.chmod(0o755)

        task_spec = {
            "runner": {"command": [str(runner_path)], "timeout_seconds": 10},
            "success_criteria": {
                "type": "files_exist",
                "required_files": ["nope.json"],
            },
        }
        eval_config = {
            "reps_per_config": 1,
            "configurations": {"only": {"env": {}}},
        }

        session = await _run_session(
            task_spec=task_spec,
            eval_config=eval_config,
            output_root=tmp_path / "out",
            task_spec_path="t.yaml",
            eval_config_path="e.yaml",
        )

        assert session.total_runs == 1
        assert session.summaries[0].success_count == 0
        assert session.summaries[0].failure_count == 1
        assert "nope.json" in session.runs[0].success_reason

    @pytest.mark.asyncio
    async def test_runner_not_found(self, tmp_path):
        task_spec = {
            "runner": {"command": ["/does/not/exist/runner"], "timeout_seconds": 10},
            "success_criteria": {
                "type": "files_exist",
                "required_files": ["x.json"],
            },
        }
        eval_config = {
            "reps_per_config": 1,
            "configurations": {"only": {"env": {}}},
        }
        session = await _run_session(
            task_spec=task_spec,
            eval_config=eval_config,
            output_root=tmp_path / "out",
            task_spec_path="t.yaml",
            eval_config_path="e.yaml",
        )
        assert session.total_runs == 1
        assert session.runs[0].success is False
        assert "not found" in session.runs[0].success_reason
