"""B2 invariant: pgvector is the default required backend for v1.

Anyone changing the default config to point at a different backend (sqlite,
dynamodb, opensearch, …) must update this test deliberately — and re-read
the v1 backend contract in docs/architecture.md before doing so.
"""

from __future__ import annotations

from memledger.models import EmbeddingConfig, MemledgerConfig


def test_default_backend_is_pgvector():
    """MemledgerConfig() must default to pgvector — the v1 OSS contract."""
    cfg = MemledgerConfig()
    assert cfg.default_backend == "pgvector", (
        f"v1 contract violation: default_backend is {cfg.default_backend!r}, "
        "expected 'pgvector'. See docs/architecture.md#memory-backend-contract-v1."
    )


def test_default_embedding_is_local():
    """Pair invariant from A3: default embedding is the local fastembed path
    (no cloud credentials required for `pip install memledger[local,pgvector]`)."""
    cfg = MemledgerConfig()
    assert cfg.embeddings.provider == "local"
    assert cfg.embeddings.dimensions == 384
    assert cfg.embeddings.model == "BAAI/bge-small-en-v1.5"


def test_default_embedding_config_standalone():
    """EmbeddingConfig() defaults independently match — guards against drift
    between MemledgerConfig.embeddings and bare EmbeddingConfig()."""
    e = EmbeddingConfig()
    assert e.provider == "local"
    assert e.dimensions == 384
