"""Unit tests for memledger models — no database required."""

from __future__ import annotations

from datetime import datetime, timezone

from memledger.models import (
    EpisodicRecord,
    MemoryRecord,
    ProceduralRecord,
    RecordType,
    SemanticRecord,
    record_from_dict,
)


def test_memory_record_defaults():
    record = MemoryRecord(content="test")
    assert record.record_type == RecordType.SEMANTIC
    assert record.namespace == "/"
    assert record.metadata == {}
    assert record.id  # auto-generated UUID


def test_semantic_record():
    record = SemanticRecord(
        content="Postgres default max_connections is 100",
        source="docs",
        confidence=0.9,
    )
    assert record.record_type == RecordType.SEMANTIC
    assert record.source == "docs"
    assert record.confidence == 0.9


def test_episodic_record():
    event_time = datetime(2026, 3, 15, tzinfo=timezone.utc)
    record = EpisodicRecord(
        content="Pod crash event",
        event_time=event_time,
        duration_ms=5000,
        outcome="Restarted",
        actors=["sre-agent"],
    )
    assert record.record_type == RecordType.EPISODIC
    assert record.event_time == event_time
    assert record.actors == ["sre-agent"]


def test_procedural_record():
    record = ProceduralRecord(
        content="How to rollback",
        steps=["step 1", "step 2"],
        preconditions=["helm access"],
        tools_required=["helm", "kubectl"],
    )
    assert record.record_type == RecordType.PROCEDURAL
    assert len(record.steps) == 2
    assert "helm" in record.tools_required


def test_record_from_dict_semantic():
    data = {"content": "a fact", "record_type": "semantic", "source": "docs"}
    record = record_from_dict(data)
    assert isinstance(record, SemanticRecord)
    assert record.source == "docs"


def test_record_from_dict_episodic():
    data = {"content": "an event", "record_type": "episodic", "outcome": "resolved"}
    record = record_from_dict(data)
    assert isinstance(record, EpisodicRecord)
    assert record.outcome == "resolved"


def test_record_from_dict_procedural():
    data = {
        "content": "a procedure",
        "record_type": "procedural",
        "steps": ["do this", "then that"],
    }
    record = record_from_dict(data)
    assert isinstance(record, ProceduralRecord)
    assert record.steps == ["do this", "then that"]


def test_record_from_dict_default():
    data = {"content": "plain record"}
    record = record_from_dict(data)
    assert isinstance(record, SemanticRecord)


def test_record_serialization():
    record = EpisodicRecord(
        content="test event",
        event_time=datetime(2026, 1, 1, tzinfo=timezone.utc),
        actors=["agent-1"],
    )
    data = record.model_dump()
    assert data["record_type"] == RecordType.EPISODIC
    assert data["actors"] == ["agent-1"]

    # Round-trip
    restored = record_from_dict(data)
    assert isinstance(restored, EpisodicRecord)
    assert restored.content == "test event"
