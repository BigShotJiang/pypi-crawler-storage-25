"""Integration test: SQLite backend — fully offline, no cloud dependencies.

Uses a fake embedder (deterministic hash-based vectors) so tests
run without any API keys or network access.
"""

from __future__ import annotations

import hashlib
import uuid

import pytest
import pytest_asyncio

from memledger.embeddings import EmbeddingProvider
from memledger.memledger import Memledger
from memledger.models import EmbeddingConfig, RecordType

pytestmark = pytest.mark.asyncio


class FakeEmbedder(EmbeddingProvider):
    """Deterministic hash-based embedder for testing. No API calls."""

    def __init__(self, dimensions: int = 64):
        config = EmbeddingConfig(provider="fake", model="fake", dimensions=dimensions)
        super().__init__(config)
        self._dimensions = dimensions

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._hash_embed(t) for t in texts]

    async def embed_single(self, text: str) -> list[float]:
        return self._hash_embed(text)

    def _hash_embed(self, text: str) -> list[float]:
        h = hashlib.sha256(text.encode()).digest()
        # Expand hash to fill dimensions
        raw = h * ((self._dimensions * 4 // len(h)) + 1)
        import struct

        values = struct.unpack(f"{self._dimensions}f", raw[: self._dimensions * 4])
        # Normalize to unit vector
        norm = max(sum(v * v for v in values) ** 0.5, 1e-10)
        return [v / norm for v in values]


def _unique_ns() -> str:
    return f"/test/{uuid.uuid4().hex[:8]}"


@pytest_asyncio.fixture
async def memledger(tmp_path):
    """Create memledger with SQLite backend and fake embedder."""
    db_path = str(tmp_path / "test_memory.db")

    e = await Memledger.create(
        backend_name="sqlite",
        backend_config={"path": db_path, "dimensions": 64},
        embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=64),
    )
    # Replace embedder with fake
    e._embedder = FakeEmbedder(dimensions=64)
    yield e
    await e.close()


async def test_add_and_search(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(
        content="OOM kills in payment-service caused by connection pool leak",
        namespace=ns,
        metadata={"severity": "P1"},
    )
    assert record_id

    results = await memledger.search(
        query="OOM kills in payment-service caused by connection pool leak",
        namespace=ns,
        top_k=3,
    )
    assert len(results.records) >= 1
    assert results.records[0].id == record_id


async def test_namespace_isolation(memledger: Memledger):
    ns_a = _unique_ns()
    ns_b = _unique_ns()

    await memledger.add(content="Secret in namespace A", namespace=ns_a)
    await memledger.add(content="Secret in namespace B", namespace=ns_b)

    results = await memledger.search(query="Secret in namespace A", namespace=ns_a, top_k=5)
    assert all(r.namespace.startswith(ns_a) for r in results.records)


async def test_typed_records(memledger: Memledger):
    ns = _unique_ns()

    # Semantic
    sid = await memledger.add(
        content="HikariCP default pool size is 10",
        record_type=RecordType.SEMANTIC,
        namespace=ns,
        source="docs",
    )
    rec = await memledger.get(sid)
    assert rec.record_type == RecordType.SEMANTIC

    # Episodic
    eid = await memledger.add(
        content="Pod crashed at 3am",
        record_type=RecordType.EPISODIC,
        namespace=ns,
        outcome="Fixed by restart",
    )
    rec = await memledger.get(eid)
    assert rec.record_type == RecordType.EPISODIC
    assert rec.outcome == "Fixed by restart"

    # Procedural
    pid = await memledger.add(
        content="How to fix OOM",
        record_type=RecordType.PROCEDURAL,
        namespace=ns,
        steps=["Check limits", "Increase memory"],
    )
    rec = await memledger.get(pid)
    assert rec.record_type == RecordType.PROCEDURAL
    assert len(rec.steps) == 2


async def test_update_and_delete(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(
        content="Test record",
        namespace=ns,
        metadata={"status": "new"},
    )

    updated = await memledger.update(record_id, metadata={"status": "reviewed"})
    assert updated is True

    record = await memledger.get(record_id)
    assert record.metadata["status"] == "reviewed"

    deleted = await memledger.delete(record_id)
    assert deleted is True

    # Soft delete: record still exists but status is archived
    archived = await memledger.get(record_id)
    assert archived is not None
    assert archived.status.value == "archived"


async def test_access_tracking(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(content="Access test", namespace=ns)

    await memledger.search(query="Access test", namespace=ns, top_k=1)
    await memledger.search(query="Access test", namespace=ns, top_k=1)

    record = await memledger.get(record_id)
    assert record.access_count >= 2


async def test_record_outcome(memledger: Memledger):
    ns = _unique_ns()

    record_id = await memledger.add(content="Outcome test", namespace=ns)

    await memledger.record_outcome(record_id, success=True)
    await memledger.record_outcome(record_id, success=False)

    record = await memledger.get(record_id)
    assert record.success_count == 1
    assert record.failure_count == 1


async def test_list_namespaces(memledger: Memledger):
    ns1 = _unique_ns()
    ns2 = _unique_ns()

    await memledger.add(content="In ns1", namespace=ns1)
    await memledger.add(content="In ns2", namespace=ns2)

    namespaces = await memledger.list_namespaces()
    assert ns1 in namespaces
    assert ns2 in namespaces


async def test_stats(memledger: Memledger):
    ns = _unique_ns()

    await memledger.add(content="Fact 1", record_type=RecordType.SEMANTIC, namespace=ns)
    await memledger.add(content="Event 1", record_type=RecordType.EPISODIC, namespace=ns)

    stats = await memledger.stats(namespace=ns)
    assert stats["total_count"] == 2
    assert stats["by_record_type"].get("semantic", 0) >= 1
    assert stats["by_record_type"].get("episodic", 0) >= 1


async def test_health_check(memledger: Memledger):
    assert await memledger.health() is True


async def test_context_manager(tmp_path):
    db_path = str(tmp_path / "ctx_test.db")

    async with await Memledger.create(
        backend_name="sqlite",
        backend_config={"path": db_path, "dimensions": 64},
        embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=64),
    ) as eng:
        eng._embedder = FakeEmbedder(dimensions=64)
        ns = _unique_ns()
        rid = await eng.add(content="Context manager test", namespace=ns)
        assert rid
