"""B5 CI gate: the deterministic MAI scorer must agree with the golden
dataset's extreme-class labels and clear an overall-accuracy floor.

This test does NOT require an LLM key. The RAGAS LLM-as-judge tier is
exercised manually (test plan O-19) before launch — see
docs/test-plan.md.

Three assertions, in order of how loud failure should be:

  1. EVERY well_attributed case scores >= 0.7
  2. EVERY unattributed case scores < 0.4
  3. Overall accuracy >= 0.70 (current baseline measured 2026-05-12: 0.733;
     8 of 10 partially_attributed cases score in the well_attributed band,
     which is a known limitation of the deterministic rubric — RAGAS judge
     tier is meant to discriminate better here)

If the deterministic scorer regresses past these floors, this test fails
loudly with which scenarios broke and what they scored.
"""

from __future__ import annotations

import json
from pathlib import Path

from evaluators import evaluate_attribution_integrity

DATASET_PATH = Path(__file__).parent.parent / "evaluators" / "calibration" / "dataset.jsonl"

# Floors. Tightened only after a deliberate calibration round.
OVERALL_ACCURACY_FLOOR = 0.70
WELL_ATTRIBUTED_MIN_SCORE = 0.7
UNATTRIBUTED_MAX_SCORE = 0.4


def _load_cases():
    return [json.loads(line) for line in DATASET_PATH.read_text().splitlines() if line.strip()]


def _predict(case):
    result = evaluate_attribution_integrity(
        decision_memory_id=case.get("scenario_id", "d"),
        retrieved_memories=case["retrieved_memories"],
    )
    return result.score


def _label(score: float) -> str:
    if score >= 0.7:
        return "well_attributed"
    if score >= 0.4:
        return "partially_attributed"
    return "unattributed"


def test_extreme_class_well_attributed_all_pass_high_band():
    """Every well_attributed case must score >= 0.7 — these are the
    obviously-good memories; the scorer should never call them
    partial/unattributed."""
    violations = []
    for case in _load_cases():
        if case["ground_truth"] != "well_attributed":
            continue
        score = _predict(case)
        if score < WELL_ATTRIBUTED_MIN_SCORE:
            violations.append((case["scenario_id"], round(score, 3)))
    assert not violations, (
        f"well_attributed cases must score >= {WELL_ATTRIBUTED_MIN_SCORE}; "
        f"these regressed: {violations}"
    )


def test_extreme_class_unattributed_all_in_low_band():
    """Every unattributed case must score < 0.4 — these are obviously-bad
    memories; the scorer should never call them well/partial."""
    violations = []
    for case in _load_cases():
        if case["ground_truth"] != "unattributed":
            continue
        score = _predict(case)
        if score >= UNATTRIBUTED_MAX_SCORE:
            violations.append((case["scenario_id"], round(score, 3)))
    assert not violations, (
        f"unattributed cases must score < {UNATTRIBUTED_MAX_SCORE}; "
        f"these regressed: {violations}"
    )


def test_overall_accuracy_above_floor():
    """Overall categorical accuracy across all 30 cases must be >= 0.70.
    Current baseline (2026-05-12): 0.733. Per-class breakdown is logged
    so a regression is debuggable."""
    cases = _load_cases()
    rows = [(c["ground_truth"], _label(_predict(c)), c["scenario_id"]) for c in cases]
    correct = sum(1 for gt, pred, _ in rows if gt == pred)
    accuracy = correct / len(rows)

    if accuracy < OVERALL_ACCURACY_FLOOR:
        misses = [(sid, gt, pred) for gt, pred, sid in rows if gt != pred]
        raise AssertionError(
            f"Overall accuracy {accuracy:.3f} < floor {OVERALL_ACCURACY_FLOOR}.\n"
            f"Misses ({len(misses)}): {misses}"
        )
