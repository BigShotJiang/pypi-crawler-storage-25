"""F2 integration test — verify 3-hop attribution chain is preserved.

Uses the sqlite backend (no external DB needed).
"""

import pytest
import pytest_asyncio

from memledger import Memledger, RecordType
from memledger.models import EmbeddingConfig
from memledger.provenance.chain import build_chain, propagate_attribution


class FakeEmbedder:
    """Deterministic embedder for testing (no API calls)."""
    dimensions = 4

    async def embed_single(self, text: str) -> list[float]:
        h = hash(text) % 10000
        return [h / 10000, (h * 7) % 10000 / 10000, (h * 13) % 10000 / 10000, (h * 31) % 10000 / 10000]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_single(t) for t in texts]


@pytest_asyncio.fixture
async def ml(tmp_path):
    """Create a Memledger instance with sqlite backend."""
    db_path = str(tmp_path / "test_chain.db")
    ml = await Memledger.create(
        backend_name="sqlite",
        backend_config={"path": db_path},
        embedding_config=EmbeddingConfig(provider="fake", model="test", dimensions=4),
    )
    ml._embedder = FakeEmbedder()
    yield ml
    await ml.close()


class TestAttributionChain:
    """F2 acceptance: run a 3-agent scenario, verify chain."""

    async def test_3_hop_chain_preserved(self, ml: Memledger):
        """Agent A writes → Agent B reads + derives → Agent C reads + derives.
        Chain should show A → B → C with timestamps and confidences."""

        # Agent A writes original finding
        id_a = await ml.add(
            content="payment-service OOM caused by HikariCP pool leak",
            record_type=RecordType.SEMANTIC,
            namespace="/ops/incidents",
            created_by="agent-a",
            confidence=0.7,
            session_id="session-001",
        )

        # Agent B reads A's finding and derives a new memory
        id_b = await ml.add(
            content="root cause confirmed: HikariCP maxPoolSize=10 too low, should be 50",
            record_type=RecordType.SEMANTIC,
            namespace="/ops/incidents",
            created_by="agent-b",
            confidence=0.85,
            session_id="session-002",
            derived_from=[id_a],
        )

        # Agent C reads B's finding and creates a runbook
        id_c = await ml.add(
            content="Runbook: 1) kubectl edit deployment 2) set maxPoolSize=50 3) rollout restart",
            record_type=RecordType.PROCEDURAL,
            namespace="/ops/runbooks",
            created_by="agent-c",
            confidence=0.9,
            session_id="session-003",
            derived_from=[id_b],
            steps=["kubectl edit deployment", "set maxPoolSize=50", "rollout restart"],
        )

        # Build upstream chain from Agent C's memory
        chain = await build_chain(ml, id_c, direction="upstream", max_hops=5)

        # Verify chain structure
        assert chain.root_memory_id == id_c
        assert chain.chain_depth >= 3, f"Expected 3+ hops, got {chain.chain_depth}"
        assert not chain.truncated, "3-hop chain should not be truncated at max_hops=5"

        # Verify agents involved
        assert "agent-a" in chain.agents_involved
        assert "agent-b" in chain.agents_involved
        assert "agent-c" in chain.agents_involved

        # Verify min confidence tracks correctly
        assert chain.min_confidence == 0.7, f"Min confidence should be agent-a's 0.7, got {chain.min_confidence}"

        # Verify hop order
        agent_order = [h.agent_id for h in chain.chain]
        assert "agent-c" in agent_order
        assert "agent-b" in agent_order
        assert "agent-a" in agent_order

    async def test_chain_truncation_at_5_hops(self, ml: Memledger):
        """Chain with 7 hops should truncate active to 5."""

        ids = []
        for i in range(7):
            rid = await ml.add(
                content=f"memory hop {i}",
                namespace="/test",
                created_by=f"agent-{i}",
                confidence=0.5 + i * 0.05,
                derived_from=[ids[-1]] if ids else [],
            )
            ids.append(rid)

        chain = await build_chain(ml, ids[-1], direction="upstream", max_hops=5)
        assert len(chain.chain) <= 5, f"Active chain should be truncated to 5, got {len(chain.chain)}"
        assert chain.chain_depth >= 6, "Full chain depth should reflect all hops"

    async def test_propagate_attribution(self):
        """propagate_attribution correctly builds child attribution from parent."""

        parent_attr = {
            "memory_id": "mem-001",
            "source_agent_id": "agent-a",
            "confidence": 0.75,
            "chain": [
                {"memory_id": "mem-000", "agent_id": "agent-root", "confidence": 0.9, "hop_number": 0},
            ],
        }

        child_attr = propagate_attribution(parent_attr, "agent-b", 0.85)

        assert child_attr["source_agent_id"] == "agent-b"
        assert child_attr["confidence"] == 0.85
        assert len(child_attr["chain"]) == 2
        assert child_attr["chain"][1]["agent_id"] == "agent-a"
        assert child_attr["chain"][1]["confidence"] == 0.75

    async def test_get_lineage_surfaces_chain(self, ml: Memledger):
        """get_lineage() returns full provenance including supersession."""

        id_old = await ml.add(
            content="OOM fix: increase memory to 2Gi",
            namespace="/ops/incidents",
            created_by="agent-a",
            confidence=0.6,
        )

        id_new = await ml.add(
            content="OOM fix: set maxPoolSize=50, not memory increase",
            namespace="/ops/incidents",
            created_by="agent-b",
            confidence=0.85,
            supersedes=id_old,
        )

        lineage = await ml.get_lineage(record_id=id_new)

        assert "record" in lineage
        assert lineage["record"]["id"] == id_new
        assert lineage["created_by"] == "agent-b"
        # Supersession chain should show the old memory
        if "supersedes_chain" in lineage:
            assert len(lineage["supersedes_chain"]) >= 1
            assert lineage["supersedes_chain"][0]["id"] == id_old
