"""examples/multi-agent — tests/__init__.py stub. Lands in the next commit."""
