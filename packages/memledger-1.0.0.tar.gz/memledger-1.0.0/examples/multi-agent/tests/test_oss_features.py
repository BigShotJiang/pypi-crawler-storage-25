"""OSS-path feature validation — no AWS, no external LLM.

Validates the install line `pip install --pre 'memledger[local,pgvector]'`
end-to-end against a running pgvector + Phoenix docker-compose stack.
Every test here is always-on (no pytest mark), runs in CI, and proves
that the components called out in the README actually work without
cloud credentials.

Covers:
  - fastembed local embeddings round-trip
  - pgvector persistence + retrieval
  - 5-hop provenance chain build via ChainStore
  - weakest-link confidence gate at search time
  - namespace RBAC denies both writes and reads
  - record_outcome() updates persisted confidence + audit
  - deterministic MAI scorer (no LLM)
  - Phoenix span emission (best-effort: warns if Phoenix unreachable)

LLM-driven scenarios live in test_scenario_oss.py (Ollama) and
test_scenario.py (AWS Bedrock).
"""

from __future__ import annotations

import os
import sys
import uuid
from pathlib import Path

import pytest

# Make sibling modules importable.
sys.path.insert(0, str(Path(__file__).parent.parent))

pytestmark = pytest.mark.asyncio


_DSN = os.environ.get(
    "MEMLEDGER_PG_DSN",
    "postgresql://postgres:postgres@localhost:5433/memledger",
)


async def _ml(rbac=None):
    """Build a Memledger with OSS defaults: fastembed local + pgvector."""
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=_DSN,
        embedding_config=EmbeddingConfig(),  # provider=local default
    )
    if rbac is not None:
        ml._rbac = rbac
    return ml


# --- fastembed + pgvector round-trip ----------------------------------------

async def test_fastembed_pgvector_round_trip():
    """Add 3 records via fastembed; search returns them ranked by similarity."""
    ml = await _ml()
    try:
        ns = f"/test/oss-rt-{uuid.uuid4().hex[:8]}"
        await ml.add(content="HikariCP maxPoolSize=50 fixes payment-service OOM",
                     namespace=ns, confidence=0.9, created_by="ops")
        await ml.add(content="Recipe: chocolate chip cookies, 350F, 12 min",
                     namespace=ns, confidence=0.5, created_by="cook")
        await ml.add(content="connection pool exhaustion triggers JVM heap pressure",
                     namespace=ns, confidence=0.85, created_by="ops")

        result = await ml.search(query="connection pool fix", namespace=ns, top_k=3)
        assert len(result.records) == 3
        # Top result must be one of the two ops-related records, not the cookie one.
        top = result.records[0].content.lower()
        assert "pool" in top or "hikari" in top
    finally:
        await ml.close()


# --- 5-hop provenance chain --------------------------------------------------

async def test_chain_build_walks_five_hops():
    """Chain walker returns all 5 hops with min_confidence = 0.3 (weakest link)."""
    ml = await _ml()
    try:
        ns = f"/test/chain-{uuid.uuid4().hex[:8]}"
        # Build a 5-hop chain with descending confidence.
        confidences = [0.9, 0.7, 0.5, 0.4, 0.3]
        agents = [f"agent-{i}" for i in range(5)]
        ids = []
        prev = None
        for c, a in zip(confidences, agents):
            mid = await ml.add(
                content=f"step from {a} at conf={c}",
                namespace=ns,
                confidence=c,
                created_by=a,
                derived_from=[prev] if prev else None,
            )
            ids.append(mid)
            prev = mid

        chain = await ml.chain_store.build_chain(ids[-1], direction="upstream", max_hops=10)
        assert chain.chain_depth == 5, f"expected 5 hops, got {chain.chain_depth}"
        assert chain.min_confidence == pytest.approx(0.3, abs=0.01)
        assert set(chain.agents_involved) == set(agents)
    finally:
        await ml.close()


# --- weakest-link confidence gate -------------------------------------------

async def test_weakest_link_gate_classifies_low():
    """Diagnosis at declared 0.85 derived from triage at 0.30 must be flagged LOW."""
    from memledger.provenance.effective_confidence import compute_effective_confidence_map

    ml = await _ml()
    try:
        ns = f"/test/gate-{uuid.uuid4().hex[:8]}"
        triage_id = await ml.add(
            content="possible connection-pool exhaustion (ambiguous)",
            namespace=ns,
            confidence=0.30,
            hedged=True,
            created_by="triage",
        )
        diag_id = await ml.add(
            content="bump maxPoolSize from 10 to 50",
            namespace=ns,
            confidence=0.85,
            created_by="diagnosis",
            derived_from=[triage_id],
        )

        triage_rec = await ml.get(triage_id)
        diag_rec = await ml.get(diag_id)
        eff_map = await compute_effective_confidence_map(
            [triage_rec, diag_rec], ml.chain_store
        )
        assert eff_map[diag_id] == pytest.approx(0.30, abs=0.01)

        result = await ml.search(
            query="connection pool fix",
            namespace=ns,
            confidence_policy={"min_threshold": 0.5, "flag_threshold": 0.7},
            top_k=10,
        )
        gating = (result.metadata or {}).get("confidence_gating", {})
        assert gating.get("uses_effective_confidence") is True

        diag_in_results = [r for r in result.records if r.id == diag_id]
        if diag_in_results:
            md = diag_in_results[0].metadata or {}
            assert md.get("_confidence_flag") == "LOW", (
                f"diagnosis must be flagged LOW or filtered; metadata={md}"
            )
    finally:
        await ml.close()


# --- namespace RBAC ----------------------------------------------------------

def _rbac_two_agents(allowed: str, denied: str, namespace: str):
    from memledger.policies import AccessRule, NamespacePolicy, NamespaceRBAC

    rbac = NamespaceRBAC()
    rbac.set_policy(NamespacePolicy(
        namespace=namespace,
        rules=[
            AccessRule(agent_pattern=allowed, permissions={"read", "write"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    return rbac


async def test_rbac_denies_write_for_unauthorized_agent():
    from memledger.memledger import NamespaceAccessDenied

    ns = f"/secret/rbac-w-{uuid.uuid4().hex[:8]}"
    ml = await _ml(rbac=_rbac_two_agents("ops-agent", "intruder", ns))
    try:
        # Authorized agent succeeds.
        ok_id = await ml.add(
            content="authorized write",
            namespace=ns,
            agent_id="ops-agent",
            created_by="ops-agent",
            confidence=0.9,
        )
        assert ok_id

        # Unauthorized agent must raise.
        with pytest.raises(NamespaceAccessDenied) as exc:
            await ml.add(
                content="should be denied",
                namespace=ns,
                agent_id="intruder",
                created_by="intruder",
                confidence=0.9,
            )
        assert exc.value.decision.namespace == ns
        assert exc.value.decision.operation == "write"
    finally:
        await ml.close()


async def test_rbac_filters_reads_for_unauthorized_agent():
    """search() must drop records that requester_id is not allowed to read."""
    ns = f"/secret/rbac-r-{uuid.uuid4().hex[:8]}"
    ml = await _ml(rbac=_rbac_two_agents("ops-agent", "intruder", ns))
    try:
        await ml.add(
            content="confidential ops note",
            namespace=ns,
            agent_id="ops-agent",
            created_by="ops-agent",
            confidence=0.9,
        )
        # Intruder gets zero records back, even though one exists.
        result = await ml.search(
            query="ops note",
            namespace=ns,
            requester_id="intruder",
            top_k=10,
        )
        assert len(result.records) == 0

        # Authorized agent gets it.
        result_ok = await ml.search(
            query="ops note",
            namespace=ns,
            requester_id="ops-agent",
            top_k=10,
        )
        assert len(result_ok.records) >= 1
    finally:
        await ml.close()


# --- record_outcome ---------------------------------------------------------

async def test_record_outcome_marks_success():
    """record_outcome(success=True) bumps the persisted success counter."""
    ml = await _ml()
    try:
        ns = f"/test/outcome-{uuid.uuid4().hex[:8]}"
        mid = await ml.add(
            content="useful runbook step",
            namespace=ns,
            confidence=0.8,
            created_by="ops",
        )
        before = await ml.get(mid)
        before_success = getattr(before, "success_count", 0) or 0

        ok = await ml.record_outcome(record_id=mid, success=True)
        assert ok is True

        after = await ml.get(mid)
        after_success = getattr(after, "success_count", 0) or 0
        assert after_success == before_success + 1, (
            f"success_count should increment by 1; before={before_success}, after={after_success}"
        )
    finally:
        await ml.close()


# --- deterministic MAI ------------------------------------------------------

async def test_deterministic_mai_scorer_runs_without_llm():
    """Run the deterministic Memory Attribution Integrity scorer on a tiny
    session. Asserts a numeric score in [0, 1] and that no LLM is required."""
    from evaluators.attribution_integrity import evaluate_attribution_integrity

    ml = await _ml()
    try:
        ns = f"/test/mai-{uuid.uuid4().hex[:8]}"
        a_id = await ml.add(
            content="signal A", namespace=ns, confidence=0.8, created_by="agent-a",
        )
        b_id = await ml.add(
            content="signal B derived from A", namespace=ns, confidence=0.7,
            created_by="agent-b", derived_from=[a_id],
        )
        a_rec, b_rec = await ml.get(a_id), await ml.get(b_id)
        retrieved = [
            {"id": a_rec.id, "content": a_rec.content, "created_by": a_rec.created_by,
             "confidence": a_rec.confidence, "derived_from": a_rec.derived_from or []},
            {"id": b_rec.id, "content": b_rec.content, "created_by": b_rec.created_by,
             "confidence": b_rec.confidence, "derived_from": b_rec.derived_from or []},
        ]
        result = evaluate_attribution_integrity(
            decision_memory_id=b_id, retrieved_memories=retrieved,
        )
        assert 0.0 <= result.score <= 1.0
        assert result.score >= 0.5, f"clean chain scored too low: {result.score}"
    finally:
        await ml.close()
