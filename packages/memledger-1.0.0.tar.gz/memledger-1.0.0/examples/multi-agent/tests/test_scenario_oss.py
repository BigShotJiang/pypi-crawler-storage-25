"""OSS-LLM end-to-end scenario — Ollama driving the agents + RAGAS judge.

Mirrors test_scenario.py (AWS Bedrock) but uses a local Ollama model.
Marked `pytest.mark.oss_llm`: runs when an Ollama server is reachable
and a model is pulled; opt in with `pytest -m oss_llm`.

Required setup:
  - `brew install ollama && brew services start ollama`
  - `ollama pull llama3.1:8b`  (or override via MEMLEDGER_OSS_LLM env)
  - docker compose stack: `docker compose up -d` in examples/multi-agent/

Runtime is ~5–10 minutes on M-series Macs. Slower than Bedrock; the
trade-off is zero cost and zero credentials.
"""

from __future__ import annotations

import os
import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import Settings  # noqa: E402

pytestmark = [pytest.mark.oss_llm, pytest.mark.asyncio]

_OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
_OSS_LLM = os.environ.get("MEMLEDGER_OSS_LLM", "ollama/llama3.1:8b")
_DSN = os.environ.get(
    "MEMLEDGER_PG_DSN",
    "postgresql://postgres:postgres@localhost:5433/memledger",
)


def _ollama_reachable() -> bool:
    import urllib.request
    try:
        with urllib.request.urlopen(f"{_OLLAMA_HOST}/api/version", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


@pytest.fixture(scope="module", autouse=True)
def _skip_if_no_ollama():
    if not _ollama_reachable():
        pytest.skip(f"Ollama not reachable at {_OLLAMA_HOST}; pull a model and start the daemon")


@pytest.fixture
def oss_settings() -> Settings:
    return Settings(
        pg_dsn=_DSN,
        llm_model=_OSS_LLM,
        judge_model=_OSS_LLM,
        otel_endpoint=os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"),
        phoenix_base_url=os.environ.get("PHOENIX_BASE_URL", "http://localhost:6006"),
        aws_region="",
    )


def _build_rbac():
    from memledger.policies import AccessRule, NamespacePolicy, NamespaceRBAC

    rbac = NamespaceRBAC()
    rbac.set_policy(NamespacePolicy(
        namespace="/ops/incidents/*",
        rules=[
            AccessRule(agent_pattern="triage-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="diagnosis-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="remediation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="escalation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="auditor-agent", permissions={"read"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    rbac.set_policy(NamespacePolicy(
        namespace="/audit/*",
        rules=[
            AccessRule(agent_pattern="auditor-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    return rbac


async def _ml(settings):
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=settings.pg_dsn,
        embedding_config=EmbeddingConfig(),
    )
    ml._rbac = _build_rbac()
    return ml


async def test_oss_scenario_runs_end_to_end(oss_settings):
    """Full 5-agent scenario on Ollama. Asserts on structural outputs +
    that the provenance chain threads correctly across agent boundaries."""
    from scenario import run_sre_scenario

    ml = await _ml(oss_settings)
    try:
        result = await run_sre_scenario(
            ml,
            oss_settings,
            judge_model=_OSS_LLM,
        )

        # Every agent wrote a memory.
        assert result.triage_memory_id
        assert result.diagnosis_memory_id
        assert result.remediation_memory_id
        assert result.audit_memory_id

        # Provenance chain on the deepest memory: walk upstream and
        # confirm the chain threads across agent boundaries. We assert
        # on the contract (chain depth + multi-agent + weakest-link),
        # not on a specific agent set — smaller OSS models legitimately
        # take different routing decisions (apply vs escalate) each run.
        deepest = result.audit_memory_id
        chain = await ml.chain_store.build_chain(deepest, direction="upstream", max_hops=10)
        agents_seen = set(chain.agents_involved)
        assert chain.chain_depth >= 3, (
            f"audit chain should be ≥3 hops (triage → ... → audit); got {chain.chain_depth}"
        )
        assert "triage-agent" in agents_seen, (
            f"triage is the root cause record; must appear in chain. got {agents_seen}"
        )
        assert "auditor-agent" in agents_seen, (
            f"auditor wrote the leaf; must appear. got {agents_seen}"
        )
        # At least one mid-flow agent (diagnosis or remediation) must thread
        # through — otherwise the chain isn't really multi-agent.
        assert agents_seen & {"diagnosis-agent", "remediation-agent"}, (
            f"chain has no mid-flow agent (diagnosis/remediation). got {agents_seen}"
        )
        # Weakest-link contract: the chain min_confidence must reflect the
        # actual minimum across all hops, not the leaf's declared value.
        assert chain.min_confidence < 0.99, (
            f"audit declared 0.99 but chain min should pull lower; got {chain.min_confidence}"
        )

        # Eval tiers ran.
        assert 0.0 <= result.deterministic_mai_score <= 1.0
        if result.ragas_score is not None:
            assert 0.0 <= result.ragas_score <= 1.0

        # Smaller OSS models occasionally produce noisier outputs;
        # a lower floor is realistic. The B6/B10 guarantees are about
        # the *gating contract*, not the LLM quality, so the score
        # threshold here is intentionally softer than the Bedrock test.
        assert result.deterministic_mai_score >= 0.5, (
            f"Deterministic MAI on Ollama: {result.deterministic_mai_score:.3f} < 0.5 "
            "— either the chain broke or the model lost role. Inspect Phoenix."
        )
    finally:
        await ml.close()
