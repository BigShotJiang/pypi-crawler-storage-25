"""B8 step 4: end-to-end test of the multi-agent reference client.

This test runs the FULL scenario — five agents, real Bedrock LLM calls
on Sonnet 4.5, real pgvector + Phoenix containers — and asserts on
the structural outputs (memory ids exist, B10 gate fires, MAI scores
clear thresholds, RAGAS judge returns a score).

Marked `pytest.mark.aws` per the project convention: default `pytest`
runs skip it; opt in with `pytest -m aws`. Closes test-plan rows
O-17 (RAGAS LLM-judge end-to-end), O-21 (RAGAS evals attached to
spans), and the chunk of O-23 covered by the local docker pgvector
deployment mode.

Requires:
  - docker compose stack (`docker compose up -d` in examples/multi-agent/)
  - AWS credentials with Bedrock InvokeModel for
    `us.anthropic.claude-sonnet-4-5-20250929-v1:0`
  - MEMLEDGER_PG_DSN pointing at the docker-compose Postgres (5433)

Note on cost: each scenario run does ~6 Bedrock InvokeModel calls
(triage / diagnosis / remediation / auditor narrative / RAGAS judge)
plus embeddings via fastembed (local, free). Roughly $0.02 per run.
"""

from __future__ import annotations

import os
import sys
import uuid
from pathlib import Path

import pytest

# Make sibling modules importable.
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import Settings  # noqa: E402

# Bedrock-only test bank. Every test here is AWS-gated.
pytestmark = [pytest.mark.aws, pytest.mark.asyncio]


_BEDROCK_SONNET = "bedrock/us.anthropic.claude-sonnet-4-5-20250929-v1:0"

_DSN = os.environ.get(
    "MEMLEDGER_PG_DSN",
    "postgresql://postgres:postgres@localhost:5433/memledger",
)


@pytest.fixture
def bedrock_settings() -> Settings:
    """Settings overridden to use Bedrock Sonnet for both the agent LLM
    and the RAGAS judge. AWS_REGION must be reachable for InvokeModel."""
    return Settings(
        pg_dsn=_DSN,
        llm_model=_BEDROCK_SONNET,
        judge_model=_BEDROCK_SONNET,
        otel_endpoint=os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"),
        phoenix_base_url=os.environ.get("PHOENIX_BASE_URL", "http://localhost:6006"),
        aws_region=os.environ.get("AWS_REGION", "us-west-2"),
    )


def _build_rbac():
    from memledger.policies import AccessRule, NamespacePolicy, NamespaceRBAC

    rbac = NamespaceRBAC()
    rbac.set_policy(NamespacePolicy(
        namespace="*",
        rules=[AccessRule(agent_pattern="*", permissions=set())],
        default_permissions=set(),
    ))
    rbac.set_policy(NamespacePolicy(
        namespace="/ops/incidents/*",
        rules=[
            AccessRule(agent_pattern="triage-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="diagnosis-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="remediation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="escalation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="auditor-agent", permissions={"read"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    rbac.set_policy(NamespacePolicy(
        namespace="/audit/*",
        rules=[
            AccessRule(agent_pattern="auditor-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    return rbac


async def _build_memledger(settings: Settings):
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=settings.pg_dsn,
        embedding_config=EmbeddingConfig(),  # local fastembed default
    )
    ml._rbac = _build_rbac()
    return ml


async def test_scenario_runs_end_to_end(bedrock_settings):
    """Full scenario: 5 agents, real Bedrock LLM calls, real RAGAS judge.
    Asserts structurally on the produced chain and scores."""
    from scenario import run_sre_scenario

    ml = await _build_memledger(bedrock_settings)
    try:
        result = await run_sre_scenario(
            ml,
            bedrock_settings,
            judge_model=_BEDROCK_SONNET,
        )
    finally:
        await ml.close()

    # Every agent produced a memory.
    assert result.triage_memory_id
    assert result.diagnosis_memory_id
    assert result.remediation_memory_id
    assert result.audit_memory_id
    assert result.namespace.startswith("/ops/incidents/")

    # Remediation made an autonomous decision; both branches are valid
    # but the value must be one of the contract strings.
    assert result.remediation_decision in {"apply", "escalate"}
    if result.remediation_decision == "escalate":
        assert result.escalation_memory_id, "escalate decision but no escalation memory written"
    else:
        assert result.escalation_memory_id is None

    # Both eval tiers ran and produced sane scores.
    assert 0.0 <= result.deterministic_mai_score <= 1.0
    assert result.ragas_score is not None, "judge_model was set; RAGAS should have run"
    assert 0.0 <= result.ragas_score <= 1.0

    # B6/B10/B11 sanity: a well-attributed chain should score in the high
    # band on both tiers. If the chain regresses to under 0.7, something
    # broke in attribution / chain-walk / gating.
    assert result.deterministic_mai_score >= 0.7, (
        f"Deterministic MAI regression: {result.deterministic_mai_score:.3f} < 0.7"
    )


async def test_b10_gate_filters_weak_chain_in_situ(bedrock_settings):
    """A focused B10 contract check that doesn't depend on LLM autonomy:
    plant a low-confidence triage and a high-confidence diagnosis derived
    from it; assert the effective-confidence map reflects the chain min,
    and that search with confidence_policy classifies the diagnosis as
    flagged or filtered (never as a clean pass).
    """
    from memledger.provenance.effective_confidence import compute_effective_confidence_map

    ml = await _build_memledger(bedrock_settings)
    try:
        ns = f"/ops/incidents/B10-CONTRACT-{uuid.uuid4().hex[:8]}"

        triage_id = await ml.add(
            content="possible connection-pool exhaustion (ambiguous signal)",
            namespace=ns,
            agent_id="triage-agent",
            created_by="triage-agent",
            confidence=0.30,
            hedged=True,
            session_id="B10-CONTRACT",
        )
        diag_id = await ml.add(
            content="bump maxPoolSize from 10 to 50",
            namespace=ns,
            agent_id="diagnosis-agent",
            created_by="diagnosis-agent",
            confidence=0.85,
            session_id="B10-CONTRACT",
            derived_from=[triage_id],
        )

        # Direct effective-confidence check: chain min should be 0.30.
        triage_rec = await ml.get(triage_id)
        diag_rec = await ml.get(diag_id)
        eff_map = await compute_effective_confidence_map([triage_rec, diag_rec], ml.chain_store)
        assert eff_map[diag_id] == pytest.approx(0.30, abs=0.01), (
            f"chain min 0.30 should pull diagnosis effective conf down; got {eff_map[diag_id]}"
        )

        # Search with confidence_policy: diagnosis must NOT appear in the
        # clean-pass bucket. It can be flagged or filtered — either is
        # within contract; what's forbidden is treating its declared 0.85
        # as authoritative.
        result = await ml.search(
            query="connection pool fix",
            namespace=ns,
            confidence_policy={"min_threshold": 0.5, "flag_threshold": 0.7},
            top_k=10,
        )
        gating = (result.metadata or {}).get("confidence_gating", {})
        assert gating.get("uses_effective_confidence") is True

        diag_in_results = [r for r in result.records if r.id == diag_id]
        if diag_in_results:
            diag = diag_in_results[0]
            md = diag.metadata or {}
            assert md.get("_confidence_flag") == "LOW", (
                f"diagnosis must be flagged LOW or filtered; metadata={md}"
            )
    finally:
        await ml.close()
