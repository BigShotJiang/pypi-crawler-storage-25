"""examples/multi-agent — entry point.

Brings up the Memledger instance (with RBAC + chain store wired) and
runs the SRE scenario end-to-end. Prints a structured summary at the
end. Visit Phoenix at $PHOENIX_BASE_URL to see the traces + evals.

Usage (from this directory):

    docker compose up -d              # if not already running
    pip install -r requirements.txt   # if not already installed
    python run.py

Configuration is entirely via env vars (see config.py). The most
common overrides:

    MEMLEDGER_EXAMPLE_LLM=bedrock/anthropic.claude-sonnet-4-5-...
    MEMLEDGER_JUDGE_MODEL=bedrock/anthropic.claude-sonnet-4-5-...  # enables RAGAS audit
    MEMLEDGER_PG_DSN=postgresql://...
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from pathlib import Path

# Make sibling modules importable when running from anywhere.
sys.path.insert(0, str(Path(__file__).parent))

from config import Settings
from scenario import run_sre_scenario


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)


def _build_rbac():
    """Construct the demo RBAC policy.

    - ops agents (triage/diagnosis/remediation/escalation) can read+write
      under /ops/incidents/*.
    - auditor can read everywhere.
    - Catch-all denies everything else.
    """
    from memledger.policies import AccessRule, NamespacePolicy, NamespaceRBAC

    rbac = NamespaceRBAC()
    # Catch-all deny everything.
    rbac.set_policy(NamespacePolicy(
        namespace="*",
        rules=[AccessRule(agent_pattern="*", permissions=set())],
        default_permissions=set(),
    ))
    # Ops incident namespace: ops agents read+write; auditor has read.
    rbac.set_policy(NamespacePolicy(
        namespace="/ops/incidents/*",
        rules=[
            AccessRule(agent_pattern="triage-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="diagnosis-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="remediation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="escalation-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="auditor-agent", permissions={"read"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    # Audit namespace: ONLY auditor can read+write; ops agents have no
    # access (audit trail is tamper-evident from the ops side).
    rbac.set_policy(NamespacePolicy(
        namespace="/audit/*",
        rules=[
            AccessRule(agent_pattern="auditor-agent", permissions={"read", "write"}),
            AccessRule(agent_pattern="*", permissions=set()),
        ],
        default_permissions=set(),
    ))
    return rbac


async def main():
    settings = Settings.from_env()
    print(f"\n{settings.summary()}\n")

    # Export Phoenix client config to the process env BEFORE the phoenix
    # helper builds its client. Without this, phoenix.py falls back to
    # OTEL_EXPORTER_OTLP_ENDPOINT (which is the gRPC port 4317) and the
    # Phoenix REST annotation calls silently fail.
    if settings.phoenix_base_url:
        os.environ["PHOENIX_BASE_URL"] = settings.phoenix_base_url
    if settings.otel_endpoint:
        os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = settings.otel_endpoint

    # Initialize OTEL → Phoenix BEFORE Memledger is created so the
    # instance's spans flow to the configured exporter from the first add().
    # The OTLP gRPC exporter reads OTEL_EXPORTER_OTLP_ENDPOINT (defaults to
    # http://localhost:4317 — Phoenix's gRPC receiver port).
    from memledger.telemetry import setup_engram_telemetry, instrument_engram
    setup_engram_telemetry(service_name="memledger-multi-agent-example", exporter="otlp")

    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    # Wire memledger with RBAC (B11) and the default JsonArrayChainStore (B10).
    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=settings.pg_dsn,
        embedding_config=EmbeddingConfig(),  # v1 default: local fastembed / 384-dim
    )
    ml._rbac = _build_rbac()
    instrument_engram(ml)

    # Decide whether to run the RAGAS auditor judge: only if MEMLEDGER_JUDGE_MODEL
    # is explicitly set in env. We don't auto-enable it just from settings.judge_model
    # because that field has a Bedrock default that costs money on every run.
    judge_model = os.environ.get("MEMLEDGER_JUDGE_MODEL")

    result = await run_sre_scenario(ml, settings, judge_model=judge_model)

    print("\n" + "=" * 72)
    print(f"  Scenario complete: {result.incident_id}")
    print("=" * 72)
    print(f"  Namespace            : {result.namespace}")
    print(f"  Triage memory        : {result.triage_memory_id}")
    print(f"  Diagnosis memory     : {result.diagnosis_memory_id}")
    print(f"  Remediation memory   : {result.remediation_memory_id}  (decision: {result.remediation_decision})")
    print(f"  Escalation memory    : {result.escalation_memory_id or '(no escalation)'}")
    print(f"  Audit memory         : {result.audit_memory_id}")
    print(f"  Deterministic MAI    : {result.deterministic_mai_score:.3f}")
    print(f"  RAGAS judge          : {f'{result.ragas_score:.3f}' if result.ragas_score is not None else 'skipped (set MEMLEDGER_JUDGE_MODEL to enable)'}")
    print("=" * 72)

    # Render the provenance chain visually so users can SEE the derivation
    # graph the scenario built. For a richer interactive view: use
    # memledger-ui's trust graph UI (separate repo) or Phoenix's traces tab.
    await _print_chain(ml, result)

    if settings.phoenix_base_url:
        print(f"\n  Phoenix UI           : {settings.phoenix_base_url}")
    print()

    await ml.close()


async def _print_chain(ml, result):
    """Render the incident's provenance chain as an indented tree."""
    from rich.console import Console
    from rich.tree import Tree

    console = Console()
    ids_to_fetch = [
        ("triage", result.triage_memory_id),
        ("diagnosis", result.diagnosis_memory_id),
        ("remediation", result.remediation_memory_id),
    ]
    if result.escalation_memory_id:
        ids_to_fetch.append(("escalation", result.escalation_memory_id))
    ids_to_fetch.append(("audit", result.audit_memory_id))

    records = {}
    for _, mid in ids_to_fetch:
        records[mid] = await ml.get(mid)

    # Build the tree by walking derived_from forward from triage.
    tree = Tree(f"[bold]Provenance chain: {result.incident_id}[/bold]")

    def _fmt(label, rec):
        hedged = " [yellow](hedged)[/yellow]" if getattr(rec, "hedged", False) else ""
        conf_color = "green" if rec.confidence >= 0.7 else "yellow" if rec.confidence >= 0.4 else "red"
        return (
            f"[bold]{label:<11}[/bold] {rec.id[:8]} "
            f"[{conf_color}]conf={rec.confidence:.2f}[/{conf_color}]{hedged} "
            f"by [cyan]{rec.created_by}[/cyan]\n"
            f"               [dim]{rec.content[:100]}{'…' if len(rec.content or '') > 100 else ''}[/dim]"
        )

    triage_node = tree.add(_fmt("triage", records[result.triage_memory_id]))
    diag_node = triage_node.add(_fmt("diagnosis", records[result.diagnosis_memory_id]))
    remed_node = diag_node.add(_fmt("remediation", records[result.remediation_memory_id]))
    if result.escalation_memory_id:
        remed_node.add(_fmt("escalation", records[result.escalation_memory_id]))
    # audit derives from everything (whole chain); render as a sibling at root
    # so it's clear it audits the whole thing, not just the leaf.
    audit_rec = records[result.audit_memory_id]
    tree.add(
        f"[bold magenta]audit[/bold magenta]      {audit_rec.id[:8]} "
        f"in [cyan]{audit_rec.namespace}[/cyan]\n"
        f"               [dim italic]{(audit_rec.content or '')[:200]}{'…' if len(audit_rec.content or '') > 200 else ''}[/dim italic]"
    )

    console.print()
    console.print(tree)


if __name__ == "__main__":
    asyncio.run(main())
