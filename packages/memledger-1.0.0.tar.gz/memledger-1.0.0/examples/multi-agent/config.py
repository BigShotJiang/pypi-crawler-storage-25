"""examples/multi-agent — env-driven settings.

All knobs live here as a single dataclass so individual modules don't
re-read `os.environ` ad-hoc. Pattern matches the rest of memledger: env
var wins, sensible default otherwise.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

# Default model strings. Sonnet via Anthropic is the runtime default
# (per project memory: project-multi-agent-example). Tests override to
# Bedrock. Either way, LiteLLM resolves the provider.
DEFAULT_LLM = "anthropic/claude-sonnet-4-5-20250929"
DEFAULT_JUDGE = "bedrock/anthropic.claude-sonnet-4-5-20250929-v1:0"

DEFAULT_PG_DSN = "postgresql://postgres:postgres@localhost:5433/memledger"
# Phoenix exposes gRPC OTLP on :4317 and HTTP UI/OTLP on :6006.
# memledger uses opentelemetry-exporter-otlp-proto-grpc → must point at :4317.
DEFAULT_OTEL = "http://localhost:4317"
DEFAULT_PHOENIX = "http://localhost:6006"


@dataclass(frozen=True)
class Settings:
    """All configuration for the multi-agent example.

    Build with `Settings.from_env()`. Individual fields are also constructible
    in tests via direct kwarg passing.
    """

    pg_dsn: str
    llm_model: str
    judge_model: str
    otel_endpoint: Optional[str]
    phoenix_base_url: Optional[str]
    aws_region: str

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            pg_dsn=os.environ.get("MEMLEDGER_PG_DSN", DEFAULT_PG_DSN),
            llm_model=os.environ.get("MEMLEDGER_EXAMPLE_LLM", DEFAULT_LLM),
            judge_model=os.environ.get("MEMLEDGER_JUDGE_MODEL", DEFAULT_JUDGE),
            otel_endpoint=os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", DEFAULT_OTEL),
            phoenix_base_url=os.environ.get("PHOENIX_BASE_URL", DEFAULT_PHOENIX),
            aws_region=os.environ.get("AWS_REGION", "us-west-2"),
        )

    def summary(self) -> str:
        """Single-line debug summary; hides the DSN password."""
        safe_dsn = self.pg_dsn
        if "@" in safe_dsn and "://" in safe_dsn:
            scheme, rest = safe_dsn.split("://", 1)
            if ":" in rest.split("@", 1)[0]:
                user, host = rest.split("@", 1)
                user = user.split(":", 1)[0] + ":***"
                safe_dsn = f"{scheme}://{user}@{host}"
        return f"Settings(pg={safe_dsn} llm={self.llm_model} judge={self.judge_model} phoenix={self.phoenix_base_url})"


if __name__ == "__main__":
    print(Settings.from_env().summary())
