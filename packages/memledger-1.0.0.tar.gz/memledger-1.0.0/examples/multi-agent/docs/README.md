# Screenshots

Drop Phoenix screenshots here. **Single canonical location** —
referenced from:
- the parent [README](../README.md)
- the v1 launch blog series (D5) on Medium
- the public docs site (memledger-docs Docusaurus build) — via a
  build-time copy step that lands these under `static/img/multi-agent/`
  during the docs build. Reused, not duplicated.

When uploading new images, keep filenames stable so cross-repo
references don't break.

Suggested filenames:

| File | Shows |
|---|---|
| `phoenix-spans.png` | Spans tab with `kind` column populated (RETRIEVER / CHAIN / EVALUATOR) |
| `phoenix-trace.png` | A trace's parent-child tree (`memledger.memory.add` → `memledger.conflict_detected`) with the right-panel attributes |
| `phoenix-session.png` | Sessions tab grouped by `INC-2026-0513-001` |
| `phoenix-annotation-deterministic.png` | `evaluators.mai_deterministic` span → Annotations tab → `memory_attribution_integrity` (CODE) |
| `phoenix-annotation-ragas.png` | `evaluators.mai_ragas` span → Annotations tab → `memory_attribution_integrity` (LLM) |
| `provenance-tree.png` | The Rich-rendered chain printed at the end of `run.py` |
