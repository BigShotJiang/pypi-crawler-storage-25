"""examples/multi-agent — the five agents.

Each agent is a thin Python class that owns:
  - its agent_id (used for memledger `created_by` + RBAC matching),
  - a reference to a shared Memledger instance,
  - the LLM model string to call via LiteLLM.

Agents do NOT manage their own Postgres connection — they share one
Memledger via dependency injection. That's the v1 direct-SDK pattern
(see README "How agents talk to memledger").

Within each step the agent's decisions are LLM-driven (hypothesis,
confidence, hedge, apply-vs-escalate, narrative). The sequence of
agents is determined by scenario.py — Stage 1 of this example uses a
fixed state machine; Stage 2 (B8b) will let agents self-route.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from memledger.memledger import Memledger

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared LLM call helper
# ---------------------------------------------------------------------------

async def _call_llm(
    model: str,
    system: str,
    user: str,
    *,
    temperature: float = 0.2,
    max_tokens: int = 600,
) -> str:
    """Call the configured LLM via LiteLLM. Returns the raw text response.

    All LLM calls in this example go through LiteLLM per the B1 invariant —
    swap providers with one env var (MEMLEDGER_EXAMPLE_LLM), no code edits.
    """
    import litellm
    response = await litellm.acompletion(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return response.choices[0].message.content or ""


def _parse_json_safely(text: str, fallback: dict) -> dict:
    """Best-effort JSON extraction from an LLM response.

    LLMs sometimes wrap JSON in markdown fences or trailing commentary.
    This tries the cheap parse, then locates the outermost {...} block.
    """
    text = text.strip()
    # Strip common markdown fences
    if text.startswith("```"):
        first_newline = text.find("\n")
        if first_newline != -1:
            text = text[first_newline + 1 :]
        if text.endswith("```"):
            text = text[: -3]
        text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if 0 <= start < end:
            try:
                return json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                pass
    logger.warning("Could not parse JSON from LLM; using fallback. raw=%r", text[:200])
    return fallback


def _clip(text: str, n: int = 220) -> str:
    text = text or ""
    return text if len(text) <= n else text[: n - 1] + "…"


# ---------------------------------------------------------------------------
# Agent base + concrete agents
# ---------------------------------------------------------------------------

@dataclass
class AgentResult:
    """Structured return from any agent step.

    `memory_id` is the memledger record this step produced (if any).
    `payload` is the agent's domain-level output for the next agent.
    """
    memory_id: Optional[str]
    payload: dict


class _BaseAgent:
    """Shared scaffolding."""

    def __init__(self, ml: "Memledger", llm_model: str, agent_id: str, namespace_root: str = "/ops/incidents") -> None:
        self.ml = ml
        self.llm_model = llm_model
        self.agent_id = agent_id
        self.namespace_root = namespace_root


# ---------------------------------------------------------------------------
# Triage
# ---------------------------------------------------------------------------

class TriageAgent(_BaseAgent):
    SYSTEM_PROMPT = (
        "You are an SRE triage agent in a production multi-agent system. "
        "Given a noisy production alert, propose ONE plausible root-cause "
        "hypothesis and rate your confidence in it. Important rules:\n"
        " - Be honest. If the alert is ambiguous, hedge — set hedged=true "
        "   and confidence < 0.5. Downstream agents will weight you "
        "   accordingly; over-confidence is worse than humility.\n"
        " - Confidence is your belief in the hypothesis, not the urgency.\n"
        " - Respond as compact JSON only: "
        '{"hypothesis": "<one sentence>", "confidence": 0.0-1.0, "hedged": true|false, "reasoning": "<one short sentence>"}'
    )

    async def triage(self, alert: dict) -> AgentResult:
        user_msg = (
            f"Alert: {alert['title']}\n"
            f"Service: {alert['service']} | Severity: {alert['severity']}\n"
            f"At: {alert['timestamp']}\n"
            f"Metrics: {json.dumps(alert.get('metrics', {}))}\n"
            f"Description: {alert.get('description', '(none)')}\n"
            f"Runbook: {alert.get('runbook', '(none)')}\n\n"
            f"Triage this alert. Return JSON only."
        )
        raw = await _call_llm(self.llm_model, self.SYSTEM_PROMPT, user_msg, temperature=0.3)
        parsed = _parse_json_safely(raw, {
            "hypothesis": "Unable to parse LLM response.",
            "confidence": 0.3,
            "hedged": True,
            "reasoning": "JSON parse failure; defaulting to low confidence.",
        })

        namespace = f"{self.namespace_root}/{alert['alert_id']}"
        memory_id = await self.ml.add(
            content=parsed["hypothesis"],
            namespace=namespace,
            agent_id=self.agent_id,
            created_by=self.agent_id,
            confidence=float(parsed["confidence"]),
            hedged=bool(parsed["hedged"]),
            session_id=alert["alert_id"],
            metadata={"reasoning": _clip(parsed.get("reasoning", ""))},
        )
        logger.info("[triage] memory=%s conf=%.2f hedged=%s", memory_id[:8], parsed["confidence"], parsed["hedged"])
        return AgentResult(memory_id=memory_id, payload={
            "namespace": namespace,
            "hypothesis": parsed["hypothesis"],
            "confidence": parsed["confidence"],
            "hedged": parsed["hedged"],
        })


# ---------------------------------------------------------------------------
# Diagnosis
# ---------------------------------------------------------------------------

class DiagnosisAgent(_BaseAgent):
    SYSTEM_PROMPT = (
        "You are an SRE diagnosis agent. You have access to a triage "
        "hypothesis and are asked to propose ONE concrete remediation. "
        "Important rules:\n"
        " - Rate your confidence in the *remediation itself*, NOT in the "
        "   upstream triage hypothesis. Downstream gating combines your "
        "   confidence with the weakest link in the provenance chain.\n"
        " - Be concrete: include parameter names, values, units when "
        "   relevant.\n"
        " - Respond as compact JSON only: "
        '{"recommendation": "<one sentence>", "confidence": 0.0-1.0, "rationale": "<one short sentence>"}'
    )

    async def diagnose(self, namespace: str, triage_memory_id: str) -> AgentResult:
        # Read triage's memory directly (we have the id) — autonomy without
        # over-fetching.
        triage = await self.ml.get(triage_memory_id)
        if triage is None:
            raise RuntimeError(f"triage memory {triage_memory_id} not found")

        user_msg = (
            f"Triage hypothesis (declared confidence {triage.confidence:.2f}"
            f"{', hedged' if triage.hedged else ''}): {triage.content}\n\n"
            f"Propose a concrete remediation. Return JSON only."
        )
        raw = await _call_llm(self.llm_model, self.SYSTEM_PROMPT, user_msg, temperature=0.2)
        parsed = _parse_json_safely(raw, {
            "recommendation": "Unable to parse LLM response.",
            "confidence": 0.3,
            "rationale": "JSON parse failure.",
        })

        memory_id = await self.ml.add(
            content=parsed["recommendation"],
            namespace=namespace,
            agent_id=self.agent_id,
            created_by=self.agent_id,
            confidence=float(parsed["confidence"]),
            hedged=False,  # diagnosis is locally confident; chain min may still pull effective down
            session_id=triage.session_id,
            derived_from=[triage.id],
            metadata={"rationale": _clip(parsed.get("rationale", ""))},
        )
        logger.info("[diagnosis] memory=%s declared_conf=%.2f derived_from=%s", memory_id[:8], parsed["confidence"], triage.id[:8])
        return AgentResult(memory_id=memory_id, payload={
            "namespace": namespace,
            "recommendation": parsed["recommendation"],
            "declared_confidence": parsed["confidence"],
            "triage_id": triage.id,
        })


# ---------------------------------------------------------------------------
# Remediation — branching decision driven by the B10 gate
# ---------------------------------------------------------------------------

class RemediationAgent(_BaseAgent):
    SYSTEM_PROMPT = (
        "You are an SRE remediation agent. You have searched for diagnoses "
        "in the incident namespace with a confidence policy applied. The "
        "system has already weighted each diagnosis by the weakest link in "
        "its provenance chain (effective confidence). Important rules:\n"
        " - If you can see at least one diagnosis that PASSED the gate "
        "   (i.e. was not filtered), you may auto-apply it.\n"
        " - If everything you can see was flagged (low confidence after the "
        "   gate) or no diagnoses returned, escalate to a human.\n"
        " - Do NOT second-guess the gate; trust the effective confidence.\n"
        " - Respond as compact JSON only: "
        '{"action": "apply"|"escalate", "target_memory_id": "<id or null>", "reason": "<one sentence>"}'
    )

    async def remediate(self, namespace: str, incident_id: str, *, confidence_min: float = 0.5) -> AgentResult:
        # Search the namespace with the confidence policy. B10 effective-
        # confidence gating fires here automatically.
        result = await self.ml.search(
            query="remediation recommendation",
            namespace=namespace,
            agent_id=self.agent_id,
            confidence_policy={
                "min_threshold": confidence_min,
                "flag_threshold": min(1.0, confidence_min + 0.2),
            },
            top_k=5,
        )

        gating = (result.metadata or {}).get("confidence_gating", {})
        passed_records = []
        flagged_records = []
        for r in result.records:
            md = r.metadata or {}
            eff = md.get("_effective_confidence")
            if md.get("_confidence_flag") == "LOW":
                flagged_records.append((r, eff))
            else:
                passed_records.append((r, eff))

        # Summarize what the agent sees, for the LLM prompt.
        passed_lines = [
            f"  PASSED  id={r.id[:8]} declared={r.confidence:.2f} effective={eff if eff is not None else 'n/a'} :: {_clip(r.content, 120)}"
            for r, eff in passed_records
        ]
        flagged_lines = [
            f"  FLAGGED id={r.id[:8]} declared={r.confidence:.2f} effective={eff if eff is not None else 'n/a'} :: {_clip(r.content, 120)}"
            for r, eff in flagged_records
        ]
        user_msg = (
            f"Incident: {incident_id}\n"
            f"Search returned {len(result.records)} memories under confidence policy "
            f"(min={confidence_min}, flag={min(1.0, confidence_min + 0.2):.2f}).\n"
            f"Gating stats: {json.dumps(gating)}\n\n"
            f"Passed:\n" + ("\n".join(passed_lines) if passed_lines else "  (none)") + "\n\n"
            f"Flagged (effective confidence below flag threshold):\n" +
            ("\n".join(flagged_lines) if flagged_lines else "  (none)") + "\n\n"
            "Decide: apply or escalate. Return JSON only."
        )

        raw = await _call_llm(self.llm_model, self.SYSTEM_PROMPT, user_msg, temperature=0.1)
        parsed = _parse_json_safely(raw, {
            "action": "escalate",
            "target_memory_id": None,
            "reason": "JSON parse failure; defaulting to escalate.",
        })

        derived = []
        if parsed.get("target_memory_id"):
            derived.append(parsed["target_memory_id"])

        # Whatever the decision, record it as a memory so the auditor can see it.
        content = (
            f"Decision: {parsed['action']}. Reason: {parsed.get('reason', '')}"
        )
        memory_id = await self.ml.add(
            content=content,
            namespace=namespace,
            agent_id=self.agent_id,
            created_by=self.agent_id,
            confidence=0.9,  # high confidence in our own decision tracking
            session_id=incident_id,
            derived_from=derived if derived else None,
            metadata={
                "decision": parsed["action"],
                "target_memory_id": parsed.get("target_memory_id"),
                "gating": gating,
            },
        )
        logger.info(
            "[remediation] memory=%s decision=%s (passed=%d, flagged=%d)",
            memory_id[:8], parsed["action"], len(passed_records), len(flagged_records),
        )
        return AgentResult(memory_id=memory_id, payload={
            "namespace": namespace,
            "decision": parsed["action"],
            "target_memory_id": parsed.get("target_memory_id"),
            "reason": parsed.get("reason"),
            "gating": gating,
        })


# ---------------------------------------------------------------------------
# Escalation
# ---------------------------------------------------------------------------

class EscalationAgent(_BaseAgent):
    async def escalate(
        self,
        namespace: str,
        incident_id: str,
        parent_memory_id: Optional[str],
        reason: str,
    ) -> AgentResult:
        """Records the escalation event with a preserved derivation chain.

        No LLM call here — the *content* of an escalation is the reason
        already produced by remediation. This step exists to make the chain
        explicit in memledger.
        """
        content = f"Escalated to on-call. Reason: {reason}"
        memory_id = await self.ml.add(
            content=content,
            namespace=namespace,
            agent_id=self.agent_id,
            created_by=self.agent_id,
            confidence=0.95,
            session_id=incident_id,
            derived_from=[parent_memory_id] if parent_memory_id else None,
            metadata={"reason": _clip(reason)},
        )
        logger.info("[escalation] memory=%s parent=%s", memory_id[:8], (parent_memory_id or "")[:8])
        return AgentResult(memory_id=memory_id, payload={
            "namespace": namespace,
            "reason": reason,
        })


# ---------------------------------------------------------------------------
# Auditor — read-only, generates narrative, triggers evaluators
# ---------------------------------------------------------------------------

class AuditorAgent(_BaseAgent):
    SYSTEM_PROMPT = (
        "You are an SRE auditor. You see the full memory chain for an "
        "incident and produce a short, factual narrative of how the "
        "decision was made. Important rules:\n"
        " - One paragraph. Plain text, no markdown.\n"
        " - Mention every agent that contributed.\n"
        " - Cite confidence values when they change a decision.\n"
        " - Do NOT speculate beyond what the memories say."
    )

    async def audit(self, namespace: str, incident_id: str, *, judge_model: Optional[str] = None) -> AgentResult:
        # Audit narratives live in a separate /audit/* namespace, NOT the
        # ops incident namespace — audit trail belongs in its own scope so
        # ops agents can't tamper with it (RBAC enforces this).
        audit_namespace = f"/audit/{incident_id}"

        # Pull every memory for this incident from the ops namespace.
        # Note: NOT passing agent_id here. memledger v1's search() has an
        # overloaded agent_id (filters records AND signals RBAC identity);
        # passing self.agent_id would filter to records authored by the
        # auditor itself, returning zero. The auditor's read permission
        # on /ops/incidents/* is enforced separately by the RBAC policy
        # configured on the Memledger instance. Tracked as drift cleanup.
        result = await self.ml.search(
            query=f"incident {incident_id}",
            namespace=namespace,
            top_k=20,
        )
        records = sorted(result.records, key=lambda r: r.created_at)
        chain_text = "\n".join(
            f"  [{r.created_at.isoformat()}] {r.created_by or '?'} (conf={r.confidence:.2f}"
            f"{', hedged' if getattr(r, 'hedged', False) else ''}): {_clip(r.content, 200)}"
            for r in records
        )

        narrative = ""
        if records:
            user_msg = (
                f"Incident chain (chronological):\n{chain_text}\n\n"
                "Produce the audit narrative."
            )
            narrative = (await _call_llm(self.llm_model, self.SYSTEM_PROMPT, user_msg, temperature=0.1)).strip()

        # Run deterministic MAI evaluation. Phoenix annotation emitted by
        # the evaluator layer per B3 wiring.
        from evaluators import evaluate_attribution_integrity
        record_dicts = [
            {
                "id": r.id, "content": r.content[:200],
                "created_by": r.created_by, "confidence": r.confidence,
                "importance": r.importance, "session_id": r.session_id,
                "derived_from": r.derived_from, "hedged": getattr(r, "hedged", False),
                "namespace": r.namespace,
            }
            for r in records
        ]
        det_result = evaluate_attribution_integrity(incident_id, record_dicts)

        # Optional RAGAS LLM-judge tier — only if requested + extras installed.
        ragas_score = None
        if judge_model and record_dicts:
            try:
                from evaluators import evaluate_mai_ragas
                ragas_result = evaluate_mai_ragas(record_dicts, judge_model=judge_model)
                ragas_score = ragas_result.score
                logger.info("[auditor] RAGAS judge=%s score=%.3f", judge_model, ragas_score)
            except Exception as e:
                logger.warning("[auditor] RAGAS judge failed: %s", e)

        # Record the narrative + scores as a final audit memory in the
        # audit-only namespace.
        memory_id = await self.ml.add(
            content=narrative or "(no records to audit)",
            namespace=audit_namespace,
            agent_id=self.agent_id,
            created_by=self.agent_id,
            confidence=0.99,
            session_id=incident_id,
            derived_from=[r.id for r in records],
            metadata={
                "deterministic_mai_score": det_result.score,
                "deterministic_mai_passed": det_result.passed,
                "ragas_score": ragas_score,
            },
        )
        logger.info(
            "[auditor] memory=%s deterministic_mai=%.3f passed=%s ragas=%s",
            memory_id[:8], det_result.score, det_result.passed,
            f"{ragas_score:.3f}" if ragas_score is not None else "skipped",
        )
        return AgentResult(memory_id=memory_id, payload={
            "narrative": narrative,
            "deterministic_mai": {"score": det_result.score, "passed": det_result.passed, "explanation": det_result.explanation},
            "ragas_score": ragas_score,
            "chain_length": len(records),
        })


__all__ = [
    "AgentResult",
    "TriageAgent",
    "DiagnosisAgent",
    "RemediationAgent",
    "EscalationAgent",
    "AuditorAgent",
]
