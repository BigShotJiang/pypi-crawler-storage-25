"""examples/multi-agent — the SRE-incident scenario state machine.

Stage 1 (here): a fixed sequence of agents — triage → diagnosis →
remediation → (escalate?) → audit. Within each step the agent makes
autonomous LLM-driven decisions; only the *order* is fixed.

Stage 2 (B8b, future): replace the fixed sequence with self-routing
agents that decide their own next action.

The sample alert below is realistic for a small-scale production
SRE workflow: HikariCP pool exhaustion on a payment service, ambiguous
enough that triage *should* hedge — which then exercises B10's
weakest-link gate during remediation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

from agents import (
    AuditorAgent,
    DiagnosisAgent,
    EscalationAgent,
    RemediationAgent,
    TriageAgent,
)

if TYPE_CHECKING:
    from memledger.memledger import Memledger
    from config import Settings

logger = logging.getLogger(__name__)


# Sample alert — realistic but small-scale. Hedge-worthy on purpose.
SAMPLE_ALERT: dict[str, Any] = {
    "alert_id": "INC-2026-0513-001",
    "title": "DB connection pool exhaustion on payment-svc",
    "service": "payment-svc",
    "severity": "P2",
    "timestamp": "2026-05-13T10:23:00Z",
    "metrics": {
        "hikari_active": "10/10",
        "p95_latency_ms": 8200,
        "timeouts_per_min": 30,
        "duration_minutes": 4,
    },
    "runbook": "https://wiki.example.com/runbooks/db-pool",
    "description": (
        "HikariCP saturated on payment-svc for 4 minutes; p95 latency 8.2s; "
        "30 timeouts/min. Could be: actual traffic spike, leaked connections, "
        "or upstream DB slowness causing pool to fill. No deploy in the last "
        "2 hours. Slack #payments quiet (low traffic period normally)."
    ),
}


@dataclass
class ScenarioResult:
    incident_id: str
    namespace: str
    triage_memory_id: str
    diagnosis_memory_id: str
    remediation_memory_id: str
    escalation_memory_id: Optional[str]
    audit_memory_id: str
    remediation_decision: str  # "apply" | "escalate"
    deterministic_mai_score: float
    ragas_score: Optional[float]


async def run_sre_scenario(
    ml: "Memledger",
    settings: "Settings",
    *,
    alert: dict[str, Any] | None = None,
    confidence_min: float = 0.5,
    judge_model: Optional[str] = None,
) -> ScenarioResult:
    """Run one full SRE-incident scenario through the 5 agents.

    Args:
        ml: shared Memledger instance.
        settings: env-driven settings (LLM model, etc).
        alert: alert dict; defaults to SAMPLE_ALERT.
        confidence_min: passed to remediation's confidence_policy.
        judge_model: optional LiteLLM model for the RAGAS auditor judge.
            If None, RAGAS step is skipped. In CI we set this to a Bedrock
            Sonnet model (per project-multi-agent-example memory).

    Returns:
        ScenarioResult with memory IDs + key metrics for the test harness.
    """
    alert = alert or SAMPLE_ALERT
    incident_id = alert["alert_id"]

    # Instantiate the five agents, sharing the one Memledger instance.
    triage = TriageAgent(ml, settings.llm_model, "triage-agent")
    diagnosis = DiagnosisAgent(ml, settings.llm_model, "diagnosis-agent")
    remediation = RemediationAgent(ml, settings.llm_model, "remediation-agent")
    escalation = EscalationAgent(ml, settings.llm_model, "escalation-agent")
    auditor = AuditorAgent(ml, settings.llm_model, "auditor-agent")

    logger.info("=== SCENARIO START: %s ===", incident_id)

    # Step 1 — Triage. The LLM decides confidence; an ambiguous alert
    # should produce a hedged, low-confidence hypothesis.
    triage_result = await triage.triage(alert)
    namespace = triage_result.payload["namespace"]

    # Step 2 — Diagnosis. Locally confident; derived_from triage so
    # the chain min confidence is bounded by triage's value.
    diagnosis_result = await diagnosis.diagnose(namespace, triage_result.memory_id)

    # Step 3 — Remediation. Searches with confidence_policy; B10's
    # weakest-link gate fires. The LLM autonomously decides apply vs
    # escalate based on what survived the gate.
    remediation_result = await remediation.remediate(
        namespace, incident_id, confidence_min=confidence_min,
    )

    # Step 4 — Escalation (conditional, driven by the remediation LLM's
    # autonomous decision).
    escalation_memory_id: Optional[str] = None
    if remediation_result.payload["decision"] == "escalate":
        escalation_result = await escalation.escalate(
            namespace=namespace,
            incident_id=incident_id,
            parent_memory_id=remediation_result.memory_id,
            reason=remediation_result.payload.get("reason") or "(unspecified)",
        )
        escalation_memory_id = escalation_result.memory_id

    # Step 5 — Audit. Read-only across the incident chain; runs the
    # deterministic MAI evaluator and (optionally) the RAGAS LLM judge.
    audit_result = await auditor.audit(namespace, incident_id, judge_model=judge_model)

    logger.info("=== SCENARIO END: %s ===", incident_id)

    return ScenarioResult(
        incident_id=incident_id,
        namespace=namespace,
        triage_memory_id=triage_result.memory_id,
        diagnosis_memory_id=diagnosis_result.memory_id,
        remediation_memory_id=remediation_result.memory_id,
        escalation_memory_id=escalation_memory_id,
        audit_memory_id=audit_result.memory_id,
        remediation_decision=remediation_result.payload["decision"],
        deterministic_mai_score=audit_result.payload["deterministic_mai"]["score"],
        ragas_score=audit_result.payload["ragas_score"],
    )
