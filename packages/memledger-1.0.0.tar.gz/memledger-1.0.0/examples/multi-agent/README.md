# examples/multi-agent

A reference client demonstrating how memledger's v1 features compose in a
multi-agent system — **without Kubernetes**. Five agents coordinate
through a shared memledger instance over a five-step SRE incident flow.
Real LLM calls, real provenance chain, real evaluation.

## What this example exercises

| memledger feature | Where it shows up |
|---|---|
| `add()` / `search()` / `get()` | Every agent writes + reads memories |
| Multi-record types (semantic / episodic / procedural) | Triage writes episodic; auditor extracts semantic |
| Cross-agent `derived_from` chains | Diagnosis derives from triage; escalation derives from diagnosis |
| **Weakest-link confidence gate (B10)** | Remediation's `search(confidence_policy={...})` filters out a high-conf diagnosis built on a low-conf triage hunch |
| **Namespace RBAC (B11)** | Ops agents read+write `/ops/incidents/*`; auditor read-only + writes to `/audit/*` |
| OTEL spans → Phoenix | Every operation emits an OTLP span — visible at http://localhost:6006 |
| Per-span eval annotations (B3) | Deterministic MAI + RAGAS scores attached to `evaluators.mai_*` spans |
| Provenance chain rendering | `run.py` prints a Rich tree at the end of every run |

## Prerequisites

- Python 3.10+
- Docker (for local Postgres + Phoenix)
- An LLM provider key: **either** `ANTHROPIC_API_KEY` (default), **or** a running Ollama instance, **or** AWS credentials for Bedrock

For the AWS-gated pytest: AWS credentials with `bedrock:InvokeModel` access for `us.anthropic.claude-sonnet-4-5-20250929-v1:0`.

## Quickstart (3 commands)

```bash
# 1. Bring up Postgres + Phoenix
cd examples/multi-agent
docker compose up -d

# 2. Install deps (uses memledger 0.5.0a0+ from PyPI)
pip install -r requirements.txt

# 3. Run the scenario (Anthropic default; set ANTHROPIC_API_KEY first)
python run.py
```

That's it. Open http://localhost:6006 to see the traces, sessions, and eval annotations.

## Configuration

All knobs are env vars:

| Var | Default | Notes |
|---|---|---|
| `MEMLEDGER_PG_DSN` | `postgresql://postgres:postgres@localhost:5433/memledger` | Matches the compose file |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | `http://localhost:4317` | Phoenix gRPC OTLP receiver |
| `PHOENIX_BASE_URL` | `http://localhost:6006` | Phoenix HTTP API for eval annotations |
| `MEMLEDGER_EXAMPLE_LLM` | `anthropic/claude-sonnet-4-5-20250929` | LiteLLM-routable. Alts: `ollama/llama3.1` (zero-key) or `bedrock/anthropic.claude-sonnet-4-5-20250929-v1:0` |
| `ANTHROPIC_API_KEY` | — | Required if `MEMLEDGER_EXAMPLE_LLM` is Anthropic |
| `MEMLEDGER_JUDGE_MODEL` | unset → RAGAS skipped | Set to a LiteLLM model to enable the RAGAS auditor judge |

## The scenario

A scripted state machine (Stage 1) — agents make LLM-driven autonomous decisions, but the *sequence* is fixed.

```
[1. Triage]       Reads a noisy alert; produces a low-confidence,
                  hedged hypothesis (LLM autonomy).

[2. Diagnosis]    Reads Triage's memory; produces a high-conf
                  recommendation derived_from triage.

[3. Remediation]  Searches with confidence_policy → B10 weakest-link
                  gate fires. Effective confidence = min(declared,
                  chain min). LLM autonomously decides apply vs escalate.

[4. Escalation]   (Conditional) Records the escalation event with
                  full derivation chain preserved.

[5. Auditor]      Read-only across the incident chain. Generates a
                  narrative; runs deterministic MAI + (optional) RAGAS
                  judge. Writes to /audit/{incident_id} namespace
                  (separate from ops; tamper-evident).
```

## How agents talk to memledger (direct SDK)

Each agent is a Python class that imports `Memledger` and calls its async
methods directly — no HTTP, no extra service. That's the simplest pattern
for Python multi-agent systems and what `pip install memledger` is
designed for.

### When you'd reach for a different pattern instead

| Pattern | When | Where |
|---|---|---|
| **Direct SDK** (this example) | Python agents | `pip install memledger` |
| **FastAPI HTTP layer** | Browser frontend, or non-Python agents | [memledger-ui](https://github.com/memledger-ai/memledger-ui) (today); a general HTTP API is a v1.x+ candidate |
| **MCP server** | Framework-agnostic agents speaking Model Context Protocol | `memledger[mcp]` extra |

## What you'll see in Phoenix

### Spans tab — every memledger op classified by OpenInference kind

![Phoenix Spans tab with kind column](docs/phoenix-spans.png)

Every memledger operation emits an OTEL span. `kind` is set per
OpenInference convention so Phoenix's UI categorizes them:
- `memledger.memory.add`, `memledger.memory.search`, `memledger.get` → `RETRIEVER`
- `memledger.conflict_detected`, `memledger.promote`, `memledger.record_outcome` → `CHAIN`
- `evaluators.mai_deterministic`, `evaluators.mai_ragas` → `EVALUATOR`

### Sessions tab — grouped by `session.id`

![Phoenix Sessions tab](docs/phoenix-session.png)

memledger sets `session.id` on every span (alongside the legacy
`memledger.memory.session_id`), so Phoenix groups the 13 turns of an
incident under one session for end-to-end review.

### Span annotations — both eval tiers, attached to their spans

memledger pushes the deterministic MAI score and (when configured) the
RAGAS LLM-judge score as Phoenix span annotations on the matching
`evaluators.mai_*` span:

| Tier 1 — deterministic (annotator kind = CODE) | Tier 2 — RAGAS LLM-judge (annotator kind = LLM) |
|---|---|
| ![deterministic annotation](docs/phoenix-annotation-deterministic.png) | ![RAGAS annotation](docs/phoenix-annotation-ragas.png) |

The underlying OpenInference attributes set on the evaluator span
(`eval.framework`, `eval.score`, `eval.passed`, `eval.judge_model`,
`openinference.span.kind: EVALUATOR`, `session.id`):

![RAGAS evaluator attributes](docs/phoenix-annotation-ragas-eval.png)

### Evaluators tab (sidebar) — intentionally empty

The Phoenix **Evaluators** tab is its *dataset-experiment* framework, not
a viewer for span annotations. It stays empty in this example. For batch
replay against the labeled calibration dataset, use
`python evaluators/calibration/replay.py` from the repo root. Wiring
memledger's golden dataset into the Phoenix Datasets API is tracked as a
v1.x follow-up.

> Screenshots are in [`docs/`](docs/); they are the canonical source
> referenced from the README, the blog series (D5), and the public docs
> site (D2) build step.

## Testing

The reference client ships with an AWS-gated end-to-end test (real
Bedrock LLM calls + RAGAS judge):

```bash
docker compose up -d
export MEMLEDGER_PG_DSN=postgresql://postgres:postgres@localhost:5433/memledger
export AWS_REGION=us-west-2   # AWS creds via ~/.aws/credentials or env
pytest examples/multi-agent/tests/test_scenario.py -m aws -v
```

Two tests:
1. `test_scenario_runs_end_to_end` — runs the full 5-agent scenario;
   asserts memory IDs exist, remediation decision is valid, MAI scores
   are in range and clear the 0.7 floor.
2. `test_b10_gate_filters_weak_chain_in_situ` — focused B10 contract
   test (no LLM autonomy): plants a 0.30-confidence triage and a
   0.85-confidence diagnosis; asserts effective_confidence_map returns
   0.30 for the diagnosis and the gate filters/flags it.

Default `pytest` runs skip the AWS marker — opt in with `-m aws`.

## Roadmap

- Stage 1 (this commit + a handful of follow-ups): scripted flow. **Done.**
- Stage 2 (separate PR): autonomous mode — agents pick their next action.
- Future: alternate scenarios (multi-tenant RBAC, cross-namespace conflict resolution).
- Future: upload the golden dataset to Phoenix Datasets so the Evaluators tab populates.
