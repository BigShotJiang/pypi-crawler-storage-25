# Changelog

All notable changes to memledger will be documented in this file. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-05-17 — first stable release

memledger v1 — memory governance and trust layer for multi-agent AI
systems. The API is now stable; all subsequent releases follow SemVer.

### What v1 ships

- **Attribution** — every memory carries `created_by`, `confidence`,
  `session_id`, `derived_from`, `supersedes`, `workflow_id`,
  `triggered_by`, `hedged`, `namespace`.
- **Weakest-link provenance chain** — derivation chains tracked across
  agent boundaries; effective confidence at retrieval is
  `min(declared, chain.min_confidence)`. A high-confidence claim built
  on a low-confidence ancestor cannot outscore its weakest link.
- **Confidence-gated retrieval** — `PASS` / `FLAG` / `FILTER` policy
  applied at search time, against effective confidence.
- **Namespace RBAC** — declarative per-agent access control over
  hierarchical namespaces. `add()` and `search()` both gate on it.
  `requester_id` parameter explicitly identifies the calling agent for
  RBAC and audit.
- **3-tier evaluation suite** — deterministic Memory Attribution
  Integrity scorer + RAGAS LLM-as-judge (provider-agnostic via LiteLLM)
  + (optional) AWS Bedrock AgentCore evaluator.
- **OpenTelemetry observability** — every operation emits an OTLP span
  with `memledger.*` trust attributes; tier-1 set to OpenInference span
  kinds so Arize Phoenix categorizes them out of the box. `session.id`
  alias on every span for cross-system correlation.
- **Outcome feedback loop** — `record_outcome()` updates memory
  confidence based on observed downstream outcomes.
- **MCP server** — framework-agnostic adoption via Model Context
  Protocol (validated against LangGraph in v1; broader framework
  coverage in v1.5).
- **Helm chart** — `charts/memledger` deploys an in-cluster pgvector
  StatefulSet or wires to an external Postgres (Aurora, RDS, Supabase,
  Neon — same backend, different DSN).
- **CLI** — `memledger init / add / search / get --chain / eval /
  status` for human-driven flows and CI smoke testing.
- **Reference client** — `examples/multi-agent/` runs five LLM-driven
  SRE agents over a shared memledger with Phoenix observability and
  the deterministic + RAGAS evaluation tiers wired end-to-end.

### OSS path validated end-to-end

- fastembed (BAAI/bge-small-en-v1.5, 384d) round-trips through pgvector.
- Multi-agent scenario runs on Ollama (llama3.1:8b) via LiteLLM.
- All 7 always-on integration tests pass; full scenario passes on Ollama.

### From the alpha series

Rolls up everything in the 0.5.0a-series:
- 0.5.0a1: governance scaffold, search() requester_id split,
  build_chain parameter rename, NaN-coercion fix in RAGAS judge,
  Phoenix-fit telemetry attributes (openinference.span.kind +
  session.id alias on every span).
- 0.5.0a0: PyPI name reservation; first public alpha.

### Compatibility

Python **3.10 – 3.13**. Python 3.14 is excluded because the upstream
LangChain/RAGAS/LiteLLM stack still uses pydantic v1 in places, which
is incompatible with 3.14. Will lift the cap in a v1.0.x patch once the
ecosystem catches up. Required backend is open-source PostgreSQL ≥ 14
with the pgvector extension ≥ 0.5. Optional extras for AWS (Aurora,
Bedrock, DynamoDB, OpenSearch, AgentCore), Phoenix, MCP, and RAGAS.

## [0.5.0a1] — 2026-05-14 — alpha

Second alpha. Cosmetic + governance polish; no SDK behavior changes
outside the documented search() signature split.

### Added
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`, issue templates,
  and PR template.
- `.github/workflows/release.yml` — GitHub Release-triggered publish to PyPI
  via trusted publishing (OIDC). Tag-pushes trigger a TestPyPI sanity build.
- `search(requester_id=...)` — explicit RBAC / audit identity, separable
  from the `agent_id` filter.

### Changed
- README rewritten for PyPI rendering (absolute links, runnable
  `asyncio.run` quickstart, install line matches the default backend).
- `provenance.chain.build_chain(engram=...)` parameter renamed to
  `memledger=...`. All in-tree callers were positional — no caller updates.
- Phoenix telemetry: `openinference.span.kind` + `session.id` alias on
  every memory operation span; evaluators wrap their score-push in an
  `EVALUATOR`-kind span so Phoenix categorizes them out of the box.

### Fixed
- `__version__` now derives from `importlib.metadata.version("memledger")`
  so it cannot lag pyproject.toml.
- `instrument.py`: `record_type` default coerced to `RecordType.SEMANTIC`
  (was `None`, breaking attribute encoding).
- `examples/multi-agent/run.py` exports `PHOENIX_BASE_URL` explicitly so it
  doesn't fall back to the OTLP gRPC port.

## [0.5.0a0] — 2026-05-12 — **alpha (name-reservation release)**

First public alpha. Reserves the `memledger` name on PyPI and signals that
the v1 OSS launch is imminent. Use at your own risk; the stable `0.5.0`
release will follow when the launch checklist in
[docs/test-plan.md](docs/test-plan.md) is fully signed off.

### Added

- **Local fastembed embedding default** (`provider=local`,
  `BAAI/bge-small-en-v1.5`, 384 dims) so `pip install memledger[local,pgvector]`
  works without any cloud credentials.
- **`[aws]` umbrella extra** that pulls Bedrock + DynamoDB + SigV4 OpenSearch
  in one shot for AWS users.
- **Three-tier evaluator suite**:
  - Tier 1 — deterministic Memory Attribution Integrity (no LLM).
  - Tier 2 — RAGAS LLM-as-judge via LiteLLM (provider-agnostic;
    `MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini` / `bedrock/...` / `anthropic/...`
    / `ollama/...`).
  - Tier 3 — AWS Bedrock AgentCore evaluator (behind `[aws]` extra).
- **Arize Phoenix wiring** (`memledger.telemetry.phoenix.log_evaluation`) —
  best-effort, deployment-agnostic over OTLP + `arize-phoenix-client`.
- **OpenTelemetry promoted to core dependency** — observability ships by
  default with `pip install memledger`.
- **Weakest-link confidence gating** (`provenance/effective_confidence.py`)
  — a memory's effective confidence for retrieval is bounded by the weakest
  link in its upstream provenance chain. Wired into `search()` and
  `search_hybrid()`.
- **`ChainStore` abstraction seam** (`provenance/chain_store.py`) so v1.5+
  can swap the JSON-array chain walker for a graph-native implementation
  (Apache AGE / RecursiveCTE / Neo4j) without touching gating code.
- **`NamespaceRBAC` auto-enforcement** in `add()` and `search()` —
  caller-supplied agent identity, opt-in policy. (v2 will derive identity
  from kagent ServiceAccount / IRSA.)
- **User-facing CLI surface** (Typer): `init`, `add`, `search`, `get`,
  `status`, `eval`, `trace show`, `conflict check`. Demo / kagent-narrative
  commands hidden behind `--help`.
- **Golden-dataset replay harness** at `evaluators/calibration/replay.py`
  reporting accuracy, per-class accuracy, confusion matrix, MAE; the
  deterministic tier has a CI floor of 0.70 categorical accuracy.

### Changed

- AWS region across all modules now reads `$AWS_REGION` (defaulting to
  `us-west-2`); no more hardcoded literals.
- AWS-coupled integration tests live behind `pytest.mark.aws`; the default
  `pytest` run is AWS-free.
- `scripts/smoke_test.py` rewritten with OSS gates (L1–L4) as the default
  and AWS gates (A1–A4) behind `--with-aws` / `--aws-only`.
- AgentCore evaluator registration helper moved from
  `evaluators/attribution_integrity.py` into the AWS-only
  `evaluators/agentcore_evaluator.py` so the deterministic tier file
  has no boto3 or AWS dependencies.

### Removed

- The committed `config/evaluator_arns.json` artifact (contained an AWS
  account ID). The file is now gitignored. Git history has been rewritten
  to scrub the account ID from every commit.

### Deferred to v1.5 / v2 (not in this alpha)

- Graph-native chain storage (Apache AGE / Neo4j). The JSON-array walker
  is acceptable up to ~5 hops; the abstraction seam makes the swap a
  drop-in.
- Temporal decay and conflict detection at the SDK boundary
  (implementations exist; not wired into `add()` / `search()`).
- IRSA-based identity for `NamespaceRBAC`. v1 RBAC is
  agent-claimed-identity — best-effort, not a hard security boundary.
- AgentCore Evaluations + CloudWatch OTEL sink first-class wiring.

### Known limitations

- One pgvector integration test (`test_semantic_record`) is flaky due to
  float-precision in the storage round-trip (asserts `confidence == 0.95`
  exactly; the round-trip yields `0.949999988…`). Tracked.
- Test plan rows requiring manual sign-off (RAGAS LLM-judge end-to-end,
  Bedrock embedding full validation, kagent EKS Helm deploy, TestPyPI
  install round-trip, multi-Python-version testing) are open. The full
  list is in [docs/test-plan.md](docs/test-plan.md) and
  [docs/v1-feature-gap-check.md](docs/v1-feature-gap-check.md).

[0.5.0a0]: https://github.com/memledger-ai/memledger-core/releases/tag/v0.5.0a0
