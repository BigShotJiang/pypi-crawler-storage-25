"""Deterministic cascade failure scenario.

Demonstrates how a low-confidence memory from a flaky source cascades
through a multi-agent system, producing an incorrect final output.

Two modes:
1. BASELINE (no provenance) — failure cascades silently, no visibility
2. PROVENANCE (with confidence gating) — failure is caught or hedged

Run 20 times with different seeds; baseline should fail >=95%, provenance should recover >=80%.
"""

import asyncio
import hashlib
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class ScenarioResult:
    """Result of one scenario run."""
    seed: int
    mode: str  # "baseline" | "provenance"
    success: bool
    final_output: str
    root_cause_memory_id: str
    cascade_depth: int
    agents_involved: list[str] = field(default_factory=list)
    confidence_signals: list[dict] = field(default_factory=list)
    trace: list[str] = field(default_factory=list)  # Step-by-step trace for debugging


async def create_memledger_instance(
    connection_string: str = "",
    backend: str = "sqlite",
    db_path: str = "",
):
    """Create a fresh Memledger instance for a scenario run."""
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig, MemledgerConfig

    if backend == "pgvector" and connection_string:
        # Use real Bedrock embedder for Aurora (requires 1024 dimensions)
        ml = await Memledger.create(
            backend_name="pgvector",
            connection_string=connection_string,
            embedding_config=EmbeddingConfig(
                provider="bedrock",
                model="amazon.titan-embed-text-v2:0",
                dimensions=1024,
            ),
            engram_config=MemledgerConfig(strict_provenance=False),
        )
    else:
        # Use fake embedder for local sqlite testing
        class FakeEmbedder:
            dimensions = 64
            async def embed_single(self, text):
                h = hashlib.sha256(text.encode()).digest()
                return [(h[i % len(h)] / 255.0) - 0.5 for i in range(64)]
            async def embed_batch(self, texts):
                return [await self.embed_single(t) for t in texts]

        import tempfile
        if not db_path:
            db_path = tempfile.mktemp(suffix=".db")
        ml = await Memledger.create(
            backend_name="sqlite",
            backend_config={"path": db_path},
            embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=64),
            engram_config=MemledgerConfig(strict_provenance=False),
        )
        ml._embedder = FakeEmbedder()

    return ml


async def run_baseline(memledger, seed: int = 42) -> ScenarioResult:
    """Run the cascade failure WITHOUT provenance gating.

    Step 1: Research-agent stores a fact from a flaky blog (low confidence 0.25)
    Step 2: Ops-agent searches, finds it, treats it as truth (no confidence signal)
    Step 3: Ops-agent applies the wrong fix, stores the result
    Step 4: Capacity-agent reads ops-agent's result, confirms it as standard
    Result: Wrong standard propagated through 3 agents
    """
    from memledger import RecordType

    rng = random.Random(seed)
    trace = []

    # Step 1: Research-agent stores BAD fact (low confidence, flaky source)
    trace.append("Step 1: research-agent stores low-confidence fact from unverified blog")
    bad_fact_id = await memledger.add(
        content=f"max_connections should be set to {rng.randint(5, 15)} (from unverified blog post, not tested)",
        record_type=RecordType.SEMANTIC,
        created_by="research-agent",
        importance=0.25,  # LOW — but baseline mode doesn't gate on this
        confidence=0.25,  # F1: explicit confidence for trust layer
        source="random-blog-2024-no-peer-review",
        session_id=f"research-session-{seed}",
        metadata={"verified": False, "source_reliability": "low"},
    )
    trace.append(f"  Stored [{bad_fact_id[:8]}] with confidence=0.25")

    # Step 2: Ops-agent searches — NO confidence gating in baseline
    trace.append("Step 2: ops-agent searches for max_connections guidance")
    results = await memledger.search(
        "max_connections postgres",
        agent_id="ops-agent",
        top_k=5,
        # NO confidence_policy — baseline mode
    )

    if not results.records:
        trace.append("  No results found (unexpected)")
        return ScenarioResult(seed=seed, mode="baseline", success=False,
                             final_output="no_results", root_cause_memory_id=bad_fact_id,
                             cascade_depth=0, trace=trace)

    # Ops-agent picks the top result — doesn't see confidence signal
    top = results.records[0]
    trace.append(f"  Found [{top.id[:8]}] by {top.created_by} — NO confidence signal shown")
    trace.append(f"  Ops-agent treats this as authoritative truth")

    # Step 3: Ops-agent applies the bad recommendation
    trace.append("Step 3: ops-agent applies the (wrong) recommendation")
    ops_decision_id = await memledger.add(
        content=f"Applied max_connections={top.content.split('set to ')[1].split(' ')[0] if 'set to' in top.content else '10'} to payment-service based on memory [{top.id[:8]}]",
        record_type=RecordType.EPISODIC,
        created_by="ops-agent",
        importance=0.7,  # Ops-agent is confident in its own action
        derived_from=[top.id],  # Derived from the bad fact
        session_id=f"ops-session-{seed}",
        outcome="Applied configuration change",
    )
    trace.append(f"  Stored decision [{ops_decision_id[:8]}] derived from [{top.id[:8]}]")

    # Step 4: Capacity-agent reads ops decision, confirms as standard
    trace.append("Step 4: capacity-agent confirms the (wrong) standard")
    standard_id = await memledger.add(
        content=f"Team standard: {top.content.split('set to ')[1].split(' ')[0] if 'set to' in top.content else '10'} connections confirmed by ops team",
        record_type=RecordType.SEMANTIC,
        created_by="capacity-review-agent",
        importance=0.8,  # High confidence — capacity agent trusts ops
        derived_from=[ops_decision_id],
        session_id=f"capacity-session-{seed}",
        source="ops-team-confirmation",
    )
    trace.append(f"  Stored standard [{standard_id[:8]}] derived from [{ops_decision_id[:8]}]")
    trace.append("  FAILURE: Wrong standard propagated through 3 agents")

    return ScenarioResult(
        seed=seed,
        mode="baseline",
        success=False,  # Always fails — bad data cascaded without checks
        final_output=f"Wrong standard confirmed: {top.content}",
        root_cause_memory_id=bad_fact_id,
        cascade_depth=3,
        agents_involved=["research-agent", "ops-agent", "capacity-review-agent"],
        trace=trace,
    )


async def run_provenance(memledger, seed: int = 42) -> ScenarioResult:
    """Run the SAME scenario WITH provenance-aware retrieval.

    Same steps, but search() uses confidence gating.
    Step 2 now shows confidence signals — ops-agent can hedge or reject.
    """
    from memledger import RecordType

    rng = random.Random(seed)
    trace = []
    confidence_signals = []

    # Step 1: Same bad fact (unchanged — provenance doesn't prevent writes)
    trace.append("Step 1: research-agent stores low-confidence fact (same as baseline)")
    bad_fact_id = await memledger.add(
        content=f"max_connections should be set to {rng.randint(5, 15)} (from unverified blog post, not tested)",
        record_type=RecordType.SEMANTIC,
        created_by="research-agent",
        importance=0.25,
        confidence=0.25,
        source="random-blog-2024-no-peer-review",
        session_id=f"research-session-{seed}",
        metadata={"verified": False, "source_reliability": "low"},
    )
    trace.append(f"  Stored [{bad_fact_id[:8]}] with confidence=0.25")

    # Step 2: Ops-agent searches WITH confidence gating
    trace.append("Step 2: ops-agent searches WITH confidence gating")
    results = await memledger.search(
        "max_connections postgres",
        agent_id="ops-agent",
        top_k=5,
        confidence_policy={"min_threshold": 0.4, "flag_threshold": 0.6},
    )

    # Check if the bad memory was filtered
    filtered_out = True
    for r in results.records:
        if r.id == bad_fact_id:
            filtered_out = False
            flag = (r.metadata or {}).get("_confidence_flag", "PASS")
            signal = (r.metadata or {}).get("_confidence_signal", "")
            trace.append(f"  [{r.id[:8]}] confidence={r.importance} flag={flag}")
            trace.append(f"  Signal: {signal}")
            confidence_signals.append({"memory_id": r.id, "flag": flag, "signal": signal})

    if filtered_out:
        trace.append(f"  [{bad_fact_id[:8]}] FILTERED — confidence 0.25 < threshold 0.4")
        trace.append("  RECOVERY: Low-confidence memory never reached ops-agent")

        return ScenarioResult(
            seed=seed,
            mode="provenance",
            success=True,  # Recovered — bad memory filtered
            final_output="Low-confidence memory filtered by confidence gating",
            root_cause_memory_id=bad_fact_id,
            cascade_depth=0,
            agents_involved=["research-agent", "ops-agent"],
            confidence_signals=confidence_signals,
            trace=trace,
        )

    # If somehow not filtered (e.g., threshold was lower), agent still sees the flag
    trace.append("  Agent sees LOW CONFIDENCE warning — hedges decision")
    trace.append("  RECOVERY: Agent hedged based on confidence signal")

    return ScenarioResult(
        seed=seed,
        mode="provenance",
        success=True,
        final_output="Agent hedged on low-confidence memory",
        root_cause_memory_id=bad_fact_id,
        cascade_depth=1,
        agents_involved=["research-agent", "ops-agent"],
        confidence_signals=confidence_signals,
        trace=trace,
    )


async def run_comparison(
    connection_string: str = "postgresql://memledger:memledger@localhost:5433/memledger",
    num_runs: int = 20,
) -> dict[str, Any]:
    """Run baseline vs provenance comparison across multiple seeds.

    Returns aggregate statistics for both modes.
    """
    baseline_results = []
    provenance_results = []

    for seed in range(num_runs):
        # Baseline run
        memledger = await create_memledger_instance(connection_string)
        result = await run_baseline(memledger, seed=seed)
        baseline_results.append(result)
        await memledger.close()

        # Provenance run (fresh instance)
        memledger = await create_memledger_instance(connection_string)
        result = await run_provenance(memledger, seed=seed)
        provenance_results.append(result)
        await memledger.close()

    baseline_failures = sum(1 for r in baseline_results if not r.success)
    provenance_recoveries = sum(1 for r in provenance_results if r.success)

    return {
        "num_runs": num_runs,
        "baseline": {
            "failure_rate": baseline_failures / num_runs,
            "failures": baseline_failures,
            "avg_cascade_depth": sum(r.cascade_depth for r in baseline_results) / num_runs,
        },
        "provenance": {
            "recovery_rate": provenance_recoveries / num_runs,
            "recoveries": provenance_recoveries,
            "avg_cascade_depth": sum(r.cascade_depth for r in provenance_results) / num_runs,
        },
        "delta": {
            "failure_reduction": f"{((baseline_failures - (num_runs - provenance_recoveries)) / max(baseline_failures, 1)) * 100:.0f}%",
        },
    }


# CLI entry point
if __name__ == "__main__":
    import json

    async def main():
        print("Running cascade failure comparison (20 runs)...")
        results = await run_comparison(num_runs=20)
        print(json.dumps(results, indent=2))

        print(f"\nBaseline failure rate: {results['baseline']['failure_rate']:.0%}")
        print(f"Provenance recovery rate: {results['provenance']['recovery_rate']:.0%}")
        print(f"Failure reduction: {results['delta']['failure_reduction']}")

    asyncio.run(main())
