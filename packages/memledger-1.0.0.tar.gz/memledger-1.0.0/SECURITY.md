# Security Policy

## Supported versions

Pre-v1.0.0, only the latest published alpha receives fixes. Once v1.0.0 ships, the latest minor receives fixes.

## Reporting a vulnerability

Please use [GitHub's private reporting](https://github.com/memledger-ai/memledger-core/security/advisories/new), or email **security@memledger-ai.dev**. <!-- TODO: confirm contact address before v1.0.0 -->

Do not open a public issue or PR for security-sensitive findings.

Expect an acknowledgement within 5 business days. We coordinate disclosure with the reporter and credit researchers in the release notes unless anonymity is requested.
