# Phoenix — local trace + eval dashboard for memledger

[Arize Phoenix](https://github.com/Arize-ai/phoenix) is the eval framework
memledger ships with for v1. **memledger talks OTLP** and is fully
deployment-agnostic — Phoenix can run in-process, in Docker, in Kubernetes,
or as Arize Cloud. The files in this directory are one convenience option
(Docker Compose) for local development and integration tests.

## Four ways to run Phoenix — pick one

| Mode | When | Start |
|---|---|---|
| **In-process** | Jupyter / quick exploration in a notebook | `import phoenix as px; session = px.launch_app()` (after `pip install arize-phoenix`) |
| **Docker (this directory)** | Local dev, integration tests | `docker compose -f infra/phoenix/docker-compose.yml up -d` |
| **Kubernetes (Helm)** | Production-shape testing, kagent / EKS | `helm install phoenix arize-phoenix/phoenix` (separate from memledger's chart) |
| **Arize Cloud** | Hosted | `PHOENIX_BASE_URL=https://app.arize.com PHOENIX_API_KEY=...` |

## Point memledger at it

memledger reads three env vars (all optional):

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006   # spans → Phoenix
export PHOENIX_BASE_URL=http://localhost:6006              # eval annotations → Phoenix
# export PHOENIX_API_KEY=...                                # only for hosted/authenticated
```

If `OTEL_EXPORTER_OTLP_ENDPOINT` is unset, telemetry no-ops.
If `PHOENIX_BASE_URL` is unset (and falls back to `OTEL_EXPORTER_OTLP_ENDPOINT`),
eval-annotation logging no-ops gracefully.

## Quickstart (with this docker-compose)

```bash
docker compose -f infra/phoenix/docker-compose.yml up -d
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
export MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini      # for RAGAS eval; or bedrock/... / ollama/...
export OPENAI_API_KEY=sk-...                          # whichever judge provider
python scripts/smoke_test.py                          # OSS suite — L4 will push eval to Phoenix
open http://localhost:6006                            # see traces + evaluations
```

## Test plan coverage

| Test plan row | Covered by |
|---|---|
| O-20 (OTEL spans visible) | This setup |
| O-21 (RAGAS evals attached to spans) | This setup + `MEMLEDGER_JUDGE_MODEL` |
| C-3 (kagent proof point, k8s Phoenix) | Separate Helm install during kagent deploy — not this directory |
