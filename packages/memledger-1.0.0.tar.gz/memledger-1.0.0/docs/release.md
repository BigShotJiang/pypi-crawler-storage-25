# Release procedure

memledger releases are cut by maintainers via the GitHub Releases UI. The
`release.yml` workflow handles building, validating, and publishing through
**PyPI Trusted Publishing** (OIDC). No API tokens are stored in the repo.

## One-time setup (already done for v0.5.0a-series)

1. Register a trusted publisher for `memledger` on both indexes:
   - https://pypi.org/manage/account/publishing/
   - https://test.pypi.org/manage/account/publishing/
   - Repository: `memledger-ai/memledger-core`
   - Workflow: `release.yml`
   - Environments: `pypi` and `testpypi` respectively
2. Add two GitHub environments to this repo (`pypi`, `testpypi`) — they can be
   empty; they exist to scope the OIDC token.

## Cutting a release

1. Bump `version` in `pyproject.toml` and add a section to `CHANGELOG.md`. Open a PR; merge to `main`.
2. From `main`:
   ```bash
   git tag v0.5.0a1
   git push origin v0.5.0a1
   ```
   The `Release` workflow runs the **TestPyPI** job. Verify the package
   installs cleanly:
   ```bash
   pip install --index-url https://test.pypi.org/simple/ \
               --extra-index-url https://pypi.org/simple/ \
               --pre memledger==0.5.0a1
   python -c "from memledger import Memledger; print(Memledger)"
   ```
3. On GitHub, open **Releases → Draft a new release**, select the tag,
   paste the CHANGELOG section as release notes, click **Publish release**.
   The `Release` workflow now runs the **PyPI** job and ships the same
   artifacts that were validated on TestPyPI.

## Why this shape

- Trusted publishing eliminates long-lived PyPI tokens — credentials are
  per-job, short-lived OIDC.
- The tag → TestPyPI step gives a final sanity pass on a real index before
  any artifact reaches PyPI proper.
- The GitHub Release click is the deliberate human "go" — nothing reaches
  PyPI without a maintainer publishing the release.
- The workflow verifies tag/version parity so a mis-bumped pyproject can't
  ship.

## Rollback

PyPI does not allow republishing the same version. If a release is bad:
1. Yank it: `Manage` → `Yank release` on https://pypi.org/project/memledger/.
2. Bump to the next alpha/post version and re-cut.
