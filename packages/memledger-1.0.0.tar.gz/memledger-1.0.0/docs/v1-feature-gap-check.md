# memledger v1 — Feature Gap Check

## Status

**Transient launch-prep doc. Delete after v1 is tagged.**
Date: 2026-05-12 · Owner: Ratnopam Chakrabarti · Branch: `oss-phase-b`.

This file maps every spec'd-for-v1 capability against the current code in
`memledger-core` and surfaces what is still missing before the D-phase
(docs/release) of the launch checklist. It is not a roadmap; it is a
go/no-go matrix.

---

## Method

### Docs read (in full)
- `internal/product-brief.md` (canonical, 2026-05-11)
- `internal/strategy-and-roadmap.md`
- `internal/engram-design-strategy.md`
- `internal/engram-overview.md`
- `internal/engram-memory-research.md` (skimmed; mostly research grounding)
- `internal/evaluation-research.md`
- `internal/engram_trust_layer_spec_merged.md` (April engineering review; flagged for drift)
- `internal/kagent-ep-memory.md`
- `internal/kagent-memory-analysis.md` (skimmed)
- `internal/memledger-architecture-diagram.md`
- `internal/sync-design.md`

Skipped per instructions: `demo/`, `mvp-plan.md`, `notebooklm-feedback.md`,
`github-issues/`, `test-script-v030.md`, demo scripts.

### Code surveyed (directory + module level)
- `src/memledger/` — `memledger.py` (1688 LOC), `models.py`, `embeddings.py`
- `src/memledger/backends/` — `base`, `pgvector`, `sqlite`, `opensearch`,
  `dynamodb`, `composition`
- `src/memledger/policies/` — `confidence_policy`, `namespace_rbac`,
  `conflict_resolution` (incl. `PositionBiasTracker`), `temporal_decay`
- `src/memledger/provenance/` — `chain.py` (build/propagate/truncate),
  `models.py`, `schema.sql`
- `src/memledger/strategies/` — `audit`, `llm`, `policies`, `retrieval`,
  `scoring`
- `src/memledger/telemetry/` — `otel.py`, `instrument.py`, `memory_spans.py`,
  `phoenix.py`
- `src/memledger/mcp/server.py` (331 LOC)
- `src/memledger/cli/` — `main`, `demo`, `eval`, `eval_report`, `dashboard`
- `src/memledger/integrations/langgraph.py`
- `evaluators/` — `attribution_integrity` (deterministic),
  `attribution_integrity_ragas`, `attribution_integrity_structural`,
  `ragas_harness`, `agentcore_*`, `calibration/`
- `charts/memledger/` — `Chart.yaml`, `values.yaml`,
  `templates/{configmap,migration-job,postgres}.yaml`
- `scripts/` — `smoke_test.py`, `seed_demo_data.py`
- `pyproject.toml` — extras `[pgvector,opensearch,dynamodb,sqlite,mcp,bedrock,langgraph,eval,telemetry,local,aws,all,dev]`
- `tests/` — listed; `tests/integration/` and `tests/unit/` are present but
  empty (all tests sit flat in `tests/`)
- `docs/test-plan.md`

---

## Gap matrix

Legend:
- v1 scope: **yes** = product-brief §6/§8 + strategy §2 explicitly call this
  out as v1; **partial** = in-scope but spec only requires a slice;
  **no** = explicitly v2+.
- Implemented: ☑ in code · ⏳ partial / not wired through · ☐ missing.
- Tested: pytest row in `docs/test-plan.md` (O-# / A-#) or named test file.

### Memory model

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| M-01 | Attribution record (created_by, confidence, session_id, derived_from, supersedes, workflow_id, triggered_by, hedged, namespace) | product-brief §6.1; spec-merged F1 | yes | ☑ | ☑ | `src/memledger/provenance/models.py`; `models.py` `MemoryRecord`; `provenance/schema.sql` | None for v1. |
| M-02 | Typed records: Semantic, Episodic, Procedural | engram-design §3.3; engram-overview "Core Features" | yes | ☑ | ☑ test-plan O-07 | `src/memledger/models.py` | None. |
| M-03 | Cross-agent derivation chain (5-hop active, deeper in JSONB) | product-brief §6.3; spec-merged F2 | yes | ☑ | ☑ O-10 (`test_provenance_chain.py`) | `provenance/chain.py` (`build_chain`, `propagate_attribution`, `truncate_chain`) | None for chain build. See M-04. |
| M-04 | Weakest-link (min) confidence applied at retrieval gate | product-brief §6.3 + §7.1; strategy §2.1 day 1 | yes | ⏳ | ☐ | `provenance/chain.py:133` computes `min_confidence`; `memledger.py::search` (lines 593-713) gates only on declared `r.confidence` | **Wire `AttributionChain.min_confidence` into `apply_confidence_gating` / `search()` before launch.** Strategy §2.1 day 1 work — not done. |
| M-05 | Supersession / lineage edges | architecture-diagram; product-brief §6.1 | yes | ☑ | ☑ (`test_batch_apis.py` supersession) | `memledger.py::add`, `MemoryRecord.supersedes` | None. |
| M-06 | Outcome feedback loop (`record_outcome`) with asymmetric weighting; human_verified pins to 1.0 | product-brief §6.5 | yes | ☑ | ☑ O-13 (`test_feedback_loop.py`) | `memledger.py::record_outcome` (line 870); `strategies/scoring.py` | None. |
| M-07 | Auto-promotion (episodic → semantic/procedural after outcome threshold) | architecture-diagram; engram-design §11.4 | partial | ☑ | ☑ O-11 | `memledger.py::_check_auto_promote` (line 919) | None. |
| M-08 | Temporal decay (power-law staleness) | spec-merged F7; product-brief §6 | partial | ⏳ | ☐ explicit test | `policies/temporal_decay.py` (67 LOC, standalone `compute_decay`) | **Not wired into `search()` ranking.** Strategy §2.1 day 3. |
| M-09 | Conflict detection at write time | spec-merged F7 | partial | ⏳ | ☐ explicit | `policies/conflict_resolution.py::check_conflict` exists | **Not called from `add()`.** Wire-up pending. |
| M-10 | Lifecycle SM (active → deprecated → expired → archived) | architecture-diagram | partial | ☑ | ☑ O-09 | `models.py::MemoryStatus`; batch APIs in `memledger.py` | None. |
| M-11 | Optimistic concurrency / `content_hash` precondition | strategy §5.3 (NotebookLM Feature C) | no | ☐ | n/a | — | Deferred per strategy §4.2. |
| M-12 | Read-only namespace mode | strategy §5.4 | no | ☐ | n/a | — | Deferred. |

### Retrieval & search

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| R-01 | Similarity × confidence ranking | spec-merged F4; product-brief §6.4 | yes | ☑ | ☑ O-12 | `memledger.py::_rerank` (line 551); `strategies/scoring.py::compute_final_score` | None. |
| R-02 | Three-tier confidence policy (PASS ≥0.6 / FLAG 0.4-0.6 / FILTER <0.4) | product-brief §6.4; spec-merged F4 | yes | ☑ | ☑ O-16 (`test_attribution_integrity.py`) | `policies/confidence_policy.py`; `apply_confidence_gating`; wired in `memledger.py::search` 670-712 | None — gate is wired. Pairs with M-04 to be complete. |
| R-03 | Namespace prefix scoping | engram-design §11.7; engram-overview | yes | ☑ | ☑ O-06 | All backends; `memledger.py::search` `namespace=` arg | None. |
| R-04 | Hybrid search (vector + BM25 RRF, OpenSearch) | engram-design §11.4 | partial | ☑ | ☑ A-04 (behind `[aws]`) | `backends/opensearch.py`; `memledger.py::search_hybrid` (line 715) | None. |
| R-05 | Composite retrieval (episodes + procedures + failures) | engram-design §11.6 | yes | ☑ | ☑ | `strategies/retrieval.py::ContextualRecall`; `memledger.py::recall_context` (line 771) | None. |
| R-06 | Policy-based scoring (success_rate × recency × frequency) | engram-design §11.5 | yes | ☑ | ☑ O-12 | `strategies/scoring.py` | None. |
| R-07 | `plan_cascade()` / `get_downstream()` (blast-radius) | product-brief §8.1 / §10.1 | yes | ☑ | ☐ explicit test | `memledger.py::plan_cascade` (1354), `get_downstream` (1319) | **Add explicit test row** for v1 readiness. |
| R-08 | `get_lineage()` returns full chain + per-hop confidence/agents | product-brief §6.3 | yes | ☑ | ☑ O-10 | `memledger.py::get_lineage` (line 1158) | None. |
| R-09 | Namespace RBAC enforced at `search()` / `add()` boundary | product-brief §6.6 + §7.1; strategy §2.1 day 2 | yes | ⏳ | ☐ | `policies/namespace_rbac.py` (149 LOC, `NamespaceRBAC.check_access`); **not imported in `memledger.py`** (only `ConfidencePolicy` is) | **Auto-enforcement pending.** Strategy §2.1 day 2 — not done. |
| R-10 | Aurora RLS policies for namespace isolation | product-brief §6.6 | yes | ⏳ | ☐ | `provenance/schema.sql` present; no RLS policy template found in chart | ambiguous — schema does not include RLS policies; product brief explicitly claims this. Verify whether RLS shipped or quietly deferred. |

### Quality & evaluation

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| E-01 | Deterministic MAI evaluator (Option A — pure Python) | product-brief §6.7; spec-merged F11 (structural) | yes | ☑ | ☑ O-16 | `evaluators/attribution_integrity.py` (191 LOC) | None. |
| E-02 | LLM-as-judge MAI evaluator (RAGAS AspectCritic via LiteLLM) | product-brief §6.7; strategy §2.2 day 6 | yes | ☑ | ☐ O-17 (NEVER RUN) | `evaluators/attribution_integrity_ragas.py` (319 LOC); RAGAS extras in pyproject | **O-17 manual run with OpenAI judge has never been executed.** Must run before launch (test-plan §7 carry-over). |
| E-03 | Structural OTEL-span evaluator (Option B) | spec-merged F11 | yes | ☑ | ☐ explicit | `evaluators/attribution_integrity_structural.py` (304 LOC) | Verify a launch-time row in test-plan; currently no O-# pinned to it. |
| E-04 | Calibration set (30 examples, Cohen's κ, agreement rate) | spec-merged F10 | yes | ☑ | ☑ | `evaluators/calibration/dataset.jsonl`, `score_agreement.py`, `results.csv`, `results_summary.json` | None. |
| E-05 | Judge position-bias measurement | spec-merged F12 | partial | ☑ | ☐ explicit | `policies/conflict_resolution.py::PositionBiasTracker` (line 87) | No conflict-detection live judge call is wired (M-09), so the tracker has no traffic in v1. Document as instrumentation-only. |
| E-06 | Golden-dataset replay harness | strategy §2 deliverable; Phase B done | yes | ☑ | ☑ `test_golden_replay.py` + `evaluators/calibration/replay.py` | `evaluators/calibration/replay.py`, `replay_results.json` | None (Phase B5 done). |
| E-07 | AgentCore Evaluations registration (custom evaluator ARN) | spec-merged F6; evaluation-research §1.4 | partial (AWS-only, behind `[aws]`) | ☑ | ☐ A-08 (manual, not yet run) | `evaluators/agentcore_evaluator.py`, `agentcore_eval_runner.py`, `agentcore_harness.py` | A-08 manual sign-off pending. Acceptable to launch with this row waived since v1 is OSS-first. |
| E-08 | LiteLLM invariant test (no direct provider SDK calls outside `embeddings.py`/RAGAS) | strategy §2 (Phase B done) | yes | ☑ | ☑ | `tests/test_no_direct_llm_calls.py` | None. |
| E-09 | pgvector contract test | strategy §2 (Phase B done) | yes | ☑ | ☑ O-05/06/07 | `tests/test_pgvector_integration.py` | Caveat: `test_semantic_record` flake noted as carry-over. |
| E-10 | Multi-annotator MAI calibration (100+ examples, 3 annotators) | product-brief §7.6; spec-merged §9.2 | no | ☐ | n/a | — | Deferred (paper-scope). |
| E-11 | LongMemEval capability benchmark vs Mem0 / flat | product-brief §7.7; spec-merged §9.3 | no | ☐ | n/a | — | Deferred. |

### Observability

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| OB-01 | OTEL spans on every memory op (add/search/recall/outcome) | product-brief §6.8; spec-merged F9 | yes | ☑ | ☐ O-20 (manual) | `telemetry/otel.py` (549 LOC), `instrument.py`, `memory_spans.py` | Manual O-20 dashboard verification pending. |
| OB-02 | OTEL promoted to core (no `[telemetry]` extra needed for spans) | strategy Phase B done | yes | ☑ | ☑ | `pyproject.toml` lines 31-39 (otel-api/sdk/exporter in core deps) | None. |
| OB-03 | Phoenix wiring | strategy Phase B done | yes | ☑ | ☐ O-21 | `telemetry/phoenix.py` (141 LOC); `tests/test_phoenix_logging.py` | Manual O-21 (evals attached to spans in Phoenix UI) pending. |
| OB-04 | OTEL attribute schema consistency (`engram.*` vs `memledger.*` vs `engram.memory.*`) | product-brief §6.8 caveat; strategy §1.2 known gap | yes | ⏳ | ☐ | `telemetry/memory_spans.py` (uses `memledger.memory.*` per arch diagram); some downstream docs still reference `engram.memory.*` | **Fast-follow:** settle on one attribute prefix and update either code or doc set. Strategy §2.1 day 4 task. See "Drift findings." |
| OB-05 | Grafana / Prometheus dashboards JSON | spec-merged F9 | partial | ☐ | ☐ | No `infra/grafana/` directory found; only chart templates | ambiguous — spec'd in F9 but architecture-diagram + strategy describe Phoenix as the v1 surface. Treat Grafana as v2 unless we want to ship a single example JSON. |
| OB-06 | AWS X-Ray / CloudWatch export | product-brief §6.8 | partial (AWS-only) | ⏳ | ☐ | OTEL is OTLP-generic; no explicit AWS exporter wired | Acceptable: operators configure ADOT collector; chart should document this. |
| OB-07 | Trust Graph UI / Outcome Timeline | spec-merged F8/F13 | no | ☐ | n/a | — | Per product-brief, this is a demo artifact, not part of the OSS package. memledger-ui repo (separate). |
| OB-08 | CLI dashboard | code-visible | yes | ☑ | ☐ | `src/memledger/cli/dashboard.py` | Smoke test row missing; minor. |

### Backends

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| B-01 | `BackendProvider` ABC (7 methods, optional health/list/stats/access/outcome) | engram-design §11.4 | yes | ☑ | ☑ | `backends/base.py` | None. |
| B-02 | pgvector backend | product-brief §6.2 (primary) | yes | ☑ | ☑ O-05/06/07 | `backends/pgvector.py` | Carry-over: `table_name` config knob half-implemented. |
| B-03 | SQLite backend (sqlite-vec) | product-brief §6.2; strategy §2.1 day 4 | yes | ☑ | ☑ `test_sqlite_integration.py`, `test_default_backend.py` | `backends/sqlite.py` | None. |
| B-04 | OpenSearch backend (k-NN + BM25 + RRF) | product-brief §6.2 | partial (AWS-only) | ☑ | ☑ A-04 (manual) | `backends/opensearch.py` | Behind `[opensearch]`/`[aws]` extra — OK. |
| B-05 | DynamoDB backend | product-brief §6.2 | partial (AWS-only) | ☑ | ☑ A-03 (manual) | `backends/dynamodb.py` | Behind `[dynamodb]`/`[aws]` extra — OK. |
| B-06 | CompositionRouter (multi-backend writes / split read paths) | product-brief §6.2 | partial | ☑ | ☑ O-08 | `backends/composition.py` | None. |
| B-07 | `register_backend()` extension API | engram-design §3.7 | yes | ☑ | ☑ (smoke) | `memledger.py::register_backend` | None. |
| B-08 | Default backend = SQLite (no `MEMLEDGER_PG_DSN` required) | strategy §2.1 day 4 | yes | ☑ | ☑ `test_default_backend.py` | `memledger.py` registry; `MemledgerConfig` defaults | Verify CLI quickstart row O-23 manually. |
| B-09 | Local embeddings default (fastembed, BAAI/bge-small-en-v1.5, 384d) | strategy §2.1 day 4; Phase A done | yes | ☑ | ☑ O-03 | `embeddings.py` + `[local]` extra (`fastembed`) | First-run-download check O-04 still ☐. |
| B-10 | Bedrock embeddings behind `[bedrock]`/`[aws]` extra | strategy §2.1 day 4 (move litellm/Bedrock out of core); Phase A done | yes | ☑ | ☐ A-01 (manual, required) | `pyproject.toml` extras; `embeddings.py` provider switch | **A-01 has not been run — required for sign-off.** |
| B-11 | AWS evaluators (AgentCore) behind `[aws]` extra | strategy Phase A done | yes | ☑ | ☐ A-08 | `evaluators/agentcore_*.py`; pyproject `[aws]` | A-08 manual. |
| B-12 | AWS tests behind `pytest -m aws` | strategy Phase A done | yes | ☑ | ☑ | `pyproject.toml` `markers`, `addopts = "-m 'not aws'"` | None. |
| B-13 | S3 Vectors / Neo4j / Milvus | engram-design §7 Phase 3 | no | ☐ | n/a | — | Deferred. |

### Deployment

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| D-01 | Helm chart (configmap + migration job + optional in-cluster Postgres) | product-brief §8.3 | yes | ☑ | ☐ O-23 (kind), O-24 (EKS) | `charts/memledger/{Chart,values}.yaml`; `templates/{configmap,migration-job,postgres}.yaml` | **No `Deployment`/`StatefulSet` template visible for memledger itself** — chart is config-and-migration only. Verify whether this is intentional (sidecar / library pattern) or a gap. Likely intentional per engram-design §8 (engram is a library, not a service); doc this in chart README. |
| D-02 | CloudNativePG operator dependency in chart | strategy §2.2 day 8 | yes | ⏳ | ☐ | `charts/memledger/templates/postgres.yaml` ships plain Postgres StatefulSet, not CNPG `Cluster` CRD | Strategy §2.2 day 8 task — not done. May ship as a follow-up; flag for D-phase. |
| D-03 | Docker compose for local dev | engram-design §6 | yes | ☑ | ☐ | `docker-compose.yaml` at repo root | None. |
| D-04 | Container image published to ghcr.io | strategy §2.2 day 8 | yes | ☐ | ☐ | No CI workflow file visible at root | **Missing — release workflow.** Strategy §2.2 day 9. |
| D-05 | PyPI release pipeline (tag → publish) | strategy §2.2 day 9 | yes | ☐ | ☐ O-25/26 | No `.github/workflows/release.yml` visible | **Missing.** Required before public launch. |
| D-06 | `pip install memledger` works on macOS/Linux/Windows, no AWS account | strategy §2.3 | yes | ⏳ | ☐ O-25/26 | Path is plausible (`[local,pgvector]` extras), but never validated from a fresh wheel | **Manual O-26 (TestPyPI fresh install) is mandatory.** |
| D-07 | `memledger init && memledger demo` quickstart < 5 min | strategy §2.3 | yes | ⏳ | ☐ | `src/memledger/cli/demo.py` exists; verify `init` subcommand | **Validate end-to-end manually (O-28).** |
| D-08 | CHANGELOG, CONTRIBUTING, CODE_OF_CONDUCT, SECURITY | strategy §2.2 day 9 | yes | ☐ | n/a | None of these files were observed in the repo root listing | **Missing — D-phase task.** |

### SDK & CLI

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| S-01 | `Memledger.create()` + `from_config()` | product-brief §12.2 | yes | ☑ | ☑ (smoke L1-L4) | `memledger.py:199, 165` | None. |
| S-02 | Public API: `add`, `search`, `record_outcome`, `get_lineage`, `plan_cascade` | product-brief §8.1 | yes | ☑ | ☑ | `memledger.py` | None. |
| S-03 | Batch APIs (`get_stale`, `get_by_status`, `bulk_archive`, `bulk_update_status`, `get_by_session`, `get_by_timerange`) | product-brief §8.1 | yes | ☑ | ☑ O-09 | `memledger.py:1096-1158` | None. |
| S-04 | MCP server (6 tools: store/search/recall/delete/stats/namespaces) | product-brief §6.9 + §8.2 | yes | ☑ | ☐ explicit | `src/memledger/mcp/server.py` (331 LOC); `[mcp]` extra | No automated test row pinned; add one or smoke manually. |
| S-05 | LangGraph integration | engram-overview "Roadmap" | partial | ☑ | ☐ | `src/memledger/integrations/langgraph.py`; `[langgraph]` extra | OK as opt-in. |
| S-06 | CLI `memledger` entry point (status, init, demo, eval, dashboard) | strategy §2.1 day 5 | yes | ⏳ | ☐ O-02 | `cli/main.py`, `demo.py`, `eval.py`, `eval_report.py`, `dashboard.py` | **Verify `memledger init` exists and runs (strategy §2.3 acceptance).** |
| S-07 | `verify()` SDK operation (self-aware agents) | product-brief §7.8 | no | ☐ | n/a | — | Deferred. |
| S-08 | Sync engine (edge ↔ cloud, vector clocks) | sync-design.md | no | ☐ | n/a | — | Deferred; design-stage only. |
| S-09 | Lifecycle hooks (`on_add`, `on_update`, ...) | sync-design.md §Lifecycle Hooks | no | ⏳ | ☐ | `memledger.py:103-128` `LifecycleHooks` class exists | Class is present but only wired internally; not a v1 public API. |

### Docs & adoption

| # | Feature | Spec source | v1 scope | Implemented | Tested | Where in code | Gap / action |
|---|---|---|---|---|---|---|---|
| DOC-01 | mkdocs-material doc site (quickstart, concepts, API ref, contributing) | strategy §2.2 day 7 | yes | ☐ | ☐ O-27 | Separate `memledger-docs` repo (per test-plan); not in this repo | **Required for launch.** Tracked as D2 in test-plan. |
| DOC-02 | README quickstart that runs copy/paste on a clean machine | strategy §2.3 | partial | ⏳ | ☐ O-28 | `README.md` (3961 bytes) exists | **Manual verify O-28.** |
| DOC-03 | `docs/architecture.md` | code-visible | partial | ☑ | n/a | `docs/architecture.md` | None. |
| DOC-04 | `docs/test-plan.md` | this file's sibling | yes | ☑ | n/a | `docs/test-plan.md` | None (this gap-check supplements it). |
| DOC-05 | AWS reference architecture doc | strategy §3.1 | no (long-term) | ☐ | n/a | — | Deferred to month-1 long-term plan. |
| DOC-06 | Blog post series (3 posts) | strategy §3.2 | no (long-term) | ☐ | n/a | — | Deferred. |
| DOC-07 | KubeCon CFP submission | strategy §3.1 / product-brief §7.3 | no (parallel track, not a code gate) | n/a | n/a | — | Tracked separately. |
| DOC-08 | Apache 2.0 LICENSE | product-brief §12.1 | yes | ☑ | n/a | `LICENSE` (11357 bytes) | None. |

---

## Critical gaps

The following rows are ☐ or ⏳ and are explicitly in v1 scope. These are the
items that must move before the D-phase (docs/release) of the launch
checklist closes.

### P0 — blocks launch acceptance criteria

1. **M-04 — Weakest-link confidence wired into `search()` gate.**
   Strategy §2.1 day 1; product-brief §6.3 + §7.1 explicitly calls this the
   "highest-priority work item." `min_confidence` is computed in
   `provenance/chain.py:133` but `memledger.py::search` gates only on
   declared `r.confidence`. KubeCon abstract claim defensibility depends on
   this. **Owner action: 1-2 days eng.**

2. **R-09 — Namespace RBAC auto-enforced at `search()` / `add()`.**
   Strategy §2.1 day 2; product-brief §6.6 + §7.1. `NamespaceRBAC` class is
   never imported in `memledger.py`. Currently convention-only.
   **Owner action: 2-3 days eng.**

3. **D-04 / D-05 — Release pipeline.** No `.github/workflows/release.yml`
   observed; no ghcr.io image; PyPI tag → publish not wired. Strategy §2.2
   day 9. Without this, "v1 OSS launch" cannot happen mechanically.

4. **D-08 — CHANGELOG, CONTRIBUTING, CODE_OF_CONDUCT, SECURITY** missing
   from repo root. Strategy §2.2 day 9.

5. **DOC-01 — Doc site not built.** Test-plan O-27 (D2 task). Required by
   strategy §2.3 acceptance.

### P1 — required manual sign-offs that have never been executed

6. **E-02 / O-17 — RAGAS judge end-to-end with OpenAI** has never been
   run. Test-plan §7 explicitly flags this as "NEVER RUN — must do before
   launch."

7. **B-10 / A-01 — Bedrock embedding path with pgvector(1024 dims)**
   never validated end-to-end. Required for the "AWS-primary embedding path
   works" claim.

8. **M-08 — Temporal decay** not wired into retrieval ranking. Module is
   built and unit-tested but not called from `search()` ranking. Strategy
   §2.1 day 3.

9. **M-09 — Conflict detection** not called from `add()`. `check_conflict`
   exists but is dead code at SDK boundary.

10. **D-06 / O-26 — TestPyPI fresh-install smoke** never executed.

11. **OB-04 — OTEL attribute prefix consistency** (`engram.*` vs
    `memledger.*` vs `engram.memory.*`). Strategy §2.1 day 4. Settle once
    before launch.

### P2 — verify-before-claim

12. **R-10 — Aurora RLS policies** are claimed in product-brief §6.6 but no
    RLS template was observed in `charts/memledger/templates/`. Either ship
    the SQL template or remove the claim.

13. **D-02 — CloudNativePG operator** in chart; currently a plain Postgres
    StatefulSet (`templates/postgres.yaml`).

14. **OB-05 — Grafana dashboard JSON** spec'd in F9 but no `infra/grafana/`
    in repo. Likely safe to defer (Phoenix is the v1 surface), but doc it.

---

## Deferred to v2+ (per docs)

These are explicitly out of v1 per product-brief, strategy, or
spec-merged. None should appear in the launch claims.

| # | Capability | Source |
|---|---|---|
| 1 | Adversarial validation (confidence trajectory, cross-agent verify, pre-write conflict) | product-brief §7.4 |
| 2 | Efficacy metrics (cascade failure rate, mean confidence at decision time, stale retrieval rate) | product-brief §7.5 |
| 3 | MAI metric family (Confidence Drift Index, Staleness Severity, Cross-Agent Contamination Index, Cascade Depth Score) | product-brief §7.6 |
| 4 | LongMemEval capability benchmark vs Mem0 / Zep / flat | product-brief §7.7; spec-merged §9.3 |
| 5 | Self-aware agents / `verify()` SDK / evolving substrate | product-brief §7.8 |
| 6 | Multi-annotator MAI calibration (100+, 3 annotators, κ>0.7) | product-brief §10.3; spec-merged §9.2 |
| 7 | Dreaming / active curation engine | strategy §5.1 |
| 8 | Verification backfill (`last_corroborated_at`, `verified_by_agent`) | strategy §5.2 |
| 9 | Optimistic concurrency / `content_hash` | strategy §5.3 |
| 10 | Read-only / append-only namespace mode | strategy §5.4 |
| 11 | AgentCore Memory sidecar / self-managed strategy / native schema | product-brief §5.3; strategy §3.2 |
| 12 | Native Neo4j / graph backend | strategy §4.4 |
| 13 | S3 Vectors cold-storage backend | engram-design §7 Phase 3 |
| 14 | Edge ↔ cloud sync engine (`SyncEngine`, vector clocks, privacy tier) | `sync-design.md` |
| 15 | Trust Graph UI + Outcome Timeline animation | spec-merged F8/F13 (lives in `memledger-ui`, separate repo) |
| 16 | AWS X-Ray / CloudWatch native exporter | product-brief §6.8 (OTLP is generic; AWS routing via ADOT is operator config) |

---

## Drift findings

The engineering review (`engram_trust_layer_spec_merged.md`) carries the
"may have drifted" warning from product-brief §12.4. The following places
disagree with current code:

| # | Drift | Spec says | Code says | Resolution |
|---|---|---|---|---|
| 1 | OTEL attribute prefix | F11 / §7.3 say `engram.memory.confidence`, `engram.memory.provenance.source_agent` | `telemetry/memory_spans.py` + architecture-diagram use `memledger.memory.*`; product-brief §6.8 acknowledges the mismatch as a "fast follow" | Pick one prefix repo-wide. Recommend `memledger.memory.*` (matches package name and arch diagram). Update doc set or code accordingly. |
| 2 | "engram" identifier still in code | Both docs refer to package as `memledger` v0.4.0 | `provenance/chain.py:21` retains `engram` as a function parameter name (per test-plan §7 carry-over); `instrument_engram`, `setup_engram_telemetry` exported from `__init__.py` | Brand rename leakage. Cosmetic but visible to OSS users on day 1. |
| 3 | F8 Trust Graph UI / F13 Outcome Timeline | Spec-merged calls these P0/P1 with file paths `ui/app.py` | No `ui/` directory in `memledger-core` | These live in the separate `memledger-ui` repo (per architecture-diagram). Engineering-review path is stale; product-brief §6 correctly omits the UI from the core package. |
| 4 | AgentCore-first F6 path | Spec-merged makes AgentCore Evals the primary eval path | Phase-A pivot moved AWS evaluators behind `[aws]`; RAGAS/LiteLLM is the OSS default. `evaluators/__init__.py` exposes deterministic + RAGAS as core; AgentCore is optional. | Product-brief §6.7 already supersedes spec-merged here. No code change; treat spec-merged §3 F6 as historical. |
| 5 | Chart deployment target | Spec-merged §4.1 lists `infra/kagent/agents.yaml`, `infra/otel-collector.yaml`, `infra/grafana/memory-dashboard.json` | Only `charts/memledger/templates/{configmap,migration-job,postgres}.yaml` exists; `infra/` at repo root has minimal contents | Spec-merged infra layout never landed in this repo; it described the April demo cluster, not the OSS chart. Either delete the layout snippet from spec-merged or mark it as "demo-only." |
| 6 | "5 backends implemented" | product-brief §6.2 lists pgvector, SQLite, OpenSearch, DynamoDB, CompositionRouter | `src/memledger/backends/` has exactly these 5 (`base.py` + 5 implementations) | No drift — confirmed accurate. |
| 7 | "Aurora RLS policies" | product-brief §6.6 claims RLS is enforced in Aurora | No RLS DDL observed in `provenance/schema.sql` or chart templates | See critical gap R-10. Either ship the SQL or soften the claim. |
| 8 | Conflict detection at write-time | product-brief §7.1 says "conflict surfacing fires at write time" (in progress) | `check_conflict` is present but not called from `Memledger.add()` | Strategy §2.1 day 3 work — code matches "in-progress" framing. Wire-up still pending for v1. |
| 9 | Position-bias instrumentation traffic | spec-merged F12 says position-bias is reported during conflict judge calls | `PositionBiasTracker` exists but conflict judge is never invoked from `add()` (see drift 8) | Tracker is instrumentation-only in v1. Document as such; do not claim live position-bias numbers in launch material. |
| 10 | OTEL evaluator (F11 Lambda) | spec-merged F11 mentions Lambda deployment for structural evaluator | Code runs `attribution_integrity_structural.py` as local Python only | Spec-merged itself allows this ("local Python for the demo; Lambda is post-demo"). No drift — already reconciled. |

---

*memledger v1 feature gap check · 2026-05-12 · Ratnopam Chakrabarti · transient — delete after v1 tag*
