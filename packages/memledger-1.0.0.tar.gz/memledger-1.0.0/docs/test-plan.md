# Memledger v1 Launch Test Plan

Owner: Ratnopam Chakrabarti
Last updated: 2026-05-12 (initial)

This is the gate for v1 launch. **No feature ships to PyPI / public GitHub
until its row here is signed off as PASS or explicitly waived.**

---

## 0. Ground rules

1. Every feature has an OSS-path test scenario AND (where applicable) an AWS-path test scenario.
2. **Manual** scenarios are marked `[manual]` — they require a human to inspect output / dashboard / behavior.
3. **Both embedding paths** (`provider=local` and `provider=bedrock`) must be exercised before any embedding-touching claim of "works".
4. Each scenario records: who ran it, when, the verdict, and a link to the log/screenshot.
5. `pytest` passing is a necessary but not sufficient condition. A green pytest run does not by itself satisfy a feature's launch row.

---

## 1. Test environments

| Env | Purpose | How to provision |
|---|---|---|
| **E1 — Clean OSS venv** | Default `pip install memledger[local,pgvector]` path on a machine with **no AWS creds** | `python3 -m venv .venv && source .venv/bin/activate && pip install memledger[local,pgvector]` |
| **E2 — OSS + AWS venv** | `pip install memledger[local,pgvector,aws]` with `aws configure` done | extend E1 with `[aws]` and AWS creds |
| **E3 — Docker pgvector** | Backs L3 / pgvector tests | `docker run -d -p 5433:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16` |
| **E4 — Local Phoenix** | Trace + eval dashboard | `docker run -p 6006:6006 -p 4317:4317 arizephoenix/phoenix:latest` |
| **E5 — Kagent on EKS** | Helm chart + AWS-side integration | Existing kagent cluster; deploy `charts/memledger` |
| **E6 — AWS resources** | OpenSearch, Aurora, DynamoDB, AgentCore | Pre-provisioned by scripts under `scripts/` (one-time per launch run) |

---

## 2. OSS path — feature × test matrix

| # | Feature | Test type | Scenario | Auto/Manual | Env | Status |
|---|---|---|---|---|---|---|
| O-01 | Package install | sdist + wheel build | `python -m build`; `pip install dist/memledger-*.whl` in fresh venv; `python -c "import memledger; from evaluators import evaluate_attribution_integrity"` | Auto | E1 | ☐ |
| O-02 | CLI entry point | Smoke | `memledger --help`, `memledger status` | Auto + `[manual]` for output review | E1 | ☐ |
| O-03 | Local embedding (fastembed) | Unit | `tests/test_embeddings_local.py` (shape, caching) | Auto | E1 | ☑ pytest-pass 2026-05-12 |
| O-04 | Local embedding — first-run download | `[manual]` | Delete `~/.cache/fastembed`; run smoke L2; verify ~130 MB downloads exactly once | Manual | E1 | ☐ |
| O-05 | pgvector backend — CRUD | Integration | `tests/test_pgvector_integration.py` (add/get/update/delete/health) | Auto | E1 + E3 | ☑ pytest-pass except `test_semantic_record` (float precision; bug filed) |
| O-06 | pgvector backend — namespace isolation | Integration | `tests/test_pgvector_integration.py::test_namespace_isolation` | Auto | E1 + E3 | ☑ |
| O-07 | pgvector backend — record types (semantic/episodic/procedural) | Integration | tests in `test_pgvector_integration.py` | Auto | E1 + E3 | ☑ except O-05 caveat |
| O-08 | Composition router | Integration | `tests/test_composition.py` (add+search route, lifecycle, soft delete, batch APIs, health) | Auto | E1 + E3 | ☑ |
| O-09 | Batch APIs | Integration | `tests/test_batch_apis.py` (get_by_session, get_stale, bulk_update_status, bulk_archive, supersession) | Auto | E1 + E3 | ☑ |
| O-10 | Provenance / derivation chain | Integration | `tests/test_provenance_chain.py` | Auto | E1 + E3 | ☑ |
| O-11 | Auto-promotion (episodic → procedural) | Integration | `tests/test_feature_validation.py::TestAutoPromotion` | Auto | E1 + E3 | ☑ (post engram→memledger string fix) |
| O-12 | Scoring (importance, recency, frequency, outcome) | Integration | `tests/test_scoring.py` | Auto | E1 + E3 | ☑ |
| O-13 | Feedback loop (success/failure → ranking) | Integration | `tests/test_feedback_loop.py` | Auto | E1 + E3 | ☑ |
| O-14 | Strategy / policy engine | Unit | `tests/test_strategies.py` | Auto | E1 | ☑ |
| O-15 | Conflict detection (high similarity warnings) | Integration | `tests/test_feature_validation.py` (relevant subtests) | Auto | E1 + E3 | ☑ if covered there; otherwise add scenario |
| O-16 | Deterministic MAI evaluator | Unit | `tests/test_attribution_integrity.py` (penalty paths, threshold) | Auto | E1 | ☑ |
| O-17 | RAGAS LLM-as-judge — OpenAI judge | E2E `[manual]` | `export MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini OPENAI_API_KEY=...`; `python scripts/smoke_test.py`; confirm L4 prints `RAGAS judge=openai/...` with score | Manual | E1 + key | ☐ NEVER RUN — must do before launch |
| O-18 | RAGAS LLM-as-judge — local Ollama judge | E2E `[manual]` | `ollama serve`; `export MEMLEDGER_JUDGE_MODEL=ollama/llama3.1`; rerun smoke | Manual | E1 + Ollama | ☐ optional |
| O-19 | Golden dataset replay (B5 deliverable) | E2E | `pytest evaluators/calibration/` after B5 lands | Auto | E1 | ☐ depends on B5 |
| O-20 | OTEL spans emitted | E2E `[manual]` | Start Phoenix (E4); set `OTEL_EXPORTER_OTLP_ENDPOINT`; run a 10-memory script; open `http://localhost:6006`; confirm spans for `memory.add` / `memory.search` / `evaluate_attribution_integrity` | Manual | E1 + E4 | ☐ |
| O-21 | OTEL + RAGAS evals linked in Phoenix | E2E `[manual]` | Same as O-20 + O-17; confirm evals attach to spans in Phoenix Evaluations tab | Manual | E1 + E4 | ☐ |
| O-22 | Smoke test L1..L4 green | Auto | `python scripts/smoke_test.py` → `OSS_READY` | Auto | E1 + E3 | ☑ 2026-05-12 |
| O-23 | Helm chart — local kind cluster | E2E `[manual]` | `kind create cluster`; `helm install memledger charts/memledger --set embeddings.provider=local`; verify pod ready, migration job green, run `kubectl exec` to add+search 1 memory | Manual | kind + local | ☐ |
| O-24 | Helm chart — kagent EKS cluster | E2E `[manual]` | Deploy on real kagent EKS; capture latency, agent-pod logs, kubectl outputs, screenshots | Manual | E5 | ☐ (C3 task) |
| O-25 | PyPI release artifacts | E2E | `python -m build && twine check dist/*` | Auto | E1 | ☐ (C1 task) |
| O-26 | `pip install memledger` from TestPyPI | E2E `[manual]` | `twine upload --repository testpypi`; fresh venv; `pip install -i https://test.pypi.org/simple/ memledger[local,pgvector]`; rerun smoke | Manual | E1 + TestPyPI | ☐ (C1 task) |
| O-27 | Docs site builds | Auto | `cd memledger-docs && npm run build` | Auto | E1 + node | ☐ (D2 task) |
| O-28 | Quickstart from README — copy/paste | `[manual]` | Take memledger-core README quickstart verbatim, run on a clean machine, every command must succeed | Manual | E1 | ☐ (D1 task) |
| O-29 | memledger-ui demo end-to-end | E2E `[manual]` | `docker compose up` in memledger-ui; open browser; demo add + search + lifecycle | Manual | memledger-ui env | ☐ (D3 task) |

---

## 3. AWS path — feature × test matrix

| # | Feature | Test type | Scenario | Auto/Manual | Env | Status |
|---|---|---|---|---|---|---|
| A-01 | Bedrock embedding (Titan v2) | E2E `[manual]` | Set `embeddings.provider=bedrock`, `model=amazon.titan-embed-text-v2:0`, `dimensions=1024`. Recreate pgvector table at 1024. Run smoke L2 + L3 with this config | Manual | E2 + E3 | ☐ — required: confirms the AWS-primary embedding path actually works |
| A-02 | Bedrock LLM strategies (importance/gating/reranking) | E2E `[manual]` | `MEMLEDGER_STRATEGY_MODEL=bedrock/...` walkthrough; observe LLM-driven importance scores via `memledger.add(...)` | Manual | E2 | ☐ |
| A-03 | DynamoDB backend | Integration (`-m aws`) | `tests/test_dynamodb_integration.py` with `ENGRAM_TEST_DDB_TABLE` set; run `./scripts/dynamodb-test.sh create` first | Auto behind marker | E2 + E6 | ☐ |
| A-04 | OpenSearch SigV4 backend | Integration (`-m aws`) | `tests/test_opensearch_integration.py` with `ENGRAM_TEST_OS_ENDPOINT` | Auto behind marker | E2 + E6 | ☐ |
| A-05 | Multi-backend composition (DynamoDB primary + OpenSearch search) | Integration (`-m aws`) | `tests/test_composition_aws.py` | Auto behind marker | E2 + E6 | ☐ |
| A-06 | Aurora Postgres + pgvector | Smoke A3 | `export ENGRAM_TEST_AURORA_DSN=...`; `python scripts/smoke_test.py --with-aws` | Auto | E2 + Aurora | ☐ |
| A-07 | Smoke A1 — Bedrock invoke | Auto | `python scripts/smoke_test.py --with-aws` | Auto | E2 | ☑ 2026-05-12 |
| A-08 | AgentCore evaluator registration | E2E `[manual]` | `pip install bedrock-agentcore-starter-toolkit`; `python -c "from evaluators import register_agentcore_evaluator; print(register_agentcore_evaluator())"`; verify ARN returned + visible in AWS console | Manual | E2 + AgentCore | ☐ |
| A-09 | AgentCore + RAGAS parity | E2E `[manual]` | Same 10-record dataset: deterministic MAI, RAGAS (`bedrock/claude-sonnet-4-...` judge), AgentCore evaluator. Compare scores; document deltas | Manual | E2 + Phoenix | ☐ |
| A-10 | EKS Helm install with Bedrock | E2E `[manual]` | `helm install memledger ./charts/memledger --set embeddings.provider=bedrock --set embeddings.dimensions=1024 ...`; verify pod has Bedrock access via IRSA; smoke add+search from in-pod | Manual | E5 | ☐ |
| A-11 | OTEL → CloudWatch (future / v2) | `[manual]` | Out of v1 scope; reinstate at v2 launch | — | — | N/A |

---

## 4. Cross-cutting / non-functional

| # | Concern | Test |
|---|---|---|
| X-01 | Python 3.10, 3.11, 3.12, 3.13 install + smoke L1..L4 | `tox` matrix (add) or manual rebuild per version |
| X-02 | macOS arm64 + Linux x86_64 install | Run smoke on at least one of each |
| X-03 | First-run model download under poor network | `[manual]` — disconnect Wi-Fi mid-download, verify clean retry message |
| X-04 | Concurrent writes to pgvector | Stress: 100 parallel `add()` calls, no deadlocks, no data loss |
| X-05 | Latency budget | Single `add()` < 500 ms (local), single `search()` < 200 ms over 10k records |
| X-06 | License + SBOM | `pip-licenses` and `cyclonedx-py` output reviewed for non-compatible licenses (E2 task) |
| X-07 | Secret scan (final) | `gitleaks` over `memledger-core`, `-docs`, `-ui` before public flip (E3 task) |
| X-08 | Quickstart docs accuracy | Already covered by O-28 |

---

## 5. Pre-launch exit criteria

The launch checklist signs off only when **all of the following** are true:

1. Every row in §2 (OSS) is ☑ or has a written waiver.
2. At least these AWS rows in §3 are ☑: A-01, A-03, A-04, A-05, A-07. The rest may be ☑ or written waiver.
3. All cross-cutting rows in §4 except X-04, X-05 (waivable if v1 explicitly scoped as alpha) are ☑.
4. `git log --all -p -S "489829964455"` returns empty across all three repos (Phase 2 history scrub verification).
5. Final smoke run on a **fresh** machine (E1 from scratch) within 24 h of the public flip.

---

## 6. Test run log template

For every scenario above, fill in when executed:

```
- Scenario: O-17 RAGAS judge — OpenAI
  Date: 2026-05-XX
  Operator: <name>
  Environment: E1 (Python 3.13.5, fastembed 0.8.0, memledger 0.5.0rc1)
  Command:
    export MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini
    export OPENAI_API_KEY=sk-...
    python scripts/smoke_test.py
  Expected: L4 prints `RAGAS judge=openai/gpt-4o-mini score=…`, verdict OSS_READY
  Actual: <paste verbatim>
  Verdict: PASS / FAIL / WAIVED (with reason)
  Artifact: <path-to-log-or-screenshot>
```

Logs go to `docs/test-runs/<scenario-id>-<date>.md` (create the dir at first run).

---

## 7. Known carry-overs (already filed, not blockers for the plan)

- `test_pgvector_integration.py::test_semantic_record` — flaky on `0.95` exact-float assertion; convert to `pytest.approx`.
- `CREATE_TABLE_SQL` in `pgvector.py` hardcodes `agent_memory` while queries use `self._table` — the `table_name` config knob is half-implemented.
- `bedrock-agentcore-starter-toolkit` not in `[aws]` extra — deliberate; revisit before A-08 sign-off.
- `engram` identifier still used as a function parameter in `provenance/chain.py:21` — wider brand rename pending.
