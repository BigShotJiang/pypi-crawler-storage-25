# memledger — End-to-End Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                    Amazon EKS (kagent)                                  │
│                                  Cluster: kagents-mem-eks                                │
│                                                                                         │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  ┌─────────────────┐  │
│  │  eks-ops-agent   │  │  triage-agent    │  │ compliance-agent │  │ research-agent  │  │
│  │                  │  │                  │  │                  │  │  (simulated)    │  │
│  │  LangGraph +     │  │  LangGraph +     │  │  LangGraph +     │  │  Seeded data    │  │
│  │  Bedrock Claude  │  │  Bedrock Claude  │  │  Bedrock Claude  │  │  conf=0.25-0.30 │  │
│  │  33 tools        │  │  A2A protocol    │  │  A2A protocol    │  │                 │  │
│  │  (20 MCP +       │  │                  │  │                  │  └─────────────────┘  │
│  │   13 memory)     │  │                  │  │                  │                        │
│  └────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘                        │
│           │                     │                     │                                   │
│           │  A2A (agent-to-agent protocol)             │                                   │
│           │◄────────────────────┤◄────────────────────┘                                   │
│           │                     │                                                         │
│           ▼                     ▼                                                         │
│  ┌─────────────────────────────────────────┐                                              │
│  │          memledger SDK (v0.4.0)         │                                              │
│  │                                         │                                              │
│  │  Memory Operations:                     │                                              │
│  │  ├─ add() — with conflict detection     │                                              │
│  │  ├─ search() — with confidence gating   │                                              │
│  │  ├─ get_lineage() — provenance chain    │                                              │
│  │  ├─ record_outcome() — success/failure  │                                              │
│  │  ├─ plan_cascade() — downstream impact  │                                              │
│  │  └─ get_stale() — temporal decay        │                                              │
│  │                                         │                                              │
│  │  Policies:                              │                                              │
│  │  ├─ ConfidencePolicy (PASS/FLAG/FILTER) │                                              │
│  │  ├─ ConflictResolution (detect+resolve) │                                              │
│  │  ├─ TemporalDecay (1%/day, 90d TTL)    │                                              │
│  │  └─ CascadeInvalidation (auto/flag)     │                                              │
│  │                                         │                                              │
│  │  Record Types:                          │                                              │
│  │  ├─ SEMANTIC (facts, knowledge)         │                                              │
│  │  ├─ EPISODIC (events, incidents)        │                                              │
│  │  └─ PROCEDURAL (runbooks, steps)        │                                              │
│  └──────────────────┬──────────────────────┘                                              │
│                     │                                                                     │
│                     ▼                                                                     │
│  ┌─────────────────────────────────────────┐       ┌──────────────────────────────────┐   │
│  │     Aurora PostgreSQL (pgvector)        │       │      OTEL Collector              │   │
│  │                                         │       │      (Deployment mode)           │   │
│  │  Table: agent_memory                    │       │                                  │   │
│  │  ├─ id, content, record_type, status    │       │  Receivers:                      │   │
│  │  ├─ embedding (vector 1024d)            │       │  └─ OTLP gRPC (:4317)           │   │
│  │  ├─ confidence, importance              │       │  └─ OTLP HTTP (:4318)           │   │
│  │  ├─ created_by, namespace              │       │                                  │   │
│  │  ├─ derived_from[], supersedes          │       │  Exporters:                      │   │
│  │  ├─ success_count, failure_count        │       │  ├─ Phoenix (OTLP gRPC)         │   │
│  │  ├─ workflow_id, triggered_by           │       │  ├─ AWS X-Ray                   │   │
│  │  └─ hedged, turn_context               │       │  ├─ CloudWatch (OTLP HTTP)      │   │
│  │                                         │       │  ├─ Prometheus (:8889)           │   │
│  │  Embeddings: Bedrock Titan V2 (1024d)   │       │  └─ Debug                       │   │
│  └─────────────────────────────────────────┘       └───────┬──────┬──────┬───────────┘   │
│                                                            │      │      │               │
│  ┌──────────────────┐  ┌──────────────────┐                │      │      │               │
│  │   memledger-ui   │  │    kagent-ui     │                │      │      │               │
│  │   (FastAPI)      │  │                  │                │      │      │               │
│  │                  │  │  Agent chat UI   │                │      │      │               │
│  │  Trust graph     │  │  A2A protocol    │                │      │      │               │
│  │  (Cytoscape.js)  │  │  Task mgmt      │                │      │      │               │
│  │  Eval dashboard  │  │                  │                │      │      │               │
│  │  Inspector       │  │                  │                │      │      │               │
│  │  5-act demo      │  │                  │                │      │      │               │
│  └──────────────────┘  └──────────────────┘                │      │      │               │
│                                                            │      │      │               │
└────────────────────────────────────────────────────────────┼──────┼──────┼───────────────┘
                                                             │      │      │
                                              ┌──────────────┘      │      └──────────────┐
                                              ▼                     ▼                     ▼
                                 ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
                                 │  Arize Phoenix    │  │  AWS CloudWatch  │  │  AWS X-Ray       │
                                 │                   │  │                  │  │                  │
                                 │  Trace UI         │  │  Log group:      │  │  Transaction     │
                                 │  Span timeline    │  │  aws/spans       │  │  Search          │
                                 │  OTLP receiver    │  │                  │  │                  │
                                 │  (:6006 UI)       │  │  56K+ spans      │  │  Trace map       │
                                 │  (:4317 gRPC)     │  │                  │  │                  │
                                 └──────────────────┘  └──────────────────┘  └──────────────────┘


┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              Evaluation Pipeline                                        │
│                                                                                         │
│  ┌─────────────────────────────────┐     ┌─────────────────────────────────┐             │
│  │  Option A — Deterministic       │     │  Option C — RAGAS / Claude      │             │
│  │                                 │     │                                 │             │
│  │  Custom Python evaluator        │     │  RAGAS AspectCritic framework   │             │
│  │  No LLM required                │     │  Judge: Claude Sonnet (Bedrock) │             │
│  │  < 1ms per evaluation           │     │  ~3s per evaluation             │             │
│  │                                 │     │                                 │             │
│  │  Rubric: MAI (Memory            │     │  Rubric: MAI (identical)        │             │
│  │  Attribution Integrity)         │     │                                 │             │
│  │                                 │     │  Score 1.0 = well-attributed    │             │
│  │  22/30 agreement (73%)          │     │  20/30 agreement (67%)          │             │
│  │  κ = 0.60                       │     │  κ = 0.50                       │             │
│  └─────────────────────────────────┘     └─────────────────────────────────┘             │
│                          │                              │                                │
│                          └──────────────┬───────────────┘                                │
│                                         ▼                                                │
│                          ┌─────────────────────────────────┐                             │
│                          │  Calibration Dataset (n=30)     │                             │
│                          │                                 │                             │
│                          │  10 well-attributed examples    │                             │
│                          │  10 partially-attributed        │                             │
│                          │  10 unattributed                │                             │
│                          │                                 │                             │
│                          │  Human-labeled ground truth     │                             │
│                          │  Inter-evaluator agreement: 83% │                             │
│                          │  Inter-evaluator κ = 0.69       │                             │
│                          └─────────────────────────────────┘                             │
│                                                                                         │
└─────────────────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              Provenance Chain (Demo Data)                                │
│                                                                                         │
│  research-agent         triage-agent         ops-agent              compliance-agent     │
│  (conf: 0.25)           (conf: 0.45)         (conf: 0.85/0.90)      (conf: 0.88)        │
│                                                                                         │
│  ┌─────────┐            ┌─────────┐          ┌─────────┐            ┌─────────┐         │
│  │ bad fact │──derived──▶│escalate │──derived─▶│diagnose │──derived──▶│ runbook │         │
│  │ (0.25)  │            │ (0.45)  │          │ (0.85)  │            │ (0.88)  │         │
│  └─────────┘            └─────────┘          └────┬────┘            └─────────┘         │
│       ▲                                           │                                     │
│       │                                           │                                     │
│       └──────────── supersedes ───────────────────┘                                     │
│                                                                                         │
│  ┌─────────┐                                 ┌─────────┐                                │
│  │ bad #2  │  (isolated, no edges)           │  fix    │                                │
│  │ (0.30)  │                                 │ (0.90)  │                                │
│  └─────────┘                                 └─────────┘                                │
│                                                                                         │
│  Trust Graph: red nodes (< 0.4) → amber (0.4-0.7) → green (≥ 0.7)                      │
│  Edge types: derived (solid blue) | supersedes (dashed red)                              │
│                                                                                         │
└─────────────────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              AWS Services Used                                           │
│                                                                                         │
│  EKS (v1.33)          │  Aurora PostgreSQL    │  Bedrock              │  CloudWatch      │
│  ├─ kagent framework  │  ├─ pgvector ext      │  ├─ Claude Sonnet 4   │  ├─ aws/spans    │
│  ├─ 4 nodes           │  ├─ 1024d embeddings  │  │  (agent LLM)       │  ├─ X-Ray traces │
│  ├─ 3 agent pods      │  ├─ Titan V2 embed    │  ├─ Titan Embed V2    │  └─ Prometheus   │
│  ├─ OTEL Collector    │  └─ IRSA auth         │  │  (embeddings)      │    metrics       │
│  ├─ Phoenix           │                       │  └─ Claude Sonnet 4   │                  │
│  ├─ memledger-ui      │                       │     (RAGAS judge)     │                  │
│  └─ kagent controller │                       │                       │                  │
│                                                                                         │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

## Memory backend contract (v1)

**Memledger's only required backend is open-source PostgreSQL with the
[pgvector](https://github.com/pgvector/pgvector) extension.** Everything
else is optional.

Minimum versions:

| Component | Minimum |
|---|---|
| PostgreSQL | 14 |
| pgvector extension | 0.5 (HNSW index support — used by `PgVectorBackend`) |

The `PgVectorBackend` class in `src/memledger/backends/pgvector.py` speaks
the standard Postgres wire protocol via `asyncpg`. It is flavor-agnostic
— same code works against community OSS Postgres, Aurora, RDS, Supabase,
Neon, or any other Postgres with the pgvector extension loaded.

### Verified deployment patterns

| Environment | Postgres source | Verification |
|---|---|---|
| **Local dev** | `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16` | `python scripts/smoke_test.py` (L3 gate writes + reads a memory) |
| **Kubernetes — self-contained** | Helm chart's in-cluster pgvector StatefulSet (`charts/memledger/templates/postgres.yaml`, enabled when `postgres.deploy=true`) | `helm install memledger ./charts/memledger`, then exec into the memledger pod and run an add+search |
| **Kubernetes — external Postgres** | Set `PGVECTOR_HOST` / `PGVECTOR_DATABASE` / `PGVECTOR_USER` / `PGVECTOR_PASSWORD` to any reachable Postgres (kagent's bundled PG, Aurora, RDS, etc.) | Same as above, but Helm `postgres.deploy=false` |
| **AWS managed** | Aurora PostgreSQL ≥ 14.5 with `CREATE EXTENSION vector;` applied once | `python scripts/smoke_test.py --with-aws` (A3 gate, requires `ENGRAM_TEST_AURORA_DSN`) |

The Helm chart's migration job runs `CREATE EXTENSION IF NOT EXISTS vector;`
defensively, so a fresh Postgres instance becomes pgvector-ready without
operator intervention.

### Optional secondary backends

These are **not** part of the v1 default and require explicit install + config:

- **OpenSearch** — `pip install memledger[opensearch]` for hybrid lexical + vector search (open-source OpenSearch self-hosted, OR AWS OpenSearch via the `aws_sigv4` auth mode behind `[aws]`).
- **DynamoDB** — `pip install memledger[aws]`. AWS-only by design; serves a primary-key + lifecycle use case in composition with a search backend.
- **SQLite + sqlite-vec** — `pip install memledger[sqlite]`. Local single-file store for tests/demos.

For all secondary backends, the `PgVectorBackend` remains available and
the composition router can route writes/reads across multiple backends.

## Eval framework — Arize Phoenix (deployment-agnostic)

v1 ships with **[Arize Phoenix](https://github.com/Arize-ai/phoenix)** (Apache 2.0)
as the trace + eval observability layer. memledger talks to Phoenix over
**OTLP** for traces and over the `arize-phoenix-client` for explicit eval
annotations. memledger does **not** depend on how Phoenix is deployed.

### Four supported deployment modes

| Mode | When | How user starts Phoenix | memledger env |
|---|---|---|---|
| In-process | Jupyter / quick exploration | `import phoenix as px; px.launch_app()` | `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006` (auto) |
| Docker (local) | Local dev, integration tests | `docker compose -f infra/phoenix/docker-compose.yml up -d` | `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006` |
| Kubernetes (Helm) | kagent / EKS production-shape | install `arize-phoenix/phoenix` chart separately from memledger | `OTEL_EXPORTER_OTLP_ENDPOINT=http://phoenix.observability:6006` |
| Arize Cloud | Hosted | (managed) | `PHOENIX_BASE_URL=https://app.arize.com PHOENIX_API_KEY=...` |

### Env vars memledger reads

- `OTEL_EXPORTER_OTLP_ENDPOINT` — where to emit spans. Unset → telemetry no-ops.
- `PHOENIX_BASE_URL` — Phoenix HTTP base for eval annotations. Falls back to
  `PHOENIX_COLLECTOR_ENDPOINT`, then `OTEL_EXPORTER_OTLP_ENDPOINT`.
- `PHOENIX_API_KEY` — optional auth header for hosted / authenticated Phoenix.

### Why OTEL is a core dependency

`opentelemetry-api`, `opentelemetry-sdk`, and the OTLP-gRPC exporter are
**core dependencies** of memledger v1 (not behind an extra). Observability
is part of the v1 value promise; an OSS user shouldn't have to discover
a `[telemetry]` extra to get basic spans. The runtime stays graceful: if
`OTEL_EXPORTER_OTLP_ENDPOINT` is unset, instrumentation is a no-op and
nothing is sent. The `[telemetry]` extra now adds Phoenix-specific OTEL
helpers (`arize-phoenix-otel`) on top.

### Quality gate flow (LLM-as-judge)

1. memledger emits OTEL spans for `memory.add`, `memory.search`,
   `evaluate_attribution_integrity` → OTLP → Phoenix.
2. RAGAS `AspectCritic` with a LiteLLM-routed judge
   (`MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini` or `bedrock/...` or
   `ollama/llama3.1` or any other LiteLLM provider) scores a memory session.
3. `memledger.telemetry.phoenix.log_evaluation(...)` pushes the score as a
   `span_annotation` (annotator_kind="LLM" or "CODE") on the originating
   span via `arize-phoenix-client`.
4. Phoenix UI renders the eval score as a chip on the span and supports
   filtering ("show me sessions where MAI < 0.7").

The deterministic MAI evaluator (Tier 1, no LLM) and the RAGAS LLM-as-judge
evaluator (Tier 2) both push to Phoenix; the AWS AgentCore evaluator (Tier 3,
behind `[aws]`) emits to AWS-native observability — not Phoenix — by design.

### Langfuse (v3 candidate)

Langfuse is an excellent alternative observability/eval platform with a
stronger production-feedback (cost, user-rating) story. v1 picks Phoenix
for tighter trace↔eval coupling and dataset-replay primitives; a Langfuse
provider behind a flag is a v3 candidate.
