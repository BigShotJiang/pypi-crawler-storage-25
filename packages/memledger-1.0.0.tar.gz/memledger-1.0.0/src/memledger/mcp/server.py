# SPDX-License-Identifier: Apache-2.0
"""Memledger MCP Server — exposes memory tools via Model Context Protocol.

Usage:
    engram serve                          # uses ~/.memledger/config.yaml
    engram serve --config ./engram.yaml   # custom config

Claude Desktop config:
    {
      "mcpServers": {
        "engram": {
          "command": "engram",
          "args": ["serve"]
        }
      }
    }
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from memledger.memledger import Memledger
from memledger.models import RecordType

logger = logging.getLogger(__name__)


class EngramMCPServer:
    """MCP server wrapping a Memledger instance."""

    def __init__(self, memledger: Memledger) -> None:
        self._ml = engram

    @classmethod
    async def from_config(cls, config_path: Optional[str] = None) -> "EngramMCPServer":
        """Create from config file, falling back to defaults."""
        if config_path:
            engram = await Memledger.from_config(config_path)
        else:
            # Try default config locations
            from pathlib import Path

            for candidate in [
                Path("./engram.yaml"),
                Path("~/.memledger/config.yaml").expanduser(),
            ]:
                if candidate.exists():
                    engram = await Memledger.from_config(str(candidate))
                    return cls(engram)

            # No config found — use SQLite defaults
            engram = await Memledger.create(
                backend_name="sqlite",
                backend_config={"path": "~/.memledger/memory.db"},
            )

        return cls(engram)

    def create_server(self):
        """Create and configure the MCP server with tools."""
        from mcp.server import Server
        from mcp.types import TextContent, Tool

        server = Server("engram-memory")
        engram = self._ml

        @server.list_tools()
        async def list_tools():
            return [
                Tool(
                    name="memory_store",
                    description=(
                        "Store a memory with content and metadata. "
                        "Use namespaces to organize: /user/preferences, /project/context, /incidents/cluster-name"
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "content": {
                                "type": "string",
                                "description": "The memory content to store. Be specific and descriptive.",
                            },
                            "namespace": {
                                "type": "string",
                                "description": "Namespace path (e.g., /user/preferences, /incidents/eks-prod)",
                                "default": "/",
                            },
                            "record_type": {
                                "type": "string",
                                "enum": ["semantic", "episodic", "procedural"],
                                "description": "Type: semantic (facts), episodic (events), procedural (how-to)",
                                "default": "semantic",
                            },
                            "metadata": {
                                "type": "object",
                                "description": "Optional key-value metadata",
                            },
                        },
                        "required": ["content"],
                    },
                ),
                Tool(
                    name="memory_search",
                    description=(
                        "Search memories by semantic similarity. "
                        "Use namespace to scope search (e.g., /incidents searches all incidents)."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "What to search for (natural language)",
                            },
                            "namespace": {
                                "type": "string",
                                "description": "Namespace scope (prefix match)",
                            },
                            "top_k": {
                                "type": "integer",
                                "description": "Number of results",
                                "default": 5,
                            },
                        },
                        "required": ["query"],
                    },
                ),
                Tool(
                    name="memory_recall",
                    description=(
                        "Comprehensive recall: find similar episodes, suggested procedures, "
                        "and known failures for a situation. More thorough than memory_search."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "The situation you're dealing with",
                            },
                            "namespace": {
                                "type": "string",
                                "description": "Namespace scope",
                            },
                            "top_k": {
                                "type": "integer",
                                "description": "Results per category",
                                "default": 5,
                            },
                        },
                        "required": ["query"],
                    },
                ),
                Tool(
                    name="memory_delete",
                    description="Delete a memory by its ID.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "record_id": {
                                "type": "string",
                                "description": "ID of the memory to delete",
                            },
                        },
                        "required": ["record_id"],
                    },
                ),
                Tool(
                    name="memory_stats",
                    description=(
                        "Get statistics about stored memories: counts by type, "
                        "namespaces, success rates. Use to understand what you know."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "namespace": {
                                "type": "string",
                                "description": "Scope stats to a namespace (optional)",
                            },
                        },
                    },
                ),
                Tool(
                    name="memory_namespaces",
                    description="List all namespaces that contain memories.",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
            ]

        @server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]):
            try:
                if name == "memory_store":
                    return await _handle_store(arguments)
                elif name == "memory_search":
                    return await _handle_search(arguments)
                elif name == "memory_recall":
                    return await _handle_recall(arguments)
                elif name == "memory_delete":
                    return await _handle_delete(arguments)
                elif name == "memory_stats":
                    return await _handle_stats(arguments)
                elif name == "memory_namespaces":
                    return await _handle_namespaces(arguments)
                else:
                    return [TextContent(type="text", text=f"Unknown tool: {name}")]
            except Exception as e:
                logger.error(f"Tool {name} failed: {e}")
                return [TextContent(type="text", text=f"Error: {str(e)}")]

        async def _handle_store(args: dict) -> list:
            content = args["content"]
            namespace = args.get("namespace", "/")
            record_type = RecordType(args.get("record_type", "semantic"))
            metadata = args.get("metadata", {})

            record_id = await engram.add(
                content=content,
                record_type=record_type,
                namespace=namespace,
                metadata=metadata,
            )

            return [
                TextContent(
                    type="text",
                    text=f"Stored {record_type.value} memory [{record_id[:8]}] in {namespace}: {content[:100]}",
                )
            ]

        async def _handle_search(args: dict) -> list:
            query = args["query"]
            namespace = args.get("namespace")
            top_k = args.get("top_k", 5)

            results = await engram.search(
                query=query,
                namespace=namespace,
                top_k=top_k,
            )

            if not results.records:
                return [TextContent(type="text", text="No memories found.")]

            lines = []
            for i, rec in enumerate(results.records, 1):
                score = f" (score: {rec.score:.3f})" if rec.score else ""
                lines.append(
                    f"{i}. [{rec.namespace}] [{rec.record_type.value}]{score}\n   ID: {rec.id}\n   {rec.content[:300]}"
                )

            text = f"Found {len(results.records)} memories ({results.search_time_ms:.0f}ms):\n\n" + "\n\n".join(lines)
            return [TextContent(type="text", text=text)]

        async def _handle_recall(args: dict) -> list:
            query = args["query"]
            namespace = args.get("namespace")
            top_k = args.get("top_k", 5)

            context = await engram.recall_context(
                query=query,
                namespace=namespace,
                top_k=top_k,
            )

            return [TextContent(type="text", text=context.summary())]

        async def _handle_delete(args: dict) -> list:
            record_id = args["record_id"]
            deleted = await engram.delete(record_id)
            if deleted:
                return [TextContent(type="text", text=f"Deleted memory {record_id}.")]
            return [TextContent(type="text", text=f"Memory {record_id} not found.")]

        async def _handle_stats(args: dict) -> list:
            namespace = args.get("namespace")
            stats = await engram.stats(namespace=namespace)

            if not stats or stats.get("total_count", 0) == 0:
                scope = f" in {namespace}" if namespace else ""
                return [TextContent(type="text", text=f"No memories stored{scope}.")]

            lines = [f"Memory statistics{' for ' + namespace if namespace else ''}:"]
            lines.append(f"  Total: {stats['total_count']}")
            if stats.get("by_record_type"):
                parts = [f"{t}: {c}" for t, c in stats["by_record_type"].items()]
                lines.append(f"  By type: {', '.join(parts)}")
            if stats.get("namespaces"):
                lines.append(f"  Namespaces: {', '.join(stats['namespaces'][:15])}")
            if stats.get("avg_success_rate") is not None:
                lines.append(f"  Avg success rate: {stats['avg_success_rate']:.1%}")

            return [TextContent(type="text", text="\n".join(lines))]

        async def _handle_namespaces(args: dict) -> list:
            namespaces = await engram.list_namespaces()
            if not namespaces:
                return [TextContent(type="text", text="No namespaces found.")]
            return [TextContent(type="text", text="Namespaces:\n" + "\n".join(f"  - {ns}" for ns in namespaces))]

        return server

    async def run(self) -> None:
        """Run the MCP server on stdio."""
        from mcp.server.stdio import stdio_server

        server = self.create_server()

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    async def close(self) -> None:
        await self._ml.close()


async def serve(config_path: Optional[str] = None) -> None:
    """Entry point for `engram serve`."""
    mcp_server = await EngramMCPServer.from_config(config_path)
    try:
        await mcp_server.run()
    finally:
        await mcp_server.close()
