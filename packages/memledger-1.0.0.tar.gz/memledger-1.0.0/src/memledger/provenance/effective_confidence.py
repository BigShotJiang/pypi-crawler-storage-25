# SPDX-License-Identifier: Apache-2.0
"""Effective confidence — declared confidence tempered by the weakest
link in the upstream provenance chain.

A memory's *declared* confidence is what its author asserted at write
time. Its *effective* confidence for retrieval-gating purposes is the
minimum of (declared, weakest-link in the upstream chain). A high-
confidence claim built on a low-confidence ancestor cannot be more
trustworthy than its ancestor — this is the v1 quality-gate invariant
(see docs/v1-feature-gap-check.md row M-04, and the multi-agent SRE
scenario in docs/architecture.md).

The `resolve_declared` hook is the seam where temporal decay (B12,
deferred to v2) will plug in. v2 will pass a resolver that returns
the declared confidence minus a time-based decay; chain math here
stays unchanged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from memledger.models import MemoryRecord
    from memledger.provenance.chain_store import ChainStore


def _default_resolve_declared(record: "MemoryRecord") -> float:
    return record.confidence if record.confidence is not None else 0.5


async def compute_effective_confidence(
    record: "MemoryRecord",
    chain_store: "ChainStore",
    *,
    resolve_declared: Callable[["MemoryRecord"], float] = _default_resolve_declared,
) -> float:
    """Return min(declared, chain.min_confidence).

    Skips the chain walk entirely when `record.derived_from` is empty —
    no provenance to weaken the declared value.
    """
    declared = resolve_declared(record)
    if not record.derived_from:
        return declared
    chain_min = await chain_store.min_confidence_upstream(record.id)
    return min(declared, chain_min)


async def compute_effective_confidence_map(
    records: list["MemoryRecord"],
    chain_store: "ChainStore",
    *,
    resolve_declared: Callable[["MemoryRecord"], float] = _default_resolve_declared,
) -> dict[str, float]:
    """Batch helper — returns {record_id: effective_confidence}."""
    return {
        record.id: await compute_effective_confidence(
            record, chain_store, resolve_declared=resolve_declared
        )
        for record in records
    }
