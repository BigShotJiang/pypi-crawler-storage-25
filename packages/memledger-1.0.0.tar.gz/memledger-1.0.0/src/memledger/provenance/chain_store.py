# SPDX-License-Identifier: Apache-2.0
"""ChainStore — swappable, read-only view over the provenance graph.

v1 ships a single implementation, `JsonArrayChainStore`, which walks
`derived_from: list[str]` arrays via the Memledger instance's read API
(`get()` and `get_downstream()`). Future implementations slot in behind
the same Protocol with no other code changes:

  - RecursiveCTEChainStore  — pure Postgres recursive CTE; same DB,
                              ~3-5x faster than Python walk.
  - ApacheAGEChainStore     — Postgres + AGE extension; openCypher.
                              Keeps the B2 "Postgres only" contract.
  - Neo4jChainStore         — external Neo4j; best perf at scale, dual-store.

WRITES intentionally live on the storage backend, not here. When
Memledger.add() persists a memory with `derived_from=[...]`, the edges
are written as part of the memory row. The chain store only reads —
this is what makes the v1.5 swap a clean drop-in (no need to refactor
the storage backend at the same time).

------------------------------------------------------------
Migration path to a graph DB (v1.5+)
------------------------------------------------------------

The `derived_from` JSONB column on the storage backend IS the source of
truth. The chain store is a read view. So when v1.5 introduces a graph
implementation, migration is a single one-shot bulk load:

    # scripts/migrate_chain_to_neo4j.py  (NOT in v1)
    async for record in memledger.iter_all_records():
        for parent_id in (record.derived_from or []):
            await graph.execute(
                "MATCH (m {id:$mid}), (p {id:$pid}) "
                "MERGE (m)-[:DERIVED_FROM]->(p)",
                mid=record.id, pid=parent_id,
            )

Risks to handle in v1.5 migration tooling (NOT v1):
  - Orphan edges (derived_from points at deleted memory) — validate + log.
  - Cycle detection (Neo4j does not prevent cycles by default).
  - Concurrent writes during cutover — maintenance window OR dual-write
    cutover pattern; pick when v1.5 lands.

Phoenix span IDs / annotations are NOT affected by the chain DB swap —
they reference memledger memory IDs by string, which don't change.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Protocol

from memledger.provenance.chain import MAX_ACTIVE_CHAIN_HOPS, build_chain
from memledger.provenance.models import AttributionChain

if TYPE_CHECKING:
    from memledger.memledger import Memledger


class ChainStore(Protocol):
    """Read-only Protocol for provenance graph queries.

    All implementations must be safe to call concurrently from search()
    and must return defensible defaults when a chain is empty or a
    memory is missing (callers must not crash on a deleted ancestor).
    """

    async def min_confidence_upstream(
        self,
        memory_id: str,
        *,
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> float:
        """Weakest-link confidence along the upstream chain.

        Returns 1.0 for an empty/missing chain so it never tightens the
        declared confidence of a memory with no provenance to weaken it.
        """

    async def build_chain(
        self,
        memory_id: str,
        *,
        direction: Literal["upstream", "downstream", "both"] = "upstream",
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> AttributionChain:
        """Full chain traversal — hops, agents, min_confidence, truncated flag."""


class JsonArrayChainStore:
    """v1 implementation — walks JSONB `derived_from` arrays via the
    Memledger instance's read API. Production-acceptable up to the
    `MAX_ACTIVE_CHAIN_HOPS` cap (5 by default). Replaced at v1.5/v2 by a
    graph-native implementation; see module docstring."""

    def __init__(self, memledger: "Memledger") -> None:
        self._ml = memledger

    async def min_confidence_upstream(
        self,
        memory_id: str,
        *,
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> float:
        chain = await build_chain(self._ml, memory_id, direction="upstream", max_hops=max_hops)
        return chain.min_confidence if chain.chain else 1.0

    async def build_chain(
        self,
        memory_id: str,
        *,
        direction: Literal["upstream", "downstream", "both"] = "upstream",
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> AttributionChain:
        return await build_chain(self._ml, memory_id, direction=direction, max_hops=max_hops)
