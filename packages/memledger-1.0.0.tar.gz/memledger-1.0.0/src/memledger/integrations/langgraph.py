# SPDX-License-Identifier: Apache-2.0
"""LangGraph integration for Memledger.

Provides:
1. EngramCheckpointer — LangGraph-compatible state persistence
2. create_memory_tools() — ready-to-use LangGraph tool nodes

Usage with LangGraph:
    from memledger.integrations.langgraph import MemledgerCheckpointer, create_memory_tools

    engram = await Memledger.from_config("engram.yaml")
    checkpointer = EngramCheckpointer(engram)
    tools = create_memory_tools(engram)
    app = graph.compile(checkpointer=checkpointer)

Requires: pip install engram[langgraph]
"""

from __future__ import annotations

import logging
from typing import Optional

from memledger.memledger import Memledger
from memledger.models import RecordType

logger = logging.getLogger(__name__)


def create_memory_tools(
    memledger: Memledger,
    default_namespace: str = "/",
    default_agent_id: Optional[str] = None,
) -> list:
    """Create LangGraph-compatible tools for memory operations.

    Returns a list of tools that can be passed to ToolNode or bind_tools.

    Example:
        tools = create_memory_tools(engram, default_namespace="/sre/incidents")
        llm_with_tools = llm.bind_tools(tools)
    """
    try:
        from langchain_core.tools import tool as langchain_tool
    except ImportError:
        raise ImportError("LangGraph integration requires langchain-core. Install with: pip install engram[langgraph]")

    @langchain_tool
    async def remember(
        content: str,
        namespace: str = default_namespace,
        record_type: str = "semantic",
        metadata: Optional[dict] = None,
    ) -> str:
        """Store information in long-term memory for future recall.

        Use this to save important facts, decisions, incident resolutions,
        user preferences, or any knowledge that should persist across sessions.

        Args:
            content: The information to remember. Be specific and descriptive.
            namespace: Category path like '/incidents/payment-service' or '/users/u1/prefs'
            record_type: Type of memory - 'semantic' (facts), 'episodic' (events), or 'procedural' (how-to)
            metadata: Optional key-value pairs (e.g. {"severity": "P1", "resolved": true})
        """
        rt = RecordType(record_type)
        record_id = await engram.add(
            content=content,
            record_type=rt,
            namespace=namespace,
            agent_id=default_agent_id,
            metadata=metadata or {},
        )
        return f"Stored {record_type} memory [{record_id[:8]}]: {content[:100]}"

    @langchain_tool
    async def recall(
        query: str,
        namespace: Optional[str] = default_namespace,
        record_type: Optional[str] = None,
        top_k: int = 5,
    ) -> str:
        """Search long-term memory for relevant past knowledge.

        Use this BEFORE starting a new task to check if you've handled
        something similar before. Searches by semantic similarity.

        Args:
            query: What to search for (natural language description)
            namespace: Optional scope to narrow search (e.g. '/incidents')
            record_type: Optional filter - 'semantic', 'episodic', or 'procedural'
            top_k: Number of results to return
        """
        rt = RecordType(record_type) if record_type else None
        results = await engram.search(
            query=query,
            namespace=namespace,
            record_type=rt,
            agent_id=default_agent_id,
            top_k=top_k,
        )

        if not results.records:
            return "No relevant memories found."

        lines = []
        for i, rec in enumerate(results.records, 1):
            score_str = f" (score: {rec.score:.3f})" if rec.score else ""
            type_str = f" [{rec.record_type.value}]"
            meta_str = f" | metadata: {rec.metadata}" if rec.metadata else ""
            lines.append(f"{i}. [{rec.namespace}]{type_str}{score_str}: {rec.content}{meta_str}")

        return f"Found {len(results.records)} memories (search took {results.search_time_ms}ms):\n" + "\n".join(lines)

    @langchain_tool
    async def forget(record_id: str) -> str:
        """Delete a specific memory by its ID.

        Args:
            record_id: The ID of the memory to delete
        """
        deleted = await engram.delete(record_id)
        if deleted:
            return f"Memory {record_id} deleted."
        return f"Memory {record_id} not found."

    return [remember, recall, forget]
