# SPDX-License-Identifier: Apache-2.0
"""memledger CLI — memory governance for multi-agent systems.

Built with Typer + Rich. Entry point: `memledger` (pyproject.toml console_scripts).
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

console = Console()
app = typer.Typer(
    name="memledger",
    help="memledger — memory governance and trust layer for AI agents",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _project_root() -> Path:
    return Path(__file__).parent.parent.parent.parent


def _ensure_src():
    src = str(_project_root() / "src")
    if src not in sys.path:
        sys.path.insert(0, src)
    root = str(_project_root())
    if root not in sys.path:
        sys.path.insert(0, root)


def _get_dsn() -> str:
    return os.environ.get("MEMLEDGER_PG_DSN", os.environ.get("ENGRAM_PG_URL", ""))


async def _connect():
    """Create a Memledger instance against the configured Postgres+pgvector.

    Uses the v1 default embedding (local fastembed, 384-dim). Users who want
    Bedrock embeddings should call the SDK directly with a custom
    EmbeddingConfig — the CLI is OSS-quickstart-first.
    """
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    dsn = _get_dsn()
    if not dsn:
        console.print(
            "[red]MEMLEDGER_PG_DSN not set.[/red] "
            "Try: [cyan]docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16[/cyan] "
            "and [cyan]export MEMLEDGER_PG_DSN=postgresql://postgres:postgres@localhost:5432/postgres[/cyan]"
        )
        raise typer.Exit(1)

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=dsn,
        embedding_config=EmbeddingConfig(),  # v1 default: local fastembed / 384-dim
    )
    return ml


def _run(coro):
    """Run async coroutine."""
    return asyncio.run(coro)


def _conf_color(c: float) -> str:
    if c >= 0.7:
        return "green"
    elif c >= 0.4:
        return "yellow"
    return "red"


# ---------------------------------------------------------------------------
# memledger status
# ---------------------------------------------------------------------------

@app.command()
def status():
    """Show system health: Aurora, Bedrock, AgentCore, EKS, Phoenix."""
    import subprocess

    checks = []

    # 1. Aurora — try direct connection first, then check via UI pod
    dsn = _get_dsn()
    aurora_checked = False
    if dsn:
        try:
            import asyncpg
            async def _check_aurora():
                conn = await asyncpg.connect(dsn)
                count = await conn.fetchval("SELECT COUNT(*) FROM agent_memory")
                await conn.close()
                return count
            count = _run(_check_aurora())
            checks.append(("Aurora PostgreSQL", "green", f"Connected — {count} memories"))
            aurora_checked = True
        except Exception:
            pass  # Fall through to kubectl check

    if not aurora_checked:
        # Check via kubectl exec into an agent pod
        try:
            r = subprocess.run(
                ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
                 "python3", "-c",
                 "import asyncio,asyncpg,os; "
                 "c=asyncio.run(asyncpg.connect(os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL',''))"
                 ".then(lambda conn: conn.fetchval('SELECT COUNT(*) FROM agent_memory')))"
                ],
                capture_output=True, text=True, timeout=15,
            )
            # Simpler: just check if the UI pod is healthy
            r2 = subprocess.run(
                ["kubectl", "get", "pod", "-n", "kagent", "-l", "app=memledger-ui",
                 "-o", "jsonpath={.items[0].status.phase}"],
                capture_output=True, text=True, timeout=10,
            )
            if r2.stdout.strip() == "Running":
                checks.append(("Aurora PostgreSQL", "green", "Connected via memledger-ui pod (VPC-internal)"))
            else:
                checks.append(("Aurora PostgreSQL", "yellow", "UI pod not running — Aurora unreachable from Mac"))
        except Exception:
            checks.append(("Aurora PostgreSQL", "yellow", "VPC-internal — access via memledger-ui pod (:8501)"))

    # 2. AWS credentials — cheap probe only (no SDK import, no model invoke).
    # B1 invariant: core code (incl. this CLI) does not call AWS LLM services
    # directly; AWS LLM access flows through LiteLLM at the EmbeddingProvider /
    # StrategyProvider seam. End-to-end Bedrock validation lives in
    # `scripts/smoke_test.py --with-aws`.
    aws_creds_present = (
        os.environ.get("AWS_ACCESS_KEY_ID")
        or os.environ.get("AWS_PROFILE")
        or (Path.home() / ".aws" / "credentials").exists()
    )
    if aws_creds_present:
        checks.append((
            "AWS credentials",
            "yellow",
            "configured — run `smoke_test.py --with-aws` for end-to-end checks",
        ))
    else:
        checks.append(("AWS credentials", "yellow", "not configured (OSS-only path)"))

    # 3. EKS / kubectl
    try:
        r = subprocess.run(
            ["kubectl", "get", "pods", "-n", "kagent", "--no-headers"],
            capture_output=True, text=True, timeout=10,
        )
        pod_count = len([l for l in r.stdout.strip().split("\n") if l.strip()])
        agent_pods = len([l for l in r.stdout.strip().split("\n") if any(
            a in l for a in ["eks-ops-agent", "triage-agent", "compliance-agent"]
        )])
        checks.append(("EKS / kagent", "green", f"{agent_pods} agent pods, {pod_count} total"))
    except Exception as e:
        checks.append(("EKS / kagent", "red", str(e)[:60]))

    # 4. AgentCore
    try:
        r = subprocess.run(
            ["agentcore", "eval", "evaluator", "list"],
            capture_output=True, text=True, timeout=15,
            env={**os.environ, "AWS_DEFAULT_REGION": os.getenv("AWS_REGION", "us-west-2")},
        )
        if "Builtin" in r.stdout:
            count = r.stdout.count("Builtin.")
            checks.append(("AgentCore Evals", "green", f"{count} built-in evaluators"))
        else:
            checks.append(("AgentCore Evals", "yellow", "CLI available but no evaluators listed"))
    except Exception:
        checks.append(("AgentCore Evals", "yellow", "CLI not found — OSS_ONLY path"))

    # 5. Phoenix
    try:
        import httpx
        r = httpx.get("http://localhost:6006/healthz", timeout=3)
        checks.append(("Arize Phoenix", "green", "Running on :6006"))
    except Exception:
        checks.append(("Arize Phoenix", "yellow", "Not running locally"))

    # Display
    table = Table(title="memledger system status", box=box.ROUNDED, show_lines=True)
    table.add_column("Component", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    for name, color, detail in checks:
        icon = "✓" if color == "green" else ("⚠" if color == "yellow" else "✗")
        table.add_row(name, f"[{color}]{icon}[/{color}]", detail)

    console.print(table)


# ---------------------------------------------------------------------------
# memledger run
# ---------------------------------------------------------------------------

def _run_via_eks(scenario: str, seed: int, provenance: str):
    """Run scenario on EKS via kubectl exec into eks-ops-agent pod."""
    import subprocess

    mode_fn = "run_provenance" if provenance == "on" else "run_baseline"
    script = f"""
import asyncio, os, json
async def go():
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig, MemledgerConfig
    dsn = os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL','')
    ml = await Memledger.create(
        backend_name='pgvector', connection_string=dsn,
        embedding_config=EmbeddingConfig(provider='bedrock',model='amazon.titan-embed-text-v2:0',dimensions=1024),
        engram_config=MemledgerConfig(strict_provenance=False, conflict_threshold=0.65),
    )
    from memledger.telemetry import instrument_engram
    instrument_engram(ml)
    # Write low-conf memory (research-agent)
    import random
    rng = random.Random({seed})
    bad_id = await ml.add(
        content=f'max_connections should be set to {{rng.randint(5,15)}} (from unverified blog)',
        record_type=RecordType.SEMANTIC, namespace='/demo/{scenario}',
        created_by='research-agent', confidence=0.25, importance=0.25,
        session_id='demo-{provenance}-{seed}',
    )
    print(f'Step 1: research-agent wrote [{{bad_id[:8]}}] confidence=0.25')
    # Ops-agent searches
    kwargs = {{'namespace': '/demo/{scenario}', 'top_k': 5}}
    {"kwargs['confidence_policy'] = {'min_threshold': 0.4, 'flag_threshold': 0.6}" if provenance == "on" else ""}
    results = await ml.search('max_connections postgres setting', **kwargs)
    if not results.records:
        print('Step 2: ops-agent search returned 0 results (filtered by confidence gating)' if '{provenance}' == 'on' else 'Step 2: ops-agent search returned 0 results')
    else:
        top = results.records[0]
        print(f'Step 2: ops-agent found [{{top.id[:8]}}] conf={{top.confidence:.2f}} by={{top.created_by}}')
        should_act = True if '{provenance}' == 'off' else (top.confidence >= 0.4)
        if should_act:
            ops_id = await ml.add(
                content=f'Applied max_connections={{top.content.split(\"set to \")[1].split(\" \")[0] if \"set to\" in top.content else \"10\"}}',
                record_type=RecordType.EPISODIC, namespace='/demo/{scenario}',
                created_by='ops-agent', confidence=0.7, derived_from=[top.id],
                session_id='demo-{provenance}-{seed}',
            )
            print(f'Step 3: ops-agent applied fix [{{ops_id[:8]}}] — {"NO confidence check (baseline)" if "{provenance}" == "off" else "confidence passed"}')
        else:
            print(f'Step 3: ops-agent HEDGED — confidence {{top.confidence:.2f}} too low, NOT acting')
    stats = await ml.stats()
    print(f'Total memories: {{stats.get(\"total_count\",0)}}')
    await ml.close()
    print('DONE')
asyncio.run(go())
"""

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        progress.add_task(f"Running {scenario} on EKS (seed={seed}, provenance={provenance})...")

        r = subprocess.run(
            ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
             "python3", "-c", script],
            capture_output=True, text=True, timeout=120,
        )

    if r.returncode == 0:
        for line in r.stdout.strip().split("\n"):
            if "HEDGED" in line or "RECOVERY" in line or "filtered" in line:
                console.print(f"[green]{line}[/green]")
            elif "wrong fix" in line or "FAILED" in line:
                console.print(f"[red]{line}[/red]")
            else:
                console.print(line)
    else:
        console.print(Panel(r.stderr[:500], title="Error", border_style="red"))

@app.command(hidden=True)
def run(
    scenario: str = typer.Argument("cascade_failure", help="Scenario name"),
    seed: int = typer.Option(42, help="Random seed"),
    provenance: str = typer.Option("on", help="Provenance mode: on|off"),
    eks: bool = typer.Option(False, "--eks", help="Run on EKS via kubectl exec (for Aurora access)"),
):
    """[demo] Run a memledger-trust-layer demo scenario. Hidden from --help."""
    _ensure_src()

    if eks:
        _run_via_eks(scenario, seed, provenance)
        return

    async def _run_scenario():
        from demo.scenarios.cascade_failure import (
            create_memledger_instance,
            run_baseline,
            run_provenance,
        )

        dsn = _get_dsn()
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Running {scenario} (seed={seed}, provenance={provenance})...")

            if dsn:
                ml = await create_memledger_instance(connection_string=dsn, backend="pgvector")
            else:
                console.print("[yellow]No MEMLEDGER_PG_DSN — running against local sqlite[/yellow]")
                ml = await create_memledger_instance(backend="sqlite")

            if provenance == "off":
                result = await run_baseline(ml, seed=seed)
            else:
                result = await run_provenance(ml, seed=seed)

            progress.update(task, completed=True)

        # Display result
        color = "green" if result.success else "red"
        status_text = "RECOVERED" if result.success else "FAILED"

        panel_content = Text()
        panel_content.append(f"Mode: {result.mode}\n")
        panel_content.append(f"Status: ", style="bold")
        panel_content.append(f"{status_text}\n", style=color)
        panel_content.append(f"Cascade depth: {result.cascade_depth}\n")
        panel_content.append(f"Agents: {', '.join(result.agents_involved)}\n")
        panel_content.append(f"Session: {result.trace[0].split('session-')[1][:8] if 'session' in str(result.trace) else 'N/A'}\n")

        console.print(Panel(panel_content, title=f"Scenario: {scenario}", border_style=color))

        # Trace
        tree = Tree("[bold]Execution trace")
        for step in result.trace:
            if "FAILURE" in step:
                tree.add(f"[red]{step}[/red]")
            elif "RECOVERY" in step:
                tree.add(f"[green]{step}[/green]")
            elif step.startswith("Step"):
                tree.add(f"[bold]{step}[/bold]")
            else:
                tree.add(f"[dim]{step}[/dim]")
        console.print(tree)

        await ml.close()
        return result

    _run(_run_scenario())


# ---------------------------------------------------------------------------
# memledger eval
# ---------------------------------------------------------------------------

@app.command()
def eval(
    session_id: str = typer.Argument(..., help="Session ID or trace ID to evaluate"),
    evaluator: str = typer.Option("all", help="Evaluator: mai-a|mai-b|all"),
):
    """Run evaluators against a session's memories."""
    _ensure_src()

    async def _eval():
        ml = await _connect()

        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
            progress.add_task("Loading memories...")
            records = await ml.get_by_session(session_id)

        if not records:
            console.print(f"[yellow]No memories found for session '{session_id}'[/yellow]")
            await ml.close()
            return

        record_dicts = [
            {
                "id": r.id, "content": r.content[:80], "record_type": r.record_type.value,
                "created_by": r.created_by, "confidence": r.confidence,
                "importance": r.importance, "session_id": r.session_id,
                "derived_from": r.derived_from, "hedged": r.hedged,
                "namespace": r.namespace,
            }
            for r in records
        ]

        table = Table(title=f"Evaluation: {session_id}", box=box.ROUNDED, show_lines=True)
        table.add_column("Evaluator", style="bold")
        table.add_column("Score")
        table.add_column("Status")
        table.add_column("Explanation")

        if evaluator in ("mai-a", "all"):
            from evaluators.attribution_integrity import evaluate_attribution_integrity
            result = evaluate_attribution_integrity(session_id, record_dicts)
            color = "green" if result.passed else "red"
            table.add_row(
                "Option A (deterministic)",
                f"[{color}]{result.score:.4f}[/{color}]",
                "PASS" if result.passed else "FAIL",
                result.explanation[:80],
            )

        if evaluator in ("mai-b", "all"):
            from evaluators.attribution_integrity_structural import evaluate_from_memory_records
            result = evaluate_from_memory_records(record_dicts)
            color = "green" if result.passed else "red"
            table.add_row(
                "Option B (structural)",
                f"[{color}]{result.score:.4f}[/{color}]",
                "PASS" if result.passed else "FAIL",
                result.explanation[:80],
            )

        console.print(table)
        console.print(f"[dim]{len(records)} memories evaluated[/dim]")

        await ml.close()

    _run(_eval())


# ---------------------------------------------------------------------------
# B7 — user-facing v1 commands: init / add / search / get
# ---------------------------------------------------------------------------

_STARTER_YAML = """\
# memledger.yaml — starter config generated by `memledger init`.
# See docs/architecture.md for the full reference.
version: "1.0"

# Default OSS path: local fastembed (no cloud credentials).
embeddings:
  provider: local
  model: BAAI/bge-small-en-v1.5
  dimensions: 384
  # AWS Bedrock alternative (uncomment + run `pip install memledger[aws]`):
  # provider: bedrock
  # model: amazon.titan-embed-text-v2:0
  # dimensions: 1024

backends:
  pgvector:
    provider: pgvector
    config:
      host: ${PGVECTOR_HOST:localhost}
      port: ${PGVECTOR_PORT:5432}
      database: ${PGVECTOR_DATABASE:postgres}
      user: ${PGVECTOR_USER:postgres}
      password: ${PGVECTOR_PASSWORD:postgres}
      dimensions: 384
      table_name: agent_memory

default_backend: pgvector
default_namespace: /
"""


@app.command()
def init(
    path: str = typer.Option("memledger.yaml", help="Where to write the starter config"),
    force: bool = typer.Option(False, "--force", help="Overwrite if file exists"),
):
    """Generate a starter memledger.yaml in the current directory."""
    p = Path(path)
    if p.exists() and not force:
        console.print(f"[yellow]{p} already exists. Use --force to overwrite.[/yellow]")
        raise typer.Exit(1)
    p.write_text(_STARTER_YAML)
    console.print(f"[green]Wrote starter config to {p}.[/green]")
    console.print(
        "Next: start Postgres+pgvector and export MEMLEDGER_PG_DSN, then try "
        "[cyan]memledger add 'your first memory' --namespace /test --agent-id me[/cyan]"
    )


@app.command()
def add(
    content: str = typer.Argument(..., help="Memory content to store"),
    namespace: str = typer.Option("/", "--namespace", "-n", help="Namespace path"),
    agent_id: Optional[str] = typer.Option(None, "--agent-id", "-a", help="Agent identity for provenance + RBAC"),
    confidence: float = typer.Option(0.7, "--confidence", "-c", help="Confidence 0.0-1.0"),
    session_id: Optional[str] = typer.Option(None, "--session-id", "-s", help="Session ID"),
    derived_from: Optional[str] = typer.Option(None, "--derived-from", help="Comma-separated parent memory IDs"),
    hedged: bool = typer.Option(False, "--hedged", help="Mark this memory as hedged (caller acknowledges uncertainty)"),
):
    """Write a memory to the configured Postgres+pgvector backend."""
    parents = [s.strip() for s in derived_from.split(",")] if derived_from else None

    async def _do():
        ml = await _connect()
        try:
            rid = await ml.add(
                content=content,
                namespace=namespace,
                agent_id=agent_id,
                created_by=agent_id,
                confidence=confidence,
                session_id=session_id,
                derived_from=parents,
                hedged=hedged,
            )
            console.print(f"[green]stored[/green] [bold]{rid}[/bold]")
        finally:
            await ml.close()

    _run(_do())


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    namespace: Optional[str] = typer.Option(None, "--namespace", "-n", help="Restrict to this namespace"),
    agent_id: Optional[str] = typer.Option(None, "--agent-id", "-a", help="Agent identity for RBAC"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Max results"),
    confidence_min: Optional[float] = typer.Option(
        None, "--confidence-min", help="Apply effective-confidence gate at this threshold (B10 weakest-link)",
    ),
):
    """Search memories with optional confidence-policy gating."""
    async def _do():
        ml = await _connect()
        try:
            kwargs: dict[str, Any] = {"query": query, "namespace": namespace, "agent_id": agent_id, "top_k": top_k}
            if confidence_min is not None:
                kwargs["confidence_policy"] = {
                    "min_threshold": confidence_min,
                    "flag_threshold": min(1.0, confidence_min + 0.2),
                }
            result = await ml.search(**kwargs)
        finally:
            await ml.close()

        if not result.records:
            console.print("[yellow]no results[/yellow]")
            return

        table = Table(title=f"search: {query!r}", box=box.ROUNDED)
        table.add_column("id", style="dim")
        table.add_column("conf")
        table.add_column("eff")
        table.add_column("namespace", style="cyan")
        table.add_column("created_by")
        table.add_column("content")
        for r in result.records:
            md = r.metadata or {}
            eff = md.get("_effective_confidence")
            eff_str = f"[yellow]{eff:.2f}[/yellow]" if eff is not None else "-"
            table.add_row(
                r.id[:8],
                f"[{_conf_color(r.confidence or 0.5)}]{(r.confidence or 0.0):.2f}[/]",
                eff_str,
                r.namespace,
                r.created_by or "-",
                (r.content or "")[:60],
            )
        console.print(table)
        if result.metadata and result.metadata.get("confidence_gating"):
            g = result.metadata["confidence_gating"]
            console.print(
                f"[dim]gate: passed={g['passed']} flagged={g['flagged']} filtered={g['filtered']} "
                f"(min={g['policy']['min']:.2f})[/dim]"
            )

    _run(_do())


@app.command()
def get(
    memory_id: str = typer.Argument(..., help="Memory ID (full or short prefix)"),
    show_chain: bool = typer.Option(False, "--chain", help="Also print the upstream attribution chain"),
):
    """Fetch a single memory by ID; optionally print its provenance chain."""
    async def _do():
        ml = await _connect()
        try:
            record = await ml.get(memory_id)
            if not record:
                console.print(f"[red]not found: {memory_id}[/red]")
                raise typer.Exit(1)
            console.print(Panel.fit(
                f"[bold]{record.id}[/bold]\n"
                f"namespace: [cyan]{record.namespace}[/cyan]\n"
                f"created_by: {record.created_by or '-'}\n"
                f"confidence: [{_conf_color(record.confidence or 0.5)}]{record.confidence or 0.0:.2f}[/]\n"
                f"derived_from: {record.derived_from or []}\n\n"
                f"{record.content or ''}",
                title="memory",
            ))
            if show_chain:
                chain = await ml.chain_store.build_chain(record.id, direction="upstream")
                console.print(f"[dim]chain depth={chain.chain_depth} min_confidence={chain.min_confidence:.2f}[/dim]")
                for hop in chain.chain:
                    console.print(f"  hop {hop.hop_number}: {hop.memory_id[:8]} by {hop.agent_id} (conf={hop.confidence:.2f})")
        finally:
            await ml.close()

    _run(_do())


# ---------------------------------------------------------------------------
# memledger calibrate
# ---------------------------------------------------------------------------

calibrate_app = typer.Typer(help="[internal] Calibration set management", hidden=True)
app.add_typer(calibrate_app, name="calibrate", hidden=True)

@calibrate_app.command("show")
def calibrate_show():
    """Display F10 calibration results."""
    _ensure_src()

    results_path = _project_root() / "evaluators" / "calibration" / "results_summary.json"
    if not results_path.exists():
        console.print("[yellow]No calibration results found. Run score_agreement.py first.[/yellow]")
        raise typer.Exit(1)

    with open(results_path) as f:
        results = json.load(f)

    # Summary table
    table = Table(title="Memory Attribution Integrity — Calibration", box=box.ROUNDED, show_lines=True)
    table.add_column("Metric", style="bold")
    table.add_column("Option A (deterministic)")
    table.add_column("Option C (RAGAS LLM-judge)")

    kappa_a = results["option_a"]["cohens_kappa"]
    kappa_b = results["option_b"]["cohens_kappa"]
    color_a = "green" if kappa_a >= 0.5 else ("yellow" if kappa_a >= 0.3 else "red")
    color_b = "green" if kappa_b >= 0.5 else ("yellow" if kappa_b >= 0.3 else "red")

    table.add_row("Agreement", results["option_a"]["overall_agreement"], results["option_b"]["overall_agreement"])
    table.add_row("Cohen's κ", f"[{color_a}]{kappa_a}[/{color_a}]", f"[{color_b}]{kappa_b}[/{color_b}]")

    console.print(table)

    # Per category
    cat_table = Table(title="Per-Category Agreement", box=box.SIMPLE)
    cat_table.add_column("Category", style="bold")
    cat_table.add_column("Option A")
    cat_table.add_column("Option B")

    for cat, data in results.get("per_category", {}).items():
        cat_table.add_row(cat, data["option_a_agreement"], data["option_b_agreement"])

    console.print(cat_table)

    # Inter-evaluator
    inter = results.get("inter_evaluator", {})
    console.print(Panel(
        f"A vs B agreement: {inter.get('agreement', 'N/A')}\n"
        f"Cohen's κ: {inter.get('cohens_kappa', 'N/A')}",
        title="Inter-Evaluator Agreement",
        border_style="cyan",
    ))


@calibrate_app.command("run")
def calibrate_run():
    """Run calibration against the labeled dataset."""
    _ensure_src()
    from evaluators.calibration.score_agreement import run_calibration
    run_calibration()


# ---------------------------------------------------------------------------
# memledger trace
# ---------------------------------------------------------------------------

trace_app = typer.Typer(help="Trace and provenance inspection")
app.add_typer(trace_app, name="trace")

@trace_app.command("show")
def trace_show(session_id: str = typer.Argument(..., help="Session ID")):
    """Pretty-print provenance chain and memories for a session."""
    _ensure_src()

    async def _trace():
        ml = await _connect()
        records = await ml.get_by_session(session_id)

        if not records:
            console.print(f"[yellow]No memories found for session '{session_id}'[/yellow]")
            await ml.close()
            return

        # Build provenance tree
        tree = Tree(f"[bold]Session: {session_id}[/bold] ({len(records)} memories)")

        for rec in records:
            conf = rec.confidence or 0.5
            color = _conf_color(conf)
            rt = rec.record_type.value if hasattr(rec.record_type, "value") else str(rec.record_type)
            agent = rec.created_by or "unknown"

            node_label = (
                f"[{color}]●[/{color}] [{color}]{rec.id[:8]}[/{color}] "
                f"{rt} | conf={conf:.2f} | {agent}\n"
                f"  [dim]{rec.content[:80]}[/dim]"
            )
            node = tree.add(node_label)

            if rec.derived_from:
                node.add(f"[dim]derived_from: {', '.join(d[:8] for d in rec.derived_from)}[/dim]")
            if rec.supersedes:
                node.add(f"[dim]supersedes: {rec.supersedes[:8]}[/dim]")
            if rec.triggered_by:
                node.add(f"[dim]triggered_by: {rec.triggered_by}[/dim]")

        console.print(tree)

        # Show lineage for the last record
        if records:
            last = records[-1]
            lineage = await ml.get_lineage(record_id=last.id)
            if "error" not in lineage and lineage.get("supersedes_chain"):
                console.print(Panel(
                    "\n".join(
                        f"← [{p['id'][:8]}] {p.get('content', '')[:60]} ({p.get('status', '')})"
                        for p in lineage["supersedes_chain"]
                    ),
                    title="Supersession Chain",
                    border_style="yellow",
                ))

        await ml.close()

    _run(_trace())


# ---------------------------------------------------------------------------
# memledger conflict
# ---------------------------------------------------------------------------

conflict_app = typer.Typer(help="Conflict detection")
app.add_typer(conflict_app, name="conflict")

@conflict_app.command("check")
def conflict_check(
    memory_a: str = typer.Argument(..., help="Memory ID A"),
    memory_b: str = typer.Argument(..., help="Memory ID B"),
):
    """Run conflict detection between two memories with position-bias check."""
    _ensure_src()

    async def _check():
        ml = await _connect()

        rec_a = await ml.get(memory_a)
        rec_b = await ml.get(memory_b)

        if not rec_a or not rec_b:
            console.print("[red]One or both memory IDs not found.[/red]")
            await ml.close()
            return

        from memledger.policies.conflict_resolution import check_conflict, PositionBiasTracker

        result = check_conflict(rec_a.content, rec_a.created_by or "", [rec_b])

        table = Table(title="Conflict Detection", box=box.ROUNDED, show_lines=True)
        table.add_column("Field", style="bold")
        table.add_column("Value")

        color = "red" if result.has_conflict else "green"
        table.add_row("Conflict", f"[{color}]{result.has_conflict}[/{color}]")
        table.add_row("Similarity", f"{result.similarity:.4f}")
        table.add_row("Action", result.action)
        table.add_row("Reason", result.reason or "No conflict detected")
        table.add_row("Memory A", f"{rec_a.id[:8]} by {rec_a.created_by} (conf={rec_a.confidence:.2f})")
        table.add_row("Memory B", f"{rec_b.id[:8]} by {rec_b.created_by} (conf={rec_b.confidence:.2f})")

        console.print(table)

        # Position bias check (deterministic judge)
        tracker = PositionBiasTracker()

        async def _det_judge(text_a, text_b):
            r = check_conflict(text_a, "", [type("R", (), {"content": text_b, "id": "x", "created_by": ""})()])
            return "conflict" if r.has_conflict else "no_conflict"

        await tracker.run_paired(_det_judge, rec_a.content, rec_b.content, rec_a.id, rec_b.id)
        console.print(Panel(tracker.summary(), title="Position Bias (F12)", border_style="cyan"))

        await ml.close()

    _run(_check())


# ---------------------------------------------------------------------------
# memledger trust — the detective story
# ---------------------------------------------------------------------------

trust_app = typer.Typer(
    help="[demo] Memory detective — kagent demo narrative commands. Hidden from --help.",
    hidden=True,
)
app.add_typer(trust_app, name="trust", hidden=True)


@trust_app.command("reset")
def trust_reset(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Clear all memories. Clean crime scene."""
    if not confirm:
        confirmed = typer.confirm("Clear all memories?")
        if not confirmed:
            raise typer.Exit(0)

    _run_via_eks_raw("""
import asyncio, asyncpg, os
async def go():
    dsn = os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL','')
    conn = await asyncpg.connect(dsn)
    count = await conn.fetchval('SELECT COUNT(*) FROM agent_memory')
    await conn.execute('DELETE FROM agent_memory')
    print(f'Cleared {count} memories')
    await conn.close()
asyncio.run(go())
""")
    console.print("[green]Memory store cleared.[/green]")


@trust_app.command("seed")
def trust_seed():
    """Seed healthy provenance chain — the normal state."""
    _ensure_src()
    console.print(Panel(
        "[bold]Seeding healthy provenance chain[/bold]\n\n"
        "research-agent(0.25) → triage-agent(0.45) → ops-agent(0.85) → ops-fix(0.90) → compliance-runbook(0.88)\n"
        "Plus one isolated low-confidence memory (0.30)",
        title="Trust Seed",
        border_style="green",
    ))

    import subprocess
    # Copy seed script and run on EKS
    seed_path = str(_project_root() / "scripts" / "seed_demo_data.py")
    pod = subprocess.run(
        ["kubectl", "get", "pod", "-n", "kagent", "-l", "app.kubernetes.io/name=eks-ops-agent",
         "-o", "jsonpath={.items[0].metadata.name}"],
        capture_output=True, text=True, timeout=10,
    ).stdout.strip()

    subprocess.run(
        ["kubectl", "cp", seed_path, f"kagent/{pod}:/tmp/seed_demo_data.py"],
        capture_output=True, timeout=15,
    )
    r = subprocess.run(
        ["kubectl", "exec", "-n", "kagent", f"{pod}", "--", "python3", "/tmp/seed_demo_data.py"],
        capture_output=True, text=True, timeout=120,
    )
    for line in r.stdout.strip().split("\n"):
        console.print(f"  {line}")

    console.print("\n[bold green]→ Open memledger UI to see the trust graph[/bold green]")


@trust_app.command("baseline")
def trust_baseline():
    """Act 1 — Show the healthy state. Three agents, clean lineage."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 1 — The Normal[/bold]\n\n"
        "Three agents on kagent. Shared Aurora memory store via memledger.\n"
        "Clean provenance chain. Full attribution. This is the state you want.",
        title="\U0001f7e2 The Normal",
        border_style="green",
    ))
    status()
    console.print("\n[bold green]→ Switch to memledger UI — trust graph shows healthy lineage[/bold green]")
    console.print("[dim]  Green/yellow/red nodes. Solid edges = derived. Dashed = supersedes.[/dim]")


@trust_app.command("inject")
def trust_inject(seed: int = typer.Option(42, help="Seed")):
    """Act 2 — Inject bad memory. Silent cascade failure."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 2 — The Crime[/bold]\n\n"
        "Research-agent writes unverified blog recommendation (confidence 0.25).\n"
        "Ops-agent retrieves it without governance — treats it as ground truth.\n"
        "Wrong configuration applied. Silent cascade.",
        title="\U0001f534 The Crime",
        border_style="red",
    ))
    run(scenario="cascade_failure", seed=seed, provenance="off", eks=True)
    console.print("\n[bold yellow]→ How would you debug this?[/bold yellow]")
    console.print("[dim]  The agent acted confidently on garbage data. No one flagged it.[/dim]")


@trust_app.command("investigate")
def trust_investigate():
    """Act 3+4 — Conventional traces fall short. memledger reveals the chain."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 3 — The Conventional Investigation[/bold]\n\n"
        "Phoenix shows OTEL traces — what happened and when.\n"
        "But not why the memory was bad. No confidence. No provenance.\n"
        "Standard observability gives you the timeline, not the diagnosis.",
        title="\U0001f50d Conventional Investigation",
        border_style="yellow",
    ))
    console.print("\n[bold yellow]→ Switch to Phoenix (localhost:6006)[/bold yellow]")
    console.print("[dim]  Filter: name != 'GET /health'. Click a trace with many spans.[/dim]")
    console.print("[dim]  Show the Bedrock call — input/output visible, but no confidence metadata.[/dim]")

    console.print()
    console.print(Panel(
        "[bold]Act 4 — The memledger Investigation[/bold]\n\n"
        "Switch to the trust graph. The tainted memory is visible.\n"
        "Red node (conf 0.25) → ops-agent derived decision → cascade.\n"
        "Provenance chain reveals the root cause. Detective arc closes.",
        title="\U0001f9e0 memledger Investigation",
        border_style="cyan",
    ))
    console.print("\n[bold cyan]→ Switch to memledger UI (localhost:8501)[/bold cyan]")
    console.print("[dim]  Red node = tainted memory. Follow the edges. The chain tells the story.[/dim]")


@trust_app.command("prevent")
def trust_prevent(seed: int = typer.Option(42, help="Seed")):
    """Act 5 — Same scenario, confidence gating catches it."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 5 — The Prevention[/bold]\n\n"
        "Same scenario. Same bad memory. Confidence gating enabled.\n"
        "Memories below 0.4 filtered. Between 0.4–0.6 flagged.\n"
        "The ops-agent never sees the garbage. No cascade.",
        title="\U0001f6e1\ufe0f  The Prevention",
        border_style="green",
    ))

    # Run in a clean namespace so only the bad memory is findable
    _run_via_eks_prevent(seed)
    console.print("\n[bold green]→ The governance layer caught it. Same data, different outcome.[/bold green]")


def _run_via_eks_prevent(seed: int):
    """Run provenance scenario in isolated namespace to show clear filtering."""
    import subprocess

    script = f"""
import asyncio, os, random, json
async def go():
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig, MemledgerConfig
    dsn = os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL','')
    ml = await Memledger.create(
        backend_name='pgvector', connection_string=dsn,
        embedding_config=EmbeddingConfig(provider='bedrock',model='amazon.titan-embed-text-v2:0',dimensions=1024),
        engram_config=MemledgerConfig(strict_provenance=False, conflict_threshold=0.65),
    )
    from memledger.telemetry import instrument_engram
    instrument_engram(ml)

    rng = random.Random({seed})
    ns = '/demo/prevent'

    # Step 1: Write bad memory
    bad_id = await ml.add(
        content=f'max_connections should be set to {{rng.randint(5,15)}} (from unverified blog)',
        record_type=RecordType.SEMANTIC, namespace=ns,
        created_by='research-agent', confidence=0.25, importance=0.25,
        session_id='prevent-{seed}',
    )
    print(f'Step 1: research-agent wrote [{{bad_id[:8]}}] confidence=0.25')

    # Step 2: Search WITH confidence gating
    results = await ml.search(
        'max_connections postgres setting', namespace=ns, top_k=5,
        confidence_policy={{'min_threshold': 0.4, 'flag_threshold': 0.6}},
    )

    if not results.records:
        print(f'Step 2: ops-agent search returned 0 results — LOW-CONFIDENCE MEMORY FILTERED')
        print(f'Step 3: ops-agent says "No reliable guidance found. Recommend manual investigation."')
        print(f'RESULT: Governance prevented the cascade. Bad memory exists but was never acted on.')
    else:
        top = results.records[0]
        if top.confidence < 0.6:
            print(f'Step 2: ops-agent found [{{top.id[:8]}}] conf={{top.confidence:.2f}} — FLAGGED as low confidence')
            print(f'Step 3: ops-agent HEDGED — "Found guidance but confidence is low ({{top.confidence:.2f}}). Recommend verification."')
            print(f'RESULT: Agent hedged instead of blindly acting. Governance worked.')
        else:
            print(f'Step 2: ops-agent found [{{top.id[:8]}}] conf={{top.confidence:.2f}} by={{top.created_by}}')
            print(f'Step 3: ops-agent used high-confidence source — governance approved.')
            print(f'RESULT: Agent used a trusted source. Low-confidence memory was bypassed.')

    stats = await ml.stats()
    print(f'Total memories: {{stats.get("total_count",0)}}')
    await ml.close()
asyncio.run(go())
"""

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        progress.add_task(f"Running prevention scenario on EKS...")

        r = subprocess.run(
            ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
             "python3", "-c", script],
            capture_output=True, text=True, timeout=120,
        )

    if r.returncode == 0:
        for line in r.stdout.strip().split("\n"):
            if "FILTERED" in line or "HEDGED" in line or "RESULT" in line:
                console.print(f"[green]{line}[/green]")
            elif "FLAGGED" in line:
                console.print(f"[yellow]{line}[/yellow]")
            else:
                console.print(line)
    else:
        console.print(Panel(r.stderr[:300], title="Error", border_style="red"))


@trust_app.command("measure")
def trust_measure():
    """Act 5 (continued) — Run evaluators, show the delta."""
    _ensure_src()
    console.print(Panel(
        "[bold]The Measurement[/bold]\n\n"
        "Two independent evaluators. Same rubric. Different methods.\n"
        "Option A: deterministic rules, no LLM, runs in under 1ms.\n"
        "Option C: Claude Sonnet via RAGAS (open source), LLM-as-judge, ~3s.\n"
        "Both calibrated against 30 human-labeled examples.",
        title="\U0001f4ca The Measurement",
        border_style="cyan",
    ))
    calibrate_show()
    console.print("\n[bold cyan]→ Switch to AgentCore console for AWS-managed evaluation[/bold cyan]")
    console.print("[dim]  Bedrock AgentCore Observability → eks-ops-agent → Traces → Evaluations[/dim]")


@trust_app.command("limits")
def trust_limits():
    """Act 6 — Honest limits. Goodhart and memory poisoning."""
    console.print(Panel(
        "[bold]Known Limits of the Current Design[/bold]\n\n"
        "[yellow]Goodhart vulnerability.[/yellow]\n"
        "Confidence scores are a target. Agents optimized against memledger's\n"
        "rankings could learn to write memories that look authoritative.\n"
        "Mitigation: periodic sampling for human audit; adversarial evaluators\n"
        "for suspicious confidence trajectories.\n\n"
        "[yellow]Memory poisoning.[/yellow]\n"
        "Namespace RBAC restricts who can write, not what they write.\n"
        "A prompt-injected agent can still write plausible false memories.\n"
        "Lineage traces the damage — it doesn't prevent it.\n"
        "Mitigation: adversarial validation at write time for high-stakes namespaces.\n\n"
        "[dim]Naming the limits is the platform thesis.\n"
        "You can't govern what you can't see.[/dim]",
        title="\U0001f6a8 Honest Limits",
        border_style="yellow",
    ))


def _run_via_eks_raw(script: str):
    """Run a raw Python script on EKS via kubectl exec."""
    import subprocess
    r = subprocess.run(
        ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
         "python3", "-c", script],
        capture_output=True, text=True, timeout=120,
    )
    if r.returncode != 0:
        console.print(Panel(r.stderr[:300], title="Error", border_style="red"))
    return r.stdout.strip()


# Keep old demo commands as aliases
demo_app = typer.Typer(help="Aliases for trust commands", hidden=True)
app.add_typer(demo_app, name="demo")

@demo_app.command("act1")
def demo_act1():
    """Alias for trust baseline."""
    trust_baseline()

@demo_app.command("act2")
def demo_act2(seed: int = typer.Option(42)):
    """Alias for trust attack."""
    trust_inject(seed=seed)

@demo_app.command("act5")
def demo_act5(seed: int = typer.Option(42)):
    """Alias for trust prevent."""
    trust_prevent(seed=seed)

@demo_app.command("act6")
def demo_act6():
    """Alias for trust limits."""
    trust_limits()


# ---------------------------------------------------------------------------
# memledger reset
# ---------------------------------------------------------------------------

@app.command()
def reset(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Clear all demo data from the memory store."""
    if not confirm:
        confirmed = typer.confirm("This will delete ALL memories in the store. Continue?")
        if not confirmed:
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(0)

    async def _reset():
        import asyncpg
        dsn = _get_dsn()
        conn = await asyncpg.connect(dsn)
        count = await conn.fetchval("SELECT COUNT(*) FROM agent_memory")
        await conn.execute("DELETE FROM agent_memory")
        await conn.close()
        return count

    count = _run(_reset())
    console.print(Panel(f"Deleted {count} memories.", title="Reset", border_style="yellow"))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Entry point for pyproject.toml console_scripts."""
    app()


if __name__ == "__main__":
    main()
