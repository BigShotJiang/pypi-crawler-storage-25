# SPDX-License-Identifier: Apache-2.0
"""Memledger dashboard — generates static HTML reports for memory inspection.

Two commands:

  engram lineage <id-or-description> [--config PATH] [--output PATH]
      Render a single memory's lineage as an HTML page with a Mermaid
      supersedes/derived chain diagram, audit timeline, and provenance
      details.

  engram dashboard [--config PATH] [--output PATH]
      Render an overview HTML page: stats, lifecycle distribution,
      record-type breakdown, recent audit log, and a list of all
      active memories grouped by namespace.

Both commands write a self-contained HTML file (Mermaid loaded from CDN)
and print the path. Pass `--open` to open it in the default browser.
"""

from __future__ import annotations

import argparse
import asyncio
import html
import sys
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from memledger.memledger import Memledger
from memledger.models import MemoryRecord

# ── Styling ──────────────────────────────────────────────────────────

_CSS = """
:root {
  --bg: #0f1419;
  --panel: #1a1f2e;
  --panel-2: #232938;
  --border: #2d3548;
  --text: #e6e9ef;
  --text-dim: #8b94a8;
  --accent: #7aa2f7;
  --accent-2: #bb9af7;
  --green: #9ece6a;
  --yellow: #e0af68;
  --red: #f7768e;
  --orange: #ff9e64;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Inter",
               "Segoe UI", Roboto, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.55;
}
.container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 32px 24px 64px;
}
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 20px;
  margin-bottom: 28px;
  border-bottom: 1px solid var(--border);
}
h1 {
  font-size: 22px;
  font-weight: 600;
  margin: 0;
  letter-spacing: -0.01em;
}
h1 .sub {
  color: var(--text-dim);
  font-weight: 400;
  margin-left: 10px;
  font-size: 14px;
}
.brand {
  font-size: 12px;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.12em;
}
h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-dim);
  font-weight: 600;
  margin: 32px 0 12px;
}
.panel {
  background: var(--panel);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 22px 24px;
  margin-bottom: 16px;
}
.panel.tight { padding: 14px 18px; }
.kv {
  display: grid;
  grid-template-columns: 160px 1fr;
  gap: 8px 20px;
  font-size: 14px;
}
.kv dt {
  color: var(--text-dim);
  font-weight: 500;
}
.kv dd {
  margin: 0;
  color: var(--text);
  font-family: ui-monospace, "SF Mono", "Menlo", monospace;
  font-size: 13px;
  word-break: break-word;
}
.content-block {
  background: var(--panel-2);
  border-left: 3px solid var(--accent);
  padding: 14px 16px;
  border-radius: 6px;
  font-size: 14px;
  white-space: pre-wrap;
  word-break: break-word;
  margin-top: 8px;
}
.badges { display: flex; gap: 6px; flex-wrap: wrap; }
.badge {
  display: inline-block;
  padding: 3px 9px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  background: var(--panel-2);
  color: var(--text);
  border: 1px solid var(--border);
}
.badge.semantic   { color: var(--accent);    border-color: var(--accent); }
.badge.episodic   { color: var(--accent-2);  border-color: var(--accent-2); }
.badge.procedural { color: var(--green);     border-color: var(--green); }
.badge.active     { color: var(--green);     border-color: var(--green); }
.badge.deprecated { color: var(--yellow);    border-color: var(--yellow); }
.badge.expired    { color: var(--orange);    border-color: var(--orange); }
.badge.archived   { color: var(--red);       border-color: var(--red); }
table.data {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  border: 1px solid var(--border);
  border-radius: 6px;
  overflow: hidden;
  table-layout: fixed;
}
table.data thead th {
  background: var(--panel-2);
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-size: 11px;
  font-weight: 600;
  text-align: left;
  padding: 10px 14px;
  border-bottom: 1px solid var(--border);
  border-right: 1px solid var(--border);
  white-space: nowrap;
}
table.data col.col-id      { width: 110px; }
table.data col.col-type    { width: 130px; }
table.data col.col-status  { width: 110px; }
table.data col.col-ts      { width: 180px; }
table.data col.col-op      { width: 130px; }
table.data thead th:last-child { border-right: none; }
table.data tbody td {
  padding: 12px 14px;
  border-bottom: 1px solid var(--border);
  border-right: 1px solid var(--border);
  vertical-align: top;
  word-break: break-word;
  white-space: normal;
}
table.data tbody td:last-child { border-right: none; }
table.data tbody tr:last-child td { border-bottom: none; }
table.data .mono {
  font-family: ui-monospace, "SF Mono", "Menlo", monospace;
  color: var(--text-dim);
}
table.data .op { color: var(--accent); font-weight: 600; }
.mermaid-wrap {
  background: var(--panel-2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 24px;
  overflow-x: auto;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
  margin-bottom: 8px;
}
.stat {
  background: var(--panel);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 18px 20px;
}
.stat .num {
  font-size: 28px;
  font-weight: 600;
  color: var(--text);
  letter-spacing: -0.02em;
}
.stat .label {
  font-size: 11px;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-top: 2px;
}
.namespace-group { margin-bottom: 22px; }
.namespace-group h3 {
  font-size: 13px;
  font-family: ui-monospace, "SF Mono", "Menlo", monospace;
  color: var(--accent);
  margin: 0 0 6px;
}
.empty {
  color: var(--text-dim);
  font-style: italic;
  font-size: 13px;
}
footer {
  margin-top: 40px;
  padding-top: 18px;
  border-top: 1px solid var(--border);
  color: var(--text-dim);
  font-size: 12px;
  text-align: center;
}
"""

_MERMAID_SCRIPT = """
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>
  mermaid.initialize({
    startOnLoad: true,
    theme: 'dark',
    themeVariables: {
      background: '#1a1f2e',
      primaryColor: '#232938',
      primaryTextColor: '#e6e9ef',
      primaryBorderColor: '#7aa2f7',
      lineColor: '#8b94a8',
      fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
      fontSize: '14px'
    },
    flowchart: { curve: 'basis', padding: 20 }
  });
</script>
"""


# ── HTML helpers ─────────────────────────────────────────────────────


def _esc(s: Any) -> str:
    return html.escape(str(s)) if s is not None else ""


def _short(record_id: Optional[str]) -> str:
    if not record_id:
        return ""
    return record_id[:8]


def _badge(kind: str, value: str) -> str:
    return f'<span class="badge {kind}">{_esc(value)}</span>'


def _page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{_esc(title)}</title>
  <style>{_CSS}</style>
</head>
<body>
  <div class="container">
    {body}
    <footer>generated by engram dashboard · {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}</footer>
  </div>
  {_MERMAID_SCRIPT}
</body>
</html>
"""


# ── Lineage rendering ────────────────────────────────────────────────


def _mermaid_lineage(lineage: dict[str, Any]) -> str:
    """Build a Mermaid flowchart for a lineage result."""
    rec = lineage.get("record", {})
    if not rec:
        return ""

    root_id = rec["id"]
    root_short = _short(root_id)
    root_type = rec.get("record_type", "semantic")
    root_label = f"{rec.get('content', '')[:60]}..."

    lines = ["flowchart TB"]
    lines.append(f'    ROOT["{root_short}<br/><i>{root_type}</i><br/>{_mermaid_escape(root_label)}"]')
    lines.append("    style ROOT fill:#7aa2f7,color:#0f1419,stroke:#7aa2f7,stroke-width:2px")

    # Supersedes chain (backward)
    prev = "ROOT"
    for i, anc in enumerate(lineage.get("supersedes_chain", [])):
        node = f"S{i}"
        lbl = f"{_short(anc['id'])}<br/><i>{anc.get('status', 'unknown')}</i><br/>{_mermaid_escape(anc.get('content', '')[:60])}..."
        lines.append(f'    {node}["{lbl}"]')
        lines.append(f"    style {node} fill:#232938,color:#e6e9ef,stroke:#e0af68,stroke-width:1px")
        lines.append(f"    {prev} -.->|supersedes| {node}")
        prev = node

    # Derived records (forward)
    for i, der in enumerate(lineage.get("derived_records", [])):
        node = f"D{i}"
        lbl = f"{_short(der['id'])}<br/><i>derived</i><br/>{_mermaid_escape(der.get('content', '')[:60])}..."
        lines.append(f'    {node}["{lbl}"]')
        lines.append(f"    style {node} fill:#232938,color:#e6e9ef,stroke:#9ece6a,stroke-width:1px")
        lines.append(f"    ROOT ==>|derived| {node}")

    return "\n".join(lines)


def _mermaid_escape(s: str) -> str:
    """Escape characters that break Mermaid labels."""
    return s.replace('"', "'").replace("[", "(").replace("]", ")").replace("{", "(").replace("}", ")")


def render_lineage_html(lineage: dict[str, Any], audit_entries: list) -> str:
    if "error" in lineage:
        body = f'<header><h1>Lineage</h1></header><div class="panel"><p class="empty">Error: {_esc(lineage["error"])}</p></div>'
        return _page("Memledger · Lineage", body)

    rec = lineage["record"]
    rid = rec["id"]
    short = _short(rid)

    diagram = _mermaid_lineage(lineage)

    confidence = lineage.get("confidence", "—")
    if isinstance(confidence, (int, float)):
        confidence = f"{confidence:.3f}"

    kv_rows = [
        ("ID", rid),
        ("Type", _badge(rec.get("record_type", ""), rec.get("record_type", ""))),
        ("Status", _badge(rec.get("status", ""), rec.get("status", ""))),
        ("Confidence", confidence),
        ("Created", rec.get("created_at", "—") or "—"),
    ]
    if lineage.get("created_by"):
        kv_rows.append(("Created by", _esc(lineage["created_by"])))
    if lineage.get("workflow_id"):
        kv_rows.append(("Workflow", _esc(lineage["workflow_id"])))
    if lineage.get("triggered_by"):
        kv_rows.append(("Triggered by", _esc(lineage["triggered_by"])))
    if lineage.get("accessed_by"):
        kv_rows.append(("Accessed by", _esc(", ".join(lineage["accessed_by"]))))

    kv_html = "\n".join(f"<dt>{k}</dt><dd>{v}</dd>" for k, v in kv_rows)

    timeline_html = ""
    if audit_entries:
        rows = []
        for e in audit_entries:
            ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            details = e.details.get("content", "") or e.details.get("result", "")
            rows.append(
                f"<tr>"
                f'<td class="mono">{_esc(ts)}</td>'
                f'<td class="op">{_esc(e.operation)}</td>'
                f"<td>{_esc(details)}</td>"
                f"</tr>"
            )
        timeline_html = (
            "<h2>Audit Trail</h2>"
            '<table class="data">'
            '<colgroup><col class="col-ts"><col class="col-op"><col></colgroup>'
            "<thead><tr><th>Timestamp</th><th>Operation</th><th>Details</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody>"
            "</table>"
        )

    body = f"""
<header>
  <h1>Memory Lineage <span class="sub">{short}</span></h1>
  <span class="brand">engram dashboard</span>
</header>

<h2>Record</h2>
<div class="panel">
  <dl class="kv">{kv_html}</dl>
  <div class="content-block">{_esc(rec.get("content", ""))}</div>
</div>

<h2>Provenance Graph</h2>
<div class="mermaid-wrap">
  <pre class="mermaid">{diagram}</pre>
</div>

{timeline_html}
"""
    return _page(f"Memledger · Lineage · {short}", body)


# ── Dashboard rendering ──────────────────────────────────────────────


def _stat(num: Any, label: str) -> str:
    return f'<div class="stat"><div class="num">{_esc(num)}</div><div class="label">{_esc(label)}</div></div>'


def render_dashboard_html(
    stats: dict[str, Any],
    records: list[MemoryRecord],
    audit_entries: list,
) -> str:
    by_type = stats.get("by_record_type", {}) or {}
    by_status = stats.get("by_status", {}) or {}

    stat_cards = [
        _stat(stats.get("total_count", 0), "Total Memories"),
        _stat(by_type.get("semantic", 0), "Semantic"),
        _stat(by_type.get("episodic", 0), "Episodic"),
        _stat(by_type.get("procedural", 0), "Procedural"),
        _stat(by_status.get("active", 0), "Active"),
        _stat(by_status.get("archived", 0), "Archived"),
    ]
    stats_html = '<div class="stats-grid">' + "".join(stat_cards) + "</div>"

    # Group active records by namespace, render each as a table
    by_ns: dict[str, list[MemoryRecord]] = {}
    for r in records:
        by_ns.setdefault(r.namespace or "/", []).append(r)

    ns_blocks = []
    for ns in sorted(by_ns):
        rows = []
        for r in sorted(by_ns[ns], key=lambda x: x.created_at or datetime.min, reverse=True):
            rt = r.record_type.value if hasattr(r.record_type, "value") else r.record_type
            st = r.status.value if hasattr(r.status, "value") else r.status
            rows.append(
                "<tr>"
                f'<td class="mono">{_short(r.id)}</td>'
                f"<td>{_badge(rt, rt)}</td>"
                f"<td>{_badge(st, st)}</td>"
                f"<td>{_esc(r.content or '')}</td>"
                "</tr>"
            )
        ns_blocks.append(
            f'<div class="namespace-group">'
            f"<h3>{_esc(ns)}</h3>"
            '<table class="data">'
            '<colgroup><col class="col-id"><col class="col-type"><col class="col-status"><col></colgroup>'
            "<thead><tr><th>ID</th><th>Memory Type</th><th>Status</th><th>Content</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody>"
            "</table>"
            "</div>"
        )

    records_html = "".join(ns_blocks) if ns_blocks else '<p class="empty">No memories yet.</p>'

    if audit_entries:
        rows = []
        for e in audit_entries[-15:]:
            ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            details = e.details.get("content", "") or e.details.get("result", "")
            rows.append(
                "<tr>"
                f'<td class="mono">{_esc(ts)}</td>'
                f'<td class="op">{_esc(e.operation)}</td>'
                f"<td>{_esc(details)}</td>"
                "</tr>"
            )
        timeline_html = (
            '<table class="data">'
            '<colgroup><col class="col-ts"><col class="col-op"><col></colgroup>'
            "<thead><tr><th>Timestamp</th><th>Operation</th><th>Details</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody>"
            "</table>"
        )
    else:
        timeline_html = '<p class="empty">No audit entries.</p>'

    body = f"""
<header>
  <h1>Memledger Dashboard <span class="sub">memory overview</span></h1>
  <span class="brand">engram dashboard</span>
</header>

<h2>Statistics</h2>
{stats_html}

<h2>Recent Audit</h2>
{timeline_html}

<h2>Active Memories</h2>
{records_html}
"""
    return _page("Memledger · Dashboard", body)


# ── Async entry points ───────────────────────────────────────────────


async def _run_lineage(args: argparse.Namespace) -> int:
    if not args.config:
        print("error: --config is required", file=sys.stderr)
        return 2

    engram = await Memledger.from_config(args.config)
    try:
        # Try as exact ID first; fall back to description-based lookup
        lineage = await engram.get_lineage(
            record_id=args.target,
            description=args.target,
        )
        # Pull audit entries for this record
        audit_entries: list = []
        if "record" in lineage and "id" in lineage["record"]:
            audit_entries = engram.audit.by_record(lineage["record"]["id"])

        html_doc = render_lineage_html(lineage, audit_entries)
    finally:
        await engram.close()

    out = Path(args.output) if args.output else Path("engram-lineage.html")
    out.write_text(html_doc, encoding="utf-8")
    print(f"wrote {out.resolve()}")
    if args.open:
        webbrowser.open(out.resolve().as_uri())
    return 0


async def _run_dashboard(args: argparse.Namespace) -> int:
    if not args.config:
        print("error: --config is required", file=sys.stderr)
        return 2

    engram = await Memledger.from_config(args.config)
    try:
        stats = await engram.stats()
        records = await engram.get_by_status("active")
        audit_entries = engram.audit.recent(50)
        html_doc = render_dashboard_html(stats, records, audit_entries)
    finally:
        await engram.close()

    out = Path(args.output) if args.output else Path("engram-dashboard.html")
    out.write_text(html_doc, encoding="utf-8")
    print(f"wrote {out.resolve()}")
    if args.open:
        webbrowser.open(out.resolve().as_uri())
    return 0


# ── Subparser registration ───────────────────────────────────────────


def add_subparsers(subparsers: Any) -> None:
    lineage = subparsers.add_parser(
        "lineage",
        help="Render a memory's lineage as an HTML report",
    )
    lineage.add_argument("target", help="Record ID or description to look up")
    lineage.add_argument("--config", "-c", required=True, help="Path to engram config YAML")
    lineage.add_argument("--output", "-o", help="Output HTML path (default: engram-lineage.html)")
    lineage.add_argument("--open", action="store_true", help="Open the report in a browser")
    lineage.set_defaults(_handler=lambda a: asyncio.run(_run_lineage(a)))

    dash = subparsers.add_parser(
        "dashboard",
        help="Render an overview dashboard of all active memories",
    )
    dash.add_argument("--config", "-c", required=True, help="Path to engram config YAML")
    dash.add_argument("--output", "-o", help="Output HTML path (default: engram-dashboard.html)")
    dash.add_argument("--open", action="store_true", help="Open the report in a browser")
    dash.set_defaults(_handler=lambda a: asyncio.run(_run_dashboard(a)))
