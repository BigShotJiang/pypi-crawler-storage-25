# SPDX-License-Identifier: Apache-2.0
"""Abstract base class for all storage backend providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from memledger.models import MemoryRecord


class BackendProvider(ABC):
    """Interface that every storage backend must implement.

    This is the single integration point. Implement this for pgvector,
    OpenSearch, Redis, DynamoDB, S3 Vectors, or any future backend.
    """

    @abstractmethod
    async def initialize(self, config: dict[str, Any]) -> None:
        """Initialize connection pools, create tables/indexes if needed."""
        ...

    @abstractmethod
    async def add(self, records: list[MemoryRecord]) -> list[str]:
        """Store one or more memory records. Returns list of record IDs."""
        ...

    @abstractmethod
    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        """Retrieve a single record by ID."""
        ...

    async def search_vector(
        self,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Semantic similarity search. Override in backends that support vector search.

        Key-value backends (DynamoDB, Redis) return empty — they rely on
        a search backend via multi-backend composition for semantic search.
        """
        return []

    async def search_text(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Full-text keyword search. Override in backends that support text search.

        Key-value backends return empty — use composition with a search backend.
        """
        return []

    @abstractmethod
    async def update(self, record_id: str, **kwargs: Any) -> bool:
        """Update fields on an existing record. Returns True if found."""
        ...

    @abstractmethod
    async def delete(self, record_id: str) -> bool:
        """Delete a record by ID. Returns True if found."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Clean up connections and resources."""
        ...

    async def health_check(self) -> bool:
        """Check if the backend is reachable. Override for backend-specific checks."""
        return True

    async def list_namespaces(self) -> list[str]:
        """List all distinct namespaces. Override in backends that support it."""
        return []

    async def stats(self, namespace: Optional[str] = None) -> dict[str, Any]:
        """Return memory statistics. Override in backends that support it."""
        return {}

    # ── Batch APIs (for lifecycle and consolidation workflows) ──

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        """Get all memories from a specific session."""
        return []

    async def get_by_timerange(
        self,
        start: Any,
        end: Any,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Get memories created within a time range."""
        return []

    async def get_stale(
        self,
        days: int = 30,
        min_access: int = 0,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Find active memories not accessed in N days with access_count <= min_access."""
        return []

    async def get_by_status(
        self,
        status: str,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Get memories with a specific lifecycle status."""
        return []

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        """Update status for multiple records. Returns count updated."""
        return 0

    async def bulk_archive(self, record_ids: list[str]) -> int:
        """Archive multiple records (soft delete). Returns count archived."""
        return await self.bulk_update_status(record_ids, "archived")
