# SPDX-License-Identifier: Apache-2.0
"""Amazon OpenSearch backend provider.

Supports k-NN vector search + BM25 full-text with hybrid scoring (RRF).
Requires: pip install engram[opensearch]
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Any, Optional

from memledger.backends.base import BackendProvider
from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


class OpenSearchBackend(BackendProvider):
    """Amazon OpenSearch / OpenSearch-compatible backend.

    Config keys:
        hosts: List of OpenSearch endpoints (e.g. ["https://host:9200"])
        auth_type: "basic" | "aws_sigv4"
        username: Basic auth username
        password: Basic auth password
        region: AWS region (for sigv4)
        index_name: Index name (default: engram-memory)
        dimensions: Vector dimensions (default: 1024)
        shards: Number of shards (default: 1)
        replicas: Number of replicas (default: 0)
    """

    def __init__(self) -> None:
        self._client = None
        self._index: str = "engram-memory"
        self._dimensions: int = 1024

    async def initialize(self, config: dict[str, Any]) -> None:
        try:
            from opensearchpy import OpenSearch
        except ImportError:
            raise ImportError("OpenSearch backend requires opensearch-py. Install with: pip install engram[opensearch]")

        self._index = config.get("index_name", "engram-memory")
        self._dimensions = config.get("dimensions", 1024)
        hosts = config.get("hosts", ["https://localhost:9200"])

        auth_type = config.get("auth_type", "basic")
        kwargs: dict[str, Any] = {
            "hosts": hosts,
            "use_ssl": any("https" in h for h in hosts),
            "verify_certs": config.get("verify_certs", False),
        }

        if auth_type == "basic":
            kwargs["http_auth"] = (
                config.get("username", "admin"),
                config.get("password", "admin"),
            )
        elif auth_type == "aws_sigv4":
            import boto3
            from opensearchpy import AWSV4SignerAuth, RequestsHttpConnection

            region = config.get("region") or os.getenv("AWS_REGION", "us-west-2")
            credentials = boto3.Session().get_credentials()
            kwargs["http_auth"] = AWSV4SignerAuth(credentials, region, "es")
            kwargs["connection_class"] = RequestsHttpConnection

        self._client = OpenSearch(**kwargs)

        # Create index if not exists
        if not self._client.indices.exists(index=self._index):
            body = {
                "settings": {
                    "index": {
                        "knn": True,
                        "number_of_shards": config.get("shards", 1),
                        "number_of_replicas": config.get("replicas", 0),
                    }
                },
                "mappings": {
                    "properties": {
                        "content": {"type": "text", "analyzer": "standard"},
                        "record_type": {"type": "keyword"},
                        "embedding": {
                            "type": "knn_vector",
                            "dimension": self._dimensions,
                            "method": {
                                "name": "hnsw",
                                "space_type": "cosinesimil",
                                "engine": "nmslib",
                                "parameters": {"ef_construction": 200, "m": 16},
                            },
                        },
                        "namespace": {"type": "keyword"},
                        "agent_id": {"type": "keyword"},
                        "user_id": {"type": "keyword"},
                        "session_id": {"type": "keyword"},
                        "status": {"type": "keyword"},
                        "importance": {"type": "float"},
                        "metadata": {"type": "object", "enabled": True},
                        "created_at": {"type": "date"},
                        "updated_at": {"type": "date"},
                        "access_count": {"type": "integer"},
                        "last_accessed_at": {"type": "date"},
                        "success_count": {"type": "integer"},
                        "failure_count": {"type": "integer"},
                        "supersedes": {"type": "keyword"},
                        "derived_from": {"type": "keyword"},
                        "created_by": {"type": "keyword"},
                        "workflow_id": {"type": "keyword"},
                        "triggered_by": {"type": "text"},
                        "accessed_by": {"type": "keyword"},
                    }
                },
            }
            self._client.indices.create(index=self._index, body=body)

        logger.info("OpenSearchBackend initialized: index=%s", self._index)

    async def add(self, records: list[MemoryRecord]) -> list[str]:
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        ids = []
        for record in records:
            metadata = self._merge_typed_fields(record)

            doc = {
                "content": record.content,
                "record_type": record.record_type.value,
                "status": record.status.value,
                "importance": record.importance,
                "embedding": record.embedding,
                "namespace": record.namespace,
                "agent_id": record.agent_id,
                "user_id": record.user_id,
                "session_id": record.session_id,
                "metadata": metadata,
                "created_at": record.created_at.isoformat(),
                "updated_at": record.updated_at.isoformat(),
                "access_count": record.access_count,
                "last_accessed_at": record.last_accessed_at.isoformat() if record.last_accessed_at else None,
                "success_count": record.success_count,
                "failure_count": record.failure_count,
                "supersedes": record.supersedes,
                "derived_from": record.derived_from,
                "created_by": record.created_by,
                "workflow_id": record.workflow_id,
                "triggered_by": record.triggered_by,
                "accessed_by": record.accessed_by,
            }
            self._client.index(index=self._index, id=record.id, body=doc, refresh="wait_for")
            ids.append(record.id)
        return ids

    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        try:
            result = self._client.get(index=self._index, id=record_id)
            return self._hit_to_record(result)
        except Exception:
            return None

    async def search_vector(
        self,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        # Default: only return active memories
        if filters is None:
            filters = {}
        filters.setdefault("status", "active")

        filter_clauses = self._build_filters(namespace, filters)

        body: dict[str, Any] = {
            "size": top_k,
            "query": {
                "knn": {
                    "embedding": {
                        "vector": embedding,
                        "k": top_k,
                    }
                }
            },
        }

        if filter_clauses:
            body["query"] = {
                "bool": {
                    "must": [body["query"]],
                    "filter": filter_clauses,
                }
            }

        result = self._client.search(index=self._index, body=body)
        return [self._hit_to_record(hit, score=hit.get("_score")) for hit in result["hits"]["hits"]]

    async def search_text(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Full-text BM25 search."""
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        filter_clauses = self._build_filters(namespace, filters)

        body: dict[str, Any] = {
            "size": top_k,
            "query": {
                "match": {"content": {"query": query}},
            },
        }

        if filter_clauses:
            body["query"] = {
                "bool": {
                    "must": [body["query"]],
                    "filter": filter_clauses,
                }
            }

        result = self._client.search(index=self._index, body=body)
        return [self._hit_to_record(hit, score=hit.get("_score")) for hit in result["hits"]["hits"]]

    async def search_hybrid(
        self,
        query: str,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Hybrid search: k-NN + BM25 combined with Reciprocal Rank Fusion.

        Runs both vector and text searches, then merges results using RRF
        scoring: score = sum(1 / (k + rank)) across both result lists.
        """
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        # Fetch more candidates from each to get good coverage for RRF
        fetch_k = top_k * 3

        vector_results = await self.search_vector(
            embedding=embedding,
            top_k=fetch_k,
            namespace=namespace,
            filters=filters,
        )

        text_results = await self.search_text(
            query=query,
            top_k=fetch_k,
            namespace=namespace,
            filters=filters,
        )

        # Reciprocal Rank Fusion (k=60 is standard)
        rrf_k = 60
        scores: dict[str, float] = {}
        record_map: dict[str, MemoryRecord] = {}

        for rank, rec in enumerate(vector_results):
            scores[rec.id] = scores.get(rec.id, 0) + 1.0 / (rrf_k + rank + 1)
            record_map[rec.id] = rec

        for rank, rec in enumerate(text_results):
            scores[rec.id] = scores.get(rec.id, 0) + 1.0 / (rrf_k + rank + 1)
            if rec.id not in record_map:
                record_map[rec.id] = rec

        # Sort by RRF score descending
        sorted_ids = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)

        results = []
        for rid in sorted_ids[:top_k]:
            rec = record_map[rid]
            rec.score = scores[rid]
            results.append(rec)

        return results

    async def update(self, record_id: str, **kwargs: Any) -> bool:
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        try:
            doc = dict(kwargs)
            doc["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._client.update(
                index=self._index,
                id=record_id,
                body={"doc": doc},
                refresh="wait_for",
            )
            return True
        except Exception:
            return False

    async def delete(self, record_id: str) -> bool:
        """Soft delete — sets status to archived."""
        if not self._client:
            raise RuntimeError("Backend not initialized.")

        try:
            self._client.update(
                index=self._index,
                id=record_id,
                body={
                    "doc": {
                        "status": "archived",
                        "updated_at": datetime.now(timezone.utc).isoformat(),
                    }
                },
                refresh="wait_for",
            )
            return True
        except Exception:
            return False

    async def record_access(self, record_ids: list[str], accessed_by: str = None) -> None:
        """Increment access_count and update last_accessed_at for retrieved records."""
        if not self._client or not record_ids:
            return
        now = datetime.now(timezone.utc).isoformat()
        if accessed_by:
            script = (
                "ctx._source.access_count = (ctx._source.access_count ?: 0) + 1; "
                "ctx._source.last_accessed_at = params.now; "
                "if (ctx._source.accessed_by == null) { ctx._source.accessed_by = []; } "
                "if (!ctx._source.accessed_by.contains(params.agent)) { ctx._source.accessed_by.add(params.agent); }"
            )
            params = {"now": now, "agent": accessed_by}
        else:
            script = "ctx._source.access_count = (ctx._source.access_count ?: 0) + 1; ctx._source.last_accessed_at = params.now"
            params = {"now": now}
        for rid in record_ids:
            try:
                self._client.update(
                    index=self._index,
                    id=rid,
                    body={
                        "script": {
                            "source": script,
                            "params": params,
                        }
                    },
                )
            except Exception:
                pass  # best-effort

    async def record_outcome(self, record_id: str, success: bool) -> bool:
        """Record a success or failure outcome for a memory."""
        if not self._client:
            raise RuntimeError("Backend not initialized.")
        field = "success_count" if success else "failure_count"
        try:
            self._client.update(
                index=self._index,
                id=record_id,
                body={
                    "script": {
                        "source": f"ctx._source.{field} = (ctx._source.{field} ?: 0) + 1",
                    }
                },
                refresh="wait_for",
            )
            return True
        except Exception:
            return False

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        """Update status for multiple records."""
        if not self._client or not record_ids:
            return 0
        now = datetime.now(timezone.utc).isoformat()
        count = 0
        for rid in record_ids:
            try:
                self._client.update(
                    index=self._index,
                    id=rid,
                    body={"doc": {"status": status, "updated_at": now}},
                    refresh="wait_for",
                )
                count += 1
            except Exception:
                pass
        return count

    async def bulk_archive(self, record_ids: list[str]) -> int:
        return await self.bulk_update_status(record_ids, "archived")

    async def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            info = self._client.info()
            return "version" in info
        except Exception:
            return False

    async def list_namespaces(self) -> list[str]:
        """List all distinct namespaces."""
        if not self._client:
            return []
        try:
            body = {
                "size": 0,
                "aggs": {"namespaces": {"terms": {"field": "namespace", "size": 1000}}},
            }
            result = self._client.search(index=self._index, body=body)
            buckets = result.get("aggregations", {}).get("namespaces", {}).get("buckets", [])
            return sorted(b["key"] for b in buckets)
        except Exception:
            return []

    async def stats(self, namespace: str | None = None) -> dict[str, Any]:
        """Return memory statistics."""
        if not self._client:
            return {}
        try:
            filter_clause = [{"prefix": {"namespace": namespace}}] if namespace else []

            body: dict[str, Any] = {
                "size": 0,
                "query": {"bool": {"filter": filter_clause}} if filter_clause else {"match_all": {}},
                "aggs": {
                    "by_type": {"terms": {"field": "record_type", "size": 10}},
                    "by_namespace": {"terms": {"field": "namespace", "size": 20}},
                    "namespaces": {"terms": {"field": "namespace", "size": 1000}},
                    "avg_success_rate": {
                        "avg": {
                            "script": {
                                "source": "def total = (doc['success_count'].value ?: 0) + (doc['failure_count'].value ?: 0); return total > 0 ? (doc['success_count'].value ?: 0) / (double) total : null"
                            }
                        }
                    },
                    "oldest": {"min": {"field": "created_at"}},
                    "newest": {"max": {"field": "created_at"}},
                    "top_accessed": {
                        "top_hits": {
                            "sort": [{"access_count": {"order": "desc"}}],
                            "size": 5,
                            "_source": False,
                        }
                    },
                },
            }

            result = self._client.search(index=self._index, body=body)
            aggs = result.get("aggregations", {})

            return {
                "total_count": result.get("hits", {}).get("total", {}).get("value", 0),
                "namespaces": sorted(b["key"] for b in aggs.get("namespaces", {}).get("buckets", [])),
                "by_record_type": {b["key"]: b["doc_count"] for b in aggs.get("by_type", {}).get("buckets", [])},
                "by_namespace": {b["key"]: b["doc_count"] for b in aggs.get("by_namespace", {}).get("buckets", [])},
                "avg_success_rate": round(aggs.get("avg_success_rate", {}).get("value", 0) or 0, 3) or None,
                "most_accessed": [h["_id"] for h in aggs.get("top_accessed", {}).get("hits", {}).get("hits", [])],
                "oldest_memory": aggs.get("oldest", {}).get("value_as_string"),
                "newest_memory": aggs.get("newest", {}).get("value_as_string"),
            }
        except Exception as e:
            logger.warning(f"Failed to get stats: {e}")
            return {}

    def _build_filters(self, namespace: Optional[str], filters: Optional[dict[str, Any]]) -> list:
        clauses = []
        if namespace:
            clauses.append({"prefix": {"namespace": namespace}})
        if filters:
            for key, value in filters.items():
                if key in ("agent_id", "user_id", "session_id", "record_type", "status"):
                    clauses.append({"term": {key: value}})
                else:
                    clauses.append({"term": {f"metadata.{key}": value}})
        return clauses

    def _merge_typed_fields(self, record: MemoryRecord) -> dict[str, Any]:
        """Merge typed record extra fields into metadata for storage."""
        from memledger.models import EpisodicRecord, ProceduralRecord, SemanticRecord

        metadata = dict(record.metadata)

        if isinstance(record, EpisodicRecord):
            typed = {}
            if record.event_time:
                typed["event_time"] = record.event_time.isoformat()
            if record.duration_ms is not None:
                typed["duration_ms"] = record.duration_ms
            if record.outcome:
                typed["outcome"] = record.outcome
            if record.actors:
                typed["actors"] = record.actors
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, ProceduralRecord):
            typed = {}
            if record.steps:
                typed["steps"] = record.steps
            if record.preconditions:
                typed["preconditions"] = record.preconditions
            if record.tools_required:
                typed["tools_required"] = record.tools_required
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, SemanticRecord):
            typed = {}
            if record.confidence is not None:
                typed["confidence"] = record.confidence
            if record.source:
                typed["source"] = record.source
            if typed:
                metadata["_typed"] = typed

        return metadata

    def _hit_to_record(self, hit: dict, score: Optional[float] = None) -> MemoryRecord:
        src = hit.get("_source", hit)
        record_type = src.get("record_type", "semantic")
        metadata = src.get("metadata", {})
        typed_data = metadata.pop("_typed", {}) if metadata else {}

        base_kwargs = dict(
            id=hit.get("_id", src.get("id", "")),
            content=src.get("content", ""),
            record_type=record_type,
            status=src.get("status", "active"),
            importance=src.get("importance", 0.5) or 0.5,
            namespace=src.get("namespace", "/"),
            agent_id=src.get("agent_id"),
            user_id=src.get("user_id"),
            session_id=src.get("session_id"),
            metadata=metadata or {},
            score=score,
            supersedes=src.get("supersedes"),
            derived_from=src.get("derived_from") or [],
            access_count=src.get("access_count", 0) or 0,
            last_accessed_at=src.get("last_accessed_at"),
            success_count=src.get("success_count", 0) or 0,
            failure_count=src.get("failure_count", 0) or 0,
            created_by=src.get("created_by"),
            workflow_id=src.get("workflow_id"),
            triggered_by=src.get("triggered_by"),
            accessed_by=src.get("accessed_by") or [],
        )

        if record_type == "episodic":
            from memledger.models import EpisodicRecord

            return EpisodicRecord(
                **base_kwargs,
                event_time=typed_data.get("event_time"),
                duration_ms=typed_data.get("duration_ms"),
                outcome=typed_data.get("outcome"),
                actors=typed_data.get("actors", []),
            )
        elif record_type == "procedural":
            from memledger.models import ProceduralRecord

            return ProceduralRecord(
                **base_kwargs,
                steps=typed_data.get("steps", []),
                preconditions=typed_data.get("preconditions", []),
                tools_required=typed_data.get("tools_required", []),
            )
        elif record_type == "semantic":
            from memledger.models import SemanticRecord

            return SemanticRecord(
                **base_kwargs,
                confidence=typed_data.get("confidence"),
                source=typed_data.get("source"),
            )
        else:
            return MemoryRecord(**base_kwargs)
