# SPDX-License-Identifier: Apache-2.0
"""Memory audit logging — structured record of all engram operations.

Every add, search, update, delete, outcome, and lifecycle change
is logged as a structured entry. The audit log is append-only and
stored in-memory with configurable max size. Can be queried for
provenance debugging and compliance.
"""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class AuditEntry:
    """Single audit log entry."""

    timestamp: datetime
    operation: str  # add, search, update, delete, outcome, status_change, promote, conflict
    record_id: Optional[str] = None
    agent_id: Optional[str] = None
    namespace: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp.isoformat(),
            "operation": self.operation,
            "record_id": self.record_id,
            "agent_id": self.agent_id,
            "namespace": self.namespace,
            **self.details,
        }

    def summary(self) -> str:
        parts = [f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}]"]
        parts.append(self.operation.upper())
        if self.record_id:
            parts.append(f"mem-{self.record_id[:8]}")
        if self.details.get("content"):
            parts.append(f'"{self.details["content"][:60]}"')
        if self.details.get("result"):
            parts.append(f"→ {self.details['result']}")
        if self.agent_id:
            parts.append(f"by {self.agent_id}")
        return " ".join(parts)


class AuditLog:
    """In-memory audit log with configurable max entries."""

    def __init__(self, max_entries: int = 1000) -> None:
        self._entries: deque[AuditEntry] = deque(maxlen=max_entries)

    def log(
        self,
        operation: str,
        record_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        namespace: Optional[str] = None,
        **details: Any,
    ) -> AuditEntry:
        entry = AuditEntry(
            timestamp=datetime.now(timezone.utc),
            operation=operation,
            record_id=record_id,
            agent_id=agent_id,
            namespace=namespace,
            details=details,
        )
        self._entries.append(entry)
        logger.debug("AUDIT: %s", entry.summary())
        return entry

    def recent(self, n: int = 10) -> list[AuditEntry]:
        """Return the N most recent entries."""
        entries = list(self._entries)
        return entries[-n:]

    def by_record(self, record_id: str) -> list[AuditEntry]:
        """Return all entries for a specific record."""
        return [e for e in self._entries if e.record_id == record_id]

    def by_operation(self, operation: str) -> list[AuditEntry]:
        """Return all entries of a specific operation type."""
        return [e for e in self._entries if e.operation == operation]

    def summary(self, n: int = 10) -> str:
        """Human-readable summary of recent entries."""
        entries = self.recent(n)
        if not entries:
            return "No audit entries."
        lines = [f"Memory audit log (last {len(entries)} operations):"]
        for i, entry in enumerate(entries, 1):
            lines.append(f"  {i}. {entry.summary()}")
        return "\n".join(lines)

    def clear(self) -> None:
        self._entries.clear()

    def __len__(self) -> int:
        return len(self._entries)
