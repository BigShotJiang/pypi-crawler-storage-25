# SPDX-License-Identifier: Apache-2.0
"""Memledger strategies — pluggable intelligence for memory decisions.

Two layers ship in this package:

  1. Deterministic intelligence (`scoring`, `audit`, `retrieval`)
     - `ScoringConfig`, `compute_policy_score`, `compute_final_score`
     - `compute_confidence`, `AuditLog`, `ContextualRecall`
     These have always shipped in engram and are used regardless of strategy choice.

  2. Pluggable strategies (`policies`, `llm`)
     - `ImportanceStrategy`, `WritePolicyStrategy`,
       `ConflictResolverStrategy`, `RerankerStrategy`
     - Deterministic reference implementations: `FixedImportance`,
       `AlwaysStore`, `HookOnly`, `PolicyRerank`
     - LLM reference implementations: `LLMImportance`, `LLMGated`,
       `LLMResolver`, `LLMRerank` (in `llm.py`)
     - Built from `MemledgerConfig.strategies` via `build_strategies()`

Defaults preserve v0.3.0 behavior. Users opt in to LLM-driven strategies one
at a time via the `strategies:` block in engram.yaml.
"""

from __future__ import annotations

from memledger.strategies.policies import (
    AlwaysStore,
    ConflictResolution,
    ConflictResolverStrategy,
    EngramStrategies,
    FixedImportance,
    HookOnly,
    ImportanceStrategy,
    PolicyRerank,
    RerankerStrategy,
    WriteDecision,
    WritePolicyStrategy,
)

__all__ = [
    "AlwaysStore",
    "ConflictResolution",
    "ConflictResolverStrategy",
    "EngramStrategies",
    "FixedImportance",
    "HookOnly",
    "ImportanceStrategy",
    "PolicyRerank",
    "RerankerStrategy",
    "WriteDecision",
    "WritePolicyStrategy",
    "build_strategies",
    "register_strategy",
]


# ── Strategy registry ──────────────────────────────────────────────


# A two-level registry: kind ("importance" / "write_policy" / etc) → provider
# name → class. Built-in providers are registered at import time. Users can
# register their own with `register_strategy()`.
_STRATEGY_REGISTRY: dict[str, dict[str, type]] = {
    "importance": {},
    "write_policy": {},
    "conflict_resolver": {},
    "reranker": {},
}


def register_strategy(kind: str, name: str, cls: type) -> None:
    """Register a third-party strategy implementation.

    Example:
        from memledger.strategies import register_strategy, ImportanceStrategy

        class MyImportance(ImportanceStrategy):
            async def score(self, record): return 0.7

        register_strategy("importance", "my_custom", MyImportance)

    After registration, users can pick "my_custom" as the provider in their
    YAML config without forking engram.
    """
    if kind not in _STRATEGY_REGISTRY:
        raise ValueError(f"Unknown strategy kind '{kind}'. Valid kinds: {list(_STRATEGY_REGISTRY)}")
    _STRATEGY_REGISTRY[kind][name] = cls


def _register_builtins() -> None:
    """Register the deterministic and LLM-driven reference implementations."""
    if _STRATEGY_REGISTRY["importance"]:
        return  # already registered

    # Deterministic defaults
    register_strategy("importance", "fixed", FixedImportance)
    register_strategy("write_policy", "always", AlwaysStore)
    register_strategy("conflict_resolver", "hook_only", HookOnly)
    # PolicyRerank is special — registered here, but it's instantiated in
    # build_strategies() with a bound reference to engram._rerank.
    register_strategy("reranker", "policy", PolicyRerank)

    # LLM strategies — imported lazily so users without LLM extras don't pay
    # the import cost. We try to register them but don't fail if the LLM
    # module isn't importable (e.g. LiteLLM not installed).
    try:
        from memledger.strategies import llm  # noqa: F401

        register_strategy("importance", "llm", llm.LLMImportance)
        register_strategy("write_policy", "llm", llm.LLMGated)
        register_strategy("conflict_resolver", "llm", llm.LLMResolver)
        register_strategy("reranker", "llm", llm.LLMRerank)
    except ImportError:
        pass  # LLM strategies are optional


def build_strategies(
    config: dict | None,
    rerank_fn,
) -> MemledgerStrategies:
    """Build the EngramStrategies bundle from a config dict.

    Args:
        config: The `strategies:` block from memledger.yaml, or None for defaults.
            Each strategy kind ("importance", "write_policy", etc.) maps to a
            dict with `provider` (the registered name) and optional `config`.
        rerank_fn: A bound reference to `Memledger._rerank` so the deterministic
            PolicyRerank strategy can call it without circular imports.

    Returns:
        An EngramStrategies bundle with all four strategies populated.

    A None or empty config produces LLM-first defaults when a `model` key is
    present in the config (or LLM strategies are registered and available).
    Without LLM strategies available, falls back to deterministic defaults
    that match v0.3.0 behavior exactly.
    """
    _register_builtins()

    config = config or {}

    # Auto-detect: if config has a top-level `model` key, or any sub-strategy
    # specifies `provider: llm`, prefer LLM defaults. Also check if LLM
    # strategies are actually registered (i.e. litellm is installed).
    _llm_available = "llm" in _STRATEGY_REGISTRY.get("importance", {})
    _has_model_key = bool(config.get("model"))

    # LLM-first: use LLM defaults when LLM strategies are available AND
    # a model key is configured. Without an explicit model, fall back to
    # deterministic (safe default — LLM strategies can't instantiate without a model).
    _use_llm = _llm_available and _has_model_key

    # Deterministic fallback providers
    _DETERMINISTIC = {
        "importance": "fixed",
        "write_policy": "always",
        "conflict_resolver": "hook_only",
        "reranker": "policy",
    }

    # LLM-first providers
    _LLM_FIRST = {
        "importance": "llm",
        "write_policy": "llm",
        "conflict_resolver": "llm",
        "reranker": "llm",
    }

    defaults = _LLM_FIRST if _use_llm else _DETERMINISTIC

    def _build(kind: str, default_provider: str, **default_kwargs):
        spec = config.get(kind) or {}
        provider = spec.get("provider", default_provider)
        cfg = spec.get("config", {}) or {}

        # Inherit top-level model into per-strategy config if not overridden
        if provider == "llm" and "model" not in cfg and config.get("model"):
            cfg["model"] = config["model"]

        if provider not in _STRATEGY_REGISTRY[kind]:
            available = list(_STRATEGY_REGISTRY[kind])
            raise ValueError(
                f"Unknown {kind} strategy provider '{provider}'. "
                f"Available: {available}. "
                f"For LLM strategies, install: pip install engram[bedrock] (or [openai], [anthropic])"
            )

        cls = _STRATEGY_REGISTRY[kind][provider]

        # PolicyRerank is special — it needs the rerank_fn injected
        if kind == "reranker" and provider == "policy":
            return cls(rerank_fn=rerank_fn)

        return cls(**{**default_kwargs, **cfg})

    return EngramStrategies(
        importance=_build("importance", defaults["importance"]),
        write_policy=_build("write_policy", defaults["write_policy"]),
        conflict_resolver=_build("conflict_resolver", defaults["conflict_resolver"]),
        reranker=_build("reranker", defaults["reranker"]),
    )
