# SPDX-License-Identifier: Apache-2.0
"""Phoenix evaluation logging — best-effort, deployment-agnostic.

memledger talks to Phoenix over (a) OTLP for traces (handled by
`telemetry/otel.py`) and (b) `arize-phoenix-client` for span
annotations (this module). Both are wire-level integrations — memledger
does not care whether Phoenix runs in-process (`phoenix.launch_app()`),
in a Docker container, in a Kubernetes Helm chart, or as Arize Cloud.

Env vars:
    PHOENIX_BASE_URL    Phoenix HTTP base URL (e.g. http://localhost:6006).
                        Falls back to PHOENIX_COLLECTOR_ENDPOINT then to
                        OTEL_EXPORTER_OTLP_ENDPOINT.
    PHOENIX_API_KEY     Optional auth header for hosted / authenticated
                        Phoenix.

This module is a no-op if (a) arize-phoenix-client is not installed
(install via `pip install memledger[eval]`) or (b) no base URL is
configured. It never raises — eval logging is best-effort observability,
not a correctness requirement.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _get_base_url() -> Optional[str]:
    return (
        os.environ.get("PHOENIX_BASE_URL")
        or os.environ.get("PHOENIX_COLLECTOR_ENDPOINT")
        or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    )


_client: Optional[Any] = None
_client_attempted: bool = False


def _get_client() -> Optional[Any]:
    """Return a cached Phoenix client, or None if it can't be built.

    Caches both the client and the failure decision — failures stay silent
    after the first attempt to avoid log spam on hot paths.
    """
    global _client, _client_attempted
    if _client_attempted:
        return _client
    _client_attempted = True

    base_url = _get_base_url()
    if not base_url:
        return None

    try:
        from phoenix.client import Client
    except ImportError:
        logger.debug(
            "Phoenix eval logging requested but arize-phoenix-client is not installed; "
            "install via `pip install memledger[eval]`. Continuing without Phoenix logging."
        )
        return None

    api_key = os.environ.get("PHOENIX_API_KEY")
    try:
        _client = Client(base_url=base_url, api_key=api_key) if api_key else Client(base_url=base_url)
    except Exception as e:
        logger.debug("Phoenix client init failed (%s); continuing without Phoenix logging.", e)
        return None
    return _client


def _current_otel_span_id_hex() -> Optional[str]:
    """Best-effort lookup of the current OTEL span's id as 16-hex string."""
    try:
        from opentelemetry import trace
        span = trace.get_current_span()
        if span is None:
            return None
        ctx = span.get_span_context()
        if not ctx.is_valid:
            return None
        return f"{ctx.span_id:016x}"
    except Exception:
        return None


def log_evaluation(
    name: str,
    score: float,
    *,
    label: Optional[str] = None,
    explanation: Optional[str] = None,
    span_id: Optional[str] = None,
    annotator_kind: str = "CODE",
    metadata: Optional[dict[str, Any]] = None,
) -> bool:
    """Push a single evaluation result to Phoenix as a span annotation.

    Args:
        name: Annotation name (e.g. "memory_attribution_integrity").
        score: Numeric score, conventionally 0.0–1.0.
        label: Optional categorical label (e.g. "passed" / "failed").
        explanation: Optional free-text explanation.
        span_id: 16-hex OTEL span id to annotate. If None, uses the
            current active OTEL span; if there is no active span, the
            call is a no-op.
        annotator_kind: "CODE" for deterministic scorers, "LLM" for
            LLM-as-judge results, "HUMAN" for manual labels.
        metadata: Optional dict of extra context to attach.

    Returns:
        True if the annotation was sent (or sync ack'd), False if the
        call no-op'd for any reason. Never raises.
    """
    client = _get_client()
    if client is None:
        return False

    target = span_id or _current_otel_span_id_hex()
    if target is None:
        logger.debug("Phoenix log_evaluation(%s): no span_id and no active OTEL span; skipping.", name)
        return False

    try:
        client.spans.add_span_annotation(
            span_id=target,
            annotation_name=name,
            annotator_kind=annotator_kind,
            score=score,
            label=label,
            explanation=explanation,
            metadata=metadata,
        )
        logger.info(
            "Phoenix annotation pushed: name=%s score=%.3f span=%s label=%s kind=%s",
            name, score, target[:12], label, annotator_kind,
        )
        return True
    except Exception as e:
        # Bumped from debug → warning so this is visible in default logs. Phoenix
        # annotation pushes are common pain points (wrong base_url, span not yet
        # ingested, auth issues) and silent failure makes them undiagnosable.
        logger.warning(
            "Phoenix annotation push failed: name=%s span=%s err=%s "
            "(check PHOENIX_BASE_URL points at Phoenix HTTP port — :6006 — not the OTLP gRPC port :4317)",
            name, target[:12], e,
        )
        return False
