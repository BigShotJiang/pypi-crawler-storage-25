# SPDX-License-Identifier: Apache-2.0
"""OpenTelemetry instrumentation for engram memory operations.

Emits spans for all key operations: add, search, record_outcome, get,
get_lineage, promote, conflict_detected. Each span includes relevant
attributes (record_type, namespace, agent_id, etc.).

Usage:
    # Auto-instruments when OTEL is configured in the environment
    # No code changes needed in engram.py -- uses a decorator pattern

    # Or explicitly:
    from memledger.telemetry import instrument_engram
    engram = await Engram.create(...)
    instrument_engram(engram)

Requires: pip install memledger
    opentelemetry-api
    opentelemetry-sdk
"""

from __future__ import annotations

import functools
import logging
import time
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Graceful import -- everything is a no-op when opentelemetry is absent
# ---------------------------------------------------------------------------

_HAS_OTEL = False
_tracer = None

try:
    from opentelemetry import trace

    _HAS_OTEL = True
except ImportError:
    trace = None  # type: ignore[assignment]

_TRACER_NAME = "engram"


def _get_tracer() -> Any:
    """Return a real tracer if OTEL is available, else None."""
    global _tracer
    if not _HAS_OTEL:
        return None
    if _tracer is None:
        _tracer = trace.get_tracer(_TRACER_NAME)
    return _tracer


# ---------------------------------------------------------------------------
# Internal metrics counters (independent of OTEL spans)
# ---------------------------------------------------------------------------

class _MetricsStore:
    """Simple in-process counters for engram operations."""

    def __init__(self) -> None:
        self.total_adds: int = 0
        self.total_searches: int = 0
        self.searches_with_results: int = 0
        self.total_search_latency_ms: float = 0.0
        self.total_outcomes: int = 0
        self.outcome_successes: int = 0
        self.total_promotions: int = 0
        self.total_conflicts: int = 0

    def snapshot(self) -> dict[str, Any]:
        """Return a metrics dict."""
        search_hit_rate = (
            self.searches_with_results / self.total_searches
            if self.total_searches > 0
            else 0.0
        )
        avg_latency = (
            self.total_search_latency_ms / self.total_searches
            if self.total_searches > 0
            else 0.0
        )
        outcome_success_rate = (
            self.outcome_successes / self.total_outcomes
            if self.total_outcomes > 0
            else 0.0
        )
        return {
            "total_adds": self.total_adds,
            "total_searches": self.total_searches,
            "search_hit_rate": round(search_hit_rate, 4),
            "avg_search_latency_ms": round(avg_latency, 2),
            "total_outcomes": self.total_outcomes,
            "outcome_success_rate": round(outcome_success_rate, 4),
            "total_promotions": self.total_promotions,
            "total_conflicts": self.total_conflicts,
        }


# Module-level metrics store -- shared across all instrumented instances
_metrics = _MetricsStore()


def metrics() -> dict[str, Any]:
    """Return current engram telemetry metrics.

    Returns a dict with:
        total_searches, search_hit_rate, avg_search_latency_ms,
        total_outcomes, outcome_success_rate, total_promotions,
        total_conflicts, total_adds
    """
    return _metrics.snapshot()


def reset_metrics() -> None:
    """Reset all counters to zero. Useful for tests."""
    global _metrics
    _metrics = _MetricsStore()


# ---------------------------------------------------------------------------
# Span helpers
# ---------------------------------------------------------------------------

def _set_span_attrs(span: Any, attrs: dict[str, Any]) -> None:
    """Set attributes on a span, skipping None values."""
    if span is None:
        return
    for key, value in attrs.items():
        if value is None:
            continue
        # OTEL attributes must be str, bool, int, float, or sequences thereof
        if isinstance(value, (str, bool, int, float)):
            span.set_attribute(key, value)
        else:
            span.set_attribute(key, str(value))


def _start_span(name: str) -> Any:
    """Start a span if OTEL is available. Returns (span, context_manager) or (None, None)."""
    tracer = _get_tracer()
    if tracer is None:
        return None, None
    span = tracer.start_span(name)
    return span, trace.use_span(span, end_on_exit=True)


# ---------------------------------------------------------------------------
# Instrumented method wrappers
# ---------------------------------------------------------------------------

def _wrap_add(original_add: Callable) -> Callable:
    """Wrap Engram.add with telemetry."""

    @functools.wraps(original_add)
    async def instrumented_add(
        content: str,
        *,
        record_type: Any = None,
        namespace: str = "/",
        agent_id: Optional[str] = None,
        importance: float = 0.5,
        supersedes: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        tracer = _get_tracer()
        if tracer is not None:
            with tracer.start_as_current_span("engram.add") as span:
                _set_span_attrs(span, {
                    "engram.record_type": record_type.value if record_type is not None else "semantic",
                    "engram.namespace": namespace,
                    "engram.agent_id": agent_id,
                    "engram.importance": importance,
                    "engram.has_supersedes": supersedes is not None,
                })
                result = await original_add(
                    content,
                    record_type=record_type,
                    namespace=namespace,
                    agent_id=agent_id,
                    importance=importance,
                    supersedes=supersedes,
                    **kwargs,
                )
                _set_span_attrs(span, {"engram.record_id": result})
                _metrics.total_adds += 1
                return result
        else:
            result = await original_add(
                content,
                record_type=record_type,
                namespace=namespace,
                agent_id=agent_id,
                importance=importance,
                supersedes=supersedes,
                **kwargs,
            )
            _metrics.total_adds += 1
            return result

    return instrumented_add


def _wrap_search(original_search: Callable) -> Callable:
    """Wrap Engram.search with telemetry."""

    @functools.wraps(original_search)
    async def instrumented_search(
        query: str,
        *,
        namespace: Optional[str] = None,
        top_k: int = 5,
        **kwargs: Any,
    ) -> Any:
        start = time.monotonic()
        tracer = _get_tracer()

        if tracer is not None:
            with tracer.start_as_current_span("engram.search") as span:
                _set_span_attrs(span, {
                    "engram.query": query[:100],
                    "engram.namespace": namespace,
                    "engram.top_k": top_k,
                })
                result = await original_search(
                    query, namespace=namespace, top_k=top_k, **kwargs
                )
                elapsed = (time.monotonic() - start) * 1000
                result_count = len(result.records) if hasattr(result, "records") else 0
                _set_span_attrs(span, {
                    "engram.result_count": result_count,
                    "engram.search_time_ms": round(elapsed, 2),
                })
                _metrics.total_searches += 1
                _metrics.total_search_latency_ms += elapsed
                if result_count > 0:
                    _metrics.searches_with_results += 1
                return result
        else:
            result = await original_search(
                query, namespace=namespace, top_k=top_k, **kwargs
            )
            elapsed = (time.monotonic() - start) * 1000
            result_count = len(result.records) if hasattr(result, "records") else 0
            _metrics.total_searches += 1
            _metrics.total_search_latency_ms += elapsed
            if result_count > 0:
                _metrics.searches_with_results += 1
            return result

    return instrumented_search


def _wrap_record_outcome(original_record_outcome: Callable) -> Callable:
    """Wrap Engram.record_outcome with telemetry."""

    @functools.wraps(original_record_outcome)
    async def instrumented_record_outcome(
        record_id: Optional[str] = None,
        success: bool = True,
        **kwargs: Any,
    ) -> bool:
        tracer = _get_tracer()

        if tracer is not None:
            with tracer.start_as_current_span("engram.record_outcome") as span:
                _set_span_attrs(span, {
                    "memledger.memory_id": record_id,
                    "engram.success": success,
                })
                result = await original_record_outcome(
                    record_id, success, **kwargs
                )
                _metrics.total_outcomes += 1
                if success:
                    _metrics.outcome_successes += 1
                return result
        else:
            result = await original_record_outcome(
                record_id, success, **kwargs
            )
            _metrics.total_outcomes += 1
            if success:
                _metrics.outcome_successes += 1
            return result

    return instrumented_record_outcome


def _wrap_get(original_get: Callable) -> Callable:
    """Wrap Engram.get with telemetry."""

    @functools.wraps(original_get)
    async def instrumented_get(
        record_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        tracer = _get_tracer()

        if tracer is not None:
            with tracer.start_as_current_span("engram.get") as span:
                _set_span_attrs(span, {"memledger.memory_id": record_id})
                result = await original_get(record_id, **kwargs)
                _set_span_attrs(span, {"engram.found": result is not None})
                return result
        else:
            return await original_get(record_id, **kwargs)

    return instrumented_get


def _wrap_get_lineage(original_get_lineage: Callable) -> Callable:
    """Wrap Engram.get_lineage with telemetry."""

    @functools.wraps(original_get_lineage)
    async def instrumented_get_lineage(
        record_id: str,
        *,
        depth: int = 5,
        **kwargs: Any,
    ) -> dict[str, Any]:
        tracer = _get_tracer()

        if tracer is not None:
            with tracer.start_as_current_span("engram.get_lineage") as span:
                _set_span_attrs(span, {
                    "memledger.memory_id": record_id,
                    "engram.chain_depth": depth,
                })
                result = await original_get_lineage(
                    record_id, depth=depth, **kwargs
                )
                return result
        else:
            return await original_get_lineage(
                record_id, depth=depth, **kwargs
            )

    return instrumented_get_lineage


def _wrap_check_auto_promote(original: Callable) -> Callable:
    """Wrap Engram._check_auto_promote to emit engram.promote spans."""

    @functools.wraps(original)
    async def instrumented(record_id: str, threshold: int = 3) -> Optional[str]:
        result = await original(record_id, threshold=threshold)
        if result is not None:
            # A promotion happened -- emit a span and count it
            tracer = _get_tracer()
            if tracer is not None:
                with tracer.start_as_current_span("engram.promote") as span:
                    _set_span_attrs(span, {
                        "engram.original_id": record_id,
                        "engram.promoted_id": result,
                        "engram.threshold": threshold,
                    })
            _metrics.total_promotions += 1
        return result

    return instrumented


# ---------------------------------------------------------------------------
# Conflict detection hook
# ---------------------------------------------------------------------------

def _make_conflict_hook(instance: Any) -> Callable:
    """Create a lifecycle hook that emits engram.conflict_detected spans."""

    async def on_conflict(new_record: Any, existing_record: Any) -> None:
        tracer = _get_tracer()
        if tracer is not None:
            with tracer.start_as_current_span("engram.conflict_detected") as span:
                similarity = existing_record.score if hasattr(existing_record, "score") else None
                _set_span_attrs(span, {
                    "engram.new_id": new_record.id,
                    "engram.existing_id": existing_record.id,
                    "engram.similarity": similarity,
                    "engram.namespace": new_record.namespace,
                })
        _metrics.total_conflicts += 1

    return on_conflict


# ---------------------------------------------------------------------------
# Public API: instrument_engram()
# ---------------------------------------------------------------------------

def instrument_engram(instance: Any) -> Any:
    """Monkey-patch an Engram instance with telemetry wrappers.

    This instruments the instance methods (not the class) so it is safe
    to call on individual instances without affecting others.

    Args:
        instance: An Engram instance (from await Engram.create(...)).

    Returns:
        The same instance, for chaining.

    Example:
        from memledger.telemetry import instrument_engram
        engram = await Engram.create(...)
        instrument_engram(engram)
        # All subsequent calls emit OTEL spans + update metrics
    """
    # Bind wrapped functions directly to the instance
    _original_add = instance.__class__.add
    _original_search = instance.__class__.search
    _original_record_outcome = instance.__class__.record_outcome
    _original_get = instance.__class__.get
    _original_get_lineage = instance.__class__.get_lineage
    _original_promote = instance.__class__._check_auto_promote

    # Create wrapped versions that bind self to the class methods
    wrapped_add = _wrap_add(lambda *a, **kw: _original_add(instance, *a, **kw))
    wrapped_search = _wrap_search(lambda *a, **kw: _original_search(instance, *a, **kw))
    wrapped_record_outcome = _wrap_record_outcome(
        lambda *a, **kw: _original_record_outcome(instance, *a, **kw)
    )
    wrapped_get = _wrap_get(lambda *a, **kw: _original_get(instance, *a, **kw))
    wrapped_get_lineage = _wrap_get_lineage(
        lambda *a, **kw: _original_get_lineage(instance, *a, **kw)
    )
    wrapped_promote = _wrap_check_auto_promote(
        lambda *a, **kw: _original_promote(instance, *a, **kw)
    )

    instance.add = wrapped_add
    instance.search = wrapped_search
    instance.record_outcome = wrapped_record_outcome
    instance.get = wrapped_get
    instance.get_lineage = wrapped_get_lineage
    instance._check_auto_promote = wrapped_promote

    # Add a metrics() convenience method on the instance
    instance.metrics = metrics

    # Register conflict detection hook
    conflict_hook = _make_conflict_hook(instance)
    instance.hooks.on_conflict.append(conflict_hook)

    logger.info(
        "Engram telemetry instrumented (otel=%s)", "enabled" if _HAS_OTEL else "disabled"
    )

    return instance


# ---------------------------------------------------------------------------
# Convenience: setup_engram_telemetry()
# ---------------------------------------------------------------------------

def setup_engram_telemetry(
    service_name: str = "engram",
    exporter: str = "console",
) -> bool:
    """Configure a basic OpenTelemetry pipeline for engram.

    Args:
        service_name: OTEL service name (default "engram").
        exporter: One of:
            - "console": prints spans to stdout (development)
            - "otlp": sends to OTEL_EXPORTER_OTLP_ENDPOINT (default localhost:4317)
            - "none": disables OTEL tracing entirely

    Returns:
        True if OTEL was configured, False if opentelemetry is not installed
        or exporter is "none".

    Example:
        from memledger.telemetry import setup_engram_telemetry, instrument_engram

        setup_engram_telemetry(exporter="console")  # dev mode
        engram = await Engram.create(...)
        instrument_engram(engram)
    """
    if exporter == "none":
        return False

    if not _HAS_OTEL:
        logger.warning(
            "opentelemetry not installed. Install with: pip install memledger"
        )
        return False

    try:
        from opentelemetry import trace as _trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        logger.warning("opentelemetry-sdk not installed. pip install memledger")
        return False

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    if exporter == "console":
        try:
            from opentelemetry.sdk.trace.export import (
                BatchSpanProcessor,
                ConsoleSpanExporter,
            )

            provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
        except ImportError:
            logger.warning("ConsoleSpanExporter not available")
            return False

    elif exporter == "otlp":
        try:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                OTLPSpanExporter,
            )
            from opentelemetry.sdk.trace.export import BatchSpanProcessor
            import os

            endpoint = os.environ.get(
                "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"
            )
            otlp_exporter = OTLPSpanExporter(endpoint=endpoint)
            provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
        except ImportError:
            logger.warning(
                "OTLP exporter not installed. "
                "pip install opentelemetry-exporter-otlp-proto-grpc"
            )
            return False
    else:
        logger.warning("Unknown exporter '%s'. Use 'console', 'otlp', or 'none'.", exporter)
        return False

    _trace.set_tracer_provider(provider)

    # Reset the cached tracer so it picks up the new provider
    global _tracer
    _tracer = None

    logger.info(
        "Engram telemetry configured: service=%s exporter=%s",
        service_name,
        exporter,
    )
    return True
