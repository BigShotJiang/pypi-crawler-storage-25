# SPDX-License-Identifier: Apache-2.0
"""Embedding provider.

Two execution paths:
- `provider: local` → fastembed (ONNX, offline, OSS quickstart default).
- Anything else → routed through LiteLLM (Bedrock, OpenAI, Anthropic, …).

INVARIANT (enforced by tests/test_no_direct_llm_calls.py): any embedding
or LLM call originating in core memledger code MUST go through this
module or through `strategies/llm.py` — both of which dispatch to
LiteLLM. Direct provider-SDK use (openai / anthropic / langchain_aws /
AWS LLM service clients) is forbidden in `src/memledger/` outside the
AWS storage backends (dynamodb, opensearch SigV4 auth — those are
legitimate boto3 callers).
"""

from __future__ import annotations

import logging
from typing import Any

from memledger.models import EmbeddingConfig

logger = logging.getLogger(__name__)


class EmbeddingProvider:
    """Generates vector embeddings.

    For `provider == "local"`, uses fastembed (requires `pip install memledger[local]`).
    For all other providers, routes through LiteLLM.
    """

    # litellm requires provider prefix for non-OpenAI models
    _PROVIDER_PREFIXES = {
        "bedrock": "bedrock/",
        "anthropic": "anthropic/",
    }

    # Cache fastembed model instances across provider instances (model load is expensive)
    _local_model_cache: dict[str, Any] = {}

    def __init__(self, config: EmbeddingConfig) -> None:
        self._config = config
        self._dimensions = config.dimensions
        self._provider = config.provider
        self._is_local = config.provider == "local"

        if self._is_local:
            self._model_name = config.model
            self._model = None  # Lazy-loaded on first embed
        else:
            # Prepend litellm provider prefix if the model doesn't already have one
            model = config.model
            prefix = self._PROVIDER_PREFIXES.get(config.provider, "")
            if prefix and not model.startswith(prefix):
                model = f"{prefix}{model}"
            self._model = model

    def _ensure_local_model(self):
        """Lazy-load the fastembed model (first call may download ~130 MB)."""
        if self._model is not None:
            return self._model
        cached = self._local_model_cache.get(self._model_name)
        if cached is not None:
            self._model = cached
            return cached
        try:
            from fastembed import TextEmbedding
        except ImportError as e:
            raise ImportError(
                "Local embedding provider requires fastembed. "
                "Install with: pip install memledger[local]"
            ) from e
        logger.info("Loading local embedding model: %s", self._model_name)
        model = TextEmbedding(model_name=self._model_name)
        self._local_model_cache[self._model_name] = model
        self._model = model
        return model

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts. Returns list of embedding vectors."""
        if self._is_local:
            model = self._ensure_local_model()
            # fastembed is synchronous; run on the default loop executor to avoid blocking
            import asyncio
            loop = asyncio.get_event_loop()
            vectors = await loop.run_in_executor(None, lambda: [v.tolist() for v in model.embed(texts)])
            return vectors

        import litellm
        response = await litellm.aembedding(
            model=self._model,
            input=texts,
            dimensions=self._dimensions,
        )
        embeddings = [item["embedding"] for item in response.data]
        return embeddings

    async def embed_single(self, text: str) -> list[float]:
        """Embed a single text. Convenience wrapper."""
        results = await self.embed([text])
        return results[0]

    @property
    def dimensions(self) -> int:
        return self._dimensions
