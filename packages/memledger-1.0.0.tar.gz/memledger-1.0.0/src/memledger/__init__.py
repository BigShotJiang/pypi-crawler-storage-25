# SPDX-License-Identifier: Apache-2.0
"""Memledger — Memory governance and trust layer for AI agents.

Quick start:
    from memledger import Memledger

    async with await Memledger.create(
        connection_string="postgresql://user:pass@localhost:5432/kagent"
    ) as ml:
        await ml.add("User prefers Python", namespace="/users/u1/prefs")
        results = await ml.search("language preference")
"""

from memledger.backends.base import BackendProvider
from memledger.memledger import Memledger, register_backend
from memledger.models import (
    MemledgerConfig,
    EpisodicRecord,
    MemoryRecord,
    MemoryStats,
    MemoryStatus,
    ProceduralRecord,
    RecordType,
    SearchResult,
    SemanticRecord,
    record_from_dict,
)
from memledger.strategies.audit import AuditLog
from memledger.strategies.retrieval import ContextualRecall
from memledger.strategies.scoring import (
    ScoringConfig,
    compute_confidence,
    compute_final_score,
    compute_policy_score,
)
from memledger.policies.confidence_policy import ConfidencePolicy
from memledger.provenance.models import AttributionRecord, AttributionChain, ChainHop
from memledger.telemetry import instrument_engram, setup_engram_telemetry

# Derive __version__ from installed-package metadata so it never drifts
# from pyproject.toml. Falls back to "0.0.0+unknown" if metadata isn't
# available (e.g. running from an unbuilt source tree without `pip install -e .`).
try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError
    try:
        __version__ = _pkg_version("memledger")
    except PackageNotFoundError:
        __version__ = "0.0.0+unknown"
except ImportError:  # pragma: no cover — Python <3.8 only, not supported
    __version__ = "0.0.0+unknown"
__all__ = [
    "AttributionChain",
    "AttributionRecord",
    "AuditLog",
    "BackendProvider",
    "ChainHop",
    "ConfidencePolicy",
    "ContextualRecall",
    "Memledger",
    "MemledgerConfig",
    "EpisodicRecord",
    "MemoryRecord",
    "MemoryStats",
    "MemoryStatus",
    "ProceduralRecord",
    "RecordType",
    "ScoringConfig",
    "SearchResult",
    "SemanticRecord",
    "compute_confidence",
    "compute_final_score",
    "compute_policy_score",
    "instrument_engram",
    "record_from_dict",
    "register_backend",
    "setup_engram_telemetry",
]
