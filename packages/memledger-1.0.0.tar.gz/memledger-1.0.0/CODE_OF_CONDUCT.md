# Code of Conduct

This project adopts the [Contributor Covenant, version 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/) verbatim.

Reports may be sent to **conduct@memledger-ai.dev**. <!-- TODO: confirm contact address before v1.0.0 -->

Maintainers are obligated to follow the enforcement guidelines in the linked document.
