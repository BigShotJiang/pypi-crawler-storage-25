# SPDX-License-Identifier: Apache-2.0
"""Memledger evaluation suite.

Three tiers, ordered by install footprint:

  Tier 1 — Deterministic Memory Attribution Integrity (MAI)
      `from evaluators import evaluate_attribution_integrity`
      Returns an AttributionIntegrityResult.
      Pure stdlib. No deps beyond memledger core. Always available.

  Tier 2 — RAGAS LLM-as-judge (OSS, provider-agnostic via LiteLLM)
      `from evaluators import evaluate_mai_ragas`
      Requires `pip install memledger[eval]`.
      Set $MEMLEDGER_JUDGE_MODEL (e.g. `openai/gpt-4o-mini`,
      `bedrock/anthropic.claude-...`, `anthropic/claude-...`,
      `ollama/llama3.1`).

  Tier 3 — AWS Bedrock AgentCore evaluator
      `from evaluators import register_agentcore_evaluator`
      Requires `pip install memledger[aws]`. AWS credentials needed.

The RAGAS and AgentCore entry points are lazy-imported so a clean
`pip install memledger` (no extras) can still load this module
and run the deterministic tier.
"""

from __future__ import annotations

from evaluators.attribution_integrity import (
    AttributionIntegrityResult,
    evaluate_attribution_integrity,
)


def evaluate_mai_ragas(*args, **kwargs):
    """Tier 2 — RAGAS LLM-as-judge. Lazy-imports the [eval] deps."""
    from evaluators.attribution_integrity_ragas import evaluate_mai_ragas as _impl
    return _impl(*args, **kwargs)


def register_agentcore_evaluator(*args, **kwargs):
    """Tier 3 — AWS Bedrock AgentCore evaluator. Lazy-imports boto3."""
    from evaluators.agentcore_evaluator import (
        register_agentcore_evaluator as _impl,
    )
    return _impl(*args, **kwargs)


__all__ = [
    "AttributionIntegrityResult",
    "evaluate_attribution_integrity",
    "evaluate_mai_ragas",
    "register_agentcore_evaluator",
]
