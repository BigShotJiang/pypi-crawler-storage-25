# SPDX-License-Identifier: Apache-2.0
"""AWS Bedrock AgentCore evaluator registration (AWS-only).

Requires the [aws] extra: `pip install memledger[aws]`.

This module is import-safe even without boto3 — the boto3 import is
deferred to call time so a clean OSS install can still load
`evaluators.__init__` and use the deterministic and RAGAS tiers.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


def register_agentcore_evaluator(
    region: Optional[str] = None,
    model_id: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
) -> dict:
    """Register the Memory Attribution Integrity evaluator with AgentCore.

    Region resolution: explicit arg > $AWS_REGION > "us-west-2".
    Returns the evaluator ARN and registration status.
    """
    try:
        import boto3

        region = region or os.getenv("AWS_REGION", "us-west-2")
        client = boto3.client("bedrock-agentcore-control", region_name=region)

        evaluator_config = {
            "evaluatorName": "memory_attribution_integrity",
            "description": "Scores whether agent decisions rely on well-attributed, confident memory",
            "level": "TRACE",
            "evaluatorConfig": {
                "llmAsAJudge": {
                    "modelConfig": {
                        "bedrockEvaluatorModelConfig": {
                            "modelId": model_id,
                            "inferenceConfig": {"maxTokens": 500, "temperature": 0.0},
                        }
                    },
                    "ratingScale": {
                        "numerical": [
                            {"value": 0.0, "label": "Unattributed", "definition": "Decision relies on memory with no provenance, or on memory with confidence < 0.4 treated as authoritative"},
                            {"value": 0.5, "label": "Partially attributed", "definition": "Some memories have attribution; low-confidence memories used but decision hedges"},
                            {"value": 1.0, "label": "Well attributed", "definition": "All retrieved memories have attribution, confidence >= 0.7, OR agent explicitly hedges on lower-confidence data"},
                        ]
                    },
                    "instructions": (
                        "Given an agent decision and the memories it retrieved, score whether the decision relied on "
                        "well-attributed, sufficiently confident memory. Score based on: (1) presence of attribution "
                        "metadata on every retrieved memory, (2) confidence thresholds, (3) consistency of derivation "
                        "chains, (4) whether contradictory memories were flagged or ignored. "
                        "Context: {context}. Target to evaluate: {assistant_turn}."
                    ),
                }
            },
        }

        try:
            response = client.create_evaluator(**evaluator_config)
            arn = response.get("evaluatorArn", "")
        except client.exceptions.ConflictException:
            response = client.get_evaluator(evaluatorName="memory_attribution_integrity")
            arn = response.get("evaluatorArn", "")

        return {"arn": arn, "status": "registered"}

    except ImportError:
        return {"error": "boto3/bedrock-agentcore SDK not installed (install with: pip install memledger[aws])", "status": "skipped"}
    except Exception as e:
        return {"error": str(e), "status": "failed"}
