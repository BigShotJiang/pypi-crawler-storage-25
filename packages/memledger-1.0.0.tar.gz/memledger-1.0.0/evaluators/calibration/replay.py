# SPDX-License-Identifier: Apache-2.0
"""Golden-dataset replay harness (B5).

Runs the deterministic MAI scorer and (optionally) the RAGAS LLM-as-judge
against the labeled calibration dataset, then reports the metrics that
matter for users of the memory quality gate:

  - Accuracy (% of cases where predicted label == ground truth)
  - Agreement rate (% where deterministic and LLM judge agree on label)
  - Confusion matrix (3x3 over {well_attributed, partially_attributed,
    unattributed})
  - Mean absolute error (MAE) on a 0-1 reference score per ground-truth
    class

Cohen's kappa is intentionally NOT reported here — it isn't used by
RAGAS / Phoenix / OpenAI Evals / LangSmith / DeepEval / TruLens. The
existing compute_cohens_kappa() utility in score_agreement.py is
preserved for use in the future research-paper deliverable
(see memory: project-cohens-kappa-for-paper).

Usage:
    # Deterministic tier only — runs anywhere, no LLM key needed:
    python evaluators/calibration/replay.py

    # Both tiers — set MEMLEDGER_JUDGE_MODEL and provider creds:
    export MEMLEDGER_JUDGE_MODEL=openai/gpt-4o-mini
    export OPENAI_API_KEY=sk-...
    python evaluators/calibration/replay.py --with-llm-judge

Results are also written to evaluators/calibration/replay_results.json.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path
from typing import Optional

LABELS = ("well_attributed", "partially_attributed", "unattributed")


def _score_to_label(score: float) -> str:
    """0-1 score → categorical label. Mirrors the rubric in
    docs/architecture.md memory quality gate section."""
    if score >= 0.7:
        return "well_attributed"
    if score >= 0.4:
        return "partially_attributed"
    return "unattributed"


def _label_to_reference_score(label: str) -> float:
    """Reference midpoint score per class — for MAE computation."""
    return {"well_attributed": 0.85, "partially_attributed": 0.55, "unattributed": 0.2}[label]


def _load_dataset(path: Optional[str] = None) -> list[dict]:
    p = Path(path) if path else Path(__file__).parent / "dataset.jsonl"
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]


def _confusion_matrix(pairs: list[tuple[str, str]]) -> dict[str, dict[str, int]]:
    cm = {gt: {pred: 0 for pred in LABELS} for gt in LABELS}
    for gt, pred in pairs:
        cm[gt][pred] += 1
    return cm


def _format_cm(cm: dict[str, dict[str, int]]) -> str:
    short = {"well_attributed": "well", "partially_attributed": "part", "unattributed": "unat"}
    header = "                 pred:well  part  unat"
    rows = [header]
    for gt in LABELS:
        rows.append(f"  gt={short[gt]:<4}        {cm[gt]['well_attributed']:>4}  {cm[gt]['partially_attributed']:>4}  {cm[gt]['unattributed']:>4}")
    return "\n".join(rows)


def run_deterministic(cases: list[dict]) -> dict:
    from evaluators import evaluate_attribution_integrity

    rows = []
    for c in cases:
        result = evaluate_attribution_integrity(
            decision_memory_id=c.get("scenario_id", "d"),
            retrieved_memories=c["retrieved_memories"],
        )
        pred_label = _score_to_label(result.score)
        rows.append({
            "scenario_id": c["scenario_id"],
            "ground_truth": c["ground_truth"],
            "predicted_label": pred_label,
            "predicted_score": round(result.score, 4),
            "passed": result.passed,
        })

    correct = sum(1 for r in rows if r["predicted_label"] == r["ground_truth"])
    accuracy = correct / len(rows)
    per_class = {label: 0 for label in LABELS}
    per_class_total = Counter(c["ground_truth"] for c in cases)
    for r in rows:
        if r["predicted_label"] == r["ground_truth"]:
            per_class[r["ground_truth"]] += 1
    mae = sum(abs(r["predicted_score"] - _label_to_reference_score(r["ground_truth"])) for r in rows) / len(rows)

    return {
        "rows": rows,
        "accuracy": round(accuracy, 4),
        "per_class_accuracy": {
            label: (per_class[label] / per_class_total[label]) if per_class_total[label] else 0.0
            for label in LABELS
        },
        "mae_to_class_reference_score": round(mae, 4),
        "confusion_matrix": _confusion_matrix([(r["ground_truth"], r["predicted_label"]) for r in rows]),
    }


def run_ragas(cases: list[dict], judge_model: Optional[str] = None) -> dict:
    from evaluators import evaluate_mai_ragas

    rows = []
    for c in cases:
        try:
            result = evaluate_mai_ragas(c["retrieved_memories"], judge_model=judge_model)
            pred_label = _score_to_label(result.score)
            rows.append({
                "scenario_id": c["scenario_id"],
                "ground_truth": c["ground_truth"],
                "predicted_label": pred_label,
                "predicted_score": round(result.score, 4),
                "passed": result.passed,
            })
        except Exception as e:
            rows.append({
                "scenario_id": c["scenario_id"],
                "ground_truth": c["ground_truth"],
                "predicted_label": None,
                "predicted_score": None,
                "error": str(e)[:200],
            })

    ok_rows = [r for r in rows if r["predicted_label"] is not None]
    if not ok_rows:
        return {"rows": rows, "accuracy": 0.0, "errors": True}

    correct = sum(1 for r in ok_rows if r["predicted_label"] == r["ground_truth"])
    return {
        "rows": rows,
        "accuracy": round(correct / len(ok_rows), 4),
        "errors": len(ok_rows) < len(rows),
        "confusion_matrix": _confusion_matrix([(r["ground_truth"], r["predicted_label"]) for r in ok_rows]),
    }


def agreement_rate(det_rows: list[dict], ragas_rows: list[dict]) -> float:
    """Fraction of cases where deterministic and RAGAS produce the same label.
    Skips cases where RAGAS errored."""
    det_by_id = {r["scenario_id"]: r["predicted_label"] for r in det_rows}
    ok = 0
    total = 0
    for r in ragas_rows:
        if r["predicted_label"] is None:
            continue
        total += 1
        if det_by_id.get(r["scenario_id"]) == r["predicted_label"]:
            ok += 1
    return ok / total if total else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--with-llm-judge", action="store_true", help="Also run RAGAS LLM-as-judge (requires MEMLEDGER_JUDGE_MODEL)")
    parser.add_argument("--dataset", default=None, help="Path to JSONL dataset (defaults to evaluators/calibration/dataset.jsonl)")
    parser.add_argument("--out", default=None, help="Where to write replay_results.json")
    args = parser.parse_args()

    sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))

    cases = _load_dataset(args.dataset)
    print(f"Loaded {len(cases)} golden cases")
    label_dist = Counter(c["ground_truth"] for c in cases)
    print(f"Label distribution: {dict(label_dist)}")

    print("\n=== Tier 1 — Deterministic MAI ===")
    det = run_deterministic(cases)
    print(f"Accuracy:               {det['accuracy']:.3f}  ({sum(int(r['predicted_label']==r['ground_truth']) for r in det['rows'])}/{len(det['rows'])})")
    print("Per-class accuracy:")
    for label, acc in det["per_class_accuracy"].items():
        print(f"  {label:<24} {acc:.3f}")
    print(f"MAE to class-reference: {det['mae_to_class_reference_score']:.3f}")
    print("Confusion matrix:")
    print(_format_cm(det["confusion_matrix"]))

    summary = {"deterministic": det}

    if args.with_llm_judge:
        judge = os.environ.get("MEMLEDGER_JUDGE_MODEL")
        if not judge:
            print("\nMEMLEDGER_JUDGE_MODEL not set — skipping LLM judge tier.")
        else:
            print(f"\n=== Tier 2 — RAGAS LLM-as-judge ({judge}) ===")
            ragas = run_ragas(cases, judge_model=judge)
            print(f"Accuracy: {ragas['accuracy']:.3f}")
            if ragas.get("confusion_matrix"):
                print("Confusion matrix:")
                print(_format_cm(ragas["confusion_matrix"]))
            if ragas.get("errors"):
                print("(Some rows errored; see replay_results.json)")
            ar = agreement_rate(det["rows"], ragas["rows"])
            print(f"Agreement rate (det vs RAGAS labels): {ar:.3f}")
            summary["ragas"] = ragas
            summary["agreement_rate"] = round(ar, 4)

    out_path = Path(args.out) if args.out else Path(__file__).parent / "replay_results.json"
    out_path.write_text(json.dumps(summary, indent=2))
    print(f"\nResults written to {out_path}")


if __name__ == "__main__":
    main()
