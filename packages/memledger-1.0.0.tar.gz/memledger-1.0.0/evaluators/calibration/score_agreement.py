# SPDX-License-Identifier: Apache-2.0
"""F10 — Calibration set scoring and agreement computation.

Runs Option A (deterministic rule-based) and Option B (structural) evaluators
against the labeled calibration dataset. Computes:
  - Per-category agreement rates
  - Overall agreement rate
  - Cohen's κ (inter-rater reliability)

Usage:
    python evaluators/calibration/score_agreement.py
"""

import csv
import json
import sys
from pathlib import Path
from typing import Any

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent.parent))


def load_dataset(path: str = "") -> list[dict]:
    """Load the calibration dataset."""
    if not path:
        path = str(Path(__file__).parent / "dataset.jsonl")
    examples = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                examples.append(json.loads(line))
    return examples


def score_to_category(score: float) -> str:
    """Map a 0-1 score to a ground-truth category."""
    if score >= 0.7:
        return "well_attributed"
    elif score >= 0.4:
        return "partially_attributed"
    else:
        return "unattributed"


def run_option_a(examples: list[dict]) -> list[dict]:
    """Run Option A (deterministic rule-based evaluator) on all examples."""
    from evaluators.attribution_integrity import evaluate_attribution_integrity

    results = []
    for ex in examples:
        result = evaluate_attribution_integrity(
            decision_memory_id=ex["scenario_id"],
            retrieved_memories=ex["retrieved_memories"],
            threshold=0.7,
        )
        predicted = score_to_category(result.score)
        results.append({
            "scenario_id": ex["scenario_id"],
            "ground_truth": ex["ground_truth"],
            "option_a_score": result.score,
            "option_a_predicted": predicted,
            "option_a_agreed": predicted == ex["ground_truth"],
        })
    return results


def run_option_b(examples: list[dict]) -> list[dict]:
    """Run Option B (structural evaluator) on all examples."""
    from evaluators.attribution_integrity_structural import evaluate_from_memory_records

    results = []
    for ex in examples:
        result = evaluate_from_memory_records(ex["retrieved_memories"], threshold=0.7)
        predicted = score_to_category(result.score)
        results.append({
            "scenario_id": ex["scenario_id"],
            "ground_truth": ex["ground_truth"],
            "option_b_score": result.score,
            "option_b_predicted": predicted,
            "option_b_agreed": predicted == ex["ground_truth"],
        })
    return results


def compute_cohens_kappa(labels_human: list[str], labels_evaluator: list[str]) -> float:
    """Compute Cohen's κ between human labels and evaluator predictions."""
    categories = sorted(set(labels_human + labels_evaluator))
    n = len(labels_human)
    if n == 0:
        return 0.0

    # Build confusion matrix
    matrix = {}
    for cat in categories:
        matrix[cat] = {c: 0 for c in categories}
    for h, e in zip(labels_human, labels_evaluator):
        matrix[h][e] += 1

    # Observed agreement
    po = sum(matrix[c][c] for c in categories) / n

    # Expected agreement by chance
    pe = 0.0
    for cat in categories:
        row_sum = sum(matrix[cat].values()) / n
        col_sum = sum(matrix[r][cat] for r in categories) / n
        pe += row_sum * col_sum

    if pe >= 1.0:
        return 1.0

    kappa = (po - pe) / (1.0 - pe)
    return round(kappa, 4)


def run_calibration(dataset_path: str = "") -> dict[str, Any]:
    """Run full calibration: both evaluators against labeled dataset."""
    examples = load_dataset(dataset_path)
    print(f"Loaded {len(examples)} calibration examples")

    # Count by category
    by_cat = {}
    for ex in examples:
        by_cat[ex["ground_truth"]] = by_cat.get(ex["ground_truth"], 0) + 1
    print(f"Distribution: {by_cat}")

    # Run both evaluators
    print("\nRunning Option A (deterministic)...")
    a_results = run_option_a(examples)

    print("Running Option B (structural)...")
    b_results = run_option_b(examples)

    # Merge results
    merged = []
    for a, b in zip(a_results, b_results):
        merged.append({**a, **{k: v for k, v in b.items() if k != "scenario_id" and k != "ground_truth"}})

    # Compute agreement rates
    a_agreed = sum(1 for r in merged if r["option_a_agreed"])
    b_agreed = sum(1 for r in merged if r["option_b_agreed"])
    ab_same = sum(1 for r in merged if r["option_a_predicted"] == r["option_b_predicted"])

    # Per-category agreement
    cat_agreement = {}
    for cat in ["well_attributed", "partially_attributed", "unattributed"]:
        cat_examples = [r for r in merged if r["ground_truth"] == cat]
        if cat_examples:
            a_cat = sum(1 for r in cat_examples if r["option_a_agreed"])
            b_cat = sum(1 for r in cat_examples if r["option_b_agreed"])
            cat_agreement[cat] = {
                "count": len(cat_examples),
                "option_a_agreement": f"{a_cat}/{len(cat_examples)} ({a_cat / len(cat_examples):.0%})",
                "option_b_agreement": f"{b_cat}/{len(cat_examples)} ({b_cat / len(cat_examples):.0%})",
            }

    # Cohen's κ
    human_labels = [r["ground_truth"] for r in merged]
    a_labels = [r["option_a_predicted"] for r in merged]
    b_labels = [r["option_b_predicted"] for r in merged]

    kappa_a = compute_cohens_kappa(human_labels, a_labels)
    kappa_b = compute_cohens_kappa(human_labels, b_labels)
    kappa_ab = compute_cohens_kappa(a_labels, b_labels)

    results = {
        "dataset_size": len(examples),
        "distribution": by_cat,
        "option_a": {
            "overall_agreement": f"{a_agreed}/{len(merged)} ({a_agreed / len(merged):.0%})",
            "cohens_kappa": kappa_a,
        },
        "option_b": {
            "overall_agreement": f"{b_agreed}/{len(merged)} ({b_agreed / len(merged):.0%})",
            "cohens_kappa": kappa_b,
        },
        "inter_evaluator": {
            "agreement": f"{ab_same}/{len(merged)} ({ab_same / len(merged):.0%})",
            "cohens_kappa": kappa_ab,
        },
        "per_category": cat_agreement,
    }

    # Print results
    print(f"\n{'='*60}")
    print("  CALIBRATION RESULTS")
    print(f"{'='*60}")
    print(f"Dataset: {len(examples)} examples ({by_cat})")
    print(f"\nOption A (deterministic): {results['option_a']['overall_agreement']} agreement, κ={kappa_a}")
    print(f"Option B (structural):    {results['option_b']['overall_agreement']} agreement, κ={kappa_b}")
    print(f"A vs B inter-evaluator:   {results['inter_evaluator']['agreement']} agreement, κ={kappa_ab}")
    print(f"\nPer category:")
    for cat, data in cat_agreement.items():
        print(f"  {cat}: A={data['option_a_agreement']}, B={data['option_b_agreement']}")

    if kappa_a < 0.3 or kappa_b < 0.3:
        print(f"\n⚠ WARNING: κ < 0.3 — evaluator should be flagged as experimental")
    elif kappa_a < 0.5 or kappa_b < 0.5:
        print(f"\n⚠ NOTE: κ < 0.5 — consider tuning rubric before demo")
    else:
        print(f"\n✓ κ ≥ 0.5 — evaluator is defensible for demo")

    # Save CSV
    csv_path = Path(__file__).parent / "results.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "scenario_id", "ground_truth",
            "option_a_score", "option_a_predicted", "option_a_agreed",
            "option_b_score", "option_b_predicted", "option_b_agreed",
        ])
        writer.writeheader()
        writer.writerows(merged)
    print(f"\nCSV saved: {csv_path}")

    # Save JSON summary
    json_path = Path(__file__).parent / "results_summary.json"
    with open(json_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"JSON saved: {json_path}")

    return results


if __name__ == "__main__":
    dataset_path = sys.argv[1] if len(sys.argv) > 1 else ""
    run_calibration(dataset_path)
