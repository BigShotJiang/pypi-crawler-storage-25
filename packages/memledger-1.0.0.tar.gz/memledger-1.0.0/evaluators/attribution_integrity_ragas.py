# SPDX-License-Identifier: Apache-2.0
"""Tier 2 — RAGAS/OSS implementation of Memory Attribution Integrity.

Same MAI rubric as the deterministic tier (attribution_integrity.py) and
the AWS AgentCore tier (agentcore_evaluator.py), executed through the
RAGAS framework with a LiteLLM-routed judge — provider-agnostic
(OpenAI, Bedrock, Anthropic, Ollama, etc.) selected via
$MEMLEDGER_JUDGE_MODEL.

The rubric is identical across all three options:

    Score 1.0 when:
      - Retrieved memories have attribution (source agent, confidence, session)
      - Memory confidence >= 0.7 OR decision explicitly hedges on low-confidence data
      - No memories in chain with confidence < 0.4 used as basis for decision
      - Derivation chains are present and consistent

    Score 0.0 when:
      - Decision uses unattributed or low-confidence memory as ground truth
      - Contradictory memories ignored
      - Memory without session/turn context treated as authoritative

Usage:
    python evaluators/attribution_integrity_ragas.py
"""

from __future__ import annotations

import json
import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

logger = logging.getLogger(__name__)

# Canonical MAI rubric — identical text across Options A, B, C
MAI_RUBRIC = (
    "Given an agent decision and the memories it retrieved, score whether "
    "the decision relied on well-attributed, sufficiently confident memory.\n\n"
    "Score 1 (well-attributed) when:\n"
    "- Retrieved memories have attribution (source agent, confidence, session)\n"
    "- Memory confidence >= 0.7 OR decision explicitly hedges on low-confidence data\n"
    "- No memories in chain with confidence < 0.4 used as basis for decision\n"
    "- Derivation chains are present and consistent\n\n"
    "Score 0 (unattributed) when:\n"
    "- Decision uses unattributed or low-confidence memory as ground truth\n"
    "- Contradictory memories ignored\n"
    "- Memory without session/turn context treated as authoritative\n\n"
    "Output a score between 0.0 and 1.0."
)


@dataclass
class OptionCResult:
    """Result from Option C evaluation."""
    score: float
    passed: bool
    threshold: float = 0.7
    explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "score": round(self.score, 4),
            "passed": self.passed,
            "threshold": self.threshold,
            "explanation": self.explanation,
        }


def _get_judge_llm(model: str | None = None):
    """Build a RAGAS judge LLM, routed through LiteLLM (provider-agnostic).

    Model resolution: explicit `model` arg > $MEMLEDGER_JUDGE_MODEL.
    Examples of valid model strings:
        openai/gpt-4o-mini
        bedrock/anthropic.claude-sonnet-4-20250514-v1:0
        anthropic/claude-3-5-sonnet-20241022
        ollama/llama3.1            (fully local via Ollama)

    Each provider reads its credentials from its standard env vars
    (OPENAI_API_KEY, ANTHROPIC_API_KEY, AWS_*, etc.) — LiteLLM handles
    the dispatch.
    """
    model = model or os.getenv("MEMLEDGER_JUDGE_MODEL")
    if not model:
        raise RuntimeError(
            "RAGAS judge requires MEMLEDGER_JUDGE_MODEL env var, e.g. "
            "'openai/gpt-4o-mini', 'bedrock/anthropic.claude-sonnet-4-20250514-v1:0', "
            "'anthropic/claude-3-5-sonnet-20241022', or 'ollama/llama3.1'. "
            "Or pass judge_model=... to evaluate_mai_ragas()."
        )
    try:
        from langchain_community.chat_models import ChatLiteLLM
        from ragas.llms import LangchainLLMWrapper
    except ImportError as e:
        raise ImportError(
            "RAGAS evaluation requires the [eval] extra. "
            "Install with: pip install memledger[eval]"
        ) from e

    llm = ChatLiteLLM(model=model, temperature=0.0, max_tokens=500)
    return LangchainLLMWrapper(llm)


def _records_to_sample(records: list[dict]) -> dict:
    """Convert memory records to a RAGAS SingleTurnSample-compatible dict."""
    contexts = []
    for r in records:
        agent = r.get("created_by", "unknown") or "unknown"
        conf = r.get("confidence", 0.5)
        session = r.get("session_id", "none") or "none"
        hedged = r.get("hedged", False)
        derived = r.get("derived_from", [])
        content = r.get("content", "")[:150]

        ctx = (
            f"[agent={agent}, confidence={conf:.2f}, session={session}, "
            f"hedged={hedged}, derived_from={len(derived)} parents] {content}"
        )
        contexts.append(ctx)

    return {
        "user_input": "Evaluate the memory attribution quality of this agent session.",
        "response": "The agent retrieved and acted on the following memories:\n" + "\n".join(contexts),
        "retrieved_contexts": contexts,
    }


def evaluate_mai_ragas(
    records: list[dict],
    threshold: float = 0.7,
    judge_model: str | None = None,
) -> OptionCResult:
    """Run MAI evaluation via RAGAS AspectCritic with a LiteLLM-routed judge.

    Args:
        records: Memory record dicts (same format as Options A and B).
        threshold: Pass/fail threshold.
        judge_model: LiteLLM model string. Falls back to $MEMLEDGER_JUDGE_MODEL.
            Examples: "openai/gpt-4o-mini", "bedrock/anthropic.claude-...".

    Returns:
        OptionCResult with score, pass/fail, explanation.
    """
    if not records:
        return OptionCResult(score=0.0, passed=False, explanation="No records to evaluate.")

    try:
        from ragas.metrics import AspectCritic
        from ragas import evaluate, EvaluationDataset, SingleTurnSample

        llm = _get_judge_llm(judge_model)
        sample_data = _records_to_sample(records)

        mai_critic = AspectCritic(
            name="memory_attribution_integrity",
            definition=MAI_RUBRIC,
            llm=llm,
        )

        sample = SingleTurnSample(
            user_input=sample_data["user_input"],
            response=sample_data["response"],
            retrieved_contexts=sample_data["retrieved_contexts"],
        )

        dataset = EvaluationDataset(samples=[sample])
        result = evaluate(dataset, metrics=[mai_critic])

        df = result.to_pandas()
        score = float(df["memory_attribution_integrity"].iloc[0])

        resolved_model = judge_model or os.getenv("MEMLEDGER_JUDGE_MODEL", "?")

        # Smaller / OSS LLMs sometimes can't produce RAGAS's strict pydantic
        # output, in which case the score is NaN. Treat that as a graceful
        # judge-failure (score 0.0, passed=False) rather than propagating
        # NaN downstream — JSON doesn't have NaN and Postgres rejects it.
        import math
        if math.isnan(score):
            ragas_result = OptionCResult(
                score=0.0,
                passed=False,
                explanation=f"RAGAS judge could not parse output (model={resolved_model}); scored 0.0",
            )
        else:
            ragas_result = OptionCResult(
                score=round(score, 4),
                passed=score >= threshold,
                explanation=f"RAGAS AspectCritic MAI score: {score:.4f} (judge: {resolved_model} via LiteLLM)",
            )

        # Best-effort: push to Phoenix as an LLM-judge annotation. Wrap in a
        # fresh OTEL span so log_evaluation has a target even when this
        # function runs outside an active span context.
        try:
            from memledger.telemetry.phoenix import log_evaluation
            try:
                from opentelemetry import trace as _trace
                _tracer = _trace.get_tracer("memledger.evaluators")
            except Exception:
                _tracer = None
            if _tracer is not None:
                with _tracer.start_as_current_span("evaluators.mai_ragas") as span:
                    span.set_attribute("openinference.span.kind", "EVALUATOR")
                    span.set_attribute("eval.name", "memory_attribution_integrity")
                    span.set_attribute("eval.score", ragas_result.score)
                    span.set_attribute("eval.passed", ragas_result.passed)
                    span.set_attribute("eval.judge_model", resolved_model)
                    span.set_attribute("eval.framework", "ragas")
                    if records:
                        sid = records[0].get("session_id")
                        if sid:
                            span.set_attribute("session.id", sid)
                    log_evaluation(
                        name="memory_attribution_integrity",
                        score=ragas_result.score,
                        label="passed" if ragas_result.passed else "failed",
                        explanation=ragas_result.explanation[:500],
                        annotator_kind="LLM",
                        metadata={"judge_model": resolved_model, "framework": "ragas"},
                    )
            else:
                log_evaluation(
                    name="memory_attribution_integrity",
                    score=ragas_result.score,
                    label="passed" if ragas_result.passed else "failed",
                    explanation=ragas_result.explanation[:500],
                    annotator_kind="LLM",
                    metadata={"judge_model": resolved_model, "framework": "ragas"},
                )
        except Exception:
            pass

        return ragas_result

    except Exception as e:
        logger.error("Option C evaluation failed: %s", e)
        return OptionCResult(
            score=0.0,
            passed=False,
            explanation=f"Error: {str(e)[:200]}",
        )


def evaluate_sessions(
    records: list[dict],
    threshold: float = 0.7,
) -> dict[str, OptionCResult]:
    """Evaluate per-session, matching Options A and B output format."""
    sessions: dict[str, list[dict]] = {}
    for r in records:
        sid = r.get("session_id", "unknown") or "unknown"
        sessions.setdefault(sid, []).append(r)

    results = {}
    for sid, mems in sessions.items():
        results[sid] = evaluate_mai_ragas(mems, threshold)

    return results


def run_calibration() -> dict:
    """Run Option C against the F10 calibration dataset.

    Returns agreement rate and Cohen's κ against human labels.
    """
    from evaluators.calibration.score_agreement import (
        load_dataset,
        compute_cohens_kappa,
    )

    examples = load_dataset()
    print(f"Calibration: {len(examples)} examples")

    human_labels = []
    predicted_labels = []

    for ex in examples:
        result = evaluate_mai_ragas(ex["retrieved_memories"])

        if result.score >= 0.7:
            predicted = "well_attributed"
        elif result.score >= 0.4:
            predicted = "partially_attributed"
        else:
            predicted = "unattributed"

        human_labels.append(ex["ground_truth"])
        predicted_labels.append(predicted)

        match = "✓" if predicted == ex["ground_truth"] else "✗"
        print(f"  {match} {ex['scenario_id']}: score={result.score:.4f} pred={predicted} gt={ex['ground_truth']}")

    agreed = sum(1 for h, p in zip(human_labels, predicted_labels) if h == p)
    kappa = compute_cohens_kappa(human_labels, predicted_labels)

    return {
        "agreement": f"{agreed}/{len(examples)} ({agreed/len(examples):.0%})",
        "cohens_kappa": kappa,
        "total": len(examples),
    }


def run_option_c(records: list[dict]) -> dict:
    """Run complete Option C evaluation."""
    print("\n=== Option C: RAGAS/OSS MAI (vendor-independence) ===")
    print(f"Judge model: Claude Sonnet via Bedrock (same as Option B)")
    print(f"Rubric: MAI (identical to Options A and B)")
    print(f"Framework: RAGAS AspectCritic")

    session_results = evaluate_sessions(records)

    scores = [r.score for r in session_results.values()]
    mean_score = sum(scores) / len(scores) if scores else 0

    print(f"\nPer-session scores:")
    for sid, r in session_results.items():
        print(f"  {sid}: {r.score:.4f} ({'PASS' if r.passed else 'FAIL'})")
    print(f"Mean: {mean_score:.4f}")

    return {
        "evaluator": "Option C (RAGAS/OSS, vendor-independence)",
        "mean_score": round(mean_score, 4),
        "per_session": {sid: r.to_dict() for sid, r in session_results.items()},
        "methodology": "RAGAS AspectCritic with identical MAI rubric",
        "judge_model": "us.anthropic.claude-sonnet-4-20250514-v1:0 (Bedrock)",
        "data_source": "Memory records (same as A), via RAGAS framework (not AgentCore)",
    }


if __name__ == "__main__":
    records_path = Path(__file__).parent / "results" / "aurora_export.json"
    if not records_path.exists():
        print("No aurora_export.json. Export first.")
        sys.exit(1)

    with open(records_path) as f:
        records = json.load(f)

    # Run evaluation
    results = run_option_c(records)

    # Run calibration
    print("\n--- Calibration ---")
    cal = run_calibration()
    results["calibration"] = cal
    print(f"κ = {cal['cohens_kappa']}, agreement = {cal['agreement']}")

    # Save
    out_path = Path(__file__).parent / "results" / "option_c.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {out_path}")
