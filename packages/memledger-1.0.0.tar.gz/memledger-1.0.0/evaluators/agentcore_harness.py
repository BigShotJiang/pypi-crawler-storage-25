# SPDX-License-Identifier: Apache-2.0
"""AgentCore Evaluations harness for memory trust evaluation.

Runs the 4 built-in evaluators + custom Memory Attribution Integrity
against traces in CloudWatch.

Usage:
    from evaluators.agentcore_harness import run_agentcore_evaluation

    results = await run_agentcore_evaluation(
        log_group="/aws/otel/memledger",
        session_id="demo-session-001",
    )
"""

from __future__ import annotations
import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


async def run_agentcore_evaluation(
    log_group: str = "/aws/otel/memledger",
    session_id: str = "demo-session-001",
    region: str | None = None,
    builtin_evaluators: list[str] | None = None,
    custom_evaluator_arn: str | None = None,
) -> dict[str, Any]:
    """Run AgentCore Evaluations against CloudWatch traces.

    Args:
        log_group: CloudWatch log group with OTEL traces
        session_id: Session to evaluate
        region: AWS region
        builtin_evaluators: List of Builtin.* evaluator names
        custom_evaluator_arn: ARN of the custom evaluator (from register_agentcore_evaluator)

    Returns:
        {evaluator_name: score, ...}
    """
    if builtin_evaluators is None:
        builtin_evaluators = [
            "Builtin.GoalSuccessRate",
            "Builtin.Correctness",
            "Builtin.ToolSelectionAccuracy",
            "Builtin.ContextRelevance",
        ]

    try:
        import boto3
        region = region or os.getenv("AWS_REGION", "us-west-2")
        client = boto3.client("bedrock-agentcore-control", region_name=region)

        # Build evaluator list
        evaluators = [{"evaluatorId": e} for e in builtin_evaluators]
        if custom_evaluator_arn:
            evaluators.append({"evaluatorId": custom_evaluator_arn})

        # Create online evaluation config
        eval_config = {
            "evaluationConfigName": f"memledger-eval-{session_id[:20]}",
            "evaluationDataSource": {
                "cloudWatchLogGroup": {
                    "logGroupName": log_group,
                }
            },
            "evaluators": evaluators,
        }

        try:
            response = client.create_online_evaluation_config(**eval_config)
            config_arn = response.get("evaluationConfigArn", "")
            logger.info("Created AgentCore eval config: %s", config_arn)
        except Exception as e:
            logger.warning("Failed to create eval config: %s", e)
            config_arn = ""

        # Note: AgentCore Evaluations runs asynchronously.
        # Results appear in CloudWatch after 2-5 minutes.
        # For the demo, we'll pre-run and screenshot results.

        return {
            "status": "configured",
            "config_arn": config_arn,
            "evaluators": [e["evaluatorId"] for e in evaluators],
            "log_group": log_group,
            "session_id": session_id,
            "note": "Results will appear in CloudWatch after 2-5 minutes. Pre-capture screenshots for demo.",
        }

    except ImportError:
        return {"status": "skipped", "reason": "bedrock-agentcore SDK not installed"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def get_evaluation_results(
    session_id: str,
    log_group: str = "/aws/otel/memledger",
    region: str | None = None,
) -> dict[str, Any]:
    """Query CloudWatch for evaluation results.

    Region resolution: explicit arg > $AWS_REGION > "us-west-2".
    Call this 5+ minutes after running the evaluation.
    """
    try:
        import boto3
        region = region or os.getenv("AWS_REGION", "us-west-2")
        client = boto3.client("logs", region_name=region)

        # Query for evaluation results
        response = client.filter_log_events(
            logGroupName=log_group,
            filterPattern=f'"evaluation" "{session_id}"',
            limit=50,
        )

        results = {}
        for event in response.get("events", []):
            try:
                data = json.loads(event["message"])
                if "evaluator" in data and "score" in data:
                    results[data["evaluator"]] = data["score"]
            except (json.JSONDecodeError, KeyError):
                continue

        return {"session_id": session_id, "results": results, "raw_events": len(response.get("events", []))}

    except Exception as e:
        return {"error": str(e)}
