# SPDX-License-Identifier: Apache-2.0
"""Memory Attribution Integrity Evaluator.

Scores 0.0-1.0: Did the agent's decision rely on well-attributed,
sufficiently confident memory?

Can run as:
1. A DeepEval G-Eval evaluator (LLM-as-judge)
2. A deterministic rule-based evaluator (no LLM needed)
3. An AgentCore custom evaluator (when available)

Score 1.0 when:
- Retrieved memories have attribution (source agent, confidence, session)
- Memory confidence >= 0.7 OR decision explicitly hedges on low-confidence data
- No memories in chain with confidence < 0.4 used as basis for decision
- Derivation chains are present and consistent

Score 0.0 when:
- Decision uses unattributed or low-confidence memory as ground truth
- Contradictory memories ignored
- Memory without session/turn context treated as authoritative
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


@dataclass
class AttributionIntegrityResult:
    """Result of a memory attribution integrity evaluation."""
    score: float                    # 0.0-1.0
    passed: bool                    # score >= threshold
    threshold: float = 0.7
    details: dict = field(default_factory=dict)
    explanation: str = ""


def evaluate_attribution_integrity(
    decision_memory_id: str,
    retrieved_memories: list[dict],  # Each: {id, content, created_by, importance, derived_from, session_id, ...}
    chain: Optional[dict] = None,   # Attribution chain from get_attribution_chain()
    threshold: float = 0.7,
) -> AttributionIntegrityResult:
    """Evaluate whether a decision was based on well-attributed memory.

    Deterministic scoring — no LLM needed. Each criterion adds or subtracts
    from the score.

    Args:
        decision_memory_id: The memory that represents the agent's decision
        retrieved_memories: Memories that were retrieved before the decision
        chain: Attribution chain for the decision memory
        threshold: Minimum score to pass (default 0.7)
    """
    score = 1.0
    penalties = []
    bonuses = []

    if not retrieved_memories:
        return AttributionIntegrityResult(
            score=0.0,
            passed=False,
            threshold=threshold,
            details={"error": "no_retrieved_memories"},
            explanation="No retrieved memories to evaluate.",
        )

    # Helper: read confidence from either 'confidence' or 'importance' field
    def _conf(m: dict) -> float:
        return m.get("confidence", m.get("importance", 0.5)) or 0.5

    # Criterion 1: Attribution completeness (do memories have source agent?)
    attributed_count = sum(1 for m in retrieved_memories if m.get("created_by"))
    attribution_ratio = attributed_count / len(retrieved_memories)
    if attribution_ratio < 1.0:
        penalty = (1.0 - attribution_ratio) * 0.4
        score -= penalty
        penalties.append(f"Attribution gap: {attributed_count}/{len(retrieved_memories)} have source agent (-{penalty:.2f})")
    else:
        bonuses.append("All retrieved memories have source attribution")

    # Criterion 2: Confidence levels
    confidences = [_conf(m) for m in retrieved_memories]
    mean_conf = sum(confidences) / len(confidences)

    # 2a: Low-confidence memories (< 0.4) used without hedging
    low_conf_unhedged = sum(
        1 for m in retrieved_memories
        if _conf(m) < 0.4 and not m.get("hedged", False)
    )
    if low_conf_unhedged > 0:
        penalty = low_conf_unhedged * 0.25
        score -= penalty
        penalties.append(f"Low-confidence unhedged: {low_conf_unhedged} below 0.4 (-{penalty:.2f})")

    # 2b: Flagged-confidence (0.4-0.6) without hedging
    flagged_unhedged = sum(
        1 for m in retrieved_memories
        if 0.4 <= _conf(m) < 0.6 and not m.get("hedged", False)
    )
    if flagged_unhedged > 0:
        penalty = flagged_unhedged * 0.1
        score -= penalty
        penalties.append(f"Flagged-confidence unhedged: {flagged_unhedged} in 0.4-0.6 (-{penalty:.2f})")

    # 2c: Mean confidence penalty
    if mean_conf < 0.6:
        penalty = (0.6 - mean_conf) * 0.5
        score -= penalty
        penalties.append(f"Low mean confidence: {mean_conf:.2f} (-{penalty:.2f})")

    # Criterion 3: Session context
    session_count = sum(1 for m in retrieved_memories if m.get("session_id"))
    session_ratio = session_count / len(retrieved_memories)
    if session_ratio < 0.5:
        penalty = (1.0 - session_ratio) * 0.15
        score -= penalty
        penalties.append(f"Weak session context: {session_count}/{len(retrieved_memories)} have session IDs (-{penalty:.2f})")

    # Criterion 4: Chain integrity (if chain provided, check for gaps)
    if chain:
        chain_hops = chain.get("chain", [])
        if chain_hops:
            min_chain_conf = chain.get("min_confidence", 1.0)
            if min_chain_conf < 0.4:
                penalty = 0.2
                score -= penalty
                penalties.append(f"Chain contains low-confidence hop (min={min_chain_conf:.2f}) (-{penalty:.2f})")

            if chain.get("truncated"):
                penalty = 0.05
                score -= penalty
                penalties.append(f"Chain truncated (depth > max_hops) (-{penalty:.2f})")
        else:
            bonuses.append("No derivation chain (original memory)")

    # Criterion 5: Diversity of sources (multiple agents = more trustworthy)
    unique_agents = set(m.get("created_by", "") for m in retrieved_memories if m.get("created_by"))
    if len(unique_agents) >= 2:
        bonus = 0.05
        score += bonus
        bonuses.append(f"Multi-agent corroboration: {len(unique_agents)} agents (+{bonus:.2f})")

    # Clamp score
    score = max(0.0, min(1.0, score))

    explanation_parts = []
    if bonuses:
        explanation_parts.append("Strengths: " + "; ".join(bonuses))
    if penalties:
        explanation_parts.append("Issues: " + "; ".join(penalties))

    result = AttributionIntegrityResult(
        score=round(score, 4),
        passed=score >= threshold,
        threshold=threshold,
        details={
            "attributed_ratio": attribution_ratio,
            "low_confidence_unhedged": low_conf_unhedged,
            "mean_confidence": round(mean_conf, 4),
            "session_context_ratio": session_ratio,
            "unique_agents": len(unique_agents),
            "chain_min_confidence": chain.get("min_confidence") if chain else None,
            "penalties": penalties,
            "bonuses": bonuses,
        },
        explanation=". ".join(explanation_parts) if explanation_parts else "No issues detected.",
    )

    # Best-effort: push to Phoenix as a span annotation. We wrap the
    # annotation call in a fresh OTEL span so log_evaluation has a target
    # span_id even when this function is called outside any active span
    # context (e.g. from an evaluator harness or a CLI replay).
    try:
        from memledger.telemetry.phoenix import log_evaluation
        try:
            from opentelemetry import trace as _trace
            _tracer = _trace.get_tracer("memledger.evaluators")
        except Exception:
            _tracer = None
        if _tracer is not None:
            with _tracer.start_as_current_span("evaluators.mai_deterministic") as span:
                span.set_attribute("openinference.span.kind", "EVALUATOR")
                span.set_attribute("eval.name", "memory_attribution_integrity")
                span.set_attribute("eval.score", result.score)
                span.set_attribute("eval.passed", result.passed)
                if retrieved_memories:
                    sid = retrieved_memories[0].get("session_id")
                    if sid:
                        span.set_attribute("session.id", sid)
                log_evaluation(
                    name="memory_attribution_integrity",
                    score=result.score,
                    label="passed" if result.passed else "failed",
                    explanation=result.explanation[:500],
                    annotator_kind="CODE",
                )
        else:
            log_evaluation(
                name="memory_attribution_integrity",
                score=result.score,
                label="passed" if result.passed else "failed",
                explanation=result.explanation[:500],
                annotator_kind="CODE",
            )
    except Exception:
        pass

    return result


# AgentCore evaluator registration moved to evaluators/agentcore_evaluator.py
# (it's the only AWS-coupled piece; keeping this file pure-OSS / pure-stdlib).
