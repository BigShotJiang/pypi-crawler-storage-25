# SPDX-License-Identifier: Apache-2.0
"""RAGAS + Phoenix evaluation harness for memory quality metrics.

Maps memory operations to RAGAS evaluation metrics:
- faithfulness: is the agent's answer grounded in retrieved memory?
- context_relevance: is the retrieved memory relevant to the query?
- context_precision: precision of memory retrieval ranking
- answer_relevance: does the final answer address the user's goal?

Phoenix consumes the same OTEL traces as CloudWatch, providing
a visual comparison UI for evaluation results.

Usage:
    from evaluators.ragas_harness import evaluate_memory_quality

    results = await evaluate_memory_quality(
        queries=["What is max_connections?"],
        retrieved_memories=[...],
        agent_answers=["max_connections should be cores*4"],
        ground_truths=["max_connections = (cores * 2) + spindles"],
    )
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


ATTRIBUTION_INTEGRITY_RUBRIC = """
Score whether the agent's decision relied on well-attributed, sufficiently confident memory.

Score YES (1.0) when:
- All retrieved memories have source attribution (agent ID, session ID)
- Memory confidence >= 0.7 OR decision explicitly hedges on low-confidence data
- Derivation chains are present and consistent
- No memories with confidence < 0.4 used as authoritative basis

Score NO (0.0) when:
- Decision uses unattributed or low-confidence memory as ground truth
- Contradictory memories ignored without acknowledgment
- Memory without session context treated as authoritative
"""


@dataclass
class MemoryQualityResult:
    """Result of memory quality evaluation."""
    faithfulness: float = 0.0           # Is answer grounded in memory?
    context_relevance: float = 0.0      # Is retrieved memory relevant?
    context_precision: float = 0.0      # Precision of ranking
    answer_relevance: float = 0.0       # Does answer address goal?
    attribution_integrity: float = 0.0  # Custom: is memory well-attributed?
    overall: float = 0.0               # Weighted average
    details: dict = field(default_factory=dict)


async def evaluate_memory_quality(
    queries: list[str],
    retrieved_memories: list[list[dict]],  # Per-query list of retrieved memories
    agent_answers: list[str],
    ground_truths: list[str],
    use_ragas: bool = True,
    use_phoenix: bool = False,
) -> MemoryQualityResult:
    """Evaluate memory quality using RAGAS metrics.

    Falls back to deterministic heuristics if RAGAS is not installed.
    """

    # Try RAGAS first
    if use_ragas:
        try:
            return await _evaluate_with_ragas(queries, retrieved_memories, agent_answers, ground_truths)
        except ImportError:
            logger.warning("RAGAS not installed, using deterministic evaluation")
        except Exception as e:
            logger.warning("RAGAS evaluation failed: %s, using deterministic", e)

    # Deterministic fallback
    return _evaluate_deterministic(queries, retrieved_memories, agent_answers, ground_truths)


async def _evaluate_with_ragas(
    queries: list[str],
    retrieved_memories: list[list[dict]],
    agent_answers: list[str],
    ground_truths: list[str],
) -> MemoryQualityResult:
    """Evaluate using RAGAS library."""
    from ragas import evaluate
    from ragas.metrics import faithfulness, context_relevancy, context_precision, answer_relevancy
    from datasets import Dataset

    # Build RAGAS dataset
    data = {
        "question": queries,
        "answer": agent_answers,
        "contexts": [[m.get("content", "") for m in mems] for mems in retrieved_memories],
        "ground_truth": ground_truths,
    }
    dataset = Dataset.from_dict(data)

    result = evaluate(
        dataset,
        metrics=[faithfulness, context_relevancy, context_precision, answer_relevancy],
    )

    return MemoryQualityResult(
        faithfulness=result.get("faithfulness", 0.0),
        context_relevance=result.get("context_relevancy", 0.0),
        context_precision=result.get("context_precision", 0.0),
        answer_relevance=result.get("answer_relevancy", 0.0),
        overall=(
            result.get("faithfulness", 0) * 0.3 +
            result.get("context_relevancy", 0) * 0.25 +
            result.get("context_precision", 0) * 0.2 +
            result.get("answer_relevancy", 0) * 0.25
        ),
        details=dict(result),
    )


def _evaluate_deterministic(
    queries: list[str],
    retrieved_memories: list[list[dict]],
    agent_answers: list[str],
    ground_truths: list[str],
) -> MemoryQualityResult:
    """Deterministic evaluation fallback — no LLM or RAGAS needed.

    Uses simple heuristics to approximate the RAGAS metrics.
    """
    n = len(queries)
    if n == 0:
        return MemoryQualityResult()

    faithfulness_scores = []
    relevance_scores = []
    precision_scores = []
    answer_scores = []

    for i in range(n):
        query = queries[i].lower()
        answer = agent_answers[i].lower() if i < len(agent_answers) else ""
        truth = ground_truths[i].lower() if i < len(ground_truths) else ""
        memories = retrieved_memories[i] if i < len(retrieved_memories) else []

        # Faithfulness: is the answer grounded in retrieved memories?
        if memories:
            memory_text = " ".join(m.get("content", "").lower() for m in memories)
            answer_words = set(answer.split())
            memory_words = set(memory_text.split())
            overlap = len(answer_words & memory_words) / max(len(answer_words), 1)
            faithfulness_scores.append(min(1.0, overlap * 2))  # Scale up
        else:
            faithfulness_scores.append(0.0)

        # Context relevance: are retrieved memories relevant to query?
        if memories:
            query_words = set(query.split())
            relevance_per_mem = []
            for m in memories:
                mem_words = set(m.get("content", "").lower().split())
                overlap = len(query_words & mem_words) / max(len(query_words), 1)
                relevance_per_mem.append(overlap)
            relevance_scores.append(sum(relevance_per_mem) / len(relevance_per_mem))
        else:
            relevance_scores.append(0.0)

        # Context precision: are relevant memories ranked higher?
        if memories and len(memories) > 1:
            # Simple: check if first result has higher relevance than last
            first_rel = len(set(query.split()) & set(memories[0].get("content", "").lower().split())) / max(len(query.split()), 1)
            last_rel = len(set(query.split()) & set(memories[-1].get("content", "").lower().split())) / max(len(query.split()), 1)
            precision_scores.append(1.0 if first_rel >= last_rel else 0.5)
        else:
            precision_scores.append(0.5)

        # Answer relevance: does answer address the query?
        if answer and truth:
            truth_words = set(truth.split())
            answer_overlap = len(set(answer.split()) & truth_words) / max(len(truth_words), 1)
            answer_scores.append(min(1.0, answer_overlap * 1.5))
        else:
            answer_scores.append(0.0)

    f = sum(faithfulness_scores) / n
    cr = sum(relevance_scores) / n
    cp = sum(precision_scores) / n
    ar = sum(answer_scores) / n

    return MemoryQualityResult(
        faithfulness=round(f, 4),
        context_relevance=round(cr, 4),
        context_precision=round(cp, 4),
        answer_relevance=round(ar, 4),
        overall=round(f * 0.3 + cr * 0.25 + cp * 0.2 + ar * 0.25, 4),
        details={
            "method": "deterministic_heuristic",
            "num_queries": n,
        },
    )


async def evaluate_with_ragas_aspect_critic(
    query: str,
    retrieved_memories: list[dict],
    agent_answer: str,
) -> dict:
    """Run the Memory Attribution Integrity evaluator via RAGAS AspectCritic."""
    try:
        from ragas.metrics import AspectCritic
        from ragas import SingleTurnSample

        critic = AspectCritic(
            name="memory_attribution_integrity",
            definition=ATTRIBUTION_INTEGRITY_RUBRIC,
        )

        sample = SingleTurnSample(
            user_input=query,
            response=agent_answer,
            retrieved_contexts=[m.get("content", "") for m in retrieved_memories],
        )

        score = await critic.single_turn_ascore(sample)
        return {"score": float(score), "method": "ragas_aspect_critic"}

    except ImportError:
        # Fallback to deterministic
        from evaluators.attribution_integrity import evaluate_attribution_integrity
        result = evaluate_attribution_integrity(
            decision_memory_id="eval",
            retrieved_memories=retrieved_memories,
        )
        return {"score": result.score, "method": "deterministic_fallback"}
    except Exception as e:
        return {"score": 0.0, "method": "error", "error": str(e)}
