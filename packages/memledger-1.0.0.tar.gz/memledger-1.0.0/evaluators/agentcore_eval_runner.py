# SPDX-License-Identifier: Apache-2.0
"""F6 — AgentCore Evaluation Runner.

Runs built-in AgentCore evaluators against memory operation data exported
from Phoenix/Aurora. Converts memledger trace data into the format AgentCore
evaluators expect.

Since AgentCore CLI requires spans in `aws/spans` CloudWatch log group (which
uses AgentCore SDK's own instrumentation), this script invokes the evaluator
API programmatically with our trace data.

Usage:
    python evaluators/agentcore_eval_runner.py
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))


async def fetch_memories_from_aurora():
    """Fetch all memories from Aurora for evaluation."""
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    dsn = os.environ.get("MEMLEDGER_PG_DSN", "")
    if not dsn:
        print("MEMLEDGER_PG_DSN not set — using Phoenix data only")
        return []

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=dsn,
        embedding_config=EmbeddingConfig(provider="bedrock", model="amazon.titan-embed-text-v2:0", dimensions=1024),
    )

    active = await ml.get_by_status("active")
    deprecated = await ml.get_by_status("deprecated")
    all_mems = active + deprecated
    await ml.close()

    return [
        {
            "id": m.id,
            "content": m.content[:200],
            "record_type": m.record_type.value,
            "created_by": m.created_by,
            "confidence": m.confidence,
            "importance": m.importance,
            "session_id": m.session_id,
            "derived_from": m.derived_from,
            "supersedes": m.supersedes,
            "hedged": m.hedged,
            "namespace": m.namespace,
            "status": m.status.value,
            "success_count": m.success_count,
            "failure_count": m.failure_count,
        }
        for m in all_mems
    ]


def run_option_a_eval(records: list[dict]) -> dict:
    """Run Option A (deterministic) evaluator."""
    from evaluators.attribution_integrity import evaluate_attribution_integrity

    # Group by session
    sessions = {}
    for r in records:
        sid = r.get("session_id", "unknown")
        sessions.setdefault(sid, []).append(r)

    results = {}
    for sid, mems in sessions.items():
        result = evaluate_attribution_integrity(sid, mems)
        results[sid] = {
            "score": result.score,
            "passed": result.passed,
            "explanation": result.explanation,
        }

    mean_score = sum(r["score"] for r in results.values()) / len(results) if results else 0
    return {"evaluator": "Option A (deterministic)", "mean_score": round(mean_score, 4), "sessions": results}


def run_option_b_eval(records: list[dict]) -> dict:
    """Run Option B (structural) evaluator."""
    from evaluators.attribution_integrity_structural import evaluate_from_memory_records

    sessions = {}
    for r in records:
        sid = r.get("session_id", "unknown")
        sessions.setdefault(sid, []).append(r)

    results = {}
    for sid, mems in sessions.items():
        result = evaluate_from_memory_records(mems)
        results[sid] = {
            "score": result.score,
            "passed": result.passed,
            "explanation": result.explanation,
        }

    mean_score = sum(r["score"] for r in results.values()) / len(results) if results else 0
    return {"evaluator": "Option B (structural)", "mean_score": round(mean_score, 4), "sessions": results}


def run_agentcore_builtin_eval(records: list[dict]) -> dict:
    """Run AgentCore built-in evaluators via SDK programmatic API.

    Uses the bedrock-agentcore SDK's evaluate API directly, bypassing
    the CloudWatch log group requirement.
    """
    try:
        from bedrock_agentcore.evaluations import evaluate, BuiltinEvaluator

        # Format records as AgentCore evaluation input
        eval_input = {
            "conversation": [
                {
                    "role": "user",
                    "content": "Assess the memory operations performed by the agent fleet",
                },
                {
                    "role": "assistant",
                    "content": "\n".join(
                        f"[{r['created_by'] or 'unknown'}] ({r['record_type']}, conf={r['confidence']:.2f}): {r['content']}"
                        for r in records[:10]
                    ),
                },
            ],
        }

        evaluator_names = [
            "Builtin.Correctness",
            "Builtin.Coherence",
            "Builtin.Completeness",
            "Builtin.Helpfulness",
        ]

        results = {}
        for eval_name in evaluator_names:
            try:
                result = evaluate(
                    evaluator_id=eval_name,
                    conversation=eval_input["conversation"],
                )
                results[eval_name] = {
                    "score": result.get("score", 0),
                    "explanation": result.get("explanation", ""),
                }
            except Exception as e:
                results[eval_name] = {"score": "N/A", "error": str(e)[:100]}

        return {"evaluator": "AgentCore Built-ins", "results": results}

    except ImportError:
        return {"evaluator": "AgentCore Built-ins", "error": "SDK not available", "results": {}}
    except Exception as e:
        return {"evaluator": "AgentCore Built-ins", "error": str(e)[:200], "results": {}}


def main():
    print("F6 — AgentCore Evaluation Runner")
    print("=" * 60)

    # Fetch data
    records = asyncio.run(fetch_memories_from_aurora())
    if not records:
        print("No records found. Using calibration dataset as fallback.")
        from evaluators.calibration.score_agreement import load_dataset
        examples = load_dataset()
        records = []
        for ex in examples:
            records.extend(ex["retrieved_memories"])

    print(f"Loaded {len(records)} memory records")

    # Run all evaluators
    print("\n--- Option A (deterministic) ---")
    a_results = run_option_a_eval(records)
    print(f"Mean score: {a_results['mean_score']}")

    print("\n--- Option B (structural) ---")
    b_results = run_option_b_eval(records)
    print(f"Mean score: {b_results['mean_score']}")

    print("\n--- AgentCore Built-ins ---")
    ac_results = run_agentcore_builtin_eval(records)
    if "error" in ac_results:
        print(f"Error: {ac_results['error']}")
    else:
        for name, r in ac_results.get("results", {}).items():
            print(f"  {name}: {r.get('score', 'N/A')}")

    # Load calibration data
    cal_path = Path(__file__).parent / "calibration" / "results_summary.json"
    cal_data = {}
    if cal_path.exists():
        with open(cal_path) as f:
            cal_data = json.load(f)

    # Compile final results
    final = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "record_count": len(records),
        "option_a": a_results,
        "option_b": b_results,
        "agentcore_builtins": ac_results,
        "calibration": cal_data,
        "position_bias": {
            "rate": "N/A — deterministic evaluators, no LLM judge calls",
            "note": "F12 position-bias tracker available for LLM-based conflict resolution",
        },
    }

    # Save
    out_path = Path(__file__).parent / "results" / "f6_complete.json"
    out_path.parent.mkdir(exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(final, f, indent=2)

    print(f"\n{'=' * 60}")
    print(f"Results saved to {out_path}")
    print(f"Option A mean: {a_results['mean_score']}")
    print(f"Option B mean: {b_results['mean_score']}")
    if cal_data:
        print(f"Calibration κ (A): {cal_data.get('option_a', {}).get('cohens_kappa', 'N/A')}")
        print(f"Calibration κ (B): {cal_data.get('option_b', {}).get('cohens_kappa', 'N/A')}")


if __name__ == "__main__":
    main()
