## Summary
<!-- 1–3 bullets on what changed and why. -->

## Scope
- [ ] SDK / API surface change (note in `CHANGELOG.md`)
- [ ] CLI surface change
- [ ] MCP server
- [ ] Helm chart / deployment
- [ ] Telemetry / OTEL attributes
- [ ] Docs / examples only

## Test plan
<!-- What you ran, what you saw. Include real-backend verification when relevant. -->
- [ ] `pytest` passes locally
- [ ] Linters (`ruff`, `mypy`) clean
- [ ] AWS-gated tests (if touched): `pytest -m aws` passes
- [ ] End-to-end against pgvector (if SDK/CLI touched)

## Risks / rollback
<!-- Anything that could regress; how to back out if needed. -->

## Linked issues
Closes #
