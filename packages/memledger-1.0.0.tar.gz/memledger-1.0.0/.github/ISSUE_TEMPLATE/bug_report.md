---
name: Bug report
about: Report a defect in memledger
title: "[bug] "
labels: bug
---

**Summary**
A clear, one-line description of the bug.

**Environment**
- memledger version (`pip show memledger`):
- Python version:
- OS:
- Backend (pgvector / opensearch / sqlite):
- Embedding provider (fastembed / bedrock / other):

**Reproduction**
Minimal steps to reproduce. Include code and commands.

```python
# repro
```

**Expected behavior**

**Actual behavior**
Include the full traceback or log output.

**Additional context**
Linked traces, screenshots, or related issues.
