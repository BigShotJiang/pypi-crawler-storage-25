---
name: Feature request
about: Propose a new capability for memledger
title: "[feat] "
labels: enhancement
---

**Use case**
What are you trying to do? Describe the multi-agent or memory-governance scenario.

**Why existing features fall short**
What did you try first, and where did it break down?

**Proposed API or behavior**
Sketch the SDK call, CLI surface, config knob, or telemetry attribute. Pseudocode is welcome.

```python
# proposed
```

**Scope**
- [ ] SDK (`memledger` Python package)
- [ ] CLI (`memledger` command)
- [ ] MCP server
- [ ] Helm chart / deployment
- [ ] Telemetry / OTEL
- [ ] Evaluators
- [ ] Docs

**Alternatives considered**

**Additional context**
Links to related issues, papers, or prior art.
