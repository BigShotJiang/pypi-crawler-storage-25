import click

from . import auth, local_instance
from .local_sync import DEFAULT_SYNC_INTERVAL_S, run_local_sync
from .local_start import get_local_status, run_local_service, start_local, stop_local


def _info_box(title, rows):
    """Print a bordered box with a title and key-value rows."""
    label_width = max(len(k) for k, _ in rows)
    content_lines = [f"  {k:<{label_width}}  {v}" for k, v in rows]
    inner_width = max(len(title) + 2, *(len(line) for line in content_lines)) + 2
    click.echo(f"\u250c {title} {'─' * (inner_width - len(title) - 2)}\u2510")
    for line in content_lines:
        click.echo(f"\u2502{line:<{inner_width}}\u2502")
    click.echo(f"\u2514{'─' * inner_width}\u2518")


def _follow_log():
    """Tail the local server log file, blocking until interrupted."""
    import time

    log_path = local_instance.get_local_log_path()
    click.echo(f"\n--- Following {log_path} (Ctrl-C to stop) ---\n")
    try:
        with open(log_path, "r") as f:
            f.seek(0, 2)  # seek to end
            while True:
                line = f.readline()
                if line:
                    click.echo(line, nl=False)
                else:
                    time.sleep(0.2)
    except KeyboardInterrupt:
        click.echo("\n--- Stopped following logs ---")


def _get_or_start_local_instance(app_port=None, api_port=None, data_dir=None):
    """Return a running local instance, starting one if needed."""
    status = get_local_status()
    if status["running"]:
        return status["instance"], False

    result = start_local(app_port=app_port, api_port=api_port, data_dir=data_dir)
    return result["instance"], not result["already_running"]


@click.group()
@click.version_option()
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
def main(ctx, debug):
    """Gradient Explorer CLI"""
    ctx.ensure_object(dict)
    ctx.obj["DEBUG"] = debug


@main.command()
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
def login(ctx, debug):
    """Log in to Gradient Explorer."""
    auth.login_flow(debug=debug or ctx.obj.get("DEBUG", False))


@main.group()
def local():
    """Manage a local Gradient Explorer instance."""


@local.command("start")
@click.option("--app-port", type=int, default=None, help="Frontend port")
@click.option("--api-port", type=int, default=None, help="API port")
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Directory for local API state",
)
@click.option("-f", "--follow", is_flag=True, help="Follow server logs after starting")
def local_start_command(app_port, api_port, data_dir, follow):
    """Start the bundled local frontend and API in the background."""
    instance, started = _get_or_start_local_instance(
        app_port=app_port,
        api_port=api_port,
        data_dir=data_dir,
    )

    if started:
        click.echo("Started local Gradient Explorer.")
    else:
        click.echo("Local Gradient Explorer is already running.")

    _info_box("Local Gradient Explorer", [
        ("Frontend", instance.web_base_url),
        ("API", instance.api_base_url),
        ("Data dir", instance.data_dir),
        ("PID", str(instance.pid)),
    ])

    if follow:
        _follow_log()


@local.command("status")
@click.option("-f", "--follow", is_flag=True, help="Follow server logs")
def local_status_command(follow):
    """Show the status of the local Gradient Explorer instance."""
    status = get_local_status()
    if not status["running"]:
        if status.get("stale"):
            instance = status["instance"]
            click.echo("Local Gradient Explorer process exists, but the server is not responding.")
            _info_box("Stale Instance", [
                ("PID", str(instance.pid)),
                ("Frontend", instance.web_base_url),
                ("API", instance.api_base_url),
            ])
            return
        click.echo("No local Gradient Explorer instance is running.")
        return

    instance = status["instance"]
    click.echo("Local Gradient Explorer is running.")
    _info_box("Local Gradient Explorer", [
        ("Frontend", instance.web_base_url),
        ("API", instance.api_base_url),
        ("Data dir", instance.data_dir),
        ("PID", str(instance.pid)),
        ("Started", instance.started_at),
    ])

    if follow:
        _follow_log()


@local.command("open")
def local_open_command():
    """Open the local Gradient Explorer frontend in a browser."""
    import webbrowser

    instance, started = _get_or_start_local_instance()
    if started:
        click.echo("Started local Gradient Explorer.")
        click.echo(f"Backend API: {instance.api_base_url}")

    opened = False
    try:
        opened = webbrowser.open(instance.web_base_url)
    except Exception:
        pass

    if opened:
        click.echo(f"Opened {instance.web_base_url}")
        return

    click.echo("Could not open browser automatically.")
    click.echo(f"Frontend URL: {instance.web_base_url}")


@local.command("stop")
def local_stop_command():
    """Stop the local Gradient Explorer instance."""
    result = stop_local()
    if not result["stopped"]:
        click.echo("No local Gradient Explorer instance is running.")
        return

    click.echo("Stopped local Gradient Explorer.")


@local.command("sync")
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Directory containing the local store to sync",
)
@click.option("--once", is_flag=True, help="Run one sync pass and exit")
@click.option("--interval", type=float, default=DEFAULT_SYNC_INTERVAL_S, show_default=True, help="Watch poll interval in seconds")
def local_sync_command(data_dir, once, interval):
    """Sync local runs and tensors to the hosted Gradient Explorer account."""
    if interval <= 0:
        raise click.ClickException("--interval must be greater than zero.")
    run_local_sync(data_dir=data_dir, once=once, interval=interval)


@main.command(name="_serve-local-instance", hidden=True)
@click.option("--app-port", type=int, required=True)
@click.option("--api-port", type=int, required=True)
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    required=True,
)
@click.option("--instance-id", type=str, required=True)
@click.option("--token", type=str, required=True)
def serve_local_instance_command(app_port, api_port, data_dir, instance_id, token):
    run_local_service(
        app_port=app_port,
        api_port=api_port,
        data_dir=data_dir,
        instance_id=instance_id,
        token=token,
    )


if __name__ == "__main__":
    main()
