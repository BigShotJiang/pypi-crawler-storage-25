import sys
import unittest
from unittest.mock import MagicMock, patch
import gradexp.client as client
import gradexp


class FakeThread:
    def __init__(self, *args, **kwargs):
        self._alive = False

    def start(self):
        self._alive = False

    def is_alive(self):
        return self._alive

    def join(self):
        return None


class TestStatusUpdates(unittest.TestCase):
    def setUp(self):
        # Reset client state
        client._client = client.Client()
        client._client.api_key = "fake_key" # Mock logged in
        client._client.run_id = "fake_run_id"
        client._client._api_base_url = "https://api.test.url"
        client._client.active = True
        # Mock requests
        self.mock_session = MagicMock()
        client._client._session = self.mock_session
        
        # Mock auth.BASE_URL
        self.auth_patcher = patch('gradexp.auth.BASE_URL', "test.url")
        self.auth_patcher.start()

    def tearDown(self):
        self.auth_patcher.stop()

    def test_finish_complete(self):
        client._client.finish() # Default status="complete"
        self.mock_session.patch.assert_called_with(
            "https://api.test.url/api/v1/runs/fake_run_id",
            headers={"Authorization": "Bearer fake_key", "Content-Type": "application/json"},
            json={"status": "complete"},
        )

    def test_finish_stopped(self):
        client._client.finish(status="stopped")
        self.mock_session.patch.assert_called_with(
            "https://api.test.url/api/v1/runs/fake_run_id",
            headers={"Authorization": "Bearer fake_key", "Content-Type": "application/json"},
            json={"status": "stopped"},
        )
        
    def test_excepthook_installed(self):
        # Check if excepthook wraps the original
        original = sys.excepthook
        
        # Force reinstall for test (since init might have been called or not)
        client.init(project_name="test", run_name="test")
        
        self.assertNotEqual(sys.excepthook, original)
        self.assertTrue(hasattr(sys.excepthook, "__code__")) # simple check
        
        # Test that calling it triggers finish("stopped")
        client._client.finish = MagicMock()
        try:
            # We don't want to actually crash, just call the hook
            sys.excepthook(RuntimeError, RuntimeError("test"), None)
        except:
            pass
            
        client._client.finish.assert_called_with("stopped")

    def test_init_resets_progress_counters_for_new_run(self):
        init_response = MagicMock()
        init_response.raise_for_status.return_value = None
        init_response.json.return_value = {
            "run_id": "new_run_id",
            "project_id": "new_project_id",
        }

        fresh_client = client.Client()
        fresh_client._bytes_uploaded = 12345
        fresh_client._tensors_uploaded = 67
        fresh_client._total_tensors_queued = 89
        fresh_client._upload_start_time = 123.0

        with patch("gradexp.auth.load_token", return_value="fake_key"), \
             patch("gradexp.auth.get_api_base_url", return_value="https://api.test.url"), \
             patch("gradexp.auth.get_web_base_url", return_value="https://app.test.url"), \
             patch("gradexp.client.threading.Thread", FakeThread), \
             patch("gradexp.client.atexit.register"), \
             patch.object(fresh_client._session, "post", return_value=init_response):
            fresh_client.init(project_name="test-project", run_name="test-run")

        self.assertEqual(fresh_client._bytes_uploaded, 0)
        self.assertEqual(fresh_client._tensors_uploaded, 0)
        self.assertEqual(fresh_client._total_tensors_queued, 0)
        self.assertIsNone(fresh_client._upload_start_time)

if __name__ == '__main__':
    # Need to prevent init from running real network requests during import/setup if possible
    # But init is only called explicitly.
    unittest.main()
