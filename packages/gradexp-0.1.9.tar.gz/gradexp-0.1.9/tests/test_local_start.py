import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import click
import requests
from click.testing import CliRunner

from gradexp import auth, local_instance, local_start
from gradexp.cli import main


class FakeSocket:
    def __init__(self, bind_behavior, fallback_port=45678):
        self.bind_behavior = bind_behavior
        self.fallback_port = fallback_port
        self.bound_port = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def setsockopt(self, level, option, value):
        return None

    def bind(self, address):
        _, port = address
        self.bound_port = port
        outcome = self.bind_behavior(port)
        if outcome is not None:
            raise outcome

    def getsockname(self):
        if self.bound_port == 0:
            return ("127.0.0.1", self.fallback_port)
        return ("127.0.0.1", self.bound_port)

    def close(self):
        return None


class TestLocalStartPortSelection(unittest.TestCase):
    def test_bundled_frontend_exists(self):
        app_dir = local_start._bundled_frontend_dir()
        self.assertTrue((app_dir / "index.html").exists())

    def test_find_available_port_pair_prefers_default_ports_before_random_ports(self):
        with patch(
            "gradexp.local_instance.socket.socket",
            side_effect=lambda *args, **kwargs: FakeSocket(lambda port: None, fallback_port=45678),
        ):
            ports = local_instance.find_available_port_pair(search_window=5)

        self.assertEqual(ports, (local_instance.DEFAULT_APP_PORT, local_instance.DEFAULT_API_PORT))

    def test_find_available_port_pair_prefers_adjacent_ports(self):
        def bind_behavior(port):
            if port in {4100, 4101}:
                return OSError("busy")
            return None

        with patch(
            "gradexp.local_instance.socket.socket",
            side_effect=lambda *args, **kwargs: FakeSocket(bind_behavior),
        ):
            ports = local_instance.find_available_port_pair(preferred_port=4100, search_window=5)

        self.assertEqual(ports, (4102, 4103))

    def test_find_available_port_pair_reports_permission_errors_cleanly(self):
        def bind_behavior(port):
            return PermissionError("blocked")

        with patch(
            "gradexp.local_instance.socket.socket",
            side_effect=lambda *args, **kwargs: FakeSocket(bind_behavior),
        ):
            with self.assertRaises(PermissionError) as context:
                local_instance.find_available_port_pair(preferred_port=4100, search_window=2)

        self.assertIn("binding loopback sockets is not permitted", str(context.exception))


class TestLocalLifecycle(unittest.TestCase):
    def test_local_cli_start_status_stop_and_auto_discovery(self):
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as home_dir:
            env_patch = {
                "HOME": home_dir,
            }
            with patch.dict(os.environ, env_patch, clear=False):
                start_result = runner.invoke(main, ["local", "start"])
                self.assertEqual(start_result.exit_code, 0, start_result.output)
                self.assertIn("Started local Gradient Explorer.", start_result.output)

                instance = local_instance.load_local_instance()
                self.assertIsNotNone(instance)

                try:
                    version_response = requests.get(f"{instance.api_base_url}/version", timeout=1.0)
                    self.assertEqual(version_response.status_code, 200)
                    version_payload = version_response.json()
                    self.assertEqual(version_payload["mode"], "local")
                    self.assertEqual(version_payload["instance_id"], instance.instance_id)

                    app_response = requests.get(instance.web_base_url, timeout=1.0)
                    self.assertEqual(app_response.status_code, 200)
                    self.assertIn("window.__GRADEXP_RUNTIME__", app_response.text)

                    self.assertEqual(auth.get_api_base_url(), instance.api_base_url)
                    self.assertEqual(auth.get_web_base_url(), instance.web_base_url)
                    self.assertEqual(auth.load_token(), local_instance.DEFAULT_LOCAL_TOKEN)

                    status_result = runner.invoke(main, ["local", "status"])
                    self.assertEqual(status_result.exit_code, 0, status_result.output)
                    self.assertIn("Local Gradient Explorer is running.", status_result.output)
                    self.assertIn(instance.api_base_url, status_result.output)
                finally:
                    stop_result = runner.invoke(main, ["local", "stop"])
                    self.assertEqual(stop_result.exit_code, 0, stop_result.output)
                    self.assertIn("Stopped local Gradient Explorer.", stop_result.output)

                self.assertIsNone(local_instance.load_local_instance())
                self.assertFalse(local_instance.get_local_instance_path().exists())

    def test_local_open_starts_instance_when_not_running(self):
        runner = CliRunner()
        instance = SimpleNamespace(
            web_base_url="http://127.0.0.1:3000",
            api_base_url="http://127.0.0.1:3001",
        )

        with patch("gradexp.cli.get_local_status", return_value={"running": False}), \
             patch("gradexp.cli.start_local", return_value={"already_running": False, "instance": instance}) as mock_start, \
             patch("webbrowser.open", return_value=True) as mock_open:
            result = runner.invoke(main, ["local", "open"])

        self.assertEqual(result.exit_code, 0, result.output)
        mock_start.assert_called_once_with(app_port=None, api_port=None, data_dir=None)
        mock_open.assert_called_once_with(instance.web_base_url)
        self.assertIn("Started local Gradient Explorer.", result.output)
        self.assertIn(f"Backend API: {instance.api_base_url}", result.output)
        self.assertIn(f"Opened {instance.web_base_url}", result.output)

    def test_local_open_reports_frontend_url_when_browser_open_fails(self):
        runner = CliRunner()
        instance = SimpleNamespace(web_base_url="http://127.0.0.1:3000")

        with patch("gradexp.cli.get_local_status", return_value={"running": True, "instance": instance}), \
             patch("webbrowser.open", return_value=False) as mock_open:
            result = runner.invoke(main, ["local", "open"])

        self.assertEqual(result.exit_code, 0, result.output)
        mock_open.assert_called_once_with(instance.web_base_url)
        self.assertIn("Could not open browser automatically.", result.output)
        self.assertIn(f"Frontend URL: {instance.web_base_url}", result.output)


if __name__ == "__main__":
    unittest.main()
