import io
import tempfile
import unittest
from contextlib import redirect_stderr
from unittest.mock import patch

from gradexp.local_server import LocalAPIHandler, LocalBaseHandler, LocalStore


class TestLocalStoreRunUpdates(unittest.TestCase):
    def test_update_run_refreshes_last_activity_at(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = LocalStore(tmp_dir, "gradexp-local-token")
            created_run = store.create_run("project-a", "run-a")
            run_id = created_run["payload"]["run_id"]
            original_run = store._get_run(run_id)
            original_last_activity = original_run["lastActivityAt"]

            with patch("gradexp.local_server._utc_now", return_value="2026-03-24T12:00:00.000Z"):
                result = store.update_run(run_id, {"status": "complete"})

            self.assertEqual(result["status"], 200)
            updated_run = store._get_run(run_id)
            self.assertEqual(updated_run["status"], "complete")
            self.assertEqual(updated_run["lastActivityAt"], "2026-03-24T12:00:00.000Z")
            self.assertNotEqual(updated_run["lastActivityAt"], original_last_activity)
            self.assertEqual(
                store.list_runs("project-a")["lastModified"],
                "2026-03-24T12:00:00.000Z",
            )

    def test_create_tensor_canonicalizes_bf16_and_validates_step_size(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = LocalStore(tmp_dir, "gradexp-local-token")
            created_run = store.create_run("project-a", "run-a")
            run_id = created_run["payload"]["run_id"]

            created_tensor = store.create_tensor(run_id, {
                "name": "weights",
                "dtype": "bf16",
                "shape": [3],
            })
            self.assertEqual(created_tensor["status"], 201)

            tensor_id = created_tensor["payload"]["tensor_id"]
            tensor = store._get_tensor(tensor_id)
            self.assertEqual(tensor["dtype"], "bfloat16")

            mismatch = store.log_tensor_step(tensor_id, 0, b"\x00\x01\x02")
            self.assertEqual(mismatch["status"], 400)
            self.assertIn("expects 6 bytes", mismatch["payload"]["error"])

            correct = store.log_tensor_step(tensor_id, 0, b"\x00\x01\x02\x03\x04\x05")
            self.assertEqual(correct["status"], 200)


class TestLocalServerLogging(unittest.TestCase):
    def test_log_message_writes_default_request_log(self):
        handler = LocalBaseHandler.__new__(LocalBaseHandler)
        handler.requestline = "GET /version HTTP/1.1"
        handler.address_string = lambda: "127.0.0.1"
        handler.log_date_time_string = lambda: "03/Apr/2026 12:00:00"

        stderr = io.StringIO()
        with redirect_stderr(stderr):
            handler.log_message('"%s" %s %s', handler.requestline, "200", "-")

        output = stderr.getvalue()
        self.assertIn("GET /version HTTP/1.1", output)
        self.assertIn("200", output)

    def test_handle_prints_traceback_for_unhandled_exception(self):
        handler = LocalAPIHandler.__new__(LocalAPIHandler)
        handler._dispatch = lambda method: (_ for _ in ()).throw(RuntimeError("boom"))
        handler._send_error = lambda status_code, message: None

        stderr = io.StringIO()
        with redirect_stderr(stderr):
            handler._handle("GET")

        output = stderr.getvalue()
        self.assertIn("Traceback", output)
        self.assertIn("RuntimeError: boom", output)


if __name__ == "__main__":
    unittest.main()
