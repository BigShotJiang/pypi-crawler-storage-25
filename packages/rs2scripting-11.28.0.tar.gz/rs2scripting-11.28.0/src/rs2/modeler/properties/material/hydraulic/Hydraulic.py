from rs2.modeler.properties.propertyProxy import PropertyProxy
from rs2._common.Client import Client
from enum import Enum, auto
from typing import List
from rs2.modeler.properties.PropertyEnums import *
from rs2.modeler.properties.material.hydraulic.FEAGroundwater.FEAGroundwater import FEAGroundwater
from rs2.modeler.properties.material.hydraulic.StaticGroundwater import StaticGroundwater
from rs2.modeler.properties.material.hydraulic.HydroDistribution import HydroDistribution
from rs2._common.ProxyObject import ProxyObject
from rs2.modeler.properties.AbsoluteStageFactorGettersInterface import AbsoluteStageFactorGettersInterface
class HydraulicStageFactor(ProxyObject):
	def __init__(self, client : Client, ID, propertyID):
		super().__init__(client, ID)
		self.propertyID = propertyID
	def getBiotsCoefficientFactor(self) -> float:
		return self._callFunction("getDoubleFactor", ["MP_BIOT_COEFFICIENT", self.propertyID], proxyArgumentIndices=[1])
	def getBiotModeFactor(self) -> str:
		return eBiotCoefficients(self._callFunction("getBiotModeFactor", []))
	def getMaterialBehaviourFactor(self) -> str:
		return MaterialBehaviours(self._callFunction("getMaterialBehaviourFactor", []))
class HydraulicDefinedStageFactor(HydraulicStageFactor):
	def __init__(self, client : Client, ID, propertyID):
		super().__init__(client, ID, propertyID)
	def setBiotsCoefficientFactor(self, value: float):
		return self._callFunction("setDoubleFactor", ["MP_BIOT_COEFFICIENT", value, self.propertyID], proxyArgumentIndices=[2])
	def setBiotModeFactor(self, biotMode: eBiotCoefficients):
		return self._callFunction("setBiotModeFactor", [biotMode.value])
	def setMaterialBehaviourFactor(self, materialBehavior: MaterialBehaviours):
		return self._callFunction("setMaterialBehaviourFactor", [materialBehavior.value])
class Hydraulic(PropertyProxy):
	"""
	Attributes:
		stageFactorInterface (AbsoluteStageFactorGettersInterface[HydraulicDefinedStageFactor, HydraulicStageFactor]): Reference object for modifying stage factor property.
		StaticGroundwater (StaticGroundwater): Reference object for modifying property.
		HydroDistribution (HydroDistribution): Reference object for modifying property.
		FEAGroundwater (FEAGroundwater): Reference object for modifying property.

	Examples:
		:ref:`Hydraulic Property Example`
	"""
	def __init__(self, client : Client, ID, documentProxyID, stageFactorInterfaceID):
		super().__init__(client, ID, documentProxyID)
		self.stageFactorInterface = AbsoluteStageFactorGettersInterface[HydraulicDefinedStageFactor, HydraulicStageFactor](self._client, stageFactorInterfaceID, ID, HydraulicDefinedStageFactor, HydraulicStageFactor)
		self.StaticGroundwater = StaticGroundwater(client, ID, documentProxyID, stageFactorInterfaceID)
		self.HydroDistribution = HydroDistribution(client, ID, documentProxyID, stageFactorInterfaceID)
		self.FEAGroundwater = FEAGroundwater(client, ID, documentProxyID, stageFactorInterfaceID)
	def getMaterialBehaviour(self) -> MaterialBehaviours:
		return MaterialBehaviours(self._getEnumEMaterialBehavioursProperty("MP_MATERIAL_BEHAVIOUR"))
	def setMaterialBehaviour(self, value: MaterialBehaviours):
		return self._setEnumEMaterialBehavioursProperty("MP_MATERIAL_BEHAVIOUR", value)
	def getFluidBulkModulus(self) -> float:
		return self._getDoubleProperty("MP_FLUID_BULK_MODULUS")
	def setFluidBulkModulus(self, value: float):
		return self._setDoubleProperty("MP_FLUID_BULK_MODULUS", value)
	def getBiotsCoefficientCalculationMethod(self) -> eBiotCoefficients:
		return eBiotCoefficients(self._getEnumEBiotCoefficientsProperty("MP_BIOT_MODE"))
	def setBiotsCoefficientCalculationMethod(self, value: eBiotCoefficients):
		return self._setEnumEBiotCoefficientsProperty("MP_BIOT_MODE", value)
	def getBiotsCoefficient(self) -> float:
		return self._getDoubleProperty("MP_BIOT_COEFFICIENT")
	def setBiotsCoefficient(self, value: float):
		return self._setDoubleProperty("MP_BIOT_COEFFICIENT", value)
	def getAccountForWaterContentInCompressibility(self) -> bool:
		return self._getBoolProperty("MP_USE_WC_IN_COMP_COUPLED")
	def setAccountForWaterContentInCompressibility(self, value: bool):
		return self._setBoolProperty("MP_USE_WC_IN_COMP_COUPLED", value)
