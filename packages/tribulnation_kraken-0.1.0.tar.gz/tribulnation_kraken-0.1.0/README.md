# Tribulnation Kraken SDK

> An SDK to connect Kraken with the Tribulnation ecosystem.

🚧 Under construction.