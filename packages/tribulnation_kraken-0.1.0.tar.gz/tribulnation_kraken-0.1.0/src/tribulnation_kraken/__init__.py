"""
### Tribulnation Kraken
> An SDK to connect Kraken with the Tribulnation ecosystem.

- Details
"""