# pyconverters_cairn_xml

[![license](https://img.shields.io/github/license/oterrier/pyconverters_cairn_xml)](https://github.com/oterrier/pyconverters_cairn_xml/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_cairn_xml/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_cairn_xml/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_cairn_xml)](https://codecov.io/gh/oterrier/pyconverters_cairn_xml)
[![docs](https://img.shields.io/readthedocs/pyconverters_cairn_xml)](https://pyconverters_cairn_xml.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_cairn_xml)](https://pypi.org/project/pyconverters_cairn_xml/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_cairn_xml)](https://pypi.org/project/pyconverters_cairn_xml/)

A converter plugin for parsing Cairn.info XML article files into structured documents. It extracts article content, metadata (authors, affiliations, disciplines, keywords, etc.), bibliography, and notes from Cairn.info's proprietary XML format.

## Installation

You can simply `pip install pyconverters_cairn_xml`.

## Developing

### Prerequisites

You will need to install [uv](https://docs.astral.sh/uv/) for package management:

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_cairn_xml
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
