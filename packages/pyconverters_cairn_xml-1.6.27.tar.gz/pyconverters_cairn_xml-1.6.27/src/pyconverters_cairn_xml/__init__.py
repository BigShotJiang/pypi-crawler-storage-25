"""Cairn.info XML converter."""

__version__ = "1.6.27"
