# osmocom

Open Source Mobile Communications — GSM/UMTS/LTE protocol utilities.

## Installation

```bash
pip install osmocom
