from setuptools import setup, find_packages

setup(
    name="osmocomtest",
    version="0.1.0",
    packages=find_packages(),
    description="Open Source Mobile Communications — GSM/UMTS/LTE protocol utilities",
    author="mnkzt",
    author_email="fadlya0929@gmail.com",
    url="https://github.com/noz-co-id/MNSF",
    python_requires=">=3.8",
)
