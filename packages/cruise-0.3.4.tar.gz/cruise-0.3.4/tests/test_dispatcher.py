"""Tests for the agent dispatcher."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from claude_agent_sdk import AssistantMessage, ResultMessage
from claude_agent_sdk.types import (
    PermissionResultAllow,
    PermissionResultDeny,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
)

from cruise.dispatcher import _make_can_use_tool_callback, run_agent
from cruise.linear import Comment, Issue


def _make_issue(id="issue-1", identifier="PROJ-1", title="Test") -> Issue:
    return Issue(id=id, identifier=identifier, title=title, state="In Progress")


def _make_result_message(success=True, num_turns=3, cost=0.01) -> ResultMessage:
    return ResultMessage(
        subtype="success" if success else "error",
        session_id="sess-abc",
        total_cost_usd=cost,
        usage={},
        duration_ms=1000,
        duration_api_ms=800,
        num_turns=num_turns,
        is_error=not success,
        result=None if success else "Error occurred",
        stop_reason="end_turn" if success else "error",
    )


class TestRunAgent:
    @pytest.mark.asyncio
    async def test_run_agent_success(self, tmp_path):
        """run_agent returns AgentResult with success=True on a clean run."""
        result_msg = _make_result_message()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
            )

        assert result.success is True
        assert result.num_turns == 3

    @pytest.mark.asyncio
    async def test_run_agent_without_images_sends_plain_string(self, tmp_path):
        """When no images are provided, the initial query is a plain string."""
        result_msg = _make_result_message()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            await run_agent(_make_issue(), "My prompt", tmp_path)

        initial_arg = mock_client.query.call_args_list[0][0][0]
        assert isinstance(initial_arg, str)
        assert initial_arg == "My prompt"

    @pytest.mark.asyncio
    async def test_run_agent_with_images_sends_async_generator(self, tmp_path):
        """When images are provided, initial query is an async generator (not plain string)."""
        result_msg = _make_result_message()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield result_msg

        mock_client.receive_response = mock_receive_response

        images = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": "abc123",
                },
            }
        ]

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(), "Test prompt", tmp_path, images=images
            )

        assert result.success is True
        initial_arg = mock_client.query.call_args_list[0][0][0]
        # Should be an async generator, not a plain string
        assert hasattr(initial_arg, "__aiter__"), (
            "Expected an async generator when images are provided, got: "
            f"{type(initial_arg)}"
        )

    @pytest.mark.asyncio
    async def test_run_agent_with_images_message_contains_text_and_image_blocks(
        self, tmp_path
    ):
        """The async generator produced for images yields text + image content blocks."""
        result_msg = _make_result_message()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        captured_args = []

        async def capture_query(arg):
            captured_args.append(arg)

        mock_client.query = capture_query

        async def mock_receive_response():
            yield result_msg

        mock_client.receive_response = mock_receive_response

        images = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": "jpeg_data",
                },
            }
        ]

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            await run_agent(
                _make_issue(), "Describe this image", tmp_path, images=images
            )

        assert len(captured_args) == 1
        gen = captured_args[0]
        # Consume the generator to get the message
        messages = [msg async for msg in gen]
        assert len(messages) == 1
        msg = messages[0]
        assert msg["type"] == "user"
        content = msg["message"]["content"]
        # Should have at least one text block and one image block
        types = [block["type"] for block in content]
        assert "text" in types
        assert "image" in types
        text_block = next(b for b in content if b["type"] == "text")
        assert "Describe this image" in text_block["text"]

    @pytest.mark.asyncio
    async def test_run_agent_handles_exception(self, tmp_path):
        """run_agent returns error result when the client raises."""
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock(side_effect=RuntimeError("connection failed"))

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
            )

        assert result.success is False
        assert "connection failed" in result.error


def _make_ask_user_question_input(questions=None):
    """Build a sample AskUserQuestion input_data dict."""
    if questions is None:
        questions = [
            {
                "question": "Which database should I use?",
                "header": "Database",
                "options": [
                    {"label": "PostgreSQL", "description": "Relational DB"},
                    {"label": "SQLite", "description": "Embedded DB"},
                ],
                "multiSelect": False,
            }
        ]
    return {"questions": questions}


class TestMakeCanUseToolCallback:
    @pytest.mark.asyncio
    async def test_non_ask_user_question_tool_is_allowed(self):
        """Non-AskUserQuestion tools are auto-allowed without calling Linear."""
        mock_linear = AsyncMock()
        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=1,
            seen_comment_ids=set(),
        )

        result = await callback("Bash", {"command": "ls"}, MagicMock())

        assert isinstance(result, PermissionResultAllow)
        mock_linear.post_comment.assert_not_called()

    @pytest.mark.asyncio
    async def test_ask_user_question_posts_comment_to_linear(self):
        """AskUserQuestion triggers posting the formatted question to Linear."""
        mock_linear = AsyncMock()
        mock_linear.post_comment = AsyncMock(return_value="posted-comment-id")
        mock_linear.fetch_issue_comments = AsyncMock(
            side_effect=[
                # Before posting: empty
                [],
                # After posting: include the reply
                [
                    Comment(id="posted-comment-id", body="🤖 Claude asks:..."),
                    Comment(id="reply-id", body="Use PostgreSQL", parent_id="posted-comment-id"),
                ],
            ]
        )

        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=5,
            seen_comment_ids=set(),
        )

        result = await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        # Should have posted the question
        mock_linear.post_comment.assert_called_once()
        call_args = mock_linear.post_comment.call_args
        posted_body = call_args[0][1] if call_args[0] else call_args[1].get("body", "")
        assert "🤖 Claude asks:" in posted_body
        assert "Which database should I use?" in posted_body

        # Result should be PermissionResultAllow with the answer
        assert isinstance(result, PermissionResultAllow)

    @pytest.mark.asyncio
    async def test_ask_user_question_returns_reply_as_answer(self):
        """Reply to Claude's question comment is returned as the answer."""
        mock_linear = AsyncMock()
        mock_linear.post_comment = AsyncMock(return_value="q-comment-id")
        mock_linear.fetch_issue_comments = AsyncMock(
            side_effect=[
                # Pre-post snapshot
                [],
                # First poll: reply has appeared
                [
                    Comment(id="q-comment-id", body="🤖 Claude asks:..."),
                    Comment(id="answer-id", body="PostgreSQL please", parent_id="q-comment-id"),
                ],
            ]
        )

        seen: set[str] = set()
        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=5,
            seen_comment_ids=seen,
        )

        result = await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        assert isinstance(result, PermissionResultAllow)
        answers = result.updated_input.get("answers", {})
        assert "PostgreSQL please" in list(answers.values())[0]

    @pytest.mark.asyncio
    async def test_ask_user_question_marks_reply_as_seen(self):
        """The answer comment ID is added to seen_comment_ids to prevent re-injection."""
        mock_linear = AsyncMock()
        mock_linear.post_comment = AsyncMock(return_value="q-id")
        mock_linear.fetch_issue_comments = AsyncMock(
            side_effect=[
                [],
                [
                    Comment(id="q-id", body="🤖 Claude asks:..."),
                    Comment(id="answer-id", body="Use SQLite", parent_id="q-id"),
                ],
            ]
        )

        seen: set[str] = set()
        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=5,
            seen_comment_ids=seen,
        )

        await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        # Both the question comment and the answer comment should be in seen
        assert "q-id" in seen
        assert "answer-id" in seen

    @pytest.mark.asyncio
    async def test_ask_user_question_timeout_returns_default_answer(self):
        """When no reply arrives before timeout, Claude continues with a default."""
        mock_linear = AsyncMock()
        mock_linear.post_comment = AsyncMock(return_value="q-id")
        # Always return just the question, never a reply
        mock_linear.fetch_issue_comments = AsyncMock(
            return_value=[Comment(id="q-id", body="🤖 Claude asks:...")]
        )

        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=0,  # Immediate timeout for test speed
            seen_comment_ids=set(),
        )

        result = await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        # Should still allow (not deny) — Claude continues with default
        assert isinstance(result, PermissionResultAllow)
        # Updated input should include a timeout marker or empty-ish answer
        assert result.updated_input is not None

    @pytest.mark.asyncio
    async def test_ask_user_question_no_linear_client_allows_with_default(self):
        """When no linear_client is provided, allow with default answer immediately."""
        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=None,
            agent_session_id="",
            question_timeout_seconds=5,
            seen_comment_ids=set(),
        )

        result = await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        assert isinstance(result, PermissionResultAllow)

    @pytest.mark.asyncio
    async def test_ask_user_question_detects_new_top_level_comment_as_answer(self):
        """A new top-level comment (not a reply) also counts as an answer."""
        mock_linear = AsyncMock()
        mock_linear.post_comment = AsyncMock(return_value="q-id")
        mock_linear.fetch_issue_comments = AsyncMock(
            side_effect=[
                # Pre-post: empty
                [],
                # First poll: new top-level comment appeared
                [
                    Comment(id="q-id", body="🤖 Claude asks:..."),
                    Comment(id="new-comment-id", body="Go with PostgreSQL", parent_id=None),
                ],
            ]
        )

        seen: set[str] = set()
        callback = _make_can_use_tool_callback(
            issue=_make_issue(),
            linear_client=mock_linear,
            agent_session_id="",
            question_timeout_seconds=5,
            seen_comment_ids=seen,
        )

        result = await callback("AskUserQuestion", _make_ask_user_question_input(), MagicMock())

        assert isinstance(result, PermissionResultAllow)
        answers = result.updated_input.get("answers", {})
        assert "Go with PostgreSQL" in list(answers.values())[0]


class TestFinalMessage:
    @pytest.mark.asyncio
    async def test_final_text_message_captured(self, tmp_path):
        """The last non-tool-call text message from the assistant is stored in result.final_message."""
        result_msg = _make_result_message()
        text_block = TextBlock(text="Done! I've opened PR #5 and all tests pass.")
        assistant_msg = AssistantMessage(
            content=[text_block],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield assistant_msg
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
            )

        assert result.final_message == "Done! I've opened PR #5 and all tests pass."

    @pytest.mark.asyncio
    async def test_tool_only_message_not_captured_as_final(self, tmp_path):
        """A message that contains only tool-use blocks is not captured as final_message."""
        result_msg = _make_result_message()
        tool_block = ToolUseBlock(id="tu-1", name="Bash", input={"command": "ls"})
        assistant_msg = AssistantMessage(
            content=[tool_block],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield assistant_msg
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
            )

        assert result.final_message is None

    @pytest.mark.asyncio
    async def test_last_text_message_wins(self, tmp_path):
        """When multiple text messages appear, only the last one is kept as final_message."""
        result_msg = _make_result_message()
        first_text = AssistantMessage(
            content=[TextBlock(text="Starting work...")],
            model="claude-3-5-sonnet",
        )
        last_text = AssistantMessage(
            content=[TextBlock(text="All done, PR opened.")],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield first_text
            yield last_text
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
            )

        assert result.final_message == "All done, PR opened."


class TestOnEventCallback:
    @pytest.mark.asyncio
    async def test_on_event_called_with_thinking_trace(self, tmp_path):
        """on_event callback is invoked with the text of ThinkingBlock content."""
        result_msg = _make_result_message()
        thinking_block = ThinkingBlock(thinking="I should check the tests first", signature="sig")
        assistant_msg = AssistantMessage(
            content=[thinking_block],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield assistant_msg
            yield result_msg

        mock_client.receive_response = mock_receive_response

        events: list[str] = []
        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
                on_event=events.append,
            )

        assert any("I should check the tests first" in e for e in events)

    @pytest.mark.asyncio
    async def test_on_event_called_for_tool_use(self, tmp_path):
        """on_event is called with 'tool:<ToolName>' when the assistant emits a tool-use block."""
        result_msg = _make_result_message()
        tool_block = ToolUseBlock(id="tu-1", name="Bash", input={"command": "ls"})
        assistant_msg = AssistantMessage(
            content=[tool_block],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield assistant_msg
            yield result_msg

        mock_client.receive_response = mock_receive_response

        events: list[str] = []
        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
                on_event=events.append,
            )

        assert any(e == "tool:Bash" for e in events)

    @pytest.mark.asyncio
    async def test_on_event_none_does_not_crash(self, tmp_path):
        """Passing on_event=None is safe and doesn't raise."""
        result_msg = _make_result_message()
        thinking_block = ThinkingBlock(thinking="thinking...", signature="sig")
        assistant_msg = AssistantMessage(
            content=[thinking_block],
            model="claude-3-5-sonnet",
        )

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.query = AsyncMock()

        async def mock_receive_response():
            yield assistant_msg
            yield result_msg

        mock_client.receive_response = mock_receive_response

        with patch("cruise.dispatcher.ClaudeSDKClient", return_value=mock_client):
            result = await run_agent(
                _make_issue(),
                "Test prompt",
                tmp_path,
                on_event=None,
            )

        assert result.success is True
