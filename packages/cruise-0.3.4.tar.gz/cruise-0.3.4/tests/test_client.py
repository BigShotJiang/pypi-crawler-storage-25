"""Tests for the WebSocket cloud client."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cruise.client import CloudClient, _dict_to_dispatch, _get_git_remote
from cruise.protocol import (
    AgentStartedMessage,
    CancelMessage,
    DispatchMessage,
    HeartbeatMessage,
    QuestionReplyMessage,
)


class TestParseMessage:
    def setup_method(self):
        self.client = CloudClient("wss://test.example/ws", "tok_123", "/tmp/repo")

    def test_parse_dispatch(self):
        raw = json.dumps({
            "type": "dispatch",
            "issue": {
                "id": "uuid-1",
                "identifier": "SUP-42",
                "title": "Fix bug",
                "state": "Todo",
                "description": "Something broken",
                "url": "https://linear.app/SUP-42",
                "labels": ["agent"],
                "branch_name": "aryan/sup-42",
            },
            "comments": [{"body": "Focus on X", "created_at": "2026-04-04"}],
            "images": [],
        })
        msg = self.client._parse_message(raw)
        assert isinstance(msg, DispatchMessage)
        assert msg.issue.identifier == "SUP-42"
        assert msg.issue.title == "Fix bug"
        assert len(msg.comments) == 1
        assert msg.comments[0].body == "Focus on X"

    def test_parse_cancel(self):
        raw = json.dumps({"type": "cancel", "issue_id": "uuid-1", "reason": "Done"})
        msg = self.client._parse_message(raw)
        assert isinstance(msg, CancelMessage)
        assert msg.issue_id == "uuid-1"
        assert msg.reason == "Done"

    def test_parse_question_reply(self):
        raw = json.dumps({"type": "question_reply", "issue_id": "uuid-1", "reply": "Use existing"})
        msg = self.client._parse_message(raw)
        assert isinstance(msg, QuestionReplyMessage)
        assert msg.reply == "Use existing"

    def test_parse_unknown_type(self):
        raw = json.dumps({"type": "unknown_thing", "data": 123})
        msg = self.client._parse_message(raw)
        assert msg is None

    def test_parse_invalid_json(self):
        msg = self.client._parse_message("not json at all")
        assert msg is None


class TestSendHelpers:
    def setup_method(self):
        self.client = CloudClient("wss://test.example/ws", "tok_123", "/tmp/repo")

    @pytest.mark.asyncio
    async def test_send_agent_started(self):
        await self.client.send_agent_started("uuid-1", "ses_abc")
        msg = self.client._send_queue.get_nowait()
        assert msg["type"] == "agent_started"
        assert msg["issue_id"] == "uuid-1"
        assert msg["session_id"] == "ses_abc"

    @pytest.mark.asyncio
    async def test_send_agent_completed(self):
        await self.client.send_agent_completed(
            issue_id="uuid-1", session_id="ses_abc", success=True,
            cost_usd=0.42, num_turns=15, duration_ms=180000, hit_turn_limit=False,
        )
        msg = self.client._send_queue.get_nowait()
        assert msg["type"] == "agent_completed"
        assert msg["success"] is True
        assert msg["cost_usd"] == 0.42

    @pytest.mark.asyncio
    async def test_send_agent_failed(self):
        await self.client.send_agent_failed("uuid-1", "Stall timeout")
        msg = self.client._send_queue.get_nowait()
        assert msg["type"] == "agent_failed"
        assert msg["error"] == "Stall timeout"

    @pytest.mark.asyncio
    async def test_send_question(self):
        await self.client.send_question("uuid-1", "Which approach?", ["A", "B"])
        msg = self.client._send_queue.get_nowait()
        assert msg["type"] == "question"
        assert msg["options"] == ["A", "B"]

    @pytest.mark.asyncio
    async def test_send_heartbeat(self):
        await self.client.send(HeartbeatMessage())
        msg = self.client._send_queue.get_nowait()
        assert msg["type"] == "heartbeat"


class TestDictToDispatch:
    def test_full_payload(self):
        data = {
            "type": "dispatch",
            "issue": {
                "id": "uuid-1",
                "identifier": "SUP-42",
                "title": "Fix bug",
                "state": "Todo",
                "description": "desc",
                "url": "https://linear.app/SUP-42",
                "labels": ["agent", "urgent"],
                "branch_name": "aryan/sup-42",
            },
            "comments": [
                {"body": "note 1", "created_at": "2026-01-01"},
                {"body": "note 2", "created_at": "2026-01-02"},
            ],
            "images": [{"type": "image", "data": "base64..."}],
            "resume_session_id": "ses_prev",
        }
        msg = _dict_to_dispatch(data)
        assert msg.issue.id == "uuid-1"
        assert len(msg.comments) == 2
        assert len(msg.images) == 1
        assert msg.resume_session_id == "ses_prev"

    def test_minimal_payload(self):
        data = {"type": "dispatch", "issue": {}, "comments": [], "images": []}
        msg = _dict_to_dispatch(data)
        assert msg.issue.identifier == ""
        assert msg.comments == []


class TestGetGitRemote:
    def test_returns_remote_url(self, tmp_path):
        """Returns origin URL for a real git repo."""
        import subprocess
        subprocess.run(["git", "init", str(tmp_path)], capture_output=True)
        subprocess.run(
            ["git", "-C", str(tmp_path), "remote", "add", "origin", "git@github.com:test/repo.git"],
            capture_output=True,
        )
        assert _get_git_remote(str(tmp_path)) == "git@github.com:test/repo.git"

    def test_returns_empty_for_non_repo(self, tmp_path):
        assert _get_git_remote(str(tmp_path)) == ""
