"""Tests for prompt building."""

from pathlib import Path

from cruise.linear import Comment, Issue
from cruise.prompt import (
    ATTEMPT_CONTEXT_TEMPLATE,
    DEFAULT_TEMPLATE,
    build_continuation_prompt,
    build_prompt,
    load_template,
)


def _make_issue(**kwargs) -> Issue:
    defaults = {
        "id": "abc",
        "identifier": "PROJ-1",
        "title": "Fix auth bug",
        "state": "Todo",
        "description": "Auth is broken",
        "url": "https://linear.app/issue/PROJ-1",
        "labels": ["bug"],
    }
    defaults.update(kwargs)
    return Issue(**defaults)


def test_build_prompt_substitutes_issue_fields():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE)
    assert "PROJ-1" in result
    assert "Fix auth bug" in result
    assert "Auth is broken" in result
    assert "Todo" in result
    assert "bug" in result


def test_build_prompt_no_description():
    issue = _make_issue(description="")
    result = build_prompt(issue, DEFAULT_TEMPLATE)
    assert "No description provided." in result


def test_build_prompt_no_labels():
    issue = _make_issue(labels=[])
    result = build_prompt(issue, DEFAULT_TEMPLATE)
    assert "none" in result


def test_build_prompt_custom_template():
    template = "Work on {issue.identifier}: {issue.title}"
    issue = _make_issue()
    result = build_prompt(issue, template)
    assert result == "Work on PROJ-1: Fix auth bug"


def test_build_prompt_unknown_placeholders_preserved():
    template = "Issue: {issue.identifier}, Unknown: {something.else}"
    issue = _make_issue()
    result = build_prompt(issue, template)
    assert "PROJ-1" in result
    assert "{something.else}" in result


def test_build_continuation_prompt():
    result = build_continuation_prompt(2, 10)
    assert "#2" in result
    assert "10" in result
    assert "continuation" in result.lower()


def test_load_template_default(tmp_path):
    result = load_template(None)
    assert result == DEFAULT_TEMPLATE


def test_load_template_from_file(tmp_path):
    path = tmp_path / "custom.md"
    path.write_text("Custom: {issue.identifier}")
    result = load_template(path)
    assert result == "Custom: {issue.identifier}"


def test_build_prompt_with_attempt_context():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE, attempt=3)
    assert "retry attempt #3" in result
    assert "Resume from the current workspace" in result


def test_build_prompt_no_attempt_context():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE, attempt=None)
    assert "retry attempt" not in result


def test_build_prompt_attempt_1_no_context():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE, attempt=1)
    assert "retry attempt" not in result


def test_build_prompt_with_comments():
    issue = _make_issue()
    comments = [
        Comment(id="c1", body="Please add validation"),
        Comment(id="c2", body="Also handle edge cases"),
    ]
    result = build_prompt(issue, DEFAULT_TEMPLATE, comments=comments)
    assert "Please add validation" in result
    assert "Also handle edge cases" in result
    assert "User comments" in result


def test_build_prompt_no_comments_no_section():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE, comments=[])
    assert "User comments" not in result


def test_build_prompt_comments_none_no_section():
    issue = _make_issue()
    result = build_prompt(issue, DEFAULT_TEMPLATE, comments=None)
    assert "User comments" not in result


def test_prompt_md_exists_at_repo_root():
    """prompt.md must be at the repo root so worker/poller find it instead of falling back to DEFAULT_TEMPLATE."""
    repo_root = Path(__file__).resolve().parents[2]
    assert (repo_root / "prompt.md").exists(), (
        "prompt.md missing from repo root — agents will silently use the barebones DEFAULT_TEMPLATE"
    )
