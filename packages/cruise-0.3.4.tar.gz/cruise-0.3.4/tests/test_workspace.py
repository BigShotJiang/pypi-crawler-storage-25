"""Tests for workspace (git worktree) management."""

import asyncio
from pathlib import Path

import pytest

from unittest.mock import AsyncMock, patch

from cruise.workspace import (
    WorkspaceError,
    cleanup_stale_worktrees,
    create_worktree,
    remove_worktree,
    worktree_exists,
)


@pytest.fixture
async def git_repo(tmp_path):
    """Create a minimal git repo with an initial commit and an origin remote."""
    repo = tmp_path / "repo"
    repo.mkdir()

    await _run("git", "init", "-b", "main", cwd=repo)
    await _run("git", "config", "user.email", "test@test.com", cwd=repo)
    await _run("git", "config", "user.name", "Test", cwd=repo)
    # Create initial commit
    (repo / "README.md").write_text("# Test")
    await _run("git", "add", ".", cwd=repo)
    await _run("git", "commit", "-m", "init", cwd=repo)
    # Create a bare clone to act as "origin"
    origin = tmp_path / "origin.git"
    await _run("git", "clone", "--bare", str(repo), str(origin))
    await _run("git", "remote", "add", "origin", str(origin), cwd=repo)
    await _run("git", "fetch", "origin", cwd=repo)

    return repo


async def _run(*args, cwd=None):
    proc = await asyncio.create_subprocess_exec(
        *args,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()
    return proc.returncode


@pytest.mark.asyncio
async def test_create_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    path = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")

    assert path == ws_root / "PROJ-1"
    assert path.exists()
    assert (path / "README.md").exists()
    assert worktree_exists(ws_root, "PROJ-1")


@pytest.mark.asyncio
async def test_create_worktree_idempotent(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    path1 = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    path2 = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    assert path1 == path2


@pytest.mark.asyncio
async def test_remove_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    assert worktree_exists(ws_root, "PROJ-1")

    await remove_worktree(git_repo, ws_root, "PROJ-1")
    assert not worktree_exists(ws_root, "PROJ-1")


@pytest.mark.asyncio
async def test_remove_nonexistent_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    # Should not raise
    await remove_worktree(git_repo, ws_root, "PROJ-999")


def test_worktree_exists_false(tmp_path):
    assert not worktree_exists(tmp_path, "PROJ-1")


class TestCleanupStaleWorktrees:
    @pytest.mark.asyncio
    async def test_removes_stale_directories(self, tmp_path):
        """Directories with no active session are removed."""
        repo = tmp_path / "repo"
        ws_root = tmp_path / "workspaces"
        (ws_root / "PROJ-1").mkdir(parents=True)
        (ws_root / "PROJ-2").mkdir(parents=True)

        with patch("cruise.workspace.remove_worktree", new_callable=AsyncMock) as mock_remove:
            await cleanup_stale_worktrees(repo, ws_root, active_identifiers=set())

        removed = {call.args[2] for call in mock_remove.call_args_list}
        assert removed == {"PROJ-1", "PROJ-2"}

    @pytest.mark.asyncio
    async def test_skips_active_sessions(self, tmp_path):
        """Directories with an active session are left alone."""
        repo = tmp_path / "repo"
        ws_root = tmp_path / "workspaces"
        (ws_root / "PROJ-1").mkdir(parents=True)
        (ws_root / "PROJ-2").mkdir(parents=True)

        with patch("cruise.workspace.remove_worktree", new_callable=AsyncMock) as mock_remove:
            await cleanup_stale_worktrees(repo, ws_root, active_identifiers={"PROJ-1"})

        removed = {call.args[2] for call in mock_remove.call_args_list}
        assert removed == {"PROJ-2"}
        assert "PROJ-1" not in removed

    @pytest.mark.asyncio
    async def test_logs_but_does_not_raise_on_failure(self, tmp_path):
        """A removal failure is logged but does not stop cleanup of other worktrees."""
        repo = tmp_path / "repo"
        ws_root = tmp_path / "workspaces"
        (ws_root / "PROJ-1").mkdir(parents=True)
        (ws_root / "PROJ-2").mkdir(parents=True)

        async def fail_on_first(rp, wsroot, identifier):
            if identifier == "PROJ-1":
                raise RuntimeError("git worktree remove failed")

        with patch("cruise.workspace.remove_worktree", side_effect=fail_on_first):
            # Should not raise
            await cleanup_stale_worktrees(repo, ws_root, active_identifiers=set())

    @pytest.mark.asyncio
    async def test_noop_when_workspace_root_missing(self, tmp_path):
        """Does nothing if workspace_root doesn't exist yet."""
        repo = tmp_path / "repo"
        ws_root = tmp_path / "nonexistent"

        with patch("cruise.workspace.remove_worktree", new_callable=AsyncMock) as mock_remove:
            await cleanup_stale_worktrees(repo, ws_root, active_identifiers=set())

        mock_remove.assert_not_called()

    @pytest.mark.asyncio
    async def test_ignores_files_in_workspace_root(self, tmp_path):
        """Non-directory entries (e.g. stray files) are skipped."""
        repo = tmp_path / "repo"
        ws_root = tmp_path / "workspaces"
        ws_root.mkdir()
        (ws_root / "somefile.txt").write_text("oops")

        with patch("cruise.workspace.remove_worktree", new_callable=AsyncMock) as mock_remove:
            await cleanup_stale_worktrees(repo, ws_root, active_identifiers=set())

        mock_remove.assert_not_called()
