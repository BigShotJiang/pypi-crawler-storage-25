"""Tests for status display utility functions."""

from cruise.status import _fmt_cost, _fmt_duration, _truncate


def test_fmt_duration_seconds():
    assert _fmt_duration(45) == "45s"


def test_fmt_duration_minutes():
    assert _fmt_duration(154) == "2m 34s"


def test_fmt_duration_hours():
    assert _fmt_duration(3661) == "1h 1m"


def test_fmt_cost_none():
    assert _fmt_cost(None) == "-"


def test_fmt_cost_small():
    # Very small amounts show 5 decimal places.
    assert _fmt_cost(0.0000001) == "$0.00000"


def test_fmt_cost_normal():
    assert _fmt_cost(0.05) == "$0.0500"


def test_truncate_short_text_unchanged():
    assert _truncate("hello", 10) == "hello"


def test_truncate_long_text():
    result = _truncate("a" * 100, 20)
    assert len(result) == 20
    assert result.endswith("…")


def test_truncate_collapses_newlines():
    assert _truncate("line1\nline2", 50) == "line1 line2"
