"""Tests for WebSocket message protocol dataclasses."""

from cruise.protocol import (
    AgentCompletedMessage,
    CancelMessage,
    DispatchMessage,
    IssuePayload,
    QuestionMessage,
)


def _make_issue_payload(**kwargs) -> IssuePayload:
    defaults = dict(
        id="1",
        identifier="PROJ-1",
        title="Fix bug",
        state="Todo",
        description="Something broke",
        url="https://linear.app/issue/PROJ-1",
    )
    defaults.update(kwargs)
    return IssuePayload(**defaults)


def test_dispatch_message_defaults():
    msg = DispatchMessage(issue=_make_issue_payload())
    assert msg.type == "dispatch"
    assert msg.comments == []
    assert msg.images == []
    assert msg.resume_session_id is None
    assert msg.linear_access_token == ""


def test_cancel_message_defaults():
    msg = CancelMessage(issue_id="ABC-1", reason="user cancelled")
    assert msg.type == "cancel"
    assert msg.issue_id == "ABC-1"
    assert msg.reason == "user cancelled"


def test_agent_completed_message_defaults():
    msg = AgentCompletedMessage(issue_id="DEF-2", success=True, num_turns=5)
    assert msg.type == "agent_completed"
    assert msg.success is True
    assert msg.num_turns == 5
    assert msg.hit_turn_limit is False
    assert msg.pr_url == ""


def test_question_message_options_default_empty():
    msg = QuestionMessage(issue_id="GHI-3", question="Which approach?")
    assert msg.options == []


def test_issue_payload_labels_default_empty():
    payload = IssuePayload(
        id="1",
        identifier="PROJ-1",
        title="Fix bug",
        state="Todo",
        description="Something broke",
        url="https://linear.app/issue/PROJ-1",
    )
    assert payload.labels == []
    assert payload.branch_name == ""
