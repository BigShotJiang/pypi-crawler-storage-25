"""Load and validate configuration from YAML."""

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml


DEFAULT_ACTIVE_STATES = ["Todo", "In Progress"]
DEFAULT_TERMINAL_STATES = ["Done", "Cancelled", "Canceled", "Duplicate"]


@dataclass
class LinearConfig:
    api_key: str
    team_key: str
    active_states: list[str] = field(default_factory=lambda: list(DEFAULT_ACTIVE_STATES))
    terminal_states: list[str] = field(
        default_factory=lambda: list(DEFAULT_TERMINAL_STATES)
    )
    dispatch_label: str = ""


@dataclass
class RepoConfig:
    path: Path
    workspace_root: Path
    branch_prefix: str = ""


@dataclass
class PollingConfig:
    interval_seconds: int = 30


@dataclass
class AgentConfig:
    max_concurrent: int = 3
    max_turns: int = 20
    stall_timeout_seconds: int = 600
    max_retry_attempts: int = 3
    max_continuations: int = 10
    permission_mode: str = "bypassPermissions"
    model: str | None = None
    question_timeout_seconds: int = 300


@dataclass
class Config:
    linear: LinearConfig
    repo: RepoConfig
    polling: PollingConfig = field(default_factory=PollingConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)


def _resolve_env_var(value: str) -> str:
    """Resolve $ENV_VAR references in string values."""
    if isinstance(value, str) and value.startswith("$"):
        env_name = value[1:]
        env_value = os.environ.get(env_name)
        if env_value is None:
            raise ValueError(f"Environment variable {env_name} is not set")
        return env_value
    return value


def _expand_path(value: str) -> Path:
    """Expand ~ and env vars in path strings."""
    return Path(os.path.expanduser(os.path.expandvars(value)))


def load_config(config_path: str | Path) -> Config:
    """Load configuration from a YAML file."""
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError("Config file must contain a YAML mapping")

    linear_raw = raw.get("linear", {})
    repo_raw = raw.get("repo", {})
    polling_raw = raw.get("polling", {})
    agent_raw = raw.get("agent", {})

    api_key = _resolve_env_var(linear_raw.get("api_key", "$LINEAR_API_KEY"))

    linear = LinearConfig(
        api_key=api_key,
        team_key=linear_raw["team_key"],
        active_states=linear_raw.get("active_states", list(DEFAULT_ACTIVE_STATES)),
        terminal_states=linear_raw.get("terminal_states", list(DEFAULT_TERMINAL_STATES)),
        dispatch_label=linear_raw.get("dispatch_label", ""),
    )

    repo = RepoConfig(
        path=_expand_path(repo_raw["path"]),
        workspace_root=_expand_path(repo_raw["workspace_root"]),
        branch_prefix=repo_raw.get("branch_prefix", ""),
    )

    polling = PollingConfig(
        interval_seconds=polling_raw.get("interval_seconds", 30),
    )

    agent = AgentConfig(
        max_concurrent=agent_raw.get("max_concurrent", 3),
        max_turns=agent_raw.get("max_turns", 20),
        stall_timeout_seconds=agent_raw.get("stall_timeout_seconds", 600),
        max_retry_attempts=agent_raw.get("max_retry_attempts", 3),
        max_continuations=agent_raw.get("max_continuations", 10),
        permission_mode=agent_raw.get("permission_mode", "bypassPermissions"),
        model=agent_raw.get("model"),
        question_timeout_seconds=agent_raw.get("question_timeout_seconds", 300),
    )

    return Config(linear=linear, repo=repo, polling=polling, agent=agent)
