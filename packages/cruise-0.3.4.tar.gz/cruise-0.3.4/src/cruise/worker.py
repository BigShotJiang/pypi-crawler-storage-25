"""Agent worker: receives dispatch commands from the cloud and runs CC sessions."""

import asyncio
import logging
import os
import shutil
from dataclasses import dataclass
from pathlib import Path

from cruise.client import CloudClient
from cruise.dispatcher import AgentResult, run_agent
from cruise.linear import LinearClient
from cruise.prompt import build_prompt, load_template
from cruise.workspace import create_worktree, remove_worktree

from cruise.protocol import (
    CancelMessage,
    DispatchMessage,
    IssuePayload,
    QuestionReplyMessage,
)

logger = logging.getLogger(__name__)

_CLAUDE_SEARCH_PATHS = [
    Path.home() / ".local" / "bin" / "claude",
    Path("/usr/local/bin/claude"),
    Path.home() / ".npm-global" / "bin" / "claude",
]


async def _find_pr_url(worktree_path: Path) -> str:
    """Find the PR URL for the current branch in a worktree via gh CLI."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "gh", "pr", "view", "--json", "url", "--jq", ".url",
            cwd=worktree_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
        url = stdout.decode().strip()
        if url.startswith("https://"):
            return url
    except Exception:
        pass
    return ""


def _find_claude_binary() -> str | None:
    """Find the claude binary, checking PATH then common install locations."""
    found = shutil.which("claude")
    if found:
        return found
    for path in _CLAUDE_SEARCH_PATHS:
        if path.is_file() and os.access(path, os.X_OK):
            logger.info(f"Found claude at {path} (not in PATH)")
            return str(path)
    logger.warning("Could not find claude binary — SDK will use bundled copy")
    return None


@dataclass
class _RunningSession:
    issue_id: str
    identifier: str
    task: asyncio.Task
    question_future: asyncio.Future | None = None


class Worker:
    """Processes dispatch commands from the cloud, running agents locally.

    Each dispatched issue gets its own worktree and CC session. The worker
    reports progress and results back to the cloud via the CloudClient.
    """

    def __init__(
        self,
        client: CloudClient,
        repo_path: str,
        workspace_root: str,
        branch_prefix: str = "",
        max_turns: int = 100,
    ):
        self.client = client
        self.repo_path = Path(repo_path)
        self.workspace_root = Path(workspace_root)
        self.branch_prefix = branch_prefix
        self.max_turns = max_turns
        self._sessions: dict[str, _RunningSession] = {}
        self._template = load_template(
            Path(self.repo_path / "prompt.md")
            if (self.repo_path / "prompt.md").exists()
            else None
        )

    async def handle_message(self, message) -> None:
        """Route an incoming cloud message to the appropriate handler."""
        if isinstance(message, DispatchMessage):
            await self._handle_dispatch(message)
        elif isinstance(message, CancelMessage):
            await self._handle_cancel(message)
        elif isinstance(message, QuestionReplyMessage):
            self._handle_question_reply(message)

    async def cancel_all(self) -> None:
        """Cancel all running sessions (for graceful shutdown)."""
        for session in list(self._sessions.values()):
            session.task.cancel()
        self._sessions.clear()

    async def _handle_dispatch(self, msg: DispatchMessage) -> None:
        """Create a worktree and start a CC session for the dispatched issue."""
        issue = msg.issue
        if issue.id in self._sessions:
            logger.warning(f"Already running session for {issue.identifier}, ignoring")
            return

        task = asyncio.create_task(
            self._run_session(issue, msg),
            name=f"agent-{issue.identifier}",
        )
        self._sessions[issue.id] = _RunningSession(
            issue_id=issue.id,
            identifier=issue.identifier,
            task=task,
        )

    async def _handle_cancel(self, msg: CancelMessage) -> None:
        """Cancel a running session."""
        session = self._sessions.pop(msg.issue_id, None)
        if session:
            logger.info(f"Cancelling {session.identifier}: {msg.reason}")
            session.task.cancel()

    def _handle_question_reply(self, msg: QuestionReplyMessage) -> None:
        """Resolve a pending AskUserQuestion future with the reply."""
        session = self._sessions.get(msg.issue_id)
        if session and session.question_future and not session.question_future.done():
            session.question_future.set_result(msg.reply)

    async def _run_session(
        self,
        issue: IssuePayload,
        msg: DispatchMessage,
    ) -> None:
        """Run a full agent session: create worktree → run agent → report result."""
        linear_client = LinearClient(msg.linear_access_token) if msg.linear_access_token else None
        try:
            worktree_path = await create_worktree(
                self.repo_path,
                self.workspace_root,
                issue.identifier,
                self.branch_prefix,
            )

            from cruise.linear import Comment, Issue as LinearIssue
            linear_issue = LinearIssue(
                id=issue.id,
                identifier=issue.identifier,
                title=issue.title,
                state=issue.state,
                description=issue.description,
                url=issue.url,
                labels=issue.labels,
            )

            if msg.prompt_context:
                # Use Linear's pre-formatted context when dispatched via agent session.
                prompt = msg.prompt_context
            else:
                comments = [
                    Comment(id="", body=c.body, created_at=c.created_at)
                    for c in msg.comments
                ]
                prompt = build_prompt(
                    linear_issue, self._template, comments=comments if comments else None,
                )

            logger.info(
                f"[{issue.identifier}] Prompt length={len(prompt)}, "
                f"title={issue.title!r}, cli_path={_find_claude_binary()}"
            )
            logger.debug(f"[{issue.identifier}] Full prompt: {prompt[:1000]}")

            await self.client.send_agent_started(issue.id, "")

            event_count = 0

            def on_event(event: str) -> None:
                nonlocal event_count
                event_count += 1
                truncated = event[:100] if event.startswith("tool:") else event[:1500]
                preview = truncated[:80].replace("\n", " ")
                logger.debug(
                    f"[{issue.identifier}] on_event #{event_count}: {preview!r}"
                )
                self.client.queue_progress(issue.id, truncated, event_count)

            effective_model = msg.model or None
            logger.info(
                f"[{issue.identifier}] Using model={effective_model!r} "
                f"permission_mode={(msg.permission_mode or 'bypassPermissions')!r}"
            )

            result = await run_agent(
                issue=linear_issue,
                prompt=prompt,
                worktree_path=worktree_path,
                permission_mode=msg.permission_mode or "bypassPermissions",
                max_turns=self.max_turns,
                model=effective_model,
                cli_path=_find_claude_binary(),
                linear_api_key=msg.linear_access_token,
                linear_client=linear_client,
                agent_session_id=msg.agent_session_id,
                images=msg.images if msg.images else None,
                resume_session_id=msg.resume_session_id,
                on_activity=lambda: None,
                on_event=on_event,
            )

            if result.session_id:
                await self.client.send_agent_started(issue.id, result.session_id)

            if result.error:
                await self.client.send_agent_failed(issue.id, result.error)
            else:
                hit_limit = result.num_turns >= (self.max_turns or 20)
                pr_url = await _find_pr_url(worktree_path)
                await self.client.send_agent_completed(
                    issue_id=issue.id,
                    session_id=result.session_id or "",
                    success=result.success,
                    cost_usd=result.cost_usd or 0.0,
                    num_turns=result.num_turns,
                    duration_ms=result.duration_ms,
                    hit_turn_limit=hit_limit,
                    pr_url=pr_url,
                )

        except asyncio.CancelledError:
            logger.info(f"Session cancelled for {issue.identifier}")
            await self.client.send_agent_failed(issue.id, "Session cancelled")
            raise
        except Exception as e:
            logger.error(f"Session failed for {issue.identifier}: {e}")
            await self.client.send_agent_failed(issue.id, str(e))
        finally:
            self._sessions.pop(issue.id, None)
            if linear_client:
                await linear_client.close()
