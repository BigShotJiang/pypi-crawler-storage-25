"""Agent session management via Claude Agent SDK."""

import asyncio
import logging
import time

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ResultMessage,
    TaskNotificationMessage,
    TaskProgressMessage,
    TaskStartedMessage,
)
from claude_agent_sdk.client import ClaudeSDKClient
from claude_agent_sdk.types import (
    HookMatcher,
    PermissionResultAllow,
    PermissionResultDeny,
    ThinkingBlock,
)

from cruise.linear import Issue, LinearClient

logger = logging.getLogger(__name__)

# How often to poll Linear for replies while waiting for an answer (seconds).
_QUESTION_POLL_INTERVAL = 5


@dataclass
class AgentResult:
    session_id: str | None = None
    success: bool = False
    cost_usd: float | None = None
    usage: dict | None = None
    duration_ms: int = 0
    num_turns: int = 0
    error: str | None = None
    final_message: str | None = None


async def run_agent(
    issue: Issue,
    prompt: str,
    worktree_path: Path,
    *,
    permission_mode: str = "bypassPermissions",
    max_turns: int | None = None,
    linear_api_key: str = "",
    model: str | None = None,
    cli_path: str | None = None,
    linear_client: LinearClient | None = None,
    agent_session_id: str = "",
    question_timeout_seconds: int = 300,
    seen_comment_ids: set[str] | None = None,
    images: list[dict] | None = None,
    resume_session_id: str | None = None,
    on_activity: Callable[[], None] | None = None,
    on_event: Callable[[str], None] | None = None,
) -> AgentResult:
    """Run a Claude Code agent session for an issue.

    When linear_client is provided, AskUserQuestion tool calls are intercepted:
    the question is posted as a Linear comment and the agent pauses until a
    reply appears (or question_timeout_seconds elapses).

    When images are provided (list of SDK image content blocks), the initial
    message is sent as a structured multipart message instead of a plain string.

    If resume_session_id is provided, resumes an existing session instead of
    starting fresh, preserving all prior conversation context.

    Returns an AgentResult with session outcome.
    """
    can_use_tool_cb = None
    hooks = None

    if linear_client is not None:
        if seen_comment_ids is None:
            seen_comment_ids = set()
        can_use_tool_cb = _make_can_use_tool_callback(
            issue=issue,
            linear_client=linear_client,
            agent_session_id=agent_session_id,
            question_timeout_seconds=question_timeout_seconds,
            seen_comment_ids=seen_comment_ids,
        )
        # Required by the SDK: a PreToolUse hook keeps the stream alive so
        # can_use_tool callbacks can be invoked in streaming mode.
        async def _passthrough_hook(input_data, tool_use_id, context):
            return {"continue_": True}

        hooks = {"PreToolUse": [HookMatcher(matcher=None, hooks=[_passthrough_hook])]}

    options = ClaudeAgentOptions(
        cwd=str(worktree_path),
        permission_mode=permission_mode,
        max_turns=max_turns,
        model=model,
        cli_path=cli_path,
        setting_sources=["project"],
        env={"LINEAR_API_KEY": linear_api_key} if linear_api_key else {},
        can_use_tool=can_use_tool_cb,
        hooks=hooks,
        resume=resume_session_id,
    )

    result = AgentResult()

    try:
        if resume_session_id:
            logger.info(
                f"Resuming session {resume_session_id} for {issue.identifier}"
            )
        else:
            logger.info(
                f"Starting agent for {issue.identifier} in {worktree_path}"
                + (f" with {len(images)} image(s)" if images else "")
            )

        logger.debug(f"[{issue.identifier}] Prompt ({len(prompt)} chars): {prompt[:500]}")
        logger.debug(f"[{issue.identifier}] Options: cwd={options.cwd} permission_mode={options.permission_mode} max_turns={options.max_turns} model={options.model} cli_path={options.cli_path}")

        async with ClaudeSDKClient(options) as client:
            initial_input = _build_initial_input(prompt, images)
            await client.query(initial_input)

            in_subagent = False

            async for message in client.receive_response():
                if on_activity:
                    on_activity()
                if isinstance(message, AssistantMessage):
                    _log_assistant_message(issue.identifier, message)
                    if on_event:
                        _fire_event(message, on_event, skip_tools=in_subagent)
                    text = _extract_text(message)
                    if text:
                        result.final_message = text
                elif isinstance(message, TaskStartedMessage):
                    in_subagent = True
                    logger.debug(f"[{issue.identifier}] Sub-agent started")
                elif isinstance(message, TaskProgressMessage):
                    logger.debug(
                        f"[{issue.identifier}] SDK TaskProgress: "
                        f"tool={message.last_tool_name!r}"
                    )
                    if on_event and message.last_tool_name:
                        on_event(f"tool:{message.last_tool_name}")
                elif isinstance(message, TaskNotificationMessage):
                    in_subagent = False
                    logger.debug(f"[{issue.identifier}] Sub-agent finished")
                elif isinstance(message, ResultMessage):
                    logger.debug(
                        f"[{issue.identifier}] ResultMessage: subtype={message.subtype} "
                        f"turns={message.num_turns} cost={message.total_cost_usd} "
                        f"is_error={message.is_error} result={getattr(message, 'result', None)}"
                    )
                    _update_result(result, message)
                else:
                    logger.debug(
                        f"[{issue.identifier}] SDK message (unhandled): "
                        f"{type(message).__name__}"
                    )

        logger.info(
            f"Agent completed for {issue.identifier}: "
            f"success={result.success} turns={result.num_turns} "
            f"cost=${result.cost_usd or 0:.4f}"
        )
    except Exception as e:
        result.error = str(e)
        logger.error(f"Agent failed for {issue.identifier}: {e}")

    return result


def _make_can_use_tool_callback(
    issue: Issue,
    linear_client: LinearClient | None,
    agent_session_id: str,
    question_timeout_seconds: int,
    seen_comment_ids: set[str],
) -> Callable:
    """Return an async can_use_tool callback that handles AskUserQuestion.

    For any tool other than AskUserQuestion, auto-allows. For AskUserQuestion:
    - If agent_session_id is set: posts an elicitation activity (native Linear UI),
      then waits question_timeout_seconds before continuing with default.
    - Otherwise: posts a comment and polls for a reply.

    seen_comment_ids is mutated so the poller won't re-inject the answer.
    """

    async def can_use_tool(tool_name: str, input_data: dict, context) -> PermissionResultAllow:
        if tool_name != "AskUserQuestion":
            return PermissionResultAllow(updated_input=input_data)

        return await _handle_ask_user_question(
            issue=issue,
            linear_client=linear_client,
            agent_session_id=agent_session_id,
            input_data=input_data,
            question_timeout_seconds=question_timeout_seconds,
            seen_comment_ids=seen_comment_ids,
        )

    return can_use_tool


async def _handle_ask_user_question(
    issue: Issue,
    linear_client: LinearClient | None,
    agent_session_id: str,
    input_data: dict,
    question_timeout_seconds: int,
    seen_comment_ids: set[str],
) -> PermissionResultAllow:
    """Post Claude's question to Linear and wait for a reply.

    Agent session path (agent_session_id set): posts an elicitation activity
    for the native Linear UI, then waits for a comment reply or timeout.

    Polling path (no agent_session_id): posts a comment and polls for a reply.

    Returns PermissionResultAllow with answers filled in from the Linear reply,
    or default empty answers if no reply arrives within the timeout.
    """
    questions = input_data.get("questions", [])

    if not linear_client:
        logger.warning(
            f"AskUserQuestion fired but no linear_client available; "
            f"returning default answer for {issue.identifier}"
        )
        return PermissionResultAllow(updated_input=_default_answer(input_data))

    comment_body = _format_question_comment(questions, question_timeout_seconds)

    if agent_session_id:
        # Native agent session: post elicitation activity for Linear's UI.
        # Reply comes via agent_session_prompted webhook (not yet handled),
        # so we fall through to timeout and continue with defaults.
        await linear_client.post_agent_activity(
            agent_session_id, "elicitation", comment_body
        )
        logger.info(
            f"Posted elicitation activity for {issue.identifier} "
            f"on session {agent_session_id}"
        )
        await asyncio.sleep(question_timeout_seconds)
        logger.info(
            f"AskUserQuestion for {issue.identifier} timed out after "
            f"{question_timeout_seconds}s; continuing with default"
        )
        return PermissionResultAllow(updated_input=_default_answer(input_data))

    # Polling path: post a comment and poll for a reply.

    # Snapshot existing comment IDs before we post so we can detect new ones.
    try:
        existing = await linear_client.fetch_issue_comments(issue.id)
        pre_post_ids = {c.id for c in existing}
    except Exception:
        logger.exception(f"Failed to fetch pre-question comments for {issue.identifier}")
        pre_post_ids = set(seen_comment_ids)

    try:
        question_comment_id = await linear_client.post_comment(issue.id, comment_body)
    except Exception:
        logger.exception(f"Failed to post question comment for {issue.identifier}")
        return PermissionResultAllow(updated_input=_default_answer(input_data))

    if question_comment_id:
        seen_comment_ids.add(question_comment_id)
        logger.info(
            f"Posted AskUserQuestion for {issue.identifier} "
            f"as Linear comment {question_comment_id}"
        )
    else:
        logger.warning(f"post_comment returned no ID for {issue.identifier}")
        return PermissionResultAllow(updated_input=_default_answer(input_data))

    deadline = time.monotonic() + question_timeout_seconds
    while time.monotonic() < deadline:
        await asyncio.sleep(_QUESTION_POLL_INTERVAL)
        try:
            comments = await linear_client.fetch_issue_comments(issue.id)
        except Exception:
            logger.exception(f"Failed to poll comments for {issue.identifier}")
            continue

        reply = _find_reply(comments, question_comment_id, pre_post_ids)
        if reply:
            seen_comment_ids.add(reply.id)
            logger.info(
                f"Received answer to AskUserQuestion for {issue.identifier}: "
                f"comment {reply.id}"
            )
            return PermissionResultAllow(
                updated_input=_build_answer(input_data, reply.body)
            )

    logger.info(
        f"AskUserQuestion for {issue.identifier} timed out after "
        f"{question_timeout_seconds}s; continuing with default"
    )
    return PermissionResultAllow(updated_input=_default_answer(input_data))


def _find_reply(comments, question_comment_id: str, pre_post_ids: set[str]):
    """Return the first comment that is a reply or new comment after the question.

    Accepts both direct threaded replies (parent_id == question_comment_id)
    and any new top-level comment that appeared after the question was posted.
    """
    for comment in comments:
        if comment.id == question_comment_id:
            continue
        if comment.id in pre_post_ids:
            continue
        # Direct reply to Claude's question comment, or any new comment.
        return comment
    return None


def _format_question_comment(questions: list[dict], timeout_seconds: int) -> str:
    """Format AskUserQuestion questions as a readable Linear comment."""
    lines = ["\U0001f916 Claude asks:"]
    for q in questions:
        question_text = q.get("question", "")
        options = q.get("options", [])
        lines.append(f"\n**{question_text}**")
        if options:
            for opt in options:
                label = opt.get("label", "")
                description = opt.get("description", "")
                if description:
                    lines.append(f"- **{label}**: {description}")
                else:
                    lines.append(f"- {label}")

    lines.append(
        f"\n---\n*Reply to this comment with your answer. "
        f"Claude will continue with its default choice after "
        f"{timeout_seconds} seconds if no reply is received.*"
    )
    return "\n".join(lines)


def _build_answer(input_data: dict, reply_text: str) -> dict:
    """Build updated_input with answers populated from the reply text."""
    questions = input_data.get("questions", [])
    answers = {q["question"]: reply_text for q in questions if "question" in q}
    return {**input_data, "answers": answers}


def _default_answer(input_data: dict) -> dict:
    """Build updated_input with empty answers (Claude picks its own default)."""
    questions = input_data.get("questions", [])
    answers = {q["question"]: "" for q in questions if "question" in q}
    return {**input_data, "answers": answers}


def _update_result(result: AgentResult, message: ResultMessage) -> None:
    """Populate AgentResult fields from a ResultMessage."""
    result.session_id = message.session_id
    result.success = message.subtype == "success"
    result.cost_usd = message.total_cost_usd
    result.usage = message.usage
    result.duration_ms = message.duration_ms
    result.num_turns = message.num_turns
    if message.is_error:
        result.error = message.result


def _log_assistant_message(identifier: str, message: AssistantMessage) -> None:
    """Log key events from assistant messages."""
    for block in message.content:
        if hasattr(block, "name"):
            logger.debug(f"[{identifier}] Tool: {block.name}")
        elif hasattr(block, "text") and block.text:
            # Log first 200 chars of text responses
            preview = block.text[:200].replace("\n", " ")
            logger.debug(f"[{identifier}] {preview}")


def _extract_text(message: AssistantMessage) -> str | None:
    """Return the combined text content of an assistant message, or None if it has no text blocks.

    Tool-use-only messages (no text blocks) return None so they don't overwrite
    a prior text message as the final message.
    """
    parts = [
        block.text
        for block in message.content
        if hasattr(block, "text") and block.text
    ]
    return "\n".join(parts) if parts else None


async def _message_with_images(prompt: str, images: list[dict]):
    """Async generator that yields a single user message containing text and image blocks."""
    content = [{"type": "text", "text": prompt}]
    content.extend(images)
    yield {
        "type": "user",
        "message": {
            "role": "user",
            "content": content,
        },
    }


def _fire_event(
    message: AssistantMessage,
    on_event: Callable[[str], None],
    skip_tools: bool = False,
) -> None:
    """Call on_event for each observable event in an assistant message.

    Fires for ThinkingBlock content (reasoning text) and tool-use blocks
    (formatted as "tool:<ToolName>"). When skip_tools is True, only fires
    thinking events — used during sub-agent execution where TaskProgressMessage
    already provides tool events, avoiding double-counting.
    """
    for block in message.content:
        if isinstance(block, ThinkingBlock) and block.thinking:
            on_event(block.thinking)
        elif hasattr(block, "name") and not skip_tools:  # ToolUseBlock
            on_event(f"tool:{block.name}")


def _build_initial_input(prompt: str, images: list[dict] | None):
    """Return the initial input for client.query().

    Returns a plain string when there are no images, or an async generator
    yielding a structured message with image content blocks when images are present.
    """
    if not images:
        return prompt
    return _message_with_images(prompt, images)
