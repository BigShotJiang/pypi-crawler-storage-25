"""WebSocket message types shared between cloud and daemon."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# -- Cloud → Daemon messages --


@dataclass
class IssuePayload:
    id: str
    identifier: str
    title: str
    state: str
    description: str
    url: str
    labels: list[str] = field(default_factory=list)
    branch_name: str = ""


@dataclass
class CommentPayload:
    body: str
    created_at: str


@dataclass
class DispatchMessage:
    type: Literal["dispatch"] = "dispatch"
    issue: IssuePayload = field(default_factory=IssuePayload)
    comments: list[CommentPayload] = field(default_factory=list)
    images: list[dict] = field(default_factory=list)
    resume_session_id: str | None = None
    linear_access_token: str = ""
    prompt_context: str = ""  # Linear-provided XML context for agent sessions
    agent_session_id: str = ""  # Linear agent session ID for posting activities
    model: str = ""  # Model override from user settings; empty = daemon default
    permission_mode: str = ""  # Permission mode from user settings; empty = daemon default


@dataclass
class CancelMessage:
    type: Literal["cancel"] = "cancel"
    issue_id: str = ""
    reason: str = ""


@dataclass
class QuestionReplyMessage:
    type: Literal["question_reply"] = "question_reply"
    issue_id: str = ""
    reply: str = ""


CloudMessage = DispatchMessage | CancelMessage | QuestionReplyMessage


# -- Daemon → Cloud messages --


@dataclass
class AgentStartedMessage:
    type: Literal["agent_started"] = "agent_started"
    issue_id: str = ""
    session_id: str = ""


@dataclass
class ProgressMessage:
    type: Literal["progress"] = "progress"
    issue_id: str = ""
    last_event: str = ""
    turns_used: int = 0


@dataclass
class AgentCompletedMessage:
    type: Literal["agent_completed"] = "agent_completed"
    issue_id: str = ""
    session_id: str = ""
    success: bool = False
    cost_usd: float = 0.0
    num_turns: int = 0
    duration_ms: int = 0
    hit_turn_limit: bool = False
    pr_url: str = ""


@dataclass
class AgentFailedMessage:
    type: Literal["agent_failed"] = "agent_failed"
    issue_id: str = ""
    error: str = ""


@dataclass
class QuestionMessage:
    type: Literal["question"] = "question"
    issue_id: str = ""
    question: str = ""
    options: list[str] = field(default_factory=list)


@dataclass
class HeartbeatMessage:
    type: Literal["heartbeat"] = "heartbeat"


@dataclass
class DaemonConnectedMessage:
    type: Literal["daemon_connected"] = "daemon_connected"
    repo_path: str = ""
    repo_remote: str = ""
    machine_info: str = ""
    workspace_root: str = ""


DaemonMessage = (
    AgentStartedMessage
    | ProgressMessage
    | AgentCompletedMessage
    | AgentFailedMessage
    | QuestionMessage
    | HeartbeatMessage
    | DaemonConnectedMessage
)
