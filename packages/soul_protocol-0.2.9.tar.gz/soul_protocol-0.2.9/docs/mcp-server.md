<!-- Covers: MCP server setup, configuration for Claude Desktop/Cursor, all 23 tools
     (13 soul/memory + 5 context + 5 psychology), 3 resources, 2 prompts, auto-detect,
     MCP Sampling Engine, programmatic usage, and design notes.
     Updated: 2026-03-27 — v0.2.8: Fixed section header "Tools (18)" → "Tools (23)".
     Updated: 2026-03-26 — v0.2.7: Added 5 psychology pipeline tools (soul_skills,
     soul_evaluate, soul_learn, soul_evolve, soul_bond). Tool count: 18 → 23.
     Updated: 2026-03-24 — v0.2.6: Added 5 LCM context tools (soul_context_ingest,
     soul_context_assemble, soul_context_grep, soul_context_expand, soul_context_describe),
     soul_reload tool, auto-detect section, MCP Sampling Engine section. Tool count: 12 → 18.
     Updated: 2026-03-13 — added soul_list + soul_switch tools, SOUL_DIR env var, multi-soul registry notes,
     renamed soul_system_prompt to soul_system_prompt_template, added optional soul parameter docs. -->

# MCP Server

Soul Protocol includes a FastMCP-based Model Context Protocol server for agent integration. Any MCP-compatible client (Claude Desktop, Cursor, custom agents) can connect to a soul and interact with its memory, identity, and emotional state in real time.

## Installation

The MCP server requires the optional `mcp` extra:

```bash
pip install soul-protocol[mcp]
```

This pulls in `fastmcp` as a dependency. The core `soul-protocol` package has no dependency on it.

## Running

```bash
# Start with an existing soul file
SOUL_PATH=aria.soul soul-mcp

# Start empty (create a soul at runtime via the soul_birth tool)
soul-mcp
```

The server reads `SOUL_PATH` from the environment on startup. If set, it loads that soul file (`.soul`, `.json`, `.yaml`, or `.md`) before accepting connections. If not set, the server starts with no soul loaded -- clients must call `soul_birth` before using any other tool.

You can also set `SOUL_DIR` to point to a directory containing multiple soul folders (e.g. `~/.soul/`). When `SOUL_DIR` is set, the server discovers all souls in that directory and loads them into the `SoulRegistry`. The first soul found becomes the active soul. Use `soul_list` and `soul_switch` to manage which soul is active at runtime. If both `SOUL_PATH` and `SOUL_DIR` are set, `SOUL_PATH` takes priority as the initially active soul.

### Auto-detect (no env var needed)

When neither `SOUL_DIR` nor `SOUL_PATH` is set, the server auto-detects soul files:

1. **`.soul/` in CWD** — if a non-empty `.soul/` directory exists in the current working directory, it is used as `SOUL_DIR`.
2. **`~/.soul/` fallback** — if CWD has no `.soul/` (or it is empty), the server checks `~/.soul/` as a user-level default.

This means running `soul-mcp` in a project with a `.soul/` folder just works — no env vars needed.

## Configuration

### Claude Desktop (`claude_desktop_config.json`)

```json
{
  "mcpServers": {
    "soul": {
      "command": "soul-mcp",
      "env": {
        "SOUL_PATH": "/path/to/aria.soul"
      }
    }
  }
}
```

### Cursor / VS Code

Add to your MCP settings (`.cursor/mcp.json` or equivalent):

```json
{
  "mcpServers": {
    "soul": {
      "command": "soul-mcp",
      "env": {
        "SOUL_PATH": "/path/to/aria.soul"
      }
    }
  }
}
```

### Custom MCP Client

Any client that speaks the Model Context Protocol over stdio can connect. The server uses FastMCP's default stdio transport.

## Tools (23)

All tools are prefixed `soul_` to avoid name collisions when running alongside other MCP servers. The 23 tools break down as: 9 soul management, 4 memory, 5 context (LCM), and 5 psychology pipeline (v0.2.7).

**Multi-soul targeting:** When the server is running with `SOUL_DIR` and multiple souls are loaded, all tools accept an optional `soul` parameter (string) to target a specific soul by name or ID. If omitted, the tool operates on the currently active soul.

---

### `soul_birth`

Create a new soul with persistent identity and memory.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | `str` | required | The soul's name |
| `archetype` | `str` | `""` | Archetype (e.g. "The Compassionate Creator") |
| `values` | `list[str]` | `[]` | Core values for significance scoring |

**Returns:** JSON with `name`, `did`, and `status: "born"`.

---

### `soul_observe`

Process an interaction through the full psychology pipeline. Extracts facts, detects sentiment, gates episodic storage, updates the self-model.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `user_input` | `str` | required | What the user said |
| `agent_output` | `str` | required | What the agent responded |
| `channel` | `str` | `"mcp"` | Source channel identifier |

**Returns:** JSON with `status`, `mood`, and `energy`.

---

### `soul_remember`

Store a memory directly, bypassing the observe pipeline.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `content` | `str` | required | The memory content |
| `importance` | `int` | `5` | Importance on a 1-10 scale |
| `memory_type` | `str` | `"semantic"` | One of: `episodic`, `semantic`, `procedural`. The `core` type is rejected — use `soul://memory/core` resource to read core memory. |
| `emotion` | `str` | `None` | Optional emotion label (e.g. "joy", "frustration") |

**Returns:** JSON with `memory_id`, `type`, and `importance`.

---

### `soul_recall`

Search the soul's memories by natural language query. Results are ranked by ACT-R activation scoring (recency, frequency, emotional intensity, query relevance).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `query` | `str` | required | Search query |
| `limit` | `int` | `5` | Maximum number of results |

**Returns:** JSON with `count` and `memories` array. Each memory includes `id`, `type`, `content`, `importance`, and `emotion`.

---

### `soul_reflect`

Trigger a reflection and memory consolidation pass. The soul reviews recent interactions, identifies themes, summarizes patterns, and generates self-insights. Requires a `CognitiveEngine` (LLM) for full power; returns a skip status without one.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| (none) | | | |

**Returns:** JSON with `status` and either `themes`, `emotional_patterns`, `self_insight` (on success) or `reason` (on skip).

---

### `soul_state`

Get the soul's current mood, energy, focus, social battery, and lifecycle stage.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| (none) | | | |

**Returns:** JSON with `mood`, `energy`, `focus`, `social_battery`, and `lifecycle`.

---

### `soul_feel`

Update the soul's emotional state directly.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mood` | `str` | `None` | One of: `neutral`, `curious`, `focused`, `tired`, `excited`, `contemplative`, `satisfied`, `concerned` |
| `energy` | `float` | `None` | Energy **delta** (-100 to 100). Positive increases, negative decreases. Clamped to 0-100 after application. |

**Returns:** JSON with updated `mood` and `energy`.

Note: `energy` is a delta, not an absolute value. Passing `energy: -10` drains 10 points from the current level.

---

### `soul_prompt`

Generate the complete system prompt for LLM injection. Includes identity, DNA, personality traits, core memory, current state, and self-model insights.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| (none) | | | |

**Returns:** Plain text system prompt string.

---

### `soul_save`

Persist the soul to disk. Creates a directory structure with config, memory, and state files.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `path` | `str` | `None` | Base directory path. Creates `<path>/<soul_id>/` with soul data. Uses original `SOUL_PATH` or `~/.soul/<soul_id>/` if omitted. |

**Returns:** JSON with `status` and `name`.

---

### `soul_export`

Export the soul as a portable `.soul` file (zip archive). Contains identity, DNA, memory tiers, state, and self-model -- everything needed to restore the soul on another machine.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `path` | `str` | required | Output file path (should end in `.soul`) |

**Returns:** JSON with `status`, `path`, and `name`.

---

### `soul_list`

List all souls known to the server. When running with `SOUL_DIR`, this returns every soul in the registry. When running with a single `SOUL_PATH`, it returns that one soul.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| (none) | | | |

**Returns:** JSON with `souls` array. Each entry includes `name`, `did`, `active` (boolean), and `lifecycle`.

---

### `soul_switch`

Switch the active soul. The newly active soul becomes the target for all subsequent tool calls that omit the `soul` parameter.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `soul` | `str` | required | Name or DID of the soul to activate |

**Returns:** JSON with `status`, `name`, and `did` of the newly active soul. Returns an error if the soul is not found in the registry.

---

### `soul_reload`

Reload a soul from disk, picking up any changes made externally (e.g. by another process, a different session, or manual editing). The in-memory soul is replaced with the freshly loaded version.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `status`, `name`, `path`, `format`, and `memories` count.

---

## Psychology Pipeline Tools (5) — v0.2.7

### `soul_skills`

View the soul's learned skills with level, XP, and progress.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `soul` | string | No | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `skills` array (id, name, level, xp, xp_to_next) and `total` count.

### `soul_evaluate`

Evaluate an interaction against a rubric and build evaluation history.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `user_input` | string | Yes | What the user said |
| `agent_output` | string | Yes | What the agent responded |
| `domain` | string | No | Self-model domain for rubric selection (auto-detected if omitted) |
| `soul` | string | No | Target soul name |

**Returns:** JSON with `rubric`, `overall_score`, `criteria` array, `learning` string, and `eval_history_size`.

### `soul_learn`

Evaluate an interaction and create a learning event if notable.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `user_input` | string | Yes | What the user said |
| `agent_output` | string | Yes | What the agent responded |
| `domain` | string | No | Domain for rubric selection |
| `soul` | string | No | Target soul name |

**Returns:** JSON with `learning_event` (id, lesson, domain, score, confidence, skill_id) or null if score is in medium range.

### `soul_evolve`

Manage soul evolution — propose, approve, reject, or list trait mutations.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | No | One of: `list`, `propose`, `approve`, `reject` (default: `list`) |
| `trait` | string | No | Trait path (e.g. `communication.warmth`) — for propose |
| `new_value` | string | No | New value for the trait — for propose |
| `reason` | string | No | Why this mutation is proposed — for propose |
| `mutation_id` | string | No | ID of mutation to approve/reject |
| `soul` | string | No | Target soul name |

**Returns:** JSON with `pending` mutations array and `history_count` (for list), or mutation details (for propose/approve/reject).

### `soul_bond`

View or modify the soul's bond strength.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `strengthen` | float | No | Amount to strengthen (negative to weaken). Omit to just view. |
| `soul` | string | No | Target soul name |

**Returns:** JSON with `bond_strength` and `interaction_count`.

---

## Context Tools — LCM (5)

Lossless Context Management tools for within-session context. Messages go into an immutable SQLite store. Three-level compaction runs automatically when the token budget is approached: Summary (LLM), Bullets (LLM), Truncation (deterministic). After compaction, `grep` still searches originals and `expand` recovers them — nothing is lost.

---

### `soul_context_ingest`

Ingest a message into the soul's context store. Messages are immutable once stored. Compaction runs automatically when the token budget is approached.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `role` | `str` | required | Message role (e.g. `"user"`, `"assistant"`, `"system"`) |
| `content` | `str` | required | Message content text |
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `message_id`, `soul`, `total_messages`, and `total_tokens`.

---

### `soul_context_assemble`

Assemble a context window that fits within the token budget. Returns ordered nodes (verbatim + compacted) ready for LLM injection. Applies three-level compaction as needed.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `max_tokens` | `int` | `100000` | Token budget for the assembled context |
| `system_reserve` | `int` | `0` | Tokens to reserve for system prompts / tool schemas |
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `soul`, `node_count`, `total_tokens`, `compaction_applied`, and `nodes` array. Each node includes `level`, `content`, `token_count`, and `seq_range`.

---

### `soul_context_grep`

Search the soul's context history by regex pattern. Searches the immutable message store — even compacted messages are searchable since originals are never deleted.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pattern` | `str` | required | Regex pattern to search for |
| `limit` | `int` | `20` | Maximum number of results |
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `soul`, `count`, and `results` array. Each result includes `message_id`, `seq`, `role`, and `snippet`.

---

### `soul_context_expand`

Expand a compacted node back to its original messages. Walks the DAG to recover verbatim content that was summarized or truncated. This is the "lossless" in Lossless Context Management.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `node_id` | `str` | required | The ID of the compacted node to expand |
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `soul`, `node_id`, `level`, `original_count`, and `messages` array. Each message includes `id`, `role`, `content`, and `seq`.

---

### `soul_context_describe`

Get a metadata snapshot of the soul's context store. Returns message count, token totals, date range, and compaction statistics.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `soul` | `str` | `None` | Target soul name (uses active soul if omitted) |

**Returns:** JSON with `soul`, `total_messages`, `total_nodes`, `total_tokens`, `compaction_stats`, and `date_range`.

---

## MCP Sampling Engine

When running as an MCP server inside Claude Code, Claude Desktop, or any MCP host, the soul delegates cognitive tasks (sentiment analysis, fact extraction, entity extraction, significance scoring, reflection, context compaction) to the **host LLM** via `ctx.sample()`. No API key is needed — the host provides the model.

The engine is lazily constructed on the first tool call that carries a FastMCP Context. Once created, it is wired into all loaded souls via `Soul.set_engine()` and reused for the remainder of the session. Tools that trigger cognitive work (`soul_observe`, `soul_reflect`, `soul_birth`) accept a `ctx` parameter for this purpose.

Without an MCP host (e.g. when using the Python API directly), you can plug in any LLM by implementing the `CognitiveEngine` protocol (`async def think(self, prompt: str) -> str`). Without any engine, the soul falls back to heuristic processing (pattern-based sentiment, rule-based fact extraction).

---

## Resources (3)

Resources provide read-only access to soul data. MCP clients can subscribe to these URIs for live state.

| URI | Returns |
|-----|---------|
| `soul://identity` | Full identity JSON: DID, name, archetype, born date, bonded_to, core values, origin story |
| `soul://memory/core` | Core memory: `persona` (self-description) and `human` (what the soul knows about the user) |
| `soul://state` | Current state: mood, energy, focus, social battery, lifecycle stage |

## Prompts (2)

Prompts are pre-built text templates that MCP clients can request.

| Name | Purpose |
|------|---------|
| `soul_system_prompt_template` | Complete system prompt template for LLM context injection. Combines DNA, identity, core memory, state, and self-model into a single prompt string. (Renamed from `soul_system_prompt` in v0.2.3.) |
| `soul_introduction` | First-person self-introduction. Example: "I'm Aria, The Compassionate Creator. My core values are empathy, curiosity. I'm currently feeling curious with 85% energy." |

## Programmatic Usage

You can also use the MCP server from Python without running it as a subprocess:

```python
from fastmcp import Client
from soul_protocol.mcp import create_server

mcp = create_server()

# Use with FastMCP's in-process client
async with Client(mcp) as client:
    result = await client.call_tool("soul_birth", {"name": "Aria"})
    print(result.data)

# Or compose with other MCP servers in a larger system
```

## Design Notes

- **Multi-soul via SoulRegistry.** When `SOUL_DIR` is set, the server loads all discovered souls into a `SoulRegistry` and exposes `soul_list` / `soul_switch` for runtime selection. One soul is active at a time; all tools default to it unless a `soul` parameter is provided. For single-soul setups (`SOUL_PATH` only), the registry holds one entry and `soul_switch` is a no-op.
- **All tools are prefixed `soul_`.** This avoids name collisions when a client connects to several MCP servers simultaneously (e.g. soul + filesystem + database).
- **Global state -- not thread-safe.** The server uses module-level state. Do not call `soul_observe` concurrently from multiple threads. Sequential tool calls from a single MCP client are fine.
- **Stateful lifecycle.** The soul persists in memory across tool calls within a session. Call `soul_save` or `soul_export` to persist before the server shuts down.
