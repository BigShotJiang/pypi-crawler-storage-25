---
id: ""
title: ""
status: pending
type: feature
tags: [refine]
business_value: 0
story_points: 1
parent: ""
assignee: ""
created: ""
---

## Description

<!-- One-line summary of what the user/agent experiences when this is done -->

## Context

<!-- Why this story exists — what problem it solves, what user need it addresses.
     Link to ADRs or research docs that informed this decision. -->

## Behavior

<!-- Spec-driven scenarios in Given/When/Then format.
     These are the contract — tests are derived from these. -->

### Scenario: [name]

- **Given** [precondition]
- **When** [action]
- **Then** [expected outcome]

## Constraints

<!-- Non-functional requirements, boundaries, performance targets.
     What must NOT happen is as important as what must. -->

## Verification

<!-- How to confirm this story is done. Maps directly to test suites.
     Workflow: write spec → derive tests from behavior → implement → verify. -->

- [ ] ...

## References

<!-- Links to ADRs, research docs, related specs, or external resources -->

---
<!-- ═══ Fill during/after implementation ═══ -->

## Implementation Summary

<!-- Filled at completion. Concise digest of what was built, key decisions,
     and outcomes — so future readers don't need to parse the full spec. -->

## Implementation Notes

<!-- Filled during implementation. Append decisions, trade-offs, and
     references as work progresses. -->
