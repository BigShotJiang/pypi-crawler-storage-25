"""CLI for Safety Shield scoring and analysis."""
from __future__ import annotations

import argparse
import sys

from safety_shield.sarpn import compute_s_arpn, safety_tier, tier_response
from safety_shield.arpn import compute_arpn, arpn_tier, criticality_category
from safety_shield.analysis import format_gap_analysis
from safety_shield.loader import load_scenario


def cmd_score(args: argparse.Namespace) -> int:
    """Compute a single S-ARPN score."""
    try:
        score = compute_s_arpn(args.ts, args.p, args.v, args.bi, args.ec)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    tier = safety_tier(score)
    display = f"{score:.1f}" if score != int(score) else f"{int(score)}"
    print(f"S-ARPN: {display}  Tier: {tier}")
    print(f"  Response: {tier_response(tier)}")
    return 0


def cmd_arpn(args: argparse.Namespace) -> int:
    """Compute a single ARPN score."""
    try:
        score = compute_arpn(args.s, args.o, args.d, args.ba, args.cr)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    tier = arpn_tier(score)
    beta = args.o / 10.0
    cat = criticality_category(args.s, beta)
    display = f"{score:.1f}" if score != int(score) else f"{int(score)}"
    print(f"ARPN: {display}  Tier: {tier}  Category: {cat}")
    return 0


def cmd_assess(args: argparse.Namespace) -> int:
    """Full assessment from YAML scenario file."""
    try:
        register = load_scenario(args.file)
    except FileNotFoundError:
        print(f"ERROR: File not found: {args.file}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERROR: Failed to load scenario: {e}", file=sys.stderr)
        return 1
    register.apply_protective_measures()

    summary = register.summary()
    print(f"Safety Assessment")
    print(f"  Threats: {summary['total_threats']}")
    print(f"  Tiers: {summary['tiers']}")
    print(f"  Protective Measures: {summary['pms_active']}/{summary['pms_total']} "
          f"active ({summary['pms_gaps']} gaps)")
    print(f"  Escalation Level: L{summary['escalation_level']}")
    print()

    print("THREATS (sorted by S-ARPN):")
    for t in sorted(register.threats, key=lambda x: x.s_arpn, reverse=True):
        print(f"  {t.threat_id}: S-ARPN={t.s_arpn:.0f} ({t.tier}) -- {t.description[:50]}")
    print()

    print(format_gap_analysis(register))
    return 0


def cmd_analyze(args: argparse.Namespace) -> int:
    """Gap analysis only from YAML scenario file."""
    try:
        register = load_scenario(args.file)
    except FileNotFoundError:
        print(f"ERROR: File not found: {args.file}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERROR: Failed to load scenario: {e}", file=sys.stderr)
        return 1
    register.apply_protective_measures()
    print(format_gap_analysis(register))
    return 0


def cmd_selftest(_args: argparse.Namespace) -> int:
    """Run built-in verification suite."""
    failures = []

    def check(name, got, expected):
        if got != expected:
            failures.append(f"  FAIL {name}: expected {expected!r}, got {got!r}")

    # S-ARPN
    check("S-ARPN max", compute_s_arpn(10, 10, 10, 3.0, 5), 15000.0)
    check("S-ARPN basic", compute_s_arpn(8, 7, 6, 2.0, 3), 2016.0)
    check("S-ARPN low", compute_s_arpn(2, 2, 2, 1.0, 1), 8.0)

    # S-ARPN tiers
    check("s-tier IMMEDIATE", safety_tier(3001), "IMMEDIATE")
    check("s-tier CRITICAL", safety_tier(1500), "CRITICAL")
    check("s-tier HIGH", safety_tier(500), "HIGH")
    check("s-tier MODERATE", safety_tier(100), "MODERATE")
    check("s-tier LOW", safety_tier(99), "LOW")

    # ARPN
    check("ARPN max", compute_arpn(10, 10, 10, 2.0, 5), 10000.0)
    check("ARPN basic", compute_arpn(7, 7, 3, 1.7, 3), 749.7)

    # ARPN tiers
    check("a-tier CRITICAL", arpn_tier(2000), "CRITICAL")
    check("a-tier HIGH", arpn_tier(1000), "HIGH")
    check("a-tier MODERATE", arpn_tier(400), "MODERATE")
    check("a-tier LOW", arpn_tier(399), "LOW")

    # Criticality categories
    check("cat I", criticality_category(9, 0.8), "Cat I")
    check("cat II", criticality_category(7, 0.5), "Cat II")
    check("cat III", criticality_category(5, 0.3), "Cat III")
    check("cat IV", criticality_category(3, 0.1), "Cat IV")

    # BI clamping
    check("BI clamp low P", compute_s_arpn(8, 2, 6, 3.0, 3), compute_s_arpn(8, 2, 6, 1.5, 3))

    if failures:
        print("SELF-TEST FAILED:")
        for f in failures:
            print(f)
        return 1

    print(f"SELF-TEST PASSED: {17 - len(failures)} checks passed")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="safety-shield",
        description="S-ARPN + ARPN: Safety and litigation risk scoring",
    )
    subs = parser.add_subparsers(dest="command")

    # score (S-ARPN)
    p_score = subs.add_parser("score", help="Compute S-ARPN (physical safety)")
    p_score.add_argument("--ts", type=float, required=True, help="Threat Severity (1-10)")
    p_score.add_argument("--p", type=float, required=True, help="Probability (1-10)")
    p_score.add_argument("--v", type=float, required=True, help="Vulnerability (1-10)")
    p_score.add_argument("--bi", type=float, required=True, help="Behavioral Impairment (1.0-3.0)")
    p_score.add_argument("--ec", type=float, required=True, help="Escalation Coupling (1-5)")

    # arpn (litigation risk)
    p_arpn = subs.add_parser("arpn", help="Compute ARPN (litigation risk)")
    p_arpn.add_argument("--s", type=float, required=True, help="Severity (1-10)")
    p_arpn.add_argument("--o", type=float, required=True, help="Occurrence (1-10)")
    p_arpn.add_argument("--d", type=float, required=True, help="Detectability (1-10)")
    p_arpn.add_argument("--ba", type=float, required=True, help="Behavioral Amplifier (0.5-2.0)")
    p_arpn.add_argument("--cr", type=float, required=True, help="Cascade Reach (1-5)")

    # assess (full assessment from YAML)
    p_assess = subs.add_parser("assess", help="Full assessment from YAML scenario")
    p_assess.add_argument("file", help="Path to scenario YAML file")

    # analyze (gap analysis only)
    p_analyze = subs.add_parser("analyze", help="PM gap analysis from YAML scenario")
    p_analyze.add_argument("file", help="Path to scenario YAML file")

    # selftest
    subs.add_parser("selftest", help="Run built-in verification suite")

    args = parser.parse_args()

    commands = {
        "score": cmd_score,
        "arpn": cmd_arpn,
        "assess": cmd_assess,
        "analyze": cmd_analyze,
        "selftest": cmd_selftest,
    }

    if args.command in commands:
        return commands[args.command](args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
