"""Gap analysis engine for protective measures.

Simulates applying each unimplemented PM and shows the S-ARPN reduction.
Answers: "Which measure should I implement next for maximum safety improvement?"
"""
from __future__ import annotations

import copy
from dataclasses import dataclass

from safety_shield.threats import SafetyRegister, SafetyThreat


@dataclass
class PMRecommendation:
    """A single protective measure recommendation with projected impact."""
    pm_id: str
    pm_description: str
    target_threat_id: str
    before_sarpn: float
    after_sarpn: float
    reduction: float
    before_tier: str
    after_tier: str
    tier_changed: bool


def gap_analysis(register: SafetyRegister) -> list[PMRecommendation]:
    """Analyze unimplemented PMs and rank by S-ARPN reduction.

    For each not_started PM, simulates applying it to each targeted threat
    and computes the S-ARPN delta. Returns recommendations sorted by
    reduction (largest first).

    Args:
        register: SafetyRegister with threats and PMs (PMs already applied)

    Returns:
        List of PMRecommendation sorted by reduction descending
    """
    unimplemented = [pm for pm in register.protective_measures
                     if pm.status == "not_started"]

    recommendations: list[PMRecommendation] = []

    for pm in unimplemented:
        best_reduction = 0.0
        best_rec = None

        for threat in register.threats:
            if threat.threat_id in pm.targets:
                # Deep copy to simulate without mutating
                sim_threat = copy.deepcopy(threat)
                before = sim_threat.s_arpn
                before_tier = sim_threat.tier

                if pm.reduces_v > 0:
                    sim_threat.v *= (1.0 - pm.reduces_v)
                    sim_threat.v = max(1.0, sim_threat.v)
                if pm.reduces_p > 0:
                    sim_threat.p *= (1.0 - pm.reduces_p)
                    sim_threat.p = max(1.0, sim_threat.p)
                sim_threat.recompute()

                reduction = before - sim_threat.s_arpn
                if reduction > best_reduction:
                    best_reduction = reduction
                    best_rec = PMRecommendation(
                        pm_id=pm.pm_id,
                        pm_description=pm.description,
                        target_threat_id=sim_threat.threat_id,
                        before_sarpn=before,
                        after_sarpn=sim_threat.s_arpn,
                        reduction=reduction,
                        before_tier=before_tier,
                        after_tier=sim_threat.tier,
                        tier_changed=before_tier != sim_threat.tier,
                    )

        if best_rec:
            recommendations.append(best_rec)

    recommendations.sort(key=lambda r: r.reduction, reverse=True)
    return recommendations


def format_gap_analysis(register: SafetyRegister) -> str:
    """Format gap analysis as a readable string."""
    recs = gap_analysis(register)
    if not recs:
        return "All protective measures are active. No gaps."

    lines = [f"GAP ANALYSIS: {len(recs)} unimplemented measures", ""]

    for rec in recs:
        tier_note = f" ({rec.before_tier} -> {rec.after_tier})" if rec.tier_changed else ""
        lines.append(f"  {rec.pm_id}: {rec.pm_description}")
        lines.append(f"    Impact on {rec.target_threat_id}: "
                     f"S-ARPN {rec.before_sarpn:.0f} -> {rec.after_sarpn:.0f} "
                     f"(-{rec.reduction:.0f}){tier_note}")
        lines.append("")

    return "\n".join(lines)
