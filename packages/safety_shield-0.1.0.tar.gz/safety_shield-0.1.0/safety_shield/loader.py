"""Load safety scenarios from YAML files."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from safety_shield.threats import (
    EscalationLevel,
    ProtectiveMeasure,
    SafetyRegister,
    SafetyThreat,
)


def load_scenario(path: str | Path) -> SafetyRegister:
    """Load a safety scenario from a YAML file.

    Expected format:
        threats:
          - id: ST-001
            description: "..."
            ts: 7
            p: 6
            v: 5
            bi: 2.0
            ec: 3

        protective_measures:
          - id: PM-001
            description: "..."
            status: done
            reduces_v: 0.1
            reduces_p: 0.15
            targets: [ST-001]

        escalation_ladder:
          - level: 1
            description: "..."
            observed: true
    """
    path = Path(path)
    data = yaml.safe_load(path.read_text())

    threats = []
    for t in data.get("threats", []):
        threats.append(SafetyThreat(
            threat_id=t["id"],
            description=t.get("description", ""),
            ts=float(t.get("ts", 1)),
            p=float(t.get("p", 1)),
            v=float(t.get("v", 1)),
            bi=float(t.get("bi", 1.0)),
            ec=float(t.get("ec", 1)),
        ))

    measures = []
    for pm in data.get("protective_measures", []):
        measures.append(ProtectiveMeasure(
            pm_id=pm["id"],
            description=pm.get("description", ""),
            status=pm.get("status", "not_started"),
            reduces_v=float(pm.get("reduces_v", 0)),
            reduces_p=float(pm.get("reduces_p", 0)),
            targets=pm.get("targets", []),
        ))

    escalation = []
    for el in data.get("escalation_ladder", []):
        escalation.append(EscalationLevel(
            level=int(el["level"]),
            description=el.get("description", ""),
            observed=el.get("observed", False),
        ))

    # Reverse-map PM targets to threat.mitigated_by
    for threat in threats:
        threat.mitigated_by = [
            pm.pm_id for pm in measures
            if threat.threat_id in pm.targets
        ]

    # Determine current escalation level
    observed = [el.level for el in escalation if el.observed]
    current_level = max(observed) if observed else 0

    return SafetyRegister(
        threats=threats,
        protective_measures=measures,
        escalation_ladder=sorted(escalation, key=lambda e: e.level),
        current_escalation_level=current_level,
    )
