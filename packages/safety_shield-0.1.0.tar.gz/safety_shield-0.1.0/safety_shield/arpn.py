"""ARPN: Adjusted Risk Priority Number for litigation risk.

Five-dimension scoring adapted from aerospace FMEA (MIL-STD-1629A)
to legal risk assessment.

    ARPN = S x O x D x BA x CR

    S:  Severity (1-10)
    O:  Occurrence/probability (1-10)
    D:  Detectability (1-10, higher = harder to detect)
    BA: Behavioral Amplifier (0.5-2.0)
    CR: Cascade Reach (1-5)

    Maximum: 10 x 10 x 10 x 2.0 x 5 = 10,000
"""
from __future__ import annotations

# ARPN = S x O x D x BA x CR
# Max = 10 x 10 x 10 x 2.0 x 5 = 10,000
MAX_ARPN = 10_000.0

# Tier thresholds
TIER_CRITICAL = 2000
TIER_HIGH = 1000
TIER_MODERATE = 400


def compute_arpn(
    s: float,
    o: float,
    d: float,
    ba: float,
    cr: float,
) -> float:
    """Compute ARPN = S x O x D x BA x CR.

    Args:
        s: Severity (1-10). Case-level consequence if failure materializes.
        o: Occurrence (1-10). Probability of the failure mode.
        d: Detectability (1-10). How late we detect it (10 = no warning).
        ba: Behavioral Amplifier (0.5-2.0). Psychological distortion.
        cr: Cascade Reach (1-5). Cross-game impact.

    Returns:
        ARPN score, capped at MAX_ARPN (10,000).
    """
    # Validate ranges
    if not (1 <= s <= 10):
        raise ValueError(f"S must be 1-10, got {s}")
    if not (1 <= o <= 10):
        raise ValueError(f"O must be 1-10, got {o}")
    if not (1 <= d <= 10):
        raise ValueError(f"D must be 1-10, got {d}")
    if not (1 <= cr <= 5):
        raise ValueError(f"CR must be 1-5, got {cr}")

    ba = max(0.5, min(2.0, ba))
    return min(s * o * d * ba * cr, MAX_ARPN)


def arpn_tier(arpn: float) -> str:
    """Classify ARPN into litigation risk tiers.

    Returns:
        One of: "CRITICAL", "HIGH", "MODERATE", "LOW"
    """
    if arpn >= TIER_CRITICAL:
        return "CRITICAL"
    if arpn >= TIER_HIGH:
        return "HIGH"
    if arpn >= TIER_MODERATE:
        return "MODERATE"
    return "LOW"


def criticality_category(severity: float, probability: float) -> str:
    """Classify into MIL-STD-1629A Criticality Categories.

    Args:
        severity: S dimension (1-10)
        probability: beta = O/10 (0.1-1.0)

    Returns:
        "Cat I" (Catastrophic), "Cat II" (Critical),
        "Cat III" (Marginal), or "Cat IV" (Minor)
    """
    if severity >= 8 and probability >= 0.6:
        return "Cat I"
    if (severity >= 6 and probability >= 0.4) or (severity >= 8 and probability >= 0.3):
        return "Cat II"
    if (severity >= 4 and probability >= 0.2) or severity >= 6:
        return "Cat III"
    return "Cat IV"
