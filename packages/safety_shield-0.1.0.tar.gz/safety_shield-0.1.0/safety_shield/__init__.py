"""Safety Shield -- S-ARPN and ARPN scoring for threat assessment.

S-ARPN (Safety-Adapted Risk Priority Number) quantifies physical safety threats.
ARPN (Adjusted Risk Priority Number) quantifies litigation risk.

Both derive from FMEA (Failure Mode and Effects Analysis) methodology,
adapted from aerospace/manufacturing to interpersonal threat scenarios.
"""
from safety_shield.sarpn import (
    MAX_S_ARPN,
    compute_s_arpn,
    safety_tier,
)
from safety_shield.arpn import (
    MAX_ARPN,
    compute_arpn,
    arpn_tier,
)
from safety_shield.threats import (
    SafetyThreat,
    ProtectiveMeasure,
    EscalationLevel,
    SafetyRegister,
)

__version__ = "0.1.0"
__all__ = [
    "MAX_S_ARPN", "compute_s_arpn", "safety_tier",
    "MAX_ARPN", "compute_arpn", "arpn_tier",
    "SafetyThreat", "ProtectiveMeasure", "EscalationLevel", "SafetyRegister",
]
