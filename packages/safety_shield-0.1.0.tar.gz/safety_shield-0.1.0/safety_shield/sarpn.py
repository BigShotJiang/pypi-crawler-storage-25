"""S-ARPN: Safety-Adapted Risk Priority Number.

Physical safety scoring with five dimensions designed for
interpersonal threat scenarios.

    S-ARPN = TS x P x V x BI x EC

    TS: Threat Severity (1-10)
    P:  Probability (1-10)
    V:  Vulnerability (1-10)
    BI: Behavioral Impairment (1.0-3.0)
    EC: Escalation Coupling (1-5)

    Maximum: 10 x 10 x 10 x 3.0 x 5 = 15,000
"""
from __future__ import annotations

# S-ARPN = TS x P x V x BI x EC
# Max = 10 x 10 x 10 x 3.0 x 5 = 15,000
MAX_S_ARPN = 15_000.0

# Tier thresholds
TIER_IMMEDIATE = 3000
TIER_CRITICAL = 1500
TIER_HIGH = 500
TIER_MODERATE = 100


def compute_s_arpn(
    ts: float,
    p: float,
    v: float,
    bi: float,
    ec: float,
    *,
    clamp_bi_when_low_p: bool = True,
) -> float:
    """Compute S-ARPN = TS x P x V x BI x EC.

    Args:
        ts: Threat Severity (1-10). 7=injury, 9=life-threatening, 10=lethal.
        p: Probability (1-10). Likelihood given current conditions.
        v: Vulnerability (1-10). Target exposure.
        bi: Behavioral Impairment (1.0-3.0). Substance use, violence risk.
        ec: Escalation Coupling (1-5). Cross-threat-vector activation.
        clamp_bi_when_low_p: If True, clamp BI to 1.5 when P < 3.
            Prevents low-probability threats from being inflated by
            high behavioral impairment scores.

    Returns:
        S-ARPN score, capped at MAX_S_ARPN (15,000).
    """
    # Validate ranges
    if not (1 <= ts <= 10):
        raise ValueError(f"TS must be 1-10, got {ts}")
    if not (1 <= p <= 10):
        raise ValueError(f"P must be 1-10, got {p}")
    if not (1 <= v <= 10):
        raise ValueError(f"V must be 1-10, got {v}")
    if not (1 <= ec <= 5):
        raise ValueError(f"EC must be 1-5, got {ec}")

    bi = max(1.0, min(3.0, bi))

    # IFM-01: clamp BI when probability is low to prevent
    # low-probability threats from being inflated by high BI
    if clamp_bi_when_low_p and p < 3:
        bi = min(bi, 1.5)

    return min(ts * p * v * bi * ec, MAX_S_ARPN)


def safety_tier(s_arpn: float) -> str:
    """Classify S-ARPN into safety response tiers.

    Returns:
        One of: "IMMEDIATE", "CRITICAL", "HIGH", "MODERATE", "LOW"
    """
    if s_arpn > TIER_IMMEDIATE:
        return "IMMEDIATE"
    if s_arpn >= TIER_CRITICAL:
        return "CRITICAL"
    if s_arpn >= TIER_HIGH:
        return "HIGH"
    if s_arpn >= TIER_MODERATE:
        return "MODERATE"
    return "LOW"


def tier_response(tier: str) -> str:
    """Get the recommended response for a tier level."""
    responses = {
        "IMMEDIATE": "Call 911. Leave location. Activate emergency contacts.",
        "CRITICAL": "File LE report within 24 hours. Activate protective measures.",
        "HIGH": "Protective measures review. Update LE documentation. Vary routine.",
        "MODERATE": "Maintain awareness. Monitor for escalation indicators.",
        "LOW": "Monitor. Log observations.",
    }
    return responses.get(tier, "Unknown tier")
