"""Data structures for safety threats, protective measures, and escalation tracking."""
from __future__ import annotations

from dataclasses import dataclass, field

from safety_shield.sarpn import MAX_S_ARPN, compute_s_arpn, safety_tier


@dataclass
class ProtectiveMeasure:
    """A single protective measure that reduces threat exposure.

    Each PM quantifiably reduces Vulnerability (V) and/or Probability (P)
    on specific threats. The gap analysis engine uses these reductions to
    recommend which unimplemented measures provide the most S-ARPN reduction.
    """
    pm_id: str
    description: str
    status: str = "not_started"  # "done", "active", "not_started"
    reduces_v: float = 0.0      # V reduction factor (0.0-1.0)
    reduces_p: float = 0.0      # P reduction factor (0.0-1.0)
    targets: list[str] = field(default_factory=list)  # threat IDs


@dataclass
class SafetyThreat:
    """A physical safety threat scored with S-ARPN.

    Attributes:
        threat_id: Unique identifier (e.g., "ST-001")
        description: What the threat is
        ts: Threat Severity (1-10)
        p: Probability (1-10)
        v: Vulnerability (1-10)
        bi: Behavioral Impairment (1.0-3.0)
        ec: Escalation Coupling (1-5)
        mitigated_by: List of PM IDs that reduce this threat
    """
    threat_id: str
    description: str
    ts: float = 1.0
    p: float = 1.0
    v: float = 1.0
    bi: float = 1.0
    ec: float = 1.0
    mitigated_by: list[str] = field(default_factory=list)

    # Computed
    s_arpn: float = 0.0
    tier: str = "LOW"

    def __post_init__(self):
        self.recompute()

    def recompute(self):
        """Recompute S-ARPN and tier from current dimensions."""
        self.s_arpn = compute_s_arpn(self.ts, self.p, self.v, self.bi, self.ec)
        self.tier = safety_tier(self.s_arpn)


@dataclass
class EscalationLevel:
    """A level in the escalation ladder (L1-L10)."""
    level: int
    description: str = ""
    observed: bool = False


@dataclass
class SafetyRegister:
    """Aggregation of all threats, protective measures, and escalation state.

    The register is the central data structure. It holds all threats,
    all PMs, and the escalation ladder. The gap analysis engine operates
    on this register to recommend actions.
    """
    threats: list[SafetyThreat] = field(default_factory=list)
    protective_measures: list[ProtectiveMeasure] = field(default_factory=list)
    escalation_ladder: list[EscalationLevel] = field(default_factory=list)
    current_escalation_level: int = 0

    _pms_applied: bool = False

    def apply_protective_measures(self):
        """Adjust V/P on threats based on active/done protective measures.

        Idempotent: calling multiple times has no additional effect.
        The first call reduces V/P and recomputes S-ARPN.
        Subsequent calls are no-ops.
        """
        if self._pms_applied:
            return

        active_pms = [pm for pm in self.protective_measures
                      if pm.status in ("done", "active")]

        for pm in active_pms:
            for threat in self.threats:
                if threat.threat_id in pm.targets:
                    if pm.reduces_v > 0:
                        threat.v *= (1.0 - pm.reduces_v)
                        threat.v = max(1.0, threat.v)
                    if pm.reduces_p > 0:
                        threat.p *= (1.0 - pm.reduces_p)
                        threat.p = max(1.0, threat.p)
                    threat.recompute()

        self._pms_applied = True

    def active_threats(self) -> list[SafetyThreat]:
        """Threats with tier >= MODERATE."""
        return [t for t in self.threats
                if t.tier in ("IMMEDIATE", "CRITICAL", "HIGH", "MODERATE")]

    def immediate_threats(self) -> list[SafetyThreat]:
        """IMMEDIATE tier only."""
        return [t for t in self.threats if t.tier == "IMMEDIATE"]

    def summary(self) -> dict:
        """Summary statistics for the register."""
        tiers = {}
        for t in self.threats:
            tiers[t.tier] = tiers.get(t.tier, 0) + 1
        n_done = len([pm for pm in self.protective_measures
                      if pm.status in ("done", "active")])
        return {
            "total_threats": len(self.threats),
            "tiers": tiers,
            "pms_active": n_done,
            "pms_total": len(self.protective_measures),
            "pms_gaps": len(self.protective_measures) - n_done,
            "escalation_level": self.current_escalation_level,
        }
