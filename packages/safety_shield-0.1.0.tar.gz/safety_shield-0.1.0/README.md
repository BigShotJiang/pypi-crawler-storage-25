# Safety Shield

**S-ARPN: Physical safety scoring for threat assessment and protective measure planning.**

Safety Shield quantifies physical safety threats using S-ARPN (Safety-Adapted Risk Priority Number), a five-dimension scoring system. It also includes ARPN (Adjusted Risk Priority Number) for litigation risk scoring. Both derive from FMEA (Failure Mode and Effects Analysis) methodology adapted from aerospace and manufacturing.

## Who This Is For

- Anyone facing physical threats where strategic decisions (legal filings, regulatory complaints, negotiations) affect safety
- Whistleblowers facing retaliation
- Attorneys assessing client safety risk in adversarial proceedings
- Advocates and case workers managing threat situations
- Co-founder disputes, employment retaliation, or any scenario where business conflict has a safety dimension

## S-ARPN Scoring

```
S-ARPN = TS x P x V x BI x EC
```

| Dimension | Scale | Definition |
|-----------|-------|-----------|
| **TS** (Threat Severity) | 1-10 | Worst-case physical outcome. 7=injury, 9=life-threatening, 10=lethal. |
| **P** (Probability) | 1-10 | Likelihood given current conditions. |
| **V** (Vulnerability) | 1-10 | Target exposure. Protective measures reduce V. |
| **BI** (Behavioral Impairment) | 1.0-3.0 | Substance use, violence history, impulse control. Clamped to 1.5 when P < 3 to prevent low-probability inflation. |
| **EC** (Escalation Coupling) | 1-5 | How many threat vectors activate simultaneously. |

**Maximum S-ARPN:** 15,000

### Tier Thresholds

| Tier | S-ARPN | Required Response |
|------|--------|-------------------|
| **IMMEDIATE** | >3,000 | Call 911. Leave location. |
| **CRITICAL** | 1,500-3,000 | LE report within 24 hours. |
| **HIGH** | 500-1,500 | Protective measures review. |
| **MODERATE** | 100-500 | Maintain awareness. |
| **LOW** | <100 | Monitor. |

## ARPN Scoring (Litigation Risk)

```
ARPN = S x O x D x BA x CR
```

| Dimension | Scale | Definition |
|-----------|-------|-----------|
| **S** (Severity) | 1-10 | Case-level consequence if failure materializes. |
| **O** (Occurrence) | 1-10 | Probability of the failure mode. |
| **D** (Detectability) | 1-10 | How late we detect it (10 = no warning). |
| **BA** (Behavioral Amplifier) | 0.5-2.0 | Psychological distortion of rational play. |
| **CR** (Cascade Reach) | 1-5 | Cross-case impact. |

**Maximum ARPN:** 10,000. Tiers: CRITICAL (>=2000), HIGH (>=1000), MODERATE (>=400), LOW (<400).

Includes MIL-STD-1629A Criticality Categories (Cat I through Cat IV).

## Quick Start

```bash
pip install safety-shield
```

### Score a threat

```python
from safety_shield import compute_s_arpn, safety_tier

score = compute_s_arpn(ts=7, p=6, v=5, bi=2.0, ec=3)
tier = safety_tier(score)
print(f"S-ARPN: {score}  Tier: {tier}")
# S-ARPN: 1260.0  Tier: HIGH
```

### Score litigation risk

```python
from safety_shield import compute_arpn, arpn_tier

score = compute_arpn(s=7, o=7, d=3, ba=1.7, cr=3)
tier = arpn_tier(score)
print(f"ARPN: {score}  Tier: {tier}")
# ARPN: 749.7  Tier: MODERATE
```

### CLI

```bash
# S-ARPN score
safety-shield score --ts 7 --p 6 --v 5 --bi 2.0 --ec 3

# ARPN score
safety-shield arpn --s 7 --o 7 --d 3 --ba 1.7 --cr 3

# Full assessment from YAML
safety-shield assess scenario.yaml

# Gap analysis: which protective measures reduce your score most
safety-shield analyze scenario.yaml

# Self-test
safety-shield selftest
```

### Define a scenario in YAML

```yaml
# scenario.yaml
threats:
  - id: ST-001
    description: "Coordinated intimidation campaign"
    ts: 7
    p: 6
    v: 5
    bi: 2.0
    ec: 3

protective_measures:
  - id: PM-001
    description: "LE report filed"
    status: done
    reduces_v: 0.1
    reduces_p: 0.15
    targets: [ST-001]

  - id: PM-002
    description: "Security cameras"
    status: not_started
    reduces_v: 0.15
    reduces_p: 0.1
    targets: [ST-001]

escalation_ladder:
  - level: 1
    description: "Verbal threats via proxy"
    observed: true
  - level: 2
    description: "Professional targeting"
    observed: false
```

## Protective Measures

Each protective measure quantifiably reduces V (vulnerability) and/or P (probability) on specific threats. The gap analysis engine simulates applying each unimplemented measure and shows which ones reduce your S-ARPN the most.

```bash
safety-shield analyze scenario.yaml
```

```
GAP ANALYSIS: 1 unimplemented measures

  PM-002: Security cameras
    Impact on ST-001: S-ARPN 1071 -> 820 (-251)
```

## Provenance

S-ARPN was developed by applying failure analysis methodologies from aerospace (MIL-STD-1629A), manufacturing, and fraud analytics to physical safety threats. The FMEA lineage spans hyperscale cloud infrastructure, manufacturing, NASA/FMECA, and fraud analytics.

## Citation

```bibtex
@misc{mcnamara2026sarpn,
  author = {McNamara, Colin},
  title = {S-ARPN: Safety-Adapted Risk Priority Number for Physical Threat Assessment},
  year = {2026},
  publisher = {Colin McNamara LLC},
  howpublished = {\url{https://github.com/acquit-ai/safety-shield}}
}
```

## Contributing

If you're in a situation where you need this tool, you're not alone. If you have expertise in threat assessment, safety advocacy, or safety engineering and want to improve the methodology, PRs are welcome.

## License

MIT. See [LICENSE](LICENSE).
