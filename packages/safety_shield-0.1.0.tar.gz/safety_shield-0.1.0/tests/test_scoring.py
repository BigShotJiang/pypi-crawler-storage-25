"""Tests for S-ARPN and ARPN scoring."""
import pytest

from safety_shield.sarpn import MAX_S_ARPN, compute_s_arpn, safety_tier
from safety_shield.arpn import MAX_ARPN, compute_arpn, arpn_tier, criticality_category
from safety_shield.threats import SafetyThreat, ProtectiveMeasure, SafetyRegister
from safety_shield.analysis import gap_analysis


class TestSARPN:
    def test_formula(self):
        assert compute_s_arpn(8, 7, 6, 2.0, 3) == 2016.0

    def test_max(self):
        assert compute_s_arpn(10, 10, 10, 3.0, 5) == MAX_S_ARPN
        assert MAX_S_ARPN == 15000.0

    def test_rejects_out_of_range(self):
        with pytest.raises(ValueError):
            compute_s_arpn(0, 5, 5, 1.0, 2)  # TS below 1
        with pytest.raises(ValueError):
            compute_s_arpn(11, 5, 5, 1.0, 2)  # TS above 10
        with pytest.raises(ValueError):
            compute_s_arpn(5, 5, 5, 1.0, 6)  # EC above 5

    def test_bi_clamp_low_p(self):
        # When P < 3, BI should be clamped to 1.5
        score_clamped = compute_s_arpn(8, 2, 6, 3.0, 3)
        score_manual = compute_s_arpn(8, 2, 6, 1.5, 3)
        assert score_clamped == score_manual

    def test_bi_no_clamp_high_p(self):
        # When P >= 3, BI should NOT be clamped
        score = compute_s_arpn(8, 5, 6, 3.0, 3)
        assert score == 8 * 5 * 6 * 3.0 * 3

    def test_bi_floor(self):
        # BI below 1.0 should be clamped to 1.0
        score = compute_s_arpn(5, 5, 5, 0.5, 2)
        assert score == 5 * 5 * 5 * 1.0 * 2


class TestSafetyTier:
    def test_immediate(self):
        assert safety_tier(3001) == "IMMEDIATE"

    def test_critical(self):
        assert safety_tier(1500) == "CRITICAL"
        assert safety_tier(3000) == "CRITICAL"

    def test_high(self):
        assert safety_tier(500) == "HIGH"
        assert safety_tier(1499) == "HIGH"

    def test_moderate(self):
        assert safety_tier(100) == "MODERATE"
        assert safety_tier(499) == "MODERATE"

    def test_low(self):
        assert safety_tier(99) == "LOW"
        assert safety_tier(0) == "LOW"


class TestARPN:
    def test_formula(self):
        assert compute_arpn(7, 7, 3, 1.7, 3) == pytest.approx(749.7)

    def test_max(self):
        assert compute_arpn(10, 10, 10, 2.0, 5) == MAX_ARPN
        assert MAX_ARPN == 10000.0

    def test_ba_clamp(self):
        # BA below 0.5 should be clamped
        score = compute_arpn(5, 5, 5, 0.1, 2)
        assert score == 5 * 5 * 5 * 0.5 * 2

    def test_rejects_out_of_range(self):
        with pytest.raises(ValueError):
            compute_arpn(0, 5, 5, 1.0, 2)  # S below 1
        with pytest.raises(ValueError):
            compute_arpn(5, 5, 5, 1.0, 6)  # CR above 5


class TestARPNTier:
    def test_critical(self):
        assert arpn_tier(2000) == "CRITICAL"

    def test_high(self):
        assert arpn_tier(1000) == "HIGH"

    def test_moderate(self):
        assert arpn_tier(400) == "MODERATE"

    def test_low(self):
        assert arpn_tier(399) == "LOW"


class TestCriticalityCategory:
    def test_cat_i(self):
        assert criticality_category(9, 0.8) == "Cat I"

    def test_cat_ii(self):
        assert criticality_category(7, 0.5) == "Cat II"

    def test_cat_iii(self):
        assert criticality_category(5, 0.3) == "Cat III"

    def test_cat_iv(self):
        assert criticality_category(3, 0.1) == "Cat IV"


class TestProtectiveMeasures:
    def test_apply_reduces_v(self):
        threat = SafetyThreat(threat_id="ST-001", description="test",
                              ts=8, p=7, v=6, bi=2.0, ec=3)
        original_sarpn = threat.s_arpn
        pm = ProtectiveMeasure(pm_id="PM-001", description="cameras",
                               status="done", reduces_v=0.2,
                               targets=["ST-001"])
        register = SafetyRegister(threats=[threat], protective_measures=[pm])
        register.apply_protective_measures()
        assert threat.s_arpn < original_sarpn
        assert threat.v < 6

    def test_idempotent(self):
        threat = SafetyThreat(threat_id="ST-001", description="test",
                              ts=8, p=7, v=6, bi=2.0, ec=3)
        pm = ProtectiveMeasure(pm_id="PM-001", description="cameras",
                               status="done", reduces_v=0.2,
                               targets=["ST-001"])
        register = SafetyRegister(threats=[threat], protective_measures=[pm])
        register.apply_protective_measures()
        sarpn_after_first = threat.s_arpn
        register.apply_protective_measures()  # second call
        assert threat.s_arpn == sarpn_after_first  # no change

    def test_not_started_not_applied(self):
        threat = SafetyThreat(threat_id="ST-001", description="test",
                              ts=8, p=7, v=6, bi=2.0, ec=3)
        original_sarpn = threat.s_arpn
        pm = ProtectiveMeasure(pm_id="PM-001", description="cameras",
                               status="not_started", reduces_v=0.2,
                               targets=["ST-001"])
        register = SafetyRegister(threats=[threat], protective_measures=[pm])
        register.apply_protective_measures()
        assert threat.s_arpn == original_sarpn


class TestGapAnalysis:
    def test_recommends_unimplemented(self):
        threat = SafetyThreat(threat_id="ST-001", description="test",
                              ts=8, p=7, v=6, bi=2.0, ec=3)
        pm = ProtectiveMeasure(pm_id="PM-001", description="cameras",
                               status="not_started", reduces_v=0.2,
                               targets=["ST-001"])
        register = SafetyRegister(threats=[threat], protective_measures=[pm])
        recs = gap_analysis(register)
        assert len(recs) == 1
        assert recs[0].pm_id == "PM-001"
        assert recs[0].reduction > 0

    def test_no_recs_when_all_active(self):
        threat = SafetyThreat(threat_id="ST-001", description="test",
                              ts=8, p=7, v=6, bi=2.0, ec=3)
        pm = ProtectiveMeasure(pm_id="PM-001", description="cameras",
                               status="done", reduces_v=0.2,
                               targets=["ST-001"])
        register = SafetyRegister(threats=[threat], protective_measures=[pm])
        register.apply_protective_measures()
        recs = gap_analysis(register)
        assert len(recs) == 0
