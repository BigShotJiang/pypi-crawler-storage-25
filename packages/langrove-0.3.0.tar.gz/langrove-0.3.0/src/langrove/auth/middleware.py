"""FastAPI auth middleware."""

from __future__ import annotations

from typing import Any

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from langrove.auth.base import AuthHandler
from langrove.exceptions import AuthError


class AuthMiddleware(BaseHTTPMiddleware):
    """Authenticates requests using the configured AuthHandler.

    Skips auth for health endpoints and docs.
    Stores both the authenticated user and the Auth instance (if any)
    on ``request.state`` for downstream authorization.
    """

    # Paths that don't require authentication
    SKIP_PATHS = {"/ok", "/health", "/info", "/docs", "/openapi.json", "/redoc"}

    def __init__(self, app: Any, handler: AuthHandler):
        super().__init__(app)
        self._handler = handler
        # Expose the langgraph_sdk.Auth instance for authorization (None for plain function auth)
        self._auth = getattr(handler, "auth", None)

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Skip auth for CORS preflight requests
        if request.method == "OPTIONS":
            return await call_next(request)

        # Skip auth for health/docs endpoints
        if request.url.path in self.SKIP_PATHS:
            return await call_next(request)

        # Extract headers
        headers = {k: v for k, v in request.headers.items()}

        try:
            user = await self._handler.authenticate(
                headers,
                method=request.method,
                path=request.url.path,
            )
        except AuthError as e:
            from fastapi.responses import JSONResponse

            return JSONResponse(
                status_code=401,
                content={"code": "unauthorized", "message": str(e)},
            )
        except Exception as e:
            from fastapi.responses import JSONResponse

            return JSONResponse(
                status_code=500,
                content={"code": "auth_error", "message": str(e)},
            )

        if user is None:
            from fastapi.responses import JSONResponse

            return JSONResponse(
                status_code=401,
                content={"code": "unauthorized", "message": "Authentication failed"},
            )

        # Store user and auth instance for downstream access
        request.state.user = user
        request.state.auth = self._auth

        return await call_next(request)
