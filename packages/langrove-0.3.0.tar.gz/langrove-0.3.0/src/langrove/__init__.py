"""Langrove: Open-source, self-hosted LangGraph deployment server."""

__version__ = "0.3.0"
