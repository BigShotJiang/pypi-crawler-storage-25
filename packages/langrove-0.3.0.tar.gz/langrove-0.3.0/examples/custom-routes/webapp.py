"""Custom routes example for Langrove — mounted via http.app in langgraph.json.

Demonstrates how to add custom endpoints alongside the default LangGraph routes.
Routes defined here share request.app.state with the main server, giving access
to the checkpointer, graph_registry, and any other langrove state.
"""

from fastapi import FastAPI, Request

app = FastAPI()


@app.get("/hello")
def hello():
    return {"Hello": "World"}


@app.get("/status")
def status():
    return {"status": "ok"}


@app.get("/graphs")
async def list_graphs(request: Request):
    """Example of accessing langrove's graph registry from a custom route."""
    registry = request.app.state.graph_registry
    graphs = registry.list_graphs()
    return {"graphs": [g.graph_id for g in graphs]}
