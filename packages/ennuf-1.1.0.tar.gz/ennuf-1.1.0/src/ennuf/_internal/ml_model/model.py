#  (C) Crown Copyright, Met Office, 2023.
"""Module for representing machine learning models containing only ennuf-supported properties."""
from pathlib import Path
from typing import List, Set, Iterable

import numpy as np

from ennuf._internal.config import CONFIG
from ennuf._internal.fortran import copy_neural_net_mod, copy_svr_mod
from ennuf._internal.ml_model.base_layer import BaseLayer
from ennuf._internal.ml_model.layers import input_layer


class Model:
    """
    Class defining an ennuf model, an abstract representation of a machine learning model with far fewer features
    than those found on those in more powerful python machine learning libraries such as TensorFlow or PyTorch.
    Only features supported by ennuf are encoded, i.e. those with adequate predefined Fortran representations.
    """

    def __init__(
        self,
        name: str,
        output_names: List[str],
        description: str="",
        dtype:np.dtype=np.float32,
        formatter=None,
    ):
        """

        Parameters
        ----------
        name
         a valid fortran identifier, e.g. "ennuf_nn"
        output_names
         List of names of the network output layers,
         e.g. ["temperature_profile", "humidity_profile", "pressure_profile"]
        description
         a description of the model, which will appear as a comment in the generated file,
          e.g. "Neural network for calculating bulk cloud fraction from thermodynamic variables"
        dtype
            The type of the model weights, usually real numbers of a given precision.
        formatter
         The fortran formatter for the model to use. Defaults to ennuf.CONFIG.default_formatter() if None is provided.
        """
        self.name = name
        self.description = description
        self.dtype = dtype
        self.output_names = output_names
        self._module_name = f"{self.name}_mod"
        self.formatter = formatter if formatter is not None else CONFIG.default_formatter
        self.layers: List[BaseLayer] = []
        """
        The model's layers. Note this is a list rather than a set, so that when displayed to a user the layers
        can appear easily in the same order they specified them; but this is *not* guaranteed to be the ordering of
        the layers of a sequential model.
        """

    @property
    def layer_dict(self):
        """A dict mapping the model's layers' names to the layer objects themselves"""
        return {layer.name: layer for layer in self.layers}

    def __str__(self):
        """Writes the layers of this model and some info about itself."""
        description = f"An ML model with dtype {self.dtype} the following layers:\n"
        for layer in self.layers:
            description += str(layer) + ";\n"
        return description

    @property
    def inputs(self) -> Iterable[input_layer.InputLayer]:
        """Returns a filtered list of the model's layers containing only the input layers."""
        return filter(lambda layer: isinstance(layer, input_layer.InputLayer), self.layers)

    @property
    def outputs(self) -> Iterable[BaseLayer]:
        """Returns a filtered list of the model's layers containing only the input layers."""
        return filter(lambda layer: layer.name in self.output_names, self.layers)

    @property
    def layer_types_used(self) -> Set:
        return set(type(layer) for layer in self.layers)

    def to_fortran(self) -> str:
        return (
            f"{self._fortran_file_head()}"
            f"{self._fortran_module_head()}"
            f"{self._fortran_subroutine()}"
            f"{self._fortran_module_tail()}"
        )

    def create_fortran_module(self, file: Path | str, overwrite: bool = False, include_neural_net_mod=True, include_svr_mod=False) -> None:
        mode = "w" if overwrite else "x"

        if not isinstance(file, Path):
            file = Path(file)
        with open(file, mode, encoding="utf-8") as module_file:
            module_file.write(self.to_fortran())
        dest_dir = file.parent    
        if include_neural_net_mod:
            copy_neural_net_mod(dest_dir)
        if include_svr_mod:
            copy_svr_mod(dest_dir)

    def _fortran_file_head(self) -> str:
        """Returns text that goes at the top of the fortran file"""
        required_header = self.formatter.required_file_header()
        header_comment = self.formatter.format_line(f"! Easy Neural Networks in the Um in Fortran: {self.description}")
        return f"{required_header}" f"\n" f"{header_comment}"

    def _fortran_module_head(self) -> str:
        """Returns text that begins the fortran module this_model_mod"""
        module_stmt = self.formatter.format_line(f"MODULE {self._module_name}")
        implicit_stmt = self.formatter.format_line("IMPLICIT NONE")
        required_imports = self.formatter.required_module_imports()
        required_declarations = self.formatter.required_module_declarations(self._module_name)
        contains_stmt = self.formatter.format_line("CONTAINS")
        return f"{module_stmt}" f"{required_imports}" f"{implicit_stmt}" f"{required_declarations}" f"{contains_stmt}"

    def _fortran_subroutine(self) -> str:
        """Returns text that begins the fortran subroutine this_model"""
        subroutine_name = self.name
        # build the SUBROUTINE statement:
        arg_list = []
        for input_layer_ in self.inputs:
            arg_list.append(input_layer_.name)
        for output_name in self.output_names:
            # since output names have y_ prepended elsewhere to distinguish them from weights.
            arg_list.append(f"y_{output_name}")
        arg_str = ""
        for arg in arg_list:
            if arg_str:
                arg_str = f"{arg_str}, {arg}"
            else:
                arg_str = f"{arg}"
        subroutine_stmt = self.formatter.format_line(f"SUBROUTINE {subroutine_name}({arg_str})")
        # build the imports of neural network stuff:
        layer_types_to_import = ""
        for layer_type in self.layer_types_used:
            if layer_type.fortran_id():
                if layer_types_to_import:
                    layer_types_to_import = f"{layer_types_to_import} ,{layer_type.fortran_id()}"
                else:
                    layer_types_to_import = layer_type.fortran_id()
        if layer_types_to_import=="svr":
            import_stmt = self.formatter.format_line(f"USE svr_mod, ONLY: {layer_types_to_import}\n")
        else:
            import_stmt = self.formatter.format_line(f"USE neural_net_mod, ONLY: {layer_types_to_import}\n")
        required_imports_stmt = self.formatter.required_subroutine_imports()
        implicit_stmt = self.formatter.format_line("IMPLICIT NONE\n")
        required_decls_stmt = self.formatter.required_subroutine_declarations(subroutine_name)

        layer_typedecl_stmts = ""
        layer_init_stmts = ""
        for layer in self.layers:
            # TODO: make this depend on model dtype field
            layer_typedecls = layer.get_fortran_type_declaration(self.formatter.default_dtype)
            layer_typedecl_stmts = f"{layer_typedecl_stmts}{layer_typedecls}\n"
            layer_inits = layer.get_fortran_data_initialisation()
            layer_init_stmts = f"{layer_init_stmts}{layer_inits}\n"
        required_opening_stmts = self.formatter.required_subroutine_opening_actions()

        main_body = ""
        for layer in self.layers:
            # All layers besides input layers have an inputs field; all layers besides input ones
            # want to call a Fortran subroutine.
            if layer.inputs is not None:
                main_body = f"{main_body}{layer.get_fortran_layer_subroutine_call_stmt()}\n"
        required_closing_stmts = self.formatter.required_subroutine_closing_actions()
        return_stmt = "RETURN"
        end_subroutine_stmt = f"END SUBROUTINE {subroutine_name}"
        return (
            f"{subroutine_stmt}"
            f"{required_imports_stmt}"
            f"{import_stmt}"
            f"{implicit_stmt}"
            f"{required_decls_stmt}"
            f"{layer_typedecl_stmts}"
            f"{layer_init_stmts}\n"
            f"{required_opening_stmts}\n"
            f"{main_body}\n"
            f"{required_closing_stmts}\n"
            f"{return_stmt}\n"
            f"{end_subroutine_stmt}\n"
        )

    def _fortran_module_tail(self) -> str:
        """Returns text that ends the fortran module this_model_mod."""
        return f"END MODULE {self._module_name}\n"
