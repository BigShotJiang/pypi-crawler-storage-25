"""
Layer 1 — 文本函数。

中文说明：
- ``FIND`` 区分大小写；``SEARCH`` 支持通配符的完整语义未实现，仅大小写不敏感查找子串。
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any

from excel_funcs._utils import coerce_float
from excel_funcs.errors import VALUE as VALUE_ERROR
from excel_funcs.errors import ExcelErrorValue


def _as_str(x: Any) -> str | ExcelErrorValue:
    if x is None:
        return ""
    if isinstance(x, ExcelErrorValue):
        return x
    return str(x)


def CONCAT(*texts: Any) -> str | ExcelErrorValue:
    """Excel ``CONCAT`` / ``CONCATENATE``：拼接文本。"""

    parts: list[str] = []
    for t in texts:
        s = _as_str(t)
        if isinstance(s, ExcelErrorValue):
            return s
        parts.append(s)
    return "".join(parts)


def TEXTJOIN(delimiter: Any, ignore_empty: Any, *texts: Any) -> str | ExcelErrorValue:
    """Excel ``TEXTJOIN`` 简化：``ignore_empty`` 为真时跳过空串。"""

    d = _as_str(delimiter)
    if isinstance(d, ExcelErrorValue):
        return d
    ign = bool(ignore_empty)
    out: list[str] = []
    for t in texts:
        s = _as_str(t)
        if isinstance(s, ExcelErrorValue):
            return s
        if ign and s == "":
            continue
        out.append(s)
    return d.join(out)


def LEFT(text: Any, num_chars: Any = 1) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    n = coerce_float(num_chars)
    if n is None or n < 0:
        return VALUE_ERROR
    return s[: int(n)]


def RIGHT(text: Any, num_chars: Any = 1) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    n = coerce_float(num_chars)
    if n is None or n < 0:
        return VALUE_ERROR
    ni = int(n)
    return s[-ni:] if ni else ""


def MID(text: Any, start_num: Any, num_chars: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    st = coerce_float(start_num)
    ln = coerce_float(num_chars)
    if st is None or ln is None or st < 1 or ln < 0:
        return VALUE_ERROR
    # Excel 起始为 1
    i = int(st) - 1
    j = i + int(ln)
    if i >= len(s):
        return ""
    return s[i:j]


def LEN(text: Any) -> int | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    return len(s)


def TRIM(text: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    return re.sub(r"\s+", " ", s).strip()


def UPPER(text: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    return s.upper()


def LOWER(text: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    return s.lower()


def PROPER(text: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s

    def cap_word(w: str) -> str:
        if not w:
            return w
        return w[0].upper() + w[1:].lower()

    return "".join(cap_word(t) for t in re.split(r"(\s+)", s))


def SUBSTITUTE(text: Any, old_text: Any, new_text: Any, instance_num: Any | None = None) -> str | ExcelErrorValue:
    s = _as_str(text)
    o = _as_str(old_text)
    n = _as_str(new_text)
    for v in (s, o, n):
        if isinstance(v, ExcelErrorValue):
            return v
    if o == "":
        return VALUE_ERROR
    if instance_num is None:
        return s.replace(o, n)
    k = coerce_float(instance_num)
    if k is None or k < 1 or int(k) != k:
        return VALUE_ERROR
    idx = 0
    count = 0
    target = int(k)
    while True:
        pos = s.find(o, idx)
        if pos < 0:
            break
        count += 1
        if count == target:
            return s[:pos] + n + s[pos + len(o) :]
        idx = pos + len(o)
    return s


def REPLACE(old_text: Any, start_num: Any, num_chars: Any, new_text: Any) -> str | ExcelErrorValue:
    s = _as_str(old_text)
    n = _as_str(new_text)
    if isinstance(s, ExcelErrorValue) or isinstance(n, ExcelErrorValue):
        return s if isinstance(s, ExcelErrorValue) else n
    st = coerce_float(start_num)
    ln = coerce_float(num_chars)
    if st is None or ln is None or st < 1 or ln < 0:
        return VALUE_ERROR
    i = int(st) - 1
    j = i + int(ln)
    return s[:i] + n + s[j:]


def REPT(text: Any, number_times: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    nt = coerce_float(number_times)
    if nt is None or nt < 0 or int(nt) != nt:
        return VALUE_ERROR
    return s * int(nt)


def FIND(find_text: Any, within_text: Any, start_num: Any = 1) -> int | ExcelErrorValue:
    f = _as_str(find_text)
    w = _as_str(within_text)
    if isinstance(f, ExcelErrorValue) or isinstance(w, ExcelErrorValue):
        return f if isinstance(f, ExcelErrorValue) else w
    st = coerce_float(start_num)
    if st is None or st < 1:
        return VALUE_ERROR
    i = int(st) - 1
    pos = w.find(f, i)
    if pos < 0:
        return VALUE_ERROR
    return pos + 1


def SEARCH(find_text: Any, within_text: Any, start_num: Any = 1) -> int | ExcelErrorValue:
    """不区分大小写的子串查找（不含通配符）。"""

    f = _as_str(find_text)
    w = _as_str(within_text)
    if isinstance(f, ExcelErrorValue) or isinstance(w, ExcelErrorValue):
        return f if isinstance(f, ExcelErrorValue) else w
    st = coerce_float(start_num)
    if st is None or st < 1:
        return VALUE_ERROR
    i = int(st) - 1
    pos = w.lower().find(f.lower(), i)
    if pos < 0:
        return VALUE_ERROR
    return pos + 1


def VALUE_FROM_TEXT(text: Any) -> float | ExcelErrorValue:
    """
    Excel ``VALUE``：将文本转为数值；失败 ``#VALUE!``。

    函数名使用 ``VALUE_FROM_TEXT`` 以免与错误常量 ``errors.VALUE`` 在包聚合导出时混淆。
    """

    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    s = s.strip()
    if s == "":
        return VALUE_ERROR
    c = coerce_float(s)
    if c is None:
        return VALUE_ERROR
    return c


def CHAR(number: Any) -> str | ExcelErrorValue:
    n = coerce_float(number)
    if n is None or n < 1 or n > 255 or int(n) != n:
        return VALUE_ERROR
    return chr(int(n))


def CODE(text: Any) -> int | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    if s == "":
        return VALUE_ERROR
    return ord(s[0])


def EXACT(text1: Any, text2: Any) -> bool | ExcelErrorValue:
    a = _as_str(text1)
    b = _as_str(text2)
    if isinstance(a, ExcelErrorValue) or isinstance(b, ExcelErrorValue):
        return a if isinstance(a, ExcelErrorValue) else b
    return a == b


def FIXED(number: Any, decimals: Any = 2, no_commas: Any = False) -> str | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(decimals)
    if x is None or d is None:
        return VALUE_ERROR
    fmt = f"{{:.{int(d)}f}}"
    s = fmt.format(x)
    if not no_commas:
        # 极简千分位
        sign = ""
        if s.startswith("-"):
            sign = "-"
            s = s[1:]
        if "." in s:
            ip, fp = s.split(".", 1)
        else:
            ip, fp = s, ""
        ip = f"{int(ip):,}"
        s = sign + ip + ("." + fp if fp or int(d) > 0 else "")
    return s


def CLEAN(text: Any) -> str | ExcelErrorValue:
    s = _as_str(text)
    if isinstance(s, ExcelErrorValue):
        return s
    return "".join(ch for ch in s if ord(ch) >= 32 or ch in "\t\n\r")


def TEXT(value: Any, format_text: Any) -> str | ExcelErrorValue:
    """
    ``TEXT`` 极简：支持 ``0``/``0.00`` 数字格式与 ``yyyy-mm-dd`` 日期占位（非完整 Excel 格式引擎）。
    """

    fmt = _as_str(format_text)
    if isinstance(fmt, ExcelErrorValue):
        return fmt
    if isinstance(value, (datetime, date)):
        # 极简替换
        d = value if isinstance(value, date) else value.date()
        s = fmt
        s = s.replace("yyyy", f"{d.year:04d}")
        s = s.replace("yy", f"{d.year % 100:02d}")
        s = s.replace("mm", f"{d.month:02d}")
        s = s.replace("dd", f"{d.day:02d}")
        return s
    x = coerce_float(value)
    if x is None:
        return VALUE_ERROR
    if "." in fmt:
        # 小数位数 = fmt 中小数点后 0 的个数
        if "." in fmt:
            _, frac = fmt.split(".", 1)
            dec = len(frac)
        else:
            dec = 0
        return f"{x:.{dec}f}"
    return str(int(round(x)))
