"""
Layer 1 — 查找与引用（简化语义）。

中文说明：
- ``VLOOKUP``/``HLOOKUP`` 的 **range_lookup=True** 近似匹配未完整实现；当前以 **精确匹配** 为主。
- ``INDIRECT`` 不支持工作簿级地址，仅返回占位 ``#REF!`` 或简单解析（本版极简）。
"""

from __future__ import annotations

from typing import Any, Sequence

from excel_funcs.errors import NA, REF, VALUE, ExcelErrorValue, is_error


def _ensure_table(table: Any) -> list[list[Any]] | ExcelErrorValue:
    if not isinstance(table, (list, tuple)) or not table:
        return VALUE
    rows = [list(r) if isinstance(r, (list, tuple)) else [r] for r in table]
    return rows


def VLOOKUP(
    lookup_value: Any,
    table_array: Any,
    col_index_num: Any,
    range_lookup: Any = False,
) -> Any:
    """
    Excel ``VLOOKUP``：``table_array`` 为二维列表，首列为查找列。

    ``range_lookup`` 为 ``True`` 时：若找不到精确匹配，返回不大于查找值的最大行（**仅数值列** 近似）。
    """

    if is_error(lookup_value):
        return lookup_value
    rows = _ensure_table(table_array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    try:
        ci = int(col_index_num)
    except (TypeError, ValueError):
        return VALUE
    if ci < 1 or ci > len(rows[0]):
        return REF
    approx = bool(range_lookup)

    def row_key(r: list[Any]) -> Any:
        return r[0]

    if not approx:
        for r in rows:
            if is_error(r[0]):
                return r[0]
            if r[0] == lookup_value:
                return r[ci - 1]
        return NA

    # 近似：按首列数值排序后找最后一个 <= lookup_value
    nums: list[tuple[float, list[Any]]] = []
    for r in rows:
        from excel_funcs._utils import coerce_float

        k = coerce_float(row_key(r))
        if k is None:
            continue
        nums.append((k, r))
    if not nums:
        return NA
    nums.sort(key=lambda x: x[0])
    best: list[Any] | None = None
    lk = lookup_value
    from excel_funcs._utils import coerce_float as _cf

    lv = _cf(lk)
    if lv is None:
        return NA
    for k, r in nums:
        if k <= lv:
            best = r
        else:
            break
    if best is None:
        return NA
    return best[ci - 1]


def HLOOKUP(
    lookup_value: Any,
    table_array: Any,
    row_index_num: Any,
    range_lookup: Any = False,
) -> Any:
    """首行查找；``table_array`` 行为行、列为字段。"""

    rows = _ensure_table(table_array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    if not rows:
        return VALUE
    ncols = len(rows[0])
    table_t: list[list[Any]] = []
    for c in range(ncols):
        table_t.append([rows[r][c] for r in range(len(rows))])
    return VLOOKUP(lookup_value, table_t, row_index_num, range_lookup)


def INDEX(array: Any, row_num: Any, column_num: Any | None = None) -> Any:
    """
    Excel ``INDEX``：``array`` 为一维或二维序列；行列从 **1** 开始。
    """

    if column_num is None:
        # 一维
        if not isinstance(array, (list, tuple)):
            return VALUE
        try:
            r = int(row_num)
        except (TypeError, ValueError):
            return VALUE
        if r < 1 or r > len(array):
            return REF
        v = array[r - 1]
        return v
    rows = _ensure_table(array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    try:
        r = int(row_num)
        c = int(column_num)
    except (TypeError, ValueError):
        return VALUE
    if r < 1 or c < 1 or r > len(rows) or c > len(rows[0]):
        return REF
    return rows[r - 1][c - 1]


def MATCH(
    lookup_value: Any,
    lookup_array: Sequence[Any],
    match_type: Any = 0,
) -> int | ExcelErrorValue:
    """
    Excel ``MATCH``：返回 1-based 索引。

    ``match_type``：``0`` 精确；``1`` 小于等于；``-1`` 大于等于（**要求已排序**，此处做线性扫描近似）。
    """

    arr = list(lookup_array)
    try:
        mt = int(match_type)
    except (TypeError, ValueError):
        return VALUE
    if mt == 0:
        for i, v in enumerate(arr):
            if v == lookup_value:
                return i + 1
        return NA
    from excel_funcs._utils import coerce_float

    lv = coerce_float(lookup_value)
    if lv is None:
        return NA
    nums = [(i, coerce_float(x)) for i, x in enumerate(arr)]
    nums = [(i, v) for i, v in nums if v is not None]
    if mt == 1:
        nums.sort(key=lambda t: t[1])
        best = None
        for i, v in nums:
            if v <= lv:
                best = (i, v)
            else:
                break
        if best is None:
            return NA
        return best[0] + 1
    if mt == -1:
        nums.sort(key=lambda t: t[1], reverse=True)
        best = None
        for i, v in nums:
            if v >= lv:
                best = (i, v)
            else:
                break
        if best is None:
            return NA
        return best[0] + 1
    return VALUE


def CHOOSE(index_num: Any, *values: Any) -> Any:
    try:
        k = int(index_num)
    except (TypeError, ValueError):
        return VALUE
    if k < 1 or k > len(values):
        return VALUE
    return values[k - 1]


def ADDRESS(
    row_num: Any,
    column_num: Any,
    abs_num: Any = 1,
    a1: Any = True,
    sheet_text: Any = "",
) -> str | ExcelErrorValue:
    """返回 ``A1`` 样式地址字符串（极简）。"""

    try:
        r = int(row_num)
        c = int(column_num)
    except (TypeError, ValueError):
        return VALUE
    if r < 1 or c < 1:
        return VALUE

    def col_letters(n: int) -> str:
        s = ""
        while n:
            n, rem = divmod(n - 1, 26)
            s = chr(65 + rem) + s
        return s

    addr = f"{col_letters(c)}{r}"
    st = str(sheet_text) if sheet_text else ""
    if st:
        return f"{st}!{addr}"
    return addr


def ROW(reference: Any = None) -> int | list[int]:
    """无参时返回 ``1``（非 Excel 工作表行号）；传入二维数组时返回每行行号列表的简化版不支持。"""

    if reference is None:
        return 1
    return 1


def COLUMN(reference: Any = None) -> int:
    if reference is None:
        return 1
    return 1


def ROWS(array: Any) -> int | ExcelErrorValue:
    rows = _ensure_table(array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    return len(rows)


def COLUMNS(array: Any) -> int | ExcelErrorValue:
    rows = _ensure_table(array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    return len(rows[0])


def TRANSPOSE(array: Any) -> list[list[Any]] | ExcelErrorValue:
    rows = _ensure_table(array)
    if isinstance(rows, ExcelErrorValue):
        return rows
    return [list(col) for col in zip(*rows)]


def OFFSET(reference: Any, rows: Any, cols: Any, height: Any | None = None, width: Any | None = None) -> Any:
    """
    ``OFFSET`` 未实现动态区域切片；返回 ``#REF!`` 提示使用 ``INDEX``/切片。
    """

    return REF


def INDIRECT(ref_text: Any, a1: Any = True) -> Any:
    """不支持；返回 ``#REF!``。"""

    return REF


def XLOOKUP(
    lookup_value: Any,
    lookup_array: Sequence[Any],
    return_array: Sequence[Any],
    if_not_found: Any | None = None,
    match_mode: Any = 0,
    search_mode: Any = 1,
) -> Any:
    """
    Excel ``XLOOKUP`` 简化：**精确匹配**、**正向搜索**；``if_not_found`` 在找不到时返回。
    """

    la = list(lookup_array)
    ra = list(return_array)
    if len(la) != len(ra):
        return VALUE
    for i, v in enumerate(la):
        if v == lookup_value:
            return ra[i]
    if if_not_found is not None:
        return if_not_found
    return NA


def XMATCH(lookup_value: Any, lookup_array: Sequence[Any], match_mode: Any = 0) -> int | ExcelErrorValue:
    """基于 ``MATCH(..., 0)`` 的简化。"""

    return MATCH(lookup_value, lookup_array, 0)


def LOOKUP(lookup_value: Any, lookup_vector: Sequence[Any], result_vector: Sequence[Any] | None = None) -> Any:
    """向量形式 ``LOOKUP``：近似匹配未实现，按 ``MATCH`` type 1 退化。"""

    lv = list(lookup_vector)
    if result_vector is None:
        return NA
    rv = list(result_vector)
    if len(lv) != len(rv):
        return VALUE
    idx = MATCH(lookup_value, lv, 1)
    if isinstance(idx, ExcelErrorValue):
        return idx
    return rv[idx - 1]
