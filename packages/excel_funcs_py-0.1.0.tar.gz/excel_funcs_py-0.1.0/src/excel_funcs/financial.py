"""
Layer 1 — 财务函数（常用子集）。

中文说明：
- ``RATE`` 使用牛顿迭代，初值与 Excel 在极端参数下可能略有差异。
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from excel_funcs._utils import coerce_float
from excel_funcs.errors import NUM, VALUE, ExcelErrorValue


def PV(
    rate: Any,
    nper: Any,
    pmt: Any,
    fv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    """Excel ``PV``：现值。"""

    r = coerce_float(rate)
    n = coerce_float(nper)
    p = coerce_float(pmt)
    f = coerce_float(fv)
    t = int(coerce_float(type_) or 0)
    if r is None or n is None or p is None or f is None:
        return VALUE
    if r == 0:
        return -(p * n + f)
    pv = (-p * (1 + r * t) * ((1 + r) ** n - 1) / r - f) / (1 + r) ** n
    return float(pv)


def FV(
    rate: Any,
    nper: Any,
    pmt: Any,
    pv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    """Excel ``FV``。"""

    r = coerce_float(rate)
    n = coerce_float(nper)
    p = coerce_float(pmt)
    present = coerce_float(pv)
    t = int(coerce_float(type_) or 0)
    if r is None or n is None or p is None or present is None:
        return VALUE
    if r == 0:
        return float(-(present + p * n))
    fv = -present * (1 + r) ** n - p * (1 + r * t) * ((1 + r) ** n - 1) / r
    return float(fv)


def PMT(
    rate: Any,
    nper: Any,
    pv: Any,
    fv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    """Excel ``PMT``：每期付款。"""

    r = coerce_float(rate)
    n = coerce_float(nper)
    p = coerce_float(pv)
    f = coerce_float(fv)
    t = int(coerce_float(type_) or 0)
    if r is None or n is None or p is None or f is None:
        return VALUE
    if r == 0:
        return float(-(p + f) / n)
    q = (1 + r) ** n
    return float(-(p * q + f) * r / ((1 + r * t) * (q - 1)))


def NPER(
    rate: Any,
    pmt: Any,
    pv: Any,
    fv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    r = coerce_float(rate)
    p = coerce_float(pmt)
    present = coerce_float(pv)
    f = coerce_float(fv)
    t = int(coerce_float(type_) or 0)
    if r is None or p is None or present is None or f is None:
        return VALUE
    if r == 0:
        if p == 0:
            return NUM
        return float(-(present + f) / p)
    try:
        import math

        num = p * (1 + r * t) - f * r
        den = present * r + p * (1 + r * t)
        if num == 0 or den == 0:
            return NUM
        val = math.log(num / den) / math.log(1 + r)
        return float(val)
    except (ValueError, ZeroDivisionError):
        return NUM


def RATE(
    nper: Any,
    pmt: Any,
    pv: Any,
    fv: Any = 0,
    type_: Any = 0,
    guess: Any = 0.1,
) -> float | ExcelErrorValue:
    """牛顿法求每期利率。"""

    n = coerce_float(nper)
    p = coerce_float(pmt)
    present = coerce_float(pv)
    f = coerce_float(fv)
    g = coerce_float(guess)
    t = int(coerce_float(type_) or 0)
    if n is None or p is None or present is None or f is None or g is None:
        return VALUE
    r = g
    for _ in range(100):
        if abs(r) < 1e-12:
            r = 1e-12
        q = (1 + r) ** n
        dr = n * (1 + r) ** (n - 1)
        num = present * q + p * (1 + r * t) * (q - 1) / r + f
        dnum = (
            present * dr
            + p
            * (
                t * (q - 1) / r
                + (1 + r * t) * (dr / r - (q - 1) / (r * r))
            )
        )
        if dnum == 0:
            break
        r_new = r - num / dnum
        if abs(r_new - r) < 1e-8:
            return float(r_new)
        r = r_new
    return NUM


def IPMT(
    rate: Any,
    per: Any,
    nper: Any,
    pv: Any,
    fv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    """某期利息部分（简化）。"""

    r = coerce_float(rate)
    k = coerce_float(per)
    n = coerce_float(nper)
    p = coerce_float(pv)
    f = coerce_float(fv)
    if None in (r, k, n, p, f) or k < 1 or k > n:
        return VALUE
    pay = PMT(r, n, p, f, type_)
    if isinstance(pay, ExcelErrorValue):
        return pay
    bal = p
    for period in range(1, int(k)):
        interest = bal * r
        principal = pay - interest
        bal -= principal
    return float(bal * r)


def PPMT(
    rate: Any,
    per: Any,
    nper: Any,
    pv: Any,
    fv: Any = 0,
    type_: Any = 0,
) -> float | ExcelErrorValue:
    r = coerce_float(rate)
    k = coerce_float(per)
    n = coerce_float(nper)
    p = coerce_float(pv)
    f = coerce_float(fv)
    if None in (r, k, n, p, f):
        return VALUE
    pay = PMT(r, n, p, f, type_)
    ip = IPMT(r, k, n, p, f, type_)
    if isinstance(pay, ExcelErrorValue) or isinstance(ip, ExcelErrorValue):
        return pay if isinstance(pay, ExcelErrorValue) else ip  # type: ignore[return-value]
    return float(pay - ip)


def NPV(rate: Any, *values: Any) -> float | ExcelErrorValue:
    r = coerce_float(rate)
    if r is None:
        return VALUE
    total = 0.0
    for i, v in enumerate(values):
        c = coerce_float(v)
        if c is None:
            return VALUE
        total += c / (1 + r) ** (i + 1)
    return float(total)


def IRR(values: Any, guess: Any = 0.1) -> float | ExcelErrorValue:
    """内部收益率：牛顿法。"""

    if not isinstance(values, (list, tuple)) or len(values) < 2:
        return VALUE
    cfs = [coerce_float(x) for x in values]
    if any(x is None for x in cfs):
        return VALUE
    cfs_f = [float(x) for x in cfs]  # type: ignore[list-item]
    r = coerce_float(guess) or 0.1
    if r is None:
        return VALUE
    for _ in range(100):
        npv = sum(cf / (1 + r) ** i for i, cf in enumerate(cfs_f))
        # NPV'(r) = sum_i -i * cf_i / (1+r)^(i+1)；i=0 项为 0
        dnpv = sum(-i * cf / (1 + r) ** (i + 1) for i, cf in enumerate(cfs_f))
        if dnpv == 0:
            break
        r_new = r - npv / dnpv
        if abs(r_new - r) < 1e-8:
            return float(r_new)
        r = r_new
    return NUM


def XNPV(rate: Any, values: Any, dates: Any) -> float | ExcelErrorValue:
    r = coerce_float(rate)
    if r is None or not isinstance(values, (list, tuple)) or not isinstance(dates, (list, tuple)):
        return VALUE
    if len(values) != len(dates):
        return VALUE
    d0 = dates[0]
    if isinstance(d0, datetime):
        d0 = d0.date()
    elif not isinstance(d0, date):
        return VALUE
    total = 0.0
    for v, d in zip(values, dates):
        cf = coerce_float(v)
        if cf is None:
            return VALUE
        if isinstance(d, datetime):
            dd = d.date()
        elif isinstance(d, date):
            dd = d
        else:
            return VALUE
        days = (dd - d0).days
        total += cf / (1 + r) ** (days / 365.0)
    return float(total)


def XIRR(values: Any, dates: Any, guess: Any = 0.1) -> float | ExcelErrorValue:
    """简化牛顿迭代。"""

    r = coerce_float(guess) or 0.1
    if not isinstance(values, (list, tuple)) or not isinstance(dates, (list, tuple)):
        return VALUE
    d0 = dates[0]
    if isinstance(d0, datetime):
        d0 = d0.date()
    elif not isinstance(d0, date):
        return VALUE
    cfs = []
    for v, d in zip(values, dates):
        cf = coerce_float(v)
        if cf is None:
            return VALUE
        if isinstance(d, datetime):
            dd = d.date()
        elif isinstance(d, date):
            dd = d
        else:
            return VALUE
        cfs.append((cf, (dd - d0).days / 365.0))
    for _ in range(100):
        npv = sum(cf / (1 + r) ** t for cf, t in cfs)
        dnpv = sum(-t * cf / (1 + r) ** (t + 1) for cf, t in cfs)
        if dnpv == 0:
            break
        r_new = r - npv / dnpv
        if abs(r_new - r) < 1e-8:
            return float(r_new)
        r = r_new
    return NUM
