"""
内部工具：区域扁平化、数值试探转换等。

本模块不对外承诺稳定 API，仅供 ``excel_funcs`` 包内使用。
"""

from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN, ROUND_UP
from typing import Any, Iterable, Iterator, Sequence, TypeVar

T = TypeVar("T")


def iter_flat_numbers(
    *args: Any,
    booleans_as_numbers: bool = True,
) -> Iterator[float | int]:
    """
    将任意嵌套的 ``list``/``tuple`` 与标量展开为数值迭代器。

    - ``None`` 视为跳过（模拟空单元格在 SUM 中被忽略的行为，具体函数可另行处理）。
    - 布尔值在 ``booleans_as_numbers`` 为真时转为 0/1（与 Excel SUM 一致）。
    """

    for a in args:
        if a is None:
            continue
        if isinstance(a, (list, tuple)):
            yield from iter_flat_numbers(*a, booleans_as_numbers=booleans_as_numbers)
        elif isinstance(a, bool) and booleans_as_numbers:
            yield 1 if a else 0
        elif isinstance(a, (int, float)) and not isinstance(a, bool):
            yield a
        else:
            # 非数值留给上层决定是否当作 0 或错误
            continue


def flatten_all(*args: Any) -> list[Any]:
    """递归展开所有可迭代层级（除 str/bytes）。"""

    out: list[Any] = []

    def _walk(x: Any) -> None:
        if x is None:
            out.append(None)
        elif isinstance(x, (str, bytes)):
            out.append(x)
        elif isinstance(x, (list, tuple)):
            for i in x:
                _walk(i)
        else:
            out.append(x)

    for a in args:
        _walk(a)
    return out


def coerce_float(x: Any) -> float | None:
    """
    尝试转为 float；失败返回 ``None``（调用方可转为 ``#VALUE!``）。
    """

    if x is None or x == "":
        return None
    if isinstance(x, bool):
        return float(int(x))
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        try:
            return float(x.strip())
        except ValueError:
            return None
    return None


def excel_round_half_away_from_zero(value: float, digits: int) -> float:
    """
    Excel ``ROUND``：按「远离 0」的半舍入到 ``digits`` 位小数（与 Python bankers rounding 不同）。
    """

    if digits < 0:
        factor = 10 ** (-digits)
        q = Decimal(str(value / factor))
        rounded = q.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return float(rounded * factor)
    q = Decimal(str(value)).quantize(Decimal(10) ** -digits, rounding=ROUND_HALF_UP)
    return float(q)


def excel_rounddown(value: float, digits: int) -> float:
    if digits >= 0:
        q = Decimal(str(value)).quantize(Decimal(10) ** -digits, rounding=ROUND_DOWN)
        return float(q)
    factor = 10 ** (-digits)
    q = Decimal(str(value / factor)).quantize(Decimal("1"), rounding=ROUND_DOWN)
    return float(q * factor)


def excel_roundup(value: float, digits: int) -> float:
    if digits >= 0:
        q = Decimal(str(value)).quantize(Decimal(10) ** -digits, rounding=ROUND_UP)
        return float(q)
    factor = 10 ** (-digits)
    q = Decimal(str(value / factor)).quantize(Decimal("1"), rounding=ROUND_UP)
    return float(q * factor)
