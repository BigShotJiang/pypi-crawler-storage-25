"""
Excel 风格错误值与类型判断。

说明（中文）：
- Excel 中公式可能返回 #N/A、#VALUE! 等；本库用不可变数据类表示，便于在 Python 中链式传递并用 ISERROR/ISNA 判断。
- 与「抛出 Python 异常」相比，返回错误值更接近工作表语义；复杂场景下实现者仍可选择 raise。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Final


@dataclass(frozen=True, slots=True)
class ExcelErrorValue:
    """
    表示单个 Excel 错误字面量，例如 ``#N/A``。

    Attributes:
        code: 与 Excel 状态栏一致的错误字符串，含前导 ``#``。
    """

    code: str

    def __repr__(self) -> str:  # pragma: no cover - 调试友好
        return f"ExcelErrorValue({self.code!r})"


# 常用错误单例（与 Excel 显示文本对齐）
NA: Final[ExcelErrorValue] = ExcelErrorValue("#N/A")
VALUE: Final[ExcelErrorValue] = ExcelErrorValue("#VALUE!")
REF: Final[ExcelErrorValue] = ExcelErrorValue("#REF!")
DIV0: Final[ExcelErrorValue] = ExcelErrorValue("#DIV/0!")
NUM: Final[ExcelErrorValue] = ExcelErrorValue("#NUM!")
NAME: Final[ExcelErrorValue] = ExcelErrorValue("#NAME?")
NULL: Final[ExcelErrorValue] = ExcelErrorValue("#NULL!")


def is_error(value: Any) -> bool:
    """
    对应 Excel ``ISERROR``：任意错误类型（含 ``#N/A``）为真。

    Args:
        value: 任意 Python 对象。

    Returns:
        若为 :class:`ExcelErrorValue` 则 ``True``；否则 ``False``。
        说明：Python 内置 ``Exception`` 不计入，以保持类型明确。
    """

    return isinstance(value, ExcelErrorValue)


def is_na(value: Any) -> bool:
    """
    对应 Excel ``ISNA``：仅 ``#N/A`` 为真。
    """

    return value is NA


def is_err(value: Any) -> bool:
    """
    对应 Excel ``ISERR``：错误但 **不含** ``#N/A`` 时为真。
    """

    return isinstance(value, ExcelErrorValue) and value is not NA
