"""
Layer 1 — 数学与聚合类函数（对应 Excel「数学和三角函数」「统计」子集）。

中文说明：
- 参数中的 ``list``/``tuple`` 表示矩形或一维区域，内部会按行优先展开。
- 遇到 :class:`~excel_funcs.errors.ExcelErrorValue` 时，多数聚合函数会**优先返回第一个错误**（与 Excel 链式行为接近）。
"""

from __future__ import annotations

import math
import random
from typing import Any, Callable, Iterable, Sequence

from excel_funcs._utils import (
    coerce_float,
    excel_round_half_away_from_zero,
    excel_rounddown,
    excel_roundup,
    flatten_all,
    iter_flat_numbers,
)
from excel_funcs.errors import DIV0, ExcelErrorValue, VALUE, is_error


def _first_error(*args: Any) -> ExcelErrorValue | None:
    """深度优先找到第一个错误单元格。"""

    for a in flatten_all(*args):
        if is_error(a):
            return a  # type: ignore[return-value]
    return None


def SUM(*args: Any) -> float | ExcelErrorValue:
    """
    Excel ``SUM``：对区域内所有数值求和；忽略空与非数值（不将文本当 0，除非可解析为数字——本实现与 Excel 略有差异，文本跳过）。

    若区域内存在错误值，返回遇到的第一个错误。
    """

    err = _first_error(*args)
    if err is not None:
        return err
    total = 0.0
    for a in flatten_all(*args):
        if a is None or a == "":
            continue
        if isinstance(a, bool):
            total += 1.0 if a else 0.0
            continue
        if isinstance(a, (int, float)):
            total += float(a)
            continue
        if isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                total += c
            # 无法转换的文本：Excel SUM 忽略
            continue
    return total


def AVERAGE(*args: Any) -> float | ExcelErrorValue:
    """Excel ``AVERAGE``：算术平均；分母为**参与计算的数值个数**（空跳过）。"""

    err = _first_error(*args)
    if err is not None:
        return err
    nums: list[float] = []
    for a in flatten_all(*args):
        if a is None or a == "":
            continue
        if isinstance(a, bool):
            nums.append(1.0 if a else 0.0)
            continue
        if isinstance(a, (int, float)):
            nums.append(float(a))
            continue
        if isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                nums.append(c)
    if not nums:
        return DIV0
    return sum(nums) / len(nums)


def AVERAGEA(*args: Any) -> float | ExcelErrorValue:
    """
    Excel ``AVERAGEA``：文本与 ``False`` 计为 0，``True`` 计为 1；空单元格跳过。
    """

    err = _first_error(*args)
    if err is not None:
        return err
    vals: list[float] = []
    for a in flatten_all(*args):
        if a is None:
            continue
        if a == "":
            vals.append(0.0)
        elif isinstance(a, bool):
            vals.append(1.0 if a else 0.0)
        elif isinstance(a, (int, float)):
            vals.append(float(a))
        elif isinstance(a, str):
            vals.append(0.0)
        else:
            vals.append(0.0)
    if not vals:
        return DIV0
    return sum(vals) / len(vals)


def COUNT(*args: Any) -> int | ExcelErrorValue:
    """Excel ``COUNT``：仅统计数值（含可解析数字字符串则**不**计——与 Excel 区域行为一致时，纯标量字符串不计）。"""

    err = _first_error(*args)
    if err is not None:
        return err
    n = 0
    for a in flatten_all(*args):
        if isinstance(a, (int, float)) and not isinstance(a, bool):
            n += 1
        elif isinstance(a, bool):
            # Excel COUNT 对布尔：在单元格中为数值？实际上 COUNT 不计 TRUE/FALSE in cell in classic excel
            # 简化：不计 bool
            continue
    return n


def COUNTA(*args: Any) -> int | ExcelErrorValue:
    """Excel ``COUNTA``：非空单元格数量（空字符串 ``''`` 计为 1，与 Excel 一致）。"""

    err = _first_error(*args)
    if err is not None:
        return err
    n = 0
    for a in flatten_all(*args):
        if a is None:
            continue
        n += 1
    return n


def COUNTBLANK(*args: Any) -> int | ExcelErrorValue:
    """Excel ``COUNTBLANK``：统计 ``None`` 与空字符串 ``''``。"""

    err = _first_error(*args)
    if err is not None:
        return err
    n = 0
    for a in flatten_all(*args):
        if a is None or a == "":
            n += 1
    return n


def MAX(*args: Any) -> float | ExcelErrorValue:
    err = _first_error(*args)
    if err is not None:
        return err
    nums: list[float] = []
    for a in flatten_all(*args):
        if isinstance(a, (int, float)) and not isinstance(a, bool):
            nums.append(float(a))
        elif isinstance(a, bool):
            nums.append(1.0 if a else 0.0)
        elif isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                nums.append(c)
    if not nums:
        return 0.0
    return max(nums)


def MIN(*args: Any) -> float | ExcelErrorValue:
    err = _first_error(*args)
    if err is not None:
        return err
    nums: list[float] = []
    for a in flatten_all(*args):
        if isinstance(a, (int, float)) and not isinstance(a, bool):
            nums.append(float(a))
        elif isinstance(a, bool):
            nums.append(1.0 if a else 0.0)
        elif isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                nums.append(c)
    if not nums:
        return 0.0
    return min(nums)


def MEDIAN(*args: Any) -> float | ExcelErrorValue:
    err = _first_error(*args)
    if err is not None:
        return err
    nums: list[float] = []
    for a in flatten_all(*args):
        if isinstance(a, (int, float)) and not isinstance(a, bool):
            nums.append(float(a))
        elif isinstance(a, bool):
            nums.append(1.0 if a else 0.0)
        elif isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                nums.append(c)
    if not nums:
        return DIV0
    nums.sort()
    m = len(nums) // 2
    if len(nums) % 2:
        return nums[m]
    return (nums[m - 1] + nums[m]) / 2


def PRODUCT(*args: Any) -> float | ExcelErrorValue:
    err = _first_error(*args)
    if err is not None:
        return err
    p = 1.0
    any_num = False
    for a in flatten_all(*args):
        if a is None or a == "":
            continue
        if isinstance(a, bool):
            p *= 1.0 if a else 0.0
            any_num = True
            continue
        if isinstance(a, (int, float)):
            p *= float(a)
            any_num = True
            continue
        if isinstance(a, str):
            c = coerce_float(a)
            if c is not None:
                p *= c
                any_num = True
    return p if any_num else 0.0


def SUMPRODUCT(*arrays: Sequence[Any]) -> float | ExcelErrorValue:
    """
    Excel ``SUMPRODUCT`` 简化版：传入多个**等长一维**可迭代对象；对应位置相乘后求和。

    二维区域需调用方先对齐行数列数；本实现仅检查第一维长度一致。
    """

    if not arrays:
        return VALUE
    n = len(arrays[0])
    for arr in arrays[1:]:
        if len(arr) != n:
            return VALUE
    total = 0.0
    for i in range(n):
        prod = 1.0
        for arr in arrays:
            v = arr[i]
            if is_error(v):
                return v  # type: ignore[return-value]
            c = coerce_float(v)
            if c is None:
                return VALUE
            prod *= c
        total += prod
    return total


def _criteria_match(cell: Any, criteria: Any) -> bool:
    """极简条件：标量相等；``criteria`` 为 ``'>5'`` 形式字符串时做简单解析。"""

    if isinstance(criteria, str) and criteria and criteria[0] in "><=":
        op = ""
        j = 0
        while j < len(criteria) and criteria[j] in "><=":
            op += criteria[j]
            j += 1
        rhs = coerce_float(criteria[j:].strip())
        lhs = coerce_float(cell)
        if lhs is None or rhs is None:
            return False
        if op in (">",):
            return lhs > rhs
        if op in ("<",):
            return lhs < rhs
        if op in (">=",):
            return lhs >= rhs
        if op in ("<=",):
            return lhs <= rhs
        if op in ("<>", "!="):
            return lhs != rhs
        if op in ("=", "=="):
            return lhs == rhs
    return cell == criteria


def SUMIF(range_vals: Iterable[Any], criteria: Any, sum_range: Iterable[Any] | None = None) -> float | ExcelErrorValue:
    """Excel ``SUMIF`` 简化实现：一维可迭代；``sum_range`` 缺省时与 ``range`` 相同。"""

    r = list(range_vals)
    s = list(sum_range) if sum_range is not None else r
    if len(s) != len(r):
        return VALUE
    total = 0.0
    for i, cell in enumerate(r):
        if is_error(cell):
            return cell  # type: ignore[return-value]
        if _criteria_match(cell, criteria):
            v = s[i]
            if is_error(v):
                return v  # type: ignore[return-value]
            c = coerce_float(v)
            if c is None:
                continue
            total += c
    return total


def COUNTIF(range_vals: Iterable[Any], criteria: Any) -> int | ExcelErrorValue:
    n = 0
    for cell in range_vals:
        if is_error(cell):
            return cell  # type: ignore[return-value]
        if _criteria_match(cell, criteria):
            n += 1
    return n


def AVERAGEIF(
    range_vals: Iterable[Any],
    criteria: Any,
    average_range: Iterable[Any] | None = None,
) -> float | ExcelErrorValue:
    r = list(range_vals)
    a = list(average_range) if average_range is not None else r
    if len(a) != len(r):
        return VALUE
    nums: list[float] = []
    for i, cell in enumerate(r):
        if is_error(cell):
            return cell  # type: ignore[return-value]
        if _criteria_match(cell, criteria):
            v = a[i]
            if is_error(v):
                return v  # type: ignore[return-value]
            c = coerce_float(v)
            if c is not None:
                nums.append(c)
    if not nums:
        return DIV0
    return sum(nums) / len(nums)


def SUMIFS(sum_range: Iterable[Any], *criteria_pairs: Any) -> float | ExcelErrorValue:
    """
    Excel ``SUMIFS``：参数为 ``sum_range, crit_range1, crit1, crit_range2, crit2, ...``。
    """

    s = list(sum_range)
    if len(criteria_pairs) % 2 != 0:
        return VALUE
    ranges: list[list[Any]] = []
    crits: list[Any] = []
    for i in range(0, len(criteria_pairs), 2):
        cr = list(criteria_pairs[i])
        crit = criteria_pairs[i + 1]
        if len(cr) != len(s):
            return VALUE
        ranges.append(cr)
        crits.append(crit)
    total = 0.0
    for idx in range(len(s)):
        ok = True
        for cr, c in zip(ranges, crits):
            cell = cr[idx]
            if is_error(cell):
                return cell  # type: ignore[return-value]
            if not _criteria_match(cell, c):
                ok = False
                break
        if not ok:
            continue
        v = s[idx]
        if is_error(v):
            return v  # type: ignore[return-value]
        cf = coerce_float(v)
        if cf is not None:
            total += cf
    return total


def COUNTIFS(*criteria_pairs: Any) -> int | ExcelErrorValue:
    if len(criteria_pairs) % 2 != 0:
        return VALUE
    ranges = [list(criteria_pairs[i]) for i in range(0, len(criteria_pairs), 2)]
    crits = [criteria_pairs[i + 1] for i in range(0, len(criteria_pairs), 2)]
    if not ranges:
        return VALUE
    n0 = len(ranges[0])
    for cr in ranges:
        if len(cr) != n0:
            return VALUE
    count = 0
    for idx in range(n0):
        ok = True
        for cr, c in zip(ranges, crits):
            cell = cr[idx]
            if is_error(cell):
                return cell  # type: ignore[return-value]
            if not _criteria_match(cell, c):
                ok = False
                break
        if ok:
            count += 1
    return count


def AVERAGEIFS(average_range: Iterable[Any], *criteria_pairs: Any) -> float | ExcelErrorValue:
    s = list(average_range)
    if len(criteria_pairs) % 2 != 0:
        return VALUE
    ranges = [list(criteria_pairs[i]) for i in range(0, len(criteria_pairs), 2)]
    crits = [criteria_pairs[i + 1] for i in range(0, len(criteria_pairs), 2)]
    for cr in ranges:
        if len(cr) != len(s):
            return VALUE
    nums: list[float] = []
    for idx in range(len(s)):
        ok = True
        for cr, c in zip(ranges, crits):
            cell = cr[idx]
            if is_error(cell):
                return cell  # type: ignore[return-value]
            if not _criteria_match(cell, c):
                ok = False
                break
        if not ok:
            continue
        v = s[idx]
        if is_error(v):
            return v  # type: ignore[return-value]
        cf = coerce_float(v)
        if cf is not None:
            nums.append(cf)
    if not nums:
        return DIV0
    return sum(nums) / len(nums)


def ROUND(number: Any, num_digits: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(num_digits)
    if x is None or d is None:
        return VALUE
    di = int(d)
    return excel_round_half_away_from_zero(x, di)


def ROUNDDOWN(number: Any, num_digits: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(num_digits)
    if x is None or d is None:
        return VALUE
    return excel_rounddown(x, int(d))


def ROUNDUP(number: Any, num_digits: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(num_digits)
    if x is None or d is None:
        return VALUE
    return excel_roundup(x, int(d))


def MROUND(number: Any, multiple: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    m = coerce_float(multiple)
    if x is None or m is None or m == 0:
        return VALUE
    n = round(x / m)
    return n * m


def CEILING_MATH(number: Any, significance: Any = 1, mode: Any = 0) -> float | ExcelErrorValue:
    """Excel ``CEILING.MATH`` 近似：向绝对值增大方向取整到 ``significance``。"""

    x = coerce_float(number)
    s = coerce_float(significance)
    if x is None or s is None or s == 0:
        return VALUE
    import math as _m

    return float(_m.ceil(x / s) * s)


def FLOOR_MATH(number: Any, significance: Any = 1, mode: Any = 0) -> float | ExcelErrorValue:
    x = coerce_float(number)
    s = coerce_float(significance)
    if x is None or s is None or s == 0:
        return VALUE
    return float(math.floor(x / s) * s)


def INT(number: Any) -> int | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    return int(math.floor(x))


def TRUNC(number: Any, num_digits: Any = 0) -> float | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(num_digits)
    if x is None or d is None:
        return VALUE
    di = int(d)
    factor = 10**di
    if di >= 0:
        return math.trunc(x * factor) / factor
    factor = 10 ** (-di)
    return math.trunc(x / factor) * factor


def ABS(number: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    return abs(x)


def SIGN(number: Any) -> int | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    return 1 if x > 0 else (-1 if x < 0 else 0)


def MOD(number: Any, divisor: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    d = coerce_float(divisor)
    if x is None or d is None or d == 0:
        return DIV0
    return float(x - d * math.trunc(x / d))


def POWER(number: Any, power: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    p = coerce_float(power)
    if x is None or p is None:
        return VALUE
    try:
        return float(x**p)
    except (OverflowError, ValueError, OSError):
        return NUM


def SQRT(number: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    if x < 0:
        return NUM
    return math.sqrt(x)


def EXP(number: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    return math.exp(x)


def LN(number: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    if x <= 0:
        return NUM
    return math.log(x)


def LOG(number: Any, base: Any = 10) -> float | ExcelErrorValue:
    x = coerce_float(number)
    b = coerce_float(base)
    if x is None or b is None or b <= 0 or b == 1:
        return VALUE
    if x <= 0:
        return NUM
    return math.log(x, b)


def LOG10(number: Any) -> float | ExcelErrorValue:
    x = coerce_float(number)
    if x is None:
        return VALUE
    if x <= 0:
        return NUM
    return math.log10(x)


def PI() -> float:
    return math.pi


def RAND() -> float:
    return random.random()


def RANDBETWEEN(bottom: Any, top: Any) -> int | ExcelErrorValue:
    b = coerce_float(bottom)
    t = coerce_float(top)
    if b is None or t is None:
        return VALUE
    lo, hi = int(round(b)), int(round(t))
    if lo > hi:
        lo, hi = hi, lo
    return random.randint(lo, hi)


def FACT(n: Any) -> int | ExcelErrorValue:
    x = coerce_float(n)
    if x is None:
        return VALUE
    if x < 0 or int(x) != x:
        return NUM
    return math.factorial(int(x))


def COMBIN(n: Any, k: Any) -> float | ExcelErrorValue:
    nn = coerce_float(n)
    kk = coerce_float(k)
    if nn is None or kk is None:
        return VALUE
    if nn < 0 or kk < 0 or int(nn) != nn or int(kk) != kk:
        return NUM
    return float(math.comb(int(nn), int(kk)))


def PERMUT(n: Any, k: Any) -> float | ExcelErrorValue:
    nn = coerce_float(n)
    kk = coerce_float(k)
    if nn is None or kk is None:
        return VALUE
    if nn < 0 or kk < 0 or int(nn) != nn or int(kk) != kk or kk > nn:
        return NUM
    return float(math.perm(int(nn), int(kk)))


def GCD(*args: Any) -> int | ExcelErrorValue:
    ints: list[int] = []
    for a in flatten_all(*args):
        c = coerce_float(a)
        if c is None:
            return VALUE
        if int(c) != c or c < 0:
            return NUM
        ints.append(int(c))
    if not ints:
        return 0
    g = ints[0]
    for x in ints[1:]:
        g = math.gcd(g, x)
    return g


def LCM(*args: Any) -> float | ExcelErrorValue:
    ints: list[int] = []
    for a in flatten_all(*args):
        c = coerce_float(a)
        if c is None:
            return VALUE
        if int(c) != c or c < 0:
            return NUM
        ints.append(int(c))
    if not ints:
        return 0.0

    def lcm_two(a: int, b: int) -> int:
        return a * b // math.gcd(a, b)

    out = ints[0]
    for x in ints[1:]:
        out = lcm_two(out, x)
    return float(out)


def QUOTIENT(numerator: Any, denominator: Any) -> int | ExcelErrorValue:
    a = coerce_float(numerator)
    b = coerce_float(denominator)
    if a is None or b is None or b == 0:
        return DIV0
    return int(a // b)


def MAXIFS(max_range: Iterable[Any], *criteria_pairs: Any) -> float | ExcelErrorValue:
    """同 ``SUMIFS`` 结构，对满足条件的 ``max_range`` 求最大值。"""

    m = list(max_range)
    if len(criteria_pairs) % 2 != 0:
        return VALUE
    ranges = [list(criteria_pairs[i]) for i in range(0, len(criteria_pairs), 2)]
    crits = [criteria_pairs[i + 1] for i in range(0, len(criteria_pairs), 2)]
    for cr in ranges:
        if len(cr) != len(m):
            return VALUE
    nums: list[float] = []
    for idx in range(len(m)):
        ok = True
        for cr, c in zip(ranges, crits):
            cell = cr[idx]
            if is_error(cell):
                return cell  # type: ignore[return-value]
            if not _criteria_match(cell, c):
                ok = False
                break
        if not ok:
            continue
        v = m[idx]
        if is_error(v):
            return v  # type: ignore[return-value]
        cf = coerce_float(v)
        if cf is not None:
            nums.append(cf)
    if not nums:
        return 0.0
    return max(nums)


def MINIFS(min_range: Iterable[Any], *criteria_pairs: Any) -> float | ExcelErrorValue:
    m = list(min_range)
    if len(criteria_pairs) % 2 != 0:
        return VALUE
    ranges = [list(criteria_pairs[i]) for i in range(0, len(criteria_pairs), 2)]
    crits = [criteria_pairs[i + 1] for i in range(0, len(criteria_pairs), 2)]
    for cr in ranges:
        if len(cr) != len(m):
            return VALUE
    nums: list[float] = []
    for idx in range(len(m)):
        ok = True
        for cr, c in zip(ranges, crits):
            cell = cr[idx]
            if is_error(cell):
                return cell  # type: ignore[return-value]
            if not _criteria_match(cell, c):
                ok = False
                break
        if not ok:
            continue
        v = m[idx]
        if is_error(v):
            return v  # type: ignore[return-value]
        cf = coerce_float(v)
        if cf is not None:
            nums.append(cf)
    if not nums:
        return 0.0
    return min(nums)


def SUBTOTAL(function_num: Any, *args: Any) -> Any:
    """
    Excel ``SUBTOTAL`` 子集：``1–11`` 与 ``101–111`` 映射相同（**忽略隐藏行** 未实现）。

    支持：1 AVERAGE, 2 COUNT, 3 COUNTA, 4 MAX, 5 MIN, 6 PRODUCT, 9 SUM。
    """

    n = int(coerce_float(function_num) or -1)
    if n > 100:
        n -= 100
    mapping: dict[int, Callable[..., Any]] = {
        1: AVERAGE,
        2: COUNT,
        3: COUNTA,
        4: MAX,
        5: MIN,
        6: PRODUCT,
        9: SUM,
    }
    fn = mapping.get(n)
    if fn is None:
        return VALUE
    return fn(*args)


def AGGREGATE(
    function_num: Any,
    options: Any,
    *args: Any,
) -> Any:
    """
    ``AGGREGATE`` 极简占位：当前忽略 ``options``，将 ``function_num`` 映射到与 ``SUBTOTAL`` 相同的子集。
    """

    _ = options
    return SUBTOTAL(function_num, *args)
