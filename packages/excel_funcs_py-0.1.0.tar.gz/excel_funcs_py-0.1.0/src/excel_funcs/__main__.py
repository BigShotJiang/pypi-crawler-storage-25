"""``python -m excel_funcs`` 时打印简短演示。"""

from __future__ import annotations

from excel_funcs import ExcelFunctions, SUM, IF


def main() -> None:
    xf = ExcelFunctions()
    print("excel_funcs demo")
    print("SUM(1,2,3):", SUM(1, 2, 3))
    print("IF(True,'Y','N'):", IF(True, "Y", "N"))
    print("xf.math.average(10,20,30):", xf.math.average(10, 20, 30))
    print("xf.text.proper('hello world'):", xf.text.proper("hello world"))


if __name__ == "__main__":
    main()
