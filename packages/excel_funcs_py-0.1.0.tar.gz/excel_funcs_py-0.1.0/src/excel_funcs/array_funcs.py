"""
Layer 1 — 数组/动态数组风格函数（基于 Python ``list``，无 numpy 硬依赖）。

中文说明：
- 行为对齐 Excel 365 **子集**；大表请自行评估性能。
- ``UNIQUE`` 当前实现针对 **一维** 列表；二维可按行展平后使用。
"""

from __future__ import annotations

import random
from collections import Counter
from typing import Any, Sequence

from excel_funcs.errors import VALUE


def UNIQUE(data: Sequence[Any], by_col: bool = False, exactly_once: bool = False) -> list[Any]:
    """
    Excel ``UNIQUE`` 简化版。

    - ``exactly_once=True``：仅保留在区域中**恰好出现一次**的值（保持首次出现顺序）。
    - ``by_col``：占位，与 Excel 按列比较行为不同，当前忽略。
    """

    _ = by_col
    flat = list(data)
    if exactly_once:
        cnt = Counter(flat)
        return [x for x in flat if cnt[x] == 1]

    seen: set[Any] = set()
    out: list[Any] = []
    for x in flat:
        if x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


def SORT(array: Sequence[Any], sort_index: int = 1, sort_order: int = 1, by_col: bool = False) -> list[Any]:
    """
    一维 ``SORT``；``sort_order`` 为 ``1`` 升序，``-1`` 降序。

    ``sort_index`` / ``by_col`` 为多维预留参数，一维数据下忽略 ``sort_index``。
    """

    _ = sort_index, by_col
    arr = list(array)
    rev = sort_order == -1
    try:
        return sorted(arr, reverse=rev)
    except TypeError:
        return arr


def SORTBY(array: Sequence[Any], *by_arrays: Any) -> list[Any]:
    """按第一个 ``by_array`` 与 ``array`` 等长对齐排序。"""

    if not by_arrays:
        return list(array)
    keys = list(by_arrays[0])
    arr = list(array)
    if len(keys) != len(arr):
        return VALUE  # type: ignore[return-value]
    try:
        return [x for _, x in sorted(zip(keys, arr), key=lambda t: t[0])]
    except TypeError:
        return arr


def FILTER(array: Sequence[Any], include: Sequence[bool], if_empty: Any | None = None) -> list[Any] | Any:
    if len(include) != len(array):
        return VALUE
    out = [x for x, ok in zip(array, include) if ok]
    if not out and if_empty is not None:
        return if_empty
    return out


def SEQUENCE(rows: Any, columns: Any = 1, start: Any = 1, step: Any = 1) -> list[list[float]] | Any:
    """返回二维列表（先行后列）。"""

    try:
        r = int(rows)
        c = int(columns)
        s = float(start)
        st = float(step)
    except (TypeError, ValueError):
        return VALUE
    if r < 1 or c < 1:
        return VALUE
    out: list[list[float]] = []
    val = s
    for _ in range(r):
        row: list[float] = []
        v = val
        for _ in range(c):
            row.append(v)
            v += st
        out.append(row)
        val += st * c
    return out


def RANDARRAY(
    rows: Any,
    columns: Any = 1,
    min_: Any = 0,
    max_: Any = 1,
    integer: bool = False,
) -> list[list[float]] | Any:
    try:
        r = int(rows)
        c = int(columns)
        lo = float(min_)
        hi = float(max_)
    except (TypeError, ValueError):
        return VALUE
    if r < 1 or c < 1:
        return VALUE
    out: list[list[float]] = []
    for _ in range(r):
        row: list[float] = []
        for _ in range(c):
            x = random.uniform(lo, hi)
            row.append(float(int(round(x))) if integer else x)
        out.append(row)
    return out
