"""
Layer 1 — 逻辑与条件类函数。

中文说明：
- ``IF``/``IFS``/``SWITCH`` 在 Python 中会**先求值**各分支表达式（语言限制）；Excel 为短路求值，极重分支若有副作用则行为不同。
"""

from __future__ import annotations

from typing import Any

from excel_funcs.errors import NA, ExcelErrorValue, is_error, is_na


def TRUE() -> bool:
    """Excel ``TRUE``。"""

    return True


def FALSE() -> bool:
    """Excel ``FALSE``。"""

    return False


def IF(condition: Any, value_if_true: Any, value_if_false: Any) -> Any:
    """
    Excel ``IF``。

    Note:
        Python 会在调用前计算 ``value_if_true`` 与 ``value_if_false``，无短路。
    """

    return value_if_true if bool(condition) else value_if_false


def IFERROR(value: Any, value_if_error: Any) -> Any:
    """Excel ``IFERROR``：若 ``value`` 为任意 :class:`~excel_funcs.errors.ExcelErrorValue` 则返回备用值。"""

    if is_error(value):
        return value_if_error
    return value


def IFNA(value: Any, value_if_na: Any) -> Any:
    """Excel ``IFNA``：仅 ``#N/A`` 时替换。"""

    if is_na(value):
        return value_if_na
    return value


def AND(*args: Any) -> bool | ExcelErrorValue:
    """
    Excel ``AND``：全为真则真；任一参数为错误则返回该错误；空参数在 Excel 中为 ``#VALUE!``，此处返回 ``False`` 与部分版本不同，建议始终传入条件。
    """

    if not args:
        from excel_funcs.errors import VALUE

        return VALUE
    for a in args:
        if is_error(a):
            return a  # type: ignore[return-value]
        if not bool(a):
            return False
    return True


def OR(*args: Any) -> bool | ExcelErrorValue:
    if not args:
        from excel_funcs.errors import VALUE

        return VALUE
    any_true = False
    for a in args:
        if is_error(a):
            return a  # type: ignore[return-value]
        if bool(a):
            any_true = True
    return any_true


def NOT(value: Any) -> bool | ExcelErrorValue:
    if is_error(value):
        return value  # type: ignore[return-value]
    return not bool(value)


def XOR(*args: Any) -> bool | ExcelErrorValue:
    """Excel ``XOR``：奇数个 ``TRUE`` 时为真。"""

    if not args:
        from excel_funcs.errors import VALUE

        return VALUE
    c = 0
    for a in args:
        if is_error(a):
            return a  # type: ignore[return-value]
        if bool(a):
            c += 1
    return c % 2 == 1


def IFS(*pairs: Any) -> Any:
    """
    Excel ``IFS``：成对 ``(test1, value1, test2, value2, ...)``；若无匹配则返回 ``#N/A``。
    """

    if len(pairs) % 2 != 0:
        from excel_funcs.errors import VALUE

        return VALUE
    for i in range(0, len(pairs), 2):
        cond = pairs[i]
        val = pairs[i + 1]
        if is_error(cond):
            return cond
        if bool(cond):
            return val
    return NA


def SWITCH(expression: Any, *values: Any) -> Any:
    """
    Excel ``SWITCH`` 近似：``SWITCH(expr, key1, val1, key2, val2, ..., [default])``。

    当 ``values`` 长度为奇数时，最后一项视为 **default**（与 Excel 一致）。
    """

    if not values:
        from excel_funcs.errors import VALUE

        return VALUE
    if len(values) % 2 == 1:
        *pairs, default = values
    else:
        pairs = values
        default = NA
    for i in range(0, len(pairs), 2):
        key = pairs[i]
        res = pairs[i + 1]
        if expression == key:
            return res
    return default
