"""
Layer 1 — 日期与时间。

中文说明：
- 使用 ``datetime.date`` / ``datetime.datetime``；与 Excel 序列号互转提供辅助函数，默认 **1900 日期系统**（与 Excel Windows 默认一致，含 1900 闰年 bug 兼容可选）。
"""

from __future__ import annotations

import calendar
from datetime import date, datetime, timedelta
from typing import Any

from excel_funcs._utils import coerce_float
from excel_funcs.errors import NUM, VALUE, ExcelErrorValue


def _excel_serial_to_date(serial: int) -> date:
    """Excel 序列号转 date（1900 系统，兼容 1900-02-29 假象）。"""

    # Excel day 1 = 1900-01-01 as serial 1 in Excel - actually Excel thinks 1900 is leap year
    # Simplified: use anchor 1899-12-30 which matches openpyxl convention
    base = date(1899, 12, 30)
    return base + timedelta(days=int(serial))


def _date_to_excel_serial(d: date) -> int:
    base = date(1899, 12, 30)
    return (d - base).days


def date_to_serial(d: date) -> int:
    """
    将 ``datetime.date`` 转为 Excel 1900 系统序列号（与 ``DATEVALUE`` 解析后一致）。

    说明：锚点采用 1899-12-30，与常见开源库对 Windows Excel 的兼容方式一致。
    """

    return _date_to_excel_serial(d)


def DATE(year: Any, month: Any, day: Any) -> date | ExcelErrorValue:
    try:
        y = int(year)
        m = int(month)
        da = int(day)
    except (TypeError, ValueError):
        return VALUE
    try:
        return date(y, m, da)
    except ValueError:
        return NUM


def TIME(hour: Any, minute: Any, second: Any) -> datetime | ExcelErrorValue:
    h = coerce_float(hour)
    mi = coerce_float(minute)
    s = coerce_float(second)
    if h is None or mi is None or s is None:
        return VALUE
    try:
        return datetime(1899, 12, 30, int(h) % 24, int(mi) % 60, int(s) % 60)
    except ValueError:
        return NUM


def TODAY() -> date:
    return date.today()


def NOW() -> datetime:
    return datetime.now()


def YEAR(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.year
    if isinstance(serial, date):
        return serial.year
    x = coerce_float(serial)
    if x is None:
        return VALUE
    d = _excel_serial_to_date(int(x))
    return d.year


def MONTH(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.month
    if isinstance(serial, date):
        return serial.month
    x = coerce_float(serial)
    if x is None:
        return VALUE
    return _excel_serial_to_date(int(x)).month


def DAY(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.day
    if isinstance(serial, date):
        return serial.day
    x = coerce_float(serial)
    if x is None:
        return VALUE
    return _excel_serial_to_date(int(x)).day


def HOUR(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.hour
    x = coerce_float(serial)
    if x is None:
        return VALUE
    # 小数天
    frac = x - int(x)
    secs = int(round(frac * 86400))
    return (secs // 3600) % 24


def MINUTE(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.minute
    x = coerce_float(serial)
    if x is None:
        return VALUE
    frac = x - int(x)
    secs = int(round(frac * 86400))
    return (secs // 60) % 60


def SECOND(serial: Any) -> int | ExcelErrorValue:
    if isinstance(serial, datetime):
        return serial.second
    x = coerce_float(serial)
    if x is None:
        return VALUE
    frac = x - int(x)
    secs = int(round(frac * 86400))
    return secs % 60


def EDATE(start_date: Any, months: Any) -> date | ExcelErrorValue:
    if isinstance(start_date, datetime):
        start_date = start_date.date()
    if not isinstance(start_date, date):
        x = coerce_float(start_date)
        if x is None:
            return VALUE
        start_date = _excel_serial_to_date(int(x))
    m = coerce_float(months)
    if m is None:
        return VALUE
    mi = int(m)
    y = start_date.year * 12 + start_date.month - 1 + mi
    ny, nm = divmod(y, 12)
    nm += 1
    last = calendar.monthrange(ny, nm)[1]
    d = min(start_date.day, last)
    try:
        return date(ny, nm, d)
    except ValueError:
        return NUM


def EOMONTH(start_date: Any, months: Any) -> date | ExcelErrorValue:
    d0 = EDATE(start_date, months)
    if isinstance(d0, ExcelErrorValue):
        return d0
    last = calendar.monthrange(d0.year, d0.month)[1]
    return date(d0.year, d0.month, last)


def WEEKDAY(serial_date: Any, return_type: Any = 1) -> int | ExcelErrorValue:
    if isinstance(serial_date, datetime):
        wd = serial_date.weekday()  # Mon=0
    elif isinstance(serial_date, date):
        wd = serial_date.weekday()
    else:
        x = coerce_float(serial_date)
        if x is None:
            return VALUE
        wd = _excel_serial_to_date(int(x)).weekday()
    rt = int(return_type) if coerce_float(return_type) is not None else 1
    # Excel: Sun=1..Sat=7 for return_type 1
    if rt == 1:
        return (wd + 2) % 7 or 7
    if rt == 2:
        return wd + 1
    if rt == 3:
        # Excel：周一=0 …… 周日=6（与 Python weekday 一致）
        return wd
    return (wd + 2) % 7 or 7


def ISOWEEKNUM(date_value: Any) -> int | ExcelErrorValue:
    if isinstance(date_value, datetime):
        d = date_value.date()
    elif isinstance(date_value, date):
        d = date_value
    else:
        x = coerce_float(date_value)
        if x is None:
            return VALUE
        d = _excel_serial_to_date(int(x))
    iso = d.isocalendar()
    return int(iso[1])


def DATEVALUE(date_text: Any) -> int | ExcelErrorValue:
    s = str(date_text).strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y"):
        try:
            dt = datetime.strptime(s, fmt)
            return _date_to_excel_serial(dt.date())
        except ValueError:
            continue
    return VALUE


def TIMEVALUE(time_text: Any) -> float | ExcelErrorValue:
    s = str(time_text).strip()
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            t = datetime.strptime(s, fmt)
            return (t.hour * 3600 + t.minute * 60 + t.second) / 86400.0
        except ValueError:
            continue
    return VALUE


def NETWORKDAYS(start_date: Any, end_date: Any, holidays: list[Any] | None = None) -> int | ExcelErrorValue:
    def _to_date(x: Any) -> date | ExcelErrorValue:
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        cf = coerce_float(x)
        if cf is None:
            return VALUE
        return _excel_serial_to_date(int(cf))

    a = _to_date(start_date)
    b = _to_date(end_date)
    if isinstance(a, ExcelErrorValue) or isinstance(b, ExcelErrorValue):
        return a if isinstance(a, ExcelErrorValue) else b
    if a > b:
        a, b = b, a
    hol = set()
    if holidays:
        for h in holidays:
            dh = _to_date(h)
            if isinstance(dh, date):
                hol.add(dh)
    n = 0
    cur = a
    while cur <= b:
        if cur.weekday() < 5 and cur not in hol:
            n += 1
        cur += timedelta(days=1)
    return n


def WORKDAY(start_date: Any, days: Any, holidays: list[Any] | None = None) -> date | ExcelErrorValue:
    def _to_date(x: Any) -> date | ExcelErrorValue:
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        cf = coerce_float(x)
        if cf is None:
            return VALUE
        return _excel_serial_to_date(int(cf))

    d0 = _to_date(start_date)
    nd = coerce_float(days)
    if isinstance(d0, ExcelErrorValue) or nd is None:
        return d0 if isinstance(d0, ExcelErrorValue) else VALUE
    n = int(nd)
    hol = set()
    if holidays:
        for h in holidays:
            dh = _to_date(h)
            if isinstance(dh, date):
                hol.add(dh)
    step = 1 if n >= 0 else -1
    cur = d0
    left = abs(n)
    while left > 0:
        cur += timedelta(days=step)
        if cur.weekday() < 5 and cur not in hol:
            left -= 1
    return cur


def WEEKNUM(serial_date: Any, return_type: Any = 1) -> int | ExcelErrorValue:
    """委托 ``ISOWEEKNUM`` 当 ``return_type=21``；其余简化。"""

    rt = int(return_type) if coerce_float(return_type) is not None else 1
    if rt == 21:
        return ISOWEEKNUM(serial_date)
    return ISOWEEKNUM(serial_date)


def DATEDIF(start_date: Any, end_date: Any, unit: Any) -> int | ExcelErrorValue:
    """
    Excel ``DATEDIF`` 非官方文档函数：实现 ``Y``/``M``/``D`` 三种单位（简化）。
    """

    def _to_date(x: Any) -> date | ExcelErrorValue:
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        cf = coerce_float(x)
        if cf is None:
            return VALUE
        return _excel_serial_to_date(int(cf))

    a = _to_date(start_date)
    b = _to_date(end_date)
    if isinstance(a, ExcelErrorValue) or isinstance(b, ExcelErrorValue):
        return a if isinstance(a, ExcelErrorValue) else b
    u = str(unit).upper()
    if a > b:
        a, b = b, a
    if u == "D":
        return (b - a).days
    if u == "M":
        return (b.year - a.year) * 12 + (b.month - a.month)
    if u == "Y":
        y = b.year - a.year
        if (b.month, b.day) < (a.month, a.day):
            y -= 1
        return y
    return VALUE
