"""
Layer 1 — 信息类函数 ``IS*``、``TYPE``、``N`` 等。

中文说明：
- ``ISFORMULA`` / ``ISREF`` 在纯 Python 数据中无工作表语义，返回基于类型的启发式结果或固定 ``False``。
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from excel_funcs.errors import ExcelErrorValue, NA, is_err, is_error, is_na


def ISBLANK(value: Any) -> bool:
    return value is None or value == ""


def ISNUMBER(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return True
    from excel_funcs._utils import coerce_float

    return coerce_float(value) is not None and not isinstance(value, (list, tuple, dict))


def ISTEXT(value: Any) -> bool:
    return isinstance(value, str)


def ISLOGICAL(value: Any) -> bool:
    return isinstance(value, bool)


def ISERROR(value: Any) -> bool:
    return is_error(value)


def ISERR(value: Any) -> bool:
    return is_err(value)


def ISNA(value: Any) -> bool:
    return is_na(value)


def ISFORMULA(value: Any) -> bool:
    """无工作表上下文时恒为 ``False``。"""

    return False


def ISREF(value: Any) -> bool:
    """若 ``value`` 为嵌套列表（模拟区域）则视为引用。"""

    return isinstance(value, (list, tuple)) and len(value) > 0 and isinstance(value[0], (list, tuple))


def N(value: Any) -> float | ExcelErrorValue:
    """Excel ``N``：数值直返；日期转序列；错误直返；其余 ``0``。"""

    if is_error(value):
        return value  # type: ignore[return-value]
    if isinstance(value, bool):
        return float(int(value))
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, (datetime, date)):
        from excel_funcs.datetime_funcs import date_to_serial

        d = value if isinstance(value, date) else value.date()
        return float(date_to_serial(d))
    if isinstance(value, str):
        from excel_funcs._utils import coerce_float

        c = coerce_float(value)
        return 0.0 if c is None else c
    return 0.0


def TYPE(value: Any) -> int | ExcelErrorValue:
    """
    Excel ``TYPE`` 返回码：数字=1；文本=2；逻辑=4；错误=16；数组=64（本实现数组以嵌套 list 表示）。
    """

    if is_error(value):
        return 16
    if isinstance(value, bool):
        return 4
    if isinstance(value, (int, float)):
        return 1
    if isinstance(value, str):
        return 2
    if isinstance(value, (list, tuple)):
        return 64
    return 1


def ERROR_TYPE(value: Any) -> int | ExcelErrorValue:
    """对应 ``ERROR.TYPE`` 的简化映射。"""

    if not isinstance(value, ExcelErrorValue):
        return NA
    mapping = {
        "#NULL!": 1,
        "#DIV/0!": 2,
        "#VALUE!": 3,
        "#REF!": 4,
        "#NAME?": 5,
        "#NUM!": 6,
        "#N/A": 7,
    }
    return mapping.get(value.code, 8)
