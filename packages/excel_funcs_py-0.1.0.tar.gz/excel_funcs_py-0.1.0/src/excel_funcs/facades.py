"""
Layer 2 — 按 Excel 功能区划分的 Facade 类。

中文说明：
- 每个类将 Layer1 纯函数挂到 ``@staticmethod``，便于 ``ExcelFunctions().math.sum(...)`` 式点选。
- 方法名采用 **小写蛇形**，与 Python 惯例一致；docstring 中标注对应 Excel 英文名。
"""

from __future__ import annotations

import excel_funcs.array_funcs as array_funcs
import excel_funcs.datetime_funcs as datetime_funcs
import excel_funcs.financial as financial
import excel_funcs.info as info
import excel_funcs.logical as logical
import excel_funcs.lookup as lookup
import excel_funcs.math_agg as math_agg
import excel_funcs.text as xf_text


class MathFuncs:
    """数学与统计相关函数。"""

    sum = staticmethod(math_agg.SUM)
    average = staticmethod(math_agg.AVERAGE)
    averagea = staticmethod(math_agg.AVERAGEA)
    count = staticmethod(math_agg.COUNT)
    counta = staticmethod(math_agg.COUNTA)
    countblank = staticmethod(math_agg.COUNTBLANK)
    max = staticmethod(math_agg.MAX)
    min = staticmethod(math_agg.MIN)
    median = staticmethod(math_agg.MEDIAN)
    product = staticmethod(math_agg.PRODUCT)
    sumproduct = staticmethod(math_agg.SUMPRODUCT)
    sumif = staticmethod(math_agg.SUMIF)
    sumifs = staticmethod(math_agg.SUMIFS)
    countif = staticmethod(math_agg.COUNTIF)
    countifs = staticmethod(math_agg.COUNTIFS)
    averageif = staticmethod(math_agg.AVERAGEIF)
    averageifs = staticmethod(math_agg.AVERAGEIFS)
    maxifs = staticmethod(math_agg.MAXIFS)
    minifs = staticmethod(math_agg.MINIFS)
    subtotal = staticmethod(math_agg.SUBTOTAL)
    aggregate = staticmethod(math_agg.AGGREGATE)
    round = staticmethod(math_agg.ROUND)
    rounddown = staticmethod(math_agg.ROUNDDOWN)
    roundup = staticmethod(math_agg.ROUNDUP)
    mround = staticmethod(math_agg.MROUND)
    ceiling_math = staticmethod(math_agg.CEILING_MATH)
    floor_math = staticmethod(math_agg.FLOOR_MATH)
    int = staticmethod(math_agg.INT)
    trunc = staticmethod(math_agg.TRUNC)
    abs = staticmethod(math_agg.ABS)
    sign = staticmethod(math_agg.SIGN)
    mod = staticmethod(math_agg.MOD)
    power = staticmethod(math_agg.POWER)
    sqrt = staticmethod(math_agg.SQRT)
    exp = staticmethod(math_agg.EXP)
    ln = staticmethod(math_agg.LN)
    log = staticmethod(math_agg.LOG)
    log10 = staticmethod(math_agg.LOG10)
    pi = staticmethod(math_agg.PI)
    rand = staticmethod(math_agg.RAND)
    randbetween = staticmethod(math_agg.RANDBETWEEN)
    fact = staticmethod(math_agg.FACT)
    combin = staticmethod(math_agg.COMBIN)
    permut = staticmethod(math_agg.PERMUT)
    gcd = staticmethod(math_agg.GCD)
    lcm = staticmethod(math_agg.LCM)
    quotient = staticmethod(math_agg.QUOTIENT)


class TextFuncs:
    """文本函数。"""

    concat = staticmethod(xf_text.CONCAT)
    textjoin = staticmethod(xf_text.TEXTJOIN)
    left = staticmethod(xf_text.LEFT)
    right = staticmethod(xf_text.RIGHT)
    mid = staticmethod(xf_text.MID)
    len = staticmethod(xf_text.LEN)
    trim = staticmethod(xf_text.TRIM)
    upper = staticmethod(xf_text.UPPER)
    lower = staticmethod(xf_text.LOWER)
    proper = staticmethod(xf_text.PROPER)
    substitute = staticmethod(xf_text.SUBSTITUTE)
    replace = staticmethod(xf_text.REPLACE)
    rept = staticmethod(xf_text.REPT)
    find = staticmethod(xf_text.FIND)
    search = staticmethod(xf_text.SEARCH)
    text = staticmethod(xf_text.TEXT)
    value = staticmethod(xf_text.VALUE_FROM_TEXT)
    char = staticmethod(xf_text.CHAR)
    code = staticmethod(xf_text.CODE)
    exact = staticmethod(xf_text.EXACT)
    fixed = staticmethod(xf_text.FIXED)
    clean = staticmethod(xf_text.CLEAN)


class LogicalFuncs:
    """逻辑与条件。"""

    true = staticmethod(logical.TRUE)
    false = staticmethod(logical.FALSE)
    if_ = staticmethod(logical.IF)
    iferror = staticmethod(logical.IFERROR)
    ifna = staticmethod(logical.IFNA)
    ifs = staticmethod(logical.IFS)
    switch = staticmethod(logical.SWITCH)
    and_ = staticmethod(logical.AND)
    or_ = staticmethod(logical.OR)
    not_ = staticmethod(logical.NOT)
    xor = staticmethod(logical.XOR)


class LookupFuncs:
    """查找与引用。"""

    vlookup = staticmethod(lookup.VLOOKUP)
    hlookup = staticmethod(lookup.HLOOKUP)
    index = staticmethod(lookup.INDEX)
    match = staticmethod(lookup.MATCH)
    choose = staticmethod(lookup.CHOOSE)
    address = staticmethod(lookup.ADDRESS)
    row = staticmethod(lookup.ROW)
    column = staticmethod(lookup.COLUMN)
    rows = staticmethod(lookup.ROWS)
    columns = staticmethod(lookup.COLUMNS)
    transpose = staticmethod(lookup.TRANSPOSE)
    offset = staticmethod(lookup.OFFSET)
    indirect = staticmethod(lookup.INDIRECT)
    xlookup = staticmethod(lookup.XLOOKUP)
    xmatch = staticmethod(lookup.XMATCH)
    lookup = staticmethod(lookup.LOOKUP)


class DateFuncs:
    """日期与时间。"""

    today = staticmethod(datetime_funcs.TODAY)
    now = staticmethod(datetime_funcs.NOW)
    date = staticmethod(datetime_funcs.DATE)
    time = staticmethod(datetime_funcs.TIME)
    year = staticmethod(datetime_funcs.YEAR)
    month = staticmethod(datetime_funcs.MONTH)
    day = staticmethod(datetime_funcs.DAY)
    hour = staticmethod(datetime_funcs.HOUR)
    minute = staticmethod(datetime_funcs.MINUTE)
    second = staticmethod(datetime_funcs.SECOND)
    edate = staticmethod(datetime_funcs.EDATE)
    eomonth = staticmethod(datetime_funcs.EOMONTH)
    weekday = staticmethod(datetime_funcs.WEEKDAY)
    weeknum = staticmethod(datetime_funcs.WEEKNUM)
    isoweeknum = staticmethod(datetime_funcs.ISOWEEKNUM)
    datevalue = staticmethod(datetime_funcs.DATEVALUE)
    timevalue = staticmethod(datetime_funcs.TIMEVALUE)
    networkdays = staticmethod(datetime_funcs.NETWORKDAYS)
    workday = staticmethod(datetime_funcs.WORKDAY)
    datedif = staticmethod(datetime_funcs.DATEDIF)
    date_to_serial = staticmethod(datetime_funcs.date_to_serial)


class FinancialFuncs:
    """财务函数。"""

    pv = staticmethod(financial.PV)
    fv = staticmethod(financial.FV)
    pmt = staticmethod(financial.PMT)
    nper = staticmethod(financial.NPER)
    rate = staticmethod(financial.RATE)
    ipmt = staticmethod(financial.IPMT)
    ppmt = staticmethod(financial.PPMT)
    npv = staticmethod(financial.NPV)
    irr = staticmethod(financial.IRR)
    xirr = staticmethod(financial.XIRR)
    xnpv = staticmethod(financial.XNPV)


class InfoFuncs:
    """信息类函数。"""

    isblank = staticmethod(info.ISBLANK)
    isnumber = staticmethod(info.ISNUMBER)
    istext = staticmethod(info.ISTEXT)
    islogical = staticmethod(info.ISLOGICAL)
    iserror = staticmethod(info.ISERROR)
    iserr = staticmethod(info.ISERR)
    isna = staticmethod(info.ISNA)
    isformula = staticmethod(info.ISFORMULA)
    isref = staticmethod(info.ISREF)
    n = staticmethod(info.N)
    type = staticmethod(info.TYPE)
    error_type = staticmethod(info.ERROR_TYPE)


class ArrayFuncs:
    """动态数组风格函数（基于 list）。"""

    unique = staticmethod(array_funcs.UNIQUE)
    sort = staticmethod(array_funcs.SORT)
    sortby = staticmethod(array_funcs.SORTBY)
    filter = staticmethod(array_funcs.FILTER)
    sequence = staticmethod(array_funcs.SEQUENCE)
    randarray = staticmethod(array_funcs.RANDARRAY)
