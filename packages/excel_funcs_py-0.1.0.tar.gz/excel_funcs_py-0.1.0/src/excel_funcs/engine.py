"""
Layer 3 — 统一入口 ``ExcelFunctions``（Excel 引擎外观）。

中文说明：
- 聚合所有 :mod:`excel_funcs.facades` 中的分类 Facade，推荐作为依赖注入的单一入口。
"""

from __future__ import annotations

from excel_funcs.facades import (
    ArrayFuncs,
    DateFuncs,
    FinancialFuncs,
    InfoFuncs,
    LogicalFuncs,
    LookupFuncs,
    MathFuncs,
    TextFuncs,
)


class ExcelFunctions:
    """
    对外统一 API：通过属性访问各功能分组。

    Example:
        >>> xf = ExcelFunctions()
        >>> xf.math.sum(1, 2, 3)
        6.0
    """

    __slots__ = ("math", "text", "logical", "lookup", "date", "financial", "info", "array")

    def __init__(self) -> None:
        self.math = MathFuncs()
        self.text = TextFuncs()
        self.logical = LogicalFuncs()
        self.lookup = LookupFuncs()
        self.date = DateFuncs()
        self.financial = FinancialFuncs()
        self.info = InfoFuncs()
        self.array = ArrayFuncs()
