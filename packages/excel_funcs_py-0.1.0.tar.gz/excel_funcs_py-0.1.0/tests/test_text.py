"""文本函数测试。"""

from excel_funcs import LEFT, MID, TRIM, UPPER


def test_trim_upper_left() -> None:
    assert TRIM("  a  b  ") == "a b"
    assert UPPER("ab") == "AB"
    assert LEFT("abcd", 2) == "ab"


def test_mid() -> None:
    assert MID("abcdef", 2, 3) == "bcd"
