"""数学与聚合函数与 Excel 常见用例对照。"""

from excel_funcs import AVERAGE, COUNT, COUNTA, DIV0, ROUND, SUM, SUMIFS


def test_sum_flat_and_nested() -> None:
    assert SUM(1, 2, [3, 4]) == 10.0


def test_average_empty_div0() -> None:
    assert AVERAGE() is DIV0
    assert AVERAGE([]) is DIV0  # type: ignore[arg-type]


def test_count_counta() -> None:
    assert COUNT(1, "x", True) == 1
    assert COUNTA(1, "", "a") == 3


def test_round_half_away_from_zero() -> None:
    assert ROUND(2.5, 0) == 3.0
    assert ROUND(-2.5, 0) == -3.0


def test_sumifs() -> None:
    r1 = [1, 2, 3, 4]
    r2 = ["a", "a", "b", "b"]
    assert SUMIFS(r1, r2, "a") == 3.0
