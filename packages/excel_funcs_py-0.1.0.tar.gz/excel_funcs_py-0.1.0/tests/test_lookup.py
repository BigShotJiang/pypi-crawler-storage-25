"""查找函数测试。"""

from excel_funcs.lookup import INDEX, MATCH, VLOOKUP, XLOOKUP


def test_vlookup_exact() -> None:
    table = [[1, "a"], [2, "b"]]
    assert VLOOKUP(2, table, 2, False) == "b"


def test_match_exact() -> None:
    assert MATCH("b", ["a", "b", "c"], 0) == 2


def test_index() -> None:
    assert INDEX([[10, 20], [30, 40]], 2, 2) == 40


def test_xlookup() -> None:
    assert XLOOKUP(2, [1, 2, 3], ["x", "y", "z"]) == "y"
