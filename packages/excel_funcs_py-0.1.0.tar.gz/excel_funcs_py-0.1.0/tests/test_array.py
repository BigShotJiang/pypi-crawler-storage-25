"""数组函数测试。"""

from excel_funcs.array_funcs import SEQUENCE, SORT, UNIQUE


def test_unique() -> None:
    assert UNIQUE([1, 2, 1, 3]) == [1, 2, 3]


def test_sort() -> None:
    assert SORT([3, 1, 2]) == [1, 2, 3]


def test_sequence_shape() -> None:
    m = SEQUENCE(2, 3)
    assert len(m) == 2 and len(m[0]) == 3
