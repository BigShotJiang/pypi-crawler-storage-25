"""日期函数测试。"""

from datetime import date

from excel_funcs.datetime_funcs import DATE, EDATE, EOMONTH, NETWORKDAYS, date_to_serial


def test_date_edate_eomonth() -> None:
    d = DATE(2024, 1, 15)
    assert isinstance(d, date)
    e = EDATE(d, 1)
    assert e.month == 2
    assert EOMONTH(d, 0).day == 31


def test_networkdays() -> None:
    a = date(2024, 1, 1)
    b = date(2024, 1, 7)
    # Mon..Sun: weekdays Mon-Fri = 5
    assert NETWORKDAYS(a, b) == 5


def test_date_to_serial_roundtrip_order() -> None:
    d = date(2024, 6, 1)
    s = date_to_serial(d)
    assert s > 40000
