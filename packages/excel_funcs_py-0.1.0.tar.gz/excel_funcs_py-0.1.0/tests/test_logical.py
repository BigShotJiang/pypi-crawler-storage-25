"""逻辑函数测试。"""

from excel_funcs import IF, IFERROR
from excel_funcs.errors import VALUE


def test_if_basic() -> None:
    assert IF(True, 1, 2) == 1
    assert IF(False, 1, 2) == 2


def test_iferror() -> None:
    assert IFERROR(1, 2) == 1
    assert IFERROR(VALUE, 2) == 2
