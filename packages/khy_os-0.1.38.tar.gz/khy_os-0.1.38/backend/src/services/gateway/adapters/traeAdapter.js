/**
 * Trae IDE Adapter — connect to Trae (ByteDance) models.
 *
 * Strategy (generate):
 * 0) Trae Native Protocol (x-cloudide-token, requires nativeToken + nativeHost)
 * 1) CodeWhisperer protocol (accessToken required; sessionCookies optional)
 * 2) Proprietary Trae Network SDK (if @byted-icube/trae-network-client available)
 * 3) HTTP OpenAI-compatible endpoint
 * 4) Fallback token retry on auth failure
 *
 * Status model (getStatus):
 *   verified  — token valid, API probed OK
 *   pending   — token found, not yet probed
 *   encrypted — official Trae login detected but safeStorage-encrypted (external undecryptable)
 *   installed — Trae dirs exist but no login artifacts
 *   missing   — no Trae installation found
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { sanitizeOutgoingHeaders } = require('./ipAnonymizer');
const { attachImagesToOpenAIMessages } = require('./_imageCompat');
const { requestJson, collectProxyCandidates } = require('./_proxyTunnel');
const {
  collectTraeOfficialArtifacts,
  resolveTraeOfficialCredential,
  verifyTraeOfficialSession,
  resolveTraeOfficialStoragePaths,
  resolveTraeOfficialDbPaths,
  decodeTraeOfficialAuthBlob,
  resolveNativeHostByRegion,
  TRAE_REGION_HOST_MAP,
} = require('./traeOfficialArtifacts');

const TRAE_STORAGE_PATHS = [
  // Nirvana 换号软件 (各种安装位置)
  path.join(os.homedir(), '.config', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), '.config', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  // Windows: Program Files 安装目录
  'C:\\Program Files\\nirvana\\User\\globalStorage\\storage.json',
  'C:\\Program Files\\Nirvana\\User\\globalStorage\\storage.json',
  'C:\\Program Files\\nirvana\\storage.json',
  'C:\\Program Files\\Nirvana\\storage.json',
  // Trae CN (国内版)
  path.join(os.homedir(), '.config', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  // Trae 国际版
  path.join(os.homedir(), '.config', 'Trae', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Trae', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Trae', 'User', 'globalStorage', 'storage.json'),
];

// Nirvana 换号软件的 trae_local_cache.json — 包含完整 session_cookies (60天有效)
const NIRVANA_TRAE_CACHE_PATHS = (() => {
  const envPath = String(process.env.NIRVANA_TRAE_CACHE || '').trim();
  const home = os.homedir();
  const paths = [
    envPath,
    // Windows: %APPDATA%/nirvana (标准用户数据)
    path.join(home, 'AppData', 'Roaming', 'nirvana', 'trae_local_cache.json'),
    path.join(home, 'AppData', 'Roaming', 'Nirvana', 'trae_local_cache.json'),
    // Windows: Program Files 安装目录
    'C:\\Program Files\\nirvana\\trae_local_cache.json',
    'C:\\Program Files\\Nirvana\\trae_local_cache.json',
    'C:\\Program Files (x86)\\nirvana\\trae_local_cache.json',
    // Windows: %LOCALAPPDATA%
    path.join(home, 'AppData', 'Local', 'nirvana', 'trae_local_cache.json'),
    path.join(home, 'AppData', 'Local', 'Nirvana', 'trae_local_cache.json'),
    // Linux
    path.join(home, '.config', 'nirvana', 'trae_local_cache.json'),
    path.join(home, '.config', 'Nirvana', 'trae_local_cache.json'),
    // macOS
    path.join(home, 'Library', 'Application Support', 'nirvana', 'trae_local_cache.json'),
    path.join(home, 'Library', 'Application Support', 'Nirvana', 'trae_local_cache.json'),
  ].filter(Boolean);
  return paths;
})();

const COOKIE_EXPIRE_BUFFER_MS = 5 * 60 * 1000; // 5 分钟提前过期缓冲

const KNOWN_MODELS = [
  { id: 'gpt-5.4-beta', name: 'GPT-5.4 Beta', isDefault: true },
  { id: 'gpt-5.2', name: 'GPT-5.2', isDefault: false },
  { id: 'minimax-m2.7', name: 'MiniMax-M2.7', isDefault: false },
  { id: 'kimi-k2.5', name: 'Kimi-K2.5', isDefault: false },
  { id: 'deepseek-v3.2', name: 'DeepSeek-V3.2', isDefault: false },
  { id: 'gemini-3.1-pro-preview', name: 'Gemini-3.1-Pro-Preview', isDefault: false },
  { id: 'gemini-3-flash-preview', name: 'Gemini-3-Flash-Preview', isDefault: false },
  { id: 'gemini-2.5-flash', name: 'Gemini-2.5-Flash', isDefault: false },
];

// Models that Trae IDE has offered historically or may add soon.
// Injected when the API doesn't list them, same strategy as Kiro.
// Source: Trae CN model picker (2026-05).
const TRAE_INJECTED_MODELS = [
  { id: 'doubao-1.5-pro', name: 'Doubao 1.5 Pro' },
  { id: 'doubao-1.5-thinking', name: 'Doubao 1.5 Thinking' },
  { id: 'deepseek-r1', name: 'DeepSeek R1' },
  { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet' },
  { id: 'gpt-4o', name: 'GPT-4o' },
];
const TRAE_INJECT_MODELS = !/^(0|false|off)$/i.test(
  String(process.env.TRAE_INJECT_MODELS || '1').trim()
);

const ACCOUNT_POOL_TYPE = 'trae';
const TIMEOUT_MS = 60_000;
const MODEL_DISCOVERY_CACHE_MS = Math.max(5000, parseInt(process.env.TRAE_MODEL_CACHE_MS || '120000', 10) || 120000);
const MODEL_TOKEN_REGEX = /\b[a-zA-Z0-9][a-zA-Z0-9._:-]{2,80}\b/g;

// 结构化检测状态
let _detectionState = {
  installDetected: false,            // 磁盘上有 Trae/Nirvana 目录
  officialArtifactsDetected: false,  // 找到 iCube 等登录痕迹（即使加密）
  officialArtifactSources: [],       // 发现 artifact 的路径列表
  credentialMode: 'none',            // 'none' | 'encrypted' | 'plaintext' | 'cookie'
  sessionVerified: false,            // token 成功调用过 API
  available: false,                  // 派生：sessionVerified || credentialMode 为 plaintext/cookie
  _checked: false,
  _officialCredential: null,         // resolveTraeOfficialCredential() 缓存
};
const ENDPOINT_PROBE_CACHE_MS = 5 * 60 * 1000;
const ENDPOINT_PROBE_CACHE_MAX = 64; // 上限 64 条，防止长时间运行堆积
const _endpointProbeCache = new Map();

/**
 * 写入探活缓存（带 TTL 淘汰）
 * 超过 ENDPOINT_PROBE_CACHE_MAX 时淘汰最旧的 entry
 */
function _setProbeCache(key, result) {
  _endpointProbeCache.set(key, { at: Date.now(), result: result });
  if (_endpointProbeCache.size > ENDPOINT_PROBE_CACHE_MAX) {
    // Map 保持插入顺序 — 删最早插入的
    const first = _endpointProbeCache.keys().next().value;
    if (first !== undefined) _endpointProbeCache.delete(first);
  }
}
let _token = null;
let _models = [];
let _modelsFetchedAt = 0;
let _lastApiMeta = {
  at: 0,
  endpoint: '',
  officialHit: false,
  officialCount: 0,
  localCount: 0,
  mergedCount: 0,
  error: '',
  mode: 'http',
};

let _sdkLoadTried = false;
let _sdkModule = null;
let _sdkLoadError = null;
let _sdkClient = null;
let _sdkClientEndpoint = '';

function parseList(raw) {
  return String(raw || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

function dedupe(values = []) {
  const out = [];
  const seen = new Set();
  for (const value of values) {
    const key = String(value || '').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

function normalizeModelId(id) {
  return String(id || '')
    .trim()
    .replace(/^["']|["']$/g, '')
    .replace(/\s+/g, '');
}

function canonicalModelKey(id) {
  return normalizeModelId(id).toLowerCase();
}

function normalizeToken(raw) {
  return String(raw || '').trim();
}

function isLikelyCredentialToken(raw) {
  const token = normalizeToken(raw);
  if (!token) return false;
  if (token.length < 20 || token.length > 4096) return false;
  if (/\s/.test(token)) return false;
  if (!/^[A-Za-z0-9._\-+/=~:]+$/.test(token)) return false;
  if (/^(null|undefined|token|access[_-]?token|bearer)$/i.test(token)) return false;
  // Keep acceptance broad: some IDE sessions use pure-hex credentials.
  if (/^(eyJ|sk-|rk-|rt_|atk-|khy-)/i.test(token)) return true;
  if (/^[A-Za-z0-9]{20,}$/i.test(token)) return true;
  return /[A-Za-z]/.test(token) || /\d/.test(token);
}

function normalizeEndpointBase(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';

  let base = text;
  if (!/^https?:\/\//i.test(base)) {
    base = `https://${base.replace(/^\/+/, '')}`;
  }

  try {
    const url = new URL(base);
    let pathname = String(url.pathname || '').trim();
    if (pathname.endsWith('/chat/completions')) {
      pathname = pathname.slice(0, -('/chat/completions'.length));
    }
    if (!pathname || pathname === '/') {
      pathname = '/v1';
    }
    pathname = pathname.replace(/\/+$/, '') || '/v1';
    return `${url.protocol}//${url.host}${pathname}`;
  } catch {
    return '';
  }
}

function toRelayEndpointBase(raw) {
  const normalized = normalizeEndpointBase(raw);
  if (!normalized) return '';
  return normalized
    .replace(/\/chat\/completions$/i, '')
    .replace(/\/models$/i, '')
    .replace(/\/+$/, '');
}

function buildChatUrl(base) {
  return `${String(base || '').replace(/\/+$/, '')}/chat/completions`;
}

function buildModelsUrl(base) {
  return `${String(base || '').replace(/\/+$/, '')}/models`;
}

function isLikelyModelId(id) {
  const model = canonicalModelKey(id);
  if (!model) return false;
  if (model.length < 3 || model.length > 64) return false;
  if (model.startsWith('http') || model.includes('@') || model.includes('\\')) return false;
  if (/[^a-z0-9._:-]/i.test(model)) return false;
  if (!/\d/.test(model) && !/(sonnet|haiku|opus|cascade|chat|turbo|lightning|lite|large|medium|plus)/i.test(model)) return false;
  // yi/swe 太短，需要后跟分隔符防止误匹配 hash (如 "mEXYIzGB..." 碰巧含 "yi")
  return /(gpt|claude|deepseek|qwen|glm|doubao|llama|mistral|moonshot|yi[-._:]|kimi|minimax|gemini|swe[-._:]|sonnet|haiku|opus|cascade)/i.test(model);
}

function modelDisplayName(id) {
  const normalized = normalizeModelId(id);
  const known = KNOWN_MODELS.find(m => canonicalModelKey(m.id) === canonicalModelKey(normalized));
  if (known?.name) return known.name;
  if (/^gpt/i.test(normalized)) return normalized.replace(/^gpt/i, 'GPT');
  if (/^claude/i.test(normalized)) return normalized.replace(/^claude/i, 'Claude');
  if (/^deepseek/i.test(normalized)) return normalized.replace(/^deepseek/i, 'DeepSeek');
  if (/^doubao/i.test(normalized)) return normalized.replace(/^doubao/i, 'Doubao');
  if (/^minimax/i.test(normalized)) return normalized.replace(/^minimax/i, 'MiniMax');
  if (/^gemini/i.test(normalized)) return normalized.replace(/^gemini/i, 'Gemini');
  if (/^kimi/i.test(normalized)) return normalized.replace(/^kimi/i, 'Kimi');
  return normalized;
}

function extractModelIdsFromString(text) {
  const out = new Set();
  const src = String(text || '');
  if (!src) return out;

  if (isLikelyModelId(src)) out.add(normalizeModelId(src));

  const cleaned = src.replace(/[,"'()[\]{}]/g, ' ');
  const regex = new RegExp(MODEL_TOKEN_REGEX.source, 'g');
  let m;
  while ((m = regex.exec(cleaned)) !== null) {
    const token = normalizeModelId(m[0]);
    if (isLikelyModelId(token)) out.add(token);
  }
  return out;
}

function readTraeStorageSnapshots() {
  const snapshots = [];
  for (const p of TRAE_STORAGE_PATHS) {
    try {
      if (!fs.existsSync(p)) continue;
      const data = JSON.parse(fs.readFileSync(p, 'utf8'));
      snapshots.push({ path: p, data });
    } catch {
      // ignore malformed storage snapshots
    }
  }
  return snapshots;
}

/**
 * 检测磁盘上是否安装了 Trae IDE（检查官方 + Nirvana 路径）
 */
function detectInstallation() {
  const dirsToCheck = new Set();
  for (const p of TRAE_STORAGE_PATHS) dirsToCheck.add(path.dirname(p));
  for (const p of resolveTraeOfficialStoragePaths()) dirsToCheck.add(path.dirname(p));
  for (const p of resolveTraeOfficialDbPaths()) dirsToCheck.add(path.dirname(p));
  for (const dir of dirsToCheck) {
    try { if (fs.existsSync(dir)) return true; } catch { /* ignore */ }
  }
  return false;
}

/**
 * 端点探活：验证端点是否返回有效的 OpenAI 兼容 JSON 响应。
 * 缓存 5 分钟，超时 8 秒。不会删除端点，只返回状态。
 * @param {string} url - 端点基础 URL (如 https://api.trae.ai/v1)
 * @param {string} [token] - Bearer token
 * @returns {Promise<'ok'|'fail'>}
 */
async function probeEndpoint(url, token = '') {
  const cacheKey = url;
  const cached = _endpointProbeCache.get(cacheKey);
  if (cached && (Date.now() - cached.at < ENDPOINT_PROBE_CACHE_MS)) {
    return cached.result;
  }

  const modelsUrl = `${String(url || '').replace(/\/+$/, '')}/models`;
  const headers = { 'Accept': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  try {
    const result = await requestJson(modelsUrl, {
      method: 'GET',
      headers,
      timeout: 8000,
      maxRetries: 0,
    });
    const body = result?.body || result?.data || result;
    // 有效：JSON 含 data/models 数组；失败：HTML / 404 / 非 JSON
    const contentType = String(result?.headers?.['content-type'] || '').toLowerCase();
    const isHtml = contentType.includes('text/html');
    const isJson = (Array.isArray(body?.data) || Array.isArray(body?.models));
    const status = (isJson && !isHtml) ? 'ok' : 'fail';
    _setProbeCache(cacheKey, status);
    return status;
  } catch {
    _setProbeCache(cacheKey, 'fail');
    return 'fail';
  }
}

/**
 * 读取 Nirvana 的 trae_local_cache.json — 包含完整 session_cookies + access_token。
 * 文件格式: { "email@example.com": { email, access_token, session_cookies, cookies_expire_at, ... } }
 * @returns {Array<{email, accessToken, sessionCookies, cookiesExpireAt, tokenExpireAt, apiBase, userId, region, source, path}>}
 */
function readNirvanaCacheAccounts() {
  const now = Date.now();
  const results = [];
  const seenEmails = new Set();

  for (const cachePath of NIRVANA_TRAE_CACHE_PATHS) {
    try {
      if (!fs.existsSync(cachePath)) continue;
      const raw = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
      if (!raw || typeof raw !== 'object') continue;

      for (const [email, acc] of Object.entries(raw)) {
        if (!acc || typeof acc !== 'object') continue;
        if (!acc.session_cookies || !acc.cookies_expire_at) continue;

        const cookiesExpireTs = new Date(acc.cookies_expire_at).getTime();
        if (!Number.isFinite(cookiesExpireTs) || cookiesExpireTs < now + COOKIE_EXPIRE_BUFFER_MS) continue;

        const emailKey = String(email || acc.email || '').trim().toLowerCase();
        if (seenEmails.has(emailKey)) continue;
        if (emailKey) seenEmails.add(emailKey);

        const accessToken = normalizeToken(acc.access_token);
        results.push({
          email: acc.email || email,
          accessToken,
          sessionCookies: acc.session_cookies,
          cookiesExpireAt: acc.cookies_expire_at,
          tokenExpireAt: acc.token_expire_at || null,
          apiBase: acc.api_base || null,
          userId: acc.trae_user_id || null,
          region: acc.region || null,
          source: 'nirvana-cache',
          path: cachePath,
        });
      }
    } catch {
      // ignore malformed cache files
    }
  }

  // 按 cookie 过期时间降序 (选最晚过期的)
  results.sort((a, b) => new Date(b.cookiesExpireAt) - new Date(a.cookiesExpireAt));
  return results;
}

function isCookieExpired(cookiesExpireAt) {
  if (!cookiesExpireAt) return true;
  const ts = new Date(cookiesExpireAt).getTime();
  if (!Number.isFinite(ts)) return true;
  return ts < Date.now() + COOKIE_EXPIRE_BUFFER_MS;
}

function readTraeToken() {
  // ── 优先级 1: 官方 Trae 扫描 (storage.json + state.vscdb / state-global.vscdb) ──
  // 不依赖 Nirvana，优先从官方 Trae 安装中发现可用凭据
  const officialCred = resolveTraeOfficialCredential();
  _detectionState._officialCredential = officialCred;
  _detectionState.officialArtifactsDetected = officialCred.officialArtifactsDetected;
  _detectionState.officialArtifactSources = officialCred.sourcePaths || [];

  if (officialCred.credentialMode === 'plaintext' && officialCred.token) {
    _detectionState.credentialMode = 'plaintext';
    return {
      accessToken: normalizeToken(officialCred.token),
      refreshToken: null,
      source: 'official-trae',
      path: (officialCred.sourcePaths || [])[0] || null,
      endpoint: normalizeEndpointBase(officialCred.endpoint || ''),
      sdkEndpoint: null,
      expiresAt: null,
      sessionCookies: null,
      cookiesExpireAt: null,
    };
  }

  if (officialCred.officialArtifactsDetected && _detectionState.credentialMode === 'none') {
    _detectionState.credentialMode = officialCred.credentialMode; // 'encrypted'
  }

  // ── 优先级 2: Nirvana/旧式 storage.json 中的明文 token (Nirvana + Trae CN/国际) ──
  const snapshots = readTraeStorageSnapshots();
  for (const snap of snapshots) {
    const data = snap.data || {};
    const token = data.traeAuth?.accessToken
      || data['traeAuth/accessToken']
      || data['trae.auth']?.accessToken
      || data['bytedance.auth']?.accessToken
      || data.nirvanaAuth?.accessToken
      || data['nirvanaAuth/accessToken']
      || data.accessToken;

    if (!isLikelyCredentialToken(token)) continue;

    const endpoint = normalizeEndpointBase(
      data.traeAuth?.endpoint
      || data.traeAuth?.host
      || data['trae.auth']?.endpoint
      || data['trae.auth']?.host
      || data.nirvanaAuth?.host
      || data['nirvanaAuth/host']
      || data.endpoint
      || data.baseUrl
      || data.baseURL
    );

    return {
      accessToken: normalizeToken(token),
      refreshToken: data.traeAuth?.refreshToken
        || data['traeAuth/refreshToken']
        || data['trae.auth']?.refreshToken
        || data['bytedance.auth']?.refreshToken
        || data.nirvanaAuth?.refreshToken
        || data['nirvanaAuth/refreshToken']
        || null,
      source: path.basename(path.dirname(path.dirname(path.dirname(snap.path)))),
      path: snap.path,
      endpoint,
      sdkEndpoint: data.traeAuth?.sdkEndpoint || data.nirvanaAuth?.sdkEndpoint || null,
      expiresAt: data.traeAuth?.expiresAt
        || data['traeAuth/expiresAt']
        || data['trae.auth']?.expiresAt
        || data['bytedance.auth']?.expiresAt
        || data.nirvanaAuth?.refreshExpireAt
        || data['nirvanaAuth/refreshExpireAt']
        || null,
      sessionCookies: null,
      cookiesExpireAt: null,
    };
  }

  // ── 优先级 3: Nirvana trae_local_cache.json (60天 session_cookies) ──
  const cacheAccounts = readNirvanaCacheAccounts();
  if (cacheAccounts.length > 0) {
    const best = cacheAccounts[0];
    _detectionState.credentialMode = 'cookie';
    return {
      accessToken: best.accessToken || '',
      refreshToken: null,
      source: 'nirvana-cache',
      path: best.path,
      endpoint: normalizeEndpointBase(best.apiBase),
      sdkEndpoint: null,
      expiresAt: best.tokenExpireAt,
      sessionCookies: best.sessionCookies,
      cookiesExpireAt: best.cookiesExpireAt,
    };
  }

  return null;
}

function isTokenExpired(tokenData) {
  if (!tokenData || !tokenData.expiresAt) return false;
  const ts = new Date(tokenData.expiresAt).getTime();
  if (!Number.isFinite(ts)) return false;
  return ts < (Date.now() + 60 * 1000);
}

function resolveTokenPriority() {
  const raw = String(process.env.TRAE_TOKEN_PRIORITY || 'pool-first').trim().toLowerCase();
  if (raw === 'local-first' || raw === 'local_first' || raw === 'local') return 'local-first';
  return 'pool-first';
}

function dedupeTokens(tokens = []) {
  const out = [];
  const seen = new Set();
  for (const token of tokens) {
    if (!token || !isLikelyCredentialToken(token.accessToken)) continue;
    const key = normalizeToken(token.accessToken);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(token);
  }
  return out;
}

function toPoolTokenShape(poolToken = null) {
  if (!poolToken || !isLikelyCredentialToken(poolToken.accessToken)) return null;

  const auth = poolToken.authData && typeof poolToken.authData === 'object' ? poolToken.authData : {};
  const endpoint = normalizeEndpointBase(
    auth.endpoint
    || auth.host
    || auth.baseUrl
    || auth.baseURL
    || auth.callback?.host
  );

  return {
    accessToken: normalizeToken(poolToken.accessToken),
    refreshToken: poolToken.refreshToken ? normalizeToken(poolToken.refreshToken) : null,
    source: `pool:${poolToken.label || ACCOUNT_POOL_TYPE}`,
    path: poolToken.sourcePath || '',
    expiresAt: poolToken.expiresAt || auth.expiresAt || null,
    endpoint,
    sdkEndpoint: auth.sdkEndpoint || auth.socketEndpoint || null,
  };
}

async function getPoolActiveToken() {
  try {
    const pool = require('../../accountPool');
    await pool.init();
    const token = await pool.getActiveToken(ACCOUNT_POOL_TYPE);
    return toPoolTokenShape(token);
  } catch {
    return null;
  }
}

async function getTokenCandidates() {
  const localToken = readTraeToken();
  const poolToken = await getPoolActiveToken();
  const currentToken = (_token && _token.accessToken) ? _token : null;

  if (localToken && localToken.accessToken) {
    persistObservedToken(localToken);
  }

  const ordered = resolveTokenPriority() === 'local-first'
    ? [localToken, poolToken, currentToken]
    : [poolToken, localToken, currentToken];

  const deduped = dedupeTokens(ordered);

  // 追加 Nirvana cache 中其他未去重的账号 (有 sessionCookies 的)
  // 如果已有同 token 但缺 cookies，用 Nirvana 版本增强
  const cacheAccounts = readNirvanaCacheAccounts();
  const existingTokens = new Set(deduped.map(t => normalizeToken(t.accessToken)));
  for (const acc of cacheAccounts) {
    if (!acc.accessToken) continue;
    const normalizedAccToken = normalizeToken(acc.accessToken);

    // 已有同 token — 补充 sessionCookies
    if (existingTokens.has(normalizedAccToken)) {
      if (acc.sessionCookies) {
        const existing = deduped.find(t => normalizeToken(t.accessToken) === normalizedAccToken);
        if (existing && !existing.sessionCookies) {
          existing.sessionCookies = acc.sessionCookies;
          existing.cookiesExpireAt = acc.cookiesExpireAt;
          if (acc.apiBase) existing.apiBase = acc.apiBase;
        }
      }
      continue;
    }

    if (!isLikelyCredentialToken(acc.accessToken)) continue;
    existingTokens.add(normalizedAccToken);
    deduped.push({
      accessToken: normalizedAccToken,
      refreshToken: null,
      source: 'nirvana-cache',
      path: acc.path,
      endpoint: normalizeEndpointBase(acc.apiBase),
      sdkEndpoint: null,
      expiresAt: acc.tokenExpireAt,
      sessionCookies: acc.sessionCookies,
      cookiesExpireAt: acc.cookiesExpireAt,
      apiBase: acc.apiBase,
    });
  }

  return deduped;
}

/** 评分: 有效 Cookie +100, 有效 Token +50 */
function _scoreToken(t) {
  let score = 0;
  if (t.sessionCookies && !isCookieExpired(t.cookiesExpireAt)) score += 100;
  if (!isTokenExpired(t)) score += 50;
  if (isLikelyCredentialToken(t.accessToken)) score += 10;
  return score;
}

async function selectToken({ allowExpired = false } = {}) {
  const candidates = await getTokenCandidates();
  if (candidates.length === 0) {
    return { token: null, fallback: null, candidates: [] };
  }

  // 按评分降序排列, 优先选有 Cookie 的账号
  const scored = candidates.map(t => ({ t, s: _scoreToken(t) }));
  scored.sort((a, b) => b.s - a.s);
  const sorted = scored.map(x => x.t);

  const nonExpired = sorted.filter(t => !isTokenExpired(t) || (t.sessionCookies && !isCookieExpired(t.cookiesExpireAt)));
  const token = nonExpired[0] || (allowExpired ? sorted[0] : null);
  if (!token) {
    return { token: null, fallback: null, candidates };
  }

  const fallback = nonExpired.find(t => t.accessToken !== token.accessToken) || null;
  return { token, fallback, candidates };
}

function _stableLabel(source) {
  // Strip accumulated "pool:" / "trae:" prefixes to prevent label growth loop
  const stripped = String(source || '').replace(/^(?:pool:|trae:)+/g, '');
  return `${ACCOUNT_POOL_TYPE}:${stripped || 'pool'}`;
}

function persistObservedToken(token = null) {
  if (!token || !isLikelyCredentialToken(token.accessToken)) return;

  Promise.resolve().then(async () => {
    try {
      const pool = require('../../accountPool');
      await pool.init();
      await pool.saveObservedToken(ACCOUNT_POOL_TYPE, {
        accessToken: token.accessToken,
        refreshToken: token.refreshToken || null,
        sourcePath: token.path || '',
        label: _stableLabel(token.source),
        authData: {
          source: token.source || ACCOUNT_POOL_TYPE,
          path: token.path || '',
          endpoint: token.endpoint || null,
          sdkEndpoint: token.sdkEndpoint || null,
          expiresAt: token.expiresAt || null,
        },
      }, { activateIfNone: true });
      await pool.autoImportObservedCredentials(ACCOUNT_POOL_TYPE);
    } catch {
      // best effort only
    }
  });
}

function discoverModelsFromSnapshots(snapshots = []) {
  const discoveredByKey = new Map();
  const defaultHints = [];

  const addModel = (raw, options = {}) => {
    const normalized = normalizeModelId(raw);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (!discoveredByKey.has(key)) discoveredByKey.set(key, normalized);
    if (options.defaultHint) defaultHints.push(normalized);
  };

  const walk = (value, keyHint = '') => {
    if (value == null) return;
    const key = String(keyHint || '').toLowerCase();

    if (typeof value === 'string') {
      for (const id of extractModelIdsFromString(value)) {
        addModel(id, {
          defaultHint: key.includes('default') || key.includes('selected') || key.includes('current') || key.includes('active'),
        });
      }
      return;
    }

    if (Array.isArray(value)) {
      for (const item of value) walk(item, keyHint);
      return;
    }

    if (typeof value === 'object') {
      for (const [k, v] of Object.entries(value)) {
        const lk = String(k || '').toLowerCase();
        if (isLikelyModelId(k)) addModel(k, { defaultHint: lk.includes('default') || lk.includes('selected') });
        if (typeof v === 'string' && (lk.includes('model') || lk.includes('assistant') || lk.includes('engine'))) {
          addModel(v, {
            defaultHint: lk.includes('default') || lk.includes('selected') || lk.includes('current') || lk.includes('active'),
          });
        }
        walk(v, lk);
      }
    }
  };

  for (const snapshot of snapshots) walk(snapshot.data);
  return {
    discoveredModelIds: [...discoveredByKey.values()],
    defaultModelId: defaultHints[0] || null,
  };
}

function buildModelList(discoveredModelIds = [], defaultModelId = null, options = {}) {
  const seen = new Set();
  const catalog = [];
  const defaultKey = canonicalModelKey(defaultModelId);
  const apiModelKeys = new Set((options.apiModelIds || []).map(canonicalModelKey));
  const localModelKeys = new Set((options.localModelIds || []).map(canonicalModelKey));
  let hasDefault = false;

  const sourceFor = (id, fallback = 'builtin') => {
    const key = canonicalModelKey(id);
    if (apiModelKeys.has(key)) return 'official';
    if (localModelKeys.has(key)) return 'local';
    return fallback;
  };

  const addModel = (id, name, isDefault = false, fallbackSource = 'builtin') => {
    const normalized = normalizeModelId(id);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (seen.has(key)) return;
    seen.add(key);
    catalog.push({
      id: normalized,
      name: name || modelDisplayName(normalized),
      isDefault: !!isDefault,
      discoverySource: sourceFor(normalized, fallbackSource),
    });
    if (isDefault) hasDefault = true;
  };

  for (const model of KNOWN_MODELS) {
    const key = canonicalModelKey(model.id);
    addModel(model.id, model.name, defaultKey ? key === defaultKey : !!model.isDefault, 'builtin');
  }

  for (const discoveredId of discoveredModelIds) {
    const key = canonicalModelKey(discoveredId);
    addModel(discoveredId, modelDisplayName(discoveredId), defaultKey ? key === defaultKey : false, 'local');
  }

  if (!hasDefault && catalog.length > 0) {
    const fallback = catalog.find(m => canonicalModelKey(m.id) === 'doubao-1.5-pro') || catalog[0];
    fallback.isDefault = true;
  }

  return catalog;
}

function resolveTraeApiBases(tokenData = null) {
  const envList = [
    ...parseList(process.env.TRAE_API_ENDPOINTS),
    ...parseList(process.env.TRAE_API_ENDPOINT),
    ...parseList(process.env.TRAE_API_BASE_URL),
  ];

  // Trae 原生/CW 协议端点 — 不支持 /v1/chat/completions，仅限 GenerateAssistantResponse/ListAvailableModels
  const TRAE_NATIVE_HOSTS = [
    'api-us-east.trae.ai', 'api-eu-west.trae.ai', 'api-ap.trae.ai',
    'api-cn.trae.ai', 'api.trae.cn', 'api-cn-east.trae.ai',
    'adaptive-api.trae.ai',
    // Windows 运行日志 + product.json 确认的原生协议主机 — 非 OpenAI 兼容
    'grow-normal.trae.ai', 'core-normal.trae.ai',
    'growsg-normal.trae.ai', 'growva-normal.trae.ai',
    'grow-normal.traeapi.us',
  ];
  const isNativeHost = (url) => {
    try { return TRAE_NATIVE_HOSTS.includes(new URL(url).hostname); } catch { return false; }
  };

  // token 字段中的非 CW/原生端点 (可能是真正的 OpenAI 兼容中继)
  const tokenList = [
    tokenData?.endpoint,
    tokenData?.host,
    tokenData?.baseUrl,
    tokenData?.baseURL,
    tokenData?.apiBase,
  ].filter(url => url && !isNativeHost(url));

  // 官方凭据中提取的 endpointHints（过滤掉原生端点）
  const officialHints = (_detectionState._officialCredential?.endpointHints || [])
    .filter(url => url && !isNativeHost(url));

  // 不再盲加 api.trae.ai/v1 — 只有来自明确来源的端点才进入 OpenAI 兼容列表
  // 如果用户设置了 env、token 有端点、或官方 serverData 有 apiHost，才有真实端点
  // 否则列表为空 → fetchModelsFromApi 会直接抛错，避免打到 HTML 页面
  const all = dedupe(
    [...envList, ...tokenList, ...officialHints].map(normalizeEndpointBase).filter(Boolean)
  );

  // 按探活缓存排序：已验证 > 未探 > 已失败
  const probeOrder = { ok: 0, unknown: 1, fail: 2 };
  all.sort((a, b) => {
    const ca = _endpointProbeCache.get(a);
    const cb = _endpointProbeCache.get(b);
    const sa = ca && (Date.now() - ca.at < ENDPOINT_PROBE_CACHE_MS) ? ca.result : 'unknown';
    const sb = cb && (Date.now() - cb.at < ENDPOINT_PROBE_CACHE_MS) ? cb.result : 'unknown';
    return (probeOrder[sa] ?? 1) - (probeOrder[sb] ?? 1);
  });

  return all;
}

/**
 * 判断当前 token 是否来自 Trae CN (国内版)
 * 依据: source 路径含 "Trae CN"、region 含 cn、apiBase 含 cn 域名
 */
function _isTraeCN(tokenData) {
  if (!tokenData) return false;
  const source = String(tokenData.source || tokenData.sourcePath || '').toLowerCase();
  if (source.includes('trae cn')) return true;
  if (source.includes('nirvana')) return true;  // Nirvana 是国内换号工具
  const region = String(tokenData.region || '').toLowerCase();
  if (region.includes('cn') || region.includes('china')) return true;
  const apiBase = String(tokenData.apiBase || tokenData.endpoint || '').toLowerCase();
  if (apiBase.includes('api-cn') || apiBase.includes('trae.cn') || apiBase.includes('adaptive-api')) return true;
  return false;
}

/**
 * 获取 CW 原生端点（区分 CN/国际版）
 */
function _resolveTraeCWEndpoint(tokenData) {
  // 优先使用 token 自带的端点
  const raw = normalizeEndpointBase(tokenData?.apiBase || tokenData?.endpoint);
  if (raw) return raw.replace(/\/v1\/?$/, '');
  // 根据区域选择默认端点
  return _isTraeCN(tokenData)
    ? 'https://adaptive-api.trae.ai'
    : 'https://api-us-east.trae.ai';
}

function parseApiModels(payload = {}) {
  const rows = Array.isArray(payload?.data)
    ? payload.data
    : (Array.isArray(payload?.models) ? payload.models : []);

  const out = [];
  const seen = new Set();
  let defaultModelId = null;

  const push = (id, name, isDefault = false) => {
    const normalized = normalizeModelId(id);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ id: normalized, name: name || modelDisplayName(normalized), isDefault: !!isDefault });
    if (isDefault && !defaultModelId) defaultModelId = normalized;
  };

  for (const row of rows) {
    const id = row?.id || row?.model || row?.modelId;
    const name = row?.name || row?.display_name || row?.displayName || row?.title || id;
    const isDefault = !!(row?.is_default || row?.isDefault || row?.default || row?.selected);
    push(id, name, isDefault);
  }

  if (!defaultModelId && payload?.default_model) {
    const d = normalizeModelId(payload.default_model);
    if (isLikelyModelId(d)) defaultModelId = d;
  }

  return { models: out, defaultModelId };
}

/**
 * 构建 Trae API 请求头 (含 Cookie 注入)
 * @param {object} tokenData - token 对象 (含 accessToken, sessionCookies)
 * @param {object} [extra] - 额外 headers
 * @returns {object}
 */
function buildTraeHeaders(tokenData, extra = {}) {
  const headers = {
    Authorization: `Bearer ${tokenData.accessToken}`,
    'x-api-key': tokenData.accessToken,
    'x-amzn-codewhisperer-optout': 'true',
    ...extra,
  };
  // 注入 session_cookies (Nirvana cache 提供, ~60天有效)
  if (tokenData.sessionCookies && !isCookieExpired(tokenData.cookiesExpireAt)) {
    headers['Cookie'] = tokenData.sessionCookies;
  }
  return headers;
}

function jsonRequest(url, { method = 'GET', headers = {}, body = null, timeout = 12000 } = {}) {
  return requestJson(
    url,
    {
      method,
      timeout,
      headers: sanitizeOutgoingHeaders(headers),
      body,
    },
    {
      namespace: 'trae',
      envKeys: ['TRAE_HTTP_PROXY', 'TRAE_HTTPS_PROXY', 'TRAE_PROXY', 'TRAE_ALL_PROXY'],
      autoEnvKey: 'TRAE_AUTO_PROXY',
      portsEnvKey: 'TRAE_AUTO_PROXY_PORTS',
    }
  );
}

async function fetchModelsFromApi(tokenData, options = {}) {
  const timeoutMs = Math.max(3000, parseInt(options.timeoutMs || '10000', 10) || 10000);
  const bases = resolveTraeApiBases(tokenData);

  if (bases.length === 0) {
    throw new Error('没有可用的 OpenAI 兼容端点 — 未配置 TRAE_API_ENDPOINT 且 token 无 endpoint 字段');
  }

  let lastErr = null;

  for (const base of bases) {
    // 跳过已知失败的端点（避免重复打到 HTML 页面）
    const cached = _endpointProbeCache.get(base);
    if (cached && (Date.now() - cached.at < ENDPOINT_PROBE_CACHE_MS) && cached.result === 'fail') {
      lastErr = lastErr || new Error(`端点 ${base} 已知不可用（探活缓存）`);
      continue;
    }

    const url = buildModelsUrl(base);
    try {
      const res = await jsonRequest(url, {
        method: 'GET',
        timeout: timeoutMs,
        headers: buildTraeHeaders(tokenData, { Accept: 'application/json' }),
      });

      if (res.status === 401 || res.status === 403) {
        const authErr = new Error(`Trae auth failed (${res.status})`);
        authErr.code = 'AUTH';
        throw authErr;
      }

      // 检测 HTML / 非 JSON 响应 — 标记端点为 fail
      const contentType = String(res.headers?.['content-type'] || '').toLowerCase();
      const rawBody = String(res.raw || '').trim();
      if (contentType.includes('text/html') || rawBody.startsWith('<!') || rawBody.startsWith('<html')) {
        _setProbeCache(base, 'fail');
        lastErr = new Error(`端点 ${url} 返回 HTML 而非 JSON — 不是 OpenAI 兼容端点`);
        continue;
      }

      if (res.status < 200 || res.status >= 300) {
        _setProbeCache(base, 'fail');
        lastErr = new Error(`models endpoint ${url} -> HTTP ${res.status}`);
        continue;
      }

      const parsed = parseApiModels(res.data || {});
      if (parsed.models.length > 0) {
        _setProbeCache(base, 'ok');
        return { ...parsed, endpoint: base, mode: 'http' };
      }
      lastErr = new Error(`models endpoint ${url} returned empty model list`);
    } catch (err) {
      if (err && err.code === 'AUTH') throw err;
      lastErr = err instanceof Error ? err : new Error(String(err || 'models endpoint error'));
    }
  }

  if (lastErr) throw lastErr;
  throw new Error('models endpoint unavailable');
}

function extractMessageText(payload = {}) {
  if (typeof payload?.choices?.[0]?.message?.content === 'string') return payload.choices[0].message.content;
  if (typeof payload?.choices?.[0]?.delta?.content === 'string') return payload.choices[0].delta.content;
  if (typeof payload?.output_text === 'string') return payload.output_text;
  if (typeof payload?.content === 'string') return payload.content;
  return '';
}

function consumeSseText(text = '', onChunk = null) {
  const chunks = String(text || '').split(/\r?\n/);
  let full = '';

  for (const lineRaw of chunks) {
    const line = String(lineRaw || '').trim();
    if (!line || !line.startsWith('data:')) continue;
    const data = line.slice(5).trim();
    if (!data || data === '[DONE]') continue;
    try {
      const obj = JSON.parse(data);
      const delta = obj?.choices?.[0]?.delta?.content;
      const textPart = typeof delta === 'string'
        ? delta
        : (typeof obj?.choices?.[0]?.message?.content === 'string' ? obj.choices[0].message.content : '');
      if (!textPart) continue;
      full += textPart;
      if (typeof onChunk === 'function') onChunk({ type: 'text', text: textPart });
    } catch {
      // tolerate non-json SSE lines
    }
  }

  return full;
}

async function readWebReadable(stream) {
  if (!stream) return '';
  if (typeof stream.getReader !== 'function') {
    if (typeof stream.on === 'function') {
      return await new Promise((resolve, reject) => {
        let out = '';
        stream.on('data', (chunk) => { out += String(chunk); });
        stream.on('end', () => resolve(out));
        stream.on('error', reject);
      });
    }
    return '';
  }

  const reader = stream.getReader();
  let out = '';
  const decoder = new TextDecoder();
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    out += decoder.decode(value, { stream: true });
  }
  out += decoder.decode();
  return out;
}

function buildTraeMessages(prompt, options = {}) {
  let messages;
  if (Array.isArray(options.messages) && options.messages.length > 0) {
    messages = options.messages.map((m) => ({
      role: m.role || 'user',
      content: (typeof m.content === 'string' || Array.isArray(m.content))
        ? m.content
        : String(m.content || ''),
    }));
  } else {
    messages = [{ role: 'user', content: String(prompt || '') }];
  }
  return attachImagesToOpenAIMessages(messages, options.images || []);
}

function resolveTraeSdkMode() {
  const mode = String(process.env.TRAE_SDK_MODE || 'auto').trim().toLowerCase();
  if (mode === 'off' || mode === 'disable' || mode === 'disabled') return 'off';
  if (mode === 'force' || mode === 'only') return 'force';
  return 'auto';
}

function resolveTraeInstallPaths() {
  const out = [];
  const envInstall = String(process.env.TRAE_INSTALL_PATH || '').trim();
  if (envInstall) out.push(envInstall);

  try {
    const { findInstallation } = require('./ideDetector');
    const detected = findInstallation('trae');
    if (detected) out.push(detected);
  } catch {
    // ignore detector failure
  }

  return dedupe(out);
}

function resolveTraeSdkModuleCandidates() {
  const out = [];

  for (const item of parseList(process.env.TRAE_SDK_MODULE_PATHS || process.env.TRAE_SDK_MODULE_PATH || '')) {
    out.push(item);
  }

  out.push('@byted-icube/trae-network-client');

  const installs = resolveTraeInstallPaths();
  for (const root of installs) {
    out.push(path.join(root, 'resources', 'app', 'node_modules', '@byted-icube', 'trae-network-client'));
  }

  return dedupe(out);
}

function loadTraeSdkModule() {
  if (_sdkLoadTried) return _sdkModule;
  _sdkLoadTried = true;

  const errors = [];
  for (const candidate of resolveTraeSdkModuleCandidates()) {
    try {
      const mod = require(candidate);
      if (mod && typeof mod.fetch === 'function' && typeof mod.ZmqClient === 'function') {
        _sdkModule = mod;
        _sdkLoadError = null;
        return _sdkModule;
      }
      errors.push(`invalid exports: ${candidate}`);
    } catch (err) {
      errors.push(`${candidate}: ${err && err.message ? err.message : String(err)}`);
    }
  }

  _sdkModule = null;
  _sdkLoadError = errors.join(' | ');
  return null;
}

function resolveTraeSdkEndpoints(tokenData = null) {
  const endpoints = [
    ...parseList(process.env.TRAE_SDK_ENDPOINTS || process.env.TRAE_SDK_ENDPOINT || ''),
    tokenData?.sdkEndpoint || '',
    tokenData?.socketEndpoint || '',
  ];

  // Windows 上 ZMQ 的 IPC transport 不可用（Rust panic 无法被 JS catch 捕获）
  // 仅在非 Windows 或端点不是 ipc:// 时添加默认 IPC 端点
  if (process.platform !== 'win32') {
    endpoints.push('ipc:///tmp/trae.sock');
  }

  const resolved = dedupe(endpoints.map(s => String(s || '').trim()).filter(Boolean));

  // Windows: 过滤所有 ipc:// 端点，避免 Rust ZMQ panic
  if (process.platform === 'win32') {
    return resolved.filter(ep => !ep.startsWith('ipc://'));
  }

  return resolved;
}

function getTraeSdkClient(tokenData = null) {
  const sdk = loadTraeSdkModule();
  if (!sdk) return null;

  const endpoints = resolveTraeSdkEndpoints(tokenData);
  if (_sdkClient && _sdkClientEndpoint && endpoints.includes(_sdkClientEndpoint)) {
    return { sdk, client: _sdkClient, endpoint: _sdkClientEndpoint };
  }

  for (const endpoint of endpoints) {
    try {
      const client = new sdk.ZmqClient(endpoint);
      _sdkClient = client;
      _sdkClientEndpoint = endpoint;
      return { sdk, client, endpoint };
    } catch {
      // try next endpoint
    }
  }

  return null;
}

function mergeAttempts(...groups) {
  const out = [];
  for (const group of groups) {
    for (const item of (group || [])) {
      if (!item || typeof item !== 'object') continue;
      out.push(item);
    }
  }
  return out;
}

// ── Trae 原生协议通道 (x-cloudide-token) ──
// Trae 官方 API 使用 x-cloudide-token 请求头而非 Bearer
// 端点由 iCubeAuthInfo.host 动态拼接（待第三轮调查确认典型值）
// 目前为骨架代码 — host 字段确认后补全

const TRAE_NATIVE_PROTOCOL_TIMEOUT_MS = 120_000;

/**
 * 构建 Trae 原生协议请求头 (x-cloudide-token 而非 Bearer)
 * @param {string} cloudideToken - iCubeAuthInfo 解密后的 token 字段
 * @param {object} [extra] - 额外 headers
 */
function buildNativeProtocolHeaders(cloudideToken, extra = {}) {
  return {
    'Content-Type': 'application/json',
    'x-cloudide-token': cloudideToken,
    ...extra,
  };
}

/**
 * 通过 Trae 原生协议调用 AI API (x-cloudide-token 鉴权)
 *
 * 调用链路:
 *   1. iCubeAuthInfo.host + /generateAssistantResponse (或其他 AI 路径)
 *   2. 请求头: x-cloudide-token: <token>
 *   3. 响应格式: 与 CW 协议类似的 SSE 流
 *
 * 前置条件:
 *   - tokenData 中需要有 nativeToken (iCubeAuthInfo 解密后的 token)
 *   - tokenData 中需要有 nativeHost (iCubeAuthInfo 解密后的 host)
 *   或: 未来通过 sandbox IPC 拦截 / 扩展 API 获取
 *
 * @param {object} tokenData - 含 nativeToken + nativeHost 的 token 对象
 * @param {string} prompt
 * @param {string} model
 * @param {object} [options]
 * @returns {Promise<object>}
 */
async function callTraeByNativeProtocol(tokenData, prompt, model, options = {}) {
  const nativeToken = tokenData?.nativeToken;
  const nativeHost = tokenData?.nativeHost;

  if (!nativeToken || !nativeHost) {
    return {
      success: false,
      content: 'Trae 原生协议需要 nativeToken (iCubeAuthInfo.token) 和 nativeHost (iCubeAuthInfo.host)',
      provider: 'Trae(Native)',
      adapter: 'trae',
      model,
      errorType: 'config',
      attempts: [{ provider: 'Trae(Native)', success: false, error: 'missing_native_credential' }],
    };
  }

  const baseUrl = nativeHost.startsWith('http') ? nativeHost : `https://${nativeHost}`;
  const chatUrl = `${baseUrl.replace(/\/+$/, '')}/generateAssistantResponse`;
  const onChunk = options.onChunk || (() => {});

  const messages = buildTraeMessages(prompt, options);
  const payload = {
    model,
    messages,
    stream: true,
  };

  try {
    const res = await jsonRequest(chatUrl, {
      method: 'POST',
      timeout: TRAE_NATIVE_PROTOCOL_TIMEOUT_MS,
      headers: sanitizeOutgoingHeaders(buildNativeProtocolHeaders(nativeToken, {
        Accept: 'text/event-stream',
      })),
      body: payload,
    });

    // HTML / 非 JSON 检测
    const contentType = String(res.headers?.['content-type'] || '').toLowerCase();
    const rawText = String(res.raw || '').trim();
    if (contentType.includes('text/html') || rawText.startsWith('<!') || rawText.startsWith('<html')) {
      return {
        success: false,
        content: `${chatUrl} 返回 HTML（非 API 端点）`,
        provider: 'Trae(Native)',
        adapter: 'trae',
        model,
        errorType: 'protocol',
        attempts: [{ provider: 'Trae(Native)', success: false, error: 'html_response' }],
      };
    }

    if (res.status === 401 || res.status === 403) {
      return {
        success: false,
        content: `Trae 原生协议鉴权失败 (${res.status})`,
        provider: 'Trae(Native)',
        adapter: 'trae',
        model,
        errorType: 'auth',
        attempts: [{ provider: 'Trae(Native)', success: false, error: `auth_${res.status}` }],
      };
    }

    // SSE 流解析
    const content = consumeSseText(rawText, onChunk).trim();
    if (content) {
      _setProbeCache(baseUrl, 'ok');
      return {
        success: true,
        content,
        provider: `Trae Native (${model}@${nativeHost})`,
        adapter: 'trae',
        model,
        attempts: [{ provider: 'Trae(Native)', success: true }],
      };
    }

    // 非流式 JSON 兜底
    const json = res.data || {};
    const text = extractMessageText(json).trim();
    if (text) {
      _setProbeCache(baseUrl, 'ok');
      return {
        success: true,
        content: text,
        provider: `Trae Native (${model}@${nativeHost})`,
        adapter: 'trae',
        model,
        attempts: [{ provider: 'Trae(Native)', success: true }],
      };
    }

    return {
      success: false,
      content: json.error?.message || 'empty response from native protocol',
      provider: 'Trae(Native)',
      adapter: 'trae',
      model,
      errorType: 'empty',
      attempts: [{ provider: 'Trae(Native)', success: false, error: 'empty_response' }],
    };
  } catch (err) {
    return {
      success: false,
      content: err?.message || String(err),
      provider: 'Trae(Native)',
      adapter: 'trae',
      model,
      errorType: 'network',
      attempts: [{ provider: 'Trae(Native)', success: false, error: err?.message || String(err) }],
    };
  }
}

// ── CodeWhisperer 协议通道 (复用 Kiro 的 SDK 客户端) ──
// Trae 原生 AI API 使用和 Kiro 相同的 GenerateAssistantResponse 协议
// 端点: api-us-east.trae.ai/generateAssistantResponse
// 需要 Cookie + Bearer Token 双重认证

let _cwModule = null;
let _traeCWClient = null;
let _traeCWClientKey = '';

const TRAE_CW_TIMEOUT_MS = 120_000;

async function _getCWModule() {
  if (_cwModule) return _cwModule;
  _cwModule = await import('@aws/codewhisperer-streaming-client');
  return _cwModule;
}

function _convertMessagesToConversation(messages, { modelId, system } = {}) {
  const history = [];
  const buildCtx = (extra = {}) => ({ modelId: modelId || undefined, editorState: {}, ...extra });

  if (system) {
    const sysText = typeof system === 'string' ? system : '';
    if (sysText) {
      history.push({ userInputMessage: { content: sysText, origin: 'AI_EDITOR', userInputMessageContext: buildCtx() } });
      history.push({ assistantResponseMessage: { content: 'OK' } });
    }
  }

  for (const msg of messages) {
    if (msg.role === 'user') {
      history.push({ userInputMessage: { content: typeof msg.content === 'string' ? msg.content : '', origin: 'AI_EDITOR', userInputMessageContext: buildCtx() } });
    } else if (msg.role === 'assistant') {
      history.push({ assistantResponseMessage: { content: typeof msg.content === 'string' ? msg.content : '' } });
    }
  }

  const last = history.at(-1);
  if (last?.assistantResponseMessage) {
    history.push({ userInputMessage: { content: 'Continue.', origin: 'AI_EDITOR', userInputMessageContext: buildCtx() } });
  }

  return {
    conversationId: crypto.randomUUID(),
    currentMessage: history.at(-1),
    history: history.slice(0, -1),
    chatTriggerType: 'MANUAL',
  };
}

/**
 * 创建 Trae 的 CodeWhispererStreaming 客户端
 * 接受显式 endpoint 参数，每个端点创建独立客户端
 */
async function _createTraeCWClient(tokenData, explicitEndpoint = null) {
  const bareEndpoint = explicitEndpoint || _resolveTraeCWEndpoint(tokenData);
  const clientKey = `${tokenData.accessToken}:${bareEndpoint}`;
  if (_traeCWClient && _traeCWClientKey === clientKey) return _traeCWClient;

  const { CodeWhispererStreaming } = await _getCWModule();

  const clientOpts = {
    region: 'us-east-1',
    endpoint: bareEndpoint,
    token: { token: tokenData.accessToken },
    customUserAgent: 'KiroIDE 0.11.107',
  };

  // 国际版 CW 端点需要走代理 (与 kiroAdapter 相同模式)
  if (!_isTraeCN(tokenData)) {
    const proxyCandidates = collectProxyCandidates({
      namespace: 'trae',
      envKeys: ['TRAE_HTTP_PROXY', 'TRAE_HTTPS_PROXY'],
    });
    const proxyUrl = proxyCandidates[0] || '';
    if (proxyUrl) {
      try {
        const { HttpsProxyAgent } = require('https-proxy-agent');
        const proxyAgent = new HttpsProxyAgent(proxyUrl);
        const { NodeHttpHandler } = await import('@smithy/node-http-handler');
        clientOpts.requestHandler = new NodeHttpHandler({ httpsAgent: proxyAgent });
      } catch {
        // https-proxy-agent 或 @smithy/node-http-handler 不可用，SDK 使用默认 handler
      }
    }
  }

  const client = new CodeWhispererStreaming(clientOpts);

  // Middleware: 注入必须的 headers
  client.middlewareStack.add(
    (next) => async (args) => {
      args.request.headers = sanitizeOutgoingHeaders({
        ...args.request.headers,
        'x-amzn-codewhisperer-optout': 'true',
        'x-amzn-kiro-agent-mode': 'vibe',
      });
      return next(args);
    },
    { step: 'build', name: 'traeOptOutHeader' }
  );

  // Middleware: 注入 Cookie (Trae 登录态复用核心)
  if (tokenData.sessionCookies && !isCookieExpired(tokenData.cookiesExpireAt)) {
    client.middlewareStack.add(
      (next) => async (args) => {
        args.request.headers = {
          ...args.request.headers,
          'Cookie': tokenData.sessionCookies,
        };
        return next(args);
      },
      { step: 'build', name: 'traeCookieHeader' }
    );
  }

  _traeCWClient = client;
  _traeCWClientKey = clientKey;
  return client;
}

/**
 * 通过 CodeWhisperer 协议调用 Trae 原生 AI API
 * 这是与 Kiro 相同的协议, 支持 Claude/GPT 等模型
 */
async function callTraeByCodeWhisperer(tokenData, prompt, model, options = {}) {
  // accessToken 是必须的; sessionCookies 可选增强
  if (!tokenData.accessToken) {
    return { success: false, content: 'Trae CodeWhisperer 通道需要 accessToken', errorType: 'auth', attempts: [] };
  }

  // 多端点级联: 优先 token 自带端点, 然后 CN / 国际版候选
  const cwEndpoints = _resolveTraeCWEndpoints(tokenData);
  const allAttempts = [];

  for (const endpoint of cwEndpoints) {
    let client;
    try {
      client = await _createTraeCWClient(tokenData, endpoint);
    } catch (err) {
      allAttempts.push({ provider: `Trae(CW:${endpoint})`, success: false, error: `sdk_load: ${err.message}` });
      continue;
    }

    try {
      const { GenerateAssistantResponseCommand } = await _getCWModule();

      let messages;
      if (options.messages && options.messages.length > 0) {
        messages = options.messages;
      } else {
        messages = [{ role: 'user', content: String(prompt || '') }];
      }

      const conversationState = _convertMessagesToConversation(messages, {
        modelId: model,
        system: options.system,
      });

      const command = new GenerateAssistantResponseCommand({ conversationState });

      const response = await Promise.race([
        client.send(command),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`CW timeout (${TRAE_CW_TIMEOUT_MS / 1000}s)`)), TRAE_CW_TIMEOUT_MS)
        ),
      ]);

      if (!response.generateAssistantResponseResponse) {
        throw new Error('Empty response from Trae CodeWhisperer');
      }

      let content = '';
      let usedModelId = null;
      const onChunk = options.onChunk || (() => {});

      try {
        for await (const event of response.generateAssistantResponseResponse) {
          if (event.assistantResponseEvent?.content) {
            const text = event.assistantResponseEvent.content;
            content += text;
            if (event.assistantResponseEvent.modelId) usedModelId = event.assistantResponseEvent.modelId;
            onChunk({ type: 'text', text });
          }
          if (event.reasoningContentEvent?.text) {
            onChunk({ type: 'thinking', text: event.reasoningContentEvent.text });
          }
          if (event.invalidStateEvent) {
            throw new Error(`CW error: ${event.invalidStateEvent.reason || 'unknown'} — ${event.invalidStateEvent.message || ''}`);
          }
        }
      } catch (streamErr) {
        if (content.trim()) {
          _setProbeCache(endpoint, 'ok');
          return {
            success: true,
            content: content.trim(),
            provider: `Trae CW (${usedModelId || model}@${endpoint})`,
            adapter: 'trae',
            model: usedModelId || model,
            attempts: mergeAttempts(allAttempts, [{ provider: `Trae(CW:${endpoint})`, success: true, warning: 'stream_interrupted' }]),
            _cwEndpointVerified: endpoint,
          };
        }
        throw streamErr;
      }

      _setProbeCache(endpoint, 'ok');
      return {
        success: true,
        content: content.trim(),
        provider: `Trae CW (${usedModelId || model}@${endpoint})`,
        adapter: 'trae',
        model: usedModelId || model,
        attempts: mergeAttempts(allAttempts, [{ provider: `Trae(CW:${endpoint})`, success: true }]),
        _cwEndpointVerified: endpoint,
      };
    } catch (err) {
      // 重置客户端缓存
      _traeCWClient = null;
      _traeCWClientKey = '';
      const errMsg = err.message || String(err);
      allAttempts.push({ provider: `Trae(CW:${endpoint})`, success: false, error: errMsg });
      // 将失败的 CW 端点写入探活缓存，避免后续重复超时
      _setProbeCache(endpoint, 'fail');
      // HTML 响应 / 网络错误 → 继续尝试下一个端点
      continue;
    }
  }

  return {
    success: false,
    content: allAttempts[allAttempts.length - 1]?.error || 'All CW endpoints failed',
    provider: 'Trae',
    adapter: 'trae',
    model,
    errorType: 'network',
    attempts: allAttempts,
  };
}

/**
 * 返回多个 CW 候选端点（按优先级排序）
 * CN 用户优先试 CN 端点，国际用户优先试 US 端点
 * 集成 _endpointProbeCache：已验证 > 未知 > 已失败，跳过已知失败的端点
 */
function _resolveTraeCWEndpoints(tokenData) {
  const endpoints = [];
  const seen = new Set();
  const add = (url) => {
    if (!url) return;
    const normalized = url.replace(/\/v1\/?$/, '').replace(/\/+$/, '');
    if (seen.has(normalized)) return;
    seen.add(normalized);
    endpoints.push(normalized);
  };

  // 1) token 自带端点（最可靠）
  add(normalizeEndpointBase(tokenData?.apiBase));
  add(normalizeEndpointBase(tokenData?.endpoint));
  add(normalizeEndpointBase(tokenData?.host));

  // 2) 根据 CN/国际版选择候选顺序
  //    注意: grow-*/core-* 主机来自 Windows 端运行日志 + product.json ugApi 确认
  if (_isTraeCN(tokenData)) {
    add('https://adaptive-api.trae.ai');
    add('https://grow-normal.trae.ai');
    add('https://core-normal.trae.ai');
    add('https://growsg-normal.trae.ai');
    add('https://api-us-east.trae.ai');
    add('https://api-ap.trae.ai');
  } else {
    add('https://api-us-east.trae.ai');
    add('https://growva-normal.trae.ai');
    add('https://grow-normal.traeapi.us');
    add('https://adaptive-api.trae.ai');
    add('https://grow-normal.trae.ai');
    add('https://growsg-normal.trae.ai');
    add('https://core-normal.trae.ai');
    add('https://api-eu-west.trae.ai');
    add('https://api-ap.trae.ai');
  }

  // 3) 按探活缓存排序：已验证 > 未知 > 已失败
  const probeOrder = { ok: 0, unknown: 1, fail: 2 };
  endpoints.sort((a, b) => {
    const ca = _endpointProbeCache.get(a);
    const cb = _endpointProbeCache.get(b);
    const sa = ca && (Date.now() - ca.at < ENDPOINT_PROBE_CACHE_MS) ? ca.result : 'unknown';
    const sb = cb && (Date.now() - cb.at < ENDPOINT_PROBE_CACHE_MS) ? cb.result : 'unknown';
    return (probeOrder[sa] ?? 1) - (probeOrder[sb] ?? 1);
  });

  // 4) 过滤掉已知失败的端点（只保留 ok/unknown）
  return endpoints.filter(ep => {
    const cached = _endpointProbeCache.get(ep);
    if (!cached || (Date.now() - cached.at >= ENDPOINT_PROBE_CACHE_MS)) return true; // 未缓存或已过期 → 保留
    return cached.result !== 'fail';
  });
}

/**
 * 通过 Trae 原生 API 获取模型列表 (ListAvailableModels)
 * 端点: GET /ListAvailableModels?origin=AI_EDITOR
 * 多端点级联尝试 — 不再只试一个
 */
async function fetchModelsFromNativeApi(tokenData, options = {}) {
  if (!tokenData.accessToken) return null;

  const timeoutMs = Math.max(3000, parseInt(options.timeoutMs || '12000', 10) || 12000);
  const cwEndpoints = _resolveTraeCWEndpoints(tokenData);
  if (cwEndpoints.length === 0) return null;

  for (const bareBase of cwEndpoints.slice(0, 4)) {
    const url = `${bareBase}/ListAvailableModels?origin=AI_EDITOR`;
    try {
      const res = await jsonRequest(url, {
        method: 'GET',
        timeout: timeoutMs,
        headers: buildTraeHeaders(tokenData, {
          Accept: 'application/json',
          'User-Agent': 'KiroIDE 0.11.107',
        }),
      });

      if (res.status !== 200) continue;

      // 检测 HTML / 非 JSON 响应 → 跳过
      const contentType = String(res.headers?.['content-type'] || '').toLowerCase();
      const rawText = String(res.raw || '').trim();
      if (contentType.includes('text/html') || rawText.startsWith('<!') || rawText.startsWith('<html')) {
        _setProbeCache(bareBase, 'fail');
        continue;
      }

      const data = res.data || {};
      const rawModels = Array.isArray(data.models) ? data.models : [];
      if (rawModels.length === 0) continue;

      const models = rawModels.map(m => ({
        id: m.modelId || m.id || '',
        name: m.modelName || m.name || m.modelId || '',
      })).filter(m => m.id);

      const defaultModelId = data.defaultModel?.modelId || null;
      _setProbeCache(bareBase, 'ok');
      return { models, defaultModelId, endpoint: bareBase, mode: 'native' };
    } catch {
      // 尝试下一个端点
    }
  }

  return null;
}

async function callTraeBySdk(tokenData, prompt, model, options = {}) {
  const sdkCtx = getTraeSdkClient(tokenData);
  if (!sdkCtx) {
    return {
      success: false,
      content: _sdkLoadError ? `Trae SDK unavailable: ${_sdkLoadError}` : 'Trae SDK unavailable',
      provider: 'Trae',
      adapter: 'trae',
      model,
      errorType: 'unavailable',
      attempts: [{ provider: 'Trae(SDK)', success: false, error: 'sdk_unavailable' }],
    };
  }

  const { sdk, client, endpoint: sdkEndpoint } = sdkCtx;
  const useStream = options.stream === true || typeof options.onChunk === 'function';
  const payload = {
    model,
    messages: buildTraeMessages(prompt, options),
    stream: useStream,
    max_tokens: options.maxTokens || 2048,
    temperature: options.temperature || 0.4,
  };

  const attempts = [];
  for (const base of resolveTraeApiBases(tokenData)) {
    const url = buildChatUrl(base);
    try {
      const res = await sdk.fetch(client, url, {
        method: 'POST',
        headers: sanitizeOutgoingHeaders(buildTraeHeaders(tokenData, {
          'Content-Type': 'application/json',
        })),
        body: JSON.stringify(payload),
      });

      const statusCode = Number(res.status || 0);
      if (statusCode === 401 || statusCode === 403) {
        return {
          success: false,
          content: `Trae SDK auth failed (${statusCode})`,
          provider: 'Trae',
          adapter: 'trae',
          model,
          errorType: 'auth',
          statusCode,
          attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: `auth failed (${statusCode})`, statusCode }]),
        };
      }

      const contentType = String(res.headers?.get?.('content-type') || '').toLowerCase();
      if (useStream || contentType.includes('text/event-stream')) {
        const sseRaw = await readWebReadable(res.body);
        const content = consumeSseText(sseRaw, options.onChunk).trim();
        if (content) {
          return {
            success: true,
            content,
            provider: `Trae SDK (${model})`,
            adapter: 'trae',
            model,
            attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: true }]),
          };
        }
        attempts.push({ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: `empty stream from ${url}` });
        continue;
      }

      const bodyText = await res.text();
      let json = null;
      try { json = JSON.parse(bodyText); } catch {
        json = null;
      }

      const text = extractMessageText(json || {}).trim();
      if (text) {
        return {
          success: true,
          content: text,
          provider: `Trae SDK (${model})`,
          adapter: 'trae',
          model,
          attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: true }]),
        };
      }

      attempts.push({
        provider: `Trae(SDK:${sdkEndpoint})`,
        success: false,
        error: json?.error?.message || `invalid response (${statusCode})`,
        statusCode,
      });
    } catch (err) {
      attempts.push({ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: err?.message || String(err) });
    }
  }

  return {
    success: false,
    content: attempts[attempts.length - 1]?.error || 'Trae SDK request failed',
    provider: 'Trae',
    adapter: 'trae',
    model,
    errorType: 'network',
    attempts,
  };
}

function callTraeByHttp(tokenData, prompt, model, options = {}) {
  const useStream = options.stream === true || typeof options.onChunk === 'function';
  const payload = {
    model,
    messages: buildTraeMessages(prompt, options),
    stream: useStream,
    max_tokens: options.maxTokens || 2048,
    temperature: options.temperature || 0.4,
  };

  const bases = resolveTraeApiBases(tokenData);
  const attempts = [];

  const runOne = (baseIndex) => {
    if (baseIndex >= bases.length) {
      return Promise.resolve({
        success: false,
        content: attempts[attempts.length - 1]?.error || 'Trae HTTP request failed',
        provider: 'Trae',
        adapter: 'trae',
        model,
        errorType: 'network',
        attempts,
      });
    }

    const base = bases[baseIndex];
    const endpoint = buildChatUrl(base);
    return jsonRequest(endpoint, {
      method: 'POST',
      timeout: TIMEOUT_MS,
      headers: buildTraeHeaders(tokenData, { 'Content-Type': 'application/json' }),
      body: payload,
    }).then(async (res) => {
      const statusCode = Number(res.status || 0);
      if (statusCode === 401 || statusCode === 403) {
        return {
          success: false,
          content: `Trae auth failed (${statusCode})`,
          provider: 'Trae',
          adapter: 'trae',
          model,
          errorType: 'auth',
          statusCode,
          attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: false, error: `auth failed (${statusCode})`, statusCode }]),
        };
      }
      if (statusCode < 200 || statusCode >= 300) {
        _setProbeCache(base, 'fail');
        attempts.push({ provider: 'Trae(HTTP)', success: false, error: `HTTP ${statusCode}`, statusCode });
        return runOne(baseIndex + 1);
      }

      // 检测 HTML / 非 JSON 响应 → 标记端点失败，尝试下一个
      const contentType = String(res.headers?.['content-type'] || '').toLowerCase();
      const rawText = String(res.raw || '').trim();
      if (contentType.includes('text/html') || rawText.startsWith('<!') || rawText.startsWith('<html')) {
        _setProbeCache(base, 'fail');
        attempts.push({ provider: 'Trae(HTTP)', success: false, error: `${base} 返回 HTML（非 OpenAI 端点）` });
        return runOne(baseIndex + 1);
      }

      const streamLike = useStream || contentType.includes('text/event-stream');
      const dataText = rawText;

      if (streamLike) {
        const streamedText = consumeSseText(dataText, options.onChunk).trim();
        if (streamedText) {
          return {
            success: true,
            content: streamedText,
            provider: `Trae (${model})`,
            adapter: 'trae',
            model,
            attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: true }]),
          };
        }
      }

      const json = res.data || {};
      const text = extractMessageText(json).trim();
      if (text) {
        return {
          success: true,
          content: text,
          provider: `Trae (${model})`,
          adapter: 'trae',
          model,
          attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: true }]),
        };
      }

      const errorText = json.error?.message || `invalid response (${statusCode})`;
      attempts.push({ provider: 'Trae(HTTP)', success: false, error: errorText, statusCode });
      return runOne(baseIndex + 1);
    }).catch(async (err) => {
      attempts.push({ provider: 'Trae(HTTP)', success: false, error: err?.message || String(err) });
      return runOne(baseIndex + 1);
    });
  };

  return runOne(0);
}

function detect(forceRefresh = false) {
  if (_detectionState._checked && !forceRefresh) return _detectionState.available;

  // 1) 安装检测
  _detectionState.installDetected = detectInstallation();

  // 2) 读取 token — 内部已更新 _detectionState 的 officialArtifactsDetected / credentialMode / officialArtifactSources
  const localToken = readTraeToken();

  // 3) 如果 readTraeToken 还没做官方扫描（比如直接从旧 storage.json 拿到 token），补扫
  if (!_detectionState.officialArtifactsDetected && !_detectionState._officialCredential) {
    const officialCred = resolveTraeOfficialCredential();
    _detectionState._officialCredential = officialCred;
    _detectionState.officialArtifactsDetected = officialCred.officialArtifactsDetected;
    _detectionState.officialArtifactSources = officialCred.sourcePaths || [];
    if (_detectionState.credentialMode === 'none' && officialCred.credentialMode !== 'none') {
      _detectionState.credentialMode = officialCred.credentialMode;
    }
  }

  // 4) 设置 token
  if (localToken) {
    _token = localToken;
    persistObservedToken(localToken);
  } else if (!(_token && _token.accessToken && String(_token.source || '').startsWith('pool:'))) {
    _token = null;
  }

  // 5) available = 有可用明文 token/cookie（但不再是最终状态 — detectAsync 会做探活验证）
  _detectionState.available = !!(_token && isLikelyCredentialToken(_token.accessToken));
  if (!_detectionState.available) _models = [];
  _detectionState._checked = true;
  return _detectionState.available;
}

async function detectAsync(forceRefresh = false) {
  let ok = detect(forceRefresh);
  const selected = await selectToken({ allowExpired: false });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _detectionState.available = true;
    ok = true;
    persistObservedToken(_token);
  }

  // 官方凭据验证（仅当有 officialCredential 且有 token 时）
  if (!ok && _detectionState._officialCredential) {
    const cred = _detectionState._officialCredential;
    if (cred.token) {
      // 有明文 token → 构建 tokenData 并验证
      // nativeHost: 优先 cred 自带的 host，否则根据 regionHint 推断
      const nativeHost = cred.nativeHost
        || resolveNativeHostByRegion(cred.regionHint);
      _token = {
        accessToken: normalizeToken(cred.token),
        refreshToken: null,
        source: 'official-trae',
        path: (cred.sourcePaths || [])[0] || null,
        endpoint: normalizeEndpointBase(cred.endpoint || ''),
        sdkEndpoint: null,
        expiresAt: null,
        sessionCookies: null,
        cookiesExpireAt: null,
        // 原生协议字段 — 供 callTraeByNativeProtocol 使用
        nativeToken: cred.token,
        nativeHost,
      };
      _detectionState.credentialMode = 'plaintext';
      _detectionState.available = true;
      ok = true;
      persistObservedToken(_token);
    }
  }

  // 官方凭据精确验证 — 优先用 verifyTraeOfficialSession 替代通用 probeEndpoint
  if (_detectionState._officialCredential) {
    const cred = _detectionState._officialCredential;
    try {
      const verification = await verifyTraeOfficialSession(cred, requestJson);
      if (verification.sessionVerified) {
        _detectionState.sessionVerified = true;
        if (verification.verifiedEndpoint) {
          _setProbeCache(verification.verifiedEndpoint, 'ok');
        }
      }
    } catch { /* 验证失败不阻塞 */ }
  }

  // 端点探活：有 token 但 session 尚未验证时，用通用 probeEndpoint 兜底
  if (ok && _token && _token.accessToken && !_detectionState.sessionVerified) {
    try {
      const bases = resolveTraeApiBases(_token);
      // 只探活已知 OpenAI 兼容的端点（跳过空列表）
      for (const base of bases.slice(0, 3)) {
        const status = await probeEndpoint(base, _token.accessToken);
        if (status === 'ok') {
          _detectionState.sessionVerified = true;
          break;
        }
      }
    } catch { /* 探活失败不影响检测结果 */ }
  }

  return ok;
}

async function listModels() {
  detect(true);
  const selected = await selectToken({ allowExpired: true });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _detectionState.available = true;
    persistObservedToken(_token);
  }

  if (!_token || !_token.accessToken) {
    // No token — still return known + injected models so users can see what's
    // available (generate() will report auth errors at call time).
    const fallback = KNOWN_MODELS.map(m => ({
      id: m.id,
      name: m.name,
      isDefault: !!m.isDefault,
      provider: 'trae',
      description: 'No Trae token — login in Trae IDE to use this model.',
      discoverySource: 'builtin',
    }));
    if (TRAE_INJECT_MODELS) {
      const existingIds = new Set(fallback.map(m => canonicalModelKey(m.id)));
      for (const im of TRAE_INJECTED_MODELS) {
        if (existingIds.has(canonicalModelKey(im.id))) continue;
        fallback.push({
          id: im.id,
          name: im.name,
          isDefault: false,
          provider: 'trae',
          description: 'No Trae token — login in Trae IDE to use this model.',
          discoverySource: 'injected',
        });
      }
    }
    _models = fallback;
    _detectionState.available = false;
    return _models;
  }

  if (_models.length > 0 && (Date.now() - _modelsFetchedAt) < MODEL_DISCOVERY_CACHE_MS) {
    return _models;
  }

  const snapshots = readTraeStorageSnapshots();
  const discovered = discoverModelsFromSnapshots(snapshots);
  const localModelIds = discovered.discoveredModelIds || [];
  let apiModels = [];
  let apiDefault = null;
  let officialHit = false;
  let officialEndpoint = '';
  let apiError = '';

  if (_token && _token.accessToken && !isTokenExpired(_token)) {
    // 优先尝试 Trae 原生 API (/ListAvailableModels) — 有无 Cookie 都可尝试
    // Cookie 增强成功率，但 accessToken 单独也可能有效
    try {
      const nativeApi = await fetchModelsFromNativeApi(_token);
      if (nativeApi && nativeApi.models && nativeApi.models.length > 0) {
        apiModels = nativeApi.models.map(m => m.id || m.modelId);
        apiDefault = nativeApi.defaultModelId || null;
        officialEndpoint = nativeApi.endpoint || '';
        officialHit = true;
      }
    } catch (_nativeErr) {
      // 原生 API 失败不阻塞，fallback 到 OpenAI 格式
    }

    // OpenAI 格式 API 兜底
    if (!officialHit) {
      try {
        const api = await fetchModelsFromApi(_token);
        apiModels = (api.models || []).map(m => m.id);
        apiDefault = api.defaultModelId || null;
        officialEndpoint = api.endpoint || '';
        officialHit = apiModels.length > 0;
      } catch (err) {
        apiError = err?.message || String(err);
        if (err && err.code === 'AUTH' && selected.fallback && selected.fallback.accessToken && !isTokenExpired(selected.fallback)) {
          _token = selected.fallback;
          persistObservedToken(_token);
          try {
            const retry = await fetchModelsFromApi(_token);
            apiModels = (retry.models || []).map(m => m.id);
            apiDefault = retry.defaultModelId || null;
            officialEndpoint = retry.endpoint || '';
            officialHit = apiModels.length > 0;
            apiError = '';
          } catch (retryErr) {
            apiError = retryErr?.message || apiError;
            if (retryErr && retryErr.code === 'AUTH') {
              _detectionState.available = false;
              _models = [];
              _modelsFetchedAt = Date.now();
              _lastApiMeta = {
                at: Date.now(),
                endpoint: '',
                officialHit: false,
                officialCount: 0,
                localCount: localModelIds.length,
                mergedCount: 0,
                error: apiError,
                mode: 'http',
              };
              return [];
            }
          }
        } else if (err && err.code === 'AUTH') {
          _detectionState.available = false;
          _models = [];
          _modelsFetchedAt = Date.now();
          _lastApiMeta = {
            at: Date.now(),
            endpoint: '',
            officialHit: false,
            officialCount: 0,
            localCount: localModelIds.length,
            mergedCount: 0,
            error: apiError,
            mode: 'http',
          };
          return [];
        }
      }
    }
  }

  const merged = buildModelList(
    [...apiModels, ...localModelIds],
    apiDefault || discovered.defaultModelId,
    { apiModelIds: apiModels, localModelIds }
  );

  _models = merged.map(m => ({ ...m, provider: 'trae', description: '' }));

  // Inject models that Trae IDE shows but API omits (same pattern as Kiro).
  if (TRAE_INJECT_MODELS) {
    const existingIds = new Set(_models.map(m => canonicalModelKey(m.id)));
    for (const im of TRAE_INJECTED_MODELS) {
      if (existingIds.has(canonicalModelKey(im.id))) continue;
      _models.push({
        id: im.id,
        name: im.name,
        isDefault: false,
        provider: 'trae',
        description: 'Injected — Trae IDE shows this model but API may not list it.',
        discoverySource: 'injected',
      });
    }
  }

  _detectionState.available = true;
  _modelsFetchedAt = Date.now();
  _lastApiMeta = {
    at: Date.now(),
    endpoint: officialEndpoint,
    officialHit,
    officialCount: apiModels.length,
    localCount: localModelIds.length,
    mergedCount: _models.length,
    error: apiError,
    mode: 'http',
  };

  return _models;
}

function getStatus() {
  detect(true);
  const modelCount = _models.length || KNOWN_MODELS.length;
  const sdk = loadTraeSdkModule();
  const hasCookie = !!(_token?.sessionCookies && !isCookieExpired(_token?.cookiesExpireAt));

  // 五级中文状态描述
  let detail = '';
  let statusLevel = 'unknown'; // 'verified' | 'pending' | 'encrypted' | 'installed' | 'missing'

  if (_detectionState.available && _detectionState.sessionVerified) {
    statusLevel = 'verified';
    const cookieSuffix = hasCookie ? ' + Cookie' : '';
    detail = `Token 有效，已验证${cookieSuffix} (${modelCount} 个模型)`;
  } else if (_detectionState.available) {
    statusLevel = 'pending';
    const cookieSuffix = hasCookie ? ' + Cookie' : '';
    detail = `Token 检测到，待验证${cookieSuffix} (${modelCount} 个模型)`;
  } else if (_detectionState.officialArtifactsDetected && _detectionState.credentialMode === 'encrypted') {
    statusLevel = 'encrypted';
    // 显示加密方案详情
    const blobAnalysis = _detectionState._officialCredential?.authBlobAnalysis;
    const scheme = blobAnalysis?.schemeHint || 'unknown';
    const schemeDesc = scheme === 'trae-custom-encrypted'
      ? 'Electron safeStorage 加密'
      : scheme === 'dpapi' ? 'Windows DPAPI 加密'
      : scheme.startsWith('chromium-safe-storage') ? `Chromium ${scheme.split('-').pop()} 加密`
      : '加密格式未知';
    const bridgeHint = _detectionState._officialCredential?.bridgeStale
      ? '（桥接 token 已过期，请在 Trae 中刷新）'
      : '（安装 khy-trae-bridge 扩展可自动提取 token）';
    detail = `Trae 已登录，检测到加密登录态（${schemeDesc}）${bridgeHint}`;
  } else if (_detectionState.installDetected) {
    statusLevel = 'installed';
    detail = 'Trae 已安装，未检测到登录态 — 请先登录 Trae IDE';
  } else {
    statusLevel = 'missing';
    detail = '未检测到 Trae 安装';
  }

  // 端点状态统计
  const endpointBases = _token ? resolveTraeApiBases(_token) : [];
  const endpointStatus = endpointBases.map(ep => {
    const cached = _endpointProbeCache.get(ep);
    const probeResult = cached && (Date.now() - cached.at < ENDPOINT_PROBE_CACHE_MS) ? cached.result : 'untested';
    return { endpoint: ep, status: probeResult };
  });

  // 官方 artifact 分析摘要
  const officialCred = _detectionState._officialCredential;
  const officialArtifacts = officialCred ? {
    detected: officialCred.officialArtifactsDetected,
    sources: officialCred.sourcePaths || [],
    authBlobPresent: officialCred.authBlobPresent || false,
    userTagBlobPresent: officialCred.userTagBlobPresent || false,
    serverDataPresent: officialCred.serverDataPresent || false,
    regionHint: officialCred.regionHint || null,
    userIdHint: officialCred.userIdHint || null,
    endpointHints: officialCred.endpointHints || [],
    credentialMode: officialCred.credentialMode || 'none',
    authBlobAnalysis: officialCred.authBlobAnalysis || null,
    nativeHost: officialCred.nativeHost || null,
    bridgePath: officialCred.bridgePath || null,
    bridgeStale: officialCred.bridgeStale || false,
  } : null;

  return {
    name: 'Trae IDE',
    type: 'trae',
    available: _detectionState.available,
    statusLevel,
    detail,
    // 完整结构化检测状态
    installDetected: _detectionState.installDetected,
    officialArtifactsDetected: _detectionState.officialArtifactsDetected,
    officialArtifactSources: _detectionState.officialArtifactSources,
    credentialMode: _detectionState.credentialMode,
    sessionVerified: _detectionState.sessionVerified,
    // token 信息
    tokenPath: _token?.path || '',
    tokenSource: _token?.source || '',
    hasCookie,
    cookiesExpireAt: _token?.cookiesExpireAt || null,
    // 官方 artifact 分析
    officialArtifacts,
    // 端点状态
    endpoints: endpointStatus,
    // SDK 信息
    sdk: {
      available: !!sdk,
      endpoint: _sdkClientEndpoint || '',
      error: sdk ? '' : (_sdkLoadError || ''),
      mode: resolveTraeSdkMode(),
    },
    // 模型发现
    officialModels: {
      hit: !!_lastApiMeta.officialHit,
      endpoint: _lastApiMeta.endpoint || '',
      officialCount: _lastApiMeta.officialCount || 0,
      localCount: _lastApiMeta.localCount || 0,
      mergedCount: _lastApiMeta.mergedCount || modelCount,
      error: _lastApiMeta.error || '',
      at: _lastApiMeta.at || 0,
      mode: _lastApiMeta.mode || 'http',
    },
    refreshModels: listModels,
  };
}

async function generate(prompt, options = {}) {
  const selected = await selectToken({ allowExpired: true });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _detectionState.available = true;
    persistObservedToken(_token);
  }

  if (!_token || !_token.accessToken) {
    return {
      success: false,
      content: 'Trae token not found',
      provider: 'Trae',
      adapter: 'trae',
      attempts: [{ provider: 'Trae', success: false, error: 'No token' }],
    };
  }

  if (!isLikelyCredentialToken(_token.accessToken)) {
    return {
      success: false,
      content: 'Trae token invalid — please refresh account pool/import data',
      provider: 'Trae',
      adapter: 'trae',
      errorType: 'auth',
      attempts: [{ provider: 'Trae', success: false, error: 'invalid token shape' }],
    };
  }

  if (isTokenExpired(_token)) {
    return {
      success: false,
      content: 'Trae token expired — please re-login in Trae IDE',
      provider: 'Trae',
      adapter: 'trae',
      errorType: 'auth',
      attempts: [{ provider: 'Trae', success: false, error: 'token expired' }],
    };
  }

  const defaultModel = (_models.find(m => m.isDefault) || _models[0] || {}).id || 'doubao-1.5-pro';
  const model = options.model || defaultModel;

  // ---- 策略: Native → CW → SDK → HTTP → fallback ----
  const allAttempts = [];

  // 0) Trae 原生协议 (x-cloudide-token, 需要 nativeToken + nativeHost)
  if (_token.nativeToken && _token.nativeHost) {
    try {
      const nativeResult = await callTraeByNativeProtocol(_token, prompt, model, options);
      if (nativeResult.success) return nativeResult;
      if (nativeResult.attempts) allAttempts.push(...nativeResult.attempts);
    } catch (nativeErr) {
      allAttempts.push({ provider: 'Trae-Native', success: false, error: nativeErr?.message || String(nativeErr) });
    }
  }

  // 1) CodeWhisperer 协议通道 (Trae 原生, accessToken 必须; sessionCookies 可选增强)
  {
    try {
      const cwResult = await callTraeByCodeWhisperer(_token, prompt, model, options);
      if (cwResult.success) return cwResult;
      if (cwResult.attempts) allAttempts.push(...cwResult.attempts);
    } catch (cwErr) {
      allAttempts.push({ provider: 'Trae-CW', success: false, error: cwErr?.message || String(cwErr) });
    }
  }

  // 2) SDK 通道 (OpenAI 兼容)
  const sdkMode = resolveTraeSdkMode();
  let sdkResult = null;

  if (sdkMode !== 'off') {
    sdkResult = await callTraeBySdk(_token, prompt, model, options);
    if (sdkResult.success) {
      sdkResult.attempts = mergeAttempts(allAttempts, sdkResult.attempts);
      return sdkResult;
    }
    if (sdkMode === 'force') {
      sdkResult.attempts = mergeAttempts(allAttempts, sdkResult.attempts);
      return sdkResult;
    }
  }

  // 3) HTTP 通道 (OpenAI 兼容)
  let result = await callTraeByHttp(_token, prompt, model, options);
  if (result.success) {
    result.attempts = mergeAttempts(allAttempts, sdkResult?.attempts, result.attempts);
    return result;
  }

  // 4) auth 失败 → fallback token 重试 HTTP
  if (result.errorType === 'auth' && selected.fallback && selected.fallback.accessToken && !isTokenExpired(selected.fallback)) {
    _token = selected.fallback;
    persistObservedToken(_token);

    const retry = await callTraeByHttp(_token, prompt, model, options);
    if (retry.success) {
      retry.attempts = mergeAttempts(allAttempts, sdkResult?.attempts, result.attempts, retry.attempts);
      return retry;
    }

    return {
      ...retry,
      attempts: mergeAttempts(allAttempts, sdkResult?.attempts, result.attempts, retry.attempts),
    };
  }

  result.attempts = mergeAttempts(allAttempts, sdkResult?.attempts, result.attempts);
  return result;
}

function destroy() {
  _detectionState = {
    installDetected: false, officialArtifactsDetected: false,
    officialArtifactSources: [],
    credentialMode: 'none', sessionVerified: false, available: false,
    _checked: false, _officialCredential: null,
  };
  _endpointProbeCache.clear();
  _token = null;
  _models = [];
  _modelsFetchedAt = 0;
  _lastApiMeta = {
    at: 0,
    endpoint: '',
    officialHit: false,
    officialCount: 0,
    localCount: 0,
    mergedCount: 0,
    error: '',
    mode: 'http',
  };

  try {
    if (_sdkClient && typeof _sdkClient.close === 'function') {
      _sdkClient.close();
    }
  } catch {
    // ignore sdk client close errors
  }
  _sdkClient = null;
  _sdkClientEndpoint = '';

  // CodeWhisperer 协议客户端
  _traeCWClient = null;
  _traeCWClientKey = '';
}

/**
 * Build an OpenAI-compatible relay profile from current Trae login state.
 * Used by `proxy switch-center sync --provider trae` and auto sync flow.
 */
async function getRelayProfile(options = {}) {
  const selected = await selectToken({ allowExpired: false });
  if (!selected.token || !selected.token.accessToken) {
    throw new Error('Trae token not found. Please login in Trae IDE first.');
  }
  _token = selected.token;
  _detectionState.available = true;
  persistObservedToken(_token);

  if (isTokenExpired(_token)) {
    throw new Error('Trae token expired. Please re-login in Trae IDE.');
  }

  const models = await listModels();
  const modelIds = (Array.isArray(models) ? models : [])
    .map(m => normalizeModelId(m?.id || ''))
    .filter(Boolean);
  if (modelIds.length === 0) {
    throw new Error('No Trae models discovered from current account.');
  }

  const defaultModel = normalizeModelId(
    options.defaultModel
    || options.model
    || (models.find(m => m && m.isDefault) || {}).id
    || modelIds[0]
  ) || modelIds[0];

  const endpointOverride = toRelayEndpointBase(options.endpoint || options.baseUrl || options.base || '');
  const endpointFromToken = toRelayEndpointBase(_token.endpoint || '');
  const endpointFromApi = toRelayEndpointBase(resolveTraeApiBases(_token)[0] || '');
  const endpoint = endpointOverride
    || endpointFromToken
    || endpointFromApi
    || '';  // 不再盲加 api.trae.ai/v1 — 真实 Trae API 是原生协议非 OpenAI 兼容

  if (!endpoint) {
    throw new Error('没有可用的 OpenAI 兼容端点 — Trae 原生 API 不支持 /v1/chat/completions 格式');
  }

  const modelMap = {};
  for (const id of modelIds) modelMap[id] = id;

  return {
    id: String(options.id || 'trae-auto').trim() || 'trae-auto',
    name: String(options.name || 'Trae Auto').trim() || 'Trae Auto',
    endpoint,
    key: String(options.key || '').trim() || _token.accessToken,
    models: modelIds,
    modelMap,
    defaultModel,
    source: _token.source || '',
    path: _token.path || '',
    generatedAt: new Date().toISOString(),
  };
}

module.exports = { detect, detectAsync, getStatus, listModels, generate, destroy, getRelayProfile };
