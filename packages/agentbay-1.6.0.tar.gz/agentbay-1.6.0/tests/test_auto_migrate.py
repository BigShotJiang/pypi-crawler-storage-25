"""Phase 1.1 acceptance tests for auto-migrate-on-auth.

Six cases enumerated by the design spec:
1. AgentBay() with no key + local SQLite present       → no migration
2. AgentBay(api_key=...) with empty local SQLite       → no migration, no error
3. 50 unsynced rows + existing cloud project           → migrates 50, success line
4. 50 unsynced rows + NO cloud project                 → auto-creates "Local migration", migrates
5. Re-run after a successful migration                  → no-op (idempotent)
6. 25th POST fails                                      → 25 synced, 25 dirty, partial line, retry next start
"""

from __future__ import annotations

import io
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from agentbay.local import LocalMemory
from agentbay.migrate import (
    LOCAL_MIGRATION_PROJECT_DESCRIPTION,
    LOCAL_MIGRATION_PROJECT_NAME,
    count_unsynced,
    run_auto_migration,
)


BASE_URL = "https://www.aiagentsbay.com"
API_KEY = "ab_live_test_fake"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(status: int = 200, body=None):
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = body if body is not None else {}
    return resp


def _seed_local(db_path: str, n: int) -> None:
    mem = LocalMemory(db_path=db_path, quiet=True)
    for i in range(n):
        mem.store(
            content=f"content body {i}",
            title=f"entry {i}",
            type="PATTERN",
            tags=["seed"],
        )


def _push_memory_response(idx: int):
    return _mock_response(200, {"id": f"cloud_mem_{idx}"})


@pytest.fixture
def temp_db_dir():
    with tempfile.TemporaryDirectory() as td:
        yield td


@pytest.fixture
def empty_db(temp_db_dir):
    return os.path.join(temp_db_dir, "empty.db")


@pytest.fixture
def seeded_db(temp_db_dir):
    """Local DB pre-seeded with 50 unsynced memories."""
    path = os.path.join(temp_db_dir, "seeded.db")
    _seed_local(path, 50)
    assert count_unsynced(path) == 50
    return path


# ---------------------------------------------------------------------------
# Test 1 — AgentBay() with no key + local SQLite → no migration triggered
# ---------------------------------------------------------------------------


def test_no_api_key_skips_migration(monkeypatch):
    """Constructing AgentBay() with no key must never call the migration runner.

    LocalMemory is patched so the test does not touch the user's real
    ~/.agentbay/local.db (which can be in an older schema state).
    """
    monkeypatch.setenv("AGENTBAY_QUIET", "1")
    monkeypatch.delenv("AGENTBAY_API_KEY", raising=False)

    with patch("agentbay.client.run_auto_migration_in_background") as bg, \
         patch("agentbay.client.load_saved_key", return_value=None), \
         patch("agentbay.local.LocalMemory") as local_cls:
        local_cls.return_value = MagicMock()
        from agentbay import AgentBay

        brain = AgentBay()  # no key → local mode
        assert brain._is_local is True
        assert brain.api_key is None
        bg.assert_not_called()


# ---------------------------------------------------------------------------
# Test 2 — AgentBay(api_key=...) with empty local SQLite → no-op, no error
# ---------------------------------------------------------------------------


def test_empty_local_db_is_noop(empty_db):
    """No local rows means no resolution, no POST, no stderr line."""
    stream = io.StringIO()
    with patch("requests.get") as get, patch("requests.post") as post:
        result = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=empty_db,
            stream=stream,
        )

    assert result == {"pushed": 0, "conflicts": 0, "errors": 0, "skipped": True}
    get.assert_not_called()
    post.assert_not_called()
    assert stream.getvalue() == ""


# ---------------------------------------------------------------------------
# Test 3 — 50 unsynced rows + existing cloud project → all 50 migrate
# ---------------------------------------------------------------------------


def test_migrates_all_when_project_exists(seeded_db):
    stream = io.StringIO()
    list_resp = _mock_response(200, {"projects": [{"id": "proj_existing"}]})
    push_responses = [_push_memory_response(i) for i in range(50)]

    with patch("requests.get", return_value=list_resp) as get, \
         patch("requests.post", side_effect=push_responses) as post:
        result = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=stream,
        )

    assert get.call_count == 1
    assert post.call_count == 50
    assert result["pushed"] == 50
    assert result["errors"] == 0
    assert result["project_id"] == "proj_existing"
    assert (
        stream.getvalue().strip()
        == "AgentBay: synced 50 local memories to your cloud account."
    )

    # cloud_id stamping: every memory has a sync_log row pointing at the cloud id
    with sqlite3.connect(seeded_db) as conn:
        synced = conn.execute(
            "SELECT COUNT(DISTINCT entry_id) FROM sync_log WHERE direction = 'up'"
        ).fetchone()[0]
        cloud_ids = {
            row[0]
            for row in conn.execute(
                "SELECT cloud_id FROM sync_log WHERE direction = 'up'"
            )
        }
    assert synced == 50
    assert len(cloud_ids) == 50  # each cloud_id is unique
    assert count_unsynced(seeded_db) == 0


# ---------------------------------------------------------------------------
# Test 4 — 50 unsynced rows + NO cloud project → auto-creates "Local migration"
# ---------------------------------------------------------------------------


def test_auto_creates_local_migration_project(seeded_db):
    stream = io.StringIO()
    list_resp = _mock_response(200, {"projects": []})
    create_resp = _mock_response(201, {"id": "proj_local_migration"})
    push_responses = [_push_memory_response(i) for i in range(50)]

    with patch("requests.get", return_value=list_resp), \
         patch(
             "requests.post",
             side_effect=[create_resp] + push_responses,
         ) as post:
        result = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=stream,
        )

    # First POST is project create — match name and description exactly
    create_call = post.call_args_list[0]
    create_body = create_call.kwargs["json"]
    assert create_body == {
        "name": LOCAL_MIGRATION_PROJECT_NAME,
        "description": LOCAL_MIGRATION_PROJECT_DESCRIPTION,
    }
    create_url = create_call.args[0] if create_call.args else create_call.kwargs.get("url")
    assert create_url.endswith("/api/v1/projects")

    # Remaining 50 POSTs are per-entry memory writes against the new project
    memory_calls = post.call_args_list[1:]
    assert len(memory_calls) == 50
    for call in memory_calls:
        url = call.args[0] if call.args else call.kwargs.get("url")
        assert "/api/v1/projects/proj_local_migration/memory" in url

    assert result["pushed"] == 50
    assert result["errors"] == 0
    assert result["project_id"] == "proj_local_migration"
    assert (
        stream.getvalue().strip()
        == "AgentBay: synced 50 local memories to your cloud account."
    )


# ---------------------------------------------------------------------------
# Test 5 — Re-running after a successful migration is a no-op
# ---------------------------------------------------------------------------


def test_rerun_after_success_is_noop(seeded_db):
    list_resp = _mock_response(200, {"projects": [{"id": "proj_existing"}]})
    push_responses = [_push_memory_response(i) for i in range(50)]

    with patch("requests.get", return_value=list_resp), \
         patch("requests.post", side_effect=push_responses):
        first = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=io.StringIO(),
        )
    assert first["pushed"] == 50
    assert count_unsynced(seeded_db) == 0

    # Second run: nothing dirty, no HTTP at all, no stderr line
    stream = io.StringIO()
    with patch("requests.get") as get, patch("requests.post") as post:
        second = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=stream,
        )
    assert second == {"pushed": 0, "conflicts": 0, "errors": 0, "skipped": True}
    get.assert_not_called()
    post.assert_not_called()
    assert stream.getvalue() == ""


# ---------------------------------------------------------------------------
# Test 6 — Partial failure: 25 succeed, 25 stay dirty, retry next start finishes
# ---------------------------------------------------------------------------


def test_partial_failure_retries_next_start(seeded_db):
    list_resp = _mock_response(200, {"projects": [{"id": "proj_existing"}]})

    # First 25 succeed, last 25 return 500
    first_run_responses = (
        [_push_memory_response(i) for i in range(25)]
        + [_mock_response(500, {"error": "boom"}) for _ in range(25)]
    )

    stream1 = io.StringIO()
    with patch("requests.get", return_value=list_resp), \
         patch("requests.post", side_effect=first_run_responses):
        first = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=stream1,
        )

    assert first["pushed"] == 25
    assert first["errors"] == 25
    assert (
        stream1.getvalue().strip()
        == "AgentBay: 25 memories still pending — will retry next start."
    )
    # Exactly half stamped, half still dirty
    assert count_unsynced(seeded_db) == 25
    with sqlite3.connect(seeded_db) as conn:
        synced = conn.execute(
            "SELECT COUNT(DISTINCT entry_id) FROM sync_log WHERE direction = 'up'"
        ).fetchone()[0]
    assert synced == 25

    # Next start: only the remaining 25 are POSTed and they succeed
    second_run_responses = [_push_memory_response(100 + i) for i in range(25)]
    stream2 = io.StringIO()
    with patch("requests.get", return_value=list_resp), \
         patch("requests.post", side_effect=second_run_responses) as post:
        second = run_auto_migration(
            api_key=API_KEY,
            base_url=BASE_URL,
            db_path=seeded_db,
            stream=stream2,
        )

    assert post.call_count == 25
    assert second["pushed"] == 25
    assert second["errors"] == 0
    assert (
        stream2.getvalue().strip()
        == "AgentBay: synced 25 local memories to your cloud account."
    )
    assert count_unsynced(seeded_db) == 0
