"""Phase 1.1 — Auto-migrate local SQLite memories to cloud on auth.

Mirrors the npm package `aiagentsbay-mcp@0.8.0` migration behavior so the
offline → cloud transition is consistent across SDKs:

- Triggered automatically by `AgentBay(api_key=...)` when the local SQLite
  has any unsynced rows. Runs in a background thread, never blocks the
  constructor, never prompts.
- Resolves the target project: uses the user's first cloud project, or
  auto-creates one named "Local migration" with the same description the
  npm package uses.
- Per-entry POST with cloud_id stamped on success (via the existing
  `SyncEngine` sync_log table), so re-runs are no-ops and partial failures
  retry the still-dirty rows on the next start.
- Surfaces a single stderr line — never a stack trace — so the user sees
  exactly one piece of feedback when migration runs.
"""

from __future__ import annotations

import os
import sqlite3
import sys
import threading
from pathlib import Path
from typing import Any, Dict, Optional

import requests

from .sync import SyncEngine


LOCAL_MIGRATION_PROJECT_NAME = "Local migration"
LOCAL_MIGRATION_PROJECT_DESCRIPTION = (
    "Auto-created when migrating offline AgentBay memories."
)


def default_local_db_path() -> str:
    """Return the conventional local DB path used when no key is set."""
    return str(Path.home() / ".agentbay" / "local.db")


def count_unsynced(db_path: str) -> int:
    """Count rows in the local DB that have not yet been pushed to cloud.

    Returns 0 if the database file or the `memories` table does not exist.
    """
    if not os.path.exists(db_path):
        return 0

    try:
        with sqlite3.connect(db_path) as conn:
            tables = {
                row[0]
                for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if "memories" not in tables:
                return 0

            if "sync_log" not in tables:
                return conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

            row = conn.execute(
                """
                SELECT COUNT(*) FROM memories m
                LEFT JOIN sync_log s
                  ON m.id = s.entry_id AND s.direction = 'up'
                WHERE s.id IS NULL
                   OR m.updated_at > s.synced_at
                """
            ).fetchone()
            return int(row[0])
    except sqlite3.DatabaseError:
        return 0


def _resolve_project(
    api_key: str,
    base_url: str,
    timeout: int,
    session: Optional[requests.Session] = None,
) -> Optional[str]:
    """Return the project id to migrate into.

    Uses the user's first project. If they have none, auto-creates one
    named "Local migration" — same name and description as the npm
    package so users get the same experience across SDKs.

    Returns None when the resolution fails (e.g. offline). The caller
    should treat this as "skip migration this time, retry next start".
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    http = session or requests
    url = f"{base_url.rstrip('/')}/api/v1/projects"

    try:
        resp = http.get(url, headers=headers, timeout=timeout)
    except requests.RequestException:
        return None

    if resp.status_code != 200:
        return None

    try:
        data = resp.json()
    except ValueError:
        return None

    projects = data.get("projects") if isinstance(data, dict) else data
    if isinstance(projects, list) and projects:
        first = projects[0]
        if isinstance(first, dict) and first.get("id"):
            return str(first["id"])

    try:
        created = http.post(
            url,
            headers=headers,
            json={
                "name": LOCAL_MIGRATION_PROJECT_NAME,
                "description": LOCAL_MIGRATION_PROJECT_DESCRIPTION,
            },
            timeout=timeout,
        )
    except requests.RequestException:
        return None

    if created.status_code not in (200, 201):
        return None

    try:
        body = created.json()
    except ValueError:
        return None

    if isinstance(body, dict):
        if body.get("id"):
            return str(body["id"])
        proj = body.get("project")
        if isinstance(proj, dict) and proj.get("id"):
            return str(proj["id"])
    return None


def _format_result_line(pushed: int, conflicts: int, errors: int) -> Optional[str]:
    """Build the single stderr line for a migration run.

    Returns None when nothing happened (no successes, no failures), so
    the caller stays silent.
    """
    synced = pushed + conflicts
    if errors > 0:
        return (
            f"AgentBay: {errors} memories still pending "
            f"— will retry next start."
        )
    if synced > 0:
        return f"AgentBay: synced {synced} local memories to your cloud account."
    return None


def run_auto_migration(
    api_key: str,
    base_url: str,
    db_path: Optional[str] = None,
    timeout: int = 30,
    session: Optional[requests.Session] = None,
    stream: Any = None,
) -> Dict[str, Any]:
    """Run one migration pass synchronously.

    Returns a result dict with `pushed`, `conflicts`, `errors`,
    `project_id` and `skipped` keys. Used directly by tests; the
    constructor wraps it in a background thread.
    """
    out = stream if stream is not None else sys.stderr
    path = db_path or default_local_db_path()

    if count_unsynced(path) == 0:
        return {"pushed": 0, "conflicts": 0, "errors": 0, "skipped": True}

    project_id = _resolve_project(
        api_key=api_key,
        base_url=base_url,
        timeout=timeout,
        session=session,
    )
    if not project_id:
        return {"pushed": 0, "conflicts": 0, "errors": 0, "skipped": True}

    engine = SyncEngine(local_db_path=path, api_key=api_key, base_url=base_url)
    try:
        result = engine.push(project_id)
    except Exception:
        return {
            "pushed": 0,
            "conflicts": 0,
            "errors": count_unsynced(path),
            "project_id": project_id,
            "skipped": False,
        }

    pushed = int(result.get("pushed", 0))
    conflicts = int(result.get("conflicts", 0))
    errors = int(result.get("errors", 0))

    line = _format_result_line(pushed, conflicts, errors)
    if line:
        print(line, file=out)

    return {
        "pushed": pushed,
        "conflicts": conflicts,
        "errors": errors,
        "project_id": project_id,
        "skipped": False,
    }


def run_auto_migration_in_background(
    api_key: str,
    base_url: str,
    db_path: Optional[str] = None,
    timeout: int = 30,
) -> threading.Thread:
    """Fire-and-forget wrapper around `run_auto_migration`.

    Returns the spawned daemon thread so callers may join() in tests.
    Production callers ignore the return value.
    """
    def _run() -> None:
        try:
            run_auto_migration(
                api_key=api_key,
                base_url=base_url,
                db_path=db_path,
                timeout=timeout,
            )
        except Exception:
            return

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    return thread
