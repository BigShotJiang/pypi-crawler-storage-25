def hello():
    print("hello from pysteer!")


if __name__ == "__main__":
    hello()
