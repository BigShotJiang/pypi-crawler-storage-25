from setuptools import setup, find_packages


setup(
    name='pysteer',
    version='0.01',
    packages=find_packages(),
    install_requires=[]
)
