class TokenizeBot:
    def __init__(self):
        self.suffixes = ["n't", "'ve", "'re", "'ll", "'s", "'d", "'m"]
        self.standard_punct = '][.,;"?():!_`'

    def tokenize(self, text, lowercase=False):
        if not text: return []
        if lowercase: text = text.lower()
        text = text.replace('"', " '' ").replace('“', " `` ").replace('”', " '' ").replace(" ` ", " `` ")
        buffered = "".join([f" {c} " if c in self.standard_punct else c for c in text])
        raw_words = buffered.split()
        final_tokens = []
        for word in raw_words:
            low_word = word.lower()
            if low_word == "can't":
                final_tokens.extend(["ca" if lowercase else word[:2], word[-3:]])
            else:
                split = False
                for s in self.suffixes:
                    if low_word.endswith(s) and len(word) > len(s):
                        final_tokens.extend([word[:-len(s)], word[-len(s):]])
                        split = True
                        break
                if not split:
                    if word.endswith("'") and len(word) > 1:
                        final_tokens.extend([word[:-1], "'"])
                    else:
                        final_tokens.append(word)
        return final_tokens
