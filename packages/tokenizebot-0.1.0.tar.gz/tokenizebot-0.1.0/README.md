# TokenizeBot

![PyPI version](https://img.shields.io/pypi/v/tokenizebot)
![License](https://img.shields.io/pypi/l/tokenizebot)

A lightweight, rule-based tokenizer for handling English clitics and punctuation.

## Installation
```bash
pip install tokenizebot
```

## Usage
```python
from tokenizebot import TokenizeBot
bot = TokenizeBot()

tokens = bot.tokenize("They've been busy.", lowercase=True)
print(tokens) 
```
