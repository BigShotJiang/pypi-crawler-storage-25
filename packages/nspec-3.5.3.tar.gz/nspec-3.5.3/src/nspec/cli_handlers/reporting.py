"""Reporting and validation command handlers for nspec CLI.

Handles validate, generate, dashboard, stats, progress, deps,
audit, and related reporting commands.
"""

from __future__ import annotations

import sys
from pathlib import Path

from nspec.domain.datasets import DatasetLoader
from nspec.mutation import clean_dangling_deps
from nspec.reporting.table_formatter import NspecTableFormatter
from nspec.spinner import spinner
from nspec.validation.validator import NspecValidator


def _resolve_strict_mode(args) -> bool:
    """Resolve enforce_epic_grouping from config.toml."""
    try:
        from nspec.config import NspecConfig

        project_root = getattr(args, "project_root", None)
        config = NspecConfig.load(project_root)
        return config.validation.enforce_epic_grouping
    except Exception:  # noqa: BLE001
        return False


def handle_validate(args) -> int:
    """Run all validation layers."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None)
    try:
        config = NspecConfig.load(project_root)
        strict_completion_parity = config.validation.strict_completion_parity
    except Exception:  # noqa: BLE001
        strict_completion_parity = True

    validator = NspecValidator(
        docs_root=args.docs_root,
        strict_mode=_resolve_strict_mode(args),
        strict_completion_parity=strict_completion_parity,
        project_root=project_root,
    )
    success, errors = validator.validate()

    if success:
        print("Nspec validation passed - no errors found")  # noqa: T201
        return 0
    print(f"\nFound {len(errors)} errors:")  # noqa: T201
    for error in errors:
        print(error)  # noqa: T201
        print()  # noqa: T201
    return 1


def handle_validate_main(args) -> int:
    """Run integrity validation against the main branch."""
    from nspec.validation.main_integrity import (
        format_error,
        validate_main_integrity,
    )

    project_root = getattr(args, "project_root", None)
    try:
        success, errors, summary = validate_main_integrity(
            docs_root=args.docs_root,
            project_root=project_root,
        )
    except Exception as e:  # noqa: BLE001
        print(f"Failed to validate main branch: {e}")  # noqa: T201
        return 1

    if success:
        print(f"  {summary}")  # noqa: T201
        return 0
    print(f"\n  {summary}\n")  # noqa: T201
    for error in errors:
        print(f"  {format_error(error)}")  # noqa: T201
    print()  # noqa: T201
    return 1


def handle_generate(args) -> int:
    """Generate NSPEC.md from validated fRIMPLs."""
    # Pass 0: Auto-clean dangling dependencies
    cleaned = clean_dangling_deps(args.docs_root)
    if cleaned:
        for spec_id, _path, removed in cleaned:
            print(f"Spec {spec_id}: removed dangling deps {removed}")  # noqa: T201

    # Pass 1: Validate
    validator = NspecValidator(
        docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
    )
    with spinner("Loading"):
        success, errors = validator.validate()

    if not success:
        print(f"\nValidation failed with {len(errors)} errors. Cannot generate.")  # noqa: T201
        for error in errors:
            print(error)  # noqa: T201
            print()  # noqa: T201
        print("Fix errors first, then run --generate again.")  # noqa: T201
        return 1

    # Pass 2: Generate files
    validator.generate_nspec(Path("NSPEC.md"))
    validator.generate_nspec_completed(Path("NSPEC_COMPLETED.md"))
    return 0


def handle_dashboard(args) -> int:
    """Generate + stats in one call."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None)
    try:
        config = NspecConfig.load(project_root)
        strict_completion_parity = config.validation.strict_completion_parity
        default_epic = config.defaults.epic
    except Exception:  # noqa: BLE001
        strict_completion_parity = True
        default_epic = None

    # Clean dangling deps
    cleaned = clean_dangling_deps(args.docs_root)
    if cleaned:
        for spec_id, _path, removed in cleaned:
            print(f"Spec {spec_id}: removed dangling deps {removed}")  # noqa: T201

    # Auto-assign ungrouped specs to default epic (from config)
    if default_epic:
        from nspec.mutation import auto_assign_ungrouped_to_epic

        try:
            assigned = auto_assign_ungrouped_to_epic(default_epic, args.docs_root)
            if assigned:
                for spec_id, epic_id in assigned:
                    print(f"Spec {spec_id}: auto-assigned to Epic {epic_id}")  # noqa: T201
        except (FileNotFoundError, ValueError) as e:
            print(f"Auto-assign failed: {e}")  # noqa: T201

    # Validate and generate
    validator = NspecValidator(
        docs_root=args.docs_root,
        strict_mode=_resolve_strict_mode(args),
        strict_completion_parity=strict_completion_parity,
        project_root=project_root,
    )
    validator.verbose_status = getattr(args, "verbose_status", False)
    validator.epic_filter = getattr(args, "epic", None)

    with spinner("Loading"):
        success, errors = validator.validate()

    if not success:
        print(f"\nValidation failed with {len(errors)} errors.")  # noqa: T201
        for error in errors:
            print(error)  # noqa: T201
            print()  # noqa: T201
        return 1

    # Generate files
    validator.generate_nspec(Path("NSPEC.md"))
    validator.generate_nspec_completed(Path("NSPEC_COMPLETED.md"))

    # Show stats (without calendar)
    formatter = NspecTableFormatter(
        datasets=validator.datasets,  # pyright: ignore[reportArgumentType]
        ordered_active_specs=validator.ordered_active_specs,
        verbose_status=validator.verbose_status,
        epic_filter=validator.epic_filter,
    )
    formatter.show_stats(show_calendar=False)
    return 0


def handle_stats(args) -> int:
    """Show engineering metrics dashboard."""
    output_format = getattr(args, "format", "text")
    output_path = getattr(args, "output", None)

    if output_format == "text":
        from nspec.reporting.dev_metrics import print_dev_metrics

        print_dev_metrics(Path("."))
        return 0

    import json

    from nspec.reporting.dev_metrics import build_metrics_payload

    payload = build_metrics_payload(Path("."))

    if output_format == "json":
        content = json.dumps(payload, indent=2)
    elif output_format == "yaml":
        try:
            import yaml

            content = yaml.dump(payload, default_flow_style=False, sort_keys=False)
        except ImportError:
            print("Error: PyYAML is required for YAML output. Install with: pip install pyyaml")  # noqa: T201
            return 1
    else:
        content = ""

    if output_path:
        output_path.write_text(content)
        print(f"Written to {output_path}")  # noqa: T201
    else:
        print(content)  # noqa: T201
    return 0


def handle_progress(args) -> int:
    """Show task/AC progress."""
    validator = NspecValidator(
        docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
    )

    try:
        loader = DatasetLoader(
            docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
        )
        validator.datasets = loader.load()
    except ValueError as e:
        print(f"Failed to load datasets: {e}")  # noqa: T201
        return 1

    if args.progress == "__summary__":
        validator.show_progress(show_all=args.all)
    else:
        validator.show_progress(spec_id=args.progress)
    return 0


def handle_deps(args) -> int:
    """List direct dependencies of a spec/epic."""
    loader = DatasetLoader(args.docs_root, project_root=getattr(args, "project_root", None))
    datasets = loader.load()

    fr = datasets.active_frs.get(args.deps)
    if not fr:
        print(f"Spec {args.deps} not found in active nspec")  # noqa: T201
        return 1

    if not fr.deps:
        print(f"Spec {args.deps} has no dependencies")  # noqa: T201
        return 0

    title = fr.path.stem.replace(f"FR-{args.deps}-", "").replace("-", " ").title()
    print(f"\nDependencies of {args.deps}: {title}")  # noqa: T201
    print(f"   Priority: {fr.priority} | Status: {fr.status}")  # noqa: T201
    print(f"   Count: {len(fr.deps)} dependencies\n")  # noqa: T201

    for dep_id in sorted(fr.deps, key=lambda x: int(x) if x.isdigit() else 0):
        dep_fr = datasets.active_frs.get(dep_id)
        if dep_fr:
            dep_title = dep_fr.path.stem.replace(f"FR-{dep_id}-", "").replace("-", " ").title()
            dep_impl = datasets.active_impls.get(dep_id)
            impl_status = dep_impl.status if dep_impl else "N/A"
            print(f"   {dep_id}: {dep_title}")  # noqa: T201
            print(f"        FR: {dep_fr.status} | IMPL: {impl_status} | Pri: {dep_fr.priority}")  # noqa: T201
        else:
            dep_fr = datasets.completed_frs.get(dep_id)
            if dep_fr:
                print(f"   {dep_id}: (completed)")  # noqa: T201
            else:
                print(f"   {dep_id}: (not found)")  # noqa: T201

    print()  # noqa: T201
    return 0


def handle_audit(args) -> int:
    """Run the coverage audit pipeline."""
    from nspec.analysis.coverage_audit import (
        format_audit_summary,
        run_audit,
    )

    coverage_json = Path(getattr(args, "coverage_json", "coverage.json"))
    registry = Path(getattr(args, "registry", "work/coverage_decisions.json"))
    strict = getattr(args, "strict", False)

    include = getattr(args, "include", None)
    include_patterns = [p.strip() for p in include.split(",")] if include else None
    exclude = getattr(args, "exclude", None)
    exclude_patterns = [p.strip() for p in exclude.split(",")] if exclude else None

    try:
        result = run_audit(
            coverage_json,
            registry,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Audit error: {e}", file=sys.stderr)  # noqa: T201
        return 1

    print(format_audit_summary(result))  # noqa: T201

    if strict and (result.unresolved or result.stale_decisions):
        return 1
    return 0


def handle_audit_trail(args) -> int:
    """List or show audit trail artifacts."""
    from nspec.config import NspecConfig
    from nspec.domain.audit_dao import AuditDAO
    from nspec.domain.audit_types import KIND_TO_DIR, VALID_KINDS

    trail_command = getattr(args, "trail_command", None)
    if not trail_command:
        print("Usage: nspec trail <list|show>")  # noqa: T201
        return 1

    project_root = getattr(args, "project_root", None)
    try:
        config = NspecConfig.load(project_root)
        p_root = config.resolve_project_root()
    except Exception:  # noqa: BLE001
        p_root = Path.cwd()

    dao = AuditDAO.from_project_root(p_root)

    if trail_command == "list":
        kind_filter = getattr(args, "kind", None)
        kinds_to_list = [kind_filter] if kind_filter else sorted(VALID_KINDS)
        try:
            dataset = dao.load()
        except ValueError as e:
            print(f"Error loading audit artifacts: {e}", file=sys.stderr)  # noqa: T201
            return 1

        for kind in kinds_to_list:
            artifacts = dataset.by_kind(kind)  # type: ignore[arg-type]
            if artifacts:
                print(f"\n## {KIND_TO_DIR[kind]} ({len(artifacts)})\n")  # noqa: T201
                for a in artifacts:
                    topic = getattr(a.frontmatter, "topic", "")
                    print(f"  {a.slug}  —  {topic}")  # noqa: T201
            elif kind_filter:
                print(f"No {kind} artifacts found.")  # noqa: T201
        if not kind_filter and dataset.total == 0:
            print("No audit artifacts found.")  # noqa: T201
        return 0

    if trail_command == "show":
        slug = getattr(args, "slug", "")
        artifact = dao.find_by_slug(slug)
        if artifact is None:
            print(f"Artifact not found: {slug}", file=sys.stderr)  # noqa: T201
            return 1
        print(f"# {artifact.slug} ({artifact.kind})\n")  # noqa: T201
        print(f"URI: {artifact.uri}\n")  # noqa: T201
        print(artifact.body)  # noqa: T201
        return 0

    print("Usage: nspec trail <list|show>")  # noqa: T201
    return 1


def handle_context_audit(args) -> int:
    """Run the CLAUDE.md context budget audit."""
    from nspec.analysis.context_audit import (
        format_audit_report,
        run_context_audit,
    )

    file_path = getattr(args, "file", None) or "CLAUDE.md"
    threshold = getattr(args, "threshold", 50) / 100.0

    try:
        result = run_context_audit(file_path, threshold=threshold)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)  # noqa: T201
        return 1

    print(format_audit_report(result))  # noqa: T201
    return 0
