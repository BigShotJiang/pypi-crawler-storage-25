"""CRUD command handlers for nspec CLI.

Handles create, delete, complete, supersede, reject, finalize,
dependency management, priority/LOE/status changes, and task/criteria checks.
"""

from __future__ import annotations

from pathlib import Path

from nspec.mutation import (
    add_dependency,
    check_acceptance_criteria,
    check_impl_task,
    clean_dangling_deps,
    complete_spec,
    create_adr,
    create_new_spec,
    delete_spec,
    finalize_spec,
    list_adrs,
    move_dependency,
    next_status,
    reject_spec,
    remove_dependency,
    set_loe,
    set_priority,
    set_status,
    supersede_spec,
    validate_spec_criteria,
)
from nspec.paths import get_paths

# Exceptions expected during nspec CLI operations
_NspecCliErrors = (RuntimeError, ValueError, KeyError, TypeError, OSError, IOError)


def _normalize_spec_ref(spec_str: str) -> str:
    """Auto-prefix numeric IDs with 'S'."""
    if not spec_str:
        return spec_str
    spec_str = spec_str.strip()
    if spec_str and spec_str[0].isdigit():
        return "S" + spec_str
    return spec_str


def run_validation_check(
    docs_root: Path, operation_name: str, project_root: Path | None = None
) -> bool:
    """Run validation after a mutation operation and report results."""
    from nspec.validation.validator import NspecValidator

    print(f"\nRunning validation after {operation_name}...")  # noqa: T201
    validator = NspecValidator(docs_root=docs_root, project_root=project_root)
    success, errors = validator.validate()

    if success:
        print("Validation passed - nspec is consistent")  # noqa: T201
        return True
    print(f"Validation failed with {len(errors)} error(s):")  # noqa: T201
    for error in errors:
        print(f"  - {error}")  # noqa: T201
    print("\nFix these errors before proceeding with other nspec operations.")  # noqa: T201
    return False


def resolve_epic(explicit_epic: str | None, docs_root: Path) -> str | None:
    """Resolve epic ID: explicit flag > config default > None.

    Args:
        explicit_epic: Explicitly provided epic ID (--epic flag)
        docs_root: Path to docs/ directory

    Returns:
        Resolved epic ID (normalized to E### format), or None if no epic specified or configured
    """
    if explicit_epic:
        # Normalize to E### format if bare number provided
        if explicit_epic[0].isdigit():
            return f"E{explicit_epic.zfill(3)}"
        return explicit_epic

    # Check config for defaults.epic
    from nspec.config import NspecConfig

    config = NspecConfig.load(docs_root.parent)
    if config.defaults.epic:
        default_epic = config.defaults.epic
        # Config stores bare number (e.g. "001") — prefix with E
        if default_epic[0].isdigit():
            return f"E{default_epic.zfill(3)}"
        return default_epic

    return None


def validate_epic_exists(epic_id: str, docs_root: Path, project_root: Path | None = None) -> bool:
    """Validate that epic ID exists in active nspec.

    Args:
        epic_id: Epic ID to validate (can be "E001" or bare "001")
        docs_root: Path to docs/ directory

    Returns:
        True if epic exists

    Raises:
        ValueError: If epic doesn't exist
    """
    paths = get_paths(docs_root, project_root=project_root)
    # Normalize epic_id to E### format for pattern matching
    normalized = epic_id.upper() if epic_id.upper().startswith("E") else f"E{epic_id.zfill(3)}"
    pattern = f"FR-{normalized}-*.md"
    matches = list(paths.active_frs_dir.glob(pattern))

    if not matches:
        raise ValueError(f"Epic {epic_id} not found in {paths.active_frs_dir}")

    return True


def _set_default_epic(epic_id: str, project_root: Path | None = None) -> None:
    """Update config.toml to set the default epic."""
    from nspec.config import CONFIG_REL_PATH, NspecConfig

    if project_root is None:
        project_root = Path.cwd()

    config = NspecConfig.load(project_root)
    # Ensure config_file is set (may be None if file didn't exist)
    if config.config_file is None:
        config.config_file = project_root / CONFIG_REL_PATH
    # Store without E prefix (just the number)
    epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
    config.defaults.epic = epic_num
    config.save()


def handle_create_new(args) -> int:  # noqa: C901
    """Create new FR+IMPL from templates."""
    from nspec.config import NspecConfig

    if not args.title:
        print("Error: --title is required for spec create")  # noqa: T201
        return 1

    is_epic = getattr(args, "type", "spec") == "epic"
    set_default = getattr(args, "set_default", False)

    # Load config for git.auto_add and templates.fr/impl
    config = None
    try:
        config = NspecConfig.load(getattr(args, "project_root", None) or args.docs_root.parent)
        auto_add = config.git.auto_add
        fr_template = config.templates.fr
        impl_template = config.templates.impl
    except Exception:  # noqa: BLE001
        auto_add = False
        fr_template = None
        impl_template = None

    # Validate flag combinations
    if set_default and not is_epic:
        print("Error: --set-default only valid with --type epic")  # noqa: T201
        return 1
    if is_epic and getattr(args, "epic", None):
        print("Error: --epic cannot be used with --type epic (epics don't nest)")  # noqa: T201
        return 1

    try:
        # Resolve epic FIRST (before creating anything) — skip for epic creation
        epic_id = None
        if not is_epic:
            epic_id = resolve_epic(getattr(args, "epic", None), args.docs_root)

            # Config gates: require epic assignment when either gate is enabled
            if epic_id is None and config is not None:
                require_default_epic = config.strict.require_default_epic
                enforce_epic_grouping = config.validation.enforce_epic_grouping
                if require_default_epic or enforce_epic_grouping:
                    raise ValueError(
                        "Spec creation requires epic assignment.\n"
                        "Set it in .novabuilt.dev/nspec/config.toml:\n"
                        "  [defaults]\n"
                        '  epic = "001"\n\n'
                        "Current gates:\n"
                        "  [strict]\n"
                        f"  require_default_epic = {str(require_default_epic).lower()}\n"
                        "  [validation]\n"
                        f"  enforce_epic_grouping = {str(enforce_epic_grouping).lower()}\n\n"
                        "To allow orphan creation, disable both gates."
                    )

            # Validate epic exists BEFORE creating files (only if epic specified)
            if epic_id:
                validate_epic_exists(
                    epic_id, args.docs_root, project_root=getattr(args, "project_root", None)
                )

        # Resolve default priority from configured levels
        priority = args.priority
        _auto_priority = priority is None
        if priority is None:
            from nspec.domain.statuses import default_priority

            priority = default_priority()

        # Create spec/epic files
        fr_path, impl_path, spec_id = create_new_spec(
            title=args.title,
            priority=priority,
            docs_root=args.docs_root,
            fr_template=fr_template,
            impl_template=impl_template,
            is_epic=is_epic,
            auto_priority=_auto_priority,
        )

        # Add spec to epic (only if epic specified and not creating an epic)
        if epic_id and not is_epic:
            move_dependency(
                spec_id=spec_id,
                target_epic_id=epic_id,
                docs_root=args.docs_root,
            )

        # Set as default epic if requested
        if set_default and is_epic:
            _set_default_epic(spec_id, getattr(args, "project_root", None))

        # Git add if enabled in config
        if auto_add:
            import subprocess

            subprocess.run(["git", "add", str(fr_path), str(impl_path)], check=True)  # noqa: S603, S607

        if is_epic:
            if set_default:
                print(f"Created Epic {spec_id} (set as default)")  # noqa: T201
            else:
                print(f"Created Epic {spec_id}")  # noqa: T201
        elif epic_id:
            print(f"Created Spec {spec_id} in Epic {epic_id}")  # noqa: T201
        else:
            print(f"Created Spec {spec_id}")  # noqa: T201
        print(str(fr_path))  # noqa: T201
        print(str(impl_path))  # noqa: T201
        return 0
    except (ValueError, FileNotFoundError) as e:
        print(f"Failed to create spec: {e}")  # noqa: T201
        return 1


def handle_delete(args) -> int:
    """Delete FR+IMPL for a spec."""
    if not args.id:
        print("Error: --id is required for spec delete")  # noqa: T201
        return 1

    # Auto-prefix numeric IDs with S
    spec_id = args.id.strip()
    if spec_id and spec_id[0].isdigit():
        spec_id = "S" + spec_id

    try:
        fr_path, impl_path = delete_spec(
            spec_id=args.id,
            docs_root=args.docs_root,
            force=args.force,
        )
        print(f"Deleted Spec {spec_id}")  # noqa: T201
        print(f"   Removed: {fr_path.name}")  # noqa: T201
        print(f"   Removed: {impl_path.name}")  # noqa: T201
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to delete spec: {e}")  # noqa: T201
        return 1


def handle_complete(args) -> int:
    """Move FR+IMPL to completed directory."""
    if not args.id:
        print("Error: --id is required for spec complete")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = complete_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
        )
        print(str(fr_old))  # noqa: T201
        print(str(fr_new))  # noqa: T201
        print(str(impl_old))  # noqa: T201
        print(str(impl_new))  # noqa: T201
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to complete spec: {e}")  # noqa: T201
        return 1


def handle_supersede(args) -> int:
    """Move FR+IMPL to superseded directory."""
    if not args.id:
        print("Error: --id is required for spec supersede")  # noqa: T201
        return 1

    superseded_by = getattr(args, "by", None) or "unknown"

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = supersede_spec(
            spec_id=spec_id,
            superseded_by=superseded_by,
            docs_root=args.docs_root,
        )
        print(str(fr_old))  # noqa: T201
        print(str(fr_new))  # noqa: T201
        print(str(impl_old))  # noqa: T201
        print(str(impl_new))  # noqa: T201
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to supersede spec: {e}")  # noqa: T201
        return 1


def handle_reject(args) -> int:
    """Archive spec as rejected."""
    if not args.id:
        print("Error: --id is required for spec reject")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = reject_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
            force=args.force,
        )
        print(str(fr_old))  # noqa: T201
        print(str(fr_new))  # noqa: T201
        print(str(impl_old))  # noqa: T201
        print(str(impl_new))  # noqa: T201
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to reject spec: {e}")  # noqa: T201
        return 1


def handle_finalize(args) -> int:
    """Show completion status."""
    if not args.id:
        print("Error: --id is required for spec finalize")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        finalize_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
            execute=args.execute,
        )
        return 0
    except FileNotFoundError as e:
        print(f"Failed to finalize spec: {e}")  # noqa: T201
        return 1


def handle_add_dep(args) -> int:
    """Add dependency to a spec."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep add")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.to)
    dependency_id = _normalize_spec_ref(args.dep)
    try:
        result = add_dependency(
            spec_id=spec_id,
            dependency_id=dependency_id,
            docs_root=args.docs_root,
        )
        print(f"Added dependency {dependency_id} to Spec {spec_id}")  # noqa: T201
        print(f"   Updated: {result['path']}")  # noqa: T201
        if result.get("moved_from"):
            print(f"   Moved from Epic {result['moved_from']}")  # noqa: T201

        run_validation_check(args.docs_root, "dependency addition")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to add dependency: {e}")  # noqa: T201
        return 1


def handle_remove_dep(args) -> int:
    """Remove dependency from a spec."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep remove")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.to)
    dependency_id = _normalize_spec_ref(args.dep)
    try:
        fr_path = remove_dependency(
            spec_id=spec_id,
            dependency_id=dependency_id,
            docs_root=args.docs_root,
        )
        print(f"Removed dependency {dependency_id} from Spec {spec_id}")  # noqa: T201
        print(f"   Updated: {fr_path}")  # noqa: T201

        run_validation_check(args.docs_root, "dependency removal")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to remove dependency: {e}")  # noqa: T201
        return 1


def handle_move_dep(args) -> int:
    """Move spec to target epic."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep move")  # noqa: T201
        return 1

    try:
        result = move_dependency(
            spec_id=args.dep,
            target_epic_id=args.to,
            docs_root=args.docs_root,
        )

        print(f"Moved Spec {args.dep} to Epic {args.to}")  # noqa: T201
        if result["removed_from"]:
            for epic_id in result["removed_from"]:
                print(f"   Removed from Epic {epic_id}")  # noqa: T201
        if result["added_to"]:
            print(f"   Added to Epic {result['added_to']}")  # noqa: T201
        if result["priority_bumped"]:
            print(f"   Priority bumped to {result['priority_bumped']}")  # noqa: T201

        run_validation_check(args.docs_root, "dependency move")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to move dependency: {e}")  # noqa: T201
        return 1


def handle_dep_clean(args) -> int:
    """Remove dependencies pointing to non-existent specs."""
    cleaned = clean_dangling_deps(
        args.docs_root,
        project_root=getattr(args, "project_root", None),
        dry_run=getattr(args, "dry_run", False),
    )
    if not cleaned:
        print("No dangling deps found")  # noqa: T201
        return 0

    for spec_id, path, removed in cleaned:
        prefix = "[dry-run] " if getattr(args, "dry_run", False) else ""
        print(f"{prefix}Spec {spec_id}: removed dangling deps {removed}")  # noqa: T201
        print(f"   Updated: {path}")  # noqa: T201

    if not getattr(args, "dry_run", False):
        run_validation_check(args.docs_root, "dangling dependency cleanup")
    return 0


def handle_set_priority(args) -> int:
    """Change priority for a spec."""
    if not args.id or not args.priority:
        print("Error: --id and --priority are required for task set-priority")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_path = set_priority(
            spec_id=spec_id,
            priority=args.priority,
            docs_root=args.docs_root,
        )
        print(f"Updated Spec {spec_id} to {args.priority}")  # noqa: T201
        print(f"   Updated: {fr_path}")  # noqa: T201

        run_validation_check(args.docs_root, "priority change")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set priority: {e}")  # noqa: T201
        return 1


def handle_set_loe(args) -> int:
    """Set LOE for a spec."""
    if not args.id or not args.loe:
        print("Error: --id and --loe are required for task set-loe")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        impl_path = set_loe(
            spec_id=spec_id,
            loe=args.loe,
            docs_root=args.docs_root,
        )
        print(f"Updated Spec {spec_id} LOE to {args.loe}")  # noqa: T201
        print(f"   Updated: {impl_path}")  # noqa: T201

        run_validation_check(args.docs_root, "LOE change")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set LOE: {e}")  # noqa: T201
        return 1


def handle_set_status(args) -> int:
    """Set status for FR and IMPL files atomically."""
    if not args.id or args.fr_status is None or args.impl_status is None:
        print("Error: --id, --fr-status, and --impl-status required")  # noqa: T201
        return 1

    try:
        set_status(
            spec_id=args.id,
            fr_status=args.fr_status,
            impl_status=args.impl_status,
            docs_root=args.docs_root,
            force=args.force,
        )
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set status: {e}")  # noqa: T201
        return 1


def handle_next_status(args) -> int:
    """Auto-advance IMPL to next logical state."""
    if not args.id:
        print("Error: --id is required for task next-status")  # noqa: T201
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        next_status(
            spec_id=spec_id,
            docs_root=args.docs_root,
        )
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to advance status: {e}")  # noqa: T201
        return 1


def handle_check_criteria(args) -> int:
    """Mark acceptance criterion as complete or obsolete."""
    if not args.id or not args.criteria_id:
        print("Error: --id and --criteria-id are required for task criteria")  # noqa: T201
        return 1

    marker = getattr(args, "marker", "x")
    marker_desc = "complete" if marker == "x" else "obsolete"

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_path = check_acceptance_criteria(
            spec_id=spec_id,
            criteria_id=args.criteria_id,
            docs_root=args.docs_root,
            marker=marker,
        )
        print(f"Marked {args.criteria_id} as {marker_desc} for Spec {spec_id}")  # noqa: T201
        print(f"   Updated: {fr_path}")  # noqa: T201
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to check criteria: {e}")  # noqa: T201
        return 1


def handle_check_task(args) -> int:
    """Mark IMPL task as complete or obsolete."""
    if not args.id or not args.task_id:
        print("Error: --id and --task-id are required for task check")  # noqa: T201
        return 1

    marker = getattr(args, "marker", "x")
    marker_desc = "complete" if marker == "x" else "obsolete"

    spec_id = _normalize_spec_ref(args.id)
    try:
        impl_path = check_impl_task(
            spec_id=spec_id,
            task_id=args.task_id,
            docs_root=args.docs_root,
            marker=marker,
        )
        print(f"Marked task '{args.task_id}' as {marker_desc} for Spec {spec_id}")  # noqa: T201
        print(f"   Updated: {impl_path}")  # noqa: T201
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to check task: {e}")  # noqa: T201
        return 1


def handle_validate_criteria(args) -> int:
    """Validate acceptance criteria for a spec."""
    if not args.id:
        print("Error: --id is required for validate criteria")  # noqa: T201
        return 1

    try:
        is_valid, violations = validate_spec_criteria(
            spec_id=args.id,
            docs_root=args.docs_root,
            strict=args.strict,
        )

        if is_valid:
            print(f"Spec {args.id} acceptance criteria validation passed")  # noqa: T201
            return 0
        print(f"Spec {args.id} acceptance criteria validation failed:\n")  # noqa: T201
        for violation in violations:
            print(f"   {violation}")  # noqa: T201
        return 1
    except _NspecCliErrors as e:
        print(f"Validation error: {e}")  # noqa: T201
        return 1


def handle_review_finalize(args) -> int:
    """Finalize a review-packet spec end-to-end (archive + checkboxes + complete)."""
    if not args.id:
        print("Error: --id required")  # noqa: T201
        return 1

    from nspec.workflow.review_workflow import finalize_review_packet_spec

    spec_id = _normalize_spec_ref(args.id)
    try:
        result = finalize_review_packet_spec(
            review_spec_id=spec_id,
            docs_root=args.docs_root,
            archive_date=getattr(args, "date", None),
        )
        print(f"Finalized review spec {result.review_spec_id} (target {result.target_spec_id})")  # noqa: T201
        print(f"   Archived: {result.archived_path}")  # noqa: T201
        print(f"   Completed FR: {result.completed_fr_path}")  # noqa: T201
        print(f"   Completed IMPL: {result.completed_impl_path}")  # noqa: T201
        return 0
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        print(f"Failed to finalize review spec: {e}")  # noqa: T201
        return 1


def handle_create_adr(args) -> int:
    """Create a new ADR."""
    if not args.title:
        print("Error: --title is required for adr create")  # noqa: T201
        return 1

    try:
        adr_id, fr_path = create_adr(args.title, args.docs_root)
        print(f"Created ADR-{adr_id}: {args.title}")  # noqa: T201
        print(f"   {fr_path}")  # noqa: T201
        return 0
    except _NspecCliErrors as e:
        print(f"Error creating ADR: {e}")  # noqa: T201
        return 1


def handle_list_adrs(args) -> int:
    """List all ADRs."""
    try:
        adrs = list_adrs(args.docs_root)
        if not adrs:
            print("No ADRs found (FR-900-999 range)")  # noqa: T201
            return 0

        print(f"\nArchitecture Decision Records ({len(adrs)} total)")  # noqa: T201
        print("=" * 60)  # noqa: T201
        for adr_id, status, title, _path in adrs:
            status_emoji = {
                "DRAFT": "D",
                "PROPOSED": "P",
                "ACCEPTED": "A",
                "DEPRECATED": "!",
                "SUPERSEDED": ">",
            }.get(status.upper(), "?")
            print(f"  ADR-{adr_id}: [{status_emoji}] {status}")  # noqa: T201
            print(f"           {title}")  # noqa: T201
            print()  # noqa: T201
        return 0
    except _NspecCliErrors as e:
        print(f"Error listing ADRs: {e}")  # noqa: T201
        return 1


def handle_repair_collisions(args) -> int:
    """Repair cross-directory spec ID collisions (S909 AC-F5).

    Detects spec IDs present in multiple places (active + completed,
    completed/done + completed/superseded, etc.) and offers per-collision
    resolution: rename-completed (RETIRED suffix), rename-active (next free
    ID), or delete-completed (with --force).
    """
    from datetime import datetime

    from nspec.mutation.lifecycle import find_duplicate_spec_ids
    from nspec.paths import get_paths

    project_root = getattr(args, "project_root", None)
    paths = get_paths(args.docs_root, project_root=project_root)

    duplicates = find_duplicate_spec_ids(args.docs_root, project_root=project_root)
    if not duplicates:
        print("No cross-directory spec ID collisions detected.")  # noqa: T201
        return 0

    print(f"Found {len(duplicates)} colliding spec ID(s):")  # noqa: T201
    for spec_id, paths_list in sorted(duplicates.items()):
        print(f"  {spec_id}:")  # noqa: T201
        for p in paths_list:
            try:
                rel = p.relative_to(args.docs_root)
            except ValueError:
                rel = p
            print(f"    - {rel}")  # noqa: T201

    if getattr(args, "dry_run", False):
        print("\n--dry-run: no changes made.")  # noqa: T201
        return 0

    mode = getattr(args, "mode", None)
    if not mode:
        print(  # noqa: T201
            "\nNo --mode specified. Re-run with one of:\n"
            "  --mode rename-completed   # archive completed file with RETIRED-{ts} suffix\n"
            "  --mode rename-active      # renumber the active file to the next free ID\n"
            "  --mode delete-completed   # delete the completed file (requires --force)\n"
            "Run with --dry-run to preview the collision set without modifying anything."
        )
        return 1

    if mode == "delete-completed" and not getattr(args, "force", False):
        print("--mode delete-completed requires --force (destructive operation).")  # noqa: T201
        return 1

    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")  # noqa: DTZ005
    summary: list[str] = []

    for spec_id, paths_list in sorted(duplicates.items()):
        # Partition into active and archived
        active_paths = [
            p
            for p in paths_list
            if paths.active_frs_dir in p.parents or p.parent == paths.active_frs_dir
        ]
        archived_paths = [p for p in paths_list if p not in active_paths]

        try:
            if mode == "rename-completed":
                # Tag every archived FR (and matching IMPL) with -RETIRED-{ts}
                changes = _retire_completed_files(archived_paths, timestamp, args.docs_root, paths)
                summary.append(f"{spec_id}: retired {len(changes)} file(s) — {', '.join(changes)}")
            elif mode == "rename-active":
                if not active_paths:
                    summary.append(f"{spec_id}: no active file to renumber, skipped")
                    continue
                from nspec.mutation.lifecycle import (
                    get_next_spec_id,
                    renumber_spec,
                )

                fr_path = active_paths[0]
                # Read priority from FR
                import re as _re

                from nspec.domain.statuses import get_priority_line_pattern

                content = fr_path.read_text(encoding="utf-8")
                m = _re.search(get_priority_line_pattern(), content, _re.MULTILINE)
                priority = m.group(1) if m else "P2"
                id_prefix = "E" if spec_id.startswith("E") else "S"
                new_id = get_next_spec_id(
                    priority,
                    args.docs_root,
                    project_root=project_root,
                    id_prefix=id_prefix,
                )
                changes = renumber_spec(
                    spec_id,
                    new_id,
                    fr_path,
                    args.docs_root,
                    project_root=project_root,
                    keep_old_dep=True,
                )
                summary.append(f"{spec_id}: renumbered active → {new_id} ({len(changes)} edit(s))")
            elif mode == "delete-completed":
                deleted = _delete_completed_files(archived_paths)
                summary.append(f"{spec_id}: deleted {len(deleted)} archived file(s)")
            else:
                print(f"Unknown --mode {mode}")  # noqa: T201
                return 1
        except _NspecCliErrors as e:
            summary.append(f"{spec_id}: ERROR — {e}")

    print("\nResults:")  # noqa: T201
    for line in summary:
        print(f"  {line}")  # noqa: T201
    return 0


def _retire_completed_files(
    archived_paths: list[Path], timestamp: str, _docs_root: Path, _paths
) -> list[str]:
    """Rename archived FR/IMPL files to add a -RETIRED-{timestamp} suffix.

    For each archived FR file, also retires the matching IMPL file in the
    same directory. Returns a list of new filenames.
    """
    import re as _re

    renames: list[str] = []
    for fr_path in list(archived_paths):
        if not fr_path.exists():
            continue
        # Extract slug to find matching IMPL
        m = _re.match(r"^FR-([ES]\d+[a-z]?)-(.+)$", fr_path.stem)
        if not m:
            continue
        spec_id, slug = m.group(1), m.group(2)
        # Build retired stem
        new_fr_name = f"FR-{spec_id}-{slug}-RETIRED-{timestamp}.md"
        new_fr_path = fr_path.parent / new_fr_name
        fr_path.rename(new_fr_path)
        renames.append(new_fr_name)

        # Look for matching IMPL in same directory
        impl_path = fr_path.parent / f"IMPL-{spec_id}-{slug}.md"
        if impl_path.exists():
            new_impl_name = f"IMPL-{spec_id}-{slug}-RETIRED-{timestamp}.md"
            new_impl_path = impl_path.parent / new_impl_name
            impl_path.rename(new_impl_path)
            renames.append(new_impl_name)
    return renames


def _delete_completed_files(archived_paths: list[Path]) -> list[Path]:
    """Delete archived FR/IMPL files (and matching IMPL siblings)."""
    import re as _re

    deleted: list[Path] = []
    for fr_path in list(archived_paths):
        if not fr_path.exists():
            continue
        m = _re.match(r"^FR-([ES]\d+[a-z]?)-(.+)$", fr_path.stem)
        if not m:
            continue
        spec_id, slug = m.group(1), m.group(2)
        impl_path = fr_path.parent / f"IMPL-{spec_id}-{slug}.md"
        fr_path.unlink()
        deleted.append(fr_path)
        if impl_path.exists():
            impl_path.unlink()
            deleted.append(impl_path)
    return deleted
