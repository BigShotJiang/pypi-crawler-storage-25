"""Session persistence — DAOs and state classes for nspec sessions.

Provides:
- SessionState: Persistent session state dataclass
- SessionDAO: CRUD for per-session JSON files with active symlink
- CheckoutEntry/CheckoutDAO: Spec reservation with TTL leases
- LoopRetryEntry/LoopRetriesDAO: Per-spec crash/timeout retry tracking
- Convenience functions: load_session, save_session, clear_session
"""

import contextlib
import json
import time
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path


def _generate_session_id(spec_id: str) -> str:
    """Generate a unique session ID: {spec_id}-{compact_utc_timestamp_with_micros}-{pid}.

    Uses microsecond-precision timestamps plus ``os.getpid()`` to guarantee
    uniqueness both within a process (sub-second calls) and across process
    restarts (PID changes).
    """
    import os

    ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{spec_id}-{ts}-{os.getpid()}"


@dataclass
class SessionState:
    """Persistent session state for cross-session handoff.

    Each session is stored as a separate JSON file in the sessions/ directory.
    The active session is indicated by an ``active`` symlink.
    """

    spec_id: str
    session_id: str = ""
    active_epic: str | None = None
    status: str = "active"  # active | completed | abandoned
    last_task: str | None = None
    last_phase: int | None = None  # Pipeline phase: 3-7
    attempts: dict[str, int] = field(default_factory=dict)
    notes: str | None = None
    started_at: str = ""
    updated_at: str = ""
    last_activity: str = ""
    session_start: str = ""
    errors_captured: int = 0
    agent_id: str | None = None
    view_preset: str | None = None
    sort_mode: str | None = None
    sort_direction: str | None = None

    def __post_init__(self) -> None:
        from nspec.runtime.timestamps import now_iso

        now = now_iso()
        if not self.session_id:
            self.session_id = _generate_session_id(self.spec_id)
        if not self.started_at:
            self.started_at = now
        if not self.updated_at:
            self.updated_at = now
        if not self.last_activity:
            self.last_activity = now
        if not self.session_start:
            self.session_start = now


class SessionDAO:
    """Data access object for per-session state files.

    Sessions are stored as individual JSON files under
    ``.novabuilt.dev/nspec/sessions/``. The currently active session
    is indicated by an ``active`` symlink in that directory.

    Session ID format: ``{spec_id}-{YYYYMMDDTHHMMSSZ}``
    """

    def __init__(self, project_root: Path, config: object | None = None) -> None:
        from nspec.config import NspecConfig

        self._project_root = project_root
        if config is None:
            config = NspecConfig.load(project_root)
        self._sessions_dir_name = config.session.sessions_dir  # pyright: ignore[reportAttributeAccessIssue]

    @property
    def sessions_dir(self) -> Path:
        """Absolute path to the sessions directory."""
        return self._project_root / ".novabuilt.dev" / "nspec" / self._sessions_dir_name

    @property
    def active_link(self) -> Path:
        """Path to the ``active`` symlink."""
        return self.sessions_dir / "active"

    @property
    def state_path(self) -> Path:
        """Resolves to the active session file path."""
        link = self.active_link
        if link.exists():
            return link.resolve()
        # No active session — return the link path itself (won't exist)
        return link

    def _session_path(self, session_id: str) -> Path:
        """Path for a session file by ID."""
        return self.sessions_dir / f"{session_id}.json"

    def _ensure_dir(self) -> None:
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    def _set_active_link(self, session_id: str) -> None:
        """Point the ``active`` symlink at the given session file.

        Concurrent-safe: creates a uniquely-named temp symlink first,
        then uses ``os.replace`` to atomically swap it into place. The
        previous unlink-then-symlink pattern had a TOCTOU race where two
        concurrent writers would observe the link as gone, then race to
        ``symlink_to``, with the loser hitting EEXIST.
        """
        import os
        import threading

        link = self.active_link
        target = f"{session_id}.json"  # relative symlink

        # Unique temp name per writer (pid + tid + nanos) — must be
        # unique across concurrent threads in this process.
        tmp_name = f".active.tmp.{os.getpid()}.{threading.get_ident()}.{time.monotonic_ns()}"
        tmp_path = link.parent / tmp_name
        # Best-effort cleanup if a prior crashed run left this name behind
        if tmp_path.is_symlink() or tmp_path.exists():
            tmp_path.unlink()
        tmp_path.symlink_to(target)
        # os.replace is atomic on POSIX even when the target is a symlink
        os.replace(tmp_path, link)

    def _remove_active_link(self) -> None:
        link = self.active_link
        if link.is_symlink() or link.exists():
            link.unlink()

    # -- CRUD ---------------------------------------------------------------

    def create(
        self, spec_id: str, epic_id: str | None = None, agent_id: str | None = None
    ) -> SessionState:
        """Create a new session and set it as active.

        Also auto-checks out the spec if it is not already checked out.
        """
        session_id = _generate_session_id(spec_id)
        state = SessionState(
            spec_id=spec_id,
            session_id=session_id,
            active_epic=epic_id,
            agent_id=agent_id,
        )
        self._ensure_dir()
        path = self._session_path(session_id)
        path.write_text(json.dumps(asdict(state), indent=2) + "\n")
        self._set_active_link(session_id)

        # Auto-checkout the spec (best-effort — don't fail session creation)
        if spec_id:
            try:
                co = CheckoutDAO(self._project_root)
                if not co.is_checked_out(spec_id):
                    co.checkout(spec_id, session_id=session_id, agent_id=agent_id)
            except (ValueError, OSError):
                pass

        return state

    def get(self, session_id: str) -> SessionState | None:
        """Load a session by its ID."""
        path = self._session_path(session_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            return SessionState(**data)
        except (json.JSONDecodeError, TypeError, KeyError):
            return None

    def get_active(self) -> SessionState | None:
        """Load the currently active session (follows symlink)."""
        from nspec.runtime.locks import state_lock

        link = self.active_link
        if not link.is_symlink():
            return None
        try:
            with state_lock(project_root=self._project_root):
                if not link.exists():
                    # Dangling symlink
                    self._remove_active_link()
                    return None
                data = json.loads(link.read_text())
            return SessionState(**data)
        except (json.JSONDecodeError, TypeError, KeyError):
            return None
        except TimeoutError:
            return None

    def list(self, spec_id: str | None = None) -> list[SessionState]:
        """List all sessions, optionally filtered by spec_id."""
        if not self.sessions_dir.exists():
            return []
        sessions: list[SessionState] = []
        for path in sorted(self.sessions_dir.glob("*.json")):
            try:
                data = json.loads(path.read_text())
                state = SessionState(**data)
                if spec_id is None or state.spec_id == spec_id:
                    sessions.append(state)
            except (json.JSONDecodeError, TypeError, KeyError):
                continue
        return sessions

    def update(self, state: SessionState) -> SessionState:
        """Save an updated session back to disk."""
        from nspec.runtime.locks import state_lock
        from nspec.runtime.timestamps import now_iso

        state.updated_at = now_iso()
        self._ensure_dir()
        path = self._session_path(state.session_id)
        with state_lock(project_root=self._project_root):
            path.write_text(json.dumps(asdict(state), indent=2) + "\n")
        return state

    def delete(self, session_id: str) -> bool:
        """Delete a session file. Removes active link if it pointed here."""
        path = self._session_path(session_id)
        if not path.exists():
            return False
        # If active link points to this session, remove it
        link = self.active_link
        if link.is_symlink():
            try:
                if link.resolve() == path.resolve():
                    self._remove_active_link()
            except OSError:
                pass
        path.unlink()
        return True

    def activate(self, session_id: str) -> SessionState | None:
        """Set a session as the active one (updates symlink)."""
        state = self.get(session_id)
        if state is None:
            return None
        self._set_active_link(session_id)
        return state

    def archive(self, session_id: str) -> SessionState | None:
        """Mark a session as completed and remove active link if applicable.

        Also auto-checks in the spec associated with this session.
        """
        state = self.get(session_id)
        if state is None:
            return None
        state.status = "completed"
        self.update(state)
        # Remove active link if it pointed to this session
        link = self.active_link
        if link.is_symlink():
            try:
                if link.resolve() == self._session_path(session_id).resolve():
                    self._remove_active_link()
            except OSError:
                pass

        # Auto-checkin the spec (best-effort)
        if state.spec_id:
            with contextlib.suppress(OSError, TimeoutError):
                CheckoutDAO(self._project_root).checkin(state.spec_id)

        return state

    # -- Convenience methods (backward compat surface) ----------------------

    def load(self) -> SessionState | None:
        """Alias for get_active() — backward compat."""
        return self.get_active()

    def save(self, state: SessionState) -> Path:
        """Save session state. Creates file if needed, sets active link."""
        from nspec.runtime.locks import state_lock
        from nspec.runtime.timestamps import now_iso

        state.updated_at = now_iso()
        self._ensure_dir()
        path = self._session_path(state.session_id)
        with state_lock(project_root=self._project_root):
            path.write_text(json.dumps(asdict(state), indent=2) + "\n")
        # Ensure active link points here
        self._set_active_link(state.session_id)
        return path

    def clear(self) -> bool:
        """Archive active session and remove symlink."""
        state = self.get_active()
        if state is None:
            return False
        self.archive(state.session_id)
        return True

    def save_progress(
        self,
        task_id: str | None = None,
        notes: str | None = None,
        phase: int | None = None,
    ) -> SessionState | None:
        """Update the active session with progress info."""
        state = self.get_active()
        if state is None:
            return None
        if task_id is not None:
            state.last_task = task_id
        if notes is not None:
            state.notes = notes
        if phase is not None:
            state.last_phase = phase
        self.update(state)
        return state

    # -- Field accessors (backward compat) ----------------------------------

    def get_spec_id(self) -> str | None:
        """Read spec_id from active session."""
        state = self.get_active()
        return state.spec_id if state else None

    def get_active_epic(self) -> str | None:
        """Read active_epic from active session."""
        state = self.get_active()
        return state.active_epic if state else None

    def set_spec_id(self, spec_id: str) -> None:
        """Update spec_id on active session, or create a new session."""
        state = self.get_active()
        if state:
            state.spec_id = spec_id
            self.update(state)
        else:
            self.create(spec_id)

    def set_active_epic(self, epic_id: str | None) -> None:
        """Update active_epic on active session."""
        state = self.get_active() or SessionState(spec_id="")
        state.active_epic = epic_id
        self.save(state)

    def increment_errors(self) -> int:
        """Increment the errors_captured counter and return the new value."""
        state = self.get_active() or SessionState(spec_id="")
        state.errors_captured += 1
        self.save(state)
        return state.errors_captured

    def reset_errors(self) -> None:
        """Reset the errors_captured counter to zero."""
        state = self.get_active()
        if state is not None:
            state.errors_captured = 0
            self.update(state)

    def touch_activity(self) -> None:
        """Update ``last_activity`` timestamp (and ``updated_at``) in-place."""
        from nspec.runtime.timestamps import now_iso

        state = self.get_active() or SessionState(spec_id="")
        state.last_activity = now_iso()
        self.save(state)


# ---------------------------------------------------------------------------
# Checkout DAO — spec reservation with TTL
# ---------------------------------------------------------------------------


@dataclass
class CheckoutEntry:
    """A single spec checkout record."""

    session_id: str
    checked_out_at: str
    lease_expires: float
    agent_id: str | None = None


class CheckoutDAO:
    """Data access object for spec checkouts with TTL.

    Checkouts are stored in ``checkouts.json`` alongside session files.
    Each spec can have at most one active (non-expired) checkout.
    Multiple specs can be checked out concurrently up to ``checkout_max``.
    """

    def __init__(self, project_root: Path, config: object | None = None) -> None:
        from nspec.config import NspecConfig

        self._project_root = project_root
        if config is None:
            config = NspecConfig.load(project_root)
        self._sessions_dir_name = config.session.sessions_dir  # pyright: ignore[reportAttributeAccessIssue]
        self._ttl = config.session.checkout_ttl_seconds  # pyright: ignore[reportAttributeAccessIssue]
        self._max = config.session.checkout_max  # pyright: ignore[reportAttributeAccessIssue]

    @property
    def sessions_dir(self) -> Path:
        return self._project_root / ".novabuilt.dev" / "nspec" / self._sessions_dir_name

    @property
    def checkouts_path(self) -> Path:
        return self.sessions_dir / "checkouts.json"

    def _load(self) -> dict[str, dict[str, object]]:
        path = self.checkouts_path
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text())
            return data.get("checkouts", {})
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, checkouts: dict[str, dict[str, object]]) -> None:
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.checkouts_path.write_text(json.dumps({"checkouts": checkouts}, indent=2) + "\n")

    def reap_expired(self) -> list[str]:
        """Remove expired checkouts. Returns list of reaped spec IDs."""
        from nspec.runtime.locks import state_lock

        with state_lock(project_root=self._project_root):
            checkouts = self._load()
            now = time.time()
            expired = [
                sid
                for sid, entry in checkouts.items()
                if float(entry.get("lease_expires", 0)) <= now  # pyright: ignore[reportArgumentType]
            ]
            for sid in expired:
                del checkouts[sid]
            if expired:
                self._save(checkouts)
        return expired

    def checkout(
        self,
        spec_id: str,
        session_id: str = "",
        agent_id: str | None = None,
        ttl: int | None = None,
    ) -> CheckoutEntry:
        """Check out a spec with a TTL lease.

        Raises:
            ValueError: If spec is already checked out or max checkouts reached.
        """
        from nspec.runtime.locks import state_lock
        from nspec.runtime.timestamps import now_iso

        if ttl is None:
            ttl = self._ttl

        with state_lock(project_root=self._project_root):
            checkouts = self._load()
            now = time.time()

            # Reap expired inline
            expired = [
                sid
                for sid, entry in checkouts.items()
                if float(entry.get("lease_expires", 0)) <= now  # pyright: ignore[reportArgumentType]
            ]
            for sid in expired:
                del checkouts[sid]

            # Check if already checked out (non-expired)
            if spec_id in checkouts:
                existing = checkouts[spec_id]
                raise ValueError(
                    f"Spec {spec_id} is already checked out by "
                    f"session {existing.get('session_id', 'unknown')} "
                    f"(agent: {existing.get('agent_id', 'unknown')})"
                )

            # Check max
            if len(checkouts) >= self._max:
                raise ValueError(
                    f"Maximum concurrent checkouts ({self._max}) reached. "
                    f"Checkin a spec before checking out another."
                )

            entry_data: dict[str, object] = {
                "session_id": session_id,
                "checked_out_at": now_iso(),
                "lease_expires": now + ttl,
                "agent_id": agent_id,
            }
            checkouts[spec_id] = entry_data
            self._save(checkouts)

        return CheckoutEntry(
            session_id=str(entry_data["session_id"]),
            checked_out_at=str(entry_data["checked_out_at"]),
            lease_expires=float(entry_data["lease_expires"]),  # pyright: ignore[reportArgumentType]
            agent_id=agent_id,
        )

    def checkin(self, spec_id: str) -> bool:
        """Release a checkout. Returns True if it existed."""
        from nspec.runtime.locks import state_lock

        with state_lock(project_root=self._project_root):
            checkouts = self._load()
            if spec_id not in checkouts:
                return False
            del checkouts[spec_id]
            self._save(checkouts)
        return True

    def heartbeat(self, spec_id: str, ttl: int | None = None) -> CheckoutEntry | None:
        """Extend the lease for a checked-out spec. Returns updated entry or None."""
        from nspec.runtime.locks import state_lock

        if ttl is None:
            ttl = self._ttl

        with state_lock(project_root=self._project_root):
            checkouts = self._load()
            if spec_id not in checkouts:
                return None
            entry = checkouts[spec_id]
            entry["lease_expires"] = time.time() + ttl
            checkouts[spec_id] = entry
            self._save(checkouts)

        return CheckoutEntry(
            session_id=str(entry.get("session_id", "")),
            checked_out_at=str(entry.get("checked_out_at", "")),
            lease_expires=float(entry["lease_expires"]),
            agent_id=entry.get("agent_id"),  # type: ignore[arg-type]
        )

    def get(self, spec_id: str) -> CheckoutEntry | None:
        """Get checkout entry for a spec (None if not checked out or expired)."""
        checkouts = self._load()
        entry = checkouts.get(spec_id)
        if entry is None:
            return None
        if float(entry.get("lease_expires", 0)) <= time.time():  # pyright: ignore[reportArgumentType]
            return None
        return CheckoutEntry(
            session_id=str(entry.get("session_id", "")),
            checked_out_at=str(entry.get("checked_out_at", "")),
            lease_expires=float(entry.get("lease_expires", 0)),  # pyright: ignore[reportArgumentType]
            agent_id=entry.get("agent_id"),  # type: ignore[arg-type]
        )

    def is_checked_out(self, spec_id: str) -> bool:
        """Check if a spec is currently checked out (non-expired)."""
        return self.get(spec_id) is not None

    def list_active(self) -> dict[str, CheckoutEntry]:
        """List all active (non-expired) checkouts."""
        checkouts = self._load()
        now = time.time()
        result: dict[str, CheckoutEntry] = {}
        for sid, entry in checkouts.items():
            if float(entry.get("lease_expires", 0)) > now:  # pyright: ignore[reportArgumentType]
                result[sid] = CheckoutEntry(
                    session_id=str(entry.get("session_id", "")),
                    checked_out_at=str(entry.get("checked_out_at", "")),
                    lease_expires=float(entry.get("lease_expires", 0)),  # pyright: ignore[reportArgumentType]
                    agent_id=entry.get("agent_id"),  # type: ignore[arg-type]
                )
        return result


# ---------------------------------------------------------------------------
# Free functions (delegate to SessionDAO)
# ---------------------------------------------------------------------------


def load_session(project_root: Path) -> SessionState | None:
    """Load active session state from disk."""
    return SessionDAO(project_root).load()


def save_session(state: SessionState, project_root: Path) -> Path:
    """Save session state to disk."""
    return SessionDAO(project_root).save(state)


def clear_session(project_root: Path) -> bool:
    """Archive active session and remove symlink."""
    return SessionDAO(project_root).clear()


# ---------------------------------------------------------------------------
# Loop Retries Persistence (Spec S075)
# ---------------------------------------------------------------------------

LOOP_RETRIES_FILE = ".novabuilt.dev/nspec/loop_retries.json"


@dataclass
class LoopRetryEntry:
    """Per-spec retry tracking for nspec-loop crash resume."""

    count: int = 0
    last_exit: str = ""
    last_failure_at: str = ""


class LoopRetriesDAO:
    """Data access object for loop_retries.json.

    Tracks per-spec crash/timeout counts across loop restarts.
    Separate from session files because session_clear() must not
    wipe retry state.
    """

    def __init__(self, project_root: Path) -> None:
        self._project_root = project_root

    @property
    def retries_path(self) -> Path:
        return self._project_root / LOOP_RETRIES_FILE

    def _load_raw(self) -> dict[str, dict[str, object]]:
        path = self.retries_path
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            return {}

    def _save_raw(self, data: dict[str, dict[str, object]]) -> None:
        path = self.retries_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2) + "\n")

    def increment(self, spec_id: str, exit_reason: str = "") -> int:
        """Increment retry count for a spec. Returns new count."""
        data = self._load_raw()
        entry = data.get(spec_id, {"count": 0, "last_exit": "", "last_failure_at": ""})
        entry["count"] = int(entry.get("count", 0)) + 1  # pyright: ignore[reportArgumentType]
        entry["last_exit"] = exit_reason
        entry["last_failure_at"] = datetime.now().isoformat(timespec="seconds")  # noqa: DTZ005
        data[spec_id] = entry
        self._save_raw(data)
        return int(entry["count"])

    def get_count(self, spec_id: str) -> int:
        """Get current retry count for a spec (0 if not tracked)."""
        data = self._load_raw()
        entry = data.get(spec_id)
        if entry is None:
            return 0
        return int(entry.get("count", 0))  # pyright: ignore[reportArgumentType]

    def clear(self, spec_id: str) -> bool:
        """Remove a single spec's retry entry. Returns True if existed."""
        data = self._load_raw()
        if spec_id not in data:
            return False
        del data[spec_id]
        if data:
            self._save_raw(data)
        else:
            # Delete file when empty
            path = self.retries_path
            if path.exists():
                path.unlink()
        return True

    def list_all(self) -> dict[str, LoopRetryEntry]:
        """Return all retry entries."""
        data = self._load_raw()
        result: dict[str, LoopRetryEntry] = {}
        for spec_id, entry_data in data.items():
            result[spec_id] = LoopRetryEntry(
                count=int(entry_data.get("count", 0)),  # pyright: ignore[reportArgumentType]
                last_exit=str(entry_data.get("last_exit", "")),
                last_failure_at=str(entry_data.get("last_failure_at", "")),
            )
        return result

    def reset(self) -> bool:
        """Delete the entire retries file. Returns True if existed."""
        path = self.retries_path
        if path.exists():
            path.unlink()
            return True
        return False
