"""Runtime infrastructure for nspec.

Submodules:
    atomic     — Atomic file writes and batched write operations
    locks      — File-based locking for specs, queue, and state
    timestamps — ISO timestamp generation
    session    — Session persistence (SessionDAO, CheckoutDAO, LoopRetriesDAO)
"""

from nspec.runtime.atomic import atomic_write, batch_writes, spec_read, spec_write
from nspec.runtime.locks import queue_lock, spec_lock, state_lock
from nspec.runtime.session import (
    CheckoutDAO,
    CheckoutEntry,
    LoopRetriesDAO,
    SessionDAO,
    SessionState,
    clear_session,
    load_session,
    save_session,
)
from nspec.runtime.timestamps import now_iso

__all__ = [
    # session
    "CheckoutDAO",
    "CheckoutEntry",
    "LoopRetriesDAO",
    "SessionDAO",
    "SessionState",
    # atomic
    "atomic_write",
    "batch_writes",
    "clear_session",
    "load_session",
    # timestamps
    "now_iso",
    # locks
    "queue_lock",
    "save_session",
    "spec_lock",
    "spec_read",
    "spec_write",
    "state_lock",
]
