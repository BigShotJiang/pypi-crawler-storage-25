"""MCP mutation tools — state-changing operations."""

from __future__ import annotations

import contextlib
import logging
import re
from pathlib import Path
from typing import Any

from nspec.domain import lifecycle_hints
from nspec.interfaces.mcp._helpers import (
    _attach_branch_warnings,
    _capture_test_gate_error,
    _check_stale_branch,
    _compute_task_progress,
    _dao,
    _exception_error,
    _find_epic_for_spec,
    _get_task_tag,
    _invalid_id_error,
    _normalize_epic_id,
    _post_mutation_validate,
    _resolve_code_root,
    _resolve_docs_root,
    _resolve_id_from_disk,
    _resolve_project_root,
    _run_test_gate,
    _to_bool,
    _tool_error,
    _verify_epic_exists,
)
from nspec.interfaces.mcp.server import mcp
from nspec.runtime.locks import spec_lock


def _read_impl_status_code(impl_path: Path) -> int | None:
    """Read the IMPL status code from a resolved impl file path."""
    from nspec.mutation._helpers import _get_current_status

    try:
        content = impl_path.read_text()
    except OSError:
        return None
    result = _get_current_status(content, kind="IMPL")
    return result[0] if result else None


def _merge_hint(response: dict[str, Any], hint: lifecycle_hints.PhaseHint | None) -> None:
    """Attach a serialized phase hint to an MCP response dict in place."""
    payload = lifecycle_hints.serialize(hint)
    if payload is not None:
        response["next_steps"] = payload


def _impl_status_before_advance(spec_id: str, docs_root: Path) -> int | None:
    """Locate the IMPL file for ``spec_id`` and read its current status code."""
    from nspec.mutation._helpers import _find_impl_file

    try:
        impl_path = _find_impl_file(spec_id, docs_root)
    except Exception:
        return None
    return _read_impl_status_code(impl_path)


def _count_acs(fr_path: Path) -> tuple[int, int]:
    """Count checked vs total acceptance criteria in an FR file.

    Returns (done, total). Returns (0, 0) if the file is unreadable.
    Markers x (complete), ~ (obsolete), and > (deferred) all count as done.
    """
    try:
        content = fr_path.read_text()
    except OSError:
        return 0, 0
    done = len(re.findall(r"^\s*-\s*\[[x~>]\]\s*AC-", content, re.MULTILINE | re.IGNORECASE))
    pending = len(re.findall(r"^\s*-\s*\[\s\]\s*AC-", content, re.MULTILINE))
    return done, done + pending


logger = logging.getLogger("nspec.mcp")


@mcp.tool()
def task_complete(
    spec_id: str,
    task_id: str,
    marker: str = "x",
    run_tests: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an IMPL task as complete.

    By default skips the test gate for fast feedback. The caller
    (e.g. the /loop skill) is expected to run ``make test-quick``
    via Bash where output streams to the terminal.
    Set run_tests=True to run the test gate inside this tool.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1", "dod-1")
        marker: "x" for complete, "~" for obsolete, ">" for deferred
        run_tests: Run test gate before marking (default: False)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.tasks import VERIFICATION_ROUTES

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Check task tag to determine verification route
    task_tag = _get_task_tag(spec_id, task_id, root)
    should_run_tests, verification_hint = VERIFICATION_ROUTES.get(
        task_tag, VERIFICATION_ROUTES["code"]
    )

    if run_tests and should_run_tests:
        test_cwd = _resolve_code_root(project_root) or project_root
        passed, output = _run_test_gate(cwd=test_cwd)
        if not passed:
            _capture_test_gate_error(output, root, spec_id, task_id)
            return {
                "success": False,
                "reason": "Test gate failed — task not marked",
                "test_output": output[-2000:],  # Last 2000 chars
            }

    try:
        with spec_lock(spec_id, project_root=project_root):
            path = _dao(root).tasks.check_task(spec_id, task_id, marker=marker)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Compute progress from the updated file
    progress = _compute_task_progress(path)

    result: dict[str, Any] = {
        "success": True,
        "path": str(path),
        "task_id": task_id,
        "marker": marker,
        "tag": task_tag,
        "verification": verification_hint,
        **progress,
    }

    _merge_hint(
        result,
        lifecycle_hints.hint_for_task_complete(
            spec_id,
            done=int(progress.get("done", 0)),
            total=int(progress.get("total", 0)),
        ),
    )

    _attach_branch_warnings(result, _check_stale_branch(spec_id, root))
    return result


@mcp.tool()
def criteria_complete(
    spec_id: str,
    criteria_id: str,
    marker: str = "x",
    run_tests: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an acceptance criterion as complete in the FR file.

    By default skips the test gate for fast feedback. The caller
    (e.g. the /loop skill) is expected to run ``make test-quick``
    via Bash where output streams to the terminal.
    Set run_tests=True to run the test gate inside this tool.

    Args:
        spec_id: ID (e.g., "S004")
        criteria_id: Criterion ID (e.g., "AC-F1", "AC-Q2")
        marker: "x" for complete, "~" for obsolete, ">" for deferred
        run_tests: Run test gate before marking (default: False)
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    if run_tests:
        test_cwd = _resolve_code_root(project_root) or project_root
        passed, output = _run_test_gate(cwd=test_cwd)
        if not passed:
            _capture_test_gate_error(output, root, spec_id)
            return {
                "success": False,
                "reason": "Test gate failed — criterion not marked",
                "test_output": output[-2000:],
            }

    try:
        with spec_lock(spec_id, project_root=project_root):
            path = _dao(root).tasks.check_criteria(spec_id, criteria_id, marker=marker)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    ac_done, ac_total = _count_acs(path)
    result: dict[str, Any] = {
        "success": True,
        "path": str(path),
        "criteria_id": criteria_id,
        "marker": marker,
        "ac_done": ac_done,
        "ac_total": ac_total,
    }
    _merge_hint(
        result,
        lifecycle_hints.hint_for_criteria_complete(spec_id, done=ac_done, total=ac_total),
    )
    _attach_branch_warnings(result, _check_stale_branch(spec_id, root))
    return result


@mcp.tool()
def activate(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Activate a spec by advancing its status and writing the active session.

    Sets IMPL to Active and FR to Active, and persists the spec ID
    to the active session file for tool integration.

    Args:
        spec_id: Spec ID to activate
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import CheckoutDAO, SessionDAO

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Reap expired checkouts and check for conflicts
    try:
        co_dao = CheckoutDAO(project_root)
        co_dao.reap_expired()
        existing = co_dao.get(spec_id)
        if existing:
            # Allow if same session, reject if different
            active_session = SessionDAO(project_root).get_active()
            active_sid = active_session.session_id if active_session else None
            if existing.session_id and existing.session_id != active_sid:
                return _tool_error(
                    f"Spec {spec_id} is checked out by session "
                    f"{existing.session_id} (agent: {existing.agent_id}). "
                    f"Checkin first or wait for lease to expire."
                )
    except (OSError, TimeoutError):
        pass  # Best-effort — don't block activation on checkout failures

    try:
        with spec_lock(spec_id, project_root=project_root):
            # Set FR=Active(2), IMPL=Active(1)
            fr_path, impl_path = _dao(root).status.set_status(spec_id, 2, 1)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Persist session context to active session
    dao = SessionDAO(project_root)
    try:
        if spec_id.startswith("E"):
            dao.set_active_epic(spec_id)
            dao.set_spec_id("")
            epic_id = spec_id
        else:
            dao.set_spec_id(spec_id)
            epic_id = _find_epic_for_spec(spec_id, root)
            if epic_id:
                with contextlib.suppress(Exception):
                    dao.set_active_epic(epic_id)
    except Exception as e:
        return _exception_error(e)

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "epic_id": epic_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }
    _merge_hint(result, lifecycle_hints.hint_for_activate(spec_id))
    _attach_branch_warnings(result, _check_stale_branch(spec_id, root))
    return result


@mcp.tool()
def advance(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Advance a spec to the next logical status.

    Progresses IMPL through: Planning -> Active -> Testing -> Ready.
    Also auto-upgrades FR status when appropriate.

    Args:
        spec_id: Spec ID to advance
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.mutation import check_state_pair_warning

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    # Read IMPL status before the transition so we can emit a phase-aware hint
    # once the advance succeeds. Missing file / parse failure → skip the hint.
    prev_status = _impl_status_before_advance(spec_id, root)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).status.next_status(spec_id)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except ValueError as e:
        error_msg = str(e)
        # Provide structured hints for terminal states
        # Inspect the error message text from the state machine to produce
        # structured hints. Lowercase comparison keeps this distinct from the
        # `"<STATE>" in <expr>.status` pattern that AC-F5 bans, and sidesteps
        # naive grep-based regression checks that only look at capitalized
        # status literals.
        _error_lower = error_msg.lower()
        if "already ready" in _error_lower:
            return {
                "success": False,
                "error": "IMPL already Ready (3) - use complete() to archive",
                "hint": f"Use complete(spec_id='{spec_id}') to archive this spec.",
            }
        if "paused" in _error_lower:
            return {
                "success": False,
                "error": error_msg,
                "hint": f"Use activate(spec_id='{spec_id}') to resume the spec, then advance.",
            }
        if "exception" in _error_lower:
            return {
                "success": False,
                "error": error_msg,
                "hint": "This spec requires human triage before it can proceed.",
            }
        return _exception_error(e)
    except Exception as e:
        return _exception_error(e)
    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }
    # Soft warning if resulting state pair is unusual per VALID_STATE_PAIRS
    warning = check_state_pair_warning(spec_id, root)
    if warning:
        result["warning"] = warning
    new_status = _read_impl_status_code(Path(impl_path))
    _merge_hint(
        result,
        lifecycle_hints.hint_for_advance(spec_id, prev_status, new_status),
    )
    _attach_branch_warnings(result, _check_stale_branch(spec_id, root))
    return result


@mcp.tool()
def execute_agent(  # noqa: C901
    prompt: str | None = None,
    prompt_file: str | None = None,
    timeout: int | None = None,
    model: str | None = None,
    reasoning_effort: str | None = None,
    sandbox: str | None = None,
    approval_policy: str | None = None,
    flags: list[str] | None = None,
    docs_root: str | None = None,
    purpose: str = "review",
    review_token: str | None = None,
) -> dict[str, Any]:
    """Execute a prompt via the configured agent for the given purpose.

    Dispatches to the agent specified by the purpose-specific config section:
    ``[review].agent`` for reviews, ``[refinement].agent`` for refinements.
    Uses tmux (preferred) or subprocess fallback.

    Exactly one of ``prompt`` or ``prompt_file`` must be provided. When
    ``prompt_file`` is given, the agent is told to read its instructions
    from the file — this avoids embedding large prompts into the tmux
    command string (which hits OS argument-length limits).

    When ``purpose="review"`` and ``review_token`` is provided, the token
    is consumed and a ``verdict_token`` is returned proving the review was
    dispatched to an external agent (delegation integrity guard, S311).

    Args:
        prompt: The prompt text to send to the agent (mutually exclusive
            with prompt_file).
        prompt_file: Path to a file containing the prompt text. The agent
            is instructed to read this file (mutually exclusive with prompt).
        timeout: Timeout in seconds (default: from config or 600).
        model: Model override (default: from agent config).
        reasoning_effort: Reasoning effort override (default: from agent config).
        sandbox: Sandbox mode override (default: from agent config).
        approval_policy: Approval policy override (default: from agent config).
        flags: Extra CLI flags (default: from agent config).
        docs_root: Path to docs directory (default: ./docs)
        purpose: Which config section to use: ``"review"`` or ``"refinement"``.
        review_token: Review token from review_spec(). When provided for
            purpose="review", consumed and replaced with a verdict_token.
    """
    # Normalize empty strings to None for uniform validation
    if prompt is not None and not prompt.strip():
        prompt = None
    if prompt_file is not None and not prompt_file.strip():
        prompt_file = None

    # Validate prompt source: exactly one of prompt or prompt_file
    if prompt is not None and prompt_file is not None:
        return _tool_error("Cannot specify both 'prompt' and 'prompt_file'. Provide exactly one.")
    if prompt is None and prompt_file is None:
        return _tool_error(
            "Must provide either 'prompt' (inline text) or 'prompt_file' (path to file)."
        )

    # Delegate file reading to the agent — avoids embedding large file
    # content into the tmux command string (which hits OS arg-length limits).
    if prompt_file is not None:
        prompt_path = Path(prompt_file).resolve()
        if not prompt_path.exists():
            return _tool_error(f"Prompt file not found: {prompt_file}")
        prompt = (
            f"Read this prompt file for your full instructions: {prompt_path}\n"
            "It contains the review criteria, code changes, and acceptance criteria."
        )

    # At this point prompt is guaranteed to be a non-None string
    assert prompt is not None  # for type checker  # noqa: S101

    from nspec.config import NspecConfig
    from nspec.orchestration.executor import resolve_executor

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except Exception:
        config = NspecConfig()

    # Select config section based on purpose
    valid_purposes = ("review", "refinement", "handoff")
    if purpose not in valid_purposes:
        return _tool_error(f"Invalid purpose: {purpose!r}. Must be one of {valid_purposes}.")
    if purpose == "refinement":
        agent_section = config.refinement
    elif purpose == "handoff":
        agent_section = config.handoff
    else:
        agent_section = config.review

    agent_name = agent_section.agent
    executor = resolve_executor(agent_name, config)

    kwargs: dict[str, Any] = {}

    # Read model/effort overrides from the purpose-specific, agent-specific
    # config subsection (e.g., [review.claude], [refinement.gemini]).
    # CLI parameter overrides always take precedence.
    agent_sub = getattr(agent_section, agent_name, None)

    if model is not None:
        kwargs["model"] = model
    elif agent_sub is not None and hasattr(agent_sub, "model"):
        kwargs["model"] = agent_sub.model
    if reasoning_effort is not None:
        kwargs["reasoning_effort"] = reasoning_effort
    elif agent_sub is not None and hasattr(agent_sub, "effort"):
        kwargs["reasoning_effort"] = agent_sub.effort
    if sandbox is not None:
        kwargs["sandbox"] = sandbox
    if approval_policy is not None:
        kwargs["approval_policy"] = approval_policy
    if flags is not None:
        kwargs["flags"] = flags

    # Integration mode: run agent in the code_root directory
    code_root = config.resolve_code_root()
    if code_root is not None:
        kwargs["cwd"] = code_root

    result = executor.execute(
        prompt,
        timeout=timeout or agent_section.timeout,
        **kwargs,
    )

    # S371: persist agent output to disk and only return a small snippet inline.
    # Large review outputs (>~50KB) were oversizing MCP responses and triggering
    # server disconnects. The caller can read the full output from output_path.
    output_path: str | None = None
    output_snippet: str = ""
    if result.output:
        from datetime import UTC, datetime

        out_dir = project_root / "work" / "agent-output"
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(tz=UTC).strftime("%Y%m%d-%H%M%S")
        # Sanitize filename components to prevent path traversal or invalid
        # filesystem chars from purpose/agent_name (defense-in-depth — these
        # come from config but should never be able to escape the out_dir).
        safe_purpose = re.sub(r"[^A-Za-z0-9_.-]", "_", purpose) or "agent"
        safe_agent = re.sub(r"[^A-Za-z0-9_.-]", "_", agent_name) or "unknown"
        out_file = out_dir / f"{safe_purpose}-{safe_agent}-{ts}.txt"
        out_file.write_text(result.output, encoding="utf-8")
        output_path = str(out_file)

        # Inline snippet: head + tail when oversized; verdict-bearing tail
        # is what callers actually need to parse.
        snippet_max = 8000  # ~8KB inline budget
        if len(result.output) <= snippet_max:
            output_snippet = result.output
        else:
            head_len = snippet_max // 4
            tail_len = snippet_max - head_len
            output_snippet = (
                result.output[:head_len]
                + f"\n\n[... {len(result.output) - snippet_max} bytes truncated; "
                + f"full output at {out_file.name} ...]\n\n"
                + result.output[-tail_len:]
            )

    response: dict[str, Any] = {
        "success": result.success,
        "output": output_snippet,
        "output_path": output_path,
        "output_bytes": len(result.output) if result.output else 0,
        "error": result.error,
        "duration_s": result.duration_s,
        "agent": agent_name,
        "purpose": purpose,
    }

    # Generate verdict_token when review_token is provided for review purpose.
    # Use the full output (not the snippet) for token derivation so the HMAC
    # keys off the actual reviewer payload.
    if purpose == "review" and review_token and result.success and result.output:
        from nspec.workflow.review import generate_verdict_token, resolve_spec_from_review_token

        # Resolve spec_id from the review_token file (tamper-proof — not from prompt)
        spec_id = resolve_spec_from_review_token(review_token, project_root)
        if spec_id:
            verdict_token = generate_verdict_token(
                spec_id, project_root, review_token, result.output, agent=agent_name
            )
            if verdict_token:
                response["verdict_token"] = verdict_token
            else:
                response["verdict_token_error"] = (
                    "Failed to generate verdict_token — review_token may be "  # noqa: S105
                    "invalid or already consumed."
                )
        else:
            response["verdict_token_error"] = (
                "Could not resolve spec_id from review_token — token may be invalid or expired."  # noqa: S105
            )

    return response


@mcp.tool()
def review_spec(
    spec_id: str,
    docs_root: str | None = None,
    uncommitted: bool = False,
    base_branch: str | None = None,
    commit_sha: str | None = None,
    test_results: str | None = None,
) -> dict[str, Any]:
    """Generate a review prompt for a spec to use with execute_agent().

    Writes the assembled review prompt to ``work/review-prompts/`` and
    returns the file path as ``prompt_file``. Pass the path to
    ``execute_agent(prompt_file=...)`` to execute the review.

    This tool is REQUIRED before calling complete(). The complete() tool
    will refuse to archive a spec without an APPROVED review verdict.

    Args:
        spec_id: Spec ID to review (e.g., "S020")
        docs_root: Path to docs directory (default: ./docs)
        uncommitted: Review staged and unstaged changes against HEAD (default: False)
        base_branch: Review changes against this branch
        commit_sha: Review changes from a specific commit
        test_results: Test output from make test-quick (included as receipt for reviewer)
    """
    from nspec.workflow.review import prepare_mcp_review

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    project_root = _resolve_project_root(root)
    code_root = _resolve_code_root(project_root)

    try:
        request = prepare_mcp_review(
            spec_id,
            root,
            uncommitted=uncommitted,
            base_branch=base_branch,
            commit_sha=commit_sha,
            code_root=code_root,
            test_results=test_results or "(not provided)",
        )

        # Issue a single-use review token to prove the flow went through review_spec()
        from nspec.config import NspecConfig
        from nspec.workflow.review import generate_review_token

        try:
            cfg = NspecConfig.load(project_root)
            review_agent = cfg.review.agent
            ttl_hours = cfg.review.token_ttl_hours
        except Exception:
            return {
                "success": False,
                "spec_id": spec_id,
                "error": "Cannot generate review token: no review agent configured.",
                "hint": "Set [review].agent in .novabuilt.dev/nspec/config.toml",
            }
        token = generate_review_token(
            spec_id, project_root, agent=review_agent, ttl_hours=ttl_hours
        )

        # Write prompt to file instead of returning inline
        from datetime import UTC, datetime

        prompt_dir = project_root / "work" / "review-prompts"
        prompt_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(tz=UTC).strftime("%Y%m%d-%H%M%S")
        prompt_path = prompt_dir / f"{spec_id}-{ts}.md"
        prompt_path.write_text(request.prompt, encoding="utf-8")

        return {
            "success": True,
            "spec_id": spec_id,
            "prompt_file": str(prompt_path),
            "review_token": token,
            "hint": (
                "Pass the prompt_file to execute_agent(prompt_file=..., "
                "review_token=token) to execute the review. Then call "
                "write_review_verdict with the verdict_token from the "
                "execute_agent response."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def review(
    spec_id: str,
    docs_root: str | None = None,
    base_branch: str | None = None,
    uncommitted: bool = False,
    test_results: str | None = None,
    implementer: str = "claude",
) -> dict[str, Any]:
    """Execute an atomic review cycle for a spec.

    For external review agents (codex, gemini), orchestrates the full
    review pipeline server-side: generate prompt, dispatch to agent,
    parse verdict, store raw output, and write findings to IMPL.
    The implementing agent receives only the structured verdict and
    findings summary — never the raw review output.

    For self-review (agent="claude"), returns the decomposed path
    components (prompt_file + review_token) so the implementing agent
    can perform the review itself. The prompt is written to a file
    under ``work/review-prompts/`` to avoid inflating the response.

    Args:
        spec_id: Spec ID to review (e.g., "S309")
        docs_root: Path to docs directory (default: ./docs)
        base_branch: Review changes against this branch
        uncommitted: Include staged/unstaged changes in diff
        test_results: Test output from make test-quick (receipt for reviewer)
        implementer: Implementer name (default: "claude")
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    project_root = _resolve_project_root(root)

    # Load config to determine review agent
    try:
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        review_agent = config.review.agent
    except Exception:
        review_agent = "codex"

    is_self_review = review_agent == "claude"

    if is_self_review:
        # Self-review: fall back to decomposed path (review_spec + write_review_verdict)
        return review_spec(
            spec_id=spec_id,
            docs_root=docs_root,
            base_branch=base_branch,
            uncommitted=uncommitted,
            test_results=test_results,
        )

    # External agent: atomic review
    from nspec.workflow.review import ApprovalEvidenceError
    from nspec.workflow.review import atomic_review as _atomic_review

    try:
        result = _atomic_review(
            spec_id,
            root,
            project_root=project_root,
            base_branch=base_branch,
            uncommitted=uncommitted,
            test_results=test_results or "(not provided)",
            implementer=implementer,
        )
        response: dict[str, Any] = {
            "success": True,
            "spec_id": result.spec_id,
            "verdict": result.verdict,
            "findings": result.findings,
            "review_round": result.review_round,
            "reviewer": result.reviewer,
            "mode": "atomic",
            "hint": (
                "Review complete. Verdict and findings have been written to the IMPL. "
                "Raw output stored at: " + result.raw_output_path
            ),
        }
        _merge_hint(
            response,
            lifecycle_hints.hint_for_review(result.spec_id, result.verdict),
        )
        return response
    except ApprovalEvidenceError as e:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": str(e),
            "unchecked_acs": e.result.unchecked_acs,
            "incomplete_tasks": e.result.incomplete_tasks,
            "test_gate_ran": e.result.test_gate_ran,
            "test_gate_passed": e.result.test_gate_passed,
            "hint": (
                "Review agent returned APPROVED but the spec has unchecked "
                "ACs/tasks. Check off remaining items and retry the review."
            ),
        }
    except RuntimeError as e:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": str(e),
            "hint": "The review agent failed. Check agent configuration and try again.",
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_review_verdict(  # noqa: C901
    spec_id: str,
    verdict: str,
    feedback: str | None = None,
    reviewer: str | None = None,
    implementer: str = "claude",
    review_token: str | None = None,
    verdict_token: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write a review verdict to the IMPL file.

    Use this tool after obtaining a review verdict from the configured review agent
    (via execute_agent). This separates prompt generation and
    verdict writing from the actual review execution, enabling flexible
    review backends.

    **Anti-rubber-stamping guards:**
    - A ``review_token`` (from ``review_spec()``) is required. This proves
      the review flow was initiated through the proper channel.

    **Delegation integrity guard (S311):**
    - When the configured review agent is external (not ``"claude"``), a
      ``verdict_token`` from ``execute_agent()`` is required. This proves
      the review was dispatched to an external agent, not self-reviewed.
    - When ``[review].agent = "claude"`` (self-review mode), the
      ``review_token`` alone is sufficient — no ``verdict_token`` needed.

    **Reviewer resolution:** If ``reviewer`` is provided, it is used as-is
    (override). If omitted, falls back to ``[review].agent`` from config.toml.
    If neither is available, returns an error with guidance.

    Typical workflow:
    1. Call review_spec(spec_id, base_branch="main") to get the review prompt and review_token
    2. Call execute_agent(prompt=..., review_token=token) to execute the review
    3. Parse the response content for P-level findings (P0/P1 → NEEDS_WORK) or "VERDICT:" line
    4. Call this tool with the verdict_token from step 2

    Args:
        spec_id: Spec ID (e.g., "S020")
        verdict: "APPROVED" or "NEEDS_WORK"
        feedback: Optional feedback text (shown in IMPL findings section)
        reviewer: Reviewer name (default: configured review agent)
        implementer: Implementer name (default: "claude")
        review_token: Single-use token from review_spec() (required for self-review)
        verdict_token: Single-use token from execute_agent() (required for external review)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.workflow.review import (
        ApprovalEvidenceError,
        ReviewVerdict,
        consume_review_token,
        consume_verdict_token,
        validate_review_token,
        validate_verdict_token,
        write_review_to_impl,
    )

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Load config for reviewer default
    try:
        from nspec.config import NspecConfig

        project_root = _resolve_project_root(root)
        cfg = NspecConfig.load(project_root)
        configured_review_agent = cfg.review.agent
    except Exception:
        project_root = _resolve_project_root(root)
        cfg = None
        configured_review_agent = None

    # --- Guard 0: Early FR state check (S348) ---
    # Detect when the FR is still in Proposed state before consuming any
    # tokens. The write_review_to_impl path will eventually call
    # approve_review → set_status(fr=3, impl=3), which requires
    # FR to be Active (2). Catching this early gives a helpful error
    # instead of a cryptic "Invalid FR transition" deep in set_status.
    try:
        from nspec.mutation._helpers import _get_current_status
        from nspec.paths import get_paths

        paths = get_paths(root, project_root=project_root)
        fr_pattern = f"FR-{spec_id}-*.md"
        fr_files = list(paths.active_frs_dir.glob(fr_pattern))
        if not fr_files:
            fr_files = list(paths.completed_frs_dir.glob(fr_pattern))
        if fr_files:
            fr_content = fr_files[0].read_text()
            fr_status = _get_current_status(fr_content, kind="FR")
            if fr_status is not None:
                fr_code, fr_emoji, fr_text = fr_status
                if fr_code < 2:  # Proposed (0) or In Design (1) — not yet Active
                    return {
                        "success": False,
                        "spec_id": spec_id,
                        "error": (
                            f"FR is in {fr_emoji} {fr_text} state — cannot write "
                            f"review verdict. Call activate(spec_id='{spec_id}') "
                            f"first to move the FR through Active."
                        ),
                        "hint": (
                            f"activate('{spec_id}') transitions the FR to Active "
                            f"and the IMPL to Active, which is required before "
                            f"review verdicts can be written."
                        ),
                    }
    except Exception:  # noqa: S110
        pass  # Best-effort check — fall through to let write_review_to_impl fail naturally

    # Resolve reviewer: explicit param > config > error
    # Guard: when an external review agent is configured, prevent reviewer override
    if (
        reviewer is not None
        and configured_review_agent
        and configured_review_agent != "claude"
        and reviewer != configured_review_agent
    ):
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                f"Reviewer mismatch: '{reviewer}' does not match configured "
                f"review agent '{configured_review_agent}'. "
                f"Cannot override reviewer when an external agent is configured."
            ),
            "hint": (
                f"Use reviewer='{configured_review_agent}' or omit the reviewer "
                f"parameter to use the configured agent."
            ),
        }
    if reviewer is not None:
        pass  # Use the provided override (validated above)
    elif configured_review_agent:
        reviewer = configured_review_agent
    else:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": "No reviewer specified and no review agent configured.",
            "hint": (
                "Either pass reviewer='agent_name' or set [review].agent "
                "in .novabuilt.dev/nspec/config.toml"
            ),
        }

    # --- Guard 2: Token chain validation (delegation integrity, S311) ---
    is_self_review = configured_review_agent == "claude"

    if is_self_review:
        # Self-review mode: review_token is sufficient (no external dispatch needed)
        if not review_token:
            return {
                "success": False,
                "spec_id": spec_id,
                "error": "review_token is required. Call review_spec() first to get a token.",
                "hint": (
                    "Workflow: review_spec(spec_id) → review code → "
                    "write_review_verdict(spec_id, verdict, review_token=token)"
                ),
            }
    else:
        # External agent mode (S092/S309): require verdict_token to prove the
        # review was dispatched through execute_agent().  The verdict_token is
        # generated by execute_agent() after consuming the review_token, so
        # its presence proves the full chain: review_spec → execute_agent →
        # write_review_verdict.  Without a valid verdict_token the call is
        # rejected — preventing the implementing agent from self-reviewing.
        if not verdict_token:
            return {
                "success": False,
                "spec_id": spec_id,
                "error": (
                    f"verdict_token is required when the review agent is external "
                    f"('{configured_review_agent}'). "
                    f"Call review_spec() then execute_agent(review_token=token) "
                    f"to obtain a verdict_token, or use review(spec_id) for the "
                    f"atomic path."
                ),
                "hint": (
                    "Decomposed workflow: review_spec(spec_id) → "
                    "execute_agent(prompt=..., review_token=token) → "
                    "write_review_verdict(spec_id, verdict, verdict_token=token)"
                ),
            }

    # Validate verdict
    verdict_upper = verdict.upper()
    if verdict_upper not in ("APPROVED", "NEEDS_WORK"):
        return {
            "success": False,
            "spec_id": spec_id,
            "error": f"Invalid verdict: {verdict}. Must be APPROVED or NEEDS_WORK.",
        }

    # S903: refuse degenerate APPROVED verdicts. Catches the rubber-stamp
    # failure mode where codex died (tmux pane death) and the implementer
    # agent forwarded the death-message string as the "finding", or where
    # `_get_git_diff` returned the no-diff sentinel and codex hallucinated
    # an APPROVED on an empty prompt.
    feedback_str = feedback or ""
    if verdict_upper == "APPROVED":
        degenerate_markers = (
            "Pane is dead",
            "(no git diff available)",
        )
        matched_marker = next((m for m in degenerate_markers if m in feedback_str), None)
        if matched_marker is not None:
            return {
                "success": False,
                "spec_id": spec_id,
                "error": (
                    f"Refusing APPROVED verdict: feedback contains degenerate "
                    f"marker {matched_marker!r}. The reviewer process likely "
                    f"died or received an empty diff. Re-run the review."
                ),
            }

    # Create ReviewVerdict and write to IMPL
    review_verdict = ReviewVerdict(
        verdict=verdict_upper,
        feedback=feedback_str,
        raw_output="",  # No raw output when using MCP backend
    )

    try:
        with spec_lock(spec_id):
            # S348: Validate + write + consume all inside spec_lock.
            # The lock serializes concurrent access, eliminating TOCTOU.
            # Token is validated (not consumed) before the write, then
            # consumed only after a successful write. Failed writes leave
            # the token file intact for retry.
            token_agent = configured_review_agent or reviewer
            if (
                is_self_review
                and review_token
                and not validate_review_token(
                    spec_id, review_token, project_root, agent=token_agent
                )
            ):
                return {
                    "success": False,
                    "spec_id": spec_id,
                    "error": "Invalid or already-used review_token.",
                    "hint": (
                        "Each token is single-use. Call review_spec() again to get a new token."
                    ),
                }

            # S092: Validate verdict_token for external agent reviews.
            # The token proves execute_agent() was called with a valid
            # review_token.  Validated (not consumed) before the write;
            # consumed only after success to allow retry on write failure.
            if (
                not is_self_review
                and verdict_token
                and not validate_verdict_token(spec_id, verdict_token, project_root)
            ):
                return {
                    "success": False,
                    "spec_id": spec_id,
                    "error": "Invalid or already-used verdict_token.",
                    "hint": (
                        "Each verdict_token is single-use. Run the decomposed "
                        "review flow again: review_spec() → execute_agent() → "
                        "write_review_verdict()."
                    ),
                }

            impl_path = write_review_to_impl(
                spec_id,
                review_verdict,
                reviewer,
                implementer,
                root,
            )

            # Write succeeded — now consume tokens (single-use).
            if is_self_review and review_token:
                consume_review_token(spec_id, review_token, project_root, agent=token_agent)
            if not is_self_review and verdict_token:
                consume_verdict_token(spec_id, verdict_token, project_root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except ApprovalEvidenceError as e:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": str(e),
            "unchecked_acs": e.result.unchecked_acs,
            "incomplete_tasks": e.result.incomplete_tasks,
            "test_gate_ran": e.result.test_gate_ran,
            "test_gate_passed": e.result.test_gate_passed,
            "hint": (
                "Check off the listed ACs via criteria_complete() and "
                "tasks via task_complete() before requesting APPROVED, "
                "or record a NEEDS_WORK verdict instead."
            ),
        }
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "verdict": verdict_upper,
        "reviewer": reviewer,
        "implementer": implementer,
        "impl_path": str(impl_path),
    }


@mcp.tool()
def refine_impl(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Check if an IMPL is a skeleton and generate a refinement prompt.

    Detects template placeholder tasks in the IMPL file. If the IMPL is
    a skeleton, returns a prompt for the configured agent to generate real tasks.
    If the IMPL already has real tasks, returns `{is_skeleton: False}`.

    Typical workflow:
    1. Call refine_impl(spec_id) to check and get the prompt
    2. If is_skeleton is True, call execute_agent(prompt=...)
    3. Call write_refinement(spec_id, agent_output) with the response content

    Args:
        spec_id: Spec ID to check/refine (e.g., "S077")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.workflow.refine import generate_refinement_prompt, is_skeleton_impl

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    try:
        from nspec.mutation import _find_impl_file

        impl_path = _find_impl_file(spec_id, root)
        impl_content = impl_path.read_text()
    except FileNotFoundError:
        return _tool_error(f"IMPL file not found for {spec_id}")

    if not is_skeleton_impl(impl_content):
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": False,
            "message": f"IMPL for {spec_id} already has real tasks — no refinement needed.",
        }

    try:
        prompt = generate_refinement_prompt(spec_id, root)
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": True,
            "prompt": prompt.prompt_text,
            "hint": (
                "Use this prompt with execute_agent(prompt=..., purpose='refinement') "
                "to refine. Then call write_refinement with the response content."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_refinement(
    spec_id: str,
    agent_output: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write agent refinement output to the IMPL file.

    Parses the agent output for refined tasks (between TASKS_START/TASKS_END),
    executive summary, and LOE, then writes them to the IMPL.

    Use this after calling execute_agent(prompt=...) with the prompt
    from refine_impl(). Pass the response content as agent_output.

    Args:
        spec_id: Spec ID (e.g., "S077")
        agent_output: Raw text output (content field) from agent response
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.workflow.refine import parse_refinement_result, write_refinement_to_impl

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Parse the agent output
    result = parse_refinement_result(agent_output)
    if result is None:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                "Could not parse refinement output. "
                "Expected TASKS_START/TASKS_END delimiters in agent response."
            ),
        }

    try:
        with spec_lock(spec_id):
            impl_path = write_refinement_to_impl(spec_id, result, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Count tasks in refined output
    import re

    task_count = len(re.findall(r"^\s*- \[ \]", result.tasks_markdown, re.MULTILINE))

    # Auto-compute LOE if refinement didn't provide one
    loe_value = result.loe
    if not loe_value or loe_value == "N/A":
        try:
            from nspec.config import NspecConfig
            from nspec.domain.datasets import DatasetLoader
            from nspec.domain.loe import LoeWeights, estimate_spec_loe

            project_root = _resolve_project_root(root)
            try:
                config = NspecConfig.load(project_root)
            except Exception:
                config = NspecConfig()
            loader = DatasetLoader(docs_root=root, project_root=project_root)
            datasets = loader.load()
            fr = datasets.get_fr(spec_id)
            impl = datasets.get_impl(spec_id)
            if fr and impl:
                weights = LoeWeights(
                    task_count=config.loe.weight_task_count,
                    max_depth=config.loe.weight_max_depth,
                    nested_ratio=config.loe.weight_nested_ratio,
                    dep_count=config.loe.weight_dep_count,
                    complexity_signal=config.loe.weight_complexity_signal,
                    min_history_specs=config.loe.min_history_specs,
                )
                estimate = estimate_spec_loe(
                    spec_id=spec_id,
                    fr=fr,
                    impl=impl,
                    weights=weights,
                    completed_impls=datasets.completed_impls,
                    completed_frs=datasets.completed_frs,
                )
                loe_value = estimate.estimated_loe
                from nspec.mutation import set_loe

                set_loe(spec_id, loe_value, root, project_root=project_root)
        except Exception:  # noqa: S110
            pass  # LOE auto-compute is best-effort; don't fail refinement

    return {
        "success": True,
        "spec_id": spec_id,
        "impl_path": str(impl_path),
        "task_count": task_count,
        "loe": loe_value,
        "executive_summary": result.executive_summary,
    }


@mcp.tool()
def refine_fr(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Check if an FR is a skeleton and generate an authoring prompt.

    Detects template placeholder content in the FR file. If the FR is
    a skeleton, returns a prompt for the configured agent to author real FR content.
    If the FR already has real content, returns `{is_skeleton: False}`.

    Typical workflow:
    1. Call refine_fr(spec_id) to check and get the prompt
    2. If is_skeleton is True, call execute_agent(prompt=...)
    3. Call write_fr_refinement(spec_id, agent_output) with the response content

    Args:
        spec_id: Spec ID to check/refine (e.g., "S129")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.workflow.refine import generate_fr_refinement_prompt, is_skeleton_fr

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    try:
        from nspec.paths import get_paths

        paths = get_paths(root)
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            return _tool_error(f"FR file not found for {spec_id}")
        fr_content = fr_files[0].read_text()
    except FileNotFoundError:
        return _tool_error(f"FR file not found for {spec_id}")

    if not is_skeleton_fr(fr_content):
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": False,
            "message": f"FR for {spec_id} already has real content — no authoring needed.",
        }

    try:
        prompt = generate_fr_refinement_prompt(spec_id, root)
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": True,
            "prompt": prompt.prompt_text,
            "hint": (
                "Use this prompt with execute_agent(prompt=..., purpose='refinement') "
                "to refine. Then call write_fr_refinement with the response content."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_fr_refinement(
    spec_id: str,
    agent_output: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write agent FR authoring output to the FR file.

    Parses the agent output for authored FR content (between FR_START/FR_END),
    then writes it to the FR file, replacing template placeholders.

    Use this after calling execute_agent(prompt=...) with the prompt
    from refine_fr(). Pass the response content as agent_output.

    Args:
        spec_id: Spec ID (e.g., "S129")
        agent_output: Raw text output (content field) from agent response
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.workflow.refine import parse_fr_refinement_result
    from nspec.workflow.refine import write_fr_refinement as _write_fr_refinement

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Parse the agent output
    result = parse_fr_refinement_result(agent_output)
    if result is None:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                "Could not parse FR authoring output. "
                "Expected FR_START/FR_END delimiters in agent response."
            ),
        }

    try:
        with spec_lock(spec_id):
            fr_path = _write_fr_refinement(spec_id, result, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
    }


def _complete_inner(  # noqa: C901
    spec_id: str,
    root: Path,
    project_root: Path | None,
    normalize_spec_ref: Any,
    get_paths: Any,
    _find_impl_file: Any,
    extract_verdict_from_impl: Any,
    complete_spec: Any,
    clear_session: Any,
) -> dict[str, Any]:
    """Inner logic for complete(), called under spec_lock."""
    paths = get_paths(root, project_root=project_root)
    normalized_id = normalize_spec_ref(spec_id)
    fr_pattern = f"FR-{normalized_id}-*.md"
    impl_pattern = f"IMPL-{normalized_id}-*.md"
    completed_frs = list(paths.completed_done.glob(fr_pattern))
    completed_impls = list(paths.completed_done.glob(impl_pattern))
    active_frs = list(paths.active_frs_dir.glob(fr_pattern))
    active_impls = list(paths.active_impls_dir.glob(impl_pattern))

    if completed_frs and completed_impls and not active_frs and not active_impls:
        return {
            "success": True,
            "spec_id": spec_id,
            "already_completed": True,
            "message": f"Spec {spec_id} is already completed",
            "fr_path": str(completed_frs[0]),
            "impl_path": str(completed_impls[0]),
        }

    # Partial completion state detection (corrupt state from interrupted operations)
    if completed_frs and not completed_impls:
        return {
            "success": False,
            "error": f"Corrupt state detected for {spec_id}",
            "details": "FR is in completed/done but IMPL is not",
            "fr_path": str(completed_frs[0]),
            "hint": (
                "Manual remediation required: either move IMPL to completed/done "
                "or move FR back to active and re-run completion."
            ),
        }
    if completed_impls and not completed_frs:
        return {
            "success": False,
            "error": f"Corrupt state detected for {spec_id}",
            "details": "IMPL is in completed/done but FR is not",
            "impl_path": str(completed_impls[0]),
            "hint": (
                "Manual remediation required: either move FR to completed/done "
                "or move IMPL back to active and re-run completion."
            ),
        }

    # Check review verdict before completing
    try:
        impl_path = _find_impl_file(spec_id, root, project_root=project_root)
        impl_content = impl_path.read_text()
        verdict = extract_verdict_from_impl(impl_content)
    except FileNotFoundError:
        return {"success": False, "error": f"IMPL file not found for {spec_id}"}
    except (OSError, UnicodeDecodeError) as e:
        return _exception_error(e)

    if verdict != "APPROVED":
        if verdict is None:
            return {
                "success": False,
                "error": f"Cannot complete {spec_id} — no review verdict found",
                "hint": f"Run `/review {spec_id}` to request agent-based review before completion.",
            }
        return {
            "success": False,
            "error": f"Cannot complete {spec_id} — review verdict is {verdict}",
            "hint": f"Run `/review {spec_id}` to request a new review after fixing.",
        }

    # HMAC verdict tamper detection (S312). The reviewer and reviewed
    # timestamp fields in the IMPL must match the signature written by
    # write_review_to_impl(). Specs lacking a Verdict-Sig field are
    # grandfathered when [review].require_hmac is False (default).
    #
    # This check MUST fail closed: if the signature is present but cannot
    # be verified for any reason (missing secret, I/O error, import
    # failure), the spec is rejected. Swallowing errors here would let an
    # attacker bypass tamper detection by provoking an exception.
    from nspec.config import NspecConfig
    from nspec.mutation import _get_impl_field
    from nspec.workflow.review import (
        get_or_create_review_secret,
        verify_verdict_hmac,
    )

    # Loading config is a soft failure — fall back to defaults on parse
    # errors so a broken config.toml doesn't block completion. The
    # require_hmac flag defaults to False, so this preserves legacy
    # behaviour for specs without a Verdict-Sig field.
    try:
        cfg_for_hmac = NspecConfig.load(project_root)
    except Exception as exc:
        logger.warning(
            "HMAC verdict verification: config load failed for %s, falling back to defaults: %s",
            spec_id,
            exc,
        )
        cfg_for_hmac = NspecConfig()

    sig_value = _get_impl_field(impl_content, "Verdict-Sig")
    if sig_value:
        signed_reviewer = _get_impl_field(impl_content, "Reviewer") or ""
        signed_timestamp = _get_impl_field(impl_content, "Reviewed") or ""
        try:
            secret = get_or_create_review_secret(project_root or root.parent)
            sig_ok = verify_verdict_hmac(
                secret,
                verdict,
                signed_reviewer,
                signed_timestamp,
                sig_value,
            )
        except Exception as exc:
            # Fail closed: unable to compute or compare the signature
            # means we cannot prove the verdict is authentic.
            logger.warning("HMAC verdict verification failed for %s: %s", spec_id, exc)
            return {
                "success": False,
                "error": (f"Cannot complete {spec_id} — verdict signature could not be verified"),
                "hint": (
                    "The review secret is unreadable or the signature is malformed. "
                    "Re-run write_review_verdict() to regenerate the signature."
                ),
            }
        if not sig_ok:
            return {
                "success": False,
                "error": (f"Cannot complete {spec_id} — verdict signature invalid"),
                "hint": (
                    "Verdict must be recorded through write_review_verdict(). "
                    "Hand-edited verdict fields are rejected."
                ),
            }
    elif cfg_for_hmac.review.require_hmac:
        return {
            "success": False,
            "error": (f"Cannot complete {spec_id} — missing verdict signature"),
            "hint": (
                "Run write_review_verdict() to sign the verdict, or set "
                "[review].require_hmac = false to grandfather legacy specs."
            ),
        }

    try:
        fr_old, fr_new, impl_old, impl_new = complete_spec(spec_id, root)
    except Exception as e:
        return _exception_error(e)

    # Auto-clear session state on spec completion
    with contextlib.suppress(Exception):
        clear_session(project_root)

    # Post-completion GitHub issue closure (non-fatal)
    github_closure: dict[str, Any] | None = None
    try:
        from nspec.config import NspecConfig
        from nspec.integrations.github import close_linked_issue

        cfg = NspecConfig.load(project_root)
        if cfg.github.auto_close:
            # Read FR from completed/done location
            fr_content = Path(fr_new).read_text(encoding="utf-8")
            reason = f"Resolved via nspec spec {spec_id}"
            closed = close_linked_issue(fr_content, reason, spec_id)
            if closed:
                from nspec.integrations.github import parse_github_issue_ref

                ref = parse_github_issue_ref(fr_content)
                github_closure = {"closed": True, "issue_ref": ref}
            # If no github_issue: header or close returned False, skip silently
        else:
            github_closure = {"closed": False, "reason": "auto_close disabled in config"}
    except Exception as exc:
        logger.warning("Post-completion GitHub closure failed for %s: %s", spec_id, exc)
        github_closure = {
            "closed": False,
            "error": str(exc),
            "action_taken": "skipped",
        }

    # Post-completion doc generation (non-fatal)
    docgen_info: dict[str, Any] | None = None
    try:
        from nspec.config import NspecConfig
        from nspec.reporting.docgen import generate_docs

        cfg = NspecConfig.load(project_root)
        if cfg.docs.enabled:
            docgen_result = generate_docs(
                spec_id,
                root,
                project_root=project_root,
                config=cfg,
                code_root=_resolve_code_root(project_root),  # pyright: ignore[reportArgumentType]
            )
            docgen_info = {
                "success": docgen_result.success,
                "target": docgen_result.target,
            }
            if docgen_result.error:
                docgen_info["error"] = docgen_result.error
    except Exception as exc:
        logger.warning("Post-completion docgen failed for %s: %s", spec_id, exc)
        docgen_info = {"success": False, "error": str(exc)}

    # Pre-merge integrity validation (non-fatal — warns but does not block)
    integrity_info: dict[str, Any] | None = None
    try:
        from nspec.validation.main_integrity import validate_main_integrity

        integrity_ok, integrity_errors, integrity_summary = validate_main_integrity(
            docs_root=root,
            project_root=project_root,
        )
        if integrity_ok:
            integrity_info = {"passed": True, "summary": integrity_summary}
        else:
            from nspec.validation.main_integrity import format_error

            integrity_info = {
                "passed": False,
                "summary": integrity_summary,
                "errors": [format_error(e) for e in integrity_errors],
            }
            logger.warning(
                "Pre-merge integrity check failed for %s: %s",
                spec_id,
                integrity_summary,
            )
    except Exception as exc:
        logger.warning("Pre-merge integrity check skipped for %s: %s", spec_id, exc)
        integrity_info = {"passed": None, "error": str(exc)}

    # Post-completion PR creation (non-fatal)
    pr_info: dict[str, Any] | None = None
    try:
        from nspec.integrations.github import create_pr_for_completed_spec

        # Extract AC items and title from FR for PR body
        fr_content = Path(fr_new).read_text(encoding="utf-8")
        ac_items = re.findall(r"-\s*\[x\]\s*(AC-\S+:.*)", fr_content)
        title_match = re.search(r"^#\s+FR-\S+:\s*(.+)$", fr_content, re.MULTILINE)
        spec_title = title_match.group(1).strip() if title_match else spec_id

        pr_url = create_pr_for_completed_spec(
            spec_id,
            spec_title,
            ac_items=ac_items or None,
            verdict="APPROVED",
            cwd=str(project_root) if project_root else None,
        )
        if pr_url:
            pr_info = {"created": True, "url": pr_url}
        else:
            from nspec.integrations.github import _current_branch

            branch = _current_branch(
                cwd=str(project_root) if project_root else None,
            )
            reason = (
                "on main/master branch" if branch else "not on a branch (detached HEAD or no git)"
            )
            pr_info = {"created": False, "reason": reason}
    except Exception as exc:
        logger.warning("Post-completion PR creation failed for %s: %s", spec_id, exc)
        pr_info = {"created": False, "error": str(exc)}

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_moved": f"{fr_old} -> {fr_new}",
        "impl_moved": f"{impl_old} -> {impl_new}",
    }
    if github_closure is not None:
        result["github_closure"] = github_closure
    if docgen_info is not None:
        result["docgen"] = docgen_info
    if pr_info is not None:
        result["pr"] = pr_info
    if integrity_info is not None:
        result["integrity"] = integrity_info
    return result


@mcp.tool()
def complete(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Complete a spec and archive it to completed/done.

    Validates that all acceptance criteria and tasks are checked
    before archiving. Also requires an APPROVED review verdict.

    Args:
        spec_id: Spec ID to complete
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.ids import normalize_spec_ref
    from nspec.mutation import _find_impl_file
    from nspec.paths import get_paths
    from nspec.runtime.session import clear_session
    from nspec.workflow.review import extract_verdict_from_impl

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Check for stale branch before completing (advisory only)
    branch_warnings = _check_stale_branch(spec_id, root)

    # Acquire per-spec lock to prevent parallel agents from completing simultaneously
    try:
        with spec_lock(spec_id, project_root=project_root):
            dao = _dao(root)
            result = _complete_inner(
                spec_id,
                root,
                project_root,
                normalize_spec_ref,
                get_paths,
                _find_impl_file,
                extract_verdict_from_impl,
                lambda sid, _dr, **_kw: dao.specs.complete(sid),
                clear_session,
            )
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }

    _attach_branch_warnings(result, branch_warnings)
    return result


@mcp.tool()
def force_archive(spec_id: str, reason: str, docs_root: str | None = None) -> dict[str, Any]:
    """Force-archive a spec that's stuck in an inconsistent state.

    Use when:
    - FR has Completed status but IMPL tasks/ACs are unchecked
    - Spec was completed outside nspec's tracking (manual edits, pre-nspec work)
    - Agent needs to unblock operations blocked by stale validation errors

    Bulk-marks all unchecked tasks and ACs as complete (tagged with
    ``(force_archive)``), sets statuses to Completed, logs the reason
    to Session Notes, and moves files to completed/done/.

    Args:
        spec_id: Spec ID to force-archive (e.g., "S659")
        reason: Required reason explaining why the override is needed
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.mutation.lifecycle import force_archive_spec

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    if not reason or not reason.strip():
        return {
            "success": False,
            "error": "reason is required for force_archive",
            "hint": "Provide a reason explaining why the spec needs force-archiving.",
        }

    try:
        with spec_lock(spec_id, project_root=project_root):
            result = force_archive_spec(
                spec_id,
                reason=reason.strip(),
                docs_root=root,
                project_root=project_root,
            )
    except FileNotFoundError:
        return {
            "success": False,
            "error": f"Spec {spec_id} not found in active directories",
            "hint": (
                "Check that the spec exists in docs/frs/active/ and docs/impls/active/. "
                "It may already be completed or archived."
            ),
        }
    except ValueError as e:
        return {
            "success": False,
            "error": str(e),
            "hint": (
                "force_archive only works on specs with Active or Completed FR status. "
                "Specs that haven't been worked on should not be force-archived."
            ),
        }
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }

    return {"success": True, **result}


@mcp.tool()
def cheap_docs(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Generate documentation for a spec using a low-reasoning agent.

    Runs the same docgen pipeline as post-completion (template rendering +
    agent invocation + target write) without requiring the spec to be archived.
    Useful for on-demand doc generation at any point.

    Requires ``[docs].enabled = true`` in config.toml.

    Args:
        spec_id: Spec ID to generate docs for (e.g., "S092")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.reporting.docgen import generate_docs

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    cfg = NspecConfig.load(project_root)
    if not cfg.docs.enabled:
        return {
            "success": False,
            "error": "Doc generation is disabled",
            "hint": "Set [docs].enabled = true in .novabuilt.dev/nspec/config.toml",
        }

    result = generate_docs(
        spec_id,
        root,
        project_root=project_root,
        config=cfg,
        code_root=_resolve_code_root(project_root),
    )
    return {
        "success": result.success,
        "spec_id": spec_id,
        "target": result.target,
        "error": result.error,
    }


@mcp.tool()
def supersede(
    spec_id: str,
    superseded_by: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Supersede a spec and archive it to completed/superseded.

    Moves FR+IMPL to completed/superseded/, sets FR status to Superseded,
    records the replacing spec ID. Does NOT require completion readiness —
    a spec can be superseded at any stage.

    Args:
        spec_id: Spec ID to supersede (e.g., "S027")
        superseded_by: Spec/epic ID that replaces this one (e.g., "E002")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import clear_session, load_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        with spec_lock(spec_id, project_root=project_root):
            try:
                fr_old, fr_new, impl_old, impl_new = _dao(root).specs.supersede(
                    spec_id, superseded_by
                )
            except Exception as e:
                return _exception_error(e)

            # Only clear session state if the superseded spec was the active one
            with contextlib.suppress(Exception):
                session = load_session(project_root)
                if session and session.spec_id == spec_id:
                    clear_session(project_root)

            return {
                "success": True,
                "spec_id": spec_id,
                "superseded_by": superseded_by,
                "fr_moved": f"{fr_old} -> {fr_new}",
                "impl_moved": f"{impl_old} -> {impl_new}",
            }
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }


@mcp.tool()
def task_block(
    spec_id: str,
    task_id: str,
    reason: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an IMPL task as blocked with a reason.

    Inserts a BLOCKED marker line after the task in the IMPL file.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1")
        reason: Why the task is blocked
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            path = _dao(root).tasks.set_blocked(spec_id, task_id, reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "path": str(path),
        "task_id": task_id,
        "reason": reason,
    }


@mcp.tool()
def task_unblock(
    spec_id: str,
    task_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Remove the BLOCKED marker from an IMPL task.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1")
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            path = _dao(root).tasks.set_unblocked(spec_id, task_id)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "path": str(path),
        "task_id": task_id,
    }


@mcp.tool()
def park(
    spec_id: str,
    reason: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Park a spec by setting IMPL status to Paused.

    Use this when a spec is blocked and cannot proceed.

    Args:
        spec_id: Spec ID to park
        reason: Optional reason for parking
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).specs.park(spec_id, reason=reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }
    if reason:
        result["reason"] = reason
    return result


@mcp.tool()
def epic_specs(
    epic_id: str,
    status_filter: str | None = None,
    starting_spec_id: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Query specs belonging to an epic, optionally filtered by status.

    Returns spec_id, title, fr_status, and impl_status for each member spec.

    Args:
        epic_id: Epic ID (e.g., "E002")
        status_filter: "completed", "incomplete", "paused", or omit for all
        starting_spec_id: Slice the sorted list from this spec onward (inclusive).
            Returns empty list if the spec is not a member of the epic.
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.mutation import get_epic_specs

    root = _resolve_docs_root(docs_root)
    normalized, error = _normalize_epic_id(epic_id, root)
    if error:
        return error
    assert normalized is not None  # noqa: S101

    try:
        specs = get_epic_specs(
            normalized,
            root,
            status_filter=status_filter,
            starting_spec_id=starting_spec_id,
            project_root=_resolve_project_root(root),
        )
    except Exception as e:
        return _exception_error(e)

    return {
        "epic_id": normalized,
        "status_filter": status_filter,
        "count": len(specs),
        "specs": specs,
    }


@mcp.tool()
def park_epic(
    epic_id: str,
    reason: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Park all non-completed specs in an epic.

    Sets IMPL to Paused and FR to Deferred for every incomplete spec
    in the epic. Already completed or paused specs are skipped.

    Args:
        epic_id: Epic ID (e.g., "E002")
        reason: Optional reason to record in each IMPL
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.mutation import park_epic_specs

    root = _resolve_docs_root(docs_root)
    normalized, error = _normalize_epic_id(epic_id, root)
    if error:
        return error
    assert normalized is not None  # noqa: S101

    try:
        result = park_epic_specs(
            normalized,
            root,
            reason=reason,
            project_root=_resolve_project_root(root),
        )
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "epic_id": normalized,
        **result,
    }


@mcp.tool()
def exception(
    spec_id: str,
    reason: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Set spec to Exception state for human triage.

    Use when:
    - Subagent timeout
    - Unexpected failure mode
    - Guardrail violation detected

    Exception is distinct from Paused - it indicates something went wrong
    that requires human investigation, not just temporary blocking.

    Args:
        spec_id: Spec ID to set to exception state
        reason: Why the spec entered exception state (required)
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            impl_path = _dao(root).specs.set_exception(spec_id, reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "impl_path": str(impl_path),
        "reason": reason,
        "status": "⚠️ Exception",
    }


@mcp.tool()
def start_design(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Move FR to In Design without starting IMPL.

    Sets FR=In Design(1) while keeping IMPL at Planning(0).
    Use this when a spec needs design work before implementation begins.

    Idempotent: calling on a spec already In Design returns success (no-op).
    Rejects if FR is past In Design (Active, Completed, etc.).

    Args:
        spec_id: Spec ID to move to In Design
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).specs.start_design(spec_id)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
        "fr_status": "In Design",
    }


@mcp.tool()
def hold(
    spec_id: str,
    reason: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Put a spec on hold by setting IMPL to Hold state.

    Sets IMPL=Hold(5) from Planning, Active, or Testing.
    Records the hold reason in the IMPL file.

    Idempotent: calling on a spec already on Hold updates the reason
    and returns success.
    Rejects if IMPL is Ready (terminal state).

    Args:
        spec_id: Spec ID to put on hold
        reason: Why the spec is being put on hold (required)
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).specs.hold(spec_id, reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
        "reason": reason,
        "status": "Hold",
    }


@mcp.tool()
def reset(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Reset a spec back to Planning state.

    Sets IMPL=Planning(0) from Paused, Hold, or Exception.
    If FR is Deferred, also resets it to Proposed.

    Idempotent: calling on a spec already at Planning returns success (no-op).
    Rejects if IMPL is Active, Testing, or Ready.

    Args:
        spec_id: Spec ID to reset
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).specs.reset(spec_id)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
        "status": "Planning",
    }


@mcp.tool()
def recover(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Recover a spec from Exception to Active state.

    Sets IMPL=Active(1) from Exception.
    Use this after investigating and fixing the issue that caused
    the exception.

    Idempotent: calling on a spec already Active returns success (no-op).
    Rejects if IMPL is not Exception or Active.

    Args:
        spec_id: Spec ID to recover
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = _dao(root).specs.recover(spec_id)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
        "status": "Active",
    }


@mcp.tool()
def blocked_specs(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List specs that have blocked tasks, are paused, or in exception state.

    Scans active IMPLs for BLOCKED task markers, Paused status, and
    Exception status. For Exception specs, extracts the reason from
    IMPL Execution Notes.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.datasets import DatasetLoader

    root = _resolve_docs_root(docs_root)
    try:
        loader = DatasetLoader(root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    def _collect_blocked(tasks: list, out: list[str]) -> None:
        for task in tasks:
            if task.blocked and task.blocked_reason:
                out.append(f"Task {task.id}: {task.blocked_reason}")
            if task.children:
                _collect_blocked(task.children, out)

    def _extract_exception_reason(impl_path: Path) -> str:
        """Extract the most recent exception reason from IMPL Execution Notes."""
        import re as _re

        try:
            content = impl_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return ""
        # Find last EXCEPTION marker in Execution Notes
        matches = _re.findall(r"⚠️ EXCEPTION — (.+)", content)
        return matches[-1].strip() if matches else ""

    from nspec.domain.statuses import is_exception_status, is_paused_status

    blocked: list[dict[str, Any]] = []
    for spec_id, impl in datasets.active_impls.items():
        reasons: list[str] = []
        is_paused = is_paused_status(impl.status)
        is_exception = is_exception_status(impl.status)

        _collect_blocked(impl.tasks, reasons)

        if reasons or is_paused or is_exception:
            fr = datasets.get_fr(spec_id)
            entry: dict[str, Any] = {
                "spec_id": spec_id,
                "title": fr.title if fr else f"Spec {spec_id}",
                "status": impl.status,
                "is_paused": is_paused,
                "is_exception": is_exception,
                "blocked_tasks": reasons,
            }
            if is_exception:
                entry["exception_reason"] = _extract_exception_reason(impl.path)
            blocked.append(entry)

    return {
        "count": len(blocked),
        "specs": blocked,
    }


@mcp.tool()
def loop_pipeline(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Return the resolved loop pipeline and agent map.

    Reads the ``[loop] pipeline`` and ``[agents]`` sections from config.
    Returns the step list, agent map, and whether it came from config or defaults.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import DEFAULT_AGENTS, DEFAULT_PIPELINE, NspecConfig

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except FileNotFoundError:
        config = NspecConfig()

    steps = [{"step": s.step, "params": list(s.params)} for s in config.loop.pipeline]
    agents = dict(config.agents.agents)

    # Determine if pipeline/agents come from config or are defaults
    is_default_pipeline = config.loop.pipeline == DEFAULT_PIPELINE
    is_default_agents = config.agents.agents == DEFAULT_AGENTS
    source = "default" if (is_default_pipeline and is_default_agents) else "config"

    return {
        "steps": steps,
        "agents": agents,
        "source": source,
    }


@mcp.tool()
def dep_graph(
    epic_id: str | None = None,
    spec_id: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Analyze dependency graph across active specs.

    Returns declared dependencies, file-level collisions (from git history),
    recommended execution order, and parallelization groupings.

    Args:
        epic_id: Optional epic ID to filter analysis to
        spec_id: Optional spec ID to show only its relationships
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.analysis.dep_graph import analyze

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    result = analyze(
        root,
        epic_id=epic_id,
        spec_id=spec_id,
        project_root=project_root,
    )

    return {
        "specs": {
            sid: {
                "deps": node.deps,
                "files": node.files,
                "file_source": node.file_source,
                "priority": node.priority,
                "title": node.title,
            }
            for sid, node in result.specs.items()
        },
        "declared_deps": result.declared_deps,
        "file_collisions": [
            {"file": c.file_path, "specs": c.spec_ids} for c in result.file_collisions
        ],
        "execution_order": result.execution_order,
        "parallel_groups": result.parallel_groups,
        "cycle": result.cycle,
    }


@mcp.tool()
def loop_init(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:  # noqa: C901
    """Initialize a loop session targeting a specific spec.

    Single atomic call that resolves the spec, validates it is workable
    (not Paused/Exception), finds its parent epic, conditionally activates
    it, persists state, and returns a structured result with resume_phase.

    Use this instead of activate() + session_start() when /loop targets
    a specific spec ID. Key differences:
    - Rejects Paused/Exception specs upfront
    - Returns resume_phase as a structured int (no status string parsing)
    - Conditional activation (doesn't force Active on already-progressed specs)

    Args:
        spec_id: Spec ID (accepts "142", "S142", "s142")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.datasets import DatasetLoader
    from nspec.runtime.session import SessionDAO
    from nspec.session import initialize_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Load datasets and verify spec exists in active backlog
    try:
        loader = DatasetLoader(docs_root=root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)
    if not impl:
        return _tool_error(f"Spec {spec_id} not found in active backlog")
    if not datasets.is_active(spec_id):
        return _tool_error(f"Spec {spec_id} is not in the active backlog")

    # Reject Paused/Exception specs
    from nspec.domain.statuses import (
        is_exception_status as _is_exc_status,
    )
    from nspec.domain.statuses import (
        is_paused_status as _is_paused_status,
    )
    from nspec.domain.statuses import (
        parse_status_text as _parse_status_text,
    )

    status = impl.status
    if _is_paused_status(status):
        return _tool_error(f"Spec {spec_id} is Paused — unpark it first")
    if _is_exc_status(status):
        return _tool_error(f"Spec {spec_id} is in Exception state — requires human triage")

    # Check checkout conflicts
    try:
        from nspec.runtime.session import CheckoutDAO

        co_dao = CheckoutDAO(project_root)
        co_dao.reap_expired()
        existing = co_dao.get(spec_id)
        if existing:
            active_session = SessionDAO(project_root).get_active()
            active_sid = active_session.session_id if active_session else None
            if existing.session_id and existing.session_id != active_sid:
                return _tool_error(
                    f"Spec {spec_id} is checked out by session "
                    f"{existing.session_id} (agent: {existing.agent_id}). "
                    f"Checkin first or wait for lease to expire."
                )
    except (OSError, TimeoutError):
        pass

    # Find parent epic
    epic_id = _find_epic_for_spec(spec_id, root)

    # Determine resume_phase: check session state first, fall back to IMPL status.
    # Exact text match (via parse_status_text) preserves the pre-refactor behavior
    # where only the literal IMPL state word triggers each branch — broader helpers
    # like is_in_progress_status would collapse Active/Testing/Ready together.
    resume_phase = 3  # default: full pipeline
    session = SessionDAO(project_root).get_active()
    _status_text = _parse_status_text(status)
    if session and session.spec_id == spec_id and session.last_phase:
        resume_phase = session.last_phase
    elif _status_text == "active":
        resume_phase = 4
    elif _status_text == "testing":
        resume_phase = 5
    elif _status_text == "ready":
        resume_phase = 6

    # Activate only if at phase 3 (Planning/Proposed)
    activated = False
    if resume_phase == 3:
        try:
            with spec_lock(spec_id, project_root=project_root):
                _dao(root).status.set_status(spec_id, 2, 1)
            activated = True
        except TimeoutError:
            return _tool_error(f"Could not acquire lock for {spec_id}")
        except Exception as e:
            return _exception_error(e)

    # Persist to active session
    try:
        dao = SessionDAO(project_root)
        dao.set_spec_id(spec_id)
        if epic_id:
            with contextlib.suppress(Exception):
                dao.set_active_epic(epic_id)
    except Exception as e:
        return _exception_error(e)

    # Initialize session context
    try:
        session_context = initialize_session(spec_id, root, project_root=project_root)
    except Exception:
        session_context = ""

    # Reset error counter
    try:
        from nspec.orchestration.error_agent import reset_session_counter

        reset_session_counter()
    except Exception:  # noqa: S110
        pass

    title = fr.title if fr else impl.spec_id
    priority = fr.priority if fr else "unknown"

    return {
        "success": True,
        "spec_id": spec_id,
        "epic_id": epic_id,
        "title": title,
        "priority": priority,
        "impl_status": status,
        "resume_phase": resume_phase,
        "activated": activated,
        "session_context": session_context,
        "completion": impl.completion_percent,
    }


@mcp.tool()
def queue_init(
    epic_id: str | None = None,
    max_agents: int | None = None,
    lease_ttl: int | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Initialize the agent assignment queue from the backlog.

    Populates the queue with eligible specs ordered by priority/dependency.
    Discards any previous queue state.

    Args:
        epic_id: Optional epic ID to filter specs.
        max_agents: Maximum concurrent agents (default: from [queue] config or 5).
        lease_ttl: Lease timeout in seconds (default: from [queue] config or 300).
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Queue state summary with entries count and configuration.
    """
    from nspec.config import NspecConfig
    from nspec.orchestration.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    config = NspecConfig.load(project_root)
    resolved_max_agents = max_agents if max_agents is not None else config.queue.max_agents
    if config.queue.mode == "single":
        resolved_max_agents = 1
    resolved_lease = lease_ttl if lease_ttl is not None else config.queue.lease_ttl_seconds

    dao = QueueDAO(project_root)
    state = dao.initialize_from_backlog(
        root,
        epic_id=epic_id,
        max_agents=resolved_max_agents,
        lease_ttl=resolved_lease,
    )
    return {
        "success": True,
        "epic_id": state.epic_id,
        "entries": len(state.entries),
        "max_agents": state.max_agents,
        "lease_ttl_seconds": state.lease_ttl_seconds,
        "specs": [
            {"spec_id": e.spec_id, "priority": e.priority, "title": e.title} for e in state.entries
        ],
    }


@mcp.tool()
def queue_claim(
    agent_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Claim the next unclaimed spec from the queue.

    Atomically assigns the highest-priority unclaimed spec to the agent.
    Two concurrent claims will never return the same spec.

    Args:
        agent_id: Unique identifier for the claiming agent.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Assignment details (spec_id, title, priority, lease_expires) or error.
    """
    from nspec.orchestration.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.claim(agent_id)


@mcp.tool()
def queue_release(
    agent_id: str,
    spec_id: str,
    reason: str | None = None,
    completed: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Release a claimed spec back to the queue or mark it completed.

    Args:
        agent_id: The agent releasing the spec.
        spec_id: The spec being released.
        reason: Optional reason for release.
        completed: If True, move to completed list instead of re-queuing.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Release confirmation or error.
    """
    from nspec.orchestration.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.release(agent_id, spec_id, reason=reason, completed=completed)


@mcp.tool()
def queue_heartbeat(
    agent_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Extend the lease for an agent's current claim.

    Call periodically to prevent lease expiry while working on a spec.

    Args:
        agent_id: The agent sending the heartbeat.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Updated lease expiry or error.
    """
    from nspec.orchestration.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.heartbeat(agent_id)


@mcp.tool()
def queue_status(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Get full queue status: agents, queued specs, completed specs.

    Shows all active agent assignments with lease expiry, unclaimed specs
    waiting in queue, and specs already completed.

    Args:
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Full queue state with agents, queued, completed, and metadata.
    """
    from nspec.orchestration.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.status()


@mcp.tool()
def swarm_launch(
    epic_id: str,
    num_agents: int = 3,
    model: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Launch a parallel Claude Code agent swarm (S253).

    Initializes the work queue from the epic backlog, creates isolated
    git worktrees, and spawns Claude Code CLI instances in tmux sessions.

    Each agent claims a spec from the queue and executes it autonomously.

    Args:
        epic_id: Epic ID to pull specs from (e.g., "E005").
        num_agents: Number of parallel agents to spawn (default: 3).
        model: Claude model to use (default: from [claude_code] config).
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Launch summary with agent assignments and queue state.
    """
    from nspec.config import NspecConfig
    from nspec.orchestration.swarm import SwarmManager

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    config = NspecConfig.load(project_root)
    manager = SwarmManager(project_root, config)
    return manager.launch(
        epic_id=epic_id,
        num_agents=num_agents,
        model=model,
        docs_root=root,
    )


@mcp.tool()
def swarm_status(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Get the current swarm status: agents, progress, and health.

    Shows all active agent assignments with tmux session status,
    completed specs, and failed specs.

    Args:
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Swarm state with agents, completed, failed, and counts.
    """
    from nspec.orchestration.swarm import SwarmManager

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    manager = SwarmManager(project_root)
    return manager.status()


@mcp.tool()
def swarm_teardown(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Tear down the active swarm: kill agents, clean worktrees, clear state.

    Kills all tmux sessions, removes git worktrees, releases queue claims,
    and deletes the swarm state file.

    Args:
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Teardown summary with killed agents and cleaned worktrees.
    """
    from nspec.orchestration.swarm import SwarmManager

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    manager = SwarmManager(project_root)
    return manager.teardown()


@mcp.tool()
def branch_status(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List all nspec/* branches with spec ID, PR status, and ahead/behind main.

    Shows branch health: commits ahead/behind main, associated PR status,
    and stale warnings for branches >20 commits behind.

    Args:
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Branch list with spec_id, ahead, behind, stale, pr_status fields.
    """
    from nspec.workflow.branches import branch_status_report

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    return branch_status_report(cwd=str(project_root))


@mcp.tool()
def branch_cleanup(
    docs_root: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Remove nspec/* branches whose PRs have been merged.

    Only deletes branches with merged PRs. Skips branches with open
    or no PRs. Use dry_run=True to preview without deleting.

    Args:
        docs_root: Path to docs directory (default: ./docs).
        dry_run: Preview cleanup without deleting (default: False).

    Returns:
        Summary with deleted, skipped, and error lists.
    """
    from nspec.workflow.branches import cleanup_merged_branches

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    return cleanup_merged_branches(cwd=str(project_root), dry_run=dry_run)


def _create_custom_type_spec(
    resolved_type: Any,
    title: str,
    priority: str,
    epic_id: str | None,
    docs_root: Path,
    project_root: Path | None,
) -> dict[str, Any]:
    """Create a single-file spec for a user-defined custom type.

    Custom types produce one file (not FR+IMPL pair) using the type's
    directory, file_pattern, and template from config. The spec ID
    uses the standard S-prefix allocation.
    """
    import re

    from nspec.mutation.lifecycle import _allocate_and_reserve
    from nspec.resources import load_custom_template

    if project_root is None:
        project_root = docs_root.parent

    # Allocate an S-prefixed ID
    try:
        spec_id = _allocate_and_reserve(
            priority,
            docs_root,
            project_root=project_root,
            id_prefix="S",
        )
    except Exception as e:
        return _exception_error(e)

    # Generate slug from title
    slug = title.lower()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[-\s]+", "-", slug)
    slug = slug.strip("-")

    # Generate filename from type's file_pattern
    id_num = int(spec_id[1:])  # Strip "S" prefix
    filename = resolved_type.format_filename(id_num, slug)

    # Resolve directory — relative to docs_root
    type_dir = docs_root / resolved_type.directory
    type_dir.mkdir(parents=True, exist_ok=True)
    spec_path = type_dir / filename

    # Load template content
    template_content: str
    if resolved_type.template:
        try:
            template_content = load_custom_template(resolved_type.template, project_root)
        except FileNotFoundError as e:
            return {"success": False, "error": str(e)}
    else:
        # Fallback: generate a minimal template from required_sections
        lines = [
            f"# {resolved_type.prefix}-{spec_id}: {title}",
            "",
            f"**Priority:** {priority}",
            f"**Status:** {resolved_type.initial_status}",
            "deps: []",
            "",
        ]
        if epic_id:
            lines.append(f"epic_id: {epic_id}")
            lines.append("")
        for section in resolved_type.required_sections:
            lines.append(f"## {section}")
            lines.append("")
            lines.append(f"<!-- {section} content -->\n")
        template_content = "\n".join(lines)

    # Apply standard placeholder replacements
    from datetime import datetime

    current_date = datetime.now().strftime("%Y-%m-%d")  # noqa: DTZ005
    content = template_content.replace("XXX", spec_id)
    content = content.replace("[TITLE]", title)
    content = content.replace("[SPEC TITLE]", title)
    content = content.replace("YYYY-MM-DD", current_date)

    # Inject header fields if not present in template
    if "**Priority:**" not in content:
        header = (
            f"# {resolved_type.prefix}-{spec_id}: {title}\n\n"
            f"**Priority:** {priority}\n"
            f"**Status:** {resolved_type.initial_status}"
        )
        content = content.replace(
            f"# {resolved_type.prefix}-{spec_id}",
            header,
            1,
        )

    spec_path.write_text(content, encoding="utf-8")

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "spec_type": resolved_type.name,
        "spec_path": str(spec_path),
        "fr_path": str(spec_path),  # Alias for compatibility
        "impl_path": str(spec_path),  # Single-file types use same path
    }

    # Add to epic if specified
    if epic_id:
        try:
            normalized_epic, error = _normalize_epic_id(epic_id, docs_root)
            if error:
                result["epic_warning"] = f"Could not add to epic: {error.get('error', '')}"
            else:
                assert normalized_epic is not None  # noqa: S101
                from nspec.mutation.deps import add_dep  # noqa: I001  # pyright: ignore[reportAttributeAccessIssue]

                add_dep(spec_id, normalized_epic, docs_root, project_root=project_root)
                result["epic_id"] = normalized_epic
        except Exception as e:
            result["epic_warning"] = f"Created but failed to add to epic: {e}"

    return result


@mcp.tool()
def create_spec(  # noqa: C901
    title: str,
    priority: str | None = None,
    epic_id: str | None = None,
    is_epic: bool = False,
    set_default: bool = False,
    docs_root: str | None = None,
    spec_type: str | None = None,
    template: str | None = None,
) -> dict[str, Any]:
    """Create a new FR+IMPL spec pair.

    Auto-assigns the next available spec ID in the priority range.
    Optionally adds the spec to an epic.

    Args:
        title: Spec title (e.g., "Add search feature")
        priority: Priority level (P0-P3). Default: P2
        epic_id: Optional epic ID to group under (ignored if is_epic=True)
        is_epic: If True, create an epic (E###) instead of a spec (S###)
        set_default: If True and is_epic=True, set this epic as the default in config
        docs_root: Path to docs directory (default: ./docs)
        spec_type: Optional spec type name (e.g., "rfc"). When provided,
            creates file(s) for that SpecType instead of the default FR+IMPL pair.
        template: Optional template profile (quick, standard, full, formal).
            Controls ceremony level of generated spec files.
    """
    from nspec.config import NspecConfig
    from nspec.domain.spec_types import default_registry
    from nspec.domain.statuses import default_priority

    _auto_priority = priority is None
    if priority is None:
        priority = default_priority()

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = _dao(root)

    # Normalize boolean params (MCP clients may pass strings)
    is_epic = _to_bool(is_epic)
    set_default = _to_bool(set_default)

    # Resolve spec_type via registry if provided
    if spec_type is not None:
        try:
            config = NspecConfig.load(project_root)
            registry = default_registry(config)
        except (FileNotFoundError, KeyError, ValueError):
            registry = default_registry()
        try:
            resolved_type = registry.get(spec_type)
        except KeyError as e:
            return {"success": False, "error": str(e)}

        # Map spec_type to existing is_epic flag for built-in types.
        # IMPL is always created alongside its FR — reject standalone.
        if resolved_type.name == "epic":
            is_epic = True
        elif resolved_type.name == "fr":
            is_epic = False
        elif resolved_type.name == "impl":
            return {
                "success": False,
                "error": (
                    "IMPL specs are always created alongside their FR. "
                    "Use spec_type='fr' or omit spec_type to create an FR+IMPL pair."
                ),
            }
        else:
            # Custom type — create directly using SpecType metadata
            return _create_custom_type_spec(
                resolved_type=resolved_type,
                title=title,
                priority=priority,
                epic_id=epic_id,
                docs_root=root,
                project_root=project_root,
            )

    # Validate flag combinations
    if set_default and not is_epic:
        return {
            "success": False,
            "error": "set_default only valid when is_epic=True",
        }
    if is_epic and epic_id:
        return {
            "success": False,
            "error": "epic_id cannot be used with is_epic=True (epics don't nest)",
        }

    # Epic enforcement: use config default if no epic specified (only for specs, not epics)
    if not is_epic:
        require_default_epic = True  # default
        enforce_epic_grouping = False
        if epic_id is None:
            try:
                from nspec.config import NspecConfig

                config = NspecConfig.load(project_root)
                require_default_epic = config.strict.require_default_epic
                enforce_epic_grouping = config.validation.enforce_epic_grouping
                if config.defaults.epic:
                    default_epic = config.defaults.epic
                    # Config stores bare number (e.g. "001") — prefix with E
                    if default_epic and default_epic[0].isdigit():
                        default_epic = f"E{default_epic}"
                    epic_id = default_epic
            except (FileNotFoundError, ValueError):
                pass  # Don't break creation on config issues

        # Gate epic requirement on strict config and grouping enforcement policy
        if epic_id is None and (require_default_epic or enforce_epic_grouping):
            return {
                "success": False,
                "error": (
                    "Spec creation requires epic assignment. Set [defaults] epic in "
                    ".novabuilt.dev/nspec/config.toml or pass epic_id.\n"
                    "Current gates:\n"
                    f"  [strict] require_default_epic = {str(require_default_epic).lower()}\n"
                    "  [validation] "
                    f"enforce_epic_grouping = {str(enforce_epic_grouping).lower()}\n"
                    "To allow orphan creation, disable both gates."
                ),
            }

        # Normalize and verify epic (only when epic is provided)
        if epic_id is not None:
            normalized_epic, error = _normalize_epic_id(epic_id, root)
            if error:
                return error
            assert normalized_epic is not None  # noqa: S101
            epic_id = normalized_epic

            epic_error = _verify_epic_exists(epic_id=epic_id, docs_root=root)
            if epic_error:
                # Add helpful hint for new projects
                epic_error["hint"] = (
                    "For new projects, run init() first to create the project structure "
                    "and default epic. Example: init(epic_title='My Project')"
                )
                return epic_error

    try:
        fr_path, impl_path, spec_id = dao.specs.create(
            title,
            priority,
            is_epic=is_epic,
            template=template,
            auto_priority=_auto_priority,
        )
    except Exception as e:
        return _exception_error(e)

    # Verify files exist on disk after creation
    if not fr_path.exists():
        logger.error("create_spec: FR file missing after creation: %s", fr_path)
        return {"success": False, "error": f"FR file not found after creation: {fr_path}"}
    if not impl_path.exists():
        logger.error("create_spec: IMPL file missing after creation: %s", impl_path)
        return {"success": False, "error": f"IMPL file not found after creation: {impl_path}"}

    logger.debug("create_spec: created %s → FR=%s, IMPL=%s", spec_id, fr_path, impl_path)

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }

    # Epic conflict check: warn about conflicting branches, PRs, title overlap
    if is_epic:
        try:
            from nspec.git_ops import epic_conflict_check

            conflict_report = epic_conflict_check(title, root)
            if conflict_report.warnings:
                result["warnings"] = conflict_report.warnings
        except Exception as e:
            logger.debug("create_spec: epic conflict check failed: %s", e)

    # Set as default epic if requested (track old value for rollback)
    _did_set_default = False
    _old_default_epic: str | None = None
    if set_default and is_epic:
        try:
            from nspec.config import NspecConfig

            config = NspecConfig.load(project_root)
            _old_default_epic = config.defaults.epic  # capture for rollback (may be None)
            # Store without E prefix (just the number)
            epic_num = spec_id[1:] if spec_id.startswith("E") else spec_id
            config.defaults.epic = epic_num
            config.save()
            _did_set_default = True
            result["set_as_default"] = True
        except Exception as e:
            logger.warning("create_spec: failed to set default epic: %s", e)
            result["set_default_warning"] = f"Failed to set as default: {e}"

    # Add spec to epic (only for specs, not epics)
    if epic_id and not is_epic:
        # Verify spec is loadable before adding to epic
        from nspec.domain.datasets import DatasetLoader

        try:
            loader = DatasetLoader(root)
            datasets = loader.load()
            if spec_id not in datasets.active_frs:
                logger.warning(
                    "create_spec: spec %s created but not loadable — rolling back",
                    spec_id,
                )
                # Rollback: delete orphan files
                try:
                    fr_path.unlink(missing_ok=True)
                    impl_path.unlink(missing_ok=True)
                except Exception as rollback_err:
                    logger.debug("create_spec: rollback failed: %s", rollback_err)
                return {
                    "success": False,
                    "error": (
                        f"Spec {spec_id} created but failed validation — "
                        f"rolled back (files deleted). Not added to epic {epic_id}"
                    ),
                    "spec_id": spec_id,
                }
        except Exception as e:
            logger.warning("create_spec: dataset load failed after create: %s", e)
            # Rollback: delete orphan files on load failure
            try:
                fr_path.unlink(missing_ok=True)
                impl_path.unlink(missing_ok=True)
            except Exception as rollback_err:
                logger.debug("create_spec: rollback failed: %s", rollback_err)
            return {
                "success": False,
                "error": (
                    f"Spec {spec_id} created but dataset loading failed — "
                    f"rolled back (files deleted): {e}"
                ),
                "spec_id": spec_id,
            }

        # S256: route epic assignment through the membership DAO so the
        # child FR stores its owning `epic_id`. We no longer mutate the
        # parent epic's `deps` list to encode membership.
        try:
            dao.memberships.set_owner(spec_id, epic_id)
        except Exception as e:
            return _exception_error(e)
        result["epic_id"] = epic_id

    # If IMPL is a skeleton, include refinement prompt in response
    try:
        from nspec.workflow.refine import generate_refinement_prompt, is_skeleton_impl

        impl_content = impl_path.read_text()
        if is_skeleton_impl(impl_content):
            prompt = generate_refinement_prompt(spec_id, root)
            result["refinement_prompt"] = prompt.prompt_text
            result["refinement_hint"] = (
                "IMPL has placeholder tasks. Call execute_agent(prompt=...) "
                "with this prompt, then call "
                "write_refinement with the response content."
            )
    except Exception as e:
        logger.debug("create_spec: refinement prompt generation failed: %s", e)

    # Run post-mutation validation
    try:
        valid, payload, reject_mode = _post_mutation_validate(root, project_root)
        result["validation"] = payload
        if not valid and reject_mode:
            # Rollback: clear epic membership, config change, and delete FR+IMPL files
            if epic_id and not is_epic:
                try:
                    _dao(root).memberships.clear_owner(spec_id)
                except Exception as dep_err:
                    logger.debug("create_spec: rollback epic membership failed: %s", dep_err)
            if _did_set_default:
                try:
                    from nspec.config import NspecConfig as _CfgRb

                    _cfg_rb = _CfgRb.load(project_root)
                    _cfg_rb.defaults.epic = _old_default_epic  # restore (may be None)
                    _cfg_rb.save()
                except Exception as cfg_err:
                    logger.debug("create_spec: rollback config failed: %s", cfg_err)
            try:
                fr_path.unlink(missing_ok=True)
                impl_path.unlink(missing_ok=True)
            except Exception as rollback_err:
                logger.debug("create_spec: rollback failed: %s", rollback_err)
            return {
                "success": False,
                "error": "Validation failed after creation — rolled back",
                "validation": payload,
                "spec_id": spec_id,
            }
    except Exception as e:
        logger.debug("create_spec: post-creation validation failed: %s", e)

    return result


@mcp.tool()
def issue_import(  # noqa: C901
    repo: str | None = None,
    number: int = 0,
    epic_id: str | None = None,
    priority: str | None = None,
    dry_run: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Import a GitHub issue as an nspec spec.

    Fetches the issue via ``gh`` CLI, creates an FR+IMPL pair, and
    populates the FR with issue content (body sections, labels→priority).

    Args:
        repo: Repository in "owner/repo" format. Falls back to [github].repo in config.
        number: Issue number (required, must be > 0).
        epic_id: Optional epic to assign the spec to.
        priority: Override priority (P0-P3). Default: mapped from labels or config default.
        dry_run: If True, return issue preview without creating a spec.
        docs_root: Path to docs directory (default: ./docs).
    """
    from nspec.config import NspecConfig
    from nspec.integrations.github import (
        fetch_issue,
        issue_to_fr_content,
        map_labels_to_priority,
    )

    dry_run = _to_bool(dry_run)

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Resolve repo
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:  # noqa: S110
            pass
    if not repo:
        return {
            "success": False,
            "error": "repo is required. Pass repo or set [github].repo in config.toml.",
        }

    if number <= 0:
        return {"success": False, "error": "number must be a positive integer."}

    # Fetch issue
    try:
        issue = fetch_issue(repo, number)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    # Resolve priority
    try:
        config = NspecConfig.load(project_root)
        gh_config = config.github
    except Exception:
        from nspec.config import GitHubConfig

        gh_config = GitHubConfig()

    if priority is None:
        priority = map_labels_to_priority(
            issue.labels, gh_config.label_priority_map, gh_config.default_priority
        )

    # Fall back to config default_epic when no explicit epic_id provided
    if epic_id is None and gh_config.default_epic:
        epic_id = gh_config.default_epic

    if dry_run:
        return {
            "success": True,
            "dry_run": True,
            "issue": {
                "number": issue.number,
                "title": issue.title,
                "labels": issue.labels,
                "state": issue.state,
                "url": issue.url,
                "body_preview": issue.body[:500] if issue.body else "",
            },
            "mapped_priority": priority,
            "repo": repo,
        }

    # Create spec
    spec_result = create_spec(
        title=issue.title,
        priority=priority,
        epic_id=epic_id,
        docs_root=docs_root,
    )
    if not spec_result.get("success"):
        return spec_result

    spec_id = spec_result["spec_id"]
    fr_path = Path(spec_result["fr_path"])

    # Populate FR with issue content
    try:
        existing_fr = fr_path.read_text()
        updated_fr = issue_to_fr_content(issue, spec_id, priority, existing_fr)
        fr_path.write_text(updated_fr)
        # S926: invalidate cache after writing FR file
        from nspec.domain.datasets import invalidate_dataset_cache

        invalidate_dataset_cache()
    except Exception as e:
        logger.warning("issue_import: FR population failed: %s", e)

    # S367: Post back-comment on the GitHub issue for bidirectional tracking
    back_comment_posted = False
    back_comment_warning: str | None = None
    try:
        from nspec.integrations.github import post_back_comment

        # Use project-relative paths to avoid leaking absolute filesystem paths
        try:
            fr_rel = str(fr_path.relative_to(project_root))
        except (ValueError, TypeError):
            fr_rel = str(fr_path)
        impl_abs = spec_result.get("impl_path", "")
        try:
            impl_rel = str(Path(impl_abs).relative_to(project_root)) if impl_abs else ""
        except (ValueError, TypeError):
            impl_rel = impl_abs

        back_comment_posted = post_back_comment(
            repo=repo,
            issue_number=issue.number,
            spec_id=spec_id,
            fr_path=fr_rel,
            impl_path=impl_rel,
            epic_id=epic_id,
            priority=priority,
            status="Planning",
        )
        if not back_comment_posted:
            back_comment_warning = (
                f"Failed to post back-comment on {repo}#{issue.number}. "
                "Run `nspec tracker audit --fix` to retry."
            )
    except Exception as e:
        back_comment_warning = (
            f"Back-comment failed on {repo}#{issue.number}: {e}. "
            "Run `nspec tracker audit --fix` to retry."
        )

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": spec_result.get("impl_path", ""),
        "issue_title": issue.title,
        "issue_url": issue.url,
        "github_ref": f"{repo}#{issue.number}",
        "priority": priority,
        "epic_id": epic_id,
        "back_comment_posted": back_comment_posted,
    }
    if back_comment_warning:
        result["back_comment_warning"] = back_comment_warning
    return result


@mcp.tool()
def issue_list(
    repo: str | None = None,
    state: str = "open",
    label: str | None = None,
    limit: int = 30,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List GitHub issues from a repository.

    Returns issues with their mapped nspec priorities based on labels.

    Args:
        repo: Repository in "owner/repo" format. Falls back to [github].repo in config.
        state: Filter by state: "open", "closed", or "all". Default: "open".
        label: Optional label filter.
        limit: Maximum number of issues to return. Default: 30.
        docs_root: Path to docs directory (default: ./docs).
    """
    from nspec.config import NspecConfig
    from nspec.integrations.github import fetch_issues, map_labels_to_priority

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Resolve repo
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:  # noqa: S110
            pass
    if not repo:
        return {
            "success": False,
            "error": "repo is required. Pass repo or set [github].repo in config.toml.",
        }

    # Load config for label mapping
    try:
        config = NspecConfig.load(project_root)
        gh_config = config.github
    except Exception:
        from nspec.config import GitHubConfig

        gh_config = GitHubConfig()

    try:
        issues = fetch_issues(repo, state=state, label=label, limit=limit)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    return {
        "success": True,
        "repo": repo,
        "issues": [
            {
                "number": iss.number,
                "title": iss.title,
                "labels": iss.labels,
                "state": iss.state,
                "mapped_priority": map_labels_to_priority(
                    iss.labels, gh_config.label_priority_map, gh_config.default_priority
                ),
                "url": iss.url,
            }
            for iss in issues
        ],
    }


@mcp.tool()
def issue_sync(
    epic_id: str,
    repo: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Audit GitHub issue sync for an epic — find mismatches.

    Cross-references all specs in an epic against GitHub issues,
    returning local-only specs (no linked issue), diverged specs
    (local/remote status mismatch), and orphan issues (no matching spec).

    Args:
        epic_id: Epic ID to audit (e.g., "E006")
        repo: GitHub repo in "owner/repo" format. Falls back to config.
        docs_root: Path to docs directory (default: ./docs).
    """
    from nspec.config import NspecConfig
    from nspec.integrations.github import SyncReport, sync_audit

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Resolve repo from config if not provided
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:  # noqa: S110
            pass
    if not repo:
        return {
            "success": False,
            "error": "repo is required. Pass repo or set [github].repo in config.toml.",
        }

    normalized, error = _normalize_epic_id(epic_id, root)
    if error:
        return error
    assert normalized is not None  # noqa: S101

    result = sync_audit(normalized, root, repo, project_root=project_root)

    if isinstance(result, dict):
        return result  # error dict

    assert isinstance(result, SyncReport)  # noqa: S101
    return {
        "success": True,
        "epic_id": result.epic_id,
        "repo": result.repo,
        "local_only": [
            {
                "spec_id": e.spec_id,
                "title": e.title,
                "spec_status": e.spec_status,
            }
            for e in result.local_only
        ],
        "diverged": [
            {
                "spec_id": e.spec_id,
                "title": e.title,
                "spec_status": e.spec_status,
                "github_ref": e.github_ref,
                "issue_state": e.issue_state,
            }
            for e in result.diverged
        ],
        "orphan_issues": [
            {
                "number": o.number,
                "title": o.title,
                "url": o.url,
                "state": o.state,
            }
            for o in result.orphan_issues
        ],
        "summary": {
            "local_only_count": len(result.local_only),
            "diverged_count": len(result.diverged),
            "orphan_count": len(result.orphan_issues),
        },
    }


@mcp.tool()
def create_issue(
    spec_id: str,
    repo: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Create a GitHub issue from a spec and link it.

    Creates a GitHub issue from the spec's FR title and summary,
    then writes the ``github_issue:`` header back to the FR file.

    Args:
        spec_id: Spec ID to create an issue for (e.g., "S042")
        repo: GitHub repo in "owner/repo" format. Falls back to config.
        docs_root: Path to docs directory (default: ./docs).
    """
    from nspec.config import NspecConfig
    from nspec.integrations.github import create_issue_from_spec

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Resolve repo from config if not provided
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:  # noqa: S110
            pass
    if not repo:
        return {
            "success": False,
            "error": "repo is required. Pass repo or set [github].repo in config.toml.",
        }

    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    return create_issue_from_spec(spec_id, root, repo, project_root=project_root)


@mcp.tool()
def batch_import(
    epic_id: str | None = None,
    repo: str | None = None,
    label: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Batch-import all open non-imported GitHub issues as nspec specs.

    Fetches open issues (optionally filtered by label), skips issues
    already labeled ``imported``, and calls ``issue_import`` for each.
    Individual import failures do not halt the batch — they are logged
    and included in the summary. Rate limit errors (HTTP 403/429 from
    ``gh`` CLI) trigger exponential backoff with max 3 retries.

    Args:
        epic_id: Target epic for all imported specs. Falls back to config.
        repo: GitHub repo in "owner/repo" format. Falls back to config.
        label: Optional label filter (e.g., "bug"). Only imports issues with this label.
        docs_root: Path to docs directory (default: ./docs).
    """
    import time

    from nspec.config import GitHubConfig, NspecConfig
    from nspec.integrations.github import fetch_issues, map_labels_to_priority

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Resolve config
    try:
        config = NspecConfig.load(project_root)
        gh_config = config.github
    except Exception:
        gh_config = GitHubConfig()

    # Resolve repo
    if not repo:
        repo = gh_config.repo
    if not repo:
        return {
            "success": False,
            "error": "repo is required. Pass repo or set [github].repo in config.toml.",
        }

    # Resolve epic
    if not epic_id:
        epic_id = gh_config.default_epic

    # Fetch open issues with optional label filter
    max_retries = 3
    issues: list = []
    for attempt in range(max_retries + 1):
        try:
            # gh CLI supports up to 1000; use 500 as a practical upper bound
            issues = fetch_issues(repo, state="open", label=label, limit=500)
            break
        except ValueError as e:
            err_str = str(e)
            if (
                "403" in err_str or "429" in err_str or "rate" in err_str.lower()
            ) and attempt < max_retries:
                delay = 2**attempt  # 1s, 2s, 4s
                time.sleep(delay)
                continue
            return {"success": False, "error": f"Failed to fetch issues: {e}"}

    # Filter out already-imported issues
    # Case-insensitive check for 'imported' label
    to_import = [iss for iss in issues if not any(lbl.lower() == "imported" for lbl in iss.labels)]

    if not to_import:
        return {
            "success": True,
            "imported": [],
            "failures": [],
            "summary": {
                "total_fetched": len(issues),
                "skipped_imported": len(issues) - len(to_import),
                "imported_count": 0,
                "failure_count": 0,
            },
        }

    imported: list[dict] = []
    failures: list[dict] = []

    for iss in to_import:
        # Resolve priority from labels
        priority = map_labels_to_priority(
            iss.labels, gh_config.label_priority_map, gh_config.default_priority
        )

        # Try import with rate limit retry (handles both exceptions and error dicts)
        result = None
        for attempt in range(max_retries + 1):
            try:
                result = issue_import(
                    repo=repo,
                    number=iss.number,
                    epic_id=epic_id,
                    priority=priority,
                    docs_root=docs_root,
                )
            except Exception as e:
                result = {"success": False, "error": str(e)}

            # Check for rate limit in error response and retry
            if result and not result.get("success"):
                err_str = str(result.get("error", ""))
                if (
                    "403" in err_str or "429" in err_str or "rate" in err_str.lower()
                ) and attempt < max_retries:
                    time.sleep(2**attempt)
                    continue
            break

        if result and result.get("success"):
            imported.append(
                {
                    "spec_id": result.get("spec_id", ""),
                    "issue_number": iss.number,
                    "title": iss.title,
                    "priority": priority,
                    "github_ref": result.get("github_ref", ""),
                }
            )
        else:
            failures.append(
                {
                    "operation": "issue_import",
                    "issue_ref": f"{repo}#{iss.number}",
                    "error": (result or {}).get("error", "Unknown error"),
                    "action_taken": "skipped",
                }
            )

    return {
        "success": True,
        "imported": imported,
        "failures": failures,
        "summary": {
            "total_fetched": len(issues),
            "skipped_imported": len(issues) - len(to_import),
            "imported_count": len(imported),
            "failure_count": len(failures),
        },
    }


@mcp.tool()
def set_priority(spec_id: str, priority: str, docs_root: str | None = None) -> dict[str, Any]:
    """Change a spec's priority level.

    Automatically updates dependent spec priorities to maintain
    the priority inheritance rule (child <= parent).

    Args:
        spec_id: Spec ID to update
        priority: New priority (P0-P3)
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Read old priority for rollback
    old_priority: str | None = None
    try:
        import re as _re

        from nspec.paths import get_paths as _gp

        _paths = _gp(root)
        for _fr in sorted(_paths.active_frs_dir.glob(f"FR-{spec_id}-*.md")):
            _content = _fr.read_text()
            _m = _re.search(r"\*\*Priority:\*\*\s*(?:\S+\s+)?(P\d+)", _content)
            if _m:
                old_priority = _m.group(1)
            break
    except Exception:  # noqa: S110
        pass

    try:
        result = _dao(root).deps.set_priority(spec_id, priority)
    except Exception as e:
        return _exception_error(e)

    # Post-mutation validation
    response: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "priority": priority,
        "path": str(result["path"]),
    }
    try:
        valid, payload, reject_mode = _post_mutation_validate(root)
        response["validation"] = payload
        if not valid and reject_mode:
            # Revert to old priority
            if old_priority:
                try:
                    _dao(root).deps.set_priority(spec_id, old_priority)
                except Exception as revert_err:
                    logger.debug("set_priority: revert failed: %s", revert_err)
            return {
                "success": False,
                "error": "Validation failed after priority change — reverted",
                "validation": payload,
                "spec_id": spec_id,
            }
    except Exception as e:
        logger.debug("set_priority: post-mutation validation failed: %s", e)

    return response


@mcp.tool()
def swap_priority(spec_id_a: str, spec_id_b: str, docs_root: str | None = None) -> dict[str, Any]:
    """Swap the priorities of two epics.

    After the swap, epic A gets epic B's old priority and vice versa.
    The response includes a plain-English summary showing each epic's
    new priority (lower P number = higher priority).

    Example: if E001 is P2 and E006 is P5, after swap E001 becomes P5
    and E006 becomes P2.

    Args:
        spec_id_a: First epic ID (e.g., "E001")
        spec_id_b: Second epic ID (e.g., "E006")
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id_a = _resolve_id_from_disk(spec_id_a, root)
        spec_id_b = _resolve_id_from_disk(spec_id_b, root)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    try:
        from nspec.mutation import swap_priority as _swap

        result = _swap(spec_id_a, spec_id_b, root)
    except Exception as e:
        return _exception_error(e)

    new_a = result[spec_id_a]
    new_b = result[spec_id_b]
    return {
        "success": True,
        "swaps": [
            {"epic": spec_id_a, "priority": new_a},
            {"epic": spec_id_b, "priority": new_b},
        ],
        "summary": f"{spec_id_a} is now {new_a}, {spec_id_b} is now {new_b}",
    }


@mcp.tool()
def unify_collisions(docs_root: str | None = None) -> dict[str, Any]:
    """Detect and resolve spec ID collisions.

    Scans active FR directory for duplicate spec IDs (same numeric ID,
    different file slugs). Renumbers the newer file (by mtime) to the
    next available ID, updates FR/IMPL headers and epic deps.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        from nspec.mutation import unify_collisions as _unify

        resolutions = _unify(root)
    except Exception as e:
        return _exception_error(e)

    if not resolutions:
        return {"success": True, "collisions": 0, "message": "No collisions detected."}

    response: dict[str, Any] = {
        "success": True,
        "collisions": len(resolutions),
        "resolutions": resolutions,
    }

    # Post-resolution validation (AC-F5)
    try:
        valid, payload, _ = _post_mutation_validate(root)
        response["validation"] = payload
        if not valid:
            response["validation_passed"] = False
        else:
            response["validation_passed"] = True
    except Exception as e:
        logger.debug("unify_collisions: post-resolution validation failed: %s", e)

    return response


@mcp.tool()
def add_dep(spec_id: str, dep_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Add a dependency to a spec.

    If the target is an epic and the dependency belongs to another
    epic, it will be automatically moved.

    Args:
        spec_id: Spec ID to add dependency to
        dep_id: Dependency spec ID
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
        dep_id = _resolve_id_from_disk(dep_id, root)
    except ValueError:
        return _invalid_id_error(f"{spec_id} / {dep_id}")
    try:
        result = _dao(root).deps.add(spec_id, dep_id)
    except Exception as e:
        return _exception_error(e)

    moved_from = result.get("moved_from")

    # Post-mutation validation
    response: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "dep_id": dep_id,
        "path": str(result["path"]),
        "moved_from": moved_from,
    }
    try:
        valid, payload, reject_mode = _post_mutation_validate(root)
        response["validation"] = payload
        if not valid and reject_mode:
            # Rollback: remove the dep we just added
            try:
                _dao(root).deps.remove(spec_id, dep_id)
            except Exception as revert_err:
                logger.debug("add_dep: revert remove failed: %s", revert_err)
            # Restore the moved_from relationship if add() moved the dep
            if moved_from:
                try:
                    _dao(root).deps.add(moved_from, dep_id)
                except Exception as restore_err:
                    logger.debug("add_dep: revert moved_from failed: %s", restore_err)
            return {
                "success": False,
                "error": "Validation failed after adding dependency — reverted",
                "validation": payload,
                "spec_id": spec_id,
                "dep_id": dep_id,
            }
    except Exception as e:
        logger.debug("add_dep: post-mutation validation failed: %s", e)

    return response


@mcp.tool()
def remove_dep(spec_id: str, dep_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Remove a dependency from a spec.

    Args:
        spec_id: Spec ID to remove dependency from
        dep_id: Dependency spec ID to remove
        docs_root: Path to docs directory (default: ./docs)
    """
    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
        dep_id = _resolve_id_from_disk(dep_id, root)
    except ValueError:
        return _invalid_id_error(f"{spec_id} / {dep_id}")
    try:
        path = _dao(root).deps.remove(spec_id, dep_id)
    except Exception as e:
        return _exception_error(e)
    return {"success": True, "spec_id": spec_id, "dep_id": dep_id, "path": str(path)}


@mcp.tool()
def session_save(
    spec_id: str,
    task_id: str | None = None,
    notes: str | None = None,
    phase: int | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Persist session state for cross-session handoff.

    Saves spec progress to the active session file.
    Increments attempt counter for the given task_id.

    Args:
        spec_id: Spec ID being worked on
        task_id: Current task ID (optional)
        notes: Session notes (optional)
        phase: Pipeline phase number to checkpoint (optional, 3-7)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    dao = SessionDAO(project_root)

    # Load existing session or create new
    try:
        existing = dao.get_active()
    except Exception:
        existing = None
    if existing and existing.spec_id == spec_id:
        state = existing
        state.last_task = task_id or state.last_task
        state.notes = notes or state.notes
        if phase is not None:
            state.last_phase = phase
    else:
        # Carry forward active_epic from previous session
        prev_epic = existing.active_epic if existing else None
        state = dao.create(spec_id=spec_id, epic_id=prev_epic)
        state.last_task = task_id
        state.last_phase = phase
        state.notes = notes

    # If active_epic is still unset, look it up from the spec's parent epic
    if not state.active_epic and not spec_id.startswith("E"):
        epic_id = _find_epic_for_spec(spec_id, root)
        if epic_id:
            state.active_epic = epic_id

    # Increment attempt counter for task
    if task_id:
        state.attempts[task_id] = state.attempts.get(task_id, 0) + 1

    try:
        path = dao.save(state)
    except Exception as e:
        return _exception_error(e)

    result: dict[str, Any] = {
        "success": True,
        "path": str(path),
        "spec_id": spec_id,
        "task_id": task_id,
        "last_phase": state.last_phase,
        "attempts": state.attempts,
    }

    # Auto-park if a task hits 3 consecutive failures
    if task_id and state.attempts.get(task_id, 0) >= 3:
        root = _resolve_docs_root(docs_root)
        reason = (
            f"Auto-parked: task {task_id} failed {state.attempts[task_id]} consecutive attempts"
        )
        try:
            _dao(root).specs.park(spec_id, reason=reason)
            result["auto_parked"] = True
            result["park_reason"] = reason
        except (FileNotFoundError, ValueError):
            # Already paused or file not found — don't fail the save
            pass

    return result


@mcp.tool()
def session_resume(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Load persisted session state for a spec.

    Returns saved session context if the active session matches spec_id.

    Args:
        spec_id: Spec ID to resume
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        dao = SessionDAO(project_root)
        state = dao.get_active()
    except Exception as e:
        return _exception_error(e)

    if not state or state.spec_id != spec_id:
        return {
            "found": False,
            "spec_id": spec_id,
            "message": f"No saved session for spec {spec_id}",
        }

    return {
        "found": True,
        "session_id": state.session_id,
        "spec_id": state.spec_id,
        "active_epic": state.active_epic,
        "last_task": state.last_task,
        "last_phase": state.last_phase,
        "attempts": state.attempts,
        "notes": state.notes,
        "started_at": state.started_at,
        "updated_at": state.updated_at,
    }


@mcp.tool()
def session_clear(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Archive the active session and remove the active link.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        dao = SessionDAO(project_root)
        archived = dao.clear()
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "archived": archived,
    }
