"""nspec MCP interface — Model Context Protocol server and tools.

Re-exports the FastMCP instance and main() entry point.
Tool modules (_query, _mutation, _checkout, _audit) register their tools
on the shared ``mcp`` instance at import time.
"""

# Import tool modules to register all @mcp.tool() functions at package import time
import nspec.interfaces.mcp._audit as _audit  # noqa: F401
import nspec.interfaces.mcp._checkout as _checkout  # noqa: F401
import nspec.interfaces.mcp._mutation as _mutation  # noqa: F401
import nspec.interfaces.mcp._query as _query  # noqa: F401
from nspec.interfaces.mcp.server import main, mcp

__all__ = ["main", "mcp"]
