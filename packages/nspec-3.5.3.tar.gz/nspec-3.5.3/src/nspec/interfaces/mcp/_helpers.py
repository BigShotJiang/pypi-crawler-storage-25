"""Shared helper functions for MCP tool modules."""

from __future__ import annotations

import logging
import os
import re
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nspec.dao.factory import DAORegistry

logger = logging.getLogger("nspec.mcp")


def _resolve_project_root(docs_root: Path | None = None) -> Path:
    """Resolve project root from config.toml.

    When *docs_root* is provided (legacy callers / tests), falls back to
    heuristic derivation.  Otherwise derives from ``NspecConfig.load()``.
    """
    if docs_root is None:
        from nspec.config import NspecConfig

        return NspecConfig.load().resolve_project_root()

    resolved = docs_root.resolve()

    # Common case: `.../docs`
    if resolved.name == "docs":
        return resolved.parent

    # Heuristic: docs roots contain `frs/` and `impls/`.
    if (resolved / "frs").exists() or (resolved / "impls").exists():
        return resolved.parent

    # Otherwise assume the caller already provided a project root.
    return resolved


def _resolve_code_root(project_root: Path) -> Path | None:
    """Resolve ``[project].code_root`` from config, if set.

    Returns the resolved absolute path to the external code directory,
    or None if integration mode is not configured.
    """
    from nspec.config import NspecConfig

    try:
        config = NspecConfig.load(project_root)
        return config.resolve_code_root()
    except Exception:
        logger.warning("Failed to resolve code root", exc_info=True)
        return None


def _normalize_id(raw: str) -> str:
    """Normalize and validate spec/epic IDs at the MCP boundary (E###/S###)."""
    from nspec.domain.ids import normalize_spec_ref

    return normalize_spec_ref(raw)


def _resolve_id(raw: str, known_ids: set[str]) -> str:
    """Resolve a fuzzy spec/epic ID against known IDs.

    Accepts prefixed IDs (S022, E007) and bare numbers (022, 7).
    """
    from nspec.domain.ids import resolve_fuzzy_id

    return resolve_fuzzy_id(raw, known_ids)


def _scan_known_ids(docs_root: Path) -> set[str]:
    """Lightweight scan of FR/IMPL filenames to collect known spec IDs.

    Avoids full dataset parsing — just extracts IDs from filenames.
    """

    from nspec.paths import get_paths

    pattern = re.compile(r"^(?:FR|IMPL)-([ES]\d{3}[a-z]?)-", re.IGNORECASE)
    paths = get_paths(docs_root)
    ids: set[str] = set()
    for directory in [
        paths.active_frs_dir,
        paths.active_impls_dir,
        paths.completed_done,
        paths.completed_superseded,
        paths.completed_rejected,
    ]:
        if directory.exists():
            for f in directory.iterdir():
                m = pattern.match(f.name)
                if m:
                    ids.add(m.group(1).upper())
    return ids


def _resolve_id_from_disk(raw: str, docs_root: Path) -> str:
    """Resolve a fuzzy ID using a lightweight disk scan.

    Tries prefixed normalization first (no disk needed).
    Falls back to scanning filenames for bare-number resolution.
    """
    from nspec.domain.ids import parse_bare_number, resolve_fuzzy_id

    # Fast path: prefixed IDs don't need disk scan
    try:
        return _normalize_id(raw)
    except ValueError:
        pass

    # Only scan disk if it looks like a bare number
    if parse_bare_number(raw) is None:
        raise ValueError(f"Invalid spec ref: {raw!r}")

    return resolve_fuzzy_id(raw, _scan_known_ids(docs_root))


def _invalid_id_error(raw: str) -> dict[str, Any]:
    return {
        "success": False,
        "error": f"Invalid ID: {raw!r} (expected E###, S###, or bare number)",
    }


def _dao(root: Path) -> DAORegistry:
    """Create a DAO registry for the given docs root."""
    from nspec.dao.factory import create_dao_registry

    return create_dao_registry(root, _resolve_project_root(root))


def _tool_error(message: str) -> dict[str, Any]:
    result: dict[str, Any] = {"success": False, "error": message}
    # Attempt error capture using caller context
    _try_capture_from_frame(message, depth=2)
    return result


def _exception_error(exc: Exception) -> dict[str, Any]:
    """Convert an exception to a tool error dict, and attempt error capture.

    S384: when the exception is a SpecIdCollisionError, surface the
    colliding spec ID, source paths, and a remediation hint so MCP
    callers see structured collision info instead of crashing or
    receiving an opaque message.
    """
    # Lazy import to avoid a circular dependency
    from nspec.domain.datasets import SpecIdCollisionError

    if isinstance(exc, SpecIdCollisionError):
        result: dict[str, Any] = {
            "success": False,
            "error": str(exc),
            "error_kind": "spec_id_collision",
            "spec_id": exc.spec_id,
            "label": exc.label,
            "collisions": [{"location": loc, "path": str(p)} for loc, p in exc.sources],
            "hint": (
                "Run unify_collisions() to resolve, or manually rename "
                "one of the conflicting files."
            ),
        }
        _try_capture_from_frame(str(exc), depth=2)
        return result

    result = {"success": False, "error": str(exc)}
    _try_capture_from_frame(str(exc), depth=2)
    return result


def _try_capture_from_frame(error_message: str, *, depth: int = 2) -> None:
    """Extract tool name and docs_root from the call stack and attempt capture.

    Walks up the stack to find the first MCP tool function (skipping internal
    helpers like _tool_error, _exception_error, _invalid_id_error).
    Extracts `root` or `docs_root` from the caller's locals for correct
    project targeting.
    """
    import sys

    _skip = {"_tool_error", "_exception_error", "_invalid_id_error", "_try_capture_from_frame"}
    try:
        frame = sys._getframe(depth)
        # Walk up to find the actual MCP tool function
        while frame and frame.f_code.co_name in _skip:
            frame = frame.f_back
        if not frame:
            return
        caller_name = frame.f_code.co_name
        # Extract docs_root from caller's locals (standard name in MCP tools)
        local_vars = frame.f_locals
        docs_root = local_vars.get("root") or local_vars.get("docs_root")
        if isinstance(docs_root, str):
            docs_root = Path(docs_root)
        _capture_mcp_error(caller_name, error_message, docs_root)
    except (ValueError, AttributeError):
        pass


def _capture_mcp_error(
    tool_name: str,
    error_message: str,
    docs_root: Path | None = None,
) -> None:
    """Attempt to capture an MCP error as a spec via the error agent."""
    try:
        from nspec.config import _find_config_file
        from nspec.orchestration.error_agent import ErrorContext, ErrorType, maybe_capture_error
        from nspec.runtime.session import SessionDAO

        root = _resolve_docs_root(str(docs_root) if docs_root else None)

        # Derive project root by searching upward for config.toml
        # (don't assume the docs dir is named "docs")
        config_file = _find_config_file(root)
        project_root = config_file.parent.parent.parent if config_file else root.parent

        # Get active spec from session state (but NOT task — MCP errors
        # are not task-specific and shouldn't trigger auto-park)
        dao = SessionDAO(project_root)
        state = dao.load()
        active_spec = state.spec_id if state else None

        ctx = ErrorContext(
            error_type=ErrorType.MCP,
            command_or_tool=tool_name,
            error_message=error_message,
            active_spec_id=active_spec,
            # active_task_id intentionally None: general MCP errors
            # shouldn't auto-park the active spec
        )
        maybe_capture_error(ctx, root)
    except Exception:
        logger.warning("Error capture failed", exc_info=True)


def _capture_test_gate_error(
    output: str,
    docs_root: Path | None = None,
    spec_id: str | None = None,
    task_id: str | None = None,
) -> None:
    """Attempt to capture a test gate failure as a spec via the error agent."""
    try:
        from nspec.orchestration.error_agent import ErrorContext, ErrorType, maybe_capture_error

        ctx = ErrorContext(
            error_type=ErrorType.TEST_GATE,
            command_or_tool="make test-quick",
            exit_code=1,
            stdout=output,
            error_message="Test gate failed",
            active_spec_id=spec_id,
            active_task_id=task_id,
        )
        maybe_capture_error(ctx, docs_root)
    except Exception:  # noqa: S110
        pass  # Never break MCP tools for error capture


def _post_mutation_validate(
    root: Path,
    project_root: Path | None = None,
) -> tuple[bool, dict[str, Any], bool]:
    """Run post-mutation validation and return (valid, payload, reject_mode).

    Returns a tuple of (is_valid, validation_payload, reject_mode) where
    payload contains structured validation results and reject_mode indicates
    whether the caller should reject invalid mutations (True) or warn (False).
    """
    from nspec.validation.validator import NspecValidator

    strict_mode = False
    reject_mode = True
    try:
        from nspec.config import NspecConfig as _Cfg

        if project_root is None:
            project_root = _resolve_project_root(root)
        _cfg = _Cfg.load(project_root)
        strict_mode = _cfg.validation.enforce_epic_grouping
        reject_mode = _cfg.strict.validation_on_mutate
    except Exception:
        # Can't load config — default to warn mode (non-blocking)
        reject_mode = False

    validator = NspecValidator(root, strict_mode=strict_mode)
    valid, errors = validator.validate()
    structured = [
        {
            "layer": ve.layer,
            "message": ve.message,
            "spec_id": ve.spec_id,
            "severity": ve.severity,
            "code": ve.code,
        }
        for ve in getattr(validator, "structured_errors", [])[:20]
    ]
    payload: dict[str, Any] = {
        "valid": valid,
        "error_count": len(errors),
        "errors": errors[:20],
        "structured_errors": structured,
    }
    return valid, payload, reject_mode  # type: ignore[return-value]


def _normalize_epic_id(
    raw: str, docs_root: Path | None = None
) -> tuple[str | None, dict[str, Any] | None]:
    """Normalize and validate an epic ID at the MCP boundary."""
    try:
        if docs_root is not None:
            epic_id = _resolve_id_from_disk(raw, docs_root)
        else:
            epic_id = _normalize_id(raw)
    except ValueError:
        return None, _invalid_id_error(raw)
    if not epic_id.upper().startswith("E"):
        return None, _tool_error(f"Invalid epic_id: {raw!r} (expected E###)")
    return epic_id, None


def _verify_epic_exists(*, epic_id: str, docs_root: Path) -> dict[str, Any] | None:
    """Verify that epic_id corresponds to a real Epic FR on disk.

    Uses a lightweight file scan (not a full dataset load) so create_spec can
    fail with a clear message even when unrelated specs are invalid.
    """

    from nspec.paths import get_paths

    paths = get_paths(docs_root)
    matches = sorted(paths.active_frs_dir.glob(f"FR-{epic_id}-*.md"))
    if not matches:
        return _tool_error(f"Epic {epic_id} not found in {paths.active_frs_dir}")

    try:
        content = matches[0].read_text()
    except OSError as e:
        return _tool_error(f"Failed to read epic file {matches[0]}: {e}")

    if not re.search(r"^\*\*Type:\*\*\s*Epic\b", content, re.MULTILINE):
        return _tool_error(
            f"{epic_id} is not an Epic (missing '**Type:** Epic' in {matches[0].name})"
        )

    return None


def _extract_spec_id_from_prompt(prompt: str) -> str | None:
    """Extract spec ID (e.g., S311) from a review prompt.

    Looks for patterns like 'spec S311' or 'S311:' in the first few lines.
    """
    import re as _re

    match = _re.search(r"\bS(\d{3,})\b", prompt[:500])
    return f"S{match.group(1)}" if match else None


def _resolve_docs_root(docs_root: str | None = None) -> Path:
    """Resolve docs root (spec root) path from config.

    Priority: explicit parameter > NSPEC_DOCS_ROOT env var >
    config.toml ``[paths].spec_root`` > ``.`` (config dir).

    When no config.toml exists and no NSPEC_* env vars are set,
    silently creates a minimal config (MCP is non-interactive).

    Also applies configurable emojis from config.toml.
    """
    from nspec.config import NspecConfig

    _config_project_root: Path | None = None

    if docs_root:
        root = Path(docs_root).resolve()
    elif env_root := os.environ.get("NSPEC_DOCS_ROOT"):
        root = Path(env_root).resolve()
    else:
        # Resolve from config.toml [paths].spec_root
        try:
            config = NspecConfig.load()
            root = config.resolve_spec_root()
            _config_project_root = config.resolve_project_root()
        except Exception:
            logger.warning("Config load failed, falling back to docs/", exc_info=True)
            root = Path("docs").resolve()
    logger.debug("docs_root: %s (resolved: %s, exists: %s)", root, root.resolve(), root.exists())

    # Use config-derived project root when available; fall back to heuristic
    project_root = _config_project_root or _resolve_project_root(root)
    try:
        from nspec.orchestration.init import needs_init

        if needs_init(project_root):
            # Only scaffold config — don't auto-create full project
            # User should explicitly call `init` tool for complete setup
            NspecConfig.scaffold(project_root)
    except OSError:
        pass  # Read-only filesystem or other I/O issue

    # Apply configurable emojis from config.toml
    try:
        from nspec.domain.statuses import configure as configure_statuses

        config = NspecConfig.load(project_root)
        configure_statuses(config.emojis, config.priorities)
    except Exception:
        logger.warning("Status configuration failed", exc_info=True)

    # Update last_activity timestamp on every MCP tool invocation (S120 audit trail)
    try:
        from nspec.runtime.session import SessionDAO

        SessionDAO(project_root).touch_activity()
    except Exception:  # noqa: S110
        pass  # Never break MCP tools for activity tracking

    return root


def _run_test_gate(*, cwd: Path | None = None) -> tuple[bool, str]:
    """Run make test-quick as a quality gate.

    Returns:
        (passed, output) tuple
    """
    # Load MCP timeout from config
    from nspec.config import NspecConfig

    _cfg = NspecConfig.load(cwd)
    _mcp_timeout = _cfg.timeouts.mcp_s

    try:
        result = subprocess.run(  # noqa: S603
            ["make", "test-quick"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=_mcp_timeout,
            cwd=str(cwd) if cwd else None,
        )
        passed = result.returncode == 0
        output = result.stdout + result.stderr
        return passed, output.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return False, f"Test gate failed: {e}"


def _get_task_tag(spec_id: str, task_id: str, docs_root: Path) -> str:
    """Get the verification tag for a task, defaulting to 'code'.

    Loads the IMPL file, parses tasks, and finds the matching task
    to read its tag. Returns 'code' if task not found or no tag set.
    """
    from nspec.domain.datasets import DatasetLoader
    from nspec.domain.tasks import TaskParser

    try:
        loader = DatasetLoader(docs_root)
        datasets = loader.load()
        impl = datasets.get_impl(spec_id)
        if impl and impl.tasks:
            parser = TaskParser()
            flat = parser.flatten(impl.tasks)
            for task in flat:
                if task.id == task_id:
                    return task.effective_tag
    except Exception:  # noqa: S110
        pass
    return "code"


def _compute_task_progress(impl_path: Path) -> dict[str, Any]:
    """Read an IMPL file and return task progress counts.

    Returns dict with 'done', 'total', 'remaining' keys.
    """

    try:
        content = impl_path.read_text()
    except OSError:
        return {}

    done = len(re.findall(r"^\s*- \[x\]", content, re.MULTILINE))
    obsolete = len(re.findall(r"^\s*- \[~\]", content, re.MULTILINE))
    deferred = len(re.findall(r"^\s*- \[>\]", content, re.MULTILINE))
    delegated = len(re.findall(r"^\s*- \[→", content, re.MULTILINE))
    pending = len(re.findall(r"^\s*- \[ \]", content, re.MULTILINE))
    total = done + obsolete + deferred + delegated + pending

    remaining: list[str] = []
    for line in content.split("\n"):
        if re.match(r"^\s*- \[ \]", line):
            remaining.append(line.strip().removeprefix("- [ ] "))  # noqa: PERF401

    return {
        "done": done + obsolete + deferred + delegated,
        "total": total,
        "remaining_tasks": remaining[:10],  # Cap at 10 to avoid huge responses
    }


def _find_epic_for_spec(spec_id: str, docs_root: Path) -> str | None:
    """Find the owning epic for a spec via the EpicMembershipDAO (S256)."""
    if spec_id.startswith("E"):
        return None
    try:
        from nspec.dao.markdown import MarkdownEpicMembershipDAO

        project_root = _resolve_project_root(docs_root)
        dao = MarkdownEpicMembershipDAO(docs_root, project_root)
        return dao.get_owner(spec_id)
    except Exception:
        return None


def _discover_epics_on_disk(docs_root: Path) -> list[str]:
    """Lightweight scan of active FR filenames to find epic IDs.

    Returns a sorted list of epic IDs (e.g. ["E001", "E006"]) found
    on disk, without loading full datasets.
    """
    from nspec.paths import get_paths

    try:
        paths = get_paths(docs_root)
        fr_dir = paths.active_frs_dir
        if not fr_dir.exists():
            return []
        import re

        pattern = re.compile(r"^FR-(E\d{3}[a-z]?)-", re.IGNORECASE)
        epics: set[str] = set()
        for f in fr_dir.iterdir():
            m = pattern.match(f.name)
            if m:
                epics.add(m.group(1).upper())
        return sorted(epics)
    except Exception:
        return []


def _to_bool(value: bool | str) -> bool:
    """Convert a bool-ish value to an actual bool.

    MCP clients may send booleans as strings ("true", "false").
    """
    if isinstance(value, bool):
        return value
    return str(value).lower() in ("true", "1", "yes")


# ---------------------------------------------------------------------------
# Stale-branch detection (S347)
# ---------------------------------------------------------------------------


def _check_stale_branch(
    spec_id: str,
    docs_root: Path,
) -> list[str]:
    """Check whether a spec's files were last modified on a different branch.

    Uses ``git log --all`` to find the most recent commit touching the spec's
    FR/IMPL files across all branches, then checks whether that commit is
    reachable from HEAD.  If not, the on-disk files may be stale relative to
    work done on another branch.

    Returns a (possibly empty) list of warning strings.  Never raises — git
    failures are silently swallowed so MCP operations are never blocked.
    """
    import shutil

    if not shutil.which("git"):
        return []

    project_root = _resolve_project_root(docs_root)

    # Locate spec files (FR + IMPL) via glob
    from nspec.paths import get_paths

    paths = get_paths(docs_root)
    spec_files: list[Path] = []
    for directory in [paths.active_frs_dir, paths.active_impls_dir]:
        if directory.exists():
            spec_files.extend(directory.glob(f"*-{spec_id}-*.md"))

    if not spec_files:
        return []

    warnings: list[str] = []
    cwd = str(project_root)

    # Get current branch name
    try:
        result = subprocess.run(  # noqa: S603
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=5,
            cwd=cwd,
        )
        if result.returncode != 0:
            return []
        current_branch = result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return []

    for spec_file in spec_files:
        try:
            # Find the most recent commit touching this file across ALL branches
            result = subprocess.run(  # noqa: S603
                [  # noqa: S607
                    "git",
                    "log",
                    "--all",
                    "--format=%H",
                    "-1",
                    "--",
                    str(spec_file),
                ],
                capture_output=True,
                text=True,
                timeout=5,
                cwd=cwd,
            )
            if result.returncode != 0 or not result.stdout.strip():
                continue  # No git history for this file

            latest_commit = result.stdout.strip()

            # Check if this commit is reachable from HEAD
            reachable = subprocess.run(  # noqa: S603
                ["git", "merge-base", "--is-ancestor", latest_commit, "HEAD"],  # noqa: S607
                capture_output=True,
                text=True,
                timeout=5,
                cwd=cwd,
            )
            if reachable.returncode == 0:
                continue  # Commit is on the current branch — no staleness

            # Find which branch contains this commit
            branch_result = subprocess.run(  # noqa: S603
                [  # noqa: S607
                    "git",
                    "branch",
                    "--all",
                    "--contains",
                    latest_commit,
                    "--format=%(refname:short)",
                ],
                capture_output=True,
                text=True,
                timeout=5,
                cwd=cwd,
            )
            branches = [
                b.strip().removeprefix("origin/")
                for b in branch_result.stdout.strip().splitlines()
                if b.strip() and b.strip() != current_branch
            ]
            # De-duplicate after stripping origin/
            branches = list(dict.fromkeys(branches))

            if branches:
                branch_name = branches[0]
                file_label = spec_file.name
                warnings.append(
                    f"Spec {spec_id} file {file_label} was last touched on "
                    f"branch '{branch_name}'. Current checkout is "
                    f"'{current_branch}'. The on-disk file may not reflect "
                    f"the spec's true progress."
                )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            continue  # Swallow git failures

    return warnings


def _attach_branch_warnings(
    response: dict[str, Any],
    warnings: list[str],
) -> None:
    """Merge stale-branch warnings into an MCP response dict.

    Appends to an existing ``warnings`` list if present, otherwise
    creates one.  Does nothing when *warnings* is empty.
    """
    if not warnings:
        return
    existing = response.get("warnings", [])
    existing.extend(warnings)
    response["warnings"] = existing
