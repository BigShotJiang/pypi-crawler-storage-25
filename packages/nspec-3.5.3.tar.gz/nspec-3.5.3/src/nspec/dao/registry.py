"""Module-level singleton for the DAO registry.

Provides ``get_registry()`` for production code and ``_reset_registry()``
for tests.
"""

from __future__ import annotations

from pathlib import Path  # noqa: TC003

from nspec.dao.factory import DAORegistry, create_dao_registry

_registry: DAORegistry | None = None


def get_registry(
    docs_root: Path,
    project_root: Path | None = None,
) -> DAORegistry:
    """Get or create the module-level DAO registry singleton."""
    global _registry
    if _registry is None:
        _registry = create_dao_registry(docs_root, project_root)
    return _registry


def _reset_registry() -> None:
    """Reset the singleton (for tests only)."""
    global _registry
    _registry = None
