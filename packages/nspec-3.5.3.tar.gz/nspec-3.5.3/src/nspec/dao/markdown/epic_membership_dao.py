"""Markdown backend for EpicMembershipDAO (S256).

This DAO is the canonical read/write interface for epic membership.

Membership is stored on the child spec via FR ``epic_id``. The DAO also
honors legacy data where an epic's ``deps`` list contains its child specs,
so unmigrated projects keep working. When there is a conflict, the
spec-owned ``epic_id`` wins.

Other modules MUST NOT scan epic ``deps`` to infer membership. The test
``tests/test_epic_membership_boundary.py`` enforces that boundary.
"""

from __future__ import annotations

import re
from pathlib import Path  # noqa: TC003
from typing import Any

from nspec.domain.ids import normalize_spec_ref
from nspec.paths import NspecPaths, get_paths

_EPIC_ID_LINE_RE = re.compile(r"^epic_id:\s*\S+\s*$", re.MULTILINE)


class MarkdownEpicMembershipDAO:
    """Canonical DAO for epic membership, backed by FR markdown files."""

    def __init__(
        self,
        docs_root: Path,
        project_root: Path | None = None,
        *,
        paths_config: NspecPaths | None = None,
    ) -> None:
        self._docs_root = docs_root
        self._project_root = project_root
        self._paths_config = paths_config

    # ------------------------------------------------------------------ reads

    def _load(self) -> Any:
        """Load a fresh datasets snapshot (reads from disk)."""
        from nspec.domain.datasets import DatasetLoader

        loader = DatasetLoader(
            docs_root=self._docs_root,
            paths_config=self._paths_config,
            project_root=self._project_root,
        )
        return loader.load()

    @staticmethod
    def compute_memberships_from_datasets(datasets: Any) -> dict[str, str]:
        """Compute {spec_id -> epic_id} from an already-loaded datasets snapshot.

        This is the single shared routine that knows how to derive epic
        membership. It is used by instance reads (``get_owner``, ``get_members``,
        ``all_memberships``) and is also exposed so hot-path callers that already
        have a datasets object in hand (e.g. the ordering module, reports) can
        reuse it without re-reading files.

        Spec-owned ``epic_id`` is authoritative; epic ``deps`` are consulted
        only as a fallback for specs that have not yet been migrated.
        """
        memberships: dict[str, str] = {}

        # Primary source: child FR epic_id field (active and completed).
        for spec_id, fr in datasets.active_frs.items():
            if fr.is_epic:
                continue
            owner = getattr(fr, "epic_id", None)
            if owner:
                memberships[spec_id] = owner
        for spec_id, fr in getattr(datasets, "completed_frs", {}).items():
            if fr.is_epic:
                continue
            owner = getattr(fr, "epic_id", None)
            if owner:
                memberships.setdefault(spec_id, owner)

        # Legacy fallback: epic deps that reference non-epic specs. Honor
        # both active and completed specs — completed specs are still members
        # of the epic they were shipped under (traceability). An "epic" here
        # is anything whose ID starts with E OR whose declared type is Epic,
        # so this fallback still works for older projects where the FR header
        # didn't encode a Type field.
        for epic_id, fr in datasets.active_frs.items():
            if not fr.is_epic:
                continue
            for dep_id in fr.deps or []:
                dep_fr = datasets.active_frs.get(dep_id) or getattr(
                    datasets, "completed_frs", {}
                ).get(dep_id)
                if dep_fr is None:
                    # Dep may point to an external/missing spec — still record
                    # membership by ID so legacy callers that look up by dep
                    # list still work.
                    memberships.setdefault(dep_id, epic_id)
                    continue
                if dep_fr.is_epic:
                    continue  # Epic-to-epic dep (blocking), not membership
                memberships.setdefault(dep_id, epic_id)

        return memberships

    def _compute_memberships(self, datasets: Any) -> dict[str, str]:
        """Instance wrapper kept for convenience within the DAO."""
        return self.compute_memberships_from_datasets(datasets)

    def get_owner(self, spec_id: str) -> str | None:
        spec_id = normalize_spec_ref(spec_id)
        datasets = self._load()
        return self._compute_memberships(datasets).get(spec_id)

    def get_members(self, epic_id: str) -> list[str]:
        epic_id = normalize_spec_ref(epic_id)
        datasets = self._load()
        memberships = self._compute_memberships(datasets)
        return sorted(sid for sid, eid in memberships.items() if eid == epic_id)

    def all_memberships(self) -> dict[str, str]:
        datasets = self._load()
        return self._compute_memberships(datasets)

    # ----------------------------------------------------------------- writes

    def _child_fr_path(self, spec_id: str) -> Path:
        paths = get_paths(
            self._docs_root,
            config=self._paths_config,
            project_root=self._project_root,
        )
        matches = sorted(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not matches:
            raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {paths.active_frs_dir}")
        return matches[0]

    def _verify_epic(self, epic_id: str) -> None:
        datasets = self._load()
        epic_fr = datasets.active_frs.get(epic_id)
        if epic_fr is None:
            raise FileNotFoundError(f"Epic {epic_id} not found")
        if not epic_fr.is_epic:
            raise ValueError(f"{epic_id} is not an Epic (type: {epic_fr.type})")

    def _rewrite_child(self, spec_id: str, epic_id: str | None) -> Path:
        """Write or clear the ``epic_id:`` line in the child FR.

        Placement: immediately after the ``deps:`` line if present, otherwise
        before the first ``##`` section, otherwise appended to the file.
        """
        fr_path = self._child_fr_path(spec_id)
        content = fr_path.read_text()

        # Remove any existing epic_id line.
        content = _EPIC_ID_LINE_RE.sub("", content)
        # Collapse any doubled blank lines created by the removal.
        content = re.sub(r"\n{3,}", "\n\n", content)

        if epic_id is not None:
            new_line = f"epic_id: {epic_id}"
            deps_match = re.search(r"^deps:\s*\[.*?\]\s*$", content, re.MULTILINE)
            if deps_match:
                insert_at = deps_match.end()
                content = content[:insert_at] + "\n" + new_line + content[insert_at:]
            else:
                section_match = re.search(r"^## ", content, re.MULTILINE)
                if section_match:
                    insert_at = section_match.start()
                    content = content[:insert_at] + new_line + "\n\n" + content[insert_at:]
                else:
                    content = content.rstrip() + "\n\n" + new_line + "\n"

        fr_path.write_text(content)

        # S926: invalidate DatasetLoader cache after rewriting FR file
        from nspec.domain.datasets import invalidate_dataset_cache

        invalidate_dataset_cache(self._docs_root)

        return fr_path

    def set_owner(self, spec_id: str, epic_id: str) -> Path:
        spec_id = normalize_spec_ref(spec_id)
        epic_id = normalize_spec_ref(epic_id)

        if spec_id.startswith("E"):
            raise ValueError(f"{spec_id} is an epic and cannot have an owning epic")

        self._verify_epic(epic_id)
        return self._rewrite_child(spec_id, epic_id)

    def clear_owner(self, spec_id: str) -> Path:
        spec_id = normalize_spec_ref(spec_id)
        return self._rewrite_child(spec_id, None)

    def move(self, spec_id: str, target_epic_id: str) -> dict[str, Any]:
        """Reassign ``spec_id`` to ``target_epic_id``.

        Also sweeps any legacy epic-``deps`` encoded membership so the
        child is only owned by the target. Blocking (spec-to-spec / epic-
        to-epic) deps are untouched.
        """
        spec_id = normalize_spec_ref(spec_id)
        target_epic_id = normalize_spec_ref(target_epic_id)

        self._verify_epic(target_epic_id)

        datasets = self._load()
        prior_owner = self._compute_memberships(datasets).get(spec_id)

        # Rewrite the child's epic_id.
        path = self._rewrite_child(spec_id, target_epic_id)

        # Sweep legacy encoding: remove spec from any epic's deps list where
        # it is recorded as a child.
        removed_from: list[str] = []
        for epic_id, fr in datasets.active_frs.items():
            if not fr.is_epic:
                continue
            if spec_id not in (fr.deps or []):
                continue
            # Skip target — the target may legitimately still encode the
            # spec as legacy membership; we rewrite it below too for cleanliness.
            try:
                from nspec.mutation import remove_dependency

                remove_dependency(
                    epic_id,
                    spec_id,
                    self._docs_root,
                    project_root=self._project_root,
                )
                removed_from.append(epic_id)
            except (ValueError, FileNotFoundError):
                continue

        return {
            "spec_id": spec_id,
            "target_epic_id": target_epic_id,
            "prior_owner": prior_owner,
            "removed_from_legacy_deps": removed_from,
            "path": path,
        }
