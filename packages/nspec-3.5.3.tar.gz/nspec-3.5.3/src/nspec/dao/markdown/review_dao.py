"""Markdown backend for ReviewDAO — delegates to crud.py."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003
from typing import Any


class MarkdownReviewDAO:
    """Review verdict operations on markdown IMPL files."""

    def __init__(self, docs_root: Path, project_root: Path | None = None) -> None:
        self._docs_root = docs_root
        self._project_root = project_root

    def get_verdict(self, spec_id: str) -> dict[str, Any]:
        from nspec.mutation import get_review_status

        return get_review_status(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )
