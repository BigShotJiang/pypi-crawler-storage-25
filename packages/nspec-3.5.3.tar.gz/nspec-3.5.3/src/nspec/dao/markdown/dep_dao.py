"""Markdown backend for DependencyDAO — delegates to crud.py."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003
from typing import Any


class MarkdownDependencyDAO:
    """Dependency and priority operations on markdown FR files."""

    def __init__(self, docs_root: Path, project_root: Path | None = None) -> None:
        self._docs_root = docs_root
        self._project_root = project_root

    def add(self, spec_id: str, dep_id: str) -> dict[str, Any]:
        from nspec.mutation import add_dependency

        result = add_dependency(
            spec_id,
            dep_id,
            self._docs_root,
            project_root=self._project_root,
        )
        # add_dependency returns dict[str, Path | str | None], coerce
        return dict(result)

    def remove(self, spec_id: str, dep_id: str) -> Path:
        from nspec.mutation import remove_dependency

        return remove_dependency(
            spec_id,
            dep_id,
            self._docs_root,
            project_root=self._project_root,
        )

    def move(self, spec_id: str, target_epic: str) -> dict[str, Any]:
        from nspec.mutation import move_dependency

        result = move_dependency(
            spec_id,
            target_epic,
            self._docs_root,
            project_root=self._project_root,
        )
        return dict(result)

    def set_priority(self, spec_id: str, priority: str) -> dict[str, Any]:
        from nspec.mutation import set_priority

        # set_priority returns Path, wrap it
        path = set_priority(
            spec_id,
            priority,
            self._docs_root,
            project_root=self._project_root,
        )
        return {"path": path, "spec_id": spec_id, "priority": priority}
