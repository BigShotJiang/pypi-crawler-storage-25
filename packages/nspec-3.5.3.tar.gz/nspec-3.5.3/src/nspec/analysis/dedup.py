"""Deterministic spec deduplication analysis.

Produces structured JSON output for the /ndedup skill. All matching is
algorithmic (normalized title comparison, token overlap, GitHub label
lookup) — no LLM guessing.

Usage:
    python -m nspec.analysis.dedup E006 [--docs-root ./docs]
    nspec dedup-analysis E006
"""

from __future__ import annotations

import json
import re
import subprocess
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path

from nspec.domain.datasets import DatasetLoader
from nspec.domain.statuses import (
    is_completed_status,
    is_paused_status,
    is_status_literal_active,
    is_superseded_status,
    parse_status_text,
)
from nspec.validation.validators import FRMetadata  # noqa: TC001

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class SpecEntry:
    spec_id: str
    title: str
    normalized_title: str
    fr_status: str
    impl_status: str
    epic_id: str | None
    bucket: str  # open, closed, superseded, deferred
    github_issue: int | None = None
    github_labels: list[str] = field(default_factory=list)
    classification: str | None = None  # bug, feature, ambiguous


@dataclass
class DuplicatePair:
    spec_a: str
    spec_b: str
    title_a: str
    title_b: str
    similarity: float
    match_type: str  # exact, near, cross_status
    status_a: str
    status_b: str
    recommendation: str  # supersede_a, supersede_b, review


@dataclass
class TopicGroup:
    name: str
    keywords: list[str]
    specs: list[str]


@dataclass
class DedupReport:
    epic_id: str
    census: dict[str, int]
    specs: list[SpecEntry]
    exact_duplicates: list[DuplicatePair]
    near_duplicates: list[DuplicatePair]
    cross_status_matches: list[DuplicatePair]
    topic_groups: list[TopicGroup]


# ---------------------------------------------------------------------------
# Title normalization
# ---------------------------------------------------------------------------

_NOISE_WORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "dare",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "out",
        "off",
        "over",
        "under",
        "again",
        "further",
        "then",
        "once",
        "that",
        "this",
        "these",
        "those",
        "and",
        "but",
        "or",
        "nor",
        "not",
        "so",
        "yet",
        "both",
        "each",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "no",
        "only",
        "own",
        "same",
        "than",
        "too",
        "very",
        "just",
        "because",
        "when",
        "where",
        "how",
        "all",
        "any",
        "every",
        "it",
        "its",
        "we",
        "they",
        "them",
        "their",
    }
)

_PREFIX_PATTERN = re.compile(r"^FR-[SE]\d+[a-z]?:\s*")
_FEAT_BUG_PREFIX = re.compile(r"^(feat|fix|bug|chore|refactor|enhancement):\s*", re.IGNORECASE)


def normalize_title(title: str) -> str:
    """Normalize a spec title for comparison.

    Strips FR-SXXX: prefix, lowercases, removes punctuation,
    removes noise words, sorts tokens for order-independent matching.
    """
    t = _PREFIX_PATTERN.sub("", title)
    t = _FEAT_BUG_PREFIX.sub("", t)
    t = t.lower()
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    tokens = [w for w in t.split() if w not in _NOISE_WORDS and len(w) > 1]
    return " ".join(sorted(tokens))


def token_set(title: str) -> set[str]:
    """Extract meaningful token set from a normalized title."""
    return set(title.split())


def jaccard_similarity(a: set[str], b: set[str]) -> float:
    """Jaccard index: |intersection| / |union|."""
    if not a and not b:
        return 1.0
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


# ---------------------------------------------------------------------------
# GitHub issue label lookup
# ---------------------------------------------------------------------------


def fetch_github_labels(repo: str, issue_number: int) -> list[str]:
    """Fetch labels for a GitHub issue via gh CLI."""
    try:
        result = subprocess.run(  # noqa: S603
            [  # noqa: S607
                "gh",
                "issue",
                "view",
                str(issue_number),
                "--repo",
                repo,
                "--json",
                "labels",
                "--jq",
                '[.labels[].name] | join(",")',
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return [lbl.strip() for lbl in result.stdout.strip().split(",") if lbl.strip()]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return []


def classify_from_labels(labels: list[str]) -> str | None:
    """Classify as bug/feature from GitHub labels."""
    label_set = {lbl.lower() for lbl in labels}
    has_severity = any("p0" in lbl or "p1" in lbl or "critical" in lbl for lbl in label_set)
    if "bug" in label_set or has_severity:
        return "bug"
    if "enhancement" in label_set or "feature" in label_set:
        return "feature"
    return None


_BUG_KEYWORDS = re.compile(
    r"\b(fix|bug|error|crash|silently?|fails?|incorrect|broken|rejects?|"
    r"wrong|missing|stale|mismatch|invalid|orphan|swallows?|doesn.t|can.t|"
    r"independently|parse error|resolves to|shows 0|despite)\b",
    re.IGNORECASE,
)

_FEATURE_KEYWORDS = re.compile(
    r"\b(feat|rfc|new|support|implement|enhance|command|skill|"
    r"template|audit|extract|dashboard|mode)\b",
    re.IGNORECASE,
)


def classify_from_title(title: str) -> str:
    """Classify as bug/feature/ambiguous from title keywords."""
    bug_score = len(_BUG_KEYWORDS.findall(title))
    feat_score = len(_FEATURE_KEYWORDS.findall(title))
    if bug_score > feat_score:
        return "bug"
    if feat_score > bug_score:
        return "feature"
    return "ambiguous"


# ---------------------------------------------------------------------------
# Topic groups
# ---------------------------------------------------------------------------

TOPIC_DEFINITIONS: list[tuple[str, list[str]]] = [
    ("TUI", ["tui ", "tui:", "dashboard", "detail view", "widget", "screen", "layout"]),
    ("Validation", ["validate", "validation", "checker", "validator"]),
    ("Dependencies", ["add_dep", "remove_dep", "dep_graph", "dependency"]),
    ("Review/Workflow", ["review_spec", "review ", "verdict", "execute_agent", "codex"]),
    ("Import/Triage", ["issue_import", "issue ", "triage", "tracker sync", "tracker ref"]),
    ("Templates", ["template", " impl ", "implementation notes", "loe", "durability"]),
    ("CLI/Skills", ["/ngo", "/nloop", "/nspec", "/nplan", "skill:", "command"]),
    ("Package/Refactor", ["move ", "extract ", "split ", "consolidate", "package", "module"]),
    ("Config/Infra", ["config", "spec_root", "epic_id", "priority"]),
    (
        "Context/Docs",
        [
            "claude.md",
            "claudemd",
            "context-audit",
            "doc-extract",
            "doc-map",
            "devprocess",
        ],
    ),
]


def assign_topics(title: str) -> list[str]:
    """Return topic names that match a spec title."""
    lower = title.lower()
    matched = []
    for name, keywords in TOPIC_DEFINITIONS:
        if any(kw in lower for kw in keywords):
            matched.append(name)
    return matched


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------

_GH_ISSUE_PATTERN = re.compile(r"Novabuiltdevv/nspec-issues#(\d+)")


def _extract_github_issue(fr: FRMetadata) -> int | None:
    """Extract GitHub issue number from FR file content."""
    try:
        content = fr.path.read_text()
        m = re.search(r"^github_issue:\s*\S+#(\d+)", content, re.MULTILINE)
        if m:
            return int(m.group(1))
        m = _GH_ISSUE_PATTERN.search(content)
        if m:
            return int(m.group(1))
    except OSError:
        pass
    return None


def _classify_bucket(fr_status: str, impl_status: str) -> str:
    """Classify a spec into open/closed/superseded/deferred."""
    if is_superseded_status(fr_status):
        return "superseded"
    if is_completed_status(fr_status) and is_completed_status(impl_status):
        return "closed"
    is_deferred = parse_status_text(fr_status) == "deferred"
    if (is_deferred or is_paused_status(impl_status)) and not is_superseded_status(fr_status):
        return "deferred"
    return "open"


def analyze_epic(  # noqa: C901
    epic_id: str,
    docs_root: Path | None = None,
    gh_repo: str = "Novabuiltdevv/nspec-issues",
    skip_github: bool = False,
) -> DedupReport:
    """Run full dedup analysis on an epic. Returns structured report."""

    if docs_root is None:
        docs_root = Path("docs")

    ds = DatasetLoader(docs_root).load()

    # Build spec entries for the target epic
    entries: list[SpecEntry] = []
    all_frs = {**ds.active_frs, **ds.completed_frs}
    all_impls = {**ds.active_impls, **ds.completed_impls}

    for spec_id, fr in all_frs.items():
        if fr.epic_id != epic_id and not fr.spec_id.startswith("E"):
            continue
        if fr.is_epic:
            continue

        impl = all_impls.get(spec_id)
        impl_status = impl.status if impl else "N/A"

        bucket = _classify_bucket(fr.status, impl_status)
        gh_issue = _extract_github_issue(fr)

        gh_labels: list[str] = []
        classification: str | None = None
        if gh_issue and not skip_github:
            gh_labels = fetch_github_labels(gh_repo, gh_issue)
            classification = classify_from_labels(gh_labels)

        if classification is None:
            classification = classify_from_title(fr.title)

        entries.append(
            SpecEntry(
                spec_id=spec_id,
                title=fr.title,
                normalized_title=normalize_title(fr.title),
                fr_status=fr.status,
                impl_status=impl_status,
                epic_id=fr.epic_id,
                bucket=bucket,
                github_issue=gh_issue,
                github_labels=gh_labels,
                classification=classification,
            )
        )

    # Census
    census: dict[str, int] = defaultdict(int)
    for e in entries:
        census[e.bucket] += 1
    census["total"] = len(entries)

    # Duplicate detection
    exact_dupes: list[DuplicatePair] = []
    near_dupes: list[DuplicatePair] = []
    cross_status: list[DuplicatePair] = []

    for i, a in enumerate(entries):
        for b in entries[i + 1 :]:
            if a.spec_id == b.spec_id:
                continue

            sim = jaccard_similarity(
                token_set(a.normalized_title),
                token_set(b.normalized_title),
            )

            if sim < 0.5:
                continue

            # Determine recommendation
            rec = _recommend(a, b)

            pair = DuplicatePair(
                spec_a=a.spec_id,
                spec_b=b.spec_id,
                title_a=a.title,
                title_b=b.title,
                similarity=round(sim, 3),
                match_type="exact" if sim >= 0.95 else "near",
                status_a=a.bucket,
                status_b=b.bucket,
                recommendation=rec,
            )

            if a.bucket != b.bucket:
                pair.match_type = "cross_status"
                cross_status.append(pair)
            elif sim >= 0.95:
                exact_dupes.append(pair)
            else:
                near_dupes.append(pair)

    # Topic groups
    topic_map: dict[str, list[str]] = defaultdict(list)
    for e in entries:
        if e.bucket in ("superseded", "closed"):
            continue
        for topic in assign_topics(e.title):
            topic_map[topic].append(e.spec_id)

    groups = [
        TopicGroup(name=name, keywords=kws, specs=topic_map.get(name, []))
        for name, kws in TOPIC_DEFINITIONS
        if topic_map.get(name)
    ]

    return DedupReport(
        epic_id=epic_id,
        census=dict(census),
        specs=entries,
        exact_duplicates=exact_dupes,
        near_duplicates=near_dupes,
        cross_status_matches=cross_status,
        topic_groups=groups,
    )


def _recommend(a: SpecEntry, b: SpecEntry) -> str:
    """Determine which spec to keep when duplicates are found."""
    # If one is already superseded, no action needed — it's already resolved
    if a.bucket == "superseded" or b.bucket == "superseded":
        return "already_resolved"

    # If one is closed and the other is open, supersede the open one
    if a.bucket == "closed" and b.bucket == "open":
        return f"supersede_{b.spec_id}"
    if b.bucket == "closed" and a.bucket == "open":
        return f"supersede_{a.spec_id}"

    # Both open: keep the more progressed or lower ID
    if a.bucket == "open" and b.bucket == "open":
        a_active = (
            is_status_literal_active(a.fr_status) or parse_status_text(a.impl_status) == "testing"
        )
        b_active = (
            is_status_literal_active(b.fr_status) or parse_status_text(b.impl_status) == "testing"
        )
        if a_active and not b_active:
            return f"supersede_{b.spec_id}"
        if b_active and not a_active:
            return f"supersede_{a.spec_id}"
        # Both same progress — keep lower spec ID
        a_num = int(re.search(r"\d+", a.spec_id).group())  # pyright: ignore[reportOptionalMemberAccess]
        b_num = int(re.search(r"\d+", b.spec_id).group())  # pyright: ignore[reportOptionalMemberAccess]
        if a_num <= b_num:
            return f"supersede_{b.spec_id}"
        return f"supersede_{a.spec_id}"

    return "review"


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def _serialize(obj: object) -> object:
    """JSON serializer for dataclasses."""
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)  # pyright: ignore[reportArgumentType]
    return str(obj)


def main(argv: list[str] | None = None) -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Spec dedup analysis")
    parser.add_argument("epic_id", help="Epic ID (e.g., E006)")
    parser.add_argument("--docs-root", type=Path, default=None)
    parser.add_argument(
        "--skip-github", action="store_true", help="Skip GitHub API calls for labels"
    )
    parser.add_argument("--format", choices=["json", "summary"], default="summary")
    args = parser.parse_args(argv)

    report = analyze_epic(
        epic_id=args.epic_id,
        docs_root=args.docs_root,
        skip_github=args.skip_github,
    )

    if args.format == "json":
        print(json.dumps(report, default=_serialize, indent=2))  # noqa: T201
        return

    # Summary format
    print(f"## Dedup Analysis — {report.epic_id}\n")  # noqa: T201
    print("### Census")  # noqa: T201
    for bucket, count in sorted(report.census.items()):
        print(f"  {bucket}: {count}")  # noqa: T201

    if report.exact_duplicates:
        print(f"\n### Exact Duplicates ({len(report.exact_duplicates)})")  # noqa: T201
        for d in report.exact_duplicates:
            print(f"  {d.spec_a} ↔ {d.spec_b} (sim={d.similarity}) → {d.recommendation}")  # noqa: T201
            print(f"    A: [{d.status_a}] {d.title_a}")  # noqa: T201
            print(f"    B: [{d.status_b}] {d.title_b}")  # noqa: T201

    if report.near_duplicates:
        print(f"\n### Near Duplicates ({len(report.near_duplicates)})")  # noqa: T201
        for d in report.near_duplicates:
            print(f"  {d.spec_a} ↔ {d.spec_b} (sim={d.similarity}) → {d.recommendation}")  # noqa: T201
            print(f"    A: [{d.status_a}] {d.title_a}")  # noqa: T201
            print(f"    B: [{d.status_b}] {d.title_b}")  # noqa: T201

    if report.cross_status_matches:
        print(f"\n### Cross-Status Matches ({len(report.cross_status_matches)})")  # noqa: T201
        for d in report.cross_status_matches:
            print(f"  {d.spec_a} ↔ {d.spec_b} (sim={d.similarity}) → {d.recommendation}")  # noqa: T201
            print(f"    A: [{d.status_a}] {d.title_a}")  # noqa: T201
            print(f"    B: [{d.status_b}] {d.title_b}")  # noqa: T201

    if report.topic_groups:
        print(f"\n### Topic Groups ({len(report.topic_groups)})")  # noqa: T201
        for g in report.topic_groups:
            print(f"  {g.name}: {', '.join(g.specs)}")  # noqa: T201

    # Classification summary for open specs
    open_specs = [s for s in report.specs if s.bucket == "open"]
    if open_specs:
        bugs = [s for s in open_specs if s.classification == "bug"]
        features = [s for s in open_specs if s.classification == "feature"]
        ambiguous = [s for s in open_specs if s.classification == "ambiguous"]
        print("\n### Classification (open specs)")  # noqa: T201
        print(f"  Bugs: {len(bugs)} — {', '.join(s.spec_id for s in bugs)}")  # noqa: T201
        print(f"  Features: {len(features)} — {', '.join(s.spec_id for s in features)}")  # noqa: T201
        if ambiguous:
            print(f"  Ambiguous: {len(ambiguous)} — {', '.join(s.spec_id for s in ambiguous)}")  # noqa: T201


if __name__ == "__main__":
    main()
