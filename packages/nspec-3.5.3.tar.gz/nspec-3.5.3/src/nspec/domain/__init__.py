"""Domain models and parsing for nspec.

Submodules:
    ids        — Spec ID parsing and normalization
    tasks      — Task and acceptance-criteria parsing for progress tracking
    statuses   — FR/IMPL status codes, priority levels, state validation
    datasets   — FR/IMPL dataset loading and metadata
    ordering   — Spec ordering and epic dependency resolution
    loe        — Level-of-effort estimation
    spec_types — Pluggable spec format types and registry
"""

from nspec.domain.datasets import DatasetLoader, DatasetStats, NspecDatasets
from nspec.domain.ids import (
    SpecRef,
    normalize_spec_ref,
    parse_bare_number,
    parse_spec_ref,
    resolve_fuzzy_id,
    spec_ref_number,
)
from nspec.domain.loe import LoeEstimate, LoeWeights, estimate_spec_loe
from nspec.domain.ordering import eligible_next_specs, ordered_specs, spec_to_epic_map
from nspec.domain.statuses import (
    FRStatus,
    FRStatusCode,
    IMPLStatus,
    IMPLStatusCode,
    Priority,
    configure,
    is_active_status,
    is_completed_status,
    parse_status_text,
)
from nspec.domain.tasks import (
    AcceptanceCriteria,
    AcceptanceCriteriaParser,
    Task,
    TaskParser,
)

__all__ = [
    # tasks
    "AcceptanceCriteria",
    "AcceptanceCriteriaParser",
    # datasets
    "DatasetLoader",
    "DatasetStats",
    # statuses
    "FRStatus",
    "FRStatusCode",
    "IMPLStatus",
    "IMPLStatusCode",
    # loe
    "LoeEstimate",
    "LoeWeights",
    "NspecDatasets",
    "Priority",
    # ids
    "SpecRef",
    "Task",
    "TaskParser",
    "configure",
    # ordering
    "eligible_next_specs",
    "estimate_spec_loe",
    "is_active_status",
    "is_completed_status",
    "normalize_spec_ref",
    "ordered_specs",
    "parse_bare_number",
    "parse_spec_ref",
    "parse_status_text",
    "resolve_fuzzy_id",
    "spec_ref_number",
    "spec_to_epic_map",
]
