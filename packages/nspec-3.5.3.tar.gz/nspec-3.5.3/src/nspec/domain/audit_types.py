"""Audit trail domain types — decisions, inventories, and handoffs.

Three artifact families stored in `.novabuilt.dev/nspec/audit/`:
- decisions: architectural choices made in conversation
- inventories: forensic exports (one-shot data captures)
- handoffs: per-session snapshots for cross-session continuity
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path  # noqa: TC003
from typing import Literal

AuditKind = Literal["decision", "inventory", "handoff"]
VALID_KINDS: frozenset[str] = frozenset({"decision", "inventory", "handoff"})
KIND_TO_DIR: dict[str, str] = {
    "decision": "decisions",
    "inventory": "inventories",
    "handoff": "handoffs",
}


@dataclass
class DecisionFrontmatter:
    """Frontmatter schema for decision artifacts."""

    decided_at: str
    topic: str
    participants: list[str] = field(default_factory=list)
    related_specs: list[str] = field(default_factory=list)
    outcome: str = ""


@dataclass
class InventoryFrontmatter:
    """Frontmatter schema for inventory artifacts."""

    generated_at: str
    topic: str
    source_query: str = ""
    count: int = 0
    related_specs: list[str] = field(default_factory=list)


@dataclass
class HandoffFrontmatter:
    """Frontmatter schema for handoff artifacts."""

    created_at: str
    topic: str
    epic_id: str = ""
    spec_id: str = ""
    phase: str = ""
    related_specs: list[str] = field(default_factory=list)


AuditFrontmatter = DecisionFrontmatter | InventoryFrontmatter | HandoffFrontmatter


@dataclass
class AuditArtifact:
    """A single audit artifact (frontmatter + body + path)."""

    kind: AuditKind
    frontmatter: AuditFrontmatter
    body: str
    path: Path
    slug: str

    @property
    def uri(self) -> str:
        """Stable artifact URI: audit://{kind}/{slug}."""
        return f"audit://{self.kind}/{self.slug}"


@dataclass
class AuditDataset:
    """Collection of audit artifacts grouped by kind."""

    decisions: list[AuditArtifact] = field(default_factory=list)
    inventories: list[AuditArtifact] = field(default_factory=list)
    handoffs: list[AuditArtifact] = field(default_factory=list)

    def by_kind(self, kind: AuditKind) -> list[AuditArtifact]:
        """Return artifacts for a given kind."""
        return getattr(self, KIND_TO_DIR[kind])

    @property
    def total(self) -> int:
        return len(self.decisions) + len(self.inventories) + len(self.handoffs)
