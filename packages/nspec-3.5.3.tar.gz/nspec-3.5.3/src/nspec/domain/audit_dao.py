"""Audit DAO — loads and writes audit trail artifacts.

Scans `.novabuilt.dev/nspec/audit/{decisions,inventories,handoffs}/`
and returns an AuditDataset. Uses a minimal YAML-subset frontmatter parser
(no PyYAML dependency required — our schema is controlled).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path  # noqa: TC003

from nspec.domain.audit_types import (
    KIND_TO_DIR,
    VALID_KINDS,
    AuditArtifact,
    AuditDataset,
    AuditKind,
    DecisionFrontmatter,
    HandoffFrontmatter,
    InventoryFrontmatter,
)

logger = logging.getLogger("nspec.audit")

AUDIT_REL_PATH = ".novabuilt.dev/nspec/audit"


def _parse_frontmatter(content: str) -> tuple[dict, str]:
    """Split YAML-subset frontmatter from markdown body.

    Expects content starting with '---\\n'. Supports: scalar strings,
    integers, lists of strings (bracket or dash notation).
    Raises ValueError if frontmatter is missing or malformed.
    """
    if not content.startswith("---"):
        raise ValueError("Missing YAML frontmatter (file must start with '---')")
    parts = content.split("---", 2)
    if len(parts) < 3:
        raise ValueError("Malformed frontmatter: missing closing '---'")
    raw = parts[1].strip()
    body = parts[2].strip()
    data = _parse_simple_yaml(raw)
    if not isinstance(data, dict):
        raise ValueError(f"Frontmatter must be a mapping, got: {type(data).__name__}")
    return data, body


def _parse_simple_yaml(raw: str) -> dict:
    """Parse a simple YAML subset (scalars, lists) into a dict."""
    result: dict = {}
    lines = raw.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.strip().startswith("#"):
            i += 1
            continue
        # Key: value pair
        match = re.match(r"^(\w[\w_]*)\s*:\s*(.*)", line)
        if not match:
            i += 1
            continue
        key = match.group(1)
        value_str = match.group(2).strip()

        # Inline list: [item1, item2]
        if value_str.startswith("["):
            items_raw = value_str.strip("[]")
            if items_raw.strip():
                result[key] = [_unquote(s.strip()) for s in items_raw.split(",") if s.strip()]
            else:
                result[key] = []
            i += 1
            continue

        # Block list: lines starting with "- "
        if value_str == "" or value_str == "[]":
            # Check if next lines are list items
            items: list[str] = []
            j = i + 1
            while j < len(lines) and lines[j].startswith("- "):
                items.append(_unquote(lines[j][2:].strip()))
                j += 1
            if items:
                result[key] = items
                i = j
                continue
            result[key] = [] if value_str == "[]" else ""
            i += 1
            continue

        # Scalar value
        result[key] = _parse_scalar(value_str)
        i += 1
    return result


def _unquote(s: str) -> str:
    """Remove surrounding quotes from a string."""
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


def _parse_scalar(s: str) -> str | int:
    """Parse a scalar: integer or string (unquoted)."""
    s = _unquote(s)
    try:
        return int(s)
    except ValueError:
        return s


def _serialize_yaml(data: dict) -> str:
    """Serialize a dict to simple YAML format (no dependency needed)."""
    lines: list[str] = []
    for key, value in data.items():
        if isinstance(value, list):
            if not value:
                lines.append(f"{key}: []")
            else:
                lines.append(f"{key}:")
                for item in value:
                    lines.append(f"- {_quote_if_needed(str(item))}")  # noqa: PERF401
        elif isinstance(value, int):
            lines.append(f"{key}: {value}")
        else:
            lines.append(f"{key}: {_quote_if_needed(str(value))}")
    return "\n".join(lines) + "\n"


def _quote_if_needed(s: str) -> str:
    """Quote a string if it contains special YAML characters."""
    if not s:
        return "''"
    if any(c in s for c in (":", "#", "[", "]", "{", "}", ",", "'", '"', "\n")):
        escaped = s.replace("'", "''")
        return f"'{escaped}'"
    return s


def _build_frontmatter(
    kind: AuditKind, data: dict
) -> DecisionFrontmatter | InventoryFrontmatter | HandoffFrontmatter:
    """Construct typed frontmatter from raw dict based on kind."""
    if kind == "decision":
        return DecisionFrontmatter(
            decided_at=str(data.get("decided_at", "")),
            topic=str(data.get("topic", "")),
            participants=data.get("participants", []),
            related_specs=data.get("related_specs", []),
            outcome=str(data.get("outcome", "")),
        )
    if kind == "inventory":
        return InventoryFrontmatter(
            generated_at=str(data.get("generated_at", "")),
            topic=str(data.get("topic", "")),
            source_query=str(data.get("source_query", "")),
            count=int(data.get("count", 0)),
            related_specs=data.get("related_specs", []),
        )
    return HandoffFrontmatter(
        created_at=str(data.get("created_at", "")),
        topic=str(data.get("topic", "")),
        epic_id=str(data.get("epic_id", "")),
        spec_id=str(data.get("spec_id", "")),
        phase=str(data.get("phase", "")),
        related_specs=data.get("related_specs", []),
    )


class AuditDAO:
    """Data access object for audit trail artifacts."""

    def __init__(self, audit_root: Path) -> None:
        self._root = audit_root

    @classmethod
    def from_project_root(cls, project_root: Path) -> AuditDAO:
        return cls(project_root / AUDIT_REL_PATH)

    @property
    def root(self) -> Path:
        return self._root

    def load(self) -> AuditDataset:
        """Load all audit artifacts from disk.

        Raises ValueError on malformed frontmatter (fail loud, no silent skips).
        """
        dataset = AuditDataset()
        for kind in VALID_KINDS:
            kind_dir = self._root / KIND_TO_DIR[kind]
            if not kind_dir.is_dir():
                continue
            artifacts = self._load_kind(kind, kind_dir)  # type: ignore[arg-type]
            setattr(dataset, KIND_TO_DIR[kind], artifacts)
        return dataset

    def _load_kind(self, kind: AuditKind, kind_dir: Path) -> list[AuditArtifact]:
        """Load all artifacts of a given kind from a directory."""
        artifacts: list[AuditArtifact] = []
        for path in sorted(kind_dir.glob("*.md")):
            content = path.read_text(encoding="utf-8")
            data, body = _parse_frontmatter(content)
            frontmatter = _build_frontmatter(kind, data)
            slug = path.stem
            artifacts.append(
                AuditArtifact(
                    kind=kind,
                    frontmatter=frontmatter,
                    body=body,
                    path=path,
                    slug=slug,
                )
            )
        return artifacts

    def find_by_slug(self, slug: str) -> AuditArtifact | None:
        """Find an artifact by its slug (filename without .md)."""
        for kind in VALID_KINDS:
            kind_dir = self._root / KIND_TO_DIR[kind]
            path = kind_dir / f"{slug}.md"
            if path.is_file():
                content = path.read_text(encoding="utf-8")
                data, body = _parse_frontmatter(content)
                frontmatter = _build_frontmatter(kind, data)  # type: ignore[arg-type]
                return AuditArtifact(
                    kind=kind,  # type: ignore[arg-type]
                    frontmatter=frontmatter,
                    body=body,
                    path=path,
                    slug=slug,
                )
        return None

    def write(self, kind: AuditKind, slug: str, frontmatter_data: dict, body: str) -> Path:
        """Write an audit artifact to disk.

        Creates the kind directory if it doesn't exist.
        Returns the path to the written file.
        """
        kind_dir = self._root / KIND_TO_DIR[kind]
        kind_dir.mkdir(parents=True, exist_ok=True)
        path = kind_dir / f"{slug}.md"
        yaml_str = _serialize_yaml(frontmatter_data)
        content = f"---\n{yaml_str}---\n\n{body}\n"
        path.write_text(content, encoding="utf-8")
        return path
