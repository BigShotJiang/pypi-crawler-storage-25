"""Centralized status definitions for nspec tooling.

This is the SINGLE SOURCE OF TRUTH for all status emojis, codes, and text.
All other modules should import from here - DO NOT duplicate these definitions.

Emojis are configurable via [emojis] section in config.toml.
Use configure() to apply overrides and reset() to restore defaults.
For dynamic access (immune to import-time caching), use accessor functions:
  get_all_status_emojis(), get_status_emoji_pattern()
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import IntEnum

# =============================================================================
# FR (Feature Request) Statuses
# =============================================================================


class FRStatusCode(IntEnum):
    """FR status codes for programmatic use."""

    PROPOSED = 0
    IN_DESIGN = 1
    ACTIVE = 2
    COMPLETED = 3
    REJECTED = 4
    SUPERSEDED = 5
    DEFERRED = 6


@dataclass(frozen=True)
class FRStatus:
    """FR status definition."""

    code: int
    emoji: str
    text: str

    @property
    def full(self) -> str:
        """Full status string (emoji + text)."""
        return f"{self.emoji} {self.text}"


# =============================================================================
# IMPL (Implementation) Statuses
# =============================================================================


class IMPLStatusCode(IntEnum):
    """IMPL status codes for programmatic use."""

    PLANNING = 0
    ACTIVE = 1
    TESTING = 2
    READY = 3  # Ready for archival (distinct from FR Completed)
    PAUSED = 4
    HOLD = 5
    EXCEPTION = 6  # Subagent timeout or unexpected failure - needs human triage


@dataclass(frozen=True)
class IMPLStatus:
    """IMPL status definition."""

    code: int
    emoji: str
    text: str

    @property
    def full(self) -> str:
        """Full status string (emoji + text)."""
        return f"{self.emoji} {self.text}"


# =============================================================================
# Priority Definitions
# =============================================================================


@dataclass(frozen=True)
class Priority:
    """Priority definition."""

    code: str  # P0, P1, P2, P3
    emoji: str
    rank: int  # Lower = higher priority

    @property
    def full(self) -> str:
        """Full priority string (emoji + code)."""
        return f"{self.emoji} {self.code}"


# =============================================================================
# Default Emoji Values
# =============================================================================

_DEFAULT_FR_EMOJIS: dict[int, str] = {
    0: "🟡",  # Proposed
    1: "🔵",  # In Design
    2: "🔵",  # Active
    3: "✅",  # Completed
    4: "❌",  # Rejected
    5: "🔄",  # Superseded
    6: "⏳",  # Deferred
}

_DEFAULT_FR_TEXTS: dict[int, str] = {
    0: "Proposed",
    1: "In Design",
    2: "Active",
    3: "Completed",
    4: "Rejected",
    5: "Superseded",
    6: "Deferred",
}

_DEFAULT_IMPL_EMOJIS: dict[int, str] = {
    0: "🟡",  # Planning
    1: "🔵",  # Active
    2: "🧪",  # Testing
    3: "🟠",  # Ready
    4: "⏳",  # Paused
    5: "⚪",  # Hold
    6: "⚠️",  # Exception
}

_DEFAULT_IMPL_TEXTS: dict[int, str] = {
    0: "Planning",
    1: "Active",
    2: "Testing",
    3: "Ready",
    4: "Paused",
    5: "Hold",
    6: "Exception",
}

_DEFAULT_PRIORITY_EMOJIS: dict[str, str] = {
    "P0": "🔥",
    "P1": "🟠",
    "P2": "🟡",
    "P3": "🔵",
}

_DEFAULT_DEP_EMOJIS: dict[str, str] = {
    "COMPLETED": "✅",
    "ACTIVE": "🔵",
    "PROPOSED": "🟡",
    "REJECTED": "❌",
    "SUPERSEDED": "🔄",
    "TESTING": "🧪",
    "PAUSED": "⏳",
    "EXCEPTION": "⚠️",
    "UNKNOWN": "❓",
}

_DEFAULT_EPIC_EMOJIS: dict[str, str] = {
    "PROPOSED": "📋",
    "ACTIVE": "🚀",
    "COMPLETED": "🏆",
}

# Legacy emoji strings that may appear in existing files on disk.
# These map to the same status codes as the canonical emojis but use
# different emoji characters.  Used ONLY for parsing (reading), never
# for writing.  Centralised here so no other module needs its own copy.
LEGACY_FR_STATUSES: dict[str, tuple[int, str, str]] = {
    "🟢 Active": (2, "🟢", "Active"),
}

LEGACY_IMPL_STATUSES: dict[str, tuple[int, str, str]] = {
    "📋 Planning": (0, "📋", "Planning"),
    "🚧 Active": (1, "🚧", "Active"),
    "✅ Completed": (3, "✅", "Completed"),
    "⏸️ Paused": (4, "⏸️", "Paused"),
}

# =============================================================================
# Mutable Module-Level State (rebuilt by configure/reset)
# =============================================================================

# FR status definitions - keyed by code
FR_STATUSES: dict[int, FRStatus] = {}

# Reverse lookup: full status string -> FRStatus
FR_STATUS_BY_TEXT: dict[str, FRStatus] = {}

# Terminal FR statuses (cannot transition out of these)
FR_TERMINAL_CODES = {FRStatusCode.COMPLETED, FRStatusCode.REJECTED, FRStatusCode.SUPERSEDED}

# IMPL status definitions - keyed by code
IMPL_STATUSES: dict[int, IMPLStatus] = {}

# Reverse lookup: full status string -> IMPLStatus
IMPL_STATUS_BY_TEXT: dict[str, IMPLStatus] = {}

# Terminal IMPL statuses
IMPL_TERMINAL_CODES = {IMPLStatusCode.READY}

# Priorities (unified for all types)
SPEC_PRIORITIES: dict[str, Priority] = {}
ALL_PRIORITIES: dict[str, Priority] = {}

# Priority rank for sorting (lower = higher priority)
PRIORITY_RANK: dict[str, int] = {}


def default_priority() -> str:
    """Return the lowest-priority configured level (last in SPEC_PRIORITIES).

    Falls back to "P3" if priorities haven't been configured yet.
    """
    if SPEC_PRIORITIES:
        return list(SPEC_PRIORITIES.keys())[-1]
    return "P3"


# Priority display names
PRIORITY_NAMES: dict[str, str] = {
    "P0": "CRITICAL",
    "P1": "HIGH",
    "P2": "MEDIUM",
    "P3": "LOW",
}


class DepDisplayEmoji:
    """Emojis used for displaying dependency status in nspec table."""

    COMPLETED = "✅"
    ACTIVE = "🔵"
    PROPOSED = "🟡"
    REJECTED = "❌"
    SUPERSEDED = "🔄"
    TESTING = "🧪"
    PAUSED = "⏳"
    EXCEPTION = "⚠️"
    UNKNOWN = "❓"


class EpicDisplayEmoji:
    """Emojis used for displaying epic status (derived from dependencies).

    Epic status is calculated, not stored:
    - PROPOSED: No deps have started (all proposed/planning)
    - ACTIVE: At least one dep is active/testing
    - COMPLETED: All deps are completed
    """

    PROPOSED = "📋"  # Clipboard - planning phase
    ACTIVE = "🚀"  # Rocket - work in progress
    COMPLETED = "🏆"  # Trophy - delivered


# All possible status emojis (for regex pattern matching)
ALL_STATUS_EMOJIS = ""

# Regex pattern to match status emoji at start of string
# \uFE0F is the variation selector that some emojis (e.g. ⏸️) include
STATUS_EMOJI_PATTERN = ""

# Priority-line regex patterns (rebuilt by _build()).
# PRIORITY_LINE_PATTERN: anchored with re.MULTILINE, captures the priority code.
#   Use with re.search to extract the current priority from FR content.
#   Permits trailing content after the code (e.g., for multi-field lines).
# PRIORITY_LINE_SUB_PATTERN: non-anchored, non-capturing — matches the
#   `**Priority:** [emoji] CODE` prefix for re.sub-based replacement.
# PRIORITY_LINE_STRICT_PATTERN: fully anchored (^...$), capturing. The
#   validator uses this to assert the priority line is exactly
#   `**Priority:** [emoji] CODE` with no trailing content.
PRIORITY_LINE_PATTERN = ""
PRIORITY_LINE_SUB_PATTERN = ""
PRIORITY_LINE_STRICT_PATTERN = ""

# TUI display terminal-status emoji set — the emojis used to render
# "rendering-terminal" status indicators in the TUI table and accordion
# widgets. Defined here so widgets import a single source of truth instead
# of redeclaring the literal set.
DISPLAY_TERMINAL_EMOJIS: frozenset[str] = frozenset({"✅", "🔄", "❌"})


# =============================================================================
# Build / Configure / Reset
# =============================================================================


def _build(
    fr_emojis: dict[int, str] | None = None,
    impl_emojis: dict[int, str] | None = None,
    priority_emojis: dict[str, str] | None = None,
    dep_emojis: dict[str, str] | None = None,
    epic_emojis: dict[str, str] | None = None,
    priority_levels: list[str] | None = None,
    priority_default_emoji: str = "⚪",
) -> None:
    """Rebuild all module-level status dicts from emoji mappings."""
    global FR_STATUSES, FR_STATUS_BY_TEXT
    global IMPL_STATUSES, IMPL_STATUS_BY_TEXT
    global SPEC_PRIORITIES, ALL_PRIORITIES, PRIORITY_RANK
    global ALL_STATUS_EMOJIS, STATUS_EMOJI_PATTERN

    fe = fr_emojis or _DEFAULT_FR_EMOJIS
    ie = impl_emojis or _DEFAULT_IMPL_EMOJIS
    pe = priority_emojis or _DEFAULT_PRIORITY_EMOJIS
    de = dep_emojis or _DEFAULT_DEP_EMOJIS
    ee = epic_emojis or _DEFAULT_EPIC_EMOJIS
    if priority_levels is not None:
        levels = priority_levels
    else:
        from nspec.config import PrioritiesConfig

        levels = PrioritiesConfig().levels

    # FR statuses
    FR_STATUSES.clear()
    for code in _DEFAULT_FR_TEXTS:
        FR_STATUSES[code] = FRStatus(
            code, fe.get(code, _DEFAULT_FR_EMOJIS[code]), _DEFAULT_FR_TEXTS[code]
        )
    FR_STATUS_BY_TEXT.clear()
    FR_STATUS_BY_TEXT.update({s.full: s for s in FR_STATUSES.values()})

    # IMPL statuses
    IMPL_STATUSES.clear()
    for code in _DEFAULT_IMPL_TEXTS:
        IMPL_STATUSES[code] = IMPLStatus(
            code, ie.get(code, _DEFAULT_IMPL_EMOJIS[code]), _DEFAULT_IMPL_TEXTS[code]
        )
    IMPL_STATUS_BY_TEXT.clear()
    IMPL_STATUS_BY_TEXT.update({s.full: s for s in IMPL_STATUSES.values()})

    # Priorities — driven by levels list (default P0-P3, extensible via config)
    SPEC_PRIORITIES.clear()
    for rank, pcode in enumerate(levels):
        emoji = pe.get(pcode, priority_default_emoji)
        SPEC_PRIORITIES[pcode] = Priority(pcode, emoji, rank)
    ALL_PRIORITIES.clear()
    ALL_PRIORITIES.update(SPEC_PRIORITIES)
    PRIORITY_RANK.clear()
    PRIORITY_RANK.update({p.code: p.rank for p in ALL_PRIORITIES.values()})

    # Dependency display emojis
    for attr in (
        "COMPLETED",
        "ACTIVE",
        "PROPOSED",
        "REJECTED",
        "SUPERSEDED",
        "TESTING",
        "PAUSED",
        "EXCEPTION",
        "UNKNOWN",
    ):
        setattr(DepDisplayEmoji, attr, de.get(attr, _DEFAULT_DEP_EMOJIS[attr]))

    # Epic display emojis
    for attr in ("PROPOSED", "ACTIVE", "COMPLETED"):
        setattr(EpicDisplayEmoji, attr, ee.get(attr, _DEFAULT_EPIC_EMOJIS[attr]))

    # Collect all unique emoji base characters for pattern matching
    all_emojis_set: set[str] = set()
    for s in FR_STATUSES.values():
        all_emojis_set.add(s.emoji.rstrip("\ufe0f"))
    for s in IMPL_STATUSES.values():
        all_emojis_set.add(s.emoji.rstrip("\ufe0f"))
    for p in SPEC_PRIORITIES.values():
        all_emojis_set.add(p.emoji.rstrip("\ufe0f"))
    for attr in (
        "COMPLETED",
        "ACTIVE",
        "PROPOSED",
        "REJECTED",
        "SUPERSEDED",
        "TESTING",
        "PAUSED",
        "EXCEPTION",
        "UNKNOWN",
    ):
        all_emojis_set.add(getattr(DepDisplayEmoji, attr).rstrip("\ufe0f"))
    for attr in ("PROPOSED", "ACTIVE", "COMPLETED"):
        all_emojis_set.add(getattr(EpicDisplayEmoji, attr).rstrip("\ufe0f"))
    # Add legacy emojis that might appear in existing files
    all_emojis_set.update({"🟢", "🔴", "📋", "🚧", "⏸"})

    ALL_STATUS_EMOJIS = "".join(sorted(all_emojis_set))  # pyright: ignore[reportConstantRedefinition]
    STATUS_EMOJI_PATTERN = rf"^([{ALL_STATUS_EMOJIS}]\uFE0F?)\s+"  # pyright: ignore[reportConstantRedefinition]

    # Rebuild priority-line patterns from the current SPEC_PRIORITIES.
    # All three variants accept the legacy emoji+code format (pre-S332) and the
    # words-only format (post-S332) so in-flight file migrations still parse.
    # Emoji base chars have variation selectors stripped before joining so the
    # character class matches the raw codepoints and the optional `\uFE0F?`
    # captures the variation selector separately (matches validator behavior).
    global PRIORITY_LINE_PATTERN, PRIORITY_LINE_SUB_PATTERN, PRIORITY_LINE_STRICT_PATTERN
    _p_emojis = "".join(p.emoji.rstrip("\ufe0f") for p in SPEC_PRIORITIES.values())
    _p_emojis_escaped = re.escape(_p_emojis)
    _p_codes = "|".join(re.escape(p) for p in sorted(SPEC_PRIORITIES, key=len, reverse=True))
    PRIORITY_LINE_PATTERN = (  # pyright: ignore[reportConstantRedefinition]
        rf"^\*\*Priority:\*\*\s+(?:[{_p_emojis_escaped}]\uFE0F?\s+)?({_p_codes})"
    )
    PRIORITY_LINE_SUB_PATTERN = (  # pyright: ignore[reportConstantRedefinition]
        rf"\*\*Priority:\*\*\s+(?:[{_p_emojis_escaped}]\uFE0F?\s+)?(?:{_p_codes})"
    )
    PRIORITY_LINE_STRICT_PATTERN = (  # pyright: ignore[reportConstantRedefinition]
        rf"^\*\*Priority:\*\*\s+(?:[{_p_emojis_escaped}]\uFE0F?\s+)?({_p_codes})$"
    )


def configure(  # noqa: C901
    emojis_config: object | None = None,
    priorities_config: object | None = None,
) -> None:
    """Apply emoji overrides from config and rebuild all status dicts.

    Args:
        emojis_config: An EmojisConfig instance (or any object with matching attrs).
                       Pass None to use defaults.
        priorities_config: A PrioritiesConfig instance (or any object with
                          levels/emojis/default_emoji attrs). Pass None for
                          default P0-P3.
    """
    if emojis_config is None and priorities_config is None:
        _build()
        return
    if emojis_config is None:
        emojis_config = object()  # empty sentinel — all getattr() will return None

    # Build override dicts from config attributes
    fr_emojis = dict(_DEFAULT_FR_EMOJIS)
    config_fr_map = {
        "fr_proposed": 0,
        "fr_in_design": 1,
        "fr_active": 2,
        "fr_completed": 3,
        "fr_rejected": 4,
        "fr_superseded": 5,
        "fr_deferred": 6,
    }
    for attr, code in config_fr_map.items():
        val = getattr(emojis_config, attr, None)
        if val is not None:
            fr_emojis[code] = val

    impl_emojis = dict(_DEFAULT_IMPL_EMOJIS)
    config_impl_map = {
        "impl_planning": 0,
        "impl_active": 1,
        "impl_testing": 2,
        "impl_ready": 3,
        "impl_paused": 4,
        "impl_hold": 5,
        "impl_exception": 6,
    }
    for attr, code in config_impl_map.items():
        val = getattr(emojis_config, attr, None)
        if val is not None:
            impl_emojis[code] = val

    priority_emojis = dict(_DEFAULT_PRIORITY_EMOJIS)
    # Apply legacy [emojis] priority overrides for P0-P3
    for pcode in list(_DEFAULT_PRIORITY_EMOJIS.keys()):
        val = getattr(emojis_config, f"priority_{pcode.lower()}", None)
        if val is not None:
            priority_emojis[pcode] = val
    # Apply [priorities] config if present (takes precedence over [emojis])
    priority_levels: list[str] | None = None
    priority_default_emoji: str = "⚪"
    if priorities_config is not None:
        cfg_levels = getattr(priorities_config, "levels", None)
        if isinstance(cfg_levels, list) and cfg_levels:
            priority_levels = cfg_levels
        cfg_emojis = getattr(priorities_config, "emojis", None)
        if isinstance(cfg_emojis, dict):
            priority_emojis.update(cfg_emojis)
        cfg_default = getattr(priorities_config, "default_emoji", None)
        if cfg_default is not None:
            priority_default_emoji = str(cfg_default)

    dep_emojis = dict(_DEFAULT_DEP_EMOJIS)
    config_dep_map = {
        "dep_completed": "COMPLETED",
        "dep_active": "ACTIVE",
        "dep_proposed": "PROPOSED",
        "dep_rejected": "REJECTED",
        "dep_superseded": "SUPERSEDED",
        "dep_testing": "TESTING",
        "dep_paused": "PAUSED",
        "dep_exception": "EXCEPTION",
        "dep_unknown": "UNKNOWN",
    }
    for attr, key in config_dep_map.items():
        val = getattr(emojis_config, attr, None)
        if val is not None:
            dep_emojis[key] = val

    epic_emojis = dict(_DEFAULT_EPIC_EMOJIS)
    config_epic_map = {
        "epic_proposed": "PROPOSED",
        "epic_active": "ACTIVE",
        "epic_completed": "COMPLETED",
    }
    for attr, key in config_epic_map.items():
        val = getattr(emojis_config, attr, None)
        if val is not None:
            epic_emojis[key] = val

    _build(
        fr_emojis,
        impl_emojis,
        priority_emojis,
        dep_emojis,
        epic_emojis,
        priority_levels=priority_levels,
        priority_default_emoji=priority_default_emoji,
    )


def reset() -> None:
    """Restore all emojis to defaults. Useful for test isolation."""
    _build()


# =============================================================================
# Accessor Functions (immune to import-time caching)
# =============================================================================


def get_all_status_emojis() -> str:
    """Return current ALL_STATUS_EMOJIS string."""
    return ALL_STATUS_EMOJIS


def get_status_emoji_pattern() -> str:
    """Return current STATUS_EMOJI_PATTERN regex string."""
    return STATUS_EMOJI_PATTERN


# =============================================================================
# Helper Functions
# =============================================================================


def get_fr_status(code: int) -> FRStatus | None:
    """Get FR status by code."""
    return FR_STATUSES.get(code)


def get_impl_status(code: int) -> IMPLStatus | None:
    """Get IMPL status by code."""
    return IMPL_STATUSES.get(code)


def get_priority(code: str) -> Priority | None:
    """Get priority by code (P0-P3)."""
    return ALL_PRIORITIES.get(code.upper())


# =============================================================================
# Config-authoritative resolve functions (S331)
# =============================================================================


def resolve_status(word: str, *, kind: str = "any") -> str:
    """Return the config-driven emoji for a status word.

    Looks up *word* (case-insensitive) in the configured FR and/or IMPL
    status dicts.  The emoji returned always reflects any config.toml
    overrides applied via ``configure()``.

    When *kind* is ``"any"`` (default), IMPL statuses take precedence for
    shared words like ``"Active"`` because IMPL is the more common context
    in nspec tooling.  Use ``kind="fr"`` or ``kind="impl"`` to force
    disambiguation.

    Args:
        word: Status text such as ``"Active"``, ``"planning"``, ``"Testing"``.
        kind: ``"fr"`` to search FR only, ``"impl"`` to search IMPL only,
              ``"any"`` (default) to search both (IMPL first).

    Returns:
        The emoji string (e.g. ``"🔵"``).

    Raises:
        KeyError: If *word* does not match any known status in the
                  requested category.
        ValueError: If *kind* is not one of ``"fr"``, ``"impl"``, ``"any"``.
    """
    normalised = word.strip().lower()
    kind_lower = kind.lower()
    if kind_lower not in ("fr", "impl", "any"):
        raise ValueError(f"kind must be 'fr', 'impl', or 'any', got {kind!r}")

    # Build search order based on kind
    search: list[dict[int, FRStatus] | dict[int, IMPLStatus]] = []
    if kind_lower in ("impl", "any"):
        search.append(IMPL_STATUSES)
    if kind_lower in ("fr", "any"):
        search.append(FR_STATUSES)

    for status_dict in search:
        for status in status_dict.values():
            if status.text.lower() == normalised:
                return status.emoji
    raise KeyError(f"Unknown status word: {word!r}")


def resolve_priority(word: str) -> str:
    """Return the config-driven emoji for a priority code.

    Looks up *word* (case-insensitive, e.g. ``"P1"``, ``"p2"``) in the
    configured priority dict.  The emoji returned always reflects any
    config.toml overrides applied via ``configure()``.

    Args:
        word: Priority code such as ``"P0"``, ``"P1"``, ``"p2"``.

    Returns:
        The emoji string (e.g. ``"🟠"``).

    Raises:
        KeyError: If *word* does not match any configured priority.
    """
    code = word.strip().upper()
    pri = ALL_PRIORITIES.get(code)
    if pri is None:
        raise KeyError(f"Unknown priority code: {word!r}")
    return pri.emoji


def parse_status_text(status_str: str) -> str:
    """Extract status text from full status string (e.g., '🔵 Active' -> 'active')."""
    if not status_str:
        return ""
    parts = status_str.split(maxsplit=1)
    return parts[-1].lower().strip() if parts else ""


def is_active_status(status_str: str) -> bool:
    """Check if status represents active work."""
    text = parse_status_text(status_str)
    return text in ("active", "testing", "in design")


def is_completed_status(status_str: str) -> bool:
    """Check if status represents completed work."""
    text = parse_status_text(status_str)
    return text == "completed"


def is_done_status(status_str: str) -> bool:
    """Check if status represents finished work (completed or ready)."""
    text = parse_status_text(status_str)
    return text in ("completed", "ready")


def is_superseded_status(status_str: str) -> bool:
    """Check if status is superseded."""
    text = parse_status_text(status_str)
    return text == "superseded"


def is_paused_status(status_str: str) -> bool:
    """Check if status represents a paused spec."""
    return parse_status_text(status_str) == "paused"


def is_ready_status(status_str: str) -> bool:
    """Check if status represents the IMPL Ready state (work complete, awaiting archive)."""
    return parse_status_text(status_str) == "ready"


def is_exception_status(status_str: str) -> bool:
    """Check if status represents an exception that needs human triage."""
    return parse_status_text(status_str) == "exception"


def is_in_progress_status(status_str: str) -> bool:
    """Check if status represents in-progress IMPL work (Active/Testing/Ready).

    Distinct from :func:`is_active_status` — this matches the ordering-logic
    definition of "in flight" which includes Ready (work done, awaiting archive),
    while is_active_status uses the legacy FR-oriented definition that includes
    In Design but not Ready.
    """
    return parse_status_text(status_str) in ("active", "testing", "ready")


def is_terminal_workflow_status(status_str: str) -> bool:
    """Check if status represents a completed-or-ready workflow state.

    Matches Ready (IMPL) or Completed (FR) — used by ordering to skip specs
    whose work is done regardless of which file type reports the status.
    """
    return parse_status_text(status_str) in ("ready", "completed")


def is_status_literal_active(status_str: str) -> bool:
    """Check if status contains the literal word 'active' (case-insensitive).

    Preserves the exact pre-refactor semantics of ``"active" in fr.status.lower()``
    used by ordering.py. Distinct from :func:`is_active_status` which also
    matches Testing and In Design — this matches *only* the Active state.
    """
    return "active" in status_str.lower()


def get_priority_line_pattern() -> str:
    """Return the current priority-line regex pattern (anchored, capturing).

    Use with ``re.search(..., re.MULTILINE)`` to extract the priority code from
    FR content. Accepts both the legacy emoji+code format and the post-S332
    words-only format.
    """
    return PRIORITY_LINE_PATTERN


def get_priority_line_sub_pattern() -> str:
    """Return the current priority-line substitution regex pattern.

    Non-anchored, non-capturing. Use with ``re.sub`` to replace the full
    ``**Priority:** [emoji] CODE`` line in FR content.
    """
    return PRIORITY_LINE_SUB_PATTERN


def get_priority_line_strict_pattern() -> str:
    """Return the strict priority-line regex pattern (``^...$``, capturing).

    Fully anchored — requires the priority code to be the last thing on the
    line. Used by the validator to reject lines with unexpected trailing
    content. Use with ``re.search(..., re.MULTILINE)`` or ``re.compile(...,
    re.MULTILINE)`` to match a priority line as a full line.
    """
    return PRIORITY_LINE_STRICT_PATTERN


def get_dep_display_emoji(status_str: str) -> str:
    """Get the emoji to display for a dependency based on its status.

    Args:
        status_str: Full status string like '🔵 Active' or 'active'

    Returns:
        Display emoji for dependency list
    """
    text = parse_status_text(status_str)

    status_emoji_map = {
        "completed": DepDisplayEmoji.COMPLETED,
        "active": DepDisplayEmoji.ACTIVE,
        "testing": DepDisplayEmoji.TESTING,
        "rejected": DepDisplayEmoji.REJECTED,
        "superseded": DepDisplayEmoji.SUPERSEDED,
        "paused": DepDisplayEmoji.PAUSED,
        "exception": DepDisplayEmoji.EXCEPTION,
    }

    return status_emoji_map.get(text, DepDisplayEmoji.PROPOSED)


# =============================================================================
# Legend and Display Helpers
# =============================================================================


def get_status_legend() -> str:
    """Generate the status legend string for display.

    Shows key statuses for the nspec table legend.
    """
    return (
        f"Specs: {FR_STATUSES[0].emoji} Proposed  "
        f"{FR_STATUSES[2].emoji} Active  "
        f"{IMPL_STATUSES[2].emoji} Testing  "
        f"{FR_STATUSES[3].emoji} Completed  "
        f"{IMPL_STATUSES[4].emoji} Paused\n"
        f"Epics:   {EpicDisplayEmoji.PROPOSED} Planning  "
        f"{EpicDisplayEmoji.ACTIVE} In Progress  "
        f"{EpicDisplayEmoji.COMPLETED} Done"
    )


# =============================================================================
# Emoji Constants for Pattern Matching
# =============================================================================
# ALL_STATUS_EMOJIS and STATUS_EMOJI_PATTERN are set by _build() above.
# Use get_all_status_emojis() / get_status_emoji_pattern() for dynamic access.


def get_status_emoji_fallback() -> dict[str, str]:
    """Generate fallback mapping from status text to emoji.

    This consolidates all status->emoji mappings in one place.
    Used when parsing status strings that don't have emoji prefix.
    """
    return {
        # FR statuses
        "proposed": FR_STATUSES[0].emoji,
        "in-design": FR_STATUSES[1].emoji,
        "in design": FR_STATUSES[1].emoji,
        "active": FR_STATUSES[2].emoji,
        "completed": FR_STATUSES[3].emoji,
        "complete": FR_STATUSES[3].emoji,
        "rejected": FR_STATUSES[4].emoji,
        "superseded": FR_STATUSES[5].emoji,
        "deferred": FR_STATUSES[6].emoji,
        # IMPL statuses
        "planning": IMPL_STATUSES[0].emoji,
        "testing": IMPL_STATUSES[2].emoji,
        "paused": IMPL_STATUSES[4].emoji,
        "hold": IMPL_STATUSES[5].emoji,
        "exception": IMPL_STATUSES[6].emoji,
        # Legacy aliases
        "in-progress": FR_STATUSES[2].emoji,  # maps to active
        "blocked": "🔴",  # legacy, not in standard statuses
    }


def print_status_codes() -> None:
    """Print all status codes reference.

    Usage: Run `make nspec.status-codes` to see this output.
    """
    print("\n" + "=" * 60)  # noqa: T201
    print("NSPEC STATUS CODES REFERENCE")  # noqa: T201
    print("=" * 60)  # noqa: T201

    print("\n📋 FR (Feature Request) Status Codes:")  # noqa: T201
    print("-" * 40)  # noqa: T201
    print("  Code  Emoji  Status")  # noqa: T201
    print("-" * 40)  # noqa: T201
    for code, status in FR_STATUSES.items():
        print(f"    {code}     {status.emoji}    {status.text}")  # noqa: T201

    print("\n📋 IMPL (Implementation) Status Codes:")  # noqa: T201
    print("-" * 40)  # noqa: T201
    print("  Code  Emoji  Status")  # noqa: T201
    print("-" * 40)  # noqa: T201
    for code, status in IMPL_STATUSES.items():
        print(f"    {code}     {status.emoji}    {status.text}")  # noqa: T201

    print("\n📋 Priority Codes:")  # noqa: T201
    print("-" * 40)  # noqa: T201
    print("  Priorities (P0-P3):")  # noqa: T201
    for code, priority in SPEC_PRIORITIES.items():
        name = PRIORITY_NAMES.get(code, "")
        print(f"    {code}  {priority.emoji}  {name}")  # noqa: T201

    print("\n" + "=" * 60)  # noqa: T201
    print("USAGE:")  # noqa: T201
    print("=" * 60)  # noqa: T201
    print("\n  Start work:  make nspec.activate <SPEC_ID>")  # noqa: T201
    print("  Advance:     make nspec.next-status <SPEC_ID>")  # noqa: T201
    print("  Reset:       make nspec.reset <SPEC_ID>")  # noqa: T201
    print("\n  Workflow:    activate → next-status (repeat) → complete")  # noqa: T201
    print()  # noqa: T201


def get_status_codes_help() -> str:
    """Return a concise string of status codes for --help epilog."""
    fr_codes = ", ".join(f"{s.code}={s.text}" for s in FR_STATUSES.values())
    impl_codes = ", ".join(f"{s.code}={s.text}" for s in IMPL_STATUSES.values())
    return f"FR codes: {fr_codes}\nIMPL codes: {impl_codes}"


# =============================================================================
# Valid State Pairs Matrix (FR-286)
# =============================================================================
# Defines which (FR_status, IMPL_status) combinations are valid.
# Reference: DEV-PROCESS.md lines 956-960 (Linear Flow diagram)
#
# FR:   Proposed → In Design → Active → Completed
#                                 ↓
# IMPL:                      Planning → Active → Testing → Ready → [archived]
#
# Key rule: IMPL cannot advance past Planning(0) until FR reaches Active(2)


@dataclass(frozen=True)
class StateValidation:
    """Validation result for a state pair."""

    valid: bool
    reason: str


# Matrix of valid (FR, IMPL) state pairs.
# Keys are (fr_status_code, impl_status_code) tuples.
# Values are StateValidation(valid, reason) indicating whether the pair is allowed.
VALID_STATE_PAIRS: dict[tuple[int, int], StateValidation] = {
    # FR=Proposed(0): Only IMPL=Planning allowed
    (0, 0): StateValidation(valid=True, reason="Both not started"),
    (0, 1): StateValidation(valid=False, reason="Cannot start IMPL until FR is Active"),
    (0, 2): StateValidation(valid=False, reason="Cannot start IMPL until FR is Active"),
    (0, 3): StateValidation(valid=False, reason="Cannot complete IMPL without finalized spec"),
    (0, 4): StateValidation(valid=True, reason="FR proposed, IMPL paused"),
    (0, 5): StateValidation(valid=True, reason="FR proposed, IMPL on hold"),
    # FR=In Design(1): Only IMPL=Planning allowed
    (1, 0): StateValidation(valid=True, reason="Spec being designed, impl planning"),
    (1, 1): StateValidation(valid=False, reason="Cannot start IMPL while spec in design"),
    (1, 2): StateValidation(valid=False, reason="Cannot test IMPL while spec in design"),
    (1, 3): StateValidation(valid=False, reason="Cannot complete IMPL without finalized spec"),
    (1, 4): StateValidation(valid=True, reason="FR in design, IMPL paused"),
    (1, 5): StateValidation(valid=True, reason="FR in design, IMPL on hold"),
    # FR=Active(2): IMPL can proceed through all states except Completed
    (2, 0): StateValidation(valid=True, reason="Spec done, impl not started"),
    (2, 1): StateValidation(valid=True, reason="Spec locked, actively implementing"),
    (2, 2): StateValidation(valid=True, reason="Spec locked, testing implementation"),
    (2, 3): StateValidation(valid=False, reason="Cannot complete IMPL until FR is Completed"),
    (2, 4): StateValidation(valid=True, reason="FR active, IMPL paused"),
    (2, 5): StateValidation(valid=True, reason="FR active, IMPL on hold"),
    # FR=Completed(3): Only IMPL=Completed valid (atomic completion)
    (3, 0): StateValidation(valid=False, reason="FR completed but IMPL not started - inconsistent"),
    (3, 1): StateValidation(
        valid=False, reason="FR completed but IMPL still active - inconsistent"
    ),
    (3, 2): StateValidation(
        valid=False, reason="FR completed but IMPL still testing - inconsistent"
    ),
    (3, 3): StateValidation(valid=True, reason="Both completed"),
    (3, 4): StateValidation(valid=False, reason="FR completed but IMPL paused - inconsistent"),
    (3, 5): StateValidation(valid=False, reason="FR completed but IMPL on hold - inconsistent"),
    # FR=Rejected(4): Any IMPL state valid (spec cancelled)
    (4, 0): StateValidation(valid=True, reason="FR rejected, IMPL not started"),
    (4, 1): StateValidation(valid=True, reason="FR rejected mid-implementation"),
    (4, 2): StateValidation(valid=True, reason="FR rejected during testing"),
    (4, 3): StateValidation(valid=True, reason="FR rejected after IMPL complete"),
    (4, 4): StateValidation(valid=True, reason="FR rejected, IMPL paused"),
    (4, 5): StateValidation(valid=True, reason="FR rejected, IMPL on hold"),
    # FR=Superseded(5): Any IMPL state valid (spec replaced)
    (5, 0): StateValidation(valid=True, reason="FR superseded, IMPL not started"),
    (5, 1): StateValidation(valid=True, reason="FR superseded mid-implementation"),
    (5, 2): StateValidation(valid=True, reason="FR superseded during testing"),
    (5, 3): StateValidation(valid=True, reason="FR superseded after IMPL complete"),
    (5, 4): StateValidation(valid=True, reason="FR superseded, IMPL paused"),
    (5, 5): StateValidation(valid=True, reason="FR superseded, IMPL on hold"),
    # FR=Deferred(6): IMPL should be Paused or Hold
    (6, 0): StateValidation(valid=True, reason="FR deferred, IMPL planning"),
    (6, 1): StateValidation(valid=False, reason="Cannot have active IMPL with deferred FR"),
    (6, 2): StateValidation(valid=False, reason="Cannot have testing IMPL with deferred FR"),
    (6, 3): StateValidation(valid=False, reason="Cannot complete IMPL with deferred FR"),
    (6, 4): StateValidation(valid=True, reason="Both deferred/paused"),
    (6, 5): StateValidation(valid=True, reason="FR deferred, IMPL on hold"),
    (6, 6): StateValidation(valid=True, reason="FR deferred, IMPL in exception state"),
    # IMPL=Exception(6): Valid with any FR state (failures can happen anytime)
    (0, 6): StateValidation(valid=True, reason="FR proposed, IMPL hit exception"),
    (1, 6): StateValidation(valid=True, reason="FR in design, IMPL hit exception"),
    (2, 6): StateValidation(valid=True, reason="FR active, IMPL hit exception"),
    (3, 6): StateValidation(
        valid=False, reason="FR completed but IMPL in exception - inconsistent"
    ),
    (4, 6): StateValidation(valid=True, reason="FR rejected, IMPL hit exception"),
    (5, 6): StateValidation(valid=True, reason="FR superseded, IMPL hit exception"),
}


def is_valid_state_pair(fr_status: int, impl_status: int) -> tuple[bool, str]:
    """Check if a (FR, IMPL) state combination is valid.

    Args:
        fr_status: FR status code (0-6)
        impl_status: IMPL status code (0-5)

    Returns:
        Tuple of (is_valid, reason_message)
    """
    key = (fr_status, impl_status)
    if key not in VALID_STATE_PAIRS:
        return (False, f"Unknown state combination: FR={fr_status}, IMPL={impl_status}")

    validation = VALID_STATE_PAIRS[key]
    return (validation.valid, validation.reason)


# =============================================================================
# Initialize on import
# =============================================================================
_build()
