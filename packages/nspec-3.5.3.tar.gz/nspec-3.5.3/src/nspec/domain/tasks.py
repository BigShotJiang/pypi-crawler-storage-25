"""Task and Acceptance Criteria parsing for fRIMPL progress tracking.

This module provides classes and functions for parsing, validating, and tracking:
- Acceptance Criteria (AC) from FR documents (Success Criteria sections)
- Implementation Tasks from IMPL documents (Day/Phase sections)

Both use checkbox format: `- [ ]` (pending) or `- [x]` (completed)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# Regex patterns for parsing
# Matches: - [ ] task, - [x] task, - [~] task (obsolete),
# - [>] task (deferred), - [→S123] task (delegated)
CHECKBOX_RE = re.compile(r"^- \[([ x~>]|→[ES]\d{3}[a-z]?)\] (.+)$", re.MULTILINE)
# Pattern to extract delegated spec ID
DELEGATED_RE = re.compile(r"^→([ES]\d{3}[a-z]?)$", re.IGNORECASE)
# Pattern to match BLOCKED marker line following a task
BLOCKED_RE = re.compile(r"^\s+- \*\*BLOCKED:\*\*\s+(.+)$")
# Pattern to extract task tag (e.g., #code, #tui, #docs, #infra)
TAG_RE = re.compile(r"\s+#(code|tui|docs|infra)\s*$")
# Pattern to strip trailing HTML comment timestamps (audit trail)
AUDIT_COMMENT_RE = re.compile(r"\s*<!--\s*\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\s*-->\s*$")
# Pattern to match "- Tests:" annotation lines (plain bullets under tasks)
TESTS_ANNOTATION_RE = re.compile(r"^\s+-\s+Tests:\s+(.+)$")

# Verification routes: tag → (run_tests, description)
VERIFICATION_ROUTES: dict[str, tuple[bool, str]] = {
    "code": (True, "Run `make test-quick`"),
    "tui": (True, "Run `make test-quick` + Playwright MCP visual check"),
    "docs": (False, "Markdown lint / link check (no test gate)"),
    "infra": (False, "Manual verification (no test gate)"),
}


@dataclass
class AcceptanceCriteria:
    """Single acceptance criterion from FR checkbox.

    Acceptance criteria define WHAT needs to be delivered for a spec
    to be considered complete. They come from FR Success Criteria sections.

    Example from FR:
        ### Functional Requirements
        - [ ] ScheduledTask entity schema defined
        - [x] Temporal execution engine works
    """

    id: str  # Slugified: "functional-req-1"
    description: str  # "ScheduledTask entity schema defined"
    completed: bool  # False for [ ], True for [x], [~] (obsolete), or [>] (deferred)
    section: str  # "Functional Requirements"
    category: str  # "functional" | "performance" | "quality" | "documentation"
    line_number: int  # For error reporting

    @property
    def emoji(self) -> str:
        """Status emoji for display."""
        return "✅" if self.completed else "🟡"


@dataclass
class Task:
    """Hierarchical implementation task from IMPL checkbox.

    Tasks define HOW the spec will be implemented. They come from
    IMPL Day/Phase sections and should be actionable work items.
    Tasks can have children (nested list items) forming a tree.

    Example from IMPL:
        ## Day 1: Setup
        - [x] Create directory structure
        - [ ] Write conftest.py
          - Define fixtures
          - Add mock helpers
        - [→220] PostgreSQL adapter (delegated to spec 220)

    The nested items become children of "Write conftest.py".
    """

    id: str  # Slugified: "day1-setup-task1" or explicit "1.1"
    description: str  # "Create directory structure"
    completed: bool  # False for [ ], True for [x], [~] (obsolete), [>] (deferred), or [→XXX]
    section: str  # "Day 1: Setup"
    line_number: int  # For error reporting
    delegated_to: str | None = None  # Spec ID if delegated (e.g., "220")
    depth: int = 0  # Indentation level (0 = top-level)
    children: list[Task] = field(default_factory=list)
    parent: Task | None = field(default=None, repr=False)  # Back-reference
    spec_id: str | None = None  # Spec this task belongs to (for URI)
    tag: str | None = None  # Verification tag: code, tui, docs, infra (None = code)
    blocked: bool = False  # True if task has a BLOCKED marker
    blocked_reason: str | None = None  # Reason from BLOCKED marker
    tests: list[str] = field(default_factory=list)  # Test file refs from "- Tests:" annotations

    @property
    def effective_tag(self) -> str:
        """Return the verification tag, defaulting to 'code'."""
        return self.tag or "code"

    @property
    def verification_route(self) -> tuple[bool, str]:
        """Return (run_tests, description) for this task's verification."""
        return VERIFICATION_ROUTES.get(self.effective_tag, VERIFICATION_ROUTES["code"])

    @property
    def emoji(self) -> str:
        """Status emoji for display."""
        if self.delegated_to:
            return f"→{self.delegated_to}"
        return "✅" if self.completed else "🟡"

    @property
    def path(self) -> str:
        """XPath-style path within spec (no spec prefix).

        Format: /section/task-id/child-id/...
        Example: /day1-setup/1.1/0

        Used for navigation within a spec's task tree.
        """
        parts = []
        node: Task | None = self
        while node is not None:
            if node.id:
                parts.append(node.id)
            node = node.parent

        # Add section as root
        if self.section:
            parts.append(slugify(self.section))

        parts.reverse()
        return "/" + "/".join(parts)

    @property
    def uri(self) -> str:
        """Full praxis:// URI for this task.

        Format: praxis://impl/{spec_id}{path}
        Example: praxis://impl/444/day-1-create-kernel-types/1.1

        Can be pasted into TUI to navigate directly to this task.
        """
        spec = self.spec_id or "unknown"
        return f"praxis://impl/{spec}{self.path}"

    @property
    def short_path(self) -> str:
        """Shortened path showing just immediate context.

        Example: day1-setup/1.1 instead of full path
        """
        if self.parent:
            return f"{slugify(self.section)}/{self.parent.id}/{self.id}"
        return f"{slugify(self.section)}/{self.id}"

    def get_siblings(self, all_root_tasks: list[Task]) -> list[Task]:
        """Return all sibling tasks at the same depth within the same phase/section.

        Siblings are tasks that share the same parent (or are all top-level
        within the same section). Phase boundaries (### Phase N: headings)
        separate sibling groups — tasks in different phases are not siblings.

        Args:
            all_root_tasks: The full list of root-level tasks from TaskParser.

        Returns:
            List of sibling tasks (including self), in document order.
        """
        if self.parent is not None:
            # Subtask: siblings are the other children of the same parent
            return list(self.parent.children)
        # Top-level task: siblings are other root tasks in the same section
        return [t for t in all_root_tasks if t.section == self.section]

    @property
    def is_leaf(self) -> bool:
        """True if this task has no children."""
        return len(self.children) == 0

    @property
    def child_count(self) -> int:
        """Total number of descendants (recursive)."""
        count = len(self.children)
        for child in self.children:
            count += child.child_count
        return count

    @property
    def completion_status(self) -> tuple[int, int]:
        """Return (completed, total) for this task and all descendants."""
        completed = 1 if self.completed else 0
        total = 1
        for child in self.children:
            c, t = child.completion_status
            completed += c
            total += t
        return completed, total


def slugify(text: str) -> str:
    """Convert text to slug format.

    Examples:
        "Functional Requirements" -> "functional-requirements"
        "Day 1: Setup" -> "day1-setup"
    """
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"[-\s]+", "-", text)
    return text.strip("-")


def categorize_ac_section(section: str) -> str:
    """Determine category of acceptance criteria section.

    Categories:
        - functional: Feature functionality, behavior, API
        - performance: Speed, throughput, latency, scalability
        - quality: Tests, coverage, documentation, code quality
        - documentation: Docs, guides, examples

    Args:
        section: Section name like "Functional Requirements"

    Returns:
        Category string
    """
    section_lower = section.lower()

    if any(
        kw in section_lower for kw in ["functional", "feature", "behavior", "api", "capability"]
    ):
        return "functional"

    if any(
        kw in section_lower
        for kw in ["performance", "speed", "latency", "throughput", "scalability"]
    ):
        return "performance"

    if any(
        kw in section_lower
        for kw in [
            "quality",
            "test",
            "coverage",
            "code quality",
            "reliability",
            "security",
        ]
    ):
        return "quality"

    if any(kw in section_lower for kw in ["documentation", "docs", "guide", "example"]):
        return "documentation"

    # Default to functional if unclear
    return "functional"


class AcceptanceCriteriaParser:
    """Parse acceptance criteria from FR documents.

    Scans for "Success Criteria" section and extracts checkbox items.
    Each checkbox becomes an AcceptanceCriteria object.
    """

    def parse(self, content: str, path: Path) -> list[AcceptanceCriteria]:
        """Parse all acceptance criteria from FR content.

        Args:
            content: Full FR document text
            path: Path to FR file (for error reporting)

        Returns:
            List of AcceptanceCriteria objects

        Raises:
            ValueError: If checkbox format is invalid
        """
        criteria = []
        lines = content.split("\n")
        current_section = ""
        in_success_criteria = False

        for line_num, line in enumerate(lines, start=1):
            # Track when we enter Success/Acceptance Criteria section
            stripped = line.strip()
            if stripped.startswith(("## Success Criteria", "## Acceptance Criteria")):
                in_success_criteria = True
                continue

            # Exit Success Criteria section if we hit another top-level section
            if (
                in_success_criteria
                and line.strip().startswith("##")
                and not line.strip().startswith("###")
            ):
                break

            # Track subsections within Success Criteria
            if in_success_criteria and line.strip().startswith("###"):
                current_section = line.strip().lstrip("#").strip()
                continue

            # Parse checkbox items
            if in_success_criteria:
                match = CHECKBOX_RE.match(line)
                if match:
                    checkbox_content = match.group(1)
                    completed = checkbox_content in ("x", "~", ">")
                    description = match.group(2).strip()

                    # Validate checkbox format strictly
                    if not self._is_valid_checkbox_format(line):
                        raise ValueError(
                            f"❌ Invalid checkbox format in {path.name} line {line_num}:\n"
                            f"   Found: {line.strip()}\n"
                            f"   Required: - [ ] or - [x] (dash, space, bracket, space, bracket)\n"
                            f"   ➜ Fix: Use exactly '- [ ]' or '- [x]'"
                        )

                    # Generate unique ID
                    section_slug = slugify(current_section)
                    ac_id = f"{section_slug}-{len(criteria)}"

                    # Categorize
                    category = categorize_ac_section(current_section)

                    criteria.append(
                        AcceptanceCriteria(
                            id=ac_id,
                            description=description,
                            completed=completed,
                            section=current_section,
                            category=category,
                            line_number=line_num,
                        )
                    )

        return criteria

    def _is_valid_checkbox_format(self, line: str) -> bool:
        """Validate strict checkbox format.

        Valid:
            - [ ] Description (pending)
            - [x] Description (completed)
            - [~] Description (obsolete/N/A)
            - [>] Description (deferred)

        Invalid:
            * [ ] Description  (asterisk instead of dash)
            -[ ] Description   (no space after dash)
            - [] Description   (no space in brackets)
            - [X] Description  (uppercase X)
        """
        stripped = line.strip()
        return stripped.startswith(("- [ ] ", "- [x] ", "- [~] ", "- [>] "))


class TaskParser:
    """Parse hierarchical implementation tasks from IMPL documents.

    Scans for Day/Phase sections and extracts checkbox items and nested
    list items. Builds a tree structure based on indentation.

    Example IMPL structure:
        ## Day 1: Setup
        - [x] Create directory structure
        - [ ] Write conftest.py
          - Define fixtures
          - Add mock helpers
        - [→220] PostgreSQL adapter

    The nested items become children of "Write conftest.py".
    """

    # Pattern specifically for checkboxes
    CHECKBOX_ITEM_RE = re.compile(r"^(\s*)- \[([ x~>]|→\d{3})\] (.+)$")

    def parse(self, content: str, _path: Path) -> list[Task]:
        """Parse all tasks from IMPL content into a tree structure.

        Args:
            content: Full IMPL document text
            path: Path to IMPL file (for error reporting)

        Returns:
            List of top-level Task objects (children nested within)

        Raises:
            ValueError: If task format is invalid
        """
        root_tasks: list[Task] = []  # Top-level tasks per section
        lines = content.split("\n")
        current_section = ""
        task_counter = 0

        # Stack to track parent tasks at each depth level
        # parent_stack[depth] = task at that depth (or None for root)
        parent_stack: list[Task | None] = [None] * 20  # Support up to 20 levels

        for line_num, line in enumerate(lines, start=1):
            # Track current task section (## or ### headers)
            stripped = line.strip()
            if stripped.startswith("##"):
                header_text = stripped.lstrip("#").strip()
                if self._is_task_section(header_text):
                    current_section = header_text
                    # Reset parent stack and task counter for new section
                    parent_stack = [None] * 20
                    task_counter = 0
                else:
                    # Any other header exits the current task section
                    # (e.g., "Execution Notes", "Session Notes", etc.)
                    current_section = ""
                    parent_stack = [None] * 20
                continue

            # Skip if not in a Day/Phase section
            if not current_section:
                continue

            # Try to match checkbox item first
            checkbox_match = self.CHECKBOX_ITEM_RE.match(line)
            if checkbox_match:
                indent = checkbox_match.group(1)
                checkbox_content = checkbox_match.group(2)
                description = checkbox_match.group(3).strip()
                depth = len(indent) // 2  # Assume 2-space indentation

                # Determine completion state and delegation
                delegated_to: str | None = None
                if checkbox_content in ("x", "~", ">"):
                    completed = True
                elif checkbox_content == " ":
                    completed = False
                else:
                    delegated_match = DELEGATED_RE.match(checkbox_content)
                    if delegated_match:
                        delegated_to = delegated_match.group(1)
                        completed = True
                    else:
                        completed = False

                # Peek at next line for BLOCKED marker
                blocked = False
                blocked_reason: str | None = None
                if line_num < len(lines):  # line_num is 1-indexed, check next
                    next_line = lines[line_num]  # lines[line_num] is the next line
                    blocked_match = BLOCKED_RE.match(next_line)
                    if blocked_match:
                        blocked = True
                        blocked_reason = blocked_match.group(1).strip()

                parent = parent_stack[depth - 1] if depth > 0 else None
                task = self._create_task(
                    description=description,
                    completed=completed,
                    section=current_section,
                    line_number=line_num,
                    delegated_to=delegated_to,
                    depth=depth,
                    task_counter=task_counter,
                    parent=parent,
                )
                task.blocked = blocked
                task.blocked_reason = blocked_reason
                task_counter += 1

                self._attach_to_parent(task, depth, parent_stack, root_tasks)
                continue

            # Check for "- Tests:" annotation and attach to most recent task
            tests_match = TESTS_ANNOTATION_RE.match(line)
            if tests_match and current_section:
                tests_value = tests_match.group(1).strip()
                # Find the most recent task (last in parent_stack or root_tasks)
                recent_task = self._find_most_recent_task(parent_stack, root_tasks)
                if recent_task is not None:
                    # Parse test refs: may be comma-separated, may have backticks
                    for ref in self._parse_test_refs(tests_value):
                        recent_task.tests.append(ref)
                continue

            # NOTE: Plain list items (non-checkbox bullets) are NOT captured as tasks.
            # Only checkbox items (- [ ], - [x], - [~], - [→XXX]) are tracked.
            # Plain bullets are documentation/notes, not actionable tasks.

        return root_tasks

    def _create_task(
        self,
        description: str,
        completed: bool,
        section: str,
        line_number: int,
        delegated_to: str | None,
        depth: int,
        task_counter: int,
        parent: Task | None = None,
    ) -> Task:
        """Create a Task with generated ID."""
        # Strip trailing audit timestamp comments (e.g., "<!-- 2026-02-09T23:15:00 -->")
        description = AUDIT_COMMENT_RE.sub("", description).rstrip()

        # Extract tag from end of description (e.g., "Add auth middleware #code")
        tag: str | None = None
        tag_match = TAG_RE.search(description)
        if tag_match:
            tag = tag_match.group(1)
            description = description[: tag_match.start()].rstrip()

        # Extract task ID if present.
        # Supported formats: bold "**1.1**: Desc", numbered "1. Desc", colon "1: Desc"
        task_id = ""
        clean_desc = description
        if description.startswith("**") and "**:" in description:
            # Bold format: **1.1**: Description
            id_end = description.index("**:")
            task_id = description[2:id_end]
            clean_desc = description[id_end + 4 :].strip()
        else:
            # Plain format: "1. Description" or "1.1. Description" or "dod-1. Description"
            plain_id_match = re.match(r"^([\w.-]+)\.\s+", description)
            if plain_id_match:
                task_id = plain_id_match.group(1)
                clean_desc = description[plain_id_match.end() :].strip()
            else:
                # Support numeric dotted IDs without a trailing '.' (e.g., "2.1 Do thing")
                # This commonly appears in templates that embed commands: "2.1 `cmd` → file".
                numeric_dotted_id_match = re.match(r"^(\d+(?:\.\d+)+)\s+", description)
                if numeric_dotted_id_match:
                    task_id = numeric_dotted_id_match.group(1)
                    clean_desc = description[numeric_dotted_id_match.end() :].strip()

        # Generate ID
        if task_id:
            generated_id = task_id
        elif parent:
            # Children get parent ID + index
            child_idx = len(parent.children)
            generated_id = f"{parent.id}.{child_idx}"
        else:
            # Special case: Definition of Done uses "dod-N" format
            if section.lower() == "definition of done":
                generated_id = f"dod-{task_counter + 1}"  # 1-indexed for user-friendliness
            else:
                section_slug = slugify(section)
                generated_id = f"{section_slug}-{task_counter}"

        return Task(
            id=generated_id,
            description=clean_desc if task_id else description,
            completed=completed,
            section=section,
            line_number=line_number,
            delegated_to=delegated_to,
            depth=depth,
            tag=tag,
        )

    def _attach_to_parent(
        self,
        task: Task,
        depth: int,
        parent_stack: list[Task | None],
        root_tasks: list[Task],
    ) -> None:
        """Attach task to its parent based on depth, or to root list."""
        if depth == 0:
            # Top-level task
            root_tasks.append(task)
            task.parent = None
        else:
            # Find parent at previous depth
            parent = parent_stack[depth - 1]
            if parent:
                task.parent = parent
                parent.children.append(task)
            else:
                # No parent found, treat as root
                root_tasks.append(task)

        # Update stack: this task becomes the parent for deeper items
        parent_stack[depth] = task
        # Clear deeper levels (they're no longer valid parents)
        for i in range(depth + 1, len(parent_stack)):
            parent_stack[i] = None

    def flatten(self, tasks: list[Task]) -> list[Task]:
        """Flatten hierarchical tasks into a flat list (for backward compatibility).

        Performs depth-first traversal to return all tasks.
        """
        result: list[Task] = []
        for task in tasks:
            result.append(task)
            if task.children:
                result.extend(self.flatten(task.children))
        return result

    # Section prefixes that contain trackable tasks
    TASK_SECTION_PREFIXES = (
        # Minimal template sections
        "Tasks",  # Main tasks section (new minimal template)
        "Definition of Done",  # DoD checklist (new minimal template)
        # Legacy template sections (for existing specs)
        "Day ",  # Daily roadmap sections
        "Phase ",  # Phase tracking sections
        "Gate ",  # Validation gate sections (Gate 1:, Gate 4:)
        "Testing Checklist",  # Testing checklist section
        "Completion Checklist",  # Final completion checklist
        "Implementation Verification",  # Implementation verification checklist
        "Validation Gates",  # Validation gates section
        "Code Quality",  # Completion sub-section
        "Testing",  # Completion sub-section (standalone)
        "Documentation",  # Completion sub-section
        "Quality Gates",  # Completion sub-section
        "Nspec Hygiene",  # Completion sub-section
        "Before Starting",  # Testing checklist sub-section
        "During Implementation",  # Testing checklist sub-section
        "Before Ending",  # Testing checklist sub-section
        "Before Marking",  # Testing checklist sub-section
        "Manual Verification",  # Gate 4 sub-section
    )

    @staticmethod
    def _find_most_recent_task(
        parent_stack: list[Task | None], root_tasks: list[Task]
    ) -> Task | None:
        """Find the most recently added task from the parent stack or root list."""
        # Walk the parent stack from deepest to shallowest
        for i in range(len(parent_stack) - 1, -1, -1):
            if parent_stack[i] is not None:
                return parent_stack[i]
        # Fallback: last root task
        return root_tasks[-1] if root_tasks else None

    @staticmethod
    def _parse_test_refs(value: str) -> list[str]:
        """Parse test references from a Tests: annotation value.

        Handles:
        - Single path: `tests/test_foo.py`
        - Backtick-wrapped: `tests/test_foo.py`
        - Comma-separated: `tests/test_foo.py`, `tests/test_bar.py`
        - Prose descriptions (returned as-is): "Verify exception messages"
        """
        # Split on commas for multi-ref support
        refs = []
        for part in value.split(","):
            part = part.strip()
            # Strip backticks
            if part.startswith("`") and part.endswith("`"):
                part = part[1:-1]
            if part:
                refs.append(part)
        return refs

    def _is_task_section(self, header_text: str) -> bool:
        """Check if a header indicates a section that contains trackable tasks.

        Args:
            header_text: The header text without leading # symbols

        Returns:
            True if this section should have its checkboxes parsed as tasks
        """
        return any(header_text.startswith(prefix) for prefix in self.TASK_SECTION_PREFIXES)

    def _is_valid_checkbox_format(self, line: str) -> bool:
        """Validate strict checkbox format.

        Valid formats:
            - [ ] Description (pending)
            - [x] Description (completed)
            - [~] Description (obsolete/N/A)
            - [>] Description (deferred)
            - [→XXX] Description (delegated to spec XXX)
        """
        stripped = line.strip()
        if stripped.startswith(("- [ ] ", "- [x] ", "- [~] ", "- [>] ")):
            return True
        # Check for delegation format: - [→XXX]
        if stripped.startswith("- [→") and "] " in stripped:
            # Extract content between brackets
            bracket_content = stripped[4 : stripped.index("] ")]
            return bool(re.match(r"^\d{3}$", bracket_content))
        return False


# --- URI Parsing and Resolution ---


def parse_uri(uri: str) -> tuple[str | None, str]:
    """Parse a praxis:// URI into (spec_id, path).

    Format: praxis://impl/{spec_id}/{section}/{task_id}/...
    Example: praxis://impl/444/day-1-create-kernel-types/1.1

    Returns:
        (spec_id, path) tuple, or (None, "") if invalid
    """
    if not uri.startswith("praxis://impl/"):
        return None, ""

    # Strip scheme
    rest = uri[len("praxis://impl/") :]
    parts = rest.split("/", 1)

    if len(parts) == 1:
        return parts[0], ""
    return parts[0], "/" + parts[1]


def resolve_path(tasks: list[Task], path: str) -> Task | None:
    """Resolve a path to a Task within a task tree.

    Args:
        tasks: List of root tasks
        path: Path like /day-1-create-kernel-types/1.1/0

    Returns:
        Matching Task or None
    """
    if not path or path == "/":
        return None

    # Split path into segments
    segments = [s for s in path.strip("/").split("/") if s]
    if not segments:
        return None

    # First segment is section, find tasks in that section
    section_slug = segments[0]
    current_tasks = [t for t in tasks if slugify(t.section) == section_slug]

    if not current_tasks:
        return None

    # If only section specified, return None (it's a section, not a task)
    if len(segments) == 1:
        return None

    # Navigate through remaining segments
    found: Task | None = None
    for segment in segments[1:]:
        found = None
        for task in current_tasks:
            if task.id == segment:
                found = task
                break
        if found:
            current_tasks = found.children
        else:
            return None

    return found


def find_similar_paths(tasks: list[Task], path: str, max_results: int = 5) -> list[str]:
    """Find paths similar to the given path (for 'did you mean?' suggestions).

    Uses simple substring/prefix matching and Levenshtein-like heuristics.
    """
    target_segments = [s for s in path.strip("/").split("/") if s]
    if not target_segments:
        return []

    suggestions: list[tuple[int, str]] = []  # (score, path)

    def score_task(task: Task) -> int:
        """Score how similar task path is to target."""
        task_segments = [s for s in task.path.strip("/").split("/") if s]
        score = 0

        # Exact segment matches
        for i, seg in enumerate(target_segments):
            if i < len(task_segments):
                if task_segments[i] == seg:
                    score += 10
                elif seg in task_segments[i] or task_segments[i] in seg:
                    score += 5

        # Penalize length difference
        score -= abs(len(task_segments) - len(target_segments)) * 2

        return score

    def collect_paths(task_list: list[Task]) -> None:
        for task in task_list:
            score = score_task(task)
            if score > 0:
                suggestions.append((score, task.path))
            if task.children:
                collect_paths(task.children)

    collect_paths(tasks)

    # Sort by score descending and return top results
    suggestions.sort(key=lambda x: x[0], reverse=True)
    return [path for _, path in suggestions[:max_results]]


# --- Targeted test runner ---


def parse_test_files_section(content: str) -> list[str]:
    """Parse ### Test Files section from IMPL content.

    Extracts file paths from bullet lists under a ### Test Files heading.
    Stops at the next heading (## or ###).

    Returns:
        List of test file paths (backticks stripped).
    """
    lines = content.split("\n")
    in_section = False
    test_files: list[str] = []

    for line in lines:
        stripped = line.strip()
        if stripped == "### Test Files":
            in_section = True
            continue
        if in_section and stripped.startswith("#"):
            break
        if in_section and stripped.startswith("- "):
            ref = stripped[2:].strip()
            if ref.startswith("`") and ref.endswith("`"):
                ref = ref[1:-1]
            if ref:
                test_files.append(ref)

    return test_files


def _normalize_test_ref(ref: str) -> str:
    """Normalize a test file reference for comparison.

    Strips backticks and whitespace.
    """
    ref = ref.strip()
    if ref.startswith("`") and ref.endswith("`"):
        ref = ref[1:-1]
    return ref.strip()


def _resolve_impl_path(
    spec_id: str,
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> Path:
    """Resolve IMPL file path for a spec, raising FileNotFoundError if not found."""
    from nspec.config import NspecConfig
    from nspec.session import find_spec_files

    _docs_root = docs_root or NspecConfig.load(project_root).resolve_spec_root()
    _project_root = project_root or Path.cwd()

    _, impl_path = find_spec_files(spec_id, _docs_root, project_root=_project_root)
    if impl_path is None:
        raise FileNotFoundError(f"IMPL file not found for spec {spec_id}")
    return impl_path


def list_spec_test_files(
    spec_id: str,
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> list[str]:
    """List test files registered in the ### Test Files section of an IMPL.

    Args:
        spec_id: Spec ID (e.g., "S220")
        docs_root: Path to docs directory (default: ./docs)
        project_root: Project root (default: cwd)

    Returns:
        List of test file paths.

    Raises:
        FileNotFoundError: If IMPL file not found for spec_id
    """
    impl_path = _resolve_impl_path(spec_id, docs_root, project_root)
    content = impl_path.read_text()
    return parse_test_files_section(content)


def add_spec_test_files(
    spec_id: str,
    files: list[str],
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> dict[str, object]:
    """Add test file entries to the ### Test Files section of an IMPL.

    Creates the section if absent (inserted before ## Definition of Done).
    Deduplicates entries (exact match after normalization).

    Args:
        spec_id: Spec ID (e.g., "S220")
        files: Test file paths to add
        docs_root: Path to docs directory (default: ./docs)
        project_root: Project root (default: cwd)

    Returns:
        {"files": [...], "added": [...], "warnings": [...]}

    Raises:
        FileNotFoundError: If IMPL file not found
        ValueError: If files list is empty
    """
    if not files:
        raise ValueError("files list must not be empty")

    impl_path = _resolve_impl_path(spec_id, docs_root, project_root)
    content = impl_path.read_text()

    existing = parse_test_files_section(content)
    existing_normalized = {_normalize_test_ref(f) for f in existing}

    added: list[str] = []
    warnings: list[str] = []

    for f in files:
        normalized = _normalize_test_ref(f)
        if normalized in existing_normalized:
            warnings.append(f"Already present: {normalized}")
        else:
            existing.append(normalized)
            existing_normalized.add(normalized)
            added.append(normalized)

    # Rewrite the section in the file
    content = _write_test_files_section(content, existing)
    impl_path.write_text(content)

    return {"files": existing, "added": added, "warnings": warnings}


def remove_spec_test_files(
    spec_id: str,
    files: list[str],
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> dict[str, object]:
    """Remove test file entries from the ### Test Files section of an IMPL.

    Removes the heading if the section becomes empty.

    Args:
        spec_id: Spec ID (e.g., "S220")
        files: Test file paths to remove
        docs_root: Path to docs directory (default: ./docs)
        project_root: Project root (default: cwd)

    Returns:
        {"files": [...], "removed": [...], "warnings": [...]}

    Raises:
        FileNotFoundError: If IMPL file not found
        ValueError: If files list is empty
    """
    if not files:
        raise ValueError("files list must not be empty")

    impl_path = _resolve_impl_path(spec_id, docs_root, project_root)
    content = impl_path.read_text()

    existing = parse_test_files_section(content)
    existing_normalized = {_normalize_test_ref(f) for f in existing}

    to_remove_normalized = {_normalize_test_ref(f) for f in files}
    removed: list[str] = []
    warnings: list[str] = []

    for f in files:
        normalized = _normalize_test_ref(f)
        if normalized in existing_normalized:
            removed.append(normalized)
        else:
            warnings.append(f"Not found: {normalized}")

    remaining = [f for f in existing if _normalize_test_ref(f) not in to_remove_normalized]

    content = _write_test_files_section(content, remaining)
    impl_path.write_text(content)

    return {"files": remaining, "removed": removed, "warnings": warnings}


def _write_test_files_section(content: str, test_files: list[str]) -> str:  # noqa: C901
    """Rewrite the ### Test Files section in IMPL content.

    If test_files is empty, removes the section entirely.
    If the section doesn't exist, creates it before ## Definition of Done.
    """
    lines = content.split("\n")

    # Find existing section boundaries
    section_start = None
    section_end = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "### Test Files":
            section_start = i
            continue
        if section_start is not None and section_end is None and stripped.startswith("#"):
            section_end = i
            break

    # If section exists but no following heading, it extends to end
    if section_start is not None and section_end is None:
        section_end = len(lines)

    if section_start is not None and section_end is not None:
        # Remove existing section
        # Also remove blank line before section if present
        remove_start = section_start
        if remove_start > 0 and lines[remove_start - 1].strip() == "":
            remove_start -= 1
        # Remove trailing blank lines in section
        while section_end > remove_start and lines[section_end - 1].strip() == "":
            section_end -= 1
        # Keep one blank line before next heading
        lines = lines[:remove_start] + lines[section_end:]
    else:
        remove_start = None

    if not test_files:
        return "\n".join(lines)

    # Build new section content
    section_lines = ["### Test Files", ""]
    for f in test_files:
        section_lines.append(f"- `{f}`")  # noqa: PERF401
    section_lines.append("")

    # Find insertion point
    if remove_start is not None:
        # Insert where old section was
        insert_at = remove_start
    else:
        # Insert before ## Definition of Done
        insert_at = None
        for i, line in enumerate(lines):
            if line.strip() == "## Definition of Done":
                insert_at = i
                break

        if insert_at is None:
            # Fallback: append after last ## section's content
            last_heading = None
            for i in range(len(lines) - 1, -1, -1):
                if lines[i].strip().startswith("## "):
                    last_heading = i
                    break
            if last_heading is not None:
                # Find the end of the last section (next ## or EOF)
                insert_at = len(lines)
                for i in range(last_heading + 1, len(lines)):
                    if lines[i].strip().startswith("## "):
                        insert_at = i
                        break

        if insert_at is None:
            # Last resort: append
            insert_at = len(lines)

    # Ensure blank line before section
    if insert_at > 0 and lines[insert_at - 1].strip() != "":
        section_lines = ["", *section_lines]

    lines = lines[:insert_at] + section_lines + lines[insert_at:]
    return "\n".join(lines)


def _is_pytest_target(ref: str) -> bool:
    """Check if a test reference looks like a valid pytest target.

    Valid: file paths ending in .py, or pytest node IDs like path.py::test_name
    Invalid: prose descriptions like "Verify exception messages"
    """
    if ref.endswith(".py"):
        return True
    # Pytest node IDs must have .py before the :: separator
    if "::" in ref:
        path_part = ref.split("::")[0]
        return path_part.endswith(".py")
    return False


def collect_spec_tests(
    spec_id: str,
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> list[str]:
    """Collect all test targets for a spec from IMPL task annotations and test_files.

    Gathers test refs from:
    1. All Task.tests fields (from `- Tests:` annotations)
    2. IMPLMetadata.test_files (from `### Test Files` section)

    Deduplicates and filters to valid pytest targets (`.py` files or `::` node IDs).

    Args:
        spec_id: Spec ID (e.g., "S220")
        docs_root: Path to docs directory (default: ./docs)
        project_root: Project root (default: cwd)

    Returns:
        Deduplicated list of pytest targets. Empty if no annotations found.

    Raises:
        FileNotFoundError: If IMPL file not found for spec_id
    """
    from nspec.config import NspecConfig
    from nspec.session import find_spec_files
    from nspec.validation.validators import IMPLValidator

    _docs_root = docs_root or NspecConfig.load(project_root).resolve_spec_root()
    _project_root = project_root or Path.cwd()

    _, impl_path = find_spec_files(spec_id, _docs_root, project_root=_project_root)
    if impl_path is None:
        raise FileNotFoundError(f"IMPL file not found for spec {spec_id}")

    content = impl_path.read_text()
    validator = IMPLValidator()
    impl_meta = validator.validate(impl_path, content)

    # Collect from all tasks recursively
    all_refs: list[str] = []

    def _collect_from_tasks(task_list: list[Task]) -> None:
        for task in task_list:
            all_refs.extend(task.tests)
            if task.children:
                _collect_from_tasks(task.children)

    _collect_from_tasks(impl_meta.tasks)
    all_refs.extend(impl_meta.test_files)

    # Deduplicate preserving order, filter to valid pytest targets
    seen: set[str] = set()
    result: list[str] = []
    for ref in all_refs:
        if ref not in seen and _is_pytest_target(ref):
            seen.add(ref)
            result.append(ref)

    return result


@dataclass
class TestRunResult:
    """Result of running spec-targeted tests."""

    spec_id: str
    targets: list[str]  # pytest targets that were run
    fallback: bool  # True if fell back to make test-quick
    returncode: int  # pytest/make exit code
    output: str  # stdout+stderr from the test run
    passed: bool  # True if returncode == 0


def run_spec_tests(
    spec_id: str,
    docs_root: Path | None = None,
    project_root: Path | None = None,
) -> TestRunResult:
    """Run only the tests relevant to a spec.

    Collects test targets from IMPL task annotations and test_files,
    then runs pytest with just those targets. Falls back to `make test-quick`
    if no test annotations are found.

    Args:
        spec_id: Spec ID (e.g., "S220")
        docs_root: Path to docs directory (default: ./docs)
        project_root: Project root for subprocess cwd (default: cwd)

    Returns:
        TestRunResult with pass/fail status and output
    """
    import subprocess

    _project_root = project_root or Path.cwd()

    targets = collect_spec_tests(spec_id, docs_root, _project_root)

    if targets:
        cmd = ["python", "-m", "pytest", "-x", "--tb=short", *targets]
        fallback = False
    else:
        cmd = ["make", "test-quick"]
        fallback = True

    result = subprocess.run(  # noqa: S603
        cmd,
        capture_output=True,
        text=True,
        cwd=str(_project_root),
    )

    output = result.stdout
    if result.stderr:
        output += "\n" + result.stderr

    return TestRunResult(
        spec_id=spec_id,
        targets=targets,
        fallback=fallback,
        returncode=result.returncode,
        output=output,
        passed=result.returncode == 0,
    )
