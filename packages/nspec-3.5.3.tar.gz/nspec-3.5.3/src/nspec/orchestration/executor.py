"""Agent executor plugin interface for dispatching prompts to backends.

Resolves agent names from the ``[agents]`` config section to concrete
executor implementations. Three built-in backends:

- ``subprocess:codex`` — spawns the ``codex`` CLI via tmux (default for codex)
- ``subprocess:gemini`` — spawns the ``gemini`` CLI via tmux (default for gemini)
- ``subprocess:claude`` — spawns the ``claude`` CLI via tmux (default for claude)
- ``self`` — no-op, the current session handles it

Usage::

    from nspec.config import NspecConfig
    from nspec.orchestration.executor import resolve_executor

    config = NspecConfig.load()
    executor = resolve_executor("codex", config)
    result = executor.execute("Review this code...")
    if result.success:
        print(result.output)
"""

from __future__ import annotations

import logging
import os
import subprocess
import time
from abc import abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from nspec import tmux
from nspec.config import NspecConfig
from nspec.output import clean_terminal_output

logger = logging.getLogger("nspec.orchestration.executor")

STDIN_THRESHOLD = 100_000  # Prompts exceeding this size are piped via stdin (S956)


@dataclass
class ExecutorResult:
    """Result from an agent executor invocation."""

    success: bool
    output: str  # Raw response text
    error: str = ""  # Error message on failure
    duration_s: float = 0.0


@runtime_checkable
class AgentExecutor(Protocol):
    """Execute a prompt and return the response text."""

    def execute(self, prompt: str, *, timeout: int = 300, **kwargs: Any) -> ExecutorResult: ...


@dataclass
class TmuxExecutor:
    """Base class for executors that spawn a CLI inside a tmux session.

    Subclasses implement ``_build_command`` to produce the CLI-specific
    command line. All tmux spawn/poll/capture/timeout/cleanup logic lives
    here.

    Falls back to ``subprocess.run()`` when tmux is not available.
    """

    default_timeout: int = 300
    poll_interval: float = 2.0
    session_prefix: str = "nspec"
    completion_patterns: list[str] = field(default_factory=list)

    @abstractmethod
    def _build_command(self, prompt: str, **kwargs: Any) -> tuple[list[str], str]:
        """Build the CLI command and return (cmd, label).

        The label is used in log messages (e.g. model name).
        """

    @property
    def _cli_name(self) -> str:
        """Short name for log messages (e.g. 'codex', 'gemini')."""
        return self.session_prefix.removeprefix("nspec-") or "agent"

    def _write_log(self, prompt: str, result: ExecutorResult, label: str) -> None:
        """Write invocation to work/logs/ for debugging and audit."""
        name = self._cli_name
        try:
            log_dir = Path("work/logs")
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now(tz=UTC).strftime("%Y%m%d-%H%M%S")
            log_path = log_dir / f"{name}-{ts}.md"
            status = "SUCCESS" if result.success else "FAILED"
            lines = [
                f"# {name.title()} Execution Log — {status}",
                "",
                f"**Timestamp:** {datetime.now(tz=UTC).isoformat()}",
                f"**Label:** {label}",
                f"**Duration:** {result.duration_s:.1f}s",
                f"**Success:** {result.success}",
                "",
                "## Prompt",
                "",
                "```",
                prompt[:5000] + ("\n... (truncated)" if len(prompt) > 5000 else ""),
                "```",
                "",
                "## Output",
                "",
                "```",
                result.output or "(empty)",
                "```",
                "",
            ]
            if result.error:
                lines.extend(
                    [
                        "## Error",
                        "",
                        "```",
                        result.error,
                        "```",
                        "",
                    ]
                )
            log_path.write_text("\n".join(lines))
            logger.info("%s log written to %s", name.title(), log_path)
        except Exception:  # noqa: BLE001
            logger.warning("Failed to write %s log", name, exc_info=True)

    def _generate_session_name(self) -> str:
        """Generate a unique tmux session name."""
        return f"{self.session_prefix}-{os.getpid()}-{int(time.time())}"

    def _check_completion(self, content: str) -> bool:
        """Check if pane content matches any completion pattern."""
        if not self.completion_patterns:
            return False
        return any(pattern in content for pattern in self.completion_patterns)

    def _execute_tmux(  # noqa: C901
        self, prompt: str, *, effective_timeout: int, **kwargs: Any
    ) -> ExecutorResult:
        """Execute via tmux: spawn session, poll for completion, capture output."""
        prompt_as_stdin = len(prompt) > STDIN_THRESHOLD
        cmd, label = self._build_command(prompt, prompt_as_stdin=prompt_as_stdin, **kwargs)
        session_name = self._generate_session_name()
        name = self._cli_name

        prompt_file: Path | None = None
        if prompt_as_stdin:
            import tempfile

            fd, tmp_path = tempfile.mkstemp(prefix="nspec-prompt-", suffix=".txt")
            prompt_file = Path(tmp_path)
            os.write(fd, prompt.encode())
            os.close(fd)

        cwd = kwargs.get("cwd")
        if prompt_file:
            parts: list[str] = []
            if cwd:
                parts.append(f"cd {_shell_escape([str(cwd)])}")
            parts.append(f"{_shell_escape(cmd)} < {_shell_escape([str(prompt_file)])}")
            shell_cmd = " && ".join(parts)
        elif cwd:
            shell_cmd = f"cd {_shell_escape([str(cwd)])} && {_shell_escape(cmd)}"
        else:
            shell_cmd = _shell_escape(cmd)

        logger.info(
            "Executing %s via tmux session %s: label=%s, timeout=%ds",
            name,
            session_name,
            label,
            effective_timeout,
        )
        start = time.monotonic()

        try:
            tmux.new_session(session_name, shell_cmd, remain_on_exit=True)
        except tmux.TmuxError as exc:
            if prompt_file:
                prompt_file.unlink(missing_ok=True)
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"Failed to create tmux session: {exc}",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, label)
            return exec_result

        captured_output = ""
        try:
            while True:
                time.sleep(self.poll_interval)
                elapsed = time.monotonic() - start

                # Check if session still exists at all
                session_exists = tmux.has_session(session_name)

                if not session_exists:
                    duration = time.monotonic() - start
                    output = captured_output.strip()
                    if output:
                        logger.info("%s tmux session completed in %.1fs", name, duration)
                        exec_result = ExecutorResult(
                            success=True,
                            output=output,
                            duration_s=duration,
                        )
                    else:
                        exec_result = ExecutorResult(
                            success=False,
                            output="",
                            error=f"{name.title()} session exited with no output",
                            duration_s=duration,
                        )
                    self._write_log(prompt, exec_result, label)
                    return exec_result

                # Check if the process inside the pane has exited
                pane_dead = tmux.is_pane_dead(session_name)

                if pane_dead:
                    duration = time.monotonic() - start
                    try:
                        final_output = tmux.capture_pane(session_name, history=True).strip()
                    except tmux.TmuxError:
                        final_output = captured_output.strip()

                    tmux.kill_session(session_name)

                    if final_output:
                        logger.info(
                            "%s tmux session completed in %.1fs (final capture: %d chars)",
                            name,
                            duration,
                            len(final_output),
                        )
                        exec_result = ExecutorResult(
                            success=True,
                            output=final_output,
                            duration_s=duration,
                        )
                    else:
                        exec_result = ExecutorResult(
                            success=False,
                            output="",
                            error=f"{name.title()} session exited with no output",
                            duration_s=duration,
                        )
                    self._write_log(prompt, exec_result, label)
                    return exec_result

                # Process still running — capture current pane content
                try:
                    content = tmux.capture_pane(session_name, history=True)
                    captured_output = content
                except tmux.TmuxError:
                    continue  # transient capture failure

                # Check for completion patterns
                if self._check_completion(content):
                    duration = time.monotonic() - start
                    logger.info(
                        "%s completion pattern matched in %.1fs",
                        name,
                        duration,
                    )
                    tmux.kill_session(session_name)
                    exec_result = ExecutorResult(
                        success=True,
                        output=content.strip(),
                        duration_s=duration,
                    )
                    self._write_log(prompt, exec_result, label)
                    return exec_result

                # Check timeout
                if effective_timeout > 0 and elapsed > effective_timeout:
                    duration = time.monotonic() - start
                    logger.warning("%s tmux session timed out after %.1fs", name, duration)
                    tmux.kill_session(session_name)
                    exec_result = ExecutorResult(
                        success=False,
                        output=captured_output.strip(),
                        error=f"{name.title()} timed out after {effective_timeout}s",
                        duration_s=duration,
                    )
                    self._write_log(prompt, exec_result, label)
                    return exec_result
        finally:
            if prompt_file:
                prompt_file.unlink(missing_ok=True)
            tmux.kill_session(session_name)

    def _execute_subprocess(
        self, prompt: str, *, effective_timeout: int, **kwargs: Any
    ) -> ExecutorResult:
        """Fallback: execute via subprocess.run() when tmux is unavailable."""
        prompt_as_stdin = len(prompt) > STDIN_THRESHOLD
        cmd, label = self._build_command(prompt, prompt_as_stdin=prompt_as_stdin, **kwargs)
        cwd = kwargs.get("cwd")
        name = self._cli_name

        logger.info(
            "Executing %s subprocess (tmux unavailable): label=%s, timeout=%ds",
            name,
            label,
            effective_timeout,
        )
        start = time.monotonic()

        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                cwd=str(cwd) if cwd else None,
                input=prompt if prompt_as_stdin else None,
            )
            duration = time.monotonic() - start

            if result.returncode == 0 and result.stdout.strip():
                logger.info("%s subprocess completed in %.1fs", name, duration)
                exec_result = ExecutorResult(
                    success=True,
                    output=result.stdout.strip(),
                    duration_s=duration,
                )
                self._write_log(prompt, exec_result, label)
                return exec_result
            error_text = result.stderr.strip() or f"Exit code {result.returncode}"
            logger.warning(
                "%s subprocess failed (rc=%d) in %.1fs: %s",
                name,
                result.returncode,
                duration,
                error_text[:200],
            )
            exec_result = ExecutorResult(
                success=False,
                output=result.stdout.strip(),
                error=error_text,
                duration_s=duration,
            )
            self._write_log(prompt, exec_result, label)
            return exec_result
        except subprocess.TimeoutExpired:
            duration = time.monotonic() - start
            logger.warning("%s subprocess timed out after %.1fs", name, duration)
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"{name.title()} subprocess timed out after {effective_timeout}s",
                duration_s=duration,
            )
            self._write_log(prompt, exec_result, label)
            return exec_result
        except FileNotFoundError:
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"{name} CLI not found",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, label)
            return exec_result
        except OSError as exc:
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"Failed to launch {name} subprocess: {exc}",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, label)
            return exec_result

    def execute(self, prompt: str, *, timeout: int = 0, **kwargs: Any) -> ExecutorResult:
        """Execute a prompt via the CLI.

        Tries tmux first for reliable output capture, falls back to
        subprocess.run() when tmux is unavailable. All output is cleaned
        via ``clean_terminal_output()`` before returning.
        """
        effective_timeout = timeout if timeout > 0 else self.default_timeout

        if tmux.is_available():
            result = self._execute_tmux(prompt, effective_timeout=effective_timeout, **kwargs)
        else:
            result = self._execute_subprocess(prompt, effective_timeout=effective_timeout, **kwargs)

        if result.output:
            result.output = clean_terminal_output(result.output)

        return result


@dataclass
class CodexTmuxExecutor(TmuxExecutor):
    """Spawns the ``codex`` CLI inside a tmux session.

    Pulls defaults from ``[codex]`` and ``[review]`` config sections.
    """

    model: str = "gpt-5.3-codex"
    reasoning_effort: str = "medium"
    sandbox: str = "workspace-write"
    approval_policy: str = "on-request"
    flags: list[str] = field(default_factory=lambda: ["--full-auto"])
    default_timeout: int = 300
    poll_interval: float = 2.0
    session_prefix: str = "nspec-codex"
    completion_patterns: list[str] = field(default_factory=list)

    def _build_command(self, prompt: str, **kwargs: Any) -> tuple[list[str], str]:
        """Build the codex CLI command and return (cmd, model)."""
        model = kwargs.get("model", self.model)
        reasoning_effort = kwargs.get("reasoning_effort", self.reasoning_effort)
        sandbox = kwargs.get("sandbox", self.sandbox)
        approval_policy = kwargs.get("approval_policy", self.approval_policy)
        raw_flags = kwargs.get("flags", self.flags)
        if raw_flags is None:
            flags: list[str] = []
        elif isinstance(raw_flags, list | tuple) and all(
            isinstance(flag, str) for flag in raw_flags
        ):
            flags = list(raw_flags)
        else:
            raise TypeError("flags must be a list of strings")

        cmd = [
            "codex",
            "exec",
            "--model",
            model,
            "-c",
            f'model_reasoning_effort="{reasoning_effort}"',
            "-c",
            f'sandbox_mode="{sandbox}"',
            "-c",
            f'approval_policy="{approval_policy}"',
        ]
        cmd.extend(flags)
        if kwargs.get("prompt_as_stdin"):
            cmd.append("-")
        else:
            cmd.append(prompt)
        return cmd, model


@dataclass
class GeminiTmuxExecutor(TmuxExecutor):
    """Spawns the ``gemini`` CLI inside a tmux session.

    Pulls defaults from ``[gemini]`` config section.
    """

    model: str = "gemini-3-pro-preview"
    approval_mode: str = "plan"
    sandbox: bool = False
    flags: list[str] = field(default_factory=list)
    default_timeout: int = 300
    poll_interval: float = 2.0
    session_prefix: str = "nspec-gemini"
    completion_patterns: list[str] = field(default_factory=list)

    def _build_command(self, prompt: str, **kwargs: Any) -> tuple[list[str], str]:
        """Build the gemini CLI command and return (cmd, model)."""
        model = kwargs.get("model", self.model)
        approval_mode = kwargs.get("approval_mode", self.approval_mode)
        sandbox = kwargs.get("sandbox", self.sandbox)
        raw_flags = kwargs.get("flags", self.flags)
        if raw_flags is None:
            flags: list[str] = []
        elif isinstance(raw_flags, list | tuple) and all(
            isinstance(flag, str) for flag in raw_flags
        ):
            flags = list(raw_flags)
        else:
            raise TypeError("flags must be a list of strings")

        cmd = ["gemini"]
        if kwargs.get("prompt_as_stdin"):
            cmd.extend(["-p", "-"])
        else:
            cmd.extend(["-p", prompt])
        cmd.extend(
            [
                "-m",
                model,
                "--approval-mode",
                approval_mode,
                "--output-format",
                "text",
            ]
        )
        if sandbox:
            cmd.append("--sandbox")
        cmd.extend(flags)
        return cmd, model


@dataclass
class ClaudeCodeTmuxExecutor(TmuxExecutor):
    """Spawns the ``claude`` CLI inside a tmux session.

    Pulls defaults from ``[claude_code]`` config section.
    Used for single-shot Claude Code execution (reviews, refinements)
    and as the per-agent executor in swarm mode.
    """

    model: str = "sonnet"
    permission_mode: str = "bypassPermissions"
    default_timeout: int = 1800
    poll_interval: float = 5.0
    session_prefix: str = "nspec-claude"
    completion_patterns: list[str] = field(default_factory=list)

    def _build_command(self, prompt: str, **kwargs: Any) -> tuple[list[str], str]:
        """Build the claude CLI command and return (cmd, model)."""
        model = kwargs.get("model", self.model)
        permission_mode = kwargs.get("permission_mode", self.permission_mode)

        cmd = [
            "claude",
            "--print",
            "--model",
            model,
            "--permission-mode",
            permission_mode,
        ]
        if not kwargs.get("prompt_as_stdin"):
            cmd.append(prompt)
        return cmd, model


@dataclass
class SelfExecutor:
    """No-op executor — the current session handles the prompt."""

    def execute(
        self,
        prompt: str,
        *,
        timeout: int = 300,  # noqa: ARG002
        **kwargs: Any,  # noqa: ARG002
    ) -> ExecutorResult:
        return ExecutorResult(
            success=True,
            output=prompt,
            error="",
            duration_s=0.0,
        )


def _shell_escape(cmd: list[str]) -> str:
    """Join a command list into a shell-safe string."""
    import shlex

    return shlex.join(cmd)


def resolve_executor(agent_name: str, config: NspecConfig | None = None) -> AgentExecutor:
    """Resolve an agent name to a concrete executor.

    Reads ``config.agents.agents[agent_name]`` to determine the backend.
    Parses the prefix (``subprocess:``, ``self``) and returns the
    appropriate executor instance.

    Args:
        agent_name: Logical agent name (e.g., "codex", "gemini", "claude").
        config: NspecConfig instance. If None, loads from cwd.

    Returns:
        An AgentExecutor implementation.
    """
    if config is None:
        config = NspecConfig.load()

    impl_string = config.agents.agents.get(agent_name, "self")

    # Validate provider config values (warn only)
    try:
        from nspec.providers import validate_value

        if impl_string.startswith("subprocess:"):
            backend = impl_string.split(":", 1)[1]
            if backend == "codex":
                for field, value in [
                    ("models", config.codex.model),
                    ("effort_levels", config.codex.reasoning_effort),
                    ("sandbox_modes", config.codex.sandbox),
                ]:
                    w = validate_value("codex", field, value)
                    if w:
                        logger.warning(w)
            elif backend == "gemini":
                w = validate_value("gemini", "models", config.gemini.model)
                if w:
                    logger.warning(w)
    except Exception:  # noqa: BLE001
        logger.warning("Executor validation failed", exc_info=True)

    if impl_string == "self":
        return SelfExecutor()

    if impl_string.startswith("subprocess:"):
        backend = impl_string.split(":", 1)[1]
        if backend == "codex":
            return CodexTmuxExecutor(
                model=config.codex.model,
                reasoning_effort=config.codex.reasoning_effort,
                sandbox=config.codex.sandbox,
                approval_policy=config.codex.approval_policy,
                flags=config.codex.flags,
                default_timeout=config.review.timeout,
                poll_interval=config.codex.poll_interval,
                session_prefix=config.codex.session_prefix,
            )
        if backend == "gemini":
            return GeminiTmuxExecutor(
                model=config.gemini.model,
                approval_mode=config.gemini.approval_mode,
                sandbox=config.gemini.sandbox,
                flags=config.gemini.flags,
                default_timeout=config.review.timeout,
                poll_interval=config.gemini.poll_interval,
                session_prefix=config.gemini.session_prefix,
            )
        if backend == "claude":
            return ClaudeCodeTmuxExecutor(
                model=config.claude_code.model,
                permission_mode=config.claude_code.permission_mode,
                default_timeout=config.claude_code.timeout,
                poll_interval=config.claude_code.poll_interval,
                session_prefix=config.claude_code.session_prefix,
            )
        # Unknown subprocess backend — fall through to codex as default
        logger.warning("Unknown subprocess backend %r, defaulting to codex", backend)
        return CodexTmuxExecutor(
            model=config.codex.model,
            reasoning_effort=config.codex.reasoning_effort,
            flags=config.codex.flags,
            default_timeout=config.review.timeout,
            poll_interval=config.codex.poll_interval,
            session_prefix=config.codex.session_prefix,
        )

    # Unknown format — default to self
    logger.warning("Unknown agent implementation %r, defaulting to self", impl_string)
    return SelfExecutor()
