"""Provider registry and discovery for agent backends.

Maintains a curated registry of known providers (codex, gemini, claude, grok)
with their valid model names, effort levels, sandbox modes, and
provider-specific options. Discovery adapters introspect installed CLIs
and APIs to find available values.

Validation is warn-only: unknown values log a warning but never block execution.
New models from providers shouldn't break existing config.

Usage::

    from nspec.providers import BUILTIN_REGISTRY, validate_value, validate_config
    from nspec.providers import discover

    # Check if a value is known
    validate_value("codex", "models", "o4-mini")  # None (known)
    validate_value("codex", "models", "o4-ultra")  # "unknown model..." (warning)

    # Validate an entire config
    warnings = validate_config(config)

    # Run discovery adapters
    result = discover("codex")
"""

from __future__ import annotations

import logging
import subprocess
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger("nspec.providers")


@dataclass
class ProviderInfo:
    """Known valid values for a provider backend.

    Common fields have named attributes; provider-specific enums go in ``extra``.
    """

    name: str
    models: list[str] = field(default_factory=list)
    effort_levels: list[str] = field(default_factory=list)
    sandbox_modes: list[str] = field(default_factory=list)
    extra: dict[str, list[str]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Curated defaults — the canonical set of values we know about
# ---------------------------------------------------------------------------

BUILTIN_REGISTRY: dict[str, ProviderInfo] = {
    "codex": ProviderInfo(
        name="codex",
        models=[
            "gpt-5.3-codex",
            # S376: gpt-5.1-codex-max and gpt-5.1-codex ship on ChatGPT-account Codex CLI sessions.
            "gpt-5.1-codex-max",
            "gpt-5.1-codex",
            "o4-mini",
            "o3",
            "o3-pro",
            "codex-mini",
        ],
        effort_levels=["low", "medium", "high"],
        sandbox_modes=["workspace-write", "workspace-read", "none"],
        extra={
            "approval_policy": ["on-request", "unless-allow-listed", "full-auto", "suggest"],
        },
    ),
    "gemini": ProviderInfo(
        name="gemini",
        models=[
            "gemini-3-pro-preview",
            "gemini-2.5-pro",
            "gemini-2.5-flash",
        ],
        effort_levels=[],
        sandbox_modes=[],
        extra={
            "approval_mode": ["plan", "full", "auto"],
        },
    ),
    "claude": ProviderInfo(
        name="claude",
        models=[
            "claude-opus-4-6",
            "claude-sonnet-4-6",
            "claude-haiku-4-5-20251001",
            "opus",
            "sonnet",
            "haiku",
        ],
        effort_levels=["low", "medium", "high"],
        sandbox_modes=[],
        extra={},
    ),
    "grok": ProviderInfo(
        name="grok",
        models=["grok-3", "grok-3-mini"],
        effort_levels=[],
        sandbox_modes=[],
        extra={},
    ),
}


@dataclass
class DiscoveryResult:
    """Result from running a discovery adapter."""

    provider: str
    models: list[str] = field(default_factory=list)
    effort_levels: list[str] = field(default_factory=list)
    sandbox_modes: list[str] = field(default_factory=list)
    extra: dict[str, list[str]] = field(default_factory=dict)
    error: str = ""


# ---------------------------------------------------------------------------
# Discovery adapters
# ---------------------------------------------------------------------------


@runtime_checkable
class DiscoveryAdapter(Protocol):
    """Discover available values from a provider's CLI or API."""

    @property
    def provider_name(self) -> str: ...

    def discover(self, *, timeout: int = 10) -> DiscoveryResult: ...


@dataclass
class StaticDiscoveryAdapter:
    """Fallback adapter that returns registry defaults without introspection."""

    provider: str

    @property
    def provider_name(self) -> str:
        return self.provider

    def discover(self, *, timeout: int = 10) -> DiscoveryResult:  # noqa: ARG002
        info = BUILTIN_REGISTRY.get(self.provider)
        if info is None:
            return DiscoveryResult(
                provider=self.provider, error=f"Unknown provider: {self.provider}"
            )
        return DiscoveryResult(
            provider=self.provider,
            models=list(info.models),
            effort_levels=list(info.effort_levels),
            sandbox_modes=list(info.sandbox_modes),
            extra={k: list(v) for k, v in info.extra.items()},
        )


@dataclass
class CodexDiscoveryAdapter:
    """Discover models from the codex CLI via ``codex --help``."""

    @property
    def provider_name(self) -> str:
        return "codex"

    def discover(self, *, timeout: int = 10) -> DiscoveryResult:
        result = DiscoveryResult(provider="codex")
        try:
            proc = subprocess.run(  # noqa: S603
                ["codex", "--help"],  # noqa: S607
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            result.models = _parse_models_from_help(proc.stdout)
        except FileNotFoundError:
            result.error = "codex CLI not found"
        except subprocess.TimeoutExpired:
            result.error = "codex --help timed out"
        except OSError as exc:
            result.error = f"codex discovery failed: {exc}"

        # Merge with static defaults for fields not discoverable from --help
        info = BUILTIN_REGISTRY.get("codex")
        if info:
            if not result.models:
                result.models = list(info.models)
            result.effort_levels = list(info.effort_levels)
            result.sandbox_modes = list(info.sandbox_modes)
            result.extra = {k: list(v) for k, v in info.extra.items()}

        return result


@dataclass
class GeminiDiscoveryAdapter:
    """Discover models from the gemini CLI via ``gemini --help``."""

    @property
    def provider_name(self) -> str:
        return "gemini"

    def discover(self, *, timeout: int = 10) -> DiscoveryResult:
        result = DiscoveryResult(provider="gemini")
        try:
            proc = subprocess.run(  # noqa: S603
                ["gemini", "--help"],  # noqa: S607
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            result.models = _parse_models_from_help(proc.stdout)
        except FileNotFoundError:
            result.error = "gemini CLI not found"
        except subprocess.TimeoutExpired:
            result.error = "gemini --help timed out"
        except OSError as exc:
            result.error = f"gemini discovery failed: {exc}"

        # Merge with static defaults
        info = BUILTIN_REGISTRY.get("gemini")
        if info:
            if not result.models:
                result.models = list(info.models)
            result.extra = {k: list(v) for k, v in info.extra.items()}

        return result


@dataclass
class ClaudeDiscoveryAdapter:
    """Discover models from the Anthropic API via ``/v1/models``."""

    api_key_env: str = "ANTHROPIC_API_KEY"

    @property
    def provider_name(self) -> str:
        return "claude"

    def discover(self, *, timeout: int = 10) -> DiscoveryResult:
        import os

        result = DiscoveryResult(provider="claude")

        api_key = os.environ.get(self.api_key_env, "")
        if not api_key:
            result.error = f"{self.api_key_env} not set"
            # Fall back to static defaults
            info = BUILTIN_REGISTRY.get("claude")
            if info:
                result.models = list(info.models)
                result.effort_levels = list(info.effort_levels)
            return result

        try:
            import json

            req = urllib.request.Request(
                "https://api.anthropic.com/v1/models",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                },
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310 — controlled registry URL  # noqa: S310
                data = json.loads(resp.read())
                if "data" in data:
                    result.models = [m["id"] for m in data["data"] if "id" in m]
        except Exception as exc:  # noqa: BLE001
            result.error = f"Anthropic API discovery failed: {exc}"
            # Fall back to static defaults
            info = BUILTIN_REGISTRY.get("claude")
            if info:
                result.models = list(info.models)

        info = BUILTIN_REGISTRY.get("claude")
        if info:
            result.effort_levels = list(info.effort_levels)

        return result


# ---------------------------------------------------------------------------
# Adapter registry
# ---------------------------------------------------------------------------

_DISCOVERY_ADAPTERS: dict[str, type] = {
    "codex": CodexDiscoveryAdapter,
    "gemini": GeminiDiscoveryAdapter,
    "claude": ClaudeDiscoveryAdapter,
}


def _get_adapter(provider: str) -> DiscoveryAdapter:
    """Get the discovery adapter for a provider."""
    adapter_cls = _DISCOVERY_ADAPTERS.get(provider)
    if adapter_cls is None:
        return StaticDiscoveryAdapter(provider=provider)
    return adapter_cls()


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------


def validate_value(provider: str, field: str, value: str) -> str | None:
    """Check if a value is known for a provider field.

    Returns None if the value is known or the provider/field is unknown
    (we don't warn about things we can't validate).
    Returns a warning message string if the value is unrecognized.
    """
    info = BUILTIN_REGISTRY.get(provider)
    if info is None:
        return None  # Unknown provider — can't validate

    known: list[str] | None = None
    if field == "models":
        known = info.models
    elif field == "effort_levels":
        known = info.effort_levels
    elif field == "sandbox_modes":
        known = info.sandbox_modes
    else:
        known = info.extra.get(field)

    if known is None or not known:
        return None  # Unknown or empty field — can't validate

    if value in known:
        return None  # Known value

    return (
        f"Unknown {field} value '{value}' for provider '{provider}'. "
        f"Known values: {', '.join(known)}"
    )


def validate_config(config: Any) -> list[str]:  # noqa: C901
    """Validate provider-specific values in an NspecConfig.

    Returns a list of warning strings. Empty list means all values are known.
    Does NOT raise — validation is advisory only.
    """
    warnings: list[str] = []

    # Validate codex config
    if hasattr(config, "codex"):
        w = validate_value("codex", "models", config.codex.model)
        if w:
            warnings.append(w)
        w = validate_value("codex", "effort_levels", config.codex.reasoning_effort)
        if w:
            warnings.append(w)
        w = validate_value("codex", "sandbox_modes", config.codex.sandbox)
        if w:
            warnings.append(w)
        w = validate_value("codex", "approval_policy", config.codex.approval_policy)
        if w:
            warnings.append(w)

    # Validate gemini config
    if hasattr(config, "gemini"):
        w = validate_value("gemini", "models", config.gemini.model)
        if w:
            warnings.append(w)
        if hasattr(config.gemini, "approval_mode"):
            w = validate_value("gemini", "approval_mode", config.gemini.approval_mode)
            if w:
                warnings.append(w)

    # Validate review config
    if hasattr(config, "review"):
        if hasattr(config.review, "codex"):
            w = validate_value("codex", "models", config.review.codex.model)
            if w:
                warnings.append(w)
            w = validate_value("codex", "effort_levels", config.review.codex.effort)
            if w:
                warnings.append(w)
        if hasattr(config.review, "claude"):
            w = validate_value("claude", "models", config.review.claude.model)
            if w:
                warnings.append(w)
            w = validate_value("claude", "effort_levels", config.review.claude.effort)
            if w:
                warnings.append(w)
        if hasattr(config.review, "gemini"):
            w = validate_value("gemini", "models", config.review.gemini.model)
            if w:
                warnings.append(w)

    # Validate user overrides from [providers] section
    if hasattr(config, "providers") and config.providers.overrides:
        for provider_name in config.providers.overrides:
            if provider_name not in BUILTIN_REGISTRY:
                warnings.append(f"Unknown provider '{provider_name}' in [providers] overrides")  # noqa: PERF401

    return warnings


# ---------------------------------------------------------------------------
# Discovery entry point
# ---------------------------------------------------------------------------


def discover(provider: str | None = None, *, timeout: int = 10) -> dict[str, Any]:
    """Run discovery adapters and return structured results.

    Args:
        provider: Specific provider to discover, or None for all.
        timeout: Subprocess/HTTP timeout in seconds.

    Returns:
        Dict with registry, discovered values, and validation info.
    """
    from nspec.config import NspecConfig

    providers_to_check = [provider] if provider else list(BUILTIN_REGISTRY.keys())
    discovered: dict[str, Any] = {}

    for prov in providers_to_check:
        adapter = _get_adapter(prov)
        result = adapter.discover(timeout=timeout)
        discovered[prov] = {
            "models": result.models,
            "effort_levels": result.effort_levels,
            "sandbox_modes": result.sandbox_modes,
            "extra": result.extra,
            "error": result.error,
        }

    # Validate current config
    config_warnings: list[str] = []
    try:
        config = NspecConfig.load()
        config_warnings = validate_config(config)
    except Exception:  # noqa: BLE001
        config_warnings = ["Could not load config for validation"]

    return {
        "registry": {
            name: {
                "models": info.models,
                "effort_levels": info.effort_levels,
                "sandbox_modes": info.sandbox_modes,
                "extra": info.extra,
            }
            for name, info in BUILTIN_REGISTRY.items()
        },
        "discovered": discovered,
        "config_warnings": config_warnings,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_models_from_help(help_text: str) -> list[str]:
    """Extract model names from CLI --help output.

    Looks for lines containing model-like strings (patterns like
    ``word-number`` or ``word-number-word``). This is a best-effort
    heuristic — CLI help formats vary.
    """
    import re

    models: list[str] = []
    # Match model-like patterns: word-number variants
    pattern = re.compile(r"\b([a-z][\w.-]*(?:-\d[\w.-]*))\b", re.IGNORECASE)
    for line in help_text.splitlines():
        # Skip lines that are clearly not model listings
        lower = line.lower()
        if "model" in lower or "default" in lower:
            for match in pattern.finditer(line):
                candidate = match.group(1)
                # Filter out obviously non-model strings
                if len(candidate) > 3 and any(c.isdigit() for c in candidate):
                    models.append(candidate)
    return list(dict.fromkeys(models))  # dedupe preserving order
