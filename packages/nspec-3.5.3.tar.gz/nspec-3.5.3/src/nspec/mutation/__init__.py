"""Mutation package — nspec's write-path operations.

This package is the single entry point for all spec mutation operations.
Functions are organized into focused submodules by concern:

- ``_helpers``: Shared private utilities (file locks, validation, lookup)
- ``lifecycle``: Spec creation, deletion, completion, superseding, rejection
- ``deps``: Dependency graph mutations and priority management
- ``progress``: Task and acceptance-criteria checkbox updates
- ``status``: Status transitions and state-pair validation
- ``review``: Review workflow (request, start, approve, request changes)
- ``loe``: Level-of-effort calculation and updates
- ``state``: Spec state management (park, hold, reset, recover, exception)
- ``epic``: Epic-scoped queries and bulk operations
- ``adr``: Architecture Decision Record management
"""

from contextlib import suppress

# --- _helpers (private, but some are used by workflow/ and mcp_server) ---
from nspec.mutation._helpers import (
    NspecIntegrityError,
    _file_lock,
    _find_impl_file,
    _get_current_status,
    _git_add,
    _line_matches_task_id,
    _NspecCrudErrors,
    _validate_after_write,
)

# --- adr ---
from nspec.mutation.adr import (
    create_adr,
    get_next_adr_id,
    list_adrs,
)

# --- deps ---
from nspec.mutation.deps import (
    _auto_update_dependency_priorities,  # noqa: F401
    _build_reverse_dependency_map,  # noqa: F401
    _calculate_effective_priority,  # noqa: F401
    _check_dependency_cycle,  # noqa: F401
    _check_epic_priority_unique,  # noqa: F401
    _epic_priority_from_id,  # noqa: F401
    _find_dependent_specs,  # noqa: F401
    _get_priority_level,  # noqa: F401
    _next_available_epic_priority,  # noqa: F401
    add_dependency,
    check_cross_epic_dependency,
    move_dependency,
    remove_dependency,
    set_priority,
    swap_priority,
)

# --- epic ---
from nspec.mutation.epic import (
    auto_assign_ungrouped_to_epic,
    get_epic_specs,
    park_epic_specs,
)

# --- lifecycle ---
from nspec.mutation.lifecycle import (
    DuplicateSpecIdError,
    _allocate_and_reserve,  # noqa: F401
    _check_completion_readiness,  # noqa: F401
    _collect_all_existing_spec_ids,  # noqa: F401
    _get_id_ranges,  # noqa: F401
    _get_ids_with_fallback,  # noqa: F401
    _pick_next_id,  # noqa: F401
    _prune_reservations,  # noqa: F401
    _read_reservations,  # noqa: F401
    _remaining_ids_in_range,  # noqa: F401
    _reservation_path,  # noqa: F401
    _reserve_id,  # noqa: F401
    clean_dangling_deps,
    complete_spec,
    create_new_spec,
    delete_spec,
    finalize_spec,
    find_duplicate_spec_ids,
    force_archive_spec,
    get_all_spec_ids,
    get_next_spec_id,
    reject_spec,
    renumber_spec,
    supersede_spec,
    unify_collisions,
)

# --- loe ---
from nspec.mutation.loe import (
    _format_hours_to_loe,  # noqa: F401
    _loe_component_to_hours,  # noqa: F401
    _parse_loe_to_hours,  # noqa: F401
    calculate_epic_loe,
    set_loe,
    update_epic_loe,
)

# --- progress ---
from nspec.mutation.progress import (
    _check_files_modified,  # noqa: F401
    _check_sequential_order,  # noqa: F401
    _check_subtasks_complete,  # noqa: F401
    _find_task_by_id,  # noqa: F401
    _parse_task_file_annotations,  # noqa: F401
    check_acceptance_criteria,
    check_impl_task,
    set_task_blocked,
    set_task_unblocked,
    validate_spec_criteria,
)

# --- review ---
from nspec.mutation.review import (
    _add_review_note,  # noqa: F401
    _append_review_history_row,  # noqa: F401
    _get_impl_field,  # noqa: F401
    _get_review_round,  # noqa: F401
    _get_review_verdict,  # noqa: F401
    _set_impl_field,  # noqa: F401
    _set_review_verdict,  # noqa: F401
    approve_review,
    get_review_status,
    request_changes,
    request_review,
    start_review,
)

# --- state ---
from nspec.mutation.state import (
    _write_hold_reason,  # noqa: F401
    hold_spec,
    park_spec,
    recover_spec,
    reset_spec,
    set_exception,
    start_design_spec,
)

# --- status ---
from nspec.mutation.status import (
    VALID_FR_TRANSITIONS,
    VALID_IMPL_TRANSITIONS,
    _validate_transition,  # noqa: F401
    check_state_pair_warning,
    next_status,
    set_status,
)

with suppress(ImportError):
    from nspec.mutation.lifecycle import (
        _RESERVATION_TTL_SECONDS,  # noqa: F401
        EPIC_ID_RANGE,  # noqa: F401
        _active_reserved_ids,  # noqa: F401
        _read_reservation_data,  # noqa: F401
        _reservation_lock_path,  # noqa: F401
    )

__all__ = [
    # status
    "VALID_FR_TRANSITIONS",
    "VALID_IMPL_TRANSITIONS",
    # lifecycle
    "DuplicateSpecIdError",
    # helpers
    "NspecIntegrityError",
    "_NspecCrudErrors",
    "_file_lock",
    "_find_impl_file",
    "_get_current_status",
    "_git_add",
    "_line_matches_task_id",
    "_validate_after_write",
    # deps
    "add_dependency",
    # review
    "approve_review",
    # epic
    "auto_assign_ungrouped_to_epic",
    # loe
    "calculate_epic_loe",
    # progress
    "check_acceptance_criteria",
    "check_cross_epic_dependency",
    "check_impl_task",
    "check_state_pair_warning",
    "clean_dangling_deps",
    "complete_spec",
    # adr
    "create_adr",
    "create_new_spec",
    "delete_spec",
    "finalize_spec",
    "find_duplicate_spec_ids",
    "force_archive_spec",
    "get_all_spec_ids",
    "get_epic_specs",
    "get_next_adr_id",
    "get_next_spec_id",
    "get_review_status",
    # state
    "hold_spec",
    "list_adrs",
    "move_dependency",
    "next_status",
    "park_epic_specs",
    "park_spec",
    "recover_spec",
    "reject_spec",
    "remove_dependency",
    "renumber_spec",
    "request_changes",
    "request_review",
    "reset_spec",
    "set_exception",
    "set_loe",
    "set_priority",
    "set_status",
    "set_task_blocked",
    "set_task_unblocked",
    "start_design_spec",
    "start_review",
    "supersede_spec",
    "swap_priority",
    "unify_collisions",
    "update_epic_loe",
    "validate_spec_criteria",
]
