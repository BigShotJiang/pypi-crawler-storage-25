"""Review workflow: request, start, approve, request changes."""

import re
from pathlib import Path

from nspec.mutation._helpers import (
    _find_impl_file,
    _get_current_status,
)
from nspec.paths import NspecPaths
from nspec.runtime.atomic import spec_read, spec_write
from nspec.runtime.timestamps import now_iso


def _get_impl_field(impl_content: str, field_name: str) -> str | None:
    """Extract a field value from IMPL content.

    Args:
        impl_content: IMPL file content
        field_name: Field name without ** markers (e.g., "Implementer")

    Returns:
        Field value or None if not found/empty
    """
    pattern = rf"^\*\*{field_name}:\*\*\s*(.+)$"
    match = re.search(pattern, impl_content, re.MULTILINE)
    if match:
        value = match.group(1).strip()
        if value and value not in ("—", "--", "–"):  # noqa: RUF001
            return value
    return None


def _set_impl_field(impl_content: str, field_name: str, value: str) -> str:
    """Set a field value in IMPL content.

    If field doesn't exist, adds it after the header block.

    Args:
        impl_content: IMPL file content
        field_name: Field name without ** markers (e.g., "Implementer")
        value: New value to set

    Returns:
        Updated content
    """
    pattern = rf"^\*\*{field_name}:\*\*.*$"
    replacement = f"**{field_name}:** {value}"

    # Check if field exists
    if re.search(pattern, impl_content, re.MULTILINE):
        return re.sub(pattern, replacement, impl_content, flags=re.MULTILINE)

    # Field doesn't exist - add it after the last ** field in the header
    # Find the last **Field:** line before the first ---
    lines = impl_content.split("\n")
    insert_idx = None
    for i, line in enumerate(lines):
        if line.strip() == "---":
            break
        if line.startswith("**") and ":**" in line:
            insert_idx = i

    if insert_idx is not None:
        lines.insert(insert_idx + 1, replacement)
        return "\n".join(lines)

    # Fallback: just prepend warning (shouldn't happen with valid IMPL)
    print(f"⚠️  Could not find header block to add **{field_name}:** field")  # noqa: T201
    return impl_content


def _get_review_verdict(impl_content: str) -> str | None:
    """Extract review verdict from IMPL content.

    Returns:
        "PENDING", "APPROVED", "NEEDS_WORK", or None
    """
    pattern = r"^\*\*Verdict:\*\*\s*(\w+)"
    match = re.search(pattern, impl_content, re.MULTILINE)
    if match:
        return match.group(1).upper()
    return None


def _append_review_history_row(impl_content: str, verdict: str, reviewer: str) -> str:
    """Append a row to the ### Review History table.

    Creates the table if it doesn't exist. Determines round number
    by counting existing data rows.

    Args:
        impl_content: IMPL file content
        verdict: Review verdict (e.g., "APPROVED", "NEEDS_WORK")
        reviewer: Reviewer name

    Returns:
        Updated content with new history row appended
    """
    now = now_iso()

    header = "### Review History\n"
    table_header = "| # | Date | Verdict | Reviewer |\n|---|------|---------|----------|\n"

    if header in impl_content:
        # Table exists — count existing rows and append
        idx = impl_content.index(header) + len(header)
        after = impl_content[idx:]

        # Count data rows (lines starting with |, not header/separator)
        round_num = 0
        for line in after.split("\n"):
            stripped = line.strip()
            if (
                stripped.startswith("| ")
                and not stripped.startswith("| #")
                and not stripped.startswith("|--")
            ):
                round_num += 1
            elif stripped and not stripped.startswith("|"):
                break  # Past the table

        round_num += 1
        new_row = f"| {round_num} | {now} | {verdict} | {reviewer} |\n"

        # Find end of table (last | line)
        lines = after.split("\n")
        insert_at = 0
        for i, line in enumerate(lines):
            if line.strip().startswith("|"):
                insert_at = i + 1
            elif line.strip() and not line.strip().startswith("|"):
                break

        before_table_end = "\n".join(lines[:insert_at])
        after_table_end = "\n".join(lines[insert_at:])
        return impl_content[:idx] + before_table_end + "\n" + new_row + after_table_end
    # No history table — create it before ### Findings or ### Notes
    round_num = 1
    new_table = header + table_header + f"| {round_num} | {now} | {verdict} | {reviewer} |\n"

    for marker in ("### Findings\n", "### Notes\n"):
        if marker in impl_content:
            idx = impl_content.index(marker)
            return impl_content[:idx] + new_table + "\n" + impl_content[idx:]

    # Fallback: insert before ## Session Notes
    session_marker = "## Session Notes"
    if session_marker in impl_content:
        idx = impl_content.index(session_marker)
        return impl_content[:idx] + new_table + "\n" + impl_content[idx:]

    return impl_content.rstrip() + "\n\n" + new_table


def _get_review_round(impl_content: str) -> int:
    """Get the current review round number from the history table.

    Returns:
        Current round number (0 if no history table or no rows)
    """
    header = "### Review History\n"
    if header not in impl_content:
        return 0

    idx = impl_content.index(header) + len(header)
    after = impl_content[idx:]

    count = 0
    for line in after.split("\n"):
        stripped = line.strip()
        if (
            stripped.startswith("| ")
            and not stripped.startswith("| #")
            and not stripped.startswith("|--")
        ):
            count += 1
        elif stripped and not stripped.startswith("|"):
            break
    return count


def _set_review_verdict(impl_content: str, verdict: str, reviewer: str = "") -> str:
    """Set review verdict in IMPL content and append to review history.

    If **Verdict:** line doesn't exist, inserts the Review section.
    Also appends a row to ### Review History table.

    Args:
        impl_content: IMPL file content
        verdict: Review verdict string
        reviewer: Reviewer name for history table
    """
    pattern = r"^\*\*Verdict:\*\*.*$"
    replacement = f"**Verdict:** {verdict}"

    # Check if Verdict line exists (Review section already present)
    if re.search(pattern, impl_content, re.MULTILINE):
        impl_content = re.sub(pattern, replacement, impl_content, flags=re.MULTILINE)
        # Append to review history table (section already exists)
        if reviewer:
            impl_content = _append_review_history_row(impl_content, verdict, reviewer)
        return impl_content

    # Verdict line doesn't exist — insert Review section with history row
    now = now_iso()
    history_rows = ""
    if reviewer:
        history_rows = f"| 1 | {now} | {verdict} | {reviewer} |\n"

    review_section = f"""## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** {verdict}
**Reviewed:** —

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|
{history_rows}
### Findings

[Reviewer writes findings here]

"""

    # Insert before ## Session Notes if it exists
    session_marker = "## Session Notes"
    if session_marker in impl_content:
        idx = impl_content.index(session_marker)
        return impl_content[:idx] + review_section + impl_content[idx:]

    # Otherwise append before final --- or at end
    if impl_content.rstrip().endswith("---"):
        return impl_content.rstrip()[:-3] + review_section + "---\n"

    return impl_content.rstrip() + "\n\n" + review_section


def _add_review_note(
    impl_content: str,
    note: str,
    verdict: str = "",
) -> str:
    """Safely add a note to the Review Findings section.

    Uses string manipulation instead of regex replacement to avoid
    issues with special characters in the note text.

    When verdict is provided, prefixes the note with a round-stamped
    header: ``**Review N (date — VERDICT):**``

    Checks for ``### Findings`` first (current template), then
    ``### Notes`` (legacy), then falls back to creating a section.

    Args:
        impl_content: IMPL file content
        note: Note text to add (can contain any characters)
        verdict: Review verdict for round context prefix

    Returns:
        Updated content with note added after findings header
    """
    # Build round-context prefix if verdict provided
    if verdict:
        from datetime import datetime

        now = datetime.now().strftime("%Y-%m-%d %H:%M")  # noqa: DTZ005
        round_num = _get_review_round(impl_content)
        if round_num == 0:
            round_num = 1
        prefix = f"**Review {round_num} ({now} — {verdict}):**\n"
        note = prefix + note
    # Placeholder texts to strip when inserting real content
    placeholders = (
        "[Reviewer writes findings here]\n",
        "[Reviewer findings go here]\n",
        "[Old-style reviewer notes]\n",
        "<!-- Reviewer writes findings here -->\n",
        "(Reviewer writes findings here)\n",
    )

    # Look for Findings section first (current template), then Notes (legacy)
    for marker in ("### Findings\n", "### Notes\n"):
        if marker in impl_content:
            idx = impl_content.index(marker) + len(marker)
            after = impl_content[idx:]
            # Strip placeholder text
            for ph in placeholders:
                if after.lstrip("\n").startswith(ph):
                    stripped = after.lstrip("\n")
                    after = stripped[len(ph) :]
            return impl_content[:idx] + note + "\n\n" + after

    # Fallback: neither found, try adding after ## Review
    review_marker = "## Review\n"
    if review_marker in impl_content:
        idx = impl_content.index(review_marker) + len(review_marker)
        return impl_content[:idx] + f"\n### Findings\n{note}\n\n" + impl_content[idx:]

    # Last resort: append to end
    return impl_content + f"\n\n### Findings\n{note}\n"


def request_review(
    spec_id: str,
    implementer: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Mark spec as ready for review.

    Sets the Implementer field and moves to Testing status.

    Args:
        spec_id: Spec ID
        implementer: Name/handle of implementer (e.g., "claude", "gemini")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If spec is not in Active status
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = spec_read(impl_path)

    # Validate IMPL is in Active status (can't request review before work starts)
    current_status = _get_current_status(content, kind="IMPL")
    if current_status:
        status_code, _, status_text = current_status
        if status_code == 0:  # Planning
            raise ValueError(
                f"❌ Cannot request review: Spec {spec_id} is still in Planning. "
                f"Run nspec_activate first."
            )
        if status_code >= 2:  # Testing or beyond
            raise ValueError(
                f"❌ Cannot request review: Spec {spec_id} is already in {status_text}."
            )

    # Update implementer field
    content = _set_impl_field(content, "Implementer", implementer)

    # Ensure verdict is PENDING
    content = _set_review_verdict(content, "PENDING")

    spec_write(impl_path, content)

    # Move to Testing status (FR stays Active, IMPL goes to Testing)
    from nspec.mutation.status import set_status

    set_status(
        spec_id, 2, 2, docs_root, paths_config=paths_config, project_root=project_root
    )  # FR=Active, IMPL=Testing

    print(f"✅ Spec {spec_id} ready for review")  # noqa: T201
    print(f"   Implementer: {implementer}")  # noqa: T201
    print("   Status: 🧪 Testing (awaiting review)")  # noqa: T201
    print(  # noqa: T201
        f"\n   Next: A different reviewer should run: nspec_start_review {spec_id} <reviewer_name>"
    )

    return impl_path


def start_review(
    spec_id: str,
    reviewer: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Claim a spec for review.

    Sets the Reviewer field. Validates reviewer != implementer.

    Args:
        spec_id: Spec ID
        reviewer: Name/handle of reviewer
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If reviewer == implementer or spec not in Testing status
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = spec_read(impl_path)

    # Check implementer
    implementer = _get_impl_field(content, "Implementer")
    if implementer and implementer.lower() == reviewer.lower():
        raise ValueError(f"❌ Reviewer cannot be the same as implementer ({implementer})")

    # Set reviewer
    content = _set_impl_field(content, "Reviewer", reviewer)
    spec_write(impl_path, content)

    print(f"✅ Review started for Spec {spec_id}")  # noqa: T201
    print(f"   Implementer: {implementer or '(not set)'}")  # noqa: T201
    print(f"   Reviewer: {reviewer}")  # noqa: T201
    print("\n   After review, run either:")  # noqa: T201
    print(f"   - nspec_approve {spec_id}           # If approved")  # noqa: T201
    print(f"   - nspec_request_changes {spec_id}   # If changes needed")  # noqa: T201

    return impl_path


def approve_review(
    spec_id: str,
    notes: str | None,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Approve a spec's review.

    Records the APPROVED verdict, reviewer, and timestamp in the IMPL
    file.  Does **not** change FR or IMPL status — the caller is
    responsible for calling ``advance()`` / ``set_status()`` when the
    spec is actually ready to move forward.  This decoupling (S377)
    prevents spec-authoring-only reviews from accidentally pushing the
    FR to Completed before tasks and ACs are checked off.

    Args:
        spec_id: Spec ID
        notes: Optional review notes
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = spec_read(impl_path)

    # Validate reviewer is set
    reviewer = _get_impl_field(content, "Reviewer")
    if not reviewer:
        raise ValueError("❌ Cannot approve: No reviewer set. Run nspec_start_review first.")

    # Set verdict (with history tracking)
    content = _set_review_verdict(content, "APPROVED", reviewer=reviewer)

    # Add review date (full ISO timestamp)
    reviewed_ts = now_iso()
    content = _set_impl_field(content, "Reviewed", reviewed_ts)

    # Add notes to Review section if provided
    if notes:
        content = _add_review_note(content, notes, verdict="APPROVED")

    spec_write(impl_path, content)

    # S377: Status transition removed.  Previously this called
    # set_status(spec_id, 3, 3, ...) to move FR=Completed, IMPL=Ready.
    # That broke spec-authoring-only reviews where the spec isn't ready
    # for completion.  Callers (write_review_verdict MCP tool, /ngo
    # pipeline) now call advance() explicitly after recording the verdict.

    print(f"✅ Spec {spec_id} APPROVED")  # noqa: T201
    print(f"   Reviewer: {reviewer}")  # noqa: T201
    print(f"   Reviewed: {reviewed_ts}")  # noqa: T201
    print(f"\n   Ready to complete: complete(spec_id='{spec_id}')")  # noqa: T201

    return impl_path


def request_changes(
    spec_id: str,
    notes: str | None,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Request changes on a spec's review.

    Sets verdict to NEEDS_WORK. Spec stays in Testing status.

    Args:
        spec_id: Spec ID
        notes: Review notes explaining what needs to change (None to
            skip writing findings, e.g. when the reviewer already wrote
            them directly to the IMPL)
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = spec_read(impl_path)

    # Validate reviewer is set
    reviewer = _get_impl_field(content, "Reviewer")
    if not reviewer:
        raise ValueError(
            "❌ Cannot request changes: No reviewer set. Run nspec_start_review first."
        )

    # Set verdict (with history tracking)
    content = _set_review_verdict(content, "NEEDS_WORK", reviewer=reviewer)

    # Add review date (full ISO timestamp)
    today = now_iso()
    content = _set_impl_field(content, "Reviewed", today)

    # Add notes to Review section with round context (skip when None —
    # reviewer may have already written findings directly to the IMPL)
    if notes is not None:
        content = _add_review_note(content, notes, verdict="NEEDS_WORK")

    spec_write(impl_path, content)

    # Revert FR to Active (no longer Completed until review passes).
    # IMPL stays at Testing for the review retry cycle.
    from nspec.mutation.status import set_status

    set_status(
        spec_id,
        fr_status=2,
        impl_status=2,  # FR=Active, IMPL=Testing
        docs_root=docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    implementer = _get_impl_field(content, "Implementer")

    print(f"⚠️  Spec {spec_id} NEEDS WORK")  # noqa: T201
    print(f"   Reviewer: {reviewer}")  # noqa: T201
    print(f"   Notes: {notes}")  # noqa: T201
    print("   Status reverted to Active for fixes.")  # noqa: T201
    print(f"\n   Implementer ({implementer}) should address feedback, then:")  # noqa: T201
    print(f"   - nspec_request_review {spec_id} {implementer}  # Re-submit for review")  # noqa: T201

    return impl_path


def get_review_status(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict:
    """Get review status for a spec.

    Returns:
        Dict with implementer, reviewer, verdict, reviewed date
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = impl_path.read_text()

    return {
        "implementer": _get_impl_field(content, "Implementer"),
        "reviewer": _get_impl_field(content, "Reviewer"),
        "verdict": _get_review_verdict(content),
        "reviewed": _get_impl_field(content, "Reviewed"),
    }
