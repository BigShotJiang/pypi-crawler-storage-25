"""Architecture Decision Record management."""

import re
from pathlib import Path


def get_next_adr_id(docs_root: Path) -> str:
    """Get the next available ADR ID in the 900-999 range.

    Args:
        docs_root: Path to docs/ directory

    Returns:
        Next available ADR ID (e.g., "901", "902")

    Raises:
        ValueError: If ADR range is exhausted (900-999)
    """
    from nspec.config import NspecConfig

    config = NspecConfig.load()
    adr_min = config.id_ranges.adr_min
    adr_max = config.id_ranges.adr_max

    adr_dir = docs_root / "03-architecture"
    if not adr_dir.exists():
        return f"{adr_min}"

    # Find all existing ADR files
    used_ids = set()
    for f in adr_dir.glob("ADR-*.md"):
        # Extract ID from filename like ADR-245-title.md or ADR-901-title.md
        match = re.match(r"ADR-(\d+)", f.stem)
        if match:
            used_ids.add(int(match.group(1)))

    # Find next available in configured range
    for next_id in range(adr_min, adr_max + 1):
        if next_id not in used_ids:
            return f"{next_id}"

    raise ValueError(f"ADR range exhausted ({adr_min}-{adr_max})")


def create_adr(title: str, docs_root: Path) -> tuple[str, Path]:
    """Create a new ADR in the docs/03-architecture directory.

    ADRs are stored as ADR-XXX-title.md files (not as FR/IMPL pairs).

    Args:
        title: Title for the ADR
        docs_root: Path to docs/ directory

    Returns:
        (adr_id, adr_path) - The assigned ID and path to created file

    Raises:
        ValueError: If ADR range is exhausted
        FileNotFoundError: If ADR template doesn't exist
    """
    from datetime import datetime

    adr_dir = docs_root / "03-architecture"
    template_path = adr_dir / "ADR-TEMPLATE.md"

    if not template_path.exists():
        raise FileNotFoundError(f"ADR template not found: {template_path}")

    # Get next ADR ID
    adr_id = get_next_adr_id(docs_root)

    # Generate filename
    slug = title.lower()
    slug = re.sub(r"[^\w\s-]", "", slug)  # Remove special chars
    slug = re.sub(r"[-\s]+", "-", slug)  # Convert spaces to dashes
    slug = slug.strip("-")

    filename = f"ADR-{adr_id}-{slug}.md"
    adr_path = adr_dir / filename

    # Load and populate template
    template = template_path.read_text()
    current_date = datetime.now().strftime("%Y-%m-%d")  # noqa: DTZ005

    content = template.replace("ADR-XXX:", f"ADR-{adr_id}:")
    content = content.replace("[Decision Title]", title)
    content = content.replace("YYYY-MM-DD", current_date)

    # Write the file
    adr_path.write_text(content)

    return adr_id, adr_path


def list_adrs(docs_root: Path) -> list[tuple[str, str, str, Path]]:
    """List all ADRs with their status.

    Args:
        docs_root: Path to docs/ directory

    Returns:
        List of (adr_id, status, title, path) tuples, sorted by ID
    """
    adr_dir = docs_root / "03-architecture"
    if not adr_dir.exists():
        return []

    adrs = []
    for f in adr_dir.glob("ADR-*.md"):
        # Skip template
        if f.stem.upper() == "TEMPLATE":
            continue

        # Extract ID from filename
        match = re.match(r"ADR-(\d+)", f.stem)
        if not match:
            continue

        adr_id = match.group(1)

        # Read file to get status and title
        content = f.read_text()

        # Extract status - look for **Status:** DRAFT/PROPOSED/ACCEPTED/etc
        status_match = re.search(r"\*\*Status:\*\*\s+(\w+)", content)
        status = status_match.group(1) if status_match else "UNKNOWN"

        # Extract title from first heading after ADR-XXX:
        title_match = re.search(r"^#\s+ADR-\d+:\s+(.+)$", content, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else f.stem

        adrs.append((adr_id, status, title, f))

    # Sort by ID
    adrs.sort(key=lambda x: int(x[0]))

    return adrs


# =============================================================================
# Review Workflow Functions
# =============================================================================
