"""Shared private helpers for mutation submodules.

Contains file locking, post-write validation, IMPL lookup, status parsing,
priority emoji resolution, and task line matching utilities used across
multiple mutation submodules.
"""

import errno
import fcntl
import logging
import os
import re
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Literal

from nspec.domain.ids import normalize_spec_ref
from nspec.domain.statuses import (
    FR_STATUSES,
    IMPL_STATUSES,
    LEGACY_FR_STATUSES,
    LEGACY_IMPL_STATUSES,
)
from nspec.paths import NspecPaths, get_paths
from nspec.runtime.locks import _get_lock_dir

_crud_logger = logging.getLogger("nspec.crud")

# Exceptions expected during CRUD file operations
_NspecCrudErrors = (RuntimeError, ValueError, KeyError, TypeError, OSError, IOError)


class NspecIntegrityError(Exception):
    """Raised when a post-mutation integrity check fails.

    Indicates the spec database is in a potentially corrupt state after a write.
    The write already happened — the caller should report this to the user.
    """

    def __init__(self, spec_id: str, path: str, detail: str) -> None:
        self.spec_id = spec_id
        self.path = path
        self.detail = detail
        super().__init__(f"Integrity error for {spec_id} ({path}): {detail}")


@contextmanager
def _file_lock(
    path: Path, timeout: float | None = None, project_root: Path | None = None
) -> Iterator[None]:
    """Acquire an exclusive file lock to prevent concurrent read-modify-write races.

    Uses a separate lock file in the project-scoped lock directory.

    Args:
        path: The file being locked.
        timeout: Maximum time to wait for lock (seconds).
        project_root: Explicit project root for lock directory scoping.
                     If None, auto-detected via NspecConfig.
    """
    if timeout is None:
        try:
            from nspec.config import NspecConfig

            timeout = float(NspecConfig.load().timeouts.lock_acquire_s)
        except Exception:  # noqa: BLE001
            timeout = 10.0

    # Derive project root from the file path if not explicitly provided.
    # Walk up the directory tree to find .novabuilt.dev/ marker.
    if project_root is None:
        candidate = path.resolve().parent
        for _ in range(10):  # max depth
            if (candidate / ".novabuilt.dev").is_dir():
                project_root = candidate
                break
            if candidate.parent == candidate:
                break
            candidate = candidate.parent

    lock_dir = _get_lock_dir(project_root)
    lock_path = lock_dir / f"{path.name}.lock"
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    acquired = False
    try:
        start = time.monotonic()
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
                break
            except OSError as e:
                if e.errno not in (errno.EWOULDBLOCK, errno.EAGAIN):
                    raise
                if time.monotonic() - start > timeout:
                    raise TimeoutError(
                        f"Could not acquire file lock for {path.name} within {timeout}s"
                    ) from None
                time.sleep(0.1)
        yield
    finally:
        if acquired:
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _validate_after_write(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    *,
    check_fr: bool = True,
    check_impl: bool = True,
) -> None:
    """Post-mutation integrity check. Raises NspecIntegrityError if spec is corrupt."""
    from nspec.validation.validators import FRValidator, IMPLValidator

    paths = get_paths(docs_root, config=paths_config)

    if check_fr:
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            pass
        else:
            fr_path = fr_files[0]
            try:
                content = fr_path.read_text(encoding="utf-8")
                FRValidator().validate(fr_path, content)
            except (ValueError, OSError) as e:
                _crud_logger.error("Post-write FR validation failed for %s: %s", spec_id, e)
                raise NspecIntegrityError(spec_id, str(fr_path), str(e)) from e

    if check_impl:
        impl_files = list(paths.active_impls_dir.glob(f"IMPL-{spec_id}-*.md"))
        if not impl_files:
            pass
        else:
            impl_path = impl_files[0]
            try:
                content = impl_path.read_text(encoding="utf-8")
                IMPLValidator().validate(impl_path, content)
            except (ValueError, OSError) as e:
                _crud_logger.error("Post-write IMPL validation failed for %s: %s", spec_id, e)
                raise NspecIntegrityError(spec_id, str(impl_path), str(e)) from e


def _line_matches_task_id(line: str, task_id: str) -> bool:
    """Check if a checkbox line contains the given task ID."""
    bold_pattern = f"**{task_id}**:"
    plain_pattern_dot = f"] {task_id}. "
    plain_pattern_colon = f"] {task_id}: "
    plain_pattern_space = f"] {task_id} "
    return (
        bold_pattern in line
        or plain_pattern_dot in line
        or plain_pattern_colon in line
        or plain_pattern_space in line
    )


def _find_impl_file(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Find IMPL file for a spec. Searches both active and completed directories."""
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    impl_pattern = f"IMPL-{spec_id}-*.md"

    impl_dir = paths.active_impls_dir
    impl_files = list(impl_dir.glob(impl_pattern))
    if impl_files:
        return impl_files[0]

    completed_dir = paths.completed_impls_dir
    impl_files = list(completed_dir.glob(impl_pattern))
    if impl_files:
        return impl_files[0]

    raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found")


def _get_current_status(
    content: str, *, kind: Literal["FR", "IMPL", "ANY"] = "ANY"
) -> tuple[int, str, str] | None:
    """Extract current status from file content.

    Accepts both emoji+text format (``"🔵 Active"``) and words-only
    format (``"Active"``).

    Returns:
        Tuple of (status_code, emoji, text) or None if not found
    """
    fr_map: dict[str, tuple[int, str, str]] = {
        s.full: (s.code, s.emoji, s.text) for s in FR_STATUSES.values()
    }
    fr_map.update(LEGACY_FR_STATUSES)
    # Words-only entries (S332): "Proposed" -> same tuple as "🟡 Proposed"
    for s in FR_STATUSES.values():
        fr_map.setdefault(s.text, (s.code, s.emoji, s.text))

    impl_map: dict[str, tuple[int, str, str]] = {
        s.full: (s.code, s.emoji, s.text) for s in IMPL_STATUSES.values()
    }
    impl_map.update(LEGACY_IMPL_STATUSES)
    # Words-only entries (S332)
    for s in IMPL_STATUSES.values():
        impl_map.setdefault(s.text, (s.code, s.emoji, s.text))

    if kind == "FR":
        status_map = fr_map
    elif kind == "IMPL":
        status_map = impl_map
    else:
        status_map = {**fr_map, **impl_map}

    match = re.search(r"^\*\*Status:\*\*\s+(.+)$", content, re.MULTILINE)
    if match:
        status_str = match.group(1).strip()
        return status_map.get(status_str)
    return None


def _git_add(*paths: Path) -> None:
    """Git-add files so complete() can git-mv them later. No-op outside a git repo."""
    import subprocess
    from contextlib import suppress

    with suppress(FileNotFoundError, subprocess.TimeoutExpired):
        subprocess.run(  # noqa: S603
            ["git", "add", *[str(p) for p in paths]],  # noqa: S607
            capture_output=True,
            timeout=5,
        )
