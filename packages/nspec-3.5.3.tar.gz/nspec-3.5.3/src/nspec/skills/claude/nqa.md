---
description: Run quality analysis — complexity, maintainability, dead code, security, and coverage
---

Run the full quality analysis suite, compare against the tracked status file, and present an actionable summary with trend observations. Offer to fix the next highest-impact finding.

## Argument parsing

Parse `$ARGUMENTS` for optional flags:

- `--focus <area>` — run only one analysis: `complexity`, `maintainability`, `deadcode`, `security`, `coverage`, or `all` (default: `all`).
- `--fix` — after presenting the report, automatically start fixing the top recommendation (create a spec or fix inline if small enough).
- `--update` — after presenting the report, update `docs/qa/status.md` with the latest numbers and any new/resolved findings.
- No arguments — run everything, report all findings, and offer next action.

## Phase 0 — Read prior status

Read `docs/qa/status.md` to understand the baseline. This file tracks:
- Open findings (complexity, maintainability, coverage)
- Gaps not covered by mutation testing
- Resolved findings history
- Trend data (coverage %, grade F count, MI grade C count over time)

If the file doesn't exist, note this and proceed — Phase 5 will create it.

## Phase 1 — Run analysis tools

Run `make arch-viz` to generate all reports into `work/arch-viz/`. This runs:
- **radon cc** — cyclomatic complexity (grade C+ reported)
- **radon mi** — maintainability index (grade B- reported)
- **radon raw** — raw LOC/SLOC/comment metrics
- **vulture** — dead code detection (80%+ confidence)
- **bandit** — security scan (medium+ severity)
- **pyan3** — call graphs (HTML + SVG, visual only)

If `--focus` was specified, run only the relevant make sub-target:
- `complexity` / `maintainability` → `make arch-complexity`
- `deadcode` → `make arch-deadcode`
- `security` → `make arch-security`
- `coverage` → `make test-cov` (generates `work/htmlcov/`)
- `all` → `make arch-viz`

Also gather supplementary data in parallel:
- `poetry run interrogate src/nspec/ -v` — docstring coverage
- `git diff --stat $(git tag --sort=-v:refname | head -1)..HEAD` — changes since last release

## Phase 2 — Read and parse outputs

Read these files from `work/arch-viz/`:

1. **`complexity.md`** — parse the markdown table. Extract:
   - Count of functions per grade (C, D, E, F)
   - Top 10 highest-complexity functions (sorted by CC descending)
   - Any NEW grade-F functions compared to the documented set in `docs/testing/mutation-testing.md`

2. **`maintainability.txt`** — parse lines like `path - GRADE (score)`. Extract:
   - All files at grade C (MI = 0-9) — these are the hardest to maintain
   - All files at grade B with MI < 15 — approaching danger zone

3. **`deadcode.txt`** — parse vulture output. Extract:
   - Total count of suspected dead code items
   - Group by type: unused imports, unused functions, unused variables, unused classes
   - Flag any items in `src/nspec/mcp_server.py` as FALSE POSITIVES (MCP tool imports are registered via side-effect, not called directly)

4. **`security.txt`** — parse bandit output. Extract:
   - Count by severity (low/medium/high)
   - List any medium+ findings with file:line references
   - If no medium+ issues: report "clean"

5. **Coverage** (if available): read `work/htmlcov/index.html` or run `poetry run coverage report --show-missing` to get per-module coverage percentages. Flag any module below 70%.

## Phase 3 — Compute summary metrics

Calculate these aggregate numbers:

| Metric | How |
|--------|-----|
| **Codebase size** | Sum SLOC from `raw-metrics.txt` |
| **Complexity hotspots** | Count of grade D+ functions |
| **Grade F functions** | List by name with CC score |
| **Maintainability red** | Files at MI grade C (score 0-9) |
| **Dead code items** | Count from vulture (excluding mcp_server.py false positives) |
| **Security findings** | Count of medium+ severity |
| **Commits since release** | From git diff stat |

## Phase 4 — Present the report

Render the report in this format:

```
## Quality Report — <date>

### Summary

| Metric | Value | Trend |
|--------|-------|-------|
| SLOC | N | — |
| Complexity hotspots (D+) | N | ↑/↓/— vs last known |
| Grade F functions | N | list names |
| Maintainability red (C) | N files | list names |
| Dead code (real) | N items | — |
| Security (medium+) | N | — |
| Commits since vX.Y.Z | N | — |

### Complexity — Top 10 hotspots

| Function | File | CC | Grade |
|----------|------|----|-------|
| ... | ... | ... | ... |

### Maintainability — Files needing attention

| File | MI Score | Grade |
|------|----------|-------|
| ... | ... | ... |

### Dead code — Actionable items

(exclude mcp_server.py false positives)
- `file:line` — unused function `name`
- ...

### Security

- Clean / or list findings

### Recommendations

1. [Top priority action item with specific file:function reference]
2. [Second priority]
3. [Third priority]
```

### Recommendations guidance

Prioritize recommendations by impact:
1. **Grade F functions** — these need decomposition or dedicated test coverage (link to mutation testing phases if applicable)
2. **MI grade C files** — candidate for refactoring or splitting
3. **Real dead code** — safe deletions that reduce maintenance burden
4. **Security findings** — medium+ severity items need investigation
5. **Coverage gaps** — modules below 70% coverage

Cross-reference with `docs/testing/mutation-testing.md` expansion plan — if a hotspot is already targeted by a phase spec, note it. If a new hotspot isn't covered by any phase, flag it as a candidate for inclusion.

## Phase 5 — Compare with prior status and update

Compare the fresh analysis against `docs/qa/status.md`:

1. **New findings**: Any grade-F function, MI grade-C file, or sub-70% module that appears in the fresh data but NOT in the status file → add to the appropriate "Open Findings" section with a new row number.
2. **Resolved findings**: Any item in the status file that no longer appears in the fresh data (e.g., a function was decomposed below CC 40, or coverage rose above 70%) → move from "Open Findings" to "Resolved Findings" with today's date.
3. **Changed values**: If a metric changed (CC score, MI score, coverage %) → update the value in the status file.
4. **Trend row**: Append a new row to the Trend table with today's date and current metrics.
5. **Gaps table**: Update "Gaps Not Covered by Mutation Testing" if new hotspots appeared or existing ones got assigned to a phase.

If `--update` was passed (or no flags — default behavior), write the updated `docs/qa/status.md`. If the file didn't exist, create it from scratch using the template in Phase 4.

## Phase 6 — Offer next action

After presenting the report, offer to do the **next logical thing** based on priority:

1. **If there are gaps not covered by mutation testing** → offer to update the relevant phase spec's `paths_to_mutate` in `pyproject.toml` and add the module to the phase FR.
2. **If a module is below 40% coverage** → offer to write targeted tests for the uncovered lines.
3. **If there's real dead code (non-false-positive)** → offer to delete it.
4. **If there are medium+ security findings** → offer to investigate and fix.
5. **If coverage is below the 80% target** → identify the highest-impact module to test next.
6. **If all findings are tracked and covered** → report "all findings tracked, no immediate action needed."

Present the offer as a one-line question: "Next: [description of action]. Proceed?" If `--fix` was passed, skip the question and proceed directly.

## Notes

- The `mcp_server.py` unused imports are a known false positive pattern. MCP tools are registered by importing them (side-effect registration via FastMCP decorators). Always exclude these from the dead code count.
- `pyan3` call graph generation may produce empty output or fail on large codebases — this is non-critical. Report that call graphs are available if the files are non-empty, skip if empty.
- Raw metrics (`raw-metrics.txt`) is large (~1600 lines). Don't dump it — only extract the SLOC summary.
- The status file (`docs/qa/status.md`) is checked into git. Changes to it should be committed alongside any code fixes that resolve findings.
