---
description: Autonomous loop through the backlog — pick, execute, complete, repeat
argument-hint: [e###] [--max-specs <n>] [--dry-run] [--no-refine] [with <model> agent swarm]
---

Orchestrator that picks specs and executes them **inline** via `/ngo {spec_id}`. Each spec runs in this context — no subagent overhead. Context is managed via automatic compaction (`autoCompactWindow`), not per-spec isolation.

**CRITICAL: This is an AUTONOMOUS LOOP. After completing or blocking a spec, you MUST immediately loop back to Phase 1 and pick the next spec. NEVER ask the user "should I continue?" or "do you want me to proceed?" — the answer is always yes. The ONLY reasons to stop are: (1) `next_spec` returns no candidates, (2) `--max-specs` limit reached, or (3) the user explicitly interrupts. Asking for confirmation defeats the entire purpose of autonomous execution.**

**All backlog state is managed through nspec MCP tools — zero direct file I/O.**

## Argument Parsing

Parse `$ARGUMENTS` for:
- `--epic <id>` or bare `e###` → filter to a specific epic
- bare `s###` or `###` (numeric, not matching `e###`) → target a specific spec (skip Phase 1, execute inline)
- `--max-specs <n>` → stop after N spec completions (default: unlimited)
- `--dry-run` → show next pick and exit without executing
- `--no-refine` → skip backlog refinement after each completion
- `--per-spec-pr` → override `[loop] batch_branch` and force each `/ngo` invocation to push + PR per spec (passes `--push` to `/ngo`)
- `with <model> agent swarm` → parallel execution mode (see Swarm Mode below)

Initialize counters: `completed = 0`, `blocked_list = []`.

## Swarm Mode

When `with <model> agent swarm` is specified (e.g., `with sonnet agent swarm`):

1. **Launch swarm**: Call `swarm_launch(epic_id, num_agents=N, model="<model>")` — this handles queue initialization, git worktree creation, and spawning Claude Code CLI instances in tmux sessions. Each agent works in an isolated worktree on branch `nspec/claude-{i}`.
2. **Monitor progress**: Call `swarm_status()` to check agent health, tmux session status, completed specs, and failures.
3. **Teardown**: When done (or to abort), call `swarm_teardown()` — kills tmux sessions, removes worktrees, releases queue claims, and clears swarm state.

**Swarm agent prompt**: Each agent gets `/ngo {spec_id}` with heartbeat and release instructions. Agents call `queue_heartbeat` periodically to extend their lease.

**Lease timeout recovery**: If an agent crashes without releasing, its spec is automatically reclaimed after `lease_ttl_seconds` (default: 300s). The next `queue_claim` call reaps expired leases before assigning.

**Progress tracking**:
```
swarm_launch(epic_id="E005", num_agents=3, model="sonnet")
  → 3 agents spawned: claude-1 (S252), claude-2 (S205), claude-3 (S201)
swarm_status()
  → claude-1: running (S252), claude-2: running (S205), claude-3: completed (S201)
swarm_teardown()
  → 2 agents killed, 3 worktrees cleaned
```

**Configuration**: Swarm defaults are in `[claude_code]` config section (model, permission_mode, timeout, worktree_base, session_prefix).

For sequential mode (no swarm argument), continue to Phase 0 below.

## Loop Protocol

### Phase 0: Load Pipeline

1. Call `loop_pipeline()` to get the step list, agent map, and source indicator.
2. Store the result: `pipeline_steps`, `agent_map`, `pipeline_source`.
3. If `pipeline_source` is `"default"`, execute the phases below in their numbered order.
4. If `pipeline_source` is `"config"`, iterate through `pipeline_steps` and for each step:
   - Match `step.step` to the phase name below (e.g., `"pick"` → Phase 1, `"refine"` → Phase 8).
   - Skip unknown step types with a warning: `"Unknown pipeline step: {step.step}, skipping"`.
5. Steps not present in the pipeline are skipped entirely.

**Step type → Phase mapping:**

| Step type | Phase |
|-----------|-------|
| `pick` | Phase 1: Pick |
| `execute` | → Run `/ngo {spec_id}` inline (covers start, author_fr, auto_refine, execute, verify, review, complete) |
| `refine` | Phase 8: Refine |
| `report` | Phase 9: Progress Report |

**Note:** The `start`, `author_fr`, `auto_refine`, `verify`, `review`, and `complete` step types are all handled by the inline `/ngo` invocation. If the pipeline config includes them individually, they map to the single `/ngo` call.

### Phase 0.5: Targeted Spec Shortcut <!-- not a pipeline step -->

**Only execute this phase if a spec ID argument was provided** (bare `s###` or `###`).

1. **Invoke `/ngo {spec_id}` inline** via the `Skill` tool. This runs the full lifecycle in this context.
2. If the spec completes → increment `completed`, print completion summary, **EXIT**.
3. If the spec is parked or hits an exception → append to `blocked_list` with the reason, print failure summary, **EXIT**.

Do NOT loop after a targeted spec — the user asked for one specific spec.

### Phase 1: Pick <!-- step_type: pick -->

1. Call `get_epic` to resolve epic scope. If `--epic` was provided, use that ID; otherwise use the active epic.
2. Call `next_spec` (pass `epic_id` if set) to get the highest-priority unblocked spec.
3. If `next_spec` returns no candidate:
   - Print a summary: specs completed this run, blocked specs list.
   - **EXIT** — backlog is clear (or fully blocked).

### Phase 2: Dry-Run Check <!-- not a pipeline step -->

If `--dry-run` is active:
- Call `show` with the picked spec ID to display full details.
- Print: "Dry run — would pick spec {id}: {title}"
- **EXIT**.

### → Execute Spec Inline <!-- replaces Phases 3-7 -->

**Invoke `/ngo {spec_id}` inline** via the `Skill` tool. This runs the full spec lifecycle (start, author_fr, auto_refine, execute, verify, review, complete) in this context.

When `--per-spec-pr` is active, append ` --push` to the `/ngo` invocation so each spec pushes + creates a PR. Otherwise (default batch mode), `/ngo` commits locally and defers push to loop exit.

**Handle the result:**

- **Spec completed** → increment `completed`, continue to Phase 8.
- **Spec parked or exception** → append `{spec_id}: {reason}` to `blocked_list`, **GOTO Phase 1** (pick next spec).

**Context management:** Automatic compaction keeps the context window healthy across multi-spec runs. For very long runs (10+ specs), the model's `autoCompactWindow` setting triggers compaction as needed — no manual intervention required.

### Phase 8: Refine <!-- step_type: refine -->

Skip this phase if `--no-refine` is set.

After completing a spec, assess whether the backlog ordering still makes sense:

1. Call `epics` to review overall epic progress.
2. Call `blocked_specs` to check if anything is newly unblocked or still stuck.
3. Call `next_spec` (peek only — do not activate) to see what would be picked next.
4. Consider:
   - Did completing this spec unblock other specs? If so, are their priorities correct?
   - Did you learn something during execution that changes priorities?
   - Is there new work to capture? (missing specs, missing tasks on existing specs)
5. Take action using MCP tools:
   - `add_dep` / `remove_dep` to fix the dependency graph
   - `set_priority` to adjust priorities based on new knowledge
   - `create_spec` to capture newly discovered work
   - `task_unblock` to release tasks that were waiting on the completed spec
6. Print a brief refinement summary:
   - Dependencies changed (if any)
   - Priorities adjusted (if any)
   - New specs created (if any)
   - "No refinement needed" if nothing changed

### Phase 9: Progress Report <!-- step_type: report -->

Print after each spec completion:
- Specs completed this run: `{completed}`
- Specs remaining in epic (estimate from backlog)
- Specs blocked this run: `{blocked_list}`

If `--max-specs` was set and `completed >= max_specs`:
- Print full session summary.
- **EXIT**.

### GOTO Phase 1 (MANDATORY — DO NOT STOP HERE)

**You MUST loop back to Phase 1 now.** Call `next_spec` and continue. Do NOT ask the user if they want to continue. Do NOT summarize and wait. Do NOT treat this as a stopping point. The loop continues until `next_spec` returns no candidates or `--max-specs` is reached.

## Exit Summary

On any exit, print:
- Total specs completed this run
- Total specs blocked (with IDs and reasons)
- Blocked list for follow-up

### Batch Exit: Push + PR (default)

When `[loop] batch_branch` is `true` (default) and `--per-spec-pr` was NOT passed, the loop accumulated commits locally across all completed specs. At exit, push the batch and create a single PR.

**This applies whether running in a worktree or on a regular branch.** The only difference is step 7 (worktree cleanup).

1. **Check for commits:** `git log main..HEAD --oneline` via Bash.
   - If no commits beyond main: skip push/PR, go to step 7.

2. **Check for conflicts with main:**
   - `git fetch origin main` via Bash.
   - `git diff --stat origin/main...HEAD` via Bash — check what files diverge.
   - If the diff shows files outside `docs/` and `src/`, warn: those are likely shared infrastructure changes that may conflict with other epic branches.
   - `git merge-base --is-ancestor origin/main HEAD` via Bash — if main has advanced, note it in the PR body.

3. **Check for other open epic PRs:**
   - `gh pr list --state open --json title,headRefName,number` via Bash.
   - If other `epic/*` PRs exist, list them in the PR body under "## Related PRs" so reviewers can coordinate merge order.

4. **Run validation:** `make test-quick` via Bash.
   - If tests fail: do NOT push. Print "Tests failing — fix before pushing." and skip to step 7.

5. **Push the branch:** `git push -u origin HEAD` via Bash.

6. **Create PR:**
   - Get the branch name: `git branch --show-current`
   - Call `epic_specs(epic_id)` to build a summary table of spec statuses.
   - Create PR via `gh pr create`:
     - Title: `epic({epic_id}): {epic_title} — batch ({completed} specs)`
     - Body: Summary table of specs (completed/blocked/pending), stats, related PRs if any
     - If any specs are blocked or tests failed, create as `--draft`

7. **Worktree cleanup (if applicable):** If running in a git worktree (detect: `.git` is a file, not a directory — `test -f .git`):
   - Call `ExitWorktree` to return to main worktree.
   - Print cleanup instructions:
     ```
     PR: {pr_url}
     Branch: {branch_name}
     After merge: git worktree remove {worktree_path} && git branch -D {branch_name}
     ```

**When `--per-spec-pr` is active:** Skip this section entirely — each `/ngo` worker already pushed + created a PR for its spec. Only print the exit summary.

## Resilience Notes

**Context management:** Specs execute inline. Automatic compaction (`autoCompactWindow`) keeps the context healthy across multi-spec runs. For very long sessions, prior spec artifacts (diffs, tool results) are compacted away, preserving orchestrator state (counters, blocked_list).

**Failure containment:** `/ngo` parks specs on failure and returns control to the loop. The orchestrator records the failure in `blocked_list` and picks the next spec — no automatic retry.

**Checkpointing:** `/ngo` calls `session_save` throughout execution. If the session crashes, the spec can be resumed by running `/ngo {spec_id}` or `/nloop` again — it picks up from the last checkpoint.

**Never stop the loop:** If `/ngo` fails for any reason, record it in `blocked_list` and continue to the next spec. The loop keeps going.

**Exception state:** `/ngo` uses `exception()` (not `park()`) for failures that indicate the agent is stuck, hallucinating, or violating guardrails.

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `loop_pipeline` | Phase 0 — load pipeline and agent map |
| `get_epic` | Phase 1 — resolve epic scope |
| `next_spec` | Phase 1 — select highest-priority unblocked spec |
| `show` | Phase 2 — display spec details (dry-run) |
| `epics` | Phase 8 — review epic progress |
| `blocked_specs` | Phase 8 — check for newly unblocked work |
| `set_priority` | Phase 8 — adjust priorities |
| `add_dep` | Phase 8 — add discovered dependencies |
| `remove_dep` | Phase 8 — remove outdated dependencies |
| `create_spec` | Phase 8 — capture newly discovered work |
| `task_unblock` | Phase 8 — release tasks waiting on completed spec |
| `swarm_launch` | Swarm — init queue, create worktrees, spawn agents |
| `swarm_status` | Swarm — check agent health and progress |
| `swarm_teardown` | Swarm — kill agents, clean worktrees, clear state |

All execution-phase tools (`activate`, `session_start`, `task_complete`, `criteria_complete`, `review`, `review_spec`, `advance`, `complete`, etc.) are used by `/ngo` inline — invoked via the `Skill` tool within the loop.
