---
description: Full spec executor — resolve, execute, verify, review, and complete a spec
argument-hint: [spec-id (optional)]
---

Execute the complete lifecycle for a single spec: resolve it, do the work, verify acceptance criteria, get a review, and archive it. Act autonomously — never ask the user what to do.

**This is the single source of truth for "how a spec gets done."** Both standalone `/ngo` and `/nloop` (which calls `/ngo` for each spec) use this pipeline.

## Lifecycle Hints (`next_steps`)

Every nspec MCP call that owns a phase transition (`activate`, `task_complete`, `criteria_complete`, `advance`, `spec_tests`, `review`) returns a structured `next_steps` object when a transition or terminal condition applies. It looks like:

```json
{
  "next_steps": {
    "phase": "verify",
    "summary": "Entering Verify phase for S### — run tests.",
    "actions": [
      {"kind": "mcp", "tool": "spec_tests", "args": {"spec_id": "S###"}, "description": "..."}
    ]
  }
}
```

**Rule:** after every nspec MCP call, if the response carries `next_steps.actions`, honor the first action unless it conflicts with the current goal or with explicit pipeline logic below (e.g., the Phase 6 retry loop, parking on failure, Phase 5's `make test-quick` receipt capture). The hints are authoritative for "what's the next tool to call"; the phase structure below remains authoritative for orchestration (fix loops, checkpoints, failure handling).

## Argument Parsing

Parse `$ARGUMENTS` for:
- A spec ID (bare `s###` or `###`) → use that spec directly
- If no argument → auto-resolve (see Resolution below)

## Phase 1: Resolve Spec

**If a spec ID was provided**, use it directly. Skip to Resume Detection.

**Otherwise, auto-resolve using this deterministic cascade:**

1. Call `session_resume` (no args) or `get_epic` to check for an active spec in `state.json`.

2. **If there is an active spec that is NOT 100% complete** → resume it. Skip to Resume Detection.

3. **If the active spec is 100% complete** → call `advance` to move it to the next status. If it reaches Ready, call `complete` to archive it. Then fall through to (4).

4. **Find the next spec:** Call `next_spec` (with epic_id if an active epic is set). If no epic is set, call `next_spec` without filtering.

5. **If a next spec is found** → call `activate` on it. Continue to Resume Detection.

6. **If no workable specs exist** → show the backlog summary from `epics` and state "No unblocked specs available. Create new specs or unblock existing ones." **EXIT**.

## Phase 2: Resume Detection

Check the IMPL status (from the `show(spec_id)` response or the status field from resolution) to determine which phases to skip. Store the result as `resume_phase`:

| IMPL Status contains | `resume_phase` | Skip |
|----------------------|----------------|------|
| "Planning" or "Proposed" | 3 | Nothing — full pipeline |
| "Active" | 4 | Skip Phase 3 (activate), Phase 3.0 (author_fr), Phase 3.5 (auto_refine) |
| "Testing" | 5 | Skip Phases 3, 3.0, 3.5, 4 |
| "Ready" | 6 | Skip Phases 3, 3.0, 3.5, 4, 5 |

Print: "Spec {id} at {status} — resuming from Phase {resume_phase}"

For Active specs, call `session_start(spec_id)` here to load the task list and identify which task to resume from.

## Phase 2.5: Pre-flight Snapshot

**Run this phase for all specs (regardless of `resume_phase`).**

Call `preflight(spec_id)` to get a structured state snapshot. Print a compact summary:

```
PRE-FLIGHT: S### P# status tasks:done/total deps:[dep_id:status,...] branch:name dirty:N
```

If `anomaly_count > 0`, print each anomaly as a warning line:

```
WARNING: <anomaly description>
```

Pre-flight warnings are informational — they do NOT abort execution. The agent should note them and proceed. This snapshot provides a "before" picture that helps diagnose state-mismatch bugs if they occur during execution.

## Phase 3: Start

**Skip this phase if `resume_phase > 3`.**

The spec is not yet Active, so no `next_steps` has been emitted. Bootstrap the session:
- `activate(spec_id)` — then honor the hint it returns for what to do next (task execution, FR/IMPL refinement if skeleton).
- `session_start(spec_id)` — loads tasks and resume point for task-by-task execution.

### Phase 3.0: Author FR (if skeleton)

**Skip this phase if `resume_phase > 3`.**

1. Call `refine_fr(spec_id)` to check if the FR has placeholder content.
2. If `is_skeleton` is False → skip, continue to Phase 3.5.
3. If `is_skeleton` is True:
   a. Execute the prompt: call `execute_agent(prompt=..., purpose="refinement")`.
   b. If timeout or no response → `park(spec_id, reason="FR authoring timeout")`, **EXIT with failure**.
   c. Call `write_fr_refinement(spec_id, agent_output)` with the response `output` field.
   d. If write fails → `park(spec_id, reason="FR authoring parse failed")`, **EXIT with failure**.
   e. Continue to Phase 3.5.

### Phase 3.5: Auto-Refine IMPL (if skeleton)

**Skip this phase if `resume_phase > 3`.**

1. Call `refine_impl(spec_id)` to check if the IMPL has placeholder tasks.
2. If `is_skeleton` is False → skip, continue to Phase 4.
3. If `is_skeleton` is True:
   a. Execute the prompt: call `execute_agent(prompt=..., purpose="refinement")`.
   b. If timeout or no response → `park(spec_id, reason="Refinement timeout")`, **EXIT with failure**.
   c. Call `write_refinement(spec_id, agent_output)` with the response `output` field.
   d. If write fails → `park(spec_id, reason="Refinement parse failed")`, **EXIT with failure**.
   e. Call `session_start(spec_id)` again to reload the refined task list.
   f. Continue to Phase 4.

## Phase 4: Execute

**Skip this phase if `resume_phase > 4`.**

**All execution is inline — never use the Agent tool.** Regardless of task count or LOE, execute every task directly in this context.

For each pending task in order:

1. **Do the work.** Read the task description, make code changes, write tests — whatever the task requires.
2. Mark the task done and honor the `next_steps.actions` returned by `task_complete`. The hint will point at the next task mid-flight, or at `criteria_complete` + `advance` when all tasks are done.
3. Run targeted tests when the hint (or Phase 5) says to. If the `spec_tests` response has `passed=false`, honor its retry hint; if it still fails, `task_block` + `session_save` + `park`, then **EXIT with failure**.
4. Checkpoint via `session_save` after each task.

**After all tasks complete:** the last `task_complete` / `criteria_complete` response points at `advance`. Honor it, then `session_save(spec_id, phase=5)` to checkpoint.

## Phase 5: Verify & Commit

**Skip this phase if `resume_phase > 5`.**

1. **Run `make test-quick` via Bash** once before marking any criteria, to confirm the implementation is sound. **Capture the last 30 lines of output** — this will be passed to the reviewer as a test receipt. (This is the one case we can't fully defer to `next_steps`: the `spec_tests` hint points at targeted tests, not the full-suite receipt the reviewer needs.)
2. If tests fail, fix and retry before proceeding.
3. Mark each acceptance criterion with `criteria_complete`. The hint returned by the final `criteria_complete` call will point at `advance`. If an AC cannot be satisfied, `task_block` + `park` the spec and **EXIT with failure**.
4. **Commit implementation changes before review:**
   - Ensure `git status --porcelain` shows only files related to this spec.
     If you have unrelated changes, call `park(spec_id, reason="Unrelated worktree changes prevent single-spec commit")`
     and **EXIT with failure**.
   - Stage: `git add -A`
   - Commit message MUST follow conventional commits:
     `fix|feat|docs|test|refactor|chore(<scope>): <short summary>`
     Then include the spec ID in the body, e.g.:
     `git commit -m "fix(tui): refresh table on resize" -m "Refs: S123"`
   - Verify clean: `git status --porcelain` should be empty after commit.
   - **Capture the commit SHA** via `git rev-parse HEAD` — the reviewer will review this specific commit.

## Phase 6: Review (MANDATORY)

**No spec can be completed without an APPROVED review.**

The review agent is configured via `[review].agent` in config.toml (default: `"codex"`). The `review()` tool handles dispatch automatically. `advance`'s Testing→Ready hint already points at `review(spec_id, base_branch="main")` — honor it, passing `test_results=<Phase 5 output>` so the reviewer has a receipt without re-running tests. `session_save` first so a timeout doesn't lose state.

The review agent writes findings directly to the IMPL file and responds with just the verdict (APPROVED or NEEDS_WORK). This means findings are persisted reliably regardless of agent output truncation.

**Handle the response based on `mode`:**

   **If `mode` is "atomic" (external agent):**
   The review was executed server-side. The response contains `verdict`, `findings`, and `reviewer`. Verdict and findings have already been written to the IMPL. Proceed to step 4.

   **If `mode` is not present (self-review fallback):**
   The response contains `prompt_file` (path to the review prompt on disk) and `review_token` (same as `review_spec()` output). Read the prompt file via Bash, then YOU must evaluate the code against the criteria and produce findings with P-level severity (P0-P3). Apply the same rubric: P0/P1 → NEEDS_WORK, P2/P3 only → APPROVED. Then call `write_review_verdict` with the verdict, feedback, `reviewer="claude"`, and `review_token`.

4. **Handle the verdict:**

   **If timeout or error (`success` is false):**
   - Call `park` with reason: "Review timeout — retry with /nreview {spec_id}"
   - **EXIT with failure.**

   **If verdict is APPROVED:**
   - Atomic mode: verdict is already written to IMPL. Self-review: call `write_review_verdict` with the verdict and feedback.
   - Call `advance(spec_id)` to transition Testing → Ready (S377: verdict no longer auto-advances statuses).
   - `session_save(spec_id, phase=7)` to checkpoint, then **continue to Phase 7**.

   **If verdict is NEEDS_WORK:**
   - Atomic mode: findings are already written to IMPL. Self-review: call `write_review_verdict` with the verdict and feedback first.
   - The response's `next_steps` points at `review` retry. Before re-dispatching, fix findings, re-run `make test-quick` (capture output for the receipt), and **amend the implementation commit** (`git add -A && git commit --amend --no-edit`) so the reviewer sees a clean commit. Cap retries at `config.review.max_retries` (default 5) — on exhaustion, `park(spec_id, reason="Review failed after N retries — needs manual intervention")` and **EXIT with failure**.

## Phase 7: Complete

1. Call `complete` with the spec ID to archive to completed/done (spec is already Ready from Phase 6's `advance()` call).
   - **Note:** `complete()` will also verify APPROVED verdict as a safety gate.
2. Call `session_clear` to clean up session state.
3. If there are any uncommitted changes (e.g. review findings written to IMPL, spec archival), create a follow-up commit:
   - Stage: `git add -A`
   - Commit: `git commit -m "chore(spec): archive S### after review" -m "Refs: S###"`
4. **Push after every spec (always):**
   - Run `git push origin HEAD` immediately after commit. This enables async CI feedback and visibility for parallel agents/reviewers.
   - Do NOT create a PR per spec — PRs are created at `/nloop` exit or manually.
   - If push fails (e.g., no remote, auth error), log a warning but do NOT block completion.
   - After push, run `.claude/hooks/ci-watch.sh` in the background (non-blocking) so CI feedback arrives asynchronously.
5. **Post-flight snapshot:** Call `show(spec_id)` to verify the spec has been archived. Print a compact post-flight summary:

   ```
   POST-FLIGHT: S### archived — tasks:done/total AC:done/total branch:name worktree:clean|dirty
   ```

   If the spec is still found in active (not archived), print a warning:
   ```
   WARNING: Spec S### still appears active after complete — check archive status
   ```

6. Print completion summary: spec ID, title, phases executed.
7. **EXIT with success.**

## Failure Handling

On any failure, `/ngo` parks the spec and exits — it does NOT loop. The caller (`/nloop` or the user) decides what to do next.

| Failure Mode | Action | Exit |
|--------------|--------|------|
| FR authoring timeout/parse failure | `park(spec_id, reason)` | failure |
| IMPL refinement timeout/parse failure | `park(spec_id, reason)` | failure |
| Task failure (after retry) | `task_block` + `park(spec_id, reason)` | failure |
| Criteria unsatisfied | `task_block` + `park(spec_id, reason)` | failure |
| Review timeout | `park(spec_id, reason)` | failure |
| Review NEEDS_WORK after `config.review.max_retries` retries | `park(spec_id, reason)` | failure |
| Unrelated worktree changes | `park(spec_id, reason)` | failure |
| No workable specs | (no park — nothing to park) | failure |

## Exception vs Paused

- **Paused:** Temporary block, retryable. Use `park()`. Can be resumed.
- **Exception:** Requires human investigation. Use `exception()`. Something went wrong that suggests the agent is stuck, hallucinating, or violating guardrails.

## Rules

- **Never ask** "what do you want to work on?" or "should I proceed?"
- **Never present options** for the user to pick from
- **Always act**: resolve → execute → verify → review → complete (or park on failure)
- All spec resolution MUST use nspec MCP tools (`session_start`, `next_spec`, `activate`, `advance`, `complete`, `get_epic`, `blocked_specs`) — never read FR/IMPL files directly to determine what to work on

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `get_epic` | Resolve — check active epic |
| `session_resume` | Resolve — check for active spec |
| `next_spec` | Resolve — find highest-priority unblocked spec |
| `activate` | Resolve/Start — set spec Active |
| `preflight` | Pre-flight — state snapshot before execution |
| `show` | Resume Detection / Post-flight — check IMPL status, verify archive |
| `session_start` | Start/Resume — load tasks and resume point |
| `refine_fr` | Author FR — check skeleton and get prompt |
| `write_fr_refinement` | Author FR — write authored content to FR |
| `refine_impl` | Auto-Refine — check skeleton and get prompt |
| `write_refinement` | Auto-Refine — write refinement to IMPL |
| `spec_tests` | Execute — run targeted tests for spec |
| `task_complete` | Execute — mark task done |
| `task_block` | Execute — record failure reason |
| `park` | Any failure — pause blocked spec |
| `exception` | Guardrail violation — set Exception state |
| `session_save` | Execute/Review — checkpoint progress |
| `criteria_complete` | Verify — mark acceptance criteria met |
| `review` | Review — atomic review for external agents, decomposed for self-review |
| `review_spec` | Review — get review prompt (self-review fallback) |
| `write_review_verdict` | Review — record verdict (self-review only) |
| `advance` | Complete — move spec through statuses |
| `complete` | Complete — archive to done |
| `session_clear` | Complete — clean up session state |
| `epics` | Resolve — backlog summary (no specs case) |
| `blocked_specs` | Resolve — check for blockers |

## Related commands
- `/nbacklog` - View dashboard (THE COMPASS)
- `/nbacklog:show <id>` - Show spec details
- `/nloop` - Autonomous backlog loop (calls `/ngo` for each spec)
