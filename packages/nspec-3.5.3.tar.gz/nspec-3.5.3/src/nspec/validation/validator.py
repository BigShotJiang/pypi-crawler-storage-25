"""Nspec Validator - Core validation and generation logic.

Extracted from cli.py to reduce module size and improve maintainability.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from nspec.domain.datasets import DatasetLoader, DatasetStats, NspecDatasets
from nspec.domain.statuses import (
    ALL_PRIORITIES,
    FR_STATUSES,
    PRIORITY_NAMES,
    FRStatusCode,
    is_completed_status,
)
from nspec.paths import NspecPaths
from nspec.spinner import spinner
from nspec.summary import render_project_status
from nspec.validation.checkers import (
    BusinessLogicChecker,
    DependencyChecker,
    ExistenceChecker,
    OrderingChecker,
    ValidationError,
)

logger = logging.getLogger("nspec")


class NspecValidator:
    """Main orchestrator for nspec validation and generation.

    This class runs all 6 validation layers and provides reporting.

    Architecture (2-pass):
        Pass 1: Load datasets, validate, and calculate final sorted order
        Pass 2: Format final sorted datasets to NSPEC.md and NSPEC_COMPLETED.md
    """

    def __init__(
        self,
        docs_root: Path,
        strict_mode: bool = False,
        strict_completion_parity: bool = True,
        paths_config: NspecPaths | None = None,
        project_root: Path | None = None,
        registry: object | None = None,
    ) -> None:
        """Initialize validator.

        Args:
            docs_root: Root docs directory (usually Path("docs"))
            strict_mode: If True, enforce that every spec must be grouped
                        under at least one epic
            strict_completion_parity: If True, IMPL=Completed requires FR=Completed
            registry: Optional SpecTypeRegistry for required_sections validation.
        """
        self.docs_root = docs_root
        self.strict_mode = strict_mode
        self.strict_completion_parity = strict_completion_parity
        self.paths_config = paths_config
        self.project_root = project_root
        self.registry = registry
        self.datasets: NspecDatasets | None = None
        self.ordered_active_specs: list[str] = []
        self.ordered_completed_specs: list[str] = []
        self.verbose_status: bool = False  # Compact status by default (emoji only)
        self.epic_filter: str | None = None  # Filter to show only epic + dependencies

    def validate(self) -> tuple[bool, list[str]]:
        """Run all validation layers.

        Returns:
            (success, errors) - success=True if no errors.
            Also populates self.structured_errors with ValidationError objects.
        """
        errors: list[str] = []
        self.structured_errors: list[ValidationError] = []

        # Layer 1-2: Format validation + dataset loading
        # S929: DatasetLoader no longer raises on individual parse errors.
        # Invalid files are skipped and their errors are collected on the
        # datasets object. We convert them to structured ValidationError
        # objects here so the TUI error screen and CLI both surface them.
        logger.debug("Layer 1-2: Loading and validating document formats...")
        with spinner("Loading nspec"):
            loader = DatasetLoader(
                docs_root=self.docs_root,
                paths_config=self.paths_config,
                project_root=self.project_root,
                registry=self.registry,  # pyright: ignore[reportArgumentType]
            )
            self.datasets = loader.load()
        logger.debug(
            "Loaded %d specs (%d active, %d completed)",
            self.datasets.total_spec_count(),
            self.datasets.active_spec_count(),
            self.datasets.completed_spec_count(),
        )

        # S929: Surface per-file parse errors as structured validation errors
        if self.datasets.parse_errors:
            for label, path, error_msg in self.datasets.parse_errors:
                # Try to extract spec ID from filename (e.g., "FR-S123-..." → "S123")
                spec_id_from_file = None
                stem = path.stem
                parts = stem.split("-")
                if len(parts) >= 2:
                    candidate = parts[1]
                    if candidate.startswith(("S", "E")):
                        spec_id_from_file = candidate

                ve = ValidationError(
                    layer="Layer 1-2: Format/Loading",
                    message=f"{label} parse error: {error_msg}",
                    spec_id=spec_id_from_file,
                )
                self.structured_errors.append(ve)
                errors.append(f"{label} parse error: {error_msg}")
            logger.warning(
                "%d file(s) skipped due to parse errors", len(self.datasets.parse_errors)
            )

        # S909 / AC-F3: Surface cross-directory ID collisions as validation
        # errors so `nspec validate` remains the visible audit surface.
        # Collisions are recorded on the dataset (load() does not raise);
        # this is the only place they become user-visible errors.
        collision_errors: list[str] = []
        for spec_id, sources in self.datasets.fr_collisions.items():
            self._add_collision_error("FR", spec_id, sources, collision_errors)
        for spec_id, sources in self.datasets.impl_collisions.items():
            self._add_collision_error("IMPL", spec_id, sources, collision_errors)
        for spec_id, sources in self.datasets.fr_archive_collisions.items():
            self._add_collision_error("FR", spec_id, sources, collision_errors)
        for spec_id, sources in self.datasets.impl_archive_collisions.items():
            self._add_collision_error("IMPL", spec_id, sources, collision_errors)

        success, layer_errors = self._run_layers()
        # S929: Include parse errors in the returned error list so that
        # `nspec validate` CLI reports them and success reflects them.
        all_errors = errors + collision_errors + layer_errors
        return (success and not collision_errors and not errors), all_errors

    def _add_collision_error(
        self,
        label: str,
        spec_id: str,
        sources: list[tuple[str, Path]],
        errors: list[str],
    ) -> None:
        """Append a ValidationError for a cross-directory ID collision (S909)."""
        sources_str = ", ".join(f"{loc}={p.name}" for loc, p in sources)
        msg = (
            f"Cross-directory ID collision: {label} {spec_id} appears in "
            f"{len(sources)} locations ({sources_str}). "
            f"Resolve via `nspec repair-collisions` or rename one of the files."
        )
        ve = ValidationError(
            layer="Layer 0: Cross-directory ID collision",
            message=msg,
            spec_id=spec_id,
            code="cross_dir_collision",
        )
        self.structured_errors.append(ve)
        errors.append(msg)

    def validate_with_datasets(self, datasets: NspecDatasets) -> tuple[bool, list[str]]:
        """Run validation layers 3-7 against pre-loaded datasets.

        Skips Layer 1-2 (format/loading) — the caller is responsible for
        providing valid datasets (e.g. from ``MainDatasetLoader``).

        Returns:
            (success, errors) - success=True if no errors.
            Also populates self.structured_errors with ValidationError objects.
        """
        self.datasets = datasets
        self.structured_errors: list[ValidationError] = []
        return self._run_layers()

    def _run_layers(self) -> tuple[bool, list[str]]:  # noqa: C901
        """Run validation layers 3-7 on self.datasets.

        Assumes self.datasets is already populated (by validate() or
        validate_with_datasets()).
        """
        errors: list[str] = []
        if not hasattr(self, "structured_errors"):
            self.structured_errors = []

        # Layer 3: Existence validation
        logger.debug("Layer 3: Checking FR/IMPL pairing...")
        checker = ExistenceChecker(self.datasets)  # pyright: ignore[reportArgumentType]
        layer3_errors = checker.check()
        if layer3_errors:
            self.structured_errors.extend(layer3_errors)
            errors.extend([str(e) for e in layer3_errors])
        else:
            logger.debug("All FR/IMPL pairs valid")

        # Layer 4: Dependency validation
        logger.debug("Layer 4: Validating dependency graph...")
        checker = DependencyChecker(self.datasets)  # pyright: ignore[reportArgumentType]
        layer4_errors = checker.check()
        if layer4_errors:
            self.structured_errors.extend(layer4_errors)
            errors.extend([str(e) for e in layer4_errors])
        else:
            logger.debug("Dependency graph valid")

        # Layer 5: Business logic validation (includes duplicate epic priority warning)
        logger.debug("Layer 5: Checking business rules...")
        checker = BusinessLogicChecker(
            self.datasets,  # pyright: ignore[reportArgumentType]
            strict_mode=self.strict_mode,
            strict_completion_parity=self.strict_completion_parity,
        )
        layer5_errors = checker.check()
        if layer5_errors:
            # Separate errors and warnings
            warnings = [e for e in layer5_errors if e.severity == "warning"]
            real_errors = [e for e in layer5_errors if e.severity == "error"]

            if real_errors:
                self.structured_errors.extend(real_errors)
                errors.extend([str(e) for e in real_errors])
            if warnings:
                self.structured_errors.extend(warnings)
                logger.warning("%d warnings (non-blocking):", len(warnings))
                for w in warnings:
                    logger.warning("   %s", w)

        if not layer5_errors or all(e.severity == "warning" for e in layer5_errors):
            logger.debug("Business rules valid")

        # Layer 6: Ordering validation (generate ordered list first)
        logger.debug("Layer 6: Validating nspec ordering...")
        self.ordered_active_specs = self._generate_ordered_nspec()
        checker = OrderingChecker(self.datasets)  # pyright: ignore[reportArgumentType]
        layer6_errors = checker.check(self.ordered_active_specs)
        if layer6_errors:
            self.structured_errors.extend(layer6_errors)
            errors.extend([str(e) for e in layer6_errors])
        else:
            logger.debug("Nspec ordering valid")

        # Generate ordered list for completed specs (simple: by spec ID)
        self.ordered_completed_specs = sorted(self.datasets.completed_frs.keys())  # pyright: ignore[reportOptionalMemberAccess]

        # Layer 7: Completed-in-active validation
        # Fail if any active spec has "Completed" FR status AND its IMPL is
        # also Completed/Ready (should be archived).  A spec whose FR is
        # Completed but whose IMPL is still Active/Testing is a valid
        # intermediate state (FR approved, implementation in flight).
        completed_status = FR_STATUSES[FRStatusCode.COMPLETED]
        completed_in_active = []
        for spec_id, fr in self.datasets.active_frs.items():  # pyright: ignore[reportOptionalMemberAccess]
            if is_completed_status(fr.status):
                # Check IMPL status — only flag if IMPL is also done
                impl = self.datasets.active_impls.get(spec_id)  # pyright: ignore[reportOptionalMemberAccess]
                if impl is not None and not is_completed_status(impl.status):
                    # FR Completed but IMPL still in-progress — valid state
                    continue
                completed_in_active.append((spec_id, fr.title))

        if completed_in_active:
            error_lines = [
                "VALIDATION ERROR: Completed specs in active directory",
                "",
                f'The following specs have "{completed_status.full}" status '
                "but are still in docs/frs/active/:",
                "",
            ]
            for spec_id, title in completed_in_active:
                # Clean up title (remove prefix if present)
                clean_title = title.split(": ", 1)[-1] if ": " in title else title
                error_lines.append(f"  - Spec {spec_id}: {clean_title}")

            error_lines.extend(
                [
                    "",
                    "To fix, archive each completed spec:",
                ]
            )
            for spec_id, _ in completed_in_active:
                error_lines.append(f"  make nspec.complete {spec_id}")

            error_lines.extend(
                [
                    "",
                    "Or if they shouldn't be completed, update their status:",
                ]
            )
            for spec_id, _ in completed_in_active:
                error_lines.append(f"  make nspec.activate {spec_id}  # Set to Active")

            combined_msg = "\n".join(error_lines)
            errors.append(combined_msg)

            for spec_id, title in completed_in_active:
                clean = title.split(": ", 1)[-1] if ": " in title else title
                self.structured_errors.append(
                    ValidationError(
                        layer="Layer 7: Completed-in-active",
                        message=(
                            f'Spec {spec_id} ("{clean}") has Completed status but is in '
                            "active directory"
                        ),
                        spec_id=spec_id,
                    )
                )

        success = len(errors) == 0
        return success, errors

    def _calculate_effective_priority(
        self, sid: str, active_frs: dict[str, Any], memo: dict[str, int]
    ) -> int:
        """Calculate effective priority with dependency promotion.

        If a high-priority spec depends on this spec, promote this spec's
        effective priority to match.

        Args:
            sid: Spec ID to calculate priority for
            active_frs: Dictionary of active FR documents
            memo: Memoization cache for recursive calls

        Returns:
            Effective priority rank (0=P0, 1=P1, 2=P2, 3=P3)
        """
        if sid in memo:
            return memo[sid]

        from nspec.domain.statuses import PRIORITY_RANK

        fr = active_frs.get(sid)
        max_rank = max(PRIORITY_RANK.values(), default=3)
        own_priority = PRIORITY_RANK.get(fr.priority if fr else "", max_rank)

        # Find all specs that depend on this spec
        dependent_priorities = []
        for other_sid, other_fr in active_frs.items():
            if sid in other_fr.deps:
                # Recursively calculate dependent's effective priority
                dep_priority = self._calculate_effective_priority(other_sid, active_frs, memo)
                dependent_priorities.append(dep_priority)

        # Effective priority is the highest (lowest number) among:
        # - Own priority
        # - All dependent spec priorities (transitive)
        if dependent_priorities:
            effective = min(own_priority, min(dependent_priorities))
        else:
            effective = own_priority

        memo[sid] = effective
        return effective

    def _generate_ordered_nspec(self) -> list[str]:
        """Generate ordered list of active spec IDs grouped by parent epic.

        Delegates to ordering.ordered_specs() for the actual algorithm.

        Returns:
            List of spec IDs in nspec order
        """
        if not self.datasets:
            return []

        from nspec.domain.ordering import ordered_specs

        return ordered_specs(self.datasets)

    def _get_epic_scope(self, epic_id: str) -> set[str]:
        """Get the epic and all its transitive dependencies.

        Args:
            epic_id: The epic spec ID to start from

        Returns:
            Set of spec IDs including the epic and all dependencies
        """
        if not self.datasets:
            return {epic_id}

        result = {epic_id}
        to_process = [epic_id]

        while to_process:
            current = to_process.pop()
            fr = self.datasets.get_fr(current)
            if fr and fr.deps:
                for dep_id in fr.deps:
                    if dep_id not in result:
                        result.add(dep_id)
                        to_process.append(dep_id)

        return result

    def generate_nspec(self, output_path: Path) -> None:
        """Generate NSPEC.md file (Pass 2: Format pre-sorted datasets).

        Uses the ordered spec lists computed during validate() (Pass 1).

        Args:
            output_path: Where to write NSPEC.md
        """
        if not self.datasets:
            print("No datasets loaded. Run validate() first.")  # noqa: T201
            return

        if not self.ordered_active_specs:
            print("No ordered specs available. Run validate() first.")  # noqa: T201
            return

        # Use pre-computed ordered list from Pass 1
        ordered_specs = self.ordered_active_specs

        # Build markdown content with project status summary
        lines = [
            "# Praxis Core V2 - Active Nspec",
            "",
            "<!-- WARNING: GENERATED FILE - DO NOT EDIT MANUALLY -->",
            "<!-- Source: FR/IMPL docs in docs/frs/active/ and docs/impls/active/ -->",
            "<!-- To update: Edit FR/IMPL docs, then run `make nspec` -->",
            "",
            f"**Last Updated:** {self._get_date()}",
            f"**Total Active:** {len(ordered_specs)} specs",
            "",
        ]

        # Add project status summary
        summary_lines = render_project_status(
            datasets=self.datasets,
            docs_root=self.docs_root,
            show_velocity=True,
            show_recent_added=True,
            show_recent_completed=True,
            show_completion_stats=True,
            velocity_days=30,
            recent_hours=24,
            completed_hours=168,
        )
        lines.extend(summary_lines)

        lines.extend(
            [
                "---",
                "",
            ]
        )

        # Group by priority
        current_priority = None
        for spec_id in ordered_specs:
            fr = self.datasets.get_fr(spec_id)
            impl = self.datasets.get_impl(spec_id)

            if not fr:
                continue

            # Priority header
            if fr.priority != current_priority:
                current_priority = fr.priority
                priority = ALL_PRIORITIES.get(fr.priority)
                priority_emoji = priority.emoji if priority else "?"
                priority_name = PRIORITY_NAMES.get(fr.priority, "UNKNOWN")
                lines.append(f"## {priority_emoji} {fr.priority} - {priority_name}")
                lines.append("")

            # Spec entry
            status_emoji = fr.status.split()[0]  # Extract emoji
            loe = impl.effective_loe if impl else "~TBD"

            # Calculate overall progress if we have both AC and tasks
            progress_str = ""
            if impl and (fr.ac_total > 0 or impl.tasks_total > 0):
                overall = (fr.ac_completion_percent + impl.completion_percent) / 2
                progress_str = f" [{int(overall)}%]"

            lines.append(f"### Spec {spec_id}: {fr.title.split(': ', 1)[-1]}{progress_str}")
            lines.append(f"* **Status:** {status_emoji} {fr.status.split(maxsplit=1)[-1]}")
            lines.append(f"* **Priority:** {fr.priority}")
            lines.append(f"* **LOE:** {loe}")

            if fr.deps:
                deps_str = ", ".join(fr.deps)
                lines.append(f"* **Dependencies:** {deps_str}")

            # Progress breakdown if available
            if impl and (fr.ac_total > 0 or impl.tasks_total > 0):
                lines.append("* **Progress:**")
                if fr.ac_total > 0:
                    lines.append(
                        f"  - Acceptance Criteria: {fr.ac_completed}/{fr.ac_total} "
                        f"({fr.ac_completion_percent}%)"
                    )
                if impl.tasks_total > 0:
                    lines.append(
                        f"  - Implementation Tasks: {impl.tasks_completed}/{impl.tasks_total} "
                        f"({impl.completion_percent}%)"
                    )

            lines.append(f"* **FR:** [FR-{spec_id}]({fr.path.relative_to(self.docs_root)})")
            if impl:
                lines.append(
                    f"* **IMPL:** [IMPL-{spec_id}]({impl.path.relative_to(self.docs_root)})"
                )

            lines.append("")

        # Write file
        output_path.write_text("\n".join(lines))

    def generate_nspec_completed(self, output_path: Path) -> None:
        """Generate NSPEC_COMPLETED.md file (Pass 2: Format completed specs).

        Uses the ordered completed spec list computed during validate() (Pass 1).

        Args:
            output_path: Where to write NSPEC_COMPLETED.md
        """
        if not self.datasets:
            print("No datasets loaded. Run validate() first.")  # noqa: T201
            return

        if not self.ordered_completed_specs:
            # No completed specs - create empty file
            output_path.write_text(
                "# Praxis Core V2 - Completed Specs\n\n"
                "<!-- WARNING: GENERATED FILE - DO NOT EDIT MANUALLY -->\n"
                "<!-- Source: Completed FR/IMPL docs in docs/completed/ -->\n\n"
                "**No completed specs yet.**\n"
            )
            return

        lines = [
            "# Praxis Core V2 - Completed Specs",
            "",
            "<!-- WARNING: GENERATED FILE - DO NOT EDIT MANUALLY -->",
            "<!-- Source: Completed FR/IMPL docs in docs/completed/ -->",
            "",
            f"**Last Updated:** {self._get_date()}",
            f"**Total Completed:** {len(self.ordered_completed_specs)} specs",
            "",
            "---",
            "",
        ]

        # Add completed specs (simple list format)
        for spec_id in self.ordered_completed_specs:
            fr = self.datasets.get_fr(spec_id)
            impl = self.datasets.get_impl(spec_id)

            if not fr:
                continue

            lines.append(f"### Spec {spec_id}: {fr.title.split(': ', 1)[-1]}")
            lines.append(f"* **Status:** {FR_STATUSES[FRStatusCode.COMPLETED].full}")
            lines.append(f"* **Priority:** {fr.priority}")

            if impl and impl.effective_loe:
                lines.append(f"* **LOE:** {impl.effective_loe}")

            lines.append(f"* **FR:** [FR-{spec_id}]({fr.path.relative_to(self.docs_root)})")
            if impl:
                lines.append(
                    f"* **IMPL:** [IMPL-{spec_id}]({impl.path.relative_to(self.docs_root)})"
                )

            lines.append("")

        # Write file
        output_path.write_text("\n".join(lines))

    def show_progress(self, spec_id: str | None = None, show_all: bool = False) -> None:
        """Show task/AC progress for specs.

        Args:
            spec_id: Specific spec ID to show (or None for all)
            show_all: Show all specs with progress
        """
        if not self.datasets:
            print("No datasets loaded. Run validate() first.")  # noqa: T201
            return

        if spec_id:
            # Show specific spec
            self._show_spec_progress(spec_id)
        elif show_all:
            # Show all active specs
            for sid in sorted(self.datasets.active_frs.keys()):
                self._show_spec_progress(sid)
                print()  # noqa: T201
        else:
            # Show summary
            self._show_progress_summary()

    def _show_spec_progress(self, spec_id: str) -> None:
        """Show detailed progress for one spec."""
        fr = self.datasets.get_fr(spec_id)  # pyright: ignore[reportOptionalMemberAccess]
        impl = self.datasets.get_impl(spec_id)  # pyright: ignore[reportOptionalMemberAccess]

        if not fr:
            print(f"Spec {spec_id} not found")  # noqa: T201
            return

        print(f"Spec {spec_id}: {fr.title.split(': ', 1)[-1]}")  # noqa: T201

        # FR Acceptance Criteria
        if fr.ac_total > 0:
            print(  # noqa: T201
                f"|- FR-{spec_id} Acceptance Criteria: "
                f"{fr.ac_completion_percent}% ({fr.ac_completed}/{fr.ac_total})"
            )

            # Group by section
            sections = {}
            for ac in fr.acceptance_criteria:
                if ac.section not in sections:
                    sections[ac.section] = []
                sections[ac.section].append(ac)

            for section, acs in sections.items():
                completed = sum(1 for ac in acs if ac.completed)
                pct = int((completed / len(acs)) * 100) if acs else 0
                print(f"|  |- {section}: {pct}% ({completed}/{len(acs)})")  # noqa: T201
                for ac in acs:
                    print(f"|  |  {ac.emoji} {ac.description}")  # noqa: T201

        # IMPL Tasks
        if impl and impl.tasks_total > 0:
            print("|")  # noqa: T201
            print(  # noqa: T201
                f"\\- IMPL-{spec_id} Implementation Tasks: "
                f"{impl.completion_percent}% ({impl.tasks_completed}/{impl.tasks_total})"
            )

            # Group by section
            sections = {}
            for task in impl.tasks:
                if task.section not in sections:
                    sections[task.section] = []
                sections[task.section].append(task)

            for section, tasks in sections.items():
                completed = sum(1 for t in tasks if t.completed)
                pct = int((completed / len(tasks)) * 100) if tasks else 0
                print(f"   |- {section}: {pct}% ({completed}/{len(tasks)})")  # noqa: T201
                for task in tasks:
                    print(f"   |  {task.emoji} {task.description}")  # noqa: T201

        # Overall
        if impl and (fr.ac_total > 0 or impl.tasks_total > 0):
            overall = (fr.ac_completion_percent + impl.completion_percent) / 2
            print(f"\nOverall Spec Progress: {int(overall)}%")  # noqa: T201

    def _show_progress_summary(self) -> None:
        """Show summary progress across all specs."""
        stats = DatasetStats(self.datasets)  # pyright: ignore[reportArgumentType]
        progress = stats.overall_progress()

        print("Nspec Progress Summary")  # noqa: T201
        print("\nOverall Completion:")  # noqa: T201
        print(f"  Acceptance Criteria: {progress['ac_completion']}%")  # noqa: T201
        print(f"  Implementation Tasks: {progress['task_completion']}%")  # noqa: T201
        print(f"  Combined Average: {progress['overall_completion']}%")  # noqa: T201

        # Priority breakdown
        print("\nSpecs by Priority:")  # noqa: T201
        priority_breakdown = stats.priority_breakdown()
        for priority, count in priority_breakdown.items():
            print(f"  {priority}: {count} specs")  # noqa: T201

        # Near completion
        near_complete = stats.specs_near_completion(threshold=80)
        if near_complete:
            print("\nNear Completion (>=80%):")  # noqa: T201
            for sid in near_complete:
                fr = self.datasets.get_fr(sid)  # pyright: ignore[reportOptionalMemberAccess]
                impl = self.datasets.get_impl(sid)  # pyright: ignore[reportOptionalMemberAccess]
                if fr and impl:
                    overall = (fr.ac_completion_percent + impl.completion_percent) / 2
                    print(f"  Spec {sid}: {int(overall)}% - {fr.title.split(': ', 1)[-1]}")  # noqa: T201

        # Zero progress
        zero_progress = stats.specs_without_progress()
        if zero_progress:
            print(f"\nNot Started (0% progress): {len(zero_progress)} specs")  # noqa: T201

    def _get_date(self) -> str:
        """Get current date in YYYY-MM-DD format."""
        return datetime.now().strftime("%Y-%m-%d")  # noqa: DTZ005
