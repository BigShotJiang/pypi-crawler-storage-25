"""Post-merge integrity validation for main branch.

Loads datasets from main via ``MainDatasetLoader`` and runs the
existing 6-layer validator to detect broken cross-references,
ID collisions, and orphaned dependencies.
"""

from __future__ import annotations

import logging
from pathlib import Path  # noqa: TC003

from nspec.domain.ids import should_skip_spec_file
from nspec.validation.checkers import ValidationError

logger = logging.getLogger("nspec")


def validate_main_integrity(
    docs_root: Path,
    project_root: Path | None = None,
    *,
    ref: str = "main",
) -> tuple[bool, list[ValidationError], str]:
    """Validate spec integrity on the main branch.

    Loads datasets from *ref* (default ``main``) using
    ``MainDatasetLoader``, then runs validation layers 3-7
    via ``NspecValidator.validate_with_datasets()``.

    Args:
        docs_root: Root docs directory (e.g. ``Path("docs")``).
        project_root: Project root for git commands.
        ref: Git ref to validate (default: ``"main"``).

    Returns:
        ``(success, structured_errors, summary)`` where *summary*
        is a human-readable one-liner.
    """
    from nspec.domain.datasets import MainDatasetLoader
    from nspec.validation.validator import NspecValidator

    loader = MainDatasetLoader(
        docs_root=docs_root,
        project_root=project_root,
        ref=ref,
        fallback=False,
    )
    datasets = loader.load()

    # Pre-layer check: detect duplicate IDs that MainDatasetLoader
    # silently deduplicates (keeps first, logs warning).
    dup_errors = _detect_duplicate_ids(loader, docs_root, project_root)

    validator = NspecValidator(
        docs_root=docs_root,
        project_root=project_root,
    )
    success, _error_strings = validator.validate_with_datasets(datasets)
    structured = validator.structured_errors

    if dup_errors:
        structured = dup_errors + structured
        success = False

    summary = format_summary(success, structured)
    return success, structured, summary


def _detect_duplicate_ids(
    loader: object,
    docs_root: Path,
    project_root: Path | None,
) -> list[ValidationError]:
    """Detect duplicate spec IDs in the raw file list from main.

    ``MainDatasetLoader`` silently deduplicates (keeps first, logs warning).
    This function re-scans the git file list to surface duplicates as
    validation errors.
    """
    import re

    from nspec.domain.datasets import MainDatasetLoader
    from nspec.git_reader import FileNotFoundInRefError, list_spec_files
    from nspec.paths import get_paths

    assert isinstance(loader, MainDatasetLoader)  # noqa: S101
    cwd = str(loader.project_root)
    ref = loader.ref

    resolved = get_paths(docs_root, project_root=project_root)
    cfg = resolved.config
    docs_rel = loader._docs_rel()
    active_frs_rel = f"{docs_rel}/{cfg.feature_requests_dir}"
    active_impls_rel = f"{docs_rel}/{cfg.implementation_dir}"
    completed_rel = f"{docs_rel}/{cfg.completed_dir}/{cfg.completed_done_subdir}"
    superseded_rel = f"{docs_rel}/{cfg.completed_dir}/{cfg.completed_superseded_subdir}"

    errors: list[ValidationError] = []
    id_pattern = re.compile(r"(?:FR|IMPL)-([SE]\d+)-")

    # Scan all directories: active, completed/done, completed/superseded
    scan_targets: list[tuple[str, str]] = [
        ("FR", active_frs_rel),
        ("IMPL", active_impls_rel),
        ("FR", completed_rel),
        ("IMPL", completed_rel),
        ("FR", superseded_rel),
        ("IMPL", superseded_rel),
    ]

    # Use a shared seen dict per label so cross-directory duplicates
    # (e.g. same FR ID in active/ and completed/done/) are detected.
    seen_by_label: dict[str, dict[str, str]] = {"FR": {}, "IMPL": {}}

    for label, path in scan_targets:
        try:
            files = list_spec_files(ref, path, f"{label}-*.md", cwd=cwd)
        except FileNotFoundInRefError:
            continue

        seen = seen_by_label[label]
        for fpath in files:
            filename = fpath.rsplit("/", 1)[-1] if "/" in fpath else fpath
            if should_skip_spec_file(filename):
                continue
            m = id_pattern.match(filename)
            if not m:
                continue
            spec_id = m.group(1)
            # Use full path for disambiguation in cross-directory detection
            qualified = f"{path}/{filename}"
            if spec_id in seen:
                errors.append(
                    ValidationError(
                        layer="Layer 0: Duplicate ID",
                        message=(
                            f"Duplicate {label} ID {spec_id} on main: "
                            f"{seen[spec_id]} and {qualified}"
                        ),
                        spec_id=spec_id,
                        code="duplicate_id",
                    )
                )
            else:
                seen[spec_id] = qualified

    return errors


def format_error(error: ValidationError) -> str:
    """Format a single ``ValidationError`` into a stable user-facing line.

    Format: ``[layer] spec_id: message`` (spec_id omitted when absent).
    """
    parts: list[str] = []
    prefix = "ERROR" if error.severity == "error" else "WARN"
    layer_short = error.layer.split(":", 1)[0].strip() if error.layer else "Unknown"
    parts.append(f"[{prefix}] {layer_short}")
    if error.spec_id:
        parts.append(error.spec_id)
    parts.append(error.message)
    return " — ".join(parts)


def format_summary(success: bool, errors: list[ValidationError]) -> str:
    """One-line summary suitable for CLI output or MCP responses."""
    if success:
        return "Main branch integrity check passed — no errors found."
    error_count = sum(1 for e in errors if e.severity == "error")
    warn_count = sum(1 for e in errors if e.severity == "warning")
    parts = []
    if error_count:
        parts.append(f"{error_count} error{'s' if error_count != 1 else ''}")
    if warn_count:
        parts.append(f"{warn_count} warning{'s' if warn_count != 1 else ''}")
    return f"Main branch integrity check FAILED — {', '.join(parts)}."
