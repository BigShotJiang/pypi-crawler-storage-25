"""Nspec CLI Command Handlers - Extracted from cli.main() to reduce complexity.

This module contains individual command handlers for each nspec CLI command,
following the Command pattern to reduce cyclomatic complexity.
"""

import logging
import subprocess
from pathlib import Path
from typing import Protocol

from nspec.domain.datasets import DatasetLoader
from nspec.mutation import (
    add_dependency,
    check_impl_task,
    complete_spec,
    create_new_spec,
    delete_spec,
    move_dependency,
    next_status,
    remove_dependency,
    set_priority,
    update_epic_loe,
    validate_spec_criteria,
)
from nspec.validation.validator import NspecValidator

# Exceptions expected during nspec command operations
_NspecCommandErrors = (RuntimeError, ValueError, KeyError, TypeError, OSError, IOError)


class CommandContext(Protocol):
    """Protocol for command context passed to handlers."""

    # Common attributes
    docs_root: Path
    validator: NspecValidator

    # Command-specific attributes
    validate: bool
    generate: bool
    progress: str | None
    all: bool
    stats: bool
    create_new: bool
    delete: bool
    complete: bool
    force: bool
    check_criteria: bool
    check_task: bool
    validate_criteria: bool
    strict: bool
    criteria_id: str | None
    task_id: str | None
    add_dep: bool
    to: str | None
    dep: str | None
    set_priority: bool
    remove_dep: bool
    title: str | None
    priority: str
    next_status: bool
    fr_status: int | None
    impl_status: int | None
    id: str | None
    git_add: bool
    fr_template: str | None
    impl_template: str | None
    coverage_json: str | None
    registry: str | None


class CommandHandler:
    """Base class for nspec CLI command handlers."""

    def __init__(self, name: str) -> None:
        self.name = name

    def execute(self, context: CommandContext) -> int:
        """Execute the command with the given context."""
        raise NotImplementedError


class ValidateCommandHandler(CommandHandler):
    """Handler for validation command."""

    def __init__(self) -> None:
        super().__init__("validate")

    def execute(self, context: CommandContext) -> int:
        """Run validation checks."""
        success, errors = context.validator.validate()

        if success:
            return 0
        print(f"\n❌ Found {len(errors)} errors:")  # noqa: T201
        for error in errors:
            print(error)  # noqa: T201
            print()  # noqa: T201
        return 1


class GenerateCommandHandler(CommandHandler):
    """Handler for generate command."""

    def __init__(self) -> None:
        super().__init__("generate")

    def execute(self, context: CommandContext) -> int:
        """Generate NSPEC.md from validated fRIMPLs."""
        # Pass 1: Validate and compute final sorted datasets
        success, errors = context.validator.validate()

        if not success:
            print(f"\n❌ Validation failed with {len(errors)} errors. Cannot generate.")  # noqa: T201
            for error in errors:
                print(error)  # noqa: T201
                print()  # noqa: T201
            print("Fix errors first, then run --generate again.")  # noqa: T201
            return 1

        # Pass 2: Auto-update Epic LOE from dependencies
        epic_updates = 0
        for spec_id, fr in context.validator.datasets.active_frs.items():  # pyright: ignore[reportOptionalMemberAccess]
            if fr.is_epic:  # Epic
                try:
                    updated_path = update_epic_loe(spec_id, context.docs_root)
                    if updated_path:
                        epic_updates += 1
                except _NspecCommandErrors as e:
                    logging.warning("Failed to update Epic %s: %s", spec_id, e)

        # Pass 3: Format final sorted datasets to markdown files
        nspec_path = Path("NSPEC.md")
        completed_path = Path("NSPEC_COMPLETED.md")

        context.validator.generate_nspec(nspec_path)
        context.validator.generate_nspec_completed(completed_path)
        return 0


class ProgressCommandHandler(CommandHandler):
    """Handler for progress command."""

    def __init__(self) -> None:
        super().__init__("progress")

    def execute(self, context: CommandContext) -> int:
        """Show task/AC progress."""
        # Load datasets
        try:
            loader = DatasetLoader(docs_root=context.docs_root)
            context.validator.datasets = loader.load()
        except ValueError as e:
            print(f"❌ Failed to load datasets: {e}")  # noqa: T201
            return 1

        if context.progress == "__summary__":
            context.validator.show_progress(show_all=context.all)
        else:
            context.validator.show_progress(spec_id=context.progress)
        return 0


class StatsCommandHandler(CommandHandler):
    """Handler for stats command."""

    def __init__(self) -> None:
        super().__init__("stats")

    def execute(self, context: CommandContext) -> int:
        """Show nspec statistics."""
        # Load datasets
        try:
            loader = DatasetLoader(docs_root=context.docs_root)
            context.validator.datasets = loader.load()
        except ValueError as e:
            print(f"❌ Failed to load datasets: {e}")  # noqa: T201
            return 1

        context.validator.show_stats()  # pyright: ignore[reportAttributeAccessIssue]
        return 0


class CreateNewCommandHandler(CommandHandler):
    """Handler for create-new command."""

    def __init__(self) -> None:
        super().__init__("create-new")

    def execute(self, context: CommandContext) -> int:
        """Create new FR+IMPL from templates."""
        if not context.title:
            print("❌ Error: --title required for --create-new")  # noqa: T201
            print(  # noqa: T201
                "Usage: python -m src.tools.nspec --create-new --title "
                '"Feature Name" [--priority P2]'
            )
            return 1

        try:
            # Resolve epic from config default
            from nspec.cli_handlers.crud import resolve_epic, validate_epic_exists

            epic_id = resolve_epic(None, context.docs_root)

            # Config gates: require epic assignment when either gate is enabled
            if epic_id is None:
                from nspec.config import NspecConfig

                config = NspecConfig.load(context.docs_root.parent)
                require_default_epic = config.strict.require_default_epic
                enforce_epic_grouping = config.validation.enforce_epic_grouping
                if require_default_epic or enforce_epic_grouping:
                    raise ValueError(
                        "Spec creation requires epic assignment.\n"
                        "Set it in .novabuilt.dev/nspec/config.toml:\n"
                        "  [defaults]\n"
                        '  epic = "001"\n\n'
                        "Current gates:\n"
                        "  [strict]\n"
                        f"  require_default_epic = {str(require_default_epic).lower()}\n"
                        "  [validation]\n"
                        f"  enforce_epic_grouping = {str(enforce_epic_grouping).lower()}\n\n"
                        "To allow orphan creation, disable both gates."
                    )

            # Validate epic exists before creating files
            if epic_id:
                validate_epic_exists(epic_id, context.docs_root)

            fr_path, impl_path, spec_id = create_new_spec(
                title=context.title,
                priority=context.priority,
                docs_root=context.docs_root,
                fr_template=context.fr_template,
                impl_template=context.impl_template,
            )

            # Add spec to epic if resolved
            if epic_id:
                move_dependency(
                    spec_id=spec_id,
                    target_epic_id=epic_id,
                    docs_root=context.docs_root,
                )

            # Run silent validation to catch issues like ID collisions
            validator = NspecValidator(docs_root=context.docs_root)
            success, errors = validator.validate()
            if not success:
                # Cleanup created files if validation fails
                fr_path.unlink()
                impl_path.unlink()
                print("❌ Created files failed validation (cleaned up):")  # noqa: T201
                for error in errors:
                    print(f"  {error}")  # noqa: T201
                return 1

            # Git add if requested
            if context.git_add:
                subprocess.run(["git", "add", str(fr_path), str(impl_path)], check=True)  # noqa: S603, S607

            # Output just the two file paths (for Make target parsing)
            print(str(fr_path))  # noqa: T201
            print(str(impl_path))  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to create spec: {e}")  # noqa: T201
            return 1


class DeleteCommandHandler(CommandHandler):
    """Handler for delete command."""

    def __init__(self) -> None:
        super().__init__("delete")

    def execute(self, context: CommandContext) -> int:
        """Delete FR+IMPL for a spec."""
        if not context.id:
            print("❌ Error: --id required for --delete")  # noqa: T201
            print(  # noqa: T201
                "Usage: export REALLY_DELETE_NSPEC_ITEM=Y && "
                "python -m src.tools.nspec --delete --id XXX"
            )
            return 1

        try:
            fr_path, impl_path = delete_spec(
                spec_id=context.id,
                docs_root=context.docs_root,
            )
            print(f"✅ Deleted Spec {context.id}")  # noqa: T201
            print(f"   Removed: {fr_path.name}")  # noqa: T201
            print(f"   Removed: {impl_path.name}")  # noqa: T201
            return 0
        except (RuntimeError, FileNotFoundError) as e:
            print(f"❌ Failed to delete spec: {e}")  # noqa: T201
            return 1


class CompleteCommandHandler(CommandHandler):
    """Handler for complete command."""

    def __init__(self) -> None:
        super().__init__("complete")

    def execute(self, context: CommandContext) -> int:
        """Move FR+IMPL to completed directory."""
        if not context.id:
            print("❌ Error: --id required for --complete")  # noqa: T201
            print("Usage: python -m src.tools.nspec --complete --id XXX")  # noqa: T201
            return 1

        try:
            fr_moved, impl_moved = complete_spec(
                spec_id=context.id,
                docs_root=context.docs_root,
                skip_validation=context.force,
            )
            print(f"✅ Completed Spec {context.id}")  # noqa: T201
            print(f"   Moved: {fr_moved}")  # noqa: T201
            print(f"   Moved: {impl_moved}")  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to complete spec: {e}")  # noqa: T201
            return 1


class AddDependencyCommandHandler(CommandHandler):
    """Handler for add-dep command."""

    def __init__(self) -> None:
        super().__init__("add-dep")

    def execute(self, context: CommandContext) -> int:
        """Add dependency to a spec."""
        if not context.to or not context.dep:
            print("❌ Error: --to and --dep required for --add-dep")  # noqa: T201
            print("Usage: python -m src.tools.nspec --add-dep --to XXX --dep YYY")  # noqa: T201
            return 1

        try:
            result = add_dependency(
                spec_id=context.to,
                dependency_id=context.dep,
                docs_root=context.docs_root,
            )
            print(f"✅ Added dependency: Spec {context.to} now depends on {context.dep}")  # noqa: T201
            print(f"   Updated: {result['path']}")  # noqa: T201
            if result.get("moved_from"):
                print(f"   ↪ Moved from Epic {result['moved_from']}")  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to add dependency: {e}")  # noqa: T201
            return 1


class RemoveDependencyCommandHandler(CommandHandler):
    """Handler for remove-dep command."""

    def __init__(self) -> None:
        super().__init__("remove-dep")

    def execute(self, context: CommandContext) -> int:
        """Remove dependency from a spec."""
        if not context.to or not context.dep:
            print("❌ Error: --to and --dep required for --remove-dep")  # noqa: T201
            print("Usage: python -m src.tools.nspec --remove-dep --to XXX --dep YYY")  # noqa: T201
            return 1

        try:
            remove_dependency(
                from_spec_id=context.to,
                to_spec_id=context.dep,
                docs_root=context.docs_root,
            )
            print(f"✅ Removed dependency: Spec {context.to} no longer depends on {context.dep}")  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to remove dependency: {e}")  # noqa: T201
            return 1


class SetPriorityCommandHandler(CommandHandler):
    """Handler for set-priority command."""

    def __init__(self) -> None:
        super().__init__("set-priority")

    def execute(self, context: CommandContext) -> int:
        """Change priority for a spec."""
        if not context.id or not context.priority:
            print("❌ Error: --id and --priority required for --set-priority")  # noqa: T201
            print("Usage: python -m src.tools.nspec --set-priority --id XXX --priority P1")  # noqa: T201
            return 1

        try:
            set_priority(
                spec_id=context.id,
                new_priority=context.priority,
                docs_root=context.docs_root,
            )
            print(f"✅ Updated Spec {context.id} priority to {context.priority}")  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to set priority: {e}")  # noqa: T201
            return 1


class NextStatusCommandHandler(CommandHandler):
    """Handler for next-status command."""

    def __init__(self) -> None:
        super().__init__("next-status")

    def execute(self, context: CommandContext) -> int:
        """Auto-advance IMPL to next logical state."""
        if not context.id:
            print("❌ Error: --id required for --next-status")  # noqa: T201
            print("Usage: python -m src.tools.nspec --next-status --id XXX")  # noqa: T201
            return 1

        try:
            new_statuses = next_status(context.id, context.docs_root)
            print(f"✅ Advanced Spec {context.id} to next status")  # noqa: T201
            print(f"   FR: {new_statuses['fr']['from']} → {new_statuses['fr']['to']}")  # noqa: T201  # pyright: ignore[reportArgumentType]
            print(f"   IMPL: {new_statuses['impl']['from']} → {new_statuses['impl']['to']}")  # noqa: T201  # pyright: ignore[reportArgumentType]
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to advance status: {e}")  # noqa: T201
            return 1


class CheckCriteriaCommandHandler(CommandHandler):
    """Handler for check-criteria command."""

    def __init__(self) -> None:
        super().__init__("check-criteria")

    def execute(self, context: CommandContext) -> int:
        """Mark acceptance criterion as complete."""
        if not context.id or not context.criteria_id:
            print("❌ Error: --id and --criteria-id required for --check-criteria")  # noqa: T201
            print("Usage: python -m src.tools.nspec --check-criteria --id XXX --criteria-id AC-F1")  # noqa: T201
            return 1

        try:
            from nspec.mutation import check_acceptance_criteria

            check_acceptance_criteria(
                spec_id=context.id,
                criteria_id=context.criteria_id,
                docs_root=context.docs_root,
            )
            print(f"✅ Marked criterion {context.criteria_id} as complete for Spec {context.id}")  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to check criterion: {e}")  # noqa: T201
            return 1


class CheckTaskCommandHandler(CommandHandler):
    """Handler for check-task command."""

    def __init__(self) -> None:
        super().__init__("check-task")

    def execute(self, context: CommandContext) -> int:
        """Mark IMPL task as complete."""
        if not context.id or not context.task_id:
            print("❌ Error: --id and --task-id required for --check-task")  # noqa: T201
            print('Usage: python -m src.tools.nspec --check-task --id XXX --task-id "1.1"')  # noqa: T201
            return 1

        try:
            check_impl_task(
                spec_id=context.id,
                task_id=context.task_id,
                docs_root=context.docs_root,
            )
            print(f'✅ Marked task "{context.task_id}" as complete for Spec {context.id}')  # noqa: T201
            return 0
        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to check task: {e}")  # noqa: T201
            return 1


class ValidateCriteriaCommandHandler(CommandHandler):
    """Handler for validate-criteria command."""

    def __init__(self) -> None:
        super().__init__("validate-criteria")

    def execute(self, context: CommandContext) -> int:
        """Validate acceptance criteria for a spec."""
        if not context.id:
            print("❌ Error: --id required for validate criteria")  # noqa: T201
            print("Usage: nspec validate criteria --id XXX [--strict]")  # noqa: T201
            return 1

        try:
            result = validate_spec_criteria(
                spec_id=context.id,
                strict=context.strict,
                docs_root=context.docs_root,
            )

            if result["valid"]:  # pyright: ignore[reportArgumentType]
                print(f"✅ Spec {context.id} criteria validation passed")  # noqa: T201
                if result["stats"]:  # pyright: ignore[reportArgumentType]
                    print(f"   {result['stats']}")  # noqa: T201  # pyright: ignore[reportArgumentType]
            else:
                print(f"❌ Spec {context.id} criteria validation failed:")  # noqa: T201
                for error in result.get("errors", []):  # pyright: ignore[reportAttributeAccessIssue]
                    print(f"   - {error}")  # noqa: T201

            return 0 if result["valid"] else 1  # pyright: ignore[reportArgumentType]

        except (ValueError, FileNotFoundError) as e:
            print(f"❌ Failed to validate criteria: {e}")  # noqa: T201
            return 1


class CommandRegistry:
    """Registry for nspec CLI command handlers."""

    def __init__(self) -> None:
        self.handlers: dict[str, CommandHandler] = {}
        self._register_default_handlers()

    def _register_default_handlers(self) -> None:
        """Register all built-in command handlers."""
        self.register("validate", ValidateCommandHandler())
        self.register("generate", GenerateCommandHandler())
        self.register("progress", ProgressCommandHandler())
        self.register("stats", StatsCommandHandler())
        self.register("create_new", CreateNewCommandHandler())
        self.register("delete", DeleteCommandHandler())
        self.register("complete", CompleteCommandHandler())
        self.register("add_dep", AddDependencyCommandHandler())
        self.register("remove_dep", RemoveDependencyCommandHandler())
        self.register("set_priority", SetPriorityCommandHandler())
        self.register("next_status", NextStatusCommandHandler())
        self.register("check_criteria", CheckCriteriaCommandHandler())
        self.register("check_task", CheckTaskCommandHandler())
        self.register("validate_criteria", ValidateCriteriaCommandHandler())

    def register(self, name: str, handler: CommandHandler) -> None:
        """Register a command handler."""
        self.handlers[name] = handler

    def get(self, name: str) -> CommandHandler | None:
        """Get a command handler by name."""
        return self.handlers.get(name)
