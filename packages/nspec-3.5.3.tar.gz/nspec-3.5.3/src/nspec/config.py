"""Configuration DAO for .novabuilt.dev/nspec/config.toml.

Single data access object that owns all reads and writes to the nspec
configuration file. Replaces scattered TOML parsing in paths.py, cli.py,
and init.py with a unified, typed interface.

Config file location: .novabuilt.dev/nspec/config.toml

Schema:
    [paths]
    feature_requests = "frs/active"
    implementation = "impls/active"
    completed = "completed"
    completed_done = "done"
    completed_superseded = "superseded"
    completed_rejected = "rejected"

    [defaults]
    epic = "001"

    [session]
    sessions_dir = "sessions"

    [skills]
    sources = ["builtin"]

    [codex]
    model = "o4-mini"
    sandbox = "workspace-write"
    approval_policy = "on-request"
    flags = ["--full-auto"]

    [validation]
    enforce_epic_grouping = true

    [id_ranges]
    spec_min = 1
    spec_max = 899
    epic_min = 1
    epic_max = 99
    adr_min = 901
    adr_max = 999

    [emojis]
    # fr_proposed = "🟡"
    # impl_paused = "⏳"
    # priority_p0 = "🔥"

    [github]
    repo = "myorg/myproject-issues"
    default_priority = "P2"
    default_epic = "E006"
    auto_close = true

    [github.label_priority_map]
    bug = "P1"
    enhancement = "P2"

    [refinement]
    agent = "codex"
    timeout = 300
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

# Canonical config file location relative to project root
CONFIG_REL_PATH = ".novabuilt.dev/nspec/config.toml"

# Directories where upward config traversal should stop (exact match).
# Prevents traversal from escaping into system paths.
_TRAVERSAL_STOP_DIRS: frozenset[str] = frozenset(
    {
        "/tmp",  # nosec B108 — not a temp file, traversal boundary constant  # noqa: S108
        "/private/tmp",  # nosec B108
    }
)

# Valid values for [queue] mode
QUEUE_MODES = ("single", "multi")


@dataclass
class PathsConfig:
    """Typed representation of [paths] section."""

    feature_requests: str = "frs/active"
    implementation: str = "impls/active"
    completed: str = "completed"
    completed_done: str = "done"
    completed_superseded: str = "superseded"
    completed_rejected: str = "rejected"
    spec_root: str = "../../docs"


@dataclass
class SessionConfig:
    """Typed representation of [session] section."""

    sessions_dir: str = "sessions"
    checkout_ttl_seconds: int = 3600
    checkout_max: int = 5


@dataclass
class SkillsConfig:
    """Typed representation of [skills] section."""

    sources: list[str] = field(default_factory=lambda: ["builtin"])
    targets: dict[str, str] = field(default_factory=lambda: {"claude": ".claude/commands"})


def _default_priority_emojis() -> dict[str, str]:
    """Return default priority emojis from domain/statuses.py (single source of truth).

    Uses a lazy import to avoid circular dependency between config.py and statuses.py.
    """
    from nspec.domain.statuses import _DEFAULT_PRIORITY_EMOJIS

    return _DEFAULT_PRIORITY_EMOJIS


@dataclass
class PrioritiesConfig:
    """Typed representation of [priorities] section.

    Controls which priority levels are available via ``max_level`` (default 50).
    Generates P0 through P{max_level} automatically. Emojis are customizable
    per level; unknown levels get ``default_emoji``.
    """

    max_level: int = 50
    emojis: dict[str, str] = field(default_factory=lambda: dict(_default_priority_emojis()))
    default_emoji: str = "⚪"

    @property
    def levels(self) -> list[str]:
        """Auto-generate P0 through P{max_level}."""
        return [f"P{i}" for i in range(self.max_level + 1)]


@dataclass
class EmojisConfig:
    """Typed representation of [emojis] section.

    All fields are optional. When set, they override the default emoji
    for the corresponding status/priority/display element.
    """

    # FR statuses
    fr_proposed: str | None = None
    fr_in_design: str | None = None
    fr_active: str | None = None
    fr_completed: str | None = None
    fr_rejected: str | None = None
    fr_superseded: str | None = None
    fr_deferred: str | None = None

    # IMPL statuses
    impl_planning: str | None = None
    impl_active: str | None = None
    impl_testing: str | None = None
    impl_ready: str | None = None
    impl_paused: str | None = None
    impl_hold: str | None = None

    # Priorities (legacy — prefer [priorities.emojis] for new configs)
    priority_p0: str | None = None
    priority_p1: str | None = None
    priority_p2: str | None = None
    priority_p3: str | None = None

    # Dependency display
    dep_completed: str | None = None
    dep_active: str | None = None
    dep_proposed: str | None = None
    dep_rejected: str | None = None
    dep_superseded: str | None = None
    dep_testing: str | None = None
    dep_paused: str | None = None
    dep_unknown: str | None = None

    # Epic display
    epic_proposed: str | None = None
    epic_active: str | None = None
    epic_completed: str | None = None


@dataclass
class UserIdRange:
    """Per-user spec ID range override."""

    spec_min: int
    spec_max: int
    epic_min: int | None = None
    epic_max: int | None = None


@dataclass
class IdRangesConfig:
    """Typed representation of [id_ranges] section.

    Controls the numeric range for auto-assigned spec and epic IDs.
    All priorities share the same range by default (sequential IDs).

    Per-user overrides are stored in ``users`` dict, keyed by user/agent ID.
    """

    spec_min: int = 1
    spec_max: int = 899
    epic_min: int = 1
    epic_max: int = 99
    adr_min: int = 901
    adr_max: int = 999
    # S908: behavior when allocator's monotonic max+1 exceeds spec_max.
    # "extend" — auto-bump spec_max by extend_step, log warning, persist
    #   the new ceiling to .novabuilt.dev/nspec/state/id_ceiling.json
    # "fail"   — raise (legacy behavior). Use when strict ID-range control
    #   matters more than allocation never blocking.
    on_exhaustion: Literal["extend", "fail"] = "extend"
    extend_step: int = 100
    # Warning threshold (fraction of range used). 0.9 = warn at 90% capacity.
    capacity_warn_threshold: float = 0.9
    users: dict[str, UserIdRange] = field(default_factory=dict)

    def resolve_range(
        self,
        user_id: str | None = None,
    ) -> tuple[int, int, int, int]:
        """Return (spec_min, spec_max, epic_min, epic_max) for user.

        Falls back to global range when user_id is None or not configured.
        """
        if user_id and user_id in self.users:
            u = self.users[user_id]
            return (
                u.spec_min,
                u.spec_max,
                u.epic_min if u.epic_min is not None else self.epic_min,
                u.epic_max if u.epic_max is not None else self.epic_max,
            )
        return self.spec_min, self.spec_max, self.epic_min, self.epic_max

    def validate_user_ranges(self) -> list[str]:
        """Check for overlapping or out-of-bounds user ranges.

        Validates both spec and epic ranges when present.
        Returns list of error messages (empty = valid).
        """
        errors: list[str] = []
        user_items = list(self.users.items())
        for uid, r in user_items:
            # Spec range validation
            if r.spec_min > r.spec_max:
                errors.append(f"User '{uid}': spec_min ({r.spec_min}) > spec_max ({r.spec_max})")
            if r.spec_min < self.spec_min or r.spec_max > self.spec_max:
                errors.append(
                    f"User '{uid}': spec range [{r.spec_min}, {r.spec_max}] "
                    f"outside global [{self.spec_min}, {self.spec_max}]"
                )
            # Epic range validation — require both or neither
            if (r.epic_min is None) != (r.epic_max is None):
                errors.append(f"User '{uid}': must set both epic_min and epic_max, or neither")
            if r.epic_min is not None and r.epic_max is not None:
                if r.epic_min > r.epic_max:
                    errors.append(
                        f"User '{uid}': epic_min ({r.epic_min}) > epic_max ({r.epic_max})"
                    )
                if r.epic_min < self.epic_min or r.epic_max > self.epic_max:
                    errors.append(
                        f"User '{uid}': epic range [{r.epic_min}, {r.epic_max}] "
                        f"outside global [{self.epic_min}, {self.epic_max}]"
                    )

        # Check pairwise spec overlap
        for i, (uid_a, r_a) in enumerate(user_items):
            for uid_b, r_b in user_items[i + 1 :]:
                if r_a.spec_min <= r_b.spec_max and r_b.spec_min <= r_a.spec_max:
                    errors.append(
                        f"Users '{uid_a}' [{r_a.spec_min}, {r_a.spec_max}] "
                        f"and '{uid_b}' [{r_b.spec_min}, {r_b.spec_max}] spec overlap"
                    )
                # Epic overlap (only when both have epic ranges)
                if (
                    r_a.epic_min is not None
                    and r_a.epic_max is not None
                    and r_b.epic_min is not None
                    and r_b.epic_max is not None
                    and r_a.epic_min <= r_b.epic_max
                    and r_b.epic_min <= r_a.epic_max
                ):
                    errors.append(
                        f"Users '{uid_a}' [{r_a.epic_min}, {r_a.epic_max}] "
                        f"and '{uid_b}' [{r_b.epic_min}, {r_b.epic_max}] epic overlap"
                    )
        return errors


@dataclass
class TuiConfig:
    """Typed representation of [tui] section.

    Controls TUI display constants. All defaults match the previously
    hardcoded values so behavior is unchanged for users who don't customize.
    """

    # Column widths (table.py)
    col_id: int = 5
    col_priority: int = 3
    col_status: int = 3
    col_upstream: int = 6
    col_downstream: int = 6
    col_estimate: int = 5
    min_title_width: int = 25

    # Truncation limits
    detail_title_max: int = 35  # widgets.py SpecDetailPanel
    error_message_max: int = 120  # error_screen.py

    # Scroll context
    context_lines_divisor: int = 3  # detail_screen.py viewport_height // N

    # Display modes (display_modes.py)
    default_view: str = "standard"  # minimal, standard, full
    default_sort: str = "dependency"  # dependency, priority, status, id, alpha


@dataclass
class WatchdogConfig:
    """Typed representation of [watchdog] section.

    Controls the Claude Code stall detector & auto-recovery.
    """

    stall_timeout: int = 180  # seconds before declaring token stall
    mcp_stall_timeout: int = 120  # seconds before declaring MCP tool hang
    poll_interval: int = 15  # seconds between polls
    recovery_message: str = "Please continue from where you left off."


@dataclass(frozen=True)
class PipelineStep:
    """A single step in the loop pipeline.

    Each step has a type (e.g., "pick", "execute", "review") and
    optional parameters (e.g., agent name for review/auto_refine).
    """

    step: str
    params: tuple[str, ...] = ()


# Default 10-step pipeline matching the hardcoded /loop phases
DEFAULT_PIPELINE: tuple[PipelineStep, ...] = (
    PipelineStep("pick"),
    PipelineStep("start"),
    PipelineStep("author_fr", ("codex",)),
    PipelineStep("auto_refine", ("codex",)),
    PipelineStep("execute"),
    PipelineStep("verify"),
    PipelineStep("review", ("codex",)),
    PipelineStep("complete"),
    PipelineStep("refine"),
    PipelineStep("report"),
)

# Default agent map: logical name -> implementation
DEFAULT_AGENTS: dict[str, str] = {
    "claude": "self",
    "codex": "subprocess:codex",
    "gemini": "subprocess:gemini",
}


@dataclass
class AgentsConfig:
    """Typed representation of [agents] section.

    Maps logical agent names to their backing implementation.
    "self" means the current session; "subprocess:codex" spawns the codex
    CLI binary; "mcp:<server>" means an external MCP server.
    """

    agents: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_AGENTS))


@dataclass
class LoopConfig:
    """Typed representation of [loop] section.

    Controls the external loop orchestrator (nspec-loop).
    """

    session_timeout: str = "30m"  # timeout(1) format: 30m, 1h, etc.
    max_retries: int = 3  # Spec-level retries before Exception
    pipeline: tuple[PipelineStep, ...] = DEFAULT_PIPELINE
    batch_branch: bool = True  # Bundle specs onto one branch; push/PR at loop exit


@dataclass
class TimeoutsConfig:
    """Typed representation of [timeouts] section.

    All values are in seconds. Defaults match the previously hardcoded values
    so behavior is unchanged for users who don't customize.
    """

    lock_acquire_s: float = 10.0
    lock_stale_s: int = 3600
    git_s: int = 30
    subprocess_s: int = 10
    mcp_s: int = 120


@dataclass
class CodexConfig:
    """Typed representation of [codex] section.

    Controls the codex CLI executor defaults.
    These are passed to the ``CodexTmuxExecutor``.
    """

    model: str = "gpt-5.3-codex"
    reasoning_effort: str = "medium"
    sandbox: str = "workspace-write"
    approval_policy: str = "on-request"
    flags: list[str] = field(default_factory=lambda: ["--full-auto"])
    timeout: int = 300
    poll_interval: float = 2.0
    session_prefix: str = "nspec-codex"


@dataclass
class GeminiConfig:
    """Typed representation of [gemini] section.

    Controls the gemini CLI executor defaults.
    These are passed to the ``GeminiTmuxExecutor``.
    """

    model: str = "gemini-3-pro-preview"
    approval_mode: str = "plan"
    sandbox: bool = False
    flags: list[str] = field(default_factory=list)
    timeout: int = 300
    poll_interval: float = 2.0
    session_prefix: str = "nspec-gemini"


@dataclass
class ClaudeCodeConfig:
    """Typed representation of [claude_code] section.

    Controls the Claude Code CLI executor defaults for swarm agents.
    These are passed to the ``ClaudeCodeTmuxExecutor``.
    """

    model: str = "sonnet"
    permission_mode: str = "bypassPermissions"
    timeout: int = 1800
    poll_interval: float = 5.0
    worktree_base: str = ".worktrees"
    session_prefix: str = "nspec-claude"


@dataclass
class LoeEstimatorConfig:
    """Typed representation of [loe] section.

    Controls the LOE estimation algorithm weights and thresholds.
    """

    weight_task_count: float = 1.0
    weight_max_depth: float = 2.0
    weight_nested_ratio: float = 1.5
    weight_dep_count: float = 1.5
    weight_complexity_signal: float = 3.0
    min_history_specs: int = 10


@dataclass
class ReviewCodexConfig:
    """Per-agent settings for Codex review backend."""

    model: str = "gpt-5.3-codex"
    effort: str = "medium"


@dataclass
class ReviewClaudeConfig:
    """Per-agent settings for Claude review backend."""

    model: str = "opus"
    effort: str = "high"


@dataclass
class ReviewGeminiConfig:
    """Per-agent settings for Gemini review backend."""

    model: str = "gemini-3-pro-preview"


@dataclass
class ReviewConfig:
    """Typed representation of [review] section.

    The ``agent`` field selects which backend performs reviews:
    ``"codex"``, ``"claude"``, or ``"gemini"``.  Each agent type has
    its own nested config with model and effort options.

    ``diff_exclude`` controls which paths are excluded from the review diff.
    ``diff_include`` controls which paths are included (empty = all paths).
    """

    agent: str = "codex"
    timeout: int = 300
    token_ttl_hours: int = 24
    max_retries: int = 5
    require_test_pass: bool = False
    require_hmac: bool = False
    diff_exclude: list[str] = field(
        default_factory=lambda: [
            ".novabuilt.dev/",
            ".claude/",
            "poetry.lock",
            "work/",
        ]
    )
    diff_include: list[str] = field(default_factory=list)
    codex: ReviewCodexConfig = field(default_factory=ReviewCodexConfig)
    claude: ReviewClaudeConfig = field(default_factory=ReviewClaudeConfig)
    gemini: ReviewGeminiConfig = field(default_factory=ReviewGeminiConfig)


@dataclass
class RefinementCodexConfig:
    """Per-agent settings for Codex refinement backend."""

    model: str = "gpt-5.3-codex"
    effort: str = "medium"


@dataclass
class RefinementClaudeConfig:
    """Per-agent settings for Claude refinement backend."""

    model: str = "opus"
    effort: str = "high"


@dataclass
class RefinementGeminiConfig:
    """Per-agent settings for Gemini refinement backend."""

    model: str = "gemini-3-pro-preview"


@dataclass
class RefinementConfig:
    """Typed representation of [refinement] section.

    The ``agent`` field selects which backend performs refinements:
    ``"codex"``, ``"claude"``, or ``"gemini"``.  Each agent type has
    its own nested config with model and effort options.
    """

    agent: str = "codex"
    timeout: int = 300
    codex: RefinementCodexConfig = field(default_factory=RefinementCodexConfig)
    claude: RefinementClaudeConfig = field(default_factory=RefinementClaudeConfig)
    gemini: RefinementGeminiConfig = field(default_factory=RefinementGeminiConfig)


@dataclass
class HandoffConfig:
    """Typed representation of [handoff] section.

    Controls audit-trail generation via cheap models. Summarization tasks
    (handoffs, decisions, inventories) are routed to a low-cost agent.
    """

    agent: str = "claude"
    model: str = "haiku-4-5"
    effort: str = "low"
    timeout: int = 60


@dataclass
class StrictConfig:
    """Typed representation of [strict] section.

    Controls project hygiene enforcement. Separate from [validation]
    which controls `--validate` warnings.
    """

    require_default_epic: bool = True
    validation_on_mutate: bool = True


@dataclass
class ValidationConfig:
    """Typed representation of [validation] section."""

    enforce_epic_grouping: bool = False
    strict_completion_parity: bool = True


@dataclass
class BackendConfig:
    """Typed representation of [backend] section.

    Controls which persistence backend is active.
    """

    engine: str = "markdown"  # "markdown" | "terminusdb"

    def __post_init__(self) -> None:
        valid = ("markdown", "terminusdb")
        if self.engine not in valid:
            raise ValueError(f"[backend] engine must be one of {valid}, got: {self.engine!r}")


@dataclass
class QueueConfig:
    """Typed representation of [queue] section.

    Controls the agent assignment queue for multi-agent parallel execution.
    """

    mode: str = "single"  # "single" or "multi"
    max_agents: int = 5
    lease_ttl_seconds: int = 300  # 5 minutes

    def __post_init__(self) -> None:
        if self.mode not in QUEUE_MODES:
            raise ValueError(f"[queue] mode must be one of {QUEUE_MODES}, got: {self.mode!r}")

    @property
    def effective_max_agents(self) -> int:
        """Return max_agents capped to 1 in single mode."""
        return 1 if self.mode == "single" else self.max_agents


@dataclass
class DocsConfig:
    """Typed representation of [docs] section.

    Controls opt-in post-completion doc generation via a low-reasoning agent.
    """

    enabled: bool = False
    template: str = "changelog.md"
    target: str = "CHANGELOG.md"
    agent: str = "haiku"
    mode: str = "append"  # "append" | "replace-section"


@dataclass
class TemplatesConfig:
    """Typed representation of [templates] section.

    Controls which ceremony-level profile is used when creating new specs.
    Profiles: quick (Crystal Clear), standard (Crystal Yellow),
    full (Crystal Orange), formal (Crystal Red).
    """

    default: str = "standard"
    fr: str | None = None
    impl: str | None = None


@dataclass
class ErrorAgentTriggersConfig:
    """Typed representation of [error_agent.triggers] section."""

    exit_codes: list[int] = field(default_factory=lambda: [1, 2])
    mcp_errors: bool = True
    test_failures: bool = True
    subprocess_timeout: bool = True


@dataclass
class ErrorAgentConfig:
    """Typed representation of [error_agent] section.

    Controls automatic error-to-spec conversion during agent sessions.
    """

    enabled: bool = False
    auto_create_spec: bool = True
    auto_park_on_blocking: bool = True
    epic_id: str | None = None
    priority: str | None = None  # resolved to lowest configured level at runtime
    max_per_session: int = 5
    triggers: ErrorAgentTriggersConfig = field(default_factory=ErrorAgentTriggersConfig)
    ignore_patterns: list[str] = field(default_factory=list)


@dataclass
class ProvidersConfig:
    """Typed representation of [providers] section.

    User overrides for provider registries. Merged on top of the
    built-in registry in ``providers.py``. Keys are provider names,
    values are dicts mapping field names to lists of valid values.
    """

    overrides: dict[str, dict[str, list[str]]] = field(default_factory=dict)


@dataclass
class ResourcesConfig:
    """Typed representation of [resources] section.

    Maps logical handle names to file paths (relative to .novabuilt.dev/nspec/).
    """

    handles: dict[str, str] = field(default_factory=dict)


@dataclass
class GitHubConfig:
    """Typed representation of [github] section.

    Controls the GitHub issue import integration. Uses the ``gh`` CLI
    for fetching issues — no API token management needed (``gh auth``
    handles that).

    ``label_priority_map`` maps GitHub label names (case-insensitive)
    to nspec priority levels.
    """

    repo: str = ""
    default_priority: str = "P2"
    default_epic: str = "E006"
    auto_close: bool = True
    label_priority_map: dict[str, str] = field(
        default_factory=lambda: {
            "priority:p0": "P0",
            "critical": "P0",
            "priority:p1": "P1",
            "urgent": "P1",
            "priority:p3": "P3",
            "low": "P3",
        }
    )


@dataclass
class LinearConfig:
    """Typed representation of [linear] section.

    Controls the repo-to-Linear sync integration. The API token is read
    from the environment variable specified by ``token_env`` (default:
    ``LINEAR_API_KEY``).

    State mapping translates nspec FR/IMPL statuses to Linear workflow
    state UUIDs. Priority mapping translates nspec priorities (P0-P3) to
    Linear priority integers (1=Urgent .. 4=Low).
    """

    token_env: str = "LINEAR_API_KEY"  # noqa: S105
    team_id: str = ""
    state_mapping: dict[str, str] = field(default_factory=dict)
    priority_mapping: dict[str, int] = field(
        default_factory=lambda: {
            "P0": 1,  # Urgent
            "P1": 2,  # High
            "P2": 3,  # Medium
            "P3": 4,  # Low
        }
    )
    label_ids: list[str] = field(default_factory=list)


@dataclass
class ProjectConfig:
    """Typed representation of [project] section.

    When ``code_root`` is set, code operations (git diff, agent execution,
    test gates) run in that directory instead of the spec root. This enables
    a "control repo" pattern where specs live in one repo and the target
    project code lives in another.
    """

    code_root: str | None = None


@dataclass
class GitConfig:
    """Typed representation of [git] section."""

    auto_add: bool = False


@dataclass
class GuardConfig:
    """Typed representation of [guard] section (S910).

    Mirrors the bash hook config in `.claude/hooks/guard-*.sh`. The hooks
    parse config.toml directly via awk for portability; this Python view
    exists so `nspec hooks doctor`, tests, and downstream tooling can
    inspect the same values without re-implementing the parser.
    """

    enforce_mcp_writes: bool = True
    credential_firewall_enabled: bool = True
    destructive_ops_enabled: bool = True
    credential_patterns: list[str] = field(default_factory=list)
    destructive_patterns: list[str] = field(default_factory=list)


@dataclass
class NspecMetaConfig:
    """Typed representation of [nspec] section.

    Tracks nspec tool version for version-gated sync.
    Written by ensure_synced() after successful sync.
    """

    version: str = ""
    skills_auto_update: bool | None = None  # None = unset (prompt user)


@dataclass
class DefaultsConfig:
    """Typed representation of [defaults] section."""

    epic: str | None = None


@dataclass
class NspecConfig:
    """Single data access object for .novabuilt.dev/nspec/config.toml.

    Usage:
        # Load existing config
        config = NspecConfig.load(project_root)
        print(config.paths.feature_requests)
        print(config.defaults.epic)

        # Modify and persist
        config.defaults.epic = "002"
        config.save()

        # Scaffold new project
        config = NspecConfig.scaffold(project_root)
    """

    paths: PathsConfig = field(default_factory=PathsConfig)
    defaults: DefaultsConfig = field(default_factory=DefaultsConfig)
    project: ProjectConfig = field(default_factory=ProjectConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    skills: SkillsConfig = field(default_factory=SkillsConfig)
    priorities: PrioritiesConfig = field(default_factory=PrioritiesConfig)
    emojis: EmojisConfig = field(default_factory=EmojisConfig)
    strict: StrictConfig = field(default_factory=StrictConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    codex: CodexConfig = field(default_factory=CodexConfig)
    gemini: GeminiConfig = field(default_factory=GeminiConfig)
    claude_code: ClaudeCodeConfig = field(default_factory=ClaudeCodeConfig)
    review: ReviewConfig = field(default_factory=ReviewConfig)
    refinement: RefinementConfig = field(default_factory=RefinementConfig)
    handoff: HandoffConfig = field(default_factory=HandoffConfig)
    loe: LoeEstimatorConfig = field(default_factory=LoeEstimatorConfig)
    id_ranges: IdRangesConfig = field(default_factory=IdRangesConfig)
    tui: TuiConfig = field(default_factory=TuiConfig)
    timeouts: TimeoutsConfig = field(default_factory=TimeoutsConfig)
    loop: LoopConfig = field(default_factory=LoopConfig)
    agents: AgentsConfig = field(default_factory=AgentsConfig)
    watchdog: WatchdogConfig = field(default_factory=WatchdogConfig)
    docs: DocsConfig = field(default_factory=DocsConfig)
    backend: BackendConfig = field(default_factory=BackendConfig)
    queue: QueueConfig = field(default_factory=QueueConfig)
    templates: TemplatesConfig = field(default_factory=TemplatesConfig)
    git: GitConfig = field(default_factory=GitConfig)
    guard: GuardConfig = field(default_factory=GuardConfig)
    linear: LinearConfig = field(default_factory=LinearConfig)
    github: GitHubConfig = field(default_factory=GitHubConfig)
    error_agent: ErrorAgentConfig = field(default_factory=ErrorAgentConfig)
    providers: ProvidersConfig = field(default_factory=ProvidersConfig)
    resources: ResourcesConfig = field(default_factory=ResourcesConfig)
    nspec_meta: NspecMetaConfig = field(default_factory=NspecMetaConfig)
    spec_types: dict[str, dict[str, Any]] = field(default_factory=dict)
    config_file: Path | None = field(default=None, repr=False)

    @classmethod
    def load(cls, project_root: Path | None = None) -> NspecConfig:  # noqa: C901
        """Load config from .novabuilt.dev/nspec/config.toml.

        Searches upward from project_root (or cwd) for the config file.
        Returns default config if no file is found.

        Args:
            project_root: Directory to start searching from.
                         If None, uses current working directory.

        Returns:
            NspecConfig with values from file, or defaults if not found.
        """
        if project_root is None:
            project_root = Path.cwd()

        config_file = _find_config_file(project_root)
        raw = _parse_toml(config_file) if config_file else {}

        nspec_meta_raw = raw.get("nspec", {})
        paths_raw = raw.get("paths", {})
        defaults_raw = raw.get("defaults", {})
        project_raw = raw.get("project", {})
        session_raw = raw.get("session", {})
        skills_raw = raw.get("skills", {})
        priorities_raw = raw.get("priorities", {})
        emojis_raw = raw.get("emojis", {})
        strict_raw = raw.get("strict", {})
        validation_raw = raw.get("validation", {})
        codex_raw = raw.get("codex", {})
        gemini_raw = raw.get("gemini", {})
        claude_code_raw = raw.get("claude_code", {})
        review_raw = raw.get("review", {})
        refinement_raw = raw.get("refinement", {})
        loe_raw = raw.get("loe", {})
        id_ranges_raw = raw.get("id_ranges", {})
        tui_raw = raw.get("tui", {})
        spec_types_raw = raw.get("spec_types", {})
        timeouts_raw = raw.get("timeouts", {})
        loop_raw = raw.get("loop", {})
        watchdog_raw = raw.get("watchdog", {})
        backend_raw = raw.get("backend", {})
        docs_raw = raw.get("docs", {})
        queue_raw = raw.get("queue", {})
        templates_raw = raw.get("templates", {})
        git_raw = raw.get("git", {})
        guard_raw = raw.get("guard", {})
        linear_raw = raw.get("linear", {})
        github_raw = raw.get("github", {})
        error_agent_raw = raw.get("error_agent", {})
        resources_raw = raw.get("resources", {})
        providers_raw = raw.get("providers", {})
        handoff_raw = raw.get("handoff", {})

        paths = PathsConfig(
            feature_requests=paths_raw.get("feature_requests", PathsConfig.feature_requests),
            implementation=paths_raw.get("implementation", PathsConfig.implementation),
            completed=paths_raw.get("completed", PathsConfig.completed),
            completed_done=paths_raw.get("completed_done", PathsConfig.completed_done),
            completed_superseded=paths_raw.get(
                "completed_superseded", PathsConfig.completed_superseded
            ),
            completed_rejected=paths_raw.get("completed_rejected", PathsConfig.completed_rejected),
            spec_root=paths_raw.get("spec_root", PathsConfig.spec_root),
        )

        _sau_raw = nspec_meta_raw.get("skills_auto_update")
        nspec_meta = NspecMetaConfig(
            version=str(nspec_meta_raw.get("version", "")),
            skills_auto_update=bool(_sau_raw) if _sau_raw is not None else None,
        )

        defaults = DefaultsConfig(
            epic=str(defaults_raw["epic"]) if "epic" in defaults_raw else None,
        )

        project_code_root = project_raw.get("code_root")
        project = ProjectConfig(
            code_root=str(project_code_root) if project_code_root is not None else None,
        )

        session = SessionConfig(
            sessions_dir=session_raw.get("sessions_dir", SessionConfig.sessions_dir),
        )

        skills_sources = skills_raw.get("sources")
        skills_targets = skills_raw.get("targets")
        skills = SkillsConfig(
            sources=skills_sources if isinstance(skills_sources, list) else ["builtin"],
            targets=skills_targets
            if isinstance(skills_targets, dict)
            else {"claude": ".claude/commands"},
        )

        # Build PrioritiesConfig from [priorities] section
        _default_prio = PrioritiesConfig()
        prio_emojis_raw = priorities_raw.get("emojis", {})
        prio_default_emoji = str(priorities_raw.get("default_emoji", _default_prio.default_emoji))

        # Determine max_level: explicit max_level takes precedence,
        # legacy levels list is accepted (length - 1 becomes max_level)
        prio_max_level_raw = priorities_raw.get("max_level")
        prio_levels_raw = priorities_raw.get("levels")
        if prio_max_level_raw is not None:
            prio_max_level = int(prio_max_level_raw)
        elif isinstance(prio_levels_raw, list) and prio_levels_raw:
            prio_max_level = len(prio_levels_raw) - 1
        else:
            prio_max_level = _default_prio.max_level

        prio_emojis = dict(_default_prio.emojis)
        prio_emojis.update({str(k): str(v) for k, v in prio_emojis_raw.items()})
        priorities = PrioritiesConfig(
            max_level=prio_max_level,
            emojis=prio_emojis,
            default_emoji=prio_default_emoji,
        )

        # Build EmojisConfig — only set fields that are present in TOML
        emojis_kwargs = {}
        for field_name in EmojisConfig.__dataclass_fields__:
            if field_name in emojis_raw:
                emojis_kwargs[field_name] = str(emojis_raw[field_name])
        emojis = EmojisConfig(**emojis_kwargs)

        raw_require = strict_raw.get("require_default_epic", StrictConfig.require_default_epic)
        if not isinstance(raw_require, bool):
            kind = type(raw_require).__name__
            raise ValueError(
                f"[strict] require_default_epic must be a boolean, got {kind}: {raw_require!r}"
            )
        raw_validation_on_mutate = strict_raw.get(
            "validation_on_mutate", StrictConfig.validation_on_mutate
        )
        if not isinstance(raw_validation_on_mutate, bool):
            kind = type(raw_validation_on_mutate).__name__
            raise ValueError(
                f"[strict] validation_on_mutate must be a boolean, "
                f"got {kind}: {raw_validation_on_mutate!r}"
            )
        strict = StrictConfig(
            require_default_epic=raw_require,
            validation_on_mutate=raw_validation_on_mutate,
        )

        validation = ValidationConfig(
            enforce_epic_grouping=bool(
                validation_raw.get("enforce_epic_grouping", ValidationConfig.enforce_epic_grouping)
            ),
            strict_completion_parity=bool(
                validation_raw.get(
                    "strict_completion_parity", ValidationConfig.strict_completion_parity
                )
            ),
        )

        raw_codex_flags = codex_raw.get("flags", ["--full-auto"])
        if not isinstance(raw_codex_flags, list):
            kind = type(raw_codex_flags).__name__
            raise ValueError(f"[codex] flags must be a list, got {kind}: {raw_codex_flags!r}")
        if not all(isinstance(flag, str) for flag in raw_codex_flags):
            raise ValueError("[codex] flags must be a list of strings")

        codex = CodexConfig(
            model=str(codex_raw.get("model", CodexConfig.model)),
            reasoning_effort=str(codex_raw.get("reasoning_effort", CodexConfig.reasoning_effort)),
            sandbox=str(codex_raw.get("sandbox", CodexConfig.sandbox)),
            approval_policy=str(codex_raw.get("approval_policy", CodexConfig.approval_policy)),
            flags=list(raw_codex_flags),
            timeout=int(codex_raw.get("timeout", CodexConfig.timeout)),
            poll_interval=float(codex_raw.get("poll_interval", CodexConfig.poll_interval)),
            session_prefix=str(codex_raw.get("session_prefix", CodexConfig.session_prefix)),
        )

        raw_gemini_flags = gemini_raw.get("flags", [])
        if not isinstance(raw_gemini_flags, list):
            kind = type(raw_gemini_flags).__name__
            raise ValueError(f"[gemini] flags must be a list, got {kind}: {raw_gemini_flags!r}")
        if not all(isinstance(flag, str) for flag in raw_gemini_flags):
            raise ValueError("[gemini] flags must be a list of strings")

        gemini = GeminiConfig(
            model=str(gemini_raw.get("model", GeminiConfig.model)),
            approval_mode=str(gemini_raw.get("approval_mode", GeminiConfig.approval_mode)),
            sandbox=bool(gemini_raw.get("sandbox", GeminiConfig.sandbox)),
            flags=list(raw_gemini_flags),
            timeout=int(gemini_raw.get("timeout", GeminiConfig.timeout)),
            poll_interval=float(gemini_raw.get("poll_interval", GeminiConfig.poll_interval)),
            session_prefix=str(gemini_raw.get("session_prefix", GeminiConfig.session_prefix)),
        )

        claude_code = ClaudeCodeConfig(
            model=str(claude_code_raw.get("model", ClaudeCodeConfig.model)),
            permission_mode=str(
                claude_code_raw.get("permission_mode", ClaudeCodeConfig.permission_mode)
            ),
            timeout=int(claude_code_raw.get("timeout", ClaudeCodeConfig.timeout)),
            poll_interval=float(
                claude_code_raw.get("poll_interval", ClaudeCodeConfig.poll_interval)
            ),
            worktree_base=str(claude_code_raw.get("worktree_base", ClaudeCodeConfig.worktree_base)),
            session_prefix=str(
                claude_code_raw.get("session_prefix", ClaudeCodeConfig.session_prefix)
            ),
        )

        # Parse [review] with nested [review.codex], [review.claude], [review.gemini]
        review_codex_raw = review_raw.get("codex", {})
        review_claude_raw = review_raw.get("claude", {})
        review_gemini_raw = review_raw.get("gemini", {})

        review_codex = ReviewCodexConfig(
            model=str(review_codex_raw.get("model", ReviewCodexConfig.model)),
            effort=str(review_codex_raw.get("effort", ReviewCodexConfig.effort)),
        )
        review_claude = ReviewClaudeConfig(
            model=str(review_claude_raw.get("model", ReviewClaudeConfig.model)),
            effort=str(review_claude_raw.get("effort", ReviewClaudeConfig.effort)),
        )
        review_gemini = ReviewGeminiConfig(
            model=str(review_gemini_raw.get("model", ReviewGeminiConfig.model)),
        )

        review = ReviewConfig(
            agent=str(review_raw.get("agent", ReviewConfig.agent)),
            timeout=int(review_raw.get("timeout", ReviewConfig.timeout)),
            token_ttl_hours=int(review_raw.get("token_ttl_hours", ReviewConfig.token_ttl_hours)),
            max_retries=int(review_raw.get("max_retries", ReviewConfig.max_retries)),
            require_test_pass=bool(
                review_raw.get("require_test_pass", ReviewConfig.require_test_pass)
            ),
            require_hmac=bool(review_raw.get("require_hmac", ReviewConfig.require_hmac)),
            codex=review_codex,
            claude=review_claude,
            gemini=review_gemini,
        )

        # Parse [refinement] with nested sub-tables (mirrors [review] pattern)
        refinement_codex_raw = refinement_raw.get("codex", {})
        refinement_claude_raw = refinement_raw.get("claude", {})
        refinement_gemini_raw = refinement_raw.get("gemini", {})

        refinement_codex = RefinementCodexConfig(
            model=str(refinement_codex_raw.get("model", RefinementCodexConfig.model)),
            effort=str(refinement_codex_raw.get("effort", RefinementCodexConfig.effort)),
        )
        refinement_claude = RefinementClaudeConfig(
            model=str(refinement_claude_raw.get("model", RefinementClaudeConfig.model)),
            effort=str(refinement_claude_raw.get("effort", RefinementClaudeConfig.effort)),
        )
        refinement_gemini = RefinementGeminiConfig(
            model=str(refinement_gemini_raw.get("model", RefinementGeminiConfig.model)),
        )

        refinement = RefinementConfig(
            agent=str(refinement_raw.get("agent", RefinementConfig.agent)),
            timeout=int(refinement_raw.get("timeout", RefinementConfig.timeout)),
            codex=refinement_codex,
            claude=refinement_claude,
            gemini=refinement_gemini,
        )

        loe_config = LoeEstimatorConfig(
            weight_task_count=float(
                loe_raw.get("weight_task_count", LoeEstimatorConfig.weight_task_count)
            ),
            weight_max_depth=float(
                loe_raw.get("weight_max_depth", LoeEstimatorConfig.weight_max_depth)
            ),
            weight_nested_ratio=float(
                loe_raw.get("weight_nested_ratio", LoeEstimatorConfig.weight_nested_ratio)
            ),
            weight_dep_count=float(
                loe_raw.get("weight_dep_count", LoeEstimatorConfig.weight_dep_count)
            ),
            weight_complexity_signal=float(
                loe_raw.get("weight_complexity_signal", LoeEstimatorConfig.weight_complexity_signal)
            ),
            min_history_specs=int(
                loe_raw.get("min_history_specs", LoeEstimatorConfig.min_history_specs)
            ),
        )

        # Parse per-user ranges from [id_ranges.users.<name>] tables
        users_raw = id_ranges_raw.get("users", {})
        user_ranges: dict[str, UserIdRange] = {}
        for uid, udata in users_raw.items():
            if isinstance(udata, dict):
                if "spec_min" not in udata or "spec_max" not in udata:
                    raise ValueError(f"User '{uid}': must set both spec_min and spec_max")
                user_ranges[uid] = UserIdRange(
                    spec_min=int(udata["spec_min"]),
                    spec_max=int(udata["spec_max"]),
                    epic_min=int(udata["epic_min"]) if "epic_min" in udata else None,
                    epic_max=int(udata["epic_max"]) if "epic_max" in udata else None,
                )

        id_ranges = IdRangesConfig(
            spec_min=int(id_ranges_raw.get("spec_min", IdRangesConfig.spec_min)),
            spec_max=int(id_ranges_raw.get("spec_max", IdRangesConfig.spec_max)),
            epic_min=int(id_ranges_raw.get("epic_min", IdRangesConfig.epic_min)),
            epic_max=int(id_ranges_raw.get("epic_max", IdRangesConfig.epic_max)),
            adr_min=int(id_ranges_raw.get("adr_min", IdRangesConfig.adr_min)),
            adr_max=int(id_ranges_raw.get("adr_max", IdRangesConfig.adr_max)),
            on_exhaustion=str(id_ranges_raw.get("on_exhaustion", IdRangesConfig.on_exhaustion)),  # pyright: ignore[reportArgumentType]
            extend_step=int(id_ranges_raw.get("extend_step", IdRangesConfig.extend_step)),
            capacity_warn_threshold=float(
                id_ranges_raw.get("capacity_warn_threshold", IdRangesConfig.capacity_warn_threshold)
            ),
            users=user_ranges,
        )

        # Validate user ranges at load time
        user_errors = id_ranges.validate_user_ranges()
        if user_errors:
            raise ValueError("Invalid per-user ID ranges in config:\n  " + "\n  ".join(user_errors))

        tui = TuiConfig(
            col_id=max(1, int(tui_raw.get("col_id", TuiConfig.col_id))),
            col_priority=max(1, int(tui_raw.get("col_priority", TuiConfig.col_priority))),
            col_status=max(1, int(tui_raw.get("col_status", TuiConfig.col_status))),
            col_upstream=max(1, int(tui_raw.get("col_upstream", TuiConfig.col_upstream))),
            col_downstream=max(1, int(tui_raw.get("col_downstream", TuiConfig.col_downstream))),
            col_estimate=max(1, int(tui_raw.get("col_estimate", TuiConfig.col_estimate))),
            min_title_width=max(1, int(tui_raw.get("min_title_width", TuiConfig.min_title_width))),
            detail_title_max=max(
                4, int(tui_raw.get("detail_title_max", TuiConfig.detail_title_max))
            ),
            error_message_max=max(
                1, int(tui_raw.get("error_message_max", TuiConfig.error_message_max))
            ),
            context_lines_divisor=max(
                1, int(tui_raw.get("context_lines_divisor", TuiConfig.context_lines_divisor))
            ),
            default_view=str(tui_raw.get("default_view", TuiConfig.default_view)),
            default_sort=str(tui_raw.get("default_sort", TuiConfig.default_sort)),
        )

        timeouts = TimeoutsConfig(
            lock_acquire_s=float(timeouts_raw.get("lock_acquire_s", TimeoutsConfig.lock_acquire_s)),
            lock_stale_s=int(timeouts_raw.get("lock_stale_s", TimeoutsConfig.lock_stale_s)),
            git_s=int(timeouts_raw.get("git_s", TimeoutsConfig.git_s)),
            subprocess_s=int(timeouts_raw.get("subprocess_s", TimeoutsConfig.subprocess_s)),
            mcp_s=int(timeouts_raw.get("mcp_s", TimeoutsConfig.mcp_s)),
        )

        # Parse pipeline from [loop] section
        pipeline_raw = loop_raw.get("pipeline")
        if pipeline_raw is not None:
            pipeline_steps: list[PipelineStep] = []
            for i, entry in enumerate(pipeline_raw):
                if not isinstance(entry, list | tuple) or len(entry) == 0:
                    raise ValueError(
                        f"[loop] pipeline[{i}]: each entry must be a non-empty list, "
                        f"got {type(entry).__name__}: {entry!r}"
                    )
                pipeline_steps.append(
                    PipelineStep(step=str(entry[0]), params=tuple(str(p) for p in entry[1:]))
                )
            pipeline = tuple(pipeline_steps)
        else:
            pipeline = DEFAULT_PIPELINE

        loop = LoopConfig(
            session_timeout=str(loop_raw.get("session_timeout", LoopConfig.session_timeout)),
            max_retries=int(loop_raw.get("max_retries", LoopConfig.max_retries)),
            pipeline=pipeline,
            batch_branch=bool(loop_raw.get("batch_branch", LoopConfig.batch_branch)),
        )

        # Parse [agents] section
        agents_raw = raw.get("agents", {})
        agents = AgentsConfig(
            agents={str(k): str(v) for k, v in agents_raw.items()}
            if agents_raw
            else dict(DEFAULT_AGENTS),
        )

        watchdog = WatchdogConfig(
            stall_timeout=int(watchdog_raw.get("stall_timeout", WatchdogConfig.stall_timeout)),
            mcp_stall_timeout=int(
                watchdog_raw.get("mcp_stall_timeout", WatchdogConfig.mcp_stall_timeout)
            ),
            poll_interval=int(watchdog_raw.get("poll_interval", WatchdogConfig.poll_interval)),
            recovery_message=str(
                watchdog_raw.get("recovery_message", WatchdogConfig.recovery_message)
            ),
        )

        docs = DocsConfig(
            enabled=bool(docs_raw.get("enabled", DocsConfig.enabled)),
            template=str(docs_raw.get("template", DocsConfig.template)),
            target=str(docs_raw.get("target", DocsConfig.target)),
            agent=str(docs_raw.get("agent", DocsConfig.agent)),
            mode=str(docs_raw.get("mode", DocsConfig.mode)),
        )

        backend = BackendConfig(
            engine=str(backend_raw.get("engine", BackendConfig.engine)),
        )

        queue = QueueConfig(
            mode=str(queue_raw.get("mode", QueueConfig.mode)),
            max_agents=int(queue_raw.get("max_agents", QueueConfig.max_agents)),
            lease_ttl_seconds=int(
                queue_raw.get("lease_ttl_seconds", QueueConfig.lease_ttl_seconds)
            ),
        )

        templates_fr = templates_raw.get("fr")
        templates_impl = templates_raw.get("impl")
        templates = TemplatesConfig(
            default=str(templates_raw.get("default", TemplatesConfig.default)),
            fr=str(templates_fr) if templates_fr is not None else None,
            impl=str(templates_impl) if templates_impl is not None else None,
        )

        git = GitConfig(
            auto_add=bool(git_raw.get("auto_add", GitConfig.auto_add)),
        )

        # Parse [guard] section (S910). Pattern arrays must be lists of strings;
        # anything else is silently coerced to [] so a malformed config can't
        # crash a hook-adjacent tool like `nspec hooks doctor`.
        cred_pats_raw = guard_raw.get("credential_patterns", [])
        dest_pats_raw = guard_raw.get("destructive_patterns", [])
        guard = GuardConfig(
            enforce_mcp_writes=bool(
                guard_raw.get("enforce_mcp_writes", GuardConfig.enforce_mcp_writes)
            ),
            credential_firewall_enabled=bool(
                guard_raw.get(
                    "credential_firewall_enabled",
                    GuardConfig.credential_firewall_enabled,
                )
            ),
            destructive_ops_enabled=bool(
                guard_raw.get(
                    "destructive_ops_enabled",
                    GuardConfig.destructive_ops_enabled,
                )
            ),
            credential_patterns=[str(p) for p in cred_pats_raw]
            if isinstance(cred_pats_raw, list)
            else [],
            destructive_patterns=[str(p) for p in dest_pats_raw]
            if isinstance(dest_pats_raw, list)
            else [],
        )

        # Parse [linear] section
        linear_state_raw = linear_raw.get("state_mapping", {})
        linear_priority_raw = linear_raw.get("priority_mapping", {})
        linear_label_ids = linear_raw.get("label_ids", [])
        if not isinstance(linear_label_ids, list):
            linear_label_ids = []
        linear = LinearConfig(
            token_env=str(linear_raw.get("token_env", LinearConfig.token_env)),
            team_id=str(linear_raw.get("team_id", LinearConfig.team_id)),
            state_mapping={str(k): str(v) for k, v in linear_state_raw.items()},
            priority_mapping={str(k): int(v) for k, v in linear_priority_raw.items()}
            if linear_priority_raw
            else {"P0": 1, "P1": 2, "P2": 3, "P3": 4},
            label_ids=[str(lid) for lid in linear_label_ids],
        )

        # Parse [github] section
        gh_label_map_raw = github_raw.get("label_priority_map", {})
        gh_auto_close_raw = github_raw.get("auto_close", GitHubConfig.auto_close)
        if not isinstance(gh_auto_close_raw, bool):
            gh_auto_close_raw = str(gh_auto_close_raw).lower() in ("true", "1", "yes")
        github = GitHubConfig(
            repo=str(github_raw.get("repo", GitHubConfig.repo)),
            default_priority=str(github_raw.get("default_priority", GitHubConfig.default_priority)),
            default_epic=str(github_raw.get("default_epic", GitHubConfig.default_epic)),
            auto_close=gh_auto_close_raw,
            label_priority_map={str(k): str(v) for k, v in gh_label_map_raw.items()}
            if gh_label_map_raw
            else GitHubConfig().label_priority_map,
        )

        # Parse [error_agent] section
        ea_triggers_raw = error_agent_raw.get("triggers", {})
        ea_ignore_raw = error_agent_raw.get("ignore", {})
        ea_triggers = ErrorAgentTriggersConfig(
            exit_codes=ea_triggers_raw.get("exit_codes", [1, 2]),
            mcp_errors=bool(ea_triggers_raw.get("mcp_errors", ErrorAgentTriggersConfig.mcp_errors)),
            test_failures=bool(
                ea_triggers_raw.get("test_failures", ErrorAgentTriggersConfig.test_failures)
            ),
            subprocess_timeout=bool(
                ea_triggers_raw.get(
                    "subprocess_timeout", ErrorAgentTriggersConfig.subprocess_timeout
                )
            ),
        )
        ea_epic = error_agent_raw.get("epic_id")
        error_agent = ErrorAgentConfig(
            enabled=bool(error_agent_raw.get("enabled", ErrorAgentConfig.enabled)),
            auto_create_spec=bool(
                error_agent_raw.get("auto_create_spec", ErrorAgentConfig.auto_create_spec)
            ),
            auto_park_on_blocking=bool(
                error_agent_raw.get("auto_park_on_blocking", ErrorAgentConfig.auto_park_on_blocking)
            ),
            epic_id=str(ea_epic) if ea_epic is not None else None,
            priority=str(error_agent_raw["priority"]) if "priority" in error_agent_raw else None,
            max_per_session=int(
                error_agent_raw.get("max_per_session", ErrorAgentConfig.max_per_session)
            ),
            triggers=ea_triggers,
            ignore_patterns=ea_ignore_raw.get("patterns", []),
        )

        # Parse [providers] overrides — nested dict of provider -> field -> values
        providers_overrides: dict[str, dict[str, list[str]]] = {}
        for prov_name, prov_fields in providers_raw.items():
            if isinstance(prov_fields, dict):
                parsed_fields: dict[str, list[str]] = {}
                for fld, vals in prov_fields.items():
                    if isinstance(vals, list):
                        parsed_fields[fld] = [str(v) for v in vals]
                providers_overrides[str(prov_name)] = parsed_fields
        providers = ProvidersConfig(overrides=providers_overrides)

        instance = cls(
            paths=paths,
            defaults=defaults,
            project=project,
            session=session,
            skills=skills,
            priorities=priorities,
            emojis=emojis,
            strict=strict,
            validation=validation,
            codex=codex,
            gemini=gemini,
            claude_code=claude_code,
            review=review,
            refinement=refinement,
            handoff=HandoffConfig(
                agent=str(handoff_raw.get("agent", HandoffConfig.agent)),
                model=str(handoff_raw.get("model", HandoffConfig.model)),
                effort=str(handoff_raw.get("effort", HandoffConfig.effort)),
                timeout=int(handoff_raw.get("timeout", HandoffConfig.timeout)),
            ),
            loe=loe_config,
            id_ranges=id_ranges,
            tui=tui,
            timeouts=timeouts,
            loop=loop,
            agents=agents,
            watchdog=watchdog,
            backend=backend,
            docs=docs,
            queue=queue,
            templates=templates,
            git=git,
            guard=guard,
            linear=linear,
            github=github,
            error_agent=error_agent,
            providers=providers,
            nspec_meta=nspec_meta,
            resources=ResourcesConfig(handles=dict(resources_raw)),
            spec_types=dict(spec_types_raw),
            config_file=config_file,
        )

        # Validate provider values (warn only, never fail)
        try:
            from nspec.providers import validate_config as _validate_providers

            for warning in _validate_providers(instance):
                logging.getLogger("nspec.config").warning("Provider validation: %s", warning)
        except Exception:  # noqa: BLE001
            logging.getLogger("nspec.config").warning("Provider validation skipped", exc_info=True)

        return instance

    def resolve_code_root(self) -> Path | None:
        """Resolve ``[project].code_root`` to an absolute Path.

        Handles ``~`` expansion and resolves relative paths against the
        spec root (the directory containing ``.novabuilt.dev/``).

        Returns:
            Resolved absolute Path, or None if ``code_root`` is not configured.
        """
        if self.project.code_root is None:
            return None
        p = Path(self.project.code_root).expanduser()
        if p.is_absolute():
            return p.resolve()
        # Relative paths are resolved against the spec root (config file's grandparent×2)  # noqa: E501, RUF003
        if self.config_file is not None:
            spec_root = self.config_file.parent.parent.parent  # .novabuilt.dev/nspec/ -> root
            return (spec_root / p).resolve()
        return p.resolve()

    def resolve_spec_root(self) -> Path:
        """Resolve ``[paths].spec_root`` to an absolute Path.

        Handles ``~`` expansion. Absolute paths are used as-is.
        Relative paths are resolved against the config file's parent
        directory (``.novabuilt.dev/nspec/``).

        When ``spec_root`` is ``"../../docs"`` (the default), this returns
        ``project_root/docs/``, matching the directory layout created by
        ``nspec init``.

        When ``spec_root`` is ``"."``, specs live alongside the config
        file in ``.novabuilt.dev/nspec/`` — this is the layout used by
        projects that keep specs inside the nspec directory.

        Returns:
            Resolved absolute Path for the spec root directory.
        """
        p = Path(self.paths.spec_root).expanduser()
        if p.is_absolute():
            return p.resolve()
        if self.config_file is not None:
            return (self.config_file.parent / p).resolve()
        return p.resolve()

    def resolve_project_root(self) -> Path:
        """Resolve the project root (directory containing ``.novabuilt.dev/``).

        Returns:
            The project root derived from config_file, or ``Path.cwd()``
            if no config file is known.
        """
        if self.config_file is not None:
            # .novabuilt.dev/nspec/config.toml -> project root (3 levels up)
            return self.config_file.parent.parent.parent.resolve()
        return Path.cwd()

    def get(self, section: str, key: str, default: Any = None) -> Any:
        """Read an arbitrary value by section and key.

        Convenience method for callers that need ad-hoc access without
        knowing the typed fields. Prefer direct attribute access when possible.

        Returns the default if the section/key doesn't exist or if the
        value is None.

        Args:
            section: TOML section name (e.g., "defaults", "paths")
            key: Key within the section
            default: Fallback if not found or None

        Returns:
            The value, or default if not found or None.
        """
        section_obj = getattr(self, section, None)
        if section_obj is None:
            return default
        value = getattr(section_obj, key, None)
        if value is None:
            return default
        return value

    def save(self) -> None:
        """Persist current config state to disk.

        Writes to self.config_file. Raises ValueError if no config_file is set.
        """
        if self.config_file is None:
            raise ValueError("Cannot save: no config_file path set")

        content = self._to_toml()
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        self.config_file.write_text(content)

    @classmethod
    def scaffold(cls, project_root: Path, *, force: bool = False) -> NspecConfig:
        """Create default config.toml for a new project.

        Args:
            project_root: Project root directory.
            force: If True, overwrite existing file.

        Returns:
            NspecConfig with default values, saved to disk.

        Raises:
            FileExistsError: If config file exists and force is False.
        """
        config_file = project_root / CONFIG_REL_PATH
        if config_file.exists() and not force:
            raise FileExistsError(f"File already exists: {config_file} (use --force to overwrite)")

        config = cls(
            paths=PathsConfig(),
            defaults=DefaultsConfig(),
            config_file=config_file,
        )
        config.save()
        return config

    def _to_toml(self) -> str:  # noqa: C901
        """Serialize config to TOML string."""
        lines = [
            "# nspec configuration",
            f"# Location: {CONFIG_REL_PATH}",
            "# See: https://github.com/Novabuiltdevv/nspec",
            "",
            "[nspec]",
            f'version = "{self.nspec_meta.version}"',
        ]
        if self.nspec_meta.skills_auto_update is not None:
            lines.append(f"skills_auto_update = {str(self.nspec_meta.skills_auto_update).lower()}")

        lines.extend(["", "[paths]"])

        # Always write path values (even defaults) so users see the active config
        for field_name in (
            "spec_root",
            "feature_requests",
            "implementation",
            "completed",
            "completed_done",
            "completed_superseded",
            "completed_rejected",
        ):
            value = getattr(self.paths, field_name)
            lines.append(f'{field_name} = "{value}"')

        lines.extend(["", "[defaults]"])

        # Only write epic when actually set — None means "unset" for strict mode
        if self.defaults.epic is not None:
            lines.append(f'epic = "{self.defaults.epic}"')

        # Project (integration mode — code_root points to external project)
        if self.project.code_root is not None:
            lines.extend(["", "[project]"])
            lines.append(f'code_root = "{self.project.code_root}"')

        lines.extend(["", "[session]"])
        lines.append(f'sessions_dir = "{self.session.sessions_dir}"')

        lines.extend(["", "[skills]"])
        sources_str = ", ".join(f'"{s}"' for s in self.skills.sources)
        lines.append(f"sources = [{sources_str}]")

        lines.extend(["", "[skills.targets]"])
        for agent_name, agent_path in sorted(self.skills.targets.items()):
            lines.append(f'{agent_name} = "{agent_path}"')

        lines.extend(["", "[strict]"])
        lines.append(f"require_default_epic = {str(self.strict.require_default_epic).lower()}")
        lines.append(f"validation_on_mutate = {str(self.strict.validation_on_mutate).lower()}")

        lines.extend(["", "[validation]"])
        lines.append(
            f"enforce_epic_grouping = {str(self.validation.enforce_epic_grouping).lower()}"
        )
        lines.append(
            f"strict_completion_parity = {str(self.validation.strict_completion_parity).lower()}"
        )

        lines.extend(["", "[git]"])
        lines.append(f"auto_add = {str(self.git.auto_add).lower()}")

        # Priorities
        lines.extend(["", "[priorities]"])
        lines.append(f"max_level = {self.priorities.max_level}")
        lines.append(f'default_emoji = "{self.priorities.default_emoji}"')
        lines.extend(["", "[priorities.emojis]"])
        # Only write non-default emojis (P0-P3 defaults + any custom)
        for pcode, emoji in sorted(self.priorities.emojis.items()):
            lines.append(f'{pcode} = "{emoji}"')

        lines.extend(["", "[emojis]"])
        lines.append("# Override any status/priority/display emoji below.")
        lines.append("# Missing keys use built-in defaults.")

        # Import defaults for commented-out reference
        from nspec.domain.statuses import (
            _DEFAULT_DEP_EMOJIS,
            _DEFAULT_EPIC_EMOJIS,
            _DEFAULT_FR_EMOJIS,
            _DEFAULT_FR_TEXTS,
            _DEFAULT_IMPL_EMOJIS,
            _DEFAULT_IMPL_TEXTS,
            _DEFAULT_PRIORITY_EMOJIS,
        )

        # FR statuses
        fr_key_map = {
            0: "fr_proposed",
            1: "fr_in_design",
            2: "fr_active",
            3: "fr_completed",
            4: "fr_rejected",
            5: "fr_superseded",
            6: "fr_deferred",
        }
        for code, key in fr_key_map.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_FR_EMOJIS[code]
            label = _DEFAULT_FR_TEXTS[code]
            if value is not None:
                lines.append(f'{key} = "{value}"  # {label}')
            else:
                lines.append(f'# {key} = "{default}"  # {label}')

        # IMPL statuses
        impl_key_map = {
            0: "impl_planning",
            1: "impl_active",
            2: "impl_testing",
            3: "impl_ready",
            4: "impl_paused",
            5: "impl_hold",
        }
        for code, key in impl_key_map.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_IMPL_EMOJIS[code]
            label = _DEFAULT_IMPL_TEXTS[code]
            if value is not None:
                lines.append(f'{key} = "{value}"  # {label}')
            else:
                lines.append(f'# {key} = "{default}"  # {label}')

        # Legacy priority emojis (from [emojis] section)
        for pcode in self.priorities.levels:
            key = f"priority_{pcode.lower()}"
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_PRIORITY_EMOJIS.get(pcode, self.priorities.default_emoji)
            if value is not None:
                lines.append(f'{key} = "{value}"  # {pcode}')
            else:
                lines.append(f'# {key} = "{default}"  # {pcode}')

        # Dependency display
        dep_key_map = {
            "COMPLETED": "dep_completed",
            "ACTIVE": "dep_active",
            "PROPOSED": "dep_proposed",
            "REJECTED": "dep_rejected",
            "SUPERSEDED": "dep_superseded",
            "TESTING": "dep_testing",
            "PAUSED": "dep_paused",
            "UNKNOWN": "dep_unknown",
        }
        for attr, key in dep_key_map.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_DEP_EMOJIS[attr]
            if value is not None:
                lines.append(f'{key} = "{value}"  # dep {attr.lower()}')
            else:
                lines.append(f'# {key} = "{default}"  # dep {attr.lower()}')

        # Epic display
        epic_key_map = {
            "PROPOSED": "epic_proposed",
            "ACTIVE": "epic_active",
            "COMPLETED": "epic_completed",
        }
        for attr, key in epic_key_map.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_EPIC_EMOJIS[attr]
            if value is not None:
                lines.append(f'{key} = "{value}"  # epic {attr.lower()}')
            else:
                lines.append(f'# {key} = "{default}"  # epic {attr.lower()}')

        # TUI display constants
        lines.extend(["", "[tui]"])
        lines.append(f"col_id = {self.tui.col_id}")
        lines.append(f"col_priority = {self.tui.col_priority}")
        lines.append(f"col_status = {self.tui.col_status}")
        lines.append(f"col_upstream = {self.tui.col_upstream}")
        lines.append(f"col_downstream = {self.tui.col_downstream}")
        lines.append(f"col_estimate = {self.tui.col_estimate}")
        lines.append(f"min_title_width = {self.tui.min_title_width}")
        lines.append(f"detail_title_max = {self.tui.detail_title_max}")
        lines.append(f"error_message_max = {self.tui.error_message_max}")
        lines.append(f"context_lines_divisor = {self.tui.context_lines_divisor}")
        lines.append(f'default_view = "{self.tui.default_view}"')
        lines.append(f'default_sort = "{self.tui.default_sort}"')

        # Timeouts
        lines.extend(["", "[timeouts]"])
        lines.append(f"lock_acquire_s = {self.timeouts.lock_acquire_s}")
        lines.append(f"lock_stale_s = {self.timeouts.lock_stale_s}")
        lines.append(f"git_s = {self.timeouts.git_s}")
        lines.append(f"subprocess_s = {self.timeouts.subprocess_s}")
        lines.append(f"mcp_s = {self.timeouts.mcp_s}")

        # ID ranges
        lines.extend(["", "[id_ranges]"])
        lines.append(f"spec_min = {self.id_ranges.spec_min}")
        lines.append(f"spec_max = {self.id_ranges.spec_max}")
        lines.append(f"epic_min = {self.id_ranges.epic_min}")
        lines.append(f"epic_max = {self.id_ranges.epic_max}")
        lines.append(f"adr_min = {self.id_ranges.adr_min}")
        lines.append(f"adr_max = {self.id_ranges.adr_max}")

        # Per-user ranges
        for uid, ur in self.id_ranges.users.items():
            # Always quote user IDs for TOML safety — Python isidentifier()
            # allows non-ASCII chars that TOML bare keys don't support
            escaped = uid.replace("\\", "\\\\").replace('"', '\\"')
            safe_uid = f'"{escaped}"'
            lines.append(f"\n[id_ranges.users.{safe_uid}]")
            lines.append(f"spec_min = {ur.spec_min}")
            lines.append(f"spec_max = {ur.spec_max}")
            if ur.epic_min is not None:
                lines.append(f"epic_min = {ur.epic_min}")
            if ur.epic_max is not None:
                lines.append(f"epic_max = {ur.epic_max}")

        # Agents
        lines.extend(["", "[agents]"])
        for name, impl in sorted(self.agents.agents.items()):
            lines.append(f'{name} = "{impl}"')

        # Codex (subprocess executor defaults)
        lines.extend(["", "[codex]"])
        lines.append(f'model = "{self.codex.model}"')
        lines.append(f'reasoning_effort = "{self.codex.reasoning_effort}"')
        lines.append(f'sandbox = "{self.codex.sandbox}"')
        lines.append(f'approval_policy = "{self.codex.approval_policy}"')
        codex_flags = ", ".join(f'"{flag}"' for flag in self.codex.flags)
        lines.append(f"flags = [{codex_flags}]")
        lines.append(f"timeout = {self.codex.timeout}")
        lines.append(f"poll_interval = {self.codex.poll_interval}")
        lines.append(f'session_prefix = "{self.codex.session_prefix}"')

        # Gemini (subprocess executor defaults)
        lines.extend(["", "[gemini]"])
        lines.append(f'model = "{self.gemini.model}"')
        lines.append(f'approval_mode = "{self.gemini.approval_mode}"')
        lines.append(f"sandbox = {str(self.gemini.sandbox).lower()}")
        gemini_flags = ", ".join(f'"{flag}"' for flag in self.gemini.flags)
        lines.append(f"flags = [{gemini_flags}]")
        lines.append(f"timeout = {self.gemini.timeout}")
        lines.append(f"poll_interval = {self.gemini.poll_interval}")
        lines.append(f'session_prefix = "{self.gemini.session_prefix}"')

        # Review (agent selection and per-agent settings)
        lines.extend(["", "[review]"])
        lines.append(f'agent = "{self.review.agent}"')
        lines.append(f"timeout = {self.review.timeout}")
        lines.append(f"token_ttl_hours = {self.review.token_ttl_hours}")
        lines.append(f"max_retries = {self.review.max_retries}")
        lines.append(f"require_test_pass = {str(self.review.require_test_pass).lower()}")
        lines.append(f"require_hmac = {str(self.review.require_hmac).lower()}")

        lines.extend(["", "[review.codex]"])
        lines.append(f'model = "{self.review.codex.model}"')
        lines.append(f'effort = "{self.review.codex.effort}"')

        lines.extend(["", "[review.claude]"])
        lines.append(f'model = "{self.review.claude.model}"')
        lines.append(f'effort = "{self.review.claude.effort}"')

        lines.extend(["", "[review.gemini]"])
        lines.append(f'model = "{self.review.gemini.model}"')

        # Refinement (agent selection and per-agent settings)
        lines.extend(["", "[refinement]"])
        lines.append(f'agent = "{self.refinement.agent}"')
        lines.append(f"timeout = {self.refinement.timeout}")

        lines.extend(["", "[refinement.codex]"])
        lines.append(f'model = "{self.refinement.codex.model}"')
        lines.append(f'effort = "{self.refinement.codex.effort}"')

        lines.extend(["", "[refinement.claude]"])
        lines.append(f'model = "{self.refinement.claude.model}"')
        lines.append(f'effort = "{self.refinement.claude.effort}"')

        lines.extend(["", "[refinement.gemini]"])
        lines.append(f'model = "{self.refinement.gemini.model}"')

        # Handoff (audit trail generation)
        lines.extend(["", "[handoff]"])
        lines.append(f'agent = "{self.handoff.agent}"')
        lines.append(f'model = "{self.handoff.model}"')
        lines.append(f'effort = "{self.handoff.effort}"')
        lines.append(f"timeout = {self.handoff.timeout}")

        # LOE estimator
        lines.extend(["", "[loe]"])
        lines.append(f"weight_task_count = {self.loe.weight_task_count}")
        lines.append(f"weight_max_depth = {self.loe.weight_max_depth}")
        lines.append(f"weight_nested_ratio = {self.loe.weight_nested_ratio}")
        lines.append(f"weight_dep_count = {self.loe.weight_dep_count}")
        lines.append(f"weight_complexity_signal = {self.loe.weight_complexity_signal}")
        lines.append(f"min_history_specs = {self.loe.min_history_specs}")

        # Loop
        lines.extend(["", "[loop]"])
        lines.append(f'session_timeout = "{self.loop.session_timeout}"')
        lines.append(f"max_retries = {self.loop.max_retries}")
        lines.append(f"batch_branch = {str(self.loop.batch_branch).lower()}")

        # Pipeline
        lines.append("pipeline = [")
        for step in self.loop.pipeline:
            parts = [f'"{step.step}"'] + [f'"{p}"' for p in step.params]
            lines.append(f"    [{', '.join(parts)}],")
        lines.append("]")

        # Watchdog
        lines.extend(["", "[watchdog]"])
        lines.append(f"stall_timeout = {self.watchdog.stall_timeout}")
        lines.append(f"mcp_stall_timeout = {self.watchdog.mcp_stall_timeout}")
        lines.append(f"poll_interval = {self.watchdog.poll_interval}")
        lines.append(f'recovery_message = "{self.watchdog.recovery_message}"')

        # Docs (post-completion doc generation)
        lines.extend(["", "[docs]"])
        lines.append(f"enabled = {str(self.docs.enabled).lower()}")
        lines.append(f'template = "{self.docs.template}"')
        lines.append(f'target = "{self.docs.target}"')
        lines.append(f'agent = "{self.docs.agent}"')
        lines.append(f'mode = "{self.docs.mode}"')

        # Backend (persistence engine)
        if self.backend.engine != "markdown":
            lines.extend(["", "[backend]"])
            lines.append(f'engine = "{self.backend.engine}"')

        # Queue (multi-agent parallel execution)
        lines.extend(["", "[queue]"])
        lines.append(f'mode = "{self.queue.mode}"')
        lines.append(f"max_agents = {self.queue.max_agents}")
        lines.append(f"lease_ttl_seconds = {self.queue.lease_ttl_seconds}")

        # Templates (ceremony-level profiles)
        lines.extend(["", "[templates]"])
        lines.append(f'default = "{self.templates.default}"')
        if self.templates.fr is not None:
            lines.append(f'fr = "{self.templates.fr}"')
        if self.templates.impl is not None:
            lines.append(f'impl = "{self.templates.impl}"')

        # Linear integration
        if self.linear.team_id:
            lines.extend(["", "[linear]"])
            lines.append(f'token_env = "{self.linear.token_env}"')
            lines.append(f'team_id = "{self.linear.team_id}"')
            if self.linear.label_ids:
                lid_str = ", ".join(f'"{lid}"' for lid in self.linear.label_ids)
                lines.append(f"label_ids = [{lid_str}]")

            if self.linear.state_mapping:
                lines.extend(["", "[linear.state_mapping]"])
                for status, state_id in sorted(self.linear.state_mapping.items()):
                    lines.append(f'"{status}" = "{state_id}"')

            if self.linear.priority_mapping:
                lines.extend(["", "[linear.priority_mapping]"])
                for prio, val in sorted(self.linear.priority_mapping.items()):
                    lines.append(f"{prio} = {val}")

        # GitHub integration
        if self.github.repo:
            lines.extend(["", "[github]"])
            lines.append(f'repo = "{self.github.repo}"')
            lines.append(f'default_priority = "{self.github.default_priority}"')
            lines.append(f'default_epic = "{self.github.default_epic}"')
            lines.append(f"auto_close = {str(self.github.auto_close).lower()}")

            if self.github.label_priority_map:
                lines.extend(["", "[github.label_priority_map]"])
                for label, prio in sorted(self.github.label_priority_map.items()):
                    lines.append(f'"{label}" = "{prio}"')

        # Error agent
        lines.extend(["", "[error_agent]"])
        lines.append(f"enabled = {str(self.error_agent.enabled).lower()}")
        lines.append(f"auto_create_spec = {str(self.error_agent.auto_create_spec).lower()}")
        lines.append(
            f"auto_park_on_blocking = {str(self.error_agent.auto_park_on_blocking).lower()}"
        )
        if self.error_agent.epic_id is not None:
            lines.append(f'epic_id = "{self.error_agent.epic_id}"')
        if self.error_agent.priority is not None:
            lines.append(f'priority = "{self.error_agent.priority}"')
        lines.append(f"max_per_session = {self.error_agent.max_per_session}")

        lines.extend(["", "[error_agent.triggers]"])
        ec_str = ", ".join(str(c) for c in self.error_agent.triggers.exit_codes)
        lines.append(f"exit_codes = [{ec_str}]")
        lines.append(f"mcp_errors = {str(self.error_agent.triggers.mcp_errors).lower()}")
        lines.append(f"test_failures = {str(self.error_agent.triggers.test_failures).lower()}")
        lines.append(
            f"subprocess_timeout = {str(self.error_agent.triggers.subprocess_timeout).lower()}"
        )

        lines.extend(["", "[error_agent.ignore]"])
        pat_str = ", ".join(f'"{p}"' for p in self.error_agent.ignore_patterns)
        lines.append(f"patterns = [{pat_str}]")

        # Providers (user overrides for provider registries)
        if self.providers.overrides:
            for prov_name, prov_fields in sorted(self.providers.overrides.items()):
                lines.extend(["", f"[providers.{prov_name}]"])
                for fld_name, fld_vals in sorted(prov_fields.items()):
                    vals_str = ", ".join(f'"{v}"' for v in fld_vals)
                    lines.append(f"{fld_name} = [{vals_str}]")

        # Resources (handle overrides)
        if self.resources.handles:
            lines.extend(["", "[resources]"])
            for handle, path in sorted(self.resources.handles.items()):
                lines.append(f'{handle} = "{path}"')

        lines.append("")  # trailing newline
        return "\n".join(lines)


def _find_config_file(start_dir: Path) -> Path | None:
    """Search upward from start_dir for .novabuilt.dev/nspec/config.toml.

    Stops at git root, filesystem root, traversal stop dirs, or after 10 levels.

    Args:
        start_dir: Directory to start searching from.

    Returns:
        Path to config file if found, None otherwise.
    """
    import tempfile

    search_dir = start_dir.resolve()
    sys_tmp = str(Path(tempfile.gettempdir()).resolve())

    for _ in range(10):
        config_file = search_dir / CONFIG_REL_PATH
        if config_file.exists():
            return config_file

        if (search_dir / ".git").exists():
            break

        parent = search_dir.parent
        if parent == search_dir:
            break
        parent_str = str(parent)
        if parent_str in _TRAVERSAL_STOP_DIRS or parent_str == sys_tmp:
            break
        search_dir = parent

    return None


def _parse_toml(config_file: Path) -> dict[str, Any]:
    """Parse a TOML file into a dict.

    Args:
        config_file: Path to the TOML file.

    Returns:
        Parsed dict, or empty dict on error.
    """
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redefine]
        except ImportError:
            return {}

    try:
        with open(config_file, "rb") as f:
            return tomllib.load(f)
    except Exception:  # noqa: BLE001
        return {}
