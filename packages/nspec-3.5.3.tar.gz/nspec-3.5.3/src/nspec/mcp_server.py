"""nspec MCP Server — re-export shim.

The implementation has moved to ``nspec.interfaces.mcp``.
This module re-exports all public names for backward compatibility.
"""

import subprocess  # noqa: F401

# Checkout / session / init / skills / artifacts tools
from nspec.interfaces.mcp._checkout import (
    artifacts_list,  # noqa: F401
    artifacts_sync,  # noqa: F401
    checkin,  # noqa: F401
    checkout,  # noqa: F401
    checkout_heartbeat,  # noqa: F401
    checkout_status,  # noqa: F401
    context_audit,  # noqa: F401
    coverage_audit,  # noqa: F401
    discover_providers,  # noqa: F401
    init,  # noqa: F401
    session_delete,  # noqa: F401
    session_get,  # noqa: F401
    session_list,  # noqa: F401
    skills_install,  # noqa: F401
    skills_list,  # noqa: F401
    skills_sync,  # noqa: F401
    skills_update,  # noqa: F401
    spec_test_files,  # noqa: F401
    spec_tests,  # noqa: F401
)

# Helpers (used by tests via @patch strings)
from nspec.interfaces.mcp._helpers import (
    _attach_branch_warnings,  # noqa: F401
    _capture_mcp_error,  # noqa: F401
    _capture_test_gate_error,  # noqa: F401
    _check_stale_branch,  # noqa: F401
    _compute_task_progress,  # noqa: F401
    _dao,  # noqa: F401
    _discover_epics_on_disk,  # noqa: F401
    _exception_error,  # noqa: F401
    _extract_spec_id_from_prompt,  # noqa: F401
    _find_epic_for_spec,  # noqa: F401
    _get_task_tag,  # noqa: F401
    _invalid_id_error,  # noqa: F401
    _normalize_epic_id,  # noqa: F401
    _normalize_id,  # noqa: F401
    _post_mutation_validate,  # noqa: F401
    _resolve_code_root,  # noqa: F401
    _resolve_docs_root,  # noqa: F401
    _resolve_id,  # noqa: F401
    _resolve_id_from_disk,  # noqa: F401
    _resolve_project_root,  # noqa: F401
    _run_test_gate,  # noqa: F401
    _scan_known_ids,  # noqa: F401
    _to_bool,  # noqa: F401
    _tool_error,  # noqa: F401
    _try_capture_from_frame,  # noqa: F401
    _verify_epic_exists,  # noqa: F401
)

# Mutation tools
# Mutation tools (continued)
from nspec.interfaces.mcp._mutation import (
    activate,  # noqa: F401
    add_dep,  # noqa: F401
    advance,  # noqa: F401
    batch_import,  # noqa: F401
    blocked_specs,  # noqa: F401
    branch_cleanup,  # noqa: F401
    branch_status,  # noqa: F401
    cheap_docs,  # noqa: F401
    complete,  # noqa: F401
    create_issue,  # noqa: F401
    create_spec,  # noqa: F401
    criteria_complete,  # noqa: F401
    dep_graph,  # noqa: F401
    epic_specs,  # noqa: F401
    exception,  # noqa: F401
    execute_agent,  # noqa: F401
    hold,  # noqa: F401
    issue_import,  # noqa: F401
    issue_list,  # noqa: F401
    issue_sync,  # noqa: F401
    loop_init,  # noqa: F401
    loop_pipeline,  # noqa: F401
    park,  # noqa: F401
    park_epic,  # noqa: F401
    queue_claim,  # noqa: F401
    queue_heartbeat,  # noqa: F401
    queue_init,  # noqa: F401
    queue_release,  # noqa: F401
    queue_status,  # noqa: F401
    recover,  # noqa: F401
    refine_fr,  # noqa: F401
    refine_impl,  # noqa: F401
    remove_dep,  # noqa: F401
    reset,  # noqa: F401
    review,  # noqa: F401
    review_spec,  # noqa: F401
    session_clear,  # noqa: F401
    session_resume,  # noqa: F401
    session_save,  # noqa: F401
    set_priority,  # noqa: F401
    start_design,  # noqa: F401
    supersede,  # noqa: F401
    swap_priority,  # noqa: F401
    swarm_launch,  # S253: parallel Claude Code agent swarm  # noqa: F401
    swarm_status,  # noqa: F401
    swarm_teardown,  # noqa: F401
    task_block,  # noqa: F401
    task_complete,  # noqa: F401
    task_unblock,  # noqa: F401
    unify_collisions,  # noqa: F401
    write_fr_refinement,  # noqa: F401
    write_refinement,  # noqa: F401
    write_review_verdict,  # noqa: F401
)

# Query tools
from nspec.interfaces.mcp._query import (
    epics,  # noqa: F401
    estimate_loe,  # noqa: F401
    get_epic,  # noqa: F401
    next_spec,  # noqa: F401
    preflight,  # noqa: F401
    session_start,  # noqa: F401
    show,  # noqa: F401
    validate,  # noqa: F401
)

# Core server
from nspec.interfaces.mcp.server import (
    _redirect_print_to_stderr_for_stdio,  # noqa: F401
    main,
    mcp,  # noqa: F401
)

if __name__ == "__main__":
    main()
