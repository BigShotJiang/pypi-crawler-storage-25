# py2ecma

py2ecma is an experimental transpiler / compiler that translates Python source code into JavaScript (ECMAScript).

The goal of the project is not to perfectly emulate CPython in the browser, but to provide a pragmatic, understandable bridge between Python semantics and the ECMAScript runtime.

Think of it as:

"Python syntax and structure, running on JavaScript engines"

A tool for learning, experimentation, and selective cross-language reuse
