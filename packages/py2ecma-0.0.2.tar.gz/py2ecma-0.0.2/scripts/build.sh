#!/bin/sh

# Build python package and place it in dist/

uv build
