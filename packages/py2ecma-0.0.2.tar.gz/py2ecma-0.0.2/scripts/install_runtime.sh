#!/bin/sh


uv sync --no-dev

	