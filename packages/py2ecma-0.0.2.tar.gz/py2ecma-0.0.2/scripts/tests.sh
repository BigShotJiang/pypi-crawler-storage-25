#!/bin/sh

uv run pytest  --junitxml report.xml .