#!/bin/sh

# Install python package from file
#
# Will lookup tar.gz files in ./dist/ and install them with pip.  This will also
# install development dependencies.

for file in ./dist/*.tar.gz ; do
    if [ -e "$file" ] ; then
        pip install "$file[dev]"
    fi
done