#!/bin/sh

echo "Executing flake8"
uv run flake8
echo "Executing isort"
uv run isort --check .
echo "Executing black"
uv run black --check .
echo "Executing mypy"
uv run mypy .