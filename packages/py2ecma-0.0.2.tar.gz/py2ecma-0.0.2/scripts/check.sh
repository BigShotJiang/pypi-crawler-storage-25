#!/bin/sh

poetry check
