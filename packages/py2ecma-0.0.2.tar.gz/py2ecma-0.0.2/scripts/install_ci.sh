#!/bin/sh

# Install dependencies and package into CI environment
#
# The main difference between this and `install.sh` is that this won't install
# the package as editable and force it into a virtual environment. But will
# still install all the development dependencies.

pip install uv
uv sync
