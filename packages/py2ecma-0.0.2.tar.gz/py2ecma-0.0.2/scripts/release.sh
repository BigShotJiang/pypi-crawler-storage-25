#!/bin/sh

uv run twine upload dist/*