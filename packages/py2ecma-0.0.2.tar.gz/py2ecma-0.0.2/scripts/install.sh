#!/bin/sh

# Install the development environment.

# Use `uv` to create virtual environment and install packages defined by
# pyproject.toml. Uv will use pyenv to find the correct version of python.

pyenv exec pip install uv
uv venv --python 3.14.2
uv sync
