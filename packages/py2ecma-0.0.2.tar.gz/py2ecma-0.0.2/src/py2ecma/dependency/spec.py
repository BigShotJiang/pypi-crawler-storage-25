"""
This is a modified version of the importlib.util.find_spec function

It will handle the fact that it is not always possible to run all cross
build source code both in python and through the compiler.

JS Native functions will not be able run when imported in python
"""

import os
import sys

from py2ecma.get_logger import logger


def find_import_src(name: str, origin: str) -> str:
    origin_dir = os.path.dirname(origin)
    # check if the import name is relative
    if name[0] == ".":
        # Import is relative
        return find_relative(name, origin_dir)
    else:
        # Import is absolute
        return find_absolute(name)


def search(name, search_paths):
    for p in search_paths:
        path = os.path.join(p, name.replace(".", "/") + ".py")
        logger.debug(f"Searching path: {path}")
        if os.path.exists(path):
            return path
        parent_name = name.rpartition(".")[0]
        if parent_name:
            path = os.path.join(p, parent_name.replace(".", "/") + ".py")
            logger.debug(f"Searching path: {path}")
            if os.path.exists(path):
                return path
            dirname, filename = os.path.split(path)
            module = path = os.path.join(
                p, parent_name.replace(".", "/") + "/__init__.py"
            )
            logger.debug(f"Searching path: {module}")
            if os.path.exists(module):
                return module
    return None


def find_absolute(name):
    return search(name, sys.path)


def find_relative(name, path):
    num_dots = len(name) - len(name.lstrip(".")) - 1
    dots = "../" * num_dots if num_dots > 0 else ""
    modified_path = os.path.join(path, dots)
    return search(name.lstrip("."), [modified_path])
