import ast
import glob
import os
import sys

from py2ecma.get_logger import logger

from .excludes import EXCLUDE
from .sortedset import OrderedSet
from .spec import find_import_src


class ImportLister(ast.NodeVisitor):

    def __init__(self):
        self.fileList = []
        self.moduleList = []

    def _process_names(self, names, module=None, level=0):
        logger.info("module: {}, level: {}".format(module, level))
        for item in names:
            item_module = item.name
            # Ignore pyecma.js and jsloader
            if module == "py2ecma":
                continue
            if module is not None:
                item_module = module + "." + item_module
            self.moduleList.append(("." * level if level > 0 else "") + item_module)

    def visit_Import(self, node):
        self._process_names(node.names)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        self._process_names(node.names, node.module, node.level)
        self.generic_visit(node)


def _get_module_deps(filename):
    code = ""

    importLister = ImportLister()
    for file in glob.glob(filename):
        try:
            with open(file, encoding="utf-8") as f:
                code = f.read()
            tree = ast.parse(code)
            importLister.generic_visit(tree)
        except:
            logger.error(
                "Error when trying to resolve dependecies for file: " + filename
            )

    return importLister.moduleList


def findpackage(filepath):
    logger.info("findpackage: {}".format(filepath))
    dirname = os.path.dirname(filepath)
    paths_to_compare = [[dirname, p] for p in sys.path]
    path_score = [
        (os.path.commonpath(x), len(os.path.commonpath(x))) for x in paths_to_compare
    ]
    bestmatch = max(path_score, key=lambda x: x[1])
    filepath_translation, _ = os.path.splitext(os.path.relpath(filepath, bestmatch[0]))
    return ".".join(filepath_translation.split(os.sep))


def getdeps(filename):
    logger.info('Finding dependencies for "{}"'.format(filename))
    modules = OrderedSet(_get_module_deps(filename))
    filepaths = list()

    for mod in list(modules):
        if mod.split(".")[0] in EXCLUDE:
            continue
        path = find_import_src(mod, filename)
        if path is None:
            logger.error("Could not find origin of module({})".format(mod))
            raise ImportError("Could not find: {}".format(mod))
        logger.info('dependency found: "{}"'.format(path))
        filepaths.append(path)
    return filepaths
