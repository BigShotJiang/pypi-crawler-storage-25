"""
This is the list of modules which should never be traversed in when finding
depedencies
"""

EXCLUDE = ["py2ecma", "typing"]
