CONVERT = {
    "self": "this",
    "split": "_split",
    "switch": "_switch",
    "TypeError": "_TypeError",
}


def converter(name: str) -> str:
    return CONVERT.get(name, name)
