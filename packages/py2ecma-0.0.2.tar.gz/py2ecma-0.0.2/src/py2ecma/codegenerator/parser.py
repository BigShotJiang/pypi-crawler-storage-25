import ast

from py2ecma.get_logger import logger

from .enums import CTX
from .nintermediate import asyncs as A
from .nintermediate import classes as CD
from .nintermediate import comprehensions as C
from .nintermediate import controlflow as CF
from .nintermediate import expressions as E
from .nintermediate import functions as F
from .nintermediate import imports as I
from .nintermediate import literals as L
from .nintermediate import statements as S
from .nintermediate import subscripting as SUB
from .nintermediate import variables as V
from .nintermediate.module import Module
from .traversers import find_assignments, find_defs, find_vars, has_generator

M = ast.Module


def parse(tree: ast.Module, parent_module: str = "", file_: str = "") -> Module:
    p = Parse(parent_module, file_)
    return Module(body=p.visit(tree), vars=find_vars(tree), __file__=file_)


class Parse(ast.NodeVisitor):

    def __init__(self, parent_module: str, file_: str) -> None:
        self.parent_module = parent_module
        self.file = file_

    def visit_Module(self, node):
        val = [self.visit(n) for n in node.body]
        return val

    # Constants
    def visit_Constant(self, node):
        value = node.value
        match value:
            case bool():
                return L.NameConstant(__file__=self.file, value=value)
            case int():
                return L.Num(__file__=self.file, value=value)
            case str():
                return L.Str(__file__=self.file, value=value)
            case float():
                return L.Num(__file__=self.file, value=value)
            case None:
                return L.NameConstant(__file__=self.file, value=value)

            case _:
                logger.warning(f"Could not find match of value {value}")

    # Literals
    def visit_Num(self, node):
        return L.Num(__file__=self.file, value=node.n)

    def visit_Str(self, node):
        return L.Str(__file__=self.file, value=node.s)

    def visit_FormattedValue(self, node):
        return L.FormattedValue(
            __file__=self.file,
            value=self.visit(node.value),
            conversion=node.conversion,
            spec=self.visit(node.format_spec) if node.format_spec is not None else None,
        )

    def visit_JoinedStr(self, node):
        return L.JoinedStr(__file__=self.file, values=self.visit(M(node.values)))

    def visit_Bytes(self, node):
        return L.Bytes(__file__=self.file, s=node.s)

    def visit_List(self, node):
        return L.List_(
            __file__=self.file,
            elts=self.visit(M(node.elts)),
            ctx=CTX.from_ast(node.ctx),
        )

    def visit_Tuple(self, node):
        return L.Tuple(
            __file__=self.file,
            elts=self.visit(M(node.elts)),
            ctx=CTX.from_ast(node.ctx),
        )

    def visit_Set(self, node):
        return L.Set(__file__=self.file, elts=self.visit(M(node.elts)))

    def visit_Dict(self, node):
        return L.Dict(
            __file__=self.file,
            keys=[self.visit(k) for k in node.keys if k is not None],
            values=self.visit(M(node.values)),
        )

    def visit_Ellipsis(self, node):
        return L.Ellipsis(__file__=self.file)

    def visit_NameConstant(self, node):
        return L.NameConstant(__file__=self.file, value=node.value)

    # Variables
    def visit_Name(self, node):
        return V.Name(__file__=self.file, id=node.id, ctx=CTX.from_ast(node.ctx))

    def visit_Starred(self, node):
        return V.Starred(
            __file__=self.file, value=self.visit(node.value), ctx=CTX.from_ast(node.ctx)
        )

    # Expressions
    def visit_Expr(self, node):
        return E.Expression(__file__=self.file, value=self.visit(node.value))

    def visit_UnaryOp(self, node):
        return E.UnaryOp(
            __file__=self.file, op=self.visit(node.op), operand=self.visit(node.operand)
        )

    def visit_UAdd(self, node):
        return E.UAdd(__file__=self.file)

    def visit_USub(self, node):
        return E.USub(__file__=self.file)

    def visit_Not(self, node):
        return E.Not(__file__=self.file)

    def visit_Invert(self, node):
        return E.Invert(__file__=self.file)

    def visit_BinOp(self, node):
        return E.BinOp(
            __file__=self.file,
            left=self.visit(node.left),
            op=self.visit(node.op),
            right=self.visit(node.right),
        )

    def visit_Add(self, node):
        return E.Add(__file__=self.file)

    def visit_Sub(self, node):
        return E.Sub(__file__=self.file)

    def visit_Mult(self, node):
        return E.Mult(__file__=self.file)

    def visit_Div(self, node):
        return E.Div(__file__=self.file)

    def visit_FloorDiv(self, node):
        return E.FloorDiv(__file__=self.file)

    def visit_Mod(self, node):
        return E.Mod(__file__=self.file)

    def visit_Pow(self, node):
        return E.Pow(__file__=self.file)

    def visit_LShift(self, node):
        return E.LShift(__file__=self.file)

    def visit_RShift(self, node):
        return E.RShift(__file__=self.file)

    def visit_BitOr(self, node):
        return E.BitOr(__file__=self.file)

    def visit_BitXor(self, node):
        return E.BitXor(__file__=self.file)

    def visit_BitAnd(self, node):
        return E.BitAnd(__file__=self.file)

    def visit_MatMult(self, node):
        return E.MatMult(__file__=self.file)

    def visit_BoolOp(self, node):
        return E.BoolOp(
            __file__=self.file,
            op=self.visit(node.op),
            values=self.visit(M(node.values)),
        )

    def visit_And(self, node):
        return E.And(__file__=self.file)

    def visit_Or(self, node):
        return E.Or(__file__=self.file)

    def visit_Compare(self, node):
        return E.Compare(
            __file__=self.file,
            left=self.visit(node.left),
            ops=self.visit(M(node.ops)),
            comparators=self.visit(M(node.comparators)),
        )

    def visit_Eq(self, node):
        return E.Eq(__file__=self.file)

    def visit_NotEq(self, node):
        return E.NotEq(__file__=self.file)

    def visit_Lt(self, node):
        return E.Lt(__file__=self.file)

    def visit_LtE(self, node):
        return E.LtE(__file__=self.file)

    def visit_Gt(self, node):
        return E.Gt(__file__=self.file)

    def visit_GtE(self, node):
        return E.GtE(__file__=self.file)

    def visit_Is(self, node):
        return E.Is(__file__=self.file)

    def visit_IsNot(self, node):
        return E.IsNot(__file__=self.file)

    def visit_In(self, node):
        return E.In(__file__=self.file)

    def visit_NotIn(self, node):
        return E.NotIn(__file__=self.file)

    def visit_Call(self, node):
        return (
            E.Call(
                __file__=self.file,
                func=self.visit(node.func),
                args=self.visit(M(node.args)),
            )
            if len(node.keywords) == 0
            else E.KWCall(
                __file__=self.file,
                func=self.visit(node.func),
                args=self.visit(M(node.args)),
                keywords=self.visit(M(node.keywords)),
            )
        )

    def visit_keyword(self, node):
        return E.Keyword(__file__=self.file, arg=node.arg, value=self.visit(node.value))

    def visit_IfExp(self, node):
        return E.IfExp(
            __file__=self.file,
            test=self.visit(node.test),
            body=self.visit(node.body),
            orelse=self.visit(node.orelse),
        )

    def visit_Attribute(self, node):
        return E.Attribute(
            __file__=self.file,
            value=self.visit(node.value),
            attr=node.attr,
            ctx=CTX.from_ast(node.ctx),
        )

    # Subscripting
    def visit_Subscript(self, node):
        return SUB.Subscript(
            __file__=self.file,
            value=self.visit(node.value),
            slice=self.visit(node.slice),
            ctx=CTX.from_ast(node.ctx),
        )

    def visit_Index(self, node):
        return SUB.Index(__file__=self.file, value=self.visit(node.value))

    def visit_Slice(self, node):
        return SUB.Slice(
            __file__=self.file,
            lower=self.visit(node.lower) if node.lower is not None else None,
            upper=self.visit(node.upper) if node.upper is not None else None,
            step=self.visit(node.step) if node.step is not None else None,
        )

    def visit_ExtSlice(self, node):
        return SUB.ExtSlice(__file__=self.file, dims=self.visit(node.dims))

    # Comprehensions
    def visit_ListComp(self, node):
        return C.ListComp(
            __file__=self.file,
            elt=self.visit(node.elt),
            generators=self.visit(M(node.generators)),
        )

    def visit_SetComp(self, node):
        return C.SetComp(
            __file__=self.file,
            elt=self.visit(node.elt),
            generators=self.visit(M(node.generators)),
        )

    def visit_GeneratorComp(self, node):
        return C.GeneratorComp(
            __file__=self.file,
            elt=self.visit(node.elt),
            generators=self.visit(M(node.generators)),
        )

    def visit_DictComp(self, node):
        return C.DictComp(
            __file__=self.file,
            key=self.visit(node.key),
            value=self.visit(node.value),
            generators=self.visit(M(node.generators)),
        )

    def visit_comprehension(self, node):
        return C.Comprehension(
            __file__=self.file,
            target=self.visit(node.target),
            iter=self.visit(node.iter),
            ifs=self.visit(M(node.ifs)),
            is_async=node.is_async,
        )

    # Statements
    def visit_Assign(self, node):
        return S.Assign(
            __file__=self.file,
            targets=self.visit(M(node.targets)),
            value=self.visit(node.value),
            is_fncall=any([isinstance(t, ast.Subscript) for t in node.targets]),
        )

    def visit_AnnAssign(self, node):
        return S.AnnAssign(
            __file__=self.file,
            target=self.visit(node.target),
            annotation=self.visit(node.annotation),
            value=self.visit(node.value),
            simple=node.simple,
        )

    def visit_AugAssign(self, node):
        return S.AugAssign(
            __file__=self.file,
            target=self.visit(node.target),
            op=self.visit(node.op),
            value=self.visit(node.value),
        )

    def visit_Raise(self, node):
        return S.Raise(
            __file__=self.file,
            exc=self.visit(node.exc) if node.exc else None,
            cause=self.visit(node.cause) if node.cause else None,
        )

    def visit_Assert(self, node):
        return S.Assert(
            __file__=self.file,
            test=self.visit(node.test),
            msg=self.visit(node.msg) if node.msg else None,
        )

    def visit_Delete(self, node):
        return S.Delete(__file__=self.file, targets=self.visit(M(node.targets)))

    def visit_Pass(self, node):
        return S.Pass(__file__=self.file)

    # Imports
    def visit_Import(self, node):
        return I.Import(__file__=self.file, names=self.visit(M(node.names)))

    def visit_ImportFrom(self, node):
        return I.ImportFrom(
            __file__=self.file,
            module=node.module,
            names=self.visit(M(node.names)),
            level=node.level,
            parent=self.parent_module,
        )

    def visit_alias(self, node):
        return I.Alias(__file__=self.file, name=node.name, asname=node.asname)

    # Control Flow
    def visit_If(self, node):
        return CF.If(
            __file__=self.file,
            test=self.visit(node.test),
            body=self.visit(M(node.body)),
            orelse=self.visit(M(node.orelse)),
        )

    def visit_For(self, node):
        return CF.For(
            __file__=self.file,
            target=self.visit(node.target),
            iter=self.visit(node.iter),
            body=self.visit(M(node.body)),
            orelse=self.visit(M(node.orelse)),
        )

    def visit_While(self, node):
        return CF.While(
            __file__=self.file,
            test=self.visit(node.test),
            body=self.visit(M(node.body)),
            orelse=self.visit(M(node.orelse)),
        )

    def visit_Break(self, node):
        return CF.Break(__file__=self.file)

    def visit_Continue(self, node):
        return CF.Continue(__file__=self.file)

    def visit_Try(self, node):
        return CF.Try(
            __file__=self.file,
            body=self.visit(M(node.body)),
            handlers=self.visit(M(node.handlers)),
            orelse=self.visit(M(node.orelse)),
            finalbody=self.visit(M(node.finalbody)),
        )

    def visit_TryFinally(self, node):
        return CF.TryFinally(
            __file__=self.file,
            body=self.visit(node.body),
            finalbody=self.visit(node.finalbody),
        )

    def visit_TryExcept(self, node):
        return CF.TryExcept(
            __file__=self.file,
            body=self.visit(node.body),
            handlers=self.visit(node.handlers),
            orelse=self.visit(node.orelse),
        )

    def visit_ExceptHandler(self, node):
        return CF.ExceptHandler(
            __file__=self.file,
            type=self.visit(node.type) if node.type else None,
            name=node.name,
            body=self.visit(M(node.body)),
        )

    def visit_With(self, node):
        return CF.With(
            __file__=self.file,
            items=self.visit(M(node.items)),
            body=self.visit(M(node.body)),
        )

    def visit_withitem(self, node):
        return CF.WithItem(
            __file__=self.file,
            context_expr=self.visit(node.context_expr),
            optional_vars=self.visit(node.optional_vars),
        )

    # Function & class definitions
    def visit_FunctionDef(self, node):
        return F.FunctionDef(
            __file__=self.file,
            name=node.name,
            decorators=self.visit(M(node.decorator_list)),
            args=self.visit(node.args),
            body=self.visit(M(node.body)),
            var=find_vars(M(node.body)),
            is_generator=has_generator(M(node.body)),
        )

    def visit_Lambda(self, node):
        return F.Lambda(
            __file__=self.file, args=self.visit(node.args), body=self.visit(node.body)
        )

    def visit_arguments(self, node):
        vararg = node.vararg.arg if node.vararg else None
        kwarg = node.kwarg.arg if node.kwarg else None
        return F.Arguments(
            __file__=self.file,
            args=self.visit(M(node.args)),
            vararg=vararg,
            defaults=self.visit(M(node.defaults)),
            kwarg=kwarg,
        )

    def visit_arg(self, node):
        return node.arg

    def visit_Return(self, node):
        return F.Return(
            __file__=self.file,
            value=self.visit(node.value) if node.value is not None else None,
        )

    def visit_Yield(self, node):
        return F.Yield(__file__=self.file, value=self.visit(node.value))

    def visit_YieldFrom(self, node):
        return F.YieldFrom(__file__=self.file, value=self.visit(node.value))

    def visit_Global(self, node):
        return F.Global(__file__=self.file, names=node.names)

    def visit_Nonlocal(self, node):
        return F.Nonlocal(__file__=self.file, names=node.names)

    def visit_ClassDef(self, node):
        init = class_body(
            M(find_defs(M(node.body), "__init__")),
            node.name,
            self.parent_module,
            self.file,
        )
        constructors = class_body(
            M(find_defs(M(node.body), "constructor")),
            node.name,
            self.parent_module,
            self.file,
        )

        is_proxy = (
            bool(find_defs(M(node.body), "__getattr__"))
            or bool(find_defs(node, "__getattribute__"))
            or bool(find_defs(node, "__setattr__"))
        )
        assignments = [
            CD.ClassAssign(
                cls=node.name,
                targets=self.visit(M(a.targets)),
                value=self.visit(a.value),
                __file__=self.file,
            )
            for a in find_assignments(M(node.body))
        ]

        return CD.ClassDef(
            __file__=self.file,
            name=node.name,
            bases=self.visit(M(node.bases)),
            keywords=self.visit(M(node.keywords)),
            body=class_body(M(node.body), node.name, self.parent_module, self.file),
            constructors=constructors,
            decorator_list=self.visit(M(node.decorator_list)),
            init=init,
            assignments=assignments,
            is_proxy=is_proxy,
        )

    # Async & Awaits
    def visit_AsyncFunctionDef(self, node):
        return A.AsyncFunctionDef(
            __file__=self.file,
            name=node.name,
            decorator_list=self.visit(M(node.decorator_list)),
            args=self.visit(node.args),
            body=self.visit(M(node.body)),
            var=node.var,
        )

    def visit_Await(self, node):
        return A.Await(__file__=self.file, value=self.visit(node.value))

    def visit_AsyncFor(self, node):
        return A.AsyncFor(
            __file__=self.file,
            target=self.visit(node.target),
            iter=self.visit(node.iter),
            body=self.visit(M(node.body)),
            orelse=self.visit(M(node.orelse)),
        )

    def visit_AsyncWith(self, node):
        return A.AsyncWith(
            __file__=self.file,
            items=self.visit(M(node.items)),
            body=self.visit(M(node.body)),
        )


def class_body(tree, name, module, file_):
    class ClsParser(Parse):
        def __init__(self, name, parent_module, file_):
            self.parent_module = parent_module
            self.clsname = name
            self.file = (file_,)

        def visit_FunctionDef(self, node):
            decorators = [n.id for n in node.decorator_list]
            return CD.Method(
                __file__=self.file,
                name=node.name,
                clsname=self.clsname,
                decorators=self.visit(M(node.decorator_list)),
                args=self.visit(node.args),
                body=method_body(M(node.body), self.parent_module, self.file),
                var=find_vars(M(node.body)),
                is_generator=has_generator(M(node.body)),
                is_staticmethod="staticmethod" in decorators,
                is_property="property" in decorators,
                is_classmethod="classmethod" in decorators or node.name == "__new__",
            )

        def visit_Assign(self, node):
            return ""

    cls_parser = ClsParser(name, module, file_)
    return cls_parser.visit(tree)


def method_body(tree, module, file_):
    class MethodParser(Parse):
        def __init__(self, parent_module, file_):
            self.parent_module = parent_module
            self.file = (file_,)

        def visit_FunctionDef(self, node):
            return CD.MethodFunc(
                __file__=self.file,
                name=node.name,
                decorators=self.visit(M(node.decorator_list)),
                args=self.visit(node.args),
                body=self.visit(M(node.body)),
                var=find_vars(M(node.body)),
                is_generator=has_generator(M(node.body)),
            )

    methods = MethodParser(module, file_)
    return methods.visit(tree)
