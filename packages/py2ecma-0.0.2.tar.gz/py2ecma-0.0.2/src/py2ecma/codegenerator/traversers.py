import ast
from typing import List, Set

from .nameconverter import converter
from .nintermediate.module import Module


def find_vars(tree: Module):

    class VarDeclaration(ast.NodeVisitor):
        """Visitor that finds variables declaration in a scope"""

        unique_vars: List[ast.Name]

        def __init__(self):
            self.unique_vars = []

        def vars(self) -> str:
            queue: Set[str] = set([converter(q.id) for q in self.unique_vars])
            if len(queue) > 0:
                return "var " + ", ".join(queue) + ";\n"
            else:
                return ""

        def visit_Name(self, node: ast.Name):
            if isinstance(node.ctx, ast.Store):
                self.unique_vars.append(node)
            self.generic_visit(node)

        def visit_FunctionDef(self, node: ast.FunctionDef):
            """The missing generic visit will make sure
            that the scope is bounded by the function definition"""
            pass

        def visit_ClassDef(self, node: ast.ClassDef):
            pass

    code_generator = VarDeclaration()
    code_generator.generic_visit(tree)
    return code_generator.vars()


def has_generator(tree):
    class DetectGeneratorDef(ast.NodeVisitor):
        def __init__(self):
            self.is_generator = False

        def visit_Yield(self, node):
            self.is_generator = True

        def visit_FunctionDef(self, node):
            pass

    code_generator = DetectGeneratorDef()
    code_generator.generic_visit(tree)
    return code_generator.is_generator


def find_defs(tree, search=None):
    class FindDefs(ast.NodeVisitor):
        def __init__(self, search):
            self.defs = []
            self.search = search

        def visit_FunctionDef(self, node):
            if self.search is None or self.search == node.name:
                self.defs.append(node)

    code_generator = FindDefs(search)
    code_generator.generic_visit(ast.Module(tree))
    return code_generator.defs


def find_assignments(tree):

    class FindInlineAssign(ast.NodeVisitor):
        def __init__(self):
            self.assigns = []

        def visit_Assign(self, node):
            self.assigns.append(node)

        def visit_FunctionDef(self, node):
            pass

        def visit_ClassDef(self, node):
            pass

    visitor = FindInlineAssign()
    visitor.visit(tree)
    return visitor.assigns
