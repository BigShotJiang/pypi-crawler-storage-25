import ast


def is_jsfunction(decorators):
    return any(isinstance(x, ast.Name) and x.id == "jsfunction" for x in decorators)


def is_jscall(withitems):
    return any(
        isinstance(x.context_expr, ast.Name) and x.context_expr.id == "jscall"
        for x in withitems
    )
