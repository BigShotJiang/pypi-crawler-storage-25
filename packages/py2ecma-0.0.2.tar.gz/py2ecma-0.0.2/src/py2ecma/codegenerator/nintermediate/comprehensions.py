from dataclasses import dataclass
from typing import List

from .node import Node


@dataclass
class ListComp(Node):
    elt: Node
    generators: List[Node]

    def code(self):
        yield "__list_comprehension__("
        yield "("
        yield self.generators[-1].target
        yield ") => ("
        yield self.elt
        yield "), ["
        yield self.join(", ", self.generators)
        yield "])"


@dataclass
class SetComp(Node):
    elt: Node
    generators: List[Node]


@dataclass
class GeneratorComp(Node):
    elt: Node
    generators: List[Node]


@dataclass
class DictComp(Node):
    key: Node
    value: Node
    generators: List[Node]

    def code(self):
        yield "__dict_comprehension__(("
        yield self.generators[-1].target
        yield ") => "
        yield self.key
        yield ", ("
        yield self.generators[-1].target
        yield ") => ("
        yield self.value
        yield "), ["
        yield self.generators
        yield "])"


@dataclass
class Comprehension(Node):
    target: Node
    iter: Node
    ifs: List[Node]
    is_async: bool

    def code(self):
        yield "__comprehension__("
        yield self.target
        yield ", "
        yield self.iter
        if len(self.ifs) > 0:
            yield ", "
            yield self.target
            yield " => "
            yield self.ifs
        yield ")"
