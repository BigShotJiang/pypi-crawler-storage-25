from copy import deepcopy as copy
from dataclasses import dataclass
from typing import List

from .functions import FunctionDef
from .node import Node


@dataclass
class ClassDef(Node):
    name: str
    bases: List[Node]
    keywords: List[Node]
    body: List[Node]
    constructors: List[Node]
    decorator_list: List[Node]
    init: List[Node]
    assignments: List[str]
    is_proxy: bool

    def inheritance(self):
        if len(self.bases) > 0:
            yield self.bases[-1]
        else:
            yield "BaseClass"

    def multiple_inheritance(self):
        if len(self.bases) > 1:
            for b in self.bases[::-1][1:]:
                yield f"_cls_extend({self.name}.prototype, "
                yield b
                yield ".prototype);\n"
        else:
            yield ""

    def constructor_body(self):
        assigns = copy(self.assignments)
        yield "constructor(...args) {\n"
        yield "super(...args);\n"
        for t in assigns:
            yield t.body()
        yield self.binds()
        yield self.constructor_kwargs()
        yield self.binds_static()
        if len(self.constructors) > 0:
            for x in self.constructors:
                yield x.body
        yield "}\n"

    def constructor_kwargs(self):
        methods = [method for method in self.body if isinstance(method, Method)]
        simple_methods = filter(
            lambda m: not (m.is_staticmethod or m.is_classmethod or m.is_property),
            methods,
        )
        for method in simple_methods:
            yield f"this.{method.name}"
            yield method.kwargs("this")

    def special_methods_kwargs(self):
        """Special methods referes to classmethods & static methods"""
        methods = [method for method in self.body if isinstance(method, Method)]
        simple_methods = list(
            filter(lambda m: (m.is_staticmethod or m.is_classmethod), methods)
        )
        for method in simple_methods:
            yield f"{self.name}.{method.name}"
            yield method.kwargs(self.name)

    def kwargs(self):
        if len(self.init) > 0:
            yield [init.static_kwarg() for init in self.init]

    def call(self):
        if len(self.init) > 0:
            yield [init.static_call(self.name) for init in self.init]

    def binds(self):
        methods = [method for method in self.body if isinstance(method, Method)]
        simples = [
            m.name
            for m in methods
            if not (m.is_property or m.is_staticmethod or m.is_classmethod)
        ]

        for m in simples:
            yield f"this.{m} = this.{m}.bind(this);\n"

    def binds_static(self):
        methods = [method for method in self.body if isinstance(method, Method)]
        statics = [
            method.name
            for method in methods
            if method.is_staticmethod or method.is_classmethod
        ]
        for m in statics:
            yield f"this.{m} = this.constructor.{m}.bind(this);\n"
            yield f"this.{m}.kwargs = this.constructor.{m}.kwargs.bind(this);\n"
        simples = [
            m.name
            for m in methods
            if not (m.is_property or m.is_staticmethod or m.is_classmethod)
        ]

        for m in simples:
            yield f"this.{m}.kwargs = this.{m}.kwargs.bind(this);\n"

    def proxy(self):
        pass

    def code(self):
        yield f"class {'py_' if self.is_proxy else ''}{ self.name } extends "
        yield self.inheritance()
        yield " {\n"
        yield self.constructor_body()
        yield self.kwargs()
        yield self.call()
        yield [
            b
            for b in self.body
            if not (isinstance(b, Method) and b.name == "constructor")
        ]
        yield "}\n"
        if self.is_proxy:
            yield f"const {self.name} = proxyClass(py_{self.name});\n"
        yield self.assignments
        yield self.special_methods_kwargs()
        yield self.multiple_inheritance()


@dataclass
class Method(Node):
    name: str
    clsname: str
    decorators: List[Node]
    args: Node
    body: List[Node]
    var: str
    is_generator: bool
    is_staticmethod: bool
    is_property: bool
    is_classmethod: bool

    def code(self):
        yield "static " if self.is_staticmethod or self.is_classmethod else ""
        yield "get " if self.is_property else ""
        yield "* " if self.is_generator else ""
        yield f"{ self.name } ("
        yield FunctionDef.arg_string_generator(
            self.arg[1 if self.is_classmethod else 0 :],
            self.args.defaults,
            self.args.vararg,
            self.args.kwarg,
        )
        yield ") {\n"
        if self.is_classmethod:
            yield f"var {self.arg[0]} = this;\n"
            yield "return (("
            yield FunctionDef.arg_string_generator(
                self.arg, self.args.defaults, self.args.vararg, self.args.kwarg
            )
            yield ") => {\n"
        yield self.var
        yield self.body
        if self.is_classmethod:
            yield "})(this, "
            yield self.join(
                ", ",
                self.arg[1:]  # Skip first argument it will be self
                + ([self.args.kwarg] if self.args.kwarg else [])
                + ([f"...{self.args.vararg}"] if self.args.vararg else []),
            )
            yield ");\n"
        yield "}\n"

    @property
    def arg(self):
        offset = 0 if self.is_staticmethod or self.is_classmethod else 1
        return self.args.args[offset:]

    def kwargs(self, callee):
        varg = [f"...{self.args.vararg}"] if self.args.vararg is not None else []

        yield f".kwargs = (__kwargs__, ...__args__) => {{\n"
        yield FunctionDef.kwargs_body(
            name="",
            call=f"{self.clsname}.call",
            args=self.arg[1 if self.is_classmethod else 0 :],
            defaults=self.args.defaults,
            varg=self.args.vararg,
            kwarg=self.args.kwarg,
        )
        yield f"return {callee}.{self.name}.call(this, "
        yield ", ".join(self.arg[1 if self.is_classmethod else 0 :] + ["__kwargs__"])
        yield [", "] * len(varg) + varg
        yield ");\n};\n"

    def static_kwarg(self):
        varg = [f"...{self.args.vararg}"] if self.args.vararg is not None else []

        yield "static kwargs(__kwargs__, ...__args__) {\n"

        yield FunctionDef.kwargs_body(
            name="",
            call=f"{self.clsname}.call",
            args=self.arg,
            defaults=self.args.defaults,
            varg=self.args.vararg,
            kwarg=self.args.kwarg,
        )
        yield f"return this.__new__("
        yield ", ".join(self.arg + ["dict(__kwargs__)"])
        yield [", "] * len(varg) + varg
        yield ");\n};\n"

    def static_call(self, name):
        if bool(self.args.vararg) and bool(self.args.kwarg):
            args = self.args.args
            namedargs = ", ".join(args[1:]) + ", " if len(args) > 1 else ""
            yield f"static call(self, {namedargs} ...arg) {{"
            yield f"const cls_ =  this.__new__({namedargs} dict(), ...arg);\n"
            yield f"return cls_ }};\n"


@dataclass
class ClassAssign(Node):
    cls: str
    targets: List[Node]
    value: Node

    def code(self):
        for t in self.targets:
            yield f'__attribute__({self.cls}, "'
            yield t
            yield '", '
            yield self.value
            yield ");\n"

    def body(self):
        for t in self.targets:
            yield '__attribute__(this, "'
            yield t
            yield '", '
            yield self.cls
            yield "."
            yield t
            yield ");\n"


@dataclass
class Super(Node):
    func: Node
    args: List[Node]

    def code(self):
        if bool(self.args):
            yield "__super__("
            yield self.join(", ", self.args)
            yield ")"
        else:
            yield "super"

    @classmethod
    def from_node(cls, node, file_):
        return cls(
            file_,
            node.func,
            node.args,
        )


@dataclass
class MethodFunc(FunctionDef):
    name: str
    decorators: List[Node]
    args: Node
    body: List[Node]
    var: str
    is_generator: bool

    def code(self):
        args = self.get_parameters()
        gen = "*" if self.is_generator else ""
        yield f"let {self.name} = {gen}("
        yield args
        yield ") => {\n"
        yield self.var
        yield self.body
        yield "}\n"
        yield (
            self.kwarg_method(
                self.name,
                self.name,
                self.args.args,
                self.args.defaults,
                self.args.vararg,
                self.args.kwarg,
            )
            if len(self.args.args) + len(self.args.defaults)
            or self.args.vararg
            or self.args.kwarg
            else ""
        )
