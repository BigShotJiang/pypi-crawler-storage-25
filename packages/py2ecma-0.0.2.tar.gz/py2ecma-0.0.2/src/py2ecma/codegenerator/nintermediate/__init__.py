from typing import Iterable

from py2ecma.get_logger import logger


def code_generation(intermediate) -> str:
    def flatten(container):
        for i in container:
            if not isinstance(i, str) and isinstance(i, (list, tuple, Iterable)):
                for j in flatten(i):
                    yield j
            elif i is None:
                pass
                logger.warning(f"Trying to flatten a None value")
            else:
                yield i

    return "".join(flatten(intermediate))
