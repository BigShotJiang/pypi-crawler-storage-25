from dataclasses import dataclass
from typing import List, Union

from ..enums import CTX
from .node import Node


@dataclass
class Num(Node):
    value: Union[int, float]

    def code(self):
        yield f"{self.value}"


@dataclass
class Str(Node):
    value: str

    def code(self):
        yield f"`{self.value}`"


@dataclass
class FormattedValue(Node):
    value: Node
    conversion: int
    spec: Node

    def code(self):
        yield "${"
        yield self.value
        yield "}"


@dataclass
class JoinedStr(Node):
    values: List[Node]

    def code(self):
        yield "`"
        for val in self.values:
            if isinstance(val, Str):
                yield val.value
            else:
                yield val
        yield "`"


@dataclass
class Bytes(Node):
    s: Node


@dataclass
class List_(Node):
    elts: List[Node]
    ctx: CTX

    def code(self):
        yield "__list__("
        yield self.join(", ", self.elts)
        yield ")"


@dataclass
class Tuple(Node):
    elts: List[Node]
    ctx: CTX

    def code(self):
        if self.ctx is CTX.LOAD:
            yield "tuple(["
            yield self.join(", ", self.elts)
            yield "])"
        elif self.ctx is CTX.STORE:
            yield "["
            yield self.join(", ", self.elts)
            yield "]"


@dataclass
class Set(Node):
    elts: List[Node]

    def code(self):
        yield "set.call(this, ["
        yield self.join(", ", self.elts)
        yield "])"


@dataclass
class Dict(Node):
    keys: List[Node]
    values: List[Node]

    def code(self):
        if len(self.values) > 0:
            yield "dict(["
            if len(self.keys):
                yield "tuple(["
                yield self.join(
                    "]), tuple([", self.keys, [", "] * len(self.keys), self.values
                )
                yield "])"
            if len(self.values) > len(self.keys):
                if len(self.keys) > 0:
                    yield ", "
                l = len(self.values) - len(self.keys)
                yield self.join(", ", ["..."] * l, self.values[len(self.keys) :])
            yield "])"
        else:
            yield "dict([])"


@dataclass
class Ellipsis(Node):
    pass


@dataclass
class NameConstant(Node):
    value: Union[bool, None]

    def code(self):
        if self.value is None:
            yield "null"
        elif self.value is True:
            yield "true"
        elif self.value is False:
            yield "false"
        else:
            raise ValueError(f"Unknown value in NameConstant ({self.value})")
