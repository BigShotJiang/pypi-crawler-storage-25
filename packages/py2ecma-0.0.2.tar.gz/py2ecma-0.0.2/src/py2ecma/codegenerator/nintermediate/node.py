from dataclasses import dataclass


@dataclass
class Node:
    __file__: str

    def code(self):
        raise NotImplementedError(
            "Itermediate node type '{}'".format(self.__class__.__name__)
            + " is missing the code() method override"
        )

    @staticmethod
    def join(string: str, *iterable):
        yield zip(*iterable, [string] * (len(iterable[0]) - 1) + [""])

    @staticmethod
    def merge(*iterable):

        def merge_(iterables):
            for i in iterable:
                if isinstance(i, str):
                    yield None

        return None

    def __iter__(self):
        return self.code()
