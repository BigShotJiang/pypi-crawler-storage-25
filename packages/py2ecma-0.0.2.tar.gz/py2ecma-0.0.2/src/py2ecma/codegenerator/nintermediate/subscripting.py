from dataclasses import dataclass
from typing import List, Optional

from ..enums import CTX
from .node import Node


@dataclass
class Subscript(Node):
    value: Node
    slice: Node
    ctx: CTX

    def code(self):
        yield self.value
        if self.ctx is CTX.LOAD:
            yield ".__getitem__("
            yield self.slice
            yield ")"
        elif self.ctx is CTX.STORE:
            yield ".__setitem__("
            yield self.slice
            yield ", "
        elif self.ctx is CTX.DELETE:
            yield ".__delitem__("
            yield self.slice
            yield ")"


@dataclass
class Index(Node):
    value: Node

    def code(self):
        yield self.value


@dataclass
class Slice(Node):
    lower: Optional[Node]
    upper: Optional[Node]
    step: Optional[Node]

    def code(self):
        yield "{lower: "
        yield self.lower if self.lower else "null"
        yield ", upper: "
        yield self.upper if self.upper else "null"
        yield ", step: "
        yield self.step if self.step else "null"
        yield "}"


@dataclass
class ExtSlice(Node):
    dims: List[Node]
