from dataclasses import dataclass
from typing import List, Optional

from py2ecma.dependency.excludes import EXCLUDE

from .node import Node


@dataclass
class Alias(Node):
    name: str
    asname: Optional[str]

    def code(self):
        if self.name not in EXCLUDE:
            asname = self.asname if self.asname else self.name
            yield f"var {asname} = __import__('{self.name}')"
        else:
            asname = self.asname if self.asname else self.name
            yield "//var {asname} = __import__('{self.name}')"


@dataclass
class Import(Node):
    names: List[Node]

    def code(self):
        for n in self.names:
            yield n
            yield ";\n"


@dataclass
class ImportFrom(Node):
    parent: str
    module: Optional[str]
    names: List[Node]
    level: int

    def code(self):
        module = self.module
        if module in EXCLUDE:
            yield ""
        else:
            if self.level > 0:
                module = (
                    ".".join(self.parent.split(".")[: -self.level]) + "." + self.module
                )
            for n in self.names:
                asname = n.asname if n.asname else n.name
                yield f"var {asname} = __import__('{module}').{n.name};\n"
