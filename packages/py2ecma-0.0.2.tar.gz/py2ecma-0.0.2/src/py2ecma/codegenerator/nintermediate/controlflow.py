from dataclasses import dataclass
from typing import List, Optional

from .node import Node


class ControlFlow(Node):
    pass


@dataclass
class If(ControlFlow):
    test: Node
    body: List[Node]
    orelse: List[Node]

    def code(self):
        yield "if ("
        yield self.test
        yield ") {\n"
        yield self.body
        if len(self.orelse) > 0:
            yield "} else {\n"
            yield self.orelse
        yield "}\n"


@dataclass
class For(ControlFlow):
    target: Node
    iter: Node
    body: List[Node]
    orelse: List[Node]

    def code(self):
        yield "for ("
        yield self.target
        yield " of __Iterator__("
        yield self.iter
        yield ")){\n"
        yield self.body
        yield "}\n"


@dataclass
class While(ControlFlow):
    test: Node
    body: List[Node]
    orelse: List[Node]

    def code(self):
        yield "while("
        yield self.test
        yield "){\n"
        yield self.body
        yield "}\n"


class Break(Node):
    def code(self):
        yield "break"


class Continue(Node):
    def code(self):
        yield "continue"


@dataclass
class Try(ControlFlow):
    body: List[Node]
    handlers: List[Node]
    orelse: List[Node]
    finalbody: List[Node]

    def code(self):
        yield "try {\n"
        yield self.body
        yield self.orelse
        yield "} catch(__e__) {\n"
        yield self.join(" else ", self.handlers)
        yield "}\n"


@dataclass
class TryFinally(ControlFlow):
    body: List[Node]
    finalbody: List[Node]


@dataclass
class TryExcept(ControlFlow):
    body: List[Node]
    handlers: List[Node]
    orelse: List[Node]


@dataclass
class ExceptHandler(ControlFlow):
    type: Optional[Node]
    name: Optional[str]
    body: List[Node]

    def code(self):
        if self.type:
            if self.name is None:
                yield "if (isinstance(__e__, "
                yield self.type
                yield ")){ \n"
                yield self.body
                yield "}"
            else:
                yield "if (isinstance(__e__, "
                yield self.type
                yield ")){\n var "
                yield self.name
                yield " = __e__;\n"
                yield self.body
                yield "}"
        else:
            yield "if (true){\n"
            yield self.body
            yield "}"


@dataclass
class With(ControlFlow):
    items: List[Node]
    body: List[Node]


@dataclass
class WithItem(Node):
    context_expr: Node
    optional_vars: Optional[Node]
