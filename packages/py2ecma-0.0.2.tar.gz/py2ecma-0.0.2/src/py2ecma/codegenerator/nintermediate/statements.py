from dataclasses import dataclass
from typing import List, Optional

from .expressions import Add, Sub
from .node import Node
from .variables import Name


@dataclass
class Assign(Node):
    targets: List[Node]
    value: Node
    is_fncall: bool

    def code(self):
        if self.is_fncall:
            yield self.targets
            yield self.value
            yield ");\n"
        else:
            yield self.join(" = ", self.targets)
            yield " = "
            yield self.value
            yield ";\n"


@dataclass
class AnnAssign(Node):
    target: Node
    annotation: Node
    value: Node
    simple: bool

    def code(self):
        yield self.target
        yield " = "
        yield self.value
        yield ";\n"


@dataclass
class AugAssign(Node):
    target: Node
    op: Node
    value: Node

    def code(self):
        yield self.target
        yield "="
        if isinstance(self.op, Add):
            yield "__iadd__("
        elif isinstance(self.op, Sub):
            yield "__isub__("
        else:
            yield self.op
            yield "("
        yield self.target
        yield ", "
        yield self.value
        yield ");\n"


@dataclass
class Raise(Node):
    exc: Optional[Node]
    cause: Optional[Node]

    def code(self):
        if isinstance(self.exc, Name):
            yield "throw new "
            yield self.exc
            yield "();\n"
        else:
            yield "throw "
            yield self.exc
            yield ";\n"


@dataclass
class Assert(Node):
    test: Node
    msg: Node

    def code(self):
        yield "if (!("
        yield self.test
        yield ")) { throw new AssertionError("
        yield self.msg if self.msg else ""
        yield ")}"


@dataclass
class Delete(Node):
    targets: List[Node]

    def code(self):
        yield self.join("; ", self.targets)
        yield ";\n"


@dataclass
class Pass(Node):
    def code(self):
        yield ""
