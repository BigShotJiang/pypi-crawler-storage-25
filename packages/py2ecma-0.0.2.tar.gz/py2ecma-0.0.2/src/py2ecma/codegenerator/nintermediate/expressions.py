from dataclasses import dataclass
from itertools import zip_longest
from typing import List, Optional

from ..enums import CTX
from ..nameconverter import converter
from .classes import Super
from .node import Node


@dataclass
class Expression(Node):
    value: List[Node]

    def code(self):
        yield self.value
        yield ";\n"


@dataclass
class UnaryOp(Node):
    op: Node
    operand: Node

    def code(self):
        yield self.op
        yield "("
        yield self.operand
        yield ")"


@dataclass
class UAdd(Node):
    def code(self):
        yield "__uadd__"


@dataclass
class USub(Node):
    def code(self):
        yield "__usub__"


@dataclass
class Not(Node):
    def code(self):
        yield "__not__"


@dataclass
class Invert(Node):
    def code(self):
        yield "__invert__"


@dataclass
class BinOp(Node):
    left: Node
    op: Node
    right: Node

    def code(self):
        yield self.op
        yield "("
        yield self.left
        yield ", "
        yield self.right
        yield ")"


@dataclass
class Add(Node):
    def code(self):
        yield "__add__"


@dataclass
class Sub(Node):
    def code(self):
        yield "__sub__"


@dataclass
class Mult(Node):
    def code(self):
        yield "__mul__"


@dataclass
class Div(Node):
    def code(self):
        yield "__truediv__"


@dataclass
class FloorDiv(Node):
    def code(self):
        yield "__floordiv__"


@dataclass
class Mod(Node):
    def code(self):
        yield "__mod__"


@dataclass
class Pow(Node):
    def code(self):
        yield "__pow__"


@dataclass
class LShift(Node):
    def code(self):
        yield "__lshift__"


@dataclass
class RShift(Node):
    def code(self):
        yield "__rshift__"


@dataclass
class BitOr(Node):
    def code(self):
        yield "__or__"


@dataclass
class BitXor(Node):
    def code(self):
        yield "__xor__"


@dataclass
class BitAnd(Node):
    def code(self):
        yield "__and__"


@dataclass
class MatMul(Node):
    def code(self):
        yield "__matmul__"


@dataclass
class BoolOp(Node):
    op: Node
    values: List[Node]

    def code(self):
        yield "("
        yield zip([""] + [self.op] * (len(self.values) - 1), self.values)
        yield ")"


@dataclass
class And(Node):
    def code(self):
        yield " && "


@dataclass
class Or(Node):
    def code(self):
        yield " || "


@dataclass
class Compare(Node):
    left: Node
    ops: List[Node]
    comparators: List[Node]

    def code(self):
        left = self.left
        for op, right in zip(self.ops, self.comparators):
            yield op
            yield "("
            yield left
            yield ", "
            yield right
            yield ") && "
            left = right
        yield "true"


@dataclass
class Eq(Node):
    def code(self):
        yield "__eq__"


class NotEq(Node):
    def code(self):
        yield "__ne__"


class Lt(Node):
    def code(self):
        yield "__lt__"


class LtE(Node):
    def code(self):
        yield "__le__"


class Gt(Node):
    def code(self):
        yield "__gt__"


class GtE(Node):
    def code(self):
        yield "__ge__"


class Is(Node):
    def code(self):
        yield "__is__"


class IsNot(Node):
    def code(self):
        yield "__isnot__"


class In(Node):
    def code(self):
        yield "__contains__"


class NotIn(Node):
    def code(self):
        yield "__notcontains__"


@dataclass
class Call(Node):
    func: Node
    args: List[Node]
    context: Optional[str] = None

    def code(self):
        if self.context is None:
            if isinstance(self.func, Attribute) and not isinstance(
                self.func.value, Super
            ):
                context = self.func.value
            else:
                context = "this"
        else:
            context = self.context
        yield self.func
        yield ".call("
        yield context
        yield ", "
        yield zip(self.args, [", "] * (len(self.args) - 1) + [""])
        yield ")"


@dataclass
class KWCall(Node):
    func: Node
    args: List[Node]
    keywords: List[Node]

    def code(self):
        l = len(self.args)

        keywords = sorted(self.keywords, key=lambda x: (x.arg is not None, x.arg))
        yield self.func
        yield ".kwargs(dict({"
        yield self.join(", ", keywords)
        yield "}), "
        yield zip(self.args, [", "] * (l - 1) + [""])
        yield ")"


@dataclass
class Keyword(Node):
    arg: Optional[str]
    value: Node

    def code(self):
        if self.arg is not None:
            yield (self.arg, " : ", self.value)
        else:
            yield ("...", self.value)


@dataclass
class IfExp(Node):
    test: Node
    body: Node
    orelse: Node

    def code(self):
        yield "(("
        yield self.test
        yield ") ? "
        yield self.body
        yield ":"
        yield self.orelse
        yield ")"


@dataclass
class Attribute(Node):
    value: Node
    attr: str
    ctx: CTX

    def code(self):
        yield self.value
        yield f".{converter(self.attr)}"
