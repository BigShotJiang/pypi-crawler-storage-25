from dataclasses import dataclass
from typing import List

from .node import Node


@dataclass
class AsyncFunctionDef(Node):
    name: str
    decorator_list: List[Node]
    args: Node
    body: List[Node]
    var: str


@dataclass
class Await(Node):
    value: Node


@dataclass
class AsyncFor(Node):
    target: Node
    iter: Node
    body: List[Node]
    orelse: List[Node]


@dataclass
class AsyncWith(Node):
    items: List[Node]
    body: List[Node]
