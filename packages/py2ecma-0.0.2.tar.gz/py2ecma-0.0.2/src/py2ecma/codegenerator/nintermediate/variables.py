from dataclasses import dataclass

from ..enums import CTX
from ..nameconverter import converter
from .node import Node


@dataclass
class Name(Node):
    id: str
    ctx: CTX

    def code(self):
        yield converter(self.id)


@dataclass
class Starred(Node):
    value: Node
    ctx: CTX

    def code(self):
        yield "..."
        yield self.value
