from dataclasses import dataclass
from typing import List, Optional

from .node import Node


@dataclass
class FunctionDef(Node):
    name: str
    decorators: List[Node]
    args: Node
    body: List[Node]
    var: str
    is_generator: bool

    def code(self):
        args = self.get_parameters()
        gen = "*" if self.is_generator else ""

        yield f"const {self.name} = "
        for d in self.decorators:
            yield d
            yield "("
        yield f"function{gen} ("
        yield args
        yield "){\n"
        yield self.var
        yield (
            f"{self.args.vararg} = list(...{self.args.vararg});\n"
            if self.args.vararg
            else ""
        )
        yield self.body
        yield "}\n"
        for d in self.decorators:
            yield ")"
        if len(self.decorators) > 0:
            yield ";\n"
        yield (
            self.override_call(self.name, self.args.vararg, self.args.kwarg)
            if len(self.args.args) == 0 and self.args.vararg and self.args.kwarg
            else ""
        )
        yield (
            self.kwarg_method(
                self.name,
                self.name,
                self.args.args,
                self.args.defaults,
                self.args.vararg,
                self.args.kwarg,
            )
            if len(self.args.args) + len(self.args.defaults)
            or self.args.vararg
            or self.args.kwarg
            else ""
        )

    def get_parameters(self):
        return self.arg_string_generator(
            self.args.args, self.args.defaults, self.args.vararg, self.args.kwarg
        )

    @staticmethod
    def arg_string_generator(args, defaults, varg, kwarg):
        varg = [f"...{varg}"] if varg is not None else []
        kwarg = [f"{kwarg}=dict({{}})"] if kwarg is not None else []
        arg_list = args + kwarg + varg

        prefix = [""] * (len(args) - len(defaults))
        postfix = [""] * (len(varg) + len(kwarg))
        assignments = prefix + ["="] * (len(defaults)) + postfix
        seperators = [", "] * (len(arg_list) - 1) + [""]

        yield zip(arg_list, assignments, prefix + defaults + postfix, seperators)

    @staticmethod
    def override_call(name, vararg, kwarg):
        yield f"{name}.call = function(self, ...arg) {{ return {name}(dict(), ...arg) }};\n"

    @staticmethod
    def kwarg_method(name, call, args, defaults, varg, kwarg):
        varg_ = varg
        varg = [f"...{varg}"] if varg is not None else []
        kwarg = [f"{kwarg}"] if kwarg is not None else []

        yield f"{name}." if name else ""
        yield f"kwargs{' =' if name else ''} (__kwargs__, ...__args__) {'=>' if name else ''} {{\n"
        yield FunctionDef.kwargs_body(name, call, args, defaults, varg_, kwarg)
        yield f"return {call}("
        yield ", ".join(args + ["dict(__kwargs__)"])
        yield [", "] * len(varg) + varg
        yield ");\n};\n"

    @staticmethod
    def kwargs_body(name, call, args, defaults, varg, kwarg):
        varg_ = varg
        varg = [f"...{varg}"] if varg is not None else []
        kwarg = [f"{kwarg}"] if kwarg is not None else []
        positionals = [a for a in args + varg]

        prefix = [""] * (len(args) - len(defaults))
        postfix = [""] * (len(varg) + len(kwarg))
        assignments = prefix + ["="] * (len(defaults)) + postfix
        seperators = [", "] * (len(args) - 1) + [""]
        yield (
            "var " + ", ".join(args + [varg_] * len(varg)) + ";\n"
            if len(args + [varg_] * len(varg))
            else ""
        )
        yield ("[", ", ".join(positionals), "] = __args__;\n")
        yield "({"
        yield zip(args, assignments, prefix + defaults + postfix, seperators)
        yield ", " if len(args) > 0 else ""
        yield "...__kwargs__} = {"
        yield zip(args, [":"] * len(args), args, seperators)
        yield ", " if len(args) > 0 else ""
        yield "...__kwargs__});\n"


@dataclass
class Lambda(Node):
    args: List[Node]
    body: Node

    def code(self):
        args = FunctionDef.arg_string_generator(
            args=self.args.args,
            defaults=self.args.defaults,
            varg=self.args.vararg,
            kwarg=self.args.kwarg,
        )
        yield "(("
        yield args
        yield ") => { return "
        yield self.body
        yield "})\n"


@dataclass
class Arguments(Node):
    args: List[Node]
    vararg: Optional[str]
    defaults: List[Node]
    kwarg: Optional[str]

    def code(self):
        yield ""


@dataclass
class Return(Node):
    value: Node

    def code(self):
        yield "return "
        yield self.value if self.value is not None else "null"
        yield ";\n"


@dataclass
class Yield(Node):
    value: Node

    def code(self):
        yield "yield "
        yield self.value


@dataclass
class YieldFrom(Node):
    value: Node


@dataclass
class Global(Node):
    names: List[str]

    def code(self):
        yield "var "
        yield self.join(",", self.names)
        yield ";\n"


@dataclass
class Nonlocal(Node):
    names: List[str]
