import os
from copy import deepcopy as copy
from dataclasses import dataclass
from typing import List, Union

from py2ecma.filesystem import loadsrc

from .expressions import Attribute
from .literals import Str
from .node import Node
from .variables import Name


@dataclass
class Module(Node):
    vars: str
    body: List[Node]

    def code(self):
        yield self.vars
        yield self.body


@dataclass
class StrDef(Node):
    i: int
    node: Node

    def code(self):
        ident = f"$_{self.i}"
        yield f"let {ident} = "
        yield self.node.func.value
        yield ";\n"
        self.node.func.value = ident
        self.node.context = ident


@dataclass
class Expansion(Node):
    i: int
    node: Node

    def code(self):
        class Counter:
            i = 0

            def get(self):
                ii = self.i
                self.i += 1
                return ii

        elems = []

        def t(node, context, counter):

            i = counter.get()
            ident = f"${self.i}_{i}"
            if isinstance(node.func, Attribute) and not isinstance(
                node.func.value, Name
            ):
                context = t(node.func.value, context, counter)
            newnode = copy(node)
            newnode.func.value = context
            newnode.context = context

            elems.append([f"let {ident} = ", newnode, ";\n"])

            return ident

        ident = t(self.node.func.value, "this", Counter())
        self.node.func.value = ident
        yield elems


@dataclass
class JSCall(Node):
    content: Str

    def code(self):
        yield self.content

    @classmethod
    def from_node(cls, node, file_):
        if len(node.args) != 1:
            msg = f"js call does only except one argument got {len(node.args)}"
            raise ValueError(msg)
        elif not isinstance(node.args[0], Str):
            msg = f"js call does only except one argument got {len(node.args)}"
            raise ValueError(msg)
        return cls(__file__=file_, content=node.args[0].value)


@dataclass
class JSLoad(Node):
    content: Str
    filedir: Str

    def code(self):
        location = os.path.dirname(self.__file__)
        jssrc = loadsrc(os.path.join(location, self.filedir))
        yield self.content.format(jssrc)

    @classmethod
    def from_node(cls, node, file_):
        if len(node.args) != 2:
            msg = f"jsload call does only except two argument got {len(node.args)}"
            raise ValueError(msg)
        elif not isinstance(node.args[0], Str):
            msg = f"js call does only except string argument"
            raise TypeError(msg)
        return cls(
            content=node.args[0].value, filedir=node.args[1].value, __file__=file_
        )
