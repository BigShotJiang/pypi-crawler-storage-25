from copy import copy
from typing import List, Union

from .nintermediate.classes import ClassDef, Method, Super
from .nintermediate.controlflow import ControlFlow
from .nintermediate.expressions import Attribute, Call
from .nintermediate.functions import FunctionDef
from .nintermediate.literals import Str
from .nintermediate.module import Expansion, JSCall, JSLoad, Module, StrDef
from .nintermediate.node import Node
from .nintermediate.variables import Name


def optimize(tree: Module, file_: str):
    class Count:
        def __init__(self):
            self.i = 0

        def get(self):
            i = self.i
            self.i = self.i + 1
            return i

    count = Count()
    anchor = tree.body
    traverse(tree.body, is_super, replace(Super), count, anchor, 0, file_)
    traverse(tree.body, is_jscall, replace(JSCall), count, anchor, 0, file_)
    traverse(tree.body, is_jsload, replace(JSLoad), count, anchor, 0, file_)
    traverse(tree.body, should_expand_call, insert(Expansion), count, anchor, 0, file_)
    traverse(tree.body, is_str_call, insert(StrDef), count, anchor, 0, file_)


def insert(cls):
    def __inner(count, node, anchor, offset, file_):
        expansion = cls(
            __file__=file_,
            i=count.get(),
            node=node,
        )
        anchor.insert(offset, expansion)
        return node

    return __inner


def replace(cls):
    def __inner(count, node, anchor, offset, file_):
        _cls = cls.from_node(node, file_=file_)
        return _cls

    return __inner


def should_expand_call(node):
    b = (
        isinstance(node, Call)
        and isinstance(node.func, Attribute)
        and isinstance(node.func.value, Call)
    )
    return b


def is_str_call(node):
    b = (
        isinstance(node, Call)
        and isinstance(node.func, Attribute)
        and isinstance(node.func.value, Str)
    )
    return b


def is_super(node):
    b = (
        isinstance(node, Call)
        and isinstance(node.func, Name)
        and node.func.id == "super"
    )
    return b


def is_jscall(node):
    b = isinstance(node, Call) and isinstance(node.func, Name) and node.func.id == "js"
    return b


def is_jsload(node):
    b = (
        isinstance(node, Call)
        and isinstance(node.func, Name)
        and node.func.id == "jsload"
    )
    return b


def traverse(
    node: Union[Node, List[Node]], comparator, optimize_fn, count, anchor, offset, file_
):
    if (
        isinstance(node, ControlFlow)
        or isinstance(node, FunctionDef)
        or isinstance(node, Method)
        or isinstance(node, Module)
        or isinstance(node, ClassDef)
    ):
        anchor = node.body

    if isinstance(node, list):
        cnode = copy(node)
        for i, a in enumerate(cnode):
            if isinstance(a, Node):
                traverse(a, comparator, optimize_fn, count, anchor, i, file_)
    else:
        for attr, val in node.__dict__.items():
            if comparator(val):
                rtn = optimize_fn(
                    count=count, node=val, anchor=anchor, offset=offset, file_=file_
                )
                setattr(node, attr, rtn)
                offset += 1
            elif isinstance(val, Node) or isinstance(val, list):
                traverse(val, comparator, optimize_fn, count, anchor, offset, file_)
