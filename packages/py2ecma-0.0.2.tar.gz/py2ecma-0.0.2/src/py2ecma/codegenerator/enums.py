import ast
from enum import Enum


class CTX(Enum):
    LOAD = 1
    STORE = 2
    DELETE = 3

    @staticmethod
    def from_ast(ctx):
        if isinstance(ctx, ast.Load):
            return CTX.LOAD
        elif isinstance(ctx, ast.Store):
            return CTX.STORE
        elif isinstance(ctx, ast.Del):
            return CTX.DELETE
        else:
            raise ValueError(f"Unknown context type {type(ctx)}")
