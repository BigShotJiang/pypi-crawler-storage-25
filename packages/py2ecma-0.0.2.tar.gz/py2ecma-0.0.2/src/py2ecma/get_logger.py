import argparse
import logging

logger = logging.getLogger(__name__)


class Colors:
    BLUE = "\x1b[94m"
    CYAN = "\x1b[96m"
    GREEN = "\x1b[92m"
    GREY = "\x1b[38;20m"
    YELLOW = "\x1b[33;20m"
    RED = "\x1b[31;20m"
    BOLD_RED = "\x1b[31;1m"
    RESET = "\x1b[0m"


STREAM_TEXT_FORMAT: str = (
    "{time_color}%(asctime)s{reset_color} {level_color}"
    "[%(levelname)s]{reset_color} %(message)s (%(filename)s:%(lineno)d)"
)


class CustomFormatter(logging.Formatter):

    FORMATS = {
        logging.DEBUG: Colors.CYAN,
        logging.INFO: Colors.BLUE,
        logging.WARNING: Colors.YELLOW,
        logging.ERROR: Colors.RED,
        logging.CRITICAL: Colors.BOLD_RED,
    }

    def format(self, record: logging.LogRecord) -> str:
        color_fmt = self.FORMATS.get(record.levelno)
        log_fmt = STREAM_TEXT_FORMAT.format(
            level_color=color_fmt, reset_color=Colors.RESET, time_color=Colors.GREEN
        )
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


def configure_logger(verbosity: int):
    logging.root.setLevel(logging.NOTSET)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(CustomFormatter())

    verbose: int = verbosity
    match verbose:
        case 0:
            stream_handler.setLevel(logging.ERROR)
        case 1:
            stream_handler.setLevel(logging.WARNING)
        case 2:
            stream_handler.setLevel(logging.INFO)
        case 3:
            stream_handler.setLevel(logging.DEBUG)
        case _:
            logger.error("Could not set log level")

    logger.addHandler(stream_handler)


__all__ = ["logger", "configure_logger"]
