import sys
import traceback
from collections import OrderedDict
from pathlib import Path
from typing import List

import py2ecma.filesystem as filesystem
from py2ecma.conf import TranspilerConfig
from py2ecma.get_logger import configure_logger, logger

from .codegenerator import nintermediate, optimizer, parser
from .lexer import syntaxtree
from .linker.packager import get_exports, package
from .watcher.autocompile import autocompile


def transpile(src: str, module: str = "", file_: str = "", progressbar=None) -> str:
    """
    :param src: Description
    :type src: str
    :param module: Description
    :type module: str
    :param file_: Description
    :type file_: str
    :param progressbar: Description
    :return: Description
    :rtype: str
    """
    ast = syntaxtree.generate_ast(src)
    if progressbar is not None:
        pgbar = progressbar(f" { module } ", len(src.splitlines()))
    else:
        pgbar = None
    logger.debug(f"Abstract Syntax Tree: {ast}")
    intermediate_code = parser.parse(ast, module, file_)
    optimizer.optimize(intermediate_code, file_)
    # intermediate_code contains a stack of intermediate js nodes
    logger.info(f"Intermediate code: {intermediate_code}")
    js_src = nintermediate.code_generation(intermediate_code)

    if progressbar is not None:
        pgbar.finish()
    return js_src


def transpiler(
    input_file: Path,
    output_file: Path,
    build_dir: Path,
    clean_build: bool = False,
    minimize: bool = False,
    recursive: bool = True,
    type_check: bool = False,
    watch: bool = False,
    raw: bool = False,
    use_progressbar: bool = False,
    externs: List[str] = [],
) -> None:
    """Transpile a input file and all it depedencies into es6/7 code

    The transpiling process will go through the following steps:

    * If clean build is enabled delete all js files in the build dir
    * If recursive build is NOT selected just run transpiler on input file,
      otherwise.
    * Map the depedency tree of import statements where the starting point is
      the input_file.
    * Transpile all files in the list of depedencies
    * Bundle files into one output js file
    * Minimize js file

    Args:
        input_file (str): String path to the input python file
        output_file (str): String path to the output js file

    """
    logger.info("Running transpiler")
    input_file = filesystem.abspath(input_file)
    logger.info("Checking existence of input file")
    filesystem.exists(input_file)
    logger.info(f"Setting up progressbar: {use_progressbar}")
    if use_progressbar:
        from .progress import progressbar
    else:
        from .progress import disabled_progressbar as progressbar
    logger.info("Setting syspath")
    filesystem.setsyspath(input_file)
    filesystem.setsyspath(filesystem.modulepath())
    logger.debug(sys.path)
    # Pre compilation steps
    if clean_build:
        # Make a clean build
        logger.info("Cleaning build directory")
        filesystem.clean_build_dir(build_dir)

    if recursive:
        # Find dependencies defined by imports
        logger.info("Finding dependencies")
        dependencies = filesystem.depth_first_search(input_file)
        logger.info(dependencies)
    else:
        logger.info("Only transpiling input file")
        dependencies = [input_file]

    # Compile/Transpile the list of source files
    logger.info(f"Input file: {input_file}")
    logger.info(f"Build directory: {build_dir}")
    src_cache = OrderedDict()
    ref_cache = dict()

    def build(dependency, progressbar):
        def __inner__():
            logger.info("Compiling source from file: " + dependency)
            abs_build_path = filesystem.buildpath(build_dir, input_file, dependency)
            src = filesystem.loadsrc(dependency)
            module = filesystem.codepath(
                filesystem.relbuildpath(input_file, dependency)
            )
            logger.info(f"JS src module to build: {module}")
            transpiled_src = transpile(
                src, module, dependency, progressbar
            ) + get_exports(src)
            src_cache[module] = transpiled_src
            filesystem.savesrc(transpiled_src, abs_build_path)

        return __inner__

    def bundler(src_cache, output_file):
        bundle = package(src_cache)
        if not minimize:
            import jsbeautifier  # type: ignore

            bundle = jsbeautifier.beautify(bundle)
        else:
            from .minimizer import minimizer

            bundle = minimizer(bundle, externs)
        filesystem.savesrc(bundle, output_file)

    for dependency in dependencies[::-1]:
        filesystem.exists(dependency)
        build_fn = build(dependency, progressbar)
        ref_cache[dependency] = build_fn
        build_fn()

    # Bundle the source files into a single javascript file
    if raw:
        for dep, src in src_cache.items():
            print(src)
    else:
        bundler(src_cache, output_file)

    if watch:
        autocompile(dependencies, src_cache, ref_cache, output_file, bundler)


class Transpiler:

    def __init__(self, config: TranspilerConfig):
        self.config = config
        configure_logger(1)

    def transpile(self) -> None:
        try:
            transpiler(
                input_file=self.config.input_file,
                output_file=self.config.output_file,
                build_dir=self.config.build_dir,
                clean_build=self.config.clean_build,
                minimize=self.config.minimize,
                recursive=self.config.recursive,
                type_check=self.config.type_check,
                watch=self.config.watch,
                raw=self.config.raw,
                use_progressbar=self.config.progressbar,
                externs=self.config.externs,
            )

        except KeyboardInterrupt:
            raise
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exc(file=sys.stdout)
            raise
