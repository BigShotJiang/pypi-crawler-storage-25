from .closure import closure_minimize

minimizer = closure_minimize
