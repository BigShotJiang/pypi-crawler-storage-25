import os
import subprocess
from enum import Enum


class CompilationLevel(Enum):
    BUNDLE = "BUNDLE"
    WHITESPACE_ONLY = "WHITESPACE_ONLY"
    SIMPLE = "SIMPLE"
    ADVANCED = "ADVANCED"


def closure_minimize(
    src: str, externs=None, compilation_level=CompilationLevel.SIMPLE
) -> str:
    """
    This will run google-closure-compiler executable on the generated js code
    """
    dir_ = os.path.dirname(__file__)
    executable = os.path.join(
        dir_, "closurejs/lib/node_modules/google-closure-compiler/cli.js"
    )

    def extern_args(externs):
        for ex in externs:
            yield "--externs"
            yield ex

    args = [
        executable,
        "--warning_level",
        "QUIET",
        "--compilation_level",
        compilation_level.value,
        "--use_types_for_optimization",
        "0",
        "--language_in",
        "ECMASCRIPT_2018",
        "--language_out",
        "ECMASCRIPT6",
        *extern_args(externs),
    ]

    p = subprocess.run(
        args, input=src.encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    if p.returncode != 0:
        print(p.stderr.decode())
        raise Exception(p)

    return p.stdout.decode()
