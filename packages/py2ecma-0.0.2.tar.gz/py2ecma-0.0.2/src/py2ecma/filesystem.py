import os
import re
import site
import sys
from pathlib import Path
from typing import Iterable, Iterator, List

from py2ecma.get_logger import logger

from .dependency.getdeps import getdeps


def clean_build_dir(build_dir: str, extension: str = ".js") -> None:
    def scantree(path: str) -> Iterator[os.DirEntry[str]]:
        """Recursively yield DirEntry objects for given directory."""
        for entry in os.scandir(path):
            if entry.is_dir(follow_symlinks=False):
                yield from scantree(entry.path)  # see below for Python 2.x
            else:
                yield entry

    if not os.path.exists(build_dir):
        return
    for file_ in scantree(build_dir):
        if file_.name.endswith(extension):
            os.unlink(file_.path)


def depth_first_search(node: Path) -> List[str]:
    s: List[Path] = []
    seen: List[Path] = []
    s.append(node)
    while len(s) != 0:
        v = s.pop()
        logger.debug(f"node: {v}")
        logger.debug(f"seen: {seen}")
        logger.debug(f"queue: {s}")
        if v not in seen:
            seen.append(v)
            for edge in getdeps(v):
                s.append(edge)

    return [os.path.normpath(s) for s in seen]


def reset_syspath() -> None:
    sys.path = site.getsitepackages()


def setsyspath(filepath: str):
    if os.path.isfile(filepath):
        path_dir = os.path.dirname(filepath)
    else:
        path_dir = filepath
    abs_path = os.path.abspath(path_dir)
    if abs_path not in sys.path:
        sys.path = [abs_path] + sys.path
    logger.info(
        f"preprending sys path {filepath}",
    )


def abspath(path):
    return os.path.abspath(path)


def codepath(path):
    return re.sub(r"^/", "", re.sub(r"^\.+", "", path))


def buildpath(build_dir, root_path, src_path):
    abs_build = os.path.abspath(build_dir)
    logger.debug('Absolute path to build directory: "{}"'.format(abs_build))
    abs_root = os.path.abspath(os.path.dirname(root_path))
    logger.debug('Absolute path to root directory: "{}"'.format(abs_root))
    abs_src = os.path.abspath(src_path)
    logger.debug('Absolute path to source directory: "{}"'.format(abs_src))
    relative = codepath(os.path.relpath(abs_src, abs_root))
    logger.debug('Relative path to between directories: "{}"'.format(relative))
    build_src_path = os.path.join(abs_build, relative.replace(".py", ".js"))
    logger.debug('Absolute path to build src: "{}"'.format(build_src_path))
    return build_src_path


def relbuildpath(root_path: str, src_path: str) -> str:
    # Relative build path between root path and src
    abs_root = os.path.abspath(os.path.dirname(root_path))
    abs_src = os.path.abspath(src_path)
    for p in [modulepath()] + sys.path:
        if abs_src.startswith(p):
            relative = abs_src.replace(p, "")
            break
    else:
        relative = os.path.relpath(abs_src, abs_root)
    return relative.replace(".py", "").replace("/", ".")


def exists(filepath: str) -> None:
    if not os.path.isfile(filepath):
        raise IOError("File does not exist: " + filepath)


def loadsrc(filepath: str) -> str:
    logger.debug("Loading source from file: " + filepath)
    with open(filepath, "r") as f:
        src = f.read()
    return src


def savesrc(src, filepath) -> None:
    logger.debug(f"Saving source to file: {filepath}")
    if os.path.dirname(str(filepath)) != "":
        os.makedirs(os.path.dirname(str(filepath)), exist_ok=True)
    with open(filepath, "w") as f:
        f.write(src)


def modulepath():
    path = os.path.join(os.path.dirname(__file__), "modules")
    logger.info(path)
    return path
