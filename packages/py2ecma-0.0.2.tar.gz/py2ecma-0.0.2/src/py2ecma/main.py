#!/usr/bin/env python
import argparse
import sys
import traceback

from py2ecma.arguments import arg_parser
from py2ecma.conf import TranspilerConfig
from py2ecma.transpiler import Transpiler


def run(args: argparse.Namespace) -> int:
    """Entrypoint to the application.

    Import and run your code here.
    """
    # TODO: Implement call to library code
    transpiler_config = TranspilerConfig(args)
    transpiler = Transpiler(transpiler_config)
    try:
        transpiler.transpile()
    except:
        return 1
    return 0
    return 0


def main() -> int:
    """`main` function

    Handles argument parsing with `argparse` hands it on to the `run`
    function that should call the library code as an application
    """

    args = arg_parser().parse_args()
    try:
        return run(args)
    except Exception:
        # Catch all exception that will ensure that the exception is printed and
        # that the error code is returned.
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
