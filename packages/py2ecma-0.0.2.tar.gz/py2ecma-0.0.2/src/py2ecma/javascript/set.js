class BaseSet extends Set {

    static call(_, s) {
        return new this(s);
    }

    __len__() {
        return this.size;
    }
    __contains__(x) {
        return this.has(x);
    }
    isdisjoint(other) {
        return new Set([...this].filter(x => other.has(x))).size === 0;
    }
    issubset(other) {
        for (var elem of this) {
            if (!other.has(elem)) {
                return false;
            }
        }
        return true;
    }
    __le__(other) {
        return this.issubset(other);
    }
    __lt__(other) {
        return this.issubset(other) && this.size != other.size;
    }
    issuperset(other) {
        for (var elem of other) {
            if (!this.has(elem)) {
                return false;
            }
        }
        return true;
    }
    __ge__(other) {
        return this.issuperset(other);
    }
    __gt__(other) {
        return this.issuperset(other) && this.size != other.size;
    }
    union(...others) {
        let n = this.copy();
        for (var o of others) {
            for (var e of o) {
                n.add(e);
            }
        }
        return n;
    }

    __or__(other) {
        return this.union(other);
    }
    intersection(...others) {
        let n = set.call(this);
        let [o, ...other] = others;
        for (var e of o) {
            if (this.has(e)){
                n.add(e);
            }
        }
        if (other.length > 0) {
            return n.intersection(...other);
        } else {
            return n;
        }
    }
    __and__(other) {
        return this.intersection(other);
    }
    difference(...others) {
        let n = this.copy();
        for (let o of others) {
            for (let elem of o) {
                n.delete(elem);
            }
        }
        return n;
    }
    __sub__(other) {
        return this.difference(other);
    }
    symmetric_difference(other) {
        let n = this.copy();
        for (let elem of other) {
            if (n.has(elem)) {
                n.delete(elem);
            } else {
                n.add(elem);
            }
        }
        return n;
    }
    __xor__(other) {
        return this.symmetric_difference(other);
    }
    copy() {
        return BaseSet.call(this, this);
    }

}


class set extends BaseSet {
    copy() {
        return set.call(this, this);
    }
    update(...others) {
        for (let o of others) {
            for (let e of o) {
                this.add(e);
            }
        }
    }
    intersection_update(...others) {
        var other = this.intersection(...others);
        for (let e of other.symmetric_difference(this)) {
            if (this.has(e)){
                this.delete(e);
            }
        }
    }
    difference_update(...others) {
        for (let o of others) {
            for (let e of o) {
                if (this.has(e)) {
                    this.delete(e);
                }
            }
        }
    }
    __isub__(other) {
        this.difference_update(other);
    }
    symmetric_difference_update(other) {
        for (let e of other) {
            if (this.has(e)) {
                this.delete(e);
            } else {
                this.add(e);
            }
        }
    }
    remove(elem) {
        if (this.has(elem)) {
            this.delete(elem);
        } else {
            throw KeyError.call(this, elem);
        }
    }
    discard(elem) {
        this.delete(elem);
    }
    pop() {
        for(let o of this) {
            this.delete(o);
            return o;
        }
    }
    clear() {
        super.clear();
    }
    __eq__(other) {
        return other instanceof Set && other.size == this.size && all(map(x => this.has(x), other));
    }
}


class frozenset extends BaseSet{
    constructor(elems) {
        super(elems);
        this.add = () => { throw AttributeError.call(this, "\'frozenset\' object has no attribute \'add\'"); }
        this.delete = () => { throw AttributeError.call(this, "\'frozenset\' object has no attribute \'delete\'"); }
    }
    copy() {
        return frozenset.call(this, this);
    }
    union(...others) {
        let n = super.copy();
        for (var o of others) {
            for (var e of o) {
                n.add(e);
            }
        }
        return frozenset.call(this, n);
    }
    difference(...others) {
        let n = super.copy();
        for (let o of others) {
            for (let elem of o) {
                n.delete(elem);
            }
        }
        return frozenset.call(this, n);
    }
    symmetric_difference(other) {
        let n = super.copy();
        for (let elem of other) {
            if (n.has(elem)) {
                n.delete(elem);
            } else {
                n.add(elem);
            }
        }
        return frozenset.call(this, n);
    }
    clear() {
        throw AttributeError.call(this, "\'frozenset\' object has no attribute \'clear\'");
    }

}
