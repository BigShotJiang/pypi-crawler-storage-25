Object.defineProperty(String.prototype, '__add__', {
    value(y) {
        return this + y;
    }
});
Object.defineProperty(String.prototype, '__mul__', {
    value(y) {
        return this.repeat(y);
    }
});
Object.defineProperty(String.prototype, '__len__', {
    value() {
        return this.length;
    }
});
Object.defineProperty(String.prototype, 'format', {
    value() {
        var args = arguments;
        var index = 0;
        return this.replace(/\{(\w*)\}/g, function(match, k) {
            if (k == "") {
                k = index++;
            }
            if (k == +k) {
                return args[k] == undefined ? match: str(args[k])
            }
            return typeof args[k] != 'undefined'
                ? args[k]
                : match;
        });
    }
});
Object.defineProperty(String.prototype, 'lower', {
    value() {
        return this.toLowerCase();
    }
});

Object.defineProperty(String.prototype, 'capitalize', {
    value() {
        return this.charAt(0).toUpperCase() + this.slice(1)
    }
});

Object.defineProperty(String.prototype, '_split', {
    value(...arg) {
        return list(this.split(...arg));
    }
});

Object.defineProperty(String.prototype, '__getitem__', {
    value(...slice) {
        if (isNaN(slice)) {
            return this.slice(...slice);
        } else {
            return this.charAt(slice);
        }
    }
});
const str = (s) => { if (s === null) { return "None"; } else { return s.toString(); } };
