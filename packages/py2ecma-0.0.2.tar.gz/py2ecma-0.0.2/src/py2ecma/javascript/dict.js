class Dict extends Map {
    constructor(...__args__) {
        super();
        var objs, kwargs;
        [...objs] = Array.from(__args__).slice(0, __args__.length-1);
        ({...kwargs} = Object.assign({}, __args__[__args__.length - 1]));

        if (objs !== undefined && objs.length > 1) {
         throw new TypeError();
        } else if (objs !== undefined && objs.length == 1){
            var obj = objs[0];
            if (isinstance(obj, dict)){
                for (var k of __Iterator__(obj.items())){
                    this.set(k[0], k[1]);
                }
            } else if (Array.isArray(obj)) {
                for (var i=0;i < obj.length; i += 1 ) {
                    this.set(obj[i][0].toString(), obj[i][1]);
                }

            } else {
                for (var prop in objs[0]){
                    this.set(prop.toString(), objs[0][prop]);
                }
            }
        } else if (kwargs !== undefined) {
            if (kwargs.hasOwnProperty('__iter__')) {
                for (var prop of __Iterator__(kwargs)){
                    this.set(prop.toString(), kwargs[prop]);
                }
            } else if(kwargs != null && typeof kwargs[Symbol.iterator] === 'function') {
                for (var prop of kwargs){
                    this.set(prop.toString(), kwargs[prop]);
                }
            } else {
                 for (var prop in kwargs){
                    this.set(prop.toString(), kwargs[prop]);
                }
            }
        }

        //this.values = this.values.bind(this);
        //this.keys = this.keys.bind(this);
        //this.items = this.items.bind(this);
        //this.set = this.set.bind(this);
        //this.__contains__ = this.__contains__.bind(this);
    }

    set(key, value) {
        super.set(key.toString(), value);
        this[key.toString()] = value;
    }

    __setitem__(key, value) {
        if (Array.isArray(key)) {
            key = "["+key.toString()+"]";
        }
        this.set(key.toString(), value);
    }
    __getitem__(key) {
        if (Array.isArray(key)) {
            key = "["+key.toString()+"]";
        }
        return super.get(key.toString());
    }
    __delitem__(key) {
        //delete this.key.toString();
        super.delete(key.toString());
    }
    __len__() {
        return super.size;
    }
    __contains__(item) {
        return super.has(item.toString());
    }
    clear() {
        super.clear();
    }
    copy() {
        return dict(this);
    }
    items() {
        return super.entries();
    }
    keys() {
        return super.keys();
    }
    values() {
        return super.values();
    }
    pop(key, _default) {
        throw new NotImplementedError()

    }
    popitem() {
        throw new NotImplementedError()
    }
    setdefault(key, _default) {
        throw new NotImplementedError()
    }
    update(other, kwargs) {
        other.forEach((val, key) => this.set(key, val));
        return null;
    }
    to_object() {
        return Object.assign({}, this);
    }
    __bool__() {
        return this.__len__() > 0;
    }
    __str__() {
        var kv = Array.from(this.entries()).map(x => x[0].toString() + ": " + x[1].toString());
        return "{" + kv.join(", ") + "}";
    }
    __eq__(other) {
        return other == this;
    }
    __ne__(other) {
        return !this.__eq__(other);
    }
    toString() {
        return this.__str__();
    }
}

var dict = (obj, kwargs) => new Dict(obj, kwargs);
dict.kwargs = (...args) => {
    return dict(...args);
}

dict.prototype = Dict.prototype;
