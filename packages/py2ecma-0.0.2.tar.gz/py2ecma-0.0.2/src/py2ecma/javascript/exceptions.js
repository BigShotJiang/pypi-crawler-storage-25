class BaseException {

    constructor(...args) {
        this.args = __list__(...args);
    }
    static __new__(...__args__){
        return new this(...__args__);
    }
    static call(self, ...__args__) {
        var cls = this.__new__(...__args__);
        cls.__init__(...__args__);
        return cls;
    }
    __init__(msg="") {
        this.msg = msg;
    }
    __getattr__(prop) {
        return this[prop];
    }
    __getattribute__(prop) {
        var a = this[prop];
        if (a == undefined) {
            return this.__getattr__(prop);
        } else {
            return a;
        }
    }
    toString(){
        return this.constructor.name + "(" + this.msg +  ")" ;
    }
    valueOf() {
        return this.toString();
    }
}

class Exception extends BaseException {}

class AssertionError extends Exception {}

class AttributeError extends Exception {}

class IndexError extends Exception {}

class KeyError extends Exception {}

class ValueError extends Exception {}

class _TypeError extends Exception {}

class ImportError extends Exception {}

class OverflowError extends Exception {}

class NotImplemented extends Exception {}

class NotImplementedError extends NotImplemented {}

class StopIteration extends Exception {}
