function __gt__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x > y: x.__gt__(y);}
function __lt__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x < y: x.__lt__(y);}
function __ge__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x >= y: x.__ge__(y);}
function __le__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x <= y: x.__le__(y);}
function __eq__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x == y: x.__eq__(y);}
function __ne__(x, y) {return (typeof x == "number" || typeof x == "string" || typeof x == 'boolean' || x === null) ? x != y: x.__ne__(y);}
function __contains__(x, y) {return (typeof y == "string") ? y.includes(x) : (y).__contains__(x);}
function __notcontains__(x, y) {return !__contains__(x, y);}
function __is__(x, y) {return (x === y);}
function __isnot__(x, y) {return (x !== y);}
function bool(x) {
    if (typeof(x) == "boolean"){
        return x;
    } else if (typeof x == "number") {
        return x != 0;
    } else if (typeof x == "string") {
        return x.length != 0
    } else if (x == null) {
        return false;
    } else {
        return x.__bool__();
    }
}
function __uadd__(x) {
    if (typeof x == "number") {
        return +x;
    } else {
        x.__uadd__();
        return x;
    }
}
function __usub__(x) {
    return (typeof x.__neg__ == 'function') ?  x.__neg__(): -x;}

function __iadd__(x, y) {
    if (typeof x == "number") {
        x = x + y;
        return x;
    } else {
        x.__iadd__(y);
        return x;
    }
}
function __isub__(x, y) {
    if (typeof x == "number") {
        x = x - y;
        return x;
    } else {
        x.__isub__(y);
        return x;
    }
}
function __imul__(x, y) {(typeof x == "number") ? x = x * y: x.__imul__(y);}
function __itruediv__(x, y) {(typeof x == "number") ? x =  x / y: x.__itruediv__(y);}
function __ifloordiv__(x, y) {(typeof x == "number") ? x =  Math.floor(x/y): x.__ifloordiv__(y);}
function __imod__(x, y) {(typeof x == "number") ? x = x % y : x.__imod__(y);}
function __idivmod__(x, y) {(typeof x == "number") ? x =  Math.floor(x % y): x.__idivmod__(y);}
function __ipow__(x, y) {(typeof x == "number") ? x = x ** y: x.__ipow__(y);}

function __add__(x, y) {return (typeof x == "number" || typeof x == "string") ? x + y: x.__add__(y);}
function __sub__(x, y) {return (typeof x == "number") ? x - y: x.__sub__(y);}
function __mul__(x, y) {return (typeof x == "number") ? x * y: x.__mul__(y);}
function __truediv__(x, y) {return (typeof x == "number") ? x / y: x.__truediv__(y);}
function __floordiv__(x, y) {return (typeof x == "number") ? Math.floor(x/y): x.__floordiv__(y);}
function __mod__(x, y) {return (typeof x == "number") ? ((x % y)+y)%y : x.__mod__(y);}
function __divmod__(x, y) {
    return (typeof x == "number") ? tuple([Math.floor(x / y), __mod__(x, y)]): x.__divmod__(y);
}
function __pow__(x, y) {return (typeof x == "number") ? x ** y: x.__pow__(y);}
function __lshift__(x, y) {return (typeof x == "number") ? x << y: x.__lshift__(y);}
function __rshift__(x, y) {return (typeof x == "number") ? x >> y: x.__rishift__(y);}
function __and__(x, y) {return (typeof x == "number") ? x & y: x.__and__(y);}
function __xor__(x, y) {return (typeof x == "number") ? x ^ y: x.__xor__(y);}
function __or__(x, y) {return (typeof x == "number") ? x | y: x.__or__(y);}
function __invert__(x) {return (typeof x == "number") ? ~x : x.__invert__();}
function __not__(x) {return (typeof x == "object") ? x.__not__(): !x;}
function __del__(x) {x.__del__();}

var int = parseInt;
var float = parseFloat;
var print = (...args) => { console.log(...(args.map(x => {
    if (x !== undefined && x !== null) {
        return x;
    } else {
        return x;
    }
}))); }
var dir = console.dir;
function abs(x) {
    return Math.abs(x);
}
//help()
function min(n) {
    return arguments.length == 1 ? Math.min.apply (null, n) : Math.min.apply (null, arguments);
};

function setattr(obj, name, value) {
  if ("__setattr__" in obj) {
    obj.__setattr__(name, value);
  } else {
    obj[name] = value;
  }
}
const all = (iterable) => {
    for (let i of __Iterator__(iterable)) {
        if (bool(i) !== true) {
            return false;
        }
    }
    return true;
}
//dir()
//hex()
//next()
//slice()
//any()
function divmod(x, y) {
    return __divmod__(x, y);
}
//id()
//object()
//sorted()
function sorted(l) {
    let a;
    let r = (__list_comprehension__((a) => (a), [__comprehension__(a, l)]));
    r.sort();
    return r;
}
//ascii()
function enumerate(a) {
    return a.entries();
}
//input()
//oct()
//staticmethod()
//bin()
//eval()
//open()
//exec()
function isinstance(object, classinfo) {
    switch(classinfo) {
        case int:
            return Number.isInteger(object);
        case float:
            return typeof(object) === "number" && !Number.isInteger(object);
        case str:
            return typeof(object) === "string";
        case bool:
            return typeof(object) == "boolean"
        default:
            if (classinfo instanceof Tuple) {
                if (classinfo.length == 0) {
                    return false;
                }
                var [chead, ...ctail] = classinfo;
                return isinstance(object, chead) || isinstance(object, tuple(ctail));
            } else {
                return object instanceof classinfo;
            }
    }
}
//ord()
//bytearray()
//filter()
function sum(arr, start) {
   var num = Object.is(start, undefined) ? 0 : start;
   for (var i = 0; i < arr.length; i++) {
       num += (typeof arr[i] == 'number') ? arr[i] : 0;
   }
   return num;
};
function issubclass(c, other) {
    if (c !== null && c !== undefined) {
        return c.prototype instanceof other;
    } else {
        return false;
    }
}
//pow()
//bytes()
//iter()

class Tuple extends Array {
    __getitem__(slice) {
        if (isNaN(slice)) {
            if (slice.lower === null) {
                var lower = 0;
            } else {
                var lower = slice.lower;
            }
            if (slice.upper === null) {
                var upper = this.length;
            } else {
                var upper = slice.upper;
            }
            if (slice.step === null) {
                return __list__(...this.slice(lower, upper));
            } else {
                var step = slice.step;
                var A = __list__();
                var i = (step > 0) ? 0 : this.length - 1;
                for (; i < this.length && i >= 0; i += step){
                    A.push(this[i]);
                }
                return A;
            }
        } else {
            return this[slice];
        }
    }
    __add__(x) {
        return this.concat(x);
    }

    __contains__(x) {
        return super.includes(x);
    }

    toString() {
        return "(" + this.join(", ") + ")";
    }

}
var tuple = new Proxy(Tuple, {
    apply(target, thisArgs, argslist) {
        if (argslist[0].length == 1) {
            var a = new target();
            a.push(...argslist[0]);
        } else {
            var a = new target(...argslist[0]);
        }
        return Object.freeze(a);
    },
});
//callable()
//format()
function type(obj) {
    return typeof obj;

}
//chr()
//frozenset()
function range(start, end, step) {
    var _end = end || start;
    var _start = end ? start : 0;
    var _step = step || 1;
    return list((_end - _start) / _step).fill(0).map((v, i) => _start + (i * _step));
}

//vars()
function getattr(obj, name) {
  if ("__getattribute__" in obj) {
    return obj.__getattribute__(name);
  } else if ("__getattr__" in obj) {
    return obj.__getattr__(name);
  } else {
    return obj[name];
  }
}

function hasattr(obj, attr) {
    return obj.hasOwnProperty(attr);
}
//locals()
//repr()
function zip(...arrays) {
    return Array.apply(null,Array(arrays[0].length)).map(function(_,i){
        return arrays.map(function(array){return array[i]})
    });
}

//compile()
//globals()
function map(func, iterable) {
    var l = __list__();
    for (let x of iterable) {
        l.append(func(x));
    }
    return l;
}
//reversed()
//__import__()
//complex()
function max(n) {
    return arguments.length == 1 ? Math.max.apply (null, n) : Math.max.apply (null, arguments);
};
function round(number, ndigits) {
    if (ndigits == undefined) {
        return Math.round(number);
    } else {
        var factor = Math.pow(10, ndigits);
        return Math.round(number * factor) / factor;
    }
}
//delattr()
//hash()
//memoryview()
//set()

function len(obj) {
    return obj.__len__();
}

function del(obj, key) {
    obj.__delitem__(key);
}

var __imported__ = {};
function __import__(module) {
    if (module === 'py2ecma') {
        return {}
    }
    if (__imported__[module] === undefined) {
        if (__exports__[module] === undefined &&
            __exports__[module] === undefined) {
            throw new ImportError('Module \"' + module + "\" was not found");
        }
       __imported__[module] = __exports__[module]();
    }
    return __imported__[module];
}

class __kwargs__ {
    constructor(kwargs) {
        this.value = kwargs;
    }
}

function __attribute__(cls, attr, value) {
    Object.defineProperty(cls,
                          attr,
                          {value: value,
                           configurable: true,
                           enumerable: true,
                           writable: true});
}
function __super__(t, o) {

}
