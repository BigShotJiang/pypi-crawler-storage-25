class List extends Array {

    constructor(...args){
        super(...args);

        this.append = this.append.bind(this);
        this.clear = this.clear.bind(this);
        this.copy = this.copy.bind(this);
        this.count = this.count.bind(this);
        this.extend = this.extend.bind(this);
        this.index = this.index.bind(this);
        this.insert = this.insert.bind(this);
        this.pop = this.pop.bind(this);
        this.reverse = this.reverse.bind(this);
        this.remove = this.remove.bind(this);
        this.sort = this.sort.bind(this);
        this.sort.kwargs = (...__args__) => {
            var key, reverse;
            [key, reverse] = Array.from(__args__).slice(0, __args__.length-1);
            ({key=null, reverse=false} = Object.assign({key:key, reverse:reverse}, __args__[__args__.length - 1]));
            this.sort(key, reverse);
        };
    }

    __getitem__(slice){
        if (isNaN(slice)) {
            if (slice.lower === null) {
                var lower = 0;
            } else {
                var lower = slice.lower;
            }
            if (slice.upper === null) {
                var upper = this.length;
            } else {
                var upper = slice.upper;
            }
            if (slice.step === null) {
                return __list__(...this.slice(lower, upper));
            } else {
                var step = slice.step;
                var A = __list__();
                var i = (step > 0) ? 0 : this.length - 1;
                for (; i < this.length && i >= 0; i += step){
                    A.push(this[i]);
                }
                return A;
            }
        } else {
            return this[slice];
        }
    }

    __setitem__(key, value) {
        this[key] = value;
    }

    __contains__(item) {
        return super.includes(item);
    }
    append(x){
        this.push(x);
    }
    extend(iterable) {
        this.splice(this.length, 0, ...iterable);
    }
    insert(i, x) {
        this.splice(i, 0, x);
    }
    remove(x) {
        var i = this.index(x);
        this.splice(i, 1);
    }
    pop(i) {
        if (isNaN(i)) {
            return super.pop();
        } else {
            return this.splice(i, 1)[0];
        }
    }
    clear() {
        this.splice(0, this.length)
    }
    index(x, start, end) {
        var index = this.indexOf(x, start);
        if (index === -1) {
            throw new ValueError()
        } else if (end !== undefined && index > end) {
            throw new ValueError()
        }
        return index;
    }
    count(x) {
        return this.filter(function(w) { return x == w; }).length;
    }
    sort(key=null, reverse=false) {
        if (key === null) {
            super.sort(function(x, y){
                if (x < y) {
                    return -1;
                }
                if (x > y) {
                    return 1;
                }
                return 0;
            });
        } else {
            super.sort(function(x, y){
                if (x[key] < y[key]) {
                    return -1;
                }
                if (x[key] > y[key]) {
                    return 1;
                }
                return 0;
            })
        }
        if (reverse === true) {
            super.reverse();
        }
    }

    copy() {
        return this.slice();
    }

    reverse() {
        super.reverse();
    }
    __len__() {
        return this.length;
    }
    __iter__() {
        return this[Symbol.iterator]()
    }
    __next__(){
        var value = self.next();
        if (value.done) {
            throw new StopIteration();
        } else {
            return value.value;
        }
    }
    __add__(l) {
        return this.concat(l);
    }
    __not__() {
        return this.length == 0;
    }
    __str__() {
        return "[" + this.join(", ") + "]"
    }
    toString() {
        return this.__str__();
    }
}

var __list__ = (...obj) => {
    if (obj.length > 1) {
        return new List(...obj);
    } else {
        let a = new List();
        a.push(...obj);
        return a;
    }
}

var list = (...obj) => {
    if (Array.isArray(obj[0]) && obj.length == 1) {
        return __list__(...obj[0]);
    } else if(obj[0] instanceof BaseSet && obj.length == 1) {
        return __list__(...obj[0]);
    } else {
        return new List(...obj);
    }
}
list.prototype = List.prototype;

function __Iterator__(obj) {
    if (obj.hasOwnProperty('__iter__')) {
        var iterator = {
            next: function() {
                try {
                    return {'value': obj.next(), 'done': false};
                } catch (e) {
                    if (e instanceof StopIteration) {
                        return {'value': null, 'done': true};
                    }
                    else {
                        throw e;
                    }
                }
            }
        }
        iterator[Symbol.iterator] = function() { return obj.__iter__(); };
        return iterator;
    } else {
        return obj;
    }
}
