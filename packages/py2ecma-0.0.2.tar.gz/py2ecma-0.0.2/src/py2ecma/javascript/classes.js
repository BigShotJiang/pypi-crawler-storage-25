class BaseClass {
    constructor(...__args__){
        this.__init__ = this.__init__.bind(this);
        this.__getattribute__ = this.__getattribute__.bind(this);
        this.__str__ = this.__str__.bind(this);
        this.toString = this.toString.bind(this);
        //this.__init__(...__args__);
    }
    static call(self, ...__args__) {
        var cls = this.__new__(...__args__);
        //cls.__init__(...__args__);
        return cls;
    }
    static __new__(...__args__){
        let a = new this(...__args__);
        a.__init__(...__args__);
        return a;
    }
    static get __py_class__() {
        return true;
    }
    __init__(...__args__) {

    }
    __getattr__(prop) {
        return this[prop];
    }
    __getattribute__(prop) {
        var a = this[prop];
        if (a == undefined) {
            return this.__getattr__(prop);
        } else {
            return a;
        }
    }
    __setattr__(prop, value) {
        this[prop] = value;
    }
    __del__() {
        //TODO
    }

    __repr__() {
    }

    __str__() {
        return this.constructor.name;
    }
    toString() {
        return this.__str__();
    }
    valueOf() {
        return this.toString();
    }

    __bytes__() {}

    __format__(format_spec) {}
    __lt__(other) {}
    __le__(other) {}
    __eq__(other) {}
    __ne__(other) {}
    __gt__(other) {}
    __ge__(other) {}

    __hash__() {}

    __delattr__(name) {}
    __dir__() {}

    __len__() {}
    __getitem__(key) {}
    __setitem__(key) {}
    __delitem__(key) {}
    __iter__() {}
    __reversed__() {}
    __contains__(item) {}
    __bool__() { return true; }
    __not__() { return !this.__bool__(); }


    to_object() {
        return Object.assign({}, this);
    }
    __meta_class__() {
        return {
            __dict__: dict(zip(Object.keys(this), Object.values(this))),
            __name__: this.constructor.name
        }
    }
}
Object.defineProperty(
    BaseClass.prototype,
    '__class__',
    {
        get() {
            return this.__meta_class__()
        }
    }
);
class object extends BaseClass {
    static __getattribute__(obj, prop) {
        var a = obj[prop];
        if (a == undefined) {
            return obj.__getattr__;
        } else {
            return a;
        }
    }


}

function _cls_extend(destination, source) {
  for (let k of Object.getOwnPropertyNames(source)) {
    if (source.hasOwnProperty(k)) {
      destination[k] = source[k];
    }
  }
  return destination; 
}


function proxyClass(cls) {
    return new Proxy(cls, {
        apply(target, thisArg, argumentsList) {
            var _cls = target.__new__(...argumentsList);
            _cls.__init__(...argumentsList);
            return proxyCls(_cls);
        },
        get (target, property, receiver) {
            if (property == 'call') {
                return (self, ...args) => {
                    var _cls = receiver.__new__(...args);
                    return proxyCls(_cls);
                }
            } else if (property == 'kwargs') {
                return (...args) => {
                    var _cls = receiver.__new__(...args);
                    return proxyCls(_cls);
                }
            } else {
                return target[property];
            }
        }
    });
}

function proxyCls(_cls) {
    return new Proxy(_cls, {
        get(target, propKey) {
            if (propKey == "is_proxy") {
                return true;
            }
            return target.__getattribute__(propKey);
        },
        set(target, propKey, value) {
            target.__setattr__(propKey, value);
            return true;
        }
    });
}
