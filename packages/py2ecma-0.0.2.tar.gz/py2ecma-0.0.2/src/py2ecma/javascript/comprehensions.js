var __comprehension__ = (target, iter, ifs=(()=>true),is_async=false) => { return {
    'target': target,
    'iter': iter,
    'ifs': ifs,
    'is_async': is_async}};

var __list_comprehension__ = (elt, generators, li) => {
    if (li === undefined) {
        li = __list__();
    }
    if (generators.length > 1) {
        var generator = generators[0];
        for (let el of __Iterator__(generator.iter)) {
            if (generator.ifs(el)) {
                var tail = generators.slice(1);
                tail[0].iter = el;
                __list_comprehension__(elt, tail, li);
            }
        }
    } else {
        var generator = generators[0];
        for (let el of __Iterator__(generator.iter)) {
            if (generator.ifs(el)) {
                li.append(elt(el));
            }
        }
    }
    return li;
}

var __dict_comprehension__ = (elt, val, generators, li) => {
    if (li === undefined) {
        var li = dict();
    }
    if (generators.length > 1) {
        var generator = generators[0];
        for (let el of __Iterator__(generator.iter)) {
            if (generator.ifs(el)) {
                var tail = generators.slice(1);
                tail[0].iter = el;
                __dict_comprehension__(elt, val, tail, li);
            }
        }
    } else {
        var generator = generators[0];
        for (let el of __Iterator__(generator.iter)) {
            if (generator.ifs(el)) {
                li.__setitem__(elt(el), val(el));
            }
        }
    }
    return li;
}
