import ast


def generate_ast(src: str) -> ast.Module:
    tree = ast.parse(src)
    return tree
