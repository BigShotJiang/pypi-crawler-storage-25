#!/usr/bin/env python
# WRAP_STDERR=true
import argparse
import sys

from py2ecma.conf import TranspilerConfig
from py2ecma.transpiler import Transpiler


def main():
    parser = argparse.ArgumentParser()

    # Positional arguments; required
    parser.add_argument(
        "input",
        metavar="input.py",
        help="main .py file to transpile. The transpiler"
        " will translate every import recursively from this"
        " entry point.",
    )
    # Options
    parser.add_argument(
        "-o",
        "--output",
        dest="output_file",
        default="./bundle.js",
        metavar="output.js",
        help="output javascript file. The intermediate output"
        " will be bundled together into this file.",
    )
    parser.add_argument(
        "-b",
        "--build-dir",
        dest="build_dir",
        default="./.build/",
        help="build directive, all intermediate output from"
        " transpiled files will end up here. While abiding to"
        " the directory stucture. Will default to .build in"
        " the current directory.",
        metavar="dir",
    )
    parser.add_argument(
        "-c",
        "--clean",
        action="store_true",
        dest="clean",
        default=False,
        help="clean the build directory before transpiling."
        " This will trigger a complete compile of all"
        " source files",
    )
    parser.add_argument(
        "-d",
        "--dont-follow-imports",
        action="store_false",
        dest="recursive",
        default=True,
        help="don't follow imports in the python input file."
        " Only transpile single file.",
    )
    parser.add_argument(
        "-e",
        "--externs",
        required=False,
        nargs="+",
        dest="externs",
        default=list(),
        help="Extern files for the closure compiler, can be a list of files",
    )
    parser.add_argument(
        "-m",
        "--minimize",
        action="store_true",
        dest="minimize",
        default=False,
        help="minimize the output file.",
    )
    parser.add_argument(
        "-p",
        "--disable-progressbar",
        action="store_true",
        dest="disable_progressbar",
        default=False,
        help="Disable progressbar.",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        dest="quiet",
        default=False,
        help="don't print status messages to stdout.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        dest="verbose",
        default=False,
        help="set the logging level to info.",
    )
    parser.add_argument(
        "-vv",
        "--very_verbose",
        action="store_true",
        dest="very_verbose",
        default=False,
        help="set the logging level to debug.",
    )
    parser.add_argument(
        "-w",
        "--watch",
        action="store_true",
        dest="watch",
        default=False,
        help="watch the input file and depedencies for changes" " and recompile.",
    )
    parser.add_argument(
        "-r",
        "--raw",
        action="store_true",
        dest="raw",
        default=False,
        help="Output the compiled js to console without" " runtime environment",
    )
    parser.add_argument(
        "-t",
        "--type-check",
        action="store_true",
        dest="type_check",
        default=False,
        help="enable python3.x typechecking with mypy.",
    )

    args = parser.parse_args()
    transpiler_config = TranspilerConfig(args)
    transpiler = Transpiler(transpiler_config)
    try:
        transpiler.transpile()
    except:
        return 1
    return 0


if __name__ == "__main__":
    main()
