import colored
import progressbar as pb
from python_utils import converters

c_def = colored.fg(39)
c_green = colored.fg("green")
c_white = colored.fg("white")


def custom_len(value):
    # These characters take no space
    characters = {
        c_def: 0,
        c_green: 0,
        c_white: 0,
    }

    total = 0
    for c in value:
        total += characters.get(c, 1)

    return total


class CenterTextBar(pb.Bar):

    def __init__(
        self,
        marker="#",
        left="|",
        right="|",
        fill=" ",
        fill_left=True,
        text="",
        **kwargs,
    ):
        super().__init__(
            marker=marker,
            left=left,
            right=right,
            fill=fill,
            fill_left=fill_left,
            **kwargs,
        )
        self.center_text = text

    def __call__(self, progress, data, width):
        """Updates the progress bar and its subcomponents"""

        left = converters.to_unicode(self.left(progress, data, width))
        right = converters.to_unicode(self.right(progress, data, width))
        width -= progress.custom_len(left) + progress.custom_len(right)
        width -= len(self.center_text)
        marker = converters.to_unicode(self.marker(progress, data, width))
        fill = converters.to_unicode(self.fill(progress, data, width))

        if self.fill_left:
            marker = marker.ljust(width, fill)
        else:
            marker = marker.rjust(width, fill)
        marker_split = int(len(marker) / 2)
        left_marker = marker[:marker_split]
        right_marker = marker[marker_split:]
        return (
            c_def
            + left
            + c_green
            + left_marker
            + c_def
            + self.center_text
            + c_green
            + right_marker
            + c_def
            + right
            + c_white
        )


def progressbar(text, max_value):
    widgets = [
        pb.CurrentTime(format="%(current_time)s"),
        CenterTextBar(left=" [", right="] ", text=text),
        pb.AdaptiveETA(),
    ]
    bar = pb.ProgressBar(
        widgets=widgets, max_value=max_value, len_func=custom_len
    ).start()
    return bar


def disabled_progressbar(test, max_value):
    class DisabledProgressbar:

        def update(*args, **kwargs):
            pass

        def start(*args, **kwargs):
            pass

        def finish(*args, **kwargs):
            pass

    return DisabledProgressbar()
