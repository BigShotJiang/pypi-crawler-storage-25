def loadjs(js, filepath):
    pass


def js(js: str):
    pass


def boundmethod(func):
    return func
