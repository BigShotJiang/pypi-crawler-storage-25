from py2ecma import js


def copy(x):
    js("""
        var a;
        if (isinstance(x, dict)) {
            return dict(x);
        } else if (x.is_proxy) {
            a = Object.assign({__proto__: x.__proto__}, x);
            return proxyCls(a);
        } else {
            a = new x.constructor();
            var b = Object.keys(x).filter((p) => {
                let attr = x[p];
                let not_f = !(typeof attr == "function");
                let py_cls = isinstance(attr, BaseClass);
                let py_obj = attr !== null && attr !== undefined ? attr.__py_class__ === true: false;
                return not_f || py_cls || py_obj;
            });
            b.forEach((k) => { a[k] = x[k]; });
            return a;
        }
    """)


def deepcopy(x):
    js("""
    function recursiveDeepCopy(o) {
        var newO, i;
        if (typeof o !== 'object') {
            return o;
        } else if (!o) {
            return o;
        } else if ('[object Array]' === Object.prototype.toString.apply(o)) {
            newO = [];
            for (i = 0; i < o.length; i += 1) {
                newO[i] = recursiveDeepCopy(o[i]);
            }
            return newO;
        } else {
            newO = Object.assign(o.__proto__, o);
            for (i in o) {
                if (o.hasOwnProperty(i)) {
                    newO[i] = recursiveDeepCopy(o[i]);
                }
            }
            return newO;
        }
    }
    return recursiveDeepCopy(x);
    """)
