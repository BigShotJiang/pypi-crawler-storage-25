from typing import Dict

from py2ecma import js


def dump(
    obj,
    fp,
    *,
    skipkeys=False,
    ensure_ascii=True,
    check_circular=True,
    allow_nan=True,
    cls=None,
    indent=None,
    separators=None,
    default=None,
    sort_keys=False,
    **kw,
):
    pass


def dumps(
    obj,
    *,
    skipkeys=False,
    ensure_ascii=True,
    check_circular=True,
    allow_nan=True,
    cls=None,
    indent=None,
    separators=None,
    default=None,
    sort_keys=False,
    **kw,
):
    if isinstance(obj, Dict):
        obj = obj.to_object()
    json = js("JSON")
    return json.stringify(obj)


def load(
    fp,
    *,
    cls=None,
    object_hook=None,
    parse_float=None,
    parse_int=None,
    parse_constant=None,
    object_pairs_hook=None,
    **kw,
):
    pass


def _to_py(s):
    is_object = js("typeof s === 'object'")
    is_array = js("s instanceof Array")
    if is_object and not is_array:
        # Convert to dict, make sure entries are converted to py
        s = dict(s)
        s = {k: _to_py(v) for k, v in s.items()}
    elif is_array:
        # Convert to list, make sure entries are converted to py
        s = list(s)
        s = [_to_py(i) for i in s]
    return s


def loads(
    s,
    *,
    encoding=None,
    cls=None,
    object_hook=None,
    parse_float=None,
    parse_int=None,
    parse_constant=None,
    object_pairs_hook=None,
    **kw,
):
    json = js("JSON")
    objs = _to_py(json.parse(s))
    return objs


class JSONDecoder:
    pass


class JSONEncoder:
    pass
