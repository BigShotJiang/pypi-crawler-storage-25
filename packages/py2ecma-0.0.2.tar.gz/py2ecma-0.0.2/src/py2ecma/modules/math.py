from py2ecma import js

_Math = js("Math")
pi = _Math.PI
e = _Math.E


# Number-theoretic and representation functions


def ceil(x):
    _Math.ceil(x)


def copysign(x, y):
    return -1


def fabs(x):
    return _Math.abs(x)


def factorial(x):
    return -1


def floor(x):
    return _Math.floor(x)


def fmod(x, y):
    return x % y


def frexp(x):
    return -1


def fsum(iterable):
    return _Math.sum(iterable)


def gcd(a, b):
    return -1


def modf(x):
    sign = 1 if x >= 0 else -1
    f, mod = divmod(abs(x), 1)
    return mod * sign, f * sign


# Power and logarithmic functions


def exp(x):
    return e**x


def expm1(x):
    return (e**x) - 1


def log(x, base):
    return _Math.log(x) // _Math.log(base)


def log1p(x):
    return log(x, e)


def log2(x):
    return log(x, 2)


def log10(x):
    return log(x, 10)


def pow(x, y):
    return x**y


def sqrt(x):
    return exp(log(x) * 0.5)


# Trigonometric functions


def acos(x):
    return _Math.acos(x)


def asin(x):
    return _Math.asin(x)


def atan(x):
    return _Math.atan(x)


def atan2(y, x):
    return atan(y / x)


def cos(x):
    return _Math.cos(x)


def hypot(x, y):
    return sqrt(x * x + y * y)


def sin(x):
    return _Math.sin(x)


def tan(x):
    return _Math.tan(x)


# Angular conversion


def degrees(x):
    return x * (180 / pi)


def radians(x):
    return x * (pi / 180)


# Hyperbolic functions


def acosh(x):
    return _Math.acosh(x)


def asinh(x):
    return _Math.asinh(x)


def atanh(x):
    return _Math.atanh(x)


def cosh(x):
    return _Math.cosh(x)


def sinh(x):
    return _Math.sinh(x)


def tanh(x):
    return _Math.tanh(x)


def isinf(x):
    return True


def isfinite(x):
    return not isinf(x)


def isnan(x):
    return js("isNaN")(x)
