import sys
import traceback
from os.path import commonpath, dirname, isdir

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer


def autocompile(dependencies, cache, buildfns, output_file, bundle_fn):
    path = commonpath(dependencies)
    path = path if isdir(path) else dirname(path)
    event_handler = WatchHandler(dependencies, cache, buildfns, output_file, bundle_fn)
    observer = Observer()
    observer.schedule(event_handler, path, recursive=isdir(path))
    observer.start()
    try:
        observer.join()
    except KeyboardInterrupt:
        observer.stop()
        observer.join()


class WatchHandler(FileSystemEventHandler):

    def __init__(self, dependencies, cache, buildfns, output_file, bundler_fn):
        self.dependencies = set(dependencies)
        self.cache = cache
        self.buildfns = buildfns
        self.output = output_file
        self.bundler = bundler_fn

    def on_modified(self, event):
        src_path = event.src_path
        if src_path in self.dependencies:
            fns = self.buildfns[src_path]
            try:
                fns()
                self.bundler(self.cache, self.output)
            except Exception:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
                print("".join(lines))
