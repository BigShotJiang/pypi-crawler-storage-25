import os

from ..filesystem import loadsrc


def src_base():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/base.js")
    return loadsrc(filepath)


def src_builtins():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/builtins.js")
    return loadsrc(filepath)


def src_classes():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/classes.js")
    return loadsrc(filepath)


def src_exceptions():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/exceptions.js")
    return loadsrc(filepath)


def src_dict():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/dict.js")
    return loadsrc(filepath)


def src_list():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/list.js")
    return loadsrc(filepath)


def src_set():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/set.js")
    return loadsrc(filepath)


def src_comprehensions():
    filepath = os.path.join(
        os.path.dirname(__file__), "../javascript/comprehensions.js"
    )
    return loadsrc(filepath)


def src_strings():
    filepath = os.path.join(os.path.dirname(__file__), "../javascript/strings.js")
    return loadsrc(filepath)


def jssources() -> str:
    return "\n".join(
        [
            src_base(),
            src_exceptions(),
            src_builtins(),
            src_classes(),
            src_dict(),
            src_list(),
            src_set(),
            src_strings(),
            src_comprehensions(),
        ]
    )
