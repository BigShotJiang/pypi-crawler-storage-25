import ast

from .jsloader import jssources


def package(cache):
    all = jssources() + "var __exports__ = {};\n"
    for dep, src in cache.items():
        dep = dep.replace(".__init__", "")
        wsrc = wrap_iife(src)
        all += "__exports__['{}'] = {}\n".format(dep, wsrc)
    all += "__exports__['{}']();\n".format(dep)
    return all


def wrap_iife(src):
    # IIFE (Immediately Invoked Function Expression) is a JavaScript function
    # that runs as soon as it is defined.
    return "(function () {{\n {} }});".format(src)


def wrap_as_exports(src):
    return "export default {{\n {} }}".format(src)


def get_imports(src):
    tree = ast.parse(src)
    import_generator = ImportDefinitions()
    import_generator.generic_visit(tree)
    return "".join([x for x in import_generator.queue])


class ImportDefinitions(ast.NodeVisitor):
    def __init__(self, node=None):
        self.queue = []

    """Imports"""

    def visit_Import(self, node):
        names = [
            (n.name, n.asname if n.asname is not None else n.name) for n in node.names
        ]
        stmt = [
            "import * as {} from '{}';\n".format(name.replace(".", "/"), asname)
            for (name, asname) in names
        ]
        self.queue.append("".join(stmt))

    def visit_ImportFrom(self, node):
        # TODO
        level = node.level
        prefix = ""  # "." if node.level == 1 else "../" * (level - 1)
        module = prefix + node.module.replace(".", "/")
        names = ", ".join(
            [
                n.name + str(" as " + n.asname if n.asname is not None else "")
                for n in node.names
            ]
        )
        self.queue.append("import {{{}}} from '{}';\n".format(names, module))


def get_exports(src):
    tree = ast.parse(src)
    export_generator = ExportDefinitions()
    export_generator.generic_visit(tree)
    if len(export_generator.alls) > 0:
        exports = export_generator.alls
    else:
        exports = export_generator.defs
    exports = set(exports)
    return "return {{{}}};".format(", ".join([x + ": " + x for x in exports]))


class ExportDefinitions(ast.NodeVisitor):
    def __init__(self, node=None):
        self.defs = []
        self.alls = []

    def visit_FunctionDef(self, node):
        self.defs.append(str(node.name))

    def visit_ClassDef(self, node):
        self.defs.append(str(node.name))

    def visit_Assign(self, node):
        ids = [str(x.id) for x in node.targets if isinstance(x, ast.Name)]
        if ids == ["__all__"]:
            self.alls = [x.s for x in node.value.elts]
        else:
            self.defs += ids
