import logging
from argparse import Namespace
from pathlib import Path
from typing import List


class TranspilerConfig:
    input_file: Path
    output_file: Path
    build_dir: Path

    clean_build: bool
    recursive: bool
    minimize: bool
    watch: bool
    type_check: bool
    progressbar: bool
    raw: bool
    externs: List[str]

    def __init__(self, argparser: Namespace):
        self.input_file = Path(argparser.input)
        self.output_file = Path(argparser.output_file)
        self.build_dir = Path(argparser.build_dir)

        self.clean_build = argparser.clean
        self.recursive = argparser.recursive
        self.minimize = argparser.minimize
        self.watch = argparser.watch
        self.type_check = argparser.type_check
        self.progressbar = not argparser.disable_progressbar
        self.raw = argparser.raw
        self.externs = argparser.externs

        if argparser.quiet:
            self.loglevel = logging.ERROR
            self.progressbar = False
        elif argparser.very_verbose:
            self.loglevel = logging.DEBUG
            self.progressbar = False
        elif argparser.verbose:
            self.loglevel = logging.INFO
            self.progressbar = False
        else:
            self.loglevel = logging.WARNING


__all__ = ["TranspilerConfig"]
