from helpers import jstest


@jstest
def test_init():
    return "hello world!"


@jstest
def test_str_call():
    return str(1)


@jstest
def test_str_equal():
    return ["test" == "test", "test" == "notest"]


@jstest
def test_str_lower():
    return "TeSt".lower()


@jstest
def test_str_split():
    return "Te;St; test;".split(";")


@jstest
def test_str_index():
    return "Te;St; test;"[3]


@jstest
def test_str_format():
    s = "test {} {}".format("hello", "world")
    return s


@jstest
def test_str_format_position():
    s = "test {1} {0}".format("world!", "hello")
    return s


@jstest
def test_str_none():
    s = None
    return str(s)


@jstest
def test_fstrings():
    test = 1
    return f"test { test }"


@jstest
def test_str_in():
    return "test" in "stestssss"


@jstest
def test_str_var_in():
    a = "ttststest"
    b = "test"
    return b in a


@jstest
def test_str_not_in():
    return "a" in "b"
