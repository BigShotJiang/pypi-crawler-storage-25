from helpers import jstest


@jstest
def test_list_empty():
    return []


@jstest
def test_list_init():
    return [1, 2, 3]


@jstest
def test_list_init_2():
    a = [1, 2, 3]
    return list(a)


@jstest
def test_list_init_3():
    a = [[1, 2, 3]]
    return list(a)


@jstest
def test_list_init_4():
    a = [[1, 2, 3]]
    b = list(a)
    return list(b)


@jstest
def test_list_init_5():
    a = [[1, 2, 3], [4, 5, 6]]
    b = list(a)
    return list(b)


@jstest
def test_list_init_6():
    a = [-1]
    return a


@jstest
def test_list_init_7():
    a = [5]
    return a


@jstest
def test_list_scope_1():
    a = [1, 2, 3]
    b = list(a)
    a[1] = 10
    return list(b)


@jstest
def test_list_scope_2():
    a = [1, 2, 3]
    a[1] = 10
    b = list(a)
    return list(b)


@jstest
def test_list_index():
    a = [1, 2, 3, 4, 5, 6]
    return a[2]


@jstest
def test_list_index_1():
    a = [[1, 2, 3]]
    return a[0]


@jstest
def test_list_index_2():
    a = [[1, 2, 3]]
    return a[0][1]


@jstest
def test_list_set_1():
    a = [1, 2, 3]
    a[1] = 10
    return a


@jstest
def test_list_set_2():
    a = [[1, 2, 3]]
    a[0][1] = 10
    return a


@jstest
def test_list_slice_1():
    a = [1, 2, 3, 4, 5, 6]
    return a[2:]


@jstest
def test_list_slice_2():
    a = [1, 2, 3, 4, 5, 6]
    return a[0:2]


@jstest
def test_list_slice_3():
    a = [1, 2, 3, 4, 5, 6]
    return a[:-2]


@jstest
def test_list_slice_4():
    a = [1, 2, 3, 4, 5, 6]
    return a[2:-2]


@jstest
def test_list_slice_5():
    a = [1, 2, 3, 4, 5, 6]
    return a[12:]


@jstest
def test_list_step_1():
    a = [1, 2, 3, 4, 5, 6]
    return a[::2]


@jstest
def test_list_step_2():
    a = [1, 2, 3, 4, 5, 6]
    return a[::-1]


@jstest
def test_list_len():
    a = [1, 2, 3, 4, 5, 6]
    return len(a)


@jstest
def test_list_real_length():
    a = [1, 2, 3, 4, 5, 6]
    i = 0
    for b in a:
        i += 1
    return [i, len(a)]


@jstest
def test_list_contains():
    a = [1, 2, 3, 4, 5, 6]
    return 3 in a


@jstest
def test_list_not_contains():
    a = [1, 2, 3, 4, 5, 6]
    return 10 in a


@jstest
def test_list_not_in():
    a = [1, 2, 3, 4, 5, 6]
    return 10 not in a


@jstest
def test_list_clear():
    a = [1, 2, 3, 4, 5, 6]
    a.clear()
    return a


@jstest
def test_index_1():
    a = [1, 2, 3, 4, 5, 6]
    i = a.index(3)
    return i


@jstest
def test_index_2():
    a = [1, 2, 3, 4, 5, 6]
    i = a.index(4, 2, 5)
    return i


@jstest
def test_extend():
    a = [1, 2, 3, 4, 5, 6]
    b = [7, 8, 9]
    a.extend(b)
    return a


@jstest
def test_insert():
    a = [1, 2, 3, 4, 5, 6]
    a.insert(4, 100)
    return a


@jstest
def test_remove():
    a = [1, 2, 3, 4, 5, 6]
    a.remove(4)
    return a


@jstest
def test_pop():
    a = [1, 2, 3, 4, 5, 6]
    return a.pop()


@jstest
def test_pop_1():
    a = [1, 2, 3, 4, 5, 6]
    return a.pop(3)


@jstest
def test_count():
    a = [1, 2, 3, 4, 3, 5, 6]
    return a.count(3)


@jstest
def test_sort():
    a = [1, 10, 3, 7, 3, 5, 2]
    a.sort()
    return a


@jstest
def test_sort_reverse():
    a = [1, 10, 3, 7, 3, 5, 2]
    a.sort(reverse=True)
    return a


@jstest
def test_reverse():
    a = [1, 10, 3, 7, 3, 5, 2]
    a.reverse()
    return a


@jstest
def test_copy():
    a = [1, 10, 3, 7, 3, 5, 2]
    b = a.copy()
    a[0] = 10
    return b


@jstest
def test_append():
    a = []
    a.append("test")
    a.append("hey")
    return a


@jstest
def test_concat():
    a = [1, 2]
    return [[32] + a, a + [32]]


@jstest
def test_truth_not_false():
    a = [1, 2]
    return not a


@jstest
def test_truth_not_true():
    a = []
    return not a


@jstest
def test_list_isinstance():
    a = []
    return isinstance(a, list)


@jstest
def test_list_of_list():
    a = [1, 23, 45, 56]
    return list(list(a))


@jstest
def test_list_of_list_one_element():
    a = [5]
    return list(list(a))
