from helpers import jstest


@jstest
def test_function_decorators():

    def b(func):
        def wrapper(p):
            return 1 + func(p)

        return wrapper

    @b
    def a(p):
        return p + 1

    return a(1)


@jstest
def test_function_decorators_with_parameters():

    def b(c):
        def wrapper(func):
            def inner(p):
                return c + func(p)

            return inner

        return wrapper

    @b(50)
    def a(p):
        return p + 1

    return a(1)


@jstest
def test_function_multiple_decorators():

    def c(func):
        def wrapper(p):
            return 1 + func(p)

        return wrapper

    def b(d):
        def wrapper(func):
            def inner(p):
                return d + func(p)

            return inner

        return wrapper

    @c
    @b(50)
    def a(p):
        return p + 1

    return a(1)
