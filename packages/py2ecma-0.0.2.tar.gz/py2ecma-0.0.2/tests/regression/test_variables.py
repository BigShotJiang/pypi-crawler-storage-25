from helpers import jstest


@jstest
def test_store():
    a = 1
    return a


@jstest
def test_load():
    a = 1
    b = a
    return b


@jstest
def test_chain_store_1():
    a = b = 1
    b
    return a


@jstest
def test_chain_store_2():
    a, b = 1, 2
    a
    return b


@jstest
def test_chain_store_3():
    a, b = 1, 2
    b, a = a, b
    return b


@jstest
def test_tuple_onfold():
    a, b = (1, 10)
    return b
