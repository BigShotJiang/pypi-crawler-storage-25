from helpers import jstest


@jstest
def test_method_passing():
    class A:
        def __init__(self):
            self.test = 30

        def val(self):
            return self.test

    def add(x_fn):
        x = 10 * x_fn()
        return x

    a = A()
    return add(a.val)


@jstest
def test_method_scoping():
    class A:
        def val(self):
            self.a = 42

            def inner():
                return self.a

            return inner()

    a = A()
    return a.val()
