from helpers import jstest


@jstest
def test_tuple():
    t = tuple([1, 2])
    return t[1]


@jstest
def test_add():
    return list((1, 2) + (0, 3))


@jstest
def test_contains_found():
    return "A" in ("B", 3, "A")


@jstest
def test_contains_not_found():
    return "C" in ("B", 3, "A")


@jstest
def test_not_contains_found():
    return "A" not in ("B", 3, "A")


@jstest
def test_not_contains_not_found():
    return "C" not in ("B", 3, "A")
