from helpers import jsexception, jstest


@jstest
def test_one_fun_set():
    return list(set([3]))


@jstest
def test_multiple_fun_set():
    return list(set([1, 3]))


@jstest
def test_set_empty():
    return {}


@jstest
def test_set():
    return list({1})


@jstest
def test_set_n():
    return list({1, 3})


@jstest
def test_len():
    return len({1, 3, 4})


@jstest
def test_in():
    return "monty" in {3, 30, "monty", "Python"}


@jstest
def test_not_in():
    return "monty" not in {3, 30, "monty", "Python"}


@jstest
def test_isdisjoint():
    return {3, 30, "monty", "Python"}.isdisjoint({50, "Terry"})


@jstest
def test_is_not_disjoint():
    return {3, 30, "monty", "Python"}.isdisjoint({50, "monty"})


@jstest
def test_issubset():
    return {3, 4}.issubset({1, 2, 3, 4, 5})


@jstest
def test_issubset_symbol():
    return {3, 4} <= {1, 2, 3, 4, 5}


@jstest
def test_not_issubset():
    return {3, 4, 10} <= {1, 2, 3, 4, 5}


@jstest
def test_proper_issubset():
    return {3, 4} < {1, 2, 3, 4, 5}


@jstest
def test_not_proper_issubset():
    return {3, 4} < {3, 4}


@jstest
def test_is_superset_func():
    return {3, 4, 5, 6}.issuperset({3, 4})


@jstest
def test_is_superset():
    return {3, 4, 5, 6} >= {3, 4}


@jstest
def test_is_not_superset():
    return {3, 4, 5, 6} >= {3, 4, 10}


@jstest
def test_is_proper_superset():
    return {3, 4, 5} > {3, 4}


@jstest
def test_is_not_proper_superset():
    return {3, 4} > {3, 4}


@jstest
def test_union_func():
    return list({3, 4}.union({3, 5, 6}, {6, 7, 8}))


@jstest
def test_union():
    return list({3, 4} | {3, 5, 6} | {6, 7, 8})


@jstest
def test_intersection_func():
    return list({3, 4, 5, 7}.intersection({3, 5, 6}, {5}, {6, 5, 7}))


@jstest
def test_intersection():
    return list({3, 4, 5, 7} & {3, 5, 6} & {5} & {6, 5, 7})


@jstest
def test_none_intersection():
    return len({3, 4, 5, 7} & {3, 5, 6} & {5} & {6, 7})


@jstest
def test_difference_func():
    return list({3, 4, 5, 7}.difference({3, 5, 6}, {5}, {6, 7, 10}))


@jstest
def test_difference():
    return list({3, 4, 5, 7} - {3, 5, 6} - {5} - {6, 7})


@jstest
def test_symmetric_difference_func():
    return len({1, 2, 3, 7, 8}.symmetric_difference({3, 4, 5, 6}))


@jstest
def test_symmetric_difference():
    return len({1, 2, 3, 7, 8} ^ {3, 4, 5, 6})


@jstest
def test_copy():
    return list({3, 4, 5}.copy())


@jstest
def test_frozenset():
    return list(frozenset([1, 3, 5, 7]))


@jsexception(AttributeError)
def test_frozenset_add_exception():
    a = frozenset([1, 3, 4, 6])
    a.add(10)


@jstest
def test_intersection_froze():
    return list(frozenset([3, 4, 5, 7]).intersection(frozenset([6, 5, 7])))


@jstest
def test_difference_froze():
    return list(frozenset([3, 4, 5, 7]).difference(frozenset([6, 5, 7])))


@jstest
def test_union_froze():
    return list(frozenset([3, 4, 5]).union(frozenset([5, 7])))


@jstest
def test_set_iteration():
    a = []
    for x in {1, 2, 3}:
        a.append(x)
    return list(a)


@jstest
def test_set_add():
    a = {1, 2}
    a.add(3)
    return list(a)


@jstest
def test_set_update_func():
    a = {5}
    a.update({3, 5}, {10})
    return len(a)


@jstest
def test_set_update():
    a = {5, 50}
    a |= {3, 5} | {10, 3, 60}
    return len(a)


@jstest
def test_intersection_update_func():
    a = {1, 5, 50}
    a.intersection_update({30, 5, 1}, {3, 1, 50})
    return list(a)


@jstest
def test_intersection_update():
    a = {2, 5, 50}
    a &= {30, 5, 1}
    return list(a)


@jstest
def test_difference_update_func():
    a = {2, 5, 50, 10}
    a.difference_update({5, 3, 20}, {50})
    return list(a)


@jstest
def test_difference_update():
    a = {2, 5, 50, 10}
    a -= {5, 3, 20} | {50}
    return list(a)


@jstest
def test_sym_difference_update_func():
    a = {2, 5}
    a.symmetric_difference_update({5, 3})
    return list(a)


@jstest
def test_sym_difference_update():
    a = {2, 5}
    a ^= {5, 3}
    return list(a)


@jstest
def test_set_remove():
    a = {2, 50}
    a.remove(50)
    return list(a)


@jsexception(KeyError)
def test_set_remove_fail():
    a = {2, 50}
    a.remove(1)
    return a


@jstest
def test_set_discard():
    a = {2, 50}
    a.discard(1)
    a.discard(50)
    return list(a)


@jstest
def test_set_pop():
    a = {2, 50}
    v = a.pop()
    return v


@jstest
def test_set_clear():
    a = {2, 50}
    a.clear()
    assert a == set()
    return len(a)


@jstest
def test_set_equality():
    a = {1, 2}
    b = set([1, 2])
    c = {1}
    assert a == b
    return a == c
