from helpers import jstest


@jstest
def test_for_loop():
    a = [1, 3, 5]
    b = 0
    for x in a:
        b = b + x
    return b


@jstest
def test_yield():
    def test_():
        for x in [1, 2, 3, 4]:
            yield x + 1

    a = 0
    for y in test_():
        a += y
    return a


@jstest
def test_break():
    a = [1, 2, 3, 4, 5]
    for x in a:
        if x == 4:
            break
        b = x
    return b


@jstest
def test_continue():
    a = [1, 2, 3, 4, 5]
    b = 0
    for x in a:
        if x == 4:
            continue
        b += x
    return b


@jstest
def test_dict_comprehension_1():
    a = {str(x): 10 * x for x in [1, 2, 3, 4, 5, 6]}
    return a


@jstest
def test_dict_comprehension_2():
    a = {"s " + str(y): 10 * x for y, x in {"t": 1, 1: 3, "y": 32}.items()}
    return a


@jstest
def test_list_comprehension_1():
    a = [10 * x for x in [1, 2, 3, 4, 5, 6]]
    return a


@jstest
def test_list_comprehension_2():
    b = [10 * x for x in [1, 2, 3, 4, 5, 6] if x % 2 == 0]
    return b


@jstest
def test_list_comprehension_3():
    c_map = {1: True, 2: True, 3: False, 4: False, 5: True, 6: True}
    c = [10 * x for x in [1, 2, 3, 4, 5, 6] if c_map[x]]
    return c


@jstest
def test_list_comprehension_4():
    d = [y**2 for y in [x for x in [1, 2, 3, 4, 5, 6] if x % 2 == 0]]
    return d


@jstest
def test_list_comprehension_5():
    e = [c**2 for line in [[3, 32, 4, 32, 1], [11, 2, 3, 9]] for c in line]
    return e


@jstest
def test_list_comprehension_6():
    f = [y for x in [[[3, 32], [4, 32, 1]], [[11, 2], [3, 9]]] for y in x]
    return f


@jstest
def test_list_comprehension_7():
    g = [
        z
        for x in [[[3, 32], [4, 32, 1]], [[11, 2], [3, 9]]]
        for y in x
        if len(y) > 2
        for z in y
    ]
    return g


@jstest
def test_list_comprehension_8():
    a = [(1, 2), (3, 4), (5, 6)]
    return [x + y for x, y in a]
