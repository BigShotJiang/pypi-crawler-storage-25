from helpers import jstest


@jstest
def test_function_call():
    def _test():
        return 2

    return _test()


@jstest
def test_function_simple_args():
    def _test(arg1, arg2):
        return arg1 + arg2

    return _test(1, 2)


@jstest
def test_function_simple_kwargs1():
    def _test(arg1, arg2, arg3):
        return arg1 + arg2

    return _test(arg1=1, arg2=2, arg3=3)


@jstest
def test_function_simple_kwargs2():
    def _test(arg1, arg2, arg3):
        return arg1 + arg2

    return _test(arg1=1, arg3=2, arg2=3)


@jstest
def test_function_simple_kwargs3():
    def _test(arg1, arg2, arg3):
        return arg1 + arg3

    return _test(1, arg2=None, arg3=3)


@jstest
def test_function_defaults_kwargs1():
    def _test(arg1, arg2=None, arg3=3):
        return arg1 + arg3

    return _test(1, 2)


@jstest
def test_function_defaults_kwargs2():
    def _test(arg1, arg2=None, arg3=3):
        return arg1 + arg2 + arg3

    return _test(1, arg2=2, arg3=5)


@jstest
def test_function_variable_args():
    def _test(*args):
        return args

    a, b, c = _test(1, 2, 5)
    return b


@jstest
def test_function_variable_kwargs():
    def _test(**kwargs):
        return kwargs

    return _test(a=1, b=2, c=5)


@jstest
def test_func_call_all():
    def t(a, b="b", *ar, **kwr):
        return [a, b, list(ar), kwr]

    return t("a", "1", "2", c="c")


@jstest
def test_function_call_variable_kwargs():
    def _test(b, **kwargs):
        return kwargs

    a = {"a": 1, "d": 2, "c": 5}
    b = 1
    return _test(b=b, **a)


@jstest
def test_function_chainning():
    def test():
        def test2():
            return 2

        return test2

    return test()()


@jstest
def test_function_return_empty():
    def test():
        return

    return test() is None


@jstest
def test_call_varg():
    def a(*arg, **kwargs):
        return arg

    return sum(a(2, 5, 4))


@jstest
def test_call_argvars():
    def a(*arg, **kwargs):
        k = [y for x, y in kwargs.items()]
        return sum(arg) + sum(k)

    return a(2, 5, a=1, c=3)


@jstest
def test_access_kwarg():
    def a(*arg, **kwargs):
        return sum(arg) + kwargs["a"]

    return a(2, 5, a=1, c=3)


@jstest
def test_call_star_kwarg():
    def a(*arg, **kwargs):
        k = [y for x, y in kwargs.items()]
        return sum(arg) + sum(k)

    return a(2, 5, **{"a": 1, "c": 3})


@jstest
def test_call_star_all():
    def a(*arg, **kwargs):
        k = [y for x, y in kwargs.items()]
        return sum(arg) + sum(k)

    return a(*[2, 5], **{"a": 1, "c": 3})


@jstest
def test_call_star_all_placement():
    def a(*arg, **kwargs):
        k = [y for x, y in kwargs.items()]
        return sum(arg) + sum(k)

    return a(7, *[2, 5], d=60, **{"a": 1, "c": 3}, b=30)


@jstest
def test_call_star_all_positionals():
    def a(*arg, **kwargs):
        return sum(arg)

    return a(7, 3, 4, 6, 10)
