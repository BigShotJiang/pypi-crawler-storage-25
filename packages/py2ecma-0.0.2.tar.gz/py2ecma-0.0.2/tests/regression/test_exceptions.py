from helpers import jsexception, jstest


@jsexception(Exception)
def test_raise_simple():
    raise Exception


@jsexception(Exception)
def test_raise_with_call():
    raise Exception("test")


@jstest
def test_try_catch_all():
    success = 0
    try:
        raise Exception
    except:
        success = 1
    return success


@jstest
def test_try_catch_handler():
    success = 0
    try:
        raise TypeError("test")
    except TypeError:
        return 1
    return success


@jstest
def test_try_catch_typerr():
    success = 0
    try:
        raise TypeError(1)
    except TypeError as e:
        return e.args[0]
    return success
