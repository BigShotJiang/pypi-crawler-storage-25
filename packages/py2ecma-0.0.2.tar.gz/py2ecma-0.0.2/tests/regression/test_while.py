from helpers import jstest


@jstest
def test_while_simple():
    i = 0
    while i != 10:
        i += 1
    return i
