import pytest
from helpers import jstest


@jstest
def test_simple_class():
    class Test:
        def test(self):
            return 1

    c = Test()
    return c.test()


@jstest
def test_init_class():
    class Test:
        def __init__(self, arg):
            self.arg = arg

        def get_arg(self):
            return self.arg

    c = Test(1)
    return c.get_arg()


@jstest
def test_parameter_class():
    class Test:
        def __init__(self, arg, arg2):
            self.arg = arg
            self.arg2 = arg2

        def get_arg(self):
            return self.arg + self.arg2

    c = Test(1, arg2=3)
    return c.get_arg()


@jstest
def test_keywordargs_class():
    class Test:
        def __init__(self, arg, arg2, arg3):
            self.arg = arg
            self.arg2 = arg2
            self.arg3 = arg3

        def get_arg(self):
            return self.arg + self.arg2

    c = Test(arg2=1, arg3=3, arg=2)
    return c.get_arg()


@jstest
def test_kwargs_class():
    class Test:
        def __init__(self, **kwargs):
            self.args = kwargs

        def get_arg(self):
            return self.args

    c = Test(arg2=1, arg3=3, arg=2)
    return c.get_arg()


@jstest
def test_inline_attrs_class():
    class Test:
        test = "TEST"

    c = Test()
    return c.test


@jstest
def test_override_inline_attrs_class():
    class Test:
        test = 1

    test0 = Test.test
    c = Test()
    d = Test()
    test1 = c.test
    c.test = 2
    test2 = c.test
    return [test0, test1, test2, d.test, c.test, Test.test]


@jstest
def test_setattr_class():
    class Test:
        pass

    c = Test()
    setattr(c, "test", 1)
    return c.test


@jstest
def test_setattr_override_class():
    class Test:
        def __setattr__(self, attr, val):
            if val == 3:
                super().__setattr__(attr, val)
            else:
                super().__setattr__(attr, True)

    c = Test()
    c.t1 = 10
    c.t2 = 3
    return [c.t1, c.t2]


@jstest
def test_get_attrs_class():
    class Test:
        value = None

        def __getattr__(self, name: str):
            return "Test"

    c = Test()
    return c.test


@jstest
def test_getattrs():
    class Test:
        def __init__(self):
            self.v = 50

        def __getattr__(self, name: str):
            if name == "test":
                return 1337
            else:
                return self.__getattribute__(name)

    c = Test()
    return c.test + c.v


@jstest
def test_simple_inheritance():
    class Parent:
        def __init__(self):
            self.test = True

    class Child(Parent):
        def get_test(self):
            return self.test

    c = Child()
    return c.get_test()


@jstest
def test_inheritance_override():
    class Parent:
        def __init__(self):
            self.test = True

        def get_test(self):
            return self.test

    class Child(Parent):
        def __init__(self):
            self.test = False

    c = Child()
    return c.get_test()


@jstest
def test_inheritance_kwargs():
    class Parent:
        def __init__(self, a=1, b=1):
            self.a = a
            self.b = b

    class Child(Parent):
        pass

    c = Child(b=42)
    return [c.a, c.b]


@jstest
def test_inheritance_method_override():
    class Parent:
        def __init__(self):
            self.test = self.get_test()

        def get_test(self):
            return 1

    class Child(Parent):
        def get_test(self):
            return 2

    c = Child()
    return c.get_test()


@jstest
def test_inheritance_super_init():
    class Parent:
        def __init__(self):
            self.test1 = True

    class Child(Parent):
        def __init__(self):
            self.test2 = True
            super().__init__()

        def get_test(self):
            return self.test1 and self.test2

    c = Child()
    return c.get_test()


@jstest
def test_inheritance_limit_init():
    class GrandParent:
        count = 0

        def __init__(self):
            self.count += 1

        def get_test(self):
            return self.count

    class Parent(GrandParent):
        pass

    class Child(Parent):
        pass

    c = Child()
    return c.get_test()


@jstest
def test_inheritance_isinstance():
    class Parent:
        pass

    class Child(Parent):
        pass

    class Second:
        pass

    c = Child()
    return isinstance(c, Child) and isinstance(c, Parent) and not isinstance(c, Second)


@jstest
def test_inheritance_super_func():
    class Parent:
        def test(self):
            return "Parent"

    class Child(Parent):
        def test(self):
            return ["Child", super().test()]

    c = Child()
    return c.test()


@jstest
def test_getattr():
    class Test:
        def __getattr__(self, attr):
            return 42

    c = Test()
    return [c.something, c.anything]


@jstest
def test_getattr_inheritance():
    class Parent:
        def __getattr__(self, attr):
            return 42

    class Test(Parent):
        pass

    c = Test()
    return [c.something, c.anything]


@jstest
def test_class_dict():
    class Test:
        t1 = 1

        def __init__(self):
            self.t2 = 2

        def check(self):
            return "t1" in self.__class__.__dict__

    c = Test()
    d = c.__class__.__dict__
    return ["t1" in d, c.check()]


@jstest
def test_classes_inheritance_kwargs():
    class Parent:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class Child(Parent):
        pass

    cls = Child(test=1)
    return cls.test


@jstest
def test_classes_inheritance_kwargs_empty():
    class Parent:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class Child(Parent):
        pass

    cls = Child()
    return None


@jstest
def test_classes_inheritance_kwargs_ensure_init():
    class Parent:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class Child(Parent):
        test = 1

    cls = Child(test2=2)
    return [cls.test, cls.test2]


@jstest
def test_staticmethod():
    class Test:
        @staticmethod
        def static_method(v: int) -> int:
            return 1 + v

    obj = Test()
    return [obj.static_method(30), Test.static_method(30)]


@jstest
def test_staticmethod_kwargs():
    class Test:
        @staticmethod
        def static_method(v: int) -> int:
            return 1 + v

    obj = Test()
    return [obj.static_method(v=30), Test.static_method(v=30)]


@jstest
def test_classmethod():
    class Test:
        @staticmethod
        def static_method():
            return 1

        @classmethod
        def class_method(cls):
            return cls.static_method()

    obj = Test()
    return [obj.class_method(), Test.class_method()]


@jstest
def test_classmethod_vararg():
    class Test:

        @classmethod
        def class_method(cls, a, *arg):
            return [*arg, a]

    obj = Test()
    return obj.class_method(1, 2, 3, 4, 5, 10)


@jstest
def test_classmethod_inheritance():
    class Parent:
        @classmethod
        def get(cls):
            return cls()

    class Child(Parent):
        pass

    return isinstance(Child.get(), Child)


@jstest
def test_special_constructor():
    class A:
        def constructor(self):
            pass

    a = A()
    pass
    return True


@jstest
def test_classmethod_args():
    class Parent:
        @classmethod
        def test(cls, data):
            return data

    return Parent.test(42)


@jstest
def test_classmethod_named_args():
    class Parent:
        @classmethod
        def test(cls, data):
            return data

    return Parent.test(data=42)


@jstest
def test_propertymethod_simple():
    class Test:
        @property
        def test_property(self):
            return 1

    obj = Test()
    return obj.test_property


@jstest
def test_propertymethod():
    class Test:
        def __init__(self):
            self.test = 42

        @property
        def test_property(self):
            return self.test

    obj = Test()
    return obj.test_property


@jstest
def test_inline_attrs():
    class TestAttr:
        value = "TEST"

        def set_val(self):
            self.value = 1337

    class Test:
        a = TestAttr()

        def test(self):
            self.a.set_val()

    t1 = Test()
    t2 = Test()
    t2.test()
    return [t1.a.value, t2.a.value]


@jstest
def test_inline_attrs_cls_init():
    class TestAttr:
        def __init__(self, _default=None, required=True, hide=False):
            self.default = _default
            self.required = required
            self.hide = hide

        def get_attr(self):
            return [self.default, self.required, self.hide]

    class TestAttrChild(TestAttr):
        pass

    class Test:
        a = TestAttrChild(required=False)
        b = TestAttrChild(_default=1, hide=True)

    t = Test()

    return [t.a.get_attr(), t.b.get_attr()]


@jstest
def test_call_chaining():
    class Test:
        def __init__(self):
            self.t = 1

        def test(self, v):
            self.t = self.t + v
            return v + self.t

    def x():
        return Test()

    a = x().test(42)
    b = x().test(60)
    return a + b


@jstest
def test_class_method_kwargs():
    class A:
        def test(self, a, b=10, *args, **kwargs):
            return [a, b, *args, kwargs]

    t = A()
    return t.test(1, 321, 33, d=30, f=50)


@jstest
def test_class_new_return():
    class A:
        pass

    class B:
        def __new__(cls):
            return A()

    b = B()
    return isinstance(b, A)


@pytest.mark.skip("Super call with class is not currently supported")
@jstest
def test_class_new_custom_construct():
    class A:
        def __new__(cls):
            return super(A, cls).__new__(cls)

    a = A()
    return isinstance(a, A)


@jstest
def test_class_new_args():

    class A:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class B:
        def __new__(cls, a, b=1):
            return A(a, b)

    b = B(3, 4)
    return [b.a, b.b]


@jstest
def test_new_vararg():
    class Test:

        def __new__(cls, a, *arg):
            return [*arg, a]

    obj = Test(1, 2, 3, 4, 5, 10)
    return obj


@jstest
def test_class_vararg_init():
    class A:
        def __init__(self, a, *args, **kwargs):
            self.a = a
            self.sum = sum(args)
            self.kwsum = sum([v for _, v in kwargs.items()])

        def all(self):
            return self.a + self.sum + self.kwsum

    a = A(1)
    aa = A(1, 2, 3, 4, 5)
    return [a.all(), aa.all()]
