from helpers import jstest


@jstest
def test_simple_single_inheritance():
    class A:
        def test(self):
            return 42

    class B(A):
        pass

    b = B()
    return b.test()


@jstest
def test_super_single_inheritance():
    class A:
        def test(self) -> int:
            return 42

    class B(A):
        def test(self) -> int:
            return super().test()

    b = B()
    return b.test()


@jstest
def test_multiple_inheritance():
    class A:
        def test_a(self):
            return 42

    class B:
        def test_b(self):

            return 42

    class C(A, B):
        def test(self):
            return self.test_a() + self.test_b()

    c = C()
    return c.test()


@jstest
def test_diamond():
    class A:
        def __init__(self):
            self.t = "A"

    class B:
        def __init__(self):
            self.t = "B"

    class C(A, B):
        pass

    c = C()
    return c.t
