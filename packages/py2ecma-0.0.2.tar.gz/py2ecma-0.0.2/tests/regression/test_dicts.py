from helpers import jstest

""" Initialization of dicts
"""


@jstest
def test_dict_empty():
    return {}


@jstest
def test_dict_func_empty():
    return dict()


@jstest
def test_dict_keyword():
    return dict(py2es=6, ECMA=2016)


@jstest
def test_dict_list():
    return dict([["py2ecma", 6], ["ECMA", 2016]])


@jstest
def test_dict_tuple():
    return dict([("py2ecma", 6), ("ECMA", 2016)])


@jstest
def test_dict_dict():
    return dict({"py2ecma": 6})


@jstest
def test_dict():
    return {"py2ecma": 6}


@jstest
def test_dict_extend():
    a = {"a": 1, "c": 3}
    b = {"b": 2, "c": 4}
    return {**a, **b}


@jstest
def test_dict_get():
    a = {"a": 1, "c": 3}
    return a["c"]


@jstest
def test_dict_set():
    a = {"a": 1, "c": 3}
    a["b"] = 2
    return a["b"]


@jstest
def test_dict_compound_key():
    a = {}
    a[(1, 1)] = 43
    return a[(1, 1)]


@jstest
def test_dict_len():
    a = {"guido": 3, "jack": 1024}
    return len(a)


@jstest
def test_dict_del():
    a = {"guido": 3, "jack": 1024}
    del a["guido"]
    return len(a)


@jstest
def test_dict_contains():
    a = {"guido": 3, "jack": 1024}
    return "guido" in a


@jstest
def test_dict_contains_ints():
    a = {1: True, 2: False}
    return 2 in a


# @jstest
# def test_dict_values():
#     a = {"a": 5, "b": 1}
#     v = [v for v in a.values()]
#     return 5 in v and 1 in v
#
#
@jstest
def test_dict_isinstance():
    a = {1: 1}
    return isinstance(a, dict)


@jstest
def test_dict_call():
    a = {"test": 1}
    return len(dict(a))


# @jstest
# def test_dict_copy():
#     a = {"test": 1}
#     return len(a.copy())


@jstest
def test_dict_bool():
    a = {"test": 1}
    return bool(a)


# @jstest
# def test_dict_compare():
#     a = {"test": 1}
#     b = {"test": 2}
#     c = {"test": 1}
#     return a == a and a != b
#
#
# @jstest
# def test_dict_update():
#    a = {"test": 1, "a": True}
#    b = {"test": 2, "b": False}
#    a.update(b)
#    return a

# # @jstest
# # def test_dict_tuple_assign():
# #     a = {}
# #     a["1"], a["3"] = 1, 3
