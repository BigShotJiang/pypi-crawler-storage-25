from helpers import jstest


@jstest
def test_True():
    return True


@jstest
def test_False():
    return False


@jstest
def test_And():
    return True and False


@jstest
def test_Or():
    return True or False


@jstest
def test_Eq():
    return 3 == 1


@jstest
def test_Eq_eq():
    return 1 == 1


@jstest
def test_NotEq():
    return 3 != 3


@jstest
def test_NotEq_eq():
    return 3 != 1


@jstest
def test_Lt():
    return 3 < 3


@jstest
def test_LtE():
    return 3 <= 3


@jstest
def test_Gt():
    return 3 > 3


@jstest
def test_GtE():
    return 3 >= 3


@jstest
def test_multiple_1():
    return 3 > 1 > 3


@jstest
def test_multiple_2():
    return 3 < 1 > 3


@jstest
def test_boolean_advanced():
    return 3 < 1 > 3 and 1 != 2 or 3 == 1


@jstest
def test_is_none():
    a = None
    return a is None


@jstest
def test_is_int():
    a = 1
    return a is None


@jstest
def test_is_str():
    a = ""
    return a is None


@jstest
def test_isnot():
    a = ""
    return a is not None


@jstest
def test_isnot_none():
    a = None
    return a is not None


@jstest
def test_not():
    a = False
    return not a


@jstest
def test_if_expr():
    a = 2 if True else 10
    return a


@jstest
def test_equal_1():
    return 1 == None


@jstest
def test_equal_2():
    return None == 1
