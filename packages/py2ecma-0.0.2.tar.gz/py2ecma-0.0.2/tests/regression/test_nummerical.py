from helpers import jstest


@jstest
def test_Num():
    return 1


@jstest
def test_Add():
    return 1 + 1


@jstest
def test_iadd():
    a = 2
    a += 5
    return a


@jstest
def test_isub():
    a = 56
    a -= 5
    return a


@jstest
def test_calc():
    return 2 - 1 + 10 - 40 / 10 * 30


@jstest
def test_sub():
    return 2 - 1


@jstest
def test_mult():
    return 2 * 2


@jstest
def test_div():
    return 4 / 2


@jstest
def test_floor_div():
    return 45 // 2


@jstest
def test_mod():
    return 27 % 3


@jstest
def test_mod_neg():
    return (-13) % 64


@jstest
def test_pow():
    return 4**2


@jstest
def test_usub():
    return -1


@jstest
def test_uadd():
    a = -1
    return +a


@jstest
def test_lshift():
    return 10293 << 13


@jstest
def test_rshift():
    return 10293 >> 13


@jstest
def test_bitwise_and():
    return 10293 & 13


@jstest
def test_bitwise_or():
    return 10293 | 13


@jstest
def test_bitwise_xor():
    return 10293 ^ 13


@jstest
def test_bitwise_flip():
    return ~1029313
