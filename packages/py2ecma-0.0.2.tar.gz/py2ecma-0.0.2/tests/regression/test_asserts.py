from helpers import jsexception, jstest


@jsexception(AssertionError)
def test_assert_false():
    assert False


@jstest
def test_assert_true():
    assert True
    return True
