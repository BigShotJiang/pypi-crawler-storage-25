from helpers import jstest


@jstest
def test_enumerate():
    a = [1, 2, 3, 4]

    return [i + a for i, a in enumerate(a)]


@jstest
def test_isinstance_int():
    return isinstance(1, int)


@jstest
def test_isinstance_str():
    return isinstance("test", str)


@jstest
def test_isinstance_float():
    return isinstance(1.321, float)


@jstest
def test_isinstance_not_float():
    return isinstance(1, float)


@jstest
def test_isinstance_bool():
    return isinstance(True, bool)


@jstest
def test_isinstance_bool_false():
    return isinstance("2", bool)


@jstest
def test_isinstance_tuple():
    return isinstance("2", (int, str))


@jstest
def test_isinstance_tuple_false():
    return isinstance("test", (int, bool))


@jstest
def test_isinstance_class():
    class Test:
        pass

    t = Test()
    return [isinstance("", Test), isinstance(t, Test), isinstance(Test, Test)]


@jstest
def test_min_args():
    return min(1, 0, 3, -5, 30)


@jstest
def test_min_iterable():
    return min([1, 0, 3, -5, 30])


@jstest
def test_max_args():
    return max(1, 0, 3, -5, 30)


@jstest
def test_max_iterable():
    return max([1, 0, 3, -5, 30])


@jstest
def test_round():
    return [round(1.6), round(1.4), round(1.5), round(3.14159265359, 3)]


@jstest
def test_abs():
    return abs(-3)


@jstest
def test_type():
    a = 1
    b = 1.0
    c = "test"
    d = False
    return False
    return [type(a), type(b), type(c), type(d)]


@jstest
def test_divmod():
    return list(divmod(143, 18))


@jstest
def test_negative_divmod():
    return list(divmod(-86340, 24 * 3600))


@jstest
def test_range():
    return [i for i in range(10)]


@jstest
def test_issubclass():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D:
        pass

    return (
        not issubclass(A, B)
        and issubclass(B, A)
        and issubclass(C, A)
        and not issubclass(D, A)
    )


@jstest
def test_sums():
    return sum([1], 2) + sum([10, 30, 40]) + sum([13, 16, 19], 3)


@jstest
def test_map():
    return list(map(lambda x: x + 1, [1, 2, 3, 4, 5, 6]))
