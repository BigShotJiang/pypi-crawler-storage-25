from helpers import jstest


@jstest
def test_If():
    if True:
        return 1


@jstest
def test_Else():
    if False:
        return 0
    else:
        return 1


@jstest
def test_ElseIf():
    if False:
        return 0
    elif True:
        return 1
    else:
        return 0
