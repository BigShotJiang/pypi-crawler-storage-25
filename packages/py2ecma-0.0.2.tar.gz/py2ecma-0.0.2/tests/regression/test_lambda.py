from helpers import jstest


@jstest
def test_function_lambda():
    def _test(f, arg1, arg2):
        return f(arg1, arg2)

    return _test(lambda x, y: x + y, 1, 2)


@jstest
def test_lambda_1():
    f1 = lambda x: lambda y: x + y
    inc = f1(1)
    plus10 = f1(10)
    return [inc(1), plus10(5)]


@jstest
def test_lambda_2():
    f2 = lambda x: (lambda: lambda y: x + y)()
    inc = f2(1)
    plus10 = f2(10)
    return [inc(1), plus10(5)]


@jstest
def test_lambda_3():
    f3 = lambda x: lambda y: global_x + y
    global_x = 1
    inc = f3(None)
    return inc(2)


@jstest
def test_lambda_4():
    f8 = lambda x, y, z: lambda a, b, c: lambda: z * (b + y)
    g = f8(1, 2, 3)
    h = g(2, 4, 6)
    return h()


@jstest
def test_lambda_5():
    def x(y=lambda: True):
        return y()

    return x()
