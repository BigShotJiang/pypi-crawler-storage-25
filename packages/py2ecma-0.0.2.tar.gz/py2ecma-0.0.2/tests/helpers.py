import functools
import inspect
import json

# import execjs
# import execjs._exceptions as exceptions
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import py
import pytest
from pyfakefs.fake_filesystem import FakeFilesystem

# from nodejs import node, npm, npx
from pyfakefs.fake_filesystem_unittest import Patcher

from py2ecma.linker.jsloader import jssources
from py2ecma.transpiler import transpile, transpiler


def execute(source: str, fs=None) -> str:
    def run_real():
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".js",
            delete=False,
        ) as f:
            f.write(source)
            path = f.name

        try:
            proc = subprocess.run(
                ["node", "--abort-on-uncaught-exception", path],
                capture_output=True,
                text=True,
            )

            if proc.returncode != 0:
                raise Exception(f"Exception in execute of js: {proc.stderr}")

            return proc.stdout
        finally:
            os.unlink(path)

    if fs is None:
        return run_real()

    fs.pause()
    try:
        return run_real()
    finally:
        fs.resume()


# def execute(source: str) -> str:
#    with tempfile.NamedTemporaryFile(
#        mode="w",
#        suffix=".js",
#        delete=True,
#    ) as f:
#        f.write(source)
#        path = f.name
#        f.flush()
#
#        #proc: subprocess.CompletedProcess = node.run([
#        #    f.name, "--abort-on-uncaught-exception"],
#        #    capture_output=True)
#        proc = subprocess.run(
#            [node.path, "--abort-on-uncaught-exception", f.name],
#            capture_output=True,
#            text=True,
#            # check=True,
#        )
#        proc.check_returncode()
#        result = proc.stdout
#        print(f"stderr {proc.stderr}")
#        print(f"{proc.returncode}")
#        exception = proc.returncode
#        if proc.returncode != 0:
#            print(f"TEST EXCEPTION: {exception}")
#            raise Exception(f"Exception in execute of js: {proc.stderr}")
#        print(f"TEST JS RESULT: {result}")
#    return result

from py2ecma.linker.jsloader import jssources
from py2ecma.transpiler import transpile, transpiler

# def execute(source: str) -> str:
#    with tempfile.NamedTemporaryFile(
#        mode="w",
#        suffix=".js",
#        delete=True,
#    ) as f:
#        f.write(source)
#        f.flush()
#
#        proc = subprocess.run(
#            [node.path, "--abort-on-uncaught-exception", f.name],
#            capture_output=True,
#            text=True,
#            # check=True,
#        )
#
#        result = proc.stdout
#        print(f"stderr {proc.stderr}")
#        exception = proc.returncode
#        if exception != 0:
#            print(f"TEST EXCEPTION: {exception}")
#            raise Exception(f"Exception in execute of js: {proc.stderr}")
#        print(f"TEST JS RESULT: {result}")
#    return result


def jsbenchmark(func):

    def run(benchmark):
        result = benchmark(func)
        return result

    return run


def js_test_source(func_name: str, js_body: str) -> str:
    return (
        jssources()
        + "\n"
        + js_body
        + f"\nconsole.log(JSON.stringify({func_name}()));\n"
    )


def jstest(func):
    func_name: str = func.__name__
    py_lines = inspect.getsourcelines(func)[0]
    py_src = "".join(py_lines[1:])
    js_body = transpile(py_src)
    js_src = js_test_source(func_name, js_body)

    def assertion():
        py_result = func()

        def run():
            return execute(js_src)

        js_result = json.loads(run())

        py_result = str(py_result) if isinstance(js_result, str) else py_result

        print(f"assert { py_result } == { js_result }")
        assert py_result == js_result, f"{py_result} != {js_result}"

    return assertion


def jsonly(func):
    location = os.path.dirname(inspect.getfile(func))
    py_lines = inspect.getsourcelines(func)[0]
    py_src = "".join(py_lines[1:])
    js_body = transpile(py_src, file_=location)
    js_src = jssources() + "\n" + js_body

    func_name = func.__name__

    def assertion():

        def run():
            result = execute(js_src)
            return result

        run()

    return assertion


def jsexception(exception):
    def wrap(func):
        py_lines = inspect.getsourcelines(func)[0]
        py_src = "".join(py_lines[1:])
        js_src = jssources() + "\n" + transpile(py_src)

        func_name = func.__name__

        def assertion():
            success = False
            try:
                func()
            except exception:
                success = True

            assert success

            def run():

                try:
                    result = execute(js_src)
                    print(result)
                    return True
                except Exception:
                    return True

            assert (
                run()
            ), "Test function did not " "as expected raise {} exception".format(
                exception.__name__
            )
            return True

        return assertion

    return wrap


Patcher.SKIPMODULES.add(py)


def walk(p):
    print("WALK!")
    for root, dirs, files in os.walk(p):
        path = root.split(os.sep)
        print((len(path) - 1) * "---", os.path.basename(root))
        for file in files:
            print(len(path) * "---", file)


# TODO: This can in the future be a better solution.
# def jsfstest(data_dir, cwd="", py_path=""):
#    def wrap(func):
#        func_name = func.__name__
#
#        def assertion(tmp_path):
#            current_pypath = list(sys.path)
#
#            py_lines = inspect.getsourcelines(func)[0]
#            py_src = "".join(py_lines[1:])
#
#            test_root = tmp_path
#            main_file = test_root / "main.py"
#            main_file.write_text(py_src)
#
#            try:
#                sys.path.append(str(test_root))
#
#                py_result = func()
#
#                transpiler(
#                    str(main_file),
#                    str(test_root / "bundle.js"),
#                    build_dir=str(test_root / "build"),
#                    clean_build=True,
#                )
#
#                js_body = (test_root / "bundle.js").read_text()
#                js_src = (
#                    js_body
#                    + f"\nlet func = __exports__['main']()['{func_name}'];"
#                    + "\nconsole.log(JSON.stringify(func()));\n"
#                )
#
#                js_result = (
#                    execute(js_src)
#                    .replace("\n", "")
#                    .replace("true", "True")
#                    .replace("false", "False")
#                )
#
#                pyr = (
#                    repr(py_result)
#                    .replace("'", '"')
#                    .replace("true", "True")
#                    .replace("false", "False")
#                )
#
#                assert pyr == js_result
#
#            finally:
#                sys.path[:] = current_pypath
#
#        return assertion
#
#    return wrap


def jsfstest(data_dir, cwd="", py_path=""):

    def wrap(func):
        func_name: str = func.__name__

        def assertion(fs):
            current_pypath = list(sys.path)
            py_lines = inspect.getsourcelines(func)[0]
            py_src_path = os.path.dirname(inspect.getsourcefile(func))
            transpiler_path = os.path.dirname(inspect.getsourcefile(transpiler))
            jsfiles = os.path.join(transpiler_path, "javascript")
            linker = os.path.join(transpiler_path, "linker")
            modules = os.path.join(transpiler_path, "modules")
            py_src = "".join(py_lines[1:])

            abs_data_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), data_dir
            )

            # Setup sys.paths
            sys.path.append(os.path.join(abs_data_dir, py_path))
            sys.path.insert(0, os.path.join(py_src_path, cwd))
            fs.add_real_directory(abs_data_dir, read_only=False)
            fs.add_real_directory(jsfiles, read_only=False)
            fs.add_real_directory(linker, read_only=False)
            fs.add_real_directory(modules, read_only=False)

            # Compute path for main file
            main_file = os.path.join(py_src_path, cwd, "main.py")

            with open(main_file, "w") as f:
                f.write(py_src)

            py_result = func()
            transpiler(main_file, "bundle.js", build_dir="build", clean_build=True)
            with open("bundle.js") as f:
                js_body = f.read()
                js_src = (
                    js_body
                    + f"\n let func = __exports__['main']()['{func_name}'];"
                    + f"\nconsole.log(JSON.stringify(func()));\n"
                )

            try:
                js_result = (
                    execute(js_src, fs=fs)
                    .replace("\n", "")
                    .replace("true", "True")
                    .replace("false", "False")
                )
                # js_ctx = execjs.compile(js_src)
                # js_result = js_ctx.call('__import__("main").{}'.format(func_name), [])
            except RuntimeError as e:
                print(str(e).replace("\\n", "\n"))
                raise e
            finally:
                sys.path[:] = current_pypath
            pyr = (
                repr(py_result)
                .replace("'", '"')
                .replace("true", "True")
                .replace("false", "False")
            )
            print("js-> ", js_result)
            print("py-> ", pyr)
            assert pyr == js_result

        return assertion

    return wrap
