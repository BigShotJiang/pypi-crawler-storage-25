# from module import test, test_module
import os
import sys

file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)
print(sys.path)

import module

a = module.test() + module.test_module()
print(a)
