import pytest
from helpers import jsfstest


@jsfstest(data_dir="imports")
def test_simple_import():
    import simple

    return simple.simple()


@jsfstest(data_dir="imports")
def test_simple_as_import():
    import simple as s

    return s.simple()


@jsfstest(data_dir="imports")
def test_simple_from_import():
    from simple import simple

    return simple()


@jsfstest(data_dir="imports")
def test_simple_from_as_import():
    from simple import simple as f

    return f()


@pytest.mark.skip("This is marked as skipped, it is properly not needed anymore")
@jsfstest(data_dir="imports", cwd="resources/src", py_path="resources/")
def test_simple_shared_import():
    import sharedt

    sharedt.t()


@jsfstest(data_dir="imports")
def test_relative_import():
    from resources.relative.rel import test

    return test()


@jsfstest(data_dir="imports", cwd="resources/")
def test_module():
    from module import test_module, testB

    a = testB() + test_module()
    return a
