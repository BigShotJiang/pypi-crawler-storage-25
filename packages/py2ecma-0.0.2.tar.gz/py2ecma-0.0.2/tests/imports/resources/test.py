def test_simple_shared_import():
    import sharedt

    sharedt.t()


test_simple_shared_import()
