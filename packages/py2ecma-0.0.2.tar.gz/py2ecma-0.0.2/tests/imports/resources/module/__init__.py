from .testthis import testA


def test_module():
    return "f"


testB = testA


# __all__ = ['testB', 'test_module']
