from .sec import CONSTANT


def test():
    return CONSTANT
