def simple():
    return True
