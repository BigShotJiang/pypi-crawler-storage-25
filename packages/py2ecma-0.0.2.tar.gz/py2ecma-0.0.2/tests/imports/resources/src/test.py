import sys

sys.path.append("../")


def test_simple_shared_import():
    import sharedt

    return sharedt.t()


print(test_simple_shared_import())
