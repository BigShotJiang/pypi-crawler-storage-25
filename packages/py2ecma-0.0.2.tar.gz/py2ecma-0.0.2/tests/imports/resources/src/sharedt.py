from shared.sharedlib import Test


def t():
    return Test()
