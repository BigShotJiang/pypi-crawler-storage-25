class Test:
    def __init__(self):
        self.test = True
