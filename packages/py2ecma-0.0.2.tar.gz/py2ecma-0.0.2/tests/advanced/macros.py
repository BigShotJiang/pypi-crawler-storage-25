from helpers import jsonly


@jsonly
def test_jsload():
    from py2ecma import jsload

    test = jsload("{}", "../resources/jsload.js")
    assert test == 42
