from helpers import jstest


@jstest
def test_classes():
    class Field:
        value = None

        def set_value(self, value):
            self.value = value

    class Parent:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                field = getattr(self, k)
                if isinstance(field, Field):
                    field.set_value(v)

        def __setattr__(self, name, value):
            field = getattr(self, name)
            if isinstance(field, Field):
                field.set_value(value)

        def __getattr__(self, name):
            return self.__getattribute__(name)

    class Child(Parent):
        test = Field()

    c = Child()
    test1 = c.test.value
    c.test = "test1"
    test2 = c.test.value

    d = Child(test="test2")
    test3 = d.test.value
    d.test = "test3"
    test4 = d.test.value
    return [test1, test2, test3, test4]


@jstest
def test_iteration():
    class Field:
        value = None

        def __init__(self, value):
            self.value = value

    s = []
    for i in range(10):
        s.append(Field(i))

    return [x.value for x in s]
