from helpers import jsfstest

# @jsfstest(data_dir='advanced', cwd="../../")
# def test_setters_inherited():
#     import copy
#
#     class Field:
#         value = None
#
#         def set_value(self, value):
#             self.value = value
#
#     class Model:
#         _fields = []
#         inited = False
#
#         def __init__(self, **kwargs):
#             kwargs = dict(kwargs)
#             self._fields: Dict[str, Field] = {}
#             for k, v in self.__class__.__dict__.items():
#                 if isinstance(v, Field):
#                     self._fields[k] = copy.copy(v)
#                     val = self._fields[k].value
#                     super().__setattr__(k, val)
#             for kw, value in kwargs.items():
#                 if kw in self._fields:
#                     try:
#                         self._fields[kw].set_value(value)
#                         setattr(self, kw, value)
#                     except ValueError as e:
#                         raise ValueError(e.args[0] + " for field {}".format(kw))
#             self.inited = True
#
#         def __setattr__(self, attr, value):
#             if self.has_field(attr):
#                 self._fields[attr].set_value(value)
#                 value = self._fields[attr].value
#                 super().__setattr__(attr, value)
#             else:
#                 super().__setattr__(attr, value)
#
#         def has_field(self, field: str):
#             return field in self._fields
#
#     class Child(Model):
#         test = Field()
#
#     child = Child(test=42)
#     t1 = child.test
#     child.test = 60
#     t2 = child.test
#     return [t1, t2]
