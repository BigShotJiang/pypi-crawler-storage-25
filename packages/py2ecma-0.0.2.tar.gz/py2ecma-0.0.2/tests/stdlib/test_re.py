import pytest
from helpers import jsfstest


@pytest.mark.skip("Regular expressions are not currently supported")
@jsfstest(data_dir="stdlib", cwd="../../")
def test_search_star_plus():
    import re

    assert re.search("x*", "axx").span(0) == (0, 0)
    assert re.search("x*", "axx").span() == (0, 0)
    assert re.search("x+", "axx").span(0) == (1, 3)
    assert re.search("x+", "axx").span() == (1, 3)
    assert re.search("x", "aaa") is None
    assert re.match("a*", "xxx").span(0) == (0, 0)
    assert re.match("a*", "xxx").span() == (0, 0)
    assert re.match("x*", "xxxa").span(0) == (0, 3)
    assert re.match("x*", "xxxa").span() == (0, 3)
    assert re.match("a+", "xxx") is None
    return True
