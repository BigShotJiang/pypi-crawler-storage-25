import pytest
from helpers import jsfstest


@jsfstest(data_dir="stdlib", cwd="../../")
def test_time_import():
    import time

    return []


@jsfstest(data_dir="stdlib", cwd="../../")
def test_time_time():
    from time import time

    return round(time() // 100)


@jsfstest(data_dir="stdlib", cwd="../../")
def test_time_gmtime():
    from time import gmtime

    return str(list(gmtime(33333333)))


@pytest.mark.skip
# @jsfstest(data_dir="stdlib", cwd="../../")
def test_time_strf():
    from time import gmtime, strftime

    return strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime(33333333))


@jsfstest(data_dir="stdlib", cwd="../../")
def test_datetime():
    import datetime

    return ""


@jsfstest(data_dir="stdlib", cwd="../../")
def test_date_today():
    from datetime import date

    today = date.today()
    return str(today)  # .isoformat()
