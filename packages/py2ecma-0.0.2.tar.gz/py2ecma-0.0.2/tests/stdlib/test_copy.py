from helpers import jsfstest

# @jsfstest(data_dir="stdlib", cwd="../../")
# def test_shallow_copy_dict():
#     from copy import copy
#
#     a = {"test": 2}
#     b = copy(a)
#     b["test"] = 30
#     return str(a)
#
#
# @jsfstest(data_dir="stdlib", cwd="../../")
# def test_shallow_copy_class():
#     from copy import copy
#
#     class D:
#         def __init__(self, t):
#             self.test = t
#
#     class Test:
#
#         d = D("test")
#
#         def __init__(self):
#             self.a = 1
#             self.b = {"test": 30}
#             self.c = None
#
#         def set_c(self, value):
#             self.c = value
#
#     a = Test()
#     b = copy(a)
#     a.set_c(666)
#     b.a = 42
#     b.b["test"] = 60
#     b.set_c(1337)
#     return [a.a, a.b["test"], a.c, a.d.test, b.a, b.b["test"], b.c, b.d.test]


@jsfstest(data_dir="stdlib", cwd="../../")
def test_shallow_copy_class_with_boundmethods():
    from copy import copy

    class Test:
        def __init__(self):
            self.a = 1
            self.b = {"test": 30}
            self.c = None

        def set_c(self, value):
            self.c = value

    a = Test()
    b = copy(a)
    a.set_c(666)
    b.a = 42
    b.b["test"] = 60
    b.set_c(1337)
    return str([a.a, a.b["test"], a.c, b.a, b.b["test"], b.c])


@jsfstest(data_dir="stdlib", cwd="../../")
def test_shallow_copy_with_obj_attr():
    from copy import copy

    class TestType:
        pass

    class Test:
        def __init__(self, _type):
            self._type = _type

        def check(self, tt):
            return isinstance(tt, self._type)

    t = Test(TestType)
    t_copy = copy(t)
    tt = TestType()
    return t_copy.check(tt)
