from helpers import jsfstest


@jsfstest(data_dir="stdlib", cwd="../../")
def test_modf():
    from math import modf

    a, _ = modf(40.34)
    return a
