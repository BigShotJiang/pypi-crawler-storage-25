from helpers import jsfstest


@jsfstest(data_dir="stdlib", cwd="../../")
def test_json_loads():
    from json import loads

    return str(loads("[1, 2]"))


@jsfstest(data_dir="stdlib", cwd="../../")
def test_json_dumps():
    from json import dumps

    return dumps([2, 3, 4, 60, 20, 100]).replace(" ", "")


@jsfstest(data_dir="stdlib", cwd="../../")
def test_json_loads_converts_list():
    from json import loads

    obj_list = loads("[1, 2]")
    return isinstance(obj_list, list)


@jsfstest(data_dir="stdlib", cwd="../../")
def test_json_loads_converts_dict():
    from json import loads

    obj_dict = loads('{"test": 1, "list": [1, 2, 3, 4]}')
    return isinstance(obj_dict, dict) and isinstance(obj_dict["list"], list)
