#!/bin/sh

src/py2ecma/main.py $@
