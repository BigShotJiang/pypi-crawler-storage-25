.. py2ecma documentation master file, created by
   sphinx-quickstart on Tue Jun 26 13:02:47 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to py2ecma's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

api/modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
