py2ecma.dependency package
==========================

Submodules
----------

py2ecma.dependency.excludes module
----------------------------------

.. automodule:: py2ecma.dependency.excludes
    :members:
    :undoc-members:
    :show-inheritance:

py2ecma.dependency.getdeps module
---------------------------------

.. automodule:: py2ecma.dependency.getdeps
    :members:
    :undoc-members:
    :show-inheritance:

py2ecma.dependency.sortedset module
-----------------------------------

.. automodule:: py2ecma.dependency.sortedset
    :members:
    :undoc-members:
    :show-inheritance:

py2ecma.dependency.spec module
------------------------------

.. automodule:: py2ecma.dependency.spec
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: py2ecma.dependency
    :members:
    :undoc-members:
    :show-inheritance:
