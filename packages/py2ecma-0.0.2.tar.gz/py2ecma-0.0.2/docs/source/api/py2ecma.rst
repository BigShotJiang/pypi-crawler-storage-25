py2ecma package
===============

Subpackages
-----------

.. toctree::

    py2ecma.codegenerator
    py2ecma.dependency
    py2ecma.lexer
    py2ecma.linker
    py2ecma.watcher

Submodules
----------

py2ecma.conf module
-------------------

.. automodule:: py2ecma.conf
    :members:
    :show-inheritance:

py2ecma.filesystem module
-------------------------

.. automodule:: py2ecma.filesystem
    :members:
    :show-inheritance:

py2ecma.transpiler module
-------------------------

.. automodule:: py2ecma.transpiler
    :members:
    :show-inheritance:


Module contents
---------------

.. automodule:: py2ecma
    :members:
    :show-inheritance:
