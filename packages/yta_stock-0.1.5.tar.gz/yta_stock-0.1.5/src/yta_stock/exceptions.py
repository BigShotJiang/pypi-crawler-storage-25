from typing import Union


# TODO: This exception should be sent by each
# provider as it is more descriptive than the
# one we are using in 'yta_stock_common'
class NoResourcesFoundError(Exception):
    """
    Raised when a provider successfully processes
    the request but finds no resources matching the
    query.
    """

    def __init__(
        self,
        query: str,
        provider: Union[str, None] = None
    ):
        self.query = query
        self.provider = provider

        message = f"No resources found for query='{query}'"
        message = (
            f"{message} in provider='{provider}'"
            if provider else
            message
        )
            

        super().__init__(message)