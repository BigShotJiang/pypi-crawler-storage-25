from yta_stock.exceptions import NoResourcesFoundError
from yta_stock_pexels import Pexels
from yta_stock_pexels.enum import PexelsSizeFilter, PexelsOrientation, PexelsLocale
from yta_stock_pixabay import Pixabay
from yta_programming.output import Output
from yta_constants.file import ImageFileExtension, VideoFileExtension
from typing import Union, Iterator, AsyncIterator


class StockPlatforms:
    """
    Class to handle the functionality related
    to downloading stock images or videos with
    different stock APIs.

    It is just a wrapper of the different
    providers we have, but doesn't add any
    extra functionality.
    """


    def __init__(
        self,
        do_ignore_repeated: bool = False
    ):
        self._do_ignore_repeated: bool = do_ignore_repeated
        """
        Internal flag to indicate if we are 
        ignoring the repeated resources or not.
        """
        self.pixabay: Pixabay = Pixabay(
            do_ignore_repeated_images = do_ignore_repeated,
            do_ignore_repeated_videos = do_ignore_repeated
        )
        """
        The Pixabay stock handler.
        """
        self.pexels: Pexels = Pexels(
            do_ignore_repeated_images = do_ignore_repeated,
            do_ignore_repeated_videos = do_ignore_repeated
        )
        """
        The Pexels stock handler.
        """


    def reset(
        self
    ):
        """
        This method will empty the array that handles 
        the duplicated ids (if activated) to enable 
        downloading any image found again. This method
        will also reset its platform-specific 
        downloader instances.
        """
        self.pexels.reset()
        self.pixabay.reset()


# TODO: I should implement a way of using pagination
# and look for next page results if not found in the
# current page and a behaviour like that

class _StockImage:
    """
    The images section of the main stock class,
    to be instantiated and used internally by 
    the Stock class.
    """


    def __init__(
        self,
        pixabay: Pixabay,
        pexels: Pexels
    ):
        self._pixabay: Pixabay = pixabay
        """
        The Pixabay stock handler.
        """
        self._pexels: Pexels = pexels
        """
        The Pexels stock handler.
        """


    def reset(
        self
    ):
        """
        This method will empty the array that handles 
        the duplicated ids (if activated) to enable 
        downloading any image found again. This method
        will also reset its platform-specific 
        downloader instances.
        """
        self._pixabay.images.reset()
        self._pexels.images.reset()


    async def stream(
        self,
        query: str,
        ids_to_ignore: list[int] = []
    ):
        """
        Get an image from the first platform that has one
        available, according to the `query` provided, as
        a stream.

        This method will raise an Exception if there
        are no results.
        """
        try:
            async for chunk in self._pexels.images.stream(
                query = query,
                ids_to_ignore = ids_to_ignore
            ):
                yield chunk
        except:
            pass

        try:
            async for chunk in self._pixabay.images.stream(
                query = query,
                ids_to_ignore = ids_to_ignore
            ):
                yield chunk
        except:
            pass

        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')


    async def download(
        self,
        query: str,
        ids_to_ignore: list[int] = [],
        output_filename: Union[str, None] = None
    ) -> 'FileReturned':
        """
        Download an image from the first platform that
        has results according to the provided 'query'
        and stores it locally.

        This method will raise an Exception if there
        are no results.
        """
        output_filename = Output.get_filename(output_filename, ImageFileExtension)

        try:
            image = await self._pexels.images.download(
                query = query,
                # TODO: This cannot be customized by now
                locale = PexelsLocale.ES_ES,
                orientation = PexelsOrientation.LANDSCAPE,
                size = PexelsSizeFilter.LARGE,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return image
        except:
            pass

        try:
            image = await self._pixabay.images.download(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return image
        except:
            pass

        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')
    

    async def stream_random(
        self,
        query: str,
        ids_to_ignore: Union[list[int], None] = None
    ) -> AsyncIterator[bytes]:
        """
        Get a random image, from the first platform that
        has results for the `query` provided, as a stream.

        To use this method you should do this:
        ```
        async for chunk in .stream_random(...):
            pass
        ```

        This method will raise an Exception if there
        are no results.
        """
        ids_to_ignore = ids_to_ignore or []

        providers = [
            self._pexels.images,
            self._pixabay.images,
        ]

        last_error = None

        for provider in providers:
            try:
                stream = provider.stream_random(
                    query = query,
                    ids_to_ignore = ids_to_ignore
                )

                # Validate generator
                first_chunk = await anext(stream)

                yield first_chunk

                async for chunk in stream:
                    yield chunk

                return

            except NoResourcesFoundError:
                # No results
                continue
            except Exception as e:
                last_error = e
                continue

        raise NoResourcesFoundError(
            query = query
        ) from last_error
    

    async def download_random(
        self,
        query: str,
        ids_to_ignore: list[int] = [],
        output_filename: Union[str, None] = None
    ) -> 'FileReturned':
        """
        Download a random image from the first platform
        that has results according to the provided 'query'
        and stores it locally.

        This method will raise an Exception if there
        are no results.
        """
        output_filename = Output.get_filename(output_filename, ImageFileExtension)

        try:
            image = await self._pexels.images.download_random(
                query = query,
                # TODO: This cannot be customized by now
                locale = PexelsLocale.ES_ES,
                orientation = PexelsOrientation.LANDSCAPE,
                size = PexelsSizeFilter.LARGE,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )
            
            return image
        except:
            pass

        try:
            image = await self._pixabay.images.download_random(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return image
        except:
            pass
        
        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')
        

class _StockVideo:
    """
    The videos section of the main stock class,
    to be instantiated and used internally by 
    the Stock class.
    """


    def __init__(
        self,
        pixabay: Pixabay,
        pexels: Pexels
    ):
        """
        The Stock class must instantiate this one
        by providing its own providers instances.
        """
        self._pixabay: Pixabay = pixabay
        """
        The Pixabay stock handler.
        """
        self._pexels: Pexels = pexels
        """
        The Pexels stock handler.
        """


    def reset(
        self
    ):
        """
        This method will empty the array that handles 
        the duplicated ids (if activated) to enable 
        downloading any image found again. This method
        will also reset its platform-specific 
        downloader instances.
        """
        self._pixabay.videos.reset()
        self._pexels.videos.reset()


    async def stream(
        self,
        query: str,
        ids_to_ignore: list[int] = []
    ) -> AsyncIterator[bytes]:
        """
        Get a video from the first platform that has one
        available, according to the `query` provided, as
        a stream.

        This method will raise an Exception if there
        are no results.
        """
        try:
            async for chunk in self._pexels.videos.stream(
                query = query,
                ids_to_ignore = ids_to_ignore
            ):
                yield chunk

            return
        except:
            pass

        try:
            async for chunk in self._pixabay.videos.stream(
                query = query,
                ids_to_ignore = ids_to_ignore
            ):
                yield chunk

            return
        except:
            pass

        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')


    async def download(
        self,
        query: str,
        ids_to_ignore: list[int] = [],
        output_filename: Union[str, None] = None
    ) -> 'FileReturned':
        """
        Download a video from the first platform that
        has results according to the provided 'query'
        and stores it locally.

        This method will raise an Exception if there
        are no results.
        """
        output_filename = Output.get_filename(output_filename, VideoFileExtension)

        try:
            video = await self._pexels.videos.download(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return video
        except:
            pass
        
        try:
            video = await self._pixabay.videos.download(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return video
        except:
            pass

        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')
    

    async def stream_random(
        self,
        query: str,
        ids_to_ignore: Union[list[int], None] = None
    ) -> Iterator[bytes]:
        """
        Get a random video, from the first platform that
        has results for the `query` provided, as a stream.

        To use this method you should do this:
        ```
        async for chunk in .stream_random(...):
            pass
        ```

        This method will raise an Exception if there
        are no results.
        """
        ids_to_ignore = ids_to_ignore or []

        providers = [
            self._pexels.videos,
            self._pixabay.videos,
        ]

        last_error = None

        for provider in providers:
            try:
                stream = provider.stream_random(
                    query = query,
                    ids_to_ignore = ids_to_ignore
                )

                # Validate generator
                first_chunk = await anext(stream)

                yield first_chunk

                async for chunk in stream:
                    yield chunk

                return

            except NoResourcesFoundError:
                # No results
                continue
            except Exception as e:
                last_error = e
                continue

        raise NoResourcesFoundError(
            query = query
        ) from last_error


    async def download_random(
        self,
        query: str,
        ids_to_ignore: list[int] = [],
        output_filename: Union[str, None] = None
    ) -> 'FileReturned':
        """
        Download a random video from the first platform
        that has results according to the provided 'query'
        and stores it locally.

        This method will raise an Exception if there
        are no results.
        """
        output_filename = Output.get_filename(output_filename, VideoFileExtension)

        try:
            video = await self._pexels.videos.download_random(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return video
        except:
            pass

        try:
            video = await self._pixabay.videos.download_random(
                query = query,
                ids_to_ignore = ids_to_ignore,
                output_filename = output_filename
            )

            return video
        except:
            pass
        
        # TODO: Use another provider when available
        raise Exception('No results found with any of our providers.')


class Stock:
    """
    Class to handle the functionality related
    to downloading stock images or videos with
    different stock APIs.
    """

    def __init__(
        self,
        do_ignore_repeated: bool = False
    ):
        self._do_ignore_repeated: bool = do_ignore_repeated
        """
        Internal flag to indicate if we are 
        ignoring the repeated resources or not.
        """

        self._pixabay: Pixabay = Pixabay(
            do_ignore_repeated_images = do_ignore_repeated,
            do_ignore_repeated_videos = do_ignore_repeated
        )
        """
        The Pixabay stock handler.
        """
        self._pexels: Pexels = Pexels(
            do_ignore_repeated_images = do_ignore_repeated,
            do_ignore_repeated_videos = do_ignore_repeated
        )
        """
        The Pexels stock handler.
        """

        self.images: _StockImage = _StockImage(
            pixabay = self._pixabay,
            pexels = self._pexels
        )
        """
        Handling images using different providers.
        """
        self.videos: _StockVideo = _StockVideo(
            pixabay = self._pixabay,
            pexels = self._pexels
        )
        """
        Handling videos using different providers.
        """