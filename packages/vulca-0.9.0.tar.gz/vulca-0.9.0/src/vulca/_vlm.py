"""VLM Critic -- core L1-L5 image evaluation via Gemini Vision."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

import litellm

logger = logging.getLogger("vulca")

# Local user data path -- preferred evolved context source
_LOCAL_EVOLVED_PATH = Path.home() / ".vulca" / "data" / "evolved_context.json"

_SYSTEM_PROMPT = """\
You are VULCA, a cultural-aware art evaluation system. Evaluate the given \
artwork image across five dimensions (L1-L5), each scored from 0.0 to 1.0.

## Dimension Definitions

- **L1 (Visual Perception)**: Composition, layout, spatial arrangement, visual \
clarity, color harmony, and overall visual impact.
- **L2 (Technical Execution)**: Rendering quality, detail precision, technique \
fidelity, medium-appropriate execution, and craftsmanship.
- **L3 (Cultural Context)**: Fidelity to cultural tradition, proper use of \
tradition-specific motifs/elements/terminology, adherence to canonical conventions.
- **L4 (Critical Interpretation)**: Respectful representation, absence of taboo \
violations, cultural sensitivity, appropriate contextual framing.
- **L5 (Philosophical Aesthetics)**: Artistic depth, emotional resonance, \
spiritual qualities, aesthetic harmony, and philosophical alignment with the tradition.

## Cultural Tradition: {tradition}

{tradition_guidance}

## Instructions

### Phase 1 — OBSERVE

Before scoring, describe what you see in the artwork in detail:
- Brushwork / rendering technique (type, quality, consistency)
- Color palette (dominant colors, harmony, contrast, temperature)
- Composition structure (layout, focal points, spatial relationships, depth)
- Texture and medium characteristics
- Subject matter and cultural elements present
- Use of space (negative space, layering, balance)

### Phase 2 — EVALUATE

Based on your observations, score each dimension 0.0-1.0. For each provide:
1. **observations**: 3-5 specific visual observations relevant to this dimension \
(factual descriptions, not judgments).
2. **rationale**: What you conclude from these observations (2-3 sentences).
3. **suggestion**: A SPECIFIC, ACTIONABLE improvement containing: \
(a) the exact technique name in original language if applicable, \
(b) how to apply it (e.g., "use broader horizontal strokes in the middle ground"), \
(c) what effect it would achieve. If the work excels, suggest how to push further.
4. **reference_technique**: The single most relevant traditional technique name \
for this dimension (bilingual if applicable, e.g., "reserved white space (留白)").
5. **deviation_type**: One of "traditional", "intentional_departure", or "experimental".

Respond with ONLY a JSON object:
{{
    "L1": <float>, "L1_observations": "<string>", "L1_rationale": "<string>", \
"L1_suggestion": "<string>", "L1_reference_technique": "<string>", "L1_deviation_type": "<string>",
    "L2": <float>, "L2_observations": "<string>", "L2_rationale": "<string>", \
"L2_suggestion": "<string>", "L2_reference_technique": "<string>", "L2_deviation_type": "<string>",
    "L3": <float>, "L3_observations": "<string>", "L3_rationale": "<string>", \
"L3_suggestion": "<string>", "L3_reference_technique": "<string>", "L3_deviation_type": "<string>",
    "L4": <float>, "L4_observations": "<string>", "L4_rationale": "<string>", \
"L4_suggestion": "<string>", "L4_reference_technique": "<string>", "L4_deviation_type": "<string>",
    "L5": <float>, "L5_observations": "<string>", "L5_rationale": "<string>", \
"L5_suggestion": "<string>", "L5_reference_technique": "<string>", "L5_deviation_type": "<string>"
}}
"""

def _build_extra_dimensions_prompt(extras: list[dict]) -> str:
    """Build prompt section for tradition-specific extra dimensions (E1-E3, max 3)."""
    if not extras:
        return ""
    # Limit to 3
    extras = extras[:3]
    lines = [
        "\n## Tradition-Specific Dimensions\n",
        "In addition to L1-L5, evaluate these tradition-specific dimensions:\n",
    ]
    for e in extras:
        lines.append(f"- **{e['key']} ({e['name']})**: {e['description']}")
    lines.append(
        "\nScore each with the same format as L1-L5 "
        "(observations, rationale, suggestion, reference_technique, deviation_type)."
    )
    return "\n".join(lines)


def _parse_vlm_response(
    raw: dict,
    *,
    extra_keys: list[str] | None = None,
) -> tuple[dict[str, float], dict[str, str], dict[str, str], dict[str, str], dict[str, str], dict[str, str]]:
    """Parse VLM JSON response into (scores, rationales, suggestions, deviations, observations, ref_techniques)."""
    scores: dict[str, float] = {}
    rationales: dict[str, str] = {}
    suggestions: dict[str, str] = {}
    deviations: dict[str, str] = {}
    observations: dict[str, str] = {}
    ref_techniques: dict[str, str] = {}

    for i in range(1, 6):
        key = f"L{i}"
        val = raw.get(key, 0.0)
        scores[key] = max(0.0, min(1.0, float(val))) if val else 0.0
        rationales[key] = str(raw.get(f"{key}_rationale", ""))
        suggestions[key] = str(raw.get(f"{key}_suggestion", ""))
        dev = str(raw.get(f"{key}_deviation_type", "traditional"))
        deviations[key] = dev if dev in ("traditional", "intentional_departure", "experimental") else "traditional"
        observations[key] = str(raw.get(f"{key}_observations", ""))
        ref_techniques[key] = str(raw.get(f"{key}_reference_technique", ""))

    # Parse extra dimensions (E1-E3)
    for key in (extra_keys or []):
        val = raw.get(key, 0.0)
        scores[key] = max(0.0, min(1.0, float(val))) if val else 0.0
        rationales[key] = str(raw.get(f"{key}_rationale", ""))
        suggestions[key] = str(raw.get(f"{key}_suggestion", ""))
        dev = str(raw.get(f"{key}_deviation_type", "traditional"))
        deviations[key] = dev if dev in ("traditional", "intentional_departure", "experimental") else "traditional"
        observations[key] = str(raw.get(f"{key}_observations", ""))
        ref_techniques[key] = str(raw.get(f"{key}_reference_technique", ""))

    return scores, rationales, suggestions, deviations, observations, ref_techniques


_TRADITION_GUIDANCE: dict[str, str] = {
    "default": "Apply general art evaluation principles. No specific cultural tradition.",
    "chinese_xieyi": (
        "Xieyi (\u5199\u610f) freehand ink wash painting. Prioritize: spontaneity of brushwork, "
        "use of blank space (\u7559\u767d), ink gradation (\u58a8\u5206\u4e94\u8272), qi-yun (\u6c14\u97f5) spiritual resonance, "
        "and harmony between poetry-calligraphy-painting-seal (\u8bd7\u4e66\u753b\u5370)."
    ),
    "chinese_gongbi": (
        "Gongbi (\u5de5\u7b14) meticulous painting. Prioritize: precision of line work, "
        "layered color application, fine detail rendering, and adherence to traditional subjects."
    ),
    "western_academic": (
        "Western academic tradition. Prioritize: anatomical accuracy, perspective, "
        "chiaroscuro, compositional balance, and narrative clarity."
    ),
    "islamic_geometric": (
        "Islamic geometric art. Prioritize: mathematical precision of patterns, "
        "symmetry, tessellation correctness, arabesque flow, and avoidance of figural representation."
    ),
    "japanese_traditional": (
        "Japanese traditional art (Nihonga/Ukiyo-e). Prioritize: flat color areas, "
        "bold outlines, seasonal motifs, wabi-sabi aesthetics, and mono no aware sentiment."
    ),
    "watercolor": (
        "Watercolor painting. Prioritize: transparency of washes, wet-in-wet technique, "
        "luminosity, paper-as-white usage, and freshness of application."
    ),
    "african_traditional": (
        "African traditional art. Prioritize: symbolic abstraction, mask conventions, "
        "community/ritual significance, material authenticity, and spiritual function."
    ),
    "south_asian": (
        "South Asian art traditions. Prioritize: miniature painting conventions, "
        "Mughal detail, color symbolism, narrative scenes, and decorative borders."
    ),
}


def _load_evolved_context() -> dict | None:
    """Load evolved_context.json, preferring local user file (~/.vulca/data/).

    Search order:
    1. VULCA_EVOLVED_CONTEXT env var (explicit override)
    2. _LOCAL_EVOLVED_PATH (~/.vulca/data/evolved_context.json), written by LocalEvolver
    """
    try:
        env_path = os.environ.get("VULCA_EVOLVED_CONTEXT")
        if env_path:
            p = Path(env_path)
            if p.is_file():
                return json.loads(p.read_text(encoding="utf-8"))
        if _LOCAL_EVOLVED_PATH.is_file():
            return json.loads(_LOCAL_EVOLVED_PATH.read_text(encoding="utf-8"))
    except Exception:
        logger.debug("Failed to load evolved context")
    return None


def _build_tradition_guidance(
    tradition: str,
    *,
    engram_fragments: list | None = None,
    active_dimensions: list[str] | None = None,
) -> str:
    """Build rich tradition guidance from YAML data, evolved context, and few-shot examples.

    Parameters
    ----------
    tradition:
        Tradition key (e.g. "chinese_xieyi").
    engram_fragments:
        Optional list of CulturalFragment objects retrieved from CulturalEngram.
        When provided, their content is injected into the prompt as "Cultural Memory".
    active_dimensions:
        Optional list of active L-dimension keys (e.g. ["L1", "L3", "L5"]).
        When provided, a focus hint is appended so the VLM prioritises these dims.
    """
    base = _TRADITION_GUIDANCE.get(tradition, _TRADITION_GUIDANCE["default"])

    try:
        from vulca.cultural.loader import get_tradition
        tc = get_tradition(tradition)
        if tc is None:
            parts = [base]
            _append_sparse_guidance(parts, engram_fragments, active_dimensions)
            return "\n".join(parts)

        parts = [base]

        if engram_fragments:
            # Engram mode: use selected fragments INSTEAD of full terminology/taboos
            # This is the key optimization — selective retrieval replaces full dump
            _append_sparse_guidance(parts, engram_fragments, active_dimensions)
        else:
            # Full mode: inject all terminology + taboos (original behavior)
            if tc.terminology:
                terms_text = "\n".join(
                    f"  - **{t.term}** ({t.term_zh}): {t.definition if isinstance(t.definition, str) else t.definition.get('en', '')}"
                    for t in tc.terminology[:8]
                )
                parts.append(f"\n### Key Cultural Terminology\n{terms_text}")

            if tc.taboos:
                taboos_text = "\n".join(
                    f"  - ⚠️ {t.rule}" + (f" — {t.explanation}" if t.explanation else "")
                    for t in tc.taboos
                )
                parts.append(f"\n### Evaluation Taboos (MUST respect)\n{taboos_text}")

            # Active dimension focus without engram (sparse eval only)
            if active_dimensions:
                _append_sparse_guidance(parts, None, active_dimensions)

        # Inject evolved weight guidance + few-shot examples (always, if available)
        evolved = _load_evolved_context()
        if evolved:
            _inject_evolved_guidance(parts, tradition, evolved)

        return "\n".join(parts)
    except Exception:
        logger.debug("Tradition guidance fallback for %s", tradition)
        return base


def _append_sparse_guidance(
    parts: list[str],
    engram_fragments: list | None,
    active_dimensions: list[str] | None,
) -> None:
    """Append engram fragments and active-dimension focus hint to prompt parts."""
    # Engram fragments (selective cultural knowledge)
    if engram_fragments:
        frag_lines = []
        for frag in engram_fragments:
            frag_lines.append(f"- [{frag.category}] {frag.content}")
        if frag_lines:
            parts.append("\n### Cultural Memory (Selected)\n" + "\n".join(frag_lines))

    # Active dimension focus hint
    if active_dimensions:
        dim_names = {
            "L1": "Visual Perception", "L2": "Technical Execution",
            "L3": "Cultural Context", "L4": "Critical Interpretation",
            "L5": "Philosophical Aesthetics",
        }
        focus_list = ", ".join(
            f"{d} ({dim_names.get(d, d)})" for d in active_dimensions
        )
        parts.append(f"\n### Evaluation Focus\nPrioritize these dimensions: {focus_list}")


_L_LABELS = {
    "L1": "Visual Perception", "L2": "Technical Execution",
    "L3": "Cultural Context", "L4": "Critical Interpretation",
    "L5": "Philosophical Aesthetics",
}

_DIM_NAME_TO_L = {
    "visual_perception": "L1", "technical_analysis": "L2",
    "cultural_context": "L3", "critical_interpretation": "L4",
    "philosophical_aesthetic": "L5",
}


def _inject_evolved_guidance(parts: list[str], tradition: str, evolved: dict) -> None:
    """Inject evolved weights and few-shot examples into the prompt."""
    # 1. Evolved weight emphasis — tell the VLM which dimensions matter most
    tw = evolved.get("tradition_weights", {}).get(tradition)
    if tw and isinstance(tw, dict):
        weights_l = {_DIM_NAME_TO_L.get(k, k): v for k, v in tw.items() if _DIM_NAME_TO_L.get(k)}
        if weights_l:
            ranked = sorted(weights_l.items(), key=lambda x: x[1], reverse=True)
            emphasis = ", ".join(f"{k} ({_L_LABELS.get(k, k)}) {v:.0%}" for k, v in ranked)
            parts.append(f"\n### Dimension Weights (from system evolution)\nPrioritize by weight: {emphasis}")

    # 2. Few-shot reference examples — calibrate scoring
    fse = evolved.get("few_shot_examples", [])
    tradition_examples = [ex for ex in fse if ex.get("tradition") == tradition][:2]
    if tradition_examples:
        examples_text = "\n".join(
            f"  - \"{ex.get('subject', 'N/A')}\" — overall {ex.get('score', 0):.2f}"
            + (f" (strengths: {', '.join(ex['key_strengths'])})" if ex.get('key_strengths') else "")
            for ex in tradition_examples
        )
        parts.append(f"\n### Reference Benchmarks (high-scoring works in this tradition)\n{examples_text}")

    # 3. Tradition-specific insights from evolution
    ti = evolved.get("tradition_insights", {}).get(tradition)
    if ti and isinstance(ti, str) and len(ti) < 300:
        parts.append(f"\n### Evolved Insight\n{ti}")


def _load_extra_dimensions(tradition: str) -> list[dict]:
    """Load extra_dimensions from tradition YAML config (if defined)."""
    try:
        from vulca.cultural.loader import get_tradition
        tc = get_tradition(tradition)
        if tc is None:
            return []
        # extra_dimensions is an optional list of dicts on TraditionConfig
        extras = getattr(tc, "extra_dimensions", None)
        if not extras:
            return []
        # Normalise: each item must have key, name, description
        result = []
        for item in extras:
            if isinstance(item, dict) and "key" in item and "name" in item:
                result.append({
                    "key": item["key"],
                    "name": item["name"],
                    "description": item.get("description", ""),
                })
        return result
    except Exception:
        logger.debug("Could not load extra_dimensions for tradition %s", tradition)
        return []


async def score_image(
    img_b64: str,
    mime: str,
    subject: str,
    tradition: str,
    api_key: str,
    *,
    engram_fragments: list | None = None,
    active_dimensions: list[str] | None = None,
) -> dict:
    """Call Gemini Vision to score an image on L1-L5.

    Returns a dict with L1-L5 scores and rationales, or fallback zeros on error.

    Parameters
    ----------
    engram_fragments:
        Optional CulturalFragment list from CulturalEngram retrieval.
    active_dimensions:
        Optional list of active L-dimension keys for focus hint in prompt.
    """
    tradition_guidance = _build_tradition_guidance(
        tradition,
        engram_fragments=engram_fragments,
        active_dimensions=active_dimensions,
    )

    # Load tradition-specific extra dimensions and build prompt extension
    extra_dims = _load_extra_dimensions(tradition)
    extra_prompt = _build_extra_dimensions_prompt(extra_dims)
    extra_keys = [e["key"] for e in extra_dims[:3]]

    system_msg = _SYSTEM_PROMPT.format(
        tradition=tradition.replace("_", " ").title(),
        tradition_guidance=tradition_guidance,
    )
    # Append extra dimensions prompt if any
    if extra_prompt:
        system_msg = system_msg + "\n" + extra_prompt

    user_parts = [
        {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{img_b64}"}},
    ]
    if subject:
        user_parts.append({"type": "text", "text": f"Subject/context: {subject}"})
    else:
        user_parts.append({"type": "text", "text": "Evaluate this artwork."})

    try:
        resp = await litellm.acompletion(
            model=os.environ.get("VULCA_VLM_MODEL", "gemini/gemini-2.5-flash"),
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": user_parts},
            ],
            max_tokens=6144,
            temperature=0.1,
            api_key=api_key,
            timeout=55,
        )
        text = resp.choices[0].message.content.strip()
        from vulca._parse import parse_llm_json
        parsed_json = parse_llm_json(text)

        # Use _parse_vlm_response to extract and validate all fields (including extras)
        scores, rationales, suggestions, deviations, observations, ref_techniques = _parse_vlm_response(
            parsed_json, extra_keys=extra_keys
        )

        # Rebuild flat dict (backward-compatible with callers expecting flat dict)
        data: dict = {}
        all_levels = list(("L1", "L2", "L3", "L4", "L5")) + extra_keys
        for level in all_levels:
            data[level] = scores.get(level, 0.0)
            data[f"{level}_rationale"] = rationales.get(level, "")
            data[f"{level}_suggestion"] = suggestions.get(level, "")
            data[f"{level}_deviation_type"] = deviations.get(level, "traditional")
            data[f"{level}_observations"] = observations.get(level, "")
            data[f"{level}_reference_technique"] = ref_techniques.get(level, "")
        # Store extra_keys and names in data so _engine.py can split core vs extra
        data["_extra_keys"] = extra_keys
        data["_extra_names"] = {e["key"]: e["name"] for e in extra_dims[:3]}

        return data

    except Exception as exc:
        logger.error("VLM scoring failed: %s", exc)
        fallback: dict = {"error": str(exc), "_extra_keys": extra_keys}
        for level in ("L1", "L2", "L3", "L4", "L5"):
            fallback[level] = 0.0
            fallback[f"{level}_rationale"] = f"Scoring failed: {exc}" if level == "L1" else ""
            fallback[f"{level}_suggestion"] = ""
            fallback[f"{level}_deviation_type"] = "traditional"
            fallback[f"{level}_observations"] = ""
            fallback[f"{level}_reference_technique"] = ""
        return fallback
