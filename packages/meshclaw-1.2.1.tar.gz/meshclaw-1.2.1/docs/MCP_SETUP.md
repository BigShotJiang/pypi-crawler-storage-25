# MCP Setup

MeshClaw is not a chat assistant. Codex, Claude, or a local LLM talks to the
user. MeshClaw exposes server state, policy decisions, safe execution, cleanup
plans, and evidence as tools.

## Binary

Build locally:

```sh
cd /Users/dragon/meshclaw
go build -o /Users/dragon/bin/meshclaw ./cmd/meshclaw
```

Run the MCP server:

```sh
/Users/dragon/bin/meshclaw mcp
```

## Codex/Claude MCP Command

Use this command for the MCP server:

```text
/Users/dragon/bin/meshclaw mcp
```

No extra environment is required. MeshClaw uses:

- vssh-native first execution over Tailscale/private routes
- `/Users/dragon/.meshclaw/evidence` for local evidence records

Default execution requires `Tailscale/private route + vssh server + VSSH_SECRET`.
SSH remains a compatibility fallback for nodes without vssh daemon coverage.

## Tools

- `meshclaw.server_list`
- `meshclaw.capability_list`
- `meshclaw.monitor_check`
- `meshclaw.autoheal_plan`
- `meshclaw.autoheal_apply_safe`
- `meshclaw.evidence_list`
- `meshclaw.policy_check`
- `meshclaw.provision_plan`
- `meshclaw.run_evidence`
- `meshclaw.disk_investigate`
- `meshclaw.data_clean_plan`
- `meshclaw.data_clean_apply`
- `meshclaw.analyze_logs`
- `meshclaw.security_check`
- `meshclaw.service_check`
- `meshclaw.service_quarantine`
- `meshclaw.service_remove`

## Operating Rule

Read-only and evidence-producing tools are allowed by default. Bounded safe
cleanup uses generated manifests. Destructive broad actions should be modeled as
plan first, then apply only from the generated manifest.
