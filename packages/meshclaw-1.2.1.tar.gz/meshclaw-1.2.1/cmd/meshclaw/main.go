package main

import (
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/doctor"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/workflow"
)

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}

	var err error
	switch os.Args[1] {
	case "list":
		err = list(os.Args[2:])
	case "capabilities":
		err = capabilities(os.Args[2:])
	case "status":
		err = status()
	case "monitor-check":
		err = monitorCheck(os.Args[2:])
	case "monitor-agent":
		err = monitorAgent(os.Args[2:])
	case "autoheal-plan":
		err = autohealPlan(os.Args[2:])
	case "autoheal-apply-safe":
		err = autohealApplySafe()
	case "disk-investigate":
		err = diskInvestigate(os.Args[2:])
	case "data-clean-plan":
		err = dataCleanPlan(os.Args[2:])
	case "data-clean-apply":
		err = dataCleanApply(os.Args[2:])
	case "evidence-list":
		err = evidenceList(os.Args[2:])
	case "policy-check":
		err = policyCheck(os.Args[2:])
	case "provision-plan":
		err = provisionPlan(os.Args[2:])
	case "run":
		err = run(os.Args[2:])
	case "run-evidence":
		err = runEvidence(os.Args[2:])
	case "doctor":
		err = runDoctor(os.Args[2:])
	case "analyze-logs":
		err = analyzeLogs(os.Args[2:])
	case "service-check":
		err = serviceCheck(os.Args[2:])
	case "service-quarantine":
		err = serviceQuarantine(os.Args[2:])
	case "service-remove":
		err = serviceRemove(os.Args[2:])
	case "security-check":
		err = securityCheck(os.Args[2:])
	case "hygiene-plan":
		err = hygienePlan(os.Args[2:])
	case "hygiene-scan-text":
		err = hygieneScanText(os.Args[2:])
	case "mcp":
		err = mcp()
	default:
		err = fmt.Errorf("unknown command: %s", os.Args[1])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "meshclaw:", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Println(`meshclaw - AI-native server operations control plane

Usage:
  meshclaw list
  meshclaw capabilities
  meshclaw status
  meshclaw monitor-check
  meshclaw monitor-agent [interval]
  meshclaw autoheal-plan
  meshclaw autoheal-apply-safe
  meshclaw disk-investigate <host> [path]
  meshclaw data-clean-plan <host> <path>
  meshclaw data-clean-apply <host> <manifest>
  meshclaw evidence-list [limit]
  meshclaw policy-check <subject> <action> <resource> [context]
  meshclaw provision-plan <purpose> [budget-usd]
  meshclaw run <host> <command>
  meshclaw run-evidence <host> <command>
  meshclaw doctor <host>
  meshclaw analyze-logs <host> <source>
  meshclaw service-check <host> <service>
  meshclaw service-quarantine <host> <service>
  meshclaw service-remove <host> <service> [working-directory]
  meshclaw security-check <host>
  meshclaw hygiene-plan <host>
  meshclaw hygiene-scan-text <target> <text>
  meshclaw mcp`)
}

func monitorAgent(args []string) error {
	interval := 5 * time.Minute
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw monitor-agent [interval]")
	}
	if len(args) == 1 {
		parsed, err := time.ParseDuration(args[0])
		if err != nil {
			return fmt.Errorf("invalid interval: %s", args[0])
		}
		if parsed < 10*time.Second {
			return fmt.Errorf("interval must be at least 10s")
		}
		interval = parsed
	}

	cfg := monitor.DefaultConfig()
	cfg.CheckInterval = interval
	m, err := monitor.New(cfg)
	if err != nil {
		return err
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	fmt.Printf("meshclaw monitor-agent interval=%s\n", interval)

	runOnce := func() {
		states := m.CheckAll()
		alerts := m.DetectAlerts()
		record, storeErr := evidence.Store("monitor-agent", "fleet", fmt.Sprintf("alerts=%d", len(alerts)), monitorCheckOutput{States: states, Alerts: alerts})
		fmt.Printf("monitor-agent check nodes=%d alerts=%d", len(states), len(alerts))
		if storeErr != nil {
			fmt.Printf(" evidence_error=%v", storeErr)
		} else {
			fmt.Printf(" evidence=%s", record.StoredAt)
		}
		fmt.Println()
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}

	runOnce()
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			runOnce()
		case <-stop:
			fmt.Println("meshclaw monitor-agent stopped")
			return nil
		}
	}
}

func list(args []string) error {
	if wantsJSON(args) {
		return printJSON(inventory.DefaultNodes())
	}
	fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", "NODE", "ROLE", "LOCATION", "TAILSCALE", "WIRE", "USER")
	for _, node := range inventory.DefaultNodes() {
		fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", node.Name, node.Role, node.Location, node.Tailscale, node.WireIP, node.User)
	}
	return nil
}

func capabilities(args []string) error {
	if wantsJSON(args) {
		return printJSON(capability.DefaultCapabilities())
	}
	fmt.Printf("%-18s %-13s %-14s %-18s %s\n", "ID", "KIND", "PROVIDER", "STATUS", "POLICY")
	for _, cap := range capability.DefaultCapabilities() {
		fmt.Printf("%-18s %-13s %-14s %-18s %s\n", cap.ID, cap.Kind, cap.Provider, cap.Status, cap.Policy)
	}
	return nil
}

func status() error {
	out, err := runtime.NewRunner().Status()
	fmt.Print(out)
	return err
}

type monitorCheckOutput struct {
	States map[string]*monitor.NodeState `json:"states"`
	Alerts []monitor.Alert               `json:"alerts"`
}

func monitorCheck(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	states := m.CheckAll()
	alerts := m.DetectAlerts()
	record, storeErr := evidence.Store("monitor-check", "fleet", fmt.Sprintf("alerts=%d", len(alerts)), monitorCheckOutput{States: states, Alerts: alerts})
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"states": states, "alerts": alerts, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("%-10s %-7s %-15s %6s %6s %s\n", "NODE", "ONLINE", "IP", "DISK", "MEM", "ERROR")
	for _, node := range inventory.DefaultNodes() {
		state := states[node.Name]
		if state == nil {
			continue
		}
		fmt.Printf("%-10s %-7t %-15s %5.1f%% %5.1f%% %s\n", state.Name, state.Online, state.IP, state.Disk, state.Memory, state.Error)
	}
	if len(alerts) > 0 {
		fmt.Println("alerts:")
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealPlan(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.Plan()
	record, storeErr := evidence.Store("autoheal-plan", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"actions": actions, "evidence": record, "store_error": errString(storeErr)})
	}
	if len(actions) == 0 {
		fmt.Println("autoheal status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal status=actions")
	for _, action := range actions {
		fmt.Printf("- [%s/%s] %s %s=%.1f mode=%s\n  command: %s\n  reason: %s\n  verify: %s\n",
			action.Severity, action.Type, action.Node, action.Metric, action.Value, action.Mode, action.Command, action.Reason, action.Verify)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealApplySafe() error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.CheckAndHeal()
	record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if len(actions) == 0 {
		fmt.Println("autoheal apply status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal apply status=done")
	for _, action := range actions {
		fmt.Printf("- [%t] %s %s\n  command: %s\n  result: %s\n", action.Success, action.Node, action.Type, action.Command, action.Result)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func diskInvestigate(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw disk-investigate <host> [path]")
	}
	host := args[0]
	path := "/"
	if len(args) == 2 {
		path = args[1]
	}
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if !strings.HasPrefix(path, "/") {
		return fmt.Errorf("path must be absolute: %s", path)
	}
	quoted := shellQuote(path)
	command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", quoted, quoted)
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("disk-investigate", host, path, result)
	fmt.Printf("disk-investigate host=%s path=%s success=%t transport=%s\n", host, path, result.Success, result.Transport)
	if result.Stdout != "" {
		fmt.Print(result.Stdout)
	}
	if result.Stderr != "" {
		fmt.Fprint(os.Stderr, result.Stderr)
	}
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("disk investigation failed on %s", host)
	}
	return nil
}

func dataCleanPlan(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-plan <host> <path>")
	}
	report := workflow.DataCleanPlan(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-plan", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func dataCleanApply(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-apply <host> <manifest>")
	}
	report := workflow.DataCleanApply(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-apply", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func evidenceList(args []string) error {
	limit := 20
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw evidence-list [limit]")
	}
	if len(args) == 1 {
		if _, err := fmt.Sscanf(args[0], "%d", &limit); err != nil {
			return fmt.Errorf("invalid limit: %s", args[0])
		}
	}
	records, err := evidence.List(limit)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(records)
	}
	if len(records) == 0 {
		fmt.Println("evidence records=0")
		return nil
	}
	fmt.Printf("%-20s %-18s %-10s %-22s %s\n", "TIME", "KIND", "HOST", "SUMMARY", "PATH")
	for _, record := range records {
		fmt.Printf("%-20s %-18s %-10s %-22s %s\n",
			record.Time.Local().Format("2006-01-02 15:04:05"),
			record.Kind,
			record.Host,
			truncate(record.Summary, 22),
			record.StoredAt,
		)
	}
	return nil
}

func truncate(value string, max int) string {
	if len(value) <= max {
		return value
	}
	if max <= 3 {
		return value[:max]
	}
	return value[:max-3] + "..."
}

func policyCheck(args []string) error {
	if len(args) < 3 {
		return fmt.Errorf("usage: meshclaw policy-check <subject> <action> <resource> [context]")
	}
	request := policy.Request{
		Subject:  args[0],
		Action:   args[1],
		Resource: args[2],
	}
	if len(args) > 3 {
		request.Context = strings.Join(args[3:], " ")
	}
	result := policy.Evaluate(request)
	return printJSON(result)
}

func wantsJSON(args []string) bool {
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			return true
		}
	}
	return false
}

func withoutJSONFlag(args []string) []string {
	filtered := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			continue
		}
		filtered = append(filtered, arg)
	}
	return filtered
}

func printJSON(value interface{}) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	return nil
}

func printEvidenceStoreStatus(record evidence.Record, err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", err)
		return
	}
	fmt.Printf("evidence=%s\n", record.StoredAt)
}

func provisionPlan(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw provision-plan <purpose> [budget-usd]")
	}
	req := provision.Request{Purpose: args[0], TTLHours: 6, RequiredClass: "small-vps"}
	if len(args) == 2 {
		if _, err := fmt.Sscanf(args[1], "%f", &req.BudgetUSD); err != nil {
			return fmt.Errorf("invalid budget-usd: %s", args[1])
		}
	}
	plan := provision.NewPlan(req)
	record, storeErr := evidence.Store("provision-plan", "provider", req.Purpose, plan)
	if err := printJSON(map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(storeErr)}); err != nil {
		return err
	}
	return nil
}

func run(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	out, err := runtime.NewRunner().Run(host, command)
	fmt.Print(out)
	return err
}

func runEvidence(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run-evidence <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("run-evidence", host, command, result)
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("execution failed on %s", host)
	}
	return nil
}

func runDoctor(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw doctor <host>")
	}
	fmt.Print(doctor.Check(args[0]))
	return nil
}

func analyzeLogs(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw analyze-logs <host> <source>")
	}
	report := workflow.AnalyzeLogs(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("analyze-logs", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceCheck(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-check <host> <service>")
	}
	report := workflow.ServiceCheck(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-check", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceQuarantine(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-quarantine <host> <service>")
	}
	report := workflow.ServiceQuarantine(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-quarantine", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceRemove(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw service-remove <host> <service> [working-directory]")
	}
	path := ""
	if len(args) == 3 {
		path = args[2]
	}
	report := workflow.ServiceRemove(args[0], args[1], path)
	printReport(report)
	record, storeErr := evidence.Store("service-remove", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func securityCheck(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw security-check <host>")
	}
	report := workflow.SecurityCheck(args[0])
	printReport(report)
	record, storeErr := evidence.Store("security-check", args[0], "read-only snapshot", report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygienePlan(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-plan <host>")
	}
	printHygieneReport(hygiene.Plan(args[0]))
	return nil
}

func hygieneScanText(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-text <target> <text>")
	}
	printHygieneReport(hygiene.ScanText(args[0], strings.Join(args[1:], " ")))
	return nil
}

func printReport(report workflow.Report) {
	fmt.Printf("%s host=%s status=%s\n", report.Name, report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- [%s] %s\n  evidence: %s\n  next: %s\n", finding.Severity, finding.Title, finding.Evidence, finding.Next)
	}
}

func printHygieneReport(report hygiene.Report) {
	fmt.Printf("hygiene host=%s status=%s\n", report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- finding [%s] %s target=%s evidence=%s\n", finding.Severity, finding.Type, finding.Target, finding.Evidence)
	}
	for _, action := range report.Actions {
		fmt.Printf("- action [%s] %s target=%s\n  command: %s\n  reason: %s\n  verify: %s\n", action.Mode, action.ID, action.Target, action.Command, action.Reason, action.Verify)
	}
}

func mcp() error {
	return cmdMCP()
}
