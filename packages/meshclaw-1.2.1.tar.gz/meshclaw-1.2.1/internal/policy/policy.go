package policy

import "strings"

type Decision string

const (
	Allow           Decision = "allow"
	Deny            Decision = "deny"
	RequireApproval Decision = "require_approval"
)

type Request struct {
	Subject  string `json:"subject"`
	Action   string `json:"action"`
	Resource string `json:"resource"`
	Context  string `json:"context,omitempty"`
}

type Result struct {
	Decision Decision `json:"decision"`
	Reason   string   `json:"reason"`
	Mask     bool     `json:"mask"`
}

var denied = []string{
	"rm -rf /",
	"mkfs",
	"dd if=",
	":(){",
	"shutdown",
	"poweroff",
	"reboot",
}

func CheckCommand(command string) error {
	result := Evaluate(Request{
		Subject:  "operator",
		Action:   "run_command",
		Resource: "server",
		Context:  command,
	})
	if result.Decision == Deny {
		return ErrDenied{Reason: result.Reason}
	}
	return nil
}

func Evaluate(request Request) Result {
	subject := normalize(request.Subject)
	action := normalize(request.Action)
	resource := normalize(request.Resource)
	context := strings.ToLower(request.Context)

	if subject == "" || action == "" || resource == "" {
		return Result{Decision: Deny, Reason: "subject, action, and resource are required"}
	}

	if resource == "secret" || resource == "secrets" || action == "reveal_secret" {
		return Result{Decision: Deny, Reason: "secrets are use-only capabilities and cannot be revealed", Mask: true}
	}

	if strings.Contains(resource, "secret") || strings.Contains(resource, "credential") {
		return Result{Decision: RequireApproval, Reason: "secret-adjacent resources require explicit policy approval", Mask: true}
	}

	if action == "read_state" || action == "server_list" || action == "fleet_status" || action == "capability_list" || action == "evidence_list" {
		return Result{Decision: Allow, Reason: "read-only operational facts are allowed"}
	}

	if action == "read_logs" || action == "disk_investigate" || action == "doctor" || action == "security_check" || action == "hygiene_plan" || action == "autoheal_plan" {
		return Result{Decision: Allow, Reason: "read-only diagnostic action is allowed"}
	}

	if action == "autoheal_apply_safe" {
		return Result{Decision: Allow, Reason: "bounded non-destructive remediation is allowed"}
	}

	if action == "provision_plan" || action == "capacity_plan" {
		return Result{Decision: Allow, Reason: "planning does not incur cost"}
	}

	if action == "provision_server" || action == "deprovision_server" || action == "provider_revoke" {
		return Result{Decision: RequireApproval, Reason: "provider and cost-changing actions require approval"}
	}

	if action == "restart_service" || action == "delete_data" || action == "rotate_secret" || action == "edit_database" {
		return Result{Decision: RequireApproval, Reason: "mutating infrastructure action requires approval"}
	}

	if action == "run_command" || action == "fleet_exec" {
		if containsDeniedCommand(context) {
			return Result{Decision: Deny, Reason: "blocked risky command pattern"}
		}
		if looksMutating(context) {
			return Result{Decision: RequireApproval, Reason: "raw mutating command requires approval"}
		}
		return Result{Decision: Allow, Reason: "read-only or low-risk command is allowed"}
	}

	if subject == "local-llm" || subject == "openwebui" {
		return Result{Decision: RequireApproval, Reason: "unknown local-model action requires policy approval"}
	}

	return Result{Decision: RequireApproval, Reason: "unknown action requires policy approval"}
}

func normalize(value string) string {
	return strings.ReplaceAll(strings.ToLower(strings.TrimSpace(value)), "-", "_")
}

func containsDeniedCommand(command string) bool {
	lower := strings.ToLower(command)
	for _, token := range denied {
		if strings.Contains(lower, token) {
			return true
		}
	}
	return false
}

func looksMutating(command string) bool {
	mutating := []string{
		" rm ",
		"rm -",
		"sudo rm",
		"mv ",
		"cp ",
		"chmod ",
		"chown ",
		"systemctl restart",
		"systemctl stop",
		"docker system prune",
		"apt-get install",
		"apt install",
		"pip install",
		"npm install",
		"tee ",
		">",
	}
	padded := " " + strings.ToLower(command) + " "
	for _, token := range mutating {
		if strings.Contains(padded, token) {
			return true
		}
	}
	return false
}

type ErrDenied struct {
	Reason string
}

func (e ErrDenied) Error() string {
	return e.Reason
}
