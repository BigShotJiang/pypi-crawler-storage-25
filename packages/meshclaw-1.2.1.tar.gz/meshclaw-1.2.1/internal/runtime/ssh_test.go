package runtime

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestRunEvidenceUsesVSSHRunManyJSON(t *testing.T) {
	binary := fakeVSSH(t, `#!/bin/sh
cat <<'JSON'
[{"target":"d1","result":{"success":true,"command":"printf ok","stdout":"ok\n","stderr":"","exit_code":0,"duration_ms":7}}]
JSON
`)

	result := Runner{Timeout: 2 * time.Second, VSSHBinary: binary, PreferVSSH: true}.RunEvidence("d1", "printf ok")

	if !result.Success {
		t.Fatalf("expected success: %+v", result)
	}
	if result.Transport != "vssh-native" {
		t.Fatalf("transport=%q", result.Transport)
	}
	if result.Stdout != "ok\n" {
		t.Fatalf("stdout=%q", result.Stdout)
	}
	if result.FallbackUsed {
		t.Fatal("did not expect SSH fallback")
	}
}

func TestRunEvidenceDoesNotFallbackOnRemoteCommandFailure(t *testing.T) {
	binary := fakeVSSH(t, `#!/bin/sh
cat <<'JSON'
[{"target":"d1","result":{"success":false,"command":"exit 42","stdout":"","stderr":"bad\n","exit_code":42,"duration_ms":7,"error":"remote failed"}}]
JSON
`)

	result := Runner{Timeout: 2 * time.Second, VSSHBinary: binary, PreferVSSH: true}.RunEvidence("d1", "exit 42")

	if result.Success {
		t.Fatalf("expected failure: %+v", result)
	}
	if result.Transport != "vssh-native" {
		t.Fatalf("transport=%q", result.Transport)
	}
	if result.ExitCode != 42 {
		t.Fatalf("exit_code=%d", result.ExitCode)
	}
	if result.FallbackUsed {
		t.Fatal("remote command failure must not fall back to SSH")
	}
	if len(result.Attempts) != 1 {
		t.Fatalf("attempts=%d", len(result.Attempts))
	}
}

func fakeVSSH(t *testing.T, script string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "vssh")
	if err := os.WriteFile(path, []byte(script), 0755); err != nil {
		t.Fatal(err)
	}
	return path
}
