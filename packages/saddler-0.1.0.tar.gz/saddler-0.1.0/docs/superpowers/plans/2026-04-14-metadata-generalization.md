# Metadata Generalization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace `hitch` triple fields on `AgentRecord` / `RuntimeRecord` with generic `dict[str, str]` metadata, wire CLI `--meta`, extend hitch YAML with optional metadata, and migrate `HitchExecutor` to reserved keys `saddler.hitch.*` per the design spec.

**Architecture:** Centralize key names and validation in a small `saddler/metadata` module. Records and `AgentCreateConfig` hold optional `metadata` only; hitch orchestration injects three reserved keys at create time. Pydantic validates hitch YAML `metadata` maps; CLI parses repeatable `--meta KEY=VALUE` the same way as `--env`.

**Tech Stack:** Python 3.12+, Typer, Pydantic v2, pytest.

---

## File structure (create / modify)

| File | Responsibility |
|------|----------------|
| `saddler/metadata.py` (new) | Reserved key constants, CLI `--meta` parsing, normalization/validation of metadata dicts, hitch reserved-key conflict check |
| `saddler/models.py` | `hitch` → `metadata` on `AgentCreateConfig`, `AgentRecord`, `RuntimeRecord`; validate `metadata` in `from_dict` |
| `saddler/manager.py` | `RuntimeManager.create(..., metadata=...)`, `AgentManager.create` reads `config.metadata` |
| `saddler/hitch/schema.py` | Optional `metadata` on `RuntimeServiceSpec` / `AgentServiceSpec` with str-only validation |
| `saddler/hitch/executor.py` | Match/filter via `saddler.hitch.*`; merge user YAML metadata with injected keys; exclude `metadata` from runtime cfg dump |
| `saddler/cli.py` | `--meta` on `create`, `run`, `runtime create` |
| `tests/test_metadata_unit.py` (new) | Unit tests for parsing/validation helpers |
| `tests/test_models_hitch_roundtrip.py` | Rename/repurpose to metadata JSON roundtrip (no `hitch` in JSON) |
| `tests/test_manager_hitch_create.py` | Assert persisted `metadata` uses new keys |
| `tests/hitch/test_executor.py` | Mock expectations + namespace objects use `metadata` |
| `tests/hitch/test_schema.py` | YAML metadata typing / bad types |
| `tests/cli/test_agent_commands.py` / `tests/cli/test_runtime_commands.py` | `--meta` passthrough and errors |
| `docs/spec.md` | Align §8 persistence + hitch sections with metadata (per design §8) |

---

### Task 1: `saddler/metadata.py` + unit tests

**Files:**
- Create: `saddler/metadata.py`
- Create: `tests/test_metadata_unit.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_metadata_unit.py`:

```python
import pytest

from saddler.exceptions import SaddlerError
from saddler.metadata import (
    SADDLER_HITCH_COMPOSE_FILE_KEY,
    SADDLER_HITCH_PROJECT_KEY,
    SADDLER_HITCH_RESERVED_KEYS,
    SADDLER_HITCH_SERVICE_KEY,
    ensure_no_hitch_reserved_overlap,
    hitch_orchestration_metadata,
    normalize_metadata_dict,
    parse_metadata_cli_entries,
)


def test_hitch_orchestration_metadata_keys() -> None:
    d = hitch_orchestration_metadata("proj", "/a/hitch.yaml", "svc")
    assert d == {
        SADDLER_HITCH_PROJECT_KEY: "proj",
        SADDLER_HITCH_COMPOSE_FILE_KEY: "/a/hitch.yaml",
        SADDLER_HITCH_SERVICE_KEY: "svc",
    }
    assert set(d) == SADDLER_HITCH_RESERVED_KEYS


def test_parse_metadata_cli_entries_empty() -> None:
    assert parse_metadata_cli_entries(None) == {}
    assert parse_metadata_cli_entries([]) == {}


def test_parse_metadata_cli_entries_parses_and_last_wins() -> None:
    assert parse_metadata_cli_entries(["a=1", "b=two", "a=3"]) == {"a": "3", "b": "two"}


def test_parse_metadata_cli_entries_requires_equals() -> None:
    with pytest.raises(SaddlerError, match="KEY=VALUE"):
        parse_metadata_cli_entries(["noequals"])


def test_parse_metadata_cli_entries_rejects_empty_key() -> None:
    with pytest.raises(SaddlerError, match="empty KEY"):
        parse_metadata_cli_entries(["=v"])


def test_normalize_metadata_dict_none() -> None:
    assert normalize_metadata_dict(None) is None


def test_normalize_metadata_dict_valid() -> None:
    assert normalize_metadata_dict({"k": "", "x": "y"}) == {"k": "", "x": "y"}


def test_normalize_metadata_dict_rejects_non_string_key() -> None:
    with pytest.raises(SaddlerError, match="keys must be strings"):
        normalize_metadata_dict({1: "a"})  # type: ignore[arg-type]


def test_normalize_metadata_dict_rejects_empty_key() -> None:
    with pytest.raises(SaddlerError, match="non-empty"):
        normalize_metadata_dict({"": "x"})


def test_normalize_metadata_dict_rejects_non_string_value() -> None:
    with pytest.raises(SaddlerError, match="values must be strings"):
        normalize_metadata_dict({"k": 1})  # type: ignore[dict-item]


def test_ensure_no_hitch_reserved_overlap_ok() -> None:
    ensure_no_hitch_reserved_overlap({"user.key": "v"})


def test_ensure_no_hitch_reserved_overlap_errors() -> None:
    with pytest.raises(SaddlerError, match="reserved"):
        ensure_no_hitch_reserved_overlap({SADDLER_HITCH_PROJECT_KEY: "x"})
```

- [ ] **Step 2: Run tests — expect failures**

Run: `cd /workspace && uv run pytest tests/test_metadata_unit.py -v`

Expected: `ModuleNotFoundError` or import errors until Step 3.

- [ ] **Step 3: Implement `saddler/metadata.py`**

Create `saddler/metadata.py`:

```python
from __future__ import annotations

from saddler.exceptions import SaddlerError

SADDLER_RESERVED_PREFIX = "saddler."

SADDLER_HITCH_PROJECT_KEY = "saddler.hitch.project"
SADDLER_HITCH_COMPOSE_FILE_KEY = "saddler.hitch.compose_file"
SADDLER_HITCH_SERVICE_KEY = "saddler.hitch.service"

SADDLER_HITCH_RESERVED_KEYS = frozenset(
    {
        SADDLER_HITCH_PROJECT_KEY,
        SADDLER_HITCH_COMPOSE_FILE_KEY,
        SADDLER_HITCH_SERVICE_KEY,
    }
)


def hitch_orchestration_metadata(project: str, compose_file: str, service: str) -> dict[str, str]:
    return {
        SADDLER_HITCH_PROJECT_KEY: project,
        SADDLER_HITCH_COMPOSE_FILE_KEY: compose_file,
        SADDLER_HITCH_SERVICE_KEY: service,
    }


def parse_metadata_cli_entries(entries: list[str] | None) -> dict[str, str]:
    if not entries:
        return {}
    out: dict[str, str] = {}
    for raw in entries:
        if "=" not in raw:
            raise SaddlerError(
                f"Invalid --meta format: {raw!r} (expected KEY=VALUE)"
            )
        key, value = raw.split("=", 1)
        key = key.strip()
        if not key:
            raise SaddlerError(f"Invalid --meta format: {raw!r} (empty KEY)")
        out[key] = value
    return out


def normalize_metadata_dict(data: dict | None) -> dict[str, str] | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise SaddlerError("metadata must be a string mapping")
    out: dict[str, str] = {}
    for k, v in data.items():
        if not isinstance(k, str):
            raise SaddlerError("metadata keys must be strings")
        if not k.strip():
            raise SaddlerError("metadata keys must be non-empty strings")
        if not isinstance(v, str):
            raise SaddlerError("metadata values must be strings")
        out[k] = v
    return out


def ensure_no_hitch_reserved_overlap(user_metadata: dict[str, str]) -> None:
    overlap = set(user_metadata) & SADDLER_HITCH_RESERVED_KEYS
    if overlap:
        keys = ", ".join(sorted(overlap))
        raise SaddlerError(
            f"metadata keys conflict with hitch reserved keys: {keys}"
        )
```

- [ ] **Step 4: Run tests — expect pass**

Run: `uv run pytest tests/test_metadata_unit.py -v`

Expected: all passed.

- [ ] **Step 5: Commit**

```bash
git add saddler/metadata.py tests/test_metadata_unit.py
git commit -m "feat(metadata): add validation helpers and hitch reserved keys"
```

---

### Task 2: Data models — `metadata` replaces `hitch`

**Files:**
- Modify: `saddler/models.py`
- Modify: `tests/test_models_hitch_roundtrip.py` → rename to `tests/test_models_metadata_roundtrip.py` (or replace file content in place)

- [ ] **Step 1: Write failing tests**

Replace `tests/test_models_hitch_roundtrip.py` with `tests/test_models_metadata_roundtrip.py` content:

```python
from saddler.models import AgentRecord, RuntimeRecord


def test_agent_record_metadata_json_roundtrip() -> None:
    md = {
        "saddler.hitch.project": "p",
        "saddler.hitch.compose_file": "/x/hitch.yaml",
        "saddler.hitch.service": "app",
        "user.tag": "x",
    }
    r = AgentRecord(
        agent_id="a1",
        harness="codex",
        runtime_type="local",
        runtime_state={},
        workdir="/w",
        status="created",
        runtime_id="rt1",
        metadata=md,
    )
    d = r.to_dict()
    assert "hitch" not in d
    assert d["metadata"]["user.tag"] == "x"
    r2 = AgentRecord.from_dict(d)
    assert r2.metadata == r.metadata


def test_runtime_record_metadata_json_roundtrip() -> None:
    md = {
        "saddler.hitch.project": "p",
        "saddler.hitch.compose_file": "/x/hitch.yaml",
        "saddler.hitch.service": "rt",
    }
    r = RuntimeRecord(
        runtime_id="rt1",
        runtime_type="local",
        runtime_spec={},
        runtime_state={},
        status="created",
        metadata=md,
    )
    d = r.to_dict()
    assert "hitch" not in d
    r2 = RuntimeRecord.from_dict(d)
    assert r2.metadata == r.metadata


def test_agent_record_from_dict_rejects_bad_metadata_value_type() -> None:
    from saddler.exceptions import SaddlerError

    raw = {
        "agent_id": "a1",
        "harness": "codex",
        "runtime_type": "local",
        "runtime_state": {},
        "workdir": "/w",
        "status": "created",
        "metadata": {"k": 1},
    }
    try:
        AgentRecord.from_dict(raw)
    except SaddlerError as e:
        assert "metadata" in str(e).lower() or "strings" in str(e).lower()
    else:
        raise AssertionError("expected SaddlerError")
```

Delete old file if you created new filename: `git rm tests/test_models_hitch_roundtrip.py` when adding the new file.

- [ ] **Step 2: Run tests — expect fail**

Run: `uv run pytest tests/test_models_metadata_roundtrip.py -v`

Expected: failures (no `metadata` field / validation missing).

- [ ] **Step 3: Implement models**

Edit `saddler/models.py`:

1. Add `from saddler.metadata import normalize_metadata_dict`
2. In `AgentCreateConfig`: replace `hitch: dict[str, str] | None = None` with `metadata: dict[str, str] | None = None`
3. In `AgentRecord` and `RuntimeRecord`: replace `hitch` with `metadata: dict[str, str] | None = None`
4. In `AgentRecord.from_dict`:

```python
    @classmethod
    def from_dict(cls, data: dict) -> "AgentRecord":
        raw = dict(data)
        raw.pop("config_path", None)  # legacy records
        if "foreground_sessions" not in raw:
            raw["foreground_sessions"] = 1 if raw.get("status") == "running" else 0
        if "metadata" in raw and raw["metadata"] is not None:
            raw["metadata"] = normalize_metadata_dict(raw["metadata"])
        allowed = {f.name for f in fields(cls)}
        kwargs = {k: v for k, v in raw.items() if k in allowed}
        return cls(**kwargs)
```

5. In `RuntimeRecord.from_dict`, add the same `metadata` normalization block before building `kwargs`.

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/test_models_metadata_roundtrip.py -v`

Expected: pass.

- [ ] **Step 5: Commit**

```bash
git add saddler/models.py tests/test_models_metadata_roundtrip.py
git rm tests/test_models_hitch_roundtrip.py 2>/dev/null || true
git commit -m "feat(models): replace hitch with metadata on agent and runtime records"
```

---

### Task 3: Manager create paths

**Files:**
- Modify: `saddler/manager.py`
- Modify: `tests/test_manager_hitch_create.py`

- [ ] **Step 1: Update manager tests first**

In `tests/test_manager_hitch_create.py`, replace `hitch` dicts with metadata using `hitch_orchestration_metadata` from `saddler.metadata`, and assert `loaded.metadata == expected_md`.

Example for runtime test:

```python
from saddler.metadata import hitch_orchestration_metadata

def test_runtime_manager_create_persists_metadata(isolated_store_dirs):
    ...
    expected_md = hitch_orchestration_metadata("p", "/c.yaml", "r1")
    rec = runtime_manager.create(
        {"type": "local"},
        name=None,
        metadata=expected_md,
    )
    ...
    assert loaded.metadata == expected_md
```

Rename test functions to `*_metadata` for clarity.

Agent test: pass `metadata=expected_md` in `AgentCreateConfig` instead of `hitch=`.

- [ ] **Step 2: Run tests — expect fail**

Run: `uv run pytest tests/test_manager_hitch_create.py -v`

- [ ] **Step 3: Edit `saddler/manager.py`**

1. `RuntimeManager.create`: parameter `hitch=` → `metadata=`; `normalize_metadata_dict(metadata)` before constructing `RuntimeRecord` (treat `None` as omit / field default).

```python
    def create(
        self,
        runtime_cfg: dict,
        *,
        runtime_id: str | None = None,
        name: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> RuntimeRecord:
        ...
        md = normalize_metadata_dict(metadata)
        rec = RuntimeRecord(
            ...
            metadata=md,
        )
```

Add import: `from saddler.metadata import normalize_metadata_dict`

2. `AgentManager.create` where `AgentRecord(...)` is built: use `metadata=normalize_metadata_dict(config.metadata)` instead of `hitch=config.hitch`.

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/test_manager_hitch_create.py tests/test_manager_unit.py -v`

Expected: pass.

- [ ] **Step 5: Commit**

```bash
git add saddler/manager.py tests/test_manager_hitch_create.py
git commit -m "feat(manager): inject normalized metadata on agent/runtime create"
```

---

### Task 4: Hitch schema — optional `metadata` on services

**Files:**
- Modify: `saddler/hitch/schema.py`
- Modify: `tests/hitch/test_schema.py`

- [ ] **Step 1: Add failing tests**

Append to `tests/hitch/test_schema.py`:

```python
def test_runtime_and_agent_metadata_optional() -> None:
    doc = parse_hitch_doc(
        {
            "version": 1,
            "runtimes": {
                "rt1": {"type": "local", "metadata": {"a": "1"}},
            },
            "agents": {
                "ag1": {
                    "harness": "codex",
                    "workdir": "/w",
                    "metadata": {"b": "2"},
                },
            },
        }
    )
    assert doc.runtimes["rt1"].metadata == {"a": "1"}
    assert doc.agents["ag1"].metadata == {"b": "2"}


def test_metadata_rejects_non_string_value() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        parse_hitch_doc(
            {
                "version": 1,
                "runtimes": {"rt1": {"type": "local", "metadata": {"a": 1}}},
                "agents": {},
            }
        )
```

- [ ] **Step 2: Run tests — expect fail**

Run: `uv run pytest tests/hitch/test_schema.py::test_runtime_and_agent_metadata_optional -v`

- [ ] **Step 3: Implement schema**

Add to both `RuntimeServiceSpec` and `AgentServiceSpec`:

```python
    metadata: dict[str, str] | None = None

    @field_validator("metadata", mode="before")
    @classmethod
    def metadata_string_map(cls, v: object) -> dict[str, str] | None:
        if v is None:
            return None
        if not isinstance(v, dict):
            raise ValueError("metadata must be a mapping")
        out: dict[str, str] = {}
        for key, val in v.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError("metadata keys must be non-empty strings")
            if not isinstance(val, str):
                raise ValueError("metadata values must be strings")
            out[key] = val
        return out
```

- [ ] **Step 4: Run full hitch schema tests**

Run: `uv run pytest tests/hitch/test_schema.py -v`

- [ ] **Step 5: Commit**

```bash
git add saddler/hitch/schema.py tests/hitch/test_schema.py
git commit -m "feat(hitch): allow optional string metadata in YAML service specs"
```

---

### Task 5: `HitchExecutor` migration

**Files:**
- Modify: `saddler/hitch/executor.py`
- Modify: `tests/hitch/test_executor.py`

- [ ] **Step 1: Rewrite executor tests for metadata**

Update `tests/hitch/test_executor.py`:

1. Replace `test_hitch_labels` with:

```python
from saddler.metadata import (
    SADDLER_HITCH_COMPOSE_FILE_KEY,
    SADDLER_HITCH_PROJECT_KEY,
    SADDLER_HITCH_SERVICE_KEY,
    hitch_orchestration_metadata,
)


def test_hitch_orchestration_metadata_shape() -> None:
    d = hitch_orchestration_metadata("p", "/c.yaml", "svc")
    assert d[SADDLER_HITCH_SERVICE_KEY] == "svc"
```

2. In `test_up_invokes_runtime_create_start_then_agent_create`, assert:

```python
    assert kwargs["metadata"][SADDLER_HITCH_SERVICE_KEY] == "rt"
    assert cfg.metadata[SADDLER_HITCH_SERVICE_KEY] == "app"
```

3. Replace `hitch={...}` in `SimpleNamespace` with `metadata={ SADDLER_HITCH_PROJECT_KEY: "proj", ... }` using the three keys.

4. Import `hitch_orchestration_metadata` instead of `hitch_labels` from executor (remove `hitch_labels` export or keep as deprecated alias — plan: remove `hitch_labels`, use `hitch_orchestration_metadata` only).

- [ ] **Step 2: Run tests — expect fail**

Run: `uv run pytest tests/hitch/test_executor.py -v`

- [ ] **Step 3: Implement executor**

Edit `saddler/hitch/executor.py`:

1. Remove `hitch_labels` and `_hitch_triple_matches` as currently written.

2. Add imports:

```python
from saddler.metadata import (
    SADDLER_HITCH_COMPOSE_FILE_KEY,
    SADDLER_HITCH_PROJECT_KEY,
    SADDLER_HITCH_SERVICE_KEY,
    ensure_no_hitch_reserved_overlap,
    hitch_orchestration_metadata,
    normalize_metadata_dict,
)
```

3. New helper:

```python
def _metadata_matches_hitch_scope(
    metadata: dict[str, str] | None,
    *,
    project: str,
    compose_file: str,
    service: str,
) -> bool:
    if not metadata:
        return False
    return (
        metadata.get(SADDLER_HITCH_PROJECT_KEY) == project
        and metadata.get(SADDLER_HITCH_COMPOSE_FILE_KEY) == compose_file
        and metadata.get(SADDLER_HITCH_SERVICE_KEY) == service
    )
```

4. Replace `_hitch_triple_matches(r.hitch, ...)` with `_metadata_matches_hitch_scope(r.metadata, ...)`.

5. In `_runtime_cfg_from_spec`, extend `exclude` to include `metadata`:

```python
        data = spec.model_dump(
            exclude={"name", "depends_on", "metadata"},
            exclude_none=True,
        )
```

6. In `up`, for `CreateRuntime`:

```python
                user_md = dict(step.spec.metadata or {})
                ensure_no_hitch_reserved_overlap(user_md)
                injected = hitch_orchestration_metadata(
                    self.project, self.compose_file, step.service_id
                )
                merged = {**user_md, **injected}
                rec = self.runtime_manager.create(
                    cfg, name=step.spec.name, metadata=merged
                )
```

7. For `CreateAgent`, build `user_md` from `step.spec.metadata`, call `ensure_no_hitch_reserved_overlap`, merge with `hitch_orchestration_metadata(...)`, pass `metadata=merged` in `AgentCreateConfig`.

8. `stop`: replace `r.hitch.get("project")` with `r.metadata.get(SADDLER_HITCH_PROJECT_KEY)` etc.; skip when `not r.metadata`.

9. `ps` list comprehensions: use `a.metadata` and `r.metadata` with the three keys.

- [ ] **Step 4: Run executor tests**

Run: `uv run pytest tests/hitch/test_executor.py -v`

- [ ] **Step 5: Run full hitch suite**

Run: `uv run pytest tests/hitch/ -v`

- [ ] **Step 6: Commit**

```bash
git add saddler/hitch/executor.py tests/hitch/test_executor.py
git commit -m "feat(hitch): use saddler.hitch.* metadata in executor"
```

---

### Task 6: CLI — `--meta` on create, run, runtime create

**Files:**
- Modify: `saddler/cli.py`
- Modify: `tests/cli/test_agent_commands.py`
- Modify: `tests/cli/test_runtime_commands.py` (add tests if file exists; else extend agent tests only and add runtime tests in `test_runtime_commands.py`)

- [ ] **Step 1: Add tests**

In `tests/cli/test_agent_commands.py`, add:

```python
def test_agent_create_passes_metadata(runner, mock_agent_manager, agent_record):
    mock_agent_manager.create.return_value = agent_record
    result = runner.invoke(
        app,
        [
            "agent",
            "create",
            "--harness",
            "codex",
            "--workdir",
            "/tmp/work",
            "--meta",
            "a=1",
            "--meta",
            "b=2",
        ],
    )
    assert result.exit_code == 0
    cfg = mock_agent_manager.create.call_args.args[0]
    assert cfg.metadata == {"a": "1", "b": "2"}


def test_agent_create_meta_last_wins(runner, mock_agent_manager, agent_record):
    mock_agent_manager.create.return_value = agent_record
    result = runner.invoke(
        app,
        [
            "agent",
            "create",
            "--harness",
            "codex",
            "--workdir",
            "/tmp/work",
            "--meta",
            "a=1",
            "--meta",
            "a=2",
        ],
    )
    assert result.exit_code == 0
    cfg = mock_agent_manager.create.call_args.args[0]
    assert cfg.metadata == {"a": "2"}


def test_agent_create_meta_invalid_exits_nonzero(runner, mock_agent_manager):
    result = runner.invoke(
        app,
        ["agent", "create", "--harness", "codex", "--workdir", "/tmp/work", "--meta", "bad"],
    )
    assert result.exit_code != 0
```

Mirror the same three tests for `run` subcommand (copy-paste with `"run"` and add minimal required flags consistent with existing `test_agent_run_*`).

In `tests/cli/test_runtime_commands.py` (create if needed following existing patterns from `test_runtime_commands.py`):

```python
def test_runtime_create_passes_metadata(runner, mock_runtime_manager):
    from types import SimpleNamespace
    mock_runtime_manager.create.return_value = SimpleNamespace(runtime_id="r1")
    result = runner.invoke(
        app,
        ["runtime", "create", "--meta", "env=prod"],
    )
    assert result.exit_code == 0
    args, kwargs = mock_runtime_manager.create.call_args
    assert kwargs.get("metadata") == {"env": "prod"}
```

Adjust to match how `mock_runtime_manager` is patched in that module (read `tests/cli/conftest.py`).

- [ ] **Step 2: Run new tests — fail**

Run: `uv run pytest tests/cli/test_agent_commands.py -k meta -v`

- [ ] **Step 3: Implement CLI**

In `saddler/cli.py`:

1. `from saddler.metadata import parse_metadata_cli_entries, normalize_metadata_dict`

2. Add helper used by all three commands:

```python
def _metadata_from_cli(meta: list[str] | None) -> dict[str, str] | None:
    parsed = parse_metadata_cli_entries(meta)
    if not parsed:
        return None
    return normalize_metadata_dict(parsed)
```

3. `_agent_config_from_cli`: add parameter `meta: list[str] | None = None`, and pass `metadata=_metadata_from_cli(meta)` into `AgentCreateConfig`.

4. `create` and `run` command signatures: add

```python
    meta: list[str] | None = typer.Option(
        None,
        "--meta",
        help='Metadata entry KEY=VALUE (repeatable; later wins on duplicate keys)',
    ),
```

Pass `meta` into `_agent_config_from_cli`.

5. `runtime_create`: add the same `--meta` option; after building `runtime_cfg`, compute `md = _metadata_from_cli(meta)` and call `_runtime_manager().create(runtime_cfg, name=name, metadata=md)`.

- [ ] **Step 4: Run CLI tests**

Run: `uv run pytest tests/cli/ -v`

- [ ] **Step 5: Commit**

```bash
git add saddler/cli.py tests/cli/test_agent_commands.py tests/cli/test_runtime_commands.py
git commit -m "feat(cli): add --meta to agent create/run and runtime create"
```

---

### Task 7: Integration sweep + docs

**Files:**
- Run: `uv run pytest` (whole suite)
- Modify: `docs/spec.md` (§8 JSON examples + hitch triple → metadata keys + CLI table)

- [ ] **Step 1: Repo-wide grep for stale `hitch`**

Run: `rg '\bhitch\b' saddler tests --glob '*.py'`

Fix any remaining references (there should be none on models after Task 2–5).

- [ ] **Step 2: Update `docs/spec.md`**

Replace persistence examples that show `"hitch": { "project", ... }` with `"metadata": { "saddler.hitch.project": ... }` and document open metadata + `--meta` per design §8.

Update the bullet that names triple keys `project` / `compose_file` / `service` to the three `saddler.hitch.*` strings.

- [ ] **Step 3: Full test run**

Run: `uv run pytest`

Expected: all green.

- [ ] **Step 4: Commit**

```bash
git add docs/spec.md
git commit -m "docs: align spec with metadata and saddler.hitch.* keys"
```

---

## Self-review (spec coverage)

| Spec section | Task |
|--------------|------|
| §3 Record `metadata`, remove `hitch` | Task 2 |
| §3 constraints + reserved keys | Task 1, 4, 5 |
| §4 CLI `--meta` | Task 6 |
| §4 hitch YAML metadata | Task 4, 5 |
| §5 HitchExecutor | Task 5 |
| §5 Manager create | Task 3 |
| §6 Errors | Tasks 1, 4–6 (CLI + overlap) |
| §7 Tests | Tasks 1–6 |
| §8 docs/spec.md | Task 7 |

**Placeholder scan:** No TBD/TODO/similar-to steps; each task includes concrete code or exact assertions.

**Type/name consistency:** Public hitch metadata uses `saddler.metadata.hitch_orchestration_metadata` and three `SADDLER_HITCH_*_KEY` constants everywhere; CLI uses `parse_metadata_cli_entries` + `normalize_metadata_dict`.

---

## Execution handoff

**Plan complete and saved to `docs/superpowers/plans/2026-04-14-metadata-generalization.md`. Two execution options:**

**1. Subagent-Driven (recommended)** — Dispatch a fresh subagent per task, review between tasks, fast iteration.

**2. Inline Execution** — Execute tasks in this session using executing-plans, batch execution with checkpoints.

**Which approach?**

**Note:** The writing-plans skill suggests running in a **dedicated git worktree** (from brainstorming). If you have not created one yet, create it before implementation so plan execution stays isolated from other local changes.
