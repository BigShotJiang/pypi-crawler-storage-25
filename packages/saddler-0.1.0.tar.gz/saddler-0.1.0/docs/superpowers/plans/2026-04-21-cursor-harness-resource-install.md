# Cursor Harness Resource Install Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 `CursorHarness` 的 rules/skills 安装流程统一为“从 saddler fetch 资源并安装到 runtime”，并在 rule 安装时补齐 Cursor frontmatter（默认 `alwaysApply: true`）。

**Architecture:** 资源获取保持在现有 fetcher 体系中（`parse_source` + `fetch_source` + `fetch_resource`），`CursorHarness` 只做平台特定安装编排。rule 在 harness 内完成 frontmatter 规范化后写入 runtime 的 `.cursor/rules`；skill 在 harness 内将完整目录拷贝到 `.cursor/skills/<name>`。测试通过 fake runtime 验证目标文件与目录结构。

**Tech Stack:** Python 3.12, Pydantic models, pytest, existing `RuntimeBackend` protocol, existing fetcher registry.

---

### Task 1: 为 CursorHarness 增加资源获取与 frontmatter 工具函数

**Files:**
- Modify: `saddler_v2/infra/harness/cursor.py`
- Test: `test_v2/infra/test_cursor_harness_install.py`

- [ ] **Step 1: 写失败测试（frontmatter 注入和补齐）**

```python
def test_rule_without_frontmatter_gets_default_frontmatter() -> None:
    content = "## Body\nrule content\n"
    normalized = _ensure_rule_frontmatter(content)
    assert normalized.startswith("---\n")
    assert "alwaysApply: true" in normalized
    assert "## Body" in normalized


def test_rule_frontmatter_missing_alwaysapply_gets_patched() -> None:
    content = "---\ndescription: demo\nglobs:\n---\nbody\n"
    normalized = _ensure_rule_frontmatter(content)
    assert "alwaysApply: true" in normalized
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_rule_without_frontmatter_gets_default_frontmatter -v`  
Expected: FAIL，提示 `_ensure_rule_frontmatter` 不存在或断言失败。

- [ ] **Step 3: 在 CursorHarness 中实现 frontmatter 辅助函数（最小实现）**

```python
def _inject_default_frontmatter(content: str) -> str:
    header = '---\ndescription: ""\nglobs:\nalwaysApply: true\n---\n'
    return f"{header}{content.lstrip()}"


def _ensure_rule_frontmatter(content: str) -> str:
    stripped = content.lstrip()
    if not stripped.startswith("---\n"):
        return _inject_default_frontmatter(content)
    end = stripped.find("\n---\n", 4)
    if end == -1:
        return _inject_default_frontmatter(content)
    frontmatter = stripped[: end + 5]
    body = stripped[end + 5 :]
    if "alwaysApply:" in frontmatter:
        return stripped
    patched_frontmatter = frontmatter[:-4] + "alwaysApply: true\n---\n"
    return f"{patched_frontmatter}{body}"
```

- [ ] **Step 4: 运行测试并确认通过**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_rule_without_frontmatter_gets_default_frontmatter -v`  
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add saddler_v2/infra/harness/cursor.py test_v2/infra/test_cursor_harness_install.py
git commit -m "feat(harness): add cursor rule frontmatter normalization helpers"
```

### Task 2: 改造 install_rules 为 fetch -> normalize -> copy

**Files:**
- Modify: `saddler_v2/infra/harness/cursor.py`
- Test: `test_v2/infra/test_cursor_harness_install.py`

- [ ] **Step 1: 写失败测试（install_rules 使用 fetched 资源，而非 rule.source 直写）**

```python
def test_install_rules_fetches_resource_and_writes_mdc(tmp_path: Path) -> None:
    source = tmp_path / "source"
    (source / "rules").mkdir(parents=True)
    (source / "rules" / "role.mdc").write_text("body\n", encoding="utf-8")
    spec = AgentSpec(
        harness="cursor",
        workdir="/workspace",
        role=None,
        skills=[],
        rules=[RuleSpec(name="role", source=str(source), path="rules/role.mdc")],
        harness_spec=None,
    )
    runtime = FakeRuntimeBackend(workdir_root=tmp_path / "runtime")
    harness = CursorHarness.from_spec(spec)
    harness.install_rules(runtime, spec.rules)
    written = runtime.read_runtime_text(".cursor/rules/role.mdc")
    assert "alwaysApply: true" in written
    assert "body" in written
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_install_rules_fetches_resource_and_writes_mdc -v`  
Expected: FAIL，现实现不会 fetch resource。

- [ ] **Step 3: 在 install_rules 实现 fetch-copy 流程**

```python
from ...resource import parse_source

def install_rules(self, runtime: RuntimeBackend, rules: list[RuleSpec]) -> None:
    cfg = _cursor_config_dir(self.spec.workdir)
    runtime.exec_fg(["sh", "-lc", f"mkdir -p {cfg}/rules"], cwd=self.spec.workdir)
    for rule in rules:
        fetcher_cls, source_spec = parse_source(rule.source)
        fetcher = fetcher_cls()
        with fetcher.fetch_source(source_spec) as source_root:
            with fetcher.fetch_resource(rule, source_root) as resource_path:
                content = resource_path.read_text(encoding="utf-8")
                normalized = _ensure_rule_frontmatter(content)
                tmp = resource_path.parent / f"{rule.name}.mdc"
                tmp.write_text(normalized, encoding="utf-8")
                runtime.copy_to(str(tmp), f"{cfg}/rules/{rule.name}.mdc")
```

- [ ] **Step 4: 运行测试并确认通过**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_install_rules_fetches_resource_and_writes_mdc -v`  
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add saddler_v2/infra/harness/cursor.py test_v2/infra/test_cursor_harness_install.py
git commit -m "feat(harness): install cursor rules via fetch then copy"
```

### Task 3: 改造 install_skills 为完整目录复制

**Files:**
- Modify: `saddler_v2/infra/harness/cursor.py`
- Test: `test_v2/infra/test_cursor_harness_install.py`

- [ ] **Step 1: 写失败测试（skill 目录完整拷贝）**

```python
def test_install_skills_copies_whole_skill_directory(tmp_path: Path) -> None:
    source = tmp_path / "source"
    skill_dir = source / "skills" / "demo"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("---\nname: demo\n---\n", encoding="utf-8")
    (skill_dir / "guide.md").write_text("guide", encoding="utf-8")
    spec = AgentSpec(
        harness="cursor",
        workdir="/workspace",
        role=None,
        skills=[SkillSpec(name="demo", source=str(source), path="skills/demo")],
        rules=[],
        harness_spec=None,
    )
    runtime = FakeRuntimeBackend(workdir_root=tmp_path / "runtime")
    harness = CursorHarness.from_spec(spec)
    harness.install_skills(runtime, spec.skills)
    assert runtime.runtime_path(".cursor/skills/demo/SKILL.md").exists()
    assert runtime.runtime_path(".cursor/skills/demo/guide.md").exists()
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_install_skills_copies_whole_skill_directory -v`  
Expected: FAIL，现实现只会 touch 单文件。

- [ ] **Step 3: 在 install_skills 中实现 fetch 后目录复制**

```python
def install_skills(self, runtime: RuntimeBackend, skills: list[SkillSpec]) -> None:
    cfg = _cursor_config_dir(self.spec.workdir)
    runtime.exec_fg(["sh", "-lc", f"mkdir -p {cfg}/skills"], cwd=self.spec.workdir)
    for skill in skills:
        fetcher_cls, source_spec = parse_source(skill.source)
        fetcher = fetcher_cls()
        with fetcher.fetch_source(source_spec) as source_root:
            with fetcher.fetch_resource(skill, source_root) as resource_path:
                runtime.exec_fg(
                    ["sh", "-lc", f"rm -rf {cfg}/skills/{skill.name}"],
                    cwd=self.spec.workdir,
                )
                runtime.copy_to(str(resource_path), f"{cfg}/skills/{skill.name}")
```

- [ ] **Step 4: 运行测试并确认通过**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_install_skills_copies_whole_skill_directory -v`  
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add saddler_v2/infra/harness/cursor.py test_v2/infra/test_cursor_harness_install.py
git commit -m "feat(harness): copy full skill resources into cursor runtime"
```

### Task 4: 回归测试与边界验证

**Files:**
- Modify: `test_v2/infra/test_cursor_harness_install.py`

- [ ] **Step 1: 增加边界测试（已有 frontmatter 且有 alwaysApply 时保持不变）**

```python
def test_rule_frontmatter_with_alwaysapply_is_preserved() -> None:
    content = "---\ndescription: x\nalwaysApply: false\n---\nbody\n"
    normalized = _ensure_rule_frontmatter(content)
    assert normalized == content
```

- [ ] **Step 2: 运行新增测试并确认通过**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py::test_rule_frontmatter_with_alwaysapply_is_preserved -v`  
Expected: PASS

- [ ] **Step 3: 运行完整相关测试集**

Run: `uv run pytest test_v2/infra/test_cursor_harness_install.py test_v2/infra/test_resource_fetchers.py -v`  
Expected: PASS（全部通过）。

- [ ] **Step 4: 提交**

```bash
git add test_v2/infra/test_cursor_harness_install.py
git commit -m "test(harness): cover cursor install frontmatter and directory copy cases"
```

### Task 5: 文档与验收清单收尾

**Files:**
- Modify: `docs/superpowers/specs/2026-04-21-cursor-harness-resource-install-design.md`（如需补充“已实现策略”备注）
- Modify: `docs/superpowers/plans/2026-04-21-cursor-harness-resource-install.md`

- [ ] **Step 1: 对照 spec 执行验收勾选**

```text
- [x] rules 使用 fetch->copy
- [x] skills 安装完整目录
- [x] rules frontmatter 默认 alwaysApply: true
- [x] 新增测试覆盖并通过
```

- [ ] **Step 2: 运行 git 状态确认仅包含预期文件**

Run: `git status --short`  
Expected: 仅出现 `cursor.py` 与新增测试/计划文档相关文件。

- [ ] **Step 3: 最终提交（如本仓库流程要求）**

```bash
git add saddler_v2/infra/harness/cursor.py test_v2/infra/test_cursor_harness_install.py docs/superpowers/plans/2026-04-21-cursor-harness-resource-install.md
git commit -m "feat(harness): install cursor resources by fetch then copy"
```
