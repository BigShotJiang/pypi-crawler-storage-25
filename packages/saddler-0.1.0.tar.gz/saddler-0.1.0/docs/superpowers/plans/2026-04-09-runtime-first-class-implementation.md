# Runtime First-Class Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Introduce first-class runtime resources that can be reused by multiple agents while keeping default agent commands backward-compatible.

**Architecture:** Add `RuntimeRecord` and `RuntimeStore`, then refactor manager logic so agents reference `runtime_id` instead of owning runtime state. Expose runtime lifecycle via `saddler runtime` subcommands while preserving `saddler create/start/stop/rm/ps` as aliases of `saddler agent ...`.

**Tech Stack:** Python 3.11+, Typer CLI, dataclasses, filelock, unittest.

---

### Task 1: Add runtime data model and store

**Files:**
- Modify: `saddler/models.py`
- Create: `saddler/runtime_store.py`
- Test: `tests/test_runtime_store.py`

- [ ] **Step 1: Write the failing tests**
- [ ] **Step 2: Run test to verify it fails**
- [ ] **Step 3: Implement `RuntimeRecord` and `RuntimeStore`**
- [ ] **Step 4: Run tests to verify pass**

### Task 2: Refactor manager for runtime-first lifecycle

**Files:**
- Modify: `saddler/manager.py`
- Modify: `saddler/models.py`
- Modify: `saddler/store.py`
- Test: `tests/test_manager_runtime_reuse.py`

- [ ] **Step 1: Write failing tests for runtime reuse + stop semantics**
- [ ] **Step 2: Run tests to verify fail**
- [ ] **Step 3: Implement runtime attach/reuse + runtime-level lifecycle**
- [ ] **Step 4: Run tests to verify pass**

### Task 3: Add runtime CLI and agent aliases

**Files:**
- Modify: `saddler/cli.py`
- Test: `tests/test_cli_runtime_commands.py`

- [ ] **Step 1: Write failing tests for CLI parsing/dispatch**
- [ ] **Step 2: Run tests to verify fail**
- [ ] **Step 3: Implement `saddler agent ...` / `saddler runtime ...` with top-level aliases**
- [ ] **Step 4: Run tests to verify pass**

### Task 4: Verify end-to-end and docs sync

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README command examples**
- [ ] **Step 2: Run full test suite**
- [ ] **Step 3: Manual smoke check `--help` output**

