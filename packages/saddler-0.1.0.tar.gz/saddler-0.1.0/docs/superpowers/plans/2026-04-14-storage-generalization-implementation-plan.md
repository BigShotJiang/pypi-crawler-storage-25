# Storage 一等资源化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 saddler 中引入可持久化、可引用的 `StorageRecord` 体系，移除匿名 storage 语法，并完成 CLI/hitch/runtime 生命周期联动。

**Architecture:** 新增 `StorageRecord` 与 `StorageStore/StorageManager` 作为独立资源层；`RuntimeRecord` 持久化 storage 绑定关系（`storage_id + mount`）并通过 `bound_runtime_ids` 维护事实引用。`hitch` 拓扑新增 storage 节点，`up/down` 执行顺序扩展为 storage -> runtime -> agent，并保持失败后的幂等清理能力。

**Tech Stack:** Python 3, dataclasses, pydantic, typer, filelock, pytest

---

**Ownership Constraint (must hold in implementation):** `local` storage create 仅做路径登记不创建目录，`local` storage rm 仅删除记录不删除目录内容；本地目录的创建与清理由用户负责。

---

## File Structure (planned changes)

- Create: `saddler/storage_manager.py`（storage 资源生命周期管理）
- Modify: `saddler/models.py`（新增 `StorageRecord` 与 runtime storage 绑定结构）
- Modify: `saddler/store.py`（新增 `StorageStore`）
- Modify: `saddler/manager.py`（runtime create/rm 绑定解绑逻辑）
- Modify: `saddler/storages.py`（从内联 KV 解析转向引用绑定数据模型）
- Modify: `saddler/cli.py`（新增 `saddler storage` 命令组；收敛 `runtime create --storage` 参数）
- Modify: `saddler/hitch/schema.py`（新增顶层 `storages` 与 runtime storage 引用结构）
- Modify: `saddler/hitch/plan.py`（storage 节点进入拓扑计划）
- Modify: `saddler/hitch/executor.py`（`up/down` 执行 storage 阶段、失败清单输出、down 幂等）
- Modify: `tests/cli/test_runtime_commands.py`（runtime storage 参数新语义）
- Create: `tests/cli/test_storage_commands.py`（新 storage CLI 命令）
- Modify: `tests/hitch/test_schema.py`（storages schema 校验）
- Modify: `tests/hitch/test_executor.py`（storage 执行顺序、失败清单、down 行为）
- Modify: `tests/test_store.py`（StorageStore 锁与序列化）
- Modify: `tests/test_manager_unit.py`（runtime/storage 绑定解绑行为）
- Modify: `docs/spec.md`（最终规范对齐）

---

### Task 1: 数据模型与存储层（StorageRecord + StorageStore）

**Files:**
- Modify: `saddler/models.py`
- Modify: `saddler/store.py`
- Test: `tests/test_store.py`

- [ ] **Step 1: 写失败测试（StorageRecord 序列化与 StorageStore 基本行为）**

```python
def test_storage_record_roundtrip():
    rec = StorageRecord(
        storage_id="st-1",
        kind="local",
        path="/abs/data",
        bound_runtime_ids=["rt-a"],
        metadata={"team": "ml"},
    )
    loaded = StorageRecord.from_dict(rec.to_dict())
    assert loaded.storage_id == "st-1"
    assert loaded.bound_runtime_ids == ["rt-a"]

def test_storage_store_insert_and_load(tmp_path, monkeypatch):
    monkeypatch.setattr("saddler.store.SADDLER_STORAGE_DIR", tmp_path / "storages")
    store = StorageStore()
    rec = StorageRecord(storage_id="st-1", kind="docker-volume", volume_name="v1")
    store.insert(rec)
    assert store.load("st-1").storage_id == "st-1"
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/test_store.py -k storage -v`  
Expected: FAIL（`StorageRecord`/`StorageStore` 尚未定义）

- [ ] **Step 3: 最小实现模型与 store**

```python
@dataclass
class StorageRecord:
    storage_id: str
    kind: Literal["local", "docker-volume"]
    name: str | None = None
    path: str | None = None
    volume_name: str | None = None
    bound_runtime_ids: list[str] = field(default_factory=list)
    metadata: dict[str, str] | None = None
```

```python
class StorageStore:
    def insert(self, record: StorageRecord) -> None: ...
    def load(self, storage_id: str) -> StorageRecord | None: ...
    def load_all(self) -> list[StorageRecord]: ...
    def locked_mutate(self, storage_id: str, fn) -> StorageRecord: ...
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/test_store.py -k storage -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/models.py saddler/store.py tests/test_store.py
git commit -m "feat(storage): add storage record and storage store"
```

### Task 2: StorageManager 与本地/volume 所有权边界

**Files:**
- Create: `saddler/storage_manager.py`
- Modify: `saddler/manager.py`
- Test: `tests/test_manager_unit.py`

- [ ] **Step 1: 写失败测试（create/rm 边界）**

```python
def test_storage_create_local_normalizes_abs_path(manager):
    rec = manager.create({"kind": "local", "path": "./data"}, name="d")
    assert rec.path.startswith("/")

def test_storage_rm_local_does_not_delete_directory(manager, tmp_path):
    d = tmp_path / "data"
    d.mkdir()
    rec = manager.create({"kind": "local", "path": str(d)}, name="d")
    manager.rm(rec.storage_id)
    assert d.exists()
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/test_manager_unit.py -k storage -v`  
Expected: FAIL（`StorageManager` 未实现）

- [ ] **Step 3: 最小实现 StorageManager**

```python
class StorageManager:
    def create(self, cfg: dict, *, name: str | None = None, metadata=None) -> StorageRecord:
        # local: path -> absolute, no mkdir
        # docker-volume: docker volume create
        ...

    def rm(self, storage_id_or_name: str, *, force: bool = False) -> StorageRecord:
        # local: delete record only
        # docker-volume: docker volume rm (not found => success)
        ...
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/test_manager_unit.py -k storage -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/storage_manager.py saddler/manager.py tests/test_manager_unit.py
git commit -m "feat(storage): add storage manager lifecycle and ownership rules"
```

### Task 3: Runtime 绑定模型切换（`bound_runtime_ids`）

**Files:**
- Modify: `saddler/manager.py`
- Modify: `saddler/models.py`
- Test: `tests/test_manager_unit.py`

- [ ] **Step 1: 写失败测试（create/rm 绑定解绑顺序与幂等）**

```python
def test_runtime_create_binds_storage_runtime_id(runtime_manager, storage_store):
    rec = runtime_manager.create({"type": "docker", "storages": [{"storage_id": "st-1", "mount": "/m"}]})
    assert "rt-" in rec.runtime_id
    assert rec.runtime_spec["storages"][0]["storage_id"] == "st-1"

def test_runtime_rm_unbinds_before_delete(runtime_manager, storage_store):
    runtime_manager.rm("rt-1")
    assert "rt-1" not in storage_store.load("st-1").bound_runtime_ids
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/test_manager_unit.py -k "runtime and storage" -v`  
Expected: FAIL（仍使用 `ref_count` 逻辑）

- [ ] **Step 3: 最小实现绑定/解绑逻辑**

```python
def _bind_runtime_to_storage(storage_id: str, runtime_id: str) -> None:
    def apply(s: StorageRecord) -> None:
        if runtime_id not in s.bound_runtime_ids:
            s.bound_runtime_ids.append(runtime_id)

def _unbind_runtime_from_storage(storage_id: str, runtime_id: str) -> None:
    def apply(s: StorageRecord) -> None:
        if runtime_id in s.bound_runtime_ids:
            s.bound_runtime_ids.remove(runtime_id)
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/test_manager_unit.py -k "runtime and storage" -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/manager.py saddler/models.py tests/test_manager_unit.py
git commit -m "refactor(runtime): switch storage binding source to bound runtime ids"
```

### Task 4: CLI 扩展（`saddler storage` + runtime 参数收敛）

**Files:**
- Modify: `saddler/cli.py`
- Modify: `tests/cli/test_runtime_commands.py`
- Create: `tests/cli/test_storage_commands.py`

- [ ] **Step 1: 写失败测试（新命令与参数规则）**

```python
def test_storage_create_local_passes_abs_path(runner, mock_storage_manager):
    result = runner.invoke(app, ["storage", "create", "--kind", "local", "--path", "./d", "--name", "d"])
    assert result.exit_code == 0

def test_runtime_create_storage_reference_format(runner):
    result = runner.invoke(app, ["runtime", "create", "--storage", "kind=local,mount=/m,path=/d"])
    assert result.exit_code != 0
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/cli/test_storage_commands.py tests/cli/test_runtime_commands.py -k storage -v`  
Expected: FAIL（命令不存在/旧语法仍接受）

- [ ] **Step 3: 最小实现 CLI**

```python
storage_app = typer.Typer(name="storage", help="Storage lifecycle commands")
app.add_typer(storage_app, name="storage")

@storage_app.command("create")
def storage_create(...): ...

@runtime_app.command("create")
def runtime_create(...):
    # --storage parse as "<id|name>:/mount"
    ...
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/cli/test_storage_commands.py tests/cli/test_runtime_commands.py -k storage -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/cli.py tests/cli/test_storage_commands.py tests/cli/test_runtime_commands.py
git commit -m "feat(cli): add storage commands and storage reference parsing"
```

### Task 5: hitch schema 与 plan 增加 storage 节点

**Files:**
- Modify: `saddler/hitch/schema.py`
- Modify: `saddler/hitch/plan.py`
- Modify: `tests/hitch/test_schema.py`
- Modify: `tests/hitch/test_plan.py`

- [ ] **Step 1: 写失败测试（storages 顶层与 runtime 引用）**

```python
def test_hitch_parse_storages_block():
    doc = parse_hitch_doc({
        "version": 1,
        "storages": {"cache": {"kind": "docker-volume"}},
        "runtimes": {"rt": {"type": "docker", "storages": [{"storage": "cache", "mount": "/m"}]}},
        "agents": {},
    })
    assert "cache" in doc.storages
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/hitch/test_schema.py tests/hitch/test_plan.py -k storage -v`  
Expected: FAIL（schema/plan 不识别 storage 节点）

- [ ] **Step 3: 最小实现 schema 与 plan**

```python
class StorageServiceSpec(BaseModel):
    kind: str
    name: str | None = None
    path: str | None = None
    volume_name: str | None = None
    metadata: dict[str, str] | None = None

class RuntimeStorageBinding(BaseModel):
    storage: str
    mount: str
```

```python
@dataclass(frozen=True)
class CreateStorage:
    service_id: str
    spec: StorageServiceSpec
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/hitch/test_schema.py tests/hitch/test_plan.py -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/hitch/schema.py saddler/hitch/plan.py tests/hitch/test_schema.py tests/hitch/test_plan.py
git commit -m "feat(hitch): add storage nodes to schema and plan"
```

### Task 6: hitch executor 执行顺序、失败清单、down 幂等

**Files:**
- Modify: `saddler/hitch/executor.py`
- Modify: `tests/hitch/test_executor.py`

- [ ] **Step 1: 写失败测试（up/down 语义）**

```python
def test_up_calls_storage_runtime_agent_in_order(...):
    ex.up(plan)
    assert call_order == ["storage.create", "runtime.create", "runtime.start", "agent.create"]

def test_down_skips_missing_resources(...):
    ex.down()
    assert result.exit_code == 0
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/hitch/test_executor.py -v`  
Expected: FAIL（当前 executor 未处理 storage 阶段）

- [ ] **Step 3: 最小实现 executor 逻辑**

```python
created = {"storages": [], "runtimes": [], "agents": []}
try:
    # create storages -> runtimes -> agents
except Exception as exc:
    raise SaddlerError(format_hitch_failure(exc, created))
```

```python
def down(self) -> None:
    # remove agents
    # stop+rm runtimes
    # rm storages (in-use -> warning only)
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/hitch/test_executor.py -v`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add saddler/hitch/executor.py tests/hitch/test_executor.py
git commit -m "feat(hitch): execute storage stage and add resilient down behavior"
```

### Task 7: 规范同步与全量验证

**Files:**
- Modify: `docs/spec.md`
- Modify: `tests/test_manager_hitch_create.py`（如需补充跨层回归）

- [ ] **Step 1: 写失败/回归测试（跨层）**

```python
def test_hitch_up_with_storage_reference_end_to_end(...):
    # storage declared in hitch top-level and referenced by runtime
    ...
```

- [ ] **Step 2: 运行目标测试确认当前失败或覆盖不足**

Run: `uv run pytest tests/test_manager_hitch_create.py -v`  
Expected: FAIL 或出现覆盖空洞（据实际补齐）

- [ ] **Step 3: 更新文档并补齐最小回归测试**

```markdown
- 新增 `saddler storage` 命令组
- `runtime create --storage` 改为 `<id|name>:<mount>`
- 明确 local storage 的 rm 不删除目录内容
```

- [ ] **Step 4: 全量验证**

Run: `uv run pytest -q`  
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add docs/spec.md tests/test_manager_hitch_create.py
git commit -m "docs: align spec with storage first-class lifecycle"
```

---

## Self-Review

- **Spec coverage:** 已覆盖 storage record/store、runtime 绑定解绑、CLI 命令收敛、hitch schema/plan/executor、失败清单、down 幂等与 local 内容所有权边界。
- **Placeholder scan:** 无 `TODO/TBD` 占位；每个任务包含文件、命令、预期结果与最小代码骨架。
- **Type consistency:** 统一使用 `StorageRecord.bound_runtime_ids` 作为绑定事实来源；runtime 绑定结构统一为 `storage_id + mount`。

