# Inspect Subcommands Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为 `storage/runtime/agent` 三类资源提供一致的 `inspect` 子命令体验，确保 `runtime inspect` 与 `agent inspect` 可用并输出与 `storage inspect` 一致的 YAML 详情。

**Architecture:** 在 manager 层补齐 `inspect()` 公共方法，CLI 层新增 `runtime inspect` 和 `agent inspect` 命令，并统一通过 `record.to_dict()` + `yaml.safe_dump(..., sort_keys=False, allow_unicode=True)` 输出。测试层在现有 CLI 单测文件中新增最小覆盖，验证 happy path 与错误透传语义。

**Tech Stack:** Python 3.13, Typer CLI, PyYAML, pytest, unittest.mock

---

## File Structure

- `saddler/manager.py`
  - 责任：资源解析与业务规则；新增 `RuntimeManager.inspect`、`AgentManager.inspect`，复用现有 `_load_or_raise`。
- `saddler/cli.py`
  - 责任：命令编排与输出渲染；新增 `runtime inspect`、`agent inspect` 子命令并统一 YAML 输出。
- `tests/cli/test_runtime_commands.py`
  - 责任：`runtime` CLI 行为验证；新增 `runtime inspect` 的输出与调用断言。
- `tests/cli/test_agent_commands.py`
  - 责任：`agent` CLI 行为验证；新增 `agent inspect` 的输出与调用断言。

### Task 1: 在 Manager 暴露 inspect 公共方法

**Files:**
- Modify: `saddler/manager.py`
- Test: `tests/cli/test_runtime_commands.py`
- Test: `tests/cli/test_agent_commands.py`

- [ ] **Step 1: 写失败测试（先断言 CLI 会调用 manager.inspect）**

```python
# tests/cli/test_runtime_commands.py
def test_runtime_inspect_outputs_yaml(runner, mock_runtime_manager):
    mock_runtime_manager.inspect.return_value = type(
        "RuntimeRec", (), {"to_dict": lambda self: {"runtime_id": "rt-1", "runtime_type": "local"}}
    )()
    result = runner.invoke(app, ["runtime", "inspect", "rt-1"])
    assert result.exit_code == 0
    assert "runtime_id: rt-1" in result.stdout
    assert "runtime_type: local" in result.stdout
    mock_runtime_manager.inspect.assert_called_once_with("rt-1")

# tests/cli/test_agent_commands.py
def test_agent_inspect_outputs_yaml(runner, mock_agent_manager):
    mock_agent_manager.inspect.return_value = type(
        "AgentRec", (), {"to_dict": lambda self: {"agent_id": "agent-1", "harness": "codex"}}
    )()
    result = runner.invoke(app, ["agent", "inspect", "agent-1"])
    assert result.exit_code == 0
    assert "agent_id: agent-1" in result.stdout
    assert "harness: codex" in result.stdout
    mock_agent_manager.inspect.assert_called_once_with("agent-1")
```

- [ ] **Step 2: 运行新增测试并确认失败（方法未实现）**

Run: `uv run pytest tests/cli/test_runtime_commands.py::test_runtime_inspect_outputs_yaml tests/cli/test_agent_commands.py::test_agent_inspect_outputs_yaml -v`  
Expected: FAIL，错误包含 `AttributeError` 或 mock 的 `inspect` 未被调用。

- [ ] **Step 3: 在 manager 增加最小实现**

```python
# saddler/manager.py
class RuntimeManager:
    # ... existing methods ...
    def inspect(self, runtime_id_or_name: str) -> RuntimeRecord:
        return self._load_or_raise(runtime_id_or_name)


class AgentManager:
    # ... existing methods ...
    def inspect(self, name_or_id: str) -> AgentRecord:
        return self._load_or_raise(name_or_id)
```

- [ ] **Step 4: 运行针对 manager 变更的相关测试**

Run: `uv run pytest tests/cli/test_runtime_commands.py::test_runtime_inspect_outputs_yaml tests/cli/test_agent_commands.py::test_agent_inspect_outputs_yaml -v`  
Expected: 仍可能 FAIL（CLI 命令尚未接线），但不应再因 manager 层缺少方法导致失败。

- [ ] **Step 5: 提交（manager 层）**

```bash
git add saddler/manager.py
git commit -m "feat(manager): expose inspect APIs for runtime and agent"
```

### Task 2: 新增 CLI 子命令并统一 inspect YAML 输出

**Files:**
- Modify: `saddler/cli.py`
- Test: `tests/cli/test_runtime_commands.py`
- Test: `tests/cli/test_agent_commands.py`

- [ ] **Step 1: 补充/调整失败测试（覆盖错误透传）**

```python
# tests/cli/test_runtime_commands.py
def test_runtime_inspect_propagates_error(runner, mock_runtime_manager):
    mock_runtime_manager.inspect.side_effect = SaddlerError("No runtime found: missing")
    result = runner.invoke(app, ["runtime", "inspect", "missing"])
    assert result.exit_code != 0
    assert isinstance(result.exception, SaddlerError)
    assert "No runtime found: missing" in str(result.exception)

# tests/cli/test_agent_commands.py
def test_agent_inspect_propagates_error(runner, mock_agent_manager):
    mock_agent_manager.inspect.side_effect = SaddlerError("No agent found: missing")
    result = runner.invoke(app, ["agent", "inspect", "missing"])
    assert result.exit_code != 0
    assert isinstance(result.exception, SaddlerError)
    assert "No agent found: missing" in str(result.exception)
```

- [ ] **Step 2: 运行 inspect 测试并确认当前失败**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k inspect -v && uv run pytest tests/cli/test_agent_commands.py -k inspect -v`  
Expected: FAIL（`No such command 'inspect'`）。

- [ ] **Step 3: 在 CLI 接入 `runtime inspect` / `agent inspect`**

```python
# saddler/cli.py
@runtime_app.command("inspect")
def runtime_inspect(
    name_or_id: str = typer.Argument(..., help="Runtime name or ID"),
) -> None:
    rec = _runtime_manager().inspect(name_or_id)
    typer.echo(
        yaml.safe_dump(rec.to_dict(), sort_keys=False, allow_unicode=True).strip()
    )


@agent_app.command("inspect")
def agent_inspect(
    name_or_id: str = typer.Argument(..., help="Agent name or ID"),
) -> None:
    rec = _manager().inspect(name_or_id)
    typer.echo(
        yaml.safe_dump(rec.to_dict(), sort_keys=False, allow_unicode=True).strip()
    )
```

- [ ] **Step 4: 运行 inspect 相关测试并确认通过**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k inspect -v && uv run pytest tests/cli/test_agent_commands.py -k inspect -v`  
Expected: PASS，输出显示新增的 inspect 用例通过。

- [ ] **Step 5: 提交（CLI + inspect 测试）**

```bash
git add saddler/cli.py tests/cli/test_runtime_commands.py tests/cli/test_agent_commands.py
git commit -m "feat(cli): add runtime and agent inspect commands"
```

### Task 3: 全量回归与文档对齐确认

**Files:**
- Modify: `docs/spec.md` (仅在需要时更新命令列表；若已有覆盖则不改)
- Test: `tests/cli/test_runtime_commands.py`
- Test: `tests/cli/test_agent_commands.py`
- Test: `tests/cli/test_storage_commands.py`

- [ ] **Step 1: 先写文档测试期望（若需补文档）**

```python
# 不新增自动化文档测试；本步为人工核对项：
# 确认 docs/spec.md 的命令矩阵中包含 runtime inspect 与 agent inspect。
# 若缺失，在文档中追加命令说明并保持 storage/runtime/agent 三者对称。
```

- [ ] **Step 2: 运行 CLI 回归测试**

Run: `uv run pytest tests/cli/test_storage_commands.py tests/cli/test_runtime_commands.py tests/cli/test_agent_commands.py -v`  
Expected: PASS，且 `storage inspect` 现有行为未回归。

- [ ] **Step 3: 运行更大范围验证（可选但建议）**

Run: `uv run pytest tests/cli -v`  
Expected: PASS 或仅存在与本改动无关的既有失败。

- [ ] **Step 4: 必要时更新文档**

```markdown
# docs/spec.md（示例补充）
- CLI：
  - storage create|ls|inspect|rm
  - runtime create|start|stop|inspect|rm|ps|install-harness
  - agent create|run|tui|acp|inspect|rm|ps
```

- [ ] **Step 5: 提交（回归与文档）**

```bash
git add docs/spec.md
git commit -m "docs(spec): align inspect command matrix across resources"
```

## Self-Review

- **Spec coverage:** 已覆盖 spec 中确认的核心需求：新增 `runtime inspect`、`agent inspect`，并与 `storage inspect` 输出格式对齐。
- **Placeholder scan:** 无 `TODO/TBD/implement later` 占位描述；每个代码步骤都给出具体片段与命令。
- **Type consistency:** 方法签名与现有命名一致：`RuntimeManager.inspect(runtime_id_or_name)`、`AgentManager.inspect(name_or_id)`；CLI 参数统一 `name_or_id`。

