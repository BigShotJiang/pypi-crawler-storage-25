# API-First Architecture Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在不引入 Hitch 服务化、且不将 `run/tui/acp` API 化的前提下，完成 `saddler` 第一阶段 API-first 重构：新增 `saddler.api` 资源服务层（Agent/Runtime/Storage），并将 in-scope CLI 命令迁移为通过 API facade 调用。

**Architecture:** 新增 `saddler/api` 作为进程内服务契约层，采用 dataclass DTO + 领域异常；Service 层负责用例语义和必要跨资源编排（主要是 `AgentService.create`），Manager 层保留为单资源状态与锁语义。CLI 变为薄适配层，负责参数解析、输出渲染、异常文案映射。

**Tech Stack:** Python 3.13, Typer CLI, dataclasses, pytest, unittest.mock

---

## File Structure

- `saddler/api/__init__.py`
  - 责任：导出 `AgentService`、`RuntimeService`、`StorageService`。
- `saddler/api/dto.py`
  - 责任：定义请求/响应 DTO（dataclass）。
- `saddler/api/errors.py`
  - 责任：定义 API 领域异常层级与（可选）从 `SaddlerError` 的映射工具。
- `saddler/api/wiring.py`
  - 责任：集中依赖装配（service 与 manager 的连接关系）。
- `saddler/api/agent_service.py`
  - 责任：实现 agent in-scope API，包含 create 跨资源编排。
- `saddler/api/runtime_service.py`
  - 责任：实现 runtime in-scope API 与 `install_harness` 语义。
- `saddler/api/storage_service.py`
  - 责任：实现 storage in-scope API。
- `saddler/cli.py`
  - 责任：in-scope 命令迁移为 service 调用；保留 run/tui/acp 前台会话路径。
- `tests/api/test_agent_service.py`
  - 责任：验证 `AgentService.create` 编排与异常语义。
- `tests/api/test_runtime_service.py`
  - 责任：验证 runtime 服务方法和 `install_harness` 行为。
- `tests/api/test_storage_service.py`
  - 责任：验证 storage 服务方法与错误行为。
- `tests/cli/test_agent_commands.py`
  - 责任：验证迁移后 agent CLI 行为保持稳定，`run` 走“API create + 前台启动”语义。
- `tests/cli/test_runtime_commands.py`
  - 责任：验证 runtime CLI 迁移后行为与输出兼容。
- `tests/cli/test_storage_commands.py`
  - 责任：验证 storage CLI 迁移后行为与输出兼容。

## Task 1: 建立 API 基础骨架（DTO / Errors / Wiring / Exports）

**Files:**
- Add: `saddler/api/__init__.py`
- Add: `saddler/api/dto.py`
- Add: `saddler/api/errors.py`
- Add: `saddler/api/wiring.py`

- [ ] **Step 1: 先写最小失败测试（导出与最小字段约束）**

```python
# tests/api/test_api_contract_basics.py
from saddler.api import AgentService, RuntimeService, StorageService
from saddler.api.dto import RuntimeInstallHarnessRequest

def test_api_exports_exist():
    assert AgentService is not None
    assert RuntimeService is not None
    assert StorageService is not None

def test_runtime_install_harness_request_min_fields():
    req = RuntimeInstallHarnessRequest(runtime_ref="rt-1", harness_name="codex")
    assert req.runtime_ref == "rt-1"
    assert req.harness_name == "codex"
    assert req.version is None
```

- [ ] **Step 2: 运行新增测试并确认失败（模块尚不存在）**

Run: `uv run pytest tests/api/test_api_contract_basics.py -v`  
Expected: FAIL，错误包含 import 或 attribute 缺失。

- [ ] **Step 3: 实现骨架与最小 DTO/异常定义**

实现要点：

- `dto.py` 定义 in-scope request/view dataclass（先最小可用，再渐进补字段）。
- 必须包含 `RuntimeInstallHarnessRequest(runtime_ref, harness_name, version=None)`。
- `errors.py` 定义 `ApiError` 基类及 spec 约定子类。
- `__init__.py` 公开服务类符号（可先占位）。

- [ ] **Step 4: 重新运行基础契约测试**

Run: `uv run pytest tests/api/test_api_contract_basics.py -v`  
Expected: PASS。

## Task 2: 实现 RuntimeService 与 StorageService（单资源路径）

**Files:**
- Add/Modify: `saddler/api/runtime_service.py`
- Add/Modify: `saddler/api/storage_service.py`
- Add/Modify: `saddler/api/wiring.py`
- Add: `tests/api/test_runtime_service.py`
- Add: `tests/api/test_storage_service.py`

- [ ] **Step 1: 先写失败测试（方法语义 + 错误映射）**

覆盖点：

- `create/start/stop/remove/list/inspect` 与 manager 一致性。
- `install_harness` 使用 `runtime_ref + harness_name + version` 入参语义。
- 空标识符/不存在标识符场景映射为 API 层异常。

- [ ] **Step 2: 运行测试并确认失败**

Run: `uv run pytest tests/api/test_runtime_service.py tests/api/test_storage_service.py -v`  
Expected: FAIL（service 未实现或行为不匹配）。

- [ ] **Step 3: 实现 RuntimeService / StorageService**

实现约束：

- 不引入跨服务依赖循环。
- 只做 API 语义封装，不改变现有 manager 业务规则。
- `install_harness` 文档语义必须落地为“runtime 环境工具安装”，不能混入 agent workdir 逻辑。

- [ ] **Step 4: 运行 API 单测**

Run: `uv run pytest tests/api/test_runtime_service.py tests/api/test_storage_service.py -v`  
Expected: PASS。

## Task 3: 实现 AgentService 与 create 跨资源编排

**Files:**
- Add/Modify: `saddler/api/agent_service.py`
- Add/Modify: `saddler/api/wiring.py`
- Add: `tests/api/test_agent_service.py`

- [ ] **Step 1: 先写失败测试（编排契约）**

最少覆盖以下序列语义：

1. DTO 校验与输入归一化  
2. runtime 解析/创建（`runtime` / `runtime_from_agent` / default）  
3. rigging 材料准备  
4. harness 安装前置保障  
5. 规则/技能物料安装  
6. agent 记录写入  
7. runtime `ref_count +1` 原子更新

并覆盖失败回滚关键点（例如中途失败不应产生脏绑定）。

- [ ] **Step 2: 运行测试并确认失败**

Run: `uv run pytest tests/api/test_agent_service.py -v`  
Expected: FAIL（编排逻辑未完成）。

- [ ] **Step 3: 实现 AgentService.create/list/inspect/remove**

约束：

- `AgentService -> RuntimeService` 允许，禁止反向依赖。
- 保持 manager 为底层状态实现，不在 manager 新增 service 编排语义。
- 产出 `AgentView` 为 record-faithful 视图，不为 CLI 裁剪字段。

- [ ] **Step 4: 运行 AgentService 单测**

Run: `uv run pytest tests/api/test_agent_service.py -v`  
Expected: PASS。

## Task 4: 迁移 CLI in-scope 命令到 API facade

**Files:**
- Modify: `saddler/cli.py`
- Modify: `tests/cli/test_agent_commands.py`
- Modify: `tests/cli/test_runtime_commands.py`
- Modify: `tests/cli/test_storage_commands.py`

- [ ] **Step 1: 先写/更新失败测试（命令调用 service）**

覆盖点：

- Agent 命令：`create/rm/ps/inspect` 走 `AgentService`。
- Runtime 命令：`create/start/stop/rm/ps/inspect/install-harness` 走 `RuntimeService`。
- Storage 命令：`create/ls/inspect/rm` 走 `StorageService`。
- `run/tui/acp` 仍保留前台语义；`run` 走“API create + CLI 前台启动”。

- [ ] **Step 2: 运行 CLI 相关测试并确认失败**

Run: `uv run pytest tests/cli/test_agent_commands.py tests/cli/test_runtime_commands.py tests/cli/test_storage_commands.py -v`  
Expected: FAIL（尚未接线）。

- [ ] **Step 3: 实现 CLI 接线与异常映射**

实现要点：

- 引入 wiring 统一获取 service 实例（避免到处手工 new）。
- 保持输出格式兼容（表格/YAML）。
- 保持 `Error: ...` 风格，允许小幅一致化。

- [ ] **Step 4: 运行 CLI 回归测试**

Run: `uv run pytest tests/cli/test_agent_commands.py tests/cli/test_runtime_commands.py tests/cli/test_storage_commands.py -v`  
Expected: PASS。

## Task 5: 端到端回归与边界确认

**Files:**
- Test only: `tests/api/*`
- Test only: `tests/cli/*`
- Optional doc touch: `docs/spec.md`（仅当命令行为说明需要同步）

- [ ] **Step 1: API + CLI 汇总回归**

Run: `uv run pytest tests/api tests/cli -v`  
Expected: PASS 或仅剩与本改动无关的既有失败。

- [ ] **Step 2: 边界核对（必须人工确认）**

核对清单：

- 未新增 `HitchService`。
- hitch 命令路径仍直接走 manager（Phase 1 不迁移）。
- 未新增 `AgentService.run/tui/acp`。
- `agent run` 为“API create + 前台启动”两段。

- [ ] **Step 3: 必要时同步文档说明**

若 `docs/spec.md` 需对“API-first Phase 1 边界”补充一句话说明，可最小更新；不新增大段设计重复文本。

## Suggested Commit Slices

1. `feat(api): scaffold api facade contracts and wiring`
2. `feat(api): implement runtime and storage services`
3. `feat(api): implement agent service orchestration`
4. `refactor(cli): route in-scope commands through api services`
5. `test(api,cli): add phase1 regression coverage`

## Self-Review Checklist

- [ ] DTO 与异常契约与 spec 一致（尤其 `RuntimeInstallHarnessRequest`）。
- [ ] `AgentView/RuntimeView/StorageView` 保持 record-faithful。
- [ ] 未越界引入 hitch 服务化。
- [ ] 未将前台会话 (`run/tui/acp`) API 化。
- [ ] CLI 对外行为基本兼容（输出/错误风格）。
