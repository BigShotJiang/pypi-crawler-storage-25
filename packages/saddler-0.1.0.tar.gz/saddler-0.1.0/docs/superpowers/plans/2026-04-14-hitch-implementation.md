# Hitch 编排 MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现 `saddler hitch` 子命令（config / up / stop / down / ps），用 YAML 声明 `runtimes` 与 `agents`，按 DAG 顺序调用现有 `RuntimeManager` / `AgentManager`，并在持久化记录中写入 hitch 元数据以支持安全 `down` 与过滤 `ps`。

**Architecture:** `saddler/hitch/` 负责：默认/`-f` 发现与多文件浅合并 → Pydantic 校验 → 依赖图与拓扑序 → 不可变 `HitchPlan`（步骤列表）→ `HitchExecutor` 进程内调用 manager；`saddler.models` 与 `RuntimeManager.create` / `AgentManager.create` 增加可选 `hitch` 字典字段，随 `agent.json` / `runtime.json` 持久化。

**Tech Stack:** Python 3.11+、Typer、Pydantic（已在 `pyproject.toml`）、**PyYAML**（新增）、现有 `AgentStore` / `RuntimeStore`、pytest。

---

## 文件结构（落地边界）

| 路径 | 职责 |
|------|------|
| `pyproject.toml` | 增加运行时依赖 `pyyaml`（用 `uv add pyyaml`） |
| `saddler/models.py` | `AgentRecord` / `RuntimeRecord` 增加可选 `hitch: dict[str, str] \| None`（键：`project`、`compose_file`、`service`） |
| `saddler/manager.py` | `RuntimeManager.create(..., hitch=...)`；`AgentCreateConfig` 增加 `hitch`；`AgentManager.create` 写入 `AgentRecord.hitch`；`RuntimeRecord` 创建处写入 `hitch` |
| `saddler/hitch/__init__.py` | 导出对外 API（可选，保持精简） |
| `saddler/hitch/files.py` | 默认文件名探测、`-f` 解析、`load_merged_compose(paths) -> dict` |
| `saddler/hitch/schema.py` | Pydantic 模型：`HitchFileV1`、`RuntimeServiceSpec`、`AgentServiceSpec` |
| `saddler/hitch/graph.py` | 校验 `depends_on` 指向同文件内 id、建图、环检测、`topological_sort` |
| `saddler/hitch/plan.py` | `HitchPlan`、`PlanStep` 枚举或 dataclass、`build_plan(doc, project, compose_file) -> HitchPlan` |
| `saddler/hitch/executor.py` | `HitchExecutor`：`up` / `stop` / `down` / `ps`；维护 logical runtime → `runtime_id` 映射 |
| `saddler/cli.py` | `hitch_app` Typer，`config` / `up` / `stop` / `down` / `ps`，`-f` / `--force-recreate` |
| `tests/hitch/test_files.py` | 合并与发现 |
| `tests/hitch/test_graph.py` | 环与排序 |
| `tests/hitch/test_plan.py` | plan 构建 |
| `tests/hitch/test_executor.py` | fake store 或 tmp HOME |
| `tests/cli/test_hitch_commands.py` | CliRunner + mock managers 或隔离 HOME |
| `docs/spec.md` | 新增 hitch 小节（命令表、默认文件名、与 saddler 无项目级配置的关系） |

**多文件合并规则（定死）：** 按 `-f` 顺序依次 **浅合并** 顶层：`name`、`version` 后者覆盖前者；`runtimes`、`agents` 两个字典 **按键合并**，同键以后者为准。**`compose_file` 元数据** 取 **第一个** `-f` 路径（或自动发现时命中的第一个存在文件）的 `Path.resolve()` 字符串，与 spec 中「主文件」一致，用于 `ps` / `down` 归属匹配。

**YAML 与内部 `runtime_cfg` 映射（与 `cli.runtime_create` 一致）：**

| YAML 键 | `runtime_cfg` 键 |
|---------|------------------|
| `type` | `type`（默认 `local`） |
| `name` | 传入 `RuntimeManager.create(..., name=)`，**不**写入 `runtime_cfg` |
| `image` | `image` |
| `env` | `env`（`dict[str, str]`） |
| `storages` | `storages`（`list[str]`，与 CLI `--storage` 字符串列表相同） |
| `run_as` | `run_as` |

**YAML agent 与 `AgentCreateConfig`：**

| YAML 键 | 目标 |
|---------|------|
| `harness` | 必填 |
| `role` | 可选路径字符串 |
| `workdir` | 必填 |
| `skills` | `list[str]`，默认 `[]` |
| `name` | 可选 |
| `runtime` | 若等于某 `runtimes` 的逻辑 id，则在 executor 中解析为创建后的 `runtime_id`；否则视为 **外部** id 或显示名，直接传给 `AgentCreateConfig.runtime` |
| `runtime_from_agent` | 若等于某 `agents` 的逻辑 id，在拓扑序保证该 agent 已创建后，将 **其 `agent_id`** 传入 `runtime_from_agent`；否则视为外部 agent id/名 |

---

### Task 1: 依赖与 hitch 字段模型

**Files:**

- Modify: `pyproject.toml`（dependencies）
- Modify: `saddler/models.py`
- Create: `tests/test_models_hitch_roundtrip.py`

- [ ] **Step 1: 添加 PyYAML 依赖**

Run:

```bash
cd /home/wangchen/Projects/ai-annovation/saddler && uv add pyyaml
```

Expected: `pyproject.toml` 的 `[project] dependencies` 中出现 `pyyaml`。

- [ ] **Step 2: 写失败测试（Record 序列化含 hitch）**

Create `tests/test_models_hitch_roundtrip.py`:

```python
from saddler.models import AgentRecord, RuntimeRecord


def test_agent_record_hitch_json_roundtrip() -> None:
    r = AgentRecord(
        agent_id="a1",
        harness="codex",
        runtime_type="local",
        runtime_state={},
        workdir="/w",
        status="created",
        runtime_id="rt1",
        hitch={"project": "p", "compose_file": "/x/hitch.yaml", "service": "app"},
    )
    d = r.to_dict()
    assert d["hitch"]["project"] == "p"
    r2 = AgentRecord.from_dict(d)
    assert r2.hitch == r.hitch


def test_runtime_record_hitch_json_roundtrip() -> None:
    r = RuntimeRecord(
        runtime_id="rt1",
        runtime_type="local",
        runtime_spec={},
        runtime_state={},
        status="created",
        hitch={"project": "p", "compose_file": "/x/hitch.yaml", "service": "rt"},
    )
    d = r.to_dict()
    r2 = RuntimeRecord.from_dict(d)
    assert r2.hitch == r.hitch
```

Run: `uv run pytest tests/test_models_hitch_roundtrip.py -v`

Expected: FAIL（`AgentRecord` / `RuntimeRecord` 无 `hitch` 或 `from_dict` 丢弃字段）。

- [ ] **Step 3: 实现模型字段**

在 `saddler/models.py` 的 `AgentRecord` 与 `RuntimeRecord` 上增加：

```python
hitch: dict[str, str] | None = None
```

- `to_dict()`：`asdict` 已包含；若 `None` 可考虑省略（与现有风格一致即可）。
- `from_dict()`：在 `allowed` 过滤前把 `hitch` 放进 `kwargs`（字段名加入 `fields(cls)` 集合）。

对 **旧 JSON**（无 `hitch` 键）：`from_dict` 后 `hitch` 为 `None`。

Run: `uv run pytest tests/test_models_hitch_roundtrip.py -v`

Expected: PASS。

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock saddler/models.py tests/test_models_hitch_roundtrip.py
git commit -m "feat(models): 为 Agent/Runtime 记录增加 hitch 元数据字段"
```

---

### Task 2: Manager 创建路径写入 hitch

**Files:**

- Modify: `saddler/models.py`（`AgentCreateConfig`）
- Modify: `saddler/manager.py`
- Create: `tests/test_manager_hitch_create.py`

- [ ] **Step 1: 写失败测试**

Create `tests/test_manager_hitch_create.py`：

使用 `tmp_path` + `monkeypatch.setattr(store_mod, "SADDLER_DIR", ...)` 与 `SADDLER_RUNTIME_DIR`（与 `tests/test_store.py` 中 `isolated_store_dirs` fixture 相同），因 `store` 在 import 时已绑定 `Path.home()`，不能仅靠改 `HOME`。

最小用例：

1. `RuntimeManager.create({"type": "local"}, name=None, hitch={"project":"p","compose_file":"/c.yaml","service":"r1"})`  
2. 从 store `load` 回来的 `RuntimeRecord.hitch` 等于传入字典。

3. `AgentManager.create(AgentCreateConfig(harness="codex", role=None, workdir=str(tmp_path/"w"), runtime_spec={"type":"local"}, skills=[], runtime=<刚创建的 runtime_id>, hitch={...}))`  
4. `AgentRecord.hitch` 非空。

若当前 `create` 无法接受 `hitch`，测试 FAIL。

Run: `uv run pytest tests/test_manager_hitch_create.py -v`

- [ ] **Step 2: 实现**

- `AgentCreateConfig` 增加 `hitch: dict[str, str] | None = None`。
- `RuntimeManager.create(..., hitch: dict[str, str] | None = None)`，构造 `RuntimeRecord(..., hitch=hitch)`。
- `AgentManager.create`：构造 `AgentRecord(..., hitch=config.hitch)`。

- [ ] **Step 3: 跑测试与全量回归**

Run: `uv run pytest tests/test_manager_hitch_create.py tests/test_manager_unit.py -v`

Expected: PASS。

- [ ] **Step 4: Commit**

```bash
git add saddler/models.py saddler/manager.py tests/test_manager_hitch_create.py
git commit -m "feat(manager): create 路径支持写入 hitch 元数据"
```

---

### Task 3: 文件发现与多文件合并

**Files:**

- Create: `saddler/hitch/files.py`
- Create: `tests/hitch/test_files.py`

- [ ] **Step 1: 写失败测试**

`tests/hitch/test_files.py`:

```python
from pathlib import Path

import pytest

from saddler.hitch.files import DEFAULT_FILENAMES, discover_compose_files, load_merged_compose


def test_discover_uses_first_existing_default(tmp_path: Path) -> None:
    (tmp_path / "hitch.yml").write_text("name: a\n", encoding="utf-8")
    paths = discover_compose_files(None, cwd=tmp_path)
    assert paths == [tmp_path / "hitch.yml"]


def test_discover_requires_file_when_none_exist(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        discover_compose_files(None, cwd=tmp_path)


def test_explicit_f_overrides_default(tmp_path: Path) -> None:
    (tmp_path / "hitch.yaml").write_text("name: wrong\n", encoding="utf-8")
    other = tmp_path / "b.yaml"
    other.write_text("name: right\n", encoding="utf-8")
    paths = discover_compose_files([other], cwd=tmp_path)
    assert paths == [other]


def test_load_merged_overrides_keys(tmp_path: Path) -> None:
    a = tmp_path / "a.yaml"
    b = tmp_path / "b.yaml"
    a.write_text(
        "name: one\nversion: 1\nruntimes:\n  x:\n    type: local\n",
        encoding="utf-8",
    )
    b.write_text(
        "name: two\nagents:\n  app:\n    harness: codex\n    workdir: /w\n",
        encoding="utf-8",
    )
    doc, primary = load_merged_compose([a, b])
    assert primary == a.resolve()
    assert doc["name"] == "two"
    assert doc["runtimes"]["x"]["type"] == "local"
    assert doc["agents"]["app"]["harness"] == "codex"
```

Run: `uv run pytest tests/hitch/test_files.py -v` → FAIL。

- [ ] **Step 2: 实现 `saddler/hitch/files.py`**

```python
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

DEFAULT_FILENAMES = ("hitch.yaml", "hitch.yml", "saddler.yaml")


def discover_compose_files(
    files: list[Path] | None,
    *,
    cwd: Path,
) -> list[Path]:
    if files:
        out: list[Path] = []
        for f in files:
            p = (cwd / f).resolve() if not f.is_absolute() else f.resolve()
            if not p.is_file():
                raise FileNotFoundError(f"Hitch file not found: {p}")
            out.append(p)
        return out
    for name in DEFAULT_FILENAMES:
        p = (cwd / name).resolve()
        if p.is_file():
            return [p]
    tried = ", ".join(DEFAULT_FILENAMES)
    raise FileNotFoundError(
        f"No hitch file in {cwd} (tried {tried}); use -f/--file"
    )


def load_merged_compose(paths: list[Path]) -> tuple[dict[str, Any], Path]:
    if not paths:
        raise ValueError("paths must not be empty")
    merged: dict[str, Any] = {}
    primary = paths[0].resolve()
    for path in paths:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        if raw is None:
            raw = {}
        if not isinstance(raw, dict):
            raise ValueError(f"YAML root must be a mapping: {path}")
        if "name" in raw:
            merged["name"] = raw["name"]
        if "version" in raw:
            merged["version"] = raw["version"]
        if "runtimes" in raw:
            m = merged.setdefault("runtimes", {})
            if not isinstance(raw["runtimes"], dict):
                raise ValueError(f"runtimes must be a mapping: {path}")
            m.update(raw["runtimes"])
        if "agents" in raw:
            m = merged.setdefault("agents", {})
            if not isinstance(raw["agents"], dict):
                raise ValueError(f"agents must be a mapping: {path}")
            m.update(raw["agents"])
    return merged, primary
```

- [ ] **Step 3: 跑测试**

Run: `uv run pytest tests/hitch/test_files.py -v`

- [ ] **Step 4: Commit**

```bash
git add saddler/hitch/files.py tests/hitch/test_files.py
git commit -m "feat(hitch): 默认发现与多文件 YAML 合并"
```

---

### Task 4: Pydantic schema 校验

**Files:**

- Create: `saddler/hitch/schema.py`
- Create: `tests/hitch/test_schema.py`

- [ ] **Step 1: 写失败测试**

```python
import pytest
from pydantic import ValidationError

from saddler.hitch.schema import parse_hitch_doc


def test_parse_minimal() -> None:
    doc = parse_hitch_doc(
        {
            "version": 1,
            "runtimes": {"rt": {"type": "local"}},
            "agents": {
                "a": {"harness": "codex", "workdir": "/w", "depends_on": ["rt"]}
            },
        }
    )
    assert doc.version == 1
    assert "rt" in doc.runtimes
    assert doc.agents["a"].harness == "codex"


def test_agent_requires_harness_and_workdir() -> None:
    with pytest.raises(ValidationError):
        parse_hitch_doc(
            {
                "version": 1,
                "runtimes": {},
                "agents": {"a": {"harness": "codex"}},
            }
        )
```

- [ ] **Step 2: 实现 `schema.py`**

使用 Pydantic v2 `BaseModel`：

- `RuntimeServiceSpec`：`type: str = "local"`，`name: str | None = None`，`image: str | None = None`，`env: dict[str, str] = {}`，`storages: list[str] = []`，`run_as: str | None = None`，`depends_on: list[str] = []`。
- `AgentServiceSpec`：`harness: str`，`role: str | None = None`，`workdir: str`，`skills: list[str] = []`，`name: str | None = None`，`runtime: str | None = None`，`runtime_from_agent: str | None = None`，`depends_on: list[str] = []`。
- 校验：`runtime` 与 `runtime_from_agent` **不能同时非空**（model_validator）。
- `HitchFileV1`：`version: int = 1`，`runtimes: dict[str, RuntimeServiceSpec]`，`agents: dict[str, AgentServiceSpec]`；若 `version != 1` 可抛 `ValueError` 或 ValidationError。

`parse_hitch_doc(data: dict) -> HitchFileV1`：调用 `HitchFileV1.model_validate`。

- [ ] **Step 3: pytest**

Run: `uv run pytest tests/hitch/test_schema.py -v`

- [ ] **Step 4: Commit**

```bash
git add saddler/hitch/schema.py tests/hitch/test_schema.py
git commit -m "feat(hitch): Pydantic 校验 hitch 文件 v1"
```

---

### Task 5: 依赖图与拓扑排序

**Files:**

- Create: `saddler/hitch/graph.py`
- Create: `tests/hitch/test_graph.py`

- [ ] **Step 1: 测试**

```python
import pytest

from saddler.exceptions import SaddlerError
from saddler.hitch.graph import assert_acyclic, topological_all_nodes


def test_topo_runtime_before_agent() -> None:
    order = topological_all_nodes(
        runtime_ids={"rt"},
        agent_ids={"app"},
        edges={"app": ["rt"]},
    )
    assert order.index("rt") < order.index("app")


def test_detect_cycle() -> None:
    with pytest.raises(SaddlerError, match="cycle|Cycle"):
        assert_acyclic(
            runtime_ids=set(),
            agent_ids={"a", "b"},
            edges={"a": ["b"], "b": ["a"]},
        )
```

- [ ] **Step 2: 实现**

- 节点 id 全集 = `runtime_ids | agent_ids`。
- 每条 `depends_on` 边：`from -> dep` 在图中为 **dep 先于 from**（`dep` → `from` 有向边，拓扑序从源到汇）。
- `depends_on` 中每个 id 必须 **属于** `runtime_ids` 或 `agent_ids`，否则 `SaddlerError`。
- 环检测：Kahn 或 DFS；发现环抛 `SaddlerError("Hitch depends_on cycle: ...")`。
- `topological_all_nodes`：返回列表，**runtimes 节点整体先于 agents 中仅依赖 runtime 的**，已由边决定；同一层顺序可用稳定排序（按 id 排序）保证确定性。

- [ ] **Step 3: pytest**

Run: `uv run pytest tests/hitch/test_graph.py -v`

- [ ] **Step 4: Commit**

```bash
git add saddler/hitch/graph.py tests/hitch/test_graph.py
git commit -m "feat(hitch): depends_on 校验与拓扑排序"
```

---

### Task 6: HitchPlan 构建

**Files:**

- Create: `saddler/hitch/plan.py`
- Create: `tests/hitch/test_plan.py`

`HitchPlan` 字段建议：

- `project: str`
- `compose_file: str`
- `steps: tuple[PlanStep, ...]`

`PlanStep` 用 `@dataclass(frozen=True)`：

- `CreateRuntime(service_id: str, spec: RuntimeServiceSpec)`
- `CreateAgent(service_id: str, spec: AgentServiceSpec)`

`build_plan(doc: HitchFileV1, *, project: str, compose_file: str) -> HitchPlan`：

1. 从 `doc.runtimes` / `doc.agents` 收集 `depends_on` 边（agent 与 runtime 的 `depends_on` 列表）。  
2. 调 `graph` 模块得全序。  
3. 按序：若 id 在 `runtimes` → `CreateRuntime`；若在 `agents` → `CreateAgent`。

- [ ] **Step 1: 写 `tests/hitch/test_plan.py`**

断言：`build_plan` 对含 `runtimes`+`agents` 的 `HitchFileV1` 产出步骤类型与顺序——`CreateRuntime` / `CreateAgent` 条数与拓扑序一致（例：`app depends_on rt` 则 `rt` 在前）。

Run: `uv run pytest tests/hitch/test_plan.py -v` → FAIL。

- [ ] **Step 2: 实现 `saddler/hitch/plan.py`**

- [ ] **Step 3: pytest**

Run: `uv run pytest tests/hitch/test_plan.py -v` → PASS。

- [ ] **Step 4: Commit**

```bash
git add saddler/hitch/plan.py tests/hitch/test_plan.py
git commit -m "feat(hitch): 从 HitchFile 构建拓扑有序的 HitchPlan"
```

---

### Task 7: HitchExecutor（核心行为）

**Files:**

- Create: `saddler/hitch/executor.py`
- Create: `tests/hitch/test_executor.py`

**hitch 标签构造：**

```python
def hitch_labels(project: str, compose_file: str, service: str) -> dict[str, str]:
    return {
        "project": project,
        "compose_file": compose_file,
        "service": service,
    }
```

**`up` 逻辑：**

1. `logical_runtime_ids: dict[str, str] = {}`  
2. 遍历 `plan.steps`：  
   - `CreateRuntime`：`runtime_cfg = spec.model_dump(exclude={"name", "depends_on"}, exclude_none=True)`，再剔除仅用于 YAML 的字段；`RuntimeManager.create(runtime_cfg, name=spec.name, hitch=hitch_labels(..., service=service_id))`；`logical_runtime_ids[service_id] = rec.runtime_id`。  
   - `CreateAgent`：解析 `runtime` / `runtime_from_agent`：  
     - 若 `runtime` 非空且 `runtime in logical_runtime_ids` → `attach = logical_runtime_ids[runtime]`；否则 `attach = runtime`（外部）。  
     - 若 `runtime_from_agent` 非空且在 `agents` 键中 → `logical_agent_created_ids[logical] = agent_id`（在创建该 agent 后填入）；传给 `AgentCreateConfig.runtime_from_agent` 为 **真实 agent_id**。  
   - `workdir`：相对路径按 **第一个 compose 文件所在目录** `Path.parent` 解析为绝对路径（与 compose 相对路径语义一致）。  
   - `role`：若为相对路径，同样相对 compose 父目录解析。  
3. **幂等（无 `--force-recreate`）**：创建前扫描 `AgentStore.load_all()` / `RuntimeStore.load_all()`：若存在 `hitch` 且 `project`+`compose_file`+`service` 均匹配且将执行创建 → 抛 `SaddlerError` 说明已存在；若 **同名冲突** 但 hitch 不匹配 → 抛 `SaddlerError`（spec §7）。  
4. **`--force-recreate`**：仅对 **hitch 匹配且 project+compose_file+service 一致** 的 agent 先 `AgentManager.rm`（`force=False`，若有前台会话则失败并提示）、对 hitch runtime 先 `runtime stop` + `runtime rm`（`ref_count==0` 时）；**不**动外部 runtime。然后再执行普通 `up`。顺序：**先 down 式删 hitch 资源再创建**（实现时与 `down` 复用删除逻辑的小函数避免重复）。

**`stop`：** 对 `RuntimeStore.load_all()` 中 `hitch.project == project` 且 `hitch.compose_file == compose_file` 且 `hitch.service in doc.runtimes` 的记录调用 `RuntimeManager.stop(runtime_id)`。

**`down`：**  
1. 同 `stop`。  
2. 删除 agent：`hitch` 匹配且 `service in doc.agents` → `AgentManager.rm`。  
3. 删除 runtime：按 **与 `stop` 相同的 hitch 匹配** 且 `service in doc.runtimes` → `RuntimeManager.rm`（无 force；`ref_count>0` 则 `SaddlerError`）。  

若某 hitch agent 仍绑定 **外部** runtime，`rm` agent 后 ref_count 递减；不删除外部 runtime。

**`ps`：** 打印表格：筛选 `hitch` 匹配 `project` 与 `compose_file` 的 agent 与 runtime（可同时列两类）。

- [ ] **Step 1: 在 `tests/hitch/test_executor.py` 用 `MagicMock` 注入 `RuntimeManager` / `AgentManager`，断言 `up` 调用次数与 `hitch` 参数**

- [ ] **Step 2: 实现 `HitchExecutor`**

- [ ] **Step 3: pytest**

- [ ] **Step 4: Commit**

```bash
git add saddler/hitch/executor.py tests/hitch/test_executor.py
git commit -m "feat(hitch): HitchExecutor 实现 up/stop/down/ps"
```

---

### Task 8: CLI `saddler hitch`

**Files:**

- Modify: `saddler/cli.py`
- Create: `tests/cli/test_hitch_commands.py`

- [ ] **Step 1: 注册 Typer**

```python
hitch_app = typer.Typer(name="hitch", help="Multi-service hitch (compose-style) orchestration")
app.add_typer(hitch_app, name="hitch")
```

共享选项：`--file` / `-f` 可 `typer.Option(None, "--file", "-f", help=...)` 用 `list` 或多次传入（Typer `list` + 多值）。

- `config`：`typer.echo` 合并后 YAML（可用 `yaml.safe_dump`）或仅校验静默 `--quiet`。  
- `up`：`--force-recreate` bool。  
- `stop` / `down` / `ps`：无额外参数或仅 `-f`。

实现中调用：`paths = discover_compose_files(..., cwd=Path.cwd())`，`merged, primary = load_merged_compose(paths)`，`project = merged.get("name") or primary.parent.name`，`doc = parse_hitch_doc(merged)`，`plan = build_plan(doc, project=project, compose_file=str(primary))`，`HitchExecutor(...).up(plan, force_recreate=...)`。

- [ ] **Step 2: CliRunner 测试**

`tests/cli/test_hitch_commands.py`：`monkeypatch` `discover_compose_files` / `HitchExecutor` 或 patch `saddler.cli` 中函数，断言 exit code 0 与子命令分发。

- [ ] **Step 3: 全量测试**

Run: `uv run pytest`

- [ ] **Step 4: Commit**

```bash
git commit -m "feat(cli): 新增 saddler hitch 子命令"
```

---

### Task 9: 更新 `docs/spec.md`

**Files:**

- Modify: `docs/spec.md`

- [ ] **Step 1: 在「命令体系」或新小节加入 hitch 命令表、默认文件名、`-f`、与「saddler 无项目级配置」的交叉引用**

- [ ] **Step 2: Commit**

```bash
git commit -m "docs(spec): 补充 hitch 命令与配置文件约定"
```

---

## Spec 对照自检

| Spec 章节 | 对应任务 |
|-----------|----------|
| §1.1 MVP 范围、CLI、up/stop/down、默认文件、project 名、ps、depends_on | Task 3–8 |
| §2–3 Plan + 进程内、不引入通信协议 | Task 6–7 |
| §4 YAML 形状 | Task 3–4 schema + Task 7 路径解析 |
| §5 hitch 元数据、外部资源不删 | Task 1–2、Task 7 down/stop 过滤 |
| §6 五子命令 | Task 8 |
| §7 幂等与 force-recreate | Task 7 |
| §8 错误与环 | Task 5、Task 7 抛 `SaddlerError` |
| §9 测试 | 各 Task 测试 |
| §10 docs/spec.md | Task 9 |

**占位符扫描：** 本计划不含 TBD/TODO 式步骤；合并规则与 `compose_file` 主文件已写死。

**类型一致性：** `hitch` 统一为 `dict[str, str]`，键名 `project` / `compose_file` / `service` 全文一致。

---

**Plan complete and saved to `docs/superpowers/plans/2026-04-14-hitch-implementation.md`. Two execution options:**

**1. Subagent-Driven (recommended)** — 每个 Task 派生子代理并在任务间复核，迭代快  

**2. Inline Execution** — 本会话内按 `executing-plans` 批量执行并设检查点  

你更倾向哪一种？
