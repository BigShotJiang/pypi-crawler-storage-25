# `--mount` 快速挂载 Implementation Plan

> **For agentic workers:** 推荐使用 superpowers:subagent-driven-development 或 superpowers:executing-plans 按任务逐项执行。本计划使用 `- [ ]` 复选框跟踪进度。

**Goal:** 为 `runtime create` 与 hitch runtime 增加 `--mount`/`mounts` 快速挂载能力，并保持与 `--storage` 的语义与持久化隔离。

**Architecture:** Saddler 层保留 `storages` 与 `mounts` 双通道模型；`RuntimeManager` 负责校验、标准化与冲突检测，并将两类输入编译成运行时可执行挂载指令；`DockerRuntime` 仅执行挂载，不感知来源语义；`LocalRuntime` 明确拒绝 mounts。

**Tech Stack:** Python 3, dataclasses, pydantic, typer, pytest

---

## File Structure (planned changes)

- Modify: `saddler/models.py`（`RuntimeRecord.runtime_spec` 支持 `mounts`）
- Modify: `saddler/cli.py`（新增 `--mount` 参数与解析校验）
- Modify: `saddler/manager.py`（mounts 规范化、冲突校验、runtime 构建输入编译）
- Modify: `saddler/runtimes/docker.py`（消费统一挂载指令）
- Modify: `saddler/runtimes/local.py`（可选防御性检查）
- Modify: `saddler/hitch/schema.py`（`RuntimeServiceSpec.mounts`）
- Modify: `saddler/hitch/executor.py`（hitch mounts 路径解析与传递）
- Modify: `tests/cli/test_runtime_commands.py`
- Modify: `tests/hitch/test_schema.py`
- Modify: `tests/hitch/test_executor.py`
- Modify: `tests/test_manager_unit.py`
- Modify: `tests/runtimes/test_docker_runtime.py`
- Modify: `docs/spec.md`（最终规范对齐）

---

### Task 1: 数据模型与 schema 扩展（runtime mounts）

**Files:**
- Modify: `saddler/models.py`
- Modify: `saddler/hitch/schema.py`
- Test: `tests/hitch/test_schema.py`

- [ ] **Step 1: 先写失败测试（hitch schema 支持 mounts）**

```python
def test_runtime_service_spec_accepts_mounts():
    doc = parse_hitch_doc(
        {
            "version": 1,
            "runtimes": {
                "rt-main": {
                    "type": "docker",
                    "mounts": [{"host": "./local-data", "mount": "/workspace"}],
                }
            },
        }
    )
    assert doc.runtimes["rt-main"].mounts[0].host == "./local-data"
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/hitch/test_schema.py -k mounts -v`  
Expected: FAIL（`mounts` 字段尚未定义）

- [ ] **Step 3: 最小实现数据结构**

```python
class RuntimeMountBinding(BaseModel):
    host: str
    mount: str

class RuntimeServiceSpec(BaseModel):
    ...
    mounts: list[RuntimeMountBinding] = Field(default_factory=list)
```

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/hitch/test_schema.py -k mounts -v`  
Expected: PASS

---

### Task 2: CLI `--mount` 解析与前置校验

**Files:**
- Modify: `saddler/cli.py`
- Test: `tests/cli/test_runtime_commands.py`

- [ ] **Step 1: 先写失败测试（格式、类型、路径存在性）**

```python
def test_runtime_create_docker_accepts_mount(runner, mock_runtime_manager, tmp_path):
    d = tmp_path / "data"
    d.mkdir()
    result = runner.invoke(
        app, ["runtime", "create", "--type", "docker", "--mount", f"{d}:/workspace"]
    )
    assert result.exit_code == 0

def test_runtime_create_mount_requires_docker(runner):
    result = runner.invoke(app, ["runtime", "create", "--type", "local", "--mount", "/tmp:/w"])
    assert result.exit_code != 0
    assert "--mount requires --type docker" in str(result.exception)
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k mount -v`  
Expected: FAIL（`--mount` 尚未支持）

- [ ] **Step 3: 实现 CLI 解析函数与报错文案**

实现要点：
- 可重复 `--mount <host>:<mount>`
- `host/mount` 非空，`mount` 必须绝对路径
- `host` 规范化为绝对路径并校验存在
- `--type local` + `--mount` 直接报错
- 结果写入 `runtime_cfg["mounts"] = [{"host_path": "...", "mount": "..."}]`

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k mount -v`  
Expected: PASS

---

### Task 3: RuntimeManager 规范化、冲突校验与持久化

**Files:**
- Modify: `saddler/manager.py`
- Test: `tests/test_manager_unit.py`

- [ ] **Step 1: 先写失败测试（冲突与 record 持久化）**

```python
def test_runtime_create_persists_mounts(runtime_manager, tmp_path):
    d = tmp_path / "data"; d.mkdir()
    rec = runtime_manager.create(
        {
            "type": "docker",
            "mounts": [{"host_path": str(d), "mount": "/workspace"}],
        }
    )
    assert rec.runtime_spec["mounts"][0]["host_path"] == str(d.resolve())

def test_runtime_create_rejects_storage_mount_path_conflict(runtime_manager, storage_store, tmp_path):
    d = tmp_path / "data"; d.mkdir()
    with pytest.raises(SaddlerError):
        runtime_manager.create(
            {
                "type": "docker",
                "storages": [{"storage_id": "st-1", "mount": "/workspace"}],
                "mounts": [{"host_path": str(d), "mount": "/workspace"}],
            }
        )
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/test_manager_unit.py -k "mount or conflict" -v`  
Expected: FAIL（manager 未处理 mounts）

- [ ] **Step 3: 实现 manager 逻辑**

实现要点：
- `_canonicalize_runtime_mount_specs`：规范化 mount 列表
- `_validate_unique_mount_targets`：联合校验 `storages` 与 `mounts` 的 mount 唯一性
- `create()` 持久化 `runtime_spec.mounts`
- storage 绑定/解绑逻辑仍只看 `storages`

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/test_manager_unit.py -k "mount or conflict" -v`  
Expected: PASS

---

### Task 4: 运行时执行层适配（Docker 统一挂载输入）

**Files:**
- Modify: `saddler/manager.py`
- Modify: `saddler/runtimes/docker.py`
- Test: `tests/runtimes/test_docker_runtime.py`

- [ ] **Step 1: 先写失败测试（docker create 参数）**

```python
def test_docker_runtime_setup_mounts_and_storages(monkeypatch):
    runtime = DockerRuntime(
        image="python:3.12",
        mounts=[("host-a", "/a"), ("host-b", "/b")],
    )
    ...
    assert "-v" in docker_create_cmd
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k mount -v`  
Expected: FAIL（runtime 未支持统一挂载输入）

- [ ] **Step 3: 实现 runtime 适配**

实现要点：
- manager 将 `storages + mounts` 编译为统一挂载指令（如 `list[tuple[str, str]]`）
- `DockerRuntime.setup()` 遍历统一挂载指令生成 `-v src:dest`
- runtime 层不区分来源语义

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k mount -v`  
Expected: PASS

---

### Task 5: Hitch 执行链路接入 mounts

**Files:**
- Modify: `saddler/hitch/executor.py`
- Test: `tests/hitch/test_executor.py`

- [ ] **Step 1: 先写失败测试（compose parent 相对路径解析）**

```python
def test_hitch_runtime_mount_host_resolved_against_compose_parent(tmp_path, executor):
    # mounts.host = "./local-data"
    # expect runtime_manager.create receives absolute host_path
    ...
```

- [ ] **Step 2: 运行测试确认失败**

Run: `uv run pytest tests/hitch/test_executor.py -k mount -v`  
Expected: FAIL（executor 尚未映射 mounts）

- [ ] **Step 3: 实现 hitch 映射**

实现要点：
- `_runtime_cfg_from_spec()` 处理 `mounts` 字段
- `host` 按 compose parent 解析绝对路径
- 路径不存在立即报错（阻断 up）

- [ ] **Step 4: 运行测试确认通过**

Run: `uv run pytest tests/hitch/test_executor.py -k mount -v`  
Expected: PASS

---

### Task 6: 回归验证与文档对齐

**Files:**
- Modify: `docs/spec.md`
- Verify: 相关测试全集

- [ ] **Step 1: 补充/更新规范文档**

更新要点：
- `runtime create --mount`
- hitch `runtimes.*.mounts`
- `mounts` 不进入 storage lifecycle

- [ ] **Step 2: 分层回归测试**

Run:
- `uv run pytest tests/cli/test_runtime_commands.py -k mount -v`
- `uv run pytest tests/hitch/test_schema.py tests/hitch/test_executor.py -k mount -v`
- `uv run pytest tests/test_manager_unit.py -k mount -v`
- `uv run pytest tests/runtimes/test_docker_runtime.py -k mount -v`

Expected: PASS

- [ ] **Step 3: 全量验证**

Run: `uv run pytest -q`  
Expected: PASS

---

## Risk Checklist

- [ ] **路径规范化一致性风险**：CLI 与 hitch 必须使用各自正确 base dir（cwd vs compose parent）
- [ ] **冲突检测遗漏风险**：确保 `storages.mount` 与 `mounts.mount` 联合去重
- [ ] **副作用风险**：校验失败不得写 runtime record、不得触发 storage 绑定变更
- [ ] **语义漂移风险**：runtime adapter 不得引入 storage 生命周期逻辑

---

## Self-Review

- **Spec coverage:** 覆盖了 CLI、manager、runtime、hitch、测试与文档同步全链路。
- **Placeholder scan:** 无 TODO/TBD 占位，任务均包含执行命令与预期结果。
- **Constraint check:** 明确纳入“host 路径不存在直接报错”“LocalRuntime 禁止 mounts”“mount/storage 目标冲突报错”三项硬约束。
