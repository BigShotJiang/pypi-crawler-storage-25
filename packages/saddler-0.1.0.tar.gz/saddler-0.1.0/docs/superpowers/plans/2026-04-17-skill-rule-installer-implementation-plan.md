# Skill/Rule Installer Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an infra-only installer that can fetch `skill`/`rule` artifacts from git/archive/local sources, cache by `cache_key`, and optionally install into a caller-provided target directory.

**Architecture:** Add a standalone package `saddler_v2/infra/installer` with separated modules for types, source fetching, discovery, validation, and installation. Use a shared main pipeline for skill/rule and split only in discovery/validation/install naming rules. Drive implementation with TDD in `test_v2/infra/installer`.

**Tech Stack:** Python 3.12, pytest, pathlib, tempfile, tarfile/zipfile, subprocess (git), hashlib, pydantic (if needed for typed request/result models).

---

### Task 1: Scaffold installer package and typed contracts

**Files:**
- Create: `saddler_v2/infra/installer/__init__.py`
- Create: `saddler_v2/infra/installer/types.py`
- Create: `saddler_v2/infra/installer/errors.py`
- Test: `test_v2/infra/installer/test_types.py`

- [ ] **Step 1: Write the failing test**

```python
from saddler_v2.infra.installer.types import (
    ArtifactType,
    ConflictPolicy,
    InstallMode,
    InstallRequest,
)


def test_install_request_requires_name() -> None:
    try:
        InstallRequest(
            mode=InstallMode.FETCH_ONLY,
            artifact_type=ArtifactType.SKILL,
            name="",
            source="https://example.com/repo.git",
        )
    except ValueError:
        pass
    else:
        raise AssertionError("expected name validation to fail")


def test_install_request_accepts_name_and_optional_path() -> None:
    req = InstallRequest(
        mode=InstallMode.FETCH_AND_INSTALL,
        artifact_type=ArtifactType.RULE,
        name="role",
        path="rules/role.mdc",
        source="/tmp/repo",
        target_dir="/tmp/target",
        on_conflict=ConflictPolicy.FAIL,
    )
    assert req.name == "role"
    assert req.path == "rules/role.mdc"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_types.py -v`  
Expected: FAIL with import/module-not-found or missing model validation.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/types.py
from enum import Enum
from pydantic import BaseModel, Field, model_validator


class InstallMode(str, Enum):
    FETCH_ONLY = "fetch_only"
    FETCH_AND_INSTALL = "fetch_and_install"
    INSTALL_FROM_CACHE = "install_from_cache"


class ArtifactType(str, Enum):
    SKILL = "skill"
    RULE = "rule"


class ConflictPolicy(str, Enum):
    REPLACE = "replace"
    SKIP = "skip"
    FAIL = "fail"


class InstallRequest(BaseModel):
    mode: InstallMode = InstallMode.FETCH_AND_INSTALL
    artifact_type: ArtifactType
    name: str = Field(min_length=1)
    path: str | None = None
    source: str | None = None
    cache_key: str | None = None
    target_dir: str | None = None
    on_conflict: ConflictPolicy = ConflictPolicy.FAIL

    @model_validator(mode="after")
    def _validate_mode_requirements(self) -> "InstallRequest":
        if self.mode in (InstallMode.FETCH_ONLY, InstallMode.FETCH_AND_INSTALL) and not self.source:
            raise ValueError("source is required for fetch modes")
        if self.mode in (InstallMode.FETCH_AND_INSTALL, InstallMode.INSTALL_FROM_CACHE) and not self.target_dir:
            raise ValueError("target_dir is required for install modes")
        if self.mode == InstallMode.INSTALL_FROM_CACHE and not self.cache_key:
            raise ValueError("cache_key is required for install_from_cache")
        return self
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_types.py -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/__init__.py saddler_v2/infra/installer/types.py saddler_v2/infra/installer/errors.py test_v2/infra/installer/test_types.py
git commit -m "feat(installer): add base request contracts and enums"
```

### Task 2: Implement fetch/cache pipeline for git/archive/local

**Files:**
- Create: `saddler_v2/infra/installer/sources.py`
- Modify: `saddler_v2/infra/installer/types.py`
- Test: `test_v2/infra/installer/test_sources.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path

from saddler_v2.infra.installer.sources import fetch_to_cache
from saddler_v2.infra.installer.types import SourceSpec


def test_fetch_local_source_returns_stable_cache_key(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    (src / "rules").mkdir()
    (src / "rules" / "role.mdc").write_text("rule", encoding="utf-8")

    cache_root = tmp_path / "cache"
    result1 = fetch_to_cache(SourceSpec(kind="local", uri=str(src), ref=None), cache_root)
    result2 = fetch_to_cache(SourceSpec(kind="local", uri=str(src), ref=None), cache_root)

    assert result1.cache_key == result2.cache_key
    assert result1.cache_path.exists()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_sources.py -v`  
Expected: FAIL due to missing source fetch/cache logic.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/sources.py
from dataclasses import dataclass
from pathlib import Path
import hashlib
import shutil


@dataclass(frozen=True)
class FetchResult:
    cache_key: str
    cache_path: Path
    source_digest: str


def fetch_to_cache(spec, cache_root: Path) -> FetchResult:
    # local first; git/archive follow same return contract
    src = Path(spec.uri).expanduser().resolve()
    digest = _digest_dir(src)
    cache_key = f"{spec.kind}:{digest}"
    dst = cache_root / cache_key
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst)
    return FetchResult(cache_key=cache_key, cache_path=dst, source_digest=digest)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_sources.py -v`  
Expected: PASS for local source test; add and pass git/archive tests in same file before commit.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/sources.py saddler_v2/infra/installer/types.py test_v2/infra/installer/test_sources.py
git commit -m "feat(installer): add source fetch and cache pipeline"
```

### Task 3: Implement deterministic discovery with optional path override

**Files:**
- Create: `saddler_v2/infra/installer/discovery.py`
- Test: `test_v2/infra/installer/test_discovery.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path
import pytest

from saddler_v2.infra.installer.discovery import discover_artifact
from saddler_v2.infra.installer.types import ArtifactType


def test_discover_skill_by_name_prefers_skills_dir(tmp_path: Path) -> None:
    root = tmp_path / "root"
    (root / "skills" / "demo").mkdir(parents=True)
    resolved = discover_artifact(root, ArtifactType.SKILL, name="demo", path=None)
    assert resolved == root / "skills" / "demo"


def test_discover_rule_ambiguous_requires_explicit_path(tmp_path: Path) -> None:
    root = tmp_path / "root"
    root.mkdir()
    (root / "rules").mkdir()
    (root / "rules" / "role").write_text("a", encoding="utf-8")
    (root / "role").write_text("b", encoding="utf-8")
    with pytest.raises(Exception):
        discover_artifact(root, ArtifactType.RULE, name="role", path=None)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_discovery.py -v`  
Expected: FAIL with missing discovery implementation.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/discovery.py
from pathlib import Path


def discover_artifact(source_root: Path, artifact_type, name: str, path: str | None) -> Path:
    if path:
        candidate = (source_root / path).resolve()
        if source_root.resolve() not in candidate.parents and candidate != source_root.resolve():
            raise ValueError("path escapes source_root")
        if not candidate.exists():
            raise FileNotFoundError(path)
        return candidate

    candidates = _name_candidates(source_root, artifact_type, name)
    exists = [p for p in candidates if p.exists()]
    if not exists:
        raise FileNotFoundError(name)
    if len(exists) > 1:
        raise ValueError(f"ambiguous artifact path for {name}: {exists}")
    return exists[0]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_discovery.py -v`  
Expected: PASS including explicit path, not-found, and path-escape cases.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/discovery.py test_v2/infra/installer/test_discovery.py
git commit -m "feat(installer): add deterministic artifact discovery"
```

### Task 4: Implement validation for skill frontmatter and rule text

**Files:**
- Create: `saddler_v2/infra/installer/validate.py`
- Test: `test_v2/infra/installer/test_validate.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path
import pytest

from saddler_v2.infra.installer.types import ArtifactType
from saddler_v2.infra.installer.validate import validate_artifact


def test_validate_skill_requires_frontmatter_name_description(tmp_path: Path) -> None:
    skill_dir = tmp_path / "demo"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        "---\nname: demo\ndescription: test\n---\nbody\n",
        encoding="utf-8",
    )
    meta = validate_artifact(skill_dir, ArtifactType.SKILL)
    assert meta["name"] == "demo"


def test_validate_rule_rejects_empty_file(tmp_path: Path) -> None:
    rule = tmp_path / "role.mdc"
    rule.write_text("", encoding="utf-8")
    with pytest.raises(Exception):
        validate_artifact(rule, ArtifactType.RULE)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_validate.py -v`  
Expected: FAIL due to absent validation function.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/validate.py
from pathlib import Path
import frontmatter


def validate_artifact(path: Path, artifact_type):
    if artifact_type == "skill":
        skill_md = path / "SKILL.md"
        post = frontmatter.loads(skill_md.read_text(encoding="utf-8"))
        if not post.get("name") or not post.get("description"):
            raise ValueError("frontmatter requires name and description")
        return {"name": post["name"], "description": post["description"]}
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        raise ValueError("rule content cannot be empty")
    return {"size": len(text)}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_validate.py -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/validate.py test_v2/infra/installer/test_validate.py
git commit -m "feat(installer): add skill and rule validation"
```

### Task 5: Implement install operation with conflict policies

**Files:**
- Create: `saddler_v2/infra/installer/install.py`
- Test: `test_v2/infra/installer/test_install.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path

from saddler_v2.infra.installer.install import install_artifact_payload
from saddler_v2.infra.installer.types import ConflictPolicy


def test_install_replace_policy_overwrites_existing_rule(tmp_path: Path) -> None:
    source = tmp_path / "role.mdc"
    source.write_text("new", encoding="utf-8")
    target_dir = tmp_path / "target"
    target_dir.mkdir()
    (target_dir / "role").write_text("old", encoding="utf-8")

    result = install_artifact_payload(
        artifact_type="rule",
        name="role",
        source_path=source,
        target_dir=target_dir,
        on_conflict=ConflictPolicy.REPLACE,
    )
    assert result.status == "replaced"
    assert (target_dir / "role").read_text(encoding="utf-8") == "new"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_install.py -v`  
Expected: FAIL with missing install logic.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/install.py
from pathlib import Path
import shutil
import tempfile


def install_artifact_payload(*, artifact_type, name, source_path: Path, target_dir: Path, on_conflict):
    target = target_dir / name
    exists = target.exists()
    if exists and on_conflict == "fail":
        raise ValueError("conflict")
    if exists and on_conflict == "skip":
        return {"status": "skipped", "installed_path": str(target)}
    # write to temp and atomic replace
    with tempfile.TemporaryDirectory(prefix="installer-") as td:
        staging = Path(td) / name
        if artifact_type == "skill":
            shutil.copytree(source_path, staging)
        else:
            shutil.copy2(source_path, staging)
        target.parent.mkdir(parents=True, exist_ok=True)
        staging.replace(target)
    return {"status": "replaced" if exists else "installed", "installed_path": str(target)}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_install.py -v`  
Expected: PASS for replace/skip/fail and skill-directory install cases.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/install.py test_v2/infra/installer/test_install.py
git commit -m "feat(installer): add atomic install with conflict policies"
```

### Task 6: Implement orchestrator service and mode switching

**Files:**
- Create: `saddler_v2/infra/installer/service.py`
- Modify: `saddler_v2/infra/installer/__init__.py`
- Test: `test_v2/infra/installer/test_service.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path

from saddler_v2.infra.installer.service import install_artifact
from saddler_v2.infra.installer.types import InstallRequest, InstallMode, ArtifactType


def test_fetch_only_returns_cache_key_without_install(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    (src / "rules").mkdir()
    (src / "rules" / "role").write_text("content", encoding="utf-8")
    target = tmp_path / "target"
    target.mkdir()

    result = install_artifact(
        InstallRequest(
            mode=InstallMode.FETCH_ONLY,
            artifact_type=ArtifactType.RULE,
            name="role",
            source=str(src),
        ),
        cache_root=tmp_path / "cache",
    )
    assert result.cache_key
    assert not (target / "role").exists()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_service.py -v`  
Expected: FAIL due to missing orchestrator.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/service.py
def install_artifact(request, *, cache_root):
    if request.mode == "fetch_only":
        return _fetch_only(request, cache_root)
    if request.mode == "install_from_cache":
        return _install_from_cache(request, cache_root)
    fetched = _fetch_only(request, cache_root)
    return _install_from_cache(request.model_copy(update={"cache_key": fetched.cache_key}), cache_root)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer/test_service.py -v`  
Expected: PASS for all 3 modes and `cache_key`-driven flow.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/installer/service.py saddler_v2/infra/installer/__init__.py test_v2/infra/installer/test_service.py
git commit -m "feat(installer): add mode-aware installer orchestrator"
```

### Task 7: Integration tests for end-to-end behavior and offline install-from-cache

**Files:**
- Create: `test_v2/infra/installer/test_e2e_installer.py`

- [ ] **Step 1: Write the failing test**

```python
from pathlib import Path

from saddler_v2.infra.installer.service import install_artifact
from saddler_v2.infra.installer.types import InstallRequest, InstallMode, ArtifactType


def test_e2e_fetch_then_install_from_cache_for_skill(tmp_path: Path) -> None:
    src = tmp_path / "src"
    (src / "skills" / "demo").mkdir(parents=True)
    (src / "skills" / "demo" / "SKILL.md").write_text(
        "---\nname: demo\ndescription: demo skill\n---\n",
        encoding="utf-8",
    )
    cache_root = tmp_path / "cache"
    target = tmp_path / "target"

    fetched = install_artifact(
        InstallRequest(
            mode=InstallMode.FETCH_ONLY,
            artifact_type=ArtifactType.SKILL,
            name="demo",
            source=str(src),
        ),
        cache_root=cache_root,
    )
    result = install_artifact(
        InstallRequest(
            mode=InstallMode.INSTALL_FROM_CACHE,
            artifact_type=ArtifactType.SKILL,
            name="demo",
            cache_key=fetched.cache_key,
            target_dir=str(target),
        ),
        cache_root=cache_root,
    )
    assert result.status == "installed"
    assert (target / "demo" / "SKILL.md").exists()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/installer/test_e2e_installer.py -v`  
Expected: FAIL before all pieces are wired.

- [ ] **Step 3: Write minimal implementation**

```python
# saddler_v2/infra/installer/service.py (integration gap fix)
def _resolve_cache_path(cache_root: Path, cache_key: str) -> Path:
    path = cache_root / cache_key
    if not path.exists():
        raise CacheError(
            code="CACHE_ERROR",
            message=f"cache entry not found: {cache_key}",
            details={"cache_root": str(cache_root)},
        )
    return path
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/installer -v`  
Expected: PASS for full installer test suite.

- [ ] **Step 5: Commit**

Run:
```bash
git add test_v2/infra/installer/test_e2e_installer.py saddler_v2/infra/installer
git commit -m "test(installer): cover e2e cache-driven install flows"
```

### Task 8: Hook installer into Cursor harness (non-breaking integration)

**Files:**
- Modify: `saddler_v2/infra/harness/cursor.py`
- Test: `test_v2/infra/harness/test_cursor_harness_install.py`

- [ ] **Step 1: Write the failing test**

```python
from saddler_v2.agent.model import RuleSpec, SkillSpec
from saddler_v2.agent.model import AgentSpec
from saddler_v2.infra.harness.cursor import CursorHarness


def test_cursor_harness_installs_skill_and_rule_via_installer(mocker):
    harness = CursorHarness.from_spec(
        AgentSpec(
            harness="cursor",
            workdir="/workspace",
            role=None,
            skills=[],
            rules=[],
            harness_spec=None,
        )
    )
    runtime = mocker.Mock()
    install_mock = mocker.patch("saddler_v2.infra.harness.cursor.install_artifact")

    harness.install_rules(runtime, [RuleSpec(name="role", source="...", path=None, hash=None)])
    harness.install_skills(runtime, [SkillSpec(name="demo", source="...", path=None, hash=None)])

    assert install_mock.call_count == 2
    rule_call = install_mock.call_args_list[0]
    skill_call = install_mock.call_args_list[1]
    assert "/.cursor/rules" in str(rule_call)
    assert "/.cursor/skills" in str(skill_call)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest test_v2/infra/harness/test_cursor_harness_install.py -v`  
Expected: FAIL because harness currently writes files directly.

- [ ] **Step 3: Write minimal implementation**

```python
# cursor.py
for rule in rules:
    install_artifact(
        InstallRequest(
            mode=InstallMode.FETCH_AND_INSTALL,
            artifact_type=ArtifactType.RULE,
            name=rule.name,
            path=rule.path,
            source=rule.source,
            target_dir=f"{cfg}/rules",
            on_conflict=ConflictPolicy.REPLACE,
        ),
        cache_root=_default_cache_root(self.spec.workdir),
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest test_v2/infra/harness/test_cursor_harness_install.py -v`  
Expected: PASS with no regression to harness interfaces.

- [ ] **Step 5: Commit**

Run:
```bash
git add saddler_v2/infra/harness/cursor.py test_v2/infra/harness/test_cursor_harness_install.py
git commit -m "refactor(cursor): delegate skill/rule install to installer"
```

### Task 9: Final verification and documentation alignment

**Files:**
- Modify: `docs/superpowers/specs/2026-04-17-skill-rule-installer-design.md` (only if implementation-driven clarifications are needed)
- Modify: `README.md` (optional concise usage note)

- [ ] **Step 1: Run full targeted test suite**

Run: `uv run pytest test_v2/infra/installer test_v2/infra/harness/test_cursor_harness_install.py -v`  
Expected: PASS.

- [ ] **Step 2: Run lints/type checks used by project**

Run: `uv run pytest test_v2 -q`  
Expected: PASS or known unrelated failures documented separately.

- [ ] **Step 3: Update docs if behavior changed from spec wording**

```markdown
Add concise "fetch_only / install_from_cache" usage examples and `cache_key` flow.
```

- [ ] **Step 4: Verify git diff is scoped**

Run: `git status --short`  
Expected: only installer/harness/tests/docs changes relevant to this feature.

- [ ] **Step 5: Commit**

Run:
```bash
git add README.md docs/superpowers/specs/2026-04-17-skill-rule-installer-design.md
git commit -m "docs(installer): align usage and behavior notes"
```
