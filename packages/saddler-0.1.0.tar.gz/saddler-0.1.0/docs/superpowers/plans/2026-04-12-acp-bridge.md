# ACP Bridge（stdio → WebSocket / Streamable HTTP）Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 `saddler` 仓库中实现单进程 ACP 桥：每个网络连接（WebSocket 或 Streamable HTTP 会话）对应一个独立的 stdio agent 子进程，双向转发换行分隔的 JSON-RPC 文本，并实施并发上限、行长度上限、spawn 超时与有序终止。

**Architecture:** 使用 **Starlette（ASGI）** 在同一进程内挂载 **WebSocket** 路由与 **HTTP 流式** 路由；核心逻辑为 **SessionManager**（全局槽位）+ **BridgeSession**（单连接：子进程 + 异步管道读写 + 传输回调）。**Streamable HTTP** 在官方页面尚无报文级说明时，采用 **已文档化的 MVP 轮廓**：`POST /sessions` 建连并 spawn，`GET /sessions/{id}/from-agent` 输出子进程 stdout 行流，`POST /sessions/{id}/to-agent` 读取请求体行并写入 stdin；官方草案定稿后 **仅替换** `saddler/acp_bridge/transports/shttp.py` 中的路由与帧映射，不改 spawn 与行协议核心。

**Tech Stack:** Python 3.11+，`uvicorn[standard]`，`starlette`，`pytest`，`pytest-asyncio`，`httpx`（异步测试 HTTP）。包管理：`uv`。

---

## 文件结构（落地前锁定）

| 路径 | 职责 |
|------|------|
| `saddler/acp_bridge/__init__.py` | 包导出（可选：`BridgeConfig`） |
| `saddler/acp_bridge/__main__.py` | `python -m saddler.acp_bridge` 入口 |
| `saddler/acp_bridge/config.py` | `BridgeConfig`：监听地址、spawn 模板、`max_sessions`、`max_line_bytes`、`spawn_timeout_s`、`idle_timeout_s`（可选） |
| `saddler/acp_bridge/spawn.py` | `asyncio.create_subprocess_exec`、关闭 stdin、SIGTERM/SIGKILL 阶梯终止 |
| `saddler/acp_bridge/line_io.py` | 异步按行读（上限）、写行、校验单行无裸 `\n` |
| `saddler/acp_bridge/manager.py` | `SessionManager.acquire()` / `release()`，超限时拒绝 |
| `saddler/acp_bridge/session.py` | `BridgeSession`：持有 `Process`、启动双向 `asyncio` 任务、取消与回收 |
| `saddler/acp_bridge/app.py` | `build_app(config) -> Starlette`：注册 WS 与 HTTP 路由 |
| `saddler/acp_bridge/transports/websocket.py` | WebSocket 接受后建 session，文本帧 ↔ 行 |
| `saddler/acp_bridge/transports/shttp.py` | MVP：`/sessions`、`/sessions/{id}/from-agent`、`/sessions/{id}/to-agent` |
| `saddler/acp_bridge/logging.py` | `connection_id` / `pid` / `transport` 结构化日志辅助 |
| `tests/acp_bridge/conftest.py` | 共享 fixtures（任意端口、临时配置） |
| `tests/acp_bridge/test_line_io.py` | 行长度与读写 |
| `tests/acp_bridge/test_spawn.py` | spawn/终止 |
| `tests/acp_bridge/test_manager.py` | 并发槽位 |
| `tests/acp_bridge/test_session_echo.py` | 假 echo 子进程双向转发 |
| `tests/acp_bridge/test_ws.py` | WebSocket 集成 |
| `tests/acp_bridge/test_shttp.py` | HTTP 双通道集成 |

**修改：** `pyproject.toml`（依赖、`[project.scripts]` 增加 `acp-bridge`）、可选在 `README.md` 增加一小节（计划最后一任务）。

---

### Task 1: 依赖与包骨架

**Files:**
- Create: `saddler/acp_bridge/__init__.py`
- Create: `saddler/acp_bridge/config.py`
- Modify: `pyproject.toml`

- [ ] **Step 1: 用 uv 添加运行时与开发依赖**

Run:

```bash
cd /workspace && uv add "uvicorn[standard]" starlette && uv add --dev pytest pytest-asyncio httpx
```

Expected: `pyproject.toml` / `uv.lock` 更新成功。

- [ ] **Step 2: 编写 `BridgeConfig`**

Create `saddler/acp_bridge/config.py`:

```python
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True, slots=True)
class BridgeConfig:
    """Configuration for the ACP bridge process."""

    host: str = "127.0.0.1"
    port: int = 8765
    spawn_argv: Sequence[str] = field(default_factory=lambda: ["cat"])
    spawn_cwd: Path | None = None
    max_sessions: int = 16
    max_line_bytes: int = 1 << 20
    spawn_timeout_s: float = 30.0
```

- [ ] **Step 3: 最小 `__init__.py`**

Create `saddler/acp_bridge/__init__.py`:

```python
from saddler.acp_bridge.config import BridgeConfig

__all__ = ["BridgeConfig"]
```

- [ ] **Step 4: 在 `pyproject.toml` 的 `[project.scripts]` 增加入口（在 `saddler = ...` 下一行）**

```toml
acp-bridge = "saddler.acp_bridge.__main__:main"
```

（`main` 在 Task 7 实现；**推荐 Task 7 再添加 `acp-bridge` script**，本任务只加依赖与 `config.py`，避免入口未实现。）

- [ ] **Step 5: 验证导入**

Run:

```bash
cd /workspace && uv run python -c "from saddler.acp_bridge import BridgeConfig; print(BridgeConfig())"
```

Expected: 打印 `BridgeConfig(...)` 无异常。

---

### Task 2: 行协议与 spawn 终止

**Files:**
- Create: `saddler/acp_bridge/line_io.py`
- Create: `saddler/acp_bridge/spawn.py`
- Create: `tests/acp_bridge/test_line_io.py`
- Create: `tests/acp_bridge/test_spawn.py`
- Create: `tests/acp_bridge/conftest.py`

- [ ] **Step 1: 写失败测试——超长行**

Create `tests/acp_bridge/test_line_io.py`:

```python
import pytest

from saddler.acp_bridge.line_io import read_line_bounded


@pytest.mark.asyncio
async def test_read_line_bounded_rejects_over_limit():
    from io import BytesIO

    raw = b"x" * 10 + b"\n"
    stream = BytesIO(raw)
    with pytest.raises(ValueError, match="line too long"):
        await read_line_bounded(stream, max_line_bytes=5)
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```bash
cd /workspace && uv run pytest tests/acp_bridge/test_line_io.py::test_read_line_bounded_rejects_over_limit -v
```

Expected: 失败（`read_line_bounded` 未定义或 import 错误）。

- [ ] **Step 3: 实现 `line_io.py`**

Create `saddler/acp_bridge/line_io.py`:

```python
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator


async def read_line_bounded(
    reader: asyncio.StreamReader, *, max_line_bytes: int
) -> bytes:
    """Read until LF; strip trailing CR/LF. Raises ValueError if line exceeds max."""
    buf = bytearray()
    while True:
        ch = await reader.read(1)
        if not ch:
            if buf:
                raise ValueError("incomplete line at EOF")
            return b""
        if ch == b"\n":
            line = bytes(buf)
            buf.clear()
            if line.endswith(b"\r"):
                line = line[:-1]
            if len(line) > max_line_bytes:
                raise ValueError("line too long")
            return line
        buf.extend(ch)
        if len(buf) > max_line_bytes:
            raise ValueError("line too long")


async def iter_stdout_lines(
    reader: asyncio.StreamReader, *, max_line_bytes: int
) -> AsyncIterator[bytes]:
    while True:
        line = await read_line_bounded(reader, max_line_bytes=max_line_bytes)
        if line == b"":
            break
        yield line


def validate_no_embedded_newline(data: bytes) -> None:
    if b"\n" in data or b"\r" in data:
        raise ValueError("ACP stdio line must not contain embedded newlines")


async def write_line(writer: asyncio.StreamWriter, line: bytes) -> None:
    validate_no_embedded_newline(line)
    writer.write(line + b"\n")
    await writer.drain()
```

- [ ] **Step 4: 修正测试使用 `StreamReader`**

Replace `test_read_line_bounded_rejects_over_limit` 为使用 `asyncio.StreamReader` 与 `feed_data`（或 `asyncio` 子进程）更贴近真实路径。最小可用版本：

```python
import asyncio

import pytest

from saddler.acp_bridge.line_io import read_line_bounded


@pytest.mark.asyncio
async def test_read_line_bounded_rejects_over_limit():
    reader = asyncio.StreamReader()
    reader.feed_data(b"x" * 10 + b"\n")
    reader.feed_eof()
    with pytest.raises(ValueError, match="line too long"):
        await read_line_bounded(reader, max_line_bytes=5)
```

- [ ] **Step 5: 运行测试通过**

Run:

```bash
uv run pytest tests/acp_bridge/test_line_io.py -v
```

Expected: PASS。

- [ ] **Step 6: spawn 测试——`echo` 子进程可杀**

Create `tests/acp_bridge/test_spawn.py`:

```python
import asyncio

import pytest

from saddler.acp_bridge.spawn import terminate_process


@pytest.mark.asyncio
async def test_terminate_kills_child():
    proc = await asyncio.create_subprocess_exec(
        "sleep", "60", stdout=asyncio.subprocess.PIPE
    )
    assert proc.pid is not None
    await terminate_process(proc, wait_timeout_s=2.0)
    code = await proc.wait()
    assert code is not None
```

Create `saddler/acp_bridge/spawn.py`:

```python
from __future__ import annotations

import asyncio
import contextlib
import os
import signal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from asyncio.subprocess import Process


async def terminate_process(proc: "Process", *, wait_timeout_s: float = 5.0) -> None:
    if proc.returncode is not None:
        return
    proc.terminate()
    try:
        await asyncio.wait_for(proc.wait(), timeout=wait_timeout_s)
    except TimeoutError:
        proc.kill()
        with contextlib.suppress(ProcessLookupError):
            await proc.wait()


def setup_child_watcher() -> None:
    """Call once in main on Unix if not using asyncio.run default (optional)."""
    if os.name == "posix":
        with contextlib.suppress(NotImplementedError):
            asyncio.get_event_loop_policy().get_child_watcher()
```

- [ ] **Step 7: 运行 spawn 测试**

Run:

```bash
uv run pytest tests/acp_bridge/test_spawn.py -v
```

Expected: PASS（环境需有 `sleep`）。

---

### Task 3: SessionManager

**Files:**
- Create: `saddler/acp_bridge/manager.py`
- Create: `tests/acp_bridge/test_manager.py`

- [ ] **Step 1: 失败测试 `max_sessions`**

Create `tests/acp_bridge/test_manager.py`:

```python
import pytest

from saddler.acp_bridge.config import BridgeConfig
from saddler.acp_bridge.manager import SessionManager


def test_acquire_release():
    cfg = BridgeConfig(max_sessions=2)
    m = SessionManager(cfg)
    assert m.acquire() is True
    assert m.acquire() is True
    assert m.acquire() is False
    m.release()
    assert m.acquire() is True
```

- [ ] **Step 2: 实现 `SessionManager`**

Create `saddler/acp_bridge/manager.py`:

```python
from __future__ import annotations

import threading

from saddler.acp_bridge.config import BridgeConfig


class SessionManager:
    def __init__(self, config: BridgeConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._active = 0

    def acquire(self) -> bool:
        with self._lock:
            if self._active >= self._config.max_sessions:
                return False
            self._active += 1
            return True

    def release(self) -> None:
        with self._lock:
            if self._active <= 0:
                raise RuntimeError("release without acquire")
            self._active -= 1

    @property
    def active(self) -> int:
        with self._lock:
            return self._active
```

- [ ] **Step 3: pytest**

Run:

```bash
uv run pytest tests/acp_bridge/test_manager.py -v
```

Expected: PASS。

---

### Task 4: BridgeSession（echo 子进程）

**Files:**
- Create: `saddler/acp_bridge/session.py`
- Create: `tests/acp_bridge/test_session_echo.py`

- [ ] **Step 1: 使用 `python -c` echo 循环作为假 agent**

Create `tests/acp_bridge/test_session_echo.py`（核心断言：写一行入 stdin，stdout 回一行）：

```python
import asyncio
import sys

import pytest

from saddler.acp_bridge.config import BridgeConfig
from saddler.acp_bridge.manager import SessionManager
from saddler.acp_bridge.session import BridgeSession


ECHO_PY = r"""
import sys
for line in sys.stdin.buffer:
    sys.stdout.buffer.write(line)
    sys.stdout.buffer.flush()
"""


@pytest.mark.asyncio
async def test_bridge_session_echo_roundtrip():
    cfg = BridgeConfig(max_sessions=2, max_line_bytes=4096)
    mgr = SessionManager(cfg)
    assert mgr.acquire() is True
    try:
        session = BridgeSession(
            config=cfg,
            manager=mgr,
            argv=[sys.executable, "-c", ECHO_PY],
            cwd=None,
        )
        await session.start()
        await session.send_line(b'{"jsonrpc":"2.0","id":1}')
        line = await session.receive_line()
        assert line.startswith(b"{")
        await session.close()
    finally:
        mgr.release()
```

- [ ] **Step 2: 实现 `BridgeSession`（最小）**

Create `saddler/acp_bridge/session.py`：

- `start()`：`asyncio.create_subprocess_exec`，`stdin=PIPE`，`stdout=PIPE`，`stderr=PIPE`，可选 `spawn_timeout_s` 内等待进程可写。
- `send_line` / `receive_line`：调用 `line_io.write_line` / `read_line_bounded`。
- `close()`：`stdin` 关闭 → `terminate_process` → `manager` 若曾 `acquire` 需 `release`——**注意**：session 应在创建时由调用方 `acquire`，`close` 时 `release`；在 `BridgeSession.__init__` 传入 `SessionManager` 并在 `close` 里 `release` 一次。

为避免重复 `acquire`，约定：**外部** `acquire` 成功后才构造 `BridgeSession`，`close` 时 `release`。

实现骨架：

```python
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Sequence
import uuid

from saddler.acp_bridge.config import BridgeConfig
from saddler.acp_bridge.line_io import read_line_bounded, write_line
from saddler.acp_bridge.manager import SessionManager
from saddler.acp_bridge.spawn import terminate_process


class BridgeSession:
    def __init__(
        self,
        *,
        config: BridgeConfig,
        manager: SessionManager,
        argv: Sequence[str],
        cwd: Path | None,
        connection_id: str | None = None,
    ) -> None:
        self._config = config
        self._manager = manager
        self._argv = list(argv)
        self._cwd = cwd
        self.connection_id = connection_id or str(uuid.uuid4())
        self._proc: asyncio.subprocess.Process | None = None

    async def start(self) -> None:
        self._proc = await asyncio.create_subprocess_exec(
            *self._argv,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self._cwd,
        )
        assert self._proc.stdin and self._proc.stdout

    async def send_line(self, line: bytes) -> None:
        assert self._proc and self._proc.stdin
        await write_line(self._proc.stdin, line)

    async def receive_line(self) -> bytes:
        assert self._proc and self._proc.stdout
        return await read_line_bounded(
            self._proc.stdout, max_line_bytes=self._config.max_line_bytes
        )

    async def close(self) -> None:
        if not self._proc:
            return
        if self._proc.stdin:
            self._proc.stdin.close()
            await self._proc.stdin.wait_closed()
        await terminate_process(self._proc)
        self._proc = None
        self._manager.release()
```

**修正测试**：`receive_line` 在 echo 场景应先 `send_line` 再 `receive_line`；echo 逐行 flush，OK。`close` 里 `release` 则测试在 `finally` 不应再 `release`——调整测试为 **仅** `session.close()` 内 `release`：

在 `test_bridge_session_echo_roundtrip` 中去掉 `mgr.release()` in `finally`，改为只在 `close()` 中 release；测试开头 `acquire`，`close` 内 release。

- [ ] **Step 3: pytest**

Run:

```bash
uv run pytest tests/acp_bridge/test_session_echo.py -v
```

Expected: PASS。

---

### Task 5: Starlette WebSocket 传输

**Files:**
- Create: `saddler/acp_bridge/transports/__init__.py`
- Create: `saddler/acp_bridge/transports/websocket.py`
- Create: `saddler/acp_bridge/app.py`（最小仅 WS）
- Create: `tests/acp_bridge/test_ws.py`

- [ ] **Step 1: WebSocket 协议约定（MVP）**

- 每个 **文本帧** 载荷为 **一条完整行**（不含 `\n`），UTF-8；桥写入子进程时 **追加 `\n`**。
- 子进程 **每行 stdout** 作为 **一条文本帧** 发出。

- [ ] **Step 2: 实现 `websocket.py` 中 handler**

伪代码逻辑：

```python
async def websocket_endpoint(websocket: WebSocket, config: BridgeConfig, manager: SessionManager):
    await websocket.accept()
    if not manager.acquire():
        await websocket.close(code=1013)  # Try again later
        return
    session = BridgeSession(config=config, manager=manager, argv=config.spawn_argv, cwd=config.spawn_cwd)
    try:
        await session.start()
        async def pump_out():
            while True:
                line = await session.receive_line()
                if line == b"":
                    break
                await websocket.send_text(line.decode())
        async def pump_in():
            while True:
                msg = await websocket.receive_text()
                await session.send_line(msg.encode())
        await asyncio.gather(pump_out(), pump_in())
    finally:
        await session.close()
```

**注意**：`receive_line` 在 EOF 返回 `b""` 需与 `line_io` 一致；当前 `read_line_bounded` 在 EOF 且无缓冲返回 `b""`。`pump_in` 在 `receive_text` 关闭时抛错，进 `finally`。

需将 `BridgeSession` 扩展为支持 **并发** pump：同一 `stdin` 只能一个写入者；同一 `stdout` 只能一个读取者。当前设计 OK。

**修复**：`pump_out` / `pump_in` 应用 `asyncio.create_task` 并处理一方失败取消另一方（计划实现时用 `TaskGroup` 或 `gather` with `return_exceptions`）。

- [ ] **Step 3: `build_app` 仅注册 `/ws`**

`app.py` 中 `Starlette(routes=[WebSocketRoute("/ws", endpoint)])`，`endpoint` 需闭包绑定 `config` 与 `manager`。

- [ ] **Step 4: 集成测试 `test_ws.py`**

使用 `starlette.testclient.TestClient` **不支持** 真 async WS；使用 `websockets` 库异步连接：

```python
import asyncio

import pytest
import uvicorn
import websockets

from saddler.acp_bridge.app import build_app
from saddler.acp_bridge.config import BridgeConfig


@pytest.mark.asyncio
async def test_ws_echo_roundtrip(unused_tcp_port):
    cfg = BridgeConfig(
        host="127.0.0.1",
        port=unused_tcp_port,
        spawn_argv=["python", "-c", "import sys\nfor l in sys.stdin.buffer: sys.stdout.buffer.write(l); sys.stdout.buffer.flush()"],
    )
    app = build_app(cfg)
    config = uvicorn.Config(app, host=cfg.host, port=cfg.port, log_level="warning")
    server = uvicorn.Server(config)
    task = asyncio.create_task(server.serve())
    await asyncio.sleep(0.2)
    try:
        uri = f"ws://{cfg.host}:{cfg.port}/ws"
        async with websockets.connect(uri) as ws:
            await ws.send('{"x":1}')
            msg = await ws.recv()
            assert '"x":1' in msg
    finally:
        server.should_exit = True
        await task
```

**修正**：`spawn_argv` 在 Windows 不同；测试用 `sys.executable` 与 `ECHO_PY` 常量同 Task 4。`unused_tcp_port` 需在 `conftest.py` 用 `socket` 找空闲端口。

Create `tests/acp_bridge/conftest.py`:

```python
import socket

import pytest


@pytest.fixture
def unused_tcp_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
```

- [ ] **Step 5: 运行 `test_ws.py`**

Run:

```bash
uv run pytest tests/acp_bridge/test_ws.py -v
```

Expected: PASS。

---

### Task 6: Streamable HTTP MVP（双通道）

**Files:**
- Create: `saddler/acp_bridge/transports/shttp.py`
- Modify: `saddler/acp_bridge/app.py`

- [ ] **Step 1: 在 `shttp.py` 文档字符串写死 MVP 契约**

说明：`POST /sessions` 返回 `{"session_id":"..."}`；`GET /sessions/{id}/from-agent` 为 `StreamingResponse`；`POST /sessions/{id}/to-agent` 读 body stream。与官方 Streamable HTTP 草案对齐后替换本模块。

- [ ] **Step 2: 使用内存 registry `dict[session_id, BridgeSession]`**

创建 session 时 `acquire` + `start`；注册 id；**from-agent** 与 **to-agent** 共享同一 `BridgeSession`。

- [ ] **Step 3: `GET from-agent`**

异步生成器：循环 `receive_line()`，yield `line + b"\n"`，`media_type="application/x-ndjson"` 或 `text/plain`。

- [ ] **Step 4: `POST to-agent`**

`async for chunk in request.stream()`：缓冲字节，按 `\n` 切分，对每完整行 `send_line`。

- [ ] **Step 5: `app.py` 挂载 HTTP 路由**

**YAGNI：** MVP 使用 **单进程、单监听端口**：同一 `Starlette` 应用同时注册 `/ws` 与 HTTP 路由（`POST /sessions` 等）。

**端口：** Task 1 起使用单字段 `BridgeConfig.port`；HTTP 与 WebSocket 共用该端口。

- [ ] **Step 6: `tests/acp_bridge/test_shttp.py`**

`httpx.AsyncClient` + `ASGITransport(app=app)` 对 `GET` streaming 与 `POST` body 测试，无需起真实 uvicorn。

---

### Task 7: CLI 与入口

**Files:**
- Create: `saddler/acp_bridge/__main__.py`
- Modify: `pyproject.toml`（若尚未添加 `acp-bridge` 脚本）
- Modify: `README.md`（3–5 行说明）

- [ ] **Step 1: `__main__.py` 使用 `typer` 或 `argparse` 解析 `--host`、`--port`、`--max-sessions`、`--spawn`（重复参数拼 argv）**

```python
def main() -> None:
    import argparse
    import asyncio
    import uvicorn
    from saddler.acp_bridge.app import build_app
    from saddler.acp_bridge.config import BridgeConfig

    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--max-sessions", type=int, default=16)
    p.add_argument("--max-line-bytes", type=int, default=1048576)
    p.add_argument("--spawn", nargs="+", required=True)
    args = p.parse_args()
    cfg = BridgeConfig(
        host=args.host,
        port=args.port,
        spawn_argv=tuple(args.spawn),
        max_sessions=args.max_sessions,
        max_line_bytes=args.max_line_bytes,
    )
    uvicorn.run(build_app(cfg), host=cfg.host, port=cfg.port)
```

- [ ] **Step 2: 添加 `acp-bridge` 到 `pyproject.toml`**

- [ ] **Step 3: 手动冒烟**

Run:

```bash
uv run acp-bridge --spawn python -c "import sys; exec('for l in sys.stdin.buffer:\\n sys.stdout.buffer.write(l)')" &
curl -s -X POST http://127.0.0.1:8765/sessions
```

（路径以实现的 `POST` 为准。）

---

### Task 8: 全量测试与 spec 对照自检

- [ ] **Step 1: 运行全部 `tests/acp_bridge/`**

Run:

```bash
uv run pytest tests/acp_bridge/ -v
```

Expected: 全部 PASS。

- [ ] **Step 2: 对照 `docs/superpowers/specs/2026-04-12-acp-bridge-design.md` §9 验收标准逐条勾选**（手工或 checklist issue）。

---

## Self-review（计划作者自检）

| Spec 章节 | 对应任务 |
|-----------|----------|
| 单进程、双传输 | Task 5–6、`build_app` |
| 一连接一子进程 | `BridgeSession` + `SessionManager.acquire` |
| 换行 JSON-RPC | `line_io` |
| 超限拒绝 | `SessionManager.acquire` 失败路径；WS close 1013；HTTP 503（需在 Task 5–6 补 **显式** `Response(status_code=503)` 当 `acquire` 失败） |
|  stderr 日志 | Task 5 起在 `BridgeSession.start` 后 `asyncio.create_task(drain_stderr(connection_id))`——若 spec 要求 MVP：**在 Task 4 或 5 增加 `drain_stderr` 读 `stderr` 并 `logging.info`** |
| 有序终止 | `spawn.terminate_process`、`session.close` |

**Gap 修复：** 在 **Task 4** 增加 `asyncio` 任务读取 `stderr` 并打日志至 `logging`，避免管道塞满导致子进程阻塞。

**Placeholder 扫描：** 无 TBD；Streamable HTTP 官方正文缺失处已用 MVP 路由说明替代。

**类型一致性：** `BridgeConfig` 最终字段名为 `port` 单字段时，全计划与测试需同步（Task 6 合并端口时统一）。

---

## Execution handoff

Plan complete and saved to `docs/superpowers/plans/2026-04-12-acp-bridge.md`. Two execution options:

**1. Subagent-Driven (recommended)** — dispatch a fresh subagent per task, review between tasks, fast iteration.

**2. Inline Execution** — execute tasks in this session using executing-plans, batch execution with checkpoints.

Which approach?
