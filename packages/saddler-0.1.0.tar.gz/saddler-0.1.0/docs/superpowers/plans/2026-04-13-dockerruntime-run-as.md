# Docker Runtime `run_as` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add runtime-level non-root identity support via `run_as` for Docker, with explicit fail-fast behavior on unsupported runtimes.

**Architecture:** Introduce one runtime config field `run_as` (`<name|uid>[:<group|gid>]`) and keep it runtime-scoped in phase 1. Validate format early in CLI, validate backend support in manager/runtime creation, and enforce identity in Docker command execution paths by adding `docker exec -u`. Preserve backward compatibility by making `run_as` optional in persisted state.

**Tech Stack:** Python 3.12, Typer CLI, pytest, subprocess-based runtime adapters.

---

## File Structure Map

- `saddler/cli.py`: add `--run-as` option and lightweight parser/validator wiring.
- `saddler/manager.py`: pass `run_as` into runtime construction and fail fast for unsupported backend.
- `saddler/runtimes/base.py`: add capability/contract surface for run-as support.
- `saddler/runtimes/local.py`: explicitly mark run-as unsupported.
- `saddler/runtimes/docker.py`: store `run_as`, persist it, and apply `-u` consistently in exec/copy paths.
- `tests/cli/test_runtime_commands.py`: CLI behavior and validation tests.
- `tests/test_manager_unit.py`: manager-level support/unsupported behavior tests.
- `tests/runtimes/test_docker_runtime.py` (create if missing): docker `-u` behavior and compatibility tests.

### Task 1: Add CLI `--run-as` and format validation

**Files:**
- Modify: `saddler/cli.py`
- Test: `tests/cli/test_runtime_commands.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_runtime_create_docker_run_as(runner, mock_runtime_manager, runtime_record):
    mock_runtime_manager.create.return_value = runtime_record
    result = runner.invoke(
        app,
        ["runtime", "create", "--type", "docker", "--run-as", "1000:1000"],
    )
    assert result.exit_code == 0
    args, _kwargs = mock_runtime_manager.create.call_args
    assert args[0]["run_as"] == "1000:1000"


@pytest.mark.parametrize("bad_value", ["", ":", "a:b:c", ":1000"])
def test_runtime_create_invalid_run_as_reports_error(runner, bad_value):
    result = runner.invoke(app, ["runtime", "create", "--run-as", bad_value])
    assert result.exit_code != 0
    assert isinstance(result.exception, SaddlerError)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k run_as -v`  
Expected: FAIL because `--run-as` option and validation do not exist.

- [ ] **Step 3: Write minimal implementation**

```python
def _validate_run_as(value: str) -> str:
    raw = value.strip()
    if not raw:
        raise SaddlerError("Invalid --run-as: empty value")
    if raw.count(":") > 1:
        raise SaddlerError(f"Invalid --run-as format: {value}")
    user, _sep, _group = raw.partition(":")
    if not user:
        raise SaddlerError(f"Invalid --run-as format: {value}")
    return raw


def runtime_create(..., run_as: str | None = typer.Option(None, "--run-as", help="Runtime user identity: <name|uid>[:<group|gid>]")) -> None:
    runtime_cfg: dict = {"type": runtime_type}
    ...
    if run_as is not None:
        runtime_cfg["run_as"] = _validate_run_as(run_as)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/cli/test_runtime_commands.py -k run_as -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add saddler/cli.py tests/cli/test_runtime_commands.py
git commit -m "feat(cli): add runtime --run-as option with validation"
```

### Task 2: Add runtime capability checks in manager

**Files:**
- Modify: `saddler/manager.py`
- Modify: `saddler/runtimes/base.py`
- Modify: `saddler/runtimes/local.py`
- Modify: `saddler/runtimes/docker.py`
- Test: `tests/test_manager_unit.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_runtime_create_local_with_run_as_fails_fast():
    store = MagicMock()
    agent_store = MagicMock()
    manager = RuntimeManager(store=store, agent_store=agent_store)
    with pytest.raises(SaddlerError, match="does not support run_as"):
        manager.create({"type": "local", "run_as": "1000:1000"})


def test_runtime_create_docker_with_run_as_supported(monkeypatch):
    manager = RuntimeManager(store=MagicMock(), agent_store=MagicMock())
    fake_runtime = SimpleNamespace(setup=lambda: None, dump_state=lambda: {"run_as": "1000:1000"})
    monkeypatch.setattr(manager_mod, "build_runtime", lambda *_args, **_kwargs: fake_runtime)
    rec = manager.create({"type": "docker", "run_as": "1000:1000"})
    assert rec.runtime_spec["run_as"] == "1000:1000"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_manager_unit.py -k run_as -v`  
Expected: FAIL because manager/runtime capability check is missing.

- [ ] **Step 3: Write minimal implementation**

```python
class RuntimeAdapter(ABC):
    ...
    def supports_run_as(self) -> bool:
        return False


class LocalRuntime(RuntimeAdapter):
    def supports_run_as(self) -> bool:
        return False


class DockerRuntime(RuntimeAdapter):
    def supports_run_as(self) -> bool:
        return True


def build_runtime(config: dict, *, agent_id: str | None = None) -> RuntimeAdapter:
    ...
    if runtime_type == "docker":
        return DockerRuntime(..., run_as=runtime_cfg.get("run_as"))


class RuntimeManager:
    def create(...):
        runtime = build_runtime(...)
        if runtime_cfg.get("run_as") and not runtime.supports_run_as():
            raise SaddlerError(f"Runtime '{runtime_cfg.get('type', 'local')}' does not support run_as")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_manager_unit.py -k run_as -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add saddler/manager.py saddler/runtimes/base.py saddler/runtimes/local.py saddler/runtimes/docker.py tests/test_manager_unit.py
git commit -m "feat(runtime): enforce run_as capability checks by backend"
```

### Task 3: Persist and restore Docker `run_as`

**Files:**
- Modify: `saddler/runtimes/docker.py`
- Test: `tests/runtimes/test_docker_runtime.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_docker_runtime_dump_and_load_state_with_run_as():
    rt = DockerRuntime(image="python:3.12", run_as="1000:1000")
    state = rt.dump_state()
    assert state["run_as"] == "1000:1000"
    loaded = DockerRuntime.load_state(state)
    assert loaded.run_as == "1000:1000"


def test_docker_runtime_load_state_without_run_as_backward_compatible():
    loaded = DockerRuntime.load_state({"image": "python:3.12", "env": {}, "name": "n1", "container_id": "c1"})
    assert loaded.run_as is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k "dump_and_load_state_with_run_as or backward_compatible" -v`  
Expected: FAIL because state currently omits `run_as`.

- [ ] **Step 3: Write minimal implementation**

```python
class DockerRuntime(RuntimeAdapter):
    def __init__(..., run_as: str | None = None):
        ...
        self.run_as = run_as

    def dump_state(self) -> dict:
        return {..., "run_as": self.run_as}

    @classmethod
    def load_state(cls, state: dict) -> "DockerRuntime":
        return cls(..., run_as=state.get("run_as"))
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k "dump_and_load_state_with_run_as or backward_compatible" -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add saddler/runtimes/docker.py tests/runtimes/test_docker_runtime.py
git commit -m "feat(docker): persist optional runtime run_as state"
```

### Task 4: Apply `run_as` in Docker execution paths

**Files:**
- Modify: `saddler/runtimes/docker.py`
- Test: `tests/runtimes/test_docker_runtime.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_exec_includes_user_flag_when_run_as(monkeypatch):
    calls = []
    monkeypatch.setattr(subprocess, "run", lambda cmd, **kwargs: calls.append(cmd) or SimpleNamespace(returncode=0, stdout="", stderr=""))
    rt = DockerRuntime(container_id="cid", run_as="1000:1000")
    monkeypatch.setattr(rt, "_ensure_running", lambda: "cid")
    rt.exec(["id"], cwd="/")
    assert ["docker", "exec", "-u", "1000:1000"] == calls[-1][:4]


def test_exec_without_run_as_keeps_existing_behavior(monkeypatch):
    calls = []
    monkeypatch.setattr(subprocess, "run", lambda cmd, **kwargs: calls.append(cmd) or SimpleNamespace(returncode=0, stdout="", stderr=""))
    rt = DockerRuntime(container_id="cid", run_as=None)
    monkeypatch.setattr(rt, "_ensure_running", lambda: "cid")
    rt.exec(["id"], cwd="/")
    assert "-u" not in calls[-1]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k "user_flag_when_run_as or without_run_as" -v`  
Expected: FAIL because `exec` paths do not add `-u`.

- [ ] **Step 3: Write minimal implementation**

```python
def _user_args(self) -> list[str]:
    return ["-u", self.run_as] if self.run_as else []

def exec(...):
    ...
    user_args = self._user_args()
    subprocess.run(["docker", "exec", *user_args, *env_args, *cwd_args, ref, *command], ...)

def exec_fg(...):
    subprocess.run(["docker", "exec", "-it", *user_args, *env_args, *cwd_args, ref, *command], ...)

def exec_bg(...):
    subprocess.run(["docker", "exec", "-d", *user_args, *env_args, *cwd_args, ref, *command], ...)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k "user_flag_when_run_as or without_run_as" -v`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add saddler/runtimes/docker.py tests/runtimes/test_docker_runtime.py
git commit -m "feat(docker): apply run_as to docker exec variants"
```

### Task 5: Cover copy paths and full regression suite

**Files:**
- Modify: `saddler/runtimes/docker.py`
- Test: `tests/runtimes/test_docker_runtime.py`
- Test: `tests/cli/test_runtime_commands.py`
- Test: `tests/test_manager_unit.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_copy_to_pipeline_uses_run_as_for_docker_exec(monkeypatch):
    rt = DockerRuntime(container_id="cid", run_as="1000:1000")
    ...
    assert "docker exec -i -u 1000:1000" in pipeline_cmd


def test_copy_to_pipeline_without_run_as_has_no_user_flag(monkeypatch):
    rt = DockerRuntime(container_id="cid", run_as=None)
    ...
    assert "docker exec -i -u" not in pipeline_cmd
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/runtimes/test_docker_runtime.py -k copy_to -v`  
Expected: FAIL if copy pipeline does not align with unified `run_as` logic.

- [ ] **Step 3: Write minimal implementation**

```python
user_fragment = f"-u {shlex.quote(self.run_as)} " if self.run_as else ""
pipeline = (
    f"tar cfh - ... | "
    f"docker exec -i {user_fragment}{shlex.quote(ref)} sh -lc {shlex.quote(move_script)}"
)
```

- [ ] **Step 4: Run targeted and full tests**

Run:
- `uv run pytest tests/runtimes/test_docker_runtime.py -v`
- `uv run pytest tests/cli/test_runtime_commands.py tests/test_manager_unit.py -k run_as -v`
- `uv run pytest tests -q`

Expected:
- Targeted suites PASS.
- Full suite PASS (or only known unrelated failures).

- [ ] **Step 5: Commit**

```bash
git add saddler/runtimes/docker.py tests/runtimes/test_docker_runtime.py tests/cli/test_runtime_commands.py tests/test_manager_unit.py
git commit -m "test(runtime): cover run_as copy path and regression cases"
```

### Task 6: Documentation update

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Write the failing doc expectation test (manual checklist)**

```text
Checklist:
1) runtime create examples include --run-as
2) explain support matrix (docker supported, local unsupported)
3) note syntax <name|uid>[:<group|gid>]
```

- [ ] **Step 2: Verify docs currently miss required content**

Run: `rg "run-as|run_as|runtime create" README.md`  
Expected: missing or incomplete run-as guidance.

- [ ] **Step 3: Write minimal documentation changes**

```markdown
### Docker runtime user identity

Use `--run-as` to set default runtime execution identity:

```bash
saddler runtime create --type docker --run-as 1000:1000
```

Syntax: `<name|uid>[:<group|gid>]`

- `docker`: supported
- `local`: not supported (creation fails fast if `run_as` is provided)
```

- [ ] **Step 4: Validate docs update**

Run: `rg "run-as|<name\\|uid>\\[:<group\\|gid>\\]" README.md`  
Expected: both syntax and usage lines found.

- [ ] **Step 5: Commit**

```bash
git add README.md
git commit -m "docs(runtime): document docker run_as configuration"
```

## Plan Self-Review

- **Spec coverage:** Covered unified field, runtime-only scope, capability checks, docker execution behavior, compatibility, and testing strategy.
- **Placeholder scan:** No TODO/TBD placeholders; each step includes code or explicit commands.
- **Type consistency:** Uses `run_as` consistently in CLI/runtime spec/runtime state and test naming.
