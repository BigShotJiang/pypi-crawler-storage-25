# Saddler `--mount` 快速挂载设计（与 storage 语义并行）

日期：2026-04-14  
状态：已定稿（待进入 implementation plan）  
范围：在 `runtime create` / hitch runtime 中新增“直接目录透传”能力，不引入 `StorageRecord` 生命周期。

---

## 1. 背景与目标

现有 saddler storage 体系已经完成一等资源化：`--storage` 语义是“可追踪、可复用、可管理生命周期的数据资源”。  
但在实际使用中，存在高频轻量场景：用户只想把一个本地目录直接挂进容器，不需要复用、命名、引用计数和独立删除。

当前若必须先 `storage create` 再 `runtime create --storage`，对这类临时透传场景偏重。

本设计目标：

- 新增 `runtime create --mount <host>:<mount>`，与 `--storage` 并列；
- `--mount` 不创建 `StorageRecord`，不写入 `~/.saddler/storages/`；
- `runtime.json` 中以独立 `mounts` 数组持久化，和 `storages` 不混用；
- 仅 `DockerRuntime` 支持 `mounts`；`LocalRuntime` 下传入直接报错；
- 写入前将 host 路径规范化为绝对路径，且路径不存在时直接报错。

---

## 2. 核心语义边界

### 2.1 `--storage` 与 `--mount` 分工

- `--storage`：声明“被 saddler 管理的数据资源”，存在记录、可复用、可引用追踪。
- `--mount`：声明“仅当前 runtime 透传的主机目录绑定”，无独立资源记录、无引用追踪。

两者允许同时出现，但语义与持久化严格隔离。

### 2.2 分层原则（Saddler 层区分，Runtime 层不区分来源）

为避免 runtime adapter 承担业务语义：

- 在 saddler manager 层保留 `storages` 与 `mounts` 的显式区分；
- 在传递给 `DockerRuntime` 前，将两类挂载统一编译为 runtime 可执行的挂载指令集合；
- `DockerRuntime` 只消费“要挂载什么到哪里”，不感知来源是 storage 还是 mount。

这样既保留业务边界，又保持 runtime 执行层简洁。

---

## 3. 数据模型与持久化

### 3.1 RuntimeSpec 新增 mounts

`runtime_spec` 结构扩展为：

```json
{
  "runtime_spec": {
    "storages": [
      { "storage_id": "st-xxxx", "mount": "/models" }
    ],
    "mounts": [
      { "host_path": "/abs/path/to/local-data", "mount": "/workspace" }
    ]
  }
}
```

约束：

- `mounts[*].host_path` 必须为绝对路径（写入前规范化）；
- `mounts[*].mount` 必须为容器内绝对路径；
- 同一 runtime 内所有挂载目标路径唯一（`storages.mount` 与 `mounts.mount` 联合去重）。

### 3.2 非目标

- 不新增 `StorageRecord.kind=mount`；
- 不在 storage store 记录 mounts；
- 不扩展 storage 引用计数/绑定语义到 mounts。

---

## 4. CLI 设计

### 4.1 `runtime create` 新增参数

```bash
saddler runtime create --type docker --docker-image my-image \
  --storage model-cache:/models \
  --mount ./local-data:/workspace
```

新增可重复参数：

- `--mount <host>:<mount>`

### 4.2 解析与校验规则

1. `--mount` 格式必须为 `<host>:<mount>`；
2. `host` 与 `mount` 均不能为空；
3. `mount` 必须为绝对路径；
4. `host` 按当前工作目录解析为绝对路径后校验存在性；
5. host 路径不存在时直接报错并拒绝创建；
6. 若 `--type local` 且传入 `--mount`，直接报错（无副作用）；
7. `--storage` 与 `--mount` 的 mount 目标路径出现冲突时直接报错。

错误文案沿用现有风格（`Invalid --xxx format` / `requires --type docker` 等）。

---

## 5. Hitch YAML 设计

### 5.1 Schema 扩展

在 `runtimes.<id>` 下新增并行字段：

```yaml
runtimes:
  rt-main:
    type: docker
    image: my-image
    storages:
      - storage: model-cache
        mount: /models
    mounts:
      - host: ./local-data
        mount: /workspace
```

### 5.2 路径解析

- `mounts[*].host` 若为相对路径，以 compose 文件父目录为基准解析；
- 解析后规范化为绝对路径；
- 路径不存在直接报错，`hitch up` 不进入资源创建阶段。

### 5.3 执行语义

- `hitch up`：创建 runtime 时将 mounts 写入 runtime spec 并传递到 docker 执行层；
- `hitch down`：不对 mounts 对应的 host 目录做任何删除/清理动作；
- mounts 语义与 `local storage rm 不删目录内容` 一致：saddler 不拥有目录内容生命周期。

---

## 6. RuntimeManager 与 RuntimeAdapter 行为

### 6.1 RuntimeManager

- 接收并持久化 `runtime_spec.mounts`；
- storage 绑定/解绑逻辑仅处理 `runtime_spec.storages`；
- `runtime rm` 只负责：
  - storage 解绑（仅 storages）；
  - runtime/container 删除；
  - 不触碰 mounts 的 host 目录。

### 6.2 DockerRuntime

- setup 时消费“统一挂载指令集合”（由 manager 生成）并转换为 `docker create -v ...` 参数；
- 不区分“该挂载来源于 storage 还是 mount”；
- 仅负责执行，不承担 storage 生命周期语义。

### 6.3 LocalRuntime

- 不支持 mounts；
- 由 CLI/manager 提前拦截，必要时 runtime 层保留防御性校验。

---

## 7. 冲突处理、幂等与失败语义

1. **挂载目标冲突**  
   `storages.mount` 与 `mounts.mount` 联合去重；重复即报错。

2. **前置校验失败无副作用**  
   包括 mount 格式错误、路径不存在、runtime 类型不支持、挂载目标冲突等，均在创建前失败，不写 runtime record。

3. **生命周期隔离**  
   mounts 不进入 storage 引用关系，不影响 `bound_runtime_ids`。

4. **删除幂等**  
   `runtime rm` / `hitch down` 重复执行时，对 mounts 的处理天然为 no-op（无目录清理步骤）。

---

## 8. 测试与验收标准

### 8.1 CLI / Manager 测试

- `runtime create --type docker --mount ./x:/w`：
  - host 存在 -> 创建成功，`runtime_spec.mounts` 为绝对路径；
  - host 不存在 -> 报错，且无 runtime record 落地。
- `--type local --mount ...` -> 报错（组合不合法）。
- `--storage a:/w --mount b:/w` -> 报错（mount 目标冲突）。
- storage 绑定相关测试保持通过，且不受 mounts 影响。

### 8.2 Hitch 测试

- `mounts.host` 相对路径按 compose parent 正确解析；
- 路径不存在时 `hitch up` 直接失败且不产生部分 runtime 记录；
- `hitch down` 不删除 host 目录内容。

### 8.3 DockerRuntime 测试

- 接收到统一挂载指令后，生成期望 `-v` 参数并创建容器；
- runtime adapter 不依赖 storage/mount 来源字段。

### 8.4 DoD（Definition of Done）

- CLI 与 hitch 均支持并行 `storages` / `mounts`；
- mounts 不生成任何 `StorageRecord`；
- `runtime.json` 结构包含独立 `mounts` 数组；
- `LocalRuntime` + mounts 明确拒绝；
- host 路径规范化与存在性校验在写入前完成；
- 删除流程对 mounts 不做任何目录清理。

---

## 9. 影响范围（实现阶段参考）

- `saddler/cli.py`：新增 `--mount` 解析与校验
- `saddler/hitch/schema.py`：runtime `mounts` 字段模型
- `saddler/hitch/executor.py`：hitch runtime cfg 组装与路径解析
- `saddler/manager.py`：runtime spec 规范化、冲突校验、传递统一挂载指令
- `saddler/runtimes/docker.py`：消费统一挂载指令（执行层不区分来源）
- tests:
  - `tests/cli/test_runtime_commands.py`
  - `tests/hitch/test_schema.py`
  - `tests/hitch/test_executor.py`
  - `tests/runtimes/test_docker_runtime.py`

