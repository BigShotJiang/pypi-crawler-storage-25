# CLI 单元测试设计（第一批必要覆盖）

## 背景与目标

当前仓库已实现 `agent` 与 `runtime` 生命周期命令，并提供顶层别名命令；但自动化测试覆盖不足。本文档定义第一批“必要且尽量全面”的 CLI 纯单元测试设计，目标是在不依赖 Docker 与外部环境的前提下，快速建立稳定回归保护网。

本批设计聚焦：

- `saddler` 顶层命令（别名）
- `saddler agent` 子命令组
- `saddler runtime` 子命令组
- 参数校验、错误路径与输出契约

## 范围

### In Scope

- 命令参数解析与默认值行为
- CLI 到 `AgentManager` / `RuntimeManager` 的调用契约
- 成功路径与关键失败路径（参数冲突、格式错误、缺参与非法值）
- 顶层别名命令与 `agent` 子命令一致性
- `main()` 对 `SaddlerError` 的错误处理（错误文案与返回码）

### Out of Scope

- Runtime 真正执行行为（例如容器启动、进程管理）
- 存储层持久化正确性（单独测试主题）
- 跨进程/跨运行时的端到端行为

## 测试策略

采用 `pytest + typer.testing.CliRunner` 驱动 CLI，配合 monkeypatch/mocking 替换 `saddler.cli` 中 `_manager()` 与 `_runtime_manager()` 返回值，断言：

1. 命令退出码
2. 标准输出/错误输出关键文本
3. 管理器方法调用次数与参数

该策略保证：

- 快速（毫秒级执行）
- 稳定（不依赖 Docker）
- 定位清晰（失败直接指向 CLI 参数映射或错误处理）

## 测试结构

建议目录：

- `tests/cli/conftest.py`
- `tests/cli/test_agent_commands.py`
- `tests/cli/test_runtime_commands.py`
- `tests/cli/test_top_level_aliases.py`
- `tests/cli/test_main_error_handling.py`

### 共享 fixture 设计

- `runner`: 返回 `CliRunner()`
- `mock_agent_manager`: 提供可观测调用的 `MagicMock`，并 patch 到 `_manager`
- `mock_runtime_manager`: 提供可观测调用的 `MagicMock`，并 patch 到 `_runtime_manager`

## 用例清单（第一批必要覆盖）

### A. Agent 命令组

#### A1. create

- 成功：最小参数创建成功，`_manager().create()` 被调用，输出包含 `Created agent`
- 失败：`--runtime` 与 `--runtime-from-agent` 同时传入时报错（互斥）
- 成功：`--skill` 多次传入可被转换为 list 并透传
- 成功：`--name` / `--role` 透传进 `AgentCreateConfig`

#### A2. run

- 成功：最小参数调用 `_manager().run(cfg, acp=False)`
- 成功：带 `--acp` 时调用 `_manager().run(cfg, acp=True)`
- 失败：`--runtime` 与 `--runtime-from-agent` 同时传入时报错（互斥）

#### A3. tui / acp

- 成功：`agent tui <id>` 调用 `_manager().tui(name_or_id)` 并打印结束提示
- 成功：`agent acp <id>` 调用 `_manager().acp(name_or_id)` 并打印结束提示

#### A4. rm / ps

- 成功：`agent rm <id>` 调用 `_manager().rm(id, force=False)`
- 成功：`agent rm <id> --force` 调用 `_manager().rm(id, force=True)`
- 成功：`agent ps` 空列表时输出 `No agents found.`
- 成功：`agent ps` 非空时输出表头与至少一条记录字段

### B. Runtime 命令组

#### B1. create

- 成功：默认 `--type local` 透传到 `_runtime_manager().create(...)`
- 成功：`--type docker --docker-image ...` 时 `image` 字段被写入
- 成功：`--env KEY=VALUE` 可解析为 `env` 字典
- 失败：`--env` 无 `=` 报错
- 失败：`--env =VALUE`（空 key）报错
- 成功：重复 `--storage` 透传到 `storages` 列表

#### B2. start / stop / rm / ps

- 成功：`start/stop` 调用目标方法并输出成功提示
- 成功：`rm` 的 `--force` 默认值与显式值行为正确
- 成功：`runtime ps` 空列表输出 `No runtimes found.`
- 成功：`runtime ps` 非空时输出表头与记录字段

#### B3. install-harness

- 成功：`runtime install-harness <id> --harness ... --workdir ...` 调用参数顺序正确并输出完成提示

### C. 顶层别名一致性

- `saddler create` 与 `saddler agent create` 对 `create` 入口行为一致
- `saddler run` 与 `saddler agent run` 行为一致
- `saddler rm` 与 `saddler agent rm` 行为一致
- `saddler ps` 与 `saddler agent ps` 行为一致
- `saddler tui` / `saddler acp` 与对应 `agent` 子命令行为一致

注：一致性断言以“调用参数契约一致”为主，不重复深测已在 A 组覆盖的分支。

### D. main() 错误处理

- 当 app 命令抛出 `SaddlerError` 时，`main()` 返回 `1` 且 stderr 包含 `Error: ...`
- 无异常时 `main()` 返回 `0`

## 覆盖深度与优先级

优先级从高到低：

1. 参数互斥/格式错误（防止线上误用）
2. 调用契约正确性（防止重构回归）
3. 别名一致性（防止入口行为漂移）
4. 输出文本断言（以关键片段为主，降低脆弱性）

## 测试数据与 Mock 约定

- 记录对象可使用 `types.SimpleNamespace` 或轻量 dataclass 模拟：
  - agent 记录至少含：`agent_id`, `name`, `status`, `foreground_sessions`, `harness`, `workdir`
  - runtime 记录至少含：`runtime_id`, `name`, `status`, `runtime_type`, `ref_count`
- 对 `AgentCreateConfig` 的断言可通过检查 mock 入参对象字段完成，不依赖对象完全相等

## 风险与约束

- 当前 CLI 部分逻辑依赖 `_runtime_manager()._load_or_raise(...)` 与 store 查询，若在测试中触发此路径需要补充更细粒度 patch
- Typer/Click 错误文本在版本升级后可能有细微差异；断言应使用关键字匹配而非整段全文匹配

## 验收标准

满足以下条件即可视为第一批完成：

- CLI 三组入口（top-level/agent/runtime）均有测试文件与有效用例
- 每个核心命令至少 1 个成功用例
- 每组至少覆盖 1~2 个失败路径
- 互斥参数与 `--env` 格式校验被覆盖
- `main()` 错误处理被覆盖

## 后续扩展（第二批）

- 将参数矩阵系统化（parametrize）覆盖更多组合
- 增加轻量集成测试（不依赖 Docker）验证 manager 与 store 交互
- 为关键输出引入 snapshot 风格断言（仅对稳定表格格式）
