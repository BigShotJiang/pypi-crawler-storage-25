# Saddler Runtime 一等公民设计

日期：2026-04-09  
状态：已评审（待进入实现计划）  
范围：saddler 第一阶段架构增强（runtime 复用）

---

## 1. 背景与目标

当前 saddler 以 agent 为中心管理生命周期。runtime 虽然存在抽象层（`RuntimeAdapter`），但还不是独立资源，导致：

- runtime 无法作为独立对象被显式复用与管理
- 多 agent 复用 runtime 的语义不完整
- 后续 hitch 场景难以复用同一运行环境池

本设计目标是将 runtime 提升为一等公民，使其可在多个 agent 之间复用，并保持清晰的生命周期边界。

### 1.1 本次确认的约束

- 复用目标：复用 runtime instance（非仅模板）
- workdir 模型：共享 runtime、隔离 workdir
- 停止语义：`agent stop` 仅影响该 agent 会话
- 并发语义：允许并发，由 runtime/harness 承载
- 入口模型：显式 runtime 入口 + 隐式复用入口同时支持
- 向后兼容：`saddler create/start/stop/rm/ps` 默认等价于 `saddler agent <subcommand>`

---

## 2. 方案选择

采用“双入口同模型”方案：

- 显式入口：`saddler runtime ...`
- 隐式入口：`saddler create/run --reuse-runtime ...`
- 底层统一：同一套 `RuntimeRecord` / `RuntimeManager` / `RuntimeStore`

该方案兼顾易用性与架构清晰度，避免双轨实现和后续重构成本。

---

## 3. 架构与对象模型

引入双资源模型：

- `RuntimeRecord`：可复用 runtime 资源
- `AgentRecord`：agent 会话资源，绑定 `runtime_id`

### 3.1 RuntimeRecord（新）

建议字段：

- `runtime_id`: string
- `name`: string | null（唯一）
- `runtime_type`: `"local" | "docker"`
- `runtime_spec`: object
  - `workdir`: string | null（默认 cwd）
  - `env`: dict[str, str]
  - `storages`: list[storage-spec]
  - `image`: string | null（docker）
- `runtime_state`: object（adapter serialize 结果）
- `status`: `"created" | "running" | "stopped"`
- `ref_count`: int
- `created_at`: timestamp

### 3.2 AgentRecord（扩展）

新增字段：

- `runtime_id`: string（必填）

兼容策略：

- `runtime_state` 保留为兼容字段（deprecated，迁移期只读）

### 3.3 管理器职责

- `RuntimeManager`
  - `create/start/stop/rm/ps`
  - 负责 runtime 真实生命周期、状态持久化、引用计数一致性
- `AgentManager`
  - `create/run/start/stop/rm/ps`
  - 负责 rigging、harness 安装、agent 会话生命周期
  - 通过 `runtime_id` 与 RuntimeManager 协作，不直接拥有 runtime 主状态

---

## 4. CLI 设计

### 4.1 命令分组

- `saddler agent create|run|start|stop|rm|ps`
- `saddler runtime create|start|stop|rm|ps`

兼容别名：

- `saddler create/start/stop/rm/ps` 默认等价于 `saddler agent ...`

### 4.2 Runtime 命令参数（建议）

`saddler runtime create`：

- `--name <name>`
- `--runtime <type>`（local/docker）
- `--docker-image <image>`
- `--storage <spec>`（可多次）
- `--env KEY=VALUE`（可多次）
- `--workdir <path>`（可选）

### 4.3 Agent 复用参数（建议）

为 `agent create/run` 增加：

- `--runtime-id <id-or-name>`
- `--reuse-runtime <agent-or-runtime>`

约束：

- `--runtime-id` 与 `--reuse-runtime` 互斥
- 若均未传入，默认隐式创建专属 runtime（兼容旧行为）

---

## 5. 状态机与行为语义

### 5.1 状态模型

- Runtime：`created -> running -> stopped`
- Agent：`created -> running -> stopped`

### 5.2 关键语义

- `agent start/run`：
  - 若绑定 runtime 不可用，可自动 `runtime start` 后再启动 agent
- `agent stop`：
  - 仅停止该 agent 会话，不影响 runtime 与其他 agent
- `runtime stop`：
  - 停止 runtime，并将绑定 agent 状态统一修正为 `stopped`
- `runtime rm`：
  - 默认要求 `ref_count == 0`，`--force` 才允许强制删除

---

## 6. 执行流与错误处理

### 6.1 agent create

执行顺序：

1. 解析 runtime 绑定来源（`--runtime-id` > `--reuse-runtime` > 隐式创建）
2. 校验 workdir 唯一性（维持现约束）
3. 执行 rigging（role/prototype/skills）
4. 通过 HarnessAdapter 安装 rules/skills
5. 写入 `agent.json`（`status=created`，含 `runtime_id`）
6. 更新 runtime `ref_count += 1`

失败回滚：

- rigging/安装失败：回滚 agent 目录；若 runtime 为本次隐式新建且无引用则清理
- 持久化失败：回滚 agent 写入与 `ref_count`

### 6.2 agent run/start

- `run = create + start`
- 启动前检查并确保 runtime 可用
- harness 启动失败时：
  - agent 标记为 `stopped`
  - runtime 保持当前状态（通常为 running），可被其他 agent 继续使用

### 6.3 agent stop

- 只终止当前 agent 会话
- 状态改为 `stopped`
- 若会话已不存在，建议幂等成功

### 6.4 agent rm

- 默认要求 agent 非 running
- 删除后 `ref_count -= 1`
- `ref_count == 0` 时 runtime 默认保留（runtime 一等资源）

### 6.5 runtime stop/rm

- `runtime stop`：runtime 级停止并同步关联 agent 状态
- `runtime rm`：默认无引用可删；`--force` 可强删

---

## 7. 持久化与迁移策略

### 7.1 存储布局

- `~/.saddler/agents/<agent-id>/agent.json`
- `~/.saddler/runtimes/<runtime-id>/runtime.json`

保留：

- `~/.saddler/agents/<agent-id>/skills/`

### 7.2 迁移方式

采用懒迁移，不提供一次性迁移脚本：

- 读取旧 `agent.json`（无 `runtime_id`）时，按旧字段推导或创建 RuntimeRecord
- 回写 `runtime_id` 到 agent 记录
- 运行时修正 `ref_count`

### 7.3 一致性修复

- `ref_count` 可通过全量扫描 agent 反算修复
- `runtime rm --force` 后需要同步受影响 agent 状态（至少置 `stopped`）

---

## 8. 测试与验收标准

### 8.1 单元测试

- RuntimeStore/RuntimeManager 的 CRUD、状态流转、引用计数
- Agent 与 runtime 绑定解析优先级与互斥参数校验
- 懒迁移路径（旧 agent 记录读取后补齐 `runtime_id`）
- 错误回滚（rigging 失败、持久化失败）

### 8.2 集成测试

- 创建 runtime，创建多个 agent 绑定同一 runtime，验证并发执行
- `agent stop` 不影响同 runtime 的其他 agent
- `runtime stop` 能正确影响所有绑定 agent
- `runtime rm` 在有引用时拒绝，`--force` 行为符合预期
- 顶层别名命令与 `saddler agent ...` 语义一致

### 8.3 验收标准（DoD）

- runtime 可被显式创建并被多个 agent 复用
- `agent stop` 与 `runtime stop` 语义严格区分
- `saddler create/start/stop/rm/ps` 与 `saddler agent ...` 一致
- 无一次性迁移脚本，懒迁移可稳定完成历史记录升级
- 文档与 help 文案完整说明双资源模型和兼容入口

---

## 9. 非目标（本次不做）

- query-time 实时存活探测（当前以持久化状态为准）
- 更细粒度并发配额/调度策略
- hitch 级联编排语义细化（在二阶段展开）

---

## 10. 后续步骤

本设计确认后，下一步进入实现计划阶段（writing-plans），产出可执行任务拆分、文件级改动清单与验证步骤。
