# Inspect Subcommands Alignment Design

## Background

Current CLI coverage is inconsistent for resource inspection:

- `storage inspect <id|name>` already exists and outputs full record details in YAML.
- `runtime` and `agent` currently do not provide `inspect` subcommands.

The goal of this change is to ensure `storage/runtime/agent` all expose an `inspect` subcommand with consistent behavior and output style.

## Scope

In scope:

- Add `runtime inspect <id|name>`.
- Add `agent inspect <id|name>`.
- Keep `storage inspect` behavior unchanged.
- Unify output format across all three inspect commands.

Out of scope:

- Adding new output formats such as JSON.
- Adding `--brief`/`--fields` filtering.
- Refactoring into a generic inspect rendering framework.

## Design Decision

### Recommended Approach (A): Minimal Consistency Completion

Implement inspect support in the same pattern already used by storage:

1. Add public inspect methods in managers:
   - `RuntimeManager.inspect(runtime_id_or_name) -> RuntimeRecord`
   - `AgentManager.inspect(name_or_id) -> AgentRecord`
2. Add CLI subcommands:
   - `runtime inspect`
   - `agent inspect`
3. Render output as:
   - `yaml.safe_dump(record.to_dict(), sort_keys=False, allow_unicode=True).strip()`

Reasoning:

- Lowest implementation and regression risk.
- Reuses existing identifier resolution and error semantics (`_load_or_raise`).
- Produces a uniform user experience for all first-class resources.

## Considered Alternatives

### B) CLI-only implementation via private `_load_or_raise`

Pros:

- Slightly fewer lines changed.

Cons:

- Depends on private manager internals from CLI.
- Weakens boundary clarity and maintainability.

Decision: reject.

### C) Build a generalized inspect rendering abstraction

Pros:

- Potentially cleaner long-term architecture.

Cons:

- Over-engineering for the current objective.
- Introduces unnecessary refactor risk during rapid iteration.

Decision: reject for now.

## Command Behavior

### New commands

- `saddler runtime inspect <name|id>`
- `saddler agent inspect <name|id>`

### Identifier resolution

Both commands reuse existing manager resolution behavior:

- exact id match
- exact name match
- unique prefix fallback
- ambiguous prefix error
- not found error

### Output

All inspect commands (`storage/runtime/agent`) output YAML from `record.to_dict()` with:

- `sort_keys=False`
- `allow_unicode=True`
- `.strip()` before `typer.echo`

### Error handling

No special-case error branching is introduced.
All errors continue to flow through existing `SaddlerError` handling and CLI main error wrapper (`Error: ...`).

## Architecture and Data Flow

1. CLI receives `<name|id>`.
2. CLI calls manager `inspect(...)`.
3. Manager delegates to existing resolver (`_load_or_raise`).
4. Resolved record is serialized with `to_dict()`.
5. CLI prints YAML to stdout.

This keeps business logic in manager layer and keeps CLI layer thin and consistent.

## Testing Strategy

Add/extend CLI tests with minimal required coverage:

1. Runtime inspect happy path:
   - create runtime
   - inspect runtime
   - assert output includes key fields (`runtime_id`, `runtime_type`)
2. Agent inspect happy path:
   - create agent
   - inspect agent
   - assert output includes key fields (`agent_id`, `harness`, `runtime_id`)
3. Error path sanity:
   - inspect non-existent id/name returns error with existing format

Testing notes:

- Prefer asserting critical fields rather than full YAML text equality to avoid brittle formatting coupling.

## Risks and Mitigations

- Risk: output details are verbose for some users.
  - Mitigation: keep full output now; consider optional `--brief` later only if real demand appears.
- Risk: command-level regressions.
  - Mitigation: focused CLI tests for new inspect commands and negative case.

## Acceptance Criteria

- `storage inspect` remains unchanged.
- `runtime inspect` exists and returns YAML record details.
- `agent inspect` exists and returns YAML record details.
- Not-found and ambiguous inputs preserve existing error style/semantics.
- CLI behavior is consistent across all three resource families.

## Implementation Notes

Target files:

- `saddler/manager.py`
- `saddler/cli.py`
- related CLI tests under `tests/`

No migration or backward-compatibility work is required for this iteration.
