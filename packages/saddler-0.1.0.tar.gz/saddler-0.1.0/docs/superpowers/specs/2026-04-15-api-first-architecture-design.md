# API-First Architecture Design (Phase 1)

## Background

Current `saddler` command flows are mostly CLI-centric:

- `cli.py` parses arguments and directly invokes manager-layer behavior.
- `hitch` orchestration currently runs in-process and is not API-driven.
- Cross-resource flows (especially agent + runtime) are embedded in existing manager methods.

The target direction is API-first: core capabilities should be exposed through a stable in-process Python API so CLI can become a thin adapter. This document defines the Phase 1 scope and boundaries.

## Confirmed Scope

### In scope (Phase 1)

API facade coverage for resource/state operations:

- Agent: `create`, `rm`, `ps`, `inspect`
- Runtime: `create`, `start`, `stop`, `rm`, `ps`, `inspect`, `install-harness`
- Storage: `create`, `ls`, `inspect`, `rm`

### Out of scope (Phase 1)

- `agent run` API service method (foreground session semantics stay in CLI path)
- `agent tui` and `agent acp` API service methods
- Hitch service-ization (`HitchService`) and hitch command migration
- HTTP server/API exposure

## Design Decision

### Recommended approach: Resource facades with constrained cross-resource orchestration

Introduce a new `saddler.api` facade layer:

- `AgentService`
- `RuntimeService`
- `StorageService`

Keep `manager.py` as internal low-level implementation in this phase, but remove direct CLI dependency on manager entrypoints for in-scope commands.

## Facade Granularity and Dependency Rules

### Facade granularity

Use resource-based services (not a separate coordinator layer in Phase 1).

### Allowed service dependency direction

- Allowed: `AgentService -> RuntimeService` (for create-time runtime resolution/reuse/creation)
- Allowed when needed: `AgentService -> StorageService` (currently not primary)
- Forbidden: reverse dependency (`RuntimeService -> AgentService`)
- Forbidden: circular dependencies among services

### Layer constraints

- Cross-resource orchestration belongs to **service methods with use-case semantics**.
- Manager layer is limited to single-resource state operations and must not implement service-to-service orchestration semantics in new code paths.
- Avoid facade methods that are purely mechanical 1:1 pass-through aliases without contract value.

## API Contracts

### Data model style

- Use `dataclass` request/response DTOs in `saddler.api`.
- Do not introduce `Result[T, E]` wrappers in Phase 1.
- Use exception-based error flow for domain failures.

### DTO minimum shape (Phase 1)

Request DTOs can evolve, but less obvious operations must define explicit minimum fields.

- `RuntimeInstallHarnessRequest` minimum fields:
  - `runtime_ref: str` (runtime id or name)
  - `harness_name: str`
  - `version: str | None = None` (optional, adapter-dependent)

### Error model

Define API-layer exception taxonomy (can wrap existing `SaddlerError` semantics):

- `ApiError` (base)
- `ValidationError`
- `NotFoundError`
- `ConflictError`
- `AmbiguousIdentifierError`
- `RuntimeStateError`

Mapping strategy:

- CLI adapter maps API exceptions to stable CLI-facing messages (`Error: ...` style; small consistency improvements allowed).
- Future HTTP layer can map same exceptions to status codes and structured error bodies.

## Component Boundaries

### CLI layer responsibilities

- Option/argument parsing
- Service invocation
- Output rendering (table/YAML)
- Exception-to-text adaptation

### Service layer responsibilities

- Use-case semantics and cross-resource orchestration
- Stable in-process API contract for library consumers
- DTO/exception contract boundary

### View DTO principle

`AgentView` / `RuntimeView` / `StorageView` follow a record-faithful rule in Phase 1:

- Keep full, stable projections of corresponding record state (not UI-tailored partial projections).
- Allow naming/type normalization for API consistency.
- Keep CLI rendering concerns in CLI layer; do not trim DTO fields for table/YAML formatting.

### Manager layer responsibilities

- State store operations
- Locking and mutation atomicity
- Low-level resource-specific checks

## Directory Layout (Proposed)

```text
saddler/
  api/
    __init__.py
    dto.py
    errors.py
    wiring.py
    agent_service.py
    runtime_service.py
    storage_service.py
```

Notes:

- `hitch` remains outside this facade set in Phase 1.
- Existing managers remain in place and are reused behind services.

## Service Surface (Phase 1)

### AgentService

- `create(req: AgentCreateRequest) -> AgentView`
- `remove(name_or_id: str, *, force: bool = False) -> AgentView`
- `list() -> list[AgentView]`
- `inspect(name_or_id: str) -> AgentView`

Not exposed in Phase 1:

- `run`, `tui`, `acp`

### RuntimeService

- `create(req: RuntimeCreateRequest) -> RuntimeView`
- `start(name_or_id: str) -> RuntimeView`
- `stop(name_or_id: str) -> RuntimeView`
- `remove(name_or_id: str, *, force: bool = False) -> RuntimeView`
- `list() -> list[RuntimeView]`
- `inspect(name_or_id: str) -> RuntimeView`
- `install_harness(req: RuntimeInstallHarnessRequest) -> RuntimeView`

Semantic note:

- `install_harness` installs harness CLI/tooling in the runtime environment itself.
- It is different from `HarnessAdapter.install_rules/install_skills`, which are agent-scoped materialization steps in agent workdir context.

### StorageService

- `create(req: StorageCreateRequest) -> StorageView`
- `list() -> list[StorageView]`
- `inspect(name_or_id: str) -> StorageView`
- `remove(name_or_id: str, *, force: bool = False) -> StorageView`

## `agent run` Path in Phase 1

`agent run` is intentionally kept outside service API due to foreground session semantics.

CLI flow is split into two conceptual stages:

1. Call API-backed create path (`AgentService.create`) for resource provisioning.
2. Continue foreground launch in CLI-side command flow (`tui`/`acp` behavior path), preserving user-facing interaction semantics.

This keeps resource operations API-first while avoiding premature abstraction of interactive foreground sessions.

## `AgentService.create` Orchestration Contract

`AgentService.create` is the main cross-resource use case in Phase 1. Expected internal sequence:

1. Validate request DTO and normalize workdir/runtime-relevant inputs.
2. Resolve or create runtime (`runtime` / `runtime_from_agent` / default runtime semantics).
3. Prepare rigging material (role/skills payload resolution).
4. Ensure harness installation prerequisites in selected runtime.
5. Apply agent-scoped materialization (`install_rules` / `install_skills`) when requested.
6. Persist agent record.
7. Increment runtime `ref_count` atomically for the created binding.
8. Return `AgentView`.

Boundary rule:

- Orchestration stays in `AgentService`; managers provide single-resource mutation and locking primitives.

## Hitch Position in Phase 1

- Hitch stays on current orchestration path.
- No `HitchService` is introduced in this phase.
- Hitch API-ization is a candidate for a separate Phase 2 spec.

## Migration Strategy

1. Introduce `saddler.api` package with DTOs/errors/services/wiring.
2. Migrate in-scope CLI commands to service calls.
3. Keep output formats and command UX stable; apply only small consistency improvements.
4. Add service-focused tests and CLI regression checks.
5. Keep hitch and foreground session commands unchanged in Phase 1.
6. Keep hitch on manager path in Phase 1 (no hitch usage of `AgentService.create`) to avoid dual create paths; migrate hitch in Phase 2.

## Testing Strategy

### Service tests

- Request validation behavior
- Identifier resolution behavior (id, name, prefix, ambiguity)
- Cross-resource orchestration in `AgentService.create` (runtime resolve/create + ref semantics)
- Exception taxonomy correctness

### CLI regression tests

- Existing table/YAML output shape for migrated commands remains compatible
- Error style remains `Error: ...` with expected message text patterns
- `agent run` still behaves as foreground command while reusing API-backed create semantics

### Non-goals for this phase

- Hitch end-to-end API test conversion
- HTTP contract tests

## Risks and Mitigations

- Risk: facade degenerates into pass-through wrappers.
  - Mitigation: enforce service boundary rules and require use-case semantics for cross-resource flows.
- Risk: mixed old/new paths cause temporary inconsistency.
  - Mitigation: command-by-command migration with regression assertions on output/errors.
- Risk: unclear public stability expectations.
  - Mitigation: publish API as v0-level contract (usable by library consumers, still iterative).

## Acceptance Criteria

- In-scope CLI commands no longer directly depend on manager entrypoints.
- `saddler.api` exports `AgentService`, `RuntimeService`, `StorageService` for in-process use.
- `agent run`/`tui`/`acp` remain non-service foreground flows.
- Hitch commands remain on existing orchestration path.
- CLI behavior remains stable with only small approved consistency improvements.

## Explicitly Deferred

- Hitch service facade and migration
- Foreground session API abstraction
- HTTP transport/API server
