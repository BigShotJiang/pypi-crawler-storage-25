# Saddler Storage 一等资源化设计（去匿名内联）

日期：2026-04-14  
状态：已定稿（待进入 implementation plan）  
范围：将 storage 从 runtime 内联声明升级为独立持久化资源；移除匿名 storage（含匿名 docker volume）。

---

## 1. 背景与目标

当前 runtime 的 `--storage kind=...,mount=...` 内联模型存在三个问题：

- 复用能力弱：无法稳定复用同一 storage 到多个 runtime。
- 观测能力弱：仅有计数时难以定位“谁在引用”。
- 生命周期不清：匿名资源与持久化资源混用，语义边界模糊。

本设计目标：

- 引入一等 `StorageRecord` 持久化资源。
- runtime 仅保存“storage 绑定关系 + mount”。
- 完全移除匿名 storage 功能（包括匿名 docker volume）。
- 保持与现有 manager/store 锁模型一致，确保并发下可重试与幂等。

---

## 2. 关键决策

1. **无匿名 storage**  
   不再支持任何匿名内联 storage 语法；所有 storage 必须先创建为显式记录。

2. **`runtime create --storage` 保留，但仅做引用绑定**  
   参数格式固定为 `<storage-id|name>:<mount-point>`，不再接受 `kind=...` 内联声明。

3. **hitch 仅允许引用顶层 `storages`**  
   `runtimes.<id>.storages` 只能引用 `storages.<sid>`，禁止 runtime 内联 storage 定义。

4. **`bound_runtime_ids` 取代 `ref_count`**  
   `StorageRecord` 不再持久化独立 `ref_count`，引用事实源为 `bound_runtime_ids`。
   需要展示计数时由 `len(bound_runtime_ids)` 派生。

---

## 3. 数据模型设计

### 3.1 StorageRecord

持久化路径：

`~/.saddler/storages/<storage_id>/storage.json`

示例：

```json
{
  "storage_id": "st-xxxx",
  "name": "model-cache",
  "kind": "docker-volume",
  "volume_name": "saddler-model-cache",
  "bound_runtime_ids": ["rt-aaaa", "rt-bbbb"],
  "metadata": {
    "team": "ml"
  },
  "created_at": "2026-04-14T10:00:00Z"
}
```

字段约束：

- `kind`：`local` | `docker-volume`
- `path`：仅 `local` 使用；create 时规范化为主机绝对路径并持久化
- `volume_name`：仅 `docker-volume` 使用（可选，缺省自动命名）
- `bound_runtime_ids`：引用该 storage 的 runtime id 列表（事实来源）
- `metadata`：可选 `dict[str, str]`，用户键不得以 `saddler.` 前缀开头

### 3.2 RuntimeRecord 中的 storage 绑定

`runtime.json` 的 `runtime_spec.storages` 改为：

```json
[
  { "storage_id": "st-xxxx", "mount": "/models" },
  { "storage_id": "st-yyyy", "mount": "/cache" }
]
```

说明：

- `mount` 仅属于 runtime 绑定关系，不属于 storage 资源自身。
- 同一 runtime 内 mount 路径必须唯一。

---

## 4. CLI 设计

### 4.1 新增 `saddler storage` 命令组

```bash
saddler storage create --kind docker-volume --name model-cache [--volume-name saddler-model-cache] [--meta KEY=VALUE ...]
saddler storage create --kind local --path ./shared-data --name shared-data [--meta KEY=VALUE ...]
saddler storage ls
saddler storage inspect <id|name>
saddler storage rm <id|name> [--force]
```

语义：

- `create` 负责 provision：
  - `docker-volume` -> `docker volume create`
  - `local` -> 仅登记绝对路径（不创建目录）
- provision/登记失败时不写入 `storage.json`（无“记录已存在但资源未建成”中间态）。

### 4.2 `runtime create --storage` 收敛

保留参数但收敛语义：

```bash
saddler runtime create --type docker --storage model-cache:/models --storage st-abcd1234:/cache
```

规则：

- 仅允许 `<id|name>:<mount>` 引用格式。
- storage 必须已存在。
- mount 必须为 runtime 内绝对路径。
- 不再支持 `kind=...,mount=...` 内联格式。

---

## 5. 生命周期与锁内变更规则

### 5.1 runtime create（绑定）

1. 解析并校验 storage 引用列表。  
2. 创建 runtime 记录前，在内存构建目标绑定集合。  
3. 对每个 storage 执行 `StorageStore.locked_mutate`：将 `runtime_id` append 到 `bound_runtime_ids`（若已存在则 no-op）。  
4. 写入 runtime 记录（含 storage 绑定关系）。  
5. 任一步失败时，回滚已 append 的 runtime_id。

### 5.2 runtime rm（解绑顺序）

采用“先解绑，再删 runtime”：

1. 读取 runtime 记录拿到绑定 storage 列表。  
2. 逐个 storage 在锁内执行 `bound_runtime_ids.remove(runtime_id)`；若不存在则 no-op（保证幂等重试）。  
3. 全部解绑成功后，删除 runtime 记录。  
4. 中途失败时保留 runtime 记录，允许再次执行 `runtime rm` 安全重试。

该顺序避免“runtime 已删但 storage 残留幽灵引用”。

### 5.3 storage rm

- 默认：`bound_runtime_ids` 非空则拒绝删除，并输出占用 runtime 列表。
- `--force`：允许忽略绑定检查并删除记录（用于运维场景）。

底层处理规则（显式不对称）：

- `docker-volume`：执行 `docker volume rm` 删除 volume 对象；若 not found 视为 no-op success。
- `local`：不执行目录删除，不触碰文件内容；仅删除 `storage.json` 记录。

所有权约束：

> saddler 不拥有存储内容的所有权。`storage rm` 仅清理 saddler 管理记录和对应的存储容器对象（如 docker volume），不删除任何文件内容。用户对存储内容的生命周期负全责。
>
> `local` storage 的 create 仅做路径登记，不创建目录；rm 仅删除记录，不删除目录内容。saddler 对本地文件系统没有写入所有权，目录的创建与清理由用户负责。

---

## 6. hitch YAML 与执行语义

### 6.1 schema 变更

新增顶层 `storages`：

```yaml
storages:
  model-cache:
    kind: docker-volume
    volume_name: saddler-model-cache
    metadata:
      team: ml
```

runtime 引用：

```yaml
runtimes:
  rt-main:
    type: docker
    image: my-image
    storages:
      - storage: model-cache
        mount: /models
```

约束：

- `runtimes.*.storages` 仅允许 `{storage, mount}` 引用项。
- 禁止 runtime 内联 `kind/path/volume_name` 定义。
- 禁止匿名 storage。

### 6.2 执行顺序

`hitch up`：

1. create storages  
2. create + start runtimes  
3. create agents

`hitch down`：

1. rm agents  
2. stop + rm runtimes（触发 storage 解绑）  
3. 尝试 rm 本 compose 声明且 hitch-owned 的 storages

当 storage 仍被外部 runtime 绑定时：

- 跳过该 storage 删除并输出 warning（不阻塞整体 down）。
- warning 必须包含 storage 标识和 `bound_runtime_ids` 列表。

---

## 7. 失败输出与幂等保证

### 7.1 hitch up 中途失败输出

统一输出结构化清单（按资源类型分组）：

```text
hitch up failed at: runtime create (rt-secondary)

resources already created:
  storages: model-cache (st-xxxx)
  runtimes: rt-main (rt-yyyy)
  agents:   (none)

to clean up, run: saddler hitch down
```

### 7.2 hitch down 幂等性

必须保证用户在 up 失败后可安全执行 `hitch down`：

- 资源不存在时跳过（no-op）。
- 重复执行 down 不应因“上一次已删”而失败。
- 仅在真正错误（例如权限、底层 API 错误）时非零退出。

---

## 8. metadata 规则

`StorageRecord` 支持 metadata，规则与 agent/runtime 一致：

- 类型：`dict[str, str]`
- key 不能为空字符串
- 用户自定义 key 不得使用 `saddler.` 前缀

hitch 为 storage/runtime/agent 注入系统保留键：

- `saddler.hitch.project`
- `saddler.hitch.compose_file`
- `saddler.hitch.service`

---

## 9. 验收标准（DoD）

- 不存在匿名 storage 路径（CLI 与 hitch 均禁用）。
- runtime 仅通过 `<storage-id|name>:<mount>` 引用 storage。
- `StorageRecord` 使用 `bound_runtime_ids` 作为唯一绑定事实来源。
- `runtime rm` 采用先解绑后删记录，失败可重试，无幽灵引用。
- `storage rm` 对 `docker-volume` 删除 volume 对象；对 `local` 仅删除记录，不删除目录内容。
- hitch `up/down` 语义、失败输出、幂等行为与本设计一致。

---

## 10. 影响范围

改动集中在：

- `StorageManager` + `StorageStore`（新增）
- `RuntimeManager.create/rm`（绑定与解绑逻辑）
- CLI：新增 `storage` 命令组；收敛 `runtime create --storage` 解析
- hitch schema + plan + executor（新增 storage 节点与引用解析）
- 文档：`docs/spec.md` 对齐 storage 一等资源化模型

不改动：

- `LocalRuntime` workdir 语义
- `agent.json` 直接引用 storage
- `AgentManager` / `HarnessAdapter` 的职责分层
