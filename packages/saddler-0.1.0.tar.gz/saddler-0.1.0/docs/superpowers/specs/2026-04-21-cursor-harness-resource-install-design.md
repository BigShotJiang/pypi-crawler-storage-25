# Cursor Harness 资源安装设计

## 背景

当前 `CursorHarness` 中：

- `install_rules` 直接将 `rule.source` 写入 runtime 的 `.cursor/rules/*.mdc`
- `install_skills` 仅创建空的 `.cursor/skills/<name>.md` 文件

这与目标行为不一致。安装的核心应为：从 saddler 侧定义/引用的资源出发，先 fetch，再安装到 runtime 的 Cursor 目标目录。

## 目标

1. `rules` 安装改为 `fetch -> copy`，不再依赖“内联 source 直接落盘”路径。
2. `skills` 安装改为拷贝完整 skill resource 目录到 runtime。
3. 对 rule 文件补齐 Cursor 特定 frontmatter；默认 `alwaysApply: true`。
4. 保持 fetcher 层通用，不引入 Cursor 平台语义。

## 非目标

- 不在本次变更中重构通用 resource installer 抽象。
- 不修改 Cursor 之外 harness 的安装行为。
- 不引入与当前需求无关的规则元数据策略（例如自动生成复杂 `globs`）。

## 设计原则

1. **职责边界清晰**
   - fetcher 只负责“拉取资源”
   - Cursor 语义（如 frontmatter）仅在 `CursorHarness` 处理
2. **结果可直接消费**
   - runtime 输出目录必须可被 Cursor 直接使用
3. **默认安全与可预测**
   - rule 若缺少 frontmatter，统一补齐且默认 `alwaysApply: true`

## 目标行为

### Rules 安装

安装流程：

1. 根据 `RuleSpec` 定位并 fetch 规则资源（文件形式）
2. 读取规则内容并执行 frontmatter 规范化
3. 写入 runtime：`<workdir>/.cursor/rules/<rule-name>.mdc`

frontmatter 处理规则：

- 若已有合法 frontmatter：
  - 保留现有字段
  - 若缺少 `alwaysApply`，补 `alwaysApply: true`
- 若无 frontmatter：
  - 注入最小 frontmatter：
    - `description: ""`
    - `globs:`
    - `alwaysApply: true`
  - 后接原始正文

### Skills 安装

安装流程：

1. 根据 `SkillSpec` 定位并 fetch skill 资源（目录形式）
2. 整目录复制到 runtime：`<workdir>/.cursor/skills/<skill-name>/`
3. 保持目录结构与文件内容，不做 Cursor 语义变换

## 关键实现点

建议将实现集中在 `saddler_v2/infra/harness/cursor.py`：

1. `install_rules(...)`
   - 从“直接写 `rule.source`”改为“fetch 后 copy”
   - 增加私有辅助函数：
     - `_ensure_rule_frontmatter(content: str) -> str`
     - `_inject_default_frontmatter(content: str) -> str`
2. `install_skills(...)`
   - 从“touch 空文件”改为“目录级复制”
3. 保留 `_cursor_config_dir(...)` 作为目标目录根路径计算函数

## 错误处理

1. fetch 失败：抛出明确错误（包含资源名/来源），终止当前安装。
2. rule 内容不可读：抛出规则级错误，不静默跳过。
3. 目录复制失败：抛出技能级错误，避免部分安装状态被误判成功。

## 测试策略

在 `test_v2` 补充/更新 CursorHarness 相关测试，覆盖：

1. **rules fetch-copy 路径**
   - 给定可 fetch 的规则资源，最终 `.cursor/rules/<name>.mdc` 存在且内容正确。
2. **rules frontmatter 注入**
   - 无 frontmatter 输入时，输出带默认 frontmatter，且 `alwaysApply: true`。
3. **rules frontmatter 补字段**
   - 已有 frontmatter 但缺少 `alwaysApply` 时，自动补齐为 `true`。
4. **skills 目录复制**
   - skill resource 为目录时，目标 `.cursor/skills/<name>/` 结构与源一致。

## 验收标准

满足以下条件视为完成：

1. `CursorHarness` 中 rules/skills 均采用 `fetch -> copy` 模型。
2. skills 不再生成空 `.md`，而是完整目录安装。
3. rule 输出文件均满足 Cursor `.mdc` frontmatter 规范。
4. 默认 frontmatter 包含 `alwaysApply: true`。
5. 新增/更新测试通过。

## 风险与缓解

1. **规则 frontmatter 解析边界不完整**
   - 缓解：优先实现稳定的“有/无 frontmatter”与 `alwaysApply` 补齐逻辑，避免一次性引入复杂 YAML 变换。
2. **目录复制覆盖策略不清**
   - 缓解：采用明确策略（先清理同名目标再复制，或覆盖复制），并在测试中固化行为。

## 实施顺序

1. 改造 `install_rules` 为 fetch-copy 并加入 frontmatter 规范化
2. 改造 `install_skills` 为目录复制
3. 补充测试
4. 运行测试并修正
