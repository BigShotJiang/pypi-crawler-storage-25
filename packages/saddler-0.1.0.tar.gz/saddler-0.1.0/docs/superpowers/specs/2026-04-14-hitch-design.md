# Saddler Hitch 编排设计（MVP）

日期：2026-04-14  
状态：已定稿（待进入实现计划）  
范围：类 Docker Compose 的 YAML，编排多个 `RuntimeRecord` 与 `AgentRecord`；CLI 为 `saddler hitch`。

---

## 1. 背景与目标

`docs/spec.md` 将 **hitch** 定义为 saddler 的上层编排工具：多 agent 协作、声明式配置、生命周期编排。saddler 本身仍 **不** 引入项目级配置文件；**hitch 文件由 hitch 解析并展开为与现有 CLI 一致的操作**（runtime / agent 管理）。

### 1.1 已确认的产品决策

| 主题 | 决策 |
|------|------|
| MVP 范围 | 同一文件内声明 **runtimes** 与 **agents**，支持 **`depends_on`** |
| CLI | **`saddler hitch <子命令>`**，与 `agent` / `runtime` 并列 |
| `up` | 仅 **装配**：`runtime create`/`start`（按声明）+ **`saddler create`** 各 agent；**不**自动拉起 harness（用户自行 `tui` / `run`） |
| `stop` | 对齐 **`docker compose stop`**：停止运行态（主要为 **`runtime stop`**），不删除持久化记录 |
| `down` | 对齐 **`docker compose down`**：在 `stop` 语义之上 **删除本编排创建的 agent**；对 **本文件声明的 runtime** 在条件允许时 **`runtime stop` + `runtime rm`**（见 §6） |
| 配置文件发现 | 支持 **`-f`** 多次指定；无 `-f` 时依次尝试 **`hitch.yaml`** → **`hitch.yml`** → **`saddler.yaml`**（在**当前工作目录**） |
| 项目名 | YAML 顶层 **`name`**；缺省为 **配置文件所在目录的目录名** |
| `hitch ps` | **纳入 MVP** |
| `depends_on` | 允许 **agent → agent** 与 **agent → runtime**；**仅允许引用同一文件内的键**；图须为 **DAG（禁止环）** |

---

## 2. 实现方案选择

采用 **「声明式 Plan + 进程内执行」**：

1. **解析** YAML（合并多 `-f`）→ 校验 schema 与依赖图。  
2. 生成不可变的 **Plan**（拓扑序、要执行的操作列表）。  
3. **Executor** 调用与现有 `saddler runtime` / `saddler create` **相同的业务层**（非通过子进程拼接 CLI），便于测试与错误传播。

**不采用**纯子进程调用 saddler CLI 作为 MVP 主路径（可作为后续可选或调试模式）。

---

## 3. 架构与数据流

```
YAML (-f 合并) → Parser/Validator → Plan → Executor → RuntimeManager / AgentManager（与 CLI 同源）
```

- **hitch 不引入**新的 agent 运行时协议；**不**在 MVP 实现 agent 间网络通信或消息总线。  
- **`depends_on`** 仅表达 **创建/启动顺序**：被依赖节点先完成其在本阶段所需操作（runtime 创建并启动；agent 在依赖就绪后 `create`）。

---

## 4. YAML 文件形状（MVP）

约定顶层结构（字段名与 saddler CLI 对齐，避免第三套命名；具体键名在实现阶段与 `saddler runtime create` / `saddler create` 参数一一映射）。

```yaml
name: my-project          # 可选；缺省 = 配置文件所在目录名
version: 1                # hitch 文件格式版本，用于后续演进

runtimes:
  <logical-id>:
    # 映射 runtime create：type, name（可选）, docker-image, storage, env, ...
    depends_on: []        # 可选；仅可引用本文件中其它 runtime 的 id（若存在跨 runtime 顺序）

agents:
  <logical-id>:
    depends_on: [<logical-id>, ...]   # 可为 runtime id 或 agent id，须在同一文件内且成 DAG
    # 映射 create：harness, role, workdir, skill（列表）, name（可选）,
    # runtime 绑定：引用 runtimes.<id> 或外部已有 runtime id|name（见 §5）
```

**说明：**

- **`runtimes` / `agents` 下的键**为文件内逻辑 id，用于 `depends_on` 与交叉引用。  
- **与 `saddler create` 的 `--runtime` / `--runtime-from-agent` 二选一** 在 YAML 中保持互斥：要么绑定到本文件某 `runtimes.<id>`，要么引用外部已有 runtime 或 `runtime_from_agent`。

---

## 5. 资源归属与外部引用（`down` 安全边界）

### 5.1 本项目创建的资源（须可追踪）

对 **由 hitch `up` 创建** 的 `RuntimeRecord` 与 `AgentRecord`，在持久化 JSON 中写入 **hitch 元数据**（实现时字段名可微调，语义如下）：

- `hitch.project`：字符串，与 YAML 解析后的项目名一致。  
- `hitch.compose_file`：字符串，**归一化后的绝对路径**（主文件或合并后的逻辑来源，实现需定义多 `-f` 时的记录方式）。  
- `hitch.service`：字符串，逻辑 id（`runtimes` 或 `agents` 下的键）。

**`hitch down`** 仅删除 **带有 `hitch.project` 且与当前命令解析出的项目一致**、且 **由本 hitch 管线创建** 的记录；避免误删用户手工或其它项目创建的资源。

### 5.2 外部已有 runtime / agent

YAML 允许 **引用已存在的** `runtime_id` / `display name`（或 `runtime_from_agent`）。此类资源 **不** 写入 `hitch` 归属，**不得**被 **`hitch down`** 删除。若 `down` 因仍有 agent 绑定某外部 runtime 而无法完成预期清理，**报错退出**并说明阻塞原因（不静默跳过）。

---

## 6. 命令语义（MVP）

| 命令 | 行为 |
|------|------|
| **`saddler hitch config`** | 解析并合并 `-f`，校验 YAML 与依赖图；可打印有效配置或仅校验（**零退出码表示可执行 `up`**） |
| **`saddler hitch up`** | 按拓扑序执行 **runtime**（create + start，若已存在则按 §7 幂等策略）→ **agent**（`create`）。**不**启动 harness。 |
| **`saddler hitch stop`** | 对 **本项目关联的** runtime（或文件中声明的 runtime）执行 **`runtime stop`**；**不** `rm` agent；**不** `rm` runtime 记录。 |
| **`saddler hitch down`** | 先执行与 `stop` 相当的停止语义；**`rm` 本项目创建的 agent**；对 **本文件声明且由 hitch 创建、带 hitch 元数据** 的 runtime **在 `ref_count == 0` 等条件满足时** `runtime rm`。若仍不满足删除条件，**必须**失败并给出明确原因（与现有 `runtime rm` 行为一致）。 |
| **`saddler hitch ps`** | 列出 **当前项目**（`name` + `compose_file` 匹配策略与实现一致）下的 agent/runtime 状态，信息来自现有 store。 |

---

## 7. 幂等与冲突策略

- **`up`**：若目标 agent 已存在（同 workdir 或 name 冲突），**默认**报错退出。  
- 提供 **`--force-recreate`**（或等价命名）：**仅**对 **带 hitch 归属且属于本 project** 的资源先 `rm` 再按文件重建；对外部引用资源不自动删除。  
- **runtime 名称冲突**：若与现有全局 `name` 冲突且非本项目 hitch 创建 → **报错**并提示。

---

## 8. 错误处理

- 执行链中任一步失败：**非零退出码**；**不**在 MVP 要求自动跨步骤回滚（可在 Phase 2 讨论）。  
- 依赖图含环：**校验阶段失败**，不执行任何操作。

---

## 9. 测试策略

- **Plan 单元测试**：拓扑排序、环检测、`-f` 合并、缺失字段。  
- **Executor**：用 fake store / 临时目录注入，覆盖 `up` / `stop` / `down` / `ps` 主路径。  
- **可选**：一条端到端集成测试（临时 HOME + 短 YAML）。

---

## 10. 与主规范的关系

实现完成后，应在 **`docs/spec.md`** 中增加 **hitch** 小节（命令表、YAML 发现规则、与 saddler 无项目级配置文件的原则），本文档为详细设计来源。

---

## 11. 自审记录（定稿前）

- 已消除占位符与未决「TBD」；外部引用在 `down` 时的行为以「不删除 + 明确错误/跳过策略在实现计划细化」写清。  
- 范围限于 hitch MVP；**不**包含 harness 间通信协议与 healthcheck。  
- `depends_on` 与 DAG、同一文件约束，与 §4、§8 一致。
