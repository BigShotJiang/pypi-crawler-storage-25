# Skill/Rule Installer Design (Phase 1)

## Background and Goals

We need a reusable base installer for `skill` and `rule` artifacts that Saddler depends on.  
The installer must:

- Support source types: remote git repository, remote archive, local directory.
- Support both `skill` and `rule` with a mostly shared pipeline.
- Keep `name` as required input and `path` as optional override.
- Support fetch-only mode (cache without installing).
- Use conflict handling strategy controlled by request parameter.
- Stay fully independent from other Saddler modules (no imports from app/domain/service layers).

This module belongs to `saddler_v2/infra`, but is infrastructure-only and can be reused outside Saddler orchestration.

## Scope

### In Scope

- Source fetch and cache materialization.
- Discovery from source by explicit path or by pre-defined candidate paths.
- Artifact validation (`skill` frontmatter and `rule` text constraints).
- Install into caller-provided `target_dir`.
- Conflict policy: `replace`, `skip`, `fail`.
- Modes: `fetch_only`, `fetch_and_install`, `install_from_cache`.

### Out of Scope

- Harness-specific target path conventions (caller provides `target_dir`).
- Backward compatibility layers with old installer APIs.
- Global recursive fuzzy search in source tree.

## Architecture

Create a standalone installer package under infra, for example:

- `saddler_v2/infra/installer/types.py`
- `saddler_v2/infra/installer/sources.py`
- `saddler_v2/infra/installer/discovery.py`
- `saddler_v2/infra/installer/validate.py`
- `saddler_v2/infra/installer/install.py`
- `saddler_v2/infra/installer/service.py`
- `saddler_v2/infra/installer/errors.py`

Responsibility split:

- `sources`: parse source descriptor, fetch/extract/copy safely, write cache object.
- `discovery`: resolve artifact path from (`name`, optional `path`, type).
- `validate`: type-specific structural/content checks.
- `install`: apply conflict policy and perform atomic write/replace.
- `service`: public orchestrator implementing operational modes.

## Public Contract

Core request model (`InstallRequest`) should include:

- `mode`: `fetch_only | fetch_and_install | install_from_cache` (default: `fetch_and_install`)
- `artifact_type`: `skill | rule`
- `name`: required
- `path`: optional, relative to resolved source root
- `source`: required for `fetch_only` and `fetch_and_install`
- `cache_key`: required for `install_from_cache`
- `target_dir`: required for install modes
- `on_conflict`: `replace | skip | fail`

Core response model (`InstallResult`) should include:

- `mode`
- `cache_key` (primary reference)
- `cache_path` (diagnostic only)
- `status`: `fetched | installed | replaced | skipped`
- `artifact_name`
- `installed_path` (for install modes)

## Data Flow

### 1) Fetch Phase

Input: source descriptor + optional ref.  
Output: `cache_key`, `cache_path`, `source_digest`.

Steps:

1. Normalize source spec (`git`, `archive`, `local`).
2. Resolve immutable identity:
   - git: commit hash
   - archive/local: content digest
3. Compute `cache_key`.
4. If cached object exists, return cache metadata directly.
5. Else materialize source into temp area, run safety checks, stage to cache atomically.

### 2) Install Phase

Input: `cache_key` + artifact request fields.  
Output: install status and destination path.

Steps:

1. Resolve `source_root` from cache.
2. Discover artifact path.
3. Validate artifact.
4. Install to `target_dir` according to conflict policy.

## Discovery Rules

### Explicit Path Mode (`path` provided)

- Resolve path against `source_root`.
- Reject path traversal outside source root.
- Require existence.
- Type gate:
  - `skill`: must be directory.
  - `rule`: must be file.
- No fuzzy fallback.

### Name Candidate Mode (`path` omitted)

`skill` candidates (ordered):

1. `skills/<name>`
2. `<name>`
3. `skill/<name>` (optional compatibility candidate)

`rule` candidates (ordered):

1. `rules/<name>`
2. `rules/<name>.md`
3. `rules/<name>.mdc`
4. `<name>`
5. `<name>.md`
6. `<name>.mdc`

Resolution policy:

- 0 matches -> `DiscoveryNotFound`.
- 1 match -> success.
- >1 matches -> `DiscoveryAmbiguous` (caller should provide `path`).

## Validation Rules

### Skill Validation

- Target must be a directory.
- `SKILL.md` must exist under that directory.
- `SKILL.md` must contain parseable frontmatter.
- Frontmatter must contain non-empty `name` and `description`.

### Rule Validation

- Target must be a regular file.
- File must be text-readable.
- File content must be non-empty.

Validation returns normalized metadata for downstream logs/audit.

## Conflict and Atomicity

Supported policies:

- `replace`: write to temp destination then atomic rename/replace.
- `skip`: if destination exists, return `skipped`.
- `fail`: if destination exists, raise `InstallConflictError`.

Destination naming:

- `skill`: install as directory `<target_dir>/<name>/...`
- `rule`: install as file `<target_dir>/<name>` (phase 1 fixed rule to remove naming ambiguity)

## Error Model

Use typed errors with stable `code`:

- `SOURCE_RESOLVE_ERROR`
- `CACHE_ERROR`
- `DISCOVERY_NOT_FOUND`
- `DISCOVERY_AMBIGUOUS`
- `DISCOVERY_PATH_ESCAPE`
- `VALIDATION_ERROR`
- `INSTALL_CONFLICT`
- `INSTALL_IO_ERROR`

Each error should include:

- human-readable `message`
- structured `details` (candidate list, missing frontmatter fields, offending path, etc.)

## Testing Strategy (`test_v2`)

### Fetch

- git fetch with/without ref.
- archive fetch and extraction.
- local source caching.
- cache hit reuse.

### Discovery

- explicit path success/failure/path escape.
- name-based 0/1/multi-match behavior.

### Validation

- skill missing `SKILL.md`.
- invalid frontmatter.
- frontmatter missing `name` or `description`.
- rule non-text/empty.

### Install

- `replace`, `skip`, `fail`.
- `fetch_only` has no install side effect.
- `install_from_cache` works offline with existing cache.

## Implementation Notes

- Reuse proven safety logic from previous rigging implementation concepts (safe extract, no link/path escape), but keep code physically independent from old modules.
- Keep module boundaries strict to avoid creeping dependency on Saddler app/domain objects.
- Keep API minimal and deterministic first; introduce optional recursive discovery only if future requirements prove necessary.

## Acceptance Criteria

1. Can fetch from git/archive/local and return stable `cache_key`.
2. Can perform fetch-only without writing to install destination.
3. Can install `skill` and `rule` from cache with shared core pipeline.
4. `name` required, optional `path` override supported.
5. Conflict behavior fully controlled by request parameter.
6. Skill frontmatter validation enforces required fields.
7. Module has no runtime dependency on other Saddler layers.
