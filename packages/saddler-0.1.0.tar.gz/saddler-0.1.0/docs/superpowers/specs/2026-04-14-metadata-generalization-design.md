# Saddler 资源通用 metadata 设计（去 hitch 专用字段）

日期：2026-04-14  
状态：已定稿（待进入 implementation plan）  
范围：将资源归属与标签统一到开放式字符串 metadata，覆盖 agent/runtime 与 hitch 场景。

---

## 1. 背景与目标

当前 `AgentRecord` / `RuntimeRecord` 使用 `hitch` 三元组字段承载编排归属，属于特定子系统语义，难以复用于其他资源来源。目标是把“资源元数据”升级为 saddler 通用能力。

本设计确定：

- metadata 为开放式 key-value（`dict[str, str]`）。
- metadata 在创建时写入；本期不支持更新命令。
- hitch 归属并入 metadata，不再保留独立 `hitch` 字段。
- 不考虑旧数据兼容与迁移，按快速迭代策略直接切换。

---

## 2. 方案决策

采用 **方案 B：一次性切换**。

- 删除 `hitch` 专用字段。
- 所有 hitch 归属判断改为读取 metadata 保留键。
- JSON 持久化仅保留 metadata。

理由：

- 语义最干净，避免双轨模型长期并存。
- 与“快速迭代阶段不强调向后兼容”原则一致。
- 降低后续维护与认知负担。

---

## 3. 数据模型设计

### 3.1 Record 字段

`AgentRecord` 与 `RuntimeRecord` 统一使用：

- `metadata: dict[str, str] | None`

并移除：

- `hitch: {...}`（完全删除）

### 3.2 约束

- key/value 必须为字符串。
- key 不允许为空字符串。
- value 可为空字符串（`k=`）。
- 仅创建时写入，不提供 mutation API。

### 3.3 系统保留键

保留前缀：`saddler.*`

hitch 使用以下保留键：

- `saddler.hitch.project`
- `saddler.hitch.compose_file`
- `saddler.hitch.service`

说明：用户 metadata 不得覆盖上述保留键。

---

## 4. CLI 与 YAML 输入设计

### 4.1 CLI

为以下命令新增可重复参数：

- `saddler create --meta KEY=VALUE`
- `saddler run --meta KEY=VALUE`
- `saddler runtime create --meta KEY=VALUE`

解析规则：

- 仅按首个 `=` 分割。
- 缺少 `=` 或空 key 时报错。
- 同一 key 重复时后者覆盖前者。

### 4.2 hitch YAML

扩展字段：

- `runtimes.<id>.metadata: {k: "v"}`
- `agents.<id>.metadata: {k: "v"}`

`hitch up` 创建资源时，在用户 metadata 基础上注入 `saddler.hitch.*` 三个保留键。若用户已提供同名保留键，报错退出。

---

## 5. 执行逻辑迁移

### 5.1 HitchExecutor

把当前基于 `record.hitch` 的匹配，统一替换为 metadata 键匹配：

- project <- `saddler.hitch.project`
- compose_file <- `saddler.hitch.compose_file`
- service <- `saddler.hitch.service`

涉及路径：

- `up`（写入归属 metadata）
- `stop`（筛选目标 runtime）
- `down`（筛选并删除目标 agent/runtime）
- `ps`（筛选并展示当前 hitch 项目资源）
- `force_recreate`（识别并清理当前项目下同 service 资源）

### 5.2 Manager / Store

- create 路径支持注入 metadata。
- 持久化读写仅处理 metadata，不再定义/读取 `hitch` 字段。

---

## 6. 错误处理

- CLI `--meta` 格式非法：返回参数错误，退出码非零。
- hitch metadata 冲突（用户提供 `saddler.hitch.*`）：校验失败，退出码非零。
- 非法 metadata 类型（非字符串）：schema 校验失败。

---

## 7. 测试与验收

### 7.1 测试项

- 模型层：
  - `metadata` 仅接受 `dict[str, str]`
  - record JSON 仅包含 metadata，不含 hitch
- CLI 层：
  - `--meta` 正常解析
  - 非法格式报错
  - 重复 key 覆盖
- hitch 层：
  - `up` 正确写入 `saddler.hitch.*`
  - `ps/stop/down/force_recreate` 匹配逻辑正确
  - 保留键冲突时报错

### 7.2 验收标准（DoD）

- 用户可在 create-time 为 agent/runtime 写入开放字符串 metadata。
- hitch 全链路已迁移为 metadata 保留键，不再依赖 `hitch` 字段。
- 文档与实现设计一致，不包含旧数据兼容路径。

---

## 8. 与主规范文档对齐项

后续在 `docs/spec.md` 同步以下变更：

- 资源持久化 schema 使用 `metadata` 通用字段。
- hitch 归属键说明改为 `saddler.hitch.*` metadata 保留键。
- CLI 参数表新增 `--meta`（create/run/runtime create）。

