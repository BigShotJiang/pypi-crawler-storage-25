# CLI 子命令简写与关键参数短参数设计

- 日期：2026-04-15
- 状态：已评审（待实现）
- 范围：`saddler` CLI（Typer）

## 1. 背景与目标

当前 CLI 已有少量短参数（如 `--workdir/-w`、`--file/-f`），但 `runtime` 与 `storage` 仍缺少命令组简写，且多数高频参数仅支持长参数。

本设计目标：

1. 增加命令组简写：`runtime -> rt`、`storage -> st`
2. 为高频参数补充短参数，降低输入成本
3. 保持现有长参数完全兼容，不改变业务语义与校验行为

## 2. 设计原则

1. **最小改动**：采用增量改造（方案 A），仅在参数声明与命令注册层改动。
2. **显式优先**：语义复杂或低频参数不提供短写，避免误用。
3. **冲突可记忆**：使用大写短参数区分容易冲突的槽位（`-H/-R/-S/-M`）。
4. **向后兼容**：所有既有长参数继续有效，错误信息与校验逻辑保持一致。

## 3. 命令与参数映射

### 3.1 子命令组简写

- `saddler runtime ...` 等价 `saddler rt ...`
- `saddler storage ...` 等价 `saddler st ...`

实现方式：同一 `Typer` 子应用双挂载，保留原入口并新增别名入口。

### 3.2 新增短参数（按确认清单）

| 长参数 | 简写 | 说明 |
|---|---|---|
| `--harness` | `-H` | 大写避免与 help 语义混淆 |
| `--role` | `-r` | agent 侧高频参数 |
| `--workdir` | `-w` | 已存在，保持不变 |
| `--skill` | `-s` | agent 侧高频参数 |
| `--name` | `-n` | 通用命名参数 |
| `--runtime` | `-R` | 大写区分 `--role` |
| `--meta` | `-m` | 记录元数据 |
| `--force` | `-f` | 删除类操作高频参数 |
| `--type` | `-t` | `runtime create` |
| `--docker-image` | `-i` | `runtime create` |
| `--storage` | `-S` | 大写区分 `--skill` |
| `--mount` | `-M` | 大写区分 `--meta` |
| `--env` | `-e` | `runtime create` |
| `--kind` | `-k` | `storage create` |
| `--path` | `-p` | `storage create` |

### 3.3 明确不提供短参数

- `--runtime-from-agent`：语义复杂，保持显式更安全
- `--acp`：flag 已短，短写收益低
- `--volume-name`：低频参数，显式更清晰
- `--force-recreate`：hitch 专属低频参数，保持显式

## 4. 影响范围

## 4.1 代码文件

- `saddler/cli.py`
  - 为命令组增加 `rt` / `st` 别名挂载
  - 为确认清单中的 `typer.Option` 增加短参数别名

## 4.2 测试文件

- `tests/cli/test_runtime_commands.py`
  - 补短参数路径覆盖（代表性用例）
- `tests/cli/test_storage_commands.py`
  - 补 `storage create` 短参数路径覆盖
- `tests/cli/test_top_level_aliases.py`（或同类 CLI 入口测试文件）
  - 增加 `rt`/`st` 与原命令等价性测试

## 5. 兼容性与风险

### 5.1 兼容性承诺

1. 原有长参数不移除、不改名
2. 仅新增短写入口，调用链与 manager 行为不变
3. 参数校验、错误文案、默认值逻辑保持一致

### 5.2 风险与缓解

- 风险：短参数冲突或误绑定导致错误解析
  - 缓解：为每个命令路径保留至少一条长参数测试并新增短参数对照测试
- 风险：`-f` 在不同子命令语义复用导致误解
  - 缓解：维持“按子命令作用域解析”的 Typer 现状，不引入全局别名

## 6. 验收标准（DoD）

1. `saddler runtime create --help` 与 `saddler storage create --help` 显示新增短参数。
2. `saddler rt ...` 与 `saddler runtime ...` 行为等价。
3. `saddler st ...` 与 `saddler storage ...` 行为等价。
4. 既有长参数路径测试继续通过。
5. 未列入清单的参数不新增短写。

## 7. 实施策略（非代码步骤）

1. 先改 `saddler/cli.py` 命令注册与参数声明
2. 再补对应 CLI 测试
3. 运行目标测试文件验证回归
4. 若无新增需求，不做结构性重构（如参数常量化抽象）

## 8. 非目标

1. 不重构 CLI 架构与命令分层
2. 不调整业务层（`AgentManager`/`RuntimeManager`/`StorageManager`）语义
3. 不引入新的全局参数规范系统
