# Docker Runtime Non-Root UID/GID Design

Date: 2026-04-13  
Status: Draft (approved in chat, pending implementation plan)

## Context

We need Docker runtime to support non-root execution identity while keeping behavior explicit across different runtime backends.  
The chosen direction is to introduce a unified runtime-level `run_as` field and model capability differences in each runtime.

## Goals

- Support runtime-level default execution identity for Docker.
- Use a single, unambiguous syntax for identity input.
- Fail fast when a runtime does not support `run_as`.
- Preserve backward compatibility for existing runtime records without `run_as`.

## Non-Goals

- No agent-level `run_as` override in this phase.
- No complex migration for existing persisted runtime records.
- No broad refactor of runtime lifecycle APIs beyond what this feature requires.

## User-Facing Configuration

### Runtime config field

- New field: `run_as: "<name|uid>[:<group|gid>]"`
- Exactly one representation is allowed (single string form only).
- The value is stored as user intent in `runtime_spec`.

### CLI

- `runtime create` adds `--run-as`.
- CLI performs lightweight validation:
  - non-empty
  - at most one `:`
  - non-empty user part before `:`
- Runtime/backend-specific support validation is done in manager/runtime layers.

## Architecture and Capability Model

### Unified abstraction

- Add a runtime-level capability contract for `run_as` support (for example, `supports_run_as()` or equivalent capability set).
- Current backend expectations:
  - `docker`: supported
  - `local`: unsupported

### Validation point

- During `RuntimeManager.create()`, when `run_as` is present:
  - if runtime backend is unsupported, raise `SaddlerError` and reject creation
  - error should explicitly include runtime type and `run_as`

This ensures "create succeeded" implies the configured behavior can actually be applied.

## Execution Semantics

### Scope

- Phase 1: runtime-level only.
- Agents inherit runtime default identity; agents do not own `run_as`.

### Docker behavior

- Primary enforcement happens at `docker exec` layer by passing `-u <run_as>`.
- Apply consistently in:
  - `exec`
  - `exec_fg`
  - `exec_bg`
  - copy-related exec paths where user context matters
- If `run_as` is absent, keep existing behavior (image/default user).

### Why exec-level first

- Lower regression risk than changing container primary process user.
- Clear command-level semantics.
- Keeps room for future optional `docker create --user` extension if needed.

## Error Handling

- Invalid `run_as` format: reject with `SaddlerError` at input/validation phase.
- Unsupported runtime + `run_as`: reject at create time with explicit message.
- Docker execution rejects provided user (for example, unknown user/group):
  - propagate stderr
  - include context (`run_as=<value>`) in raised error surface where applicable

## Data Model and Persistence

- `runtime_spec` stores raw configured `run_as` string.
- `runtime_state` may store normalized/effective run-as metadata for diagnostics.
- `dump_state/load_state` should read optional `run_as` with safe defaults (`None` when missing).
- Existing records without `run_as` remain valid without migration.

## Testing Strategy

### CLI tests

- `runtime create --run-as` populates runtime config correctly.
- Invalid formats return clear errors.

### Manager tests

- `local` runtime with `run_as` fails fast during creation.
- `docker` runtime with `run_as` creates successfully.

### Runtime tests (Docker)

- `exec/exec_fg/exec_bg` include `-u` when `run_as` is configured.
- No `-u` is passed when `run_as` is not configured (regression guard).

### Compatibility tests

- Loading old runtime states/specs without `run_as` still works.

## Future Extension (Out of Scope for Phase 1)

- Agent-level override support with precedence:
  - `agent.run_as > runtime.run_as > image default`
- Policy-based split execution identities (for example, root for install steps and non-root for regular commands).

## Open Questions

- None for this phase. Scope and behavior are constrained by approved decisions.
