1. 明确Workspace抽象边界 (spec v0.5)
2. 明确配置文件或命令行参数的实现方案 (spec v0.6)
  - 参考Docker CLI的分层设计方案（CLI负责原子化命令不依赖配置文件）
3. Runtime [done]
  - DockerRuntime与容器绑定
  - SSHRuntime从文档中先移除
4. 区分前台命令与后台命令，前台使用交互式方案，后台使用ACP协议
5. 抽象storage层 [done]
6. Runtime统一支持cwd与env配置 [done]
7. 增加acp-bridge支持(stdio-ws/shttp)
8. Role/Prototype/Skill Install [done]
9. Runtime Management (Create/Start/Stop/Remove) [done]
10. 重构Runtime Lifecycle [done]
11. Agent Lifecycle 以及 确保workdir可用 [done]
12. docker cp 的属主权限不对，考虑使用tar传输文件/文件夹，或者runtime支持用户管理（可以通过exec获取默认uid/gid） [done]
13. 如cursor的rules文件后缀应该是.mdc， 需要考虑这种兼容性 [done] 重构了skills和rules的安装
14. Harness Install [done]
15. 增加/完善测试 [done]
16. DockerRuntime支持设置为非root用户 [done]
17. Hitch(yml) [done]
18. saddler资源支持元数据（扩展hitch） [done]
19. Storage重构成一等公民 [done]
- 增加mount快速挂载本地目录 [done]
- 子命令简写 runtime -> rt storage -> st, 其他部分关键参数添加短参数支持 [done]



- hitch 增强
- Saddler接口化，Hitch使用Saddler接口
- 考虑使用sqlite管理状态 [不做]
- ACP bridge(不应该在saddler)

- [bug] runtime rm 未支持前缀匹配 [fixed]
- [bug] ensure harness 失败时，agent 记录仍然被创建了
- [bug] hitch 没有正确的 workdir 校验

# 大规模架构重构

- 分层
CLI 层 - API 层 - 应用层 - Domain层 - 存储层（持久化）

## Domain Model/Concept/Entity

主要分为4类:
- Entity: 有身份和生命周期
- Value: 如Config （描述值）
- Service: 跨对象的复杂业务逻辑(放不进Entity的规则)
- Interface: 外部能力抽象
一些补充的建模概念:
- Relationship: 关系, 描述实体间的关联，具体可能时隐式的或显式的，或者实体
- Index: 关系的反向索引


### Storage

Storage (Entity) 存储实体，可以被挂载到Runtime
|-- Id (Value) 存储ID
|-- Name (Value) 存储名称
|-- Metadata (Value) 元信息
|-- Spec (Value) 存储定义，描述存储是什么， immutable
    |-- Type 存储类型
    |-- ...  类型特定的存储属性
|-- MountedBy (Index) 挂载索引，描述存储被哪些Runtime挂载

### Storage Service

StorageService (Service) 存储服务，描述存储相关的业务方法
|-- Create (Method) 创建存储
|-- Remove (Method) 删除存储
|-- List (Method) 列出存储
|-- Get (Method) 获取存储

### Runtime

Runtime (Entity) 运行时实体，会被Agent使用
|-- Id (Value) 运行时ID
|-- Name (Value) 运行时名称
|-- Metadata (Value) 元信息
|-- Spec (Value) 运行时定义
    |-- Type 运行时类型
    |-- Env  运行时环境变量
    |-- ...  类型特定的运行时属性
|-- State (Value) 运行时状态
    |-- Status 运行时当前状态, Created/Running/Stopped/Removed
    |-- ... 类型特定的运行时状态
|-- RuntimeAdapter 使用的RuntimeAdapter (从State反序列化)
|-- Mounts (Relationship) 挂载记录, 记录运行时挂载了哪些存储
|-- UsedBy (Index) 使用索引，描述Runtime被哪些Agent使用

### RuntimeAdapter

RuntimeAdapter (Interface) 运行时适配器接口，描述运行时能力, 每种类型的Runtime都必须实现这些能力
|-- Create (Method) 创建运行时
|-- Start (Method) 启动运行时
|-- Stop (Method) 停止运行时
|-- Remove (Method) 删除运行时
|-- Exec (Method) 执行命令
|-- Exec_BG (Method) 后台执行命令(脱离saddler)
|-- Exec_FG (Method) 前台执行命令(在saddler中执行)
|-- CopyTo (Method) 复制文件到运行时
|-- CopyFrom (Method) 从运行时复制文件
|-- ...  其他运行时能力

### RuntimeService

RuntimeService (Service) 运行时服务，描述运行时相关的业务方法
|-- Create (Method) 创建运行时(实体)
|-- Remove (Method) 删除运行时(实体)
|-- List (Method) 列出运行时
|-- Get (Method) 获取运行时

### Harness

HarnessAdapter (Interface)  harness 适配器接口，描述harness能力, 每种类型的Harness都必须实现这些能力
|-- Install (Method) 安装harness
|-- InstallRules (Method) 安装规则
|-- InstallSkills (Method) 安装技能
|-- ListSkills (method) 列出安装的技能
|-- ListRules (method) 列出安装的规则
|-- TUI (Method) 显示harness的交互式界面
|-- ACP (Method) 启动ACP通信进程

### Agent

Agent (Entity) 代理实体，被用户使用
|-- Id (Value) 代理ID
|-- Name (Value) 代理名称
|-- Metadata (Value) 元信息
|-- Runtime 使用的Runtime
|-- Spec (Value) 代理定义
    |-- Harness 使用的harness
    |-- Workdir 工作目录
    |-- Role 角色定义 (一个特殊的Rule)
    |-- Skill 技能定义
    |-- Rule 安装的规则
|-- State (Value) 代理状态
    |-- Sessions 代理会话
    |-- ... 类型特定的代理状态
|-- HarnessAdapter 使用的HarnessAdapter(从State反序列化)

### AgentService

AgentService (Service) 代理服务，描述代理相关的业务方法
|-- Create (Method) 创建代理
|-- Remove (Method) 删除代理
|-- List (Method) 列出代理
|-- Get (Method) 获取代理