"""Worker coordination layer — manages worker subprocesses."""
