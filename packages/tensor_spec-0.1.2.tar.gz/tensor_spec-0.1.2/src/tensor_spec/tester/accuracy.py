"""AccuracyTester: dual-backend cross-framework accuracy comparison."""

from __future__ import annotations

import time
from typing import Any

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import APIMapping, MappingRegistry
from tensor_spec.tester.base import GeneratedInputs, TensorInputPlan, TesterBase, TestResult, TestStatus
from tensor_spec_worker.backend.base import BackendBase


class BackendError(Exception):
    """Raised when a specific backend fails during execution."""

    def __init__(self, backend_name: str, original: Exception) -> None:
        self.backend_name = backend_name
        self.original = original
        super().__init__(f"{backend_name} error: {original}")


class AccuracyTester(TesterBase):
    """Runs the same API on two backends and compares outputs for accuracy."""

    def __init__(
        self,
        backend_a: BackendBase,
        backend_b: BackendBase,
        mapping: MappingRegistry,
        comparator: NumpyComparator,
        tolerance: Tolerance,
        generator: TensorGenerator,
    ) -> None:
        super().__init__(generator)
        self.backend_a = backend_a
        self.backend_b = backend_b
        self.mapping = mapping
        self.comparator = comparator
        self.tolerance = tolerance

    def test(self, case: CaseConfig) -> TestResult:
        """Override template to handle BackendError specifically."""
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except BackendError as e:
            status = self._backend_error_status(e.backend_name)
            return TestResult(
                case=case,
                status=status,
                error=str(e.original),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except MemoryError as e:
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute the API on both backends and return their outputs."""
        # Backend A
        a_mapping, a_args, a_kwargs = self._prepare_call(case, inputs, self.backend_a)
        try:
            output_a = self.backend_a.exec_api(a_mapping.api, a_args, a_kwargs, a_mapping.to_payload())
            self.backend_a.check_cuda_error()
        except Exception as e:
            raise BackendError(self.backend_a.name, e) from e
        self.backend_a.empty_cache()

        # Backend B
        b_mapping, b_args, b_kwargs = self._prepare_call(case, inputs, self.backend_b)
        try:
            output_b = self.backend_b.exec_api(b_mapping.api, b_args, b_kwargs, b_mapping.to_payload())
            self.backend_b.check_cuda_error()
        except Exception as e:
            raise BackendError(self.backend_b.name, e) from e

        return {"a_output": output_a, "b_output": output_b}

    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """Convert outputs to numpy and compare with tolerance."""
        np_a = self.backend_a.tensor_to_numpy(outputs["a_output"])
        np_b = self.backend_b.tensor_to_numpy(outputs["b_output"])
        tol = self.tolerance.get(case.api_name)
        cmp_result = self.comparator.compare(np_a, np_b, tol)
        status = TestStatus.PASSED if cmp_result.passed else TestStatus.ACCURACY_ERROR
        return TestResult(case=case, status=status, compare_result=cmp_result)

    def _prepare_call(
        self,
        case: CaseConfig,
        inputs: GeneratedInputs,
        backend: BackendBase,
    ) -> tuple[APIMapping, tuple[Any, ...], dict[str, Any]]:
        """Prepare API call arguments for a specific backend."""
        mapping = self.mapping.resolve(case.api_name, backend.name)
        args = [
            self._materialize_input_value(value, lambda plan: self._build_backend_tensor(plan, backend))
            for value in inputs.args
        ]
        kwargs = {
            key: self._materialize_input_value(value, lambda plan: self._build_backend_tensor(plan, backend))
            for key, value in inputs.kwargs.items()
        }
        return mapping, tuple(args), kwargs

    def _build_backend_tensor(self, plan: TensorInputPlan, backend: BackendBase) -> Any:
        if plan.array is not None:
            return backend.numpy_to_tensor(plan.array, plan.spec)
        return backend.generate_tensor(plan.spec, self._generator.seed, plan.ordinal)

    def _backend_error_status(self, backend_name: str) -> TestStatus:
        """Map backend name to the appropriate error status."""
        return TestStatus.BACKEND_ERROR
