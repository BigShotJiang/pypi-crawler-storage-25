"""IsolatedAccuracyTester: process-isolated multi-backend accuracy comparison."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any

import numpy as np
from loguru import logger

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.tester.base import GeneratedInputs, TensorInputPlan, TesterBase, TestResult, TestStatus
from tensor_spec.worker.coordinator import Coordinator


class IsolatedAccuracyTester(TesterBase):
    """Runs accuracy comparison across N backends in separate subprocesses.

    The first backend is the reference; all others are compared against it.
    """

    def __init__(
        self,
        backends: list[tuple[str, str, str]],
        mapping: MappingRegistry,
        comparator: NumpyComparator,
        tolerance: Tolerance,
        generator: TensorGenerator,
        gpu_comparators: tuple[str, ...] = ("torch", "jax", "paddle"),
    ) -> None:
        """Initialize with a list of (worker_name, python_path, backend_name) tuples."""
        super().__init__(generator)
        if len(backends) < 2:
            raise ValueError("IsolatedAccuracyTester requires at least 2 backends")
        self._backends = backends  # [(worker_name, python_path, backend_name), ...]
        self._mapping = mapping
        self._comparator = comparator
        self._tolerance = tolerance
        self._gpu_comparators = gpu_comparators
        self._coordinator = Coordinator()
        self._coordinator.start_workers_parallel(
            [(name, python_path, backend_name) for name, python_path, backend_name in backends]
        )
        self._backend_capabilities = {
            name: self._coordinator.get_backend_info(name) for name, _python_path, _backend_name in backends
        }

    def shutdown(self) -> None:
        """Shutdown worker processes."""
        self._coordinator.shutdown_all()

    def test(self, case: CaseConfig) -> TestResult:
        """Override template to handle subprocess errors."""
        logger.info("Testing {} ...", case.api_name)
        start = time.perf_counter()
        outputs: dict[str, WorkerTensorRef] = {}
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "{} -> {} ({:.0f}ms)",
                case.api_name,
                result.status.value,
                result.duration_ms,
            )
            return result
        except _WorkerBackendError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.warning("{} -> backend_error : {}", case.api_name, e.message)
            return TestResult(
                case=case,
                status=TestStatus.BACKEND_ERROR,
                error=f"[{e.backend_name}] {e.message}",
                duration_ms=dur,
            )
        except MemoryError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> OOM: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=dur,
            )
        except Exception as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> error: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=dur,
            )
        finally:
            self._free_outputs(outputs)

    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, WorkerTensorRef]:
        """Execute the API on all workers and return output tensor refs keyed by worker name."""
        results: dict[str, WorkerTensorRef] = {}
        for worker_name, _python_path, backend_name in self._backends:
            output_ref = self._execute_on_worker(worker_name, backend_name, case, inputs)
            self._coordinator.empty_cache(worker_name)
            results[worker_name] = output_ref
        return results

    def compare(self, case: CaseConfig, outputs: dict[str, WorkerTensorRef]) -> TestResult:
        """Compare all worker outputs against the first (reference) worker."""
        tol = self._tolerance.get(case.api_name)
        ref_name = self._backends[0][0]
        ref_output = outputs[ref_name]
        cached_numpy: dict[str, np.ndarray] = {}
        last_result: CompareResult | None = None

        for worker_name, _python_path, backend_name in self._backends[1:]:
            cmp_result = self._compare_pair(ref_output, outputs[worker_name], tol.atol, tol.rtol, cached_numpy)
            last_result = cmp_result
            if not cmp_result.passed:
                return TestResult(
                    case=case,
                    status=TestStatus.ACCURACY_ERROR,
                    compare_result=cmp_result,
                    error=f"Mismatch: {self._backends[0][2]} vs {backend_name}",
                )

        if last_result is None:
            last_result = CompareResult(passed=True)
        return TestResult(case=case, status=TestStatus.PASSED, compare_result=last_result)

    def _execute_on_worker(
        self,
        worker_name: str,
        backend_name: str,
        case: CaseConfig,
        inputs: GeneratedInputs,
    ) -> WorkerTensorRef:
        """Send data to a worker, execute API, and keep the output tensor in-worker."""
        coord = self._coordinator
        mapping = self._mapping.resolve(case.api_name, backend_name)

        arg_refs = [
            self._materialize_input_value(value, lambda plan: self._send_input_tensor(worker_name, plan))
            for value in inputs.args
        ]
        kwarg_refs = {
            key: self._materialize_input_value(value, lambda plan: self._send_input_tensor(worker_name, plan))
            for key, value in inputs.kwargs.items()
        }

        # Execute
        try:
            result_tid = coord.exec_api(
                worker_name,
                mapping.api,
                list(arg_refs),
                kwarg_refs,
                mapping.to_payload(),
            )
            coord.check_cuda_error(worker_name)
            info = coord.get_tensor_info(worker_name, result_tid)
        except RuntimeError as e:
            raise _WorkerBackendError(backend_name, str(e)) from e
        finally:
            self._free_tensor_refs(worker_name, arg_refs)
            self._free_tensor_refs(worker_name, list(kwarg_refs.values()))

        return WorkerTensorRef(
            worker_name=worker_name,
            backend_name=backend_name,
            tensor_id=result_tid,
            shape=tuple(info["shape"]),
            dtype=info["dtype"],
            device=info["device"],
        )

    def _send_input_tensor(self, worker_name: str, plan: TensorInputPlan) -> str:
        if plan.array is not None:
            return self._coordinator.send_numpy(worker_name, plan.array, plan.spec)
        return self._coordinator.generate_tensor(worker_name, plan.spec, self._generator.seed, plan.ordinal)

    def _compare_pair(
        self,
        ref_output: WorkerTensorRef,
        other_output: WorkerTensorRef,
        atol: float,
        rtol: float,
        cached_numpy: dict[str, np.ndarray],
    ) -> CompareResult:
        comparator_worker = self._select_comparator_worker(ref_output, other_output)
        if comparator_worker is not None:
            try:
                logger.debug(
                    "Comparing on GPU via {} ({} vs {})",
                    comparator_worker,
                    ref_output.backend_name,
                    other_output.backend_name,
                )
                return self._compare_on_gpu(ref_output, other_output, comparator_worker, atol, rtol)
            except RuntimeError as e:
                logger.debug("GPU compare unavailable, falling back to numpy: {}", e)
        logger.debug("Comparing via numpy fallback ({} vs {})", ref_output.backend_name, other_output.backend_name)
        return self._compare_on_cpu(ref_output, other_output, atol, rtol, cached_numpy)

    def _select_comparator_worker(
        self,
        ref_output: WorkerTensorRef,
        other_output: WorkerTensorRef,
    ) -> str | None:
        if not (ref_output.device.startswith("cuda:") and other_output.device.startswith("cuda:")):
            return None
        participants = {
            ref_output.backend_name: ref_output.worker_name,
            other_output.backend_name: other_output.worker_name,
        }
        for backend_name in self._gpu_comparators:
            worker_name = participants.get(backend_name)
            if worker_name is None:
                continue
            info = self._backend_capabilities.get(worker_name, {})
            if info.get("supports_gpu_compare", False):
                return worker_name
        return None

    def _compare_on_gpu(
        self,
        ref_output: WorkerTensorRef,
        other_output: WorkerTensorRef,
        comparator_worker: str,
        atol: float,
        rtol: float,
    ) -> CompareResult:
        coord = self._coordinator
        if comparator_worker == ref_output.worker_name:
            remote_output = other_output
            actual_tid = ref_output.tensor_id
            expected_tid = None
        else:
            remote_output = ref_output
            actual_tid = None
            expected_tid = other_output.tensor_id

        handle_info = coord.get_ipc_handle(remote_output.worker_name, remote_output.tensor_id)
        imported_tid: str | None = None
        try:
            imported_tid = coord.open_ipc_handle(comparator_worker, handle_info)
            compare_payload = coord.compare_tensors(
                comparator_worker,
                actual_tid or imported_tid,
                expected_tid or imported_tid,
                atol,
                rtol,
            )
            coord.check_cuda_error(comparator_worker)
            return CompareResult(**compare_payload)
        finally:
            if imported_tid is not None:
                coord.close_ipc_handle(comparator_worker, imported_tid)

    def _compare_on_cpu(
        self,
        ref_output: WorkerTensorRef,
        other_output: WorkerTensorRef,
        atol: float,
        rtol: float,
        cached_numpy: dict[str, np.ndarray],
    ) -> CompareResult:
        ref_numpy = self._get_numpy_output(ref_output, cached_numpy)
        other_numpy = self._get_numpy_output(other_output, cached_numpy)
        return self._comparator.compare(ref_numpy, other_numpy, ToleranceConfig(atol=atol, rtol=rtol))

    def _get_numpy_output(self, output: WorkerTensorRef, cached_numpy: dict[str, np.ndarray]) -> np.ndarray:
        cached = cached_numpy.get(output.worker_name)
        if cached is not None:
            return cached
        arr = self._coordinator.get_numpy(output.worker_name, output.tensor_id)
        cached_numpy[output.worker_name] = arr
        return arr

    def _free_tensor_refs(self, worker_name: str, values: list[Any]) -> None:
        for value in values:
            for tensor_id in _iter_tensor_ids(value):
                self._coordinator.free_tensor(worker_name, tensor_id)

    def _free_outputs(self, outputs: dict[str, WorkerTensorRef]) -> None:
        for output in outputs.values():
            self._coordinator.free_tensor(output.worker_name, output.tensor_id)


@dataclass(frozen=True, slots=True)
class WorkerTensorRef:
    worker_name: str
    backend_name: str
    tensor_id: str
    shape: tuple[int, ...]
    dtype: str
    device: str


_TENSOR_ID_PATTERN = re.compile(r"^t\d+$")


def _iter_tensor_ids(value: Any) -> list[str]:
    if isinstance(value, str) and _TENSOR_ID_PATTERN.fullmatch(value):
        return [value]
    if isinstance(value, (tuple, list)):
        tensor_ids: list[str] = []
        for item in value:
            tensor_ids.extend(_iter_tensor_ids(item))
        return tensor_ids
    if isinstance(value, dict):
        tensor_ids: list[str] = []
        for item in value.values():
            tensor_ids.extend(_iter_tensor_ids(item))
        return tensor_ids
    return []


class _WorkerBackendError(Exception):
    """Internal: raised when a worker's exec_api fails."""

    def __init__(self, backend_name: str, message: str) -> None:
        self.backend_name = backend_name
        self.message = message
        super().__init__(f"{backend_name}: {message}")
