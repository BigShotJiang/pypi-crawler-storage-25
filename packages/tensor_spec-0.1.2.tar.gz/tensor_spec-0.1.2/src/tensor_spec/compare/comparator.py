"""Numpy-based comparison for accuracy testing."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from tensor_spec.compare.tolerance import ToleranceConfig


@dataclass(frozen=True, slots=True)
class CompareResult:
    """Structured result of a tensor comparison."""

    passed: bool
    max_abs_diff: float = 0.0
    max_rel_diff: float = 0.0
    mismatched_count: int = 0
    total_count: int = 0
    detail: str = ""


class NumpyComparator:
    """Numpy-based comparator for tensor accuracy testing."""

    def compare(
        self,
        actual: np.ndarray,
        expected: np.ndarray,
        tol: ToleranceConfig,
    ) -> CompareResult:
        if actual.shape != expected.shape:
            return CompareResult(
                passed=False,
                total_count=max(actual.size, expected.size),
                detail=f"Shape mismatch: {actual.shape} vs {expected.shape}",
            )
        if actual.dtype == np.bool_:
            return self._compare_exact(actual, expected)
        return self._compare_close(actual, expected, tol.atol, tol.rtol)

    def _compare_exact(
        self,
        actual: np.ndarray,
        expected: np.ndarray,
    ) -> CompareResult:
        mismatched = int(np.sum(actual != expected))
        return CompareResult(
            passed=mismatched == 0,
            mismatched_count=mismatched,
            total_count=actual.size,
        )

    def _compare_close(
        self,
        actual: np.ndarray,
        expected: np.ndarray,
        atol: float,
        rtol: float,
    ) -> CompareResult:
        a = actual.astype(np.float64)
        b = expected.astype(np.float64)
        abs_diff = np.abs(a - b)
        nan_mask = np.isnan(a) & np.isnan(b)
        non_nan_diff = np.where(nan_mask, 0.0, abs_diff)
        max_abs = float(np.max(non_nan_diff)) if non_nan_diff.size > 0 else 0.0
        denom = np.maximum(np.abs(b), 1e-12)
        max_rel = float(np.max(np.where(nan_mask, 0.0, non_nan_diff / denom)))
        close = np.allclose(a, b, atol=atol, rtol=rtol, equal_nan=True)
        not_close = ~np.isclose(a, b, atol=atol, rtol=rtol, equal_nan=True)
        mismatched = int(np.sum(not_close))
        return CompareResult(
            passed=close,
            max_abs_diff=max_abs,
            max_rel_diff=max_rel,
            mismatched_count=mismatched,
            total_count=actual.size,
        )
