"""tensor-spec: Framework-agnostic deep learning API quality verification tool."""

from tensor_spec._version import __version__, __version_tuple__
