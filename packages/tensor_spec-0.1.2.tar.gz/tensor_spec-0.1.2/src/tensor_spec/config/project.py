"""Project-level configuration: sources, defaults, tolerance, targets, and bench."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Built-in default sources per backend (used by `setup` command)
_BUILTIN_SOURCES: dict[str, dict[str, str]] = {
    "paddle": {
        "index_url": "https://www.paddlepaddle.org.cn/packages/stable/{cuda_version}/",
        "package": "paddlepaddle-gpu",
        "version": "3.3.0",
        "index_strategy": "unsafe-best-match",
    },
    "torch": {
        "index_url": "https://download.pytorch.org/whl/cu128",
        "package": "torch",
        "version": "2.9.1",
        "index_strategy": "unsafe-best-match",
    },
}


@dataclass(frozen=True, slots=True)
class SourceConfig:
    """Installation source configuration for a single framework."""

    index_url: str = ""
    extra_index_url: str = "https://pypi.org/simple/"
    index_strategy: str = ""
    package: str = ""
    version: str = ""
    whl: str = ""
    python_version: str = "3.12"
    cuda_version: str = "cu129"


@dataclass(frozen=True, slots=True)
class TargetConfig:
    """Named target: a backend + optional device + python interpreter."""

    backend: str = ""
    device: str = ""
    python: str = ""


@dataclass(frozen=True, slots=True)
class BenchE2eConfig:
    """e2e benchmark defaults."""

    warmup: int = 5
    repeat: int = 20
    percentiles: tuple[int, ...] = (50, 90, 95, 99)


@dataclass(frozen=True, slots=True)
class BenchNcuConfig:
    """NCU benchmark defaults."""

    metrics: tuple[str, ...] = ("time", "occupancy", "memory_throughput")
    save_artifacts: bool = True


@dataclass(frozen=True, slots=True)
class BenchConfig:
    """Benchmark configuration."""

    mode: str = "e2e"
    artifacts_dir: str = "./.tensor-spec/bench-artifacts"
    e2e: BenchE2eConfig = field(default_factory=BenchE2eConfig)
    ncu: BenchNcuConfig = field(default_factory=BenchNcuConfig)


@dataclass(frozen=True, slots=True)
class DefaultsConfig:
    """CLI default parameters from config file."""

    targets: tuple[str, ...] = ()
    format: str = "human"
    seed: int = 42
    verbose: bool = False


@dataclass(frozen=True, slots=True)
class ProjectConfig:
    """Unified project configuration loaded from tensor-spec.toml."""

    sources: dict[str, SourceConfig] = field(default_factory=dict)
    defaults: DefaultsConfig = field(default_factory=DefaultsConfig)
    targets: dict[str, TargetConfig] = field(default_factory=dict)
    tolerance_data: dict[str, Any] = field(default_factory=dict)
    bench: BenchConfig = field(default_factory=BenchConfig)

    def get_source(self, backend: str) -> SourceConfig:
        """Get source config for a backend, merging with built-in defaults."""
        user = self.sources.get(backend, SourceConfig())
        builtin = _BUILTIN_SOURCES.get(backend, {})

        return SourceConfig(
            index_url=user.index_url or builtin.get("index_url", ""),
            extra_index_url=user.extra_index_url,
            index_strategy=user.index_strategy or builtin.get("index_strategy", ""),
            package=user.package or builtin.get("package", ""),
            version=user.version or builtin.get("version", ""),
            whl=user.whl,
            python_version=user.python_version,
            cuda_version=user.cuda_version,
        )

    def resolve_index_url(self, backend: str) -> str:
        """Resolve index URL with {cuda_version} interpolation."""
        src = self.get_source(backend)
        return src.index_url.format(cuda_version=src.cuda_version)

    def resolve_target(self, name: str) -> TargetConfig:
        """Resolve a named target from config; raise ValueError if not found."""
        if name not in self.targets:
            available = ", ".join(sorted(self.targets)) or "(none)"
            raise ValueError(f"Unknown target '{name}'. Available: {available}")
        return self.targets[name]

    @classmethod
    def from_toml(cls, path: str | Path) -> ProjectConfig:
        """Load ProjectConfig from a TOML file."""
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)

        # Parse [sources.*]
        sources: dict[str, SourceConfig] = {}
        for name, src_data in data.get("sources", {}).items():
            sources[name] = SourceConfig(
                index_url=src_data.get("index_url", ""),
                extra_index_url=src_data.get("extra_index_url", "https://pypi.org/simple/"),
                index_strategy=src_data.get("index_strategy", ""),
                package=src_data.get("package", ""),
                version=src_data.get("version", ""),
                whl=src_data.get("whl", ""),
                python_version=src_data.get("python_version", "3.12"),
                cuda_version=src_data.get("cuda_version", "cu129"),
            )

        # Parse [defaults]
        defaults_data = data.get("defaults", {})
        targets_list = defaults_data.get("targets", [])
        defaults = DefaultsConfig(
            targets=tuple(targets_list),
            format=defaults_data.get("format", "human"),
            seed=defaults_data.get("seed", 42),
            verbose=defaults_data.get("verbose", False),
        )

        # Parse [targets.*]
        targets: dict[str, TargetConfig] = {}
        for name, tgt_data in data.get("targets", {}).items():
            targets[name] = TargetConfig(
                backend=tgt_data.get("backend", ""),
                device=tgt_data.get("device", ""),
                python=tgt_data.get("python", ""),
            )

        # Pass [tolerance] through as raw dict for Tolerance.from_dict()
        tolerance_data = data.get("tolerance", {})

        # Parse [bench]
        bench_data = data.get("bench", {})
        e2e_data = bench_data.get("e2e", {})
        ncu_data = bench_data.get("ncu", {})
        bench = BenchConfig(
            mode=bench_data.get("mode", "e2e"),
            artifacts_dir=bench_data.get("artifacts_dir", "./.tensor-spec/bench-artifacts"),
            e2e=BenchE2eConfig(
                warmup=e2e_data.get("warmup", 5),
                repeat=e2e_data.get("repeat", 20),
                percentiles=tuple(e2e_data.get("percentiles", [50, 90, 95, 99])),
            ),
            ncu=BenchNcuConfig(
                metrics=tuple(ncu_data.get("metrics", ["time", "occupancy", "memory_throughput"])),
                save_artifacts=ncu_data.get("save_artifacts", True),
            ),
        )

        return cls(
            sources=sources,
            defaults=defaults,
            targets=targets,
            tolerance_data=tolerance_data,
            bench=bench,
        )

    @classmethod
    def find_and_load(cls, start_dir: str | Path | None = None) -> ProjectConfig | None:
        """Walk up from start_dir looking for tensor-spec.toml; return None if not found."""
        current = Path(start_dir) if start_dir else Path.cwd()
        current = current.resolve()

        for directory in [current, *current.parents]:
            candidate = directory / "tensor-spec.toml"
            if candidate.is_file():
                return cls.from_toml(candidate)

        return None
