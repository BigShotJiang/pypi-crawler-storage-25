"""CaseConfig: represents a single API test case."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tensor_spec_core.tensor import TensorSpec


@dataclass(frozen=True, slots=True)
class CaseConfig:
    """A single API test case configuration.

    Attributes:
        api_name: Framework-agnostic API name (e.g., "abs", "nn.conv2d").
        args: Positional arguments (tuple of TensorSpec, scalars, etc.).
        kwargs: Keyword arguments (dict of name -> TensorSpec, scalars, etc.).
    """

    api_name: str
    args: tuple[Any, ...]
    kwargs: dict[str, Any]

    @property
    def tensor_specs(self) -> dict[str, TensorSpec]:
        """Extract all TensorSpec values from kwargs."""
        return {k: v for k, v in self.kwargs.items() if isinstance(v, TensorSpec)}
