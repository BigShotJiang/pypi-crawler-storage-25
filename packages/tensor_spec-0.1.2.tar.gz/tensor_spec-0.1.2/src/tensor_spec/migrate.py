"""Helpers for migrating legacy PaddleAPITest text cases."""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path

_EMPTY_LIST_PATTERN = re.compile(r"\blist\s*\[\s*\]")
_PRESERVED_TENSOR_APIS = {"Tensor.__getitem__", "Tensor.set_"}
_API_ALIASES = {
    "Tensor.__add__": "add",
    "Tensor.__matmul__": "matmul",
    "Tensor.__mod__": "remainder",
    "Tensor.__mul__": "multiply",
    "Tensor.__truediv__": "divide",
    "Tensor.norm": "linalg.norm",
    "mod": "remainder",
}


class MigrationError(ValueError):
    """Raised when a legacy case cannot be translated into tensor-spec syntax."""


@dataclass(frozen=True, slots=True)
class MigrationSummary:
    """Streaming migration result for a legacy case file."""

    total_lines: int
    migrated_cases: int
    rejected_cases: int
    rejects_path: Path | None


def migrate_case_line(case_str: str) -> str:
    """Translate a single PaddleAPITest case string into tensor-spec syntax."""
    stripped = case_str.strip()
    if not stripped:
        raise MigrationError("Empty case string")

    normalized = _EMPTY_LIST_PATTERN.sub("[]", stripped)
    try:
        expr = ast.parse(normalized, mode="eval").body
    except SyntaxError as exc:
        raise MigrationError(f"Invalid legacy syntax: {exc.msg}") from exc

    if not isinstance(expr, ast.Call):
        raise MigrationError("Legacy case must be a function call")

    api_name = _normalize_api_name(_render_dotted_name(expr.func))
    positional_args = list(expr.args)
    while positional_args and _is_legacy_name_placeholder(positional_args[-1]):
        positional_args.pop()

    rendered_args = [_render_value(arg) for arg in positional_args]
    rendered_kwargs = []
    for kw in expr.keywords:
        if kw.arg is None:
            raise MigrationError("Star-kwargs are not supported")
        if kw.arg == "name":
            continue
        rendered_kwargs.append(f"{kw.arg}={_render_value(kw.value)}")

    pieces = rendered_args + rendered_kwargs
    return f"{api_name}({', '.join(pieces)})"


def migrate_case_file(input_path: Path, output_path: Path, rejects_path: Path | None = None) -> MigrationSummary:
    """Stream a legacy PaddleAPITest text file into tensor-spec text syntax."""
    input_path = input_path.expanduser()
    output_path = output_path.expanduser()
    rejects_path = (
        rejects_path.expanduser()
        if rejects_path is not None
        else output_path.with_suffix(output_path.suffix + ".rejects.txt")
    )

    if input_path.resolve() == output_path.resolve():
        raise ValueError("Input and output paths must be different")
    if output_path.resolve() == rejects_path.resolve():
        raise ValueError("Output and rejects paths must be different")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    rejects_path.parent.mkdir(parents=True, exist_ok=True)

    total_lines = 0
    migrated_cases = 0
    rejected_cases = 0
    wrote_rejects = False

    with (
        input_path.open("r", encoding="utf-8", errors="replace") as src,
        output_path.open("w", encoding="utf-8") as dst,
        rejects_path.open("w", encoding="utf-8") as reject_dst,
    ):
        for line_no, raw_line in enumerate(src, start=1):
            total_lines += 1
            stripped = raw_line.strip()

            if not stripped:
                dst.write("\n")
                continue
            if stripped.startswith("#"):
                dst.write(raw_line if raw_line.endswith("\n") else raw_line + "\n")
                continue

            try:
                migrated = migrate_case_line(stripped)
            except MigrationError as exc:
                rejected_cases += 1
                wrote_rejects = True
                reject_dst.write(f"{line_no}\t{exc}\t{stripped}\n")
                continue

            dst.write(migrated + "\n")
            migrated_cases += 1

    final_rejects_path: Path | None = rejects_path if wrote_rejects else None
    if final_rejects_path is None:
        rejects_path.unlink(missing_ok=True)

    return MigrationSummary(
        total_lines=total_lines,
        migrated_cases=migrated_cases,
        rejected_cases=rejected_cases,
        rejects_path=final_rejects_path,
    )


def _normalize_api_name(api_name: str) -> str:
    if api_name.startswith("paddle."):
        api_name = api_name.removeprefix("paddle.")
    if api_name in _API_ALIASES:
        return _API_ALIASES[api_name]
    if api_name.startswith("Tensor.") and api_name not in _PRESERVED_TENSOR_APIS:
        return api_name.removeprefix("Tensor.")
    return api_name


def _is_legacy_name_placeholder(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and node.value is None


def _render_dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{_render_dotted_name(node.value)}.{node.attr}"
    raise MigrationError(f"Unsupported function reference: {ast.dump(node, include_attributes=False)}")


def _render_value(node: ast.AST) -> str:
    if isinstance(node, ast.Constant):
        return _render_constant(node.value)

    if isinstance(node, ast.Attribute):
        return _render_attribute_value(node)

    if isinstance(node, ast.Name):
        if node.id in {"None", "True", "False"}:
            return node.id
        raise MigrationError(f"Unsupported bare identifier '{node.id}'")

    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return f"-{_render_value(node.operand)}"

    if isinstance(node, ast.List):
        return f"[{', '.join(_render_value(elt) for elt in node.elts)}]"

    if isinstance(node, ast.Tuple):
        return f"({', '.join(_render_value(elt) for elt in node.elts)})"

    if isinstance(node, ast.Subscript):
        return _render_subscript(node)

    if isinstance(node, ast.Call):
        return _render_call_value(node)

    raise MigrationError(f"Unsupported value node: {ast.dump(node, include_attributes=False)}")


def _render_constant(value: object) -> str:
    if value is None:
        return "None"
    if isinstance(value, bool):
        return "True" if value else "False"
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, int | float):
        return repr(value)
    raise MigrationError(f"Unsupported constant value: {value!r}")


def _render_subscript(node: ast.Subscript) -> str:
    if isinstance(node.value, ast.Name) and node.value.id == "list":
        elements = node.slice.elts if isinstance(node.slice, ast.Tuple) else [node.slice]
        return f"[{', '.join(_render_value(elt) for elt in elements)}]"
    raise MigrationError(f"Unsupported subscript value: {ast.dump(node, include_attributes=False)}")


def _render_call_value(node: ast.Call) -> str:
    func_name = _render_dotted_name(node.func)

    if func_name == "Tensor":
        return _render_legacy_tensor(node)

    if func_name in {"Dtype", "VarType", "type"}:
        return _render_dtype_value(node)

    if func_name == "complex":
        pieces = [_render_value(arg) for arg in node.args]
        return f"complex({', '.join(pieces)})"

    if func_name in {"tuple", "list", "slice"}:
        pieces = [_render_value(arg) for arg in node.args]
        for kw in node.keywords:
            if kw.arg is None:
                raise MigrationError("Star-kwargs are not supported inside nested constructors")
            pieces.append(f"{kw.arg}={_render_value(kw.value)}")
        return f"{func_name}({', '.join(pieces)})"

    raise MigrationError(f"Unsupported nested call '{func_name}'")


def _render_legacy_tensor(node: ast.Call) -> str:
    if len(node.args) < 2:
        raise MigrationError("Legacy Tensor() must include shape and dtype")
    if node.keywords:
        raise MigrationError("Legacy Tensor() keyword arguments are not supported")

    shape_arg = node.args[0]
    dtype_arg = node.args[1]
    if not isinstance(dtype_arg, ast.Constant) or not isinstance(dtype_arg.value, str):
        raise MigrationError("Legacy Tensor() dtype must be a string literal")

    shape = _render_shape(shape_arg)
    return f"Tensor.{dtype_arg.value}({shape})"


def _render_shape(node: ast.AST) -> str:
    if isinstance(node, ast.List):
        return f"({', '.join(_render_value(elt) for elt in node.elts)})"
    if isinstance(node, ast.Tuple):
        return f"({', '.join(_render_value(elt) for elt in node.elts)})"
    dump = ast.dump(node, include_attributes=False)
    raise MigrationError(f"Legacy Tensor() shape must be a list or tuple, got {dump}")


def _render_attribute_value(node: ast.Attribute) -> str:
    attr_name = _render_dotted_name(node)
    if attr_name == "math.inf":
        return "1e309"
    raise MigrationError(f"Unsupported attribute value '{attr_name}'")


def _render_dtype_value(node: ast.Call) -> str:
    if len(node.args) != 1 or node.keywords:
        raise MigrationError("Legacy dtype wrappers must take exactly one positional argument")

    arg = node.args[0]
    if isinstance(arg, ast.Name):
        return f'"{arg.id}"'
    if isinstance(arg, ast.Attribute):
        return f'"{arg.attr}"'
    raise MigrationError(f"Unsupported dtype wrapper argument: {ast.dump(arg, include_attributes=False)}")
