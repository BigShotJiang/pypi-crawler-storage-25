"""Data generation layer: TensorSpec -> numpy arrays."""
