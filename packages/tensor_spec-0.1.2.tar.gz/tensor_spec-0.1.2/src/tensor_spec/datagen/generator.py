"""TensorSpec -> numpy array generator with constraint pipeline."""

from __future__ import annotations

import secrets

import numpy as np

from tensor_spec.datagen.constraints import (
    Constraint,
    NonZeroConstraint,
    PositiveDefiniteConstraint,
)
from tensor_spec_core.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec_core.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    TensorSpec,
)

_NUMPY_DTYPE: dict[str, str] = {
    "float16": "float16",
    "float32": "float32",
    "float64": "float64",
    "bfloat16": "float32",  # numpy doesn't support bfloat16; generate as float32
    "int8": "int8",
    "int16": "int16",
    "int32": "int32",
    "int64": "int64",
    "uint8": "uint8",
    "bool": "bool",
    "complex64": "complex64",
    "complex128": "complex128",
}


class TensorGenerator:
    """Generates numpy arrays from TensorSpec instances."""

    def __init__(self, seed: int | None = None) -> None:
        self._seed = seed if seed is not None else secrets.randbits(63)
        self._rng = np.random.default_rng(self._seed)

    @property
    def seed(self) -> int:
        return self._seed

    def generate(self, spec: TensorSpec) -> np.ndarray:
        if isinstance(spec, FloatTensorSpec):
            return self._gen_float(spec)
        if isinstance(spec, IntTensorSpec):
            return self._gen_int(spec)
        if isinstance(spec, BoolTensorSpec):
            return self._gen_bool(spec)
        if isinstance(spec, ComplexTensorSpec):
            return self._gen_complex(spec)
        raise TypeError(f"Unsupported spec type: {type(spec).__name__}")

    def _gen_float(self, spec: FloatTensorSpec) -> np.ndarray:
        stats = spec.stats or FloatStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        data = self._rng.uniform(stats.min, stats.max, spec.shape).astype(np_dtype)
        for constraint in self._float_constraints(stats):
            data = constraint.apply(data)
        return data

    def _gen_int(self, spec: IntTensorSpec) -> np.ndarray:
        stats = spec.stats or IntStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        data = self._rng.integers(stats.low, stats.high, size=spec.shape, dtype=np_dtype)
        if stats.nonzero:
            data = NonZeroConstraint().apply(data)
        return data

    def _gen_bool(self, spec: BoolTensorSpec) -> np.ndarray:
        stats = spec.stats or BoolStats()
        if stats.all_true:
            return np.ones(spec.shape, dtype=np.bool_)
        if stats.all_false:
            return np.zeros(spec.shape, dtype=np.bool_)
        return self._rng.random(spec.shape) < stats.true_ratio

    def _gen_complex(self, spec: ComplexTensorSpec) -> np.ndarray:
        stats = spec.stats or ComplexStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        real = self._rng.uniform(stats.real_min, stats.real_max, spec.shape)
        imag = self._rng.uniform(stats.imag_min, stats.imag_max, spec.shape)
        return (real + 1j * imag).astype(np_dtype)

    def _float_constraints(self, stats: FloatStats) -> list[Constraint]:
        constraints: list[Constraint] = []
        if stats.positive_definite:
            constraints.append(PositiveDefiniteConstraint())
        if stats.nonzero:
            constraints.append(NonZeroConstraint())
        return constraints
