"""NCU profiling support for bench --mode ncu."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from rich.table import Table

from tensor_spec.bench.common import (
    BenchModeContext,
    BenchModeOutcome,
    BenchOutcomeKind,
    ThresholdRule,
    apply_target_device,
)
from tensor_spec.config.case import CaseConfig
from tensor_spec.mapping.registry import APIMapping
from tensor_spec.ui.console import console
from tensor_spec_core.tensor import TensorSpec
from tensor_spec_worker.protocol import encode_arg_value
from tensor_spec_worker.spec_codec import encode_spec

_NCU_METRIC_SPECS: dict[str, str] = {
    "time": "gpu__time_duration.sum",
    "occupancy": "sm__warps_active.avg.pct_of_peak_sustained_active",
    "memory_throughput": "dram__throughput.avg.pct_of_peak_sustained_elapsed",
}

_NCU_METRIC_ALIASES: dict[str, tuple[str, ...]] = {
    "time": ("gpu__time_duration.sum",),
    "occupancy": ("sm__warps_active.avg.pct_of_peak_sustained_active",),
    "memory_throughput": (
        "dram__throughput.avg.pct_of_peak_sustained_elapsed",
        "gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed",
    ),
}


@dataclass(frozen=True, slots=True)
class NcuMetrics:
    """Aggregated NCU metrics for one case execution."""

    time_ms: float
    occupancy_pct: float
    memory_throughput_pct: float


@dataclass(frozen=True, slots=True)
class NcuCaseResult:
    """Structured result of profiling one case on one target."""

    case: CaseConfig
    target_name: str
    metrics: NcuMetrics
    artifact_path: Path | None = None


class NcuRunner:
    """Run a single case under Nsight Compute and parse raw CSV metrics."""

    def __init__(
        self,
        *,
        python_path: str,
        backend_name: str,
        metrics: tuple[str, ...],
        artifacts_dir: str,
        save_artifacts: bool,
    ) -> None:
        self.python_path = python_path
        self.backend_name = backend_name
        self.metrics = metrics
        self.artifacts_dir = Path(artifacts_dir)
        self.save_artifacts = save_artifacts

    def run(
        self,
        case: CaseConfig,
        *,
        target_name: str,
        mapping: APIMapping,
        seed: int,
    ) -> NcuCaseResult:
        payload = _build_payload(case, mapping=mapping, seed=seed)
        artifact_base = self._artifact_base(case, target_name)
        artifact_path = artifact_base.with_suffix(".ncu-rep") if self.save_artifacts else None

        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as payload_file:
            payload_path = Path(payload_file.name)
            json.dump(payload, payload_file)

        try:
            command = [
                "ncu",
                "--target-processes",
                "application-only",
                "--profile-from-start",
                "off",
                "--page",
                "raw",
                "--csv",
                "--force-overwrite",
                "--metrics",
                ",".join(resolve_metric_names(self.metrics)),
            ]
            if artifact_path is not None:
                artifact_path.parent.mkdir(parents=True, exist_ok=True)
                command.extend(["--export", str(artifact_base)])
            command.extend(
                [
                    self.python_path,
                    "-m",
                    "tensor_spec_worker.ncu_runner",
                    "--backend",
                    self.backend_name,
                    "--payload",
                    str(payload_path),
                ]
            )

            proc = subprocess.run(command, capture_output=True, text=True, check=False)
            if proc.returncode != 0:
                detail = proc.stderr.strip() or proc.stdout.strip() or f"ncu exited with status {proc.returncode}"
                raise RuntimeError(f"ncu profiling failed: {detail}")

            if artifact_path is not None:
                artifact_base.with_suffix(".csv").write_text(proc.stdout)

            return NcuCaseResult(
                case=case,
                target_name=target_name,
                metrics=parse_ncu_csv(proc.stdout),
                artifact_path=artifact_path,
            )
        finally:
            payload_path.unlink(missing_ok=True)

    def _artifact_base(self, case: CaseConfig, target_name: str) -> Path:
        slug = slugify(target_name)
        case_slug = slugify(case.api_name)
        digest = hashlib.md5(
            f"{target_name}\0{case.api_name}\0{self.backend_name}".encode(),
            usedforsecurity=False,
        ).hexdigest()[:8]
        return self.artifacts_dir / "ncu" / slug / f"{case_slug}-{digest}"


def resolve_metric_names(metrics: tuple[str, ...]) -> list[str]:
    """Map friendly metric names to concrete NCU metric identifiers."""
    names: list[str] = []
    for metric in metrics:
        if metric not in _NCU_METRIC_SPECS:
            supported = ", ".join(sorted(_NCU_METRIC_SPECS))
            raise ValueError(f"Unsupported NCU metric '{metric}'. Supported: {supported}")
        names.append(_NCU_METRIC_SPECS[metric])
    return names


def parse_ncu_csv(raw_csv: str) -> NcuMetrics:
    """Parse raw CSV output from `ncu --page raw --csv`."""
    if "==WARNING== No kernels were profiled." in raw_csv:
        raise ValueError("NCU did not profile any GPU kernels; ensure the case actually runs on CUDA")

    csv_lines = iter_csv_lines(raw_csv)
    if not csv_lines:
        raise ValueError("NCU output did not contain any CSV data")

    header = next(csv.reader([csv_lines[0]]))
    if "Metric Name" in header and "Metric Value" in header:
        kernels = _parse_metric_rows(csv_lines)
    else:
        kernels = _parse_wide_rows(csv_lines)

    time_metric = _NCU_METRIC_SPECS["time"]
    total_time_ns = sum(kernel.get(time_metric, 0.0) for kernel in kernels.values())
    if total_time_ns <= 0:
        raise ValueError("NCU output did not contain GPU kernel timing data")

    return NcuMetrics(
        time_ms=total_time_ns / 1_000_000.0,
        occupancy_pct=weighted_metric(kernels, _NCU_METRIC_SPECS["occupancy"], total_time_ns),
        memory_throughput_pct=weighted_metric(kernels, _NCU_METRIC_SPECS["memory_throughput"], total_time_ns),
    )


def iter_csv_lines(raw_csv: str) -> list[str]:
    """Filter profiler chatter and return the relevant CSV table."""
    quoted_lines = [line for line in raw_csv.splitlines() if line.startswith('"') and line.strip()]
    if not quoted_lines:
        return []

    for index, line in enumerate(quoted_lines):
        header = next(csv.reader([line]))
        if "ID" not in header:
            continue
        if ("Metric Name" in header and "Metric Value" in header) or _looks_like_wide_metric_table(header):
            return quoted_lines[index:]
    return quoted_lines


def _parse_metric_rows(csv_lines: list[str]) -> dict[str, dict[str, float]]:
    rows = csv.DictReader(csv_lines)
    kernels: dict[str, dict[str, float]] = {}
    for row in rows:
        kernel_id = row.get("ID", "").strip()
        metric_name = row.get("Metric Name", "").strip()
        metric_value = _parse_metric_value(row.get("Metric Value"))
        if not kernel_id or not metric_name or metric_value is None:
            continue
        kernels.setdefault(kernel_id, {})[metric_name] = metric_value
    if not kernels:
        raise ValueError("NCU output did not contain any metric rows")
    return kernels


def _parse_wide_rows(csv_lines: list[str]) -> dict[str, dict[str, float]]:
    rows = list(csv.DictReader(csv_lines))
    if not rows:
        raise ValueError("NCU output did not contain any metric rows")

    kernels: dict[str, dict[str, float]] = {}
    for row in rows:
        kernel_id = (row.get("ID") or "").strip()
        if not kernel_id.isdigit():
            continue
        kernel_metrics = kernels.setdefault(kernel_id, {})
        for metric_name in _all_metric_aliases():
            metric_value = _parse_metric_value(row.get(metric_name))
            if metric_value is not None:
                kernel_metrics[metric_name] = metric_value

    if not kernels:
        raise ValueError("NCU output did not contain any kernel metric rows")
    return kernels


def _looks_like_wide_metric_table(header: list[str]) -> bool:
    return "ID" in header and any(alias in header for alias in _all_metric_aliases())


def _all_metric_aliases() -> tuple[str, ...]:
    aliases: list[str] = []
    for names in _NCU_METRIC_ALIASES.values():
        aliases.extend(names)
    return tuple(aliases)


def _parse_metric_value(value: str | None) -> float | None:
    if value is None:
        return None
    stripped = value.strip()
    if not stripped:
        return None
    return float(stripped)


def weighted_metric(kernels: dict[str, dict[str, float]], metric_name: str, total_time_ns: float) -> float:
    """Compute a GPU-time-weighted average for a kernel metric."""
    weighted_sum = 0.0
    time_metric = _NCU_METRIC_SPECS["time"]
    for kernel in kernels.values():
        time_ns = kernel.get(time_metric, 0.0)
        metric_value = None
        for candidate in _NCU_METRIC_ALIASES[_metric_key(metric_name)]:
            metric_value = kernel.get(candidate)
            if metric_value is not None:
                break
        if metric_value is None or time_ns <= 0:
            continue
        weighted_sum += metric_value * time_ns
    return weighted_sum / total_time_ns if total_time_ns > 0 else 0.0


def _metric_key(metric_name: str) -> str:
    for key, aliases in _NCU_METRIC_ALIASES.items():
        if metric_name in aliases:
            return key
    raise KeyError(f"Unknown metric name: {metric_name}")


def build_payload(case: CaseConfig, *, mapping: APIMapping, seed: int) -> dict[str, Any]:
    """Serialize one case plus mapping metadata for the worker-side NCU harness."""
    next_ordinal = 0

    def encode_value(value: Any) -> Any:
        nonlocal next_ordinal
        if isinstance(value, TensorSpec):
            ordinal = next_ordinal
            next_ordinal += 1
            return {
                "_tensor_spec": encode_spec(value),
                "ordinal": ordinal,
            }
        if isinstance(value, tuple):
            return {"_t": "tuple", "items": [encode_value(item) for item in value]}
        if isinstance(value, list):
            return {"_t": "list", "items": [encode_value(item) for item in value]}
        return encode_arg_value(value)

    return {
        "seed": seed,
        "api": mapping.api,
        "mapping": mapping.to_payload(),
        "args": [encode_value(arg) for arg in case.args],
        "kwargs": {key: encode_value(value) for key, value in case.kwargs.items()},
    }


def slugify(value: str) -> str:
    """Create a filesystem-friendly slug."""
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-")
    return slug or "case"


def baseline_latency_delta_percent(target_ms: float, baseline_ms: float) -> float | None:
    """Return percentage latency delta versus baseline (higher is slower)."""
    if baseline_ms <= 0:
        return None
    return (target_ms - baseline_ms) / baseline_ms * 100.0


def baseline_throughput_delta_percent(target_pct: float, baseline_pct: float) -> float | None:
    """Return percentage throughput delta versus baseline (higher is better)."""
    if baseline_pct <= 0:
        return None
    return (target_pct - baseline_pct) / baseline_pct * 100.0


def format_latency_uplift(target_ms: float, baseline_ms: float) -> str:
    """Format a latency comparison against a baseline."""
    delta = baseline_latency_delta_percent(target_ms, baseline_ms)
    if delta is None:
        return "(baseline)"
    if target_ms <= 0:
        return "(n/a)"
    if delta < 0:
        return f"[green]{baseline_ms / target_ms:.2f}x faster[/]"
    return f"[red]{delta:.0f}% slower[/]"


def format_throughput_uplift(target_pct: float, baseline_pct: float) -> str:
    """Format a throughput comparison against a baseline."""
    delta = baseline_throughput_delta_percent(target_pct, baseline_pct)
    if delta is None:
        return "(baseline)"
    if delta > 0:
        return f"[green]{delta:.0f}% higher[/]"
    if math.isclose(delta, 0.0):
        return "0% change"
    return f"[red]{abs(delta):.0f}% lower[/]"


def validate_ncu_targets(targets) -> None:
    """NCU mode requires every target to resolve to a CUDA device."""
    for target in targets:
        if not target.config.device or "cuda" not in target.config.device.lower():
            device = target.config.device or "(default)"
            raise ValueError(f"NCU mode requires CUDA device, but target '{target.label}' has device='{device}'")


def validate_ncu_threshold_rules(_rules: tuple[ThresholdRule, ...]) -> None:
    """NCU mode accepts the shared latency/throughput threshold grammar."""


def run_ncu_mode(context: BenchModeContext) -> BenchModeOutcome:
    """Execute the NCU benchmark mode."""
    bench_results: dict[str, list[NcuCaseResult]] = {}
    total = len(context.cases)

    for target in context.targets:
        runner = NcuRunner(
            python_path=target.python_path,
            backend_name=target.config.backend,
            metrics=context.bench_config.ncu.metrics,
            artifacts_dir=context.bench_config.artifacts_dir,
            save_artifacts=context.bench_config.ncu.save_artifacts,
        )
        bench_results[target.label] = []
        for idx, case_config in enumerate(context.cases, 1):
            target_case = apply_target_device(case_config, target.config.device)
            console.print(f"  ncu {target_case.api_name} [{idx}/{total}] target={target.label} ...")
            try:
                result = runner.run(
                    target_case,
                    target_name=target.label,
                    mapping=context.mapping.resolve(target_case.api_name, target.config.backend),
                    seed=context.seed,
                )
            except (RuntimeError, ValueError) as err:
                console.print(
                    f"[bold red]error:[/] NCU profiling failed for {target_case.api_name} on {target.label}: {err}"
                )
                return BenchModeOutcome(kind=BenchOutcomeKind.EXEC_FAILURE)
            bench_results[target.label].append(result)
            console.print(
                "    ✓ "
                f"time={result.metrics.time_ms:.3f}ms "
                f"occ={result.metrics.occupancy_pct:.2f}% "
                f"mem={result.metrics.memory_throughput_pct:.2f}%"
            )

    baseline_metrics: dict[str, NcuMetrics] | None = None
    if context.baseline is not None:
        baseline_metrics = {result.case.api_name: result.metrics for result in bench_results[context.baseline]}

    table = Table(title="NCU Results", show_lines=True)
    table.add_column("API", style="cyan")
    table.add_column("Target", style="magenta")
    table.add_column("Time", justify="right")
    table.add_column("Occupancy", justify="right")
    table.add_column("Mem Throughput", justify="right")
    if baseline_metrics is not None:
        table.add_column("Latency vs Baseline", justify="right")
        table.add_column("Throughput vs Baseline", justify="right")

    for target_label, case_results in bench_results.items():
        for result in case_results:
            row = [
                result.case.api_name,
                target_label,
                f"{result.metrics.time_ms:.3f}ms",
                f"{result.metrics.occupancy_pct:.2f}%",
                f"{result.metrics.memory_throughput_pct:.2f}%",
            ]
            if baseline_metrics is not None:
                baseline_result = baseline_metrics.get(result.case.api_name)
                if baseline_result is not None and target_label != context.baseline:
                    row.append(format_latency_uplift(result.metrics.time_ms, baseline_result.time_ms))
                    row.append(
                        format_throughput_uplift(
                            result.metrics.memory_throughput_pct,
                            baseline_result.memory_throughput_pct,
                        )
                    )
                else:
                    row.append("(baseline)")
                    row.append("(baseline)")
            table.add_row(*row)

    console.print(table)

    if context.threshold_rules and baseline_metrics is not None:
        violations: list[str] = []
        for indicator, operator, limit_pct in context.threshold_rules:
            for target_label, case_results in bench_results.items():
                if target_label == context.baseline:
                    continue
                for result in case_results:
                    baseline_result = baseline_metrics.get(result.case.api_name)
                    if baseline_result is None:
                        continue
                    if indicator == "latency":
                        pct_diff = baseline_latency_delta_percent(result.metrics.time_ms, baseline_result.time_ms)
                        if pct_diff is not None and operator == "<=" and pct_diff > limit_pct:
                            violations.append(
                                f"{result.case.api_name} on {target_label}: "
                                f"latency {pct_diff:.1f}% > baseline (threshold: <={limit_pct:.0f}%)"
                            )
                    elif indicator == "throughput":
                        pct_diff = baseline_throughput_delta_percent(
                            result.metrics.memory_throughput_pct,
                            baseline_result.memory_throughput_pct,
                        )
                        if pct_diff is not None and operator == ">=" and pct_diff < limit_pct:
                            violations.append(
                                f"{result.case.api_name} on {target_label}: "
                                f"throughput {pct_diff:.1f}% < baseline (threshold: >={limit_pct:.0f}%)"
                            )

        if violations:
            console.print(f"\n[bold red]Threshold violations ({len(violations)}):[/]")
            for violation in violations:
                console.print(f"  ✗ {violation}")
            return BenchModeOutcome(kind=BenchOutcomeKind.MISMATCH)

    return BenchModeOutcome()


_build_payload = build_payload
_resolve_metric_names = resolve_metric_names
_slugify = slugify
