"""Shared helpers and context objects for bench modes."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from enum import StrEnum
from typing import Any

from tensor_spec.config.case import CaseConfig
from tensor_spec.config.project import BenchConfig, TargetConfig
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec_core.device import DeviceSpec, DeviceType
from tensor_spec_core.tensor import TensorSpec

type ThresholdRule = tuple[str, str, float]


@dataclass(frozen=True, slots=True)
class BenchTarget:
    """Resolved bench target with a stable display label and python path."""

    label: str
    config: TargetConfig
    python_path: str


@dataclass(frozen=True, slots=True)
class BenchModeContext:
    """Shared runtime context passed to a bench mode handler."""

    targets: tuple[BenchTarget, ...]
    cases: tuple[CaseConfig, ...]
    mapping: MappingRegistry
    bench_config: BenchConfig
    baseline: str | None
    threshold_rules: tuple[ThresholdRule, ...]
    seed: int
    interactive: bool
    e2e_warmup: int
    e2e_repeat: int


class BenchOutcomeKind(StrEnum):
    """High-level outcome kinds returned by bench mode handlers."""

    OK = "ok"
    EXEC_FAILURE = "exec_failure"
    MISMATCH = "mismatch"


@dataclass(frozen=True, slots=True)
class BenchModeOutcome:
    """Outcome returned by a bench mode handler."""

    kind: BenchOutcomeKind = BenchOutcomeKind.OK


@dataclass(frozen=True, slots=True)
class BenchModeHandler:
    """Bench mode implementation hooks used by the CLI dispatch layer."""

    validate_targets: Callable[[tuple[BenchTarget, ...]], None]
    validate_threshold_rules: Callable[[tuple[ThresholdRule, ...]], None]
    run: Callable[[BenchModeContext], BenchModeOutcome]


def parse_target_device(device: str | None) -> DeviceSpec | None:
    """Convert a target device string like ``cuda:0`` into a DeviceSpec."""
    if not device:
        return None
    device_name, sep, device_id_str = device.partition(":")
    try:
        device_type = DeviceType[device_name.upper()]
    except KeyError as err:
        raise ValueError(f"Unsupported target device '{device}'") from err
    device_id = int(device_id_str) if sep else 0
    return DeviceSpec(device_type=device_type, device_id=device_id)


def apply_target_device(case: CaseConfig, target_device: str | None) -> CaseConfig:
    """Fill in missing TensorSpec devices from the target configuration."""
    default_device = parse_target_device(target_device)
    if default_device is None:
        return case

    def apply_value(value: Any) -> Any:
        if isinstance(value, TensorSpec):
            return value if value.device is not None else replace(value, device=default_device)
        if isinstance(value, tuple):
            return tuple(apply_value(item) for item in value)
        if isinstance(value, list):
            return [apply_value(item) for item in value]
        if isinstance(value, dict):
            return {key: apply_value(item) for key, item in value.items()}
        return value

    return CaseConfig(
        api_name=case.api_name,
        args=tuple(apply_value(arg) for arg in case.args),
        kwargs={key: apply_value(value) for key, value in case.kwargs.items()},
    )
