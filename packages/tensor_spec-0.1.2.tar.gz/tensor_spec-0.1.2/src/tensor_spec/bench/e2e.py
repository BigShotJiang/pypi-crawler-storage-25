"""e2e benchmark mode implementation."""

from __future__ import annotations

from rich.table import Table

from tensor_spec.bench.common import (
    BenchModeContext,
    BenchModeOutcome,
    BenchOutcomeKind,
    ThresholdRule,
    apply_target_device,
)
from tensor_spec.bench.runner import BenchRunner
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.tester.base import TestStatus
from tensor_spec.ui.console import console


def validate_e2e_targets(_targets) -> None:
    """e2e mode accepts any resolved bench target."""


def validate_e2e_threshold_rules(rules: tuple[ThresholdRule, ...]) -> None:
    """e2e mode currently supports only latency thresholds."""
    if any(indicator != "latency" for indicator, _operator, _value in rules):
        raise ValueError("e2e mode only supports latency threshold rules.")


def run_e2e_mode(context: BenchModeContext) -> BenchModeOutcome:
    """Execute the e2e benchmark mode."""
    from tensor_spec.tester.check import IsolatedCheckTester

    bench_results: dict[str, list] = {}
    testers: list[IsolatedCheckTester] = []
    had_exec_failure = False
    total = len(context.cases)

    try:
        for target in context.targets:
            if context.interactive:
                with console.status(f"[bold cyan]Starting worker for {target.label}..."):
                    tester = IsolatedCheckTester(
                        python_path=target.python_path,
                        backend_name=target.config.backend,
                        mapping=context.mapping,
                        generator=TensorGenerator(seed=context.seed),
                    )
            else:
                console.print(f"Starting worker for {target.label}...")
                tester = IsolatedCheckTester(
                    python_path=target.python_path,
                    backend_name=target.config.backend,
                    mapping=context.mapping,
                    generator=TensorGenerator(seed=context.seed),
                )
            testers.append(tester)

            runner = BenchRunner(tester=tester, warmup=context.e2e_warmup, repeat=context.e2e_repeat)
            bench_results[target.label] = []

            for idx, case_config in enumerate(context.cases, 1):
                target_case = apply_target_device(case_config, target.config.device)
                console.print(f"  bench {target_case.api_name} [{idx}/{total}] target={target.label} ...")
                result = runner.run(target_case, target_name=target.label)
                bench_results[target.label].append(result)
                if result.test_status not in (TestStatus.PASSED, TestStatus.ACCURACY_ERROR):
                    had_exec_failure = True
                    console.print(f"    ✗ {result.test_status.value.upper()}")
                else:
                    console.print(f"    ✓ median={result.stats.median_ms:.2f}ms")
    finally:
        for tester in testers:
            tester.shutdown()

    if had_exec_failure:
        console.print("[bold red]Some cases failed during benchmarking.[/]")
        return BenchModeOutcome(kind=BenchOutcomeKind.EXEC_FAILURE)

    baseline_times: dict[str, float] | None = None
    if context.baseline is not None:
        baseline_times = {result.case.api_name: result.stats.median_ms for result in bench_results[context.baseline]}

    table = Table(title="E2E Results", show_lines=True)
    table.add_column("API", style="cyan")
    table.add_column("Target", style="magenta")
    table.add_column("Median", justify="right")
    table.add_column("Mean", justify="right")
    table.add_column("Std", justify="right")
    table.add_column("Min", justify="right")
    table.add_column("Max", justify="right")
    if baseline_times is not None:
        table.add_column("vs Baseline", justify="right")

    for target_label, case_results in bench_results.items():
        for result in case_results:
            row = [
                result.case.api_name,
                target_label,
                f"{result.stats.median_ms:.2f}ms",
                f"{result.stats.mean_ms:.2f}ms",
                f"{result.stats.std_ms:.2f}ms",
                f"{result.stats.min_ms:.2f}ms",
                f"{result.stats.max_ms:.2f}ms",
            ]
            if baseline_times is not None:
                baseline_time = baseline_times.get(result.case.api_name)
                is_comparable = (
                    baseline_time is not None
                    and baseline_time > 0
                    and result.stats.median_ms > 0
                    and target_label != context.baseline
                )
                if is_comparable:
                    pct = (result.stats.median_ms - baseline_time) / baseline_time * 100
                    ratio = baseline_time / result.stats.median_ms
                    row.append(f"[green]{ratio:.2f}x faster[/]" if pct < 0 else f"[red]{pct:.0f}% slower[/]")
                else:
                    row.append("(baseline)")
            table.add_row(*row)

    console.print(table)

    if context.threshold_rules and baseline_times is not None:
        violations: list[str] = []
        for indicator, operator, limit_pct in context.threshold_rules:
            if indicator != "latency":
                continue
            for target_label, case_results in bench_results.items():
                if target_label == context.baseline:
                    continue
                for result in case_results:
                    baseline_time = baseline_times.get(result.case.api_name)
                    if baseline_time is None or baseline_time <= 0:
                        continue
                    pct_diff = (result.stats.median_ms - baseline_time) / baseline_time * 100
                    if operator == "<=" and pct_diff > limit_pct:
                        violations.append(
                            f"{result.case.api_name} on {target_label}: "
                            f"latency {pct_diff:.1f}% > baseline (threshold: <={limit_pct:.0f}%)"
                        )

        if violations:
            console.print(f"\n[bold red]Threshold violations ({len(violations)}):[/]")
            for violation in violations:
                console.print(f"  ✗ {violation}")
            return BenchModeOutcome(kind=BenchOutcomeKind.MISMATCH)

    return BenchModeOutcome()
