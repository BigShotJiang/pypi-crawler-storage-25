"""Benchmark runner: warmup + repeated measurement around a tester."""

from __future__ import annotations

from dataclasses import dataclass, field

from loguru import logger

from tensor_spec.bench.stats import BenchStats, compute_stats
from tensor_spec.config.case import CaseConfig
from tensor_spec.tester.base import TesterBase, TestStatus


@dataclass(frozen=True, slots=True)
class BenchCaseResult:
    """Result of benchmarking one case on one target."""

    case: CaseConfig
    target_name: str
    warmup_count: int
    repeat_count: int
    stats: BenchStats
    raw_times_ms: list[float] = field(default_factory=list)
    test_status: TestStatus = TestStatus.PASSED


class BenchRunner:
    """Run warmup + measurement iterations for a single tester."""

    def __init__(self, tester: TesterBase, warmup: int, repeat: int) -> None:
        self.tester = tester
        self.warmup = warmup
        self.repeat = repeat

    def run(self, case: CaseConfig, target_name: str) -> BenchCaseResult:
        """Warmup then measure *repeat* iterations, returning aggregated stats."""
        # Warmup phase
        logger.info("Warming up {} on {} ({} iters)...", case.api_name, target_name, self.warmup)
        for _ in range(self.warmup):
            result = self.tester.test(case)
            if result.status not in (TestStatus.PASSED, TestStatus.ACCURACY_ERROR):
                return BenchCaseResult(
                    case=case,
                    target_name=target_name,
                    warmup_count=self.warmup,
                    repeat_count=0,
                    stats=compute_stats([result.duration_ms]),
                    raw_times_ms=[result.duration_ms],
                    test_status=result.status,
                )

        # Measurement phase
        logger.info("Measuring {} on {} ({} iters)...", case.api_name, target_name, self.repeat)
        times: list[float] = []
        last_status = TestStatus.PASSED
        for _ in range(self.repeat):
            result = self.tester.test(case)
            times.append(result.duration_ms)
            last_status = result.status
            if result.status not in (TestStatus.PASSED, TestStatus.ACCURACY_ERROR):
                break

        stats = compute_stats(times)
        return BenchCaseResult(
            case=case,
            target_name=target_name,
            warmup_count=self.warmup,
            repeat_count=len(times),
            stats=stats,
            raw_times_ms=times,
            test_status=last_status,
        )
