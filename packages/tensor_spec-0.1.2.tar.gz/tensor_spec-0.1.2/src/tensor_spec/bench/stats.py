"""Statistical helpers for benchmark timing data."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class BenchStats:
    """Aggregated timing statistics from a benchmark run."""

    mean_ms: float
    median_ms: float
    std_ms: float
    min_ms: float
    max_ms: float
    percentiles: dict[int, float]  # {50: 1.23, 90: 2.34, ...}


def compute_stats(
    times_ms: list[float],
    percentile_points: tuple[int, ...] = (50, 90, 95, 99),
) -> BenchStats:
    """Compute timing statistics from a list of durations in milliseconds."""
    if not times_ms:
        raise ValueError("times_ms must be non-empty")

    arr = np.asarray(times_ms, dtype=np.float64)
    percentiles = {int(p): float(np.percentile(arr, p)) for p in percentile_points}

    return BenchStats(
        mean_ms=float(np.mean(arr)),
        median_ms=float(np.median(arr)),
        std_ms=float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0,
        min_ms=float(np.min(arr)),
        max_ms=float(np.max(arr)),
        percentiles=percentiles,
    )
