"""Benchmark subsystem for tensor-spec."""
