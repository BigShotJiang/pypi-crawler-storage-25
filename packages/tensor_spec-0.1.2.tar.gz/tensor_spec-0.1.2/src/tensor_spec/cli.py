"""CLI entry point for tensor-spec."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Annotated

import typer
from loguru import logger

from tensor_spec.bench.common import BenchModeContext, BenchModeHandler, BenchOutcomeKind, BenchTarget
from tensor_spec.bench.e2e import run_e2e_mode, validate_e2e_targets, validate_e2e_threshold_rules
from tensor_spec.bench.ncu import run_ncu_mode, validate_ncu_targets, validate_ncu_threshold_rules
from tensor_spec.config.case import CaseConfig
from tensor_spec.config.parser import parse_case
from tensor_spec.config.project import ProjectConfig, TargetConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.ui.console import console, print_result_summary, print_setup_summary

app = typer.Typer(
    name="tensor-spec",
    help="Framework-agnostic deep learning API quality verification tool.",
)

# ── Exit code constants (from CLI spec §8.3) ──────────────────────────
EXIT_OK = 0
EXIT_INPUT = 2
EXIT_ENV = 3
EXIT_EXEC = 4
EXIT_MISMATCH = 5
EXIT_INTERNAL = 6

_VENV_BASE = ".tensor-spec/venvs"
_BENCH_MODE_HANDLERS: dict[str, BenchModeHandler] = {
    "e2e": BenchModeHandler(
        validate_targets=validate_e2e_targets,
        validate_threshold_rules=validate_e2e_threshold_rules,
        run=run_e2e_mode,
    ),
    "ncu": BenchModeHandler(
        validate_targets=validate_ncu_targets,
        validate_threshold_rules=validate_ncu_threshold_rules,
        run=run_ncu_mode,
    ),
}


# ── Output helpers ────────────────────────────────────────────────────


def _error(msg: str) -> None:
    """Print an error message that is always visible AND logged."""
    console.print(f"[bold red]error:[/] {msg}")
    logger.error(msg)


def _is_interactive() -> bool:
    """Check if we're running in an interactive terminal."""
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _stdin_has_data() -> bool:
    """Check whether stdin is piped/redirected rather than attached to a TTY."""
    return hasattr(sys.stdin, "isatty") and not sys.stdin.isatty()


def _case_pass_line(api_name: str, idx: int, total: int, duration_ms: float) -> str:
    """Format a per-case pass line."""
    return f"  ✓ {api_name} [{idx}/{total}] {duration_ms:.0f}ms"


def _case_fail_line(api_name: str, idx: int, total: int, status: str, duration_ms: float) -> str:
    """Format a per-case fail line."""
    return f"  ✗ {api_name} [{idx}/{total}] {status.upper()} {duration_ms:.0f}ms"


# ── Parallelism helper ────────────────────────────────────────────────


def _parse_jobs(jobs_str: str | None, num_cases: int) -> int:
    """Parse the --jobs flag into a concrete integer."""
    if jobs_str is None or jobs_str == "auto":
        return min(os.cpu_count() or 1, 4, num_cases) if num_cases > 0 else 1
    try:
        value = int(jobs_str)
    except ValueError as err:
        raise typer.BadParameter(f"--jobs must be 'auto' or a positive integer, got '{jobs_str}'") from err
    if value < 1:
        raise typer.BadParameter(f"--jobs must be >= 1, got {value}")
    return value


def _parse_threshold_rules(raw: str) -> list[tuple[str, str, float]]:
    """Parse a --threshold string like ``latency<=10%,throughput>=5%``.

    Returns a list of ``(indicator, operator, limit_percent)`` tuples.
    """
    import re

    _SUPPORTED_INDICATORS = {"latency", "throughput"}
    _SUPPORTED_OPERATORS = {
        "latency": {"<="},
        "throughput": {">="},
    }

    rules: list[tuple[str, str, float]] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        m = re.fullmatch(r"(\w+)\s*(<=|>=)\s*([\d.]+)%", part)
        if not m:
            raise typer.BadParameter(
                f"Invalid threshold rule '{part}'. Expected format: indicator<=N% or indicator>=N%"
            )
        indicator, operator, value_str = m.group(1), m.group(2), m.group(3)
        if indicator not in _SUPPORTED_INDICATORS:
            raise typer.BadParameter(
                f"Unsupported indicator '{indicator}'. Supported: {', '.join(sorted(_SUPPORTED_INDICATORS))}"
            )
        if operator not in _SUPPORTED_OPERATORS[indicator]:
            supported = ", ".join(sorted(_SUPPORTED_OPERATORS[indicator]))
            raise typer.BadParameter(f"Unsupported operator '{operator}' for '{indicator}'. Supported: {supported}")
        rules.append((indicator, operator, float(value_str)))

    if not rules:
        raise typer.BadParameter("--threshold must contain at least one rule")
    return rules


def _init_logging(*, verbose: bool = False) -> Path:
    """Initialize logging: always write to file, stderr only when verbose."""
    from datetime import datetime

    from zendev import setup_log

    setup_log(verbose=verbose)
    logger.remove()

    log_dir = Path(".tensor-spec/logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"{ts}.log"

    fmt = "{time:HH:mm:ss.SSS} | {level: <7} | {message}"
    logger.add(str(log_path), format=fmt, level="DEBUG")

    if verbose:
        color_fmt = "<green>{time:HH:mm:ss.SSS}</green> | <level>{level: <7}</level> | <level>{message}</level>"
        logger.add(sys.stderr, format=color_fmt, level="DEBUG", colorize=True)

    return log_path


# ── Target parsing ────────────────────────────────────────────────────


def _parse_inline_target(raw: str) -> TargetConfig:
    """Parse an inline target definition: ``backend=torch,device=cuda,python=/venv/bin/python``."""
    fields: dict[str, str] = {}
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise typer.BadParameter(f"Invalid inline target field (missing '='): '{part}'")
        key, _, value = part.partition("=")
        key = key.strip()
        value = value.strip()
        if key in fields:
            raise typer.BadParameter(f"Duplicate key '{key}' in inline target")
        if key == "name":
            raise typer.BadParameter("'name' is forbidden in inline targets")
        fields[key] = value

    if "backend" not in fields:
        raise typer.BadParameter("Inline target requires 'backend' field")
    if "python" not in fields:
        raise typer.BadParameter("Inline target requires 'python' field")

    allowed = {"backend", "device", "python"}
    unknown = set(fields) - allowed
    if unknown:
        raise typer.BadParameter(f"Unknown inline target field(s): {', '.join(sorted(unknown))}")

    return TargetConfig(
        backend=fields["backend"],
        device=fields.get("device", ""),
        python=fields["python"],
    )


def _resolve_targets(
    target_args: list[str],
    config: ProjectConfig,
) -> list[tuple[str | None, TargetConfig]]:
    """Resolve --target arguments into (name_or_none, TargetConfig) pairs.

    Without ``=`` → named config ref; with ``=`` → inline anonymous.
    """
    resolved: list[tuple[str | None, TargetConfig]] = []
    for raw in target_args:
        if "=" in raw:
            resolved.append((None, _parse_inline_target(raw)))
        else:
            tgt = config.resolve_target(raw)
            resolved.append((raw, tgt))
    return resolved


# ── Case collection ───────────────────────────────────────────────────

_CASE_EXTENSIONS = {".tspec", ".tspecb"}


def _collect_cases(
    case_args: list[str],
    *,
    match_globs: list[str] | None = None,
    exclude_globs: list[str] | None = None,
) -> list[str]:
    """Collect case strings from positional CASE arguments.

    Auto-detection:
    - Existing file → read lines
    - Existing directory → recursive expansion (.tspec/.tspecb)
    - ``-`` → stdin
    - Anything else → inline case string
    """
    import fnmatch

    seen_paths: set[Path] = set()
    case_strings: list[str] = []

    def _should_include(p: Path) -> bool:
        """Apply --match/--exclude globs."""
        name = str(p)
        if match_globs and not any(fnmatch.fnmatch(name, g) for g in match_globs):
            return False
        return not (exclude_globs and any(fnmatch.fnmatch(name, g) for g in exclude_globs))

    def _read_case_file(p: Path) -> None:
        resolved = p.resolve()
        if resolved in seen_paths:
            return
        seen_paths.add(resolved)
        if not _should_include(p):
            return
        for line in p.read_text().splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                case_strings.append(stripped)

    def _expand_dir(d: Path) -> None:
        for child in sorted(d.rglob("*")):
            if any(part.startswith(".") for part in child.parts):
                continue
            if child.is_file() and child.suffix in _CASE_EXTENSIONS:
                _read_case_file(child)

    for arg in case_args:
        p = Path(arg)
        if arg == "-":
            for line in sys.stdin:
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    case_strings.append(stripped)
        elif p.is_dir():
            _expand_dir(p)
        elif p.is_file():
            _read_case_file(p)
        else:
            # Inline case string
            case_strings.append(arg)

    return case_strings


# ── Commands ──────────────────────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        from importlib.metadata import version

        console.print(f"tensor-spec {version('tensor-spec')}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option("--version", help="Show version and exit.", callback=_version_callback, is_eager=True),
    ] = None,
) -> None:
    """Framework-agnostic deep learning API quality verification tool."""


@app.command()
def check(
    cases: Annotated[
        list[str] | None,
        typer.Argument(help="Case inputs: file paths, directories, '-' (stdin), or inline case strings"),
    ] = None,
    target: Annotated[
        list[str] | None,
        typer.Option("--target", help="Execution target (repeatable). Named ref or inline backend=...,python=..."),
    ] = None,
    match: Annotated[
        list[str] | None,
        typer.Option("--match", help="Include only paths matching glob (repeatable)"),
    ] = None,
    exclude: Annotated[
        list[str] | None,
        typer.Option("--exclude", help="Exclude paths matching glob (repeatable)"),
    ] = None,
    format_: Annotated[
        str | None,
        typer.Option("--format", help="Output format: human, json, jsonl"),
    ] = None,
    no_interactive: Annotated[
        bool,
        typer.Option("--no-interactive", help="Force plain output, disable TUI"),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
    atol: Annotated[float | None, typer.Option(help="Global absolute tolerance override")] = None,
    rtol: Annotated[float | None, typer.Option(help="Global relative tolerance override")] = None,
    fail_fast: Annotated[bool, typer.Option("--fail-fast", help="Stop on first failure")] = False,
    jobs: Annotated[str | None, typer.Option("--jobs", help="Parallelism limit (auto, or integer)")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preflight validation only")] = False,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Run correctness/reachability check or cross-target accuracy comparison.

    With 1 target: execution check — does this case run?
    With 2+ targets: comparison — do targets agree within tolerance?

    \b
    Examples:
      tensor-spec check 'abs(x=Tensor.float32((100,)))' --target torch-cu124
      tensor-spec check cases/ --target paddle-cu124 --target torch-cu124
      tensor-spec check cases.tspec --target backend=torch,python=/venv/bin/python
      echo 'abs(x=Tensor.float32((100,)))' | tensor-spec check --target torch-cu124
    """
    from rich.progress import Progress

    from tensor_spec.compare.comparator import NumpyComparator
    from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig
    from tensor_spec.mapping.registry import MappingRegistry
    from tensor_spec.tester.base import TesterBase, TestResult, TestStatus

    # --- Load project config ---
    if config_file:
        project_config = ProjectConfig.from_toml(config_file)
    else:
        project_config = ProjectConfig.find_and_load() or ProjectConfig()

    cfg_defaults = project_config.defaults
    effective_verbose = verbose or cfg_defaults.verbose
    effective_format = format_ or cfg_defaults.format or "human"
    _init_logging(verbose=effective_verbose)

    _VALID_FORMATS = {"human", "json", "jsonl"}
    if effective_format not in _VALID_FORMATS:
        _error(f"Invalid --format '{effective_format}'. Must be one of: {', '.join(sorted(_VALID_FORMATS))}")
        raise typer.Exit(EXIT_INPUT)

    # --- Resolve targets ---
    target_args: list[str] = []
    if target:
        target_args = list(target)
    elif cfg_defaults.targets:
        target_args = list(cfg_defaults.targets)

    if not target_args:
        _error("No targets specified. Use --target or set defaults.targets in tensor-spec.toml.")
        raise typer.Exit(EXIT_INPUT)

    try:
        resolved_targets = _resolve_targets(target_args, project_config)
    except (typer.BadParameter, ValueError) as e:
        _error(f"Target resolution error: {e}")
        raise typer.Exit(EXIT_INPUT) from e

    # Validate python paths exist
    for name_or_none, tgt in resolved_targets:
        label = name_or_none or f"inline({tgt.backend})"
        python_path = tgt.python
        if not python_path:
            # Fall back to venv default
            python_path = f"{_VENV_BASE}/{tgt.backend}/bin/python"
        if not Path(python_path).exists():
            _error(f"Python not found at {python_path} (target '{label}')")
            _error("Run 'tensor-spec setup' to create framework venvs.")
            raise typer.Exit(EXIT_ENV)

    # --- Collect cases ---
    if not cases and _stdin_has_data():
        cases = ["-"]

    if not cases:
        _error("No cases provided. Pass case files, directories, or inline case strings.")
        raise typer.Exit(EXIT_INPUT)

    case_strings = _collect_cases(cases, match_globs=match, exclude_globs=exclude)
    if not case_strings:
        _error("No cases found after expansion/filtering.")
        raise typer.Exit(EXIT_INPUT)

    # --- Parse all cases upfront ---
    parsed_cases = []
    for cs in case_strings:
        try:
            parsed_cases.append(parse_case(cs))
        except ValueError as e:
            _error(f"Parse error in '{cs}': {e}")
            raise typer.Exit(EXIT_INPUT) from e
    console.print(f"  {len(parsed_cases)} case(s) to run")
    logger.info("{} case(s) to run", len(parsed_cases))

    # --- Dry-run: comprehensive preflight validation ---
    if dry_run:
        issues: list[str] = []

        # Validate python paths
        for name_or_none, tgt in resolved_targets:
            label = name_or_none or f"inline({tgt.backend})"
            py = tgt.python or f"{_VENV_BASE}/{tgt.backend}/bin/python"
            if not Path(py).exists():
                issues.append(f"Python not found at {py} (target '{label}')")
            elif not Path(py).is_file():
                issues.append(f"Python path is not a file: {py} (target '{label}')")

        # Validate case parsing
        for cs in case_strings:
            try:
                parse_case(cs)
            except ValueError as e:
                issues.append(f"Parse error in '{cs}': {e}")

        # Report
        if issues:
            console.print(f"[bold red]Dry-run found {len(issues)} issue(s):[/]")
            for issue in issues:
                console.print(f"  ✗ {issue}")
            raise typer.Exit(EXIT_INPUT)

        console.print(f"[bold green]Dry-run OK:[/] {len(resolved_targets)} target(s), {len(case_strings)} case(s)")
        for name_or_none, tgt in resolved_targets:
            label = name_or_none or f"inline({tgt.backend})"
            console.print(f"  target: {label} → backend={tgt.backend}, device={tgt.device or '(default)'}")
        raise typer.Exit(EXIT_OK)

    # --- Tolerance ---
    effective_seed = cfg_defaults.seed

    tol_data = project_config.tolerance_data
    tol = Tolerance.from_dict(tol_data) if tol_data else Tolerance()
    if atol is not None or rtol is not None:
        tol = Tolerance(
            default=ToleranceConfig(
                atol=atol if atol is not None else tol.default.atol,
                rtol=rtol if rtol is not None else tol.default.rtol,
            ),
            overrides=tol.overrides,
        )

    # --- Extract backend/python lists from resolved targets ---
    effective_backends: list[str] = []
    effective_pythons: list[str] = []
    for _name, tgt in resolved_targets:
        effective_backends.append(tgt.backend)
        py = tgt.python or f"{_VENV_BASE}/{tgt.backend}/bin/python"
        effective_pythons.append(py)

    # --- Load mappings ---
    mapping = MappingRegistry()
    for b in effective_backends:
        mapping.load_bundled(b)

    # --- Determine parallelism ---
    try:
        effective_jobs = _parse_jobs(jobs, len(parsed_cases))
    except typer.BadParameter as e:
        _error(str(e))
        raise typer.Exit(EXIT_INPUT) from e

    # --- Tester factory ---
    def _create_tester() -> TesterBase:
        if len(effective_backends) == 1:
            from tensor_spec.tester.check import IsolatedCheckTester

            return IsolatedCheckTester(
                python_path=effective_pythons[0],
                backend_name=effective_backends[0],
                mapping=mapping,
                generator=TensorGenerator(seed=effective_seed),
            )
        else:
            from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

            worker_specs = [
                (effective_backends[i], effective_pythons[i], effective_backends[i])
                for i in range(len(effective_backends))
            ]
            return IsolatedAccuracyTester(
                backends=worker_specs,
                mapping=mapping,
                comparator=NumpyComparator(),
                tolerance=tol,
                generator=TensorGenerator(seed=effective_seed),
            )

    # --- Interactivity ---
    interactive = _is_interactive() and not no_interactive

    # --- Create tester(s) ---
    if interactive:
        with console.status("[bold cyan]Starting worker(s)..."):
            testers: list[TesterBase] = [_create_tester() for _ in range(effective_jobs)]
    else:
        console.print("Starting worker(s)...")
        testers: list[TesterBase] = [_create_tester() for _ in range(effective_jobs)]

    total = len(parsed_cases)
    passed = 0
    failed = 0
    results: list[TestResult] = []
    try:
        if effective_jobs == 1:
            # ── Sequential path: per-case line output ──
            tester = testers[0]
            for idx, case_config in enumerate(parsed_cases, 1):
                result = tester.test(case_config)
                results.append(result)
                if result.status == TestStatus.PASSED:
                    passed += 1
                    console.print(_case_pass_line(result.case.api_name, idx, total, result.duration_ms))
                else:
                    failed += 1
                    console.print(
                        _case_fail_line(result.case.api_name, idx, total, result.status.value, result.duration_ms)
                    )
                    if result.error:
                        console.print(f"    error: {result.error}")
                    if fail_fast:
                        break
        else:
            # ── Parallel path ──
            import threading
            from concurrent.futures import ThreadPoolExecutor, as_completed

            cancel_event = threading.Event()
            lock = threading.Lock()

            def _run_case(tester_idx: int, case_config: CaseConfig) -> TestResult:
                if cancel_event.is_set():
                    return TestResult(case=case_config, status=TestStatus.ERROR, error="cancelled")
                return testers[tester_idx].test(case_config)

            if interactive:
                with Progress(console=console) as progress:
                    task_id = progress.add_task("Running cases...", total=total)
                    with ThreadPoolExecutor(max_workers=effective_jobs) as pool:
                        futures = {
                            pool.submit(_run_case, i % effective_jobs, case_config): i
                            for i, case_config in enumerate(parsed_cases)
                        }
                        result_buffer: dict[int, TestResult] = {}
                        for future in as_completed(futures):
                            idx = futures[future]
                            result = future.result()
                            with lock:
                                result_buffer[idx] = result
                                if result.status == TestStatus.PASSED:
                                    passed += 1
                                else:
                                    failed += 1
                                    if fail_fast:
                                        cancel_event.set()
                                progress.advance(task_id)
            else:
                # Non-interactive parallel: line-by-line progress
                completed = 0
                with ThreadPoolExecutor(max_workers=effective_jobs) as pool:
                    futures = {
                        pool.submit(_run_case, i % effective_jobs, case_config): i
                        for i, case_config in enumerate(parsed_cases)
                    }
                    result_buffer: dict[int, TestResult] = {}
                    for future in as_completed(futures):
                        idx = futures[future]
                        result = future.result()
                        with lock:
                            result_buffer[idx] = result
                            completed += 1
                            if result.status == TestStatus.PASSED:
                                passed += 1
                                console.print(_case_pass_line(result.case.api_name, idx + 1, total, result.duration_ms))
                            else:
                                failed += 1
                                console.print(
                                    _case_fail_line(
                                        result.case.api_name,
                                        idx + 1,
                                        total,
                                        result.status.value,
                                        result.duration_ms,
                                    )
                                )
                                if result.error:
                                    console.print(f"    error: {result.error}")
                                if fail_fast:
                                    cancel_event.set()

            # Preserve original case order
            results = [result_buffer[i] for i in sorted(result_buffer)]

            # Print failure summary after parallel completion
            if failed > 0:
                fail_list = [r for r in results if r.status != TestStatus.PASSED]
                console.print(f"\n[bold red]Failed cases ({len(fail_list)}):[/]")
                for r in fail_list:
                    console.print(f"  ✗ {r.case.api_name} {r.status.value.upper()}")
                    if r.error:
                        console.print(f"    error: {r.error}")
    finally:
        for t in testers:
            t.shutdown()

    # --- Summary ---
    print_result_summary(results)

    if failed > 0:
        raise typer.Exit(EXIT_MISMATCH if len(effective_backends) > 1 else EXIT_EXEC)


@app.command()
def bench(
    cases: Annotated[
        list[str] | None,
        typer.Argument(help="Case inputs: file paths, directories, '-' (stdin), or inline case strings"),
    ] = None,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Benchmark mode: e2e or ncu"),
    ] = "e2e",
    target: Annotated[
        list[str] | None,
        typer.Option("--target", help="Execution target (repeatable)"),
    ] = None,
    baseline: Annotated[
        str | None,
        typer.Option("--baseline", help="Named target to use as measurement baseline"),
    ] = None,
    threshold: Annotated[
        str | None,
        typer.Option("--threshold", help="Comma-separated pass/fail rules (e.g., latency<=10%%,throughput>=5%%)"),
    ] = None,
    warmup: Annotated[int | None, typer.Option("--warmup", help="e2e: warmup iterations")] = None,
    repeat: Annotated[int | None, typer.Option("--repeat", help="e2e: measurement iterations")] = None,
    match: Annotated[
        list[str] | None,
        typer.Option("--match", help="Include only paths matching glob (repeatable)"),
    ] = None,
    exclude: Annotated[
        list[str] | None,
        typer.Option("--exclude", help="Exclude paths matching glob (repeatable)"),
    ] = None,
    format_: Annotated[
        str | None,
        typer.Option("--format", help="Output format: human, json, jsonl"),
    ] = None,
    no_interactive: Annotated[
        bool,
        typer.Option("--no-interactive", help="Force plain output"),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
    jobs: Annotated[str | None, typer.Option("--jobs", help="Parallelism limit")] = None,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Run performance benchmarks via pluggable bench modes.

    \b
    Examples:
      tensor-spec bench --mode e2e 'matmul(...)' --target torch-cu124
      tensor-spec bench --mode ncu cases/ --target torch-cu124 --target paddle-cu124
      echo 'abs(x=Tensor.float32((100,)))' | tensor-spec bench --target torch-cu124
    """
    from tensor_spec.mapping.registry import MappingRegistry

    # --- Validate mode ---
    mode_handler = _BENCH_MODE_HANDLERS.get(mode)
    if mode_handler is None:
        supported_modes = ", ".join(sorted(_BENCH_MODE_HANDLERS))
        console.print(f"[bold red]Invalid mode:[/] {mode}. Must be one of: {supported_modes}.")
        raise typer.Exit(EXIT_INPUT)

    # --- Validate format ---
    _VALID_FORMATS = {"human", "json", "jsonl"}
    effective_format = format_ or "human"
    if effective_format not in _VALID_FORMATS:
        _error(f"Invalid --format '{effective_format}'. Must be one of: {', '.join(sorted(_VALID_FORMATS))}")
        raise typer.Exit(EXIT_INPUT)

    # --- Load project config ---
    if config_file:
        project_config = ProjectConfig.from_toml(config_file)
    else:
        project_config = ProjectConfig.find_and_load() or ProjectConfig()

    cfg_defaults = project_config.defaults
    effective_verbose = verbose or cfg_defaults.verbose
    _init_logging(verbose=effective_verbose)

    # --- Resolve targets ---
    target_args: list[str] = []
    if target:
        target_args = list(target)
    elif cfg_defaults.targets:
        target_args = list(cfg_defaults.targets)

    if not target_args:
        _error("No targets specified. Use --target or set defaults.targets in tensor-spec.toml.")
        raise typer.Exit(EXIT_INPUT)

    try:
        resolved_targets = _resolve_targets(target_args, project_config)
    except (typer.BadParameter, ValueError) as e:
        _error(f"Target resolution error: {e}")
        raise typer.Exit(EXIT_INPUT) from e

    # --- Validate --baseline ---
    if baseline is not None:
        target_names = [name for name, _tgt in resolved_targets if name is not None]
        if baseline not in target_names:
            console.print(f"[bold red]--baseline '{baseline}' is not among the requested --target entries.[/]")
            console.print(f"  Available named targets: {', '.join(target_names) or '(none — only inline targets)'}")
            raise typer.Exit(EXIT_INPUT)

    # --- Validate --threshold ---
    threshold_rules: list[tuple[str, str, float]] = []
    if threshold is not None:
        if baseline is None:
            console.print("[bold red]--threshold requires --baseline to be specified.[/]")
            raise typer.Exit(EXIT_INPUT)
        threshold_rules = _parse_threshold_rules(threshold)

    bench_targets = tuple(
        BenchTarget(
            label=name_or_none or f"inline({tgt.backend})",
            config=tgt,
            python_path=tgt.python or f"{_VENV_BASE}/{tgt.backend}/bin/python",
        )
        for name_or_none, tgt in resolved_targets
    )

    try:
        mode_handler.validate_threshold_rules(tuple(threshold_rules))
        mode_handler.validate_targets(bench_targets)
    except ValueError as err:
        _error(str(err))
        raise typer.Exit(EXIT_INPUT) from err

    # --- Validate python paths ---
    for target_spec in bench_targets:
        if not Path(target_spec.python_path).exists():
            _error(f"Python not found at {target_spec.python_path} (target '{target_spec.label}')")
            _error("Run 'tensor-spec setup' to create framework venvs.")
            raise typer.Exit(EXIT_ENV)

    # --- Collect and parse cases ---
    if not cases and _stdin_has_data():
        cases = ["-"]

    if not cases:
        _error("No cases provided.")
        raise typer.Exit(EXIT_INPUT)

    case_strings = _collect_cases(cases, match_globs=match, exclude_globs=exclude)
    if not case_strings:
        _error("No cases found after expansion/filtering.")
        raise typer.Exit(EXIT_INPUT)

    parsed_cases = []
    for cs in case_strings:
        try:
            parsed_cases.append(parse_case(cs))
        except ValueError as e:
            _error(f"Parse error in '{cs}': {e}")
            raise typer.Exit(EXIT_INPUT) from e

    # --- Resolve warmup/repeat ---
    bench_cfg = project_config.bench
    effective_warmup = warmup if warmup is not None else bench_cfg.e2e.warmup
    effective_repeat = repeat if repeat is not None else bench_cfg.e2e.repeat

    # --- Interactivity ---
    interactive = _is_interactive() and not no_interactive

    # --- Build shared bench context ---
    effective_seed = cfg_defaults.seed
    mapping = MappingRegistry()
    target_backends = [target_spec.config.backend for target_spec in bench_targets]
    for b in target_backends:
        mapping.load_bundled(b)
    context = BenchModeContext(
        targets=bench_targets,
        cases=tuple(parsed_cases),
        mapping=mapping,
        bench_config=bench_cfg,
        baseline=baseline,
        threshold_rules=tuple(threshold_rules),
        seed=effective_seed,
        interactive=interactive,
        e2e_warmup=effective_warmup,
        e2e_repeat=effective_repeat,
    )
    outcome = mode_handler.run(context)
    if outcome.kind is BenchOutcomeKind.EXEC_FAILURE:
        raise typer.Exit(EXIT_EXEC)
    if outcome.kind is BenchOutcomeKind.MISMATCH:
        raise typer.Exit(EXIT_MISMATCH)


@app.command()
def doctor(
    fix: Annotated[bool, typer.Option("--fix", help="Attempt environment-only repairs")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Diagnose the tensor-spec environment.

    Checks config validity, named target resolution, python paths,
    backend loadability, and device availability.

    \b
    Examples:
      tensor-spec doctor
      tensor-spec doctor --fix
    """
    _init_logging(verbose=verbose)

    # --- Load config ---
    project_config = ProjectConfig.from_toml(config_file) if config_file else ProjectConfig.find_and_load()

    if project_config is None:
        console.print("[bold yellow]No tensor-spec.toml found.[/]")
        console.print("Run 'tensor-spec setup' to initialize your project.")
        raise typer.Exit(EXIT_INPUT)

    issues: list[str] = []
    passed: list[str] = []

    # Check config structure
    if project_config.targets:
        passed.append(f"{len(project_config.targets)} named target(s) configured")
    else:
        issues.append("No named targets defined in [targets.*]")

    # Check named targets
    for name, tgt in project_config.targets.items():
        if not tgt.backend:
            issues.append(f"Target '{name}': missing 'backend' field")
        else:
            passed.append(f"Target '{name}': backend='{tgt.backend}'")

        if tgt.python:
            if Path(tgt.python).exists():
                passed.append(f"Target '{name}': python OK ({tgt.python})")
            else:
                issues.append(f"Target '{name}': python not found at {tgt.python}")
        else:
            issues.append(f"Target '{name}': 'python' field not set")

    # Check default targets reference valid named targets
    for dt in project_config.defaults.targets:
        if dt not in project_config.targets:
            issues.append(f"defaults.targets references unknown target '{dt}'")
        else:
            passed.append(f"defaults.targets → '{dt}' resolved OK")

    # Check backend loadability (best-effort, non-fatal)
    checked_backends: set[str] = set()
    for _name, tgt in project_config.targets.items():
        if not tgt.backend or tgt.backend in checked_backends:
            continue
        checked_backends.add(tgt.backend)
        try:
            from tensor_spec.mapping.registry import MappingRegistry

            reg = MappingRegistry()
            reg.load_bundled(tgt.backend)
            passed.append(f"Backend '{tgt.backend}': mapping registry loaded")
        except Exception as exc:
            issues.append(f"Backend '{tgt.backend}': failed to load mappings — {exc}")

    # Report
    if passed:
        console.print("[bold green]Checks passed:[/]")
        for msg in passed:
            console.print(f"  ✓ {msg}")

    if issues:
        console.print(f"\n[bold red]{len(issues)} issue(s) found:[/]")
        for issue in issues:
            console.print(f"  ✗ {issue}")
        if fix:
            console.print("\n[bold cyan]--fix:[/] clearing .tensor-spec/cache/ ...")
            cache_dir = Path(".tensor-spec/cache")
            if cache_dir.exists():
                import shutil

                shutil.rmtree(cache_dir)
                console.print("  Cache cleared. Re-run 'tensor-spec doctor' to verify.")
            else:
                console.print("  No cache directory found — nothing to clear.")
        raise typer.Exit(EXIT_ENV)
    else:
        console.print("\n[bold green]All checks passed.[/]")


@app.command()
def setup(
    backend: Annotated[
        list[str] | None,
        typer.Option(help="Backend to set up (repeatable, or omit for all)"),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Set up framework virtual environments.

    Creates isolated venvs under .tensor-spec/venvs/ and installs the
    specified frameworks. Reads source configuration from tensor-spec.toml.

    \b
    Examples:
      tensor-spec setup                           # set up all configured backends
      tensor-spec setup --backend paddle           # set up paddle only
      tensor-spec setup --config my-config.toml    # use custom config file
    """
    from tensor_spec.setup_cmd import run_setup

    _init_logging(verbose=verbose)

    config = ProjectConfig.from_toml(config_file) if config_file else ProjectConfig.find_and_load() or ProjectConfig()

    results = run_setup(backends=backend, config=config, verbose=verbose)
    print_setup_summary(results)

    if any(r["status"] != "ok" for r in results):
        raise typer.Exit(1)


@app.command()
def migrate(
    input: Annotated[
        str,
        typer.Option("--input", help="Path to a legacy PaddleAPITest text case file"),
    ],
    output: Annotated[
        str,
        typer.Option("--output", help="Path to write the migrated tensor-spec case file"),
    ],
    rejects: Annotated[
        str | None,
        typer.Option(help="Optional path for rejected legacy lines"),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
) -> None:
    """Migrate a legacy PaddleAPITest text case file into tensor-spec syntax."""
    _init_logging(verbose=verbose)

    from tensor_spec.migrate import migrate_case_file

    input_path = Path(input)
    if not input_path.exists():
        _error(f"Input file not found: {input}")
        raise typer.Exit(EXIT_INPUT)

    try:
        summary = migrate_case_file(
            input_path=input_path,
            output_path=Path(output),
            rejects_path=Path(rejects) if rejects is not None else None,
        )
    except ValueError as exc:
        _error(f"Migration failed: {exc}")
        raise typer.Exit(EXIT_EXEC) from exc

    if summary.migrated_cases == 0:
        _error("Migration failed: no case lines were converted")
        raise typer.Exit(EXIT_EXEC)

    console.print(
        f"[bold green]Migrated[/] {summary.migrated_cases} case(s) from {summary.total_lines} line(s) "
        f"to [cyan]{output}[/]"
    )
    if summary.rejects_path is not None:
        console.print(
            f"[bold yellow]Rejected[/] {summary.rejected_cases} line(s); "
            f"details written to [cyan]{summary.rejects_path}[/]"
        )


@app.command()
def pack(
    files: Annotated[
        list[str] | None,
        typer.Argument(help="Input .tspec file(s) or '-' for stdin"),
    ] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output .tspecb file path"),
    ] = None,
) -> None:
    """Convert .tspec text format to .tspecb binary format.

    \b
    Examples:
      tensor-spec pack cases.tspec -o cases.tspecb
      cat cases.tspec | tensor-spec pack - -o cases.tspecb
    """
    console.print("[bold yellow]pack command is not yet implemented.[/]")
    console.print("Binary .tspecb format design is a separate effort.")
    raise typer.Exit(EXIT_INTERNAL)


@app.command()
def unpack(
    files: Annotated[
        list[str] | None,
        typer.Argument(help="Input .tspecb file(s) or '-' for stdin"),
    ] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output .tspec file path"),
    ] = None,
) -> None:
    """Convert .tspecb binary format to .tspec text format.

    \b
    Examples:
      tensor-spec unpack cases.tspecb -o cases.tspec
      cat cases.tspecb | tensor-spec unpack - -o cases.tspec
    """
    console.print("[bold yellow]unpack command is not yet implemented.[/]")
    console.print("Binary .tspecb format design is a separate effort.")
    raise typer.Exit(EXIT_INTERNAL)
