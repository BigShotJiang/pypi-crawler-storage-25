"""Implementation of the `tensor-spec setup` command."""

from __future__ import annotations

import subprocess
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as installed_version
from pathlib import Path

from loguru import logger

from tensor_spec.config.project import ProjectConfig, SourceConfig
from tensor_spec.ui.console import console

_VENV_BASE = Path(".tensor-spec/venvs")
_PACKAGE_ROOT = Path(__file__).resolve().parents[2]
_WORKSPACE_RUNTIME_PACKAGES = {
    "tensor-spec-core": _PACKAGE_ROOT / "packages" / "core",
    "tensor-spec-worker": _PACKAGE_ROOT / "packages" / "worker",
}
_BACKEND_PREREQUISITES = {
    "paddle": ("setuptools",),
    "torch": (),
}


def _runtime_install_targets() -> list[tuple[str, list[str]]]:
    workspace_targets = [
        (name, ["-e", str(path)]) for name, path in _WORKSPACE_RUNTIME_PACKAGES.items() if path.is_dir()
    ]
    if len(workspace_targets) == len(_WORKSPACE_RUNTIME_PACKAGES):
        return workspace_targets
    if workspace_targets:
        missing = [name for name, path in _WORKSPACE_RUNTIME_PACKAGES.items() if not path.is_dir()]
        raise RuntimeError(f"Incomplete workspace runtime packages: {', '.join(sorted(missing))}")

    targets: list[tuple[str, list[str]]] = []
    for name in _WORKSPACE_RUNTIME_PACKAGES:
        try:
            targets.append((name, [f"{name}=={installed_version(name)}"]))
        except PackageNotFoundError as exc:
            raise RuntimeError(
                f"Required runtime package '{name}' is not installed in the current environment."
            ) from exc
    return targets


def setup_backend(
    backend: str,
    *,
    index_url: str = "",
    extra_index_url: str = "https://pypi.org/simple/",
    index_strategy: str = "",
    package: str = "",
    version: str = "",
    whl: str = "",
    python_version: str = "3.12",
    verbose: bool = False,
) -> dict[str, str]:
    """Create a venv for *backend*, install the framework, and verify import.

    Returns a dict with keys: backend, status, detail.
    """
    venv_dir = _VENV_BASE / backend
    python_path = venv_dir / "bin" / "python"
    result: dict[str, str] = {"backend": backend}

    # --- create venv ---
    console.print(f"  [cyan]{backend}:[/] creating venv...")
    proc = subprocess.run(
        ["uv", "venv", str(venv_dir), "--python", python_version],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        result.update(status="failed", detail=f"venv creation failed: {proc.stderr.strip()}")
        return result

    # --- install package ---
    install_cmd: list[str] = ["uv", "pip", "install", "--python", str(python_path)]

    if whl:
        install_cmd.append(whl)
    else:
        pkg = package or backend
        if version:
            pkg = f"{pkg}=={version}"
        install_cmd.append(pkg)
        install_cmd.extend(_BACKEND_PREREQUISITES.get(backend, ()))
        if index_url:
            install_cmd.extend(["--index-url", index_url])
        if extra_index_url:
            install_cmd.extend(["--extra-index-url", extra_index_url])
        if index_strategy:
            install_cmd.extend(["--index-strategy", index_strategy])

    console.print(f"  [cyan]{backend}:[/] installing package...")
    proc = subprocess.run(install_cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        result.update(status="failed", detail=f"install failed: {proc.stderr.strip()}")
        return result

    try:
        runtime_targets = _runtime_install_targets()
    except RuntimeError as exc:
        result.update(status="failed", detail=str(exc))
        return result

    # --- install tensor-spec runtime packages into the venv ---
    for label, install_args in runtime_targets:
        console.print(f"  [cyan]{backend}:[/] installing {label}...")
        proc = subprocess.run(
            ["uv", "pip", "install", "--python", str(python_path), *install_args],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            result.update(status="failed", detail=f"install {label} failed: {proc.stderr.strip()}")
            return result

    # --- verify import ---
    import_name = "paddle" if backend == "paddle" else backend
    console.print(f"  [cyan]{backend}:[/] verifying import...")
    proc = subprocess.run(
        [str(python_path), "-c", f"import {import_name}; print({import_name}.__version__)"],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        result.update(status="failed", detail=f"import verification failed: {proc.stderr.strip()}")
        return result

    version_str = proc.stdout.strip()
    result.update(status="ok", detail=f"v{version_str}")
    return result


def _print_backend_result(r: dict[str, str]) -> None:
    """Print a per-backend result line."""
    backend = r["backend"]
    if r["status"] == "ok":
        console.print(f"  ✓ {backend} installed ({r['detail']})")
    else:
        console.print(f"  ✗ {backend} failed: {r['detail']}")


def run_setup(
    backends: list[str] | None = None,
    config: ProjectConfig | None = None,
    *,
    verbose: bool = False,
) -> list[dict[str, str]]:
    """Set up one or more backends in parallel. Returns list of result dicts."""
    if config is None:
        config = ProjectConfig.find_and_load() or ProjectConfig()

    if not backends:
        backends = ["paddle", "torch"]

    # Prepare args for each backend
    backend_args: list[tuple[str, dict[str, str]]] = []
    for backend in backends:
        src: SourceConfig = config.get_source(backend)
        index_url = config.resolve_index_url(backend)
        backend_args.append(
            (
                backend,
                {
                    "index_url": index_url,
                    "extra_index_url": src.extra_index_url,
                    "index_strategy": src.index_strategy,
                    "package": src.package,
                    "version": src.version,
                    "whl": src.whl,
                    "python_version": src.python_version,
                },
            )
        )

    if len(backend_args) == 1:
        # Single backend — run directly
        backend, kwargs = backend_args[0]
        logger.info("Setting up backend: {}", backend)
        console.print(f"Setting up {backend}...")
        r = setup_backend(backend, verbose=verbose, **kwargs)
        _print_backend_result(r)
        if r["status"] == "ok":
            logger.info("  {} installed successfully ({})", backend, r["detail"])
        else:
            logger.error("  {} failed: {}", backend, r["detail"])
        return [r]

    # Multiple backends — run in parallel
    from concurrent.futures import ThreadPoolExecutor, as_completed

    console.print(f"Setting up {len(backend_args)} backend(s) in parallel...")
    results: dict[str, dict[str, str]] = {}
    with ThreadPoolExecutor(max_workers=len(backend_args)) as pool:
        futures = {
            pool.submit(setup_backend, backend, verbose=verbose, **kwargs): backend for backend, kwargs in backend_args
        }
        for future in as_completed(futures):
            backend = futures[future]
            r = future.result()
            results[backend] = r
            _print_backend_result(r)
            if r["status"] == "ok":
                logger.info("  {} installed successfully ({})", backend, r["detail"])
            else:
                logger.error("  {} failed: {}", backend, r["detail"])

    # Return in original order
    return [results[b] for b, _ in backend_args]
