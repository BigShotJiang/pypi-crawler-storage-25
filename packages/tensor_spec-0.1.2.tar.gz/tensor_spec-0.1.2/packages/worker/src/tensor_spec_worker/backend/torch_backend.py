"""TorchBackend: PyTorch framework backend implementation."""

from __future__ import annotations

import contextlib
from typing import Any

import numpy as np

from tensor_spec_core.device import DeviceType
from tensor_spec_core.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec_core.tensor import BoolTensorSpec, ComplexTensorSpec, FloatTensorSpec, IntTensorSpec, TensorSpec
from tensor_spec_worker.backend.base import BackendBase
from tensor_spec_worker.backend.deterministic_generation import (
    FLOAT_TINY,
    LCG_MODULUS,
    LCG_MULTIPLIER,
    OFFSET_STEP,
    ORDINAL_STEP,
    tensor_numel,
)
from tensor_spec_worker.call_runtime import execute_call
from tensor_spec_worker.compare_result import CompareResult


class TorchBackend(BackendBase):
    """Backend for PyTorch framework."""

    def __init__(self) -> None:
        self._torch: Any = None

    @property
    def name(self) -> str:
        return "torch"

    def import_framework(self) -> None:
        import torch

        self._torch = torch

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        torch = self._torch
        device: str | None = None
        if spec.device is not None:
            if spec.device.device_type == DeviceType.CPU:
                device = "cpu"
            elif spec.device.device_type == DeviceType.CUDA:
                device = f"cuda:{spec.device.device_id}"
            else:
                msg = f"Unsupported torch device: {spec.device}"
                raise ValueError(msg)
        t = torch.tensor(np_array, device=device)
        if spec.state and spec.state.need_grad:
            t = t.requires_grad_(True)
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.detach().cpu().numpy()

    def generate_tensor(self, spec: TensorSpec, seed: int, ordinal: int) -> Any:
        torch = self._torch
        device = self._device_string(spec)
        if isinstance(spec, FloatTensorSpec):
            stats = spec.stats or FloatStats()
            data = self._generate_float(spec.shape, device, seed, ordinal, stats)
            target_dtype = self._torch_dtype(spec.dtype)
            data = data.to(target_dtype)
            if stats.nonzero:
                tiny = FLOAT_TINY[spec.dtype]
                data = torch.where(data == 0, torch.full_like(data, tiny), data)
        elif isinstance(spec, IntTensorSpec):
            stats = spec.stats or IntStats()
            data = self._generate_int(spec.shape, device, seed, ordinal, stats).to(self._torch_dtype(spec.dtype))
        elif isinstance(spec, BoolTensorSpec):
            data = self._generate_bool(spec.shape, device, seed, ordinal, spec.stats or BoolStats())
        elif isinstance(spec, ComplexTensorSpec):
            data = self._generate_complex(spec.shape, device, seed, ordinal, spec.stats or ComplexStats()).to(
                self._torch_dtype(spec.dtype)
            )
        else:
            msg = f"Unsupported spec type: {type(spec).__name__}"
            raise TypeError(msg)
        if spec.state and spec.state.need_grad:
            data = data.requires_grad_(True)
        return data

    @property
    def supports_gpu_compare(self) -> bool:
        return True

    def gpu_assert_close(self, actual: Any, expected: Any, atol: float, rtol: float) -> CompareResult:
        torch = self._torch
        if tuple(actual.shape) != tuple(expected.shape):
            return CompareResult(
                passed=False,
                total_count=max(int(actual.numel()), int(expected.numel())),
                detail=f"Shape mismatch: {tuple(actual.shape)} vs {tuple(expected.shape)}",
            )

        if actual.dtype == torch.bool and expected.dtype == torch.bool:
            mismatched = int(torch.count_nonzero(actual != expected).item())
            return CompareResult(
                passed=mismatched == 0,
                mismatched_count=mismatched,
                total_count=int(actual.numel()),
            )

        if actual.is_complex() or expected.is_complex():
            a = actual.to(torch.complex128)
            b = expected.to(torch.complex128)
        else:
            a = actual.to(torch.float64)
            b = expected.to(torch.float64)

        abs_diff = (a - b).abs()
        nan_mask = torch.isnan(a) & torch.isnan(b)
        non_nan_diff = torch.where(nan_mask, torch.zeros_like(abs_diff), abs_diff)
        close = torch.isclose(a, b, atol=atol, rtol=rtol, equal_nan=True)
        mismatched = int(torch.count_nonzero(~close).item())

        if non_nan_diff.numel() == 0:
            max_abs = 0.0
            max_rel = 0.0
        else:
            denom_floor = torch.full_like(non_nan_diff, 1e-12)
            denom = torch.maximum(b.abs(), denom_floor)
            rel_diff = torch.where(nan_mask, torch.zeros_like(non_nan_diff), non_nan_diff / denom)
            max_abs = float(non_nan_diff.max().item())
            max_rel = float(rel_diff.max().item())

        return CompareResult(
            passed=mismatched == 0,
            max_abs_diff=max_abs,
            max_rel_diff=max_rel,
            mismatched_count=mismatched,
            total_count=int(actual.numel()),
        )

    def exec_api(
        self,
        api_name: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        mapping: dict[str, Any] | None = None,
    ) -> Any:
        return execute_call("torch", self._torch, api_name, args, kwargs, mapping)

    def compute_grad(self, output: Any, inputs: list[Any], grad_output: Any | None = None) -> list[Any]:
        torch = self._torch
        grads = torch.autograd.grad(output, inputs, grad_outputs=grad_output, allow_unused=True)
        return list(grads)

    def empty_cache(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def check_cuda_error(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            with contextlib.suppress(Exception):
                torch.cuda.synchronize()

    def _device_string(self, spec: TensorSpec) -> str:
        if spec.device is None or spec.device.device_type == DeviceType.CPU:
            return "cpu"
        if spec.device.device_type == DeviceType.CUDA:
            return f"cuda:{spec.device.device_id}"
        msg = f"Unsupported torch device: {spec.device}"
        raise ValueError(msg)

    def _torch_dtype(self, dtype: str) -> Any:
        torch = self._torch
        mapping = {
            "float16": torch.float16,
            "float32": torch.float32,
            "float64": torch.float64,
            "bfloat16": torch.bfloat16,
            "int8": torch.int8,
            "int16": torch.int16,
            "int32": torch.int32,
            "int64": torch.int64,
            "uint8": torch.uint8,
            "bool": torch.bool,
            "complex64": torch.complex64,
            "complex128": torch.complex128,
        }
        return mapping[dtype]

    def _base_sequence(self, shape: tuple[int, ...], device: str, seed: int, ordinal: int, offset: int = 0) -> Any:
        torch = self._torch
        size = tensor_numel(shape)
        base = (int(seed) % LCG_MODULUS) + ordinal * ORDINAL_STEP + offset * OFFSET_STEP + 1
        seq = torch.arange(size, dtype=torch.int64, device=device)
        seq = torch.remainder(seq + base, LCG_MODULUS)
        seq = torch.remainder(seq * LCG_MULTIPLIER + 12_345, LCG_MODULUS)
        return seq.reshape(shape if shape else ())

    def _uniform(self, shape: tuple[int, ...], device: str, seed: int, ordinal: int, offset: int = 0) -> Any:
        torch = self._torch
        seq = self._base_sequence(shape, device, seed, ordinal, offset)
        return seq.to(torch.float64) / float(LCG_MODULUS - 1)

    def _generate_float(self, shape: tuple[int, ...], device: str, seed: int, ordinal: int, stats: FloatStats) -> Any:
        torch = self._torch
        data = stats.min + self._uniform(shape, device, seed, ordinal) * (stats.max - stats.min)
        if stats.positive_definite:
            if len(shape) < 2 or shape[-1] != shape[-2]:
                msg = f"positive_definite requires square matrices, got shape {shape}"
                raise ValueError(msg)
            n = shape[-1]
            data = data.reshape((-1, n, n))
            eye = torch.eye(n, dtype=data.dtype, device=device).unsqueeze(0).expand(data.shape[0], -1, -1)
            data = data @ data.transpose(-1, -2) + eye
            data = data.reshape(shape if shape else ())
        return data

    def _generate_int(self, shape: tuple[int, ...], device: str, seed: int, ordinal: int, stats: IntStats) -> Any:
        torch = self._torch
        span = stats.high - stats.low
        data = stats.low + torch.remainder(self._base_sequence(shape, device, seed, ordinal, offset=1), span)
        if stats.nonzero:
            data = torch.where(data == 0, torch.ones_like(data), data)
        return data

    def _generate_bool(self, shape: tuple[int, ...], device: str, seed: int, ordinal: int, stats: BoolStats) -> Any:
        torch = self._torch
        if stats.all_true:
            return torch.ones(shape if shape else (), dtype=torch.bool, device=device)
        if stats.all_false:
            return torch.zeros(shape if shape else (), dtype=torch.bool, device=device)
        return self._uniform(shape, device, seed, ordinal, offset=2) < stats.true_ratio

    def _generate_complex(
        self,
        shape: tuple[int, ...],
        device: str,
        seed: int,
        ordinal: int,
        stats: ComplexStats,
    ) -> Any:
        torch = self._torch
        real = stats.real_min + self._uniform(shape, device, seed, ordinal, offset=3) * (
            stats.real_max - stats.real_min
        )
        imag = stats.imag_min + self._uniform(shape, device, seed, ordinal, offset=4) * (
            stats.imag_max - stats.imag_min
        )
        return torch.complex(real.to(torch.float64), imag.to(torch.float64))
