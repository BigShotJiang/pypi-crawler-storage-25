"""Abstract base class for framework backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from tensor_spec_core.tensor import TensorSpec


class BackendBase(ABC):
    """Abstract base class for all framework backends."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Backend name (e.g. 'paddle', 'torch')."""
        ...

    @abstractmethod
    def import_framework(self) -> None:
        """Import the framework. Called once at worker startup."""
        ...

    @abstractmethod
    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        """Convert a numpy array to a framework tensor."""
        ...

    @abstractmethod
    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        """Convert a framework tensor back to numpy."""
        ...

    @abstractmethod
    def generate_tensor(self, spec: TensorSpec, seed: int, ordinal: int) -> Any:
        """Generate a framework-native tensor directly from a TensorSpec."""
        ...

    @property
    def supports_gpu_compare(self) -> bool:
        """Whether this backend can compare tensors directly on GPU."""
        return False

    def gpu_assert_close(self, actual: Any, expected: Any, atol: float, rtol: float) -> Any:
        """Compare two tensors on GPU and return a structured compare result."""
        msg = f"{self.name} does not support GPU comparison"
        raise NotImplementedError(msg)

    @abstractmethod
    def exec_api(
        self,
        api_name: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        mapping: dict[str, Any] | None = None,
    ) -> Any:
        """Execute a framework API call."""
        ...

    @abstractmethod
    def empty_cache(self) -> None:
        """Clear GPU memory cache."""
        ...

    @abstractmethod
    def compute_grad(self, output: Any, inputs: list[Any], grad_output: Any | None = None) -> list[Any]:
        """Compute gradients of output w.r.t. inputs."""
        ...

    @abstractmethod
    def check_cuda_error(self) -> None:
        """Check for asynchronous CUDA errors. No-op on CPU."""
        ...
