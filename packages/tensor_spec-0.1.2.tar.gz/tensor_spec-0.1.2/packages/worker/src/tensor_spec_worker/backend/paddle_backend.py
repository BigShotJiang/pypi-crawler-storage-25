"""PaddleBackend: Paddle framework backend implementation."""

from __future__ import annotations

import contextlib
from typing import Any

import numpy as np

from tensor_spec_core.device import DeviceType
from tensor_spec_core.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec_core.tensor import BoolTensorSpec, ComplexTensorSpec, FloatTensorSpec, IntTensorSpec, TensorSpec
from tensor_spec_worker.backend.base import BackendBase
from tensor_spec_worker.backend.deterministic_generation import (
    FLOAT_TINY,
    LCG_MODULUS,
    LCG_MULTIPLIER,
    OFFSET_STEP,
    ORDINAL_STEP,
    tensor_numel,
)
from tensor_spec_worker.call_runtime import execute_call


class PaddleBackend(BackendBase):
    """Backend for PaddlePaddle framework."""

    def __init__(self) -> None:
        self._paddle: Any = None

    @property
    def name(self) -> str:
        return "paddle"

    def import_framework(self) -> None:
        import paddle

        self._paddle = paddle

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        paddle = self._paddle
        place: str | None = None
        if spec.device is not None:
            if spec.device.device_type == DeviceType.CPU:
                place = "cpu"
            elif spec.device.device_type == DeviceType.CUDA:
                place = f"gpu:{spec.device.device_id}"
            else:
                msg = f"Unsupported paddle device: {spec.device}"
                raise ValueError(msg)
        t = paddle.to_tensor(np_array, place=place) if place is not None else paddle.to_tensor(np_array)
        if spec.state and spec.state.need_grad:
            t.stop_gradient = False
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.numpy(force=True)

    def generate_tensor(self, spec: TensorSpec, seed: int, ordinal: int) -> Any:
        paddle = self._paddle
        place = self._place_string(spec)
        self._set_place(place)
        if isinstance(spec, FloatTensorSpec):
            stats = spec.stats or FloatStats()
            data = self._generate_float(spec.shape, seed, ordinal, stats)
            data = paddle.cast(data, spec.dtype)
            if stats.nonzero:
                tiny = FLOAT_TINY[spec.dtype]
                data = paddle.where(data == 0, paddle.full_like(data, tiny), data)
        elif isinstance(spec, IntTensorSpec):
            stats = spec.stats or IntStats()
            data = paddle.cast(self._generate_int(spec.shape, seed, ordinal, stats), spec.dtype)
        elif isinstance(spec, BoolTensorSpec):
            data = self._generate_bool(spec.shape, seed, ordinal, spec.stats or BoolStats())
        elif isinstance(spec, ComplexTensorSpec):
            complex_data = self._generate_complex(spec.shape, seed, ordinal, spec.stats or ComplexStats())
            data = paddle.cast(complex_data, spec.dtype)
        else:
            msg = f"Unsupported spec type: {type(spec).__name__}"
            raise TypeError(msg)
        if spec.state and spec.state.need_grad:
            data.stop_gradient = False
        return data

    def exec_api(
        self,
        api_name: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        mapping: dict[str, Any] | None = None,
    ) -> Any:
        return execute_call("paddle", self._paddle, api_name, args, kwargs, mapping)

    def empty_cache(self) -> None:
        import contextlib

        paddle = self._paddle
        if hasattr(paddle, "device") and hasattr(paddle.device, "cuda"):
            with contextlib.suppress(Exception):
                paddle.device.cuda.empty_cache()

    def compute_grad(self, output: Any, inputs: list[Any], grad_output: Any | None = None) -> list[Any]:
        paddle = self._paddle
        return paddle.grad(output, inputs, grad_outputs=grad_output, allow_unused=True)

    def check_cuda_error(self) -> None:
        paddle = self._paddle
        if hasattr(paddle, "base") and hasattr(paddle.base, "core"):
            with contextlib.suppress(Exception):
                paddle.base.core.eager._for_test_check_cuda_error()

    def _place_string(self, spec: TensorSpec) -> str:
        if spec.device is None or spec.device.device_type == DeviceType.CPU:
            return "cpu"
        if spec.device.device_type == DeviceType.CUDA:
            return f"gpu:{spec.device.device_id}"
        msg = f"Unsupported paddle device: {spec.device}"
        raise ValueError(msg)

    def _set_place(self, place: str) -> None:
        self._paddle.device.set_device(place)

    def _base_sequence(self, shape: tuple[int, ...], seed: int, ordinal: int, offset: int = 0) -> Any:
        paddle = self._paddle
        size = tensor_numel(shape)
        base = (int(seed) % LCG_MODULUS) + ordinal * ORDINAL_STEP + offset * OFFSET_STEP + 1
        seq = paddle.arange(size, dtype="int64")
        seq = paddle.remainder(seq + base, LCG_MODULUS)
        seq = paddle.remainder(seq * LCG_MULTIPLIER + 12_345, LCG_MODULUS)
        return paddle.reshape(seq, list(shape))

    def _uniform(self, shape: tuple[int, ...], seed: int, ordinal: int, offset: int = 0) -> Any:
        paddle = self._paddle
        seq = self._base_sequence(shape, seed, ordinal, offset)
        return paddle.cast(seq, "float64") / float(LCG_MODULUS - 1)

    def _generate_float(self, shape: tuple[int, ...], seed: int, ordinal: int, stats: FloatStats) -> Any:
        paddle = self._paddle
        data = stats.min + self._uniform(shape, seed, ordinal) * (stats.max - stats.min)
        if stats.positive_definite:
            if len(shape) < 2 or shape[-1] != shape[-2]:
                msg = f"positive_definite requires square matrices, got shape {shape}"
                raise ValueError(msg)
            n = shape[-1]
            data = paddle.reshape(data, [-1, n, n])
            eye = paddle.eye(n, dtype=str(data.dtype)).reshape([1, n, n])
            eye = paddle.expand(eye, [data.shape[0], n, n])
            data = paddle.matmul(data, paddle.transpose(data, [0, 2, 1])) + eye
            data = paddle.reshape(data, list(shape))
        return data

    def _generate_int(self, shape: tuple[int, ...], seed: int, ordinal: int, stats: IntStats) -> Any:
        paddle = self._paddle
        span = stats.high - stats.low
        data = stats.low + paddle.remainder(self._base_sequence(shape, seed, ordinal, offset=1), span)
        if stats.nonzero:
            data = paddle.where(data == 0, paddle.ones_like(data), data)
        return data

    def _generate_bool(self, shape: tuple[int, ...], seed: int, ordinal: int, stats: BoolStats) -> Any:
        paddle = self._paddle
        if stats.all_true:
            return paddle.ones(list(shape), dtype="bool")
        if stats.all_false:
            return paddle.zeros(list(shape), dtype="bool")
        return self._uniform(shape, seed, ordinal, offset=2) < stats.true_ratio

    def _generate_complex(self, shape: tuple[int, ...], seed: int, ordinal: int, stats: ComplexStats) -> Any:
        paddle = self._paddle
        real = stats.real_min + self._uniform(shape, seed, ordinal, offset=3) * (stats.real_max - stats.real_min)
        imag = stats.imag_min + self._uniform(shape, seed, ordinal, offset=4) * (stats.imag_max - stats.imag_min)
        return paddle.complex(real, imag)
