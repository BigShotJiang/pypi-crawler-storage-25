"""Shared helpers for deterministic backend-native tensor generation."""

from __future__ import annotations

import math

LCG_MODULUS = 2_147_483_647
LCG_MULTIPLIER = 48_271
ORDINAL_STEP = 104_729
OFFSET_STEP = 8_191

FLOAT_TINY: dict[str, float] = {
    "float16": 6.103515625e-05,
    "bfloat16": 1.1754943508222875e-38,
    "float32": 1.1754943508222875e-38,
    "float64": 2.2250738585072014e-308,
}


def tensor_numel(shape: tuple[int, ...]) -> int:
    """Return the number of elements in a shape, including scalars."""
    return math.prod(shape) if shape else 1
