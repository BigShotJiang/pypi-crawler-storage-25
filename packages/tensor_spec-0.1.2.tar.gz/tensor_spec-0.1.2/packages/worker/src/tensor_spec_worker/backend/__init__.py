"""Framework backend layer."""
