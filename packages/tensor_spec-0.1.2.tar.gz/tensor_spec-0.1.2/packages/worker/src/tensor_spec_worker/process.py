"""Worker subprocess: runs in framework venv, executes commands over stdin/stdout."""

from __future__ import annotations

import json
import re
import sys
from dataclasses import asdict
from typing import Any

from tensor_spec_worker.ipc.shared_memory import ShmBuffer, read_array, write_array
from tensor_spec_worker.protocol import decode_arg_value
from tensor_spec_worker.spec_codec import decode_spec


class Worker:
    """Framework-isolated worker that processes JSON commands."""

    def __init__(self, backend_name: str) -> None:
        self.backend_name = backend_name
        self._backend: Any = None
        self._tensors: dict[str, Any] = {}
        self._ipc_ptrs: dict[str, int] = {}
        self._next_id = 0

    def _gen_id(self) -> str:
        self._next_id += 1
        return f"t{self._next_id}"

    def handle(self, msg: dict) -> dict:
        """Dispatch a single message and return a response dict."""
        msg_type = msg["type"]
        payload = msg.get("payload", {})

        handler = getattr(self, f"_handle_{msg_type}", None)
        if handler is None:
            return {"ok": False, "error": f"Unknown message type: {msg_type}"}
        return handler(payload)

    # -- lifecycle --

    def _handle_ping(self, _payload: dict) -> dict:
        return {"ok": True, "result": "pong"}

    def _handle_shutdown(self, _payload: dict) -> dict:
        return {"ok": True, "result": "bye"}

    def _handle_import_framework(self, _payload: dict) -> dict:
        self._backend = _load_backend(self.backend_name)
        self._backend.import_framework()
        return {"ok": True, "result": self._backend.name}

    def _handle_backend_info(self, _payload: dict) -> dict:
        if self._backend is None:
            return {"ok": False, "error": "Framework not imported"}
        return {
            "ok": True,
            "result": {
                "name": self._backend.name,
                "supports_gpu_compare": self._backend.supports_gpu_compare,
            },
        }

    # -- tensor operations --

    def _handle_load_tensor(self, payload: dict) -> dict:
        """Load numpy from SharedMemory -> framework tensor."""
        buf = ShmBuffer(
            name=payload["shm_name"],
            shape=tuple(payload["spec"]["shape"]),
            dtype=payload["spec"]["dtype"],
            nbytes=0,  # not needed for read
        )
        arr = read_array(buf)
        spec = decode_spec(payload["spec"])
        tensor = self._backend.numpy_to_tensor(arr, spec)
        tid = self._gen_id()
        self._tensors[tid] = tensor
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_generate_tensor(self, payload: dict) -> dict:
        """Generate a framework-native tensor directly inside the worker."""
        spec = decode_spec(payload["spec"])
        tensor = self._backend.generate_tensor(spec, int(payload["seed"]), int(payload["ordinal"]))
        tid = self._gen_id()
        self._tensors[tid] = tensor
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_store_tensor(self, payload: dict) -> dict:
        """Framework tensor -> numpy -> SharedMemory."""
        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        arr = self._backend.tensor_to_numpy(self._tensors[tid])
        buf = write_array(arr, untrack=True)
        return {"ok": True, "result": buf.to_dict()}

    def _handle_tensor_info(self, payload: dict) -> dict:
        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        tensor = self._tensors[tid]
        shape, dtype = self._get_tensor_meta(tensor)
        return {
            "ok": True,
            "result": {
                "shape": list(shape),
                "dtype": dtype,
                "device": self._get_tensor_device(tensor),
            },
        }

    def _handle_exec_api(self, payload: dict) -> dict:
        """Execute a framework API call."""
        api_name = payload["api"]
        mapping = payload.get("mapping")
        raw_args = payload.get("args", [])
        raw_kwargs = payload.get("kwargs", {})
        args = tuple(decode_arg_value(v, self._tensors) for v in raw_args)
        kwargs = {k: decode_arg_value(v, self._tensors) for k, v in raw_kwargs.items()}
        result = self._backend.exec_api(api_name, args, kwargs, mapping)
        tid = self._gen_id()
        self._tensors[tid] = result
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_free_tensor(self, payload: dict) -> dict:
        """Release a tensor from local storage."""
        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        del self._tensors[tid]
        return {"ok": True}

    def _handle_empty_cache(self, _payload: dict) -> dict:
        self._backend.empty_cache()
        return {"ok": True}

    def _handle_check_cuda_error(self, _payload: dict) -> dict:
        self._backend.check_cuda_error()
        return {"ok": True}

    def _handle_compare_tensors(self, payload: dict) -> dict:
        if self._backend is None:
            return {"ok": False, "error": "Framework not imported"}
        actual_tid = payload["actual_tensor_id"]
        expected_tid = payload["expected_tensor_id"]
        if actual_tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {actual_tid}"}
        if expected_tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {expected_tid}"}
        result = self._backend.gpu_assert_close(
            self._tensors[actual_tid],
            self._tensors[expected_tid],
            payload["atol"],
            payload["rtol"],
        )
        return {"ok": True, "result": asdict(result)}

    # -- GPU IPC operations --

    def _handle_get_ipc_handle(self, payload: dict) -> dict:
        """Get CUDA IPC handle for a GPU tensor."""
        import base64

        from tensor_spec_worker.ipc.cuda_handle import get_ipc_handle

        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        tensor = self._tensors[tid]
        device = self._get_tensor_device(tensor)
        if not device.startswith("cuda:"):
            return {"ok": False, "error": f"Tensor {tid} is not on CUDA: {device}"}
        device_ptr = self._get_data_ptr(tensor)
        handle_bytes = get_ipc_handle(device_ptr)
        shape, dtype = self._get_tensor_meta(tensor)
        return {
            "ok": True,
            "result": {
                "handle": base64.b64encode(handle_bytes).decode(),
                "shape": list(shape),
                "dtype": dtype,
                "device": device,
            },
        }

    def _handle_open_ipc_handle(self, payload: dict) -> dict:
        """Open a CUDA IPC handle and wrap as a framework tensor."""
        import base64

        from tensor_spec_worker.ipc.cuda_handle import open_ipc_handle
        from tensor_spec_worker.ipc.gpu_array_view import GpuArrayView

        handle_bytes = base64.b64decode(payload["handle"])
        shape = tuple(payload["shape"])
        dtype = payload["dtype"]
        device = payload.get("device", "cuda:0")
        ptr = open_ipc_handle(handle_bytes)
        view = GpuArrayView(ptr=ptr, shape=shape, dtype=dtype)
        if self.backend_name == "torch":
            import torch

            tensor = torch.as_tensor(view, device=device)
        elif self.backend_name == "paddle":
            import paddle

            tensor = paddle.to_tensor(view)
        else:
            return {"ok": False, "error": f"GPU IPC not supported for {self.backend_name}"}
        tid = self._gen_id()
        self._tensors[tid] = tensor
        self._ipc_ptrs[tid] = ptr
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_close_ipc_handle(self, payload: dict) -> dict:
        """Close a previously opened IPC handle."""
        from tensor_spec_worker.ipc.cuda_handle import close_ipc_handle

        tid = payload["tensor_id"]
        if tid in self._ipc_ptrs:
            close_ipc_handle(self._ipc_ptrs.pop(tid))
        if tid in self._tensors:
            del self._tensors[tid]
        return {"ok": True}

    # -- helper methods --

    def _get_data_ptr(self, tensor: Any) -> int:
        """Get the raw GPU data pointer from a framework tensor."""
        if self.backend_name == "torch":
            return tensor.data_ptr()
        if self.backend_name == "paddle":
            return tensor.data_ptr()
        raise RuntimeError(f"data_ptr not supported for {self.backend_name}")

    def _get_tensor_meta(self, tensor: Any) -> tuple[tuple[int, ...], str]:
        """Get (shape, dtype_str) from a framework tensor."""
        if self.backend_name == "torch":
            shape = tuple(tensor.shape)
            dtype = str(tensor.dtype).replace("torch.", "")
            return shape, dtype
        if self.backend_name == "paddle":
            shape = tuple(tensor.shape)
            dtype = str(tensor.dtype).split(".")[-1]
            return shape, dtype
        raise RuntimeError(f"meta not supported for {self.backend_name}")

    def _get_tensor_device(self, tensor: Any) -> str:
        """Get a normalized device string such as cpu or cuda:0."""
        if self.backend_name == "torch":
            device = tensor.device
            if device.type == "cuda":
                index = 0 if device.index is None else int(device.index)
                return f"cuda:{index}"
            return device.type
        if self.backend_name == "paddle":
            place = str(tensor.place).lower()
            if "gpu" in place:
                match = re.search(r"gpu:(\d+)", place)
                index = int(match.group(1)) if match is not None else 0
                return f"cuda:{index}"
            return "cpu"
        raise RuntimeError(f"device inspection not supported for {self.backend_name}")

    # -- main loop --

    def run(self) -> None:
        """Read JSON lines from stdin, process, write responses to stdout."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            msg = json.loads(line)
            try:
                resp = self.handle(msg)
            except Exception as e:
                resp = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            resp["id"] = msg.get("id")
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            if msg["type"] == "shutdown":
                break


def _load_backend(name: str) -> Any:
    """Load a backend by name."""
    if name == "paddle":
        from tensor_spec_worker.backend.paddle_backend import PaddleBackend

        return PaddleBackend()
    if name == "torch":
        from tensor_spec_worker.backend.torch_backend import TorchBackend

        return TorchBackend()
    raise ValueError(f"Unknown backend: {name}. Available: paddle, torch")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="tensor-spec worker process")
    parser.add_argument("--backend", required=True, help="Backend name (paddle, torch)")
    args = parser.parse_args()
    Worker(args.backend).run()


if __name__ == "__main__":
    main()
