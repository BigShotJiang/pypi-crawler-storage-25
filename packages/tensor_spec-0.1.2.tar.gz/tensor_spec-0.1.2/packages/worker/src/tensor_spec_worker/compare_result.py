"""Structured comparison result used inside the worker package."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CompareResult:
    """Structured result of a tensor comparison."""

    passed: bool
    max_abs_diff: float = 0.0
    max_rel_diff: float = 0.0
    mismatched_count: int = 0
    total_count: int = 0
    detail: str = ""
