"""Standalone profiling harness executed under `ncu`."""

from __future__ import annotations

import argparse
import ctypes
import json
from pathlib import Path
from typing import Any

from tensor_spec_worker.process import _load_backend
from tensor_spec_worker.protocol import decode_arg_value
from tensor_spec_worker.spec_codec import decode_spec


def _check_cuda_call(status: int) -> None:
    if status != 0:
        raise RuntimeError(f"CUDA runtime call failed with status {status}")


def _cuda_runtime() -> ctypes.CDLL:
    return ctypes.CDLL("libcudart.so")


def _cuda_profiler_start() -> None:
    _check_cuda_call(_cuda_runtime().cudaProfilerStart())


def _cuda_profiler_stop() -> None:
    _check_cuda_call(_cuda_runtime().cudaProfilerStop())


def _cuda_device_synchronize() -> None:
    _check_cuda_call(_cuda_runtime().cudaDeviceSynchronize())


def _decode_profile_value(value: Any, backend: Any, seed: int) -> Any:
    if isinstance(value, dict) and "_tensor_spec" in value:
        spec = decode_spec(value["_tensor_spec"])
        return backend.generate_tensor(spec, seed, int(value["ordinal"]))
    if isinstance(value, dict) and "_t" in value:
        items = [_decode_profile_value(item, backend, seed) for item in value["items"]]
        return decode_arg_value({"_t": value["_t"], "items": items}, {})
    if isinstance(value, list):
        return [_decode_profile_value(item, backend, seed) for item in value]
    if isinstance(value, dict):
        return {key: _decode_profile_value(item, backend, seed) for key, item in value.items()}
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description="tensor-spec NCU harness")
    parser.add_argument("--backend", required=True, help="Backend name (paddle, torch)")
    parser.add_argument("--payload", required=True, help="Path to serialized profiling payload")
    args = parser.parse_args()

    payload = json.loads(Path(args.payload).read_text())
    backend = _load_backend(args.backend)
    backend.import_framework()

    seed = int(payload["seed"])
    call_args = tuple(_decode_profile_value(item, backend, seed) for item in payload["args"])
    call_kwargs = {key: _decode_profile_value(value, backend, seed) for key, value in payload["kwargs"].items()}

    backend.empty_cache()
    _cuda_device_synchronize()
    _cuda_profiler_start()
    try:
        backend.exec_api(payload["api"], call_args, call_kwargs, payload.get("mapping"))
        _cuda_device_synchronize()
        backend.check_cuda_error()
    finally:
        _cuda_profiler_stop()


if __name__ == "__main__":
    main()
