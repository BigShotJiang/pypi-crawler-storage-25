"""Serialize and deserialize TensorSpec payloads for worker transport."""

from __future__ import annotations

from dataclasses import asdict, replace
from typing import Any

from tensor_spec_core.device import DeviceSpec, DeviceType
from tensor_spec_core.state import TensorState
from tensor_spec_core.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec_core.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    Tensor,
    TensorSpec,
)


def encode_spec(spec: TensorSpec) -> dict[str, Any]:
    """Encode a TensorSpec into a JSON-serializable payload."""
    payload: dict[str, Any] = {
        "shape": list(spec.shape),
        "dtype": spec.dtype,
    }
    if spec.device is not None:
        payload["device"] = {
            "device_type": int(spec.device.device_type),
            "device_id": spec.device.device_id,
        }
    if spec.state is not None:
        payload["state"] = asdict(spec.state)

    stats_payload = _encode_stats(spec)
    if stats_payload is not None:
        payload["stats"] = stats_payload
    return payload


def decode_spec(payload: dict[str, Any]) -> TensorSpec:
    """Decode a TensorSpec payload produced by encode_spec()."""
    dtype_factory = getattr(Tensor, payload["dtype"], None)
    if dtype_factory is None:
        msg = f"Unknown dtype: {payload['dtype']}"
        raise ValueError(msg)

    device = None
    if "device" in payload:
        device_payload = payload["device"]
        device = DeviceSpec(
            device_type=DeviceType(device_payload["device_type"]),
            device_id=device_payload["device_id"],
        )

    spec = dtype_factory(tuple(payload["shape"]), device)

    if "stats" in payload:
        spec = _decode_stats(spec, payload["stats"])
    if "state" in payload:
        spec = replace(spec, state=TensorState(**payload["state"]))
    return spec


def _encode_stats(spec: TensorSpec) -> dict[str, Any] | None:
    if isinstance(spec, FloatTensorSpec) and spec.stats is not None:
        return {"kind": "float", "data": asdict(spec.stats)}
    if isinstance(spec, IntTensorSpec) and spec.stats is not None:
        return {"kind": "int", "data": asdict(spec.stats)}
    if isinstance(spec, BoolTensorSpec) and spec.stats is not None:
        return {"kind": "bool", "data": asdict(spec.stats)}
    if isinstance(spec, ComplexTensorSpec) and spec.stats is not None:
        return {"kind": "complex", "data": asdict(spec.stats)}
    return None


def _decode_stats(spec: TensorSpec, payload: dict[str, Any]) -> TensorSpec:
    kind = payload["kind"]
    data = payload["data"]
    if isinstance(spec, FloatTensorSpec) and kind == "float":
        return spec.with_stats(FloatStats(**data))
    if isinstance(spec, IntTensorSpec) and kind == "int":
        return spec.with_stats(IntStats(**data))
    if isinstance(spec, BoolTensorSpec) and kind == "bool":
        return spec.with_stats(BoolStats(**data))
    if isinstance(spec, ComplexTensorSpec) and kind == "complex":
        return spec.with_stats(ComplexStats(**data))
    msg = f"Stats kind {kind!r} does not match spec dtype {spec.dtype!r}"
    raise ValueError(msg)
