"""CUDA IPC handle wrapper using ctypes.

Key insight from POC: cudaIpcOpenMemHandle receives the handle BY VALUE,
so we MUST use ctypes.Structure (not raw c_byte array) for correct ABI.
"""

from __future__ import annotations

import ctypes

# Flag for cudaIpcOpenMemHandle: enable lazy peer access
_cudaIpcMemLazyEnablePeerAccess = 0x01


class CudaIpcMemHandle(ctypes.Structure):
    """64-byte CUDA IPC memory handle -- matches cudaIpcMemHandle_t."""

    _fields_ = [("reserved", ctypes.c_byte * 64)]


def get_cuda_rt() -> ctypes.CDLL | None:
    """Load libcudart.so and set up function signatures. Returns None if unavailable."""
    try:
        cuda_rt = ctypes.CDLL("libcudart.so")
    except OSError:
        return None

    cuda_rt.cudaIpcGetMemHandle.argtypes = [
        ctypes.POINTER(CudaIpcMemHandle),
        ctypes.c_void_p,
    ]
    cuda_rt.cudaIpcGetMemHandle.restype = ctypes.c_int

    cuda_rt.cudaIpcOpenMemHandle.argtypes = [
        ctypes.POINTER(ctypes.c_void_p),
        CudaIpcMemHandle,
        ctypes.c_uint,
    ]
    cuda_rt.cudaIpcOpenMemHandle.restype = ctypes.c_int

    cuda_rt.cudaIpcCloseMemHandle.argtypes = [ctypes.c_void_p]
    cuda_rt.cudaIpcCloseMemHandle.restype = ctypes.c_int

    return cuda_rt


# Module-level singleton (lazy)
_cuda_rt: ctypes.CDLL | None = None


def _rt() -> ctypes.CDLL:
    """Get the CUDA runtime, raising if unavailable."""
    global _cuda_rt
    if _cuda_rt is None:
        _cuda_rt = get_cuda_rt()
    if _cuda_rt is None:
        msg = "CUDA runtime (libcudart.so) not available"
        raise RuntimeError(msg)
    return _cuda_rt


def get_ipc_handle(device_ptr: int) -> bytes:
    """Get a 64-byte IPC handle for a device pointer."""
    handle = CudaIpcMemHandle()
    err = _rt().cudaIpcGetMemHandle(ctypes.byref(handle), device_ptr)
    if err != 0:
        msg = f"cudaIpcGetMemHandle failed with error {err}"
        raise RuntimeError(msg)
    return bytes(handle.reserved)


def open_ipc_handle(handle_bytes: bytes) -> int:
    """Open an IPC handle, returning a device pointer. Caller must close it."""
    handle = CudaIpcMemHandle()
    ctypes.memmove(handle.reserved, handle_bytes, 64)
    ptr = ctypes.c_void_p()
    err = _rt().cudaIpcOpenMemHandle(
        ctypes.byref(ptr),
        handle,
        _cudaIpcMemLazyEnablePeerAccess,
    )
    if err != 0:
        msg = f"cudaIpcOpenMemHandle failed with error {err}"
        raise RuntimeError(msg)
    if ptr.value is None:
        msg = "cudaIpcOpenMemHandle returned null pointer"
        raise RuntimeError(msg)
    return ptr.value


def close_ipc_handle(device_ptr: int) -> None:
    """Close an IPC handle opened by open_ipc_handle."""
    err = _rt().cudaIpcCloseMemHandle(device_ptr)
    if err != 0:
        msg = f"cudaIpcCloseMemHandle failed with error {err}"
        raise RuntimeError(msg)
