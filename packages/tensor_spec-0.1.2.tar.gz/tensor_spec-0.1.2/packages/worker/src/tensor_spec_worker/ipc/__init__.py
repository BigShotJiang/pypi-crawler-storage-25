"""IPC transport layer for cross-process tensor sharing."""
