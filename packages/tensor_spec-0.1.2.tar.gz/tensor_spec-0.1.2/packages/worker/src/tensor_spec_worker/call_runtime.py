"""Shared runtime for executing mapped backend calls."""

from __future__ import annotations

import math
from collections.abc import Callable
from typing import Any

CallMapping = dict[str, Any]
CallHandler = Callable[[str, Any, str, tuple[Any, ...], dict[str, Any], CallMapping], Any]

_SAFE_EVAL_GLOBALS = {
    "__builtins__": {},
    "all": all,
    "any": any,
    "bool": bool,
    "complex": complex,
    "float": float,
    "getattr": getattr,
    "hasattr": hasattr,
    "int": int,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "math": math,
    "max": max,
    "min": min,
    "range": range,
    "str": str,
    "sum": sum,
    "tuple": tuple,
}


def execute_call(
    framework_name: str,
    framework: Any,
    api_name: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    mapping: CallMapping | None = None,
) -> Any:
    """Execute a backend call with optional mapping metadata."""
    call_mapping = mapping or {}
    handler_name = call_mapping.get("handler")

    if handler_name is not None:
        try:
            handler = _HANDLERS[handler_name]
        except KeyError as e:
            raise ValueError(f"Unknown call handler: {handler_name}") from e
        result = handler(framework_name, framework, api_name, args, kwargs, call_mapping)
    elif api_name.startswith("Tensor."):
        result = _execute_tensor_method(framework, api_name, args, kwargs, call_mapping)
    else:
        mapped_kwargs = _build_mapped_kwargs(framework, api_name, args, kwargs, call_mapping)
        api_func = _resolve_api(framework_name, framework, api_name)
        result = api_func(*args, **mapped_kwargs)

    result_index = call_mapping.get("result_index")
    if result_index is not None:
        result = _select_result(result, result_index)
    return result


def _resolve_api(framework_name: str, framework: Any, api_name: str) -> Any:
    resolved_name = api_name
    prefix = f"{framework_name}."
    if resolved_name.startswith(prefix):
        resolved_name = resolved_name[len(prefix) :]

    obj = framework
    for part in resolved_name.split("."):
        obj = getattr(obj, part)
    return obj


def _select_result(result: Any, index: int) -> Any:
    if not isinstance(result, (list, tuple)):
        if index == 0:
            return result
        raise TypeError(f"result_index requires a list/tuple result, got: {type(result).__name__}")
    return result[index]


def _normalize_axis(torch: Any, axis: Any) -> Any:
    if isinstance(axis, (tuple, list)):
        if not axis:
            return None
        values = [item.item() if torch.is_tensor(item) else item for item in axis]
        return tuple(values)
    if torch.is_tensor(axis):
        if axis.numel() == 0:
            return None
        if axis.dim() == 0:
            return axis.item()
        return tuple(axis.tolist())
    return axis


def _to_python_value(torch: Any, value: Any) -> Any:
    if torch.is_tensor(value):
        return value.item() if value.dim() == 0 else value.tolist()
    return value


def _reshape_keepdim_result(result: Any, x: Any) -> Any:
    return result.reshape([1] * x.dim())


def _squeeze_dims(torch: Any, x: Any, dims: tuple[int, ...]) -> Any:
    result = x
    for dim in sorted(dims, reverse=True):
        result = torch.squeeze(result, dim=dim)
    return result


def _execute_tensor_method(
    framework: Any,
    api_name: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    mapping: CallMapping,
) -> Any:
    method_name = api_name[len("Tensor.") :]
    call_kwargs = dict(kwargs)
    target = call_kwargs.pop("self", None)
    positional_args = list(args)

    if target is None:
        if not positional_args:
            raise ValueError(f"Tensor method {api_name} requires `self`")
        target = positional_args.pop(0)

    mapped_kwargs = _build_mapped_kwargs(
        framework,
        api_name,
        tuple(positional_args),
        call_kwargs,
        mapping,
        extra_context={"self": target},
    )

    if method_name == "__getitem__":
        if positional_args:
            index = positional_args[0]
        else:
            try:
                index = mapped_kwargs.pop("indices")
            except KeyError as e:
                raise ValueError("Tensor.__getitem__ requires `indices`") from e
        return target[index]

    method = getattr(target, method_name)
    return method(*positional_args, **mapped_kwargs)


def _build_mapped_kwargs(
    framework: Any,
    api_name: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    mapping: CallMapping,
    extra_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    args_map = mapping.get("args_map", {})
    drop_kwargs = set(mapping.get("drop_kwargs", []))
    mapped_kwargs = {
        args_map.get(key, key): value
        for key, value in kwargs.items()
        if key not in drop_kwargs and args_map.get(key, key) not in drop_kwargs
    }

    for key, value in mapping.get("default_kwargs", {}).items():
        mapped_kwargs.setdefault(key, value)

    computed_kwargs = mapping.get("computed_kwargs", {})
    if computed_kwargs:
        context = {
            "api_name": api_name,
            "args": args,
            "framework": framework,
            "kwargs": kwargs,
            "mapped_kwargs": mapped_kwargs,
            **kwargs,
        }
        if extra_context is not None:
            context.update(extra_context)
        for key, expr in computed_kwargs.items():
            mapped_kwargs[key] = _evaluate_expression(expr, context)
            context[key] = mapped_kwargs[key]
            context["mapped_kwargs"] = mapped_kwargs

    return mapped_kwargs


def _evaluate_expression(expr: str, context: dict[str, Any]) -> Any:
    try:
        return eval(expr, _SAFE_EVAL_GLOBALS, context)
    except Exception as e:
        raise ValueError(f"Failed to evaluate mapping expression `{expr}`: {e}") from e


def _torch_put_along_axis(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    input_tensor = kwargs["arr"]
    dim = kwargs["axis"]
    index = kwargs["indices"]
    src = kwargs["values"]
    reduce = kwargs.get("reduce", "assign")
    if reduce == "add":
        reduce = "sum"
    if reduce == "mul":
        reduce = "prod"
    include_self = kwargs.get("include_self", True)
    broadcast = kwargs.get("broadcast", True)

    def infer_broadcast_shape(input_value: Any, index_value: Any, axis: int) -> tuple[int, ...] | None:
        broadcast_shape_list = list(input_value.shape)
        broadcast_shape_list[axis] = list(index_value.shape)[axis]
        for i in range(len(input_value.shape)):
            if input_value.shape[i] < index_value.shape[i]:
                return None
        return tuple(broadcast_shape_list)

    if broadcast:
        broadcast_shape = infer_broadcast_shape(input_tensor, index, dim)
        if broadcast_shape is not None:
            index = torch.broadcast_to(index, broadcast_shape)
            src = torch.broadcast_to(src, broadcast_shape)
    index = index.to(dtype=torch.int64)

    if reduce == "assign":
        return torch.scatter(input_tensor, dim, index, src)
    return torch.scatter_reduce(input_tensor, dim, index, src, reduce, include_self=include_self)


def _torch_ctc_loss(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    ctc_kwargs: dict[str, Any] = {
        "log_probs": torch.nn.functional.log_softmax(kwargs["log_probs"], dim=-1),
        "targets": kwargs["labels"],
        "input_lengths": kwargs["input_lengths"],
        "target_lengths": kwargs["label_lengths"],
        "zero_infinity": True,
    }
    if "blank" in kwargs:
        ctc_kwargs["blank"] = kwargs["blank"]
    if "reduction" in kwargs:
        ctc_kwargs["reduction"] = kwargs["reduction"]
    return torch.nn.functional.ctc_loss(**ctc_kwargs)


def _torch_any_all(
    _framework_name: str,
    torch: Any,
    api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    raw_axis = kwargs.get("axis")
    axis = _normalize_axis(torch, raw_axis)
    keepdim = kwargs.get("keepdim", False)
    reduce_func = torch.any if api_name.endswith("any") else torch.all

    if api_name.endswith("all") and isinstance(raw_axis, (list, tuple)) and len(raw_axis) == 0:
        result = x.new_tensor([True], dtype=torch.bool)
        if keepdim:
            return _reshape_keepdim_result(result, x)
        return result.squeeze()

    if axis is None:
        result = reduce_func(x)
        return _reshape_keepdim_result(result, x) if keepdim else result
    return reduce_func(x, dim=axis, keepdim=keepdim)


def _torch_reduction(
    _framework_name: str,
    torch: Any,
    api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = _normalize_axis(torch, kwargs.get("axis"))
    keepdim = kwargs.get("keepdim", False)
    dtype = kwargs.get("dtype")

    if api_name.endswith("sum"):
        return torch.sum(x, dim=axis, keepdim=keepdim, dtype=dtype)

    if api_name.endswith("mean"):
        if axis is None:
            result = torch.mean(x)
            return _reshape_keepdim_result(result, x) if keepdim else result
        return torch.mean(x, dim=axis, keepdim=keepdim)

    if api_name.endswith("prod"):
        if dtype is None:
            dtype = x.dtype
        if axis is None:
            result = torch.prod(x, dtype=dtype)
            return _reshape_keepdim_result(result, x) if keepdim else result
        if isinstance(axis, int):
            return torch.prod(x, dim=axis, keepdim=keepdim, dtype=dtype)
        result = x
        for dim in axis:
            result = torch.prod(result, dim=dim, keepdim=True, dtype=dtype)
        if not keepdim:
            result = _squeeze_dims(torch, result, axis)
        return result

    if api_name.endswith("amax") or api_name.endswith("amin"):
        reduce_func = torch.amax if api_name.endswith("amax") else torch.amin
        if axis is None:
            result = reduce_func(x)
            return _reshape_keepdim_result(result, x) if keepdim else result
        return reduce_func(x, dim=axis, keepdim=keepdim)

    raise ValueError(f"Unsupported reduction api: {api_name}")


def _torch_arg_reduction(
    _framework_name: str,
    torch: Any,
    api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = _normalize_axis(torch, kwargs.get("axis"))
    keepdim = kwargs.get("keepdim", False)
    dtype = kwargs.get("dtype", torch.int64)
    reduce_func = torch.argmax if api_name.endswith("argmax") else torch.argmin

    if isinstance(axis, tuple):
        if len(axis) != 1:
            raise ValueError(f"{api_name} only supports a single reduction axis")
        axis = axis[0]

    result = reduce_func(x) if axis is None else reduce_func(x, dim=axis, keepdim=keepdim)
    target_dtype = torch.int32 if dtype == torch.int32 else torch.int64
    return result.to(dtype=target_dtype)


def _torch_cumsum(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = _normalize_axis(torch, kwargs.get("axis"))
    dtype = kwargs.get("dtype")

    if axis is None:
        x = x.flatten()
        axis = 0
    elif isinstance(axis, tuple):
        if len(axis) != 1:
            raise ValueError("cumsum only supports a single axis")
        axis = int(axis[0])
    else:
        axis = int(axis)

    return torch.cumsum(x, dim=axis, dtype=dtype)


def _torch_linalg_norm(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    p = kwargs.get("p")
    axis = _normalize_axis(torch, kwargs.get("axis"))
    keepdim = kwargs.get("keepdim", False)

    if p == "fro" and x.dim() == 1:
        p = 2

    if p == 0:
        if keepdim:
            return (x != 0).sum(dim=axis, keepdim=True).to(x.dtype)
        return (x != 0).sum(dim=axis).to(x.dtype)

    if x.dim() >= 2 and axis is None:
        if p == math.inf:
            result = x.abs().amax()
            return _reshape_keepdim_result(result, x) if keepdim else result
        if p == -math.inf:
            result = x.abs().amin()
            return _reshape_keepdim_result(result, x) if keepdim else result
        ord_value = 2 if p == "fro" else p
        result = torch.linalg.norm(input=x.flatten(), ord=ord_value)
        return _reshape_keepdim_result(result, x) if keepdim else result

    ord_value = 2 if p == "fro" else p
    return torch.linalg.norm(input=x, ord=ord_value, dim=axis, keepdim=keepdim)


def _torch_roll(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    shifts = kwargs["shifts"]
    axis = kwargs.get("axis")

    if torch.is_tensor(shifts):
        shifts = shifts.item() if shifts.numel() == 1 else shifts.tolist()
    if axis is not None and torch.is_tensor(axis):
        axis = axis.item() if axis.numel() == 1 else axis.tolist()
    return torch.roll(x, shifts=shifts, dims=axis)


def _torch_subtract(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    y = kwargs["y"]
    if x.dtype == torch.bool:
        x = torch.tensor(x, dtype=y.dtype)
    elif y.dtype == torch.bool:
        y = torch.tensor(y, dtype=x.dtype)
    return torch.subtract(x, y)


def _torch_matmul(
    _framework_name: str,
    _torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    y = kwargs["y"]
    if x.dtype != y.dtype:
        if x.dtype.is_complex:
            y = y.to(x.dtype)
        elif y.dtype.is_complex:
            x = x.to(y.dtype)

    if kwargs.get("transpose_x", False) and x.dim() >= 2:
        x = x.transpose(-2, -1)
    if kwargs.get("transpose_y", False) and y.dim() >= 2:
        y = y.transpose(-2, -1)
    return x @ y


def _torch_dot(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    y = kwargs["y"]
    x_dtype = x.dtype
    if x.dtype in {torch.int32, torch.int64, torch.bool}:
        x = x.to(torch.float32)
        y = y.to(torch.float32)

    result = torch.stack([torch.dot(xi, yi) for xi, yi in zip(x, y, strict=True)]) if x.ndim == 2 else torch.dot(x, y)
    return result.to(x_dtype)


def _torch_reshape(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    shape = kwargs["shape"]
    if isinstance(shape, torch.Tensor):
        shape = shape.tolist()
    elif isinstance(shape, tuple):
        shape = list(shape)
    else:
        shape = list(shape)

    elements = x.numel()
    for i, s in enumerate(shape):
        if s == 0 and elements != 0:
            shape[i] = x.shape[i]
            elements = elements // x.shape[i]
        elif s not in (-1, 0):
            elements = elements // s
    for i, s in enumerate(shape):
        if s == -1:
            shape[i] = elements
    return torch.reshape(x, shape)


def _torch_squeeze(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = kwargs.get("axis")
    if axis is None:
        return torch.squeeze(x)
    if isinstance(axis, torch.Tensor):
        axis = axis.item() if axis.numel() == 1 else tuple(axis.tolist())
    elif isinstance(axis, list):
        axis = tuple(axis)
    return torch.squeeze(x, dim=axis)


def _torch_unsqueeze(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = kwargs["axis"]
    if isinstance(axis, torch.Tensor):
        axis = axis.item() if axis.numel() == 1 else axis.tolist()
    if isinstance(axis, tuple):
        axis = list(axis)

    result = x
    if isinstance(axis, list):
        for ax in axis:
            result = torch.unsqueeze(result, ax)
        return result
    return torch.unsqueeze(x, axis)


def _torch_split(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = kwargs.get("axis", 0)
    sections = kwargs["num_or_sections"]

    if isinstance(axis, torch.Tensor):
        axis = axis.item()
    if axis < 0:
        axis = len(x.shape) + axis

    if not isinstance(sections, int):
        sections = list(sections)
        remaining = x.shape[axis]
        for section in sections:
            if section != -1:
                remaining -= section
        for i, section in enumerate(sections):
            if section == -1:
                sections[i] = remaining
                break
        return torch.split(x, sections, dim=axis)

    return torch.split(x, x.shape[axis] // sections, dim=axis)


def _torch_gather(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = kwargs.get("axis", 0)
    index = kwargs["index"]

    if torch.is_tensor(axis):
        axis = axis.item()
    axis = int(axis)
    if axis < 0:
        axis += x.dim()

    if not torch.is_tensor(index):
        index = torch.tensor(index, device=x.device)
    index = index.to(device=x.device, dtype=torch.int64)

    result = torch.index_select(x, axis, index.reshape(-1))
    shape = list(x.shape[:axis]) + list(index.shape) + list(x.shape[axis + 1 :])
    return result.reshape(shape)


def _torch_scatter(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"].clone()
    index = kwargs["index"]
    updates = kwargs["updates"]
    overwrite = kwargs.get("overwrite", True)

    if not torch.is_tensor(index):
        index = torch.tensor(index, device=x.device)
    index = index.to(device=x.device, dtype=torch.int64).reshape(-1)
    if not torch.is_tensor(updates):
        updates = torch.tensor(updates, dtype=x.dtype, device=x.device)
    else:
        updates = updates.to(device=x.device)

    try:
        expanded_updates = updates.expand_as(x)
    except RuntimeError:
        expanded_updates = updates

    if not overwrite:
        for idx in index:
            x[idx] = torch.zeros_like(x[idx])
        for i, idx in enumerate(index):
            x[idx] += expanded_updates[i]
        return x

    for i, idx in enumerate(index):
        x[idx] = expanded_updates[i]
    return x


def _torch_index_select(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    axis = kwargs.get("axis", 0)
    index = kwargs["index"]

    if torch.is_tensor(axis):
        axis = axis.item()
    axis = int(axis)
    if not torch.is_tensor(index):
        index = torch.tensor(index, device=x.device)
    index = index.to(device=x.device, dtype=torch.int64).reshape(-1)
    return torch.index_select(x, axis, index)


def _torch_where(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    condition = kwargs["condition"]
    input_value = kwargs["x"]
    other = kwargs["y"]
    if not isinstance(input_value, torch.Tensor):
        input_value = torch.tensor(input_value)
    return torch.where(condition=condition, input=input_value, other=other)


def _torch_softmax(
    _framework_name: str,
    torch: Any,
    api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    dim = kwargs.get("axis", -1)
    dtype = kwargs.get("dtype")
    if isinstance(dtype, str):
        dtype = getattr(torch, dtype)
    fn = torch.nn.functional.log_softmax if api_name.endswith("log_softmax") else torch.nn.functional.softmax
    if dtype is None:
        return fn(input=x, dim=dim)
    return fn(input=x, dim=dim, dtype=dtype)


def _torch_dropout(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    p = kwargs["p"]
    axis = kwargs.get("axis")
    training = kwargs.get("training", True)
    mode = kwargs.get("mode", "upscale_in_train")

    if axis is None:
        return torch.nn.functional.dropout(input=x, p=float(p), training=training)

    if isinstance(axis, int):
        axis = [axis]
    mask_shape = [x.shape[i] if i in axis else 1 for i in range(x.dim())]
    mask = torch.bernoulli(torch.full(mask_shape, 1 - p, device=x.device, dtype=x.dtype)).to(x.device)

    if mode == "upscale_in_train":
        return x * mask / (1.0 - p) if training else x
    if mode == "downscale_in_infer":
        return x * mask if training else x * (1.0 - p)
    raise ValueError(f"Invalid mode: {mode}")


def _torch_conv1d(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    weight = kwargs["weight"]
    bias = kwargs.get("bias")
    stride = _to_python_value(torch, kwargs.get("stride", 1))
    dilation = _to_python_value(torch, kwargs.get("dilation", 1))
    padding = _to_python_value(torch, kwargs.get("padding", 0))
    groups = kwargs.get("groups", 1)
    data_format = kwargs.get("data_format", "NCL")

    if data_format == "NLC":
        x = x.permute(0, 2, 1)
    if isinstance(stride, list):
        stride = tuple(stride)
    if isinstance(dilation, list):
        dilation = tuple(dilation)
    if isinstance(padding, str):
        padding = padding.lower()
    elif isinstance(padding, list):
        if len(padding) == 2:
            x = torch.nn.functional.pad(x, tuple(padding))
            padding = 0
        else:
            padding = tuple(padding)

    result = torch.nn.functional.conv1d(
        input=x,
        weight=weight,
        bias=bias,
        stride=stride,
        padding=padding,
        dilation=dilation,
        groups=groups,
    )
    return result.permute(0, 2, 1) if data_format == "NLC" else result


def _torch_conv2d(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    weight = kwargs["weight"]
    bias = kwargs.get("bias")
    stride = _to_python_value(torch, kwargs.get("stride", 1))
    dilation = _to_python_value(torch, kwargs.get("dilation", 1))
    padding = _to_python_value(torch, kwargs.get("padding", 0))
    groups = kwargs.get("groups", 1)
    data_format = kwargs.get("data_format", "NCHW")

    if data_format == "NHWC":
        x = x.permute(0, 3, 1, 2)
    if isinstance(stride, list):
        stride = tuple(stride)
    if isinstance(dilation, list):
        dilation = tuple(dilation)
    if isinstance(padding, str):
        padding = padding.lower()
    elif isinstance(padding, list):
        if len(padding) == 2:
            padding = tuple(padding)
        elif len(padding) == 4:
            if all(isinstance(p, int) for p in padding):
                pad_top, pad_bottom, pad_left, pad_right = padding
            elif data_format == "NHWC":
                pad_top, pad_bottom = padding[1]
                pad_left, pad_right = padding[2]
            else:
                pad_top, pad_bottom = padding[2]
                pad_left, pad_right = padding[3]
            x = torch.nn.functional.pad(x, (pad_left, pad_right, pad_top, pad_bottom))
            padding = 0
        else:
            padding = tuple(padding)

    result = torch.nn.functional.conv2d(
        input=x,
        weight=weight,
        bias=bias,
        stride=stride,
        padding=padding,
        dilation=dilation,
        groups=groups,
    )
    return result.permute(0, 2, 3, 1) if data_format == "NHWC" else result


def _torch_batch_norm(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    data_format = kwargs.get("data_format", "NCHW")
    if data_format == "NHWC":
        x = x.permute(0, 3, 1, 2)

    running_mean = kwargs.get("running_mean")
    running_var = kwargs.get("running_var")
    if running_mean is not None:
        running_mean = running_mean.detach()
    if running_var is not None:
        running_var = running_var.detach()

    training = kwargs.get("training", False)
    use_global_stats = kwargs.get("use_global_stats")
    if use_global_stats is not None:
        training = not use_global_stats

    result = torch.nn.functional.batch_norm(
        input=x,
        running_mean=running_mean,
        running_var=running_var,
        weight=kwargs.get("weight"),
        bias=kwargs.get("bias"),
        training=training,
        momentum=kwargs.get("momentum", 0.9),
        eps=kwargs.get("epsilon", 1e-5),
    )
    return result.permute(0, 2, 3, 1) if data_format == "NHWC" else result


def _torch_layer_norm(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    normalized_shape = _to_python_value(torch, kwargs["normalized_shape"])
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)
    elif isinstance(normalized_shape, list):
        normalized_shape = tuple(normalized_shape)

    weight = kwargs.get("weight")
    bias = kwargs.get("bias")
    if weight is not None:
        weight = weight.view(normalized_shape).to(x.dtype)
    if bias is not None:
        bias = bias.view(normalized_shape).to(x.dtype)

    return torch.nn.functional.layer_norm(
        input=x,
        normalized_shape=normalized_shape,
        weight=weight,
        bias=bias,
        eps=kwargs.get("epsilon", 1e-5),
    )


def _torch_pad(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    pad = _to_python_value(torch, kwargs["pad"])
    mode = kwargs.get("mode", "constant")
    value = kwargs.get("value")
    data_format = kwargs.get("data_format")
    pad_from_left_axis = kwargs.get("pad_from_left_axis", True)

    if data_format == "NLC":
        x = x.permute(0, 2, 1)
    elif data_format == "NDHWC":
        x = x.permute(0, 4, 1, 2, 3)
    elif data_format == "NHWC":
        x = x.permute(0, 3, 1, 2)

    if value is not None and torch.is_tensor(value):
        value = value.item()
    if isinstance(pad, int):
        pad = [pad, pad]
    elif isinstance(pad, tuple):
        pad = list(pad)

    if not pad_from_left_axis:
        new_pad: list[Any] = []
        for i in range(len(pad) // 2):
            left = pad[2 * i]
            right = pad[2 * i + 1]
            new_pad = [right, left, *new_pad]
        pad = new_pad
    elif len(pad) == 2 * x.ndim:
        new_pad = []
        for i in range(len(pad) // 2):
            left = pad[2 * i]
            right = pad[2 * i + 1]
            new_pad.insert(0, right)
            new_pad.insert(0, left)
        pad = new_pad

    pad_kwargs = {"input": x, "pad": tuple(pad), "mode": mode}
    if mode == "constant" and value is not None:
        pad_kwargs["value"] = value
    result = torch.nn.functional.pad(**pad_kwargs)

    if data_format == "NLC":
        return result.permute(0, 2, 1)
    if data_format == "NDHWC":
        return result.permute(0, 2, 3, 4, 1)
    if data_format == "NHWC":
        return result.permute(0, 2, 3, 1)
    return result


def _torch_interpolate(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    size = _to_python_value(torch, kwargs.get("size"))
    scale_factor = _to_python_value(torch, kwargs.get("scale_factor"))
    mode = kwargs.get("mode", "nearest")
    align_corners = kwargs.get("align_corners")
    align_mode = kwargs.get("align_mode", 0)
    data_format = kwargs.get("data_format", "NCHW")

    if not kwargs.get("align_corners", False) and align_mode == 1:
        raise ValueError("align_mode=1 with align_corners=False is not supported for torch interpolate")

    if data_format == "NHWC":
        x = x.permute(0, 3, 1, 2)
    elif data_format == "NDHWC":
        x = x.permute(0, 4, 1, 2, 3)
    elif data_format == "NWC":
        x = x.permute(0, 2, 1)

    interp_kwargs = {"input": x, "mode": mode}
    if size is not None:
        interp_kwargs["size"] = size
    if scale_factor is not None:
        interp_kwargs["scale_factor"] = scale_factor
    if mode not in ("nearest", "area") and align_corners is not None:
        interp_kwargs["align_corners"] = align_corners

    result = torch.nn.functional.interpolate(**interp_kwargs)
    if data_format == "NHWC":
        return result.permute(0, 2, 3, 1)
    if data_format == "NDHWC":
        return result.permute(0, 2, 3, 4, 1)
    if data_format == "NWC":
        return result.permute(0, 2, 1)
    return result


def _torch_cross_entropy(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    label = kwargs["label"]
    weight = kwargs.get("weight")
    reduction = kwargs.get("reduction", "mean")
    soft_label = kwargs.get("soft_label", False)
    ignore_index = kwargs.get("ignore_index", -100)
    label_smoothing = kwargs.get("label_smoothing", 0.0)
    shape = label.shape

    if x.dim() > 2:
        perm = [0, x.dim() - 1, *range(1, x.dim() - 1)]
        x = x.permute(*perm)
    if label.shape[-1:] == (1,):
        label = label.squeeze(-1)
    if weight is not None:
        weight = weight.detach()
    if label.dtype == torch.int32:
        label = label.long()

    manual_weight = soft_label and weight is not None
    saved_reduction = reduction
    saved_weight = weight
    if manual_weight:
        reduction = "none"
        weight = None

    result = torch.nn.functional.cross_entropy(
        input=x,
        target=label,
        weight=weight,
        ignore_index=ignore_index,
        reduction=reduction,
        label_smoothing=label_smoothing,
    )

    if manual_weight:
        loss_weight = label @ saved_weight
        result = result * loss_weight
        if saved_reduction == "sum":
            result = result.sum()
        elif saved_reduction == "mean":
            result = result.sum() / loss_weight.sum()
        reduction = saved_reduction

    if reduction == "none":
        return result.unsqueeze(-1) if soft_label else result.reshape(shape)
    return result


def _torch_weight_only_linear(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    x = kwargs["x"]
    weight = kwargs["weight"]
    weight_scale = kwargs["weight_scale"]
    bias = kwargs.get("bias")

    if weight.shape[0] == 0:
        out_features = int(bias.shape[0]) if bias is not None else int(weight_scale.shape[0])
        out = torch.zeros((*x.shape[:-1], out_features), dtype=x.dtype, device=x.device)
        if bias is not None:
            out = out + bias
        return out

    if weight.shape[0] < weight_scale.shape[0]:
        weight = weight.repeat(weight_scale.shape[0] // weight.shape[0], 1)
    weight_float = weight * weight_scale.unsqueeze(1)
    out = torch.matmul(x, weight_float.t())
    if bias is not None:
        out = out + bias
    return out


def _torch_variable_length_memory_efficient_attention(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    query = kwargs["query"]
    key = kwargs["key"]
    value = kwargs["value"]
    seq_lens = kwargs["seq_lens"]
    kv_seq_lens = kwargs["kv_seq_lens"]
    mask = kwargs.get("mask")
    scale = kwargs.get("scale")
    causal = kwargs.get("causal", False)
    pre_cache_length = kwargs.get("pre_cache_length", 0)

    batch_size, num_heads, query_seq_len, head_size = query.shape
    key_seq_len = key.shape[2]
    if key.shape[1] != num_heads:
        repeat_factor = num_heads // key.shape[1]
        key = (
            key.unsqueeze(2)
            .expand(-1, -1, repeat_factor, -1, -1)
            .reshape(batch_size, num_heads, key_seq_len, head_size)
        )
        value = (
            value.unsqueeze(2)
            .expand(-1, -1, repeat_factor, -1, -1)
            .reshape(batch_size, num_heads, key_seq_len, head_size)
        )
    if scale is None:
        scale = math.sqrt(1.0 / head_size)
    scale_tensor = torch.tensor(scale, dtype=query.dtype, device=query.device)
    if mask is None:
        mask = torch.zeros(
            batch_size,
            1,
            query_seq_len,
            key_seq_len,
            dtype=query.dtype,
            device=query.device,
        )
    else:
        mask = mask[:, :, :query_seq_len, :key_seq_len]

    seq_mask = torch.ones(
        batch_size,
        1,
        query_seq_len,
        key_seq_len,
        dtype=torch.bool,
        device=query.device,
    )
    for batch_index in range(batch_size):
        q_len = seq_lens[batch_index].squeeze().item()
        kv_len = kv_seq_lens[batch_index].squeeze().item() + pre_cache_length
        seq_mask[batch_index, :, q_len:, :] = False
        seq_mask[batch_index, :, :, kv_len:] = False

    if causal:
        causal_mask = torch.tril(torch.ones(1, 1, query_seq_len, key_seq_len, dtype=torch.bool, device=query.device))
        seq_mask = seq_mask & causal_mask

    attention = torch.matmul(query, key.transpose(-1, -2)) * scale_tensor
    attention = attention + mask
    attention = attention.masked_fill(~seq_mask, torch.finfo(attention.dtype).min)
    softmax_result = torch.nn.functional.softmax(attention, dim=-1)
    softmax_result = softmax_result.masked_fill(~seq_mask, 0.0)
    return torch.matmul(softmax_result, value)


def _torch_flashmask_attention(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    query = kwargs["query"]
    key = kwargs["key"]
    value = kwargs["value"]
    causal = kwargs.get("causal", False)

    if any(0 in tensor.shape for tensor in (query, key, value)):
        return torch.empty_like(query)

    q = query.permute(0, 2, 1, 3)
    k = key.permute(0, 2, 1, 3)
    v = value.permute(0, 2, 1, 3)
    out = torch.nn.functional.scaled_dot_product_attention(q, k, v, is_causal=causal)
    return out.permute(0, 2, 1, 3)


def _torch_generate_proposals(
    _framework_name: str,
    torch: Any,
    _api_name: str,
    _args: tuple[Any, ...],
    kwargs: dict[str, Any],
    _mapping: CallMapping,
) -> Any:
    def nms(box1: Any, box2: Any, normalized: bool) -> Any:
        if box2[0] > box1[2] or box2[2] < box1[0] or box2[1] > box1[3] or box2[3] < box1[1]:
            return 0
        norm = 0 if normalized else 1
        x_min = max(box1[0], box2[0])
        y_min = max(box1[1], box2[1])
        x_max = min(box1[2], box2[2])
        y_max = min(box1[3], box2[3])
        area = (x_max - x_min + norm) * (y_max - y_min + norm)
        area1 = 0 if box1[0] > box1[2] or box1[1] > box1[3] else (box1[2] - box1[0] + norm) * (box1[3] - box1[1] + norm)
        area2 = 0 if box2[0] > box2[2] or box2[1] > box2[3] else (box2[2] - box2[0] + norm) * (box2[3] - box2[1] + norm)
        return area / (area1 + area2 - area)

    def long_index(values: list[int], device: Any) -> Any:
        return torch.tensor(values, dtype=torch.int64, device=device)

    scores = kwargs["scores"]
    bbox_deltas = kwargs["bbox_deltas"]
    img_size = kwargs["im_shape"]
    anchors = kwargs["anchors"]
    variances = kwargs["variances"]
    pre_nms_top_n = kwargs.get("pre_nms_top_n", 6000)
    post_nms_top_n = kwargs.get("post_nms_top_n", 1000)
    nms_thresh = kwargs.get("nms_thresh", 0.5)
    min_size = kwargs.get("min_size", 0.1)
    eta = kwargs.get("eta", 1.0)
    pixel_offset = kwargs.get("pixel_offset", False)
    return_rois_num = kwargs.get("return_rois_num", False)

    rpn_rois = []
    rpn_roi_probs = []

    scores = scores.permute(0, 2, 3, 1).reshape(scores.shape[0], -1, 1)
    bbox_deltas = bbox_deltas.permute(0, 2, 3, 1).reshape(bbox_deltas.shape[0], -1, 4)
    anchors = anchors.reshape(-1, 4)
    variances = variances.reshape(-1, 4)
    proposal = torch.empty((scores.shape[0], scores.shape[1], 4), device=scores.device, dtype=scores.dtype)

    for batch_index in range(scores.shape[0]):
        scores_i = scores[batch_index]
        bbox_deltas_i = bbox_deltas[batch_index]
        img_size_i = img_size[batch_index]
        proposal_i = proposal[batch_index]

        indices = sorted(range(scores_i.numel()), key=lambda i: scores_i[i, 0], reverse=True)
        if pre_nms_top_n < scores_i.numel():
            indices = indices[:pre_nms_top_n]
        select_idx = long_index(indices, scores_i.device)
        scores_i = scores_i.index_select(0, select_idx)
        bbox_deltas_i = bbox_deltas_i.index_select(0, select_idx)
        anchors_i = anchors.index_select(0, select_idx)
        variances_i = variances.index_select(0, select_idx)
        proposal_i = proposal_i.index_select(0, select_idx)

        offset = 1 if pixel_offset else 0
        log_cap = math.log(1000.0 / 16.0)
        for i in range(anchors_i.shape[0]):
            anchor_width = anchors_i[i][2] - anchors_i[i][0] + offset
            anchor_height = anchors_i[i][3] - anchors_i[i][1] + offset
            anchor_center_x = anchors_i[i][0] + 0.5 * anchor_width
            anchor_center_y = anchors_i[i][1] + 0.5 * anchor_height
            bbox_center_x = variances_i[i][0] * bbox_deltas_i[i, 0] * anchor_width + anchor_center_x
            bbox_center_y = variances_i[i][1] * bbox_deltas_i[i, 1] * anchor_height + anchor_center_y
            bbox_width = anchor_width * torch.exp(torch.clamp(variances_i[i][2] * bbox_deltas_i[i, 2], max=log_cap))
            bbox_height = anchor_height * torch.exp(torch.clamp(variances_i[i][3] * bbox_deltas_i[i, 3], max=log_cap))

            proposal_i[i, 0] = bbox_center_x - 0.5 * bbox_width
            proposal_i[i, 1] = bbox_center_y - 0.5 * bbox_height
            proposal_i[i, 2] = bbox_center_x + 0.5 * bbox_width - offset
            proposal_i[i, 3] = bbox_center_y + 0.5 * bbox_height - offset

        for i in range(proposal_i.shape[0]):
            proposal_i[i, 0] = max(min(float(proposal_i[i, 0]), img_size_i[1]), 0)
            proposal_i[i, 1] = max(min(float(proposal_i[i, 1]), img_size_i[0]), 0)
            proposal_i[i, 2] = max(min(float(proposal_i[i, 2]), img_size_i[1]), 0)
            proposal_i[i, 3] = max(min(float(proposal_i[i, 3]), img_size_i[0]), 0)

        keep: list[int] = []
        for i in range(proposal_i.shape[0]):
            width = proposal_i[i, 2] - proposal_i[i, 0]
            height = proposal_i[i, 3] - proposal_i[i, 1]
            if pixel_offset:
                x_center = proposal_i[i, 0] + 0.5 * width
                y_center = proposal_i[i, 1] + 0.5 * height
                if width >= min_size and height >= min_size and x_center <= img_size_i[1] and y_center <= img_size_i[0]:
                    keep.append(i)
            elif width >= min_size and height >= min_size:
                keep.append(i)
        keep_idx = long_index(keep, proposal_i.device)
        proposal_i = proposal_i.index_select(0, keep_idx)
        scores_i = scores_i.index_select(0, keep_idx)

        adaptive_threshold = nms_thresh
        normalized = not pixel_offset
        selected_index: list[int] = []
        for num in range(proposal_i.shape[0]):
            keep_current = True
            for selected in selected_index:
                if keep_current:
                    overlap = nms(proposal_i[selected], proposal_i[num], normalized)
                    keep_current = overlap <= adaptive_threshold
                else:
                    break
            if keep_current:
                selected_index.append(num)
            if keep_current and eta < 1 and adaptive_threshold > 0.5:
                adaptive_threshold = adaptive_threshold * eta
        if len(selected_index) > post_nms_top_n:
            selected_index = selected_index[:post_nms_top_n]

        selected_idx = long_index(selected_index, proposal_i.device)
        proposal_i = proposal_i.index_select(0, selected_idx)
        scores_i = scores_i.index_select(0, selected_idx)

        rpn_rois.append(proposal_i)
        rpn_roi_probs.append(scores_i)

    rois = torch.stack(rpn_rois).squeeze()
    roi_probs = torch.stack(rpn_roi_probs).squeeze(0)
    if return_rois_num:
        rois_num = torch.tensor([roi.numel() // 4 for roi in rpn_rois], device=rois.device).squeeze()
        return rois, roi_probs, rois_num
    return rois, roi_probs


_HANDLERS: dict[str, CallHandler] = {
    "torch_dot": _torch_dot,
    "torch_any_all": _torch_any_all,
    "torch_arg_reduction": _torch_arg_reduction,
    "torch_cumsum": _torch_cumsum,
    "torch_ctc_loss": _torch_ctc_loss,
    "torch_flashmask_attention": _torch_flashmask_attention,
    "torch_gather": _torch_gather,
    "torch_generate_proposals": _torch_generate_proposals,
    "torch_index_select": _torch_index_select,
    "torch_linalg_norm": _torch_linalg_norm,
    "torch_matmul": _torch_matmul,
    "torch_batch_norm": _torch_batch_norm,
    "torch_conv1d": _torch_conv1d,
    "torch_conv2d": _torch_conv2d,
    "torch_cross_entropy": _torch_cross_entropy,
    "torch_interpolate": _torch_interpolate,
    "torch_layer_norm": _torch_layer_norm,
    "torch_pad": _torch_pad,
    "torch_put_along_axis": _torch_put_along_axis,
    "torch_reshape": _torch_reshape,
    "torch_reduction": _torch_reduction,
    "torch_roll": _torch_roll,
    "torch_scatter": _torch_scatter,
    "torch_softmax": _torch_softmax,
    "torch_split": _torch_split,
    "torch_squeeze": _torch_squeeze,
    "torch_subtract": _torch_subtract,
    "torch_unsqueeze": _torch_unsqueeze,
    "torch_variable_length_memory_efficient_attention": _torch_variable_length_memory_efficient_attention,
    "torch_where": _torch_where,
    "torch_weight_only_linear": _torch_weight_only_linear,
    "torch_dropout": _torch_dropout,
}
