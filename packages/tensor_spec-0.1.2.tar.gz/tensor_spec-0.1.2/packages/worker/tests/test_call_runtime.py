from __future__ import annotations

from types import SimpleNamespace

from tensor_spec_worker.call_runtime import execute_call


class _FakeFramework:
    def permute(self, *args, **kwargs):
        return {"args": args, "kwargs": kwargs}

    def pack(self, *args, **kwargs):
        return ("ignored", {"args": args, "kwargs": kwargs})

    def scalar(self, *args, **kwargs):
        return 7

    def empty(self, shape):
        return ("empty", tuple(shape))


class _FakeTensor:
    itemsize = 4

    def __getitem__(self, index):
        return ("getitem", index)

    def set_(self, *args, **kwargs):
        return {"args": args, "kwargs": kwargs}


def test_execute_call_applies_default_and_computed_kwargs():
    framework = _FakeFramework()
    x = SimpleNamespace(ndim=4)

    result = execute_call(
        "torch",
        framework,
        "permute",
        (),
        {"x": x, "perm": (1, 0)},
        {
            "args_map": {"x": "input"},
            "default_kwargs": {"keepdim": False},
            "computed_kwargs": {"dims": "tuple(perm) + tuple(range(len(perm), x.ndim))"},
            "drop_kwargs": ["perm"],
        },
    )

    assert result["args"] == ()
    assert result["kwargs"] == {
        "input": x,
        "keepdim": False,
        "dims": (1, 0, 2, 3),
    }


def test_execute_call_tensor_getitem_uses_self_and_indices():
    tensor = _FakeTensor()

    result = execute_call(
        "torch",
        object(),
        "Tensor.__getitem__",
        (),
        {"self": tensor, "indices": [1, 2]},
        {},
    )

    assert result == ("getitem", [1, 2])


def test_execute_call_selects_result_index():
    framework = _FakeFramework()

    result = execute_call(
        "torch",
        framework,
        "pack",
        (1, 2),
        {"alpha": 3},
        {"result_index": 1},
    )

    assert result == {"args": (1, 2), "kwargs": {"alpha": 3}}


def test_execute_call_result_index_zero_passthrough_scalar():
    result = execute_call(
        "torch",
        _FakeFramework(),
        "scalar",
        (),
        {},
        {"result_index": 0},
    )

    assert result == 7


def test_execute_call_tensor_method_uses_computed_kwargs():
    framework = _FakeFramework()
    tensor = _FakeTensor()

    result = execute_call(
        "torch",
        framework,
        "Tensor.set_",
        (),
        {
            "self": tensor,
            "source": None,
            "size": [20],
            "storage_offset": 8,
            "stride": [2],
        },
        {
            "drop_kwargs": ["shape", "offset"],
            "computed_kwargs": {
                "source": "source if source is not None else framework.empty([])",
                "size": "kwargs.get('shape') or kwargs.get('size') or (source.size() if source is not None else [])",
                "storage_offset": "(kwargs.get('offset') or kwargs.get('storage_offset') or 0) // self.itemsize",
            },
        },
    )

    assert result == {
        "args": (),
        "kwargs": {
            "source": ("empty", ()),
            "size": [20],
            "storage_offset": 2,
            "stride": [2],
        },
    }
