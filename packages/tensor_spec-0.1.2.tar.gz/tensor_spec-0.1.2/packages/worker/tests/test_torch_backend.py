import numpy as np
import pytest

try:
    import torch

    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

from tensor_spec_core.stats import FloatStats
from tensor_spec_core.tensor import Tensor
from tensor_spec_worker.backend.torch_backend import TorchBackend

pytestmark = pytest.mark.skipif(not HAS_TORCH, reason="torch not installed")


@pytest.fixture
def backend():
    b = TorchBackend()
    b.import_framework()
    return b


def test_name(backend):
    assert backend.name == "torch"


def test_import_framework():
    b = TorchBackend()
    b.import_framework()
    assert b._torch is not None


def test_numpy_to_tensor_float(backend):
    import numpy as np

    from tensor_spec_core.tensor import Tensor

    spec = Tensor.float32((2, 3))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert tuple(t.shape) == (2, 3)
    assert t.dtype == torch.float32


def test_numpy_to_tensor_with_grad(backend):
    import numpy as np

    from tensor_spec_core.state import TensorState
    from tensor_spec_core.tensor import Tensor

    spec = Tensor.float32((2, 3)).with_state(TensorState(need_grad=True))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.requires_grad is True


def test_tensor_to_numpy(backend):
    import numpy as np

    t = torch.tensor([1.0, 2.0, 3.0])
    result = backend.tensor_to_numpy(t)
    assert isinstance(result, np.ndarray)
    np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])


def test_generate_tensor_is_deterministic(backend):
    spec = Tensor.float32((4,)).with_stats(FloatStats(min=-2.0, max=2.0, nonzero=True))
    a = backend.generate_tensor(spec, seed=42, ordinal=0)
    b = backend.generate_tensor(spec, seed=42, ordinal=0)
    np.testing.assert_array_equal(backend.tensor_to_numpy(a), backend.tensor_to_numpy(b))


def test_exec_api(backend):
    import numpy as np

    t = torch.tensor([-1.0, 2.0, -3.0])
    result = backend.exec_api("abs", (t,), {})
    expected = np.array([1.0, 2.0, 3.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_dotted(backend):
    import numpy as np

    t = torch.tensor([-1.0, 2.0, -3.0])
    result = backend.exec_api("nn.functional.relu", (t,), {})
    expected = np.array([0.0, 2.0, 0.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_with_mapping_reshape(backend):
    x = torch.arange(24).reshape(2, 3, 4)
    result = backend.exec_api(
        "reshape",
        (),
        {"x": x, "shape": [0, -1]},
        {"handler": "torch_reshape"},
    )
    assert tuple(result.shape) == (2, 12)


def test_exec_api_with_mapping_unsqueeze_multiple_axes(backend):
    x = torch.arange(6).reshape(2, 3)
    result = backend.exec_api(
        "unsqueeze",
        (),
        {"x": x, "axis": [0, 2]},
        {"handler": "torch_unsqueeze"},
    )
    assert tuple(result.shape) == (1, 2, 1, 3)


def test_exec_api_with_mapping_where_scalar_input(backend):
    condition = torch.tensor([True, False, True])
    y = torch.tensor([10.0, 20.0, 30.0])
    result = backend.exec_api(
        "where",
        (),
        {"condition": condition, "x": 1.5, "y": y},
        {"handler": "torch_where"},
    )
    expected = np.array([1.5, 20.0, 1.5], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_with_mapping_linear_transposes_weight(backend):
    x = torch.arange(6, dtype=torch.float32).reshape(2, 3)
    weight = torch.arange(12, dtype=torch.float32).reshape(3, 4)
    bias = torch.arange(4, dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.linear",
        (),
        {"x": x, "weight": weight, "bias": bias},
        {"computed_kwargs": {"weight": "weight.T.contiguous()"}, "drop_kwargs": ["weight"], "args_map": {"x": "input"}},
    )
    expected = torch.nn.functional.linear(x, weight.T.contiguous(), bias)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_subtract_bool(backend):
    x = torch.tensor([True, False, True], dtype=torch.bool)
    y = torch.tensor([0.25, 0.5, 1.5], dtype=torch.float32)
    result = backend.exec_api(
        "subtract",
        (),
        {"x": x, "y": y},
        {"handler": "torch_subtract"},
    )
    expected = np.array([0.75, -0.5, -0.5], dtype=np.float32)
    np.testing.assert_array_almost_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_with_mapping_gather(backend):
    x = torch.arange(24).reshape(2, 3, 4)
    index = torch.tensor([2, 0], dtype=torch.int64)
    result = backend.exec_api(
        "gather",
        (),
        {"x": x, "index": index, "axis": 1},
        {"handler": "torch_gather"},
    )
    expected = torch.index_select(x, 1, index)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_scatter_overwrite_false(backend):
    x = torch.tensor([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])
    index = torch.tensor([0, 2, 0], dtype=torch.int64)
    updates = torch.tensor([[10.0, 20.0], [30.0, 40.0], [1.0, 1.0]])
    result = backend.exec_api(
        "scatter",
        (),
        {"x": x, "index": index, "updates": updates, "overwrite": False},
        {"handler": "torch_scatter"},
    )
    expected = torch.tensor([[11.0, 21.0], [3.0, 4.0], [30.0, 40.0]])
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_index_select(backend):
    x = torch.arange(24).reshape(2, 3, 4)
    index = torch.tensor([[2], [0]], dtype=torch.int64)
    result = backend.exec_api(
        "index_select",
        (),
        {"x": x, "index": index, "axis": torch.tensor(1)},
        {"handler": "torch_index_select"},
    )
    expected = torch.index_select(x, 1, torch.tensor([2, 0]))
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_conv1d_nlc_padding(backend):
    x = torch.arange(8, dtype=torch.float32).reshape(1, 4, 2)
    weight = torch.arange(12, dtype=torch.float32).reshape(3, 2, 2)
    bias = torch.tensor([0.0, 1.0, 2.0], dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.conv1d",
        (),
        {
            "x": x,
            "weight": weight,
            "bias": bias,
            "stride": [1],
            "padding": [1, 2],
            "dilation": [1],
            "groups": 1,
            "data_format": "NLC",
        },
        {"handler": "torch_conv1d"},
    )
    expected = torch.nn.functional.conv1d(
        torch.nn.functional.pad(x.permute(0, 2, 1), (1, 2)),
        weight,
        bias,
        stride=(1,),
        padding=0,
        dilation=(1,),
        groups=1,
    ).permute(0, 2, 1)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_conv2d_nhwc_padding(backend):
    x = torch.arange(18, dtype=torch.float32).reshape(1, 3, 3, 2)
    weight = torch.arange(24, dtype=torch.float32).reshape(2, 2, 2, 3)
    bias = torch.tensor([0.0, 1.0], dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.conv2d",
        (),
        {
            "x": x,
            "weight": weight,
            "bias": bias,
            "stride": [1, 1],
            "padding": [1, 0, 2, 1],
            "dilation": [1, 1],
            "groups": 1,
            "data_format": "NHWC",
        },
        {"handler": "torch_conv2d"},
    )
    expected = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.permute(0, 3, 1, 2), (2, 1, 1, 0)),
        weight,
        bias,
        stride=(1, 1),
        padding=0,
        dilation=(1, 1),
        groups=1,
    ).permute(0, 2, 3, 1)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_batch_norm_nhwc(backend):
    x = torch.arange(12, dtype=torch.float32).reshape(1, 2, 2, 3)
    running_mean = torch.tensor([0.5, 1.0, 1.5], dtype=torch.float32)
    running_var = torch.tensor([1.0, 1.5, 2.0], dtype=torch.float32)
    weight = torch.tensor([1.0, 1.5, 2.0], dtype=torch.float32)
    bias = torch.tensor([0.0, 0.5, 1.0], dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.batch_norm",
        (),
        {
            "x": x,
            "running_mean": running_mean,
            "running_var": running_var,
            "weight": weight,
            "bias": bias,
            "training": False,
            "momentum": 0.9,
            "epsilon": 1e-5,
            "data_format": "NHWC",
        },
        {"handler": "torch_batch_norm"},
    )
    expected = torch.nn.functional.batch_norm(
        x.permute(0, 3, 1, 2),
        running_mean,
        running_var,
        weight,
        bias,
        training=False,
        momentum=0.9,
        eps=1e-5,
    ).permute(0, 2, 3, 1)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_layer_norm_reshapes_affine(backend):
    x = torch.arange(24, dtype=torch.float32).reshape(2, 3, 2, 2)
    weight = torch.tensor([1.0, 1.5, 2.0, 2.5], dtype=torch.float32)
    bias = torch.tensor([0.0, 0.5, 1.0, 1.5], dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.layer_norm",
        (),
        {
            "x": x,
            "normalized_shape": [2, 2],
            "weight": weight,
            "bias": bias,
            "epsilon": 1e-5,
        },
        {"handler": "torch_layer_norm"},
    )
    expected = torch.nn.functional.layer_norm(x, (2, 2), weight.view(2, 2), bias.view(2, 2), eps=1e-5)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_pad_nlc(backend):
    x = torch.arange(6, dtype=torch.float32).reshape(1, 3, 2)
    result = backend.exec_api(
        "nn.functional.pad",
        (),
        {"x": x, "pad": [1, 2], "mode": "constant", "value": torch.tensor(2.0), "data_format": "NLC"},
        {"handler": "torch_pad"},
    )
    expected = torch.nn.functional.pad(x.permute(0, 2, 1), (1, 2), mode="constant", value=2.0).permute(0, 2, 1)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_interpolate_nhwc(backend):
    x = torch.arange(4, dtype=torch.float32).reshape(1, 2, 2, 1)
    result = backend.exec_api(
        "nn.functional.interpolate",
        (),
        {
            "x": x,
            "size": torch.tensor([4, 3]),
            "mode": "nearest",
            "align_corners": True,
            "data_format": "NHWC",
        },
        {"handler": "torch_interpolate"},
    )
    expected = torch.nn.functional.interpolate(x.permute(0, 3, 1, 2), size=[4, 3], mode="nearest").permute(0, 2, 3, 1)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_exec_api_with_mapping_cross_entropy_soft_label_weight(backend):
    x = torch.tensor([[2.0, 0.5, -1.0], [0.0, 1.5, 0.5]], dtype=torch.float32)
    label = torch.tensor([[0.7, 0.2, 0.1], [0.1, 0.6, 0.3]], dtype=torch.float32)
    weight = torch.tensor([1.0, 2.0, 3.0], dtype=torch.float32)
    result = backend.exec_api(
        "nn.functional.cross_entropy",
        (),
        {"x": x, "label": label, "weight": weight, "soft_label": True, "reduction": "mean"},
        {"handler": "torch_cross_entropy"},
    )
    base = torch.nn.functional.cross_entropy(x, label, reduction="none")
    loss_weight = label @ weight
    expected = (base * loss_weight).sum() / loss_weight.sum()
    np.testing.assert_allclose(backend.tensor_to_numpy(result), expected.detach().cpu().numpy())


def test_empty_cache(backend):
    # Should not raise, even without CUDA
    backend.empty_cache()


def test_check_cuda_error(backend):
    # Should not raise, even without CUDA
    backend.check_cuda_error()


def test_compute_grad(backend):
    x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
    y = torch.sum(x * x)
    grads = backend.compute_grad(y, [x])
    assert len(grads) == 1
    expected = [2.0, 4.0, 6.0]
    for g, e in zip(grads[0].detach().numpy().tolist(), expected, strict=True):
        assert abs(g - e) < 1e-5
