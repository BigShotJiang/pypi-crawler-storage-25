"""Tests for GPU IPC commands in worker/coordinator -- requires CUDA."""

from __future__ import annotations

import ctypes
import json
import subprocess
import sys

import pytest

_has_cuda = False
try:
    ctypes.CDLL("libcudart.so")
    _has_cuda = True
except OSError:
    pass

requires_cuda = pytest.mark.skipif(not _has_cuda, reason="No CUDA runtime")


def _start_worker(backend: str) -> subprocess.Popen:
    """Start a worker subprocess using current Python."""
    return subprocess.Popen(
        [sys.executable, "-m", "tensor_spec_worker", "--backend", backend],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True,
    )


def _send(proc: subprocess.Popen, msg_id: int, msg_type: str, payload: dict | None = None) -> dict:
    """Send a request and read a response."""
    msg: dict = {"id": msg_id, "type": msg_type}
    if payload:
        msg["payload"] = payload
    assert proc.stdin is not None
    assert proc.stdout is not None
    proc.stdin.write(json.dumps(msg) + "\n")
    proc.stdin.flush()
    line = proc.stdout.readline()
    return json.loads(line)


@requires_cuda
class TestWorkerGpuCommands:
    """Placeholder tests for GPU IPC -- will be meaningful on GPU machines."""

    def test_get_ipc_handle_unknown_tensor(self):
        """Verify error handling when tensor doesn't exist."""
        proc = _start_worker("torch")
        try:
            # Import framework
            _send(proc, 1, "import_framework")
            # Try to get IPC handle for nonexistent tensor
            resp = _send(proc, 2, "get_ipc_handle", {"tensor_id": "t999"})
            assert resp["ok"] is False
            assert "Unknown" in resp["error"]
        finally:
            _send(proc, 3, "shutdown")
            proc.wait(timeout=5)

    def test_close_ipc_handle_noop_for_unknown(self):
        """close_ipc_handle should succeed even for unknown tensor."""
        proc = _start_worker("torch")
        try:
            resp = _send(proc, 1, "close_ipc_handle", {"tensor_id": "t999"})
            assert resp["ok"] is True
        finally:
            _send(proc, 2, "shutdown")
            proc.wait(timeout=5)
