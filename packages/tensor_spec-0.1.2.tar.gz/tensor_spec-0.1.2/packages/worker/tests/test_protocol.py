"""Tests for worker message protocol."""

from __future__ import annotations

import pytest

from tensor_spec_worker.protocol import (
    Request,
    Response,
    decode_arg_value,
    decode_request,
    decode_response,
    encode_arg_value,
    encode_request,
    encode_response,
)


class TestRequest:
    def test_encode_decode_roundtrip(self):
        req = Request(id=1, type="ping", payload={})
        line = encode_request(req)
        decoded = decode_request(line)
        assert decoded.id == 1
        assert decoded.type == "ping"
        assert decoded.payload == {}

    def test_with_payload(self):
        req = Request(id=2, type="exec_api", payload={"api": "abs", "kwargs": {}})
        decoded = decode_request(encode_request(req))
        assert decoded.payload["api"] == "abs"


class TestResponse:
    def test_ok_response(self):
        resp = Response(id=1, ok=True, result={"tensor_id": "t1"})
        decoded = decode_response(encode_response(resp))
        assert decoded.ok is True
        assert decoded.result["tensor_id"] == "t1"

    def test_error_response(self):
        resp = Response(id=1, ok=False, error="RuntimeError: boom")
        decoded = decode_response(encode_response(resp))
        assert decoded.ok is False
        assert decoded.error == "RuntimeError: boom"
        assert decoded.result is None


class TestArgValueEncoding:
    def test_scalar_int(self):
        assert encode_arg_value(42) == 42

    def test_scalar_float(self):
        assert encode_arg_value(3.14) == 3.14

    def test_scalar_bool(self):
        assert encode_arg_value(True) is True

    def test_scalar_none(self):
        assert encode_arg_value(None) is None

    def test_scalar_string(self):
        assert encode_arg_value("hello") == "hello"

    def test_tensor_ref(self):
        encoded = encode_arg_value({"_ref": "t1"})
        assert encoded == {"_ref": "t1"}

    def test_tuple_of_refs(self):
        val = ("_ref:t1", "_ref:t2")
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "tuple"
        assert len(encoded["items"]) == 2

    def test_nested_tuple(self):
        val = (1, (2, 3))
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "tuple"
        inner = encoded["items"][1]
        assert inner["_t"] == "tuple"

    def test_list(self):
        val = [1, 2, 3]
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "list"


class TestArgValueDecoding:
    def test_scalar_passthrough(self):
        tensors: dict = {}
        assert decode_arg_value(42, tensors) == 42

    def test_tensor_ref_resolves(self):
        sentinel = object()
        tensors = {"t1": sentinel}
        assert decode_arg_value({"_ref": "t1"}, tensors) is sentinel

    def test_tuple_resolves(self):
        sentinel_a = object()
        sentinel_b = object()
        tensors = {"t1": sentinel_a, "t2": sentinel_b}
        encoded = {"_t": "tuple", "items": [{"_ref": "t1"}, {"_ref": "t2"}]}
        result = decode_arg_value(encoded, tensors)
        assert isinstance(result, tuple)
        assert result == (sentinel_a, sentinel_b)

    def test_list_resolves(self):
        tensors = {"t1": "tensor_obj"}
        encoded = {"_t": "list", "items": [{"_ref": "t1"}, 5]}
        result = decode_arg_value(encoded, tensors)
        assert isinstance(result, list)
        assert result == ["tensor_obj", 5]

    def test_unknown_ref_raises(self):
        with pytest.raises(KeyError):
            decode_arg_value({"_ref": "t999"}, {})
