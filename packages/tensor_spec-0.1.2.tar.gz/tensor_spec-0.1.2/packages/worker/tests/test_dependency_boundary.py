from __future__ import annotations

import subprocess
import sys


def test_torch_backend_import_does_not_require_tensor_spec() -> None:
    script = """
import importlib.abc
import sys

class BlockTensorSpec(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "tensor_spec" or fullname.startswith("tensor_spec."):
            raise ModuleNotFoundError(fullname)
        return None

sys.meta_path.insert(0, BlockTensorSpec())
import tensor_spec_worker.backend.torch_backend
print("ok")
"""
    proc = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.strip() == "ok"
