"""Core tensor specification types — zero external dependencies."""
