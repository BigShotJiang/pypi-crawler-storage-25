import pytest

from tensor_spec_core.stats import BoolStats, ComplexStats, FloatStats, IntStats


def test_float_stats_defaults():
    s = FloatStats()
    assert s.min == -0.5
    assert s.max == 0.5
    assert s.nonzero is False
    assert s.positive_definite is False


def test_float_stats_custom():
    s = FloatStats(min=-10.0, max=10.0, nonzero=True)
    assert s.min == -10.0
    assert s.nonzero is True


def test_float_stats_invalid_range():
    with pytest.raises(ValueError, match=r"min.*must.*< max"):
        FloatStats(min=5.0, max=3.0)


def test_float_stats_equal_range():
    with pytest.raises(ValueError):
        FloatStats(min=1.0, max=1.0)


def test_int_stats_defaults():
    s = IntStats()
    assert s.low == -65535
    assert s.high == 65535


def test_int_stats_invalid_range():
    with pytest.raises(ValueError):
        IntStats(low=10, high=5)


def test_bool_stats_defaults():
    s = BoolStats()
    assert s.true_ratio == 0.5


def test_bool_stats_invalid_ratio():
    with pytest.raises(ValueError):
        BoolStats(true_ratio=1.5)


def test_complex_stats_defaults():
    s = ComplexStats()
    assert s.real_min == -0.5
    assert s.real_max == 0.5
    assert s.imag_min == -0.5
    assert s.imag_max == 0.5


def test_all_stats_frozen():
    s = FloatStats()
    with pytest.raises(AttributeError):
        setattr(s, "min", 1.0)
