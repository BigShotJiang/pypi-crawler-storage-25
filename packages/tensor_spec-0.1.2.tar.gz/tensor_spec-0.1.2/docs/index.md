# tensor-spec

**Framework-agnostic deep learning API quality verification tool.**

tensor-spec compares tensor operation precision across deep learning frameworks (currently PaddlePaddle vs PyTorch) using process isolation and CUDA IPC zero-copy GPU data sharing.

## Quick Start

```bash
# Install
uv pip install tensor-spec

# Check a case against a backend
tensor-spec check 'abs(x=Tensor.float32((2, 3)))' --target backend=torch,python=$(which python)

# Cross-framework comparison
tensor-spec check cases/ --target torch-cu124 --target paddle-cu124

# Environment diagnosis
tensor-spec doctor
```

## Architecture

The tool uses a 10-layer architecture with separate venvs for each framework to avoid CUDA runtime conflicts. GPU tensors are shared zero-copy via CUDA IPC handles.

See [Architecture Design](design/architecture.md) for details.

## Documentation

- [Design Rationale](rationale.md) — Quick reference for all design decisions
- [Design Documents](design/architecture.md) — Detailed architecture and design docs
- [CLI Specification](design/cli-specification.md) — Command tree, options, config schema, output contracts
- [Implementation Plans](plans/2026-03-03-phase0-implementation.md) — Phase-by-phase plans
- [API Reference](api/index.md) — Auto-generated from source code
