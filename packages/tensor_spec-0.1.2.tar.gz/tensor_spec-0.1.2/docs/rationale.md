# tensor-spec 设计决策速查

每个点说明：做了什么选择、为什么、为什么不选其他方案。

---

## 1. dataclass，不用 pydantic

**选择：** `@dataclass(frozen=True, slots=True)`

**为什么：**
- spec 层要求零外部依赖，dataclass 是 stdlib
- 我们不需要 JSON schema 生成或自动验证——序列化目标是自定义二进制协议（`.tspecb`）
- 验证逻辑明确且有限（float stats 不该出现在 bool tensor 上），`__post_init__` 足够

**为什么不用 pydantic：** pydantic 的核心优势（声明式验证、JSON 序列化）我们用不上。引入它只增加依赖，不增加价值。如果后续需要复杂嵌套验证，dataclass → pydantic 迁移成本很低（字段定义兼容）。

---

## 2. Tensor.dtype() 工厂模式，不用 Tensor(shape, dtype)

**选择：** `Tensor.float32((2, 3))` 返回 `FloatTensorSpec`

**为什么：**
- dtype 决定了 `.stats()` 的合法参数（float 有 min/max，bool 有 true_ratio）。工厂方法返回特定类型，类型安全在定义层面就确定了
- 只有一个标识符 `Tensor`，不会与任何框架类名冲突
- 新增 dtype 只需加一个 `@classmethod`，不需要新的顶级类

**为什么不用 `Tensor(shape, "float32")`：** `.stats()` 方法必须根据 dtype 接受不同参数，这在同一个类上做隐式多态——给 bool tensor 传 `min=-5.9` 只能运行时报错，无法从定义层面约束。

**为什么不用 `Float32Tensor(shape)`：** 标识符爆炸——15+ 个类（float16/32/64/bfloat16/int8/16/32/64/uint8/bool/complex64/128...），每加一个 dtype 就多一个顶级类。

---

## 3. Device 对标 DLPack，不自造体系

**选择：** `DeviceType` IntEnum 的整数值直接映射 DLPack 的 `DLDeviceType`（CPU=1, CUDA=2, ROCM=10, ONEAPI=14...）；字段名 `device_type` + `device_id` 对标 DLPack 的 `DLDevice` 结构体。

**为什么：**
- DLPack 是跨框架张量共享的事实标准（PyTorch/JAX/Paddle/CuPy/NumPy 都实现了 `__dlpack__`）
- 对齐命名后，DeviceSpec 可直接产出 `__dlpack_device__()` 返回值，零转换
- 避免自造一套设备名称体系后再写映射表

**为什么不用纯字符串 type：** 字符串无约束，拼写错误无法在定义时发现。IntEnum 提供编译期检查和自动补全。

---

## 4. 白名单递归下降 parser，不用 eval()

**选择：** 手写 tokenizer + 递归下降 parser，只允许 `Tensor`、`Device`、`tuple`、`list`、`slice`、字面量。

**为什么：**
- `eval()` 是代码执行，不是解析。Config 字符串来自外部，eval 等于允许任意代码注入
- 手写 parser 的错误信息精确到字符位置，eval 的报错是 Python traceback，对用户没有帮助
- 调试时可以单步跟踪解析过程，eval 是黑盒

**为什么不用 AST（`ast.literal_eval` / `ast.parse`）：** `ast.literal_eval` 不支持函数调用（`Tensor.float32(...)`）。`ast.parse` 可以，但需要遍历 AST 做白名单检查，复杂度不低于直接手写 parser，且多了 Python AST 这一层抽象。

---

## 5. 约束驱动数据生成，不按 API 名称 hardcode

**选择：** TensorSpec 的 `.stats()` 声明约束（nonzero/positive_definite/...），数据生成器只读 stats，不需要知道 API 名称。

**为什么：**
- PaddleAPITest 的 `get_numpy_tensor()` 膨胀到 2500 行，本质是因为约束信息藏在代码里而非配置里
- 新增约束 = 新增一个 `Constraint` 类 + 在 stats 上加一个字段，不修改主逻辑
- Config 文件自包含——只看 config 就知道数据长什么样，不需要翻代码

**为什么不沿用旧方案（API→代码分支）：** 不可维护。每新增一个有特殊数据需求的 API，就要加一个 `elif api_name ==` 分支。

---

## 6. frozen dataclass + with_xxx() 替代链式可变 .stats()

**选择：** 所有 TensorSpec 是 `frozen=True`，`.with_stats()` / `.with_state()` 返回新实例（via `dataclasses.replace()`）。

**为什么：**
- 不可变数据结构在多进程传递时天然安全，不需要防御性拷贝
- Parser 中间状态不会意外污染最终结果
- 便于缓存和序列化——同一 spec 始终 equal

**为什么不用可变链式调用（`.stats().state()` 修改 self）：** 与 `frozen=True` 矛盾。要么放弃 frozen（失去不可变保证），要么在 `.stats()` 里用 `object.__setattr__` hack——丑陋且容易出错。

---

## 7. 多 venv 进程隔离，不在同一进程 import 多框架

**选择：** 每个框架独立 venv + 独立子进程，用 SharedMemory/CUDA IPC 传数据。

**为什么：**
- Paddle 和 PyTorch 有底层依赖冲突（CUDA/cuDNN 版本、C++ 库），同 env 安装不稳定
- 隐式 import 顺序约束（"paddle must import before torch"）在加第三个框架时彻底崩溃
- 进程隔离后，每个 worker 的崩溃不影响其他 worker

**为什么不用同进程 + import_order 配置：** 脆弱的隐式约束。PaddleAPITest 全项目严格遵守这个顺序，但新贡献者一不注意就会引入 bug，且加 JAX 后三框架的 import 顺序无解。

---

## 8. GPU 比较走 CUDA IPC 零拷贝，不拉回 CPU

**选择：** GPU 测试结果留在 GPU，通过 CUDA IPC handle（64 字节）跨进程传引用，选一个 Comparator Worker 在 GPU 上做 `assert_close`。

**为什么：**
- 16GB tensor 拉回 CPU 做 `np.allclose()` 需要 ~97 秒，GPU 上做 `torch.isclose()` 只需 ~50 毫秒，差 1000x
- GPU tensor 本来就在显存里，拉回 CPU 是多余的

**为什么不用 DLPack 跨进程：** DLPack 的 `DLManagedTensor` 包含原始指针（`void* data`、`void (*deleter)`），是进程局部虚拟地址，不能跨进程。跨进程 GPU 共享只能用 CUDA IPC。

**Phase 0 暂用 CPU 路径，Phase 1 实现 CUDA IPC。**

---

## 9. 自定义二进制格式存储 case（.tspecb），不用纯文本

**选择：** `.tspecb` 格式 = 针对 case DSL 词汇表优化的自定义压缩二进制格式。

**为什么：**
- 950 万条 case 纯文本 1.4GB，自定义编码利用 DSL 的重复词汇（`Tensor.float32`、函数名、shape 元组）做领域特定压缩，比通用方案压缩比更高
- 自定义编解码器可以流式解析，不需要全量加载到内存
- 编解码逻辑完全由项目控制，格式演进不受第三方库版本约束

**为什么不用 Protobuf：** 需要 `.proto` 文件和代码生成步骤，对我们的场景（动态 schema，不同 API 参数不同）过重。

**为什么不用 MessagePack：** MessagePack 是优秀的通用二进制序列化方案，但作为通用格式无法利用 case DSL 的领域特征——`Tensor.float32`、函数名、shape 元组等重复模式占数据的大部分。领域特定编码器可以对这些高频词汇建字典、做变长编码，获得更高压缩比和更快解码速度。

---

## 10. JSON Lines 运行日志，不用纯文本或数据库

**选择：** structlog → JSON Lines（`.jsonl`），一行一个 JSON 对象。

**为什么：**
- 人可读（`cat` / `tail -f`） + 结构化（`jq` / `pandas` / DuckDB 直接分析）
- append-only 流式写入，多进程安全（每行原子写入）
- 不需要自定义解析脚本

**为什么不用 SQLite：** 多进程写入需要锁，高并发日志场景下成为瓶颈。

**为什么不沿用纯文本日志：** PaddleAPITest 的 12 种纯文本文件格式需要各自的解析脚本，无法用通用工具分析。

---

## 11. uv 包管理，不用 pip + requirements.txt

**选择：** uv + pyproject.toml，标准 PEP 621 项目结构。

**为什么：**
- uv 的依赖解析和安装速度比 pip 快 10-100x
- 内建 venv 管理——多 venv 隔离方案需要频繁创建/切换 venv，uv 做这件事极快
- `uv.lock` 提供可重现的依赖锁定

**为什么不用 pip：** pip 没有 lockfile，没有内建 venv 管理，安装速度慢。在需要管理多个框架 venv 的场景下，pip 的慢速是实际的生产力问题。

---

## 12. typer CLI，不用 click 或 argparse

**选择：** typer。

**为什么：**
- 类型提示驱动的命令定义（`Annotated[str, typer.Option(...)]`），比 click 的装饰器更 Pythonic
- 底层基于 click，继承 `CliRunner` 测试工具和子命令组织能力
- 自动生成帮助文档，参数验证由类型系统保证
- `str | None` 直接表达可选参数，无需 `Optional` 或 `default=None` 样板代码

详见 [CLI 设计规格](design/cli-specification.md)。

**为什么不用 click：** click 的 `@click.option` 装饰器堆叠冗长，参数类型和默认值分散在装饰器和函数签名两处。typer 统一在函数签名中，一目了然。

**为什么不用 argparse：** 子命令支持需要手写 subparsers 样板代码；没有内建测试工具；参数验证需要手写 `type=` 函数。
