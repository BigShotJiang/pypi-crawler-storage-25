# tensor-spec 整体架构设计

## 0. 定位

tensor-spec 是一个**框架无关的深度学习 API 质量验证工具**。核心能力：
- 用声明式 Spec 描述张量输入约束
- 跨框架（Paddle / PyTorch / JAX / ...）执行同一 API 并比较结果
- 多 GPU 并行、断点续跑、结构化报告

---

## 1. 模块总览

```
tensor-spec/
├── pyproject.toml
├── src/
│   └── tensor_spec/
│       ├── __init__.py
│       │
│       ├── spec/                    # ① Tensor 描述层（框架无关的纯数据结构）
│       │   ├── __init__.py
│       │   ├── tensor.py            #    Tensor 工厂类 + TensorSpec 基类
│       │   ├── float_spec.py        #    FloatTensorSpec + float stats
│       │   ├── int_spec.py          #    IntTensorSpec + int stats
│       │   ├── bool_spec.py         #    BoolTensorSpec + bool stats
│       │   ├── complex_spec.py      #    ComplexTensorSpec + complex stats
│       │   ├── device.py            #    Device / DeviceSpec
│       │   └── state.py             #    TensorState (grad, contiguous, etc.)
│       │
│       ├── config/                  # ② Config 解析层
│       │   ├── __init__.py
│       │   ├── parser.py            #    Config 字符串 → CaseConfig 对象
│       │   ├── case.py              #    CaseConfig: api_name + args/kwargs(含 TensorSpec)
│       │   ├── loader.py            #    从文件/glob 加载 config，去重，checkpoint 跳过
│       │   └── serializer.py        #    CaseConfig → 字符串（序列化，用于 log/dump）
│       │
│       ├── datagen/                 # ③ 数据生成层（TensorSpec → numpy）
│       │   ├── __init__.py
│       │   ├── generator.py         #    核心：TensorSpec → numpy array（约束感知）
│       │   ├── constraints.py       #    约束实现：nonzero, positive_definite, unique, ...
│       │   └── cache.py             #    缓存大 numpy 数组（替代 USE_CACHED_NUMPY）
│       │
│       ├── backend/                 # ④ 框架后端层（可插拔）
│       │   ├── __init__.py
│       │   ├── base.py              #    BackendBase 抽象：numpy→tensor, exec_api, grad, ...
│       │   ├── paddle_backend.py    #    PaddleBackend: paddle 特有的 API 执行逻辑
│       │   ├── torch_backend.py     #    TorchBackend: torch 特有的 API 执行逻辑
│       │   └── registry.py          #    后端注册表：名称 → BackendBase 实例
│       │
│       ├── mapping/                 # ⑤ API 映射层
│       │   ├── __init__.py
│       │   ├── api_mapping.py       #    规范 API 名 ↔ 框架 API 名的双向映射
│       │   ├── arg_mapping.py       #    参数名映射（如 x → input）
│       │   └── mappings/            #    每个框架的映射文件
│       │       ├── paddle.json
│       │       ├── torch.json
│       │       └── ...
│       │
│       ├── compare/                 # ⑥ 比较层
│       │   ├── __init__.py
│       │   ├── comparator.py        #    比较策略接口 + 默认实现
│       │   ├── tolerance.py         #    容差配置（全局默认 + per-API 覆盖）
│       │   └── report.py            #    比较结果的结构化表示
│       │
│       ├── tester/                  # ⑦ 测试模式层
│       │   ├── __init__.py
│       │   ├── base.py              #    TesterBase: 统一的 test() 骨架（模板方法）
│       │   ├── accuracy.py          #    AccuracyTester: 跨框架精度对比
│       │   ├── single_backend.py    #    SingleBackendTester: 单框架执行（替代 paddle_only）
│       │   ├── stability.py         #    StabilityTester: 多次运行比较确定性
│       │   ├── performance.py       #    PerformanceTester: GPU 性能基准
│       │   └── cinn.py              #    CINNTester: 动态图 vs 静态图（Paddle 特有）
│       │
│       ├── engine/                  # ⑧ 执行引擎层
│       │   ├── __init__.py
│       │   ├── runner.py            #    单进程顺序执行器
│       │   ├── parallel.py          #    多进程并行执行器（GPU 感知）
│       │   ├── worker.py            #    Worker 初始化、信号处理、内存管理
│       │   └── gpu.py               #    GPU 探测、内存查询、设备分配
│       │
│       ├── log/                     # ⑨ 日志与报告层
│       │   ├── __init__.py
│       │   ├── writer.py            #    结构化日志写入（JSON Lines）
│       │   ├── aggregator.py        #    多进程日志合并
│       │   ├── checkpoint.py        #    断点续跑（checkpoint 读写）
│       │   └── report.py            #    最终报告生成（summary + detail）
│       │
│       └── cli.py                   # ⑩ CLI 入口
│
├── configs/                         # 默认配置
│   ├── tolerance.yaml               #    全局 + per-API 容差
│   ├── skip.yaml                    #    跳过规则
│   └── error_dismiss.yaml           #    可忽略错误
│
├── mappings/                        #  API 映射数据（也可放 src 内）
│   ├── paddle.json
│   └── torch.json
│
├── tests/                           # tensor-spec 自身的单元测试
│   ├── test_spec/
│   ├── test_parser/
│   ├── test_datagen/
│   ├── test_compare/
│   └── ...
│
└── docs/
```

---

## 2. 各层职责与关键设计

### ① spec 层：纯数据结构，零依赖

**核心原则：** spec 层只依赖 Python 标准库，不 import 任何框架（numpy/paddle/torch）。
它只是对张量"规格"的描述，不参与任何计算。

```python
# tensor.py
class Tensor:
    """命名空间类，只包含工厂方法"""

    @classmethod
    def float32(cls, shape, device=None):
        return FloatTensorSpec(shape=shape, dtype="float32", device=device)

    @classmethod
    def bool(cls, shape, device=None):
        return BoolTensorSpec(shape=shape, dtype="bool", device=device)

    # ... 每种 dtype 一个 classmethod

class TensorSpec:
    """基类（dataclass）"""
    shape: tuple
    dtype: str
    device: DeviceSpec | None
    _state: TensorState | None

    def state(self, **kwargs) -> Self:
        self._state = TensorState(**kwargs)
        return self

class FloatTensorSpec(TensorSpec):
    _stats: FloatStats | None

    def stats(self, **kwargs) -> Self:
        self._stats = FloatStats(**kwargs)
        return self
```

**好处：**
- Config 解析只需要 spec 层，不需要 import 任何框架
- 序列化/反序列化完全独立
- 可以在不安装 paddle/torch 的环境中验证 config 文件的合法性

### ② config 层：安全解析，告别 eval

PaddleAPITest 的 `eval()` 解析方式有安全性和可调试性问题。新设计：

```python
# parser.py 核心思路：
#
# 1. 词法分析（tokenizer）：将字符串拆为 tokens
# 2. 语法分析（parser）：递归下降解析 tokens 为 AST
# 3. 构建 CaseConfig：从 AST 构建 CaseConfig 对象
#
# 不使用 eval()，而是白名单式地处理每种语法结构

class ConfigParser:
    ALLOWED_CONSTRUCTORS = {
        "Tensor": Tensor,       # 工厂方法入口
        "Device": Device,       # 设备
        "tuple": tuple,
        "list": list,
        "slice": slice,
    }

    def parse(self, config_str: str) -> CaseConfig:
        tokens = self.tokenize(config_str)
        return self.parse_call(tokens)
```

**Config 文本格式示例：**

```
abs(x=Tensor.float64((1, 100)))
linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))
nn.conv2d(x=Tensor.float32((1, 3, 224, 224)).state(need_grad=True), weight=Tensor.float32((64, 3, 7, 7)), stride=2, padding=3)
```

### ③ datagen 层：约束驱动的数据生成

**替代 PaddleAPITest 的 2500 行 `get_numpy_tensor()`**

```python
# generator.py
class TensorGenerator:
    """TensorSpec → numpy.ndarray"""

    def generate(self, spec: TensorSpec) -> np.ndarray:
        if isinstance(spec, FloatTensorSpec):
            return self._gen_float(spec)
        elif isinstance(spec, IntTensorSpec):
            return self._gen_int(spec)
        elif isinstance(spec, BoolTensorSpec):
            return self._gen_bool(spec)
        elif isinstance(spec, ComplexTensorSpec):
            return self._gen_complex(spec)

    def _gen_float(self, spec: FloatTensorSpec) -> np.ndarray:
        stats = spec.stats or FloatStats()  # 使用默认值
        data = np.random.uniform(stats.min, stats.max, spec.shape).astype(spec.dtype)

        # 依次应用约束（pipeline 模式）
        for constraint in self._get_constraints(stats):
            data = constraint.apply(data, spec)
        return data

    def _get_constraints(self, stats: FloatStats) -> list[Constraint]:
        constraints = []
        if stats.nonzero:
            constraints.append(NonZeroConstraint())
        if stats.positive_definite:
            constraints.append(PositiveDefiniteConstraint())
        if stats.unique:
            constraints.append(UniqueConstraint())
        if stats.has_nan:
            constraints.append(InjectNaNConstraint())
        return constraints

# constraints.py
class Constraint(ABC):
    @abstractmethod
    def apply(self, data: np.ndarray, spec: TensorSpec) -> np.ndarray: ...

class NonZeroConstraint(Constraint):
    def apply(self, data, spec):
        data[data == 0] = np.finfo(data.dtype).tiny
        return data

class PositiveDefiniteConstraint(Constraint):
    def apply(self, data, spec):
        n = spec.shape[-1]
        data = data.reshape(-1, n, n)
        data = data @ np.swapaxes(data, -1, -2) + np.eye(n)
        return data.reshape(spec.shape)
```

**好处：**
- 新增约束 = 新增一个 Constraint 类，不修改主逻辑
- spec 中没声明的约束不会被应用
- 约束可组合、可测试

### ④ backend 层：可插拔的框架后端

```python
# base.py
class BackendBase(ABC):
    """框架后端抽象"""

    name: str  # "paddle", "torch", "jax", ...

    @abstractmethod
    def import_framework(self):
        """import 框架（在 worker 进程中调用）"""
        ...

    @abstractmethod
    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        """numpy → 框架 tensor"""
        ...

    @abstractmethod
    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        """框架 tensor → numpy（用于比较）"""
        ...

    @abstractmethod
    def exec_api(self, api_name: str, args: list, kwargs: dict) -> Any:
        """执行 API 调用"""
        ...

    @abstractmethod
    def compute_grad(self, outputs, inputs, grad_outputs) -> list:
        """计算梯度"""
        ...

    @abstractmethod
    def empty_cache(self):
        """清理 GPU 缓存"""
        ...

    @abstractmethod
    def check_cuda_error(self):
        """检查异步 CUDA 错误"""
        ...

# paddle_backend.py
class PaddleBackend(BackendBase):
    name = "paddle"

    def import_framework(self):
        import paddle
        self.framework = paddle

    def numpy_to_tensor(self, np_array, spec):
        import paddle
        t = paddle.to_tensor(np_array, dtype=spec.dtype)
        if spec.state and spec.state.need_grad:
            t.stop_gradient = False
        return t

    def exec_api(self, api_name, args, kwargs):
        api_func = self._resolve_api(api_name)  # "nn.conv2d" → paddle.nn.functional.conv2d
        return api_func(*args, **kwargs)

    def check_cuda_error(self):
        import paddle
        paddle.base.core.eager._for_test_check_cuda_error()

# torch_backend.py
class TorchBackend(BackendBase):
    name = "torch"
    # 类似实现...
```

**好处：**
- 添加新框架 = 实现 BackendBase 接口
- 框架的 import 顺序在 worker 中由 engine 控制，不再是隐式约束
- 不再需要 paddle_to_torch 转换——直接用两个 backend 分别执行，用 numpy 做中间表示

### ⑤ mapping 层

```json
// mappings/paddle.json
{
  "abs": {"api": "paddle.abs", "args_map": {"x": "x"}},
  "nn.conv2d": {
    "api": "paddle.nn.functional.conv2d",
    "args_map": {"x": "x", "weight": "weight", "bias": "bias"}
  },
  "linalg.cholesky": {"api": "paddle.linalg.cholesky", "args_map": {"x": "x"}}
}

// mappings/torch.json
{
  "abs": {"api": "torch.abs", "args_map": {"x": "input"}},
  "nn.conv2d": {
    "api": "torch.nn.functional.conv2d",
    "args_map": {"x": "input", "weight": "weight", "bias": "bias"}
  },
  "linalg.cholesky": {"api": "torch.linalg.cholesky", "args_map": {"x": "input"}}
}
```

**好处：**
- 完全替代 PaddleAPITest 的 mapping.json + 6500 行 rules.py
- 简单 API 只需 JSON 映射，不需要代码
- 复杂 API 可注册自定义 adapter（plugin 机制）

### ⑥ compare 层

比较层支持两条路径：GPU 测试走 Comparator Worker 的 GPU 比较，纯 CPU 测试走 numpy。

```python
# comparator.py
class Comparator:
    """CPU 比较（纯 CPU 测试的降级路径）"""
    def compare(self, actual: np.ndarray, expected: np.ndarray,
                tolerance: Tolerance, api_name: str) -> CompareResult:
        tol = tolerance.get(api_name)  # per-API 覆盖
        if actual.dtype == np.bool_:
            return self._compare_exact(actual, expected)
        return self._compare_close(actual, expected, tol.atol, tol.rtol)

# gpu_comparator.py — GPU 比较能力声明（在 BackendBase 中）
class BackendBase(ABC):
    @property
    def supports_gpu_compare(self) -> bool:
        """是否支持 GPU 上的精度比较"""
        return False

    def gpu_assert_close(self, actual, expected, atol, rtol) -> CompareResult:
        """Comparator backend 在 GPU 上比较两个 tensor"""
        raise NotImplementedError

    def wrap_foreign_gpu_ptr(self, view) -> Any:
        """从 __cuda_array_interface__ 对象构建本框架 tensor"""
        raise NotImplementedError

# comparator_selector.py — Comparator 选择
GPU_COMPARATOR_PRIORITY = ["torch", "jax", "paddle"]  # 可配置

def select_comparator(backend_a, backend_b, priority=GPU_COMPARATOR_PRIORITY):
    participants = {backend_a.name, backend_b.name}
    for name in priority:
        if name in participants and get_backend(name).supports_gpu_compare:
            return get_backend(name)
    return None  # fallback 到 CPU numpy

# tolerance.py
@dataclass
class Tolerance:
    default_atol: float = 1e-2
    default_rtol: float = 1e-2
    overrides: dict[str, tuple[float, float]]  # api_name → (atol, rtol)

    @classmethod
    def from_toml(cls, path: str) -> Tolerance: ...
```

### ⑦ tester 层：模板方法模式

**消除 PaddleAPITest 中的代码重复**

```python
# base.py
class TesterBase(ABC):
    """所有测试模式的公共骨架"""

    def test(self, case: CaseConfig) -> TestResult:
        try:
            # 1. 生成数据
            numpy_inputs = self.generate_inputs(case)

            # 2. 执行（子类实现）
            outputs = self.execute(case, numpy_inputs)

            # 3. 比较（子类实现）
            result = self.compare(case, outputs)

            return result

        except CudaError as e:
            return TestResult.cuda_error(case, e)
        except OOMError as e:
            return TestResult.oom(case, e)
        except Exception as e:
            return TestResult.error(case, e)

    def generate_inputs(self, case: CaseConfig) -> dict:
        """公共：TensorSpec → numpy（所有模式共享）"""
        generator = TensorGenerator()
        return {
            name: generator.generate(spec)
            for name, spec in case.tensor_specs.items()
        }

    @abstractmethod
    def execute(self, case, numpy_inputs) -> dict:
        """子类实现：如何执行 API"""
        ...

    @abstractmethod
    def compare(self, case, outputs) -> TestResult:
        """子类实现：如何比较结果"""
        ...

# accuracy.py
class AccuracyTester(TesterBase):
    """跨框架精度对比（替代 APITestAccuracy）

    NOTE: CLI 层使用 --target 结构化参数选择后端（见 cli-specification.md），
    引擎内部仍以 backend_a / backend_b 引用执行实例。
    """

    def __init__(self, backend_a: BackendBase, backend_b: BackendBase,
                 comparator: Comparator, tolerance: Tolerance):
        self.backend_a = backend_a
        self.backend_b = backend_b
        self.comparator = comparator
        self.tolerance = tolerance

    def execute(self, case, numpy_inputs):
        # backend A 执行
        tensors_a = self._to_tensors(self.backend_a, numpy_inputs, case)
        output_a = self.backend_a.exec_api(case.api_name, tensors_a.args, tensors_a.kwargs)
        self.backend_a.check_cuda_error()

        # backend A 反向
        grads_a = None
        if case.need_grad:
            grads_a = self.backend_a.compute_grad(...)

        # 清理 backend A
        self.backend_a.empty_cache()

        # backend B 执行（同样流程）
        tensors_b = self._to_tensors(self.backend_b, numpy_inputs, case)
        output_b = self.backend_b.exec_api(case.api_name, tensors_b.args, tensors_b.kwargs)
        grads_b = ...

        return {"a_output": output_a, "b_output": output_b,
                "a_grads": grads_a, "b_grads": grads_b}

    def compare(self, case, outputs):
        np_a = self.backend_a.tensor_to_numpy(outputs["a_output"])
        np_b = self.backend_b.tensor_to_numpy(outputs["b_output"])
        return self.comparator.compare(np_a, np_b, self.tolerance, case.api_name)

# single_backend.py
class SingleBackendTester(TesterBase):
    """单框架执行（替代 APITestPaddleOnly）"""

    def execute(self, case, numpy_inputs):
        tensors = self._to_tensors(self.backend, numpy_inputs, case)
        output = self.backend.exec_api(case.api_name, tensors.args, tensors.kwargs)
        return {"output": output}

    def compare(self, case, outputs):
        return TestResult.passed(case)  # 只要不报错就算 pass
```

### ⑧ engine 层

```python
# parallel.py
class ParallelEngine:
    """多进程并行执行器（替代 engineV2）"""

    def __init__(self, config: EngineConfig):
        self.config = config

    def run(self, cases: list[CaseConfig], tester_factory: Callable):
        set_start_method("spawn")
        gpu_manager = GPUManager(self.config.gpu_ids, self.config.memory_per_worker)

        with ProcessPool(
            max_workers=gpu_manager.total_workers,
            initializer=self._init_worker,
            initargs=(gpu_manager, tester_factory, self.config),
        ) as pool:
            for batch in chunked(cases, self.config.batch_size):
                futures = [pool.schedule(run_case, args=(case,), timeout=self.config.timeout)
                           for case in batch]
                self._collect_results(futures)

    def _init_worker(self, gpu_manager, tester_factory, config):
        gpu_id = gpu_manager.assign_gpu(os.getpid())
        os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)

        # 框架 import 顺序由 config 控制
        for backend_name in config.import_order:
            backend = get_backend(backend_name)
            backend.import_framework()

        # 初始化 tester
        global _worker_tester
        _worker_tester = tester_factory()
```

### ⑨ log 层

```python
# writer.py — JSON Lines 结构化日志
{"ts": "2025-01-01T00:00:00", "case": "abs(x=Tensor.float64((100,)))", "status": "pass", "gpu": 0, "pid": 12345}
{"ts": "2025-01-01T00:00:01", "case": "div(...)", "status": "accuracy_error", "fwd_max_diff": 0.003, "api": "div"}
{"ts": "2025-01-01T00:00:02", "case": "conv2d(...)", "status": "cuda_error", "error": "CUDA error..."}
```

**好处：** 可直接用 jq / pandas / DuckDB 分析，不需要自定义解析脚本。

---

## 3. 与 PaddleAPITest 的架构对比

| 维度 | PaddleAPITest | tensor-spec |
|------|:----------:|:---------:|
| Tensor 描述 | `Tensor([shape], "dtype")` — 信息不足 | `Tensor.dtype(shape).stats(...).state(...)` — 自包含 |
| 数据生成 | 2500 行 API 感知 hardcode | ~200 行约束驱动 pipeline |
| 框架支持 | Paddle + Torch 硬编码 | 可插拔 Backend（任意框架） |
| 跨框架转换 | paddle_to_torch 6500 行 rules.py | JSON 映射 + 小型 adapter |
| Config 解析 | `eval()` 不安全 | 白名单递归下降 parser |
| 测试模式 | 9 个类大量代码重复 | 模板方法 + 策略模式 |
| 日志 | 12 种纯文本文件 | JSON Lines 结构化 |
| 引擎 | 3 个独立引擎(V1/V2/V3) | 1 个引擎 + 2 种 runner(单进程/并行) |
| 自身测试 | 无 | 完整单元测试 |
| import 顺序 | 隐式约束（paddle before torch） | 显式配置（`config.import_order`） |

---

## 4. 关键数据流

```
Config 文件
│  abs(x=Tensor.float64((100,)).stats(min=-5, max=5))
│
▼
ConfigParser.parse()
│  → CaseConfig(api="abs", args={"x": FloatTensorSpec(shape=(100,), dtype="float64", stats=FloatStats(min=-5, max=5))})
│
▼
TesterBase.generate_inputs()
│  TensorGenerator: FloatTensorSpec → numpy.ndarray (约束驱动)
│
▼
TesterBase.execute()  ← 子类实现
│  ├── BackendA.numpy_to_tensor() → 框架A tensor
│  ├── APIMapping.resolve("abs", "paddle") → paddle.abs
│  ├── BackendA.exec_api("paddle.abs", ...) → 框架A 输出
│  ├── BackendA.compute_grad(...) → 框架A 梯度
│  ├── BackendA.empty_cache()
│  │
│  ├── BackendB.numpy_to_tensor() → 框架B tensor
│  ├── APIMapping.resolve("abs", "torch") → torch.abs
│  ├── BackendB.exec_api("torch.abs", ...) → 框架B 输出
│  └── BackendB.compute_grad(...) → 框架B 梯度
│
▼
TesterBase.compare()
│  Comparator: numpy_a vs numpy_b (with Tolerance)
│  → CompareResult(status, max_abs_diff, max_rel_diff, ...)
│
▼
LogWriter.write(TestResult)
│  → {"ts": ..., "case": ..., "status": "pass", ...}
```

---

## 5. CLI 设计

> 完整 CLI 规范见 `cli-specification.md`。以下为常用命令速览。

```bash
# 跨框架精度对比（多 target）
tensor-spec check cases/ --target torch-cu124 --target paddle-cu124

# 单框架执行检查（inline target）
tensor-spec check cases/ --target backend=paddle,python=/venv/paddle/bin/python

# 性能基准（e2e 模式，指定 baseline）
tensor-spec bench --mode e2e cases/ --target torch-cu124 --target paddle-cu124 --baseline torch-cu124

# CUDA kernel profiling（ncu 模式）
tensor-spec bench --mode ncu cases/ --target torch-cu124 --target paddle-cu124

# 预检校验（不执行，只解析检查）
tensor-spec check cases/ --target torch-cu124 --dry-run

# 环境诊断
tensor-spec doctor

# 从 PaddleAPITest 旧格式迁移
tensor-spec migrate --input old_configs/ --output new_configs/
```

---

## 6. import 顺序问题的根本解决

PaddleAPITest 依赖隐式约定（paddle before torch），tensor-spec 通过 **显式配置** 解决：

```yaml
# configs/engine.yaml
import_order:
  - paddle    # 先 import
  - torch     # 后 import
```

engine 在 worker 初始化时按配置顺序调用 `backend.import_framework()`，不再依赖文件头的 import 顺序。
