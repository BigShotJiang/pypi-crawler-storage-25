# tensor-spec 实施提示词

> ⚠️ CLI 设计已更新。详见 [CLI 设计规格](cli-specification.md)。

> 复制下方分隔线之间的内容，在 tensor-spec repo 目录中作为提示词发给 AI Agent 开始实施。

---

## 提示词开始

你将实施 **tensor-spec** — 一个框架无关的深度学习 API 质量验证工具，替代 PaddleAPITest（https://github.com/PFCCLab/PaddleAPITest）。

当前目录下有 5 份设计文档，是前期方案设计的成果。请先完整阅读以下文件，理解全部设计决策后再动手：

1. `architecture_design.md` — 10 层架构设计、模块职责、代码骨架
2. `design_decisions.md` — 技术选型（dataclass、MessagePack、TOML、多 venv + CUDA IPC）
3. `design_four_questions.md` — 现代工具链、进程隔离、渐进路线、Case 管理
4. `case_representation_design.md` — Case 表示格式（Approach 4: Tensor 工厂模式）
5. `PaddleAPITest_analysis.md` — 旧系统分析（作为参考，了解哪些问题要解决）

### 核心设计决策速查

**项目定位：** 框架无关的 DL API 质量验证工具。支持 Paddle / PyTorch / JAX / 任意框架。

**技术栈：**
- 包管理：uv + pyproject.toml
- 数据类：dataclass（frozen=True, slots=True），不用 pydantic
- Lint/Format：ruff
- 类型检查：ty
- 测试：pytest
- CLI：typer
- 日志：structlog → JSON Lines
- Case 存储：.tspec（文本）+ .tspecb（自定义二进制压缩）
- 配置：TOML
- 语言：Python 为主，性能热点用 Rust (PyO3)

**Case 表示格式（Approach 4）：**
```
abs(x=Tensor.float64((1, 100)))
linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))
nn.conv2d(x=Tensor.float32((1, 3, 224, 224)).state(need_grad=True), weight=Tensor.float32((64, 3, 7, 7)), stride=2, padding=3)
```

**进程隔离：** 多 venv（uv 管理），每个框架独立 Python 解释器子进程。

**数据传输双路径：**
- GPU 测试 → CUDA IPC + `__cuda_array_interface__` + Comparator Worker GPU 比较（结果不离开 GPU）
- 纯 CPU 测试 → SharedMemory + numpy 比较（降级路径）

**GPU Comparator 选择：** 优先级列表 `["torch", "jax", "paddle"]`，运行时从参与测试的 backend 中选最高优先级的做 comparator。Backend 声明 `supports_gpu_compare` 能力。

**10 层架构：** spec → config → datagen → backend → mapping → compare → tester → engine → log → cli

### Phase 0 实施目标（从这里开始）

```
目标：能解析 case、生成数据、跑单框架单 case
验收标准：能跑通 abs, add, matmul 三个 API 的单框架测试
```

需要实现的模块：

1. **项目骨架** — `pyproject.toml`（uv 项目），src layout，ruff/ty 配置
2. **spec/** — Tensor 工厂类 + TensorSpec dataclass 家族（FloatTensorSpec, IntTensorSpec, BoolTensorSpec, ComplexTensorSpec）+ Stats + State + Device
3. **config/parser.py** — 白名单递归下降 parser，解析 case 字符串 → CaseConfig（不用 eval）
4. **config/case.py** — CaseConfig dataclass（api_name + args/kwargs）
5. **datagen/generator.py** — TensorSpec → numpy array（约束驱动 pipeline）
6. **datagen/constraints.py** — 基础约束：NonZero, PositiveDefinite
7. **backend/base.py** — BackendBase 抽象类
8. **backend/paddle_backend.py** — PaddleBackend 实现
9. **cli.py** — `tensor-spec check 'abs(x=Tensor.float32((100,)))' --target backend=paddle,python=/venv/paddle/bin/python`
10. **tests/** — 所有模块的单元测试（pytest）

### 关键约束

- spec 层**零框架依赖**，只用 Python stdlib（dataclass）
- config parser **不用 eval()**，白名单递归下降
- 所有 dataclass 用 `frozen=True, slots=True`
- 全量 type hints，通过 ty 检查
- 每个模块都要有对应的 pytest 单测
- 遵循如无必要勿增实体原则，不过度设计
- Phase 0 暂不需要：torch backend、mapping 层、compare 层、engine 层、日志层、CUDA IPC

### 参考：旧系统的关键 API（PaddleAPITest）

以下是 tensor-spec 要替代的旧系统中的关键实现，可参考但不要照搬：

- `tester/api_config/config_analyzer.py` — 3132 行，TensorConfig + APIConfig + `get_numpy_tensor()`（2500 行 API 感知 hardcode）
- `tester/base.py` — 1149 行，paddle 必须在 torch 前 import，DLPack 比较
- `tester/accuracy.py` — 638 行，torch 先执行后释放 GPU，再执行 paddle
- `tester/paddle_to_torch/rules.py` — 6545 行，API 转换规则
- `engineV2.py` — 1049 行，Pebble ProcessPool + spawn + GPU 分配

旧系统在 `/workspace/PaddleAPITest/` 目录，如需查看细节可自行阅读。

### 开始

请先阅读上述 5 份设计文档，然后制定 Phase 0 的详细实施计划并开始实施。从项目骨架开始，逐步构建各模块，每完成一个模块就写对应的测试。

## 提示词结束
