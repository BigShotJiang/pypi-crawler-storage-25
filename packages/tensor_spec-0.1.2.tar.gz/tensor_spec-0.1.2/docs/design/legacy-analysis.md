# PaddleAPITest 完整代码分析报告

## 1. 项目概述

PaddleAPITest 是一个 Paddle API 质量保障框架，核心功能是通过对比 Paddle 与 PyTorch 同等 API 的前向/反向输出来发现 Paddle 的精度和功能问题。由 PFCCLab 社区开发维护。

**核心测试模式：**

| 模式 | 类名 | 说明 |
|------|------|------|
| accuracy | `APITestAccuracy` | Paddle vs PyTorch 前向/反向精度对比（主力） |
| paddle_only | `APITestPaddleOnly` | 仅运行 Paddle，验证 kernel 是否能正常执行 |
| paddle_cinn | `APITestCINNVSDygraph` | Paddle 动态图 vs CINN 静态图编译结果对比 |
| accuracy_stable | `APITestAccuracyStable` | 稳定性测试（多次运行同一 config 比较差异） |
| performance | 多个 Performance 类 | GPU 性能基准测试 |
| custom_device | `APITestCustomDeviceVSCPU` | 自定义设备(XPU/Iluvatar) vs CPU 精度对比 |

---

## 2. 关键实现细节

### 2.1 import 顺序：paddle 必须在 torch 之前 import

**这是全项目最关键的约束之一。** 在所有同时引入 paddle 和 torch 的文件中，一律遵循：

```python
import paddle
import torch
```

具体体现：

- `tester/base.py:6-8` — `import numpy` / `import paddle` / `import torch`
- `tester/accuracy.py:7-8` — `import paddle` / `import torch`
- `tester/api_config/config_analyzer.py:9-11` — `import numpy` / `import paddle` / `import torch`
- `engine.py:11-12` — `import paddle` / `import torch`
- `engineV2.py` 的 worker 初始化 `init_worker_gpu()` 中（line 387-388）：`import paddle` / `import torch`

**原因：** Paddle 和 PyTorch 都会注册 CUDA 相关的全局状态。如果 torch 先 import，可能导致 Paddle 的 CUDA context 初始化出问题（如设备探测、内存分配器冲突）。这个顺序在整个项目中被严格遵守。

### 2.2 环境变量设置

在引擎层面（`engineV2.py:42-43`）设置：

```python
os.environ["FLAGS_use_system_allocator"] = "1"    # 使用系统内存分配器而非 Paddle 自带的
os.environ["NVIDIA_TF32_OVERRIDE"] = "0"           # 禁用 TF32 以保证精度一致性
```

### 2.3 延迟导入（Lazy Import）机制

`engineV2.py` 使用 `TYPE_CHECKING` guard 避免在主进程中加载 paddle/torch：

```python
if TYPE_CHECKING:
    import paddle
    import torch
    from tester import (...)
```

实际导入发生在 **worker 子进程** 的 `init_worker_gpu()` 中，这样：
1. 每个子进程可以独立设置 `CUDA_VISIBLE_DEVICES`
2. 避免主进程占用 GPU 内存
3. `multiprocessing.set_start_method("spawn")` 保证子进程是全新的 Python 解释器

`tester/__init__.py` 使用 `__getattr__` 惰性加载模式：

```python
def __getattr__(name):
    if name in _lazy_imports:
        module_path, attr_name = _lazy_imports[name]
        module = importlib.import_module(module_path)
        return getattr(module, attr_name)
    raise AttributeError(...)
```

### 2.4 多进程并行执行（EngineV2 架构）

```
                    +------------------+
                    |   Main Process   |
                    | (不 import paddle/torch) |
                    +--------+---------+
                             |
                    set_start_method("spawn")
                             |
              +-------- Pebble ProcessPool --------+
              |              |                      |
       +------+-----+  +----+------+    +----------+---+
       | Worker 0   |  | Worker 1  |    | Worker N     |
       | GPU 0      |  | GPU 0     |    | GPU 3        |
       | import paddle| | import paddle| | import paddle|
       | import torch | | import torch | | import torch |
       +------+------+  +-----+-----+   +------+------+
              |                |                 |
         run_test_case()  run_test_case()   run_test_case()
```

**GPU 分配策略（`init_worker_gpu()`）：**
- 使用 `multiprocessing.Manager` dict + Lock 管理 GPU -> worker PID 映射
- 每个 worker 启动时，选择可用 slot 最多的 GPU
- 清理已死亡 worker 的 PID（通过 `os.kill(pid, 0)` 检测）
- 每个 worker 通过 `CUDA_VISIBLE_DEVICES` 绑定到指定 GPU

**批处理和超时：**
- 每批处理 20,000 条 config（`BATCH_SIZE = 20000`）
- 每个测试用例有超时（默认 1800s）
- worker 退出码：`99` = CUDA error，`98` = OOM，`1` = assertion error

### 2.5 DLPack 跨框架张量比较

精度比较的核心方法 `torch_assert_accuracy()`（`base.py:1004-1081`）使用 DLPack 协议实现零拷贝跨框架张量转换：

```python
def torch_assert_accuracy(self, paddle_tensor, torch_tensor, atol=1e-2, rtol=1e-2):
    # 1. Paddle Tensor -> CPU, detach, contiguous
    paddle_tensor = paddle_tensor.cpu().detach()
    if not paddle_tensor.is_contiguous():
        paddle_tensor = paddle_tensor.contiguous()

    # 2. 通过 DLPack 将 Paddle Tensor 转换为 Torch Tensor（零拷贝）
    paddle_dlpack = paddle.utils.dlpack.to_dlpack(paddle_tensor)
    converted_paddle_tensor = torch.utils.dlpack.from_dlpack(paddle_dlpack)

    # 3. 使用 torch.testing.assert_close() 比较
    torch.testing.assert_close(
        converted_paddle_tensor, torch_tensor,
        rtol=rtol, atol=atol,
        equal_nan=True,
        check_dtype=is_check_dtype,
    )
```

**关键点：**
- 转换前必须调用 `.cpu().detach().contiguous()`
- 如果 `torch.testing.assert_close` 因 dtype 不匹配抛出 "Comparing" 开头的错误，会 fallback 到 `numpy.testing.assert_allclose`
- 对于负 stride 的 tensor（如 `paddle.strided_slice` 输出），需要先调 `.contiguous()` 因为 torch 的 from_dlpack 不支持负 stride

### 2.6 精度容差配置

**默认容差：** `atol=1e-2, rtol=1e-2`（在 `APITestAccuracy.__init__` 中设置）

**特殊 API 容差**（`base_config.yaml` 中 `special_accuracy_atol_rtol`）：

```yaml
paddle.cumsum: [2.0, 0.01]
paddle.logcumsumexp: [2.0, 0.01]
paddle.tensordot: [1.0, 1.0]
paddle.matmul: [2.0, 0.05]
paddle.nn.functional.layer_norm: [0.2, 0.02]
paddle.nn.functional.softmax: [1, 0.01]
paddle.nn.functional.bilinear: [2.0, 0.08]
paddle.nn.functional.normalize: [0.2, 0.01]
paddle.incubate.nn.functional.fused_rms_norm: [3, 0.5]
paddle.incubate.nn.functional.fused_bias_dropout_residual_layer_norm: [1.0, 1.0]
```

**dtype 差异豁免**（`not_check_dtype` 列表）：约 30+ 个 API 允许输出 dtype 不一致。

**bitwise_alignment 模式：** 当启用时忽略所有特殊容差，使用精确比较（`atol=0, rtol=0`）。

### 2.7 Config 字符串格式与解析

测试用例用 **单行文本字符串** 描述，格式为：

```
paddle.api_name(arg1, arg2, kwarg_name=kwarg_value, )
```

其中张量参数使用特殊语法：

```
Tensor([shape], "dtype")
```

**实际示例：**

```
paddle.abs(Tensor([1, 100],"float64"), )
paddle.concat(tuple(Tensor([31376, 768],"float32"),Tensor([1, 768],"float32"),), axis=0, )
paddle.nn.functional.conv2d(Tensor([1, 3, 224, 224],"float32"), Tensor([64, 3, 7, 7],"float32"), bias=Tensor([64],"float32"), stride=2, padding=3, )
paddle.kthvalue(Tensor([4294967295],"float32"), 1, )
```

**`APIConfig` 解析流程**（`config_analyzer.py:2810+`）：

1. 将 `Tensor(` 替换为 `TensorConfig(`
2. 将 `paddle.Size([...])` 替换为 `[...]`
3. 通过 `get_api()` 提取 API 名称（第一个 `(` 之前的部分）
4. 使用正则 `get_tocken()` 逐 token 解析参数
5. 对每个 token 通过 `get_one_arg()` 分发到对应解析器：
   - `TensorConfig(...)` → `eval()` 构造 TensorConfig 对象
   - `Dtype(...)` → paddle dtype 转换
   - `list[...]` → 递归解析
   - `tuple(...)` → 递归解析
   - `slice(...)` → `eval("slice" + ...)`
   - 其他 → `eval(token)` 或字面值
6. 检查 token 后是否有 `=` 来判断是 positional 还是 keyword 参数

### 2.8 测试数据生成（`TensorConfig.get_numpy_tensor()`）

这是一个约 **2500 行** 的巨型方法，包含大量 API 特定的数据生成逻辑：

**通用规则：**

| 数据类型 | 生成方式 |
|---------|---------|
| 浮点 | `numpy.random.random(shape) - 0.5`（范围 [-0.5, 0.5]） |
| 整数 | `numpy.random.randint(-65535, 65535, size=shape)` |
| 布尔 | `numpy.random.random(shape) > 0.5` |

**API 特定逻辑示例：**

| API | 特殊处理 |
|-----|---------|
| 除法相关 API (`not_zero_apis`) | 生成非零值：浮点 `random() + 0.5`，整数 `randint(1, 65535)` |
| `paddle.arange` | 生成合法的 start/end/step 组合，限制范围不超过 100 |
| `paddle.bernoulli` | 生成 [0, 1] 范围内的概率值 |
| `paddle.linalg.cholesky` | 生成正定矩阵（`A @ A.T + I`） |
| `paddle.index_put` | 生成合法的索引张量 |
| `paddle.scatter` | 生成不越界的索引 |
| `paddle.nn.functional.cross_entropy` | label 张量值在 [0, num_classes) |
| `paddle.linalg.eigh` | 生成对称/Hermitian 矩阵 |

**bfloat16 特殊处理：**

NumPy 不原生支持 bfloat16，因此：
1. 将 dtype 临时改为 `float32` 生成 numpy 数据
2. 创建 paddle tensor 时先用 float32，再 `paddle.cast` 到 bfloat16
3. 创建 torch tensor 时先用 float32，再 `.to(dtype=torch.bfloat16)`

**缓存 numpy 机制（`USE_CACHED_NUMPY`）：**

当启用环境变量 `USE_CACHED_NUMPY=True` 时：
- 预生成 43 亿元素的大数组（每个 dtype 一个）
- 每次生成张量时从大数组中切片，避免重复随机数生成
- 显著加速大规模测试

### 2.9 Paddle-to-Torch 转换系统

**三层架构：**

```
mapping.json   →   rules.py      →   converter.py
(配置映射)         (转换规则)         (转换引擎)
```

**`mapping.json` 格式**（约 4900 行）：

```json
{
  "paddle.abs": {
    "torch_api": "torch.abs",
    "paddle_torch_args_map": { "x": "input" }
  },
  "paddle.nn.functional.conv2d": {
    "torch_api": "torch.nn.functional.conv2d",
    "paddle_torch_args_map": {
      "x": "input", "weight": "weight", "bias": "bias",
      "stride": "stride", "padding": "padding",
      "dilation": "dilation", "groups": "groups"
    },
    "Rule": "Conv2dRule"
  }
}
```

**规则系统**（`rules.py`，6545 行）：

- `Code` 数据类：分三阶段（`preprocess` / `core` / `postprocess`），自动 compile 为 `types.CodeType`
- `ConvertResult` 数据类：封装转换结果（code + output_var + error_message）
- `GenericRule`：通用规则，处理简单的 API 名称映射和参数重排
- `ErrorRule`：不支持转换的 API
- **数百个自定义 Rule 类**（如 `Conv1dRule`, `CrossEntropyRule`, `InterpolateRule` 等）

**转换结果缓存：** 每个 API 转换一次后缓存到 `cached_results` dict 中。

**执行方式：**

```python
exec_globals = {"torch": torch}
exec_locals = {
    "args": self.torch_args,
    "kwargs": self.torch_kwargs,
    "result": None,
    **self.torch_kwargs,  # kwargs 直接展开到 locals，方便 code 中按名称访问
}
exec(code.preprocess_compiled, exec_globals, exec_locals)
exec(code.core_compiled, exec_globals, exec_locals)
exec(code.postprocess_compiled, exec_globals, exec_locals)
torch_output = exec_locals[output_var]
```

### 2.10 测试执行流程（以 accuracy 模式为例）

```
1. need_skip()
   ├── 跳过 sparse API
   ├── 跳过 float8 dtype
   └── 跳过 torch_error_skip 中的 config

2. ana_api_info()
   ├── ana_paddle_api_info()
   │   ├── eval(api_name) 获取 paddle API 函数引用
   │   └── 保存 args/kwargs config
   └── ana_torch_api_info()
       ├── inspect.signature() 获取 paddle API 签名
       ├── paddle_sig.bind() 绑定参数
       └── 生成 torch 参数映射

3. converter.convert(api_name) → ConvertResult
   └── 获取预编译的转换代码

4. gen_numpy_input()
   └── 为每个 TensorConfig 生成 numpy 数据

5. ===== TORCH 执行 =====
   gen_torch_input()
   ├── numpy → torch tensor
   └── dtype 转换（paddle dtype → torch dtype）
   exec(converted_code)  → torch_output
   torch.autograd.grad()  → torch_out_grads（如需反向）

6. ===== PADDLE 执行 =====
   gen_paddle_input()
   ├── numpy → paddle tensor
   └── API 特殊处理（如 cross_entropy 的 softmax）
   paddle_api(*args, **kwargs)  → paddle_output
   paddle.grad()  → paddle_out_grads（如需反向）

7. ===== 比较 =====
   process_output()  — API 特殊后处理
   compare_paddle_and_torch()
   ├── torch_assert_accuracy()（主要：DLPack + torch.testing.assert_close）
   └── np_assert_accuracy()（备选：numpy.testing.assert_allclose）

8. write_to_log("pass" | "accuracy_error" | ...)
```

**关键设计：先 Torch 后 Paddle。** 这样做的原因是 Torch 执行完后可以清理 Torch GPU 内存再执行 Paddle，降低 OOM 风险。

### 2.11 反向测试逻辑

**前向唯一 API 列表（`forward_only_apis`）：** 约 580 个 API 仅测前向，包括：
- 比较运算：`equal`, `greater_than`, `less_than` 等
- 随机生成：`rand`, `randn`, `randint` 等
- 创建函数：`zeros`, `ones`, `full` 等
- 类型转换：`to`, `cast`, `astype` 等
- 分布式 API

**反向数据生成：**
- 对每个 output tensor，生成同 shape 的随机梯度（与 output_grad_numpy 对应）
- 使用 `paddle.grad()` / `torch.autograd.grad()` 计算
- gradient 在 paddle 和 torch 之间共享（通过相同的 numpy 数据初始化）
- bfloat16 的梯度先用 float32 生成再 cast

**inplace 操作处理**（trailing `_` 的 API，如 `paddle.Tensor.add_`）：
- 执行前先 `copy_paddle_input()` / `copy_torch_input()` 深拷贝输入
- inplace 操作的输出就是修改后的输入张量

### 2.12 错误分类与处理

| 错误类型 | 日志标签 | 严重程度 | 处理方式 |
|---------|---------|---------|---------|
| Config 解析失败 | (stdout) | 低 | return |
| Paddle→Torch 转换失败 | `paddle_to_torch_failed` | 低 | return |
| Numpy 生成失败 | `numpy_error` | 低 | return |
| Torch 执行失败 | `torch_error` | 中 | return（CUDA 错误 raise） |
| Paddle 可忽略错误 | `pass` | 低 | return（标记为 pass） |
| Paddle 执行失败 | `paddle_error` | 中 | return |
| CUDA 错误 | `cuda_error` | 高 | raise → worker exit(99) |
| OOM | `oom` | 高 | raise → worker exit(98) |
| 精度不匹配 | `accuracy_error` | 中 | return |

**CUDA 错误检测：** 每次 paddle/torch 执行后都调用 `paddle.base.core.eager._for_test_check_cuda_error()` 来检测异步 CUDA 错误。

**可忽略的 Paddle 错误**（`paddle_error_dismiss`）：特定 API 的特定错误消息被视为 Pass，如：
- conv 系列的 "element size of" 超限
- `cublasMatInv` 的 batch_size > 65536 限制
- 各种 INT_MAX 超限

### 2.13 日志系统

**12 种日志类型：**

```python
LOG_PREFIXES = {
    "checkpoint": "checkpoint",          # 记录当前正在测试的 config（用于断点续跑）
    "pass": "api_config_pass",           # 测试通过
    "numpy_error": "api_config_numpy_error",
    "paddle_error": "api_config_paddle_error",
    "torch_error": "api_config_torch_error",
    "paddle_to_torch_failed": "api_config_paddle_to_torch_failed",
    "accuracy_error": "api_config_accuracy_error",
    "accuracy_diff": "api_config_accuracy_diff",
    "timeout": "api_config_timeout",
    "crash": "api_config_crash",
    "oom": "api_config_oom",
    "match_error": "api_config_match_error",     # CINN 模式的类型不匹配
    "cuda_error": "api_config_cuda_error",
}
```

**双模式写入：**
- Engine V1（单进程）：直接写 `{prefix}{id}.txt`
- Engine V2（多进程）：每个 PID 写独立的 `.tmp/{prefix}_{pid}.txt`，最后 `aggregate_logs()` 合并

**stdout/stderr 重定向：** 通过文件描述符级别重定向（`redirect_stdio()`），将每个 worker 的 stdout/stderr 写入 `log_{pid}.log`。

**断点续跑（Checkpoint）：** 每处理一个 config 前写入 checkpoint 日志，重启时读取 checkpoint 跳过已处理的 config。

### 2.14 特殊 API 输出后处理

`process_output()` 和 `process_grad_output()` 函数处理 paddle 和 torch 输出格式不一致的情况：

| API | 后处理 |
|-----|--------|
| `paddle.unique` | 移除 paddle 独有的 inverse_index 输出 |
| `paddle.mode`, `paddle.topk`, `paddle.kthvalue` | 只比较 values，忽略 indices |
| `paddle.linalg.eigh` | 特征向量不唯一（可差符号），比较特征向量系数比 |
| `paddle.strided_slice` | 处理负 stride，调用 .contiguous() |
| `paddle.nn.functional.cross_entropy` 等 | 反向只比较部分梯度 |
| `paddle.nn.functional.scaled_dot_product_attention` | 反向只比较前 3 个梯度 |

### 2.15 设备管理

**自动设备探测**（`engineV2.py:detect_device_type()`）：
1. 先尝试 NVIDIA GPU（`pynvml`）
2. 再尝试 XPU（`xpu-smi`）
3. 再尝试 Iluvatar GPU（`ixsmi`）
4. 最后 fallback 到 CPU

**GPU 内存感知：**
- 每个 worker 开始测试前检查 GPU 空闲内存是否 >= `required_memory`（默认 10GB）
- 不够则等待（每 60s 检查一次）
- 支持每 GPU 多 worker（基于内存计算 `max_workers_per_gpu`）

### 2.16 CINN 测试的特殊实现

`paddle_cinn_vs_dygraph.py` 的独特之处：

1. 先执行**动态图**前向和反向
2. 再执行**静态图（CINN）**：通过 `@paddle.jit.to_static(full_graph=True, build_strategy=build_strategy)` 装饰器，其中 `build_strategy.build_cinn_pass = True`
3. CINN 模式下 `gen_paddle_output_and_output_grad()` 和 `get_paddle_input_list()` 无法被 trace，需要在 `@to_static` 函数内手动实现
4. 比较使用 `paddle_assert_accuracy()`（两个 paddle tensor 之间比较），不涉及 torch

---

## 3. Config 管理体系

### 3.1 分类存储

```
tester/api_config/
├── 1_not_support/         # Paddle 不支持的配置
├── 2_paddle_only_random/  # 输出随机的 API（不可比精度）
├── 3_paddle_only/         # 引擎能解析但无法转 Torch 的
├── 4_paddle_only_amp/     # AMP 模式 paddle-only
├── 5_accuracy/            # 精度测试配置（主力）
├── 6_accuracy_amp/        # AMP 精度配置
├── 7_0_size/              # 零尺寸张量配置
├── 8_big_tensor/          # 大张量配置
├── 9_getset_item/         # __getitem__/__setitem__ 配置
└── 10_performance/        # 性能基准配置
```

### 3.2 Config 变异工具

- `to_0_size_config.py`：将 config 中某些维度改为 0，生成零尺寸张量测试
- `to_big_size_config.py`：将 config 中的 shape 放大，生成大张量测试
- `to_prof_size_config.py`：将 config 调整为适合性能测试的尺寸

### 3.3 Config 来源

来自 Paddle CI/CE 流水线的 API 调用 trace，通过 `tools/api_tracer/` 工具捕获。累计超过 300 万条配置。

---

## 4. 工具链

| 工具 | 路径 | 功能 |
|------|------|------|
| api_tracer | `tools/api_tracer/` | 运行时捕获 PyTorch API 调用 |
| error_stat | `tools/error_stat/` | 解析测试日志生成错误统计 |
| find_API_config | `tools/find_API_config.py` | 按 API 名搜索 config |
| get_api_set | `tools/get_api_set.py` | 提取 config 文件中的唯一 API 集 |
| move_config | `tools/move_config.py` | 在分类文件间批量移动 config |
| remove_configs | `tools/remove_configs.py` | 从文件中删除特定 config |
| test_file_generator | `tester/test_file_generator.py` | 为失败用例生成可复现的独立脚本 |

---

## 5. 三代引擎对比

| 特性 | Engine V1 | Engine V2 | Engine V3 |
|------|-----------|-----------|-----------|
| 文件 | `engine.py` (237行) | `engineV2.py` (1049行) | `engineV3.py` (385行) |
| 并行 | 单进程 | Pebble ProcessPool | multiprocessing Queue |
| GPU 管理 | 手动 | 自动分配（内存感知） | 手动指定 |
| 超时 | 无 | ProcessPool timeout | Master 轮询检测 |
| 崩溃恢复 | 无 | 自动（ProcessExpired） | Worker 自动重启 |
| 批处理 | 无 | 20K/batch | 无 |
| 配置模式 | 单文件 | glob 模式多文件 | 单文件 |
| 主要使用场景 | 调试 | **生产主力** | 百度内部 |

---

## 6. 数据流全景图

```
Paddle CI/CE 流水线
        │
        ▼
  API Trace 采集（api_tracer）
        │
        ▼
  Config 文本文件（归类到 1-10 目录）
        │
        ▼
  Config 变异（0-size / big-tensor / prof-size）
        │
        ▼
  Engine (V1/V2/V3) 读取 config 文件
        │
        ▼
  APIConfig 解析 → TensorConfig 对象
        │
        ▼
  Tester 实例化（根据测试模式选择类）
        │
        ├─ gen_numpy_input() → 生成 numpy 随机数据
        ├─ gen_torch_input()  → numpy → torch tensor
        ├─ converter.convert() → 获取 torch 执行代码
        ├─ exec(torch_code)   → torch 前向输出
        ├─ torch.autograd.grad() → torch 反向梯度
        ├─ gen_paddle_input() → numpy → paddle tensor
        ├─ paddle_api(...)    → paddle 前向输出
        ├─ paddle.grad()      → paddle 反向梯度
        └─ torch_assert_accuracy() → DLPack 比较
                │
                ▼
        日志文件（12 种类型）
                │
                ▼
        报告（error_api.txt / error_config.txt / CSV）
```

---

## 7. 关键设计总结与新 repo 设计参考

### 7.1 值得保留的设计

1. **Config 文本格式**：简洁高效，一行一个用例，便于 diff/分类/grep
2. **DLPack 跨框架比较**：零拷贝、高效
3. **多进程 + GPU 内存感知**：生产级可靠性
4. **断点续跑（Checkpoint）**：大规模测试必需
5. **错误分级处理**：CUDA 错误杀 worker，普通错误 log 后继续
6. **特殊 API 容差配置**：YAML 配置灵活可维护
7. **转换规则缓存**：每个 API 只编译一次

### 7.2 需要改进的设计

1. **`get_numpy_tensor()` 方法过于庞大**：2500 行，应拆分为可插拔的 API 数据生成器
2. **大量 `eval()` / `exec()` 使用**：config 解析和 torch 代码执行都依赖 eval/exec，安全性和可调试性差
3. **测试类只用 `test()` 方法**：没有使用 pytest 或 unittest，缺少灵活的 fixture、参数化等能力
4. **forward_only_apis 硬编码在 YAML**：应该能自动推断（是否有反向实现）
5. **Config 解析器手写 tokenizer**：脆弱，应考虑更健壮的解析方式
6. **日志系统非结构化**：纯文本日志，应支持 JSON 结构化日志以便分析
7. **缺乏测试本身的单元测试**：框架代码没有自己的测试用例
8. **Engine V2/V3 代码重复较多**：应抽象出公共的并行执行框架
