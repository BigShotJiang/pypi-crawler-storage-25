# DLAPITest Case 表示方案设计分析

## 0. 设计背景与核心问题

PaddleAPITest 当前使用简单的 `Tensor([shape], "dtype")` 格式，信息量不足，导致：
- `get_numpy_tensor()` 方法膨胀到 **2500+ 行**（几百个 API 的特殊数据生成逻辑）
- 数据约束（非零、正定、合法索引等）隐藏在代码中而非配置中
- 统计特征（分布范围、是否含 NaN 等）无法表达

**新设计的目标：** 将数据生成约束从代码中提取到 Case 表示中，使 Tensor 描述自包含，大幅减少特殊处理代码。

---

## 1. 六种方案横向对比

### 评估维度定义

| 维度 | 说明 |
|------|------|
| **简洁性** | 配置文本的长度和可读性 |
| **类型安全** | 解析器能否在 parse 时发现错误（如 bool tensor 不应有 min/max） |
| **无冗余** | 同一信息是否只出现一次 |
| **可扩展性** | 添加新 dtype / 新 stats 的成本 |
| **实现复杂度** | Python 类层次和解析器的复杂度 |
| **语义明确** | 从表示本身能否完整理解含义 |

### 对比矩阵

| 维度 | 方案1 统一+链式 | 方案2 Kind分类+链式 | 方案3 完整dtype+链式 | 方案4 统一+工厂 | 方案5 统一+分隔符 | 方案6 统一+结构化 |
|------|:-:|:-:|:-:|:-:|:-:|:-:|
| 简洁性 | ★★★★ | ★★★ | ★★★ | ★★★★ | ★★★ | ★★ |
| 类型安全 | ★★ | ★★★★ | ★★★★★ | ★★★★ | ★★ | ★ |
| 无冗余 | ★★★★★ | ★★ | ★★★★★ | ★★★★★ | ★★★ | ★★★★ |
| 可扩展性 | ★★★★ | ★★★ | ★★ | ★★★★★ | ★★★ | ★★★★ |
| 实现复杂度 | ★★★ | ★★★ | ★ | ★★★★ | ★★ | ★★★★★ |
| 语义明确 | ★★★ | ★★★★ | ★★★★★ | ★★★★★ | ★★ | ★★★ |
| **综合** | **★★★☆** | **★★★** | **★★★** | **★★★★☆** | **★★☆** | **★★★** |

---

### 方案1：统一表示 + 链式调用

```python
Tensor((1, 2, 3), "float32", Device.cuda(0)).stats(has_nan=False, min=-5.9, max=-1.2).state(need_grad=True)
Tensor((1, 2, 3), "bool", Device.cuda(0)).stats(true_ratio=0.4).state()
```

**优点：**
- 只有一个标识符 `Tensor`，命名空间干净
- 链式调用读起来自然

**缺点：**
- `.stats()` 方法必须根据 dtype 接受不同参数（float 接受 min/max/mean/std，bool 接受 true_ratio，int 接受 low/high），这在静态类型检查和文档生成上都很困难
- 参数合法性只能在运行时校验，无法从表示形式上直观看出 stats 是否匹配 dtype
- 如果给 bool tensor 传了 `min=-5.9`，解析器只能在运行时报错，无法通过定义约束

**核心风险：** `.stats()` 的「隐式多态」——同一个方法名，不同 dtype 下合法参数不同，这对使用者和自动化工具都是认知负担。

---

### 方案2：非统一表示（Kind 分类）+ 链式调用

```python
FloatTensor((1, 2, 3), "float32", Device.cpu()).stats(has_nan=False, min=-5.9, max=-1.2).state(need_grad=True)
BoolTensor((1, 2, 3), "bool", Device.cuda(0)).stats(true_ratio=0.4).state()
IntTensor((10,), "int64", Device.cuda(0)).stats(low=0, high=100).state()
ComplexTensor((2, 3), "complex64", Device.cuda(0)).stats(real_min=-5, real_max=5).state()
```

**优点：**
- 每个 Kind 的 `.stats()` 签名固定且明确
- 不需要方法重载
- 4 个标识符（Float/Int/Bool/Complex）数量可控

**缺点：**
- 冗余：`FloatTensor` + `"float32"` 重复了 "float" 信息
- 如果写 `FloatTensor(..., "int32", ...)`，语义矛盾，需要额外校验
- 标识符与 PyTorch 的 `FloatTensor` 等类名冲突，容易混淆

**核心风险：** 标识符和 dtype 参数的语义重复，既增加了冗余又引入了不一致的可能性。

---

### 方案3：非统一表示（完整 dtype）+ 链式调用

```python
Float32Tensor((1, 2, 3), Device.cpu()).stats(has_nan=False, min=-5.9, max=-1.2).state(need_grad=True)
BFloat16Tensor((2, 4), Device.cuda(0)).stats(has_nan=False, min=0.0, max=1.0).state()
Int64Tensor((10,), Device.cuda(0)).stats(low=0, high=100).state()
BoolTensor((3, 3), Device.cuda(0)).stats(true_ratio=0.4).state()
```

**优点：**
- 语义最完美：标识符即 dtype，没有冗余
- 类型安全最强：`Float32Tensor` 的 `.stats()` 签名完全确定

**缺点：**
- 标识符爆炸：float16, float32, float64, bfloat16, int8, int16, int32, int64, uint8, uint16, uint32, uint64, bool, complex64, complex128 = **15+ 个类**
- 每增加一个 dtype（如 float8_e5m2）就要新增一个类
- 类继承或组合的复杂度极高
- 记忆负担大

**核心风险：** 不可持续的标识符膨胀。

---

### 方案4：统一表示 + 工厂模式 ★ 推荐

```python
Tensor.float32((1, 2, 3), Device.cuda(0)).stats(has_nan=False, min=-5.9, max=-1.2).state(need_grad=True)
Tensor.bool((1, 2, 3), Device.cuda(0)).stats(true_ratio=0.4).state()
Tensor.int64((10,), Device.cuda(0)).stats(low=0, high=100).state()
Tensor.complex64((2, 3), Device.cuda(0)).stats(real_min=-5, real_max=5).state()
```

**优点：**
- **一个标识符 `Tensor`**：命名空间干净，不会与任何框架类名冲突
- **dtype 即方法名**：`Tensor.float32` 语义完整，无冗余，等价于方案 3 的表达力
- **类型安全**：每个工厂方法可以返回特定的内部类型（`_FloatTensorConfig`），其 `.stats()` 签名是确定的
- **可扩展**：添加新 dtype 只需添加一个工厂方法（`@classmethod`），不需要新的顶级类
- **不需要方法重载**：工厂方法返回的类型决定了后续 `.stats()` 的合法参数
- **IDE 友好**：`Tensor.` 后自动补全出所有支持的 dtype

**缺点：**
- 与传统的 `Tensor(shape, dtype)` 构造方式有一定差异，需要适应
- `Tensor.bfloat16` 比 `BFloat16Tensor` 稍长（但不显著）

**核心优势：** 在表示层面具有方案 3 的完整语义，在实现层面只有一个标识符 `Tensor`，彻底避免了方案 2 的冗余和方案 3 的膨胀。

---

### 方案5：统一表示 + 分隔符

```python
Tensor((1, 2, 3), "float32", Device.cuda(0)) | float_stats(has_nan=False, min=-5.9) | state(need_grad=True)
Tensor((1, 2, 3), "bool", Device.cuda(0)) | bool_stats(true_ratio=0.4) | state()
```

**优点：**
- 视觉上各部分分离清晰

**缺点：**
- `|` 运算符给人「左右平等/可交换」的错觉，实际上 stats 依赖于 Tensor 的 dtype
- `float_stats` / `bool_stats` 本质是带 dtype 前缀的函数名，又回到了方案 2 的问题
- Python 中 `|` 通常表示 union type 或 bitwise or，语义不符
- 解析器实现需要特殊处理管道语法

**核心风险：** 语义误导 + 本质上是方案 2 的变形。

---

### 方案6：统一表示 + 结构化参数

```python
Tensor(meta=((1, 2, 3), "float32", Device.cuda(0)), stats={"has_nan": False, "min": -5.9}, state={"need_grad": True})
```

**优点：**
- 定义最简单，只有一个构造函数
- 可以用 JSON/YAML 直接序列化

**缺点：**
- dict 参数完全是动态的，没有任何编译期/解析期约束
- `stats={"true_ratio": 0.4}` 用在 float tensor 上不会有任何提示
- 表示冗长（大量引号和花括号）
- 可读性差（尤其嵌套在 API 调用中时）

**核心风险：** 以灵活性换取了几乎所有的类型安全。

---

## 2. 推荐方案：方案4（统一表示 + 工厂模式）

### 2.1 推荐理由

方案 4 在以下关键维度上实现了最优平衡：

```
                  类型安全
                     ▲
                     │
          方案3 ●    │    ● 方案4
                     │
          方案2 ●    │
                     │
          方案1 ●    │    ● 方案6
                     │
          方案5 ●    │
                     └──────────────────► 简洁 + 可扩展
```

方案 4 独占右上角——同时具备高类型安全和高简洁性。

### 2.2 完整设计规范

#### 2.2.1 Tensor 表示语法

```
Tensor.<dtype>(<shape>, <device>?).stats(<stats_params>)?.state(<state_params>)?
```

其中：
- `<dtype>` 是工厂方法名，如 `float32`, `int64`, `bool`, `complex128`
- `<shape>` 是 tuple，如 `(1, 2, 3)` 或 `()`（标量）
- `<device>` 可选，默认为测试配置中的 device，如 `Device.cuda(0)`, `Device.cpu()`
- `.stats()` 可选，描述数据分布特征，签名取决于 dtype kind
- `.state()` 可选，描述张量状态（梯度、连续性等）

#### 2.2.2 工厂方法列表

```python
# 浮点族 → 返回 FloatTensorSpec
Tensor.float16(shape, device?)
Tensor.float32(shape, device?)
Tensor.float64(shape, device?)
Tensor.bfloat16(shape, device?)

# 整数族 → 返回 IntTensorSpec
Tensor.int8(shape, device?)
Tensor.int16(shape, device?)
Tensor.int32(shape, device?)
Tensor.int64(shape, device?)
Tensor.uint8(shape, device?)

# 布尔 → 返回 BoolTensorSpec
Tensor.bool(shape, device?)

# 复数族 → 返回 ComplexTensorSpec
Tensor.complex64(shape, device?)
Tensor.complex128(shape, device?)
```

#### 2.2.3 stats 方法签名（按 dtype kind 分）

**FloatTensorSpec.stats():**

```python
def stats(
    self,
    min: float = -0.5,         # 最小值
    max: float = 0.5,          # 最大值
    mean: float | None = None, # 均值（可选，用于正态分布生成）
    std: float | None = None,  # 标准差（可选）
    has_nan: bool = False,     # 是否包含 NaN
    has_inf: bool = False,     # 是否包含 Inf
    nonzero: bool = False,     # 是否要求全部非零
    positive: bool = False,    # 是否要求全部正数
    # 特殊矩阵约束
    symmetric: bool = False,   # 对称矩阵
    positive_definite: bool = False,  # 正定矩阵
    orthogonal: bool = False,  # 正交矩阵
    normalized: bool = False,  # 归一化（如概率分布）
    unique: bool = False,      # 元素唯一
) -> FloatTensorSpec
```

**IntTensorSpec.stats():**

```python
def stats(
    self,
    low: int = -65535,         # 最小值（含）
    high: int = 65535,         # 最大值（不含）
    nonzero: bool = False,     # 非零
    unique: bool = False,      # 元素唯一
    sorted: bool = False,      # 已排序
    # 索引约束
    valid_index_for_dim: int | None = None,  # 作为索引时的合法维度大小
) -> IntTensorSpec
```

**BoolTensorSpec.stats():**

```python
def stats(
    self,
    true_ratio: float = 0.5,  # True 的比例
    all_true: bool = False,    # 全 True
    all_false: bool = False,   # 全 False
    true_count: int | None = None,  # 精确的 True 数量（用于 index_put 等）
) -> BoolTensorSpec
```

**ComplexTensorSpec.stats():**

```python
def stats(
    self,
    real_min: float = -0.5,
    real_max: float = 0.5,
    imag_min: float = -0.5,
    imag_max: float = 0.5,
    hermitian: bool = False,   # Hermitian 矩阵
) -> ComplexTensorSpec
```

#### 2.2.4 state 方法签名（所有类型共用）

```python
def state(
    self,
    need_grad: bool | None = None,  # None 表示自动推断（浮点可微 API 默认 True）
    is_leaf: bool = True,           # 是否叶节点
    is_contiguous: bool = True,     # 是否连续存储
    stop_gradient: bool | None = None,  # 显式控制（paddle 语义）
) -> TensorSpec
```

#### 2.2.5 完整示例

```python
# --- 基础用法 ---

# 简单浮点张量（使用所有默认值）
abs(x=Tensor.float64((1, 100)))

# 带统计约束的浮点张量
cumsum(x=Tensor.float32((3, 4, 5)).stats(min=-10.0, max=10.0), axis=1)

# 除法：第二个参数必须非零
divide(
    x=Tensor.float32((2, 3)),
    y=Tensor.float32((2, 3)).stats(nonzero=True)
)

# Cholesky 分解：需要正定矩阵
linalg.cholesky(
    x=Tensor.float64((4, 4)).stats(positive_definite=True)
)

# Bernoulli：需要 [0,1] 范围的概率值
bernoulli(
    x=Tensor.float32((3, 3)).stats(min=0.0, max=1.0)
)

# --- 整数索引 ---

# scatter：索引必须在合法范围内
scatter(
    x=Tensor.float32((5, 3)),
    index=Tensor.int64((5, 3)).stats(low=0, high=3, valid_index_for_dim=3),
    updates=Tensor.float32((5, 3))
)

# --- 布尔掩码 ---

# index_put：精确控制 True 的数量
index_put(
    x=Tensor.float32((5, 4)),
    indices=tuple(Tensor.bool((5,)).stats(true_count=3)),
    value=Tensor.float32((3, 4))
)

# --- 复数 ---
fft.fft(x=Tensor.complex64((128,)).stats(real_min=-1.0, real_max=1.0))

# --- 状态控制 ---

# 明确不需要梯度的输入
conv2d(
    x=Tensor.float32((1, 3, 224, 224)).state(need_grad=True),
    weight=Tensor.float32((64, 3, 7, 7)).state(need_grad=True),
    bias=Tensor.float32((64,)).state(need_grad=True),
    stride=2, padding=3
)

# --- cross_entropy: label 是合法类别索引 ---
cross_entropy(
    input=Tensor.float32((4, 10)).stats(normalized=True),
    label=Tensor.int64((4,)).stats(low=0, high=10)
)

# --- 最简配置（所有约束使用默认值） ---
relu(x=Tensor.float32((2, 3)))
```

#### 2.2.6 API 调用格式

与 PaddleAPITest 当前使用 `paddle.abs(...)` 不同，新格式使用**框架无关的规范 API 名称**：

```
<namespace>.<api_name>(<args>)
```

命名空间举例：

| 规范名称 | Paddle | PyTorch | JAX |
|---------|--------|---------|-----|
| `abs` | `paddle.abs` | `torch.abs` | `jax.numpy.abs` |
| `nn.conv2d` | `paddle.nn.functional.conv2d` | `torch.nn.functional.conv2d` | — |
| `linalg.cholesky` | `paddle.linalg.cholesky` | `torch.linalg.cholesky` | `jax.numpy.linalg.cholesky` |

框架到规范名称的映射存储在独立的 **mapping 文件** 中，Case 本身不绑定任何框架。

#### 2.2.7 Config 文件格式（单行文本，向后兼容思路）

```
abs(x=Tensor.float64((1, 100)))
concat(tuple(Tensor.float32((31376, 768)), Tensor.float32((1, 768))), axis=0)
nn.conv2d(x=Tensor.float32((1, 3, 224, 224)), weight=Tensor.float32((64, 3, 7, 7)), bias=Tensor.float32((64,)), stride=2, padding=3)
linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))
divide(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)).stats(nonzero=True))
```

对比 PaddleAPITest 旧格式：

```
# 旧：信息不足，需要代码中 2500 行 hardcode 处理
paddle.abs(Tensor([1, 100],"float64"), )
paddle.linalg.cholesky(Tensor([4, 4],"float64"), )
paddle.divide(Tensor([2, 3],"float32"), Tensor([2, 3],"float32"), )

# 新：约束自包含，数据生成器只需读 stats 参数
abs(x=Tensor.float64((1, 100)))
linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))
divide(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)).stats(nonzero=True))
```

---

## 3. Python 实现草案

### 3.1 类层次结构

```
TensorSpec (基类，不直接实例化)
├── FloatTensorSpec    (float16/32/64/bfloat16)
│   └── .stats(min, max, mean, std, has_nan, nonzero, positive_definite, ...)
├── IntTensorSpec      (int8/16/32/64/uint8)
│   └── .stats(low, high, nonzero, unique, valid_index_for_dim, ...)
├── BoolTensorSpec     (bool)
│   └── .stats(true_ratio, all_true, all_false, true_count, ...)
└── ComplexTensorSpec  (complex64/128)
    └── .stats(real_min, real_max, imag_min, imag_max, hermitian, ...)

Tensor (命名空间类，只含 classmethod 工厂方法)
├── .float32(shape, device?) -> FloatTensorSpec
├── .int64(shape, device?)   -> IntTensorSpec
├── .bool(shape, device?)    -> BoolTensorSpec
└── ...
```

### 3.2 关键：stats 如何消除特殊处理代码

**PaddleAPITest 的痛点：** `get_numpy_tensor()` 中有大量 `if api_name == "paddle.xxx"` 分支，因为 config 中没有数据约束信息。

**新设计的解决方式：** 数据生成器只需根据 `TensorSpec` 的 stats 参数生成数据，不需要知道 API 名称：

```python
# 旧：API 感知的数据生成（2500 行）
def get_numpy_tensor(self, api_config, index, key):
    if api_config.api_name in not_zero_apis:
        ...  # 非零处理
    elif api_config.api_name == "paddle.linalg.cholesky":
        ...  # 正定矩阵
    elif api_config.api_name == "paddle.bernoulli":
        ...  # [0,1] 范围
    # ... 几百个 elif ...

# 新：API 无关的数据生成（约 100 行）
def generate_numpy(spec: TensorSpec) -> np.ndarray:
    if isinstance(spec, FloatTensorSpec):
        data = np.random.uniform(spec.stats.min, spec.stats.max, spec.shape)
        if spec.stats.positive_definite:
            data = data @ data.T + np.eye(spec.shape[0])
        if spec.stats.nonzero:
            data[data == 0] = spec.stats.min  # 或其他策略
        if spec.stats.has_nan:
            ...
    elif isinstance(spec, IntTensorSpec):
        data = np.random.randint(spec.stats.low, spec.stats.high, spec.shape)
        ...
    elif isinstance(spec, BoolTensorSpec):
        data = np.random.random(spec.shape) < spec.stats.true_ratio
        ...
```

约束从 **API 名称 → 代码分支** 变成了 **Config 声明 → 通用生成器**，代码量可以从 2500 行降到约 100-200 行。

---

## 4. Device 表示设计

```python
class Device:
    @staticmethod
    def cuda(index: int = 0) -> DeviceSpec:
        return DeviceSpec("cuda", index)

    @staticmethod
    def cpu() -> DeviceSpec:
        return DeviceSpec("cpu", 0)

    @staticmethod
    def xpu(index: int = 0) -> DeviceSpec:
        return DeviceSpec("xpu", index)

    # 可扩展到任意自定义设备
    @staticmethod
    def custom(name: str, index: int = 0) -> DeviceSpec:
        return DeviceSpec(name, index)
```

使用示例：

```python
Tensor.float32((2, 3), Device.cuda(0))    # GPU
Tensor.float32((2, 3), Device.cpu())       # CPU
Tensor.float32((2, 3), Device.xpu(1))     # 昆仑芯 XPU
Tensor.float32((2, 3))                     # 默认 device（由运行配置决定）
```

---

## 5. 方案风险与缓解

| 风险 | 缓解措施 |
|------|---------|
| 工厂模式不常见，使用者需适应 | 提供详细文档 + config 生成工具 + 旧格式自动转换脚本 |
| stats 参数组合可能冲突（如 `positive=True, min=-5`） | 在 `__post_init__` 中校验参数一致性 |
| 部分 API 的数据约束很复杂（如 index_put） | 允许自定义 stats 扩展，保留 `custom_generator` 逃生舱 |
| 旧 config 迁移成本 | 开发自动转换工具（从旧格式 + hardcode 规则 → 新格式） |

---

## 6. 总结

**推荐方案 4（统一表示 + 工厂模式）**，核心理由：

1. **一个标识符** `Tensor` 避免命名膨胀，同时通过 `.dtype` 工厂方法保留完整的 dtype 语义
2. **类型安全**：工厂方法返回特定类型，`.stats()` 签名在定义层面即确定
3. **约束自包含**：`stats()` 将数据生成约束从代码提升到 config，消除 2500 行特殊处理
4. **框架无关**：Tensor 表示不绑定任何框架，API 名称通过 mapping 映射
5. **可扩展**：新 dtype 加一个 classmethod，新 stats 参数加一个字段
