# tensor-spec CLI Design Specification

**Status:** Finalized design specification
**Date:** 2025-07-25
**Scope:** CLI surface, user-visible semantics, configuration schema, and output contracts.

---

## 1. Command Tree

```
tensor-spec
├── check     # Correctness/reachability check
├── bench     # Performance benchmarking
├── doctor    # Environment diagnosis
├── setup     # Initialize configuration
├── migrate   # Legacy format migration
├── pack      # .tspec → .tspecb conversion
├── unpack    # .tspecb → .tspec conversion
└── --version # Global version flag
```

- `run` is removed entirely — no alias, no tombstone, no deprecation shim.
- `validate` is removed entirely — same hard cut as `run`.

---

## 2. Case File Formats

| Extension | Description |
|-----------|-------------|
| `.tspec`  | Text format — one case per line, no header |
| `.tspecb` | Binary compressed format (custom compression scheme; format design is a separate effort) |

- The CLI handles both formats transparently wherever case files are accepted.
- `pack` converts `.tspec` → `.tspecb` (top-level subcommand).
- `unpack` converts `.tspecb` → `.tspec` (top-level subcommand).

---

## 3. `check` Command

**Shape:** `tensor-spec check [OPTIONS] CASE... --target TARGET [--target TARGET ...]`

### 3.1 CASE Input Model

Positional `CASE` arguments are auto-detected:

| Input | Detection rule |
|-------|---------------|
| Existing file path | Path exists and is a regular file → file input |
| Existing directory | Path exists and is a directory → recursive expansion |
| `-` | Reserved token → stdin (multiline case input) |
| Anything else | Inline case |

**Directory expansion rules:**
- Recursive traversal of the directory tree.
- Recognizes only `.tspec` and `.tspecb` files.
- Hidden files and hidden directories are ignored.
- Overlapping paths from multiple CASE arguments are auto-deduplicated.

**Path filtering (applies to expanded paths only, not inline cases):**
- `--match GLOB` — repeatable; include only paths matching at least one glob.
- `--exclude GLOB` — repeatable; exclude paths matching any glob.

### 3.2 Target Model (`--target`)

Repeatable structured parameter with dual-mode parsing:

- **Without `=`:** reference to a config-defined named target.
  Example: `--target torch-cu124`
- **With `=`:** inline anonymous target definition.
  Example: `--target backend=torch,device=cuda,python=/venv/t24/bin/python`

No `--backend` shorthand is provided.

**Inline target schema:**

| Field | Required | Notes |
|-------|----------|-------|
| `backend` | Yes | |
| `python` | Yes | Path to Python interpreter |
| `device` | No | Defaults to backend's built-in default |

- `name` is **forbidden** in inline targets — CLI error if present.
- Backend and device are separate fields; packed forms like `backend=torch@cuda` are invalid.
- Syntax: comma-separated `key=value` pairs. Values cannot contain commas. No quoting or escaping.
- Duplicate keys within a single `--target`: **error**.
- Duplicate `--target` entries (same backend + device + python): preserved as independent targets.
- Named targets from config: **immutable** — no CLI partial overrides.

### 3.3 Execution Semantics

| Target count | Behavior |
|-------------|----------|
| 1 | Execution check — can this case run on this target? |
| 2+ | Comparison — do targets agree within tolerance? |

**Reference target selection (multi-target mode):**
- Selected by built-in backend priority: `torch > paddle` (extensible).
- Same-backend tie: the positionally first `--target` wins.
- Reference target is always printed in human output.

**Execution control:**
- Default: run all cases (no fail-fast). `--fail-fast` stops on first failure.
- Parallel execution by default:
  - `--jobs auto` (default) — resource-aware, considers CPU cores and GPU memory constraints, takes the tighter bound.
  - `--jobs N` — explicit upper limit.
  - `--jobs 1` — serial execution.

### 3.4 `check` Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--target TARGET` | repeatable | (required, or from config `defaults.targets`) | Execution target |
| `--match GLOB` | repeatable | — | Include paths matching glob |
| `--exclude GLOB` | repeatable | — | Exclude paths matching glob |
| `--format human\|json\|jsonl` | enum | `human` | Output format |
| `--no-interactive` | boolean | false | Force plain output, disable TUI |
| `--verbose` | boolean | false | Verbose output |
| `--atol FLOAT` | float | from config/built-in | Global absolute tolerance override |
| `--rtol FLOAT` | float | from config/built-in | Global relative tolerance override |
| `--fail-fast` | boolean | false | Stop on first failure |
| `--jobs N` | integer | auto | Parallelism limit |
| `--dry-run` | boolean | false | Preflight validation only |

### 3.5 `--dry-run` Semantics

Dry-run performs preflight validation without executing any backend APIs:

1. Parse targets and cases.
2. Merge config and resolve named targets.
3. Validate python paths, backend loadability, device availability, and case parsing.
4. Collect **all** discoverable issues (no fail-fast behavior in dry-run).

**Output order:** target resolution → case parse/reachability → summary.

Distinct from `doctor`: `--dry-run` validates one specific invocation; `doctor` diagnoses the broader environment.

---

## 4. `bench` Command

**Shape:** `tensor-spec bench --mode MODE [OPTIONS] CASE... --target TARGET [--target TARGET ...]`

### 4.1 Shared Surface

`bench` fully reuses `check`'s:
- CASE input model (positional, auto-detection, directory expansion, `.tspec`/`.tspecb` only).
- `--match` / `--exclude` path filtering.
- `--target` model (structured, dual-mode, same syntax and schema).
- `--format`, `--no-interactive`, `--verbose`, `--jobs`.

### 4.2 Bench Modes

`bench` is a mode family with a shared CLI surface plus pluggable mode implementations. Current built-in modes:

- `e2e`: repeated end-to-end latency measurement through the normal execution path.
- `ncu`: kernel-level Nsight Compute profiling for CUDA targets.

Future modes should plug in beside these, with shared target/case/baseline semantics and their own `[bench.<mode>]` config block.

### 4.3 Bench-Specific Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--mode MODE` | enum | (required) | Benchmark mode (`e2e`, `ncu`, ...) |
| `--baseline NAME` | string | — | Named target to use as measurement baseline |
| `--threshold RULES` | string | — | Comma-separated pass/fail rules (e.g., `latency<=10%,throughput>=5%`) |
| `--warmup N` | integer | from config | e2e mode: warmup iterations (overrides config) |
| `--repeat N` | integer | from config | e2e mode: measurement iterations (overrides config) |

**`--mode ncu` constraints:**
- CUDA-only — rejects non-CUDA device configurations at validation time.
- Allows mixed CUDA devices (e.g., `cuda:0` + `cuda:1`).

### 4.4 Baseline Model

- Baseline is set **only** via explicit `--baseline`; never auto-picked.
- `--baseline` must reference a **named** target (not an anonymous inline target).
- The named target must also be one of the requested `--target` entries.
- Without `--baseline`: measure-only mode — no uplift calculations.

### 4.5 Measurement and Results

**e2e statistics:** mean, median, std, min, max, plus optional percentiles (configurable).

**ncu metrics:** core metrics (time, occupancy, memory throughput). Raw NCU artifacts saved by default.

Mode-specific summaries are rendered independently (`E2E Results`, `NCU Results`) but share the same target resolution, baseline, and threshold concepts.

**Uplift reporting (when `--baseline` is set):**
- Per-metric, expressed as percentage and direction word.
- Latency: "1.23x faster" / "18% slower".
- Throughput: "2x higher" / "15% lower".

**Pass/fail behavior:**
- Default: measure-only; no automatic failure.
- Failures only occur with explicit `--threshold` rules.
- `--threshold` syntax: comma-separated rules, each as `indicator operator percentage` (e.g., `latency<=10%,throughput>=5%`).

**Failed/skipped cases:** excluded from uplift aggregation, listed separately in summary.

---

## 5. `doctor` Command

Environment-level diagnosis, distinct from `check --dry-run`.

**Default checks (fixed, full — no `--only` subsetting):**
- Config file validation.
- Named target resolution.
- Python path existence and executability.
- Backend loadability.
- Device support and availability.

**Behavior:**
- Read-only by default.
- `--fix`: environment-only repairs (clear caches, rebuild symlinks). Never touches config content.
- After `--fix`: automatically re-runs all checks, presenting before/after status comparison.

---

## 6. `setup` Command

Initialize project configuration. Kept as-is.

---

## 7. `migrate` Command

Legacy format conversion. Kept as-is.

---

## 8. Output Model

### 8.1 Human Output

**Interactive mode (TTY detected):**
- Live TUI / Rich table display.
- `--no-interactive` forces plain text output.

**Non-interactive mode:**
- Per-case line output followed by a final summary.

**Detail levels:**
- Success cases: case number + status only (minimal).
- Failure cases: expanded with location info (case number, source file, API/case identifier), then per-backend detail including diffs and errors.
- Summary: total stats, per-status group counts, list of failed case numbers.
- In multi-target mode: reference target is always printed.

### 8.2 Machine-Readable Output

**Unified envelope** (shared by both `json` and `jsonl`):
```json
{
  "schema_version": "...",
  "command": "...",
  "run_id": "...",
  "event": "...",
  "timestamp": "...",
  "payload": { }
}
```

**`--format json`:** Single JSON object emitted after the run completes.

Payload structure: `targets[]` + `cases[]` + `summary`.

**`--format jsonl`:** Event stream — one JSON object per line.

Minimum stable event set:

| Event | Description |
|-------|-------------|
| `started` | Run begins |
| `target_resolved` | Per-target resolution result |
| `case_result` | One case × one target result |
| `target_result` | One target aggregated result (total pass/fail/skip) |
| `summary` | Entire run aggregated |
| `error` | Error event |

- Stream always terminates with `summary` or `error`.
- JSON and JSONL payload fields are aligned where possible; JSON is a snapshot, JSONL is a stream.

### 8.3 Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 2 | Input / parse / config failure |
| 3 | Environment / backend reachability failure |
| 4 | Execution failure |
| 5 | Comparison mismatch |
| 6 | Internal tool error |

---

## 9. Configuration Schema (`tensor-spec.toml`)

```toml
# ── Defaults ──────────────────────────────────────────────
[defaults]
targets = ["torch-cu124", "paddle-cu124"]   # fallback when CLI provides no --target
format = "human"                            # applies to check and bench only
seed = 42                                   # inherited by check and bench
verbose = false                             # inherited by check and bench

# ── Named Targets (immutable from CLI) ────────────────────
[targets.torch-cu124]
backend = "torch"
device = "cuda"
python = "/venv/torch24/bin/python"

[targets.paddle-cu124]
backend = "paddle"
device = "cuda"
python = "/venv/paddle/bin/python"

# Named target fields: backend (required), device (optional), python (required).
# No extra metadata (no description, tags, etc.).
# Duplicate target names are an error.

# ── Tolerance ─────────────────────────────────────────────
[tolerance]
atol = 1e-6
rtol = 1e-5

[tolerance.overrides."nn.conv2d"]
atol = 1e-4
rtol = 1e-3

[tolerance.overrides."linalg.cholesky"]
atol = 1e-3
rtol = 1e-2

# ── Benchmark Config ──────────────────────────────────────
[bench]
mode = "e2e"
artifacts_dir = "./.tensor-spec/bench-artifacts"

[bench.e2e]
warmup = 5
repeat = 20
percentiles = [50, 90, 95, 99]

[bench.ncu]
metrics = ["time", "occupancy", "memory_throughput"]
save_artifacts = true
```

---

## 10. Precedence

Category-based precedence model. No environment variables participate (simple-first design).

| Setting category | Precedence order |
|-----------------|-----------------|
| Execution semantics (backend, python, seed, tolerance) | CLI > project config > built-in defaults |
| Observability (`--verbose`) | CLI flag > config `defaults.verbose` > built-in (false) |
| Output format | CLI `--format` > config `defaults.format` > built-in (`human`) |
| Default targets | `defaults.targets` consulted **only** when no CLI `--target` provided |
| Named target resolution | Immutable from config; no CLI partial overrides |
| Inline target resolution | Entirely from CLI |

**`seed`:** Controlled only via config `defaults.seed`. No `--seed` CLI flag.

---

## 11. Backend and Device Model

- Device values are defined per backend's own supported list.
- Each backend reports two layers:
  1. **Theoretical support list** — ordered set of devices the backend can support.
  2. **Current environment availability** — which of those devices are actually present.
- **Default device:** first theoretically-supported device that is currently available.
- Strict error distinction:
  - "Unsupported device" — not in the backend's theoretical support list.
  - "Unavailable device" — supported but not present in the current environment.
- **Device resolution order:** CLI explicit > project config > backend built-in default.
- **Backend priority** (for reference target selection): `torch > paddle` (extensible).

---

## 12. Parallelism

Applies to both `check` and `bench`.

| `--jobs` value | Behavior |
|---------------|----------|
| *(omitted)* / `auto` | Resource-aware: considers CPU cores and GPU memory constraints, takes the tighter bound |
| `N` | Explicit upper limit |
| `1` | Serial execution |

---

## 13. Notes for Implementation

1. **Remove all references to `run` and `validate`** across repo docs, help text, and code in a single pass.
2. **`--target` parser** must distinguish `=`-containing values (inline) from plain names (config reference) at parse time, not via config lookup fallback.
3. **Inline target parser** should use a simple split-on-comma, split-on-first-`=` approach — no quoting or escaping support is needed.
4. **Directory expansion** should be implemented as a lazy recursive walker filtered to `.tspec`/`.tspecb` extensions, with deduplication by resolved absolute path.
5. **Exit codes** must be consistently applied across `check` and `bench`; wrapper/orchestration code should map internal exceptions to the correct exit code.
6. **JSONL event stream** should flush after each line to support real-time piping to downstream consumers.
7. **`doctor --fix`** repairs must be individually documented in help text so users know exactly what `--fix` will do before running it.
8. **`bench --mode ncu`** should validate that all requested targets use CUDA devices before any measurement begins.
9. **Tolerance overrides** key matching should use exact string match against the case's API identifier; glob/regex matching is out of scope for v1.
10. **`pack`/`unpack`** should accept standard positional file arguments and support stdio via `-` for pipeline integration.
