# tensor-spec 选型决策

## 1. dataclass vs pydantic

### 结论：**dataclass**

| | dataclass | pydantic v2 |
|--|-----------|-------------|
| 依赖 | **零（stdlib）** | 额外依赖 |
| 性能 | **极快（无运行时开销）** | 快（v2 用 Rust core） |
| 验证 | `__post_init__` 手写 | 声明式 validator |
| 序列化 | 需自行实现 | 内建 JSON/dict |
| 类型检查 | ty 兼容 | ty 兼容 |

**选 dataclass 的理由：如无必要，勿增实体。**

- tensor-spec 的序列化目标是自定义二进制协议（`.tspecb`），不是 JSON schema → pydantic 的核心优势（自动 JSON 序列化）用不上
- 验证逻辑有限且明确（float stats 不该出现在 bool tensor 上）→ `__post_init__` 足够
- spec 层要求**零框架依赖**，dataclass 是 stdlib，完美符合
- 后续如确有需要，dataclass → pydantic 迁移成本很低（字段定义兼容）

```python
@dataclass(frozen=True, slots=True)
class FloatStats:
    min: float = -0.5
    max: float = 0.5
    nonzero: bool = False
    positive_definite: bool = False

    def __post_init__(self):
        if self.min >= self.max:
            raise ValueError(f"min({self.min}) must < max({self.max})")
```

> TODO: 如果后续需要复杂验证场景（如嵌套 stats 校验），评估是否引入 pydantic

---

## 2. 日志 / 序列化协议选型

### 三个场景，三种选择

| 场景 | 选型 | 理由 |
|------|------|------|
| **运行日志** | JSON Lines (structlog) | 人可读 + jq/pandas 直接分析 + append-only 流式写入 |
| **Case 存储** | 自定义二进制格式（`.tspecb`） | 领域特定压缩 + 高压缩比 + 快速解码 |
| **配置文件** | TOML | Python 生态标准(pyproject.toml) + 人可读可编辑 |

### 2.1 运行日志：JSON Lines

对比淘汰方案：

| 方案 | 淘汰理由 |
|------|---------|
| TOML | 配置格式，不支持 append-only 流式写入 |
| MessagePack | 二进制，运行时无法 tail -f 看日志 |
| CSV | 嵌套数据表达力差（error message 含逗号/换行） |
| 纯文本(当前) | 无结构，需自定义解析器 |
| SQLite | 多进程写入需要锁，不适合高并发日志 |

**JSON Lines 是唯一兼顾人可读 + 结构化 + 流式的选择。**

### 2.2 Case 存储：自定义二进制格式（`.tspecb`）

对比方案：

| 方案 | 大小(950万case估算) | 解析速度 | 实现成本 | 跨语言 |
|------|-------------------|---------|---------|--------|
| 纯文本 + gzip | ~33 MB | 慢(eval) | 低 | 差 |
| MessagePack + zstd | ~10-20 MB | 快 | 低 | 极好 |
| **自定义二进制（.tspecb）** | **~8-15 MB** | **极快** | **中** | **按需** |
| Protobuf | ~10-15 MB | 快 | 中(需.proto) | 好 |
| Parquet | ~15-25 MB | 中 | 中 | 好 |

**选自定义二进制格式的理由：**

1. **领域特定压缩** — case DSL 词汇表高度重复（`Tensor.float32`、函数名、shape 元组），领域特定编码器可对高频词汇建字典、做变长编码，比通用序列化方案压缩比更高
2. **紧凑** — 针对 DSL 结构优化的编码比通用方案（MessagePack）更紧凑
3. **快速解码** — 编解码器针对已知数据结构优化，跳过通用格式的类型判断开销
4. **流式解析** — 自定义格式可原生支持流式读取，不需要一次性加载到内存
5. **格式可控** — 格式演进完全由项目控制，不受第三方库版本约束

**Case 文件格式 `.tspecb`：**

```
文件 = compress([
    header,      # {"version": 1, "api_count": N, "case_count": M}
    api_table,   # ["abs", "nn.conv2d", "linalg.cholesky", ...]
    key_table,   # ["x", "weight", "bias", "stride", ...]
    groups,      # [[api_id, [case, case, ...]], ...]
])

case = [
    [arg, arg, ...],           # positional args (array)
    [[key_id, val], ...],      # keyword args (array of pairs)
]

arg/val =
    ["T", dtype_id, [shape...], stats_or_null, state_or_null]  # TensorSpec
  | ["i", 42]                                                   # int
  | ["f", 3.14]                                                 # float
  | ["b", true]                                                 # bool
  | ["s", "same"]                                               # string
  | ["l", [item, ...]]                                          # list
  | ["t", [item, ...]]                                          # tuple
  | ["n"]                                                        # None
```

**空间估算：**

```
当前文本: paddle.Tensor.__add__(Tensor([1, 1, 276, 49],"float32"), Tensor([1, 1, 276, 49],"float32"), )
= 93 bytes

自定义二进制 array mode: [0, [["T",1,[1,1,276,49],null,null], ["T",1,[1,1,276,49],null,null]], []]
≈ 35 bytes

自定义二进制 + 领域压缩 (同API分组后高度重复): 估算 ~10-15 bytes/case

950万 case * 12 bytes ≈ 110 MB (raw) → 领域压缩 → ~8-15 MB
```

### 2.3 配置文件：TOML

```toml
# tensor-spec.toml

[engine]
workers_per_gpu = 2
timeout = 1800
batch_size = 20000

[tolerance]
default_atol = 1e-2
default_rtol = 1e-2

[tolerance.overrides]
"nn.layer_norm" = { atol = 0.2, rtol = 0.02 }
"matmul" = { atol = 2.0, rtol = 0.05 }
"cumsum" = { atol = 2.0, rtol = 0.01 }

[skip]
sparse = true
float8 = true

[error_dismiss]
"nn.conv2d" = ["PreconditionNotMet", "element size of"]
```

---

## 3. 进程隔离：多 venv + 双路径数据传输

### 结论：**多进程多 venv**，CPU 测试走 SharedMemory，GPU 测试走 CUDA IPC + GPU 比较

同 env 方案存在根本问题：paddle 和 torch 有依赖冲突（CUDA 版本、cudnn 版本、底层 C++ 库），强行装在同一 env 中不稳定。因此采用**多 venv 隔离**，每个框架独立 venv，用 uv 管理。

数据传输和比较按**设备类型**分两条路径：

- **GPU 测试 → 路径 B**（CUDA IPC + GPU 比较）：结果不离开 GPU，全程零拷贝
- **纯 CPU 测试 → 路径 A**（SharedMemory + numpy 比较）：无 GPU 可用时的降级路径

### 为什么 GPU 测试不能走 CPU 比较

GPU tensor 拉回 CPU 做 `np.allclose()` 的开销随张量增大而爆炸：

| 张量大小 | GPU→CPU (PCIe) | memcpy (×4) | np.allclose | 全流程 |
|---------|---------------|-------------|-------------|--------|
| 18 MB | 1.5 ms | 28 ms | 40 ms | ~70 ms |
| 1 GB | 83 ms | 2.7 s | 3.6 s | ~6 s |
| 16 GB | 1.3 s | 40 s | 57 s | **~97 s** |

而 `torch.testing.assert_close()` 在同一 GPU 上执行 `torch.isclose()` + `torch.all()`，16GB 只需**几十毫秒**。GPU tensor 本来就在显存里，拉回 CPU 再比较是多余的。

### 路径 B：CUDA IPC + GPU 比较（GPU 测试，主路径）

核心思路：**结果不离开 GPU**。两个 Worker 各自执行 API 后，结果留在 GPU。选出一个 **Comparator Worker**（支持 GPU 比较的框架），由它打开另一个 Worker 的 CUDA IPC handle，在 GPU 上完成比较。全程无大数据 CPU 拷贝。

#### Comparator 选择机制

不是所有框架都支持 GPU 级精度比较。各 Backend 声明自己的能力：

```python
class BackendBase(ABC):
    @property
    def supports_gpu_compare(self) -> bool:
        """是否支持 GPU 上的精度比较"""
        return False

    def gpu_assert_close(self, actual, expected, atol, rtol) -> CompareResult:
        """在 GPU 上比较两个本框架 tensor，返回结构化结果"""
        raise NotImplementedError
```

**GPU 比较能力注册表（优先级从高到低）：**

```toml
# tensor-spec.toml
[compare]
# 支持 GPU 比较的框架优先级列表
# 比较两个 backend 时，从中选第一个参与本次测试的框架作为 comparator
gpu_comparators = ["torch", "jax", "paddle"]
```

| 框架 | GPU 比较能力 | 实现 | 备注 |
|------|------------|------|------|
| **torch** | `torch.testing.assert_close()` | `torch.isclose()` + `torch.all()` 全程 GPU | 最成熟，默认首选 |
| **jax** | `jax.numpy.allclose()` | JAX array 天然在 GPU 执行 | JAX 无 eager mode 细节需验证 |
| **paddle** | 待支持 | 可基于 `paddle.isclose()` 实现 | 需确认 GPU 执行路径 |
| **numpy** | CPU-only | `np.allclose()` | 终极 fallback |

**选择逻辑：**

```python
def select_comparator(target_a, target_b, priority_list):
    """从优先级列表中选出 comparator"""
    participants = {target_a.backend, target_b.backend}
    for name in priority_list:
        if name in participants:
            backend = get_backend(name)
            if backend.supports_gpu_compare:
                return backend  # comparator = 这个 backend 的 worker
    return None  # fallback 到 numpy CPU 比较
```

**示例：**

| 测试对 | gpu_comparators 列表 | Comparator | 比较方式 |
|-------|---------------------|------------|---------|
| paddle vs torch | `["torch", "jax", "paddle"]` | **torch** (优先级最高) | torch worker 打开 paddle 的 CUDA IPC |
| paddle vs jax | `["torch", "jax", "paddle"]` | **jax** (torch 未参与) | jax worker 打开 paddle 的 CUDA IPC |
| torch vs jax | `["torch", "jax", "paddle"]` | **torch** | torch worker 打开 jax 的 CUDA IPC |
| paddle vs musa | `["torch", "jax", "paddle"]` | **paddle** (仅它在列表中) | paddle worker 打开 musa 的 CUDA IPC |
| musa vs custom | `["torch", "jax", "paddle"]` | **None** | fallback 到 SharedMemory + numpy |

#### 数据流（以 paddle vs torch 为例，torch 为 comparator）

```
┌────────────────────────────────────────────────────────────────────┐
│                       主进程 (调度 + 日志)                           │
│                                                                      │
│  ① shm 写入输入 numpy                                                │
│  ② 收到 paddle worker 的 CUDA IPC handle (64B)                      │
│  ③ 转发 handle → torch worker (comparator)                          │
│  ④ ← 接收 CompareResult → 日志                                      │
└────────┬──────────────────────────────────────┬──────────────────────┘
         │                                      │
   ┌─────▼──────────────────┐        ┌──────────▼─────────────────────┐
   │  Worker A (paddle)      │        │  Worker B (torch) = Comparator │
   │                         │        │                                 │
   │  shm → numpy → GPU     │        │  shm → numpy → GPU             │
   │  exec API               │        │  exec API → torch_result (GPU) │
   │  result 留在 GPU         │        │                                 │
   │  cudaIpcGetMemHandle    │        │  ← 收到 handle (64B)            │
   │  ────handle(64B)────→   │        │  cudaIpcOpenMemHandle           │
   │                         │        │  → __cuda_array_interface__     │
   │                         │        │  → torch.as_tensor() (零拷贝)    │
   │                         │        │                                 │
   │                         │        │  self.gpu_assert_close(         │
   │                         │        │    paddle_as_torch,             │
   │                         │        │    torch_result,                │
   │                         │        │    atol, rtol                   │
   │                         │        │  ) → 全程 GPU                    │
   │                         │        │                                 │
   │  ← 收到比较完成通知       │        │  → CompareResult → main        │
   │  释放 GPU tensor         │        │  cudaIpcCloseMemHandle          │
   └──────────────────────────┘        └─────────────────────────────────┘
```

#### CUDA IPC 技术细节

1. **Handle 获取（非 comparator 侧）：** 通过 ctypes 调用 CUDA Runtime，框架无关。

> **重要：** handle 必须用 `ctypes.Structure` 定义，不能用裸 `(c_byte * 64)()`。
> `cudaIpcOpenMemHandle` 接收 handle **by value**（C ABI struct 传递），ctypes 对裸数组和 Structure 的传递方式不同，
> 裸数组会导致 `cudaErrorInvalidValue`（错误码 1）。已在 PoC 中验证（见 `../pocs/2026-03-05-cuda-ipc-verification.md`）。

```python
# 任何 backend worker: 获取 CUDA IPC handle
import ctypes

class CudaIpcMemHandle(ctypes.Structure):
    _fields_ = [("reserved", ctypes.c_byte * 64)]

cuda_rt = ctypes.CDLL("libcudart.so")
cuda_rt.cudaIpcGetMemHandle.argtypes = [ctypes.POINTER(CudaIpcMemHandle), ctypes.c_void_p]
cuda_rt.cudaIpcGetMemHandle.restype = ctypes.c_int

handle = CudaIpcMemHandle()
ret = cuda_rt.cudaIpcGetMemHandle(ctypes.byref(handle), ctypes.c_void_p(tensor.data_ptr()))
assert ret == 0
# 发送 bytes(handle.reserved) (64B) + shape + dtype + offset 给 main（仅元数据）
```

2. **Handle 打开 + tensor 重建（comparator 侧）：** 同样框架无关地打开 handle，再用各框架的方式包装：

```python
# Comparator worker: 打开 CUDA IPC handle → 本框架 tensor
import ctypes

cuda_rt = ctypes.CDLL("libcudart.so")
cuda_rt.cudaIpcOpenMemHandle.argtypes = [
    ctypes.POINTER(ctypes.c_void_p), CudaIpcMemHandle, ctypes.c_uint
]
cuda_rt.cudaIpcOpenMemHandle.restype = ctypes.c_int

# 从字节恢复 handle（跨进程接收后）
handle = CudaIpcMemHandle()
ctypes.memmove(handle.reserved, handle_bytes, 64)

ptr = ctypes.c_void_p()
ret = cuda_rt.cudaIpcOpenMemHandle(
    ctypes.byref(ptr), handle, ctypes.c_uint(1)  # cudaIpcMemLazyEnablePeerAccess
)
assert ret == 0

# 通过 __cuda_array_interface__ 零拷贝包装
class GpuArrayView:
    def __init__(self, ptr_val, shape, dtype_str):
        self.__cuda_array_interface__ = {
            "shape": shape,
            "typestr": dtype_str,
            "data": (ptr_val, False),  # (ptr, read_only)
            "version": 2,
        }

view = GpuArrayView(ptr.value, shape, "<f4")

# 各框架用自己的方式从 __cuda_array_interface__ 构建 tensor：
# torch:  torch.as_tensor(view, device='cuda')       ← 已验证
# paddle: paddle.to_tensor(view)                     ← 已验证 (3.3.0+)
# jax:    jax.numpy.array(view)                      ← 待验证
```

3. **Backend 实现示例：**

```python
class TorchBackend(BackendBase):
    @property
    def supports_gpu_compare(self) -> bool:
        return True

    def gpu_assert_close(self, actual, expected, atol, rtol) -> CompareResult:
        import torch
        try:
            torch.testing.assert_close(
                actual, expected, atol=atol, rtol=rtol, equal_nan=True
            )
            return CompareResult(passed=True)
        except AssertionError as e:
            # 提取 max_abs_diff, max_rel_diff 等信息
            return CompareResult(passed=False, detail=str(e))

    def wrap_foreign_gpu_ptr(self, view) -> 'torch.Tensor':
        import torch
        return torch.as_tensor(view, device='cuda')


class JaxBackend(BackendBase):
    @property
    def supports_gpu_compare(self) -> bool:
        return True

    def gpu_assert_close(self, actual, expected, atol, rtol) -> CompareResult:
        import jax.numpy as jnp
        close = jnp.allclose(actual, expected, atol=atol, rtol=rtol)
        if close:
            return CompareResult(passed=True)
        max_diff = float(jnp.max(jnp.abs(actual - expected)))
        return CompareResult(passed=False, max_abs_diff=max_diff)

    def wrap_foreign_gpu_ptr(self, view):
        import jax
        return jax.numpy.array(view)  # 从 __cuda_array_interface__
```

4. **输入数据仍走 SharedMemory：** 输入 numpy 由主进程生成在 CPU，需要通过 SharedMemory 传给两个 Worker，Worker 各自做 CPU→GPU 传输。这一步不可避免，但输入张量通常远小于输出。

### 路径 A：SharedMemory + CPU 比较（纯 CPU 测试，降级路径）

仅用于无 GPU 的测试场景（如 CPU-only 后端、CI 环境测试）。

```
┌──────────────────────────────────────────────────────────┐
│             主进程 (numpy 比较)                              │
│  shm 写入输入 → shm 读取结果 → np.allclose() → 日志         │
│       ┌──────────┐   ┌──────────┐   ┌──────────┐          │
│       │ input    │   │ output_a │   │ output_b │          │
│       │ (shm)    │   │ (shm)    │   │ (shm)    │          │
│       └──┬───┬───┘   └────▲─────┘   └────▲─────┘          │
└──────────┼───┼────────────┼──────────────┼─────────────────┘
           │   │            │              │
     ┌─────▼───┼────────────┼──┐   ┌───────┼───▼──────────┐
     │  Worker A                │   │  Worker B              │
     │  shm→numpy→exec→numpy   │   │  shm→numpy→exec→numpy │
     │  →shm 写回               │   │  →shm 写回             │
     └──────────────────────────┘   └────────────────────────┘
```

### 性能对比（16GB tensor）

| | 路径 A (CPU) | 路径 B (GPU) | 加速比 |
|--|-------------|-------------|--------|
| 输出传输 | GPU→CPU 1.3s + memcpy 10s ×2 | CUDA IPC handle 64B | **∞** |
| 比较 | np.allclose 57s | GPU isclose ~50ms | **1140x** |
| **总计** | **~97 s** | **~200 ms** | **485x** |

### 砍掉的方案

| 方案 | 砍掉理由 |
|------|---------|
| 同进程 + import_order | 脆弱的隐式约束；加第三个框架(JAX)时彻底崩溃 |
| 多进程同 env | paddle/torch 依赖冲突（CUDA/cudnn 版本、底层 C++ 库），不稳定 |
| GPU 测试走 CPU 比较 | 16GB 张量 ~97s，GPU tensor 拉回 CPU 是多余的 |

### 关于 DLPack 的结论

**DLPack 不能跨进程使用。** `DLManagedTensor` 包含 `void* data`、`int64_t* shape`、`void (*deleter)` 等原始指针，都是进程局部虚拟地址。DLPack 的设计目标是**同进程内**框架间的零拷贝借用。

跨进程 GPU 共享需要用 **CUDA IPC**（`cudaIpcGetMemHandle`/`cudaIpcOpenMemHandle`），得到目标进程中的本地 GPU 指针后，再通过 `__cuda_array_interface__` 协议包装成框架 tensor。

### venv 管理：uv

> 以下命令已在 PoC 中验证通过（见 `../pocs/2026-03-05-cuda-ipc-verification.md`）。

```bash
# 创建框架 venv
uv venv --python 3.12 .tensor-spec/venvs/paddle
uv venv --python 3.12 .tensor-spec/venvs/torch

# 安装框架
# 注意：paddle GPU 版需要从官方源安装指定 CUDA 版本的构建
uv pip install --python .tensor-spec/venvs/paddle/bin/python \
    paddlepaddle-gpu==3.3.0 setuptools numpy \
    -i https://www.paddlepaddle.org.cn/packages/stable/cu129/

uv pip install --python .tensor-spec/venvs/torch/bin/python \
    torch numpy --index-url https://download.pytorch.org/whl/cu124
```

```toml
# tensor-spec.toml
[backends.paddle]
python = ".tensor-spec/venvs/paddle/bin/python"

[backends.torch]
python = ".tensor-spec/venvs/torch/bin/python"
```

**Worker 启动方式：** 主进程以目标 venv 的 Python 解释器启动 Worker 子进程：

```python
worker = subprocess.Popen(
    [config.backends["paddle"].python, "-m", "tensor_spec.worker",
     "--backend", "paddle", "--gpu", "0"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
)
```

Worker 进程是 long-running daemon，通过 stdin/stdout（或 Unix socket）接收任务元数据。GPU 测试通过 CUDA IPC handle（64 字节）传递 GPU 内存引用，纯 CPU 测试通过 SharedMemory 传递数据。

**实现语言：** 主进程逻辑（解析/比较/调度）Python 实现。如果后续需要极致性能（如 Case 解析器、二进制协议编解码），用 **Rust** 写 Python 扩展（PyO3）。

**实现优先级：** 路径 A（SharedMemory）在 Phase 0 实现，路径 B（CUDA IPC）在 Phase 1 实现。Phase 0 可先用路径 A 跑通全流程验证正确性，Phase 1 切换到路径 B 获得生产级性能。

> TODO: Worker 进程的生命周期管理（启动/心跳/超时重启）
> TODO: SharedMemory 池的分配/回收策略（避免泄漏）
> TODO: Worker 与主进程的通信协议设计（任务下发 + 结果通知）
> TODO: GPU 分配策略在多 venv 模型下的实现
> TODO: 输出 shape 未知时的处理（Worker 需通知 main 实际输出的 shape/dtype）
> TODO: tensor_spec 核心包如何安装到各 venv（editable install 或 wheel）
> TODO: CUDA IPC 路径的流同步策略（Worker A 需确保 GPU kernel 完成后再传递 handle）
> TODO: CUDA IPC handle 的生命周期管理（Worker A 必须在 Worker B 比较完成后才释放 tensor）
> TODO: __cuda_array_interface__ 封装的健壮性测试（float16/float64/bfloat16, non-contiguous tensor）
> TODO: 非 CUDA GPU 后端（XPU 等）的跨进程共享方案
>
> **已验证 (2026-03-05 PoC):**
> - ~~CUDA IPC 跨进程可行性~~ → 验证通过（Level 0 纯 ctypes + Level 1 torch→paddle）
> - ~~__cuda_array_interface__ + paddle 零拷贝~~ → `paddle.to_tensor(GpuArrayView)` 直接成功（3.3.0+）
> - ~~ctypes 函数签名~~ → 必须用 `ctypes.Structure`，已修正代码示例
> - ~~venv 创建与框架安装~~ → uv + 官方源，命令已验证

---

## 总结

```
dataclass vs pydantic    → dataclass（如无必要勿增实体，后续可迁移）
日志协议                  → JSON Lines（人可读 + 结构化 + 流式）
Case 存储协议             → 自定义二进制格式 .tspecb（领域特定压缩 + 高压缩比 + 快速解码）
配置文件                  → TOML（Python 生态标准）
进程隔离                  → 多进程多 venv（uv 管理，彻底解决依赖冲突）
GPU 测试比较              → CUDA IPC + __cuda_array_interface__ + Comparator GPU 比较（结果不离开 GPU）
GPU Comparator 选择       → 优先级列表 ["torch", "jax", "paddle"]，选参与测试的最高优先级框架
CPU 测试比较              → SharedMemory + numpy（降级路径）
DLPack                   → 不能跨进程；用 CUDA IPC + __cuda_array_interface__ 替代
实现语言                  → Python 为主，性能热点用 Rust (PyO3)
```
