# tensor-spec 方案设计（四个核心问题）

## 问题 1：现代方案 vs 传统方案

### 结论：全面采用现代工具链

| 维度 | PaddleAPITest（传统） | tensor-spec（现代） |
|------|-------------------|------------------|
| 包管理 | requirements.txt / pip | **uv** + pyproject.toml |
| Lint/Format | ruff（已用） | ruff（保留） |
| 类型标注 | 部分 | **全量 type hints** + pyright 检查 |
| 数据类 | 手写 `__init__` | **dataclasses / attrs** |
| Config 解析 | `eval()` / 手写 tokenizer | **自定义安全 parser**（白名单递归下降） |
| 日志 | 12种纯文本文件 | **JSON Lines**（structlog） |
| 测试 | 无自身测试 | **pytest** 完整覆盖 |
| CLI | argparse 硬编码 | **typer** |
| 并行 | pebble ProcessPool | **multiprocessing + 可选 Ray**（TODO: 评估） |
| Case 存储 | 纯文本 .txt | **`.tspec`（文本）+ `.tspecb`（二進制）**（见问题 4） |
| CI | pre-commit only | **GitHub Actions**: lint + type check + unit test |

> TODO: 评估 Ray 作为分布式引擎的可行性（多机扩展场景）
> TODO: 评估 msgspec / pydantic v2 作为数据类基础

---

## 问题 2：多 venv 隔离方案替代 import_order

### 背景

PaddleAPITest 的隐式约束：`import paddle` 必须在 `import torch` 之前。原因是两个框架都会注册 CUDA 全局状态，顺序错误会导致设备初始化异常。

### 方案：进程级 venv 隔离

**核心思路：** 每个框架运行在独立进程中，进程间通过 **共享内存** 传递 numpy 数据。

```
                  主进程（无框架依赖）
                  ┌──────────────┐
                  │  Config 解析  │
                  │  numpy 数据生成│
                  │  结果比较     │
                  └───┬─────┬────┘
            共享内存  │     │  共享内存
           ┌─────────┘     └──────────┐
           ▼                          ▼
  ┌─────────────────┐     ┌─────────────────┐
  │  Backend 进程 A  │     │  Backend 进程 B  │
  │  (venv: paddle)  │     │  (venv: torch)   │
  │  只装 paddle     │     │  只装 torch      │
  │  numpy→tensor    │     │  numpy→tensor    │
  │  exec API        │     │  exec API        │
  │  tensor→numpy    │     │  tensor→numpy    │
  └─────────────────┘     └─────────────────┘
```

### 数据传输方案对比

| 方案 | 延迟 | 带宽 | 实现复杂度 | 适用场景 |
|------|------|------|----------|---------|
| **SharedMemory (推荐)** | ~μs | 内存带宽 | 中 | 大张量（>1KB） |
| numpy .npy 文件 via tmpfs | ~ms | 磁盘/tmpfs | 低 | 简单实现 |
| socket/pipe | ~ms | 受序列化限制 | 中 | 小数据 |
| Apache Arrow IPC | ~μs | 接近内存 | 高 | 结构化数据 |

### 推荐方案：SharedMemory + numpy

```python
# 主进程：生成 numpy，放入共享内存
shm = shared_memory.SharedMemory(create=True, size=numpy_array.nbytes)
shm_array = np.ndarray(shape, dtype, buffer=shm.buf)
shm_array[:] = numpy_array[:]

# Backend 进程：从共享内存读取，执行 API，写回结果
shm = shared_memory.SharedMemory(name=shm_name)
input_array = np.ndarray(shape, dtype, buffer=shm.buf)
# ... exec API ...
# 结果写入另一块共享内存
```

### 最终方案：只保留多 venv 隔离

~~模式 A（同 venv 兼容模式）已砍掉~~ — paddle/torch 存在依赖冲突（CUDA/cudnn 版本、底层 C++ 库），同 env 方案不稳定。

**只保留多 venv 模式：** 每个框架独立 venv（uv 管理）+ 独立进程 + SharedMemory 零拷贝。

```toml
# tensor-spec.toml
[backends.paddle]
python = ".tensor-spec/venvs/paddle/bin/python"

[backends.torch]
python = ".tensor-spec/venvs/torch/bin/python"
```

> **PoC 验证通过的安装命令：**
> ```bash
> uv venv --python 3.10 .tensor-spec/venvs/torch
> uv venv --python 3.10 .tensor-spec/venvs/paddle
> uv pip install --python .tensor-spec/venvs/torch/bin/python torch numpy --index-url https://download.pytorch.org/whl/cu124
> uv pip install --python .tensor-spec/venvs/paddle/bin/python paddlepaddle-gpu==3.3.0 setuptools numpy -i https://www.paddlepaddle.org.cn/packages/stable/cu129/
> ```

### DLPack 跨进程可行性

**结论：DLPack 不能跨进程。** `DLManagedTensor` 中的 `void* data`、`int64_t* shape`、`void (*deleter)` 都是进程局部的虚拟地址。跨进程 GPU 共享走 **CUDA IPC**（`cudaIpcGetMemHandle`/`cudaIpcOpenMemHandle`），配合 `__cuda_array_interface__` 零拷贝包装。

> **已验证 (2026-03-05):** CUDA IPC + `__cuda_array_interface__` → `paddle.to_tensor()` 零拷贝成功。
> 详见 `../pocs/2026-03-05-cuda-ipc-verification.md`（已移至独立 pocs 仓库）。

### 性能评估

以典型 tensor `(32, 3, 224, 224)` float32 = 18.4 MB 为例：

| 步骤 | 耗时 |
|------|------|
| main → shm (memcpy) | ~7 ms |
| shm → worker (零拷贝) | ~0.02 ms |
| numpy → GPU (PCIe) | ~1-2 ms |
| GPU 计算 | 1-100 ms |
| GPU → numpy (PCIe) | ~1-2 ms |
| worker → shm (memcpy) | ~7 ms |
| main 读结果 (零拷贝) | ~0.02 ms |

**传输总开销 ~17 ms，GPU 计算 1-100 ms，传输占比可接受。**

> TODO: SharedMemory 池化复用策略（预分配 buffer，避免频繁创建/销毁）
> TODO: Worker 与主进程的通信协议设计
> TODO: 输出 shape 未知时的处理
> TODO: tensor_spec 核心包如何安装到各 venv
>
> **已验证 (2026-03-05):**
> - ~~CUDA IPC 跨 venv 可行性~~ → torch→paddle 零拷贝验证通过
> - ~~paddle `__cuda_array_interface__` 支持~~ → `paddle.to_tensor(view)` 直接可用
> - ~~venv 创建 + 框架安装命令~~ → uv + 官方源验证通过

---

## 问题 3：渐进式实现路线

### Phase 0: 基础骨架（最先做）

```
目标：能解析 case、生成数据、跑单框架单 case
```

- `spec/` — Tensor 工厂 + TensorSpec dataclass 家族
- `config/parser.py` — 解析单行 case 字符串 → CaseConfig
- `datagen/generator.py` — TensorSpec → numpy（最基础的：uniform random）
- `backend/paddle_backend.py` — numpy → paddle tensor → exec → numpy
- `cli.py` — `tensor-spec check 'abs(x=Tensor.float32((100,)))' --target backend=paddle,python=/venv/paddle/bin/python`
- `tests/` — 上述所有模块的单元测试

**验收标准：** 能跑通 `abs`, `add`, `matmul` 三个 API 的单框架测试。

### Phase 1: 跨框架精度对比

```
目标：替代 PaddleAPITest 的 accuracy 模式
```

- `backend/torch_backend.py` — torch 后端
- `mapping/` — API 名称映射 + 参数映射（JSON）
- `compare/` — numpy 级比较 + 容差配置
- `tester/accuracy.py` — 双 backend 精度对比
- `log/writer.py` — JSON Lines 结构化日志

**验收标准：** 能对 100 个常见 API 跑 paddle vs torch 精度对比，结果与 PaddleAPITest 一致。

### Phase 2: 生产级引擎

```
目标：替代 engineV2 的多 GPU 并行能力
```

- `engine/parallel.py` — 多进程并行 + GPU 分配
- `engine/gpu.py` — GPU 探测 + 内存管理
- `log/checkpoint.py` — 断点续跑
- `log/aggregator.py` — 多进程日志合并
- `config/loader.py` — 批量加载 + 去重

**验收标准：** 4 GPU 并行跑 10 万条 case，throughput ≥ PaddleAPITest engineV2。

### Phase 3: 高级功能

```
目标：完善生态
```

- 多 venv 隔离模式 ✅ **CUDA IPC PoC 已验证**（2026-03-05）
- case 二进制协议 + 压缩存储
- `datagen/constraints.py` — 完整约束库
- `tester/stability.py` — 稳定性测试
- `tester/performance.py` — 性能基准
- 旧格式迁移工具（`tensor-spec migrate`）
- 新框架 backend（JAX 等）

```
Phase 0          Phase 1          Phase 2          Phase 3
骨架              精度对比          生产引擎          高级功能
spec             +torch backend   +parallel        +venv 隔离
parser           +mapping         +gpu mgmt        +binary 协议
datagen(basic)   +compare         +checkpoint      +constraints
paddle backend   +accuracy test   +batch loader    +stability/perf
cli(single)      +json log        +log aggregator  +migrate tool
tests            tests            tests            tests
```

> TODO: 每个 Phase 的详细 task breakdown
> TODO: Phase 0 的预估工作量和验收用例清单
> TODO: 与 PaddleAPITest 的兼容性策略（过渡期并行运行）

---

## 问题 4：Case 管理方案

### 现状分析（PR #614）

当前方案：
- case 以纯文本 .txt 存储，一行一个
- 通过 GitHub Release 分发（tar.gz 压缩包）
- 版本命名：`{type}-v{version}`，支持 patch
- 用 shell 脚本 `auto_get_api_config.sh` 下载

**数据规模：**
- **~950 万行** config
- **~1.4 GB** 纯文本
- tar.gz 压缩后 **~33 MB**（precision.tar.gz）
- 平均每行 **~80 字符**

**主要问题：**
1. 文本冗余极高：`paddle.Tensor.__add__` 重复上万次
2. 解析慢：950 万行 eval() 解析
3. 无法高效查询（按 API 名/dtype/shape 过滤需要全量扫描）
4. patch 机制原始（文件级覆盖）

### 推荐方案：二进制协议 + 分层存储

#### 4.1 二进制协议设计（`.tspecb` 格式）

```
文件结构：
┌──────────────────────────────────┐
│ Header (16 bytes)                │
│   magic: "TSPC" (4B)            │
│   version: uint8 (1B)           │
│   flags: uint8 (1B)             │
│   api_count: uint32 (4B)        │
│   case_count: uint64 (6B)       │
├──────────────────────────────────┤
│ API 字典表                       │
│   [api_id → api_name string]    │
│   [key_id → kwarg_name string]  │
├──────────────────────────────────┤
│ Case 数据（按 API 分组）          │
│   Group: api_id + count + cases │
│     Case: args[] + kwargs[]     │
│       Arg: tag + payload        │
├──────────────────────────────────┤
│ Index（可选，用于随机访问）       │
│   [api_id → offset]             │
└──────────────────────────────────┘
```

**Arg 编码：**

```
tag (1 byte):
  0x00 = TensorSpec
  0x01 = int (varint)
  0x02 = float (float64)
  0x03 = bool (1 byte)
  0x04 = string (len + utf8)
  0x05 = list (count + items)
  0x06 = tuple (count + items)
  0x07 = slice (start, stop, step)
  0x08 = None
  0x09 = dtype enum

TensorSpec 编码:
  dtype: uint8 (枚举, 0=f16, 1=f32, 2=f64, ...)
  ndim: uint8
  shape: varint * ndim
  flags: uint8 (bit0=has_stats, bit1=has_state)
  [stats fields if present]
  [state fields if present]
```

**空间估算：**

```
当前文本: paddle.Tensor.__add__(Tensor([1, 1, 276, 49],"float32"), Tensor([1, 1, 276, 49],"float32"), )
= 93 bytes

二进制:   api_id(2B) + arg_count(1B) + tensor(1+1+1+4*2+1=12B) * 2
= 27 bytes

压缩比: 93/27 ≈ 3.4x（二进制本身）
```

| 格式 | 950万行 | 说明 |
|------|---------|------|
| 纯文本 .txt | ~1.4 GB | 当前 |
| 纯文本 + gzip | ~33 MB | 当前 release |
| 二进制 .tspecb | ~250 MB | ~3.4x 压缩 |
| 二进制 + zstd | **~15-25 MB** | 二进制重复模式更利于压缩 |
| 二进制 + 分组 + zstd | **~8-15 MB** | 同 API 的 case 连续存储，delta 压缩效果极好 |

#### 4.2 分层存储架构

```
tensor-spec cases/
├── registry.json              # 元信息：版本、来源、统计
├── base/                      # 基础 case 集（不常变）
│   ├── math.tspecb            # 数学运算 (abs, add, mul, ...)
│   ├── linalg.tspecb          # 线性代数 (cholesky, svd, ...)
│   ├── nn.tspecb              # 神经网络 (conv, linear, ...)
│   └── ...
├── models/                    # 模型来源的 case 集
│   ├── llama3.tspecb
│   ├── qwen3.tspecb
│   └── ...
└── text/                      # 文本格式 case（可用 pack 转为 .tspecb）
    ├── math.tspec
    └── ...
```

**与 GitHub Release 集成：**

```bash
# 下载并安装 case 集
tensor-spec cases pull            # 拉取最新
tensor-spec cases pull --tag v2   # 指定版本
tensor-spec cases list            # 列出已安装的 case 集
tensor-spec cases query --api "abs" --dtype float32   # 查询
tensor-spec cases stats           # 统计信息
```

#### 4.3 查询能力（二进制格式的核心优势）

因为按 API 分组 + 有索引，可以高效做到：

```bash
# 秒级查询（不需要全量扫描）
tensor-spec cases query --api "nn.conv2d"                     # 按 API
tensor-spec cases query --api "nn.conv2d" --dtype float16     # 按 API + dtype
tensor-spec cases query --shape-rank 4                        # 按维度数
tensor-spec cases query --min-numel 1000000                   # 按元素量（大张量）
```

纯文本做这些需要 grep 全量扫描 1.4GB，二进制格式通过索引可以 O(1) 定位。

#### 4.4 与纯文本的互操作

```bash
# 格式转换（顶层命令）
tensor-spec pack cases.tspec -o cases.tspecb        # .tspec → .tspecb
tensor-spec unpack cases.tspecb -o cases.tspec      # .tspecb → .tspec

# 迁移 PaddleAPITest 旧格式
tensor-spec migrate --input /path/to/PaddleAPITest/tester/api_config/ --output cases/
```

> TODO: 二进制协议的详细字节级规范（varint 编码、stats 字段编码）
> TODO: 评估 SQLite 作为替代存储（索引查询更强，但分发不便）
> TODO: 评估 Parquet/Arrow 作为替代（生态好，但对 case 格式适配度待验证）
> TODO: Case 去重策略（shape 归一化、语义等价检测）
> TODO: Case 来源追踪（从哪个 CI/CE pipeline 哪个模型采集的）

---

## 总结

```
问题1 现代工具   → uv + dataclass + structlog + pytest + typer（全面现代化）
问题2 import隔离 → 多 venv 隔离（砍掉同 env），SharedMemory 零拷贝传数据，DLPack 不能跨进程
问题3 渐进实现   → Phase 0(骨架) → 1(精度对比) → 2(生产引擎) → 3(高级功能)
问题4 Case管理   → .tspecb 二进制协议 + 分组zstd 压缩（1.4GB→~10MB） + 索引查询
```
