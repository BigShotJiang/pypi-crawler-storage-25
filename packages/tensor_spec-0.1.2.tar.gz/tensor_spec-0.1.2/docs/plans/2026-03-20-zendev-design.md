# zendev — 个人开发工作流工具集

**Date:** 2026-03-20
**Status:** Design
**Package name:** `zendev` (PyPI available)

## Problem

每个项目都要重复写 loguru 配置和 commit message 规范，既重复又容易不一致。

## Solution

一个统一的 Python 包 `zendev`，提供：

1. **loguru 统一配置** — 一行代码完成日志初始化
2. **emoji commitizen 插件** — 统一 commit message 风格并校验

## Module 1: `zendev.log` — loguru 配置

### API

```python
import zendev

zendev.setup_log()                        # INFO + 彩色 stderr
zendev.setup_log(verbose=True)            # DEBUG
zendev.setup_log(json=True)               # 结构化 JSON（CI 友好）
```

### Behavior

- `logger.remove()` + `logger.add()` 封装
- 幂等调用（多次调用不重复添加 handler）
- 支持 `ZENDEV_LOG_LEVEL` 环境变量覆盖
- 默认格式：`HH:mm:ss.SSS | LEVEL   | message`

## Module 2: `zendev.cz` — emoji commitizen 插件

### Commit Format

```
<emoji> <type>: <subject>

[optional body]

[optional footer]
```

### Emoji Mapping

| Type | Emoji | Example |
|------|-------|---------|
| init | 🎉 | `🎉 init: begin project` |
| feat | ✨ | `✨ feat: add dark mode` |
| fix | 🐛 | `🐛 fix: null pointer` |
| docs | 📝 | `📝 docs: update README` |
| refactor | ♻️ | `♻️ refactor: extract helper` |
| test | ✅ | `✅ test: add unit tests` |
| ci | 👷 | `👷 ci: add GitHub Actions` |
| perf | ⚡ | `⚡ perf: optimize query` |
| chore | 🔧 | `🔧 chore: update deps` |
| style | 🎨 | `🎨 style: format code` |
| build | 📦 | `📦 build: bump version` |

### Integration

作为 commitizen 插件注册，用户项目中配置：

```toml
# pyproject.toml
[tool.commitizen]
name = "cz_zendev"
```

通过 prek.toml 配置 pre-commit hook 校验 commit message：

```toml
# prek.toml
[[hooks]]
repo = "https://github.com/commitizen-tools/commitizen"
hooks = ["commitizen"]
```

## Project Structure

```
zendev/
├── pyproject.toml
├── src/zendev/
│   ├── __init__.py         # re-export setup_log
│   ├── log.py              # loguru 配置
│   └── cz.py               # commitizen 插件 (cz_zendev)
├── tests/
│   ├── test_log.py
│   └── test_cz.py
└── justfile
```

## Dependencies

- `loguru >= 0.7`
- `commitizen >= 4.0`

## Build

- Build backend: `hatchling`
- Python: `>= 3.12`
- Linter: `ruff`
- Pre-commit: `prek`

## Future Extensibility

此包未来可扩展更多个人开发工具（如项目模板、通用 CI 配置等），但 v0.1 只做 log + cz 两个模块。
