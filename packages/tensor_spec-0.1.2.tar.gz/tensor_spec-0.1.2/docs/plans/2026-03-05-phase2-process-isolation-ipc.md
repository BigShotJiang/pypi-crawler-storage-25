# Phase 2: Multi-Venv Process Isolation & IPC — Implementation Plan

> ⚠️ **注意：** 本文档中的 CLI 命令设计已被新设计取代。
> 当前 CLI 设计规格见 [docs/design/cli-specification.md](/docs/design/cli-specification.md)。
> 本文档中的进程隔离、CUDA IPC、并行引擎等实现细节仍然有效。

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace Phase 1's single-process dual-import accuracy testing with process-isolated workers, each running in its own venv, communicating via SharedMemory (CPU) and CUDA IPC (GPU).

**Architecture:** Each framework runs in a dedicated subprocess spawned from its own venv Python. A `Coordinator` in the main process orchestrates: it sends numpy arrays to workers via `multiprocessing.shared_memory`, workers convert to framework tensors and execute APIs, results come back the same way. For GPU tensors, CUDA IPC handles (64 bytes) are exchanged instead of copying data to CPU. A `GpuArrayView` wrapper exposes `__cuda_array_interface__` for zero-copy tensor creation on the receiving side.

**Tech Stack:** Python 3.10+, multiprocessing.shared_memory, ctypes (CUDA runtime), JSON over stdin/stdout pipes, existing tensor-spec layers (spec, config, datagen, mapping, compare)

---

## Context for Implementer

**Existing codebase (Phase 0+1):**
- `src/tensor_spec/spec/` — TensorSpec hierarchy, Device (DLPack-aligned), Stats, State
- `src/tensor_spec/config/parser.py` — Whitelist recursive descent parser → CaseConfig
- `src/tensor_spec/config/case.py` — CaseConfig(api_name, args, kwargs)
- `src/tensor_spec/datagen/generator.py` — TensorSpec → numpy array
- `src/tensor_spec/backend/base.py` — BackendBase ABC (name, import_framework, numpy_to_tensor, tensor_to_numpy, exec_api, empty_cache, compute_grad, check_cuda_error)
- `src/tensor_spec/backend/paddle_backend.py` — PaddleBackend
- `src/tensor_spec/backend/torch_backend.py` — TorchBackend
- `src/tensor_spec/mapping/registry.py` — MappingRegistry + APIMapping, loads bundled JSON
- `src/tensor_spec/compare/comparator.py` — NumpyComparator + CompareResult
- `src/tensor_spec/compare/tolerance.py` — Tolerance + ToleranceConfig (per-API overrides from TOML)
- `src/tensor_spec/tester/base.py` — TesterBase ABC (template method: generate → execute → compare), TestStatus, TestResult, GeneratedInputs
- `src/tensor_spec/tester/accuracy.py` — AccuracyTester (dual-backend, single-process), BackendError
- `src/tensor_spec/log/writer.py` — LogWriter (JSON Lines)
- `src/tensor_spec/cli.py` — typer CLI with `run`, `validate`, `accuracy` commands

**Key POC findings (moved to ../pocs repo):**
- CUDA IPC handles MUST use `ctypes.Structure`, not raw `(c_byte * 64)()` — ABI difference for pass-by-value
- `paddle.to_tensor(GpuArrayView)` works for zero-copy via `__cuda_array_interface__`
- `torch.as_tensor(view, device='cuda')` works for torch side
- Handle lifecycle: producer creates → sends handle → consumer opens → consumer closes → producer frees
- Venvs at `.tensor-spec/venvs/{framework}/bin/python`

**Data flow for process-isolated accuracy testing (CPU path):**
```
Coordinator process                 Worker A (venv A)           Worker B (venv B)
────────────────────                ──────────────────          ──────────────────
parse_case → CaseConfig
mapping.resolve → api_a, api_b
generator.generate → numpy arrays
                                    ┌─────────────────────┐
write_array(numpy) → SharedMemory ──→ load_tensor(shm)     │
                                    │ numpy_to_tensor()     │
exec_api(api_a, tensor_ids) ───────→ exec_api() → result_a │
store_tensor(result_id) ←──────────── write_array(result)  │
                                    └─────────────────────┘
                                                            ┌─────────────────────┐
write_array(numpy) → SharedMemory ─────────────────────────→ load_tensor(shm)     │
exec_api(api_b, tensor_ids) ───────────────────────────────→ exec_api() → result_b│
store_tensor(result_id) ←──────────────────────────────────── write_array(result)  │
                                                            └─────────────────────┘
compare(result_a_numpy, result_b_numpy, tolerance)
```

**Data flow for GPU path (CUDA IPC):**
```
Worker A (GPU)                      Coordinator          Worker B / Comparator (GPU)
──────────────                      ───────────          ──────────────────────────
exec_api on GPU → tensor
get_ipc_handle → 64B handle ──────→ forward ───────────→ open_ipc_handle → GPU ptr
                                                         GpuArrayView → framework tensor
                                                         torch.testing.assert_close()
cudaIpcCloseMemHandle ←────── notify complete ←───────── cudaIpcCloseMemHandle
free tensor
```

---

## Task 1: SharedMemory Transport

**Files:**
- Create: `src/tensor_spec/ipc/__init__.py`
- Create: `src/tensor_spec/ipc/shared_memory.py`
- Create: `tests/test_ipc/__init__.py`
- Create: `tests/test_ipc/test_shared_memory.py`

**Step 1: Write the failing tests**

```python
# tests/test_ipc/__init__.py
# (empty)

# tests/test_ipc/test_shared_memory.py
"""Tests for SharedMemory-based numpy array transport."""

from __future__ import annotations

import numpy as np
import pytest

from tensor_spec.ipc.shared_memory import ShmBuffer, read_array, unlink, write_array


class TestShmBuffer:
    def test_to_dict_roundtrip(self):
        buf = ShmBuffer(name="shm_test", shape=(2, 3), dtype="float32", nbytes=24)
        assert ShmBuffer.from_dict(buf.to_dict()) == buf

    def test_frozen(self):
        buf = ShmBuffer(name="x", shape=(1,), dtype="float32", nbytes=4)
        with pytest.raises(AttributeError):
            buf.name = "y"


class TestWriteReadArray:
    def test_float32_roundtrip(self):
        arr = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
            assert result.dtype == arr.dtype
            assert result.shape == arr.shape
        finally:
            unlink(buf.name)

    def test_int64_roundtrip(self):
        arr = np.arange(100, dtype=np.int64)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_bool_roundtrip(self):
        arr = np.array([True, False, True], dtype=np.bool_)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_empty_array(self):
        arr = np.array([], dtype=np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            assert result.shape == (0,)
        finally:
            unlink(buf.name)

    def test_large_nd_array(self):
        arr = np.random.default_rng(42).standard_normal((8, 3, 32, 32)).astype(np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_result_is_owned_copy(self):
        """read_array returns an owned copy — safe after unlink."""
        arr = np.array([1.0, 2.0], dtype=np.float32)
        buf = write_array(arr)
        result = read_array(buf)
        unlink(buf.name)
        assert result[0] == 1.0
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_ipc/test_shared_memory.py -v`
Expected: FAIL (ModuleNotFoundError — `tensor_spec.ipc.shared_memory` does not exist)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/ipc/__init__.py
"""IPC transport layer for cross-process tensor sharing."""

# src/tensor_spec/ipc/shared_memory.py
"""SharedMemory-based numpy array transport for CPU tensors."""

from __future__ import annotations

from dataclasses import dataclass
from multiprocessing.shared_memory import SharedMemory

import numpy as np


@dataclass(frozen=True, slots=True)
class ShmBuffer:
    """Metadata describing a numpy array stored in SharedMemory."""

    name: str
    shape: tuple[int, ...]
    dtype: str
    nbytes: int

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict."""
        return {
            "name": self.name,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "nbytes": self.nbytes,
        }

    @classmethod
    def from_dict(cls, d: dict) -> ShmBuffer:
        """Deserialize from a dict."""
        return cls(
            name=d["name"],
            shape=tuple(d["shape"]),
            dtype=d["dtype"],
            nbytes=d["nbytes"],
        )


def write_array(arr: np.ndarray) -> ShmBuffer:
    """Write a numpy array to a new SharedMemory block.

    The caller is responsible for calling unlink() after the consumer has read.
    """
    sm = SharedMemory(create=True, size=max(arr.nbytes, 1))
    shared = np.ndarray(arr.shape, dtype=arr.dtype, buffer=sm.buf)
    np.copyto(shared, arr)
    buf = ShmBuffer(
        name=sm.name,
        shape=arr.shape,
        dtype=str(arr.dtype),
        nbytes=arr.nbytes,
    )
    sm.close()
    return buf


def read_array(buf: ShmBuffer) -> np.ndarray:
    """Read a numpy array from SharedMemory, returning an owned copy.

    Does NOT unlink — caller must do that.
    """
    sm = SharedMemory(name=buf.name)
    arr = np.ndarray(buf.shape, dtype=np.dtype(buf.dtype), buffer=sm.buf).copy()
    sm.close()
    return arr


def unlink(name: str) -> None:
    """Unlink (destroy) a SharedMemory block by name."""
    sm = SharedMemory(name=name)
    sm.close()
    sm.unlink()
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_ipc/test_shared_memory.py -v`
Expected: 8 passed

**Step 5: Commit**

```bash
git add src/tensor_spec/ipc/__init__.py src/tensor_spec/ipc/shared_memory.py \
    tests/test_ipc/__init__.py tests/test_ipc/test_shared_memory.py
git commit -m "feat(ipc): add SharedMemory transport for numpy arrays"
```

---

## Task 2: Worker Message Protocol

**Files:**
- Create: `src/tensor_spec/worker/__init__.py`
- Create: `src/tensor_spec/worker/protocol.py`
- Create: `tests/test_worker/__init__.py`
- Create: `tests/test_worker/test_protocol.py`

The protocol defines JSON messages over stdin/stdout pipes. Each message has an `id`, `type`, and `payload`. Responses have `id`, `ok`, `result`/`error`.

**Step 1: Write the failing tests**

```python
# tests/test_worker/__init__.py
# (empty)

# tests/test_worker/test_protocol.py
"""Tests for worker message protocol."""

from __future__ import annotations

import pytest

from tensor_spec.worker.protocol import (
    Request,
    Response,
    decode_arg_value,
    decode_request,
    decode_response,
    encode_arg_value,
    encode_request,
    encode_response,
)


class TestRequest:
    def test_encode_decode_roundtrip(self):
        req = Request(id=1, type="ping", payload={})
        line = encode_request(req)
        decoded = decode_request(line)
        assert decoded.id == 1
        assert decoded.type == "ping"
        assert decoded.payload == {}

    def test_with_payload(self):
        req = Request(id=2, type="exec_api", payload={"api": "abs", "kwargs": {}})
        decoded = decode_request(encode_request(req))
        assert decoded.payload["api"] == "abs"


class TestResponse:
    def test_ok_response(self):
        resp = Response(id=1, ok=True, result={"tensor_id": "t1"})
        decoded = decode_response(encode_response(resp))
        assert decoded.ok is True
        assert decoded.result["tensor_id"] == "t1"

    def test_error_response(self):
        resp = Response(id=1, ok=False, error="RuntimeError: boom")
        decoded = decode_response(encode_response(resp))
        assert decoded.ok is False
        assert decoded.error == "RuntimeError: boom"
        assert decoded.result is None


class TestArgValueEncoding:
    def test_scalar_int(self):
        assert encode_arg_value(42) == 42

    def test_scalar_float(self):
        assert encode_arg_value(3.14) == 3.14

    def test_scalar_bool(self):
        assert encode_arg_value(True) is True

    def test_scalar_none(self):
        assert encode_arg_value(None) is None

    def test_scalar_string(self):
        assert encode_arg_value("hello") == "hello"

    def test_tensor_ref(self):
        encoded = encode_arg_value({"_ref": "t1"})
        assert encoded == {"_ref": "t1"}

    def test_tuple_of_refs(self):
        val = ("_ref:t1", "_ref:t2")
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "tuple"
        assert len(encoded["items"]) == 2

    def test_nested_tuple(self):
        val = (1, (2, 3))
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "tuple"
        inner = encoded["items"][1]
        assert inner["_t"] == "tuple"

    def test_list(self):
        val = [1, 2, 3]
        encoded = encode_arg_value(val)
        assert encoded["_t"] == "list"


class TestArgValueDecoding:
    def test_scalar_passthrough(self):
        tensors = {}
        assert decode_arg_value(42, tensors) == 42

    def test_tensor_ref_resolves(self):
        sentinel = object()
        tensors = {"t1": sentinel}
        assert decode_arg_value({"_ref": "t1"}, tensors) is sentinel

    def test_tuple_resolves(self):
        sentinel_a = object()
        sentinel_b = object()
        tensors = {"t1": sentinel_a, "t2": sentinel_b}
        encoded = {"_t": "tuple", "items": [{"_ref": "t1"}, {"_ref": "t2"}]}
        result = decode_arg_value(encoded, tensors)
        assert isinstance(result, tuple)
        assert result == (sentinel_a, sentinel_b)

    def test_list_resolves(self):
        tensors = {"t1": "tensor_obj"}
        encoded = {"_t": "list", "items": [{"_ref": "t1"}, 5]}
        result = decode_arg_value(encoded, tensors)
        assert isinstance(result, list)
        assert result == ["tensor_obj", 5]

    def test_unknown_ref_raises(self):
        with pytest.raises(KeyError):
            decode_arg_value({"_ref": "t999"}, {})
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_worker/test_protocol.py -v`
Expected: FAIL (ModuleNotFoundError)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/worker/__init__.py
"""Worker process layer for framework-isolated execution."""

# src/tensor_spec/worker/protocol.py
"""JSON-over-pipe message protocol for worker communication."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Request:
    """A message from the coordinator to a worker."""

    id: int
    type: str
    payload: dict[str, Any]


@dataclass(frozen=True, slots=True)
class Response:
    """A message from a worker back to the coordinator."""

    id: int
    ok: bool
    result: Any = None
    error: str | None = None


def encode_request(req: Request) -> str:
    """Serialize a Request to a single JSON line."""
    return json.dumps({"id": req.id, "type": req.type, "payload": req.payload})


def decode_request(line: str) -> Request:
    """Deserialize a JSON line into a Request."""
    d = json.loads(line)
    return Request(id=d["id"], type=d["type"], payload=d.get("payload", {}))


def encode_response(resp: Response) -> str:
    """Serialize a Response to a single JSON line."""
    d: dict[str, Any] = {"id": resp.id, "ok": resp.ok}
    if resp.result is not None:
        d["result"] = resp.result
    if resp.error is not None:
        d["error"] = resp.error
    return json.dumps(d)


def decode_response(line: str) -> Response:
    """Deserialize a JSON line into a Response."""
    d = json.loads(line)
    return Response(
        id=d["id"],
        ok=d["ok"],
        result=d.get("result"),
        error=d.get("error"),
    )


def encode_arg_value(val: Any) -> Any:
    """Encode an argument value for JSON transport.

    Scalars (int, float, bool, None, str) pass through.
    Dicts with "_ref" key are tensor references — pass through.
    Tuples/lists are wrapped with a type tag so we can restore them.
    """
    if isinstance(val, dict):
        return val
    if isinstance(val, tuple):
        return {"_t": "tuple", "items": [encode_arg_value(v) for v in val]}
    if isinstance(val, list):
        return {"_t": "list", "items": [encode_arg_value(v) for v in val]}
    return val  # scalar


def decode_arg_value(val: Any, tensors: dict[str, Any]) -> Any:
    """Decode an argument value, resolving tensor references.

    Args:
        val: Encoded value from JSON.
        tensors: Map of tensor_id -> framework tensor.
    """
    if isinstance(val, dict):
        if "_ref" in val:
            return tensors[val["_ref"]]
        if "_t" in val:
            items = [decode_arg_value(v, tensors) for v in val["items"]]
            if val["_t"] == "tuple":
                return tuple(items)
            return items  # list
        return val
    return val  # scalar
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_worker/test_protocol.py -v`
Expected: 16 passed

**Step 5: Commit**

```bash
git add src/tensor_spec/worker/__init__.py src/tensor_spec/worker/protocol.py \
    tests/test_worker/__init__.py tests/test_worker/test_protocol.py
git commit -m "feat(worker): add JSON-over-pipe message protocol"
```

---

## Task 3: Worker Process

**Files:**
- Create: `src/tensor_spec/worker/process.py`
- Create: `tests/test_worker/test_process.py`

The worker process is a long-running subprocess that reads JSON requests from stdin and writes JSON responses to stdout. It holds framework tensors in a local dict keyed by tensor_id.

**Step 1: Write the failing tests**

```python
# tests/test_worker/test_process.py
"""Tests for worker process — runs the worker as a subprocess."""

from __future__ import annotations

import json
import subprocess
import sys

import numpy as np
import pytest

from tensor_spec.ipc.shared_memory import read_array, unlink, write_array


def _start_worker(backend: str) -> subprocess.Popen:
    """Start a worker subprocess using current Python."""
    return subprocess.Popen(
        [sys.executable, "-m", "tensor_spec.worker.process", "--backend", backend],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True,
    )


def _send(proc: subprocess.Popen, msg_type: str, payload: dict | None = None) -> dict:
    """Send a request and read a response."""
    msg = {"id": 1, "type": msg_type}
    if payload:
        msg["payload"] = payload
    proc.stdin.write(json.dumps(msg) + "\n")
    proc.stdin.flush()
    line = proc.stdout.readline()
    return json.loads(line)


class TestWorkerLifecycle:
    def test_ping(self):
        proc = _start_worker("paddle")
        try:
            resp = _send(proc, "ping")
            assert resp["ok"] is True
            assert resp["result"] == "pong"
        finally:
            _send(proc, "shutdown")
            proc.wait(timeout=5)

    def test_shutdown(self):
        proc = _start_worker("paddle")
        resp = _send(proc, "shutdown")
        assert resp["ok"] is True
        proc.wait(timeout=5)
        assert proc.returncode == 0


_has_paddle = pytest.importorskip is not None  # helper


@pytest.fixture()
def paddle_worker():
    """Yield a running paddle worker, shut it down after test."""
    pytest.importorskip("paddle")
    proc = _start_worker("paddle")
    _send(proc, "import_framework")
    yield proc
    _send(proc, "shutdown")
    proc.wait(timeout=5)


@pytest.fixture()
def torch_worker():
    """Yield a running torch worker, shut it down after test."""
    pytest.importorskip("torch")
    proc = _start_worker("torch")
    _send(proc, "import_framework")
    yield proc
    _send(proc, "shutdown")
    proc.wait(timeout=5)


class TestWorkerLoadTensor:
    def test_load_float32(self, paddle_worker):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(paddle_worker, "load_tensor", {
                "shm_name": buf.name,
                "shape": list(arr.shape),
                "dtype": "float32",
            })
            assert resp["ok"] is True
            assert "tensor_id" in resp["result"]
        finally:
            unlink(buf.name)


class TestWorkerExecApi:
    def test_exec_abs(self, paddle_worker):
        arr = np.array([-1.0, 2.0, -3.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(paddle_worker, "load_tensor", {
                "shm_name": buf.name,
                "shape": list(arr.shape),
                "dtype": "float32",
            })
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)

        resp = _send(paddle_worker, "exec_api", {
            "api": "abs",
            "args": [{"_ref": tid}],
            "kwargs": {},
        })
        assert resp["ok"] is True
        result_tid = resp["result"]["tensor_id"]

        resp = _send(paddle_worker, "store_tensor", {"tensor_id": result_tid})
        assert resp["ok"] is True
        result_buf = resp["result"]
        result = read_array(
            __import__("tensor_spec.ipc.shared_memory", fromlist=["ShmBuffer"]).ShmBuffer.from_dict(result_buf)
        )
        unlink(result_buf["name"])
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))


class TestWorkerStoreTensor:
    def test_store_roundtrip(self, paddle_worker):
        arr = np.array([10.0, 20.0], dtype=np.float64)
        buf = write_array(arr)
        try:
            resp = _send(paddle_worker, "load_tensor", {
                "shm_name": buf.name,
                "shape": list(arr.shape),
                "dtype": "float64",
            })
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)

        resp = _send(paddle_worker, "store_tensor", {"tensor_id": tid})
        assert resp["ok"] is True
        from tensor_spec.ipc.shared_memory import ShmBuffer
        result = read_array(ShmBuffer.from_dict(resp["result"]))
        unlink(resp["result"]["name"])
        np.testing.assert_array_equal(result, arr)


class TestWorkerFreeTensor:
    def test_free(self, paddle_worker):
        arr = np.array([1.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(paddle_worker, "load_tensor", {
                "shm_name": buf.name,
                "shape": list(arr.shape),
                "dtype": "float32",
            })
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)
        resp = _send(paddle_worker, "free_tensor", {"tensor_id": tid})
        assert resp["ok"] is True

    def test_free_unknown_id(self, paddle_worker):
        resp = _send(paddle_worker, "free_tensor", {"tensor_id": "t9999"})
        assert resp["ok"] is False


class TestWorkerUnknownType:
    def test_unknown_message(self):
        proc = _start_worker("paddle")
        try:
            resp = _send(proc, "totally_unknown_type")
            assert resp["ok"] is False
            assert "Unknown" in resp["error"]
        finally:
            _send(proc, "shutdown")
            proc.wait(timeout=5)
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_worker/test_process.py -v`
Expected: FAIL (module not found or subprocess error)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/worker/process.py
"""Worker subprocess: runs in framework venv, executes commands over stdin/stdout."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np

from tensor_spec.ipc.shared_memory import ShmBuffer, read_array, write_array
from tensor_spec.worker.protocol import decode_arg_value, encode_arg_value


class Worker:
    """Framework-isolated worker that processes JSON commands."""

    def __init__(self, backend_name: str) -> None:
        self.backend_name = backend_name
        self._backend: Any = None
        self._tensors: dict[str, Any] = {}
        self._next_id = 0

    def _gen_id(self) -> str:
        self._next_id += 1
        return f"t{self._next_id}"

    def handle(self, msg: dict) -> dict:
        """Dispatch a single message and return a response dict."""
        msg_type = msg["type"]
        payload = msg.get("payload", {})

        handler = getattr(self, f"_handle_{msg_type}", None)
        if handler is None:
            return {"ok": False, "error": f"Unknown message type: {msg_type}"}
        return handler(payload)

    # ── lifecycle ──

    def _handle_ping(self, _payload: dict) -> dict:
        return {"ok": True, "result": "pong"}

    def _handle_shutdown(self, _payload: dict) -> dict:
        return {"ok": True, "result": "bye"}

    def _handle_import_framework(self, _payload: dict) -> dict:
        self._backend = _load_backend(self.backend_name)
        self._backend.import_framework()
        return {"ok": True, "result": self._backend.name}

    # ── tensor operations ──

    def _handle_load_tensor(self, payload: dict) -> dict:
        """Load numpy from SharedMemory → framework tensor."""
        buf = ShmBuffer(
            name=payload["shm_name"],
            shape=tuple(payload["shape"]),
            dtype=payload["dtype"],
            nbytes=0,  # not needed for read
        )
        arr = read_array(buf)
        # Minimal TensorSpec for conversion (no stats/state needed)
        from tensor_spec.spec.tensor import Tensor

        dtype_factory = getattr(Tensor, payload["dtype"], None)
        if dtype_factory is None:
            return {"ok": False, "error": f"Unknown dtype: {payload['dtype']}"}
        spec = dtype_factory(tuple(payload["shape"]))
        tensor = self._backend.numpy_to_tensor(arr, spec)
        tid = self._gen_id()
        self._tensors[tid] = tensor
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_store_tensor(self, payload: dict) -> dict:
        """Framework tensor → numpy → SharedMemory."""
        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        arr = self._backend.tensor_to_numpy(self._tensors[tid])
        buf = write_array(arr)
        return {"ok": True, "result": buf.to_dict()}

    def _handle_exec_api(self, payload: dict) -> dict:
        """Execute a framework API call."""
        api_name = payload["api"]
        raw_args = payload.get("args", [])
        raw_kwargs = payload.get("kwargs", {})
        args = tuple(decode_arg_value(v, self._tensors) for v in raw_args)
        kwargs = {k: decode_arg_value(v, self._tensors) for k, v in raw_kwargs.items()}
        result = self._backend.exec_api(api_name, args, kwargs)
        tid = self._gen_id()
        self._tensors[tid] = result
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_free_tensor(self, payload: dict) -> dict:
        """Release a tensor from local storage."""
        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        del self._tensors[tid]
        return {"ok": True}

    def _handle_empty_cache(self, _payload: dict) -> dict:
        self._backend.empty_cache()
        return {"ok": True}

    def _handle_check_cuda_error(self, _payload: dict) -> dict:
        self._backend.check_cuda_error()
        return {"ok": True}

    # ── main loop ──

    def run(self) -> None:
        """Read JSON lines from stdin, process, write responses to stdout."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            msg = json.loads(line)
            try:
                resp = self.handle(msg)
            except Exception as e:
                resp = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            resp["id"] = msg.get("id")
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            if msg["type"] == "shutdown":
                break


def _load_backend(name: str) -> Any:
    """Load a backend by name (same logic as cli._load_backend)."""
    if name == "paddle":
        from tensor_spec.backend.paddle_backend import PaddleBackend
        return PaddleBackend()
    if name == "torch":
        from tensor_spec.backend.torch_backend import TorchBackend
        return TorchBackend()
    raise ValueError(f"Unknown backend: {name}. Available: paddle, torch")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="tensor-spec worker process")
    parser.add_argument("--backend", required=True, help="Backend name (paddle, torch)")
    args = parser.parse_args()
    Worker(args.backend).run()


if __name__ == "__main__":
    main()
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_worker/test_process.py -v`
Expected: lifecycle tests pass (ping, shutdown, unknown); framework-specific tests skip if no paddle/torch

**Step 5: Commit**

```bash
git add src/tensor_spec/worker/process.py tests/test_worker/test_process.py
git commit -m "feat(worker): add worker subprocess with JSON-over-pipe protocol"
```

---

## Task 4: Coordinator

**Files:**
- Create: `src/tensor_spec/worker/coordinator.py`
- Create: `tests/test_worker/test_coordinator.py`

The Coordinator starts worker subprocesses, sends them commands, and manages SharedMemory lifecycle.

**Step 1: Write the failing tests**

```python
# tests/test_worker/test_coordinator.py
"""Tests for the Coordinator that manages worker subprocesses."""

from __future__ import annotations

import sys

import numpy as np
import pytest

from tensor_spec.worker.coordinator import Coordinator


class TestCoordinatorLifecycle:
    def test_start_and_ping(self):
        coord = Coordinator()
        try:
            coord.start_worker("w1", sys.executable, "paddle")
            assert "w1" in coord.workers
        finally:
            coord.shutdown_all()

    def test_shutdown_all(self):
        coord = Coordinator()
        coord.start_worker("w1", sys.executable, "paddle")
        coord.shutdown_all()
        assert coord.workers["w1"].process.returncode is not None


@pytest.fixture()
def coord_with_paddle():
    """Coordinator with one paddle worker (skips if no paddle)."""
    pytest.importorskip("paddle")
    coord = Coordinator()
    coord.start_worker("paddle", sys.executable, "paddle")
    coord.import_framework("paddle")
    yield coord
    coord.shutdown_all()


class TestCoordinatorSendReceive:
    def test_send_numpy_and_get_back(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        assert tid.startswith("t")
        result = coord_with_paddle.get_numpy("paddle", tid)
        np.testing.assert_array_equal(result, arr)

    def test_exec_api_abs(self, coord_with_paddle):
        arr = np.array([-1.0, 2.0, -3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api("paddle", "abs", [tid], {})
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_exec_api_with_kwargs(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api(
            "paddle", "abs", [], {"x": tid},
        )
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_free_tensor(self, coord_with_paddle):
        arr = np.array([1.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        coord_with_paddle.free_tensor("paddle", tid)


class TestCoordinatorErrors:
    def test_exec_api_failure(self, coord_with_paddle):
        with pytest.raises(RuntimeError, match="error"):
            coord_with_paddle.exec_api("paddle", "nonexistent_api_xyz", [], {})

    def test_unknown_worker(self):
        coord = Coordinator()
        with pytest.raises(KeyError):
            coord.send_numpy("nonexistent", np.array([1.0]))
        coord.shutdown_all()
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_worker/test_coordinator.py -v`
Expected: FAIL (ModuleNotFoundError)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/worker/coordinator.py
"""Coordinator: manages worker subprocesses and SharedMemory transport."""

from __future__ import annotations

import json
import subprocess
from typing import Any

import numpy as np

from tensor_spec.ipc.shared_memory import ShmBuffer, read_array, unlink, write_array
from tensor_spec.worker.protocol import encode_arg_value


class WorkerHandle:
    """Manages communication with a single worker subprocess."""

    def __init__(self, python_path: str, backend: str) -> None:
        self.process = subprocess.Popen(
            [python_path, "-m", "tensor_spec.worker.process", "--backend", backend],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
        )
        self._next_msg_id = 0

    def send(self, msg_type: str, payload: dict[str, Any] | None = None) -> dict:
        """Send a request and wait for the response."""
        self._next_msg_id += 1
        msg: dict[str, Any] = {"id": self._next_msg_id, "type": msg_type}
        if payload:
            msg["payload"] = payload
        self.process.stdin.write(json.dumps(msg) + "\n")
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError("Worker process exited unexpectedly")
        return json.loads(line)

    def shutdown(self) -> None:
        """Send shutdown command and wait for process to exit."""
        try:
            self.send("shutdown")
        except (BrokenPipeError, RuntimeError):
            pass
        self.process.wait(timeout=10)


class Coordinator:
    """Manages multiple worker subprocesses, routes commands, handles SharedMemory."""

    def __init__(self) -> None:
        self.workers: dict[str, WorkerHandle] = {}
        self._shm_to_unlink: list[str] = []

    def start_worker(self, name: str, python_path: str, backend: str) -> None:
        """Start a named worker subprocess."""
        handle = WorkerHandle(python_path, backend)
        resp = handle.send("ping")
        if not resp.get("ok"):
            raise RuntimeError(f"Worker {name} failed ping: {resp}")
        self.workers[name] = handle

    def import_framework(self, worker_name: str) -> None:
        """Tell a worker to import its framework."""
        resp = self.workers[worker_name].send("import_framework")
        if not resp.get("ok"):
            raise RuntimeError(f"import_framework failed: {resp.get('error')}")

    def send_numpy(self, worker_name: str, arr: np.ndarray) -> str:
        """Send a numpy array to a worker via SharedMemory. Returns tensor_id."""
        buf = write_array(arr)
        self._shm_to_unlink.append(buf.name)
        resp = self.workers[worker_name].send("load_tensor", {
            "shm_name": buf.name,
            "shape": list(arr.shape),
            "dtype": str(arr.dtype),
        })
        if not resp.get("ok"):
            raise RuntimeError(f"load_tensor failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def get_numpy(self, worker_name: str, tensor_id: str) -> np.ndarray:
        """Get a numpy array from a worker via SharedMemory."""
        resp = self.workers[worker_name].send("store_tensor", {
            "tensor_id": tensor_id,
        })
        if not resp.get("ok"):
            raise RuntimeError(f"store_tensor failed: {resp.get('error')}")
        buf = ShmBuffer.from_dict(resp["result"])
        arr = read_array(buf)
        unlink(buf.name)
        return arr

    def exec_api(
        self,
        worker_name: str,
        api_name: str,
        args: list[str | Any],
        kwargs: dict[str, str | Any],
    ) -> str:
        """Execute an API on a worker. Tensor IDs are wrapped as _ref dicts.

        Returns the result tensor_id.
        """
        encoded_args = [
            {"_ref": v} if isinstance(v, str) and v.startswith("t") else encode_arg_value(v)
            for v in args
        ]
        encoded_kwargs = {
            k: {"_ref": v} if isinstance(v, str) and v.startswith("t") else encode_arg_value(v)
            for k, v in kwargs.items()
        }
        resp = self.workers[worker_name].send("exec_api", {
            "api": api_name,
            "args": encoded_args,
            "kwargs": encoded_kwargs,
        })
        if not resp.get("ok"):
            raise RuntimeError(f"exec_api failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def free_tensor(self, worker_name: str, tensor_id: str) -> None:
        """Release a tensor in a worker."""
        self.workers[worker_name].send("free_tensor", {"tensor_id": tensor_id})

    def empty_cache(self, worker_name: str) -> None:
        """Clear GPU cache on a worker."""
        self.workers[worker_name].send("empty_cache")

    def check_cuda_error(self, worker_name: str) -> None:
        """Check for CUDA errors on a worker."""
        self.workers[worker_name].send("check_cuda_error")

    def shutdown_all(self) -> None:
        """Shutdown all workers and clean up SharedMemory."""
        for handle in self.workers.values():
            handle.shutdown()
        for name in self._shm_to_unlink:
            try:
                unlink(name)
            except FileNotFoundError:
                pass
        self._shm_to_unlink.clear()
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_worker/test_coordinator.py -v`
Expected: lifecycle tests pass; paddle-specific tests skip if no paddle

**Step 5: Commit**

```bash
git add src/tensor_spec/worker/coordinator.py tests/test_worker/test_coordinator.py
git commit -m "feat(worker): add Coordinator for managing worker subprocesses"
```

---

## Task 5: CUDA IPC Handle

**Files:**
- Create: `src/tensor_spec/ipc/cuda_handle.py`
- Create: `tests/test_ipc/test_cuda_handle.py`

Based on the POC findings: MUST use `ctypes.Structure` for the handle, not raw `(c_byte * 64)()`.

**Step 1: Write the failing tests**

```python
# tests/test_ipc/test_cuda_handle.py
"""Tests for CUDA IPC handle wrapper."""

from __future__ import annotations

import ctypes

import pytest

from tensor_spec.ipc.cuda_handle import CudaIpcMemHandle, get_cuda_rt


class TestCudaIpcMemHandle:
    def test_structure_size(self):
        """Handle must be exactly 64 bytes."""
        handle = CudaIpcMemHandle()
        assert ctypes.sizeof(handle) == 64

    def test_bytes_roundtrip(self):
        """bytes() → memmove roundtrip preserves data."""
        handle = CudaIpcMemHandle()
        for i in range(64):
            handle.reserved[i] = i % 128
        raw = bytes(handle.reserved)
        assert len(raw) == 64

        restored = CudaIpcMemHandle()
        ctypes.memmove(restored.reserved, raw, 64)
        assert bytes(restored.reserved) == raw


class TestGetCudaRt:
    def test_returns_none_without_cuda(self):
        """get_cuda_rt() returns None if libcudart.so is not found."""
        # We can't guarantee CUDA presence, but we can test the function doesn't crash.
        result = get_cuda_rt()
        # Either a CDLL or None
        assert result is None or hasattr(result, "cudaIpcGetMemHandle")


# GPU-only tests — skip if no CUDA
_has_cuda = False
try:
    _rt = ctypes.CDLL("libcudart.so")
    _has_cuda = True
except OSError:
    pass

requires_cuda = pytest.mark.skipif(not _has_cuda, reason="No CUDA runtime")


@requires_cuda
class TestCudaIpcGetOpenHandle:
    def test_get_handle_for_allocated_memory(self):
        from tensor_spec.ipc.cuda_handle import close_ipc_handle, get_ipc_handle, open_ipc_handle

        cuda_rt = ctypes.CDLL("libcudart.so")

        # Allocate GPU memory
        ptr = ctypes.c_void_p()
        size = 1024
        err = cuda_rt.cudaMalloc(ctypes.byref(ptr), ctypes.c_size_t(size))
        assert err == 0, f"cudaMalloc failed: {err}"

        try:
            # Get IPC handle
            handle_bytes = get_ipc_handle(ptr.value)
            assert len(handle_bytes) == 64

            # Open IPC handle (same process — works for testing)
            opened_ptr = open_ipc_handle(handle_bytes)
            assert opened_ptr != 0

            close_ipc_handle(opened_ptr)
        finally:
            cuda_rt.cudaFree(ptr)
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_ipc/test_cuda_handle.py -v`
Expected: FAIL (ModuleNotFoundError)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/ipc/cuda_handle.py
"""CUDA IPC handle wrapper using ctypes.

Key insight from POC: cudaIpcOpenMemHandle receives the handle BY VALUE,
so we MUST use ctypes.Structure (not raw c_byte array) for correct ABI.
"""

from __future__ import annotations

import ctypes

# Flag for cudaIpcOpenMemHandle: enable lazy peer access
_cudaIpcMemLazyEnablePeerAccess = 0x01


class CudaIpcMemHandle(ctypes.Structure):
    """64-byte CUDA IPC memory handle — matches cudaIpcMemHandle_t."""

    _fields_ = [("reserved", ctypes.c_byte * 64)]


def get_cuda_rt() -> ctypes.CDLL | None:
    """Load libcudart.so and set up function signatures. Returns None if unavailable."""
    try:
        cuda_rt = ctypes.CDLL("libcudart.so")
    except OSError:
        return None

    cuda_rt.cudaIpcGetMemHandle.argtypes = [
        ctypes.POINTER(CudaIpcMemHandle),
        ctypes.c_void_p,
    ]
    cuda_rt.cudaIpcGetMemHandle.restype = ctypes.c_int

    cuda_rt.cudaIpcOpenMemHandle.argtypes = [
        ctypes.POINTER(ctypes.c_void_p),
        CudaIpcMemHandle,
        ctypes.c_uint,
    ]
    cuda_rt.cudaIpcOpenMemHandle.restype = ctypes.c_int

    cuda_rt.cudaIpcCloseMemHandle.argtypes = [ctypes.c_void_p]
    cuda_rt.cudaIpcCloseMemHandle.restype = ctypes.c_int

    return cuda_rt


# Module-level singleton (lazy)
_cuda_rt: ctypes.CDLL | None = None


def _rt() -> ctypes.CDLL:
    """Get the CUDA runtime, raising if unavailable."""
    global _cuda_rt  # noqa: PLW0603
    if _cuda_rt is None:
        _cuda_rt = get_cuda_rt()
    if _cuda_rt is None:
        raise RuntimeError("CUDA runtime (libcudart.so) not available")
    return _cuda_rt


def get_ipc_handle(device_ptr: int) -> bytes:
    """Get a 64-byte IPC handle for a device pointer."""
    handle = CudaIpcMemHandle()
    err = _rt().cudaIpcGetMemHandle(ctypes.byref(handle), device_ptr)
    if err != 0:
        raise RuntimeError(f"cudaIpcGetMemHandle failed with error {err}")
    return bytes(handle.reserved)


def open_ipc_handle(handle_bytes: bytes) -> int:
    """Open an IPC handle, returning a device pointer. Caller must close it."""
    handle = CudaIpcMemHandle()
    ctypes.memmove(handle.reserved, handle_bytes, 64)
    ptr = ctypes.c_void_p()
    err = _rt().cudaIpcOpenMemHandle(
        ctypes.byref(ptr), handle, _cudaIpcMemLazyEnablePeerAccess
    )
    if err != 0:
        raise RuntimeError(f"cudaIpcOpenMemHandle failed with error {err}")
    return ptr.value


def close_ipc_handle(device_ptr: int) -> None:
    """Close an IPC handle opened by open_ipc_handle."""
    err = _rt().cudaIpcCloseMemHandle(device_ptr)
    if err != 0:
        raise RuntimeError(f"cudaIpcCloseMemHandle failed with error {err}")
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_ipc/test_cuda_handle.py -v`
Expected: structure/roundtrip tests PASS; GPU tests SKIP if no CUDA

**Step 5: Commit**

```bash
git add src/tensor_spec/ipc/cuda_handle.py tests/test_ipc/test_cuda_handle.py
git commit -m "feat(ipc): add CUDA IPC handle ctypes wrapper"
```

---

## Task 6: GpuArrayView

**Files:**
- Create: `src/tensor_spec/ipc/gpu_array_view.py`
- Create: `tests/test_ipc/test_gpu_array_view.py`

A minimal wrapper that exposes `__cuda_array_interface__` so that `paddle.to_tensor(view)` and `torch.as_tensor(view, device='cuda')` can create tensors from a raw GPU pointer with zero copy.

**Step 1: Write the failing tests**

```python
# tests/test_ipc/test_gpu_array_view.py
"""Tests for GpuArrayView — __cuda_array_interface__ wrapper."""

from __future__ import annotations

import pytest

from tensor_spec.ipc.gpu_array_view import DTYPE_TO_TYPESTR, GpuArrayView


class TestGpuArrayView:
    def test_interface_shape(self):
        view = GpuArrayView(ptr=0xDEADBEEF, shape=(2, 3), dtype="float32")
        iface = view.__cuda_array_interface__
        assert iface["shape"] == (2, 3)

    def test_interface_typestr(self):
        view = GpuArrayView(ptr=0x1000, shape=(4,), dtype="float64")
        assert view.__cuda_array_interface__["typestr"] == "<f8"

    def test_interface_data_ptr(self):
        view = GpuArrayView(ptr=42, shape=(1,), dtype="int32")
        data_ptr, read_only = view.__cuda_array_interface__["data"]
        assert data_ptr == 42
        assert read_only is False

    def test_interface_version(self):
        view = GpuArrayView(ptr=0, shape=(1,), dtype="float32")
        assert view.__cuda_array_interface__["version"] == 2

    def test_unknown_dtype_raises(self):
        with pytest.raises(ValueError, match="Unsupported dtype"):
            GpuArrayView(ptr=0, shape=(1,), dtype="weird_type")


class TestDtypeMapping:
    @pytest.mark.parametrize(
        ("dtype", "expected"),
        [
            ("float16", "<f2"),
            ("float32", "<f4"),
            ("float64", "<f8"),
            ("int8", "<i1"),
            ("int16", "<i2"),
            ("int32", "<i4"),
            ("int64", "<i8"),
            ("uint8", "<u1"),
            ("bool", "|b1"),
            ("complex64", "<c8"),
            ("complex128", "<c16"),
        ],
    )
    def test_dtype_to_typestr(self, dtype, expected):
        assert DTYPE_TO_TYPESTR[dtype] == expected

    def test_all_common_dtypes_covered(self):
        required = {"float16", "float32", "float64", "int8", "int16", "int32",
                     "int64", "uint8", "bool", "complex64", "complex128"}
        assert required.issubset(set(DTYPE_TO_TYPESTR.keys()))
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_ipc/test_gpu_array_view.py -v`
Expected: FAIL (ModuleNotFoundError)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/ipc/gpu_array_view.py
"""GpuArrayView: exposes a GPU pointer via __cuda_array_interface__.

This allows paddle.to_tensor(view) and torch.as_tensor(view, device='cuda')
to create framework tensors from a raw GPU pointer with zero copy.
"""

from __future__ import annotations

DTYPE_TO_TYPESTR: dict[str, str] = {
    "float16": "<f2",
    "float32": "<f4",
    "float64": "<f8",
    "bfloat16": "<V2",  # no standard typestr; bfloat16 needs special handling
    "int8": "<i1",
    "int16": "<i2",
    "int32": "<i4",
    "int64": "<i8",
    "uint8": "<u1",
    "bool": "|b1",
    "complex64": "<c8",
    "complex128": "<c16",
}


class GpuArrayView:
    """Wraps a GPU device pointer as a __cuda_array_interface__ object.

    Usage::

        view = GpuArrayView(ptr=device_ptr, shape=(32, 3, 224, 224), dtype="float32")
        torch_tensor = torch.as_tensor(view, device='cuda')
        paddle_tensor = paddle.to_tensor(view)
    """

    __slots__ = ("__cuda_array_interface__",)

    def __init__(self, ptr: int, shape: tuple[int, ...], dtype: str) -> None:
        typestr = DTYPE_TO_TYPESTR.get(dtype)
        if typestr is None:
            raise ValueError(f"Unsupported dtype: {dtype}")
        self.__cuda_array_interface__ = {
            "shape": shape,
            "typestr": typestr,
            "data": (ptr, False),  # (pointer, read_only)
            "version": 2,
        }
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_ipc/test_gpu_array_view.py -v`
Expected: all passed

**Step 5: Commit**

```bash
git add src/tensor_spec/ipc/gpu_array_view.py tests/test_ipc/test_gpu_array_view.py
git commit -m "feat(ipc): add GpuArrayView for __cuda_array_interface__"
```

---

## Task 7: Worker GPU Commands (CUDA IPC Operations)

**Files:**
- Modify: `src/tensor_spec/worker/process.py` — add `_handle_get_ipc_handle` and `_handle_open_ipc_handle`
- Modify: `src/tensor_spec/worker/coordinator.py` — add `get_ipc_handle()` and `open_ipc_handle()`
- Create: `tests/test_worker/test_gpu_commands.py`

**Step 1: Write the failing tests**

```python
# tests/test_worker/test_gpu_commands.py
"""Tests for GPU IPC commands in worker/coordinator — requires CUDA."""

from __future__ import annotations

import ctypes

import numpy as np
import pytest

requires_cuda = pytest.mark.skipif(
    not _cuda_available(), reason="No CUDA runtime",
)


def _cuda_available() -> bool:
    try:
        ctypes.CDLL("libcudart.so")
        return True
    except OSError:
        return False


@requires_cuda
class TestWorkerGetIpcHandle:
    """Test that a worker can produce an IPC handle for a GPU tensor."""

    def test_get_handle_returns_64_bytes(self, torch_gpu_worker):
        """After exec on GPU, get_ipc_handle returns 64-byte handle."""
        import json, subprocess, sys
        from tensor_spec.ipc.shared_memory import write_array, unlink

        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(torch_gpu_worker, "load_tensor", {
                "shm_name": buf.name, "shape": [3], "dtype": "float32", "device": "cuda",
            })
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)

        resp = _send(torch_gpu_worker, "get_ipc_handle", {"tensor_id": tid})
        assert resp["ok"] is True
        import base64
        handle_bytes = base64.b64decode(resp["result"]["handle"])
        assert len(handle_bytes) == 64
        assert resp["result"]["shape"] == [3]
        assert resp["result"]["dtype"] == "float32"
```

> **Note:** Full GPU tests require CUDA hardware. The implementer should write tests that skip gracefully on CPU-only machines. The key tests to write:
>
> 1. `test_get_handle_returns_64_bytes` — load tensor to GPU, get handle, verify 64 bytes
> 2. `test_open_handle_and_read` — open handle in same process, read data back, verify correctness
> 3. `test_coordinator_get_ipc_handle` — coordinator-level: get_ipc_handle returns handle metadata
>
> All wrapped in `@requires_cuda` + `skipif` for the framework.

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_worker/test_gpu_commands.py -v`
Expected: SKIP (no CUDA) or FAIL (handler not found)

**Step 3: Add GPU handlers to worker**

Add to `src/tensor_spec/worker/process.py`:

```python
# Add these methods to the Worker class:

    def _handle_load_tensor(self, payload: dict) -> dict:
        """Load numpy from SharedMemory → framework tensor.

        If payload["device"] == "cuda", move tensor to GPU.
        """
        buf = ShmBuffer(
            name=payload["shm_name"],
            shape=tuple(payload["shape"]),
            dtype=payload["dtype"],
            nbytes=0,
        )
        arr = read_array(buf)
        from tensor_spec.spec.tensor import Tensor
        dtype_factory = getattr(Tensor, payload["dtype"], None)
        if dtype_factory is None:
            return {"ok": False, "error": f"Unknown dtype: {payload['dtype']}"}
        spec = dtype_factory(tuple(payload["shape"]))
        tensor = self._backend.numpy_to_tensor(arr, spec)
        # Move to GPU if requested
        device = payload.get("device", "cpu")
        if device.startswith("cuda"):
            tensor = self._move_to_device(tensor, device)
        tid = self._gen_id()
        self._tensors[tid] = tensor
        return {"ok": True, "result": {"tensor_id": tid}}

    def _move_to_device(self, tensor: Any, device: str) -> Any:
        """Move a tensor to the specified device (framework-specific)."""
        if self.backend_name == "torch":
            return tensor.to(device)
        if self.backend_name == "paddle":
            import paddle
            return paddle.to_tensor(tensor, place=paddle.CUDAPlace(0))
        return tensor

    def _handle_get_ipc_handle(self, payload: dict) -> dict:
        """Get CUDA IPC handle for a GPU tensor."""
        import base64
        from tensor_spec.ipc.cuda_handle import get_ipc_handle

        tid = payload["tensor_id"]
        if tid not in self._tensors:
            return {"ok": False, "error": f"Unknown tensor: {tid}"}
        tensor = self._tensors[tid]
        device_ptr = self._get_data_ptr(tensor)
        handle_bytes = get_ipc_handle(device_ptr)
        shape, dtype = self._get_tensor_meta(tensor)
        return {
            "ok": True,
            "result": {
                "handle": base64.b64encode(handle_bytes).decode(),
                "shape": list(shape),
                "dtype": dtype,
            },
        }

    def _handle_open_ipc_handle(self, payload: dict) -> dict:
        """Open a CUDA IPC handle and wrap as a framework tensor."""
        import base64
        from tensor_spec.ipc.cuda_handle import open_ipc_handle
        from tensor_spec.ipc.gpu_array_view import GpuArrayView

        handle_bytes = base64.b64decode(payload["handle"])
        shape = tuple(payload["shape"])
        dtype = payload["dtype"]
        ptr = open_ipc_handle(handle_bytes)
        view = GpuArrayView(ptr=ptr, shape=shape, dtype=dtype)
        if self.backend_name == "torch":
            import torch
            tensor = torch.as_tensor(view, device="cuda")
        elif self.backend_name == "paddle":
            import paddle
            tensor = paddle.to_tensor(view)
        else:
            return {"ok": False, "error": f"GPU IPC not supported for {self.backend_name}"}
        tid = self._gen_id()
        self._tensors[tid] = tensor
        self._ipc_ptrs[tid] = ptr  # track for cleanup
        return {"ok": True, "result": {"tensor_id": tid}}

    def _handle_close_ipc_handle(self, payload: dict) -> dict:
        """Close a previously opened IPC handle."""
        from tensor_spec.ipc.cuda_handle import close_ipc_handle

        tid = payload["tensor_id"]
        if tid in self._ipc_ptrs:
            close_ipc_handle(self._ipc_ptrs.pop(tid))
        if tid in self._tensors:
            del self._tensors[tid]
        return {"ok": True}

    def _get_data_ptr(self, tensor: Any) -> int:
        """Get the raw GPU data pointer from a framework tensor."""
        if self.backend_name == "torch":
            return tensor.data_ptr()
        if self.backend_name == "paddle":
            return tensor.data_ptr()
        raise RuntimeError(f"data_ptr not supported for {self.backend_name}")

    def _get_tensor_meta(self, tensor: Any) -> tuple[tuple[int, ...], str]:
        """Get (shape, dtype_str) from a framework tensor."""
        if self.backend_name == "torch":
            shape = tuple(tensor.shape)
            dtype = str(tensor.dtype).replace("torch.", "")
            return shape, dtype
        if self.backend_name == "paddle":
            shape = tuple(tensor.shape)
            dtype = str(tensor.dtype).replace("paddle.", "").replace("VarType.", "")
            return shape, dtype
        raise RuntimeError(f"meta not supported for {self.backend_name}")
```

Also add `_ipc_ptrs: dict[str, int]` to `Worker.__init__()`:
```python
    def __init__(self, backend_name: str) -> None:
        self.backend_name = backend_name
        self._backend: Any = None
        self._tensors: dict[str, Any] = {}
        self._ipc_ptrs: dict[str, int] = {}  # tensor_id → opened IPC device ptr
        self._next_id = 0
```

Add to `src/tensor_spec/worker/coordinator.py`:

```python
    def get_ipc_handle(self, worker_name: str, tensor_id: str) -> dict:
        """Get CUDA IPC handle from a worker's GPU tensor.

        Returns dict with keys: handle (base64), shape, dtype.
        """
        resp = self.workers[worker_name].send("get_ipc_handle", {
            "tensor_id": tensor_id,
        })
        if not resp.get("ok"):
            raise RuntimeError(f"get_ipc_handle failed: {resp.get('error')}")
        return resp["result"]

    def open_ipc_handle(self, worker_name: str, handle_info: dict) -> str:
        """Open a CUDA IPC handle on a worker, returns tensor_id."""
        resp = self.workers[worker_name].send("open_ipc_handle", handle_info)
        if not resp.get("ok"):
            raise RuntimeError(f"open_ipc_handle failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def close_ipc_handle(self, worker_name: str, tensor_id: str) -> None:
        """Close an IPC handle on a worker."""
        self.workers[worker_name].send("close_ipc_handle", {"tensor_id": tensor_id})
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_worker/test_gpu_commands.py -v`
Expected: GPU tests SKIP on CPU machines; PASS on GPU machines

**Step 5: Commit**

```bash
git add src/tensor_spec/worker/process.py src/tensor_spec/worker/coordinator.py \
    tests/test_worker/test_gpu_commands.py
git commit -m "feat(worker): add CUDA IPC handle get/open/close commands"
```

---

## Task 8: Process-Isolated AccuracyTester

**Files:**
- Create: `src/tensor_spec/tester/isolated_accuracy.py`
- Create: `tests/test_tester/test_isolated_accuracy.py`

This extends `TesterBase` but uses the `Coordinator` instead of direct backend calls. The coordinator handles all subprocess communication.

**Step 1: Write the failing tests**

```python
# tests/test_tester/test_isolated_accuracy.py
"""Tests for IsolatedAccuracyTester."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

import numpy as np
import pytest

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import Tensor
from tensor_spec.tester.base import TestStatus
from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester
from tensor_spec.worker.coordinator import Coordinator


def _make_case(api: str = "abs") -> CaseConfig:
    return CaseConfig(
        api_name=api,
        args=(),
        kwargs={"x": Tensor.float32((3,))},
    )


@pytest.fixture()
def _both_frameworks():
    pytest.importorskip("paddle")
    pytest.importorskip("torch")


@pytest.fixture()
def isolated_tester(_both_frameworks):
    """IsolatedAccuracyTester with real workers using current Python."""
    mapping = MappingRegistry()
    mapping.load_bundled("paddle")
    mapping.load_bundled("torch")
    tester = IsolatedAccuracyTester(
        python_a=sys.executable,
        backend_a_name="paddle",
        python_b=sys.executable,
        backend_b_name="torch",
        mapping=mapping,
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    yield tester
    tester.shutdown()


class TestIsolatedAccuracyPass:
    def test_abs_passes(self, isolated_tester):
        case = _make_case("abs")
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED
        assert result.compare_result is not None
        assert result.compare_result.passed is True

    def test_add_passes(self, isolated_tester):
        case = CaseConfig(
            api_name="add",
            args=(),
            kwargs={"x": Tensor.float32((3,)), "y": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED


class TestIsolatedAccuracyError:
    def test_unknown_api_returns_error(self, isolated_tester):
        case = CaseConfig(
            api_name="totally_fake_api",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status in (TestStatus.PADDLE_ERROR, TestStatus.TORCH_ERROR, TestStatus.ERROR)
        assert result.error is not None


class TestIsolatedAccuracyDuration:
    def test_duration_is_positive(self, isolated_tester):
        case = _make_case("abs")
        result = isolated_tester.test(case)
        assert result.duration_ms > 0
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_tester/test_isolated_accuracy.py -v`
Expected: FAIL (ModuleNotFoundError)

**Step 3: Write minimal implementation**

```python
# src/tensor_spec/tester/isolated_accuracy.py
"""IsolatedAccuracyTester: process-isolated dual-backend accuracy comparison."""

from __future__ import annotations

import time
from typing import Any

import numpy as np

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import TensorSpec
from tensor_spec.tester.base import GeneratedInputs, TesterBase, TestResult, TestStatus
from tensor_spec.worker.coordinator import Coordinator
from tensor_spec.worker.protocol import encode_arg_value


class IsolatedAccuracyTester(TesterBase):
    """Runs accuracy comparison with each backend in a separate subprocess."""

    def __init__(
        self,
        python_a: str,
        backend_a_name: str,
        python_b: str,
        backend_b_name: str,
        mapping: MappingRegistry,
        comparator: NumpyComparator,
        tolerance: Tolerance,
        generator: TensorGenerator,
    ) -> None:
        super().__init__(generator)
        self._backend_a_name = backend_a_name
        self._backend_b_name = backend_b_name
        self._mapping = mapping
        self._comparator = comparator
        self._tolerance = tolerance
        self._coordinator = Coordinator()
        self._coordinator.start_worker("a", python_a, backend_a_name)
        self._coordinator.start_worker("b", python_b, backend_b_name)
        self._coordinator.import_framework("a")
        self._coordinator.import_framework("b")

    def shutdown(self) -> None:
        """Shutdown worker processes."""
        self._coordinator.shutdown_all()

    def test(self, case: CaseConfig) -> TestResult:
        """Override template to handle subprocess errors."""
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except _WorkerBackendError as e:
            status = self._backend_error_status(e.backend_name)
            return TestResult(
                case=case,
                status=status,
                error=e.message,
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except MemoryError as e:
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute API on both workers and return numpy outputs."""
        np_a = self._execute_on_worker("a", self._backend_a_name, case, inputs)
        self._coordinator.empty_cache("a")
        np_b = self._execute_on_worker("b", self._backend_b_name, case, inputs)
        return {"a_numpy": np_a, "b_numpy": np_b}

    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """Compare numpy outputs from both workers."""
        tol = self._tolerance.get(case.api_name)
        cmp_result = self._comparator.compare(
            outputs["a_numpy"], outputs["b_numpy"], tol,
        )
        status = TestStatus.PASSED if cmp_result.passed else TestStatus.ACCURACY_ERROR
        return TestResult(case=case, status=status, compare_result=cmp_result)

    def _execute_on_worker(
        self,
        worker_name: str,
        backend_name: str,
        case: CaseConfig,
        inputs: GeneratedInputs,
    ) -> np.ndarray:
        """Send data to a worker, execute API, retrieve numpy result."""
        coord = self._coordinator
        mapping = self._mapping.resolve(case.api_name, backend_name)

        # Send tensor args
        arg_refs: list[Any] = []
        for i, val in enumerate(case.args):
            if isinstance(val, TensorSpec) and inputs.arg_arrays[i] is not None:
                tid = coord.send_numpy(worker_name, inputs.arg_arrays[i])
                arg_refs.append(tid)
            elif isinstance(val, tuple):
                # Handle tuple of tensors (e.g., concat)
                items = []
                for j, v in enumerate(val):
                    if isinstance(v, TensorSpec):
                        np_data = self._generator.generate(v)
                        items.append(coord.send_numpy(worker_name, np_data))
                    else:
                        items.append(v)
                arg_refs.append(tuple(items))
            else:
                arg_refs.append(val)

        # Send tensor kwargs (with name remapping)
        kwarg_refs: dict[str, Any] = {}
        for key, val in case.kwargs.items():
            mapped_key = mapping.args_map.get(key, key)
            if isinstance(val, TensorSpec) and key in inputs.kwarg_arrays:
                tid = coord.send_numpy(worker_name, inputs.kwarg_arrays[key])
                kwarg_refs[mapped_key] = tid
            else:
                kwarg_refs[mapped_key] = val

        # Execute
        try:
            result_tid = coord.exec_api(worker_name, mapping.api, list(arg_refs), kwarg_refs)
        except RuntimeError as e:
            raise _WorkerBackendError(backend_name, str(e)) from e

        # Get result numpy
        coord.check_cuda_error(worker_name)
        return coord.get_numpy(worker_name, result_tid)

    def _backend_error_status(self, backend_name: str) -> TestStatus:
        if backend_name == "paddle":
            return TestStatus.PADDLE_ERROR
        if backend_name == "torch":
            return TestStatus.TORCH_ERROR
        return TestStatus.ERROR


class _WorkerBackendError(Exception):
    """Internal: raised when a worker's exec_api fails."""

    def __init__(self, backend_name: str, message: str) -> None:
        self.backend_name = backend_name
        self.message = message
        super().__init__(f"{backend_name}: {message}")
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_tester/test_isolated_accuracy.py -v`
Expected: SKIP if not both frameworks; PASS if both available

**Step 5: Commit**

```bash
git add src/tensor_spec/tester/isolated_accuracy.py tests/test_tester/test_isolated_accuracy.py
git commit -m "feat(tester): add IsolatedAccuracyTester with process isolation"
```

---

## Task 9: CLI Updates — `--isolated` Mode

**Files:**
- Modify: `src/tensor_spec/cli.py` — add `--isolated`, `--python-a`, `--python-b` options to `accuracy` command
- Modify: `tests/test_cli.py` — add tests for isolated mode flags

**Step 1: Write the failing tests**

```python
# Add to tests/test_cli.py:

def test_accuracy_isolated_help():
    result = runner.invoke(app, ["accuracy", "--help"])
    assert result.exit_code == 0
    assert "--isolated" in result.output
    assert "--python-a" in result.output
    assert "--python-b" in result.output


def test_accuracy_isolated_missing_python_paths():
    result = runner.invoke(app, [
        "accuracy",
        "--backend-a", "paddle",
        "--backend-b", "torch",
        "--case", "abs(x=Tensor.float32((3,)))",
        "--isolated",
        # Missing --python-a and --python-b
    ])
    assert result.exit_code != 0
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_cli.py::test_accuracy_isolated_help -v`
Expected: FAIL (--isolated not in output)

**Step 3: Modify the accuracy command**

In `src/tensor_spec/cli.py`, update the `accuracy` command signature:

```python
@app.command()
def accuracy(
    backend_a: Annotated[str, typer.Option(help="First backend (e.g., paddle)")],
    backend_b: Annotated[str, typer.Option(help="Second backend (e.g., torch)")],
    case: Annotated[str, typer.Option(help="Case string")],
    seed: Annotated[int, typer.Option(help="Random seed")] = 42,
    tolerance_config: Annotated[str | None, typer.Option(help="Path to tolerance TOML")] = None,
    log_file: Annotated[str | None, typer.Option(help="Path to JSON Lines log file")] = None,
    isolated: Annotated[bool, typer.Option(help="Run backends in isolated subprocesses")] = False,
    python_a: Annotated[str | None, typer.Option(help="Python path for backend A venv")] = None,
    python_b: Annotated[str | None, typer.Option(help="Python path for backend B venv")] = None,
) -> None:
    """Run cross-framework accuracy comparison for a single case."""
    from tensor_spec.compare.comparator import NumpyComparator
    from tensor_spec.compare.tolerance import Tolerance
    from tensor_spec.log.writer import LogWriter
    from tensor_spec.mapping.registry import MappingRegistry
    from tensor_spec.tester.base import TestStatus

    try:
        case_config = parse_case(case)
    except ValueError as e:
        typer.echo(f"Parse error: {e}", err=True)
        raise typer.Exit(1) from e
    typer.echo(f"API: {case_config.api_name}")

    tol = Tolerance.from_toml(tolerance_config) if tolerance_config else Tolerance()

    mapping = MappingRegistry()
    mapping.load_bundled(backend_a)
    mapping.load_bundled(backend_b)

    if isolated:
        if not python_a or not python_b:
            typer.echo("--isolated requires --python-a and --python-b", err=True)
            raise typer.Exit(1)
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

        tester = IsolatedAccuracyTester(
            python_a=python_a,
            backend_a_name=backend_a,
            python_b=python_b,
            backend_b_name=backend_b,
            mapping=mapping,
            comparator=NumpyComparator(),
            tolerance=tol,
            generator=TensorGenerator(seed=seed),
        )
        result = tester.test(case_config)
        tester.shutdown()
    else:
        from tensor_spec.tester.accuracy import AccuracyTester

        ba = _load_backend(backend_a)
        bb = _load_backend(backend_b)
        ba.import_framework()
        bb.import_framework()

        tester = AccuracyTester(
            backend_a=ba,
            backend_b=bb,
            mapping=mapping,
            comparator=NumpyComparator(),
            tolerance=tol,
            generator=TensorGenerator(seed=seed),
        )
        result = tester.test(case_config)

    typer.echo(f"Status: {result.status.value}")
    if result.compare_result:
        typer.echo(f"  max_abs_diff: {result.compare_result.max_abs_diff:.6e}")
        typer.echo(f"  max_rel_diff: {result.compare_result.max_rel_diff:.6e}")
    if result.error:
        typer.echo(f"  error: {result.error}", err=True)

    if log_file:
        with LogWriter(log_file) as writer:
            writer.write(result)
        typer.echo(f"Log written to {log_file}")

    if result.status != TestStatus.PASSED:
        raise typer.Exit(1)
```

**Step 4: Run tests to verify they pass**

Run: `uv run --with pytest pytest tests/test_cli.py -v`
Expected: all tests pass (including new isolated help test)

**Step 5: Commit**

```bash
git add src/tensor_spec/cli.py tests/test_cli.py
git commit -m "feat(cli): add --isolated mode for process-isolated accuracy testing"
```

---

## Task 10: Integration Tests + Lint

**Files:**
- Modify: `tests/test_integration.py` — add process-isolation integration tests
- All files — lint pass

**Step 1: Write integration tests**

```python
# Add to tests/test_integration.py:

import sys

_has_both = False
try:
    import paddle  # noqa: F401
    import torch  # noqa: F401
    _has_both = True
except ImportError:
    pass


@pytest.mark.skipif(not _has_both, reason="Need both paddle and torch")
class TestIsolatedAccuracyIntegration:
    """End-to-end tests for process-isolated accuracy pipeline."""

    def test_isolated_abs(self):
        from tensor_spec.compare.comparator import NumpyComparator
        from tensor_spec.compare.tolerance import Tolerance
        from tensor_spec.datagen.generator import TensorGenerator
        from tensor_spec.mapping.registry import MappingRegistry
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester
        from tensor_spec.tester.base import TestStatus

        case_config = parse_case("abs(x=Tensor.float32((100,)))")
        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        tester = IsolatedAccuracyTester(
            python_a=sys.executable,
            backend_a_name="paddle",
            python_b=sys.executable,
            backend_b_name="torch",
            mapping=mapping,
            comparator=NumpyComparator(),
            tolerance=Tolerance(),
            generator=TensorGenerator(seed=42),
        )
        try:
            result = tester.test(case_config)
            assert result.status == TestStatus.PASSED
        finally:
            tester.shutdown()

    def test_isolated_matmul(self):
        from tensor_spec.compare.comparator import NumpyComparator
        from tensor_spec.compare.tolerance import Tolerance
        from tensor_spec.datagen.generator import TensorGenerator
        from tensor_spec.mapping.registry import MappingRegistry
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester
        from tensor_spec.tester.base import TestStatus

        case_config = parse_case("matmul(x=Tensor.float32((4, 3)), y=Tensor.float32((3, 5)))")
        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        tol = Tolerance()
        tester = IsolatedAccuracyTester(
            python_a=sys.executable,
            backend_a_name="paddle",
            python_b=sys.executable,
            backend_b_name="torch",
            mapping=mapping,
            comparator=NumpyComparator(),
            tolerance=tol,
            generator=TensorGenerator(seed=42),
        )
        try:
            result = tester.test(case_config)
            assert result.status == TestStatus.PASSED
        finally:
            tester.shutdown()

    def test_isolated_cli_smoke(self):
        """Smoke test: CLI accuracy --isolated works."""
        from typer.testing import CliRunner
        from tensor_spec.cli import app

        runner = CliRunner()
        result = runner.invoke(app, [
            "accuracy",
            "--backend-a", "paddle",
            "--backend-b", "torch",
            "--case", "abs(x=Tensor.float32((10,)))",
            "--isolated",
            "--python-a", sys.executable,
            "--python-b", sys.executable,
        ])
        assert result.exit_code == 0
        assert "pass" in result.output.lower()
```

**Step 2: Run tests to verify they fail**

Run: `uv run --with pytest pytest tests/test_integration.py::TestIsolatedAccuracyIntegration -v`
Expected: FAIL (test class doesn't exist yet) or SKIP (no frameworks)

**Step 3: Add the tests to the file (see code above)**

**Step 4: Run full test suite + lint**

```bash
uv run --with ruff ruff check src/ tests/
uv run --with ruff ruff format --check src/ tests/
uv run --with pytest pytest tests/ -v
```

Expected: all lint clean, all tests pass (framework-specific tests skip gracefully)

**Step 5: Commit**

```bash
git add tests/test_integration.py
git commit -m "test: add process-isolated accuracy integration tests"
```

Run lint fix if needed:
```bash
uv run --with ruff ruff check --fix src/ tests/
uv run --with ruff ruff format src/ tests/
git add -A && git commit -m "chore: lint and format Phase 2 code"
```

---

## Summary

| Task | Component | Key Deliverable |
|------|-----------|-----------------|
| 1 | SharedMemory transport | `ShmBuffer`, `write_array`, `read_array`, `unlink` |
| 2 | Worker protocol | `Request`, `Response`, `encode/decode_arg_value` |
| 3 | Worker process | `Worker` class with JSON-over-pipe main loop |
| 4 | Coordinator | `WorkerHandle`, `Coordinator` with high-level API |
| 5 | CUDA IPC handle | `CudaIpcMemHandle`, `get/open/close_ipc_handle` |
| 6 | GpuArrayView | `__cuda_array_interface__` wrapper |
| 7 | Worker GPU commands | `get/open/close_ipc_handle` handlers in worker + coordinator |
| 8 | IsolatedAccuracyTester | Process-isolated dual-backend tester |
| 9 | CLI --isolated mode | `--isolated`, `--python-a`, `--python-b` flags |
| 10 | Integration + lint | End-to-end tests, clean lint |

**CPU path (Tasks 1-4, 8-9):** Fully functional without GPU. Uses SharedMemory for numpy transport between coordinator and workers.

**GPU path (Tasks 5-7):** Requires CUDA. Tests skip gracefully on CPU-only machines. CUDA IPC handles exchange 64 bytes instead of copying gigabytes to CPU.
