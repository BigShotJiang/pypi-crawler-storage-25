# 文档系统 + CI + 测试架构 Implementation Plan

> ⚠️ **注意：** 本文档中的 CLI 命令示例（`validate`、`accuracy` 等）已被新设计取代。
> 当前 CLI 设计规格见 [docs/design/cli-specification.md](/docs/design/cli-specification.md)。

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a complete documentation site with zensical, set up 4 CI/CD workflows, and reorganize tests into unit + e2e layers.

**Architecture:** The project gets zensical-powered docs (MkDocs Material in TOML), GitHub Actions CI/CD (static checks, tests, docs deploy, tag-triggered release), and a restructured test suite with pytest-xdist/instafail/timeout/cov/xdoctest plugins. A justfile provides local developer commands.

**Tech Stack:** zensical, MkDocs Material, mkdocstrings-python, GitHub Actions, prek, pytest + 5 plugins, justfile, Codecov

**Design doc:** `docs/plans/2026-03-11-docs-ci-test-design.md`

---

### Task 1: Update pyproject.toml — dependency groups + pytest config

**Files:**
- Modify: `pyproject.toml` (entire file)

**Step 1: Replace pyproject.toml content**

Replace the `[project.optional-dependencies]` section with PEP 735 `[dependency-groups]`, and enhance `[tool.pytest.ini_options]`:

```toml
[project]
name = "tensor-spec"
version = "0.1.0"
description = "Framework-agnostic deep learning API quality verification tool"
requires-python = ">=3.12"
dependencies = [
    "numpy>=1.24",
    "typer>=0.9",
    "loguru>=0.7",
]

[project.scripts]
tensor-spec = "tensor_spec.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/tensor_spec"]

[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-xdist>=3.5",
    "pytest-instafail>=0.5",
    "pytest-timeout>=2.4",
    "pytest-cov>=5.0",
    "xdoctest>=1.3",
    "ruff>=0.4",
    "pyright>=1.1",
]
docs = [
    "mkdocstrings-python>=0.27",
    "pymdown-extensions>=10.0",
    "zensical>=0.3",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = ["--instafail", "--strict-markers", "--tb=short"]
markers = [
    "e2e: end-to-end tests",
    "slow: slow tests",
    "gpu: requires GPU",
]
timeout = 300
timeout_method = "thread"
```

**Step 2: Sync dependencies**

Run: `uv sync --group dev`
Expected: all new pytest plugins installed successfully

**Step 3: Commit**

```bash
git add pyproject.toml
git commit -m "build: add dependency-groups and enhance pytest config"
```

---

### Task 2: Reorganize tests into unit/ and e2e/ layers

**Files:**
- Create: `tests/conftest.py`
- Create: `tests/unit/__init__.py`
- Create: `tests/e2e/__init__.py`
- Move: `tests/test_backend/` → `tests/unit/test_backend/`
- Move: `tests/test_compare/` → `tests/unit/test_compare/`
- Move: `tests/test_config/` → `tests/unit/test_config/`
- Move: `tests/test_datagen/` → `tests/unit/test_datagen/`
- Move: `tests/test_ipc/` → `tests/unit/test_ipc/`
- Move: `tests/test_log/` → `tests/unit/test_log/`
- Move: `tests/test_mapping/` → `tests/unit/test_mapping/`
- Move: `tests/test_spec/` → `tests/unit/test_spec/`
- Move: `tests/test_tester/` → `tests/unit/test_tester/`
- Move: `tests/test_worker/` → `tests/unit/test_worker/`
- Move: `tests/test_cli.py` → `tests/e2e/test_cli.py`
- Move: `tests/test_integration.py` → `tests/e2e/test_accuracy_pipeline.py`

**Step 1: Create directory structure and move files**

```bash
mkdir -p tests/unit tests/e2e
touch tests/unit/__init__.py tests/e2e/__init__.py

# Move all test_* directories into unit/
for dir in tests/test_backend tests/test_compare tests/test_config tests/test_datagen tests/test_ipc tests/test_log tests/test_mapping tests/test_spec tests/test_tester tests/test_worker; do
    git mv "$dir" tests/unit/
done

# Move CLI and integration tests into e2e/
git mv tests/test_cli.py tests/e2e/test_cli.py
git mv tests/test_integration.py tests/e2e/test_accuracy_pipeline.py
```

**Step 2: Create tests/conftest.py**

```python
"""Shared test fixtures."""
```

(Minimal for now — fixtures will be added as needed.)

**Step 3: Run tests to verify nothing is broken**

Run: `uv run pytest tests/ -v --tb=short`
Expected: all existing tests PASS (same count as before the move)

**Step 4: Verify parallel execution works**

Run: `uv run pytest tests/unit -n auto -v`
Expected: tests run in parallel, all PASS

**Step 5: Commit**

```bash
git add tests/
git commit -m "refactor(tests): reorganize into unit/ and e2e/ layers"
```

---

### Task 3: Create justfile

**Files:**
- Create: `justfile`

**Step 1: Write justfile**

```just
# tensor-spec developer commands

# Install all dependency groups
install:
    uv sync --all-groups

# Linting
lint:
    uvx ruff check src/ tests/
    uvx ruff format --check src/ tests/

# Auto-fix lint issues
fmt:
    uvx ruff format src/ tests/
    uvx ruff check --fix src/ tests/

# Type checking
typecheck:
    uv run pyright src/

# Run all tests
test: test-unit test-e2e

# Run unit tests with parallel execution and doctest
test-unit:
    uv run pytest tests/unit -n auto --xdoc

# Run end-to-end tests sequentially
test-e2e:
    uv run pytest tests/e2e -v

# Run tests with coverage
cov:
    uv run pytest tests/unit -n auto --xdoc --cov=tensor_spec --cov-report=html --cov-report=xml
    uv run coverage xml

# Serve docs locally with live reload
docs:
    uv run zensical serve

# Build docs for deployment
docs-build:
    uv run zensical build
```

**Step 2: Verify justfile works**

Run: `just test-unit`
Expected: unit tests run in parallel, all PASS

Run: `just lint`
Expected: ruff check + format pass (or show existing lint issues)

**Step 3: Commit**

```bash
git add justfile
git commit -m "build: add justfile for developer commands"
```

---

### Task 4: Create prek.toml

**Files:**
- Create: `prek.toml`

**Step 1: Write prek.toml**

```toml
[[repos]]
repo = "https://github.com/pre-commit/pre-commit-hooks"
rev = "v5.0.0"
hooks = [
    { id = "trailing-whitespace" },
    { id = "end-of-file-fixer" },
    { id = "check-yaml" },
    { id = "check-added-large-files" },
    { id = "check-case-conflict" },
    { id = "check-merge-conflict" },
]

[[repos]]
repo = "https://github.com/astral-sh/ruff-pre-commit"
rev = "v0.11.2"
hooks = [
    { id = "ruff", args = ["--fix"] },
    { id = "ruff-format" },
]

[[repos]]
repo = "https://github.com/crate-ci/typos"
rev = "v1.31.1"
hooks = [
    { id = "typos" },
]
```

**Step 2: Create _typos.toml for false positive suppression**

```toml
[default.extend-words]
# Add any false positive words here as needed
```

**Step 3: Commit**

```bash
git add prek.toml _typos.toml
git commit -m "build: add prek pre-commit hooks config"
```

---

### Task 5: Create codecov.yml

**Files:**
- Create: `codecov.yml`

**Step 1: Write codecov.yml**

```yaml
coverage:
  status:
    project:
      default:
        target: 80%
    patch:
      default:
        target: 90%
```

**Step 2: Commit**

```bash
git add codecov.yml
git commit -m "ci: add Codecov coverage targets"
```

---

### Task 6: Migrate root-level docs into docs/design/

**Files:**
- Move: `architecture_design.md` → `docs/design/architecture.md`
- Move: `design_decisions.md` → `docs/design/decisions.md`
- Move: `case_representation_design.md` → `docs/design/case-representation.md`
- Move: `design_four_questions.md` → `docs/design/modernization.md`
- Move: `PaddleAPITest_analysis.md` → `docs/design/legacy-analysis.md`
- Move: `IMPLEMENTATION_PROMPT.md` → `docs/design/implementation-prompt.md`
- Move: `docs/design_rationale.md` → `docs/rationale.md`

**Step 1: Create docs/design/ and move files**

```bash
mkdir -p docs/design

git mv architecture_design.md docs/design/architecture.md
git mv design_decisions.md docs/design/decisions.md
git mv case_representation_design.md docs/design/case-representation.md
git mv design_four_questions.md docs/design/modernization.md
git mv PaddleAPITest_analysis.md docs/design/legacy-analysis.md
git mv IMPLEMENTATION_PROMPT.md docs/design/implementation-prompt.md
git mv docs/design_rationale.md docs/rationale.md
```

**Step 2: Verify no broken references**

Run: `grep -r "architecture_design\|design_decisions\|case_representation\|design_four_questions\|PaddleAPITest_analysis\|IMPLEMENTATION_PROMPT\|design_rationale" src/ tests/ docs/ --include="*.py" --include="*.md" | head -20`
Expected: if any references found, update them to new paths

**Step 3: Commit**

```bash
git add -A
git commit -m "docs: migrate root-level design docs into docs/design/"
```

---

### Task 7: Create zensical.toml + docs skeleton

**Files:**
- Create: `zensical.toml`
- Create: `docs/index.md`
- Create: `docs/api/index.md`

**Step 1: Write zensical.toml**

```toml
[project]
name = "tensor-spec"
url = ""

[build]
docs_dir = "docs"

[theme]
name = "material"
palette = [
    { scheme = "default", primary = "indigo", accent = "indigo", toggle = { icon = "material/brightness-7", name = "Switch to dark mode" } },
    { scheme = "slate", primary = "indigo", accent = "indigo", toggle = { icon = "material/brightness-4", name = "Switch to light mode" } },
]
features = [
    "navigation.instant",
    "navigation.tabs",
    "navigation.sections",
    "navigation.expand",
    "search.suggest",
    "search.highlight",
    "content.code.copy",
    "content.code.annotate",
]

[nav]
items = [
    { "Home" = "index.md" },
    { "Design Rationale" = "rationale.md" },
    { "Design" = [
        { "Architecture" = "design/architecture.md" },
        { "Decisions" = "design/decisions.md" },
        { "Case Representation" = "design/case-representation.md" },
        { "Modernization" = "design/modernization.md" },
        { "Legacy Analysis" = "design/legacy-analysis.md" },
    ] },
    { "Plans" = [
        { "Phase 0: Foundation" = "plans/2026-03-03-phase0-implementation.md" },
        { "Phase 1: Accuracy" = "plans/2026-03-05-phase1-cross-framework-accuracy.md" },
        { "Phase 2: Isolation" = "plans/2026-03-05-phase2-process-isolation-ipc.md" },
        { "Docs + CI + Tests" = "plans/2026-03-11-docs-ci-test-design.md" },
    ] },
{ "API Reference" = "api/index.md" },
]

[plugins.mkdocstrings]
handlers.python.options.show_source = true
handlers.python.options.show_root_heading = true
handlers.python.options.docstring_style = "google"
handlers.python.paths = ["src"]

[plugins.search]

[markdown_extensions]
pymdownx.highlight = { anchor_linenums = true }
pymdownx.superfences = {}
pymdownx.tabbed = { alternate_style = true }
pymdownx.tasklist = { custom_checkbox = true }
admonition = {}
pymdownx.details = {}
toc = { permalink = true }
```

**Step 2: Write docs/index.md**

```markdown
# tensor-spec

**Framework-agnostic deep learning API quality verification tool.**

tensor-spec compares tensor operation precision across deep learning frameworks (currently PaddlePaddle vs PyTorch) using process isolation and CUDA IPC zero-copy GPU data sharing.

## Quick Start

```bash
# Install
uv pip install tensor-spec

# Validate a case string
tensor-spec validate "abs(x=Tensor.float32((2, 3)))"

# Run cross-framework accuracy comparison
tensor-spec accuracy --case "abs(x=Tensor.float32((2, 3)))"
```

## Architecture

The tool uses a 10-layer architecture with separate venvs for each framework to avoid CUDA runtime conflicts. GPU tensors are shared zero-copy via CUDA IPC handles.

See [Architecture Design](design/architecture.md) for details.

## Documentation

- [Design Rationale](rationale.md) — Quick reference for all design decisions
- [Design Documents](design/architecture.md) — Detailed architecture and design docs
- [Implementation Plans](plans/2026-03-03-phase0-implementation.md) — Phase-by-phase plans
- [API Reference](api/index.md) — Auto-generated from source code
```

**Step 3: Write docs/api/index.md**

```markdown
# API Reference

::: tensor_spec
    options:
      show_submodules: true
```

**Step 4: Test docs build**

Run: `uv sync --group docs && uv run zensical build`
Expected: docs build successfully into `site/` directory

**Step 5: Add `site/` to .gitignore**

Append to `.gitignore`:
```
site/
```

**Step 6: Commit**

```bash
git add zensical.toml docs/index.md docs/api/index.md .gitignore
git commit -m "docs: add zensical config and docs site skeleton"
```

---

### Task 8: Create CI workflow — ci-static-checks.yml

**Files:**
- Create: `.github/workflows/ci-static-checks.yml`

**Step 1: Write the workflow**

```yaml
name: CI - Static Checks

on:
  push:
    branches: [main]
  pull_request:

jobs:
  static-checks:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: j178/prek-action@v1
```

**Step 2: Commit**

```bash
mkdir -p .github/workflows
git add .github/workflows/ci-static-checks.yml
git commit -m "ci: add static checks workflow (prek + ruff + typos)"
```

---

### Task 9: Create CI workflow — ci-tests.yml

**Files:**
- Create: `.github/workflows/ci-tests.yml`

**Step 1: Write the workflow**

```yaml
name: CI - Tests

on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: extractions/setup-just@v3

      - uses: astral-sh/setup-uv@v6

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install dependencies
        run: just install

      - name: Run unit tests with coverage
        run: |
          uv run pytest tests/unit -n auto --xdoc \
            --cov=tensor_spec --cov-report=xml

      - name: Run e2e tests
        run: just test-e2e

      - name: Upload coverage to Codecov
        uses: codecov/codecov-action@v5
        with:
          files: coverage.xml
          fail_ci_if_error: false
```

**Step 2: Commit**

```bash
git add .github/workflows/ci-tests.yml
git commit -m "ci: add test workflow with coverage and Codecov"
```

---

### Task 10: Create CD workflow — cd-docs.yml

**Files:**
- Create: `.github/workflows/cd-docs.yml`

**Step 1: Write the workflow**

```yaml
name: CD - Documentation

on:
  push:
    branches: [main]

permissions:
  contents: write

jobs:
  docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: astral-sh/setup-uv@v6

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install docs dependencies
        run: uv sync --group docs

      - name: Build documentation
        run: uv run zensical build

      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v4
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./site
          publish_branch: docs
```

**Step 2: Commit**

```bash
git add .github/workflows/cd-docs.yml
git commit -m "cd: add documentation build and deploy workflow"
```

---

### Task 11: Create CD workflow — cd-release.yml

**Files:**
- Create: `.github/workflows/cd-release.yml`

**Step 1: Write the workflow**

```yaml
name: CD - Release

on:
  push:
    tags: ["v*"]

permissions:
  contents: write

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: astral-sh/setup-uv@v6

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Build wheel
        run: uv build --wheel

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          files: dist/*
          generate_release_notes: true
```

**Step 2: Commit**

```bash
git add .github/workflows/cd-release.yml
git commit -m "cd: add tag-triggered release workflow"
```

---

### Task 12: Local verification

**Files:** (none — verification only)

**Step 1: Run lint**

Run: `just lint`
Expected: ruff check + format pass (fix any issues found)

**Step 2: Run unit tests**

Run: `just test-unit`
Expected: all unit tests PASS with parallel execution

**Step 3: Run e2e tests**

Run: `just test-e2e`
Expected: all e2e tests PASS

**Step 4: Run coverage**

Run: `just cov`
Expected: coverage report generated, check percentage

**Step 5: Build docs**

Run: `just docs-build`
Expected: `site/` directory created with rendered HTML

**Step 6: Final commit if any fixes were needed**

```bash
git add -A
git commit -m "fix: address lint/test issues from local verification"
```
