# Phase 0: tensor-spec Foundation Implementation Plan

> ⚠️ **注意：** 本文档中的 CLI 命令设计（`run`、`validate` 等）已被新设计取代。
> 当前 CLI 设计规格见 [docs/design/cli-specification.md](/docs/design/cli-specification.md)。
> 本文档中的模块实现细节（spec、config、datagen、backend 等）仍然有效。

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build the foundation of tensor-spec so it can parse case strings, generate data, and run single-framework single-case tests for abs, add, matmul.

**Architecture:** 10-layer architecture (spec → config → datagen → backend → ... → cli). Phase 0 implements spec, config, datagen, backend (paddle only), and cli layers. All dataclasses use `frozen=True, slots=True`. The spec layer has zero framework dependencies. The config parser uses whitelist recursive descent (no eval). Data generation is constraint-driven via a pipeline of Constraint objects.

**Tech Stack:** Python 3.10+, uv, dataclasses, numpy (datagen only), ruff, pytest, click

---

### Task 1: Project Skeleton

**Files:**
- Create: `pyproject.toml`
- Create: `src/tensor_spec/__init__.py`
- Create: `src/tensor_spec/py.typed`
- Create: `tests/__init__.py`
- Create: `ruff.toml`

**Step 1: Create pyproject.toml**

```toml
[project]
name = "tensor-spec"
version = "0.1.0"
description = "Framework-agnostic deep learning API quality verification tool"
requires-python = ">=3.10"
dependencies = [
    "numpy>=1.24",
    "click>=8.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "ruff>=0.4",
]
paddle = [
    "paddlepaddle>=2.6",
]

[project.scripts]
tensor-spec = "tensor_spec.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/tensor_spec"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

**Step 2: Create ruff.toml**

```toml
line-length = 120
target-version = "py310"

[lint]
select = ["E", "F", "I", "UP", "B", "SIM"]

[format]
quote-style = "double"
```

**Step 3: Create src/tensor_spec/__init__.py**

```python
"""tensor-spec: Framework-agnostic deep learning API quality verification tool."""
```

**Step 4: Create src/tensor_spec/py.typed and tests/__init__.py**

Empty marker files.

**Step 5: Initialize uv project and install**

Run: `cd /workspace/tensor-spec && uv sync --dev`
Expected: Dependencies installed, project editable-installed.

**Step 6: Verify**

Run: `cd /workspace/tensor-spec && uv run python -c "import tensor_spec; print('OK')"`
Expected: `OK`

**Step 7: Commit**

```bash
git init
git add pyproject.toml ruff.toml src/ tests/__init__.py
git commit -m "feat: project skeleton with uv, ruff, pytest"
```

---

### Task 2: spec/device.py — DeviceSpec

**Files:**
- Create: `src/tensor_spec/spec/__init__.py`
- Create: `src/tensor_spec/spec/device.py`
- Test: `tests/test_spec/test_device.py`

**Step 1: Write the failing test**

```python
# tests/test_spec/__init__.py (empty)
# tests/test_spec/test_device.py
from tensor_spec.spec.device import Device, DeviceSpec


def test_device_spec_creation():
    d = DeviceSpec(type="cuda", index=0)
    assert d.type == "cuda"
    assert d.index == 0


def test_device_spec_frozen():
    d = DeviceSpec(type="cpu", index=0)
    try:
        d.type = "cuda"
        assert False, "Should be frozen"
    except AttributeError:
        pass


def test_device_cuda():
    d = Device.cuda(0)
    assert d.type == "cuda"
    assert d.index == 0


def test_device_cpu():
    d = Device.cpu()
    assert d.type == "cpu"
    assert d.index == 0


def test_device_xpu():
    d = Device.xpu(1)
    assert d.type == "xpu"
    assert d.index == 1
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_spec/test_device.py -v`
Expected: FAIL (import error)

**Step 3: Write implementation**

```python
# src/tensor_spec/spec/__init__.py
"""Tensor specification layer — zero framework dependencies."""

# src/tensor_spec/spec/device.py
"""Device specification."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DeviceSpec:
    """Specification for a device (cuda, cpu, xpu, etc.)."""

    type: str
    index: int = 0

    def __str__(self) -> str:
        if self.type == "cpu":
            return "cpu"
        return f"{self.type}:{self.index}"


class Device:
    """Namespace class with factory methods for creating DeviceSpec."""

    @staticmethod
    def cuda(index: int = 0) -> DeviceSpec:
        return DeviceSpec(type="cuda", index=index)

    @staticmethod
    def cpu() -> DeviceSpec:
        return DeviceSpec(type="cpu", index=0)

    @staticmethod
    def xpu(index: int = 0) -> DeviceSpec:
        return DeviceSpec(type="xpu", index=index)
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_spec/test_device.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/spec/ tests/test_spec/
git commit -m "feat(spec): add DeviceSpec and Device factory"
```

---

### Task 3: spec/state.py — TensorState

**Files:**
- Create: `src/tensor_spec/spec/state.py`
- Test: `tests/test_spec/test_state.py`

**Step 1: Write the failing test**

```python
# tests/test_spec/test_state.py
from tensor_spec.spec.state import TensorState


def test_tensor_state_defaults():
    s = TensorState()
    assert s.need_grad is None
    assert s.is_contiguous is True


def test_tensor_state_custom():
    s = TensorState(need_grad=True, is_contiguous=False)
    assert s.need_grad is True
    assert s.is_contiguous is False


def test_tensor_state_frozen():
    s = TensorState()
    try:
        s.need_grad = True
        assert False, "Should be frozen"
    except AttributeError:
        pass
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_spec/test_state.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/spec/state.py
"""Tensor state specification (grad, contiguity, etc.)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TensorState:
    """State of a tensor (gradient requirements, memory layout, etc.)."""

    need_grad: bool | None = None
    is_contiguous: bool = True
    stop_gradient: bool | None = None
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_spec/test_state.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/spec/state.py tests/test_spec/test_state.py
git commit -m "feat(spec): add TensorState dataclass"
```

---

### Task 4: spec/stats.py — Stats Dataclasses

**Files:**
- Create: `src/tensor_spec/spec/stats.py`
- Test: `tests/test_spec/test_stats.py`

**Step 1: Write the failing test**

```python
# tests/test_spec/test_stats.py
import pytest

from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats


def test_float_stats_defaults():
    s = FloatStats()
    assert s.min == -0.5
    assert s.max == 0.5
    assert s.nonzero is False
    assert s.positive_definite is False


def test_float_stats_custom():
    s = FloatStats(min=-10.0, max=10.0, nonzero=True)
    assert s.min == -10.0
    assert s.nonzero is True


def test_float_stats_invalid_range():
    with pytest.raises(ValueError, match="min.*must.*< max"):
        FloatStats(min=5.0, max=3.0)


def test_float_stats_equal_range():
    with pytest.raises(ValueError):
        FloatStats(min=1.0, max=1.0)


def test_int_stats_defaults():
    s = IntStats()
    assert s.low == -65535
    assert s.high == 65535


def test_int_stats_invalid_range():
    with pytest.raises(ValueError):
        IntStats(low=10, high=5)


def test_bool_stats_defaults():
    s = BoolStats()
    assert s.true_ratio == 0.5


def test_bool_stats_invalid_ratio():
    with pytest.raises(ValueError):
        BoolStats(true_ratio=1.5)


def test_complex_stats_defaults():
    s = ComplexStats()
    assert s.real_min == -0.5
    assert s.real_max == 0.5
    assert s.imag_min == -0.5
    assert s.imag_max == 0.5


def test_all_stats_frozen():
    s = FloatStats()
    with pytest.raises(AttributeError):
        s.min = 1.0
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_spec/test_stats.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/spec/stats.py
"""Statistical constraints for tensor data generation."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class FloatStats:
    """Statistical constraints for float tensors."""

    min: float = -0.5
    max: float = 0.5
    nonzero: bool = False
    positive: bool = False
    positive_definite: bool = False
    symmetric: bool = False
    normalized: bool = False
    unique: bool = False
    has_nan: bool = False
    has_inf: bool = False

    def __post_init__(self) -> None:
        if self.min >= self.max:
            raise ValueError(f"min({self.min}) must be < max({self.max})")


@dataclass(frozen=True, slots=True)
class IntStats:
    """Statistical constraints for integer tensors."""

    low: int = -65535
    high: int = 65535
    nonzero: bool = False
    unique: bool = False
    sorted: bool = False

    def __post_init__(self) -> None:
        if self.low >= self.high:
            raise ValueError(f"low({self.low}) must be < high({self.high})")


@dataclass(frozen=True, slots=True)
class BoolStats:
    """Statistical constraints for boolean tensors."""

    true_ratio: float = 0.5
    all_true: bool = False
    all_false: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.true_ratio <= 1.0:
            raise ValueError(f"true_ratio must be in [0, 1], got {self.true_ratio}")


@dataclass(frozen=True, slots=True)
class ComplexStats:
    """Statistical constraints for complex tensors."""

    real_min: float = -0.5
    real_max: float = 0.5
    imag_min: float = -0.5
    imag_max: float = 0.5
    hermitian: bool = False

    def __post_init__(self) -> None:
        if self.real_min >= self.real_max:
            raise ValueError(f"real_min({self.real_min}) must be < real_max({self.real_max})")
        if self.imag_min >= self.imag_max:
            raise ValueError(f"imag_min({self.imag_min}) must be < imag_max({self.imag_max})")
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_spec/test_stats.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/spec/stats.py tests/test_spec/test_stats.py
git commit -m "feat(spec): add FloatStats, IntStats, BoolStats, ComplexStats"
```

---

### Task 5: spec/tensor.py — TensorSpec + Tensor Factory

**Files:**
- Create: `src/tensor_spec/spec/tensor.py`
- Test: `tests/test_spec/test_tensor.py`

**Step 1: Write the failing test**

```python
# tests/test_spec/test_tensor.py
import pytest

from tensor_spec.spec.device import Device
from tensor_spec.spec.stats import FloatStats, IntStats
from tensor_spec.spec.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    Tensor,
    TensorSpec,
)


def test_tensor_float32_factory():
    spec = Tensor.float32((2, 3))
    assert isinstance(spec, FloatTensorSpec)
    assert spec.shape == (2, 3)
    assert spec.dtype == "float32"
    assert spec.device is None
    assert spec.stats is None
    assert spec.state is None


def test_tensor_float64_with_device():
    spec = Tensor.float64((1, 100), Device.cuda(0))
    assert spec.dtype == "float64"
    assert spec.device is not None
    assert spec.device.type == "cuda"


def test_tensor_int64_factory():
    spec = Tensor.int64((10,))
    assert isinstance(spec, IntTensorSpec)
    assert spec.dtype == "int64"


def test_tensor_bool_factory():
    spec = Tensor.bool((3, 3))
    assert isinstance(spec, BoolTensorSpec)
    assert spec.dtype == "bool"


def test_tensor_complex64_factory():
    spec = Tensor.complex64((2, 3))
    assert isinstance(spec, ComplexTensorSpec)
    assert spec.dtype == "complex64"


def test_float_tensor_spec_with_stats():
    base = Tensor.float32((4, 4))
    spec = base.with_stats(FloatStats(positive_definite=True))
    assert spec.stats is not None
    assert spec.stats.positive_definite is True
    # Original unchanged (frozen)
    assert base.stats is None


def test_float_tensor_spec_with_state():
    from tensor_spec.spec.state import TensorState

    base = Tensor.float32((2, 3))
    spec = base.with_state(TensorState(need_grad=True))
    assert spec.state is not None
    assert spec.state.need_grad is True


def test_all_float_dtypes():
    for dtype in ["float16", "float32", "float64", "bfloat16"]:
        spec = getattr(Tensor, dtype)((2,))
        assert isinstance(spec, FloatTensorSpec)
        assert spec.dtype == dtype


def test_all_int_dtypes():
    for dtype in ["int8", "int16", "int32", "int64", "uint8"]:
        spec = getattr(Tensor, dtype)((2,))
        assert isinstance(spec, IntTensorSpec)
        assert spec.dtype == dtype


def test_tensor_spec_frozen():
    spec = Tensor.float32((2, 3))
    with pytest.raises(AttributeError):
        spec.shape = (4, 5)
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_spec/test_tensor.py -v`
Expected: FAIL

**Step 3: Write implementation**

Since dataclasses are `frozen=True`, we can't use mutable `.stats()` / `.state()` chain methods that mutate self. Instead we provide `with_stats()` and `with_state()` methods that return new instances via `dataclasses.replace()`. The parser will call these when it encounters `.stats()` / `.state()` in the case string.

```python
# src/tensor_spec/spec/tensor.py
"""Tensor specifications and the Tensor factory class."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tensor_spec.spec.device import DeviceSpec
    from tensor_spec.spec.state import TensorState
    from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats


@dataclass(frozen=True, slots=True)
class TensorSpec:
    """Base class for all tensor specifications."""

    shape: tuple[int, ...]
    dtype: str
    device: DeviceSpec | None = None
    state: TensorState | None = None


@dataclass(frozen=True, slots=True)
class FloatTensorSpec(TensorSpec):
    """Specification for float tensors (float16, float32, float64, bfloat16)."""

    stats: FloatStats | None = None

    def with_stats(self, stats: FloatStats) -> FloatTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> FloatTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class IntTensorSpec(TensorSpec):
    """Specification for integer tensors (int8-64, uint8)."""

    stats: IntStats | None = None

    def with_stats(self, stats: IntStats) -> IntTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> IntTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class BoolTensorSpec(TensorSpec):
    """Specification for boolean tensors."""

    stats: BoolStats | None = None

    def with_stats(self, stats: BoolStats) -> BoolTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> BoolTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class ComplexTensorSpec(TensorSpec):
    """Specification for complex tensors (complex64, complex128)."""

    stats: ComplexStats | None = None

    def with_stats(self, stats: ComplexStats) -> ComplexTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> ComplexTensorSpec:
        return replace(self, state=state)


# Dtype → (SpecClass, kind)
_DTYPE_MAP: dict[str, type[TensorSpec]] = {
    "float16": FloatTensorSpec,
    "float32": FloatTensorSpec,
    "float64": FloatTensorSpec,
    "bfloat16": FloatTensorSpec,
    "int8": IntTensorSpec,
    "int16": IntTensorSpec,
    "int32": IntTensorSpec,
    "int64": IntTensorSpec,
    "uint8": IntTensorSpec,
    "bool": BoolTensorSpec,
    "complex64": ComplexTensorSpec,
    "complex128": ComplexTensorSpec,
}


class Tensor:
    """Namespace class with factory methods for creating TensorSpec instances.

    Usage: Tensor.float32((2, 3)) -> FloatTensorSpec
    """

    @classmethod
    def _make(cls, dtype: str, shape: tuple[int, ...], device: DeviceSpec | None = None) -> TensorSpec:
        spec_cls = _DTYPE_MAP.get(dtype)
        if spec_cls is None:
            raise ValueError(f"Unsupported dtype: {dtype}")
        return spec_cls(shape=shape, dtype=dtype, device=device)

    # Float family
    @classmethod
    def float16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float16", device=device)

    @classmethod
    def float32(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float32", device=device)

    @classmethod
    def float64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float64", device=device)

    @classmethod
    def bfloat16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="bfloat16", device=device)

    # Int family
    @classmethod
    def int8(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int8", device=device)

    @classmethod
    def int16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int16", device=device)

    @classmethod
    def int32(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int32", device=device)

    @classmethod
    def int64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int64", device=device)

    @classmethod
    def uint8(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="uint8", device=device)

    # Bool
    @classmethod
    def bool(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> BoolTensorSpec:
        return BoolTensorSpec(shape=shape, dtype="bool", device=device)

    # Complex family
    @classmethod
    def complex64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> ComplexTensorSpec:
        return ComplexTensorSpec(shape=shape, dtype="complex64", device=device)

    @classmethod
    def complex128(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> ComplexTensorSpec:
        return ComplexTensorSpec(shape=shape, dtype="complex128", device=device)
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_spec/test_tensor.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/spec/tensor.py tests/test_spec/test_tensor.py
git commit -m "feat(spec): add TensorSpec hierarchy and Tensor factory"
```

---

### Task 6: config/case.py — CaseConfig

**Files:**
- Create: `src/tensor_spec/config/__init__.py`
- Create: `src/tensor_spec/config/case.py`
- Test: `tests/test_config/__init__.py`
- Test: `tests/test_config/test_case.py`

**Step 1: Write the failing test**

```python
# tests/test_config/test_case.py
import pytest

from tensor_spec.config.case import CaseConfig
from tensor_spec.spec.tensor import Tensor


def test_case_config_basic():
    spec = Tensor.float64((1, 100))
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": spec},
    )
    assert case.api_name == "abs"
    assert case.kwargs["x"] is spec


def test_case_config_frozen():
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    with pytest.raises(AttributeError):
        case.api_name = "add"


def test_case_config_with_scalar_kwargs():
    case = CaseConfig(
        api_name="nn.conv2d",
        args=(),
        kwargs={
            "x": Tensor.float32((1, 3, 224, 224)),
            "weight": Tensor.float32((64, 3, 7, 7)),
            "stride": 2,
            "padding": 3,
        },
    )
    assert case.kwargs["stride"] == 2


def test_case_config_tensor_specs():
    case = CaseConfig(
        api_name="add",
        args=(),
        kwargs={
            "x": Tensor.float32((2, 3)),
            "y": Tensor.float32((2, 3)),
        },
    )
    specs = case.tensor_specs
    assert len(specs) == 2
    assert "x" in specs
    assert "y" in specs
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_config/test_case.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/config/__init__.py
"""Configuration parsing and case representation."""

# src/tensor_spec/config/case.py
"""CaseConfig: represents a single API test case."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tensor_spec.spec.tensor import TensorSpec


@dataclass(frozen=True, slots=True)
class CaseConfig:
    """A single API test case configuration.

    Attributes:
        api_name: Framework-agnostic API name (e.g., "abs", "nn.conv2d").
        args: Positional arguments (tuple of TensorSpec, scalars, etc.).
        kwargs: Keyword arguments (dict of name -> TensorSpec, scalars, etc.).
    """

    api_name: str
    args: tuple[Any, ...]
    kwargs: dict[str, Any]

    @property
    def tensor_specs(self) -> dict[str, TensorSpec]:
        """Extract all TensorSpec values from kwargs."""
        return {k: v for k, v in self.kwargs.items() if isinstance(v, TensorSpec)}
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_config/test_case.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/config/ tests/test_config/
git commit -m "feat(config): add CaseConfig dataclass"
```

---

### Task 7: config/parser.py — Recursive Descent Parser

**Files:**
- Create: `src/tensor_spec/config/parser.py`
- Test: `tests/test_config/test_parser.py`

This is the largest and most complex task. The parser tokenizes a case string and builds a CaseConfig via recursive descent. No eval() is used. Only whitelisted constructors (Tensor, Device, tuple, list, slice, None, True, False, int, float, str) are allowed.

**Step 1: Write the failing test**

```python
# tests/test_config/test_parser.py
import pytest

from tensor_spec.config.case import CaseConfig
from tensor_spec.config.parser import parse_case
from tensor_spec.spec.tensor import FloatTensorSpec, IntTensorSpec, BoolTensorSpec


class TestParseSimple:
    def test_abs(self):
        case = parse_case("abs(x=Tensor.float64((1, 100)))")
        assert case.api_name == "abs"
        assert "x" in case.kwargs
        spec = case.kwargs["x"]
        assert isinstance(spec, FloatTensorSpec)
        assert spec.dtype == "float64"
        assert spec.shape == (1, 100)

    def test_add(self):
        case = parse_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))")
        assert case.api_name == "add"
        assert len(case.kwargs) == 2
        assert case.kwargs["x"].shape == (2, 3)
        assert case.kwargs["y"].shape == (2, 3)


class TestParseNamespaced:
    def test_linalg_cholesky(self):
        case = parse_case("linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))")
        assert case.api_name == "linalg.cholesky"
        spec = case.kwargs["x"]
        assert isinstance(spec, FloatTensorSpec)
        assert spec.stats is not None
        assert spec.stats.positive_definite is True

    def test_nn_conv2d(self):
        case = parse_case(
            "nn.conv2d(x=Tensor.float32((1, 3, 224, 224)).state(need_grad=True), "
            "weight=Tensor.float32((64, 3, 7, 7)), stride=2, padding=3)"
        )
        assert case.api_name == "nn.conv2d"
        assert case.kwargs["stride"] == 2
        assert case.kwargs["padding"] == 3
        spec_x = case.kwargs["x"]
        assert spec_x.state is not None
        assert spec_x.state.need_grad is True


class TestParseScalars:
    def test_int_kwarg(self):
        case = parse_case("cumsum(x=Tensor.float32((3, 4, 5)), axis=1)")
        assert case.kwargs["axis"] == 1

    def test_float_kwarg(self):
        case = parse_case("clip(x=Tensor.float32((3,)), min=-1.5, max=2.5)")
        assert case.kwargs["min"] == -1.5
        assert case.kwargs["max"] == 2.5

    def test_negative_int(self):
        case = parse_case("roll(x=Tensor.float32((4, 5)), shifts=-1, axis=0)")
        assert case.kwargs["shifts"] == -1

    def test_bool_kwarg(self):
        case = parse_case("sum(x=Tensor.float32((3, 4)), keepdim=True)")
        assert case.kwargs["keepdim"] is True

    def test_none_kwarg(self):
        case = parse_case("sum(x=Tensor.float32((3, 4)), axis=None)")
        assert case.kwargs["axis"] is None

    def test_string_kwarg(self):
        case = parse_case('pad(x=Tensor.float32((1, 3, 4)), pad=[1, 1], mode="constant")')
        assert case.kwargs["mode"] == "constant"


class TestParseContainers:
    def test_list_kwarg(self):
        case = parse_case("pad(x=Tensor.float32((1, 3, 4)), pad=[1, 2, 3, 4])")
        assert case.kwargs["pad"] == [1, 2, 3, 4]

    def test_tuple_kwarg(self):
        case = parse_case("reshape(x=Tensor.float32((6,)), shape=(2, 3))")
        assert case.kwargs["shape"] == (2, 3)


class TestParseTuplePositional:
    def test_concat_tuple_of_tensors(self):
        case = parse_case(
            "concat(tuple(Tensor.float32((31376, 768)), Tensor.float32((1, 768))), axis=0)"
        )
        assert case.api_name == "concat"
        assert isinstance(case.args[0], tuple)
        assert len(case.args[0]) == 2
        assert case.args[0][0].shape == (31376, 768)


class TestParseStats:
    def test_float_stats(self):
        case = parse_case("abs(x=Tensor.float32((4, 4)).stats(min=-10.0, max=10.0))")
        spec = case.kwargs["x"]
        assert spec.stats.min == -10.0
        assert spec.stats.max == 10.0

    def test_int_stats(self):
        case = parse_case("scatter(index=Tensor.int64((5, 3)).stats(low=0, high=3))")
        spec = case.kwargs["index"]
        assert isinstance(spec, IntTensorSpec)
        assert spec.stats.low == 0
        assert spec.stats.high == 3


class TestParseErrors:
    def test_empty_string(self):
        with pytest.raises(ValueError):
            parse_case("")

    def test_missing_parens(self):
        with pytest.raises(ValueError):
            parse_case("abs")

    def test_unknown_constructor(self):
        with pytest.raises(ValueError, match="Unknown"):
            parse_case("abs(x=Foo.bar((2,)))")
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_config/test_parser.py -v`
Expected: FAIL

**Step 3: Write implementation**

The parser is a hand-written recursive descent parser with a tokenizer. Tokens: IDENT, INT, FLOAT, STRING, LPAREN, RPAREN, LBRACKET, RBRACKET, COMMA, DOT, EQUALS, BOOL(True/False), NONE.

```python
# src/tensor_spec/config/parser.py
"""Whitelist recursive descent parser for case strings.

Parses case strings like:
    abs(x=Tensor.float64((1, 100)))
    nn.conv2d(x=Tensor.float32((1, 3, 224, 224)), stride=2, padding=3)

No eval() is used. Only whitelisted constructors are allowed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any

from tensor_spec.config.case import CaseConfig
from tensor_spec.spec.device import Device, DeviceSpec
from tensor_spec.spec.state import TensorState
from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec.spec.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    Tensor,
    TensorSpec,
)


class TokenType(Enum):
    IDENT = auto()
    INT = auto()
    FLOAT = auto()
    STRING = auto()
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    DOT = auto()
    EQUALS = auto()
    EOF = auto()


@dataclass(slots=True)
class Token:
    type: TokenType
    value: str
    pos: int


# Keywords recognized as literal values (not identifiers for resolution)
_KEYWORDS = {"True": True, "False": False, "None": None}


def _tokenize(s: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    while i < len(s):
        c = s[i]
        if c in " \t\n\r":
            i += 1
            continue
        if c == "(":
            tokens.append(Token(TokenType.LPAREN, "(", i)); i += 1
        elif c == ")":
            tokens.append(Token(TokenType.RPAREN, ")", i)); i += 1
        elif c == "[":
            tokens.append(Token(TokenType.LBRACKET, "[", i)); i += 1
        elif c == "]":
            tokens.append(Token(TokenType.RBRACKET, "]", i)); i += 1
        elif c == ",":
            tokens.append(Token(TokenType.COMMA, ",", i)); i += 1
        elif c == ".":
            tokens.append(Token(TokenType.DOT, ".", i)); i += 1
        elif c == "=":
            tokens.append(Token(TokenType.EQUALS, "=", i)); i += 1
        elif c in ('"', "'"):
            # String literal
            quote = c
            j = i + 1
            while j < len(s) and s[j] != quote:
                if s[j] == "\\":
                    j += 1
                j += 1
            if j >= len(s):
                raise ValueError(f"Unterminated string at position {i}")
            tokens.append(Token(TokenType.STRING, s[i + 1 : j], i))
            i = j + 1
        elif c.isdigit() or (c == "-" and i + 1 < len(s) and (s[i + 1].isdigit() or s[i + 1] == ".")):
            # Number: int or float
            m = re.match(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", s[i:])
            if m:
                val = m.group()
                if "." in val or "e" in val or "E" in val:
                    tokens.append(Token(TokenType.FLOAT, val, i))
                else:
                    tokens.append(Token(TokenType.INT, val, i))
                i += len(val)
            else:
                raise ValueError(f"Invalid number at position {i}")
        elif c.isalpha() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            word = s[i:j]
            tokens.append(Token(TokenType.IDENT, word, i))
            i = j
        else:
            raise ValueError(f"Unexpected character '{c}' at position {i}")
    tokens.append(Token(TokenType.EOF, "", len(s)))
    return tokens


class _Parser:
    """Recursive descent parser for case strings."""

    def __init__(self, tokens: list[Token]) -> None:
        self._tokens = tokens
        self._pos = 0

    def _peek(self) -> Token:
        return self._tokens[self._pos]

    def _advance(self) -> Token:
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def _expect(self, tt: TokenType) -> Token:
        tok = self._advance()
        if tok.type != tt:
            raise ValueError(f"Expected {tt.name}, got {tok.type.name} ('{tok.value}') at pos {tok.pos}")
        return tok

    def _at(self, tt: TokenType) -> bool:
        return self._peek().type == tt

    def parse_case(self) -> CaseConfig:
        """Parse top-level: api_name(args...)"""
        api_name = self._parse_dotted_name()
        self._expect(TokenType.LPAREN)
        args, kwargs = self._parse_arg_list()
        self._expect(TokenType.RPAREN)
        return CaseConfig(api_name=api_name, args=tuple(args), kwargs=kwargs)

    def _parse_dotted_name(self) -> str:
        """Parse 'ident' or 'ident.ident.ident'."""
        name = self._expect(TokenType.IDENT).value
        while self._at(TokenType.DOT) and self._pos + 1 < len(self._tokens):
            next_tok = self._tokens[self._pos + 1]
            if next_tok.type == TokenType.IDENT:
                # Check if the IDENT after the dot is a method call on a Tensor (like .stats/.state)
                # or a dtype factory (like .float32). We look ahead to see if this continues as api name.
                # For api names: the dot chain continues until we hit LPAREN
                # For Tensor.float32: we handle it in _parse_value
                # So here we only parse api names (not starting with Tensor)
                self._advance()  # consume DOT
                name += "." + self._advance().value  # consume IDENT
            else:
                break
        return name

    def _parse_arg_list(self) -> tuple[list[Any], dict[str, Any]]:
        """Parse comma-separated args. Returns (positional, keyword)."""
        args: list[Any] = []
        kwargs: dict[str, Any] = {}

        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            # Look ahead: is this keyword=value or just value?
            if self._at(TokenType.IDENT) and self._pos + 1 < len(self._tokens) and self._tokens[self._pos + 1].type == TokenType.EQUALS:
                # keyword arg
                key = self._advance().value
                self._advance()  # consume EQUALS
                val = self._parse_value()
                kwargs[key] = val
            else:
                val = self._parse_value()
                args.append(val)

            if self._at(TokenType.COMMA):
                self._advance()

        return args, kwargs

    def _parse_value(self) -> Any:
        """Parse a single value: tensor spec, scalar, list, tuple, string, etc."""
        tok = self._peek()

        if tok.type == TokenType.IDENT:
            # Could be: True, False, None, Tensor.dtype(...), tuple(...), list(...)
            if tok.value in _KEYWORDS:
                self._advance()
                return _KEYWORDS[tok.value]
            if tok.value == "Tensor":
                return self._parse_tensor()
            if tok.value == "Device":
                return self._parse_device()
            if tok.value == "tuple":
                return self._parse_tuple_constructor()
            if tok.value == "list":
                return self._parse_list_constructor()
            if tok.value == "slice":
                return self._parse_slice_constructor()
            raise ValueError(f"Unknown identifier '{tok.value}' at position {tok.pos}")

        if tok.type == TokenType.INT:
            self._advance()
            return int(tok.value)

        if tok.type == TokenType.FLOAT:
            self._advance()
            return float(tok.value)

        if tok.type == TokenType.STRING:
            self._advance()
            return tok.value

        if tok.type == TokenType.LPAREN:
            return self._parse_tuple_literal()

        if tok.type == TokenType.LBRACKET:
            return self._parse_list_literal()

        raise ValueError(f"Unexpected token {tok.type.name} ('{tok.value}') at position {tok.pos}")

    def _parse_tensor(self) -> TensorSpec:
        """Parse: Tensor.dtype(shape, device?).stats(...)?.state(...)?"""
        self._expect(TokenType.IDENT)  # 'Tensor'
        self._expect(TokenType.DOT)
        dtype_tok = self._expect(TokenType.IDENT)
        dtype = dtype_tok.value

        factory = getattr(Tensor, dtype, None)
        if factory is None:
            raise ValueError(f"Unknown dtype '{dtype}' at position {dtype_tok.pos}")

        # Parse (shape, device?)
        self._expect(TokenType.LPAREN)
        shape = self._parse_tuple_literal()
        device: DeviceSpec | None = None
        if self._at(TokenType.COMMA):
            self._advance()
            if not self._at(TokenType.RPAREN):
                device = self._parse_device()
                if self._at(TokenType.COMMA):
                    self._advance()
        self._expect(TokenType.RPAREN)

        spec: TensorSpec = factory(shape, device)

        # Optional .stats(...) and .state(...)
        while self._at(TokenType.DOT):
            self._advance()  # consume DOT
            method_tok = self._expect(TokenType.IDENT)
            method = method_tok.value

            self._expect(TokenType.LPAREN)
            _, method_kwargs = self._parse_arg_list()
            self._expect(TokenType.RPAREN)

            if method == "stats":
                spec = self._apply_stats(spec, method_kwargs)
            elif method == "state":
                spec = self._apply_state(spec, method_kwargs)
            else:
                raise ValueError(f"Unknown method '.{method}()' at position {method_tok.pos}")

        return spec

    def _apply_stats(self, spec: TensorSpec, kwargs: dict[str, Any]) -> TensorSpec:
        if isinstance(spec, FloatTensorSpec):
            return spec.with_stats(FloatStats(**kwargs))
        if isinstance(spec, IntTensorSpec):
            return spec.with_stats(IntStats(**kwargs))
        if isinstance(spec, BoolTensorSpec):
            return spec.with_stats(BoolStats(**kwargs))
        if isinstance(spec, ComplexTensorSpec):
            return spec.with_stats(ComplexStats(**kwargs))
        raise ValueError(f"Cannot apply stats to {type(spec).__name__}")

    def _apply_state(self, spec: TensorSpec, kwargs: dict[str, Any]) -> TensorSpec:
        state = TensorState(**kwargs)
        if isinstance(spec, (FloatTensorSpec, IntTensorSpec, BoolTensorSpec, ComplexTensorSpec)):
            return spec.with_state(state)
        raise ValueError(f"Cannot apply state to {type(spec).__name__}")

    def _parse_device(self) -> DeviceSpec:
        """Parse: Device.cuda(0) or Device.cpu()"""
        self._expect(TokenType.IDENT)  # 'Device'
        self._expect(TokenType.DOT)
        method = self._expect(TokenType.IDENT).value
        self._expect(TokenType.LPAREN)

        factory = getattr(Device, method, None)
        if factory is None:
            raise ValueError(f"Unknown Device method '{method}'")

        if self._at(TokenType.RPAREN):
            self._expect(TokenType.RPAREN)
            return factory()
        else:
            index = int(self._expect(TokenType.INT).value)
            if self._at(TokenType.COMMA):
                self._advance()
            self._expect(TokenType.RPAREN)
            return factory(index)

    def _parse_tuple_literal(self) -> tuple[Any, ...]:
        """Parse: (item, item, ...) — parenthesized tuple."""
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return tuple(items)

    def _parse_tuple_constructor(self) -> tuple[Any, ...]:
        """Parse: tuple(item, item, ...)"""
        self._expect(TokenType.IDENT)  # 'tuple'
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return tuple(items)

    def _parse_list_literal(self) -> list[Any]:
        """Parse: [item, item, ...]"""
        self._expect(TokenType.LBRACKET)
        items: list[Any] = []
        while not self._at(TokenType.RBRACKET) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RBRACKET)
        return items

    def _parse_list_constructor(self) -> list[Any]:
        """Parse: list(item, item, ...)"""
        self._expect(TokenType.IDENT)  # 'list'
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return items

    def _parse_slice_constructor(self) -> slice:
        """Parse: slice(start, stop, step)"""
        self._expect(TokenType.IDENT)  # 'slice'
        self._expect(TokenType.LPAREN)
        args: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            args.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return slice(*args)


def parse_case(case_str: str) -> CaseConfig:
    """Parse a case string into a CaseConfig.

    Args:
        case_str: A case string like "abs(x=Tensor.float64((1, 100)))"

    Returns:
        A CaseConfig object.

    Raises:
        ValueError: If the case string is malformed.
    """
    case_str = case_str.strip()
    if not case_str:
        raise ValueError("Empty case string")
    tokens = _tokenize(case_str)
    parser = _Parser(tokens)
    return parser.parse_case()
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_config/test_parser.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/config/parser.py tests/test_config/test_parser.py
git commit -m "feat(config): add whitelist recursive descent parser"
```

---

### Task 8: datagen/constraints.py — Constraint Pipeline

**Files:**
- Create: `src/tensor_spec/datagen/__init__.py`
- Create: `src/tensor_spec/datagen/constraints.py`
- Test: `tests/test_datagen/__init__.py`
- Test: `tests/test_datagen/test_constraints.py`

**Step 1: Write the failing test**

```python
# tests/test_datagen/test_constraints.py
import numpy as np

from tensor_spec.datagen.constraints import NonZeroConstraint, PositiveDefiniteConstraint


def test_nonzero_constraint():
    data = np.array([0.0, 1.0, 0.0, -1.0], dtype=np.float32)
    c = NonZeroConstraint()
    result = c.apply(data)
    assert np.all(result != 0.0)
    # Non-zero values should be preserved
    assert result[1] == 1.0
    assert result[3] == -1.0


def test_positive_definite_constraint():
    rng = np.random.default_rng(42)
    data = rng.uniform(-1, 1, (4, 4)).astype(np.float64)
    c = PositiveDefiniteConstraint()
    result = c.apply(data)
    # Check positive definite: all eigenvalues > 0
    eigenvalues = np.linalg.eigvalsh(result)
    assert np.all(eigenvalues > 0)


def test_positive_definite_batched():
    rng = np.random.default_rng(42)
    data = rng.uniform(-1, 1, (3, 4, 4)).astype(np.float64)
    c = PositiveDefiniteConstraint()
    result = c.apply(data)
    assert result.shape == (3, 4, 4)
    for i in range(3):
        eigenvalues = np.linalg.eigvalsh(result[i])
        assert np.all(eigenvalues > 0)
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_datagen/test_constraints.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/datagen/__init__.py
"""Data generation layer: TensorSpec -> numpy arrays."""

# src/tensor_spec/datagen/constraints.py
"""Constraint implementations for tensor data generation."""
from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class Constraint(ABC):
    """Base class for data constraints applied post-generation."""

    @abstractmethod
    def apply(self, data: np.ndarray) -> np.ndarray:
        """Apply the constraint to the data array, returning a modified array."""
        ...


class NonZeroConstraint(Constraint):
    """Replace zeros with small non-zero values."""

    def apply(self, data: np.ndarray) -> np.ndarray:
        if np.issubdtype(data.dtype, np.floating):
            data = data.copy()
            data[data == 0] = np.finfo(data.dtype).tiny
        elif np.issubdtype(data.dtype, np.integer):
            data = data.copy()
            data[data == 0] = 1
        return data


class PositiveDefiniteConstraint(Constraint):
    """Make the matrix positive definite via A @ A^T + I."""

    def apply(self, data: np.ndarray) -> np.ndarray:
        n = data.shape[-1]
        original_shape = data.shape
        data = data.reshape(-1, n, n)
        data = data @ np.swapaxes(data, -1, -2) + np.eye(n, dtype=data.dtype)
        return data.reshape(original_shape)
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_datagen/test_constraints.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/datagen/ tests/test_datagen/
git commit -m "feat(datagen): add NonZero and PositiveDefinite constraints"
```

---

### Task 9: datagen/generator.py — TensorGenerator

**Files:**
- Create: `src/tensor_spec/datagen/generator.py`
- Test: `tests/test_datagen/test_generator.py`

**Step 1: Write the failing test**

```python
# tests/test_datagen/test_generator.py
import numpy as np

from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.spec.stats import FloatStats, IntStats, BoolStats
from tensor_spec.spec.tensor import Tensor


def test_generate_float32():
    spec = Tensor.float32((2, 3))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (2, 3)
    assert data.dtype == np.float32


def test_generate_float64():
    spec = Tensor.float64((100,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (100,)
    assert data.dtype == np.float64


def test_generate_float_with_stats():
    spec = Tensor.float32((1000,)).with_stats(FloatStats(min=-10.0, max=10.0))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.min() >= -10.0
    assert data.max() <= 10.0


def test_generate_float_nonzero():
    spec = Tensor.float32((100,)).with_stats(FloatStats(nonzero=True))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert np.all(data != 0.0)


def test_generate_float_positive_definite():
    spec = Tensor.float64((4, 4)).with_stats(FloatStats(positive_definite=True))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    eigenvalues = np.linalg.eigvalsh(data)
    assert np.all(eigenvalues > 0)


def test_generate_int64():
    spec = Tensor.int64((10,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (10,)
    assert data.dtype == np.int64


def test_generate_int_with_stats():
    spec = Tensor.int32((100,)).with_stats(IntStats(low=0, high=10))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert np.all(data >= 0)
    assert np.all(data < 10)


def test_generate_bool():
    spec = Tensor.bool((100,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (100,)
    assert data.dtype == np.bool_


def test_generate_bool_true_ratio():
    spec = Tensor.bool((10000,)).with_stats(BoolStats(true_ratio=0.8))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    ratio = data.sum() / len(data)
    assert 0.75 < ratio < 0.85  # approximate


def test_generate_deterministic():
    spec = Tensor.float32((10,))
    data1 = TensorGenerator(seed=42).generate(spec)
    data2 = TensorGenerator(seed=42).generate(spec)
    np.testing.assert_array_equal(data1, data2)
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_datagen/test_generator.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/datagen/generator.py
"""TensorSpec -> numpy array generator with constraint pipeline."""
from __future__ import annotations

import numpy as np

from tensor_spec.datagen.constraints import (
    Constraint,
    NonZeroConstraint,
    PositiveDefiniteConstraint,
)
from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec.spec.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    TensorSpec,
)

# numpy dtype strings for our dtype names
_NUMPY_DTYPE: dict[str, str] = {
    "float16": "float16",
    "float32": "float32",
    "float64": "float64",
    "bfloat16": "float32",  # numpy doesn't support bfloat16; generate as float32
    "int8": "int8",
    "int16": "int16",
    "int32": "int32",
    "int64": "int64",
    "uint8": "uint8",
    "bool": "bool",
    "complex64": "complex64",
    "complex128": "complex128",
}


class TensorGenerator:
    """Generates numpy arrays from TensorSpec instances."""

    def __init__(self, seed: int | None = None) -> None:
        self._rng = np.random.default_rng(seed)

    def generate(self, spec: TensorSpec) -> np.ndarray:
        if isinstance(spec, FloatTensorSpec):
            return self._gen_float(spec)
        if isinstance(spec, IntTensorSpec):
            return self._gen_int(spec)
        if isinstance(spec, BoolTensorSpec):
            return self._gen_bool(spec)
        if isinstance(spec, ComplexTensorSpec):
            return self._gen_complex(spec)
        raise TypeError(f"Unsupported spec type: {type(spec).__name__}")

    def _gen_float(self, spec: FloatTensorSpec) -> np.ndarray:
        stats = spec.stats or FloatStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        data = self._rng.uniform(stats.min, stats.max, spec.shape).astype(np_dtype)

        for constraint in self._float_constraints(stats):
            data = constraint.apply(data)
        return data

    def _gen_int(self, spec: IntTensorSpec) -> np.ndarray:
        stats = spec.stats or IntStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        data = self._rng.integers(stats.low, stats.high, size=spec.shape, dtype=np_dtype)

        if stats.nonzero:
            data = NonZeroConstraint().apply(data)
        return data

    def _gen_bool(self, spec: BoolTensorSpec) -> np.ndarray:
        stats = spec.stats or BoolStats()
        if stats.all_true:
            return np.ones(spec.shape, dtype=np.bool_)
        if stats.all_false:
            return np.zeros(spec.shape, dtype=np.bool_)
        return self._rng.random(spec.shape) < stats.true_ratio

    def _gen_complex(self, spec: ComplexTensorSpec) -> np.ndarray:
        stats = spec.stats or ComplexStats()
        np_dtype = _NUMPY_DTYPE[spec.dtype]
        real = self._rng.uniform(stats.real_min, stats.real_max, spec.shape)
        imag = self._rng.uniform(stats.imag_min, stats.imag_max, spec.shape)
        return (real + 1j * imag).astype(np_dtype)

    def _float_constraints(self, stats: FloatStats) -> list[Constraint]:
        constraints: list[Constraint] = []
        if stats.positive_definite:
            constraints.append(PositiveDefiniteConstraint())
        if stats.nonzero:
            constraints.append(NonZeroConstraint())
        return constraints
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_datagen/test_generator.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/datagen/generator.py tests/test_datagen/test_generator.py
git commit -m "feat(datagen): add TensorGenerator with constraint pipeline"
```

---

### Task 10: backend/base.py — BackendBase

**Files:**
- Create: `src/tensor_spec/backend/__init__.py`
- Create: `src/tensor_spec/backend/base.py`
- Test: `tests/test_backend/__init__.py`
- Test: `tests/test_backend/test_base.py`

**Step 1: Write the failing test**

```python
# tests/test_backend/test_base.py
import pytest

from tensor_spec.backend.base import BackendBase


def test_backend_base_is_abstract():
    with pytest.raises(TypeError):
        BackendBase()
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_backend/test_base.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/backend/__init__.py
"""Framework backend layer."""

# src/tensor_spec/backend/base.py
"""Abstract base class for framework backends."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from tensor_spec.spec.tensor import TensorSpec


class BackendBase(ABC):
    """Abstract base class for all framework backends.

    Each backend wraps a specific framework (paddle, torch, jax, etc.)
    and provides a uniform interface for tensor creation, API execution, etc.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Backend name (e.g. 'paddle', 'torch')."""
        ...

    @abstractmethod
    def import_framework(self) -> None:
        """Import the framework. Called once at worker startup."""
        ...

    @abstractmethod
    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        """Convert a numpy array to a framework tensor, respecting spec (dtype, grad, device)."""
        ...

    @abstractmethod
    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        """Convert a framework tensor back to numpy."""
        ...

    @abstractmethod
    def exec_api(self, api_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        """Execute a framework API call."""
        ...

    @abstractmethod
    def empty_cache(self) -> None:
        """Clear GPU memory cache."""
        ...
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_backend/test_base.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/backend/ tests/test_backend/
git commit -m "feat(backend): add BackendBase abstract class"
```

---

### Task 11: backend/paddle_backend.py — PaddleBackend

**Files:**
- Create: `src/tensor_spec/backend/paddle_backend.py`
- Test: `tests/test_backend/test_paddle_backend.py`

Note: The test will be marked `pytest.mark.skipif` if paddle is not installed, so it can pass in CI without paddle.

**Step 1: Write the failing test**

```python
# tests/test_backend/test_paddle_backend.py
import pytest

try:
    import paddle
    HAS_PADDLE = True
except ImportError:
    HAS_PADDLE = False

from tensor_spec.backend.paddle_backend import PaddleBackend

pytestmark = pytest.mark.skipif(not HAS_PADDLE, reason="paddle not installed")


@pytest.fixture
def backend():
    b = PaddleBackend()
    b.import_framework()
    return b


def test_name(backend):
    assert backend.name == "paddle"


def test_numpy_to_tensor(backend):
    import numpy as np
    from tensor_spec.spec.tensor import Tensor

    spec = Tensor.float32((2, 3))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.shape == [2, 3]
    assert str(t.dtype) == "paddle.float32"


def test_numpy_to_tensor_with_grad(backend):
    import numpy as np
    from tensor_spec.spec.state import TensorState
    from tensor_spec.spec.tensor import Tensor

    spec = Tensor.float32((2, 3)).with_state(TensorState(need_grad=True))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.stop_gradient is False


def test_tensor_to_numpy(backend):
    import numpy as np
    t = paddle.to_tensor(np.array([1.0, 2.0, 3.0], dtype=np.float32))
    result = backend.tensor_to_numpy(t)
    assert isinstance(result, np.ndarray)
    np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])


def test_exec_api_abs(backend):
    import numpy as np
    t = paddle.to_tensor(np.array([-1.0, 2.0, -3.0], dtype=np.float32))
    result = backend.exec_api("abs", (t,), {})
    expected = np.array([1.0, 2.0, 3.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_add(backend):
    import numpy as np
    x = paddle.to_tensor(np.array([1.0, 2.0], dtype=np.float32))
    y = paddle.to_tensor(np.array([3.0, 4.0], dtype=np.float32))
    result = backend.exec_api("add", (), {"x": x, "y": y})
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), [4.0, 6.0])


def test_exec_api_matmul(backend):
    import numpy as np
    x = paddle.to_tensor(np.eye(3, dtype=np.float32))
    y = paddle.to_tensor(np.array([[1.0], [2.0], [3.0]], dtype=np.float32))
    result = backend.exec_api("matmul", (), {"x": x, "y": y})
    np.testing.assert_array_almost_equal(backend.tensor_to_numpy(result), [[1.0], [2.0], [3.0]])
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_backend/test_paddle_backend.py -v`
Expected: FAIL (or skip if no paddle)

**Step 3: Write implementation**

```python
# src/tensor_spec/backend/paddle_backend.py
"""PaddleBackend: Paddle framework backend implementation."""
from __future__ import annotations

from typing import Any

import numpy as np

from tensor_spec.backend.base import BackendBase
from tensor_spec.spec.tensor import TensorSpec


class PaddleBackend(BackendBase):
    """Backend for PaddlePaddle framework."""

    def __init__(self) -> None:
        self._paddle: Any = None

    @property
    def name(self) -> str:
        return "paddle"

    def import_framework(self) -> None:
        import paddle
        self._paddle = paddle

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        paddle = self._paddle
        t = paddle.to_tensor(np_array)
        if spec.state and spec.state.need_grad:
            t.stop_gradient = False
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.numpy(force=True)

    def exec_api(self, api_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        api_func = self._resolve_api(api_name)
        return api_func(*args, **kwargs)

    def empty_cache(self) -> None:
        paddle = self._paddle
        if hasattr(paddle, "device") and hasattr(paddle.device, "cuda"):
            try:
                paddle.device.cuda.empty_cache()
            except Exception:
                pass

    def _resolve_api(self, api_name: str) -> Any:
        """Resolve a dotted API name to a callable on the paddle module.

        E.g. 'abs' -> paddle.abs, 'linalg.cholesky' -> paddle.linalg.cholesky
        """
        obj = self._paddle
        for part in api_name.split("."):
            obj = getattr(obj, part)
        return obj
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_backend/test_paddle_backend.py -v`
Expected: PASS (or all skipped if no paddle)

**Step 5: Commit**

```bash
git add src/tensor_spec/backend/paddle_backend.py tests/test_backend/test_paddle_backend.py
git commit -m "feat(backend): add PaddleBackend implementation"
```

---

### Task 12: cli.py — CLI Entry Point

**Files:**
- Create: `src/tensor_spec/cli.py`
- Test: `tests/test_cli.py`

**Step 1: Write the failing test**

```python
# tests/test_cli.py
from click.testing import CliRunner

from tensor_spec.cli import main


def test_cli_help():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "tensor-spec" in result.output.lower() or "run" in result.output


def test_cli_run_help():
    runner = CliRunner()
    result = runner.invoke(main, ["run", "--help"])
    assert result.exit_code == 0
    assert "--backend" in result.output
    assert "--case" in result.output


def test_cli_validate_help():
    runner = CliRunner()
    result = runner.invoke(main, ["validate", "--help"])
    assert result.exit_code == 0
    assert "--case" in result.output
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_cli.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
# src/tensor_spec/cli.py
"""CLI entry point for tensor-spec."""
from __future__ import annotations

import sys
from typing import Any

import click

from tensor_spec.config.parser import parse_case
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.spec.tensor import TensorSpec


@click.group()
def main() -> None:
    """tensor-spec: Framework-agnostic deep learning API quality verification tool."""
    pass


@main.command()
@click.option("--backend", required=True, help="Backend to use (e.g., paddle)")
@click.option("--case", required=True, help='Case string (e.g., "abs(x=Tensor.float32((100,)))")')
@click.option("--seed", default=42, type=int, help="Random seed for data generation")
def run(backend: str, case: str, seed: int) -> None:
    """Run a single test case against a backend."""
    # 1. Parse the case
    click.echo(f"Parsing case: {case}")
    try:
        case_config = parse_case(case)
    except ValueError as e:
        click.echo(f"Parse error: {e}", err=True)
        sys.exit(1)
    click.echo(f"  API: {case_config.api_name}")

    # 2. Generate data
    click.echo("Generating test data...")
    gen = TensorGenerator(seed=seed)
    numpy_inputs: dict[str, Any] = {}
    for key, val in case_config.kwargs.items():
        if isinstance(val, TensorSpec):
            numpy_inputs[key] = gen.generate(val)
            click.echo(f"  {key}: shape={numpy_inputs[key].shape}, dtype={numpy_inputs[key].dtype}")

    # 3. Load backend and execute
    backend_impl = _load_backend(backend)
    backend_impl.import_framework()
    click.echo(f"Backend: {backend_impl.name}")

    # Convert numpy to tensors
    tensor_kwargs: dict[str, Any] = {}
    for key, val in case_config.kwargs.items():
        if key in numpy_inputs:
            tensor_kwargs[key] = backend_impl.numpy_to_tensor(numpy_inputs[key], case_config.kwargs[key])
        else:
            tensor_kwargs[key] = val

    # Convert positional args
    tensor_args_list: list[Any] = []
    for val in case_config.args:
        if isinstance(val, TensorSpec):
            np_data = gen.generate(val)
            tensor_args_list.append(backend_impl.numpy_to_tensor(np_data, val))
        elif isinstance(val, tuple) and any(isinstance(v, TensorSpec) for v in val):
            converted = []
            for v in val:
                if isinstance(v, TensorSpec):
                    np_data = gen.generate(v)
                    converted.append(backend_impl.numpy_to_tensor(np_data, v))
                else:
                    converted.append(v)
            tensor_args_list.append(tuple(converted))
        else:
            tensor_args_list.append(val)

    # Execute
    click.echo(f"Executing {case_config.api_name}...")
    try:
        result = backend_impl.exec_api(case_config.api_name, tuple(tensor_args_list), tensor_kwargs)
        click.echo(f"  Result type: {type(result).__name__}")
        result_np = backend_impl.tensor_to_numpy(result)
        click.echo(f"  Result shape: {result_np.shape}, dtype: {result_np.dtype}")
        click.echo("PASSED")
    except Exception as e:
        click.echo(f"FAILED: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option("--case", required=True, help="Case string to validate")
def validate(case: str) -> None:
    """Validate a case string without executing it."""
    try:
        case_config = parse_case(case)
        click.echo(f"Valid: api={case_config.api_name}, "
                    f"args={len(case_config.args)}, kwargs={list(case_config.kwargs.keys())}")
    except ValueError as e:
        click.echo(f"Invalid: {e}", err=True)
        sys.exit(1)


def _load_backend(name: str) -> Any:
    """Load a backend by name."""
    if name == "paddle":
        from tensor_spec.backend.paddle_backend import PaddleBackend
        return PaddleBackend()
    raise ValueError(f"Unknown backend: {name}. Available: paddle")
```

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_cli.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/cli.py tests/test_cli.py
git commit -m "feat(cli): add CLI with run and validate commands"
```

---

### Task 13: Integration Test — End-to-End Verification

**Files:**
- Test: `tests/test_integration.py`

**Step 1: Write integration test**

```python
# tests/test_integration.py
"""End-to-end integration tests for Phase 0.

Tests the full pipeline: parse -> generate -> (backend optional)
"""
import numpy as np
import pytest

from tensor_spec.config.parser import parse_case
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.spec.tensor import TensorSpec

try:
    import paddle
    HAS_PADDLE = True
except ImportError:
    HAS_PADDLE = False


class TestParseAndGenerate:
    """Test parse + generate pipeline without any framework."""

    def test_abs(self):
        case = parse_case("abs(x=Tensor.float64((1, 100)))")
        gen = TensorGenerator(seed=42)
        data = gen.generate(case.kwargs["x"])
        assert data.shape == (1, 100)
        assert data.dtype == np.float64

    def test_add(self):
        case = parse_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))")
        gen = TensorGenerator(seed=42)
        x = gen.generate(case.kwargs["x"])
        y = gen.generate(case.kwargs["y"])
        assert x.shape == (2, 3)
        assert y.shape == (2, 3)

    def test_matmul(self):
        case = parse_case("matmul(x=Tensor.float64((4, 5)), y=Tensor.float64((5, 3)))")
        gen = TensorGenerator(seed=42)
        x = gen.generate(case.kwargs["x"])
        y = gen.generate(case.kwargs["y"])
        result = np.matmul(x, y)
        assert result.shape == (4, 3)

    def test_cholesky_positive_definite(self):
        case = parse_case("linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))")
        gen = TensorGenerator(seed=42)
        data = gen.generate(case.kwargs["x"])
        # Should not raise — positive definite matrices have Cholesky decomposition
        L = np.linalg.cholesky(data)
        assert L.shape == (4, 4)


@pytest.mark.skipif(not HAS_PADDLE, reason="paddle not installed")
class TestFullPipeline:
    """Test full pipeline including Paddle backend execution."""

    @pytest.fixture
    def backend(self):
        from tensor_spec.backend.paddle_backend import PaddleBackend
        b = PaddleBackend()
        b.import_framework()
        return b

    def _run_case(self, case_str: str, backend):
        case = parse_case(case_str)
        gen = TensorGenerator(seed=42)
        kwargs = {}
        for key, val in case.kwargs.items():
            if isinstance(val, TensorSpec):
                np_data = gen.generate(val)
                kwargs[key] = backend.numpy_to_tensor(np_data, val)
            else:
                kwargs[key] = val
        return backend.exec_api(case.api_name, case.args, kwargs)

    def test_abs_paddle(self, backend):
        result = self._run_case("abs(x=Tensor.float32((100,)))", backend)
        result_np = backend.tensor_to_numpy(result)
        assert np.all(result_np >= 0)

    def test_add_paddle(self, backend):
        result = self._run_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))", backend)
        assert backend.tensor_to_numpy(result).shape == (2, 3)

    def test_matmul_paddle(self, backend):
        result = self._run_case("matmul(x=Tensor.float64((4, 5)), y=Tensor.float64((5, 3)))", backend)
        assert backend.tensor_to_numpy(result).shape == (4, 3)
```

**Step 2: Run all tests**

Run: `uv run pytest tests/ -v`
Expected: All tests PASS (paddle tests skipped if paddle not installed)

**Step 3: Commit**

```bash
git add tests/test_integration.py
git commit -m "test: add end-to-end integration tests for Phase 0"
```

---

### Task 14: Lint, Format, and Final Verification

**Step 1: Run ruff check and format**

Run: `uvx ruff check src/ tests/ && uvx ruff format src/ tests/`
Expected: No errors (or fix any issues)

**Step 2: Run full test suite**

Run: `uv run pytest tests/ -v --tb=short`
Expected: All tests PASS

**Step 3: Final commit if there were lint fixes**

```bash
git add -A
git commit -m "chore: lint and format fixes"
```

---

## Summary

| Task | Module | Key Deliverable |
|------|--------|----------------|
| 1 | Project skeleton | pyproject.toml, ruff config, uv sync |
| 2 | spec/device.py | DeviceSpec + Device factory |
| 3 | spec/state.py | TensorState |
| 4 | spec/stats.py | FloatStats, IntStats, BoolStats, ComplexStats |
| 5 | spec/tensor.py | TensorSpec hierarchy + Tensor factory |
| 6 | config/case.py | CaseConfig dataclass |
| 7 | config/parser.py | Whitelist recursive descent parser |
| 8 | datagen/constraints.py | NonZero, PositiveDefinite constraints |
| 9 | datagen/generator.py | TensorGenerator |
| 10 | backend/base.py | BackendBase abstract class |
| 11 | backend/paddle_backend.py | PaddleBackend |
| 12 | cli.py | CLI run + validate commands |
| 13 | Integration tests | E2E tests for abs, add, matmul |
| 14 | Lint & verify | ruff, full test suite |
