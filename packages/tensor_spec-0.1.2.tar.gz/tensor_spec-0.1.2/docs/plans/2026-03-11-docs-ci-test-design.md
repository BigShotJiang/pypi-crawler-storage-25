# 文档系统 + CI + 测试架构设计

**日期:** 2026-03-11
**状态:** 已批准

---

## 1. 概述

本设计覆盖三个方面：

1. **文档系统**：用 zensical（MkDocs Material TOML 包装器）搭建文档站点，整理散落的设计文档
2. **CI/CD**：4 个 GitHub Actions workflow（静态检查、测试、文档部署、发版）
3. **测试架构**：重组为 unit + e2e 两层，增强 pytest 插件链

参考仓库：
- [volvox](https://github.com/volvox-ai/volvox) — zensical 文档、CI 架构、测试分层（**重点参考**）
- [dns-manager](https://github.com/zrr-lab/dns-manager) — semantic-release、CodSpeed
- [precision-alignment-agent](https://github.com/zrr1999/precision-alignment-agent) — prek 静态检查
- [paddle-skills#3](https://github.com/PFCCLab/paddle-skills/issues/3) — skill 分层设计

---

## 2. 文档系统

### 2.1 文档重组

将根目录 6 个散落文档迁移到 `docs/` 下统一管理：

| 原位置 | 新位置 | 说明 |
|--------|--------|------|
| `architecture_design.md` | `docs/design/architecture.md` | 10 层架构设计 |
| `design_decisions.md` | `docs/design/decisions.md` | 选型决策 |
| `case_representation_design.md` | `docs/design/case-representation.md` | Case 表示方案 |
| `design_four_questions.md` | `docs/design/modernization.md` | 现代化策略 |
| `PaddleAPITest_analysis.md` | `docs/design/legacy-analysis.md` | 遗留系统分析 |
| `IMPLEMENTATION_PROMPT.md` | `docs/design/implementation-prompt.md` | 实施提示词 |
| `docs/design_rationale.md` | `docs/rationale.md` | 设计决策速查 |

迁移后删除根目录原文件。

### 2.2 目录结构

```
docs/
├── index.md                        # 项目首页
├── rationale.md                    # 设计决策速查
├── design/                         # 设计文档
│   ├── architecture.md
│   ├── decisions.md
│   ├── case-representation.md
│   ├── modernization.md
│   ├── legacy-analysis.md
│   └── implementation-prompt.md
├── plans/                          # 实现计划（已有）
│   ├── 2026-03-03-phase0-implementation.md
│   ├── 2026-03-05-phase1-cross-framework-accuracy.md
│   └── 2026-03-05-phase2-process-isolation-ipc.md
└── api/                            # API 参考（mkdocstrings 自动生成）
    └── index.md
```

### 2.3 zensical 配置

新建 `zensical.toml`，配置 MkDocs Material 主题 + mkdocstrings-python 插件。

### 2.4 文档依赖

在 `pyproject.toml` 中新增 `docs` 依赖组：

```toml
[dependency-groups]
docs = ["mkdocstrings-python", "pymdown-extensions", "zensical"]
```

---

## 3. CI/CD

### 3.1 Workflow 总览

| 文件名 | 名称 | 触发条件 | 内容 |
|--------|------|----------|------|
| `ci-static-checks.yml` | CI - Static Checks | push/PR to main | prek（ruff lint + format + typos） |
| `ci-tests.yml` | CI - Tests | push/PR to main | pytest unit + e2e + coverage → Codecov |
| `cd-docs.yml` | CD - Documentation | push to main | zensical build → GitHub Pages |
| `cd-release.yml` | CD - Release | tag `v*` push | build wheel + GitHub Release + PyPI |

命名约定：`ci-` = 检查型（不部署），`cd-` = 交付型（有部署动作）。

### 3.2 ci-static-checks.yml

```yaml
on: [push, pull_request]
jobs:
  static-checks:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: j178/prek-action@v1    # 执行 prek.toml 中定义的 hooks
```

配套新建 `prek.toml`：
- ruff check + ruff format
- typos（拼写检查）
- 标准 pre-commit hooks（trailing whitespace, end-of-file, yaml check）

### 3.3 ci-tests.yml

```yaml
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - checkout + setup-uv + setup-python 3.12
      - uv sync --group dev
      - just test-unit    # pytest tests/unit -n auto --xdoc --cov
      - just test-e2e     # pytest tests/e2e -v
      - coverage xml → codecov/codecov-action
```

### 3.4 cd-docs.yml

```yaml
on:
  push:
    branches: [main]
jobs:
  docs:
    steps:
      - checkout + setup-uv
      - uv sync --group docs
      - just docs-build          # uv run zensical build
      - peaceiris/actions-gh-pages → docs branch
```

### 3.5 cd-release.yml

```yaml
on:
  push:
    tags: ["v*"]
jobs:
  release:
    steps:
      - checkout + setup-uv
      - uv build --wheel
      - gh release create
      - pypa/gh-action-pypi-publish（可选，初期可不启用）
```

### 3.6 配套文件

| 文件 | 用途 |
|------|------|
| `prek.toml` | pre-commit hooks 配置 |
| `codecov.yml` | 覆盖率目标：project 80% / patch 90% |
| `justfile` | 本地 task runner |

---

## 4. 测试架构

### 4.1 目录重组

```
tests/
├── conftest.py              # 共享 fixtures
├── __init__.py
├── unit/                    # 模块级单元测试
│   ├── __init__.py
│   ├── test_backend/        # ← tests/test_backend/
│   ├── test_compare/        # ← tests/test_compare/
│   ├── test_config/         # ← tests/test_config/
│   ├── test_datagen/        # ← tests/test_datagen/
│   ├── test_ipc/            # ← tests/test_ipc/
│   ├── test_log/            # ← tests/test_log/
│   ├── test_mapping/        # ← tests/test_mapping/
│   ├── test_spec/           # ← tests/test_spec/
│   ├── test_tester/         # ← tests/test_tester/
│   └── test_worker/         # ← tests/test_worker/
└── e2e/                     # 端到端测试
    ├── __init__.py
    ├── test_cli.py          # ← tests/test_cli.py
    └── test_accuracy_pipeline.py  # ← tests/test_integration.py
```

### 4.2 pytest 配置

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = ["--instafail", "--strict-markers", "--tb=short"]
markers = [
    "e2e: end-to-end tests",
    "slow: slow tests",
    "gpu: requires GPU",
]
timeout = 300
timeout_method = "thread"
```

### 4.3 新增 pytest 插件

| 插件 | 用途 |
|------|------|
| pytest-xdist | 并行执行 (`-n auto`) |
| pytest-instafail | 失败即时显示 |
| pytest-timeout | 超时保护（300s） |
| pytest-cov | 覆盖率收集 |
| xdoctest | docstring 代码示例测试 |

### 4.4 dev 依赖组

从 `[project.optional-dependencies]` 迁移到 `[dependency-groups]`（PEP 735）：

```toml
[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-xdist>=3.5",
    "pytest-instafail>=0.5",
    "pytest-timeout>=2.4",
    "pytest-cov>=5.0",
    "xdoctest>=1.3",
    "ruff>=0.4",
    "pyright>=1.1",
]
docs = ["mkdocstrings-python", "pymdown-extensions", "zensical"]
```

---

## 5. justfile

```just
# 开发命令
lint:
    uvx ruff check src/ tests/
    uvx ruff format --check src/ tests/

fmt:
    uvx ruff format src/ tests/
    uvx ruff check --fix src/ tests/

typecheck:
    uv run pyright src/

# 测试命令
test: test-unit test-e2e

test-unit:
    uv run pytest tests/unit -n auto --xdoc

test-e2e:
    uv run pytest tests/e2e -v

cov:
    uv run pytest tests/unit -n auto --xdoc --cov=tensor_spec --cov-report=html --cov-report=xml

# 文档命令
docs:
    uv run zensical serve

docs-build:
    uv run zensical build

# 安装
install:
    uv sync --all-groups
```

---

## 6. 实施顺序

1. **pyproject.toml 更新**：dependency-groups、pytest 配置
2. **测试重组**：移动文件到 unit/ 和 e2e/
3. **工具链文件**：justfile、prek.toml、codecov.yml、ruff.toml 调整
4. **文档重组**：迁移根目录文档到 docs/design/
5. **zensical 配置**：zensical.toml + docs/index.md + docs/api/index.md
6. **CI workflows**：4 个 yml 文件
7. **验证**：本地跑通 just test、just lint、just docs-build
