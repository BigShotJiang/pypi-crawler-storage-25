"""Tests for the API mapping registry."""

from __future__ import annotations

import json

import pytest

from tensor_spec.mapping.registry import APIMapping, MappingRegistry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_PADDLE = {
    "abs": {"api": "abs", "args_map": {"x": "x"}},
    "add": {"api": "add", "args_map": {"x": "x", "y": "y"}},
}

SAMPLE_TORCH = {
    "abs": {"api": "abs", "args_map": {"x": "input"}},
    "add": {"api": "add", "args_map": {"x": "input", "y": "other"}},
}


def _write_json(tmp_path, name: str, data: dict) -> str:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return str(path)


# ---------------------------------------------------------------------------
# 1. test_load_and_resolve — load paddle.json, resolve "abs"
# ---------------------------------------------------------------------------


def test_load_and_resolve(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "paddle.json", SAMPLE_PADDLE)
    registry.load("paddle", path)

    mapping = registry.resolve("abs", "paddle")
    assert isinstance(mapping, APIMapping)
    assert mapping.api == "abs"
    assert mapping.args_map == {"x": "x"}


# ---------------------------------------------------------------------------
# 2. test_resolve_torch — load torch.json, resolve "abs", check x→input
# ---------------------------------------------------------------------------


def test_resolve_torch(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    mapping = registry.resolve("abs", "torch")
    assert mapping.api == "abs"
    assert mapping.args_map["x"] == "input"


# ---------------------------------------------------------------------------
# 3. test_resolve_unknown_api — KeyError for unknown API
# ---------------------------------------------------------------------------


def test_resolve_unknown_api(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "paddle.json", SAMPLE_PADDLE)
    registry.load("paddle", path)

    with pytest.raises(KeyError):
        registry.resolve("nonexistent_api", "paddle")


# ---------------------------------------------------------------------------
# 4. test_resolve_unknown_framework — KeyError for unknown framework
# ---------------------------------------------------------------------------


def test_resolve_unknown_framework():
    registry = MappingRegistry()

    with pytest.raises(KeyError):
        registry.resolve("abs", "unknown_framework")


# ---------------------------------------------------------------------------
# 5. test_map_kwargs — remap {"x": 1, "y": 2} → {"input": 1, "other": 2}
# ---------------------------------------------------------------------------


def test_map_kwargs(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    result = registry.map_kwargs("add", "torch", {"x": 1, "y": 2})
    assert result == {"input": 1, "other": 2}


# ---------------------------------------------------------------------------
# 6. test_map_kwargs_passthrough_unmapped — unmapped keys pass through
# ---------------------------------------------------------------------------


def test_map_kwargs_passthrough_unmapped(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    result = registry.map_kwargs("abs", "torch", {"x": 1, "alpha": 0.5})
    assert result == {"input": 1, "alpha": 0.5}


# ---------------------------------------------------------------------------
# 7. test_resolve_api_name — resolve_api returns framework-specific path
# ---------------------------------------------------------------------------


def test_resolve_api_name(tmp_path):
    data = {
        "relu": {"api": "nn.functional.relu", "args_map": {"x": "input"}},
    }
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", data)
    registry.load("torch", path)

    assert registry.resolve_api("relu", "torch") == "nn.functional.relu"


# ---------------------------------------------------------------------------
# 8. test_api_mapping_frozen — APIMapping dataclass is frozen
# ---------------------------------------------------------------------------


def test_api_mapping_frozen():
    mapping = APIMapping(api="abs", args_map={"x": "input"})

    with pytest.raises(AttributeError):
        setattr(mapping, "api", "changed")


# ---------------------------------------------------------------------------
# 9. test_load_from_package — load_bundled works for paddle and torch
# ---------------------------------------------------------------------------


def test_load_from_package():
    registry = MappingRegistry()
    registry.load_bundled("paddle")
    registry.load_bundled("torch")

    # Verify paddle mappings loaded correctly
    assert registry.resolve_api("abs", "paddle") == "abs"
    assert registry.map_kwargs("abs", "paddle", {"x": 1}) == {"x": 1}

    # Verify torch mappings loaded correctly
    assert registry.resolve_api("abs", "torch") == "abs"
    assert registry.map_kwargs("abs", "torch", {"x": 1}) == {"input": 1}

    # Verify all 10 APIs are present for each framework
    for api_name in (
        "abs",
        "add",
        "matmul",
        "sum",
        "mean",
        "sqrt",
        "exp",
        "log",
        "nn.functional.relu",
        "nn.functional.sigmoid",
    ):
        assert registry.resolve(api_name, "paddle").api is not None
        assert registry.resolve(api_name, "torch").api is not None


def test_load_rules_runtime_overrides(tmp_path):
    rules_path = tmp_path / "torch.rules.toml"
    rules_path.write_text(
        """
[api_rename]
transpose = "permute"

[[arg_rules]]
from = "x"
to = "input"

[call_overrides."transpose"]
drop_kwargs = ["perm"]
default_kwargs = { keepdim = false }
computed_kwargs = { dims = "tuple(perm) + tuple(range(len(perm), x.ndim))" }
handler = "demo_handler"
result_index = 0
""".strip()
    )

    registry = MappingRegistry()
    registry.load_rules("torch", str(rules_path), ["transpose"])

    mapping = registry.resolve("transpose", "torch")
    assert mapping.api == "permute"
    assert mapping.args_map["x"] == "input"
    assert mapping.default_kwargs == {"keepdim": False}
    assert mapping.computed_kwargs == {"dims": "tuple(perm) + tuple(range(len(perm), x.ndim))"}
    assert mapping.drop_kwargs == ("perm",)
    assert mapping.handler == "demo_handler"
    assert mapping.result_index == 0


def test_load_from_package_includes_runtime_handlers():
    registry = MappingRegistry()
    registry.load_bundled("torch")

    ctc_loss = registry.resolve("nn.functional.ctc_loss", "torch")
    generate_proposals = registry.resolve("vision.ops.generate_proposals", "torch")
    add = registry.resolve("add", "torch")
    subtract = registry.resolve("subtract", "torch")
    reshape = registry.resolve("reshape", "torch")
    reduction = registry.resolve("sum", "torch")
    norm = registry.resolve("linalg.norm", "torch")
    tensor_set = registry.resolve("Tensor.set_", "torch")
    sort = registry.resolve("sort", "torch")
    topk = registry.resolve("topk", "torch")
    unique = registry.resolve("unique", "torch")
    full_like = registry.resolve("full_like", "torch")
    linear = registry.resolve("nn.functional.linear", "torch")
    gelu = registry.resolve("nn.functional.gelu", "torch")
    transpose = registry.resolve("transpose", "torch")
    gather = registry.resolve("gather", "torch")
    scatter = registry.resolve("scatter", "torch")
    index_select = registry.resolve("index_select", "torch")
    conv1d = registry.resolve("nn.functional.conv1d", "torch")
    conv2d = registry.resolve("nn.functional.conv2d", "torch")
    batch_norm = registry.resolve("nn.functional.batch_norm", "torch")
    layer_norm = registry.resolve("nn.functional.layer_norm", "torch")
    pad = registry.resolve("nn.functional.pad", "torch")
    interpolate = registry.resolve("nn.functional.interpolate", "torch")
    cross_entropy = registry.resolve("nn.functional.cross_entropy", "torch")

    assert ctc_loss.handler == "torch_ctc_loss"
    assert generate_proposals.handler == "torch_generate_proposals"
    assert generate_proposals.result_index == 0
    assert add.default_kwargs == {"alpha": 1}
    assert subtract.handler == "torch_subtract"
    assert reshape.handler == "torch_reshape"
    assert reduction.handler == "torch_reduction"
    assert norm.handler == "torch_linalg_norm"
    assert tensor_set.computed_kwargs["storage_offset"] == (
        "(kwargs.get('offset') or kwargs.get('storage_offset') or 0) // self.itemsize"
    )
    assert tensor_set.drop_kwargs == ("shape", "offset")
    assert sort.result_index == 0
    assert topk.result_index == 0
    assert unique.result_index == 0
    assert full_like.computed_kwargs["fill_value"] == "fill_value.item() if hasattr(fill_value, 'item') else fill_value"
    assert linear.computed_kwargs["weight"] == "weight.T.contiguous()"
    assert gelu.computed_kwargs["approximate"] == "'tanh' if approximate else 'none'"
    assert transpose.computed_kwargs["dims"] == "tuple(perm) + tuple(range(len(perm), x.ndim))"
    assert transpose.drop_kwargs == ("perm",)
    assert gather.handler == "torch_gather"
    assert scatter.handler == "torch_scatter"
    assert index_select.handler == "torch_index_select"
    assert conv1d.handler == "torch_conv1d"
    assert conv2d.handler == "torch_conv2d"
    assert batch_norm.handler == "torch_batch_norm"
    assert layer_norm.handler == "torch_layer_norm"
    assert pad.handler == "torch_pad"
    assert interpolate.handler == "torch_interpolate"
    assert cross_entropy.handler == "torch_cross_entropy"
