"""Tests to verify 100-API mapping coverage for paddle and torch."""

from __future__ import annotations

from tensor_spec.mapping.registry import MappingRegistry

REQUIRED_APIS = [
    # Math unary (30)
    "abs",
    "acos",
    "acosh",
    "asin",
    "asinh",
    "atan",
    "atanh",
    "ceil",
    "cos",
    "cosh",
    "erf",
    "exp",
    "expm1",
    "floor",
    "log",
    "log10",
    "log1p",
    "log2",
    "neg",
    "reciprocal",
    "round",
    "rsqrt",
    "sign",
    "sin",
    "sinh",
    "sqrt",
    "square",
    "tan",
    "tanh",
    "trunc",
    # Math binary (10)
    "add",
    "subtract",
    "multiply",
    "divide",
    "remainder",
    "pow",
    "maximum",
    "minimum",
    "fmod",
    "atan2",
    # Reduction (10)
    "sum",
    "mean",
    "max",
    "min",
    "prod",
    "any",
    "all",
    "argmax",
    "argmin",
    "cumsum",
    # Linear algebra (5)
    "matmul",
    "dot",
    "bmm",
    "linalg.norm",
    "linalg.det",
    # Shape (15)
    "reshape",
    "transpose",
    "squeeze",
    "unsqueeze",
    "flatten",
    "concat",
    "stack",
    "split",
    "tile",
    "flip",
    "roll",
    "gather",
    "scatter",
    "index_select",
    "masked_select",
    # NN functional (20)
    "nn.functional.relu",
    "nn.functional.sigmoid",
    "nn.functional.softmax",
    "nn.functional.log_softmax",
    "nn.functional.tanh",
    "nn.functional.gelu",
    "nn.functional.silu",
    "nn.functional.leaky_relu",
    "nn.functional.elu",
    "nn.functional.dropout",
    "nn.functional.linear",
    "nn.functional.conv1d",
    "nn.functional.conv2d",
    "nn.functional.batch_norm",
    "nn.functional.layer_norm",
    "nn.functional.pad",
    "nn.functional.interpolate",
    "nn.functional.cross_entropy",
    "nn.functional.mse_loss",
    "nn.functional.l1_loss",
    # Creation/manipulation (10)
    "zeros_like",
    "ones_like",
    "full_like",
    "clone",
    "where",
    "sort",
    "topk",
    "unique",
    "isnan",
    "isfinite",
]


def test_paddle_has_all_required_apis():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    for api in REQUIRED_APIS:
        assert api in reg._mappings["paddle"], f"Missing paddle mapping for: {api}"


def test_torch_has_all_required_apis():
    reg = MappingRegistry()
    reg.load_bundled("torch")
    for api in REQUIRED_APIS:
        assert api in reg._mappings["torch"], f"Missing torch mapping for: {api}"


def test_mapping_count():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    reg.load_bundled("torch")
    assert len(reg._mappings["paddle"]) >= 100
    assert len(reg._mappings["torch"]) >= 100


def test_all_mappings_have_api_field():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    reg.load_bundled("torch")
    for framework in ["paddle", "torch"]:
        for name, mapping in reg._mappings[framework].items():
            assert mapping.api, f"{framework}.{name} has empty api field"
