"""Tests for NumpyComparator."""

from __future__ import annotations

import numpy as np
import pytest

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import ToleranceConfig


@pytest.fixture
def comparator() -> NumpyComparator:
    return NumpyComparator()


@pytest.fixture
def default_tol() -> ToleranceConfig:
    return ToleranceConfig()


class TestCompareResult:
    """Tests for CompareResult dataclass."""

    def test_defaults(self) -> None:
        r = CompareResult(passed=True)
        assert r.passed is True
        assert r.max_abs_diff == 0.0
        assert r.max_rel_diff == 0.0
        assert r.mismatched_count == 0
        assert r.total_count == 0
        assert r.detail == ""

    def test_frozen(self) -> None:
        r = CompareResult(passed=True)
        with pytest.raises(AttributeError):
            setattr(r, "passed", False)


class TestNumpyComparatorExact:
    """Tests for boolean / exact comparison."""

    def test_bool_exact_match(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([True, False, True], dtype=np.bool_)
        b = np.array([True, False, True], dtype=np.bool_)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is True
        assert result.mismatched_count == 0
        assert result.total_count == 3

    def test_bool_mismatch(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([True, False, True], dtype=np.bool_)
        b = np.array([True, True, False], dtype=np.bool_)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is False
        assert result.mismatched_count == 2
        assert result.total_count == 3

    def test_bool_all_false(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([False, False], dtype=np.bool_)
        b = np.array([False, False], dtype=np.bool_)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is True
        assert result.mismatched_count == 0


class TestNumpyComparatorClose:
    """Tests for float close comparison."""

    def test_close_match(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        b = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is True
        assert result.mismatched_count == 0
        assert result.total_count == 3
        assert result.max_abs_diff == pytest.approx(0.0, abs=1e-10)

    def test_close_within_tolerance(self, comparator: NumpyComparator) -> None:
        tol = ToleranceConfig(atol=0.1, rtol=0.1)
        a = np.array([1.0, 2.0, 3.0], dtype=np.float64)
        b = np.array([1.05, 2.05, 3.05], dtype=np.float64)
        result = comparator.compare(a, b, tol)
        assert result.passed is True
        assert result.max_abs_diff == pytest.approx(0.05, abs=1e-10)

    def test_close_mismatch(self, comparator: NumpyComparator) -> None:
        tol = ToleranceConfig(atol=1e-6, rtol=1e-6)
        a = np.array([1.0, 2.0, 3.0], dtype=np.float64)
        b = np.array([1.0, 2.5, 3.0], dtype=np.float64)
        result = comparator.compare(a, b, tol)
        assert result.passed is False
        assert result.mismatched_count >= 1
        assert result.max_abs_diff == pytest.approx(0.5, abs=1e-10)

    def test_nan_equal(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([1.0, np.nan, 3.0], dtype=np.float64)
        b = np.array([1.0, np.nan, 3.0], dtype=np.float64)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is True
        assert result.mismatched_count == 0

    def test_nan_not_equal_to_value(self, comparator: NumpyComparator) -> None:
        tol = ToleranceConfig(atol=1e-6, rtol=1e-6)
        a = np.array([1.0, np.nan, 3.0], dtype=np.float64)
        b = np.array([1.0, 2.0, 3.0], dtype=np.float64)
        result = comparator.compare(a, b, tol)
        assert result.passed is False
        assert result.mismatched_count >= 1

    def test_total_count(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.ones((4, 5), dtype=np.float32)
        b = np.ones((4, 5), dtype=np.float32)
        result = comparator.compare(a, b, default_tol)
        assert result.total_count == 20

    def test_integer_arrays(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([1, 2, 3], dtype=np.int32)
        b = np.array([1, 2, 3], dtype=np.int32)
        result = comparator.compare(a, b, default_tol)
        assert result.passed is True

    def test_float16_arrays(self, comparator: NumpyComparator) -> None:
        tol = ToleranceConfig(atol=0.1, rtol=0.1)
        a = np.array([1.0, 2.0, 3.0], dtype=np.float16)
        b = np.array([1.0, 2.0, 3.0], dtype=np.float16)
        result = comparator.compare(a, b, tol)
        assert result.passed is True


class TestNumpyComparatorShape:
    """Tests for shape mismatch handling."""

    def test_shape_mismatch(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.array([1.0, 2.0, 3.0])
        b = np.array([1.0, 2.0])
        result = comparator.compare(a, b, default_tol)
        assert result.passed is False
        assert "Shape mismatch" in result.detail
        assert result.total_count == 3

    def test_shape_mismatch_nd(self, comparator: NumpyComparator, default_tol: ToleranceConfig) -> None:
        a = np.ones((2, 3))
        b = np.ones((3, 2))
        result = comparator.compare(a, b, default_tol)
        assert result.passed is False
        assert "Shape mismatch" in result.detail
        assert "(2, 3)" in result.detail
        assert "(3, 2)" in result.detail

    def test_shape_mismatch_total_count_uses_larger(
        self,
        comparator: NumpyComparator,
        default_tol: ToleranceConfig,
    ) -> None:
        a = np.ones((10,))
        b = np.ones((5,))
        result = comparator.compare(a, b, default_tol)
        assert result.total_count == 10
