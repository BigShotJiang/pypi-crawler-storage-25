"""Tests for ProjectConfig and related dataclasses."""

from __future__ import annotations

import pytest

from tensor_spec.config.project import (
    BenchConfig,
    DefaultsConfig,
    ProjectConfig,
    SourceConfig,
    TargetConfig,
)


class TestSourceConfig:
    def test_defaults(self) -> None:
        src = SourceConfig()
        assert src.index_url == ""
        assert src.extra_index_url == "https://pypi.org/simple/"
        assert src.index_strategy == ""
        assert src.package == ""
        assert src.version == ""
        assert src.whl == ""
        assert src.python_version == "3.12"
        assert src.cuda_version == "cu129"

    def test_frozen(self) -> None:
        src = SourceConfig()
        with pytest.raises(AttributeError):
            setattr(src, "index_url", "x")


class TestTargetConfig:
    def test_defaults(self) -> None:
        tgt = TargetConfig()
        assert tgt.backend == ""
        assert tgt.device == ""
        assert tgt.python == ""

    def test_frozen(self) -> None:
        tgt = TargetConfig(backend="torch", device="cuda", python="/usr/bin/python")
        with pytest.raises(AttributeError):
            setattr(tgt, "backend", "paddle")


class TestDefaultsConfig:
    def test_defaults(self) -> None:
        cfg = DefaultsConfig()
        assert cfg.targets == ()
        assert cfg.format == "human"
        assert cfg.seed == 42
        assert cfg.verbose is False

    def test_frozen(self) -> None:
        cfg = DefaultsConfig()
        with pytest.raises(AttributeError):
            setattr(cfg, "seed", 99)


class TestBenchConfig:
    def test_defaults(self) -> None:
        bench = BenchConfig()
        assert bench.mode == "e2e"
        assert bench.artifacts_dir == "./.tensor-spec/bench-artifacts"
        assert bench.e2e.warmup == 5
        assert bench.e2e.repeat == 20
        assert bench.e2e.percentiles == (50, 90, 95, 99)
        assert bench.ncu.metrics == ("time", "occupancy", "memory_throughput")
        assert bench.ncu.save_artifacts is True

    def test_frozen(self) -> None:
        bench = BenchConfig()
        with pytest.raises(AttributeError):
            setattr(bench, "mode", "ncu")


class TestProjectConfig:
    def test_from_toml(self, tmp_path) -> None:
        toml_content = """\
[sources.paddle]
index_url = "https://example.com/paddle/"
index_strategy = "unsafe-best-match"
package = "paddlepaddle-gpu"

[sources.torch]
whl = "/tmp/torch.whl"

[defaults]
targets = ["paddle-cu124", "torch-cu124"]
format = "json"
seed = 123
verbose = true

[targets.paddle-cu124]
backend = "paddle"
device = "cuda"
python = "/venv/paddle/bin/python"

[targets.torch-cu124]
backend = "torch"
device = "cuda"
python = "/venv/torch/bin/python"

[tolerance.default]
atol = 0.1
rtol = 0.2

[tolerance.overrides.matmul]
atol = 2.0
rtol = 0.05

[bench]
mode = "e2e"
        artifacts_dir = "./.tensor-spec/my-artifacts"

[bench.e2e]
warmup = 10
repeat = 50

[bench.ncu]
metrics = ["time", "occupancy"]
save_artifacts = false
"""
        f = tmp_path / "tensor-spec.toml"
        f.write_text(toml_content)

        config = ProjectConfig.from_toml(f)
        assert "paddle" in config.sources
        assert config.sources["paddle"].index_url == "https://example.com/paddle/"
        assert config.sources["paddle"].index_strategy == "unsafe-best-match"
        assert config.sources["paddle"].package == "paddlepaddle-gpu"
        assert config.sources["torch"].whl == "/tmp/torch.whl"
        assert config.defaults.targets == ("paddle-cu124", "torch-cu124")
        assert config.defaults.format == "json"
        assert config.defaults.seed == 123
        assert config.defaults.verbose is True
        assert "paddle-cu124" in config.targets
        assert config.targets["paddle-cu124"].backend == "paddle"
        assert config.targets["paddle-cu124"].device == "cuda"
        assert config.targets["paddle-cu124"].python == "/venv/paddle/bin/python"
        assert config.targets["torch-cu124"].backend == "torch"
        assert config.tolerance_data["default"]["atol"] == pytest.approx(0.1)
        assert config.tolerance_data["overrides"]["matmul"]["atol"] == pytest.approx(2.0)
        assert config.bench.mode == "e2e"
        assert config.bench.artifacts_dir == "./.tensor-spec/my-artifacts"
        assert config.bench.e2e.warmup == 10
        assert config.bench.e2e.repeat == 50
        assert config.bench.ncu.metrics == ("time", "occupancy")
        assert config.bench.ncu.save_artifacts is False

    def test_from_toml_minimal(self, tmp_path) -> None:
        """Minimal TOML with only [defaults] should work."""
        toml_content = """\
[defaults]
seed = 77
"""
        f = tmp_path / "tensor-spec.toml"
        f.write_text(toml_content)

        config = ProjectConfig.from_toml(f)
        assert config.defaults.seed == 77
        assert config.defaults.targets == ()
        assert config.defaults.format == "human"
        assert config.targets == {}
        assert config.bench.mode == "e2e"

    def test_find_and_load_found(self, tmp_path) -> None:
        toml_content = """\
[defaults]
seed = 77
"""
        (tmp_path / "tensor-spec.toml").write_text(toml_content)
        sub = tmp_path / "a" / "b"
        sub.mkdir(parents=True)

        config = ProjectConfig.find_and_load(start_dir=sub)
        assert config is not None
        assert config.defaults.seed == 77

    def test_find_and_load_not_found(self, tmp_path) -> None:
        sub = tmp_path / "empty"
        sub.mkdir()
        config = ProjectConfig.find_and_load(start_dir=sub)
        assert config is None

    def test_get_source_builtin_defaults(self) -> None:
        config = ProjectConfig()
        paddle_src = config.get_source("paddle")
        torch_src = config.get_source("torch")
        assert "paddlepaddle" in paddle_src.index_url or "paddlepaddle" in paddle_src.package
        assert paddle_src.package == "paddlepaddle-gpu"
        assert paddle_src.version == "3.3.0"
        assert paddle_src.index_strategy == "unsafe-best-match"
        assert torch_src.package == "torch"
        assert torch_src.version == "2.9.1"
        assert torch_src.index_strategy == "unsafe-best-match"

    def test_get_source_user_overrides_builtin(self) -> None:
        config = ProjectConfig(
            sources={"paddle": SourceConfig(index_url="https://custom.example.com/", package="my-paddle")}
        )
        paddle_src = config.get_source("paddle")
        assert paddle_src.index_url == "https://custom.example.com/"
        assert paddle_src.package == "my-paddle"

    def test_resolve_index_url_interpolation(self) -> None:
        config = ProjectConfig(sources={"paddle": SourceConfig(cuda_version="cu118")})
        url = config.resolve_index_url("paddle")
        assert "cu118" in url

    def test_resolve_target(self) -> None:
        config = ProjectConfig(
            targets={"my-torch": TargetConfig(backend="torch", device="cuda", python="/usr/bin/python")}
        )
        tgt = config.resolve_target("my-torch")
        assert tgt.backend == "torch"
        assert tgt.device == "cuda"

    def test_resolve_target_unknown(self) -> None:
        config = ProjectConfig()
        with pytest.raises(ValueError, match="Unknown target"):
            config.resolve_target("nonexistent")

    def test_frozen(self) -> None:
        config = ProjectConfig()
        with pytest.raises(AttributeError):
            setattr(config, "defaults", DefaultsConfig())
