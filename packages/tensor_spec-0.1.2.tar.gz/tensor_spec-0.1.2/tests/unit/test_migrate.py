from pathlib import Path

import pytest

from tensor_spec.config.parser import parse_case
from tensor_spec.migrate import MigrationError, migrate_case_file, migrate_case_line


def test_migrate_case_line_simple_function() -> None:
    migrated = migrate_case_line('paddle.add(Tensor([2, 3],"float32"), Tensor([2, 3],"float32"), None, )')
    assert migrated == "add(Tensor.float32((2, 3)), Tensor.float32((2, 3)))"
    case = parse_case(migrated)
    assert case.api_name == "add"
    assert len(case.args) == 2


def test_migrate_case_line_tensor_alias_and_kwarg() -> None:
    migrated = migrate_case_line('paddle.Tensor.__add__(Tensor([2],"float32"), Tensor([2],"float32"), name="demo", )')
    assert migrated == "add(Tensor.float32((2)), Tensor.float32((2)))"
    case = parse_case(migrated)
    assert case.api_name == "add"
    assert case.kwargs == {}


def test_migrate_case_line_list_subscription() -> None:
    migrated = migrate_case_line('paddle.add_n(list[Tensor([1],"float32"), Tensor([1],"float32")], name="demo", )')
    assert migrated == "add_n([Tensor.float32((1)), Tensor.float32((1))])"
    case = parse_case(migrated)
    assert case.api_name == "add_n"
    assert len(case.args[0]) == 2


def test_migrate_case_line_empty_list_syntax() -> None:
    migrated = migrate_case_line('paddle.sum(Tensor([],"float32"), axis=list[], keepdim=False, )')
    assert migrated == "sum(Tensor.float32(()), axis=[], keepdim=False)"
    case = parse_case(migrated)
    assert case.kwargs["axis"] == []


def test_migrate_case_line_rejects_unknown_nested_call() -> None:
    with pytest.raises(MigrationError, match="Unsupported nested call"):
        migrate_case_line('paddle.add(Unknown(1), Tensor([1],"float32"))')


def test_migrate_case_line_dtype_wrapper() -> None:
    migrated = migrate_case_line("paddle.linspace(0, 10, 5, dtype=Dtype(float32), )")
    assert migrated == 'linspace(0, 10, 5, dtype="float32")'
    case = parse_case(migrated)
    assert case.kwargs["dtype"] == "float32"


def test_migrate_case_line_complex_and_inf() -> None:
    migrated = migrate_case_line('paddle.Tensor.__add__(Tensor([2],"float32"), complex(0.0,2.0), value=-math.inf, )')
    assert migrated == "add(Tensor.float32((2)), complex(0.0, 2.0), value=-1e309)"
    case = parse_case(migrated)
    assert case.args[1] == complex(0.0, 2.0)
    assert case.kwargs["value"] == float("-inf")


def test_migrate_case_line_keeps_non_name_none() -> None:
    migrated = migrate_case_line('paddle.divide(Tensor([2],"float32"), Tensor([2],"float32"), rounding_mode=None)')
    assert migrated == "divide(Tensor.float32((2)), Tensor.float32((2)), rounding_mode=None)"
    case = parse_case(migrated)
    assert case.kwargs["rounding_mode"] is None


def test_migrate_case_file_writes_output_and_rejects(tmp_path: Path) -> None:
    src = tmp_path / "legacy.txt"
    src.write_text(
        "# comment\n"
        'paddle.add(Tensor([1],"float32"), Tensor([1],"float32"), )\n'
        'paddle.add(Unknown(1), Tensor([1],"float32"))\n'
        "\n",
        encoding="utf-8",
    )
    output = tmp_path / "migrated.txt"
    rejects = tmp_path / "rejects.txt"

    summary = migrate_case_file(src, output, rejects)

    assert summary.total_lines == 4
    assert summary.migrated_cases == 1
    assert summary.rejected_cases == 1
    assert summary.rejects_path == rejects
    assert output.read_text(encoding="utf-8") == "# comment\nadd(Tensor.float32((1)), Tensor.float32((1)))\n\n"
    reject_text = rejects.read_text(encoding="utf-8")
    assert "Unsupported nested call 'Unknown'" in reject_text
    assert 'paddle.add(Unknown(1), Tensor([1],"float32"))' in reject_text
