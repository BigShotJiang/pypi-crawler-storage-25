"""Tests for the Coordinator that manages worker subprocesses."""

from __future__ import annotations

import sys
from typing import Any, cast

import numpy as np
import pytest

from tensor_spec.worker.coordinator import Coordinator, WorkerHandle
from tensor_spec_core.tensor import Tensor


class TestCoordinatorLifecycle:
    def test_start_and_ping(self):
        coord = Coordinator()
        try:
            coord.start_worker("w1", sys.executable, "paddle")
            assert "w1" in coord.workers
        finally:
            coord.shutdown_all()

    def test_shutdown_all(self):
        coord = Coordinator()
        coord.start_worker("w1", sys.executable, "paddle")
        coord.shutdown_all()
        assert coord.workers["w1"].process.returncode is not None


@pytest.fixture()
def coord_with_paddle():
    """Coordinator with one paddle worker (skips if no paddle)."""
    pytest.importorskip("paddle")
    coord = Coordinator()
    coord.start_worker("paddle", sys.executable, "paddle")
    coord.import_framework("paddle")
    yield coord
    coord.shutdown_all()


class TestCoordinatorSendReceive:
    def test_send_numpy_and_get_back(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        assert tid.startswith("t")
        result = coord_with_paddle.get_numpy("paddle", tid)
        np.testing.assert_array_equal(result, arr)

    def test_exec_api_abs(self, coord_with_paddle):
        arr = np.array([-1.0, 2.0, -3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api("paddle", "abs", [tid], {})
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_exec_api_with_kwargs(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api(
            "paddle",
            "abs",
            [],
            {"x": tid},
        )
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_free_tensor(self, coord_with_paddle):
        arr = np.array([1.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        coord_with_paddle.free_tensor("paddle", tid)


class TestCoordinatorErrors:
    def test_exec_api_failure(self, coord_with_paddle):
        with pytest.raises(RuntimeError, match="error"):
            coord_with_paddle.exec_api("paddle", "nonexistent_api_xyz", [], {})

    def test_unknown_worker(self):
        coord = Coordinator()
        with pytest.raises(KeyError):
            coord.send_numpy("nonexistent", np.array([1.0]))
        coord.shutdown_all()

    def test_get_ipc_handle_failure(self):
        coord = Coordinator()
        coord.workers["w1"] = cast(WorkerHandle, _FakeWorkerHandle({"ok": False, "error": "ipc failed"}))

        with pytest.raises(RuntimeError, match="ipc failed"):
            coord.get_ipc_handle("w1", "t1")

    def test_open_ipc_handle_failure(self):
        coord = Coordinator()
        coord.workers["w1"] = cast(WorkerHandle, _FakeWorkerHandle({"ok": False, "error": "open failed"}))

        with pytest.raises(RuntimeError, match="open failed"):
            coord.open_ipc_handle("w1", {"handle": "abc", "shape": [1], "dtype": "float32"})

    def test_compare_tensors_failure(self):
        coord = Coordinator()
        coord.workers["w1"] = cast(WorkerHandle, _FakeWorkerHandle({"ok": False, "error": "compare failed"}))

        with pytest.raises(RuntimeError, match="compare failed"):
            coord.compare_tensors("w1", "t1", "t2", 0.1, 0.1)

    def test_generate_tensor_failure(self):
        coord = Coordinator()
        coord.workers["w1"] = cast(WorkerHandle, _FakeWorkerHandle({"ok": False, "error": "generate failed"}))

        with pytest.raises(RuntimeError, match="generate failed"):
            coord.generate_tensor("w1", Tensor.float32((2,)), seed=42, ordinal=0)


class _FakeWorkerHandle:
    def __init__(self, response: dict[str, Any]) -> None:
        self._response = response

    def send(self, msg_type: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._response
