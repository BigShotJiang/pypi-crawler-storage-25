import numpy as np

from tensor_spec.datagen.constraints import NonZeroConstraint, PositiveDefiniteConstraint


def test_nonzero_constraint():
    data = np.array([0.0, 1.0, 0.0, -1.0], dtype=np.float32)
    c = NonZeroConstraint()
    result = c.apply(data)
    assert np.all(result != 0.0)
    assert result[1] == 1.0
    assert result[3] == -1.0


def test_positive_definite_constraint():
    rng = np.random.default_rng(42)
    data = rng.uniform(-1, 1, (4, 4)).astype(np.float64)
    c = PositiveDefiniteConstraint()
    result = c.apply(data)
    eigenvalues = np.linalg.eigvalsh(result)
    assert np.all(eigenvalues > 0)


def test_positive_definite_batched():
    rng = np.random.default_rng(42)
    data = rng.uniform(-1, 1, (3, 4, 4)).astype(np.float64)
    c = PositiveDefiniteConstraint()
    result = c.apply(data)
    assert result.shape == (3, 4, 4)
    for i in range(3):
        eigenvalues = np.linalg.eigvalsh(result[i])
        assert np.all(eigenvalues > 0)
