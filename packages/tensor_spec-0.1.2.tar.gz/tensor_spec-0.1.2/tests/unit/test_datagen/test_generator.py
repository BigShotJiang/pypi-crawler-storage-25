import numpy as np

from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec_core.stats import BoolStats, FloatStats, IntStats
from tensor_spec_core.tensor import Tensor


def test_generate_float32():
    spec = Tensor.float32((2, 3))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (2, 3)
    assert data.dtype == np.float32


def test_generate_float64():
    spec = Tensor.float64((100,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (100,)
    assert data.dtype == np.float64


def test_generate_float_with_stats():
    spec = Tensor.float32((1000,)).with_stats(FloatStats(min=-10.0, max=10.0))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.min() >= -10.0
    assert data.max() <= 10.0


def test_generate_float_nonzero():
    spec = Tensor.float32((100,)).with_stats(FloatStats(nonzero=True))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert np.all(data != 0.0)


def test_generate_float_positive_definite():
    spec = Tensor.float64((4, 4)).with_stats(FloatStats(positive_definite=True))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    eigenvalues = np.linalg.eigvalsh(data)
    assert np.all(eigenvalues > 0)


def test_generate_int64():
    spec = Tensor.int64((10,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (10,)
    assert data.dtype == np.int64


def test_generate_int_with_stats():
    spec = Tensor.int32((100,)).with_stats(IntStats(low=0, high=10))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert np.all(data >= 0)
    assert np.all(data < 10)


def test_generate_bool():
    spec = Tensor.bool((100,))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    assert data.shape == (100,)
    assert data.dtype == np.bool_


def test_generate_bool_true_ratio():
    spec = Tensor.bool((10000,)).with_stats(BoolStats(true_ratio=0.8))
    gen = TensorGenerator(seed=42)
    data = gen.generate(spec)
    ratio = data.sum() / len(data)
    assert 0.75 < ratio < 0.85


def test_generate_deterministic():
    spec = Tensor.float32((10,))
    data1 = TensorGenerator(seed=42).generate(spec)
    data2 = TensorGenerator(seed=42).generate(spec)
    np.testing.assert_array_equal(data1, data2)
