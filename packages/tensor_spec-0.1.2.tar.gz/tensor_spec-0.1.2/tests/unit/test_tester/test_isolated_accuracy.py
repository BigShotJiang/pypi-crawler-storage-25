"""Tests for IsolatedAccuracyTester."""

from __future__ import annotations

import sys

import numpy as np
import pytest

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.tester.base import TestStatus
from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester, WorkerTensorRef
from tensor_spec_core.tensor import Tensor


@pytest.fixture()
def _both_frameworks():
    pytest.importorskip("paddle")
    pytest.importorskip("torch")


@pytest.fixture()
def isolated_tester(_both_frameworks):
    """IsolatedAccuracyTester with real workers using current Python."""
    from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

    mapping = MappingRegistry()
    mapping.load_bundled("paddle")
    mapping.load_bundled("torch")
    tester = IsolatedAccuracyTester(
        backends=[
            ("paddle", sys.executable, "paddle"),
            ("torch", sys.executable, "torch"),
        ],
        mapping=mapping,
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    yield tester
    tester.shutdown()


class TestIsolatedAccuracyPass:
    def test_abs_passes(self, isolated_tester):
        case = CaseConfig(
            api_name="abs",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED
        assert result.compare_result is not None
        assert result.compare_result.passed is True

    def test_add_passes(self, isolated_tester):
        case = CaseConfig(
            api_name="add",
            args=(),
            kwargs={"x": Tensor.float32((3,)), "y": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED


class TestIsolatedAccuracyError:
    def test_unknown_api_returns_error(self, isolated_tester):
        case = CaseConfig(
            api_name="totally_fake_api",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status in (
            TestStatus.BACKEND_ERROR,
            TestStatus.ERROR,
        )
        assert result.error is not None


class TestIsolatedAccuracyDuration:
    def test_duration_is_positive(self, isolated_tester):
        case = CaseConfig(
            api_name="abs",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.duration_ms > 0


class _FakeCoordinator:
    def __init__(self) -> None:
        self.calls: list[tuple] = []
        self.numpy_outputs: dict[tuple[str, str], np.ndarray] = {}
        self.compare_result = CompareResult(passed=True)
        self.tensor_infos: dict[tuple[str, str], dict[str, object]] = {}
        self.open_error: RuntimeError | None = None
        self.compare_error: RuntimeError | None = None

    def send_numpy(self, worker_name: str, arr: np.ndarray, spec) -> str:
        self.calls.append(("send_numpy", worker_name, tuple(arr.shape), spec.dtype))
        return f"t_send_{len(self.calls)}"

    def generate_tensor(self, worker_name: str, spec, seed: int, ordinal: int) -> str:
        self.calls.append(("generate_tensor", worker_name, spec.dtype, str(spec.device), seed, ordinal))
        return f"t_gen_{ordinal}"

    def exec_api(
        self,
        worker_name: str,
        api: str,
        args: list[object],
        kwargs: dict[str, object],
        mapping: dict[str, object],
    ) -> str:
        self.calls.append(("exec_api", worker_name, api, tuple(args), tuple(sorted(kwargs.items()))))
        return "t_result"

    def get_tensor_info(self, worker_name: str, tensor_id: str) -> dict[str, object]:
        self.calls.append(("get_tensor_info", worker_name, tensor_id))
        return self.tensor_infos.get((worker_name, tensor_id), {"shape": [2], "dtype": "float32", "device": "cuda:0"})

    def empty_cache(self, worker_name: str) -> None:
        self.calls.append(("empty_cache", worker_name))

    def get_ipc_handle(self, worker_name: str, tensor_id: str) -> dict[str, object]:
        self.calls.append(("get_ipc_handle", worker_name, tensor_id))
        return {"handle": "ZmFrZQ==", "shape": [2], "dtype": "float32", "device": "cuda:0"}

    def open_ipc_handle(self, worker_name: str, handle_info: dict[str, object]) -> str:
        self.calls.append(("open_ipc_handle", worker_name, handle_info["device"]))
        if self.open_error is not None:
            raise self.open_error
        return "t_ipc"

    def compare_tensors(
        self,
        worker_name: str,
        actual_tensor_id: str,
        expected_tensor_id: str,
        atol: float,
        rtol: float,
    ) -> dict[str, object]:
        self.calls.append(("compare_tensors", worker_name, actual_tensor_id, expected_tensor_id, atol, rtol))
        if self.compare_error is not None:
            raise self.compare_error
        return {
            "passed": self.compare_result.passed,
            "max_abs_diff": self.compare_result.max_abs_diff,
            "max_rel_diff": self.compare_result.max_rel_diff,
            "mismatched_count": self.compare_result.mismatched_count,
            "total_count": self.compare_result.total_count,
            "detail": self.compare_result.detail,
        }

    def close_ipc_handle(self, worker_name: str, tensor_id: str) -> None:
        self.calls.append(("close_ipc_handle", worker_name, tensor_id))

    def check_cuda_error(self, worker_name: str) -> None:
        self.calls.append(("check_cuda_error", worker_name))

    def get_numpy(self, worker_name: str, tensor_id: str) -> np.ndarray:
        self.calls.append(("get_numpy", worker_name, tensor_id))
        return self.numpy_outputs[(worker_name, tensor_id)]

    def free_tensor(self, worker_name: str, tensor_id: str) -> None:
        self.calls.append(("free_tensor", worker_name, tensor_id))


def _make_gpu_tester(fake_coord: _FakeCoordinator) -> IsolatedAccuracyTester:
    tester = object.__new__(IsolatedAccuracyTester)
    setattr(
        tester,
        "_backends",
        [
            ("paddle", sys.executable, "paddle"),
            ("torch", sys.executable, "torch"),
        ],
    )
    setattr(tester, "_mapping", MappingRegistry())
    setattr(tester, "_comparator", NumpyComparator())
    setattr(tester, "_tolerance", Tolerance())
    setattr(tester, "_generator", TensorGenerator(seed=42))
    setattr(tester, "_gpu_comparators", ("torch", "jax", "paddle"))
    setattr(tester, "_coordinator", fake_coord)
    setattr(
        tester,
        "_backend_capabilities",
        {
            "paddle": {"name": "paddle", "supports_gpu_compare": False},
            "torch": {"name": "torch", "supports_gpu_compare": True},
        },
    )
    return tester


def test_compare_prefers_gpu_path_when_supported():
    fake_coord = _FakeCoordinator()
    tester = _make_gpu_tester(fake_coord)
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    outputs = {
        "paddle": WorkerTensorRef("paddle", "paddle", "t_ref", (2,), "float32", "cuda:0"),
        "torch": WorkerTensorRef("torch", "torch", "t_other", (2,), "float32", "cuda:0"),
    }

    result = tester.compare(case, outputs)

    assert result.status == TestStatus.PASSED
    assert ("get_ipc_handle", "paddle", "t_ref") in fake_coord.calls
    assert ("open_ipc_handle", "torch", "cuda:0") in fake_coord.calls
    assert ("compare_tensors", "torch", "t_ipc", "t_other", 0.01, 0.01) in fake_coord.calls
    assert not any(call[0] == "get_numpy" for call in fake_coord.calls)


def test_compare_falls_back_to_numpy_for_cpu_outputs():
    fake_coord = _FakeCoordinator()
    fake_coord.numpy_outputs = {
        ("paddle", "t_ref"): np.array([1.0, 2.0], dtype=np.float32),
        ("torch", "t_other"): np.array([1.0, 2.0], dtype=np.float32),
    }
    tester = _make_gpu_tester(fake_coord)
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    outputs = {
        "paddle": WorkerTensorRef("paddle", "paddle", "t_ref", (2,), "float32", "cpu"),
        "torch": WorkerTensorRef("torch", "torch", "t_other", (2,), "float32", "cpu"),
    }

    result = tester.compare(case, outputs)

    assert result.status == TestStatus.PASSED
    assert ("get_numpy", "paddle", "t_ref") in fake_coord.calls
    assert ("get_numpy", "torch", "t_other") in fake_coord.calls
    assert not any(call[0] == "compare_tensors" for call in fake_coord.calls)


def test_compare_falls_back_to_numpy_when_open_ipc_handle_fails():
    fake_coord = _FakeCoordinator()
    fake_coord.open_error = RuntimeError("open failed")
    fake_coord.numpy_outputs = {
        ("paddle", "t_ref"): np.array([1.0, 2.0], dtype=np.float32),
        ("torch", "t_other"): np.array([1.0, 2.0], dtype=np.float32),
    }
    tester = _make_gpu_tester(fake_coord)
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    outputs = {
        "paddle": WorkerTensorRef("paddle", "paddle", "t_ref", (2,), "float32", "cuda:0"),
        "torch": WorkerTensorRef("torch", "torch", "t_other", (2,), "float32", "cuda:0"),
    }

    result = tester.compare(case, outputs)

    assert result.status == TestStatus.PASSED
    assert ("open_ipc_handle", "torch", "cuda:0") in fake_coord.calls
    assert ("get_numpy", "paddle", "t_ref") in fake_coord.calls
    assert ("get_numpy", "torch", "t_other") in fake_coord.calls
    assert not any(call[0] == "close_ipc_handle" for call in fake_coord.calls)


def test_compare_falls_back_to_numpy_when_gpu_compare_fails():
    fake_coord = _FakeCoordinator()
    fake_coord.compare_error = RuntimeError("compare failed")
    fake_coord.numpy_outputs = {
        ("paddle", "t_ref"): np.array([1.0, 2.0], dtype=np.float32),
        ("torch", "t_other"): np.array([1.0, 2.0], dtype=np.float32),
    }
    tester = _make_gpu_tester(fake_coord)
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    outputs = {
        "paddle": WorkerTensorRef("paddle", "paddle", "t_ref", (2,), "float32", "cuda:0"),
        "torch": WorkerTensorRef("torch", "torch", "t_other", (2,), "float32", "cuda:0"),
    }

    result = tester.compare(case, outputs)

    assert result.status == TestStatus.PASSED
    assert ("compare_tensors", "torch", "t_ipc", "t_other", 0.01, 0.01) in fake_coord.calls
    assert ("close_ipc_handle", "torch", "t_ipc") in fake_coord.calls
    assert ("get_numpy", "paddle", "t_ref") in fake_coord.calls
    assert ("get_numpy", "torch", "t_other") in fake_coord.calls


def test_execute_uses_worker_generation_for_gpu_inputs():
    from tensor_spec_core.device import Device

    fake_coord = _FakeCoordinator()
    tester = _make_gpu_tester(fake_coord)
    tester._mapping.load_bundled("torch")
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": Tensor.float32((3,), device=Device.cuda(0))},
    )
    inputs = tester._generate_inputs(case)

    output = tester._execute_on_worker("torch", "torch", case, inputs)

    assert output.tensor_id == "t_result"
    assert ("generate_tensor", "torch", "float32", "cuda:0", 42, 0) in fake_coord.calls
    assert not any(call[0] == "send_numpy" for call in fake_coord.calls)


def test_iter_tensor_ids_ignores_plain_strings():
    from tensor_spec.tester.isolated_accuracy import _iter_tensor_ids

    values = ("train", "test", "true", "t12", ["token", "t7"], {"name": "text", "tensor": "t3"})

    assert _iter_tensor_ids(values) == ["t12", "t7", "t3"]
