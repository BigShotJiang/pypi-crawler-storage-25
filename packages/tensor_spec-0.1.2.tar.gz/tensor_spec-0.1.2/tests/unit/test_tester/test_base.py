"""Tests for tester.base module."""

from __future__ import annotations

from tensor_spec.compare.comparator import CompareResult
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.tester.base import (
    GeneratedInputs,
    TensorInputPlan,
    TesterBase,
    TestResult,
    TestStatus,
)
from tensor_spec_core.device import Device
from tensor_spec_core.tensor import Tensor


class TestTestStatus:
    """Tests for TestStatus enum."""

    def test_test_status_values(self) -> None:
        assert TestStatus.PASSED.value == "pass"
        assert TestStatus.ACCURACY_ERROR.value == "accuracy_error"
        assert TestStatus.BACKEND_ERROR.value == "backend_error"
        assert TestStatus.CUDA_ERROR.value == "cuda_error"
        assert TestStatus.OOM_ERROR.value == "oom"
        assert TestStatus.ERROR.value == "error"

    def test_test_status_count(self) -> None:
        assert len(TestStatus) == 6


class TestTestResult:
    """Tests for TestResult dataclass."""

    def test_test_result_creation(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(case=case, status=TestStatus.PASSED)
        assert result.case is case
        assert result.status == TestStatus.PASSED
        assert result.compare_result is None
        assert result.error is None
        assert result.duration_ms == 0.0

    def test_test_result_with_error(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(
            case=case,
            status=TestStatus.ERROR,
            error="something went wrong",
            duration_ms=42.5,
        )
        assert result.status == TestStatus.ERROR
        assert result.error == "something went wrong"
        assert result.duration_ms == 42.5

    def test_test_result_with_compare_result(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        cmp = CompareResult(
            passed=True,
            max_abs_diff=0.001,
            max_rel_diff=0.0001,
            mismatched_count=0,
            total_count=100,
        )
        result = TestResult(
            case=case,
            status=TestStatus.PASSED,
            compare_result=cmp,
        )
        assert result.compare_result is not None
        assert result.compare_result.passed is True

    def test_test_result_is_mutable(self) -> None:
        """TestResult must be mutable so duration_ms can be set after creation."""
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(case=case, status=TestStatus.PASSED)
        result.duration_ms = 123.4
        assert result.duration_ms == 123.4


class TestGeneratedInputs:
    """Tests for GeneratedInputs dataclass."""

    def test_defaults(self) -> None:
        gi = GeneratedInputs()
        assert gi.args == ()
        assert gi.kwargs == {}

    def test_with_data(self) -> None:
        plan = TensorInputPlan(spec=Tensor.float32((2, 3)), ordinal=0)
        gi = GeneratedInputs(
            args=(plan, 1),
            kwargs={"x": plan},
        )
        assert len(gi.args) == 2
        assert gi.args[0] is plan
        assert gi.args[1] == 1
        assert gi.kwargs["x"] is plan


class _DummyTester(TesterBase):
    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, object]:
        return {}

    def compare(self, case: CaseConfig, outputs: dict[str, object]) -> TestResult:
        return TestResult(case=case, status=TestStatus.PASSED)


class TestInputPlanning:
    def test_plans_cpu_and_gpu_inputs_in_order(self) -> None:
        tester = _DummyTester(TensorGenerator(seed=42))
        case = CaseConfig(
            api_name="add",
            args=(Tensor.float32((2,)), (Tensor.float32((1,)), Tensor.float32((1,), device=Device.cuda(0)))),
            kwargs={"x": Tensor.int32((3,))},
        )

        inputs = tester._generate_inputs(case)

        first = inputs.args[0]
        nested_cpu = inputs.args[1][0]
        nested_gpu = inputs.args[1][1]
        kwarg = inputs.kwargs["x"]

        assert isinstance(first, TensorInputPlan)
        assert isinstance(nested_cpu, TensorInputPlan)
        assert isinstance(nested_gpu, TensorInputPlan)
        assert isinstance(kwarg, TensorInputPlan)
        assert [first.ordinal, nested_cpu.ordinal, nested_gpu.ordinal, kwarg.ordinal] == [0, 1, 2, 3]
        assert first.array is not None
        assert nested_cpu.array is not None
        assert nested_gpu.array is None
        assert kwarg.array is not None
