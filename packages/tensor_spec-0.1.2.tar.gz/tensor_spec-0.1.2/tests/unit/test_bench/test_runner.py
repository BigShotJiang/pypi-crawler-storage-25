"""Unit tests for bench.runner module."""

from __future__ import annotations

from unittest.mock import MagicMock

from tensor_spec.bench.runner import BenchCaseResult, BenchRunner
from tensor_spec.config.case import CaseConfig
from tensor_spec.tester.base import TestResult, TestStatus


def _make_case(api_name: str = "test_api") -> CaseConfig:
    """Create a minimal CaseConfig for testing."""
    return CaseConfig(api_name=api_name, args=(), kwargs={})


def _make_result(case: CaseConfig, *, duration_ms: float = 5.0, status: TestStatus = TestStatus.PASSED) -> TestResult:
    """Create a TestResult with a given duration."""
    return TestResult(case=case, status=status, duration_ms=duration_ms)


class TestBenchRunner:
    """Tests for BenchRunner."""

    def test_basic_run(self) -> None:
        case = _make_case()
        mock_tester = MagicMock()
        mock_tester.test.return_value = _make_result(case, duration_ms=10.0)

        runner = BenchRunner(tester=mock_tester, warmup=3, repeat=5)
        result = runner.run(case, target_name="my-target")

        assert isinstance(result, BenchCaseResult)
        assert result.warmup_count == 3
        assert result.repeat_count == 5
        assert result.target_name == "my-target"
        assert result.test_status == TestStatus.PASSED
        assert len(result.raw_times_ms) == 5
        # 3 warmup + 5 measure = 8 calls
        assert mock_tester.test.call_count == 8

    def test_warmup_failure_aborts(self) -> None:
        case = _make_case()
        mock_tester = MagicMock()
        mock_tester.test.return_value = _make_result(case, status=TestStatus.BACKEND_ERROR, duration_ms=1.0)

        runner = BenchRunner(tester=mock_tester, warmup=5, repeat=10)
        result = runner.run(case, target_name="bad-target")

        assert result.test_status == TestStatus.BACKEND_ERROR
        assert result.repeat_count == 0
        # Should stop after first warmup failure
        assert mock_tester.test.call_count == 1

    def test_measurement_failure_stops_early(self) -> None:
        case = _make_case()
        call_count = 0

        def side_effect(_case: CaseConfig) -> TestResult:
            nonlocal call_count
            call_count += 1
            if call_count <= 3:
                # warmup passes
                return _make_result(case, duration_ms=5.0)
            if call_count <= 5:
                # first 2 measurement passes
                return _make_result(case, duration_ms=10.0)
            # 3rd measurement fails
            return _make_result(case, status=TestStatus.OOM_ERROR, duration_ms=99.0)

        mock_tester = MagicMock()
        mock_tester.test.side_effect = side_effect

        runner = BenchRunner(tester=mock_tester, warmup=3, repeat=10)
        result = runner.run(case, target_name="oom-target")

        assert result.test_status == TestStatus.OOM_ERROR
        assert result.repeat_count == 3  # 2 good + 1 bad
        assert len(result.raw_times_ms) == 3

    def test_zero_warmup(self) -> None:
        case = _make_case()
        mock_tester = MagicMock()
        mock_tester.test.return_value = _make_result(case, duration_ms=7.0)

        runner = BenchRunner(tester=mock_tester, warmup=0, repeat=3)
        result = runner.run(case, target_name="fast")

        assert result.warmup_count == 0
        assert result.repeat_count == 3
        assert mock_tester.test.call_count == 3

    def test_stats_populated(self) -> None:
        case = _make_case()
        durations = [10.0, 12.0, 11.0, 13.0, 9.0]
        call_idx = 0

        def side_effect(_case: CaseConfig) -> TestResult:
            nonlocal call_idx
            # First 2 are warmup
            if call_idx < 2:
                call_idx += 1
                return _make_result(case, duration_ms=99.0)
            idx = call_idx - 2
            call_idx += 1
            return _make_result(case, duration_ms=durations[idx])

        mock_tester = MagicMock()
        mock_tester.test.side_effect = side_effect

        runner = BenchRunner(tester=mock_tester, warmup=2, repeat=5)
        result = runner.run(case, target_name="t")

        assert result.stats.min_ms == 9.0
        assert result.stats.max_ms == 13.0
        assert result.raw_times_ms == durations
