"""Unit tests for bench.stats module."""

from __future__ import annotations

import math

import pytest

from tensor_spec.bench.stats import BenchStats, compute_stats


class TestComputeStats:
    """Tests for compute_stats()."""

    def test_known_values(self) -> None:
        times = [10.0, 20.0, 30.0, 40.0, 50.0]
        stats = compute_stats(times)

        assert isinstance(stats, BenchStats)
        assert math.isclose(stats.mean_ms, 30.0)
        assert math.isclose(stats.median_ms, 30.0)
        assert math.isclose(stats.min_ms, 10.0)
        assert math.isclose(stats.max_ms, 50.0)
        assert stats.std_ms > 0
        # ddof=1 std for [10,20,30,40,50] = sqrt(250) ≈ 15.811
        assert math.isclose(stats.std_ms, 15.811388300841896, rel_tol=1e-6)

    def test_single_value(self) -> None:
        stats = compute_stats([42.0])
        assert math.isclose(stats.mean_ms, 42.0)
        assert math.isclose(stats.median_ms, 42.0)
        assert stats.std_ms == 0.0
        assert math.isclose(stats.min_ms, 42.0)
        assert math.isclose(stats.max_ms, 42.0)

    def test_percentiles_default(self) -> None:
        times = list(range(1, 101))  # 1..100
        times_f = [float(t) for t in times]
        stats = compute_stats(times_f)
        assert set(stats.percentiles.keys()) == {50, 90, 95, 99}
        assert math.isclose(stats.percentiles[50], 50.5)

    def test_percentiles_custom(self) -> None:
        times = [1.0, 2.0, 3.0, 4.0, 5.0]
        stats = compute_stats(times, percentile_points=(25, 75))
        assert set(stats.percentiles.keys()) == {25, 75}

    def test_empty_raises(self) -> None:
        with pytest.raises(ValueError, match="non-empty"):
            compute_stats([])

    def test_frozen(self) -> None:
        stats = compute_stats([1.0, 2.0, 3.0])
        with pytest.raises(AttributeError):
            stats.mean_ms = 999.0  # type: ignore[misc]
