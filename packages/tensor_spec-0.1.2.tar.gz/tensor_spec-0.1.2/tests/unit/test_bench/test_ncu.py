"""Unit tests for bench.ncu."""

from __future__ import annotations

import math

import pytest

from tensor_spec.bench.ncu import (
    baseline_latency_delta_percent,
    baseline_throughput_delta_percent,
    format_latency_uplift,
    format_throughput_uplift,
    parse_ncu_csv,
)


def test_parse_ncu_csv_aggregates_metrics() -> None:
    raw = "\n".join(
        [
            '"ID","Metric Name","Metric Unit","Metric Value"',
            '"0","gpu__time_duration.sum","ns","1000"',
            '"0","sm__warps_active.avg.pct_of_peak_sustained_active","%","50"',
            '"0","dram__throughput.avg.pct_of_peak_sustained_elapsed","%","20"',
            '"1","gpu__time_duration.sum","ns","3000"',
            '"1","sm__warps_active.avg.pct_of_peak_sustained_active","%","70"',
            '"1","dram__throughput.avg.pct_of_peak_sustained_elapsed","%","40"',
        ]
    )

    metrics = parse_ncu_csv(raw)

    assert math.isclose(metrics.time_ms, 0.004)
    assert math.isclose(metrics.occupancy_pct, 65.0)
    assert math.isclose(metrics.memory_throughput_pct, 35.0)


def test_parse_ncu_csv_supports_wide_table_output() -> None:
    raw = "\n".join(
        [
            "==PROF== Connected to process 1 (python)",
            (
                '"ID","Process ID","Kernel Name","gpu__time_duration.sum",'
                '"sm__warps_active.avg.pct_of_peak_sustained_active",'
                '"gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed"'
            ),
            '"","","","ns","%","%"',
            '"0","123","kernel0","1000","50","20"',
            '"1","123","kernel1","3000","70","40"',
        ]
    )

    metrics = parse_ncu_csv(raw)

    assert math.isclose(metrics.time_ms, 0.004)
    assert math.isclose(metrics.occupancy_pct, 65.0)
    assert math.isclose(metrics.memory_throughput_pct, 35.0)


def test_parse_ncu_csv_requires_timing() -> None:
    with pytest.raises(ValueError, match="timing"):
        parse_ncu_csv(
            '"ID","Metric Name","Metric Unit","Metric Value"\n'
            '"0","dram__throughput.avg.pct_of_peak_sustained_elapsed","%","20"'
        )


def test_parse_ncu_csv_reports_no_profiled_kernels() -> None:
    with pytest.raises(ValueError, match="did not profile any GPU kernels"):
        parse_ncu_csv("==WARNING== No kernels were profiled.")


def test_latency_helpers() -> None:
    assert math.isclose(baseline_latency_delta_percent(12.0, 10.0) or 0.0, 20.0)
    assert "faster" in format_latency_uplift(8.0, 10.0)


def test_throughput_helpers() -> None:
    assert math.isclose(baseline_throughput_delta_percent(12.0, 10.0) or 0.0, 20.0)
    assert "higher" in format_throughput_uplift(12.0, 10.0)
