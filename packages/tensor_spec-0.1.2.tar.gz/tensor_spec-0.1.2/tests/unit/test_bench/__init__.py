"""Unit tests for bench subpackage."""
