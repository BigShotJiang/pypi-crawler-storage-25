from __future__ import annotations

from contextlib import nullcontext
from subprocess import CompletedProcess

import tensor_spec.setup_cmd as setup_cmd


def _completed(*, stdout: str = "", stderr: str = "", returncode: int = 0) -> CompletedProcess[str]:
    return CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)


def test_setup_backend_installs_workspace_runtime_packages(monkeypatch, tmp_path) -> None:
    venv_base = tmp_path / ".tensor-spec" / "venvs"
    core_dir = tmp_path / "packages" / "core"
    worker_dir = tmp_path / "packages" / "worker"
    core_dir.mkdir(parents=True)
    worker_dir.mkdir(parents=True)

    commands: list[list[str]] = []

    def fake_run(cmd: list[str], *, capture_output: bool, text: bool) -> CompletedProcess[str]:
        assert capture_output is True
        assert text is True
        commands.append(cmd)
        if cmd[:2] == ["uv", "venv"]:
            return _completed()
        if cmd[:4] == ["uv", "pip", "install", "--python"]:
            return _completed()
        if cmd[1:3] == ["-c", "import paddle; print(paddle.__version__)"]:
            return _completed(stdout="3.3.0\n")
        raise AssertionError(f"Unexpected command: {cmd}")

    monkeypatch.setattr(setup_cmd, "_VENV_BASE", venv_base)
    monkeypatch.setattr(
        setup_cmd,
        "_WORKSPACE_RUNTIME_PACKAGES",
        {
            "tensor-spec-core": core_dir,
            "tensor-spec-worker": worker_dir,
        },
    )
    monkeypatch.setattr(setup_cmd.console, "status", lambda *_args, **_kwargs: nullcontext())
    monkeypatch.setattr(setup_cmd.subprocess, "run", fake_run)

    result = setup_cmd.setup_backend(
        "paddle",
        package="paddlepaddle-gpu",
        version="3.3.0",
        index_url="https://www.paddlepaddle.org.cn/packages/stable/cu129/",
        index_strategy="unsafe-best-match",
    )

    assert result == {"backend": "paddle", "status": "ok", "detail": "v3.3.0"}
    assert commands[0] == ["uv", "venv", str(venv_base / "paddle"), "--python", "3.12"]
    assert commands[1] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "paddle" / "bin" / "python"),
        "paddlepaddle-gpu==3.3.0",
        "setuptools",
        "--index-url",
        "https://www.paddlepaddle.org.cn/packages/stable/cu129/",
        "--extra-index-url",
        "https://pypi.org/simple/",
        "--index-strategy",
        "unsafe-best-match",
    ]
    assert commands[2] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "paddle" / "bin" / "python"),
        "-e",
        str(core_dir),
    ]
    assert commands[3] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "paddle" / "bin" / "python"),
        "-e",
        str(worker_dir),
    ]


def test_setup_backend_falls_back_to_installed_runtime_distributions(monkeypatch, tmp_path) -> None:
    venv_base = tmp_path / ".tensor-spec" / "venvs"
    commands: list[list[str]] = []

    def fake_run(cmd: list[str], *, capture_output: bool, text: bool) -> CompletedProcess[str]:
        assert capture_output is True
        assert text is True
        commands.append(cmd)
        if cmd[:2] == ["uv", "venv"]:
            return _completed()
        if cmd[:4] == ["uv", "pip", "install", "--python"]:
            return _completed()
        if cmd[1:3] == ["-c", "import torch; print(torch.__version__)"]:
            return _completed(stdout="2.9.1+cu128\n")
        raise AssertionError(f"Unexpected command: {cmd}")

    def fake_installed_version(name: str) -> str:
        versions = {
            "tensor-spec-core": "0.1.2",
            "tensor-spec-worker": "0.1.2",
        }
        return versions[name]

    monkeypatch.setattr(setup_cmd, "_VENV_BASE", venv_base)
    monkeypatch.setattr(
        setup_cmd,
        "_WORKSPACE_RUNTIME_PACKAGES",
        {
            "tensor-spec-core": tmp_path / "missing-core",
            "tensor-spec-worker": tmp_path / "missing-worker",
        },
    )
    monkeypatch.setattr(setup_cmd, "installed_version", fake_installed_version)
    monkeypatch.setattr(setup_cmd.console, "status", lambda *_args, **_kwargs: nullcontext())
    monkeypatch.setattr(setup_cmd.subprocess, "run", fake_run)

    result = setup_cmd.setup_backend(
        "torch",
        package="torch",
        version="2.9.1",
        index_url="https://download.pytorch.org/whl/cu128",
        index_strategy="unsafe-best-match",
    )

    assert result == {"backend": "torch", "status": "ok", "detail": "v2.9.1+cu128"}
    assert commands[1] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "torch" / "bin" / "python"),
        "torch==2.9.1",
        "--index-url",
        "https://download.pytorch.org/whl/cu128",
        "--extra-index-url",
        "https://pypi.org/simple/",
        "--index-strategy",
        "unsafe-best-match",
    ]
    assert commands[2] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "torch" / "bin" / "python"),
        "tensor-spec-core==0.1.2",
    ]
    assert commands[3] == [
        "uv",
        "pip",
        "install",
        "--python",
        str(venv_base / "torch" / "bin" / "python"),
        "tensor-spec-worker==0.1.2",
    ]
