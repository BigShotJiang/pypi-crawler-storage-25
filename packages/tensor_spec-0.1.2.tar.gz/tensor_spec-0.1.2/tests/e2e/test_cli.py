import sys

from typer.testing import CliRunner

import tensor_spec.bench.ncu as bench_ncu
from tensor_spec.cli import app

runner = CliRunner()


def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "tensor-spec" in result.output.lower() or "check" in result.output


def test_cli_no_run_command():
    """'run' command has been removed."""
    result = runner.invoke(app, ["run", "--help"])
    assert result.exit_code != 0


def test_cli_no_validate_command():
    """'validate' command has been removed."""
    result = runner.invoke(app, ["validate", "--help"])
    assert result.exit_code != 0


def test_check_command_exists():
    result = runner.invoke(app, ["check", "--help"])
    assert result.exit_code == 0
    assert "--target" in result.output
    assert "--dry-run" in result.output
    assert "--fail-fast" in result.output
    assert "--format" in result.output
    assert "--verbose" in result.output


def test_check_no_isolated_flag():
    """--isolated flag should not exist — process isolation is the only mode."""
    result = runner.invoke(app, ["check", "--help"])
    assert "--isolated" not in result.output


def test_check_no_backend_flag():
    """--backend shorthand does not exist; use --target."""
    result = runner.invoke(app, ["check", "--help"])
    assert "--backend" not in result.output


def test_check_missing_cases():
    """check with no cases should fail."""
    result = runner.invoke(app, ["check", "--target", "nonexistent"])
    assert result.exit_code != 0


def test_check_unknown_named_target():
    """Referencing an unknown named target should fail."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "nonexistent-target"],
    )
    assert result.exit_code != 0


def test_check_inline_target_missing_backend():
    """Inline target without backend= should fail."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "python=/usr/bin/python"],
    )
    assert result.exit_code != 0


def test_check_inline_target_missing_python():
    """Inline target without python= should fail."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "backend=torch"],
    )
    assert result.exit_code != 0


def test_check_inline_target_name_forbidden():
    """Inline target with name= should fail."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "name=foo,backend=torch,python=/usr/bin/python"],
    )
    assert result.exit_code != 0


def test_check_inline_target_duplicate_key():
    """Duplicate keys in inline target should fail."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "backend=torch,backend=paddle,python=/usr/bin/python"],
    )
    assert result.exit_code != 0


def test_check_dry_run(tmp_path):
    """--dry-run should validate and exit without executing."""
    config = tmp_path / "tensor-spec.toml"
    config.write_text("""\
[defaults]
targets = ["my-target"]

[targets.my-target]
backend = "torch"
device = "cuda"
python = "/nonexistent/bin/python"
""")
    # dry-run should still fail because python path doesn't exist
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "my-target", "--dry-run", "--config", str(config)],
    )
    # Python path validation happens before dry-run summary
    assert result.exit_code != 0


def test_check_dry_run_stdin_auto(monkeypatch) -> None:
    """When no CASE args are given, piped stdin should be treated as '-' automatically."""
    monkeypatch.setattr("tensor_spec.cli._stdin_has_data", lambda: True)
    result = runner.invoke(
        app,
        [
            "check",
            "--target",
            f"backend=torch,python={__import__('sys').executable}",
            "--dry-run",
        ],
        input="abs(x=Tensor.float32((3,)))\n",
    )
    assert result.exit_code == 0
    assert "Dry-run OK" in result.output


def test_check_case_file(tmp_path):
    """Case file path should be auto-detected as file input."""
    cf = tmp_path / "cases.tspec"
    cf.write_text("# comment\nabs(x=Tensor.float32((3,)))\n\ncos(x=Tensor.float32((5,)))\n")
    result = runner.invoke(
        app,
        [
            "check",
            str(cf),
            "--target",
            "backend=paddle,python=/nonexistent/bin/python",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
        ],
    )
    # Should fail because python paths don't exist
    assert result.exit_code != 0


def test_check_case_file_missing():
    """Non-existent case file as positional arg is treated as inline case."""
    result = runner.invoke(
        app,
        [
            "check",
            "/nonexistent/cases.tspec",
            "--target",
            "backend=paddle,python=/nonexistent/bin/python",
        ],
    )
    # The non-existent path will be treated as an inline case string and fail at parse
    assert result.exit_code != 0


def test_check_single_target():
    """Single target should be accepted (check-only mode)."""
    result = runner.invoke(
        app,
        [
            "check",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=paddle,python=/nonexistent/bin/python",
        ],
    )
    assert result.exit_code != 0


def test_check_directory_expansion(tmp_path):
    """Directory CASE arg should recursively find .tspec files."""
    d = tmp_path / "cases"
    d.mkdir()
    (d / "a.tspec").write_text("abs(x=Tensor.float32((3,)))\n")
    (d / "b.txt").write_text("should_be_ignored\n")
    sub = d / "sub"
    sub.mkdir()
    (sub / "c.tspec").write_text("cos(x=Tensor.float32((5,)))\n")

    result = runner.invoke(
        app,
        [
            "check",
            str(d),
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
        ],
    )
    # Fails at python path check, but should have found 2 cases
    assert result.exit_code != 0


def test_bench_command_exists():
    result = runner.invoke(app, ["bench", "--help"])
    assert result.exit_code == 0
    assert "--mode" in result.output
    assert "--target" in result.output
    assert "--baseline" in result.output
    assert "--threshold" in result.output


# ── --jobs tests ──────────────────────────────────────────────────────


def test_check_jobs_auto():
    """check --help should show --jobs option."""
    result = runner.invoke(app, ["check", "--help"])
    assert result.exit_code == 0
    assert "--jobs" in result.output


def test_check_jobs_invalid():
    """--jobs with non-numeric value should fail."""
    result = runner.invoke(
        app,
        [
            "check",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
            "--jobs",
            "xyz",
        ],
    )
    assert result.exit_code != 0


def test_check_jobs_zero():
    """--jobs 0 should fail."""
    result = runner.invoke(
        app,
        [
            "check",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
            "--jobs",
            "0",
        ],
    )
    assert result.exit_code != 0


# ── bench tests ───────────────────────────────────────────────────────


def test_bench_help():
    """bench --help should list all expected options."""
    result = runner.invoke(app, ["bench", "--help"])
    assert result.exit_code == 0
    for flag in (
        "--mode",
        "--target",
        "--baseline",
        "--threshold",
        "--warmup",
        "--repeat",
        "--jobs",
        "--format",
        "--verbose",
        "--config",
    ):
        assert flag in result.output, f"Missing {flag} in bench help"


def test_bench_invalid_mode():
    """--mode with invalid value should fail with EXIT_INPUT."""
    result = runner.invoke(app, ["bench", "--mode", "invalid", "abs(x=Tensor.float32((3,)))"])
    assert result.exit_code == 2


def test_bench_ncu_stub():
    """--mode ncu with non-CUDA target should fail."""
    result = runner.invoke(
        app,
        [
            "bench",
            "--mode",
            "ncu",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
        ],
    )
    assert result.exit_code != 0


def test_bench_ncu_runs_with_stubbed_runner(monkeypatch) -> None:
    """NCU mode should execute the NCU runner path for CUDA targets."""
    from tensor_spec.bench.ncu import NcuCaseResult, NcuMetrics
    from tensor_spec.config.case import CaseConfig
    from tensor_spec_core.device import DeviceType

    calls: list[tuple[str, str]] = []

    class FakeNcuRunner:
        def __init__(self, *, python_path: str, backend_name: str, metrics, artifacts_dir: str, save_artifacts: bool):
            assert backend_name == "torch"
            assert metrics == ("time", "occupancy", "memory_throughput")

        def run(self, case: CaseConfig, *, target_name: str, mapping, seed: int) -> NcuCaseResult:
            assert case.kwargs["x"].device is not None
            assert case.kwargs["x"].device.device_type == DeviceType.CUDA
            assert case.kwargs["x"].device.device_id == 0
            calls.append((target_name, case.api_name))
            return NcuCaseResult(
                case=case,
                target_name=target_name,
                metrics=NcuMetrics(time_ms=1.5, occupancy_pct=60.0, memory_throughput_pct=25.0),
            )

    monkeypatch.setattr(bench_ncu, "NcuRunner", FakeNcuRunner)
    result = runner.invoke(
        app,
        [
            "bench",
            "--mode",
            "ncu",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            f"backend=torch,device=cuda:0,python={sys.executable}",
        ],
    )

    assert result.exit_code == 0
    assert calls == [("inline(torch)", "abs")]
    assert "NCU Results" in result.output
    assert "1.500ms" in result.output


def test_bench_ncu_throughput_threshold_violation(monkeypatch, tmp_path) -> None:
    """NCU mode should fail when throughput threshold is violated."""
    from tensor_spec.bench.ncu import NcuCaseResult, NcuMetrics
    from tensor_spec.config.case import CaseConfig
    from tensor_spec_core.device import DeviceType

    config = tmp_path / "tensor-spec.toml"
    config.write_text(
        f"""\
[targets.base]
backend = "torch"
device = "cuda:0"
python = "{sys.executable}"

[targets.candidate]
backend = "torch"
device = "cuda:0"
python = "{sys.executable}"
"""
    )

    class FakeNcuRunner:
        def __init__(self, *, python_path: str, backend_name: str, metrics, artifacts_dir: str, save_artifacts: bool):
            pass

        def run(self, case: CaseConfig, *, target_name: str, mapping, seed: int) -> NcuCaseResult:
            assert case.kwargs["x"].device is not None
            assert case.kwargs["x"].device.device_type == DeviceType.CUDA
            metrics = (
                NcuMetrics(time_ms=1.0, occupancy_pct=60.0, memory_throughput_pct=100.0)
                if target_name == "base"
                else NcuMetrics(time_ms=1.1, occupancy_pct=55.0, memory_throughput_pct=90.0)
            )
            return NcuCaseResult(case=case, target_name=target_name, metrics=metrics)

    monkeypatch.setattr(bench_ncu, "NcuRunner", FakeNcuRunner)
    result = runner.invoke(
        app,
        [
            "bench",
            "--mode",
            "ncu",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "base",
            "--target",
            "candidate",
            "--baseline",
            "base",
            "--threshold",
            "throughput>=5%",
            "--config",
            str(config),
        ],
    )

    assert result.exit_code == 5
    assert "Threshold violations" in result.output


def test_bench_missing_cases():
    """bench with no cases should fail."""
    result = runner.invoke(app, ["bench", "--target", "backend=torch,python=/nonexistent/bin/python"])
    assert result.exit_code != 0


def test_bench_stdin_auto(monkeypatch) -> None:
    """When no CASE args are given, bench should also auto-read piped stdin."""
    import tensor_spec.tester.check as tester_check
    from tensor_spec.tester.base import TestResult, TestStatus

    class FakeTester:
        def __init__(self, python_path: str, backend_name: str, mapping, generator) -> None:
            self.backend_name = backend_name

        def test(self, case):
            return TestResult(case=case, status=TestStatus.PASSED, duration_ms=1.0)

        def shutdown(self) -> None:
            return None

    monkeypatch.setattr("tensor_spec.cli._stdin_has_data", lambda: True)
    monkeypatch.setattr(tester_check, "IsolatedCheckTester", FakeTester)
    result = runner.invoke(
        app,
        [
            "bench",
            "--target",
            f"backend=torch,python={sys.executable}",
            "--warmup",
            "0",
            "--repeat",
            "1",
        ],
        input="abs(x=Tensor.float32((3,)))\n",
    )
    assert result.exit_code == 0
    assert "E2E Results" in result.output


def test_bench_baseline_not_in_targets(tmp_path):
    """--baseline references target not in --target list."""
    config = tmp_path / "tensor-spec.toml"
    config.write_text("""\
[targets.fast]
backend = "torch"
device = "cuda"
python = "/nonexistent/bin/python"

[targets.slow]
backend = "paddle"
device = "cuda"
python = "/nonexistent/bin/python"
""")
    result = runner.invoke(
        app,
        ["bench", "abs(x=Tensor.float32((3,)))", "--target", "fast", "--baseline", "slow", "--config", str(config)],
    )
    assert result.exit_code == 2


def test_bench_threshold_without_baseline():
    """--threshold without --baseline should fail."""
    result = runner.invoke(
        app,
        [
            "bench",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
            "--threshold",
            "latency<=10%",
        ],
    )
    assert result.exit_code == 2


def test_doctor_command_exists():
    result = runner.invoke(app, ["doctor", "--help"])
    assert result.exit_code == 0
    assert "--fix" in result.output


def test_doctor_no_config(tmp_path):
    """doctor with no config file should report missing config."""
    result = runner.invoke(app, ["doctor", "--config", str(tmp_path / "nonexistent.toml")])
    assert result.exit_code != 0


def test_pack_command_exists():
    result = runner.invoke(app, ["pack", "--help"])
    assert result.exit_code == 0


def test_unpack_command_exists():
    result = runner.invoke(app, ["unpack", "--help"])
    assert result.exit_code == 0


def test_migrate_case_file(tmp_path):
    legacy = tmp_path / "legacy.txt"
    legacy.write_text(
        "# comment\n"
        'paddle.add(Tensor([3],"float32"), Tensor([3],"float32"), )\n'
        'paddle.sum(Tensor([],"float32"), axis=list[], keepdim=False, )\n'
    )
    output = tmp_path / "migrated.txt"

    result = runner.invoke(
        app,
        [
            "migrate",
            "--input",
            str(legacy),
            "--output",
            str(output),
        ],
    )

    assert result.exit_code == 0
    assert "Migrated" in result.output
    assert output.read_text() == (
        "# comment\nadd(Tensor.float32((3)), Tensor.float32((3)))\nsum(Tensor.float32(()), axis=[], keepdim=False)\n"
    )
    assert not (tmp_path / "migrated.txt.rejects.txt").exists()


def test_migrate_case_file_with_rejects(tmp_path):
    legacy = tmp_path / "legacy.txt"
    legacy.write_text('paddle.add(Unknown(1), Tensor([3],"float32"), )\n')
    output = tmp_path / "migrated.txt"
    rejects = tmp_path / "legacy.rejects.txt"

    result = runner.invoke(
        app,
        [
            "migrate",
            "--input",
            str(legacy),
            "--output",
            str(output),
            "--rejects",
            str(rejects),
        ],
    )

    assert result.exit_code != 0
    assert "no case lines were converted" in result.output
    assert output.read_text() == ""
    assert "Unsupported nested call 'Unknown'" in rejects.read_text()


def test_cli_setup_help():
    result = runner.invoke(app, ["setup", "--help"])
    assert result.exit_code == 0
    assert "--backend" in result.output
    assert "--config" in result.output


# ── Error visibility tests ────────────────────────────────────────────


def test_check_error_visible_no_targets(tmp_path):
    """Error messages should be visible in output (not swallowed by logger)."""
    config = tmp_path / "tensor-spec.toml"
    config.write_text("")
    result = runner.invoke(app, ["check", "abs(x=Tensor.float32((3,)))", "--config", str(config)])
    assert result.exit_code != 0
    assert "error:" in result.output


def test_check_error_visible_bad_python():
    """Python-not-found error should appear in output."""
    result = runner.invoke(
        app,
        ["check", "abs(x=Tensor.float32((3,)))", "--target", "backend=torch,python=/nonexistent/bin/python"],
    )
    assert result.exit_code != 0
    assert "error:" in result.output
    assert "Python not found" in result.output


def test_bench_error_visible_no_targets(tmp_path):
    """bench error messages should be visible in output."""
    config = tmp_path / "tensor-spec.toml"
    config.write_text("")
    result = runner.invoke(
        app,
        ["bench", "abs(x=Tensor.float32((3,)))", "--config", str(config)],
    )
    assert result.exit_code != 0
    assert "error:" in result.output


# ── --no-interactive tests ────────────────────────────────────────────


def test_check_no_interactive_flag_accepted():
    """--no-interactive should be a valid flag for check."""
    result = runner.invoke(
        app,
        [
            "check",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
            "--no-interactive",
        ],
    )
    # Fails on python path, but the flag itself should be accepted
    assert result.exit_code != 0
    assert "error:" in result.output


def test_bench_no_interactive_flag_accepted():
    """--no-interactive should be a valid flag for bench."""
    result = runner.invoke(
        app,
        [
            "bench",
            "abs(x=Tensor.float32((3,)))",
            "--target",
            "backend=torch,python=/nonexistent/bin/python",
            "--no-interactive",
        ],
    )
    assert result.exit_code != 0
    assert "error:" in result.output
