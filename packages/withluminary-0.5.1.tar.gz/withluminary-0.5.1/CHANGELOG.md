# Changelog

## 0.5.1 (2026-04-23)

Full Changelog: [v0.5.0...v0.5.1](https://github.com/withluminary/python-sdk/compare/v0.5.0...v0.5.1)

### Chores

* **internal:** more robust bootstrap script ([0ef7423](https://github.com/withluminary/python-sdk/commit/0ef7423e54094d6c4629a46691439b77a6bd8bd8))

## 0.5.0 (2026-04-21)

Full Changelog: [v0.4.2...v0.5.0](https://github.com/withluminary/python-sdk/compare/v0.4.2...v0.5.0)

### Features

* **api:** manual updates ([8d614bd](https://github.com/withluminary/python-sdk/commit/8d614bdf9f70c5be4bd70e6d5a065360297a395f))

## 0.4.2 (2026-04-20)

Full Changelog: [v0.4.1...v0.4.2](https://github.com/withluminary/python-sdk/compare/v0.4.1...v0.4.2)

### Chores

* remove custom code ([a697658](https://github.com/withluminary/python-sdk/commit/a6976588b6ecb0864f397efc65ec354e46216441))

## 0.4.1 (2026-04-20)

Full Changelog: [v0.4.0...v0.4.1](https://github.com/withluminary/python-sdk/compare/v0.4.0...v0.4.1)

### Chores

* update SDK settings ([abd8d76](https://github.com/withluminary/python-sdk/commit/abd8d767099a4ce86ab438d6487506fd5b40a8d3))
* update SDK settings ([46ac6fa](https://github.com/withluminary/python-sdk/commit/46ac6fa195911a0b1f52c8f610d197017bd44533))

## 0.4.0 (2026-04-20)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/withluminary/python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([d71b29b](https://github.com/withluminary/python-sdk/commit/d71b29b1ca03b78f83028daa905f314ccc221f0c))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([c5722d4](https://github.com/withluminary/python-sdk/commit/c5722d4f0378bc7255370b55116a915dfa8563a2))

## 0.3.0 (2026-04-13)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/withluminary/python-sdk/compare/v0.2.1...v0.3.0)

### Features

* **api:** add cursor config ([91a19c2](https://github.com/withluminary/python-sdk/commit/91a19c2f2ca4ec6a28c8e3f73781a4ee3f294bf5))
* **api:** configurable auth domain ([cfbe315](https://github.com/withluminary/python-sdk/commit/cfbe315cf63d95d428e175109ebe5a718b16fcbc))
* **api:** manual updates ([af36558](https://github.com/withluminary/python-sdk/commit/af36558abf6922eca0a6d4dfdb6ad5d685d2cb79))
* **api:** manual updates ([7141bf0](https://github.com/withluminary/python-sdk/commit/7141bf046169318b1af8d95fdba7e15c8fbadae2))
* **api:** manual updates ([dc674de](https://github.com/withluminary/python-sdk/commit/dc674de271ff012299c8c89e2286d93bed76d320))
* **api:** manual updates ([bd337d5](https://github.com/withluminary/python-sdk/commit/bd337d5b26bb75ea464d47ec6486c64c2556c19d))
* **api:** manual updates ([40e4ba2](https://github.com/withluminary/python-sdk/commit/40e4ba289e195152973e9e87e22d73f658af6c09))
* **api:** revert token change ([1df1698](https://github.com/withluminary/python-sdk/commit/1df169844a308aec22634d1def8636d4ea66bf78))
* **client:** add custom JSON encoder for extended type support ([0de3fde](https://github.com/withluminary/python-sdk/commit/0de3fde131fa07c702a935a7661379f9d464faa7))
* **client:** add support for binary request streaming ([3832f10](https://github.com/withluminary/python-sdk/commit/3832f102c256edb43c15e89211daddcadf40f284))
* **internal:** implement indices array format for query and form serialization ([9482eae](https://github.com/withluminary/python-sdk/commit/9482eae5c7a09d26092e1c0969bf50e455980a28))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([b6dd431](https://github.com/withluminary/python-sdk/commit/b6dd4312851f03b8eb7cc8c1b6bcfceebaa44ff0))
* **deps:** bump minimum typing-extensions version ([7c8aa0a](https://github.com/withluminary/python-sdk/commit/7c8aa0aab97bd0beef4e3191472e6d24393d177f))
* ensure file data are only sent as 1 parameter ([490bf67](https://github.com/withluminary/python-sdk/commit/490bf677957c0c55a4b71d2c2387959ea8562010))
* move oauth2 grant type to body of request ([8c62b2b](https://github.com/withluminary/python-sdk/commit/8c62b2b82223020c418f99a82c71515e72ccd06a))
* move oauth2 grant type to body of request ([d05c5d9](https://github.com/withluminary/python-sdk/commit/d05c5d94266da956b06337774174527c20e4ca91))
* **pydantic:** do not pass `by_alias` unless set ([70a101b](https://github.com/withluminary/python-sdk/commit/70a101b86d8ee4611fc414530a3b469a58b2a9e7))
* sanitize endpoint path params ([722abcc](https://github.com/withluminary/python-sdk/commit/722abccbe83c38ec7a21bc4165bb8850ec1d5088))
* **tests:** correct setup of OAuth 2 Client Credentials tests ([765acf7](https://github.com/withluminary/python-sdk/commit/765acf789a2525d1ef806663bd58f4bdb9851763))
* use async_to_httpx_files in patch method ([dc55aaa](https://github.com/withluminary/python-sdk/commit/dc55aaa2685fb7818ebc7a9b692b7e4146609290))
* various public API fixes ([c808122](https://github.com/withluminary/python-sdk/commit/c80812235b2df4aac5652e83e97af5d97228068a))


### Chores

* add entity in-estate status to API ([dd8a25f](https://github.com/withluminary/python-sdk/commit/dd8a25fbfa83f558a3671c845e555e37cbdd8dd2))
* **ci:** bump uv version ([c54d62a](https://github.com/withluminary/python-sdk/commit/c54d62ae202dbdb418906996306cdfc78e1368e9))
* **ci:** skip lint on metadata-only changes ([4107c21](https://github.com/withluminary/python-sdk/commit/4107c21f53ab9067d52f47c060686c4a93f49c53))
* **ci:** skip uploading artifacts on stainless-internal branches ([3c2134d](https://github.com/withluminary/python-sdk/commit/3c2134de5cc754dfe8cc7166ee8fb84dc105b522))
* **ci:** upgrade `actions/github-script` ([03de7d4](https://github.com/withluminary/python-sdk/commit/03de7d4f6f45f722a4b901c25bb3f5d9e2a21251))
* configure new SDK language ([b7727fc](https://github.com/withluminary/python-sdk/commit/b7727fc4803e138ab06cf7f8e12a5e6c86bdeb98))
* format all `api.md` files ([90ea8de](https://github.com/withluminary/python-sdk/commit/90ea8de2ff8ba24013e1c31e84b4e2f2af04e4ea))
* **internal:** add `--fix` argument to lint script ([80b43f9](https://github.com/withluminary/python-sdk/commit/80b43f98c70b93d968ff9a3b0ebdefb8432cb6f7))
* **internal:** add missing files argument to base client ([6eafb4c](https://github.com/withluminary/python-sdk/commit/6eafb4c434a40206c8b2e0882240629ab53ea9a4))
* **internal:** add request options to SSE classes ([3610db7](https://github.com/withluminary/python-sdk/commit/3610db782b2bcbdd6fc83aabad2be253cf43e321))
* **internal:** bump dependencies ([135ba9c](https://github.com/withluminary/python-sdk/commit/135ba9c761e4d5077bdabc883c446bf39e92c5c8))
* **internal:** codegen related update ([273d1bc](https://github.com/withluminary/python-sdk/commit/273d1bcd233fdc1e7f0eff4eb2ef33559fd851d0))
* **internal:** fix lint error on Python 3.14 ([5048caf](https://github.com/withluminary/python-sdk/commit/5048cafbe09ff59bea02b26159f56ef15e02e66c))
* **internal:** make `test_proxy_environment_variables` more resilient ([b5f628c](https://github.com/withluminary/python-sdk/commit/b5f628cf3a4466dd8710433fd293a0461600472a))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([9f0a5cc](https://github.com/withluminary/python-sdk/commit/9f0a5cc4b9bc025b161d0435a785a23ae54eb5a1))
* **internal:** remove mock server code ([5b943f3](https://github.com/withluminary/python-sdk/commit/5b943f38b3a1142de77a366ff27b2243221c6d32))
* **internal:** tweak CI branches ([e2027bd](https://github.com/withluminary/python-sdk/commit/e2027bd186d999907658cde6daab77210f858fde))
* **internal:** update `actions/checkout` version ([cc552cd](https://github.com/withluminary/python-sdk/commit/cc552cd987976000b547c416d67acd4d255f7858))
* **internal:** update gitignore ([322fdfd](https://github.com/withluminary/python-sdk/commit/322fdfd274e3e57e012f5d79fbbd38320f369451))
* remove custom code ([c3ef346](https://github.com/withluminary/python-sdk/commit/c3ef34605a612429a9babb9fbc7ae224a1a3e6d5))
* remove custom code ([eac41a3](https://github.com/withluminary/python-sdk/commit/eac41a38e75ba0c36187433678d9674534124ad1))
* remove custom code ([1db07a2](https://github.com/withluminary/python-sdk/commit/1db07a25978e1646ac0549611a07f93ac2d42591))
* speedup initial import ([3268218](https://github.com/withluminary/python-sdk/commit/3268218a7134c62495f4edcc3b9d7c6285f5e2dc))
* update mock server docs ([592b54b](https://github.com/withluminary/python-sdk/commit/592b54b8516de913bccabe4ffa1f8ea15616fe45))
* update placeholder string ([83b3190](https://github.com/withluminary/python-sdk/commit/83b3190cfe98623c0afbcaa3df25229ff78137cb))
* update SDK settings ([2e5cd10](https://github.com/withluminary/python-sdk/commit/2e5cd1057a9c9ee124f0ec4682469954f22ab268))
* update SDK settings ([7969bda](https://github.com/withluminary/python-sdk/commit/7969bda5ecf129d740ab0f292c56ec3eb19d50a3))
* update SDK settings ([fa28048](https://github.com/withluminary/python-sdk/commit/fa28048d92dd1e26855c062a0e4218de1b0c650d))
* user endpoint and pagination ([048f4c8](https://github.com/withluminary/python-sdk/commit/048f4c8107191e51dea0015ba45b542fa6ab0172))


### Refactors

* **internal:** switch from rye to uv ([dd5caad](https://github.com/withluminary/python-sdk/commit/dd5caadc4cce2853c8e619e7376efef698d29a05))

## 0.2.1 (2026-04-11)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/withluminary/python-sdk/compare/v0.2.0...v0.2.1)

### Bug Fixes

* ensure file data are only sent as 1 parameter ([490bf67](https://github.com/withluminary/python-sdk/commit/490bf677957c0c55a4b71d2c2387959ea8562010))

## 0.2.0 (2026-04-08)

Full Changelog: [v0.1.3...v0.2.0](https://github.com/withluminary/python-sdk/compare/v0.1.3...v0.2.0)

### Features

* **internal:** implement indices array format for query and form serialization ([9482eae](https://github.com/withluminary/python-sdk/commit/9482eae5c7a09d26092e1c0969bf50e455980a28))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([b6dd431](https://github.com/withluminary/python-sdk/commit/b6dd4312851f03b8eb7cc8c1b6bcfceebaa44ff0))
* **deps:** bump minimum typing-extensions version ([7c8aa0a](https://github.com/withluminary/python-sdk/commit/7c8aa0aab97bd0beef4e3191472e6d24393d177f))
* **pydantic:** do not pass `by_alias` unless set ([70a101b](https://github.com/withluminary/python-sdk/commit/70a101b86d8ee4611fc414530a3b469a58b2a9e7))
* sanitize endpoint path params ([722abcc](https://github.com/withluminary/python-sdk/commit/722abccbe83c38ec7a21bc4165bb8850ec1d5088))
* **tests:** correct setup of OAuth 2 Client Credentials tests ([765acf7](https://github.com/withluminary/python-sdk/commit/765acf789a2525d1ef806663bd58f4bdb9851763))


### Chores

* **ci:** skip lint on metadata-only changes ([4107c21](https://github.com/withluminary/python-sdk/commit/4107c21f53ab9067d52f47c060686c4a93f49c53))
* **ci:** skip uploading artifacts on stainless-internal branches ([3c2134d](https://github.com/withluminary/python-sdk/commit/3c2134de5cc754dfe8cc7166ee8fb84dc105b522))
* **internal:** tweak CI branches ([e2027bd](https://github.com/withluminary/python-sdk/commit/e2027bd186d999907658cde6daab77210f858fde))
* **internal:** update gitignore ([322fdfd](https://github.com/withluminary/python-sdk/commit/322fdfd274e3e57e012f5d79fbbd38320f369451))
* update placeholder string ([83b3190](https://github.com/withluminary/python-sdk/commit/83b3190cfe98623c0afbcaa3df25229ff78137cb))

## 0.1.3 (2026-03-03)

Full Changelog: [v0.1.2...v0.1.3](https://github.com/withluminary/python-sdk/compare/v0.1.2...v0.1.3)

### Chores

* remove custom code ([c3ef346](https://github.com/withluminary/python-sdk/commit/c3ef34605a612429a9babb9fbc7ae224a1a3e6d5))

## 0.1.2 (2026-02-27)

Full Changelog: [v0.1.1...v0.1.2](https://github.com/withluminary/python-sdk/compare/v0.1.1...v0.1.2)

### Chores

* **ci:** bump uv version ([c54d62a](https://github.com/withluminary/python-sdk/commit/c54d62ae202dbdb418906996306cdfc78e1368e9))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([9f0a5cc](https://github.com/withluminary/python-sdk/commit/9f0a5cc4b9bc025b161d0435a785a23ae54eb5a1))

## 0.1.1 (2026-02-24)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/withluminary/python-sdk/compare/v0.1.0...v0.1.1)

### Chores

* **internal:** make `test_proxy_environment_variables` more resilient ([b5f628c](https://github.com/withluminary/python-sdk/commit/b5f628cf3a4466dd8710433fd293a0461600472a))

## 0.1.0 (2026-02-24)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/withluminary/python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** add cursor config ([91a19c2](https://github.com/withluminary/python-sdk/commit/91a19c2f2ca4ec6a28c8e3f73781a4ee3f294bf5))
* **api:** configurable auth domain ([cfbe315](https://github.com/withluminary/python-sdk/commit/cfbe315cf63d95d428e175109ebe5a718b16fcbc))
* **api:** manual updates ([af36558](https://github.com/withluminary/python-sdk/commit/af36558abf6922eca0a6d4dfdb6ad5d685d2cb79))
* **api:** manual updates ([7141bf0](https://github.com/withluminary/python-sdk/commit/7141bf046169318b1af8d95fdba7e15c8fbadae2))
* **api:** manual updates ([dc674de](https://github.com/withluminary/python-sdk/commit/dc674de271ff012299c8c89e2286d93bed76d320))
* **api:** manual updates ([bd337d5](https://github.com/withluminary/python-sdk/commit/bd337d5b26bb75ea464d47ec6486c64c2556c19d))
* **api:** manual updates ([40e4ba2](https://github.com/withluminary/python-sdk/commit/40e4ba289e195152973e9e87e22d73f658af6c09))
* **api:** revert token change ([1df1698](https://github.com/withluminary/python-sdk/commit/1df169844a308aec22634d1def8636d4ea66bf78))
* **client:** add custom JSON encoder for extended type support ([0de3fde](https://github.com/withluminary/python-sdk/commit/0de3fde131fa07c702a935a7661379f9d464faa7))
* **client:** add support for binary request streaming ([3832f10](https://github.com/withluminary/python-sdk/commit/3832f102c256edb43c15e89211daddcadf40f284))


### Bug Fixes

* move oauth2 grant type to body of request ([8c62b2b](https://github.com/withluminary/python-sdk/commit/8c62b2b82223020c418f99a82c71515e72ccd06a))
* move oauth2 grant type to body of request ([d05c5d9](https://github.com/withluminary/python-sdk/commit/d05c5d94266da956b06337774174527c20e4ca91))
* use async_to_httpx_files in patch method ([dc55aaa](https://github.com/withluminary/python-sdk/commit/dc55aaa2685fb7818ebc7a9b692b7e4146609290))
* various public API fixes ([c808122](https://github.com/withluminary/python-sdk/commit/c80812235b2df4aac5652e83e97af5d97228068a))


### Chores

* add entity in-estate status to API ([dd8a25f](https://github.com/withluminary/python-sdk/commit/dd8a25fbfa83f558a3671c845e555e37cbdd8dd2))
* **ci:** upgrade `actions/github-script` ([03de7d4](https://github.com/withluminary/python-sdk/commit/03de7d4f6f45f722a4b901c25bb3f5d9e2a21251))
* configure new SDK language ([b7727fc](https://github.com/withluminary/python-sdk/commit/b7727fc4803e138ab06cf7f8e12a5e6c86bdeb98))
* format all `api.md` files ([90ea8de](https://github.com/withluminary/python-sdk/commit/90ea8de2ff8ba24013e1c31e84b4e2f2af04e4ea))
* **internal:** add `--fix` argument to lint script ([80b43f9](https://github.com/withluminary/python-sdk/commit/80b43f98c70b93d968ff9a3b0ebdefb8432cb6f7))
* **internal:** add missing files argument to base client ([6eafb4c](https://github.com/withluminary/python-sdk/commit/6eafb4c434a40206c8b2e0882240629ab53ea9a4))
* **internal:** add request options to SSE classes ([3610db7](https://github.com/withluminary/python-sdk/commit/3610db782b2bcbdd6fc83aabad2be253cf43e321))
* **internal:** bump dependencies ([135ba9c](https://github.com/withluminary/python-sdk/commit/135ba9c761e4d5077bdabc883c446bf39e92c5c8))
* **internal:** codegen related update ([273d1bc](https://github.com/withluminary/python-sdk/commit/273d1bcd233fdc1e7f0eff4eb2ef33559fd851d0))
* **internal:** fix lint error on Python 3.14 ([5048caf](https://github.com/withluminary/python-sdk/commit/5048cafbe09ff59bea02b26159f56ef15e02e66c))
* **internal:** remove mock server code ([5b943f3](https://github.com/withluminary/python-sdk/commit/5b943f38b3a1142de77a366ff27b2243221c6d32))
* **internal:** update `actions/checkout` version ([cc552cd](https://github.com/withluminary/python-sdk/commit/cc552cd987976000b547c416d67acd4d255f7858))
* remove custom code ([eac41a3](https://github.com/withluminary/python-sdk/commit/eac41a38e75ba0c36187433678d9674534124ad1))
* remove custom code ([1db07a2](https://github.com/withluminary/python-sdk/commit/1db07a25978e1646ac0549611a07f93ac2d42591))
* speedup initial import ([3268218](https://github.com/withluminary/python-sdk/commit/3268218a7134c62495f4edcc3b9d7c6285f5e2dc))
* update mock server docs ([592b54b](https://github.com/withluminary/python-sdk/commit/592b54b8516de913bccabe4ffa1f8ea15616fe45))
* update SDK settings ([2e5cd10](https://github.com/withluminary/python-sdk/commit/2e5cd1057a9c9ee124f0ec4682469954f22ab268))
* update SDK settings ([7969bda](https://github.com/withluminary/python-sdk/commit/7969bda5ecf129d740ab0f292c56ec3eb19d50a3))
* update SDK settings ([fa28048](https://github.com/withluminary/python-sdk/commit/fa28048d92dd1e26855c062a0e4218de1b0c650d))
* user endpoint and pagination ([048f4c8](https://github.com/withluminary/python-sdk/commit/048f4c8107191e51dea0015ba45b542fa6ab0172))


### Refactors

* **internal:** switch from rye to uv ([dd5caad](https://github.com/withluminary/python-sdk/commit/dd5caadc4cce2853c8e619e7376efef698d29a05))
