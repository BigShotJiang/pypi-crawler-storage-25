from __future__ import annotations

import datetime
import itertools
import json
import logging
import mimetypes
import os
import re
import smtplib
import subprocess
import threading
import time
import traceback
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pprint import pprint
from typing import Any, Iterable, Iterator, Literal, Mapping, cast

import bs4 as bs
import numpy as np
import pandas as pd
import requests
import tornado.autoreload
import tornado.ioloop
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as chrome_options
from selenium.webdriver.firefox.options import Options as firefox_options
from selenium.webdriver.remote.webdriver import WebDriver

path = os.path.abspath(os.path.dirname(__file__)).replace("\\", "/") + "/"
data_path: str = path + "data/"
today = datetime.datetime.today()

# logger
dagster_logger = logging.getLogger("dagster_logger")
dagster_logger.setLevel(logging.INFO)
# create console handler
handler = logging.StreamHandler()
# create formatter and add it to the handler
formatter = logging.Formatter("%(asctime)s, %(message)s")
handler.setFormatter(formatter)
# add the handler to the logger
dagster_logger.addHandler(handler)
# create console handler
handler2 = logging.FileHandler(path + "dagster_logger.log")
# add the handler to the logger
dagster_logger.addHandler(handler2)

# BOKEH TOOLS
BOKEH_TOOLS = "pan,wheel_zoom,box_zoom,reset,save"


# Utilities
def set_env(secrets_: dict[str, str]) -> None:
    """Populate ``os.environ`` from a mapping of secret names to values.

    Args:
        secrets_: Keys and values coerced to ``str`` and assigned to the process
            environment.

    Returns:
        None
    """
    for x, y in secrets_.items():
        os.environ[str(x)] = str(y)


def convert_large_num_to_human_read(num: int) -> str:
    """Format a large integer with T/B/M suffixes for human-readable display.

    Args:
        num: Non-negative integer to abbreviate.

    Returns:
        String such as ``'1.2 B'`` or comma-separated smaller values.
    """
    if num // 10**12 >= 1:
        return f"{(num // 10**12) + (num % 10**12) / 10**12:,.1f} T"
    elif num // 10**9 >= 1:
        return f"{(num // 10**9) + (num % 10**9) / 10**9:,.1f} B"
    elif num // 10**6 >= 1:
        return f"{(num // 10**6) + (num % 10**6) / 10**6:,.1f} M"
    else:
        return f"{int(num):,}"


def write_to_env_file(env_dict: dict[str, Any], file_path: str, prefix: str | None = None) -> None:
    """Write key/value pairs to a ``.env`` file (``KEY=value`` lines).

    Args:
        env_dict: Mapping of environment variable names to serializable values.
        file_path: Output path for the ``.env`` file.
        prefix: Optional string prepended to each key before writing.

    Returns:
        None

    Example:
        ``env_dict`` might include ``access_token``, ``api_server``, etc.; each
        line becomes ``VAR=value`` (or ``prefixVAR=value`` when ``prefix`` is set).
    """
    with open(file_path, "w") as file:
        for key, value in env_dict.items():
            # Add 'xyz_' prefix to the variable names
            env_var_name = key
            if prefix:
                env_var_name = f"{prefix}{key}"
            # Write the variable to the .env file in the format VAR_NAME=VALUE
            file.write(f"{env_var_name}={value}\n")

    print(f".env file created at {file_path}")


def read_json_from_api(
    url: str,
    headers: Mapping[str, str] | None = None,
    data: dict[str, Any] | None = None,
    session: requests.Session | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    """Perform an HTTP GET and parse JSON, capturing basic rate-limit headers.

    Args:
        url: Request URL.
        headers: Optional HTTP headers.
        data: Optional JSON body for the GET (passed as ``json=`` to requests).
        session: Optional existing ``requests.Session``; otherwise uses module
            level ``requests.get``.

    Returns:
        Tuple of ``(response_json_or_error_dict, rate_limit_dict)`` where
        ``rate_limit_dict`` may contain ``remaining_requests`` and
        ``reset_timestamp_utc`` when headers are present.

    Note:
        On failure, may return a dict with an ``'error'`` key instead of raising.
    """
    output_data = None
    rate_limit_dict = {"remaining_requests": None, "reset_timestamp_utc": None}
    try:
        if headers:
            if session:
                if data:
                    response = session.get(url, headers=headers, json=data)
                else:
                    response = session.get(url, headers=headers)
            else:
                if data:
                    response = requests.get(url, headers=headers, json=data)
                else:
                    response = requests.get(url, headers=headers)
        else:
            if session:
                if data:
                    response = session.get(url, json=data)
                else:
                    response = session.get(url)

            else:
                if data:
                    response = requests.get(url, json=data)
                else:
                    response = requests.get(url)
        output_data = response.json()
        response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes
        if response.headers:
            if response.headers._store:
                if "x-ratelimit-remaining" in response.headers._store.keys():
                    if response.headers._store["x-ratelimit-remaining"]:
                        _, val = response.headers._store["x-ratelimit-remaining"]
                        rate_limit_dict["remaining_requests"] = val
                    if response.headers._store["x-ratelimit-reset"]:
                        _, val = response.headers._store["x-ratelimit-reset"]
                        rate_limit_dict["reset_timestamp_utc"] = val
    except requests.exceptions.RequestException as e:
        print("Error message:", e)
        if output_data:
            print("Failed to make API call.")
            pprint(output_data)
        output_data = {"error": str(e)}
    return output_data, rate_limit_dict


def read_json_from_api_post(
    url: str,
    headers: Mapping[str, str] | None = None,
    data: dict[str, Any] | None = None,
    session: requests.Session | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    """Perform an HTTP POST with JSON and parse the response like :func:`read_json_from_api`.

    Args:
        url: Request URL.
        headers: Optional HTTP headers.
        data: Optional JSON body.
        session: Optional ``requests.Session`` for connection reuse.

    Returns:
        Tuple of ``(parsed_json, rate_limit_dict)`` with the same shape as
        ``read_json_from_api``.
    """
    output_data = None
    rate_limit_dict = {"remaining_requests": None, "reset_timestamp_utc": None}
    try:
        if headers:
            if session:
                if data:
                    response = session.post(url, headers=headers, json=data)
                else:
                    response = session.post(url, headers=headers)
            else:
                if data:
                    response = requests.post(url, headers=headers, json=data)
                else:
                    response = requests.post(url, headers=headers)
        else:
            if session:
                if data:
                    response = session.post(url, json=data)
                else:
                    response = session.post(url)

            else:
                if data:
                    response = requests.post(url, json=data)
                else:
                    response = requests.post(url)
        output_data = response.json()
        response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes
        if response.headers:
            if response.headers._store:
                if response.headers._store["x-ratelimit-remaining"]:
                    _, val = response.headers._store["x-ratelimit-remaining"]
                    rate_limit_dict["remaining_requests"] = val
                if response.headers._store["x-ratelimit-reset"]:
                    _, val = response.headers._store["x-ratelimit-reset"]
                    rate_limit_dict["reset_timestamp_utc"] = val
    except requests.exceptions.RequestException as e:
        print("Error message:", e)
        if output_data:
            print("Failed to make API call.")
            pprint(output_data)
    return output_data, rate_limit_dict


def above_zero_numpy_mask(series: pd.Series[Any]) -> pd.Series[int]:
    """Return a 0/1 Series indicating whether each value is strictly positive.

    Args:
        series: One-dimensional pandas ``Series`` of numeric values.

    Returns:
        ``Series`` of integers 0 or 1 with the same index as ``series``.
    """
    # Convert the Pandas Series to a NumPy array for vectorized operations
    array = np.array(series)
    # Create a mask for values greater than 0
    mask = array > 0
    # Apply the vectorization condition to get 1 for values greater than 0 and 0 otherwise
    array[mask] = 1
    array[~mask] = 0
    # Convert the array back to a Pandas Series
    vectorized_series = pd.Series(array.astype(int), index=series.index)
    return vectorized_series


def flatten_list(array: pd.DataFrame | list) -> list[Any] | pd.DataFrame:
    """Flatten a list of lists, or return a list of DataFrames unchanged.

    Args:
        array: Non-empty list whose first element determines behavior (list of
            lists vs list of DataFrames vs already flat).

    Returns:
        Flattened list, list of DataFrames, or the original list.
    """
    if isinstance(array[0], list):
        return [item for sublist in array for item in sublist]
    elif isinstance(array[0], pd.DataFrame):
        return array
    else:
        return array


def powerset(iterable: Iterable[Any]) -> Iterator[tuple[Any, ...]]:
    """Yield all non-empty combinations of ``iterable`` for sizes 1 through n.

    Args:
        iterable: Finite iterable; converted to a list to allow duplicates in
            combinations.

    Returns:
        Iterator of tuples (each non-empty subset as a combination).

    Example:
        ``list(powerset([1, 2, 3]))`` includes ``(1,)``, ``(1, 2)``, ``(1, 2, 3)``, etc.
    """
    new_iter = list(iterable)  # allows duplicate elements
    return itertools.chain.from_iterable(itertools.combinations(new_iter, r) for r in range(1, len(new_iter) + 1))


def do_work(list_of_tasks: Iterable[Any], wait_time: float = 1) -> int:
    """Sleep through an iterable of tasks with jitter, then return a random int.

    Args:
        list_of_tasks: Items to iterate (each iteration sleeps).
        wait_time: Base seconds per task; adds random 0–9 seconds.

    Returns:
        Random integer from ``numpy.random.randint(0, 10)`` after work completes.
    """
    for x in list_of_tasks:
        dagster_logger.info(str(x))
        time.sleep(wait_time + np.random.randint(0, 10))

    return np.random.randint(0, 10)


def find_parent_of_src_folder(start_dir: str | None) -> str | None:
    """Walk upward from ``start_dir`` (or cwd) and return the parent of a ``src`` folder.

    Args:
        start_dir: Directory to begin walking upward; uses ``os.getcwd()`` if falsy.

    Returns:
        Parent path of the nearest ``src`` directory, or ``None`` if not found.
    """
    # Walk upwards through the directory structure
    if start_dir:
        current_path = start_dir
    else:
        current_path = os.getcwd()
    while current_path != os.path.dirname(current_path):  # stop if we reach the root
        if os.path.basename(current_path) == "src":
            # Return the parent of the 'src' folder
            return os.path.dirname(current_path)
        current_path = os.path.dirname(current_path)  # go up one directory level
    return None  # return None if no 'src' folder is found


def convert_unix_timestamp_to_pandas_date(input_date: float | int) -> pd.Timestamp:
    """Convert a Unix timestamp in milliseconds to a pandas datetime (date only).

    Args:
        input_date: Milliseconds since epoch.

    Returns:
        ``pd.Timestamp`` at midnight for the corresponding UTC-derived local date.
    """
    return pd.to_datetime(datetime.datetime.fromtimestamp(input_date / 1000).date())


def parse_date_features(idf_: pd.DataFrame, holidays_: list[Any] | None = None) -> pd.DataFrame:
    """Add calendar and cyclical time features (and optional holiday flags) to a DataFrame.

    Args:
        idf_: Input frame copied internally; must have a parseable datetime index.
        holidays_: Optional list of dates treated as holidays (``holiday`` column).

    Returns:
        Copy of ``idf_`` with ``hour``, ``month``, ``year``, ``weekday``, sin/cos
        encodings, and optionally ``holiday``.
    """
    idf = idf_.copy()
    idf.index = pd.to_datetime(idf.index)
    idf["hour"] = idf.index.hour  # type: ignore
    idf["month"] = idf.index.month  # type: ignore
    idf["year"] = idf.index.year  # type: ignore
    idf["weekday"] = idf.index.weekday  # type: ignore  # 0 is sunday
    idf["hour_sin"] = np.sin(idf.hour * (2.0 * np.pi / 24))
    idf["hour_cos"] = np.cos(idf.hour * (2.0 * np.pi / 24))
    idf["month_sin"] = np.sin((idf.month - 1) * (2.0 * np.pi / 12))
    idf["month_cos"] = np.cos((idf.month - 1) * (2.0 * np.pi / 12))
    if holidays_:
        idf["holiday"] = [1 if x in holidays_ else 0 for x in idf.index]
    return idf


def wrap_in_paragraphs(txt: str, colour: str = "DarkSlateBlue", size: int = 4) -> str:
    """Wrap plain text in simple HTML paragraph and font tags.

    Args:
        txt: Body text to wrap.
        colour: HTML font color name or value.
        size: HTML font size attribute.

    Returns:
        HTML fragment string.
    """
    return f"""<p><b><font color={colour} size={size}>{txt}</font></b></p>"""


def sendemail_(
    TEXT: str,
    HTML: str,
    SUBJECT: str = "Daily Market Update",
    filename: str | None = None,
    TO: Iterable[str | None] = (os.getenv("my_email"),),
) -> None:
    """Send a multipart email (plain + HTML) via Gmail SMTP SSL.

    Uses ``senders_email`` / ``senders_pw`` environment variables for credentials.

    Args:
        TEXT: Plain-text body part.
        HTML: HTML body part (preferred by MIME-capable clients).
        SUBJECT: Email subject line.
        filename: Optional path to a file attached to the message.
        TO: Iterable of recipient addresses (defaults to ``my_email`` env).

    Returns:
        None: Logs success or failure; does not return the server response.
    """
    # This is a temporary fix. Be careful of malicious links
    # context = ssl._create_unverified_context()
    recipients = [addr for addr in TO if addr]
    if not recipients:
        dagster_logger.info("sendemail_: no recipients after filtering empty addresses")
        return
    TO = recipients

    senders_email = os.getenv("senders_email", "email")  # senders email
    senders_pswd = os.getenv("senders_pw", "pw")  # senders password

    # current date, and a date 5 days away
    curtime = datetime.datetime.now().date()
    # Gmail Sign In
    gmail_sender = senders_email
    gmail_passwd = senders_pswd

    msg = MIMEMultipart("alternative")  # tell the package we'd prefer HTML emails
    msg["Subject"] = SUBJECT  # set the SUBJECT of the email
    msg["From"] = gmail_sender  # set the FROM field of the email
    msg["To"] = ", ".join(TO)  # set the TO field of the email

    # add the 2 parts of the email (one plain text, one html)
    part1 = MIMEText(TEXT, "plain")
    part2 = MIMEText(HTML, "html")
    # It will default to the plain text verison if the HTML doesn't work, plain must go first
    msg.attach(part1)
    msg.attach(part2)

    if filename:
        ctype, encoding = mimetypes.guess_type(filename)
        if ctype is None or encoding is not None:
            ctype = "application/octet-stream"
        maintype, subtype = ctype.split("/", 1)

        with open(filename) as fp:
            attachment = MIMEText(fp.read(), _subtype=subtype)
        attachment.add_header("Content-Disposition", "attachment", filename=os.path.basename(filename))
        msg.attach(attachment)

    # connect to the GMAIL server
    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    # login to the GMAIL server
    server.login(gmail_sender, gmail_passwd)

    try:
        # send email and confirm email is sent / time it is sent
        server.sendmail(gmail_sender, TO, msg.as_string())
        logging.info(str(curtime) + " email sent")
    except Exception as e:
        # print error if not sent, and confirm it wasn't sent
        dagster_logger.info(str(e))
        dagster_logger.info(error_handling())
        dagster_logger.info(str(curtime) + " error sending mail")

    server.quit()


def update_json_file(file_location: str, dictionary: dict[str, Any]) -> None:
    """Merge ``dictionary`` into an existing JSON object and write it back to disk.

    Args:
        file_location: Path to a JSON file on disk.
        dictionary: Keys and values merged into the top-level object via ``dict.update``.

    Returns:
        None

    Note:
        ``FileNotFoundError``, ``json.JSONDecodeError``, and other exceptions are
        caught, logged, and not re-raised.
    """
    try:
        # Load the JSON file
        with open(file_location, "r") as file:
            data = json.load(file)

        # Update the JSON data with the dictionary
        data.update(dictionary)

        # Write the updated data back to the JSON file
        with open(file_location, "w") as file:
            json.dump(data, file, indent=4)

        dagster_logger.info("JSON file updated successfully.")
    except FileNotFoundError:
        dagster_logger.info("File not found.")
    except json.JSONDecodeError:
        dagster_logger.info("Invalid JSON file format.")
    except Exception as e:
        dagster_logger.info(f"An error occurred: {str(e)}")


def error_handling() -> str:
    """Return the current exception traceback as a string (for logging).

    Returns:
        Full traceback string from ``traceback.format_exc()``.
    """
    return traceback.format_exc()


# Selenium / Chrome-related
def get_chromedriver_download_table() -> pd.DataFrame:
    """Build a DataFrame of Chrome for Testing chromedriver download URLs by version.

    Fetches the public JSON manifest, expands ``downloads.chromedriver`` entries,
    and attaches the manifest ``timestamp``.

    Returns:
        ``pandas.DataFrame`` with columns such as ``revision``, ``version``,
        ``platform``, ``url``, and ``timestamp``.
    """
    url = "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json"
    body, _rate = read_json_from_api(url)
    if not isinstance(body, dict):
        return pd.DataFrame()
    versions = body.get("versions", [])
    ts = body.get("timestamp")

    ok: list[dict[str, Any]] = []
    for ver in versions:
        if not isinstance(ver, dict):
            continue
        try:
            for w in ver["downloads"]["chromedriver"]:
                ok.append(
                    {"revision": ver["revision"], "version": ver["version"], "platform": w["platform"], "url": w["url"]}
                )
        except KeyError:
            pass
    wow = pd.DataFrame(ok)
    wow["timestamp"] = ts
    return wow


def check_selenium_browser_driver_ubuntu(path_to_chromedriver_dir: str) -> None:
    """Assert the on-disk chromedriver folder matches the installed Chrome major version.

    Args:
        path_to_chromedriver_dir: Base path ending with separator; expects a
            ``chromedriver/`` subdirectory whose first listing contains
            ``chromedriver{major}``.

    Returns:
        None

    Raises:
        AssertionError: If the chromedriver artifact name does not match Chrome.
    """
    version = get_application_version_ubuntu()
    vers = version.split(".")[0]
    chromedriver_dir = path_to_chromedriver_dir + "chromedriver/"
    assert f"chromedriver{vers}" in os.listdir(chromedriver_dir)[0], (
        f"in_folder= {os.listdir(chromedriver_dir)}, path= {path_to_chromedriver_dir}, "
        f"version= {vers}, chromedriver{vers}.exe not in chromedriver folder"
    )
    dagster_logger.info(f"ChromeDriver version and Browser version are synced {vers}")


def get_application_version_ubuntu(path_to_exe: str = "google-chrome") -> str:
    """Return the semantic version string reported by an executable's ``--version``.

    Args:
        path_to_exe: Executable invoked with ``--version`` (default Chrome).

    Returns:
        Version substring extracted via regex from command output.

    Raises:
        IndexError: If no version pattern matches the command output.
    """
    command = rf"""{path_to_exe} --version"""
    version = "".join([b for b in os.popen(command).readlines()])
    version = re.findall(
        r"\s(\d+.+)",
        version,
    )[0].strip()
    return version


def get_selenium_driver(browser: str = "chrome", dat_path: str = "/home/jay/PycharmProjects/home/data/") -> WebDriver:
    """Construct a headless Chrome or configured Firefox WebDriver instance.

    Args:
        browser: ``'chrome'`` or ``'firefox'``.
        dat_path: Reserved for driver path logic (Chrome path currently unused).

    Returns:
        Configured ``selenium.webdriver`` instance.

    Note:
        Chrome uses a fixed binary path ``/usr/bin/google-chrome`` and common
        headless flags; Firefox sets download preferences under Windows-style paths
        when not using Chrome.
    """
    if browser == "chrome":
        vers = get_application_version_ubuntu().split(".")[0]
        print(vers)
        chromeOptions = chrome_options()
        chromeOptions.binary_location = "/usr/bin/google-chrome"
        chromeOptions.add_experimental_option(
            "prefs",
            {
                "download.default_directory": r"/home/jay/Downloads",
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
                "safebrowsing.enabled": True,
            },
        )
        chromeOptions.add_argument("--headless")
        chromeOptions.add_argument("--no-sandbox")
        chromeOptions.add_argument("--disable-dev-shm-usage")
        # chrome_driver_path = dat_path + 'chromedriver/chromedriver' + vers
        driver = webdriver.Chrome(options=chromeOptions)
    else:
        firefoxOptions = firefox_options()
        firefoxOptions.set_preference("browser.download.folderList", 2)
        firefoxOptions.set_preference("browser.download.manager.showWhenStarting", False)
        firefoxOptions.set_preference("browser.download.dir", path.replace("/", "\\") + "data\\downloads\\")
        firefoxOptions.set_preference(
            "browser.helperApps.neverAsk.saveToDisk",
            "application/octet-stream,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        driver = webdriver.Firefox(options=firefoxOptions)
    return driver


def grab_soup(url_: str, driver: WebDriver) -> bs.BeautifulSoup:
    """Load ``url_`` in Selenium, wait briefly, and parse ``document.body`` as BeautifulSoup.

    Args:
        url_: Page URL to fetch.
        driver: Active Selenium ``WebDriver`` (Chrome or Firefox).

    Returns:
        ``bs4.BeautifulSoup`` tree built from the rendered outer HTML.
    """
    driver.get(url_)  # go to the URL
    _ = driver.page_source
    time.sleep(1)  # sleep for 1 second  to ensure all JS scripts are loaded
    html = driver.execute_script("return document.body.outerHTML;")  # execute javascript code
    soup_ = bs.BeautifulSoup(html, "lxml")  # read the data as html (using lxml driver)
    return soup_


def xpath_soup(element: Any) -> str:
    """Build an XPath string locating a BeautifulSoup element in its tree.

    Args:
        element: ``bs4`` element or NavigableString (uses ``element.parent`` when
            unnamed).

    Returns:
        XPath expression starting with ``/`` (tag names with optional indices).
    """
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:
        previous = itertools.islice(parent.children, 0, parent.contents.index(child))
        xpath_tag = child.name
        xpath_index = sum(1 for i in previous if i.name == xpath_tag) + 1
        components.append(xpath_tag if xpath_index == 1 else "%s[%d]" % (xpath_tag, xpath_index))
        child = parent
    components.reverse()
    return "/%s" % "/".join(components)


# BOKEH
def run_bokeh_app(
    files: list[str],
    port: int = 5002,
    new: Literal["tab", "window", "current"] = "tab",
) -> None:
    """Start Bokeh apps in background threads and open them in the default browser.

    Args:
        files: List of ``.py`` file paths passed to Bokeh's application builder.
        port: TCP port for the Bokeh server (host is ``localhost``).
        new: ``webbrowser.open`` ``new`` flag: ``'tab'``, ``'window'``, or ``'current'``.

    Returns:
        None: Threads keep running; shutdown thread stops the IOLoop when sessions end.
    """
    # all files in directory that you want as bokeh apps
    # run_bokeh_app(["finance_charts.py",])
    # run_bokeh_app(["personal.py", ])

    def create_bokeh_server(io_loop: Any, files: list[str], argvs: dict[str, Any], host: str, port: int) -> Any:
        """Build and return a Bokeh ``Server`` for the given app file paths.

        Args:
            io_loop: Tornado IOLoop instance.
            files: Bokeh app script paths.
            argvs: Per-file argv mapping for Bokeh handlers.
            host: ``host:port`` listen string.
            port: Integer port (also embedded in ``host``).

        Returns:
            Configured ``bokeh.server.server.Server`` instance.
        """
        from bokeh.command.util import build_single_handler_applications
        from bokeh.server.server import Server

        # Turn file paths into bokeh apps
        apps = build_single_handler_applications(files, argvs)

        # kwargs lifted from bokeh serve call to Server, with created io_loop
        kwargs = {
            "io_loop": io_loop,
            "generate_session_ids": True,
            "redirect_root": True,
            "use_x_headers": False,
            "secret_key": None,
            "num_procs": 1,
            "host": host,
            "sign_sessions": False,
            "develop": False,
            "port": port,
            "use_index": True,
        }
        server = Server(apps, **kwargs)

        return server

    def start_bokeh(io_loop: Any) -> None:
        """Start the Tornado ``IOLoop`` (blocks until stopped).

        Args:
            io_loop: Tornado ``IOLoop`` to run.

        Returns:
            Always ``None`` after ``start`` returns (blocking).
        """
        io_loop.start()
        return None

    def launch_app(host: str, app_name: str, new: str) -> None:
        """Open ``http://{host}/{app_name}`` in the system browser.

        Args:
            host: Combined ``hostname:port`` for the Bokeh server.
            app_name: Application route name (filename stem).
            new: ``webbrowser`` ``new`` flag (``'tab'``, ``'window'``, or ``'current'``).

        Returns:
            None
        """
        import webbrowser

        # Map method strings to webbrowser method
        options = {"current": 0, "window": 1, "tab": 2}

        # Concatenate url and open in browser, creating a session
        app_url = "http://{}/{}".format(host, app_name)
        print("Opening `{}` in browser".format(app_url))
        webbrowser.open(app_url, new=options[new])

        return None

    def server_loop(server: Any, io_loop: Any) -> None:
        """Poll Bokeh sessions until all disconnect, then stop ``io_loop``.

        Args:
            server: Running ``bokeh.server.server.Server``.
            io_loop: Tornado loop to stop after idle shutdown.

        Returns:
            None
        """
        import time

        connected = [
            True,
        ]
        session_loaded = False
        while any(connected):
            # Check if no session started on server
            sessions = server.get_sessions()
            if not session_loaded:
                if sessions:
                    session_loaded = True
            # Once 1+ sessions started, check for no connections
            else:
                # List of bools for each session
                connected = [
                    True,
                ] * len(sessions)
                # Set `connected` item false no connections on session
                for i in range(len(sessions)):
                    if sessions[i].connection_count == 0:
                        connected[i] = False
            # Keep the pace down
            time.sleep(2)

        # Stop server once opened session connections closed
        io_loop.stop()

        return None

    # Initialize some values, sanatize the paths to the bokeh plots
    argvs = {}
    app_names = []
    for path in files:
        argvs[path] = None
        app_names.append(os.path.splitext(os.path.split(path)[1])[0])

    # Concate hostname/port for creating handlers, launching apps
    host = "localhost:{}".format(port)
    # Initialize the tornado server
    io_loop = tornado.ioloop.IOLoop.instance()
    # tornado.autoreload.start(io_loop)

    # Add the io_loop to the bokeh server
    server = create_bokeh_server(io_loop, files, argvs, host, port)

    print("Starting the server on {}".format(host))
    args = (io_loop,)
    th_startup = threading.Thread(target=start_bokeh, args=args)
    th_startup.start()

    # Launch each application in own tab or window
    th_launch = [
        None,
    ] * len(app_names)
    for i in range(len(app_names)):
        args = (host, app_names[i], new)
        th_launch[i] = threading.Thread(target=launch_app, args=args)
        if th_launch[i] is not None:
            cast(threading.Thread, th_launch[i]).start()
        # Delay to allow tabs to open in same browser window
        time.sleep(2)

    # Run session connection test, then stop `io_loop`
    args = (server, io_loop)
    th_shutdown = threading.Thread(target=server_loop, args=args)
    th_shutdown.start()


# DATE HELPERS
def split_date_range_into_months(start_date: pd.Timestamp, end_date: pd.Timestamp) -> list[tuple[str, str]]:
    """Split ``[start_date, end_date]`` into calendar-month (start, end) string pairs.

    Args:
        start_date: Range start (time component ignored for month bucketing).
        end_date: Range end (clamped within the last partial month).

    Returns:
        List of ``(YYYY-MM-DD, YYYY-MM-DD)`` tuples per month in range.
    """
    months = []
    current_start = start_date.replace(day=1)

    while current_start <= end_date:
        # Get the last day of the current month
        current_end = (current_start + pd.offsets.MonthEnd(0)).date()  # Last day of the current month

        # Ensure we do not exceed the overall end_date
        current_end = min(current_end, end_date.date())

        # Append the current month's range as a tuple
        months.append((current_start.strftime("%Y-%m-%d"), current_end.strftime("%Y-%m-%d")))

        # Move to the next month
        current_start = (current_start + pd.DateOffset(months=1)).replace(day=1)

    return months


def convert_column_name(column_name: str) -> str:
    """Convert camelCase or PascalCase identifiers to snake_case.

    Args:
        column_name: Source column or field name.

    Returns:
        Snake-case string with spaces replaced by underscores and stripped.
    """
    # Use regular expression to add underscores before capital letters and convert them to lowercase
    result = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", column_name).lower()
    result = result.replace(" ", "_")
    return result.strip()


def is_business_day(date: datetime.date) -> bool:
    """Return whether ``date`` is a business day according to pandas.

    Args:
        date: Calendar date to test.

    Returns:
        ``True`` if ``pd.bdate_range`` includes the date, else ``False``.
    """
    return bool(len(pd.bdate_range(date, date)))


def date_conversion(
    date: str | datetime.datetime | None,
    return_type: str = "str",
) -> str | datetime.datetime | pd.Timestamp | None:
    """Normalize a date-like value into string, short string, datetime, or Timestamp.

    Args:
        date: ISO string, ``datetime``, or ``None`` (returns ``None``).
        return_type: ``'str'`` (ISO), ``'short'`` (``YYYY-MM-DD``), ``'obj'``
            (``datetime``), or ``'timestamp'`` (``pd.Timestamp``).

    Returns:
        Converted value, or ``None`` when ``date`` is ``None``.

    Raises:
        ValueError: For invalid ISO strings or unsupported ``return_type``.
        TypeError: For unsupported ``date`` types.
    """
    if date is None:
        return None
    elif isinstance(date, str):
        try:
            date_obj = datetime.datetime.fromisoformat(date)
        except ValueError:
            raise ValueError(
                f"Invalid date string format: {date}. Expected ISO format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)."
            )
    elif isinstance(date, datetime.datetime):
        date_obj = date
    else:
        raise TypeError(f"Unsupported date type: {type(date)}")

    if return_type == "str":
        return date_obj.isoformat()
    elif return_type == "short":
        return date_obj.strftime("%Y-%m-%d")
    elif return_type == "obj":
        return date_obj
    elif return_type == "timestamp":
        return pd.to_datetime(date_obj)
    else:
        raise ValueError(f"Invalid return_type: {return_type}. Expected 'str' or 'datetime'.")


# WINDOWS FUNCS
def get_application_version_windows(
    path_to_exe: str = r"C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
) -> str:
    """Read a Windows executable file version via ``wmic``.

    Args:
        path_to_exe: Full path to the ``.exe`` passed to WMIC ``datafile`` query.

    Returns:
        Version string parsed from ``Version=value`` output.

    Raises:
        IndexError: If WMIC output does not contain an ``=`` version fragment.
    """
    command = rf""" wmic datafile where name="{path_to_exe}" get Version /value """
    version = "".join([b for b in os.popen(command).readlines()])
    version = version.strip().split("=")[1]
    return version


def execute_cmd_windows(commands: str) -> str | None:
    """Run a shell command on Windows via ``subprocess.Popen`` with ``shell=True``.

    Args:
        commands: Full command string passed to the shell.

    Returns:
        Decoded stdout string when available, ``'Did not run'`` on broad
        exceptions, or ``None`` when no stdout is produced.

    Note:
        ``communicate`` is called without assigning ``stdout=PIPE`` in the
        snippet below, so captured output is often ``None``; behavior is preserved
        for compatibility.
    """
    try:
        out_var = subprocess.Popen(commands, shell=True)
        dagster_logger.info(f"{commands} | Running...")

        (output, err) = out_var.communicate()
        output_str = None
        err_str = None
        # Decode the output and error from bytes to string
        # Print the output and error
        if output:
            output_str = output.decode("utf-8")
            print("Output:")
            # This will give you the output of the command being executed
            dagster_logger.info("Command output: " + output_str)

        if err:
            err_str = err.decode("utf-8")
            print("Error:")
            print(err_str)

        return output_str
    except Exception:
        dagster_logger.info(error_handling())
        return "Did not run"


def check_selenium_browser_driver_windows() -> None:
    """Assert ``chromedriver{major}.exe`` exists beside the configured ``data_path``.

    Returns:
        None

    Raises:
        AssertionError: If the expected chromedriver filename is not in the folder.
    """
    version = get_application_version_windows()
    assert f"chromedriver{version.split('.')[0]}.exe" in os.listdir(data_path + "chromedriver/"), (
        f"version = {version}, chromedriver{version.split('.')[0]}.exe not in chromedriver folder"
    )
    dagster_logger.info(f"ChromeDriver version and Browser version are synced {version}")
