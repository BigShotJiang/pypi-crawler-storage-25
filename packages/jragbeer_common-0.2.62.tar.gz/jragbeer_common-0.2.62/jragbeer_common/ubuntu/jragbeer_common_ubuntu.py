import datetime
import io
import os
import re
import subprocess
import time
from typing import Any, Callable, Iterable, Union

import numpy as np
import paramiko
import yaml

from ..common.jragbeer_common_data_eng import dagster_logger, error_handling


class SshClient:
    """Thin wrapper around ``paramiko.SSHClient`` for remote shell commands."""

    TIMEOUT = 4

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        key: str | None = None,
        passphrase: str | None = None,
    ) -> None:
        """Connect to a host over SSH.

        Args:
            host: Remote hostname or IP address.
            port: SSH port (typically 22).
            username: SSH username.
            password: SSH password (also used for ``sudo -S`` when applicable).
            key: Optional PEM private key material as a string.
            passphrase: Optional passphrase for the private key.

        Returns:
            None
        """
        self.username = username
        self.password = password
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        pkey: paramiko.PKey | None = None
        if key is not None:
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(key), password=passphrase)
        self.client.connect(host, port, username=username, password=password, pkey=pkey, timeout=self.TIMEOUT)

    def close(self) -> None:
        """Close the SSH session and release the client.

        Returns:
            None
        """
        if self.client is not None:
            self.client.close()
            self.client = None

    def execute(self, command: str, sudo: bool = False) -> dict[str, Any]:
        """Run a command on the remote host.

        Args:
            command: Shell command string to execute.
            sudo: If True, run via ``sudo``; password is fed on stdin when the
                user is not root and a password is set.

        Returns:
            dict: Keys ``out`` (stdout lines), ``err`` (stderr lines), and
            ``retval`` (integer exit status).
        """
        feed_password = False
        if sudo and self.username != "root":
            command = "sudo -S -p '' %s" % command
            feed_password = self.password is not None and len(self.password) > 0
        if self.client is None:
            raise ValueError("Failed to connect to the remote host")
        stdin, stdout, stderr = self.client.exec_command(command)
        if feed_password:
            stdin.write(self.password + "\n")
            stdin.flush()
        return {"out": stdout.readlines(), "err": stderr.readlines(), "retval": stdout.channel.recv_exit_status()}


def execute_confirm_wait(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorate a callable so it is invoked, then sleeps briefly.

    If the call raises ``TypeError`` (e.g. wrong arity), retries with no
    arguments.

    Args:
        func: Callable to wrap.

    Returns:
        The inner wrapper; calling it returns ``func`` after execution.
    """

    def inner(*args: Any, **kwargs: Any) -> Callable[..., Any]:
        """Invoke the wrapped ``func`` with optional ``*args`` and ``**kwargs``.

        Args:
            *args: Positional arguments forwarded to ``func``.
            **kwargs: Keyword arguments forwarded to ``func``.

        Returns:
            The wrapped ``func`` object after execution (not its return value).
        """
        try:
            func(*args, **kwargs)
            # dagster_logger.info(f"{args}, {kwargs} is done! ({func.__name__})")
        except TypeError:
            func()
            # dagster_logger.info(f"it's done! ({func.__name__})")
        time.sleep(0.05)
        return func

    return inner


def execute_script_with_cmd(script_name: str) -> str:
    """Execute a Python file like a script and log the result.

    Args:
        script_name: Path to the ``.py`` file to run via :func:`execfile`.

    Returns:
        String representation of the script's evaluated result (often
        uninformative; see :func:`execfile`).
    """
    output = execfile(script_name)
    dagster_logger.info(str(output))
    return str(output)


def execute_cmd_ubuntu_sudo(commands: list[str] | str) -> str | None:
    """Run a command with ``sudo -S`` using the cluster password from the environment.

    Uses ``cluster_server_0_password`` for sudo authentication.

    Args:
        commands: argv tokens as a list, or a single string split on whitespace.

    Returns:
        Standard output on success, or ``None`` on failure or if an exception
        is swallowed after logging.

    Raises:
        ValueError: If ``cluster_server_0_password`` is unset.
    """
    try:
        if isinstance(commands, str):
            commands = commands.split()

        password = os.getenv("cluster_server_0_password")
        if not password:
            raise ValueError("cluster_server_0_password environment variable must be set")

        result = subprocess.run(
            ["sudo", "-S"] + commands,
            input=password + "\n",
            capture_output=True,
            text=True,
            check=False,  # Don't raise on non-zero exit
        )

        if result.returncode == 0:
            if result.stdout:
                dagster_logger.info(f"Command output: {result.stdout}")
            return result.stdout
        else:
            dagster_logger.warning(f"Command failed: {result.stderr}")
            return None

    except Exception:
        dagster_logger.info(error_handling())
    return None


def execute_cmd_ubuntu_normal(commands: list[str] | str) -> str | None:
    """Run a shell command locally (``shell=True``) without sudo.

    Args:
        commands: Passed to ``subprocess.run``; may be a list or string.

    Returns:
        Captured stdout as a string on success, or ``None`` if the command
        failed or an exception occurred (errors are logged).
    """
    output_str = None
    try:
        output = subprocess.run(commands, shell=True, check=True, capture_output=True, text=True)

        # Decode the output and error from bytes to string
        # Print the output and error
        if output.stdout:
            output_str = output.stdout
            dagster_logger.info(f"Command output: {output_str}")
        if output.stderr:
            dagster_logger.warning(f"Command stderr: {output.stderr}")
    except Exception:
        dagster_logger.info(error_handling())
    return output_str


def execfile(
    filepath: str,
    globals: dict[str, Any] | None = None,
    locals: dict[str, Any] | None = None,
) -> None:
    """Execute a Python file in the given namespace (similar to historical Python 2 ``execfile``).

    Sets ``__file__`` and ``__name__`` in ``globals`` before execution.

    Args:
        filepath: Path to the Python source file.
        globals: Optional globals dict (defaults to ``{}``).
        locals: Optional locals dict passed to ``exec`` (defaults to same as
            ``globals`` when omitted at call site behavior matches ``exec``).

    Returns:
        None. Side effects occur in ``globals`` / ``locals``.
    """
    if globals is None:
        globals = {}
    if locals is None:
        locals = globals
    globals.update(
        {
            "__file__": filepath,
            "__name__": "__main__",
        }
    )
    with open(filepath, "rb") as file:
        exec(compile(file.read(), filepath, "exec"), globals, locals)
    return None


def kill_remote_ubuntu_process_ids(hostname: str, username: str, password: str, pid: Union[str, Iterable[str]]) -> None:
    """Force-kill remote processes by PID over SSH (``kill -9``).

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        pid: One PID as string, whitespace-separated PIDs as string, or iterable
            of PID strings.

    Returns:
        None: Output is printed; SSH connection is not explicitly closed.
    """
    if isinstance(pid, str):
        pid = pid.split()
    # SSH into the remote machine
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, username=username, password=password)
    # Run command to get memory usage stats
    python_command = "sudo kill -9 " + " ".join(pid)
    print(python_command)
    stdin, stdout, stderr = ssh.exec_command(python_command)
    py_output = stdout.read().decode().strip()
    print(py_output)
    print("remote killing of pids done")


def get_remote_process_ids_ubuntu(hostname: str, username: str, password: str, search_string: str = "") -> list[str]:
    """List PIDs on a remote host whose ``ps aux`` line matches ``search_string``.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        search_string: Substring matched in ``ps aux`` (excludes defunct and
            the ``grep`` process itself).

    Returns:
        List of PID strings for matching processes.
    """
    # SSH into the remote machine
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, username=username, password=password)

    # Run command to show matching processes excluding defunct ones
    list_command = f"ps aux | grep '{search_string}' | grep -v '<defunct>' | grep -v 'grep'"
    stdin, stdout, stderr = ssh.exec_command(list_command)
    process_output = stdout.read().decode().strip()
    print(process_output)

    # Extract PIDs of those non-defunct processes
    pid_command = f"ps aux | grep '{search_string}' | grep -v '<defunct>' | grep -v 'grep' | awk '{{print $2}}'"
    stdin, stdout, stderr = ssh.exec_command(pid_command)
    pid_output = stdout.read().decode().strip()
    pid_list = pid_output.split()

    return pid_list


def get_remote_stats_ubuntu(hostname: str, username: str, password: str) -> dict[str, int | float | str]:
    """Collect CPU, memory, OS, and network stats from a remote Ubuntu host via SSH.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.

    Returns:
        Flat dict of metrics (memory fields, ``cpu_pct``, ``python_memory_usage_GB``,
        ``sql_memory_usage_GB``, ``query_time``, etc.).
    """
    # SSH into the remote machine
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, username=username, password=password)

    # Run command to get memory usage stats
    memory_command = "free -m | awk 'NR==2{print $2,$3,$4,$5,$6,$7}'"
    stdin, stdout, stderr = ssh.exec_command(memory_command)
    mem_output = stdout.read().decode().strip()
    # Extract memory usage stats from the output
    total, used, free, shared, buff_cache, available = mem_output.split()

    # Run commands to get CPU and memory usage
    cpu_command = "top -bn1 | grep '%Cpu(s)' | awk '{print $2 + $4}'"
    stdin, stdout, stderr = ssh.exec_command(cpu_command)
    cpu_usage = float(stdout.read().decode().strip())

    # Return memory usage stats
    mem = {
        "Total": int(total),
        "Used": int(used),
        "Free": int(free),
        "Available": int(available),
        "Percent": int(int(used) / int(total)),
    }

    # Run command to get memory usage stats
    python_command = "ps aux | grep python | awk '{print $6}'"
    stdin, stdout, stderr = ssh.exec_command(python_command)
    py_output = stdout.read().decode().strip()
    python_memory_usage_kB = sum([int(i) for i in py_output.split()])

    # Run command to get Python process memory usage
    sql_command = "ps aux | grep sql | awk '{print $6}'"
    stdin, stdout, stderr = ssh.exec_command(sql_command)
    sql_output = stdout.read().decode().strip()
    sql_memory_usage_kB = sum([int(i) for i in sql_output.split()])

    # Run command to get the number of CPU cores
    cpu_cores_command = "nproc"
    stdin, stdout, stderr = ssh.exec_command(cpu_cores_command)
    cpu_cores_output = int(stdout.read().decode().strip())

    # Run command to get CPU frequency
    cpu_freq_command = """ lscpu | grep "MHz" """
    stdin, stdout, stderr = ssh.exec_command(cpu_freq_command)
    cpu_freq_output = stdout.read().decode().strip()
    cpu_freq_output = int(re.findall(r"(\d+)(CPU)?", cpu_freq_output)[0][0])

    # Run command to get operating system information
    os_command = """lsb_release -a | grep "Description" """
    stdin, stdout, stderr = ssh.exec_command(os_command)
    os_output = stdout.read().decode().strip()
    os_output = str(os_output).split(":")[1].strip()

    # Run command to get CPU model
    cpu_model_command = "lscpu | grep 'Model name'"
    stdin, stdout, stderr = ssh.exec_command(cpu_model_command)
    cpu_model_output = stdout.read().decode().strip().split(":")[1].strip()

    ip_command = "ip addr show | grep 'inet '"
    stdin, stdout, stderr = ssh.exec_command(ip_command)
    ip_output = stdout.read().decode().strip()
    ip_output = re.findall(r"inet\s(192.168.\d+.\d+)", ip_output)[0]

    # Close the SSH connection
    ssh.close()
    output_dict: dict[str, int | float | str] = {"memory_" + k.lower() + "_MB": v for k, v in mem.items()}
    output_dict.update(
        {
            "cpu_pct": cpu_usage,  # gives a single float value
            "cpu_cores": cpu_cores_output,
            "cpu_freq": cpu_freq_output,
            "pc_network_address": ip_output,
            "pc_os": os_output,
            "pc_cpu": cpu_model_output,
            "python_memory_usage_GB": np.round(python_memory_usage_kB / 1024**2, 2),
            "sql_memory_usage_GB": np.round(
                sql_memory_usage_kB / 1024**2,
            ),
            "query_time": str(datetime.datetime.now()),
        }
    )
    return output_dict


def move_file_to_remote_pc(
    hostname: str,
    username: str,
    password: str,
    local_path: str = "/etc/dask/dask.yaml",
    remote_path: str = "/home/jay/PycharmProjects/home/dask.yaml",
) -> None:
    """Upload a local file to a remote path via SFTP; optionally configure ``/etc/dask``.

    When ``local_path`` is the default dask config path, also runs remote
    ``sudo`` commands to prepare ``/etc/dask/`` via :class:`SshClient`.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        local_path: Local file to upload.
        remote_path: Destination path on the remote host.

    Returns:
        None
    """
    # SSH into the remote machine
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(
        hostname,
        username=username,
        password=password,
    )
    sftp = ssh.open_sftp()
    try:
        sftp.put(localpath=local_path, remotepath=remote_path)
        # check that file is there
        sftp.stat(remote_path)
        print("File upload complete.")
    except Exception as e:
        print(f"Upload failed: {e}")
    sftp.close()
    ssh.close()
    if local_path == "/etc/dask/dask.yaml":
        client = SshClient(host=hostname, port=22, username=username, password=password)
        try:
            ret = client.execute(command="""sudo mkdir /etc/dask/""", sudo=True)
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
            ret = client.execute(command="""sudo chmod -R 777 /etc/dask/""", sudo=True)
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
            ret = client.execute(
                command="""sudo mv /home/jay/PycharmProjects/jragbeer_home/dask.yaml /etc/dask/dask.yaml""", sudo=True
            )
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])

        finally:
            client.close()
            dagster_logger.info("Done")


def give_write_permission_to_folder(folder_path: str) -> None:
    """Recursively grant world read/write/execute on a path via sudo.

    Args:
        folder_path: Directory (or path) passed to ``chmod -R 777``.

    Returns:
        None
    """
    execute_cmd_ubuntu_sudo(f"sudo chmod -R 777 {folder_path}")


def create_yaml_from_dict(input_dict: dict[Any, Any], name_of_yaml: str | None = None) -> str:
    """Serialize ``input_dict`` to YAML, optionally writing to a file.

    Args:
        input_dict: Mapping to dump.
        name_of_yaml: If set, YAML is written to this path; otherwise only the
            string is built.

    Returns:
        YAML document as a string.
    """
    yamll = yaml.dump(input_dict, allow_unicode=True)
    if name_of_yaml:
        with open(name_of_yaml, "w", encoding="utf-8") as ff:
            ff.write(yamll)
    if yamll is None:
        raise ValueError("Failed to dump YAML")
    return yamll


def update_repo_on_remote_machine(hostname: str, username: str, password: str, repo: str) -> None:
    """SSH to a host and run ``git restore .`` and ``git pull`` in a project directory.

    Args:
        hostname: Remote host address.
        username: SSH user.
        password: SSH password.
        repo: Repository folder name under ``/home/jay/PycharmProjects/``.

    Returns:
        None
    """
    client = SshClient(host=hostname, port=22, username=username, password=password)
    try:
        cmd = f"""cd /home/jay/PycharmProjects/{repo}/; git restore . ; git pull"""
        ret = client.execute(
            command=cmd,
        )
        print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
    finally:
        client.close()
