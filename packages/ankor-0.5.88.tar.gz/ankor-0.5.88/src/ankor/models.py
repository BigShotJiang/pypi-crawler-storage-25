from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
)
from sqlmodel import Field, SQLModel


class UserRole(str, Enum):
    admin = "admin"


class WorkflowStatus(str, Enum):
    pending = "pending"
    running = "running"
    success = "success"
    failed = "failed"
    cancelled = "cancelled"


class TriggerType(str, Enum):
    manual = "manual"
    schedule = "schedule"
    webhook = "webhook"
    rerun = "rerun"


class WorkflowRun(SQLModel, table=True):
    __tablename__ = "workflow_runs"

    id: int | None = Field(default=None, primary_key=True)
    workflow_id: int = Field(foreign_key="workflows.id")
    status: WorkflowStatus = Field(
        default=WorkflowStatus.pending,
        sa_column=Column(
            SAEnum(WorkflowStatus, name="workflowstatus", create_type=False),
            nullable=False,
            server_default="pending",
        ),
    )
    triggered_by: TriggerType = Field(
        default=TriggerType.manual,
        sa_column=Column(
            SAEnum(TriggerType, name="triggertype", create_type=False),
            nullable=False,
            server_default="manual",
        ),
    )
    started_at: datetime | None = Field(
        default=None, sa_column=Column(DateTime(timezone=True), nullable=True)
    )
    finished_at: datetime | None = Field(
        default=None, sa_column=Column(DateTime(timezone=True), nullable=True)
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    parent_id: int | None = Field(
        default=None, foreign_key="workflow_runs.id", index=True
    )
    data: dict[str, Any] = Field(
        default_factory=dict,
        sa_column=Column(JSON),
        description="Execution payload: {inputs, outputs, logs, trigger_context}. Node data lives in run_nodes.",
    )


class User(SQLModel, table=True):
    __tablename__ = "users"

    username: str = Field(primary_key=True)
    hashed_password: str
    email: str | None = Field(default=None, sa_column=Column(String, nullable=True))
    role: UserRole = Field(
        default=UserRole.admin,
        sa_column=Column(
            SAEnum(UserRole, name="userrole", create_type=False),
            nullable=False,
            server_default="admin",
        ),
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class ConfigRecord(SQLModel, table=True):
    __tablename__ = "config_records"

    id: int | None = Field(default=None, primary_key=True)
    key: str = Field(index=True, unique=True)
    value: str
    type: str  # string | number | date | datetime | time | select | json
    select_options: list[str] | None = Field(default=None, sa_column=Column(JSON))
    description: str | None = None
    folder: str | None = None
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class DataTable(SQLModel, table=True):
    __tablename__ = "data_tables"

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(unique=True)
    description: str | None = None
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class DataTableColumnMeta(SQLModel, table=True):
    __tablename__ = "data_table_column_meta"

    table_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey("data_tables.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        )
    )
    column_name: str = Field(primary_key=True)
    select_options: list[str] | None = Field(default=None, sa_column=Column(JSON))


class WebhookToken(SQLModel, table=True):
    __tablename__ = "webhook_tokens"

    id: str = Field(default="default", primary_key=True)
    token: str
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class ApiToken(SQLModel, table=True):
    __tablename__ = "api_tokens"

    id: int | None = Field(default=None, primary_key=True)
    name: str
    username: str = Field(foreign_key="users.username")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    expires_at: datetime | None = Field(
        default=None, sa_column=Column(DateTime(timezone=True), nullable=True)
    )


class Workflow(SQLModel, table=True):
    __tablename__ = "workflows"

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    folder: str | None = Field(default=None, sa_column=Column(String, nullable=True))
    enabled: bool = Field(default=True)
    schedule_override: str | None = None
    timeout_seconds: int | None = None
    max_concurrent_runs: int | None = Field(
        default=300, sa_column=Column(Integer, nullable=True, server_default="300")
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


# Alias kept for compatibility with existing call-sites until all are migrated.
WorkflowConfig = Workflow


class RunNode(SQLModel, table=True):
    __tablename__ = "run_nodes"

    id: int | None = Field(default=None, primary_key=True)
    run_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey("workflow_runs.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        )
    )
    # Self-referential FK: NULL means top-level node, non-NULL means child of that row.
    parent_node_id: int | None = Field(
        default=None,
        sa_column=Column(
            Integer,
            ForeignKey("run_nodes.id", ondelete="CASCADE"),
            nullable=True,
            index=True,
        ),
    )
    # Promoted metadata columns — allow list queries without loading data JSON.
    name: str | None = Field(default=None)
    slug: str | None = Field(default=None)
    status: WorkflowStatus | None = Field(
        default=None,
        sa_column=Column(
            SAEnum(WorkflowStatus, name="workflowstatus", create_type=False),
            nullable=True,
        ),
    )
    duration_ms: int | None = Field(default=None)
    started_at: datetime | None = Field(
        default=None, sa_column=Column(DateTime(timezone=True), nullable=True)
    )
    # FK to the child WorkflowRun (for sub-workflow nodes).
    child_run_id: int | None = Field(
        default=None,
        sa_column=Column(
            Integer,
            ForeignKey("workflow_runs.id", ondelete="SET NULL"),
            nullable=True,
        ),
    )
    # Slim execution record: {inputs, outputs, logs}.  No children — they are separate rows.
    data: dict[str, Any] = Field(
        default_factory=dict,
        sa_column=Column(JSON),
        description="Node execution payload: {inputs, outputs, logs}.",
    )
