"""Seed demo data.

When ``auto_seed`` (GTM_SEED env var) is enabled, always truncates all
tables and re-inserts fresh demo data on every startup.
"""

from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone


NOW = datetime.now(timezone.utc)

_WORKFLOW_NAMES = [
    "enrich_leads",
    "daily_report",
    "sync_catalog",
    "renewal_check",
    "churn_scoring",
]

_WORKFLOW_FOLDERS: dict[str, str] = {
    "enrich_leads": "CRM/Enrichment",
    "daily_report": "Reporting",
    "sync_catalog": "E-Commerce",
    "renewal_check": "CRM/Notifications",
    "churn_scoring": "Analytics",
}


def _make_data(
    triggered_by: str,
    nodes: list,
    inputs: dict | None = None,
    outputs: dict | None = None,
    logs: list | None = None,
) -> dict:
    """Build the WorkflowRun.data payload from seed-friendly args."""
    inp = inputs or {}
    return {
        "trigger_context": {"type": triggered_by, "inputs": inp},
        "nodes": nodes,
        "inputs": inp,
        "outputs": outputs or {},
        "logs": logs or [],
    }


def _seeded(n: int) -> float:
    x = math.sin(n + 1) * 10000
    return x - math.floor(x)


_HISTORICAL_DATA: dict[str, dict] = {
    "enrich_leads": {
        "inputs": {"limit": 10},
        "outputs": {"enriched": 10},
        "nodes": [
            {
                "id": 1,
                "name": "Fetch Contacts",
                "status": "success",
                "inputs": {"limit": 10},
                "outputs": {"count": 10},
                "duration_ms": 310,
            },
            {
                "id": 2,
                "name": "Enrich via Clearbit",
                "status": "success",
                "inputs": {"emails": 10},
                "outputs": {"enriched": 10},
                "duration_ms": 11_500,
            },
        ],
    },
    "daily_report": {
        "inputs": {"region": "EU"},
        "outputs": {"total": 48200},
        "nodes": [
            {
                "id": 1,
                "name": "Aggregate Sales Data",
                "status": "success",
                "inputs": {"region": "EU"},
                "outputs": {"total": 48200},
                "duration_ms": 510,
            },
            {
                "id": 2,
                "name": "Generate PDF",
                "status": "success",
                "inputs": {"template": "daily_v2"},
                "outputs": {"path": "/reports/daily.pdf"},
                "duration_ms": 1750,
            },
        ],
    },
    "sync_catalog": {
        "inputs": {},
        "outputs": {"synced": 50},
        "nodes": [
            {
                "id": 1,
                "name": "Fetch from ERP",
                "status": "success",
                "inputs": {},
                "outputs": {"products": 50},
                "duration_ms": 1100,
            },
            {
                "id": 2,
                "name": "Push to Shopify",
                "status": "success",
                "inputs": {"batch_size": 25},
                "outputs": {"synced": 50, "errors": 0},
                "duration_ms": 2400,
            },
        ],
    },
    "renewal_check": {
        "inputs": {"days": 7},
        "outputs": {"sent": 14},
        "nodes": [
            {
                "id": 1,
                "name": "Query Expiring",
                "status": "success",
                "inputs": {"days": 7},
                "outputs": {"count": 14},
                "duration_ms": 360,
            },
            {
                "id": 2,
                "name": "Send Reminders",
                "status": "success",
                "inputs": {},
                "outputs": {"sent": 14},
                "duration_ms": 1850,
            },
        ],
    },
    "churn_scoring": {
        "inputs": {"lookback_days": 30, "threshold": 0.75},
        "outputs": {"high_risk": 38, "rows": 822},
        "nodes": [
            {
                "id": 1,
                "name": "Load Activity",
                "status": "success",
                "inputs": {"lookback_days": 30},
                "outputs": {"users": 822},
                "duration_ms": 1050,
            },
            {
                "id": 2,
                "name": "Run ML Model",
                "status": "success",
                "inputs": {"threshold": 0.75},
                "outputs": {"high_risk": 38},
                "duration_ms": 2700,
            },
            {
                "id": 3,
                "name": "Write Scores",
                "status": "success",
                "inputs": {},
                "outputs": {"rows": 822},
                "duration_ms": 530,
            },
        ],
    },
}


def _make_historical_runs() -> list[dict]:
    """~120 runs spread over the last 30 days — used to populate the activity chart."""
    runs: list[dict] = []
    base = NOW - timedelta(days=4)
    hour_ms = 3_600_000
    t = int(base.timestamp() * 1000)
    end = int((NOW - timedelta(days=2)).timestamp() * 1000)
    slot = 0
    while t <= end:
        d = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
        is_biz = 8 <= d.hour <= 18 and d.weekday() < 5
        count = int(_seeded(slot) * (12 if is_biz else 3))
        for i in range(count):
            failed = _seeded(slot * 100 + i + 77) < 0.13
            started = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
            finished = started + timedelta(seconds=int(_seeded(slot + i) * 120) + 5)
            wf = _WORKFLOW_NAMES[int(_seeded(slot + i + 3) * len(_WORKFLOW_NAMES))]
            stub = _HISTORICAL_DATA[wf]
            nodes = [
                {
                    **n,
                    "status": (
                        "failed"
                        if (failed and j == len(stub["nodes"]) - 1)
                        else "success"
                    ),
                }
                for j, n in enumerate(stub["nodes"])
            ]
            runs.append(
                {
                    "name": wf,
                    "status": "failed" if failed else "success",
                    "triggered_by": "schedule",
                    "started_at": started,
                    "finished_at": finished,
                    "created_at": started,
                    "data": _make_data(
                        "schedule",
                        nodes,
                        inputs=stub["inputs"],
                        outputs={} if failed else stub["outputs"],
                    ),
                }
            )
        t += hour_ms
        slot += 1
    return runs


_DETAILED_RUNS = [
    {
        "name": "enrich_leads",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=2),
        "finished_at": NOW - timedelta(hours=2) + timedelta(seconds=38),
        "created_at": NOW - timedelta(hours=2),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Fetch Contacts",
                    "status": "success",
                    "inputs": {"limit": 10},
                    "outputs": {"count": 10},
                    "duration_ms": 320,
                },
                {
                    "id": 2,
                    "name": "Enrich via Clearbit",
                    "status": "success",
                    "inputs": {"emails": 10},
                    "outputs": {"enriched": 10},
                    "duration_ms": 12_000,
                },
            ],
            inputs={"limit": 10},
            outputs={"enriched": 10},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=2)).isoformat(),
                    "body": "Starting lead enrichment — limit=10",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=2, seconds=-8)).isoformat(),
                    "body": "All 10 contacts enriched successfully",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "daily_report",
        "status": "failed",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=5),
        "finished_at": NOW - timedelta(hours=5) + timedelta(seconds=72),
        "created_at": NOW - timedelta(hours=5),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Aggregate Sales Data",
                    "status": "success",
                    "inputs": {"region": "EU"},
                    "outputs": {"total": 48200},
                    "duration_ms": 520,
                },
                {
                    "id": 2,
                    "name": "Generate PDF",
                    "status": "failed",
                    "inputs": {"template": "daily_v2"},
                    "outputs": {"error": "missing field `growth_rate`"},
                    "duration_ms": 92,
                    "logs": [
                        {
                            "timestamp": (
                                NOW - timedelta(hours=5, seconds=72)
                            ).isoformat(),
                            "body": "Variable 'growth_rate' not found",
                            "type": "warning",
                            "json": False,
                        },
                        {
                            "timestamp": (
                                NOW - timedelta(hours=5, seconds=71)
                            ).isoformat(),
                            "body": "TemplateRenderError: failed to render template daily_v2",
                            "type": "error",
                            "json": False,
                        },
                    ],
                },
            ],
            inputs={"region": "EU"},
            outputs={},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=5)).isoformat(),
                    "body": "Daily report started for region=EU",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=5, seconds=-5)).isoformat(),
                    "body": "PDF generation failed — aborting",
                    "type": "error",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "sync_catalog",
        "status": "success",
        "triggered_by": "webhook",
        "started_at": NOW - timedelta(hours=14),
        "finished_at": NOW - timedelta(hours=14) + timedelta(minutes=4),
        "created_at": NOW - timedelta(hours=14),
        "data": _make_data(
            "webhook",
            [
                {
                    "id": 1,
                    "name": "Fetch from ERP",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"products": 50},
                    "duration_ms": 1230,
                },
                {
                    "id": 2,
                    "name": "Push to Shopify",
                    "status": "success",
                    "inputs": {"batch_size": 25},
                    "outputs": {"synced": 50, "errors": 0},
                    "duration_ms": 2520,
                },
            ],
            outputs={"synced": 50},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=14)).isoformat(),
                    "body": "Fetching products from ERP",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=14, seconds=-2)).isoformat(),
                    "body": "Pushing 50 products to Shopify",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "renewal_check",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=26),
        "finished_at": NOW - timedelta(hours=26) + timedelta(minutes=2),
        "created_at": NOW - timedelta(hours=26),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Query Expiring",
                    "status": "success",
                    "inputs": {"days": 7},
                    "outputs": {"count": 14},
                    "duration_ms": 380,
                },
                {
                    "id": 2,
                    "name": "Send Reminders",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"sent": 14},
                    "duration_ms": 1920,
                },
            ],
            inputs={"days": 7},
            outputs={"sent": 14},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=26)).isoformat(),
                    "body": "Querying contracts expiring in 7 days",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=26, seconds=-1)).isoformat(),
                    "body": "Sending reminders to 14 accounts",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "churn_scoring",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=30),
        "finished_at": NOW - timedelta(hours=30) + timedelta(minutes=5),
        "created_at": NOW - timedelta(hours=30),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Load Activity",
                    "status": "success",
                    "inputs": {"lookback_days": 30},
                    "outputs": {"users": 822},
                    "duration_ms": 1100,
                },
                {
                    "id": 2,
                    "name": "Run ML Model",
                    "status": "success",
                    "inputs": {"threshold": 0.75},
                    "outputs": {"high_risk": 38},
                    "duration_ms": 2840,
                },
                {
                    "id": 3,
                    "name": "Write Scores",
                    "status": "success",
                    "inputs": {},
                    "outputs": {
                        "summary": "# Churn Scores Written\n\n**822 users** updated in the database.\n\n- High-risk flagged: **38**\n- Score threshold: 0.75\n\n> Next run scheduled in 24 h."
                    },
                    "duration_ms": 560,
                },
            ],
            inputs={"lookback_days": 30, "threshold": 0.75},
            outputs={
                "report": "## Churn Analysis — April 2026\n\n**822 users** scored, **38 at high risk** (threshold: 0.75).\n\n### Risk Distribution\n\n| Level | Count |\n|-------|-------|\n| High | 38 |\n| Medium | 194 |\n| Low | 590 |\n\n> Recommend immediate outreach to high-risk accounts."
            },
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=30)).isoformat(),
                    "body": "Scored 822 users — 38 high-risk",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
]

# Child runs — seeded after _DETAILED_RUNS so parent IDs are available.
# "parent_started_at" identifies the parent run from _DETAILED_RUNS.
_CHILD_RUNS = [
    # enrich_leads completes → immediately kicks off a catalog sync
    {
        "parent_started_at": NOW - timedelta(hours=2),
        "name": "sync_catalog",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "finished_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=12),
        "created_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Fetch from ERP",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"products": 53},
                    "duration_ms": 980,
                },
                {
                    "id": 2,
                    "name": "Push to Shopify",
                    "status": "success",
                    "inputs": {"batch_size": 25},
                    "outputs": {"synced": 53, "errors": 0},
                    "duration_ms": 2180,
                },
            ],
            outputs={"synced": 53},
        ),
    },
    # daily_report fails → operator manually reruns it
    {
        "parent_started_at": NOW - timedelta(hours=5),
        "name": "daily_report",
        "status": "success",
        "triggered_by": "manual",
        "started_at": NOW - timedelta(hours=4, minutes=30),
        "finished_at": NOW - timedelta(hours=4, minutes=30) + timedelta(seconds=58),
        "created_at": NOW - timedelta(hours=4, minutes=30),
        "data": _make_data(
            "manual",
            [
                {
                    "id": 1,
                    "name": "Aggregate Sales Data",
                    "status": "success",
                    "inputs": {"region": "EU"},
                    "outputs": {"total": 48200},
                    "duration_ms": 495,
                },
                {
                    "id": 2,
                    "name": "Generate Report",
                    "status": "success",
                    "inputs": {"template": "daily_v2"},
                    "outputs": {
                        "report": "# Daily Report — April 7, 2026\n\n**Region:** EU\n\n**Total Sales:** €48,200\n\n### Highlights\n\n- Revenue up **12%** vs prior week\n- Top product: _Enterprise Plan_\n- 14 contracts renewed\n\n> Generated at 03:30 UTC"
                    },
                    "duration_ms": 1760,
                },
            ],
            inputs={"region": "EU"},
            outputs={
                "report": "# Daily Report — April 7, 2026\n\n**Region:** EU\n\n**Total Sales:** €48,200\n\n### Highlights\n\n- Revenue up **12%** vs prior week\n- Top product: _Enterprise Plan_\n- 14 contracts renewed\n\n> Generated at 03:30 UTC"
            },
        ),
    },
]

# Grandchild runs — seeded after _CHILD_RUNS so child IDs are available.
# "parent_started_at" identifies the parent run from _CHILD_RUNS.
_GRANDCHILD_RUNS = [
    # sync_catalog finishes → churn scores refreshed with updated product data
    {
        "parent_started_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "name": "churn_scoring",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=15),
        "finished_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=7, seconds=42),
        "created_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=15),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Load Activity",
                    "status": "success",
                    "inputs": {"lookback_days": 30},
                    "outputs": {"users": 845},
                    "duration_ms": 870,
                },
                {
                    "id": 2,
                    "name": "Run ML Model",
                    "status": "success",
                    "inputs": {"threshold": 0.75},
                    "outputs": {"high_risk": 41},
                    "duration_ms": 2590,
                },
                {
                    "id": 3,
                    "name": "Write Scores",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"rows": 845},
                    "duration_ms": 390,
                },
            ],
            inputs={"lookback_days": 30, "threshold": 0.75},
            outputs={"high_risk": 41, "rows": 845},
        ),
    },
    # daily_report rerun succeeds → renewal reminders go out
    {
        "parent_started_at": NOW - timedelta(hours=4, minutes=30),
        "name": "renewal_check",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW - timedelta(hours=4, minutes=30) + timedelta(minutes=1),
        "finished_at": NOW
        - timedelta(hours=4, minutes=30)
        + timedelta(minutes=3, seconds=10),
        "created_at": NOW - timedelta(hours=4, minutes=30) + timedelta(minutes=1),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Query Expiring",
                    "status": "success",
                    "inputs": {"days": 7},
                    "outputs": {"count": 14},
                    "duration_ms": 340,
                },
                {
                    "id": 2,
                    "name": "Send Reminders",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"sent": 14},
                    "duration_ms": 1780,
                },
            ],
            inputs={"days": 7},
            outputs={"sent": 14},
        ),
    },
]

_CONFIGS = [
    {
        "key": "app.name",
        "value": "ANKOR",
        "type": "string",
        "folder": "System",
        "description": "Application display name",
    },
    {
        "key": "max.retries",
        "value": "3",
        "type": "number",
        "folder": "System",
        "description": "Maximum retry attempts for failed workflows",
    },
    {
        "key": "maintenance.date",
        "value": "2026-05-01",
        "type": "date",
        "folder": "Infrastructure",
        "description": "Next scheduled maintenance window",
    },
    {
        "key": "digest.send.time",
        "value": "08:00",
        "type": "time",
        "folder": "Notifications",
        "description": "Daily digest delivery time",
    },
    {
        "key": "default.region",
        "value": "EU",
        "type": "select",
        "select_options": ["EU", "US", "APAC"],
        "folder": "Infrastructure",
        "description": "Default region for data processing",
    },
    {
        "key": "feature.flags",
        "value": json.dumps(
            {"darkMode": True, "betaWorkflows": False, "analyticsV2": True}, indent=2
        ),
        "type": "json",
        "folder": "System",
        "description": "Feature toggle flags",
    },
]

_CUSTOMER_FIRST_NAMES = [
    "Alice",
    "Bob",
    "Clara",
    "David",
    "Emma",
    "Felix",
    "Grace",
    "Henry",
    "Isabelle",
    "Jack",
    "Kate",
    "Liam",
    "Maria",
    "Noah",
    "Olivia",
    "Paul",
    "Quinn",
    "Rachel",
    "Samuel",
    "Tara",
    "Uma",
    "Victor",
    "Wendy",
    "Xander",
    "Yara",
    "Zoe",
    "Adrian",
    "Beatrice",
    "Carlos",
    "Diana",
]

_CUSTOMER_LAST_NAMES = [
    "Martin",
    "Strauss",
    "Ng",
    "Johnson",
    "Williams",
    "Brown",
    "Jones",
    "Garcia",
    "Miller",
    "Davis",
    "Wilson",
    "Taylor",
    "Anderson",
    "Thomas",
    "Jackson",
    "White",
    "Harris",
    "Sanchez",
    "Clark",
    "Lewis",
    "Robinson",
    "Walker",
    "Young",
    "Allen",
    "King",
    "Wright",
    "Scott",
    "Torres",
    "Hill",
    "Reed",
]

_CUSTOMER_EMAIL_DOMAINS = [
    "example.com",
    "techcorp.de",
    "startup.io",
    "acme.co",
    "globalinc.net",
    "devstudio.org",
    "cloudbase.io",
    "enterprise.com",
    "scale.ai",
    "b2b.co",
]

_PLANS = ["free", "pro", "enterprise"]
_PLAN_MRR = {"free": 0, "pro": 149, "enterprise": 599}


def _make_customer_rows(n: int = 250) -> list[dict]:
    rows = []
    for i in range(n):
        first = _CUSTOMER_FIRST_NAMES[
            int(_seeded(i * 7 + 1) * len(_CUSTOMER_FIRST_NAMES))
        ]
        last = _CUSTOMER_LAST_NAMES[int(_seeded(i * 7 + 2) * len(_CUSTOMER_LAST_NAMES))]
        plan = _PLANS[int(_seeded(i * 7 + 3) * len(_PLANS))]
        active = _seeded(i * 7 + 4) > 0.2
        domain = _CUSTOMER_EMAIL_DOMAINS[
            int(_seeded(i * 7 + 5) * len(_CUSTOMER_EMAIL_DOMAINS))
        ]
        email = f"{first.lower()}.{last.lower()}{i + 1}@{domain}"
        rows.append(
            {
                "id": i + 1,
                "name": f"{first} {last}",
                "email": email,
                "plan": plan,
                "mrr": _PLAN_MRR[plan],
                "active": active,
            }
        )
    return rows


_TABLES = [
    {
        "name": "Customers",
        "description": "All registered customers",
        "columns": [
            {"id": "name", "name": "name", "type": "text"},
            {"id": "email", "name": "email", "type": "text"},
            {
                "id": "plan",
                "name": "plan",
                "type": "select",
                "selectOptions": ["free", "pro", "enterprise"],
            },
            {"id": "mrr", "name": "mrr", "type": "integer"},
            {"id": "active", "name": "active", "type": "boolean"},
        ],
        "rows": _make_customer_rows(),
    },
]


async def seed_demo_data() -> None:
    """Clear all demo tables and re-insert fresh seed data.

    Always runs a full replace so the DB state is predictable after every call.
    """
    from sqlalchemy import text
    from sqlmodel import select

    from .database import get_session
    from .db_store import _pg_table, _PG_TYPE_MAP, _qi, _upsert_row
    from .models import ConfigRecord, DataTable, TriggerType, Workflow, WorkflowRun

    async for session in get_session():
        # Clear in dependency order (workflow_runs self-references via parent_id)
        await session.execute(text("DELETE FROM workflow_runs"))
        await session.execute(text("DELETE FROM workflows"))
        await session.execute(text("DELETE FROM config_records"))
        existing_ids = [
            r[0]
            for r in (
                await session.execute(text("SELECT id FROM data_tables"))
            ).fetchall()
        ]
        for tbl_id in existing_ids:
            await session.execute(text(f"DROP TABLE IF EXISTS data_table_{tbl_id}"))
        await session.execute(text("DELETE FROM data_table_column_meta"))
        await session.execute(text("TRUNCATE data_tables RESTART IDENTITY CASCADE"))
        await session.execute(text("DELETE FROM users"))

        # Seed Workflow rows and build name→id map for run association.
        for wf_name in _WORKFLOW_NAMES:
            session.add(Workflow(name=wf_name, folder=_WORKFLOW_FOLDERS.get(wf_name)))
        await session.commit()
        wf_id_map: dict[str, int] = {
            wf.name: wf.id for wf in (await session.exec(select(Workflow))).all()
        }

        historical = _make_historical_runs()
        for row in historical:
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "schedule")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            session.add(WorkflowRun(**row))

        # Keep references to detailed run objects so we can read their IDs after commit.
        detailed_objs: dict[datetime, WorkflowRun] = {}
        for row in list(
            _DETAILED_RUNS
        ):  # iterate a copy so we don't mutate the module-level list
            row = dict(row)
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "schedule")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            obj = WorkflowRun(**row)
            session.add(obj)
            detailed_objs[obj.started_at] = obj
        await session.commit()
        for obj in detailed_objs.values():
            await session.refresh(obj)

        # Children — linked to detailed runs via parent_id.
        child_objs: dict[datetime, WorkflowRun] = {}
        for row in list(_CHILD_RUNS):
            row = dict(row)
            parent_started = row.pop("parent_started_at")
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "rerun")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            row["parent_id"] = detailed_objs[parent_started].id
            obj = WorkflowRun(**row)
            session.add(obj)
            child_objs[obj.started_at] = obj
        await session.commit()
        for obj in child_objs.values():
            await session.refresh(obj)

        # Grandchildren — linked to child runs via parent_id.
        for row in list(_GRANDCHILD_RUNS):
            row = dict(row)
            parent_started = row.pop("parent_started_at")
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "rerun")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            row["parent_id"] = child_objs[parent_started].id
            session.add(WorkflowRun(**row))

        total = (
            len(historical)
            + len(_DETAILED_RUNS)
            + len(_CHILD_RUNS)
            + len(_GRANDCHILD_RUNS)
        )
        print(
            f"ankor: seeded {total} demo workflow runs ({len(_CHILD_RUNS)} children, {len(_GRANDCHILD_RUNS)} grandchildren)"
        )

        for cfg in _CONFIGS:
            session.add(ConfigRecord(**cfg))
        print(f"ankor: seeded {len(_CONFIGS)} config records")

        for tbl_data in _TABLES:
            t = DataTable(
                name=tbl_data["name"],
                description=tbl_data.get("description"),
            )
            session.add(t)
            await session.flush()
            tbl = _pg_table(t.id)
            col_defs = [
                "id INTEGER NOT NULL",
                "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                "history JSONB NOT NULL DEFAULT '[]'",
            ] + [
                f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
                for col in tbl_data["columns"]
            ]
            await session.execute(
                text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))")
            )
            for col in tbl_data["columns"]:
                if col.get("type") == "select" and col.get("selectOptions"):
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                            "VALUES (:tid, :cn, CAST(:opts AS json))"
                        ),
                        {
                            "tid": t.id,
                            "cn": col["id"],
                            "opts": json.dumps(col["selectOptions"]),
                        },
                    )
            col_ids = [c["id"] for c in tbl_data["columns"]]
            for row in tbl_data.get("rows", []):
                await _upsert_row(session, tbl, row, col_ids)
        print(f"ankor: seeded {len(_TABLES)} demo db tables")

        await session.commit()
        print("ankor: seed complete.")
        break  # get_session is a generator; one iteration is all we need
