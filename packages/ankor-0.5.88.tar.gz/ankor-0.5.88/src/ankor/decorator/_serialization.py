from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import RunNode, WorkflowRun


def _json_safe(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


def _serialize_action(n: dict) -> dict:
    """Serialise an in-memory action dict for WS broadcasts during live execution."""
    return {
        "id": n.get("id"),
        "name": n.get("name"),
        "slug": n.get("slug"),
        "type": n.get("type", "node"),
        "status": n.get("status"),
        "inputs": n.get("inputs", {}),
        "outputs": n.get("outputs", {}),
        "durationMs": n.get("duration_ms", 0),
        "startedAt": n.get("started_at"),
        "logs": n.get("logs"),
        "childRunId": n.get("child_run_id"),
        "children": [_serialize_action(c) for c in n.get("children", [])],
    }


def _serialize_db_node(
    node: "RunNode", all_nodes: list["RunNode"], depth: int = 0
) -> dict:
    """Serialise a persisted RunNode (with DB id) for WS broadcasts after completion."""
    d = node.data or {}
    children: list[dict] = []
    if depth < 5:
        children = [
            _serialize_db_node(c, all_nodes, depth + 1)
            for c in all_nodes
            if c.parent_node_id == node.id
        ]
    st = node.status
    return {
        "id": node.id,  # DB primary key — canonical identifier
        "name": node.name,
        "slug": node.slug,
        "status": st.value if hasattr(st, "value") else st,
        "inputs": d.get("inputs") or {},
        "outputs": d.get("outputs") or {},
        "durationMs": node.duration_ms or 0,
        "startedAt": node.started_at.isoformat() if node.started_at else None,
        "logs": d.get("logs"),
        "childRunId": node.child_run_id,
        "children": children,
    }


def _run_summary(run: "WorkflowRun", workflow_name: str) -> dict:
    d = run.data or {}
    return {
        "id": run.id,
        "name": workflow_name,
        "status": run.status.value,
        "triggeredBy": (
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        "triggerContext": d.get("trigger_context", {}),
        "inputs": d.get("inputs", {}),
        "outputs": d.get("outputs", {}),
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "parentId": run.parent_id,
        "children": [],
    }


def _run_detail(
    run: "WorkflowRun", workflow_name: str, actions: list | None = None
) -> dict:
    d = run.data or {}
    raw = actions if actions is not None else (d.get("actions") or d.get("nodes", []))
    return {
        **_run_summary(run, workflow_name),
        "actions": [_serialize_action(n) for n in raw],
    }
