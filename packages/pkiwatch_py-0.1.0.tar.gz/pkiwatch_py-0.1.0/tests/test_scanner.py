import pytest

from pkiwatch.scanner import parse_target, scan_tls_certificate


def test_parse_target_default_port():
    assert parse_target("example.com") == ("example.com", 443)


def test_parse_target_custom_port():
    assert parse_target("example.com:8443") == ("example.com", 8443)


def test_empty_host_rejected():
    with pytest.raises(ValueError):
        scan_tls_certificate("")
