from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from .scanner import CertificateScanError, scan_many, scan_tls_certificate

app = typer.Typer(help="PKI/TLS certificate monitoring CLI")
console = Console()


def _print_report(report, output: str) -> None:
    data = report.model_dump(mode="json")
    if output == "json":
        console.print(json.dumps(data, indent=2))
        return
    table = Table(title=f"Certificate Report: {report.host}:{report.port}")
    table.add_column("Field")
    table.add_column("Value")
    for key, value in data.items():
        table.add_row(key, json.dumps(value) if isinstance(value, list) else str(value))
    console.print(table)


@app.command()
def scan(
    host: str = typer.Argument(..., help="Hostname, for example example.com"),
    port: int = typer.Option(443, "--port", "-p"),
    timeout: float = typer.Option(5.0, "--timeout"),
    warning_days: int = typer.Option(30, "--warning-days", "-w"),
    output: str = typer.Option("table", "--output", "-o", help="table or json"),
):
    """Scan one TLS endpoint."""
    try:
        report = scan_tls_certificate(host, port, timeout, warning_days)
    except CertificateScanError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    _print_report(report, output)


@app.command()
def batch(
    targets_file: Path = typer.Argument(..., help="File with one host or host:port per line"),
    default_port: int = typer.Option(443, "--default-port"),
    timeout: float = typer.Option(5.0, "--timeout"),
    warning_days: int = typer.Option(30, "--warning-days", "-w"),
    output_file: Optional[Path] = typer.Option(None, "--output-file", "-f"),
):
    """Scan many TLS endpoints and emit JSON."""
    targets = [line.strip() for line in targets_file.read_text().splitlines() if line.strip()]
    batch_report = scan_many(targets, default_port, timeout, warning_days)
    payload = batch_report.model_dump_json(indent=2)
    if output_file:
        output_file.write_text(payload)
        console.print(f"[green]Saved report to {output_file}[/green]")
    else:
        console.print(payload)
