from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class CertificateReport(BaseModel):
    host: str
    port: int = 443
    subject: str
    issuer: str
    serial_number: str
    not_before: datetime
    not_after: datetime
    days_remaining: int
    expired: bool
    warning: bool
    dns_names: List[str] = Field(default_factory=list)
    signature_hash_algorithm: Optional[str] = None
    tls_version: Optional[str] = None
    cipher: Optional[str] = None


class BatchReport(BaseModel):
    generated_at: datetime
    reports: List[CertificateReport]
    failures: List[str] = Field(default_factory=list)
