from __future__ import annotations

import socket
import ssl
from datetime import datetime, timezone
from typing import Iterable, List, Tuple

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.x509.oid import ExtensionOID

from .models import BatchReport, CertificateReport


class CertificateScanError(RuntimeError):
    """Raised when a certificate cannot be retrieved or parsed."""


def _dns_names(cert: x509.Certificate) -> List[str]:
    try:
        san = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value
        return list(san.get_values_for_type(x509.DNSName))
    except x509.ExtensionNotFound:
        return []


def scan_tls_certificate(
    host: str,
    port: int = 443,
    timeout: float = 5.0,
    warning_days: int = 30,
) -> CertificateReport:
    """Scan a TLS endpoint and return certificate metadata."""
    if not host or not host.strip():
        raise ValueError("host is required")
    if port <= 0 or port > 65535:
        raise ValueError("port must be between 1 and 65535")

    context = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with context.wrap_socket(sock, server_hostname=host) as tls_sock:
                der_cert = tls_sock.getpeercert(binary_form=True)
                tls_version = tls_sock.version()
                cipher = tls_sock.cipher()[0] if tls_sock.cipher() else None
    except Exception as exc:  # network/TLS errors vary by platform
        raise CertificateScanError(f"Failed to scan {host}:{port}: {exc}") from exc

    if not der_cert:
        raise CertificateScanError(f"No certificate returned by {host}:{port}")

    cert = x509.load_der_x509_certificate(der_cert, default_backend())
    now = datetime.now(timezone.utc)
    not_before = cert.not_valid_before_utc
    not_after = cert.not_valid_after_utc
    days_remaining = (not_after - now).days

    return CertificateReport(
        host=host,
        port=port,
        subject=cert.subject.rfc4514_string(),
        issuer=cert.issuer.rfc4514_string(),
        serial_number=hex(cert.serial_number),
        not_before=not_before,
        not_after=not_after,
        days_remaining=days_remaining,
        expired=days_remaining < 0,
        warning=days_remaining <= warning_days,
        dns_names=_dns_names(cert),
        signature_hash_algorithm=(
            cert.signature_hash_algorithm.name if cert.signature_hash_algorithm else None
        ),
        tls_version=tls_version,
        cipher=cipher,
    )


def parse_target(value: str, default_port: int = 443) -> Tuple[str, int]:
    value = value.strip()
    if not value:
        raise ValueError("empty target")
    if ":" in value:
        host, port_s = value.rsplit(":", 1)
        return host.strip(), int(port_s)
    return value, default_port


def scan_many(
    targets: Iterable[str],
    default_port: int = 443,
    timeout: float = 5.0,
    warning_days: int = 30,
) -> BatchReport:
    reports: List[CertificateReport] = []
    failures: List[str] = []
    for raw in targets:
        try:
            host, port = parse_target(raw, default_port=default_port)
            reports.append(scan_tls_certificate(host, port, timeout, warning_days))
        except Exception as exc:
            failures.append(f"{raw}: {exc}")
    return BatchReport(generated_at=datetime.now(timezone.utc), reports=reports, failures=failures)
