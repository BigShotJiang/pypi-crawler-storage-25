# pkiwatch-py

`pkiwatch-py` is a production-ready Python library and CLI for TLS/PKI certificate expiry monitoring, certificate inventory, and basic compliance reporting for enterprise endpoints.

## Install

```bash
pip install pkiwatch-py
```

## CLI

```bash
pkiwatch scan google.com
pkiwatch scan google.com --output json
printf "google.com\nexample.com:443\n" > targets.txt
pkiwatch batch targets.txt --output-file cert-report.json
```

## Python API

```python
from pkiwatch import scan_tls_certificate

report = scan_tls_certificate("google.com", warning_days=45)
print(report.days_remaining, report.issuer)
```

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
ruff check src tests
python -m build
python -m twine check dist/*
```

## Publish

Create a PyPI API token, then:

```bash
python -m twine upload dist/*
```

Use `__token__` as username and the token as password.

## License

MIT

Author: Raghava Chellu

MIT License is freely usable for academic, personal, and commercial projects.
