from setuptools import find_packages, setup

setup(
    name="proxy-platform",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "typer[all]>=0.12.0",
        "rich>=13.7.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "python-jose>=3.3.0",
    ],
    entry_points={
        "console_scripts": [
            "pbd=proxy_platform.main:app",
        ],
    },
    author="PBD Team",
    description="CLI client for PBD Admin and User APIs",
    python_requires=">=3.11",
)
