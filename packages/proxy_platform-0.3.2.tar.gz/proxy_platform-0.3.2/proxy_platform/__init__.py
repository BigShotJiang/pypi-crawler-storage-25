"""PBD CLI - Command line client for PBD APIs."""

__version__ = "0.2.0"
