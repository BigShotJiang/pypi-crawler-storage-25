"""HTTP client for PBD APIs."""

import base64
import json
import logging
from datetime import datetime, timedelta
from typing import Any

import requests
from rich.console import Console

from .config import (
    get_api_urls,
    get_default_api_type,
    get_refresh_token,
    get_token,
    save_tokens,
)

console = Console()
logger = logging.getLogger(__name__)


class APIClient:
    """HTTP client for making authenticated requests to PBD APIs."""

    def __init__(self, api_type: str | None = None):
        """Initialize the API client.

        Args:
            api_type: Either 'admin' or 'user'. If None, uses default from config.
        """
        self.api_type = api_type or get_default_api_type()
        urls = get_api_urls()
        self.base_url = urls[f"{self.api_type}_api"]
        self._token_refreshed = False  # Prevent infinite refresh loops

    def _is_token_expired(self, token: str) -> bool:
        """Check if a JWT token is expired or close to expiring."""
        try:
            payload = token.split(".")[1]
            # Add padding if needed
            payload += "=" * (-len(payload) % 4)
            decoded = json.loads(base64.urlsafe_b64decode(payload))

            exp = decoded.get("exp")
            if not exp:
                return False

            return datetime.fromtimestamp(exp) < (datetime.now() + timedelta(minutes=1))

        except Exception:
            return False

    def _refresh_access_token(self) -> bool:
        """Try to refresh the access token using refresh token.

        Returns:
            True if refresh successful, False otherwise
        """
        if self._token_refreshed:
            # Already tried to refresh in this request, prevent loop
            return False

        refresh_token = get_refresh_token(self.api_type)
        if not refresh_token:
            return False

        try:
            # Call refresh endpoint
            response = requests.post(
                f"{self.base_url}/api/v1/auth/refresh",
                headers={
                    "Authorization": f"Bearer {refresh_token}",
                    "Content-Type": "application/json",
                },
                timeout=10,
            )

            if response.status_code == 200:
                data = response.json()

                # Handle both dict response and string response
                if isinstance(data, dict):
                    new_access_token = data.get("access_token")
                    new_refresh_token = data.get("refresh_token")
                elif isinstance(data, str):
                    # API returned a plain token string
                    new_access_token = data
                    new_refresh_token = None
                else:
                    console.print(f"[dim]Unexpected refresh response type: {type(data)}[/dim]")
                    return False

                if new_access_token:
                    # Save new tokens
                    if self.api_type == "admin":
                        save_tokens(
                            admin_token=new_access_token,
                            admin_refresh=new_refresh_token,
                        )
                    else:
                        save_tokens(
                            user_token=new_access_token,
                            user_refresh=new_refresh_token,
                        )

                    self._token_refreshed = True
                    console.print("[dim]✓ Token refreshed[/dim]")
                    return True

            return False

        except Exception as e:
            console.print(f"[dim]Token refresh failed: {str(e)}[/dim]")
            return False

    def _get_headers(self) -> dict[str, str]:
        """Get headers including authentication token."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        token = get_token(self.api_type)
        if token:
            headers["Authorization"] = f"Bearer {token}"

        return headers

    def request(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        require_auth: bool = True,
        extra_headers: dict[str, str] | None = None,
    ) -> requests.Response:
        """Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            endpoint: API endpoint (e.g., '/api/v1/users/profile')
            data: JSON data to send in the request body
            params: Query parameters
            require_auth: Whether this endpoint requires authentication

        Returns:
            requests.Response object

        Raises:
            Exception if authentication is required but no token is found
        """
        if require_auth:
            token = get_token(self.api_type)
            if not token:
                raise Exception(f"Not authenticated. Please run 'pbd login --api {self.api_type}' first.")

            # Check if token is expired and try to refresh
            if self._is_token_expired(token):
                if not self._refresh_access_token():
                    raise Exception(f"Token expired. Please run 'pbd login --api {self.api_type}' to re-authenticate.")

        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers()
        if extra_headers:
            headers.update(extra_headers)

        # Log the request details in verbose mode
        logger.debug(f"→ {method} {url}")
        if params:
            logger.debug(f"  Query params: {params}")
        if data:
            logger.debug(f"  Request body: {data}")

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=data,
                params=params,
                timeout=30,
            )

            # Log the response in verbose mode
            logger.debug(f"← {response.status_code} {response.reason}")
            if response.status_code >= 400:
                logger.debug(f"  Error response: {response.text[:200]}")

            return response
        except requests.exceptions.ConnectionError:
            logger.error(f"Connection failed to {self.base_url}")
            console.print(f"[red]Error: Could not connect to {self.base_url}[/red]")
            console.print("[yellow]Make sure the API server is running.[/yellow]")
            raise
        except requests.exceptions.Timeout:
            console.print("[red]Error: Request timed out[/red]")
            raise

    def get(self, endpoint: str, params: dict[str, Any] | None = None, require_auth: bool = True) -> requests.Response:
        """Make a GET request."""
        return self.request("GET", endpoint, params=params, require_auth=require_auth)

    def post(self, endpoint: str, data: dict[str, Any] | None = None, require_auth: bool = True) -> requests.Response:
        """Make a POST request."""
        return self.request("POST", endpoint, data=data, require_auth=require_auth)

    def put(self, endpoint: str, data: dict[str, Any] | None = None, require_auth: bool = True) -> requests.Response:
        """Make a PUT request."""
        return self.request("PUT", endpoint, data=data, require_auth=require_auth)

    def patch(self, endpoint: str, data: dict[str, Any] | None = None, require_auth: bool = True) -> requests.Response:
        """Make a PATCH request."""
        return self.request("PATCH", endpoint, data=data, require_auth=require_auth)

    def delete(self, endpoint: str, require_auth: bool = True) -> requests.Response:
        """Make a DELETE request."""
        return self.request("DELETE", endpoint, require_auth=require_auth)

    def upload(
        self,
        endpoint: str,
        files: dict[str, tuple[str, Any, str]],
        data: dict[str, Any] | None = None,
        require_auth: bool = True,
    ) -> requests.Response:
        """Upload files to the API.

        Args:
            endpoint: API endpoint
            files: Dict of file field names to (filename, file_object, content_type) tuples
            data: Optional additional form data
            require_auth: Whether authentication is required

        Returns:
            requests.Response object
        """
        if require_auth:
            token = get_token(self.api_type)
            if not token:
                raise Exception(f"Not authenticated. Please run 'pbd login --api {self.api_type}' first.")

            # Check if token is expired and try to refresh
            if self._is_token_expired(token):
                if not self._refresh_access_token():
                    raise Exception(f"Token expired. Please run 'pbd login --api {self.api_type}' to re-authenticate.")

        url = f"{self.base_url}{endpoint}"

        # Get auth headers but don't set Content-Type (requests will set it for multipart)
        headers = {}
        token = get_token(self.api_type)
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            response = requests.post(
                url=url,
                headers=headers,
                files=files,
                data=data,
                timeout=30,
            )

            logger.debug(f"← {response.status_code} {response.reason}")
            if response.status_code >= 400:
                logger.debug(f"  Error response: {response.text[:200]}")

            return response
        except requests.exceptions.ConnectionError:
            logger.error(f"Connection failed to {self.base_url}")
            console.print(f"[red]Error: Could not connect to {self.base_url}[/red]")
            console.print("[yellow]Make sure the API server is running.[/yellow]")
            raise
        except requests.exceptions.Timeout:
            console.print("[red]Error: Request timed out[/red]")
            raise

    def login(self, username: str, password: str, otp_code: str | None = None) -> dict[str, Any]:
        """Authenticate and return tokens.

        Args:
            username: User's email
            password: User's password

        Returns:
            Dict containing access_token and refresh_token

        Raises:
            Exception if login fails
        """
        extra: dict[str, str] | None = {"X-OTP": otp_code} if otp_code else None
        response = self.request(
            "POST",
            "/api/v1/auth/login",
            data={"username": username, "password": password},
            require_auth=False,
            extra_headers=extra,
        )

        if response.status_code == 200:
            data = response.json()

            # Handle both dict response and string response
            if isinstance(data, dict):
                return data  # Return full response with both tokens
            elif isinstance(data, str):
                # API returned a plain token string
                return {"access_token": data, "refresh_token": None}  # nosec B105
            else:
                # Unexpected response type
                return {"access_token": None, "refresh_token": None}  # nosec B105
        else:
            try:
                error_data = response.json()
                if isinstance(error_data, dict):
                    error_detail = error_data.get("detail", "Unknown error")
                else:
                    error_detail = str(error_data)
            except Exception:
                error_detail = response.text if response.text else "Unknown error"
            raise Exception(f"Login failed: {error_detail}")
