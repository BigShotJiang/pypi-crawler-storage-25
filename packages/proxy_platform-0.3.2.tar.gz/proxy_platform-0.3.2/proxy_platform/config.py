"""Configuration and token management for PBD CLI."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".proxy-platform"
TOKEN_FILE = CONFIG_DIR / "tokens.json"
CONFIG_FILE = CONFIG_DIR / "config.json"

ENVIRONMENTS = {
    "development": {
        "admin_api": "http://localhost:8001",
        "user_api": "http://localhost:8002",
    },
    "test": {
        "admin_api": "https://admin-api.tst.pbd.proxy.nl",
        "user_api": "https://api.tst.pbd.proxy.nl",
    },
    "acceptance": {
        "admin_api": "https://admin-api.acc.pbd.proxy.nl",
        "user_api": "https://api.acc.pbd.proxy.nl",
    },
    "production": {
        "admin_api": "https://admin-api.prd.pbd.proxy.nl",
        "user_api": "https://api.platform.proxy.nl",
    },
}


def ensure_config_dir() -> None:
    """Ensure the config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_current_environment() -> str:
    """Get the currently selected environment."""
    ensure_config_dir()
    if not CONFIG_FILE.exists():
        return "development"

    try:
        with open(CONFIG_FILE) as f:
            config: dict[str, Any] = json.load(f)
            result: str = config.get("environment", "development")
            return result
    except (OSError, json.JSONDecodeError):
        return "development"


def set_environment(env: str) -> None:
    """Set the current environment."""
    ensure_config_dir()
    config: dict[str, Any] = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
        except (OSError, json.JSONDecodeError):
            pass

    config["environment"] = env
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_api_urls() -> dict:
    """Get API URLs for the current environment.

    Checks environment variables first (ADMIN_API_URL, USER_API_URL),
    then falls back to configured environment URLs.
    """
    # Check for environment variable overrides (for container environments)
    admin_api_override = os.environ.get("ADMIN_API_URL")
    user_api_override = os.environ.get("USER_API_URL")

    if admin_api_override or user_api_override:
        # If either override is set, use them (fall back to configured URLs if only one is set)
        env = get_current_environment()
        default_urls = ENVIRONMENTS.get(env, ENVIRONMENTS["development"])
        return {
            "admin_api": admin_api_override or default_urls["admin_api"],
            "user_api": user_api_override or default_urls["user_api"],
        }

    # No overrides, use configured environment
    env = get_current_environment()
    return ENVIRONMENTS.get(env, ENVIRONMENTS["development"])


def save_tokens(
    admin_token: str | None = None,
    user_token: str | None = None,
    admin_refresh: str | None = None,
    user_refresh: str | None = None,
) -> None:
    """Save authentication tokens and refresh tokens."""
    ensure_config_dir()

    tokens: dict[str, Any] = {}
    if TOKEN_FILE.exists():
        try:
            with open(TOKEN_FILE) as f:
                tokens = json.load(f)
        except (OSError, json.JSONDecodeError):
            pass

    env = get_current_environment()
    if env not in tokens:
        tokens[env] = {}

    if admin_token:
        tokens[env]["admin_token"] = admin_token
        tokens[env]["admin_token_saved_at"] = datetime.now().isoformat()
        if admin_refresh:
            tokens[env]["admin_refresh_token"] = admin_refresh

    if user_token:
        tokens[env]["user_token"] = user_token
        tokens[env]["user_token_saved_at"] = datetime.now().isoformat()
        if user_refresh:
            tokens[env]["user_refresh_token"] = user_refresh

    with open(TOKEN_FILE, "w") as f:
        json.dump(tokens, f, indent=2)

    # Set restrictive permissions
    os.chmod(TOKEN_FILE, 0o600)


def get_token(api_type: str = "user") -> str | None:
    """Get the stored authentication token for the current environment."""
    ensure_config_dir()

    if not TOKEN_FILE.exists():
        return None

    try:
        with open(TOKEN_FILE) as f:
            tokens = json.load(f)

        env = get_current_environment()
        env_tokens: dict[str, Any] = tokens.get(env, {})

        token_key = f"{api_type}_token"
        result: str | None = env_tokens.get(token_key)
        return result
    except (OSError, json.JSONDecodeError):
        return None


def get_refresh_token(api_type: str = "user") -> str | None:
    """Get the stored refresh token for the current environment."""
    ensure_config_dir()

    if not TOKEN_FILE.exists():
        return None

    try:
        with open(TOKEN_FILE) as f:
            tokens = json.load(f)

        env = get_current_environment()
        env_tokens: dict[str, Any] = tokens.get(env, {})

        token_key = f"{api_type}_refresh_token"
        result: str | None = env_tokens.get(token_key)
        return result
    except (OSError, json.JSONDecodeError):
        return None


def clear_tokens() -> None:
    """Clear all stored tokens for the current environment."""
    ensure_config_dir()

    if not TOKEN_FILE.exists():
        return

    try:
        with open(TOKEN_FILE) as f:
            tokens: dict[str, Any] = json.load(f)

        env = get_current_environment()
        if env in tokens:
            del tokens[env]

        with open(TOKEN_FILE, "w") as f:
            json.dump(tokens, f, indent=2)
    except (OSError, json.JSONDecodeError):
        pass


def get_default_api_type() -> str:
    """Get the default API type (admin or user)."""
    ensure_config_dir()
    if not CONFIG_FILE.exists():
        return "user"

    try:
        with open(CONFIG_FILE) as f:
            config: dict[str, Any] = json.load(f)
            result: str = config.get("default_api", "user")
            return result
    except (OSError, json.JSONDecodeError):
        return "user"


def set_default_api_type(api_type: str) -> None:
    """Set the default API type."""
    ensure_config_dir()
    config: dict[str, Any] = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
        except (OSError, json.JSONDecodeError):
            pass

    config["default_api"] = api_type
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
