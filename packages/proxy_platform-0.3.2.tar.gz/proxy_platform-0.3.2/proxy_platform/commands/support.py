"""Support ticket portal commands for users."""

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()

# Valid support ticket categories and statuses (mirrors pbd-shared enums)
SUPPORT_CATEGORIES = ["general", "billing", "technical", "other"]
SUPPORT_STATUSES = ["open", "in_progress", "closed"]


@app.command(name="submit")
def submit_ticket(
    subject: str = typer.Option(..., "--subject", "-s", help="Ticket subject"),
    description: str = typer.Option(..., "--description", "-d", help="Ticket description"),
    category: str = typer.Option(..., "--category", "-c", help=f"Category: {', '.join(SUPPORT_CATEGORIES)}"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Submit a new support ticket.

    Creates a new support ticket in the portal. The category must be one of:
    general, billing, technical, other.

    Examples:
        pbd support submit --subject "Cannot access cluster" --description "Getting 403 error" --category technical
        pbd support submit --subject "Invoice question" --description "Need clarification on invoice" --category billing
    """
    if api is None:
        api = get_default_api_type()

    if category not in SUPPORT_CATEGORIES:
        console.print(f"[red]Error: Invalid category '{category}'[/red]")
        console.print(f"[yellow]Valid categories: {', '.join(SUPPORT_CATEGORIES)}[/yellow]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)
        data = {
            "subject": subject,
            "description": description,
            "category": category,
        }

        response = client.post("/api/v1/support", data=data)

        if response.status_code == 201:
            result = response.json()
            console.print()
            console.print("[green]Support ticket submitted successfully![/green]")
            console.print()
            console.print("[bold]Ticket Details[/bold]")
            console.print("-" * 70)
            console.print(f"ID:          [cyan]{result.get('id')}[/cyan]")
            console.print(f"Subject:     {result.get('subject')}")
            console.print(f"Category:    [blue]{result.get('category')}[/blue]")
            console.print(f"Status:      [yellow]{result.get('status')}[/yellow]")
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="list")
def list_tickets(
    page: int = typer.Option(1, "--page", "-p", help="Page number (1-based)"),
    category: str | None = typer.Option(
        None, "--category", "-c", help=f"Filter by category: {', '.join(SUPPORT_CATEGORIES)}"
    ),
    status: str | None = typer.Option(None, "--status", "-s", help=f"Filter by status: {', '.join(SUPPORT_STATUSES)}"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List your own support tickets.

    Shows your submitted support tickets. Supports filtering by category and status.

    Examples:
        pbd support list
        pbd support list --category technical
        pbd support list --status open
        pbd support list --page 2
    """
    if api is None:
        api = get_default_api_type()

    if category and category not in SUPPORT_CATEGORIES:
        console.print(f"[red]Error: Invalid category '{category}'[/red]")
        console.print(f"[yellow]Valid categories: {', '.join(SUPPORT_CATEGORIES)}[/yellow]")
        raise typer.Exit(1)

    if status and status not in SUPPORT_STATUSES:
        console.print(f"[red]Error: Invalid status '{status}'[/red]")
        console.print(f"[yellow]Valid statuses: {', '.join(SUPPORT_STATUSES)}[/yellow]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)
        params: dict[str, str | int] = {"page": page}
        if category:
            params["category"] = category
        if status:
            params["status"] = status

        response = client.get("/api/v1/support", params=params)

        if response.status_code == 200:
            data = response.json()
            items = data.get("data", [])

            if not items:
                console.print("[yellow]No support tickets found[/yellow]")
                return

            total = data.get("total", len(items))
            table = Table(title=f"Support Tickets ({len(items)} of {total})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Subject", style="white")
            table.add_column("Category", style="blue")
            table.add_column("Status", style="yellow")
            table.add_column("Date", style="dim")

            for item in items:
                item_id = str(item.get("id", "N/A"))[:8] + "..."
                created = item.get("created_at", "N/A")[:10] if item.get("created_at") else "N/A"

                table.add_row(
                    item_id,
                    item.get("subject", "N/A"),
                    item.get("category", "N/A"),
                    item.get("status", "N/A"),
                    created,
                )

            console.print()
            console.print(table)

            if data.get("has_next"):
                console.print(f"\n[dim]Page {data.get('page')}. Use --page to navigate.[/dim]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_ticket(
    ticket_id: str = typer.Argument(..., help="Ticket ID (UUID)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """View a support ticket with its full message thread.

    Examples:
        pbd support get 550e8400-e29b-41d4-a716-446655440000
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/support/{ticket_id}")

        if response.status_code == 200:
            item = response.json()
            console.print()
            console.print("[bold]Support Ticket Details[/bold]")
            console.print("-" * 70)
            console.print(f"ID:          [cyan]{item.get('id')}[/cyan]")
            console.print(f"Subject:     {item.get('subject')}")
            console.print(f"Description: {item.get('description')}")
            console.print(f"Category:    [blue]{item.get('category')}[/blue]")
            console.print(f"Status:      [yellow]{item.get('status')}[/yellow]")
            if item.get("created_at"):
                console.print(f"Created:     {item.get('created_at')}")

            # Show message thread if present
            messages = item.get("messages", [])
            if messages:
                console.print()
                console.print(f"[bold]Messages ({len(messages)})[/bold]")
                console.print("-" * 70)
                for message in messages:
                    sender = message.get("sender_name", "N/A")
                    created = message.get("created_at", "N/A")[:10] if message.get("created_at") else "N/A"
                    console.print(f"[cyan]{sender}[/cyan] ({created}):")
                    console.print(f"  {message.get('content')}")
                    console.print()
            console.print()
        elif response.status_code == 404:
            console.print(f"[red]Ticket not found: {ticket_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="reply")
def reply_ticket(
    ticket_id: str = typer.Argument(..., help="Ticket ID (UUID)"),
    content: str = typer.Option(..., "--content", "-c", help="Reply content"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Reply to a support ticket.

    Examples:
        pbd support reply <id> --content "Here is the additional information you requested"
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        data = {"content": content}
        response = client.post(f"/api/v1/support/{ticket_id}/messages", data=data)

        if response.status_code == 201:
            result = response.json()
            console.print(f"[green]Reply added to ticket [cyan]{ticket_id}[/cyan][/green]")
            console.print(f"  Message ID: [cyan]{result.get('id')}[/cyan]")
            console.print(f"  Content:    {result.get('content')}")
            console.print()
        elif response.status_code == 404:
            console.print(f"[red]Ticket not found: {ticket_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="close")
def close_ticket(
    ticket_id: str = typer.Argument(..., help="Ticket ID (UUID)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Close your own support ticket.

    This marks the ticket as closed. Only the ticket owner can close their ticket.

    Examples:
        pbd support close <id>
        pbd support close <id> --yes
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        if not yes:
            confirm = typer.confirm(f"Are you sure you want to close ticket {ticket_id}?")
            if not confirm:
                console.print("[yellow]Close cancelled[/yellow]")
                raise typer.Exit(0)

        response = client.delete(f"/api/v1/support/{ticket_id}")

        if response.status_code in [200, 204]:
            console.print(f"[green]Ticket [cyan]{ticket_id}[/cyan] closed successfully[/green]")
        elif response.status_code == 403:
            console.print("[red]Error: You are not allowed to close this ticket[/red]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print(f"[red]Ticket not found: {ticket_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
