"""Order and payment management commands."""

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from ..client import APIClient
from ..config import get_current_environment, get_default_api_type

app = typer.Typer()
console = Console()


@app.command(name="list")
def list_orders(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of orders to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List user orders."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/users/orders?limit={limit}")

        if response.status_code == 200:
            data = response.json()
            # API returns {"orders": [...]} not {"items": [...]}
            orders = data.get("orders", data.get("items", []))

            if not orders:
                console.print("[yellow]No orders found[/yellow]")
                return

            total = data.get("total_count", data.get("total", len(orders)))
            table = Table(title=f"Orders ({len(orders)} of {total})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Description", style="white")
            table.add_column("Amount", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Date", style="blue")

            for order in orders:
                # Handle amount which might be a string
                amount = order.get("amount", order.get("total_amount", 0))
                try:
                    amount_float = float(amount) if amount else 0
                except (ValueError, TypeError):
                    amount_float = 0

                table.add_row(
                    str(order.get("id", "N/A"))[:8] + "...",
                    order.get("description", "N/A"),
                    f"{order.get('currency', 'EUR')} {amount_float:.2f}",
                    order.get("status", "N/A"),
                    order.get("created_at", "N/A")[:10] if order.get("created_at") else "N/A",
                )

            console.print()
            console.print(table)
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_order(
    order_id: str = typer.Argument(..., help="Order ID"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get details about a specific order."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        # Try to get from orders list first
        response = client.get("/api/v1/users/orders?limit=100")

        if response.status_code == 200:
            data = response.json()
            # API returns {"orders": [...]} not {"items": [...]}
            orders = data.get("orders", data.get("items", []))
            order = next(
                (o for o in orders if str(o.get("id")) == order_id or str(o.get("id")).startswith(order_id)), None
            )

            if order:
                # Handle amount which might be a string
                amount = order.get("amount", order.get("total_amount", 0))
                try:
                    amount_float = float(amount) if amount else 0
                except (ValueError, TypeError):
                    amount_float = 0

                console.print()
                console.print("[bold]Order Details[/bold]")
                console.print("─" * 70)
                console.print(f"ID:              [cyan]{order.get('id')}[/cyan]")
                console.print(f"Description:     {order.get('description', 'N/A')}")
                console.print(f"Amount:          [green]{order.get('currency', 'EUR')} {amount_float:.2f}[/green]")
                console.print(f"Status:          [yellow]{order.get('status')}[/yellow]")

                if order.get("created_at"):
                    console.print(f"Created:         {order.get('created_at')}")

                if order.get("paid_at"):
                    console.print(f"Paid:            {order.get('paid_at')}")

                if order.get("product_id"):
                    console.print(f"Product ID:      {order.get('product_id')}")

                console.print()
            else:
                console.print(f"[red]Order not found: {order_id}[/red]")
                raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="create")
def create_order(
    product_id: str | None = typer.Option(None, "--product", "-p", help="Product ID (skip product selection)"),
    tier: str | None = typer.Option(None, "--tier", "-t", help="Pricing tier name or ID (skip tier selection)"),
    provider: str | None = typer.Option(
        None, "--provider", help="Cloud provider, e.g. hetzner (skip provider selection)"
    ),
    region: str | None = typer.Option(None, "--region", "-r", help="Region code, e.g. nbg1 (skip region selection)"),
    firewall_id: str | None = typer.Option(
        None, "--firewall", "-f", help="Firewall ID to attach (skip firewall selection)"
    ),
    no_firewall: bool = typer.Option(False, "--no-firewall", help="Deploy without firewall"),
    auto_pay: bool = typer.Option(True, "--auto-pay", help="Automatically simulate payment in dev mode"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Accept terms without prompting"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Create an order with full deployment configuration.

    Runs interactively when no flags are given. Supply flags to skip individual steps:

    Example:
        pbd orders create
        pbd orders create --product f25bea71 --tier starter --provider hetzner --region nbg1 --no-firewall --yes
    """
    try:
        if api is None:
            api = get_default_api_type()

        client = APIClient(api_type=api)

        # Step 1: Product Selection
        if not product_id:
            products_response = client.get("/api/v1/products?limit=100")
            if products_response.status_code != 200:
                console.print("[red]Failed to fetch products[/red]")
                raise typer.Exit(1)

            products = products_response.json()
            if not products:
                console.print("[yellow]No products available[/yellow]")
                raise typer.Exit(1)

            if len(products) == 1:
                selected_product = products[0]
                product_id = selected_product.get("id")
            else:
                console.print("\n[bold cyan]Step 1: Select a Product[/bold cyan]")
                console.print()

                table = Table(title="Available Products")
                table.add_column("#", style="cyan", no_wrap=True)
                table.add_column("Name", style="green")
                table.add_column("Type", style="blue")
                table.add_column("Description")

                for idx, product in enumerate(products, 1):
                    table.add_row(
                        str(idx),
                        product.get("name", "N/A"),
                        product.get("product_type", "N/A"),
                        (product.get("description", "")[:50] + "...")
                        if len(product.get("description", "")) > 50
                        else product.get("description", "N/A"),
                    )

                console.print(table)
                console.print()

                choice = Prompt.ask("Select product number", default="1")
                try:
                    selected_product = products[int(choice) - 1]
                    product_id = selected_product.get("id")
                except (ValueError, IndexError):
                    console.print("[red]Invalid selection[/red]")
                    raise typer.Exit(1) from None
        else:
            # Fetch specific product
            if len(product_id) < 36:
                # Resolve partial ID
                products_response = client.get("/api/v1/products?limit=100")
                products = products_response.json()
                matching = [p for p in products if str(p.get("id", "")).startswith(product_id)]
                if len(matching) == 1:
                    product_id = matching[0].get("id")
                    selected_product = matching[0]
                else:
                    console.print("[red]Could not resolve product ID[/red]")
                    raise typer.Exit(1)
            else:
                product_response = client.get(f"/api/v1/products/{product_id}")
                if product_response.status_code != 200:
                    console.print(f"[red]Product not found: {product_id}[/red]")
                    raise typer.Exit(1)
                selected_product = product_response.json()

        console.print(f"\n[green]✓[/green] Selected: [bold]{selected_product.get('name')}[/bold]")

        # Step 2: Pricing Tier Selection
        pricing_tiers = selected_product.get("pricing_tiers", [])
        if not pricing_tiers:
            console.print("[red]No pricing tiers available for this product[/red]")
            raise typer.Exit(1)

        selected_tier = None
        if tier:
            # Match by name (case-insensitive) or ID
            for t in pricing_tiers:
                if t.get("name", "").lower() == tier.lower() or str(t.get("id", "")).startswith(tier):
                    selected_tier = t
                    break
            if not selected_tier:
                console.print(f"[red]Tier not found: {tier}[/red]")
                console.print(f"Available: {', '.join(t.get('name') for t in pricing_tiers)}")
                raise typer.Exit(1)
        else:
            console.print("\n[bold cyan]Step 2: Select Pricing Tier[/bold cyan]")
            console.print()

            table = Table(title="Available Pricing Tiers")
            table.add_column("#", style="cyan", no_wrap=True)
            table.add_column("Name", style="green")
            table.add_column("Price", style="yellow")
            table.add_column("Billing", style="blue")
            table.add_column("Specs")

            for idx, t in enumerate(pricing_tiers, 1):
                specs = t.get("specs", {})
                specs_str = f"CPU: {specs.get('cpu_cores', 'N/A')}, RAM: {specs.get('memory_gb', 'N/A')}GB, Nodes: {specs.get('nodes', 'N/A')}"
                table.add_row(
                    str(idx),
                    t.get("name", "N/A"),
                    f"€{t.get('price', 0):.2f}",
                    t.get("billing_interval", "N/A"),
                    specs_str,
                )

            console.print(table)
            console.print()

            tier_choice = Prompt.ask("Select pricing tier number", default="1")
            try:
                selected_tier = pricing_tiers[int(tier_choice) - 1]
            except (ValueError, IndexError):
                console.print("[red]Invalid selection[/red]")
                raise typer.Exit(1) from None

        console.print(
            f"[green]✓[/green] Selected: [bold]{selected_tier.get('name')}[/bold] - €{selected_tier.get('price', 0):.2f}/{selected_tier.get('billing_interval', 'month')}"
        )

        # Step 3: Provider Selection
        available_providers = [
            {"name": "Hetzner", "value": "hetzner", "description": "German cloud provider, cost-effective"},
            {"name": "AWS", "value": "aws", "description": "Amazon Web Services (not yet implemented)"},
            {"name": "GCP", "value": "gcp", "description": "Google Cloud Platform (not yet implemented)"},
        ]

        if provider:
            selected_provider = provider.lower()
            if selected_provider != "hetzner":
                console.print(f"[yellow]Note: {selected_provider} is not yet implemented. Using Hetzner.[/yellow]")
                selected_provider = "hetzner"
        else:
            console.print("\n[bold cyan]Step 3: Select Cloud Provider[/bold cyan]")
            console.print()
            for idx, p in enumerate(available_providers, 1):
                status = "" if p["value"] == "hetzner" else " [dim](coming soon)[/dim]"
                console.print(f"  {idx}. [bold]{p['name']}[/bold]{status} - {p['description']}")
            console.print()
            provider_choice = Prompt.ask("Select provider number", default="1")
            selected_provider = available_providers[int(provider_choice) - 1]["value"]
            if selected_provider != "hetzner":
                console.print("[yellow]Note: Not yet implemented. Using Hetzner.[/yellow]")
                selected_provider = "hetzner"

        console.print(f"[green]✓[/green] Selected: [bold]{selected_provider}[/bold]")

        # Step 4: Region Selection
        available_regions = [
            {"name": "Nuremberg, Germany", "value": "nbg1", "location": "🇩🇪"},
            {"name": "Falkenstein, Germany", "value": "fsn1", "location": "🇩🇪"},
            {"name": "Helsinki, Finland", "value": "hel1", "location": "🇫🇮"},
            {"name": "Ashburn, USA", "value": "ash", "location": "🇺🇸"},
        ]

        if region:
            selected_region = region.lower()
            region_label = next(
                (r["name"] for r in available_regions if r["value"] == selected_region), selected_region
            )
        else:
            console.print("\n[bold cyan]Step 4: Select Region[/bold cyan]")
            console.print()
            for idx, r in enumerate(available_regions, 1):
                console.print(f"  {idx}. {r['location']} [bold]{r['name']}[/bold] ({r['value']})")
            console.print()
            region_choice = Prompt.ask("Select region number", default="1")
            selected_region = available_regions[int(region_choice) - 1]["value"]
            region_label = available_regions[int(region_choice) - 1]["name"]

        console.print(f"[green]✓[/green] Selected: [bold]{region_label}[/bold]")

        # Step 5: Firewall Configuration
        selected_firewall_id: str | None = None
        fw_response = client.get("/api/v1/firewalls")
        firewalls = fw_response.json() if fw_response.status_code == 200 else []
        if isinstance(firewalls, dict):
            firewalls = firewalls.get("items", firewalls.get("data", []))

        if no_firewall:
            console.print("[green]✓[/green] Firewall: [bold]None[/bold]")
        elif firewall_id:
            # Match by ID or name
            matched = next(
                (
                    fw
                    for fw in firewalls
                    if str(fw.get("id", "")).startswith(firewall_id)
                    or fw.get("name", "").lower() == firewall_id.lower()
                ),
                None,
            )
            if matched:
                selected_firewall_id = matched.get("id")
                console.print(f"[green]✓[/green] Firewall: [bold]{matched.get('name')}[/bold]")
            else:
                console.print(f"[red]Firewall not found: {firewall_id}[/red]")
                raise typer.Exit(1)
        elif firewalls:
            console.print("\n[bold cyan]Step 5: Firewall Configuration[/bold cyan]")
            console.print()
            fw_table = Table()
            fw_table.add_column("#", style="cyan", width=4)
            fw_table.add_column("Name", style="green")
            fw_table.add_column("Description", style="dim")
            for i, fw in enumerate(firewalls, 1):
                fw_table.add_row(str(i), fw.get("name", "N/A"), fw.get("description") or "")
            console.print(fw_table)
            console.print()

            fw_options = [str(i) for i in range(1, len(firewalls) + 1)]
            fw_choice = Prompt.ask(f"Select firewall [{'/ '.join(fw_options)}/none]", default="1")
            if fw_choice.lower() != "none" and fw_choice in fw_options:
                selected_fw = firewalls[int(fw_choice) - 1]
                selected_firewall_id = selected_fw.get("id")
                console.print(f"[green]✓[/green] Firewall: [bold]{selected_fw.get('name')}[/bold]")
            else:
                console.print("[green]✓[/green] Firewall: [bold]None[/bold]")
        else:
            console.print("[dim]No firewalls available — deploying without firewall.[/dim]")
            console.print("[green]✓[/green] Firewall: [bold]None[/bold]")

        # Step 6: Accept terms
        if not yes:
            console.print("\n[bold cyan]Step 6: Terms & Conditions[/bold cyan]")
            console.print()
            console.print("By placing this order you accept the platform terms of service,")
            console.print("privacy policy, and provider-specific agreements.")
            console.print()
            if not typer.confirm("I accept the terms and conditions"):
                console.print("[yellow]Order cancelled.[/yellow]")
                raise typer.Exit(0)

        # Step 7: Create Order
        console.print("\n[bold cyan]Step 7: Creating Order[/bold cyan]")
        console.print()

        # Prepare order data
        order_data: dict[str, object] = {
            "amount": float(selected_tier.get("price", 0)),
            "currency": selected_tier.get("currency", "EUR"),
            "description": f"{selected_product.get('name')} - {selected_tier.get('name')}",
            "redirect_url": "http://localhost:3000/payment/success",
            "product_id": product_id,
            "pricing_tier_id": selected_tier.get("id"),
            "accepted_documents": True,
        }
        if selected_firewall_id:
            order_data["firewall_id"] = selected_firewall_id

        is_dev = get_current_environment() == "development"
        console.print(f"[yellow]Creating order for {order_data['currency']} {order_data['amount']:.2f}...[/yellow]")

        response = client.post("/api/v1/payments/create", data=order_data)

        if response.status_code not in [200, 201]:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(f"[red]{response.json().get('detail', 'Unknown error')}[/red]")
            raise typer.Exit(1)

        result = response.json()
        order_id = result.get("order_id")

        console.print()
        console.print("[green]✓ Order created successfully![/green]")
        console.print()
        console.print("[bold]Order Summary[/bold]")
        console.print("─" * 70)
        console.print(f"Order ID:        [cyan]{order_id}[/cyan]")
        console.print(f"Product:         [green]{selected_product.get('name')}[/green]")
        console.print(f"Tier:            [green]{selected_tier.get('name')}[/green]")
        console.print(f"Amount:          [yellow]{order_data['currency']} {order_data['amount']:.2f}[/yellow]")
        console.print(f"Provider:        [blue]{selected_provider}[/blue]")
        console.print(f"Region:          [blue]{selected_region}[/blue]")
        fw_label = (
            next((fw.get("name") for fw in firewalls if fw.get("id") == selected_firewall_id), "None")
            if selected_firewall_id
            else "None"
        )
        console.print(f"Firewall:        [blue]{fw_label}[/blue]")
        console.print(f"Status:          [yellow]{result.get('status', 'pending')}[/yellow]")
        if result.get("payment_url") and not is_dev:
            console.print(f"Payment URL:     [blue]{result.get('payment_url')}[/blue]")
        console.print()

        # Step 8: Auto-simulate payment in dev mode only
        if auto_pay and is_dev:
            console.print("[bold cyan]Step 8: Simulating Payment (Dev Mode)[/bold cyan]")
            console.print()

            admin_client = APIClient(api_type="admin")

            # Simulate payment
            pay_response = admin_client.post(
                "/api/v1/dev/simulate-payment",
                data={
                    "order_id": order_id,
                    "payment_status": "paid",
                },
            )

            if pay_response.status_code in [200, 201]:
                pay_result = pay_response.json()
                console.print("[green]✓ Payment simulated successfully![/green]")
                console.print()

                # Check if deployment was triggered
                if pay_result.get("deployment_triggered"):
                    deployment_result = pay_result.get("deployment_result", {})
                    deployment_id = deployment_result.get("deployment_id") or deployment_result.get("cluster_id")

                    if deployment_id:
                        console.print("[green]✓ Deployment triggered automatically![/green]")
                        console.print()
                        console.print(f"Deployment ID:   [cyan]{deployment_id}[/cyan]")
                        console.print(f"Status:          [yellow]{deployment_result.get('status', 'pending')}[/yellow]")
                        console.print()
                        console.print(f"[cyan]Check status: pbd clusters get {deployment_id}[/cyan]")
                        console.print("[cyan]List clusters: pbd clusters list[/cyan]")
                else:
                    console.print("[yellow]Payment succeeded but deployment not triggered automatically[/yellow]")
                    console.print(f"[cyan]Trigger manually: pbd dev trigger-deployment {order_id}[/cyan]")
            else:
                console.print(f"[red]Payment simulation failed: {pay_response.status_code}[/red]")
                console.print(f"[cyan]Try manually: pbd dev simulate-payment {order_id}[/cyan]")
        else:
            payment_url = result.get("payment_url")
            if payment_url:
                console.print("[bold cyan]Step 8: Complete Payment[/bold cyan]")
                console.print()
                console.print("[green]Open the link below to complete your payment:[/green]")
                console.print(f"[bold blue]{payment_url}[/bold blue]")
                console.print()
                console.print("[dim]Your cluster will be deployed automatically after payment.[/dim]")
            elif is_dev:
                console.print(f"[cyan]To simulate payment: pbd dev simulate-payment {order_id}[/cyan]")

        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
