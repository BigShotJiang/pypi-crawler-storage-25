"""Deployment management commands.

NOTE: Deployments are triggered automatically after successful payment.
Use the 'orders' commands to create orders and initiate deployments.

This module is for checking deployment status only.
"""

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()


@app.command(name="list")
def list_deployments(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of deployments to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List user deployments.

    Deployments are created automatically after successful payment.
    To create a new deployment, use: pbd orders create
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters?limit={limit}")

        if response.status_code == 200:
            data = response.json()
            deployments = data.get("data", [])

            if not deployments:
                console.print("[yellow]No deployments found[/yellow]")
                console.print()
                console.print("[cyan]Tip: Create an order to trigger a deployment:[/cyan]")
                console.print("[cyan]   pbd orders create-interactive[/cyan]")
                return

            total = data.get("total", len(deployments))
            table = Table(title=f"Deployments ({len(deployments)} of {total})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Type", style="blue")
            table.add_column("Region", style="magenta")
            table.add_column("Date", style="dim")

            for deployment in deployments:
                created = deployment.get("created_at") or "N/A"
                table.add_row(
                    deployment.get("cluster_id", "N/A"),
                    deployment.get("cluster_name", "N/A"),
                    deployment.get("status", "N/A"),
                    deployment.get("cluster_type", "N/A"),
                    deployment.get("region_name") or deployment.get("region", "N/A"),
                    created[:10],
                )

            console.print()
            console.print(table)
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_deployment(
    cluster_id: str = typer.Argument(..., help="Cluster ID (UUID or partial)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get deployment details for a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}/deployment")

        if response.status_code == 200:
            deployment = response.json()

            console.print()
            console.print(f"[bold]Deployment Details: {cluster_id}[/bold]")
            console.print("─" * 70)
            console.print(f"Status:          [yellow]{deployment.get('status')}[/yellow]")
            console.print(f"Type:            [blue]{deployment.get('deployment_type', 'N/A')}[/blue]")

            if deployment.get("created_at"):
                console.print(f"Created:         {deployment.get('created_at')}")

            if deployment.get("completed_at"):
                console.print(f"Completed:       {deployment.get('completed_at')}")

            console.print()
        elif response.status_code == 404:
            console.print(f"[red]Cluster not found: {cluster_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
