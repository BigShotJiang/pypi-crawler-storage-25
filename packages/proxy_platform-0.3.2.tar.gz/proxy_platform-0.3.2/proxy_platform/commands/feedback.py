"""Feedback portal commands for users."""

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()

# Valid feedback categories and statuses (mirrors pbd-shared enums)
FEEDBACK_CATEGORIES = ["bug_report", "feature_request", "improvement", "other"]
FEEDBACK_STATUSES = ["open", "solved"]


@app.command(name="submit")
def submit_feedback(
    title: str = typer.Option(..., "--title", "-t", help="Feedback title"),
    description: str = typer.Option(..., "--description", "-d", help="Feedback description"),
    category: str = typer.Option(..., "--category", "-c", help=f"Category: {', '.join(FEEDBACK_CATEGORIES)}"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Submit new feedback.

    Submits a feedback item to the portal. The category must be one of:
    bug_report, feature_request, improvement, other.

    Examples:
        pbd feedback submit --title "Login broken" --description "Cannot login" --category bug_report
        pbd feedback submit --title "Dark mode" --description "Please add dark mode" --category feature_request
    """
    if api is None:
        api = get_default_api_type()

    if category not in FEEDBACK_CATEGORIES:
        console.print(f"[red]Error: Invalid category '{category}'[/red]")
        console.print(f"[yellow]Valid categories: {', '.join(FEEDBACK_CATEGORIES)}[/yellow]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)
        data = {
            "title": title,
            "description": description,
            "category": category,
        }

        response = client.post("/api/v1/feedback", data=data)

        if response.status_code == 201:
            result = response.json()
            console.print()
            console.print("[green]Feedback submitted successfully![/green]")
            console.print()
            console.print("[bold]Feedback Details[/bold]")
            console.print("-" * 70)
            console.print(f"ID:          [cyan]{result.get('id')}[/cyan]")
            console.print(f"Title:       {result.get('title')}")
            console.print(f"Category:    [blue]{result.get('category')}[/blue]")
            console.print(f"Status:      [yellow]{result.get('status')}[/yellow]")
            console.print(f"Votes:       {result.get('vote_count', 0)}")
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="list")
def list_feedback(
    limit: int = typer.Option(20, "--limit", "-l", help="Number of items per page"),
    page: int = typer.Option(1, "--page", "-p", help="Page number (1-based)"),
    category: str | None = typer.Option(
        None, "--category", "-c", help=f"Filter by category: {', '.join(FEEDBACK_CATEGORIES)}"
    ),
    status: str | None = typer.Option(None, "--status", "-s", help=f"Filter by status: {', '.join(FEEDBACK_STATUSES)}"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List feedback items.

    By default, solved items are excluded. Pass --status solved to see them,
    or --status open to see only open items.

    Examples:
        pbd feedback list
        pbd feedback list --category bug_report
        pbd feedback list --status solved
        pbd feedback list --limit 50 --page 2
    """
    if api is None:
        api = get_default_api_type()

    if category and category not in FEEDBACK_CATEGORIES:
        console.print(f"[red]Error: Invalid category '{category}'[/red]")
        console.print(f"[yellow]Valid categories: {', '.join(FEEDBACK_CATEGORIES)}[/yellow]")
        raise typer.Exit(1)

    if status and status not in FEEDBACK_STATUSES:
        console.print(f"[red]Error: Invalid status '{status}'[/red]")
        console.print(f"[yellow]Valid statuses: {', '.join(FEEDBACK_STATUSES)}[/yellow]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)
        params: dict[str, str | int] = {"per_page": limit, "page": page}
        if category:
            params["category"] = category
        if status:
            params["status"] = status

        response = client.get("/api/v1/feedback", params=params)

        if response.status_code == 200:
            data = response.json()
            items = data.get("data", [])

            if not items:
                console.print("[yellow]No feedback items found[/yellow]")
                return

            total = data.get("total", len(items))
            table = Table(title=f"Feedback ({len(items)} of {total})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Title", style="white")
            table.add_column("Category", style="blue")
            table.add_column("Status", style="yellow")
            table.add_column("Votes", style="green")
            table.add_column("Voted", style="magenta")
            table.add_column("Date", style="dim")

            for item in items:
                item_id = str(item.get("id", "N/A"))[:8] + "..."
                voted = "[green]Yes[/green]" if item.get("user_has_voted") else ""
                created = item.get("created_at", "N/A")[:10] if item.get("created_at") else "N/A"

                table.add_row(
                    item_id,
                    item.get("title", "N/A"),
                    item.get("category", "N/A"),
                    item.get("status", "N/A"),
                    str(item.get("vote_count", 0)),
                    voted,
                    created,
                )

            console.print()
            console.print(table)

            if data.get("has_next"):
                console.print(f"\n[dim]Page {data.get('page')} of {-(-total // limit)}. Use --page to navigate.[/dim]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_feedback(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get a single feedback item by ID, including comments and vote status.

    Examples:
        pbd feedback get 550e8400-e29b-41d4-a716-446655440000
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/feedback/{feedback_id}")

        if response.status_code == 200:
            item = response.json()
            console.print()
            console.print("[bold]Feedback Details[/bold]")
            console.print("-" * 70)
            console.print(f"ID:              [cyan]{item.get('id')}[/cyan]")
            console.print(f"Title:           {item.get('title')}")
            console.print(f"Description:     {item.get('description')}")
            console.print(f"Category:        [blue]{item.get('category')}[/blue]")
            console.print(f"Status:          [yellow]{item.get('status')}[/yellow]")
            console.print(f"Votes:           [green]{item.get('vote_count', 0)}[/green]")
            console.print(f"Voted by you:    {'Yes' if item.get('user_has_voted') else 'No'}")
            console.print(f"Submitted by:    {item.get('user_name')} ({item.get('user_email')})")

            if item.get("jira_ticket"):
                console.print(f"Jira Ticket:     [cyan]{item.get('jira_ticket')}[/cyan]")
            if item.get("solved_in_release"):
                console.print(f"Solved in:       {item.get('solved_in_release')}")
            if item.get("created_at"):
                console.print(f"Created:         {item.get('created_at')}")

            # Show comments if present
            comments = item.get("comments", [])
            if comments:
                console.print()
                console.print(f"[bold]Comments ({len(comments)})[/bold]")
                console.print("-" * 70)
                for comment in comments:
                    console.print(f"[cyan]{comment.get('user_name')}[/cyan] ({comment.get('created_at', 'N/A')[:10]}):")
                    console.print(f"  {comment.get('content')}")
                    console.print()
            console.print()
        elif response.status_code == 404:
            console.print(f"[red]Feedback not found: {feedback_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="update")
def update_feedback(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    title: str | None = typer.Option(None, "--title", "-t", help="New title"),
    description: str | None = typer.Option(None, "--description", "-d", help="New description"),
    category: str | None = typer.Option(
        None, "--category", "-c", help=f"New category: {', '.join(FEEDBACK_CATEGORIES)}"
    ),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Update your own feedback item (title, description, category).

    Only the owner of the feedback can update it.
    Status cannot be changed here — that is admin-only.

    Examples:
        pbd feedback update <id> --title "Updated title"
        pbd feedback update <id> --category feature_request
    """
    if api is None:
        api = get_default_api_type()

    if category and category not in FEEDBACK_CATEGORIES:
        console.print(f"[red]Error: Invalid category '{category}'[/red]")
        console.print(f"[yellow]Valid categories: {', '.join(FEEDBACK_CATEGORIES)}[/yellow]")
        raise typer.Exit(1)

    if not any([title, description, category]):
        console.print("[red]Error: At least one field must be provided (--title, --description, --category)[/red]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)

        # The user API PUT endpoint uses FeedbackCreate which requires all fields,
        # so we fetch current values first and merge
        get_response = client.get(f"/api/v1/feedback/{feedback_id}")
        if get_response.status_code != 200:
            console.print(f"[red]Error: Could not fetch feedback {feedback_id}[/red]")
            raise typer.Exit(1)

        current = get_response.json()
        data = {
            "title": title if title is not None else current.get("title", ""),
            "description": description if description is not None else current.get("description", ""),
            "category": category if category is not None else current.get("category", ""),
        }

        response = client.put(f"/api/v1/feedback/{feedback_id}", data=data)

        if response.status_code == 200:
            result = response.json()
            console.print(f"[green]Feedback [cyan]{feedback_id}[/cyan] updated successfully[/green]")
            console.print(f"  Title:    {result.get('title')}")
            console.print(f"  Category: {result.get('category')}")
            console.print()
        elif response.status_code == 403:
            console.print("[red]Error: You are not allowed to edit this feedback[/red]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print(f"[red]Feedback not found: {feedback_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="delete")
def delete_feedback(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Delete your own feedback item.

    Only the owner of the feedback can delete it.
    This action cannot be undone.

    Examples:
        pbd feedback delete <id>
        pbd feedback delete <id> --yes
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        if not yes:
            confirm = typer.confirm(f"Are you sure you want to delete feedback {feedback_id}?")
            if not confirm:
                console.print("[yellow]Deletion cancelled[/yellow]")
                raise typer.Exit(0)

        response = client.delete(f"/api/v1/feedback/{feedback_id}")

        if response.status_code == 204:
            console.print(f"[green]Feedback [cyan]{feedback_id}[/cyan] deleted successfully[/green]")
        elif response.status_code == 403:
            console.print("[red]Error: You are not allowed to delete this feedback[/red]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print(f"[red]Feedback not found: {feedback_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="vote")
def vote_feedback(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Upvote a feedback item.

    Each user can vote once per feedback item.
    Returns an error if you have already voted.

    Examples:
        pbd feedback vote 550e8400-e29b-41d4-a716-446655440000
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.post(f"/api/v1/feedback/{feedback_id}/vote")

        if response.status_code == 204:
            console.print(f"[green]Vote added to feedback [cyan]{feedback_id}[/cyan][/green]")
        elif response.status_code == 409:
            console.print("[yellow]You have already voted on this feedback[/yellow]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print(f"[red]Feedback not found: {feedback_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="unvote")
def unvote_feedback(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Retract your vote on a feedback item.

    Returns an error if you have not voted on this item.

    Examples:
        pbd feedback unvote 550e8400-e29b-41d4-a716-446655440000
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.delete(f"/api/v1/feedback/{feedback_id}/vote")

        if response.status_code == 204:
            console.print(f"[green]Vote removed from feedback [cyan]{feedback_id}[/cyan][/green]")
        elif response.status_code == 404:
            # Could be feedback not found or vote not found
            try:
                detail = response.json().get("detail", "Not found")
            except Exception:
                detail = "Not found"
            console.print(f"[red]{detail}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="comment")
def add_comment(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    content: str = typer.Option(..., "--content", "-c", help="Comment content"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Add a comment to a feedback item.

    Examples:
        pbd feedback comment <id> --content "This is a great idea!"
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        data = {"content": content}
        response = client.post(f"/api/v1/feedback/{feedback_id}/comments", data=data)

        if response.status_code == 201:
            result = response.json()
            console.print(f"[green]Comment added to feedback [cyan]{feedback_id}[/cyan][/green]")
            console.print(f"  Comment ID: [cyan]{result.get('id')}[/cyan]")
            console.print(f"  Content:    {result.get('content')}")
            console.print()
        elif response.status_code == 404:
            console.print(f"[red]Feedback not found: {feedback_id}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="update-comment")
def update_comment(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    comment_id: str = typer.Argument(..., help="Comment ID (UUID)"),
    content: str = typer.Option(..., "--content", "-c", help="New comment content"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Edit your own comment on a feedback item.

    Only the comment owner can edit their comment.

    Examples:
        pbd feedback update-comment <feedback-id> <comment-id> --content "Updated comment"
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        data = {"content": content}
        response = client.put(f"/api/v1/feedback/{feedback_id}/comments/{comment_id}", data=data)

        if response.status_code == 200:
            result = response.json()
            console.print(f"[green]Comment [cyan]{comment_id}[/cyan] updated successfully[/green]")
            console.print(f"  Content: {result.get('content')}")
            console.print()
        elif response.status_code == 403:
            console.print("[red]Error: You are not allowed to edit this comment[/red]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print("[red]Feedback or comment not found[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="delete-comment")
def delete_comment(
    feedback_id: str = typer.Argument(..., help="Feedback ID (UUID)"),
    comment_id: str = typer.Argument(..., help="Comment ID (UUID)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Delete your own comment on a feedback item.

    Only the comment owner can delete their comment.
    This action cannot be undone.

    Examples:
        pbd feedback delete-comment <feedback-id> <comment-id>
        pbd feedback delete-comment <feedback-id> <comment-id> --yes
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        if not yes:
            confirm = typer.confirm(f"Are you sure you want to delete comment {comment_id}?")
            if not confirm:
                console.print("[yellow]Deletion cancelled[/yellow]")
                raise typer.Exit(0)

        response = client.delete(f"/api/v1/feedback/{feedback_id}/comments/{comment_id}")

        if response.status_code == 204:
            console.print(f"[green]Comment [cyan]{comment_id}[/cyan] deleted successfully[/green]")
        elif response.status_code == 403:
            console.print("[red]Error: You are not allowed to delete this comment[/red]")
            raise typer.Exit(1)
        elif response.status_code == 404:
            console.print("[red]Feedback or comment not found[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
