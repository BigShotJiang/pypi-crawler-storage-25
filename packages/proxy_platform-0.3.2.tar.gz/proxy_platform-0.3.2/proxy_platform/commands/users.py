"""User management commands."""

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()


@app.command(name="profile")
def get_profile(
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get user profile information."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get("/api/v1/users/profile")

        if response.status_code == 200:
            user = response.json()

            console.print()
            console.print("[bold]User Profile[/bold]")
            console.print("─" * 70)
            console.print(f"ID:              [cyan]{user.get('id')}[/cyan]")
            console.print(f"Email:           [cyan]{user.get('email')}[/cyan]")
            console.print(f"First Name:      {user.get('first_name', 'N/A')}")
            console.print(f"Last Name:       {user.get('last_name', 'N/A')}")
            console.print(f"Company:         {user.get('company_name', 'N/A')}")
            console.print(f"Phone:           {user.get('phone', 'N/A')}")

            if user.get("is_admin"):
                console.print("Role:            [magenta]Admin[/magenta]")

            if user.get("created_at"):
                console.print(f"Member Since:    {user.get('created_at')}")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="stats")
def get_stats(
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get user statistics."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get("/api/v1/users/stats")

        if response.status_code == 200:
            stats = response.json()

            console.print()
            console.print("[bold]User Statistics[/bold]")
            console.print("─" * 70)

            for key, value in stats.items():
                formatted_key = key.replace("_", " ").title()
                console.print(f"{formatted_key}: [cyan]{value}[/cyan]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="activities")
def get_activities(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of activities to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get user activity log."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/users/activities?limit={limit}")

        if response.status_code == 200:
            data = response.json()
            activities = data.get("items", [])

            if not activities:
                console.print("[yellow]No activities found[/yellow]")
                return

            table = Table(title=f"Recent Activities ({len(activities)} of {data.get('total', 0)})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Type", style="green")
            table.add_column("Description", style="white")
            table.add_column("Date", style="yellow")

            for activity in activities:
                table.add_row(
                    str(activity.get("id", "N/A")),
                    activity.get("activity_type", "N/A"),
                    activity.get("description", "N/A"),
                    activity.get("created_at", "N/A"),
                )

            console.print()
            console.print(table)
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="orders")
def get_orders(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of orders to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get user orders."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/users/orders?limit={limit}")

        if response.status_code == 200:
            data = response.json()
            orders = data.get("items", [])

            if not orders:
                console.print("[yellow]No orders found[/yellow]")
                return

            table = Table(title=f"Orders ({len(orders)} of {data.get('total', 0)})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Status", style="yellow")
            table.add_column("Total", style="green")
            table.add_column("Date", style="blue")

            for order in orders:
                table.add_row(
                    str(order.get("id", "N/A")),
                    order.get("status", "N/A"),
                    f"€{order.get('total_amount', 0):.2f}",
                    order.get("created_at", "N/A"),
                )

            console.print()
            console.print(table)
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="verification")
def get_verification_status(
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get user verification status."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get("/api/v1/users/verification-status")

        if response.status_code == 200:
            status = response.json()

            console.print()
            console.print("[bold]Verification Status[/bold]")
            console.print("─" * 70)

            for key, value in status.items():
                formatted_key = key.replace("_", " ").title()
                if isinstance(value, bool):
                    value_str = "[green]Yes[/green]" if value else "[red]No[/red]"
                    console.print(f"{formatted_key}: {value_str}")
                else:
                    console.print(f"{formatted_key}: [cyan]{value}[/cyan]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
