"""Product catalog commands."""

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()


@app.command(name="list")
def list_products(
    limit: int = typer.Option(50, "--limit", "-l", help="Number of products to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List available products.

    Shows all products available for purchase.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/products?limit={limit}")

        if response.status_code == 200:
            data = response.json()

            # Handle both list and dict responses
            if isinstance(data, list):
                products = data
            else:
                products = data.get("items", [])

            if not products:
                console.print("[yellow]No products found[/yellow]")
                return

            table = Table(title=f"Available Products ({len(products)})")
            table.add_column("ID", style="cyan", no_wrap=True, overflow="fold")
            table.add_column("Name", style="green")
            table.add_column("Category", style="yellow")
            table.add_column("Price", style="magenta")
            table.add_column("Provider", style="blue")

            for product in products:
                provider = product.get("provider", {})
                product_id = str(product.get("id", "N/A"))
                # Truncate long UUIDs for display
                display_id = product_id[:8] + "..." if len(product_id) > 8 else product_id

                table.add_row(
                    display_id,
                    product.get("name", "N/A"),
                    product.get("category", "N/A"),
                    f"€{product.get('price', 0):.2f}",
                    provider.get("name", "N/A") if provider else "N/A",
                )

            console.print()
            console.print(table)
            console.print()
            console.print("[cyan]💡 To see full product ID for ordering, use: pbd products get <partial-id>[/cyan]")
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_product(
    product_id: str = typer.Argument(..., help="Product ID (or partial ID)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get details about a specific product."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        # Try direct get first
        response = client.get(f"/api/v1/products/{product_id}")

        if response.status_code == 200:
            product = response.json()
        else:
            # If not found, try to find by partial ID
            list_response = client.get("/api/v1/products?limit=100")
            if list_response.status_code == 200:
                list_data = list_response.json()
                products = list_data if isinstance(list_data, list) else list_data.get("items", [])
                matching = [p for p in products if str(p.get("id", "")).startswith(product_id)]

                if len(matching) == 1:
                    product = matching[0]
                elif len(matching) > 1:
                    console.print(f"[yellow]Multiple products match '{product_id}':[/yellow]")
                    for p in matching:
                        console.print(f"  - {p.get('id')} ({p.get('name')})")
                    console.print("\n[cyan]Please provide a more specific ID[/cyan]")
                    raise typer.Exit(1)
                else:
                    console.print(f"[red]Product not found: {product_id}[/red]")
                    raise typer.Exit(1)
            else:
                console.print(f"[red]Error: {response.status_code}[/red]")
                raise typer.Exit(1)

        # Display product details
        console.print()
        console.print(f"[bold]Product Details: {product.get('name')}[/bold]")
        console.print("─" * 70)
        console.print(f"ID:              [cyan]{product.get('id')}[/cyan]")
        console.print(f"Name:            [green]{product.get('name')}[/green]")
        console.print(f"Category:        [yellow]{product.get('category', 'N/A')}[/yellow]")
        console.print(f"Price:           [magenta]€{product.get('price', 0):.2f}[/magenta]")

        provider = product.get("provider", {})
        if provider:
            console.print(f"Provider:        [blue]{provider.get('name', 'N/A')}[/blue]")

        if product.get("description"):
            console.print(f"Description:     {product.get('description')}")

        console.print()
        console.print(
            f"[cyan]💡 To order: pbd orders create {product.get('price', 0):.2f} --product {product.get('id')}[/cyan]"
        )
        console.print()

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
