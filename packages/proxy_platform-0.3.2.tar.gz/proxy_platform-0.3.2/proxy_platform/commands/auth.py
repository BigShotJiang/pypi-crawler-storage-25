"""Authentication commands."""

import typer
from rich.console import Console
from rich.prompt import Prompt

from ..client import APIClient
from ..config import (
    clear_tokens,
    get_current_environment,
    get_default_api_type,
    save_tokens,
    set_default_api_type,
)

app = typer.Typer()
console = Console()


@app.command()
def login(
    email: str | None = typer.Option(None, "--email", "-e", help="Email address"),
    password: str | None = typer.Option(None, "--password", "-p", help="Password", hide_input=True),
    api: str = typer.Option("user", "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Login to the PBD API.

    Authenticate and store the access token for future requests.
    """
    if api not in ["admin", "user"]:
        console.print("[red]Error: API type must be 'admin' or 'user'[/red]")
        raise typer.Exit(1)

    env = get_current_environment()
    console.print(f"Logging in to [cyan]{api}[/cyan] API ([yellow]{env}[/yellow])...")
    console.print()

    # Prompt for credentials if not provided
    email_str: str = email if email else Prompt.ask("Email")
    password_str: str = password if password else Prompt.ask("Password", password=True)

    try:
        client = APIClient(api_type=api)
        try:
            result = client.login(email_str, password_str)
        except Exception as e:
            if "OTP required" in str(e) or "X-OTP" in str(e):
                console.print("[yellow]Two-factor authentication required.[/yellow]")
                otp_code = Prompt.ask("OTP code")
                result = client.login(email_str, password_str, otp_code=otp_code)
            else:
                raise

        # Result contains both access_token and refresh_token
        access_token: str | None = result.get("access_token")
        refresh_token: str | None = result.get("refresh_token")

        # Save the tokens
        if api == "admin":
            save_tokens(admin_token=access_token, admin_refresh=refresh_token)
        else:
            save_tokens(user_token=access_token, user_refresh=refresh_token)

        # Set as default API type
        set_default_api_type(api)

        console.print()
        console.print("[green]✓[/green] Login successful!")
        console.print(f"Authenticated as: [cyan]{email_str}[/cyan]")
        console.print(f"API type: [cyan]{api}[/cyan]")
        console.print(f"Environment: [yellow]{env}[/yellow]")
        if refresh_token:
            console.print("[dim]✓ Auto-refresh enabled[/dim]")

    except Exception as e:
        console.print(f"[red]✗ Login failed: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command()
def logout() -> None:
    """Logout from the PBD API.

    Clear stored authentication tokens.
    """
    clear_tokens()
    console.print("[green]✓[/green] Logged out successfully")


@app.command()
def whoami(
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Show current user information.

    Display information about the currently authenticated user.
    """
    if api is None:
        api = get_default_api_type()

    if api not in ["admin", "user"]:
        console.print("[red]Error: API type must be 'admin' or 'user'[/red]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)
        response = client.get("/api/v1/users/profile")

        if response.status_code == 200:
            user = response.json()
            env = get_current_environment()

            console.print()
            console.print("[bold]Current User Information[/bold]")
            console.print("─" * 50)
            console.print(f"Name:        [cyan]{user.get('first_name', '')} {user.get('last_name', '')}[/cyan]")
            console.print(f"Email:       [cyan]{user.get('email', 'N/A')}[/cyan]")
            console.print(f"User ID:     [cyan]{user.get('id', 'N/A')}[/cyan]")
            console.print(f"API Type:    [cyan]{api}[/cyan]")
            console.print(f"Environment: [yellow]{env}[/yellow]")

            if user.get("is_admin"):
                console.print("Role:        [magenta]Admin[/magenta]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command()
def switch(
    api: str = typer.Argument(..., help="API type to switch to (admin or user)"),
) -> None:
    """Switch default API type.

    Change the default API type for subsequent commands.
    """
    if api not in ["admin", "user"]:
        console.print("[red]Error: API type must be 'admin' or 'user'[/red]")
        raise typer.Exit(1)

    set_default_api_type(api)
    console.print(f"[green]✓[/green] Switched to [bold cyan]{api}[/bold cyan] API")
