"""Cluster management commands."""

import base64

import typer
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

app = typer.Typer()
console = Console()


@app.command(name="list")
def list_clusters(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of clusters to fetch"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """List your clusters.

    Shows clusters owned by the authenticated user.
    For admin view of all clusters, use: pbd admin clusters
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters?limit={limit}")

        if response.status_code == 200:
            data = response.json()
            clusters = data.get("data", [])

            if not clusters:
                console.print("[yellow]No clusters found[/yellow]")
                return

            table = Table(title=f"Clusters ({len(clusters)} of {data.get('total', 0)})")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Provider", style="blue")
            table.add_column("Region", style="magenta")

            for cluster in clusters:
                table.add_row(
                    cluster.get("cluster_id", "N/A"),
                    cluster.get("cluster_name", "N/A"),
                    cluster.get("status", "N/A"),
                    cluster.get("provider", "N/A"),
                    cluster.get("region_name") or cluster.get("region", "N/A"),
                )

            console.print()
            console.print(table)
            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="get")
def get_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID (full UUID or partial)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get details about a specific cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}")

        if response.status_code == 200:
            cluster = response.json()

            name = cluster.get("cluster_name", "N/A")

            console.print()
            console.print(f"[bold]Cluster Details: {name}[/bold]")
            console.print("─" * 70)
            console.print(f"ID:           [cyan]{cluster.get('cluster_id')}[/cyan]")
            console.print(f"Name:         [green]{name}[/green]")
            if cluster.get("display_name"):
                console.print(f"Internal:     [dim]{cluster.get('cluster_name')}[/dim]")
            console.print(f"Status:       [yellow]{cluster.get('status')}[/yellow]")
            console.print(f"Provider:     [blue]{cluster.get('provider', 'N/A')}[/blue]")
            console.print(
                f"Region:       [magenta]{cluster.get('region_name') or cluster.get('region', 'N/A')}[/magenta]"
            )
            console.print(f"Nodes:        {cluster.get('node_count', 'N/A')}")

            if cluster.get("created_at"):
                console.print(f"Created:      {cluster.get('created_at')}")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="rename")
def rename_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    name: str = typer.Option(..., "--name", "-n", help="New display name"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Rename a cluster (sets the display name)."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.patch(f"/api/v1/clusters/{cluster_id}", data={"display_name": name})

        if response.status_code == 200:
            cluster = response.json()
            console.print(f"[green]✓[/green] Cluster renamed to [bold]{cluster.get('cluster_name')}[/bold]")
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="delete")
def delete_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Delete a cluster and all its resources."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        # Show deletion preview
        preview_response = client.get(f"/api/v1/clusters/{cluster_id}/deletion-preview")
        if preview_response.status_code == 200:
            preview = preview_response.json()
            cluster_name = preview.get("cluster_name", cluster_id)
            resources = preview.get("resources", {})
            estimated_time = preview.get("estimated_deletion_time", "unknown")

            console.print()
            console.print(f"[bold red]Delete cluster: {cluster_name}[/bold red]")
            console.print("─" * 70)
            console.print("[yellow]The following resources will be permanently deleted:[/yellow]")
            console.print()
            for resource_type, items in resources.items():
                if isinstance(items, list) and items:
                    console.print(f"  [red]•[/red] {resource_type}: {len(items)} item(s)")
                elif items:
                    console.print(f"  [red]•[/red] {resource_type}: {items}")
            console.print()
            console.print(f"[dim]Estimated deletion time: {estimated_time}[/dim]")
            console.print()

            validation = preview.get("validation", {})
            if validation.get("warnings"):
                for warning in validation["warnings"]:
                    console.print(f"[yellow]⚠ {warning}[/yellow]")
                console.print()
        elif preview_response.status_code == 404:
            console.print(f"[red]Cluster not found: {cluster_id}[/red]")
            raise typer.Exit(1)

        if not yes:
            if not typer.confirm("[bold red]This action is irreversible. Continue?[/bold red]"):
                console.print("[yellow]Deletion cancelled.[/yellow]")
                raise typer.Exit(0)

        response = client.delete(f"/api/v1/clusters/{cluster_id}")

        if response.status_code in [200, 202, 204]:
            console.print("[green]✓[/green] Cluster deletion started. This may take a minute.")
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="kubeconfig")
def get_kubeconfig(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    output: str | None = typer.Option(None, "--output", "-o", help="Save to file (e.g. ~/.kube/config)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Download kubeconfig for a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}/kubeconfig")

        if response.status_code == 200:
            data = response.json()
            kubeconfig_b64 = data.get("kubeconfig", "")

            try:
                kubeconfig = base64.b64decode(kubeconfig_b64).decode("utf-8")
            except Exception:
                kubeconfig = kubeconfig_b64

            if output:
                import os

                path = os.path.expanduser(output)
                os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
                with open(path, "w") as f:
                    f.write(kubeconfig)
                os.chmod(path, 0o600)
                console.print(f"[green]✓[/green] Kubeconfig saved to [cyan]{path}[/cyan]")
            else:
                console.print(kubeconfig)

        elif response.status_code == 404:
            console.print("[red]Kubeconfig not available (cluster may still be deploying)[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="etcd-key")
def get_etcd_key(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Show the etcd encryption key for a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}/etcd-encryption-key")

        if response.status_code == 200:
            data = response.json()
            console.print()
            console.print(f"[bold]Etcd Encryption Key: {data.get('cluster_name')}[/bold]")
            console.print("─" * 70)
            console.print("[yellow]⚠ Keep this key safe — it encrypts your cluster secrets.[/yellow]")
            console.print()
            console.print(data.get("etcd_encryption_key", "N/A"))
            console.print()
        elif response.status_code == 404:
            console.print("[red]Encryption key not available (cluster may still be deploying)[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="deployment")
def get_deployment(
    cluster_id: str = typer.Argument(..., help="Cluster ID (full UUID or partial)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get deployment information for a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}/deployment")

        if response.status_code == 200:
            deployment = response.json()

            console.print()
            console.print(f"[bold]Deployment Info for Cluster {cluster_id}[/bold]")
            console.print("─" * 70)

            for key, value in deployment.items():
                console.print(f"{key}: [cyan]{value}[/cyan]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="firewall")
def get_firewall(
    cluster_id: str = typer.Argument(..., help="Cluster ID (full UUID or partial)"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Get firewall configuration for a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/clusters/{cluster_id}/firewall")

        if response.status_code == 200:
            firewall = response.json()

            console.print()
            console.print(f"[bold]Firewall Configuration for Cluster {cluster_id}[/bold]")
            console.print("─" * 70)

            rules = firewall.get("rules", [])
            if rules:
                table = Table()
                table.add_column("Direction", style="cyan")
                table.add_column("Protocol", style="green")
                table.add_column("Port", style="yellow")
                table.add_column("Source/Dest", style="blue")

                for rule in rules:
                    table.add_row(
                        rule.get("direction", "N/A"),
                        rule.get("protocol", "N/A"),
                        str(rule.get("port", "N/A")),
                        rule.get("source_ip", rule.get("destination_ip", "N/A")),
                    )

                console.print(table)
            else:
                console.print("[yellow]No firewall rules configured[/yellow]")

            console.print()
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.json().get("detail", "Unknown error"))
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command(name="assign-firewall")
def assign_firewall(
    cluster_id: str = typer.Argument(..., help="Cluster ID (full UUID or partial)"),
    firewall: str | None = typer.Option(None, "--firewall", "-f", help="Firewall name or ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Assign or change the firewall on a cluster."""
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        # Fetch available firewalls
        fw_response = client.get("/api/v1/firewalls")
        firewalls = fw_response.json() if fw_response.status_code == 200 else []
        if isinstance(firewalls, dict):
            firewalls = firewalls.get("items", firewalls.get("data", []))

        selected_firewall_id: str | None = None
        selected_firewall_name: str = "None"

        if firewall:
            matched = next(
                (
                    fw
                    for fw in firewalls
                    if str(fw.get("id", "")).startswith(firewall) or fw.get("name", "").lower() == firewall.lower()
                ),
                None,
            )
            if not matched:
                console.print(f"[red]Firewall not found: {firewall}[/red]")
                raise typer.Exit(1)
            selected_firewall_id = matched.get("id")
            selected_firewall_name = matched.get("name", selected_firewall_id or "Unknown")
        elif firewalls:
            table = Table()
            table.add_column("#", style="cyan", width=4)
            table.add_column("Name", style="green")
            table.add_column("Description", style="dim")
            for i, fw in enumerate(firewalls, 1):
                table.add_row(str(i), fw.get("name", "N/A"), fw.get("description") or "")
            console.print()
            console.print(table)
            console.print()

            fw_options = [str(i) for i in range(1, len(firewalls) + 1)]
            fw_choice = typer.prompt(f"Select firewall [{'/'.join(fw_options)}/none]", default="1")
            if fw_choice.lower() != "none" and fw_choice in fw_options:
                selected_fw = firewalls[int(fw_choice) - 1]
                selected_firewall_id = selected_fw.get("id")
                selected_firewall_name = selected_fw.get("name", selected_firewall_id or "Unknown")
            else:
                console.print("[yellow]No firewall selected. Aborted.[/yellow]")
                raise typer.Exit(0)
        else:
            console.print("[red]No firewalls available.[/red]")
            raise typer.Exit(1)

        if not yes:
            if not Confirm.ask(
                f"Firewall [bold]{selected_firewall_name}[/bold] koppelen aan cluster [cyan]{cluster_id[:8]}…[/cyan]"
            ):
                console.print("[yellow]Geannuleerd.[/yellow]")
                raise typer.Exit(0)

        response = client.put(
            f"/api/v1/clusters/{cluster_id}/firewall",
            data={"firewall_id": selected_firewall_id},
        )

        if response.status_code in [200, 201, 204]:
            console.print(
                f"[green]✓[/green] Firewall [bold]{selected_firewall_name}[/bold] gekoppeld aan cluster [cyan]{cluster_id[:8]}…[/cyan]"
            )
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            try:
                console.print(response.json().get("detail", "Unknown error"))
            except Exception:
                console.print(response.text or "Unknown error")
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
