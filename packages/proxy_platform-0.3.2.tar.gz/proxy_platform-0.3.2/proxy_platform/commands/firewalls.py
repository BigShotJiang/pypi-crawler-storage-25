"""Firewall management commands."""

import json
import logging
from typing import Any

import typer
from requests import Response
from rich.console import Console
from rich.table import Table

from ..client import APIClient
from ..config import get_default_api_type

logger = logging.getLogger(__name__)

app = typer.Typer()
console = Console()


def _print_error(response: Response) -> None:
    """Print error message from API response."""
    console.print(f"[red]Error: {response.status_code}[/red]")
    try:
        error_data: Any = response.json()
        if isinstance(error_data, dict):
            console.print(error_data.get("detail", "Unknown error"))
        else:
            console.print(str(error_data))
    except Exception:
        console.print(response.text if response.text else "Unknown error")


def _unwrap_response(data: Any) -> Any:
    """Unwrap API response if it contains a 'data' key.

    Handles both wrapped responses ({'data': ...}) and direct responses.
    """
    if data is None:
        return None
    if isinstance(data, dict) and "data" in data:
        return data["data"]
    return data


@app.command("list")
def list_firewalls(
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """List all firewalls.

    Display all firewalls accessible to the authenticated user.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get("/api/v1/firewalls")

        # Debug: Show what we got
        logger.debug(f"Response status: {response.status_code}")
        logger.debug(f"Response headers: {response.headers}")
        try:
            logger.debug(f"Response text length: {len(response.text) if response.text else 0}")
        except (TypeError, AttributeError):
            logger.debug("Response text length: N/A (mock or unavailable)")

        if response.status_code == 200:
            try:
                data = response.json()
                logger.debug(f"Parsed JSON type: {type(data)}")
                logger.debug(f"JSON keys: {list(data.keys()) if isinstance(data, dict) else 'not a dict'}")
            except Exception as e:
                console.print(f"[red]Error: Failed to parse response as JSON: {e}[/red]")
                console.print(f"[dim]Response text: {response.text[:200]}[/dim]")
                raise typer.Exit(1) from None

            firewalls = _unwrap_response(data)
            logger.debug(f"After unwrap, type: {type(firewalls)}")

            if firewalls is None:
                console.print("[red]Error: Response data is None[/red]")
                console.print(f"[dim]Full response: {data}[/dim]")
                raise typer.Exit(1)

            if not isinstance(firewalls, list):
                console.print("[red]Error: Unexpected response format[/red]")
                console.print(f"[dim]Expected list, got: {type(firewalls).__name__}[/dim]")
                console.print(f"[dim]Data: {firewalls}[/dim]")
                raise typer.Exit(1)

            if not firewalls:
                console.print("[yellow]No firewalls found[/yellow]")
                return

            table = Table(title="Firewalls")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Description", style="white")
            table.add_column("Rules", justify="right", style="magenta")
            table.add_column("Created", style="dim")

            for firewall in firewalls:
                # Handle None description values
                desc = firewall.get("description") or ""
                desc_display = desc[:50] + ("..." if len(desc) > 50 else "")

                table.add_row(
                    str(firewall.get("id", "N/A")),
                    firewall.get("name", "N/A"),
                    desc_display,
                    str(firewall.get("rule_count", len(firewall.get("rules", [])))),
                    firewall.get("created_at", "N/A"),
                )

            console.print(table)
            console.print(f"\n[dim]Total: {len(firewalls)} firewall(s)[/dim]")

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        import traceback

        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        raise typer.Exit(1) from None


@app.command("get")
def get_firewall(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Get firewall details.

    Display detailed information about a specific firewall.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/firewalls/{firewall_id}")

        if response.status_code == 200:
            data = response.json()
            firewall = _unwrap_response(data)

            console.print("\n[bold]Firewall Details[/bold]")
            console.print("─" * 80)
            console.print(f"ID:          [cyan]{firewall.get('id', 'N/A')}[/cyan]")
            console.print(f"Name:        [green]{firewall.get('name', 'N/A')}[/green]")
            console.print(f"Description: {firewall.get('description', 'N/A')}")
            console.print(f"Created:     [dim]{firewall.get('created_at', 'N/A')}[/dim]")
            console.print(f"Updated:     [dim]{firewall.get('updated_at', 'N/A')}[/dim]")

            rules = firewall.get("rules", [])
            if rules:
                console.print(f"\n[bold]Firewall Rules ({len(rules)})[/bold]")
                console.print("─" * 80)

                table = Table(show_header=True)
                table.add_column("ID", style="cyan")
                table.add_column("Direction", style="yellow")
                table.add_column("Protocol", style="magenta")
                table.add_column("Ports", style="green")
                table.add_column("Source IPs", style="white")
                table.add_column("Action", style="blue")

                for rule in rules:
                    direction = rule.get("direction", "inbound")
                    ports = rule.get("destination_ports") if direction == "inbound" else rule.get("source_ports")
                    if ports:
                        port_str = ", ".join(str(p) for p in ports)
                    else:
                        port_str = "any"

                    source_ips = rule.get("source_ips") or []
                    ip_str = ", ".join(source_ips) if source_ips else "any"

                    table.add_row(
                        str(rule.get("id", "N/A")),
                        direction,
                        rule.get("protocol", "N/A"),
                        port_str,
                        ip_str,
                        rule.get("action", "allow"),
                    )

                console.print(table)
            else:
                console.print("\n[yellow]No rules configured[/yellow]")

            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command("create")
def create_firewall(
    name: str = typer.Option(..., "--name", "-n", help="Firewall name"),
    description: str | None = typer.Option(None, "--description", "-d", help="Firewall description"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Create a new firewall.

    Create a new firewall with the specified name and optional description.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)

        payload = {"name": name}
        if description:
            payload["description"] = description

        response = client.post("/api/v1/firewalls", data=payload)

        if response.status_code in [200, 201]:
            data_response = response.json()
            firewall = _unwrap_response(data_response)
            console.print("\n[green]✓[/green] Firewall created successfully!")
            console.print(f"ID:   [cyan]{firewall.get('id')}[/cyan]")
            console.print(f"Name: [green]{firewall.get('name')}[/green]")
            if firewall.get("description"):
                console.print(f"Description: {firewall.get('description')}")
            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command("update")
def update_firewall(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    name: str | None = typer.Option(None, "--name", "-n", help="New firewall name"),
    description: str | None = typer.Option(None, "--description", "-d", help="New firewall description"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Update a firewall.

    Update the name and/or description of an existing firewall.
    """
    if api is None:
        api = get_default_api_type()

    if not name and not description:
        console.print("[red]Error: At least one of --name or --description must be provided[/red]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)

        payload = {}
        if name:
            payload["name"] = name
        if description:
            payload["description"] = description

        response = client.patch(f"/api/v1/firewalls/{firewall_id}", data=payload)

        if response.status_code == 200:
            data_response = response.json()
            firewall = _unwrap_response(data_response)
            console.print("\n[green]✓[/green] Firewall updated successfully!")
            console.print(f"ID:   [cyan]{firewall.get('id')}[/cyan]")
            console.print(f"Name: [green]{firewall.get('name')}[/green]")
            if firewall.get("description"):
                console.print(f"Description: {firewall.get('description')}")
            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command("delete")
def delete_firewall(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Delete a firewall.

    Delete a firewall by its ID. This will also delete all associated rules.
    """
    if api is None:
        api = get_default_api_type()

    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete firewall {firewall_id}?")
        if not confirm:
            console.print("[yellow]Deletion cancelled[/yellow]")
            raise typer.Abort()

    try:
        client = APIClient(api_type=api)
        response = client.delete(f"/api/v1/firewalls/{firewall_id}")

        if response.status_code in [200, 204]:
            console.print(f"[green]✓[/green] Firewall {firewall_id} deleted successfully")

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


# Firewall Rules Commands
rules_app = typer.Typer()
app.add_typer(rules_app, name="rules", help="Manage firewall rules")


@rules_app.command("list")
def list_rules(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """List all rules for a firewall.

    Display all rules configured for the specified firewall.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/firewalls/{firewall_id}/rules")

        if response.status_code == 200:
            data = response.json()
            rules = _unwrap_response(data)

            if not isinstance(rules, list):
                console.print("[red]Error: Unexpected response format[/red]")
                console.print(f"[dim]Expected list, got: {type(rules).__name__}[/dim]")
                raise typer.Exit(1)

            if not rules:
                console.print(f"[yellow]No rules found for firewall {firewall_id}[/yellow]")
                return

            table = Table(title=f"Firewall Rules (Firewall ID: {firewall_id})")
            table.add_column("ID", style="cyan")
            table.add_column("Direction", style="yellow")
            table.add_column("Protocol", style="magenta")
            table.add_column("Port Range", style="green")
            table.add_column("Source/Dest", style="white")
            table.add_column("Action", style="blue")
            table.add_column("Priority", justify="right", style="dim")

            for rule in rules:
                # Handle port range display
                # API returns destination_ports for inbound, source_ports for outbound
                # OR port_range_min/port_range_max for backwards compatibility
                direction = rule.get("direction", "")

                # Try new format first (arrays)
                if direction == "inbound" or direction == "ingress":
                    ports = rule.get("destination_ports")
                else:
                    ports = rule.get("source_ports")

                # Fall back to old format (min/max)
                if ports is None:
                    port_min = rule.get("port_range_min")
                    port_max = rule.get("port_range_max")
                    if port_min is not None and port_max is not None:
                        if port_min == port_max:
                            ports = [port_min]
                        else:
                            ports = [port_min, port_max]

                if ports is None or len(ports) == 0:
                    port_range = "any"
                elif len(ports) == 1:
                    port_range = str(ports[0])
                elif len(ports) == 2:
                    port_range = f"{ports[0]}-{ports[1]}"
                else:
                    # Multiple ports (not a range)
                    port_range = ",".join(str(p) for p in ports)

                # Handle remote IP display
                # API returns source_ips for inbound, destination_ips for outbound
                # OR remote_ip_prefix for backwards compatibility
                if direction == "inbound" or direction == "ingress":
                    ips = rule.get("source_ips")
                else:
                    ips = rule.get("destination_ips")

                # Fall back to old format (remote_ip_prefix)
                if ips is None:
                    remote_ip = rule.get("remote_ip_prefix")
                    if remote_ip:
                        ips = [remote_ip]

                if ips is None or len(ips) == 0:
                    ip_display = "any"
                elif len(ips) == 1:
                    ip_display = ips[0]
                else:
                    ip_display = ", ".join(ips[:2]) + ("..." if len(ips) > 2 else "")

                table.add_row(
                    str(rule.get("id", "N/A")),
                    rule.get("direction", "N/A"),
                    rule.get("protocol", "N/A"),
                    port_range,
                    ip_display,
                    rule.get("action", "N/A"),
                    str(rule.get("priority", "N/A")),
                )

            console.print(table)
            console.print(f"\n[dim]Total: {len(rules)} rule(s)[/dim]")

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@rules_app.command("create")
def create_rule(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    direction: str = typer.Option(..., "--direction", help="Direction (ingress/inbound or egress/outbound)"),
    protocol: str = typer.Option(..., "--protocol", help="Protocol (tcp, udp, icmp, or any)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Rule name (auto-generated if not provided)"),
    action: str = typer.Option("allow", "--action", help="Action (allow or deny)"),
    port_min: int | None = typer.Option(None, "--port-min", help="Minimum port number"),
    port_max: int | None = typer.Option(None, "--port-max", help="Maximum port number"),
    remote_ip: str | None = typer.Option(None, "--remote-ip", help="Remote IP prefix (CIDR notation)"),
    priority: int | None = typer.Option(None, "--priority", help="Rule priority (lower = higher priority)"),
    description: str | None = typer.Option(None, "--description", "-d", help="Rule description"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Create a new firewall rule.

    Add a new rule to the specified firewall.
    """
    if api is None:
        api = get_default_api_type()

    # Normalize direction: accept both ingress/inbound and egress/outbound
    direction_map = {
        "ingress": "inbound",
        "inbound": "inbound",
        "egress": "outbound",
        "outbound": "outbound",
    }

    if direction.lower() not in direction_map:
        console.print("[red]Error: Direction must be 'ingress', 'egress', 'inbound', or 'outbound'[/red]")
        raise typer.Exit(1)

    direction = direction_map[direction.lower()]

    if protocol not in ["tcp", "udp", "icmp", "any"]:
        console.print("[red]Error: Protocol must be 'tcp', 'udp', 'icmp', or 'any'[/red]")
        raise typer.Exit(1)

    if action not in ["allow", "deny"]:
        console.print("[red]Error: Action must be 'allow' or 'deny'[/red]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)

        # Auto-generate name if not provided
        if name is None:
            name = f"{action.capitalize()} {protocol.upper()} {direction}"
            if port_min is not None:
                if port_max is not None and port_max != port_min:
                    name += f" ports {port_min}-{port_max}"
                else:
                    name += f" port {port_min}"

        payload: dict[str, Any] = {
            "name": name,
            "direction": direction,
            "protocol": protocol,
            "action": action,
        }

        # Handle ports - API uses destination_ports for ingress, source_ports for egress
        if port_min is not None or port_max is not None:
            # Build port list: single port or range
            ports: list[int] = []
            if port_min is not None and port_max is not None:
                if port_min == port_max:
                    ports = [port_min]
                else:
                    ports = [port_min, port_max]
            elif port_min is not None:
                ports = [port_min]
            elif port_max is not None:
                ports = [port_max]

            # Set the appropriate field based on direction
            if direction == "inbound":
                payload["destination_ports"] = ports
            else:
                payload["source_ports"] = ports

        # Handle remote IP - API uses source_ips for inbound, destination_ips for outbound
        if remote_ip:
            if direction == "inbound":
                payload["source_ips"] = [remote_ip]
            else:
                payload["destination_ips"] = [remote_ip]

        if priority is not None:
            payload["priority"] = priority
        if description:
            payload["description"] = description

        response = client.post(f"/api/v1/firewalls/{firewall_id}/rules", data=payload)

        if response.status_code in [200, 201]:
            data_response = response.json()
            rule = _unwrap_response(data_response)

            # Format ports for display
            direction = rule.get("direction", "")
            if direction in ["inbound"]:
                ports = rule.get("destination_ports")
            else:
                ports = rule.get("source_ports")

            if ports is None or len(ports) == 0:
                port_display = "any"
            elif len(ports) == 1:
                port_display = str(ports[0])
            elif len(ports) == 2:
                port_display = f"{ports[0]}-{ports[1]}"
            else:
                port_display = ",".join(str(p) for p in ports)

            # Format IPs for display
            if direction in ["inbound"]:
                ips = rule.get("source_ips")
            else:
                ips = rule.get("destination_ips")

            if ips is None or len(ips) == 0:
                ip_display = "any"
            elif len(ips) == 1:
                ip_display = ips[0]
            else:
                ip_display = ", ".join(ips)

            console.print("\n[green]✓[/green] Firewall rule created successfully!")
            console.print(f"Rule ID:     [cyan]{rule.get('id')}[/cyan]")
            console.print(f"Name:        [white]{rule.get('name')}[/white]")
            console.print(f"Direction:   [yellow]{rule.get('direction')}[/yellow]")
            console.print(f"Protocol:    [magenta]{rule.get('protocol')}[/magenta]")
            console.print(f"Action:      [blue]{rule.get('action')}[/blue]")
            console.print(f"Port(s):     [green]{port_display}[/green]")
            console.print(f"Source/Dest: [white]{ip_display}[/white]")
            console.print(f"Priority:    [dim]{rule.get('priority', 100)}[/dim]")
            if rule.get("description"):
                console.print(f"Description: [dim]{rule.get('description')}[/dim]")
            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@rules_app.command("update")
def update_rule(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    rule_id: str = typer.Argument(..., help="Rule ID"),
    direction: str | None = typer.Option(None, "--direction", help="Direction (inbound or outbound)"),
    protocol: str | None = typer.Option(None, "--protocol", help="Protocol (tcp, udp, icmp, or any)"),
    action: str | None = typer.Option(None, "--action", help="Action (allow or deny)"),
    port_min: int | None = typer.Option(None, "--port-min", help="Minimum port number"),
    port_max: int | None = typer.Option(None, "--port-max", help="Maximum port number"),
    remote_ip: str | None = typer.Option(None, "--remote-ip", help="Remote IP prefix (CIDR notation)"),
    priority: int | None = typer.Option(None, "--priority", help="Rule priority (lower = higher priority)"),
    description: str | None = typer.Option(None, "--description", "-d", help="Rule description"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Update a firewall rule.

    Modify an existing firewall rule.
    """
    if api is None:
        api = get_default_api_type()

    if direction and direction not in ["ingress", "egress"]:
        console.print("[red]Error: Direction must be 'ingress' or 'egress'[/red]")
        raise typer.Exit(1)

    if protocol and protocol not in ["tcp", "udp", "icmp", "any"]:
        console.print("[red]Error: Protocol must be 'tcp', 'udp', 'icmp', or 'any'[/red]")
        raise typer.Exit(1)

    if action and action not in ["allow", "deny"]:
        console.print("[red]Error: Action must be 'allow' or 'deny'[/red]")
        raise typer.Exit(1)

    if not any([direction, protocol, action, port_min, port_max, remote_ip, priority, description]):
        console.print("[red]Error: At least one field must be provided for update[/red]")
        raise typer.Exit(1)

    try:
        client = APIClient(api_type=api)

        payload: dict[str, Any] = {}
        if direction:
            payload["direction"] = direction
        if protocol:
            payload["protocol"] = protocol
        if action:
            payload["action"] = action
        if port_min is not None:
            payload["port_range_min"] = port_min
        if port_max is not None:
            payload["port_range_max"] = port_max
        if remote_ip:
            payload["remote_ip_prefix"] = remote_ip
        if priority is not None:
            payload["priority"] = priority
        if description:
            payload["description"] = description

        response = client.patch(f"/api/v1/firewalls/{firewall_id}/rules/{rule_id}", data=payload)

        if response.status_code == 200:
            data_response = response.json()
            rule = _unwrap_response(data_response)
            console.print("\n[green]✓[/green] Firewall rule updated successfully!")
            console.print(f"Rule ID:    [cyan]{rule.get('id')}[/cyan]")
            console.print(f"Direction:  [yellow]{rule.get('direction')}[/yellow]")
            console.print(f"Protocol:   [magenta]{rule.get('protocol')}[/magenta]")
            console.print(f"Action:     [blue]{rule.get('action')}[/blue]")
            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@rules_app.command("delete")
def delete_rule(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    rule_id: str = typer.Argument(..., help="Rule ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Delete a firewall rule.

    Remove a rule from the specified firewall.
    """
    if api is None:
        api = get_default_api_type()

    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete rule {rule_id} from firewall {firewall_id}?")
        if not confirm:
            console.print("[yellow]Deletion cancelled[/yellow]")
            raise typer.Abort()

    try:
        client = APIClient(api_type=api)
        response = client.delete(f"/api/v1/firewalls/{firewall_id}/rules/{rule_id}")

        if response.status_code in [200, 204]:
            console.print(f"[green]✓[/green] Rule {rule_id} deleted successfully from firewall {firewall_id}")

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


# Additional utility commands


@app.command("by-name")
def get_firewall_by_name(
    name: str = typer.Argument(..., help="Firewall name"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Get firewall by name.

    Find and display a firewall by its name.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/firewalls/by-name?name={name}")

        if response.status_code == 200:
            data = response.json()
            firewall = _unwrap_response(data)

            console.print("\n[bold]Firewall Details[/bold]")
            console.print("─" * 80)
            console.print(f"ID:          [cyan]{firewall.get('id', 'N/A')}[/cyan]")
            console.print(f"Name:        [green]{firewall.get('name', 'N/A')}[/green]")
            console.print(f"Description: {firewall.get('description', 'N/A')}")
            console.print(f"Created:     [dim]{firewall.get('created_at', 'N/A')}[/dim]")
            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command("clusters")
def get_firewall_clusters(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """List clusters using a firewall.

    Display all clusters that are using the specified firewall.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/firewalls/{firewall_id}/clusters")

        if response.status_code == 200:
            data = response.json()
            clusters = _unwrap_response(data)

            # Handle case where clusters might still be wrapped or be a dict
            if isinstance(clusters, dict):
                # If it's still a dict, it might have a 'clusters' key or similar
                if "clusters" in clusters:
                    clusters = clusters["clusters"]
                else:
                    # Unexpected format, show what we got
                    console.print("[red]Error: Unexpected response format[/red]")
                    console.print(f"[dim]Response keys: {list(clusters.keys())}[/dim]")
                    raise typer.Exit(1)

            if not isinstance(clusters, list):
                console.print(f"[red]Error: Expected list, got {type(clusters).__name__}[/red]")
                raise typer.Exit(1)

            if not clusters:
                console.print(f"[yellow]No clusters using firewall {firewall_id}[/yellow]")
                return

            # Log raw cluster data for debugging
            logger.debug(f"Raw cluster data: {json.dumps(clusters, indent=2)}")

            table = Table(title=f"Clusters Using Firewall {firewall_id}")
            table.add_column("Cluster ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Provider", style="blue")

            for cluster in clusters:
                # Support both cluster_id and id, cluster_name and name
                cluster_id_val = cluster.get("cluster_id") or cluster.get("id", "N/A")
                cluster_name_val = cluster.get("cluster_name") or cluster.get("name", "N/A")

                table.add_row(
                    str(cluster_id_val),
                    cluster_name_val,
                    cluster.get("status", "N/A"),
                    cluster.get("provider", "N/A"),
                )

            console.print(table)
            console.print(f"\n[dim]Total: {len(clusters)} cluster(s)[/dim]")

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None


@app.command("validate-deletion")
def validate_firewall_deletion(
    firewall_id: str = typer.Argument(..., help="Firewall ID"),
    api: str | None = typer.Option(
        None, "--api", "-a", help="API type (admin or user). Uses default if not specified."
    ),
) -> None:
    """Validate if a firewall can be deleted.

    Check if a firewall can be safely deleted without affecting active clusters.
    """
    if api is None:
        api = get_default_api_type()

    try:
        client = APIClient(api_type=api)
        response = client.get(f"/api/v1/firewalls/{firewall_id}/validate-deletion")

        if response.status_code == 200:
            data = response.json()
            result = _unwrap_response(data)

            can_delete = result.get("can_delete", False)
            reasons = result.get("reasons", [])

            console.print(f"\n[bold]Deletion Validation for Firewall {firewall_id}[/bold]")
            console.print("─" * 80)

            if can_delete:
                console.print("[green]✓ Firewall can be safely deleted[/green]")
            else:
                console.print("[red]✗ Firewall cannot be deleted[/red]")
                console.print("\n[yellow]Reasons:[/yellow]")
                for reason in reasons:
                    console.print(f"  • {reason}")

            console.print()

        else:
            _print_error(response)
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise typer.Exit(1) from None
