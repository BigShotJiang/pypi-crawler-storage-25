"""Main CLI application entry point."""

import logging

import typer
from rich.console import Console
from rich.logging import RichHandler

from . import __version__
from .commands import auth, clusters, feedback, firewalls, orders, products, support, users
from .commands.admin import app as admin_app
from .config import ENVIRONMENTS, get_current_environment, set_environment

app = typer.Typer(
    name="pbd",
    help="PBD API CLI - Command line client for PBD Admin and User APIs",
    add_completion=True,
)
console = Console()

# Global state for verbose logging
_verbose_enabled = False


def setup_logging(verbose: bool = False) -> None:
    """Configure logging for the CLI.

    Args:
        verbose: If True, enable DEBUG level logging with detailed output
    """
    global _verbose_enabled
    _verbose_enabled = verbose

    level = logging.DEBUG if verbose else logging.WARNING

    # Configure root logger with Rich handler for beautiful output
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True, show_path=verbose)],
    )

    # Set specific loggers
    logger = logging.getLogger("proxy_platform")
    logger.setLevel(level)

    if verbose:
        logger.debug("Verbose logging enabled")


@app.callback()
def main_callback(
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose output with debug logging",
    ),
) -> None:
    """PBD CLI - Command line client for PBD Admin and User APIs.

    Use --verbose to see detailed debug output including API calls and responses.
    """
    setup_logging(verbose)


# Register command groups
app.add_typer(auth.app, name="auth", help="Authentication commands")
app.add_typer(feedback.app, name="feedback", help="Feedback portal commands")
app.add_typer(support.app, name="support", help="Support ticket commands")
app.add_typer(products.app, name="products", help="Product catalog commands")
app.add_typer(orders.app, name="orders", help="Order and payment management commands")
app.add_typer(clusters.app, name="clusters", help="Cluster management commands")
app.add_typer(firewalls.app, name="firewall", help="Firewall management commands")
app.add_typer(users.app, name="users", help="User management commands")
app.add_typer(admin_app, name="admin", help="Admin commands (for Proxy employees)")


@app.command()
def version() -> None:
    """Show CLI version."""
    console.print(f"PBD CLI version: [bold cyan]{__version__}[/bold cyan]")


@app.command()
def env(
    environment: str | None = typer.Argument(
        None,
        help="Environment to switch to (development, test, acceptance, production)",
    ),
    show: bool = typer.Option(
        False,
        "--show",
        "-s",
        help="Show current environment",
    ),
) -> None:
    """Manage environment settings.

    Switch between development, test, acceptance, and production environments.
    """
    if show or environment is None:
        current = get_current_environment()
        console.print(f"Current environment: [bold cyan]{current}[/bold cyan]")
        console.print("\nAvailable environments:")
        for env_name, urls in ENVIRONMENTS.items():
            marker = "→" if env_name == current else " "
            console.print(f"{marker} [yellow]{env_name}[/yellow]")
            console.print(f"    Admin API: {urls['admin_api']}")
            console.print(f"    User API:  {urls['user_api']}")
        return

    if environment not in ENVIRONMENTS:
        console.print(f"[red]Error: Invalid environment '{environment}'[/red]")
        console.print(f"Available: {', '.join(ENVIRONMENTS.keys())}")
        raise typer.Exit(1)

    set_environment(environment)
    console.print(f"[green]✓[/green] Switched to [bold cyan]{environment}[/bold cyan] environment")


# Convenience aliases for common commands
@app.command(name="login")
def login_alias(
    email: str | None = typer.Option(None, "--email", "-e", help="Email address"),
    password: str | None = typer.Option(None, "--password", "-p", help="Password"),
    api: str = typer.Option("user", "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Login to the API (alias for 'auth login')."""
    from .commands.auth import login as auth_login

    auth_login(email=email, password=password, api=api)


@app.command(name="logout")
def logout_alias() -> None:
    """Logout from the API (alias for 'auth logout')."""
    from .commands.auth import logout as auth_logout

    auth_logout()


@app.command(name="whoami")
def whoami_alias(
    api: str | None = typer.Option(None, "--api", "-a", help="API type (admin or user)"),
) -> None:
    """Show current user info (alias for 'auth whoami')."""
    from .commands.auth import whoami as auth_whoami

    auth_whoami(api=api)


if __name__ == "__main__":
    app()
