# PBD API CLI

A command-line client for interacting with the PBD platform.

## Distributions

This repository produces **two separate packages** from a single codebase:

| Package | Entry point | Audience | Admin commands |
|---------|-------------|----------|----------------|
| `proxy-platform` | `proxy_platform.main:app` | Proxy employees (internal) | ✅ Included |
| `proxy-platform-public` | `proxy_platform.main_public:app` | End users / customers | ❌ Excluded |

Both packages expose the same `pbd` command and share all user-facing functionality. The internal package additionally exposes `pbd admin` commands.

## Features

- 🔐 **Authentication** - Login, logout, and manage API tokens (with OTP/2FA support)
- 🌍 **Multi-environment** - Switch between development, test, acceptance, and production
- 🎯 **Dual API Support** - Separate Admin and User commands for clear access control
- 🖥️ **Cluster Management** - List, inspect, rename, delete, kubeconfig, and etcd key
- 🛒 **Orders & Payments** - Guided or fully non-interactive order creation
- 🔥 **Firewall Management** - Create and manage firewall rules
- 🎫 **Support Tickets** - Submit and track support requests
- 💬 **Feedback Portal** - Submit feature requests and vote on community feedback
- 📊 **Rich Output** - Beautiful tables and formatted output
- 🚀 **Easy to Use** - Intuitive command structure with shell completion
- 💾 **Token Storage** - Secure token management in `~/.proxy-platform/`
- 🐛 **Debug Mode** - Verbose logging with `--verbose` flag

## Installation

### Internal (Proxy employees)

```bash
pip install proxy-platform
```

Includes all commands including `pbd admin`.

### Public (customers)

```bash
pip install proxy-platform-public
```

Identical to the internal package but without `pbd admin`.

### Development setup

```bash
cd pbd-api-client
pip install -e ".[dev]"
pre-commit install
```

This installs the internal version (with admin) plus all dev tools, and activates the pre-commit hooks.

To test the public entry point locally:

```bash
python -m proxy_platform.main_public
```

### Pre-commit hooks

The following checks run automatically on every commit:

| Hook | When | What |
|------|------|------|
| ruff (lint + format) | Python files changed | Code style and formatting |
| mypy | Python files changed | Type checking |
| bandit | `proxy_platform/` files changed | Static security analysis |
| pip-audit | `pyproject*.toml` changed | Known CVEs in dependencies |
| conventional-commit | Every commit | Commit message format |

If a hook blocks your commit, fix the reported issue and commit again. To run all hooks manually:

```bash
pre-commit run --all-files
```

### Enable Shell Completion (Recommended)

```bash
pbd --install-completion
source ~/.zshrc  # or ~/.bashrc
```

## Quick Start

### 1. Set Environment

```bash
pbd env production    # Switch to production
pbd env development   # Switch to local dev
pbd env --show        # Show current environment
```

### 2. Login

```bash
pbd login
pbd login --email user@example.com --password mypassword
```

If your account has 2FA enabled, you'll be prompted for your OTP code automatically.

### 3. Deploy a Cluster

```bash
# Interactive (guided, recommended)
pbd orders create

# Fully non-interactive (all flags provided)
pbd orders create --tier "Starter Kit" --provider hetzner --region nbg1 --firewall "My firewall" --yes
```

After payment, your cluster is deployed automatically. Check status with:

```bash
pbd clusters list
pbd clusters get <cluster-id>
```

## Commands Reference

### Authentication

```bash
pbd login [--email EMAIL] [--password PASSWORD] [--api admin|user]
pbd logout
pbd whoami [--api admin|user]
pbd auth switch admin
pbd auth switch user
```

### Clusters

```bash
# List your clusters
pbd clusters list [--limit 10]

# Get cluster details
pbd clusters get <cluster-id>

# Rename a cluster (sets display name)
pbd clusters rename <cluster-id> --name "My cluster"

# Delete a cluster (shows what will be deleted, asks confirmation)
pbd clusters delete <cluster-id>
pbd clusters delete <cluster-id> --yes  # Skip confirmation

# Download kubeconfig
pbd clusters kubeconfig <cluster-id>
pbd clusters kubeconfig <cluster-id> --output ~/.kube/config

# Show etcd encryption key
pbd clusters etcd-key <cluster-id>

# Get deployment info for a cluster
pbd clusters deployment <cluster-id>

# Get firewall attached to a cluster
pbd clusters firewall <cluster-id>

# Assign or change the firewall on a cluster
pbd clusters assign-firewall <cluster-id> --firewall "My firewall"
pbd clusters assign-firewall <cluster-id>  # interactive selection
```

### Orders & Payments

Deployments are triggered automatically after successful payment.

```bash
# Create an order (interactive when no flags given)
pbd orders create

# Non-interactive (all steps via flags)
pbd orders create \
  --tier "Starter Kit" \
  --provider hetzner \
  --region nbg1 \
  --firewall "My firewall" \
  --yes

# Available flags:
#   --product   -p   Product ID (auto-selects if only one available)
#   --tier      -t   Pricing tier name or ID
#   --provider       Cloud provider (hetzner)
#   --region    -r   Region code (nbg1, fsn1, hel1, ash)
#   --firewall  -f   Firewall name or ID
#   --no-firewall    Deploy without firewall
#   --yes       -y   Accept terms without prompting

# List your orders
pbd orders list [--limit 10]

# Get order details
pbd orders get <order-id>
```

In **development mode**, payment is simulated automatically after order creation. In **production**, a Mollie payment URL is shown.

### Firewalls

```bash
# List all firewalls
pbd firewall list

# Get firewall details (including rules)
pbd firewall get <firewall-id>

# Get firewall by name
pbd firewall by-name <firewall-name>

# Create a firewall
pbd firewall create --name my-firewall --description "Production firewall"

# Update a firewall
pbd firewall update <firewall-id> --name new-name

# Delete a firewall
pbd firewall delete <firewall-id>
pbd firewall delete <firewall-id> --force  # Skip confirmation

# List clusters using a firewall
pbd firewall clusters <firewall-id>

# Firewall rules
pbd firewall rules list <firewall-id>
pbd firewall rules create <firewall-id> --direction inbound --protocol tcp --port-min 443 --port-max 443 --remote-ip 0.0.0.0/0
pbd firewall rules delete <firewall-id> <rule-id>
```

### Products

```bash
pbd products list [--limit 50]
pbd products get <product-id>
pbd products get f25bea71   # Partial IDs are resolved automatically
```

### Users

```bash
pbd users profile
pbd users stats
pbd users activities [--limit 10]
pbd users orders [--limit 10]
pbd users verification
```

### Support

```bash
pbd support submit --subject "Cannot access cluster" --description "Getting 403 error" --category technical
pbd support list [--category technical] [--status open]
pbd support get <ticket-id>
pbd support reply <ticket-id> --content "Additional info"
pbd support close <ticket-id> [--yes]
```

Valid categories: `general`, `billing`, `technical`, `other`
Valid statuses: `open`, `in_progress`, `closed`

### Feedback

```bash
pbd feedback submit --title "Feature request" --description "..." --category feature
pbd feedback list [--category feature] [--status open]
pbd feedback get <feedback-id>
pbd feedback vote <feedback-id>
pbd feedback unvote <feedback-id>
pbd feedback comment <feedback-id> --content "I need this too"
```

### Admin Commands (Proxy employees only)

```bash
pbd admin login
pbd admin clusters [--limit 10]
pbd admin users [--limit 50] [--search "email@example.com"]
pbd admin orders [--limit 50] [--status paid]
```

Admin and user sessions are independent — you can be logged in as both simultaneously.

### Development Commands (Local only)

These commands are blocked outside the `development` environment.

```bash
pbd dev simulate-payment <order-id> [--status paid|failed]
pbd dev trigger-deployment <order-id>
```

### Environment

```bash
pbd env development
pbd env test
pbd env acceptance
pbd env production
pbd env --show
```

### General

```bash
pbd version
pbd --help
pbd clusters --help
```

## Environment Configuration

| Environment | Admin API | User API |
|-------------|-----------|----------|
| **development** | http://localhost:8001 | http://localhost:8002 |
| **test** | https://admin-api.tst.pbd.proxy.nl | https://api.tst.pbd.proxy.nl |
| **acceptance** | https://admin-api.acc.pbd.proxy.nl | https://api.acc.pbd.proxy.nl |
| **production** | https://admin-api.prd.pbd.proxy.nl | https://api.platform.proxy.nl |

## Configuration

Tokens and settings are stored in `~/.proxy-platform/`:

```
~/.proxy-platform/
├── config.json    # Environment and default API settings
└── tokens.json    # Authentication tokens (per environment, 0600)
```

## Project Structure

```
pbd-api-client/
├── pyproject.toml          # Internal distribution (proxy-platform, includes admin)
├── pyproject.public.toml   # Public distribution (proxy-platform-public, no admin)
└── proxy_platform/
    ├── main.py             # Internal CLI entry point
    ├── main_public.py      # Public CLI entry point (no admin)
    ├── config.py
    ├── client.py
    └── commands/
        ├── auth.py
        ├── clusters.py
        ├── feedback.py
        ├── firewalls.py
        ├── orders.py
        ├── products.py
        ├── support.py
        ├── users.py
        └── admin/          # Only included in proxy-platform (internal)
```

## Troubleshooting

```bash
# Debug mode — shows all API calls and responses
pbd --verbose <command>

# Re-authenticate
pbd logout && pbd login

# Check environment
pbd env --show
```

## Requirements

- Python 3.11+

## License

Internal use only — PBD Development Team
