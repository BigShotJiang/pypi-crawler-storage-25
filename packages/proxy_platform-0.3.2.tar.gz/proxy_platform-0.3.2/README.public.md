# Proxy Platform CLI

A command-line client for the Proxy Platform.

## Installation

```bash
pipx install proxy-platform
```

Or with pip:

```bash
pip install proxy-platform
```

## Quick Start

```bash
# Show available commands
proxy-platform --help

# Log in
proxy-platform login

# Browse the product catalog
proxy-platform products list

# Create an order
proxy-platform orders create

# List your clusters
proxy-platform clusters list

# View your profile
proxy-platform users profile
```

## Commands

| Command group | Purpose |
|---------------|---------|
| `auth` | Login, logout, and session management |
| `products` | Browse the product catalog |
| `orders` | Create and manage orders |
| `clusters` | Manage your clusters |
| `firewall` | Manage firewall rules |
| `users` | View and update your profile |
| `support` | Open and track support tickets |
| `feedback` | Submit feedback |

Run any command with `--help` for usage details:

```bash
proxy-platform clusters --help
proxy-platform orders create --help
```

## Shell Completion

Enable tab completion in your shell:

```bash
proxy-platform --install-completion
```

## Configuration

Configuration and tokens are stored in `~/.proxy-platform/`. Tokens are saved with `0600` permissions and refreshed automatically.

## Requirements

- Python 3.11 or newer

## License

Proprietary. © Proxy Platform B.V.
