"""Tests for user commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.users import (
    get_activities,
    get_orders,
    get_profile,
    get_stats,
    get_verification_status,
)


class TestGetProfile:
    """Test cases for get_profile command."""

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_profile_success_full(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting profile with full details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "user-123",
            "email": "test@example.com",
            "first_name": "John",
            "last_name": "Doe",
            "company_name": "Test Company",
            "phone": "+1234567890",
            "is_admin": True,
            "created_at": "2024-01-01",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_profile(api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/users/profile")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_profile_minimal(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting profile with minimal details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "user-456",
            "email": "minimal@example.com",
            # No other fields
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_profile(api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_profile_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting profile with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "admin-789",
            "email": "admin@example.com",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_profile(api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_profile_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting profile with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"detail": "Unauthorized"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_profile(api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_profile_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting profile with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_profile(api=None)

        assert exc_info.value.exit_code == 1


class TestGetStats:
    """Test cases for get_stats command."""

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_stats_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting stats successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_orders": 5,
            "total_spent": 150.50,
            "active_clusters": 2,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_stats(api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/users/stats")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_stats_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting stats with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_orders": 3,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_stats(api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_stats_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting stats with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_stats(api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_stats_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting stats with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_stats(api=None)

        assert exc_info.value.exit_code == 1


class TestGetActivities:
    """Test cases for get_activities command."""

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_activities_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting activities successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "activity-1",
                    "activity_type": "login",
                    "description": "User logged in",
                    "created_at": "2024-01-01",
                }
            ],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_activities(limit=10, api=None)

        mock_client_instance.get.assert_called_once_with("/api/v1/users/activities?limit=10")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_activities_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting activities with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [{"id": "1", "activity_type": "test", "description": "Test", "created_at": "2024-01-01"}],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_activities(limit=5, api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_activities_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting activities with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [],
            "total": 0,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_activities(limit=10, api=None)

        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No activities found" in printed_output

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_activities_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting activities with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_activities(limit=10, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_activities_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting activities with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_activities(limit=10, api=None)

        assert exc_info.value.exit_code == 1


class TestGetOrders:
    """Test cases for get_orders command."""

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_orders_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting orders successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "order-1",
                    "status": "completed",
                    "total_amount": 25.50,
                    "created_at": "2024-01-01",
                }
            ],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_orders(limit=10, api=None)

        mock_client_instance.get.assert_called_once_with("/api/v1/users/orders?limit=10")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_orders_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting orders with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [{"id": "order-2", "status": "pending", "total_amount": 10.00, "created_at": "2024-01-02"}],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_orders(limit=20, api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_orders_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting orders with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [],
            "total": 0,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_orders(limit=10, api=None)

        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No orders found" in printed_output

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_orders_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting orders with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_orders(limit=10, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_orders_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting orders with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_orders(limit=10, api=None)

        assert exc_info.value.exit_code == 1


class TestGetVerificationStatus:
    """Test cases for get_verification_status command."""

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_verification_status_success_with_bools(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting verification status with boolean values."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email_verified": True,
            "phone_verified": False,
            "identity_verified": True,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_verification_status(api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/users/verification-status")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_verification_status_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting verification status with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email_verified": True,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_verification_status(api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_verification_status_success_with_strings(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting verification status with string values."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "verification_level": "basic",
            "last_verified": "2024-01-01",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_verification_status(api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_verification_status_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting verification status with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_verification_status(api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.users.get_default_api_type")
    @patch("proxy_platform.commands.users.APIClient")
    @patch("proxy_platform.commands.users.console")
    def test_get_verification_status_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting verification status with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_verification_status(api=None)

        assert exc_info.value.exit_code == 1
