"""Tests for admin feedback commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.admin.feedback import (
    delete_comment,
    delete_feedback,
    get_feedback,
    list_feedback,
    update_feedback,
)

SAMPLE_FEEDBACK = {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "title": "Add dark mode",
    "description": "Please add dark mode support",
    "category": "feature_request",
    "status": "open",
    "vote_count": 5,
    "user_has_voted": False,
    "user_name": "Test User",
    "user_email": "test@example.com",
    "jira_ticket": None,
    "solved_in_release": None,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
}

SAMPLE_COMMENT = {
    "id": "comment-uuid-1234",
    "feedback_id": "550e8400-e29b-41d4-a716-446655440000",
    "user_id": "user-uuid-1234",
    "user_name": "Test User",
    "content": "Great idea!",
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
}

SAMPLE_PAGINATED_RESPONSE = {
    "data": [SAMPLE_FEEDBACK],
    "total": 1,
    "page": 1,
    "limit": 25,
    "offset": 0,
    "has_next": False,
    "has_previous": False,
}


class TestAdminListFeedback:
    """Test cases for admin list_feedback command."""

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback successfully."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_PAGINATED_RESPONSE
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=25, page=1, category=None, status=None)

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.get.assert_called_once_with("/admin/feedback", params={"per_page": 25, "page": 1})
        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_with_filters(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback with category and status filters."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_PAGINATED_RESPONSE
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=10, page=2, category="bug_report", status="open")

        mock_client_instance.get.assert_called_once_with(
            "/admin/feedback",
            params={"per_page": 10, "page": 2, "category": "bug_report", "status": "open"},
        )

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_with_all_status_types(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback with solved status (shows solved items)."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        solved_item = dict(SAMPLE_FEEDBACK)
        solved_item["status"] = "solved"
        mock_response.json.return_value = {
            "data": [SAMPLE_FEEDBACK, solved_item],
            "total": 2,
            "page": 1,
            "limit": 25,
            "offset": 0,
            "has_next": False,
            "has_previous": False,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=25, page=1, category=None, status="solved")

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_empty(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback when no items found."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [],
            "total": 0,
            "page": 1,
            "limit": 25,
            "offset": 0,
            "has_next": False,
            "has_previous": False,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=25, page=1, category=None, status=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback with error response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=25, page=1, category=None, status=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_list_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test listing feedback with exception."""
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=25, page=1, category=None, status=None)

        assert exc_info.value.exit_code == 1


class TestAdminGetFeedback:
    """Test cases for admin get_feedback command."""

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_get_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test getting feedback successfully."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_FEEDBACK
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000")

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.get.assert_called_once_with("/admin/feedback/550e8400-e29b-41d4-a716-446655440000")
        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_get_feedback_with_comments_and_extra_fields(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test getting feedback with comments, jira ticket, and release info."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        feedback_with_extras = dict(SAMPLE_FEEDBACK)
        feedback_with_extras["jira_ticket"] = "PBD-456"
        feedback_with_extras["solved_in_release"] = "v3.0"
        feedback_with_extras["comments"] = [SAMPLE_COMMENT]
        mock_response.json.return_value = feedback_with_extras
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000")

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_get_feedback_no_comments(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test getting feedback with no comments."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        no_comments = dict(SAMPLE_FEEDBACK)
        no_comments["comments"] = []
        mock_response.json.return_value = no_comments
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_feedback(feedback_id="some-id")

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_get_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test getting feedback with error response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_feedback(feedback_id="nonexistent-id")

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_get_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test getting feedback with exception."""
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            get_feedback(feedback_id="some-id")

        assert exc_info.value.exit_code == 1


class TestAdminUpdateFeedback:
    """Test cases for admin update_feedback command."""

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test updating feedback successfully."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        updated = dict(SAMPLE_FEEDBACK)
        updated["status"] = "solved"
        updated["jira_ticket"] = "PBD-123"
        mock_response.json.return_value = updated
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        update_feedback(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            data='{"status": "solved", "jira_ticket": "PBD-123"}',
        )

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.put.assert_called_once_with(
            "/admin/feedback/550e8400-e29b-41d4-a716-446655440000",
            data={"status": "solved", "jira_ticket": "PBD-123"},
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_204_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test updating feedback with 204 No Content response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        update_feedback(
            feedback_id="some-id",
            data='{"status": "open"}',
        )

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_with_all_fields(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test updating feedback with all possible fields."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = dict(SAMPLE_FEEDBACK)
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        update_feedback(
            feedback_id="some-id",
            data='{"status": "solved", "jira_ticket": "PBD-999", "solved_in_release": "v2.0", "title": "New title", "description": "New desc", "category": "improvement"}',
        )

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_invalid_json(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test updating feedback with invalid JSON."""
        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                data="not valid json",
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_invalid_status(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test updating feedback with invalid status value."""
        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                data='{"status": "invalid_status"}',
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_invalid_category(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test updating feedback with invalid category value."""
        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                data='{"category": "invalid_category"}',
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test updating feedback with error response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="nonexistent-id",
                data='{"status": "solved"}',
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_update_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test updating feedback with exception."""
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                data='{"status": "solved"}',
            )

        assert exc_info.value.exit_code == 1


class TestAdminDeleteFeedback:
    """Test cases for admin delete_feedback command."""

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_feedback_success_with_yes(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback successfully with --yes flag."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "Feedback deleted"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000", yes=True)

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.delete.assert_called_once_with("/admin/feedback/550e8400-e29b-41d4-a716-446655440000")
        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_feedback_204_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback with 204 No Content response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_feedback(feedback_id="some-id", yes=True)

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    @patch("proxy_platform.commands.admin.feedback.typer.confirm")
    def test_delete_feedback_cancelled(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback when user cancels confirmation."""
        mock_confirm.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="some-id", yes=False)

        assert exc_info.value.exit_code == 0

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    @patch("proxy_platform.commands.admin.feedback.typer.confirm")
    def test_delete_feedback_confirmed(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback when user confirms."""
        mock_confirm.return_value = True
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_feedback(feedback_id="some-id", yes=False)

        mock_client_instance.delete.assert_called_once()

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback with error response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="nonexistent-id", yes=True)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting feedback with exception."""
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="some-id", yes=True)

        assert exc_info.value.exit_code == 1


class TestAdminDeleteComment:
    """Test cases for admin delete_comment command."""

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_comment_success_with_yes(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment successfully with --yes flag."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "Comment deleted"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_comment(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            comment_id="comment-uuid-1234",
            yes=True,
        )

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.delete.assert_called_once_with(
            "/admin/feedback/550e8400-e29b-41d4-a716-446655440000/comments/comment-uuid-1234"
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_comment_204_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment with 204 No Content response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_comment(
            feedback_id="some-id",
            comment_id="comment-id",
            yes=True,
        )

        assert mock_console.print.called

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    @patch("proxy_platform.commands.admin.feedback.typer.confirm")
    def test_delete_comment_cancelled(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment when user cancels."""
        mock_confirm.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                yes=False,
            )

        assert exc_info.value.exit_code == 0

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    @patch("proxy_platform.commands.admin.feedback.typer.confirm")
    def test_delete_comment_confirmed(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment when user confirms."""
        mock_confirm.return_value = True
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_comment(
            feedback_id="some-id",
            comment_id="comment-id",
            yes=False,
        )

        mock_client_instance.delete.assert_called_once()

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_comment_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment with error response."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(
                feedback_id="some-id",
                comment_id="nonexistent-id",
                yes=True,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.admin.feedback.APIClient")
    @patch("proxy_platform.commands.admin.feedback.console")
    def test_delete_comment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test deleting comment with exception."""
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                yes=True,
            )

        assert exc_info.value.exit_code == 1
