"""Tests for firewall commands."""

from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest
from typer.testing import CliRunner

from proxy_platform.main import app

runner = CliRunner()


# Test data fixtures
@pytest.fixture
def sample_firewall() -> dict[str, Any]:
    """Sample firewall data."""
    return {
        "id": 1,
        "name": "web-firewall",
        "description": "Firewall for web servers",
        "created_at": "2025-12-14T10:00:00Z",
        "updated_at": "2025-12-14T10:00:00Z",
        "rules": [
            {
                "id": 1,
                "direction": "ingress",
                "protocol": "tcp",
                "port_range_min": 80,
                "port_range_max": 80,
                "remote_ip_prefix": "0.0.0.0/0",
                "action": "allow",
                "priority": 100,
            },
            {
                "id": 2,
                "direction": "ingress",
                "protocol": "tcp",
                "port_range_min": 443,
                "port_range_max": 443,
                "remote_ip_prefix": "0.0.0.0/0",
                "action": "allow",
                "priority": 100,
            },
        ],
    }


@pytest.fixture
def sample_firewall_list() -> list[dict[str, Any]]:
    """Sample firewall list data."""
    return [
        {
            "id": 1,
            "name": "web-firewall",
            "description": "Firewall for web servers",
            "created_at": "2025-12-14T10:00:00Z",
            "rules": [],
        },
        {
            "id": 2,
            "name": "db-firewall",
            "description": "Firewall for database servers",
            "created_at": "2025-12-14T11:00:00Z",
            "rules": [],
        },
    ]


# Firewall list tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_firewalls_success(mock_api_client: MagicMock, sample_firewall_list: list[dict[str, Any]]) -> None:
    """Test listing firewalls successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = sample_firewall_list
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 0
    assert "web-firewall" in result.stdout
    assert "db-firewall" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_firewalls_empty(mock_api_client: MagicMock) -> None:
    """Test listing firewalls when none exist."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = []
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 0
    assert "No firewalls found" in result.stdout


# Firewall get tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_success(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test getting a firewall by ID successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = sample_firewall
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "get", "1"])

    assert result.exit_code == 0
    assert "web-firewall" in result.stdout
    assert "Firewall Rules (2)" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_not_found(mock_api_client: MagicMock) -> None:
    """Test getting a non-existent firewall."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "get", "999"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


# Firewall create tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_success(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test creating a firewall successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = sample_firewall
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "web-firewall"])

    assert result.exit_code == 0
    assert "Firewall created successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_with_description(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test creating a firewall with description."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = sample_firewall
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "web-firewall", "--description", "Test firewall"])

    assert result.exit_code == 0
    assert "Firewall created successfully" in result.stdout


# Firewall update tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_success(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test updating a firewall successfully."""
    updated_firewall = sample_firewall.copy()
    updated_firewall["name"] = "updated-firewall"

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = updated_firewall
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "update", "1", "--name", "updated-firewall"])

    assert result.exit_code == 0
    assert "Firewall updated successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_no_fields(mock_api_client: MagicMock) -> None:
    """Test updating a firewall without providing any fields."""
    result = runner.invoke(app, ["firewall", "update", "1"])

    assert result.exit_code == 1
    assert "At least one of --name or --description must be provided" in result.stdout


# Firewall delete tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_success(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "1", "--force"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_cancel(mock_api_client: MagicMock) -> None:
    """Test canceling firewall deletion."""
    result = runner.invoke(app, ["firewall", "delete", "1"], input="n\n")

    assert result.exit_code == 1


# Firewall rules list tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_success(mock_api_client: MagicMock) -> None:
    """Test listing firewall rules successfully."""
    rules = [
        {
            "id": 1,
            "direction": "ingress",
            "protocol": "tcp",
            "port_range_min": 80,
            "port_range_max": 80,
            "remote_ip_prefix": "0.0.0.0/0",
            "action": "allow",
            "priority": 100,
        },
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rules
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "1"])

    assert result.exit_code == 0
    assert "ingress" in result.stdout
    assert "tcp" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_empty(mock_api_client: MagicMock) -> None:
    """Test listing rules when none exist."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = []
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "1"])

    assert result.exit_code == 0
    assert "No rules found" in result.stdout


# Firewall rules create tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_success(mock_api_client: MagicMock) -> None:
    """Test creating a firewall rule successfully."""
    rule = {
        "id": 1,
        "direction": "ingress",
        "protocol": "tcp",
        "port_range_min": 22,
        "port_range_max": 22,
        "remote_ip_prefix": "10.0.0.0/8",
        "action": "allow",
        "priority": 100,
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = rule
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        [
            "firewall",
            "rules",
            "create",
            "1",
            "--direction",
            "ingress",
            "--protocol",
            "tcp",
            "--port-min",
            "22",
            "--port-max",
            "22",
        ],
    )

    assert result.exit_code == 0
    assert "Firewall rule created successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_invalid_direction(mock_api_client: MagicMock) -> None:
    """Test creating a rule with invalid direction."""
    result = runner.invoke(app, ["firewall", "rules", "create", "1", "--direction", "invalid", "--protocol", "tcp"])

    assert result.exit_code == 1
    assert "Direction must be" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_invalid_protocol(mock_api_client: MagicMock) -> None:
    """Test creating a rule with invalid protocol."""
    result = runner.invoke(app, ["firewall", "rules", "create", "1", "--direction", "ingress", "--protocol", "invalid"])

    assert result.exit_code == 1
    assert "Protocol must be" in result.stdout


# Firewall rules update tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_success(mock_api_client: MagicMock) -> None:
    """Test updating a firewall rule successfully."""
    rule = {
        "id": 1,
        "direction": "ingress",
        "protocol": "tcp",
        "port_range_min": 2222,
        "port_range_max": 2222,
        "remote_ip_prefix": "10.0.0.0/8",
        "action": "allow",
        "priority": 100,
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rule
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1", "--port-min", "2222"])

    assert result.exit_code == 0
    assert "Firewall rule updated successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_no_fields(mock_api_client: MagicMock) -> None:
    """Test updating a rule without providing any fields."""
    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1"])

    assert result.exit_code == 1
    assert "At least one field must be provided for update" in result.stdout


# Firewall rules delete tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_success(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall rule successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1", "--force"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_cancel(mock_api_client: MagicMock) -> None:
    """Test canceling rule deletion."""
    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1"], input="n\n")

    assert result.exit_code == 1


# Additional firewall commands tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_by_name_success(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test getting a firewall by name successfully."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = sample_firewall
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "by-name", "web-firewall"])

    assert result.exit_code == 0
    assert "web-firewall" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_clusters(mock_api_client: MagicMock) -> None:
    """Test getting clusters using a firewall."""
    clusters = [
        {"id": 1, "name": "web-cluster", "status": "running", "created_at": "2025-12-14T10:00:00Z"},
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = clusters
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "clusters", "1"])

    assert result.exit_code == 0
    assert "web-cluster" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_validate_deletion_can_delete(mock_api_client: MagicMock) -> None:
    """Test validating firewall deletion when it can be deleted."""
    validation_result = {"can_delete": True, "reasons": []}

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = validation_result
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "validate-deletion", "1"])

    assert result.exit_code == 0
    assert "can be safely deleted" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_validate_deletion_cannot_delete(mock_api_client: MagicMock) -> None:
    """Test validating firewall deletion when it cannot be deleted."""
    validation_result = {
        "can_delete": False,
        "reasons": ["Firewall is in use by 2 active clusters"],
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = validation_result
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "validate-deletion", "1"])

    assert result.exit_code == 0
    assert "cannot be deleted" in result.stdout
    assert "Firewall is in use by 2 active clusters" in result.stdout


# Error handling tests


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_firewalls_api_error(mock_api_client: MagicMock) -> None:
    """Test listing firewalls with API error."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=500)
    mock_response.json.return_value = {"detail": "Internal server error"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 1
    assert "Error: 500" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_firewalls_exception(mock_api_client: MagicMock) -> None:
    """Test listing firewalls with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_with_no_rules(mock_api_client: MagicMock) -> None:
    """Test getting a firewall with no rules."""
    firewall = {
        "id": 1,
        "name": "empty-firewall",
        "description": "No rules",
        "created_at": "2025-12-14T10:00:00Z",
        "updated_at": "2025-12-14T10:00:00Z",
        "rules": [],
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "get", "1"])

    assert result.exit_code == 0
    assert "No rules configured" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_exception(mock_api_client: MagicMock) -> None:
    """Test getting a firewall with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "get", "1"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_error(mock_api_client: MagicMock) -> None:
    """Test creating a firewall with API error."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=400)
    mock_response.json.return_value = {"detail": "Invalid firewall name"}
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "invalid@name"])

    assert result.exit_code == 1
    assert "Error: 400" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_exception(mock_api_client: MagicMock) -> None:
    """Test creating a firewall with exception."""
    mock_instance = MagicMock()
    mock_instance.post.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "test-firewall"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_not_found(mock_api_client: MagicMock) -> None:
    """Test updating a non-existent firewall."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "update", "999", "--name", "new-name"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_exception(mock_api_client: MagicMock) -> None:
    """Test updating a firewall with exception."""
    mock_instance = MagicMock()
    mock_instance.patch.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "update", "1", "--name", "new-name"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_with_confirmation(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall with user confirmation."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "1"], input="y\n")

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_not_found(mock_api_client: MagicMock) -> None:
    """Test deleting a non-existent firewall."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "999", "--force"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_exception(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall with exception."""
    mock_instance = MagicMock()
    mock_instance.delete.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "1", "--force"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_error(mock_api_client: MagicMock) -> None:
    """Test listing rules with API error."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "999"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_exception(mock_api_client: MagicMock) -> None:
    """Test listing rules with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "1"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_invalid_action(mock_api_client: MagicMock) -> None:
    """Test creating a rule with invalid action."""
    result = runner.invoke(
        app,
        [
            "firewall",
            "rules",
            "create",
            "1",
            "--direction",
            "ingress",
            "--protocol",
            "tcp",
            "--action",
            "invalid",
        ],
    )

    assert result.exit_code == 1
    assert "Action must be" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_exception(mock_api_client: MagicMock) -> None:
    """Test creating a rule with exception."""
    mock_instance = MagicMock()
    mock_instance.post.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "rules", "create", "1", "--direction", "ingress", "--protocol", "tcp"],
    )

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_invalid_direction(mock_api_client: MagicMock) -> None:
    """Test updating a rule with invalid direction."""
    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1", "--direction", "invalid"])

    assert result.exit_code == 1
    assert "Direction must be 'ingress' or 'egress'" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_invalid_protocol(mock_api_client: MagicMock) -> None:
    """Test updating a rule with invalid protocol."""
    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1", "--protocol", "invalid"])

    assert result.exit_code == 1
    assert "Protocol must be" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_invalid_action(mock_api_client: MagicMock) -> None:
    """Test updating a rule with invalid action."""
    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1", "--action", "invalid"])

    assert result.exit_code == 1
    assert "Action must be 'allow' or 'deny'" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_not_found(mock_api_client: MagicMock) -> None:
    """Test updating a non-existent rule."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Rule not found"}
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "update", "1", "999", "--priority", "50"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_exception(mock_api_client: MagicMock) -> None:
    """Test updating a rule with exception."""
    mock_instance = MagicMock()
    mock_instance.patch.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "update", "1", "1", "--priority", "50"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_with_confirmation(mock_api_client: MagicMock) -> None:
    """Test deleting a rule with user confirmation."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1"], input="y\n")

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_exception(mock_api_client: MagicMock) -> None:
    """Test deleting a rule with exception."""
    mock_instance = MagicMock()
    mock_instance.delete.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1", "--force"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_by_name_not_found(mock_api_client: MagicMock) -> None:
    """Test getting a firewall by name that doesn't exist."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "by-name", "nonexistent"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_by_name_exception(mock_api_client: MagicMock) -> None:
    """Test getting a firewall by name with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "by-name", "test-firewall"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_clusters_empty(mock_api_client: MagicMock) -> None:
    """Test getting clusters when firewall is not in use."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = []
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "clusters", "1"])

    assert result.exit_code == 0
    assert "No clusters using firewall" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_clusters_error(mock_api_client: MagicMock) -> None:
    """Test getting clusters with API error."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "clusters", "999"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_clusters_exception(mock_api_client: MagicMock) -> None:
    """Test getting clusters with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "clusters", "1"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_validate_deletion_not_found(mock_api_client: MagicMock) -> None:
    """Test validating deletion of non-existent firewall."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Firewall not found"}
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "validate-deletion", "999"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_validate_deletion_exception(mock_api_client: MagicMock) -> None:
    """Test validating deletion with exception."""
    mock_instance = MagicMock()
    mock_instance.get.side_effect = Exception("Connection error")
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "validate-deletion", "1"])

    assert result.exit_code == 1
    assert "Error:" in result.stdout


# Test with API selection


@patch("proxy_platform.commands.firewalls.get_default_api_type")
@patch("proxy_platform.commands.firewalls.APIClient")
def test_firewalls_with_default_api(mock_api_client: MagicMock, mock_get_default: MagicMock) -> None:
    """Test using default API type."""
    mock_get_default.return_value = "user"
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = []
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 0
    mock_get_default.assert_called()
    mock_api_client.assert_called_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_firewalls_with_admin_api(mock_api_client: MagicMock) -> None:
    """Test using admin API for firewall commands."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = []
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list", "--api", "admin"])

    assert result.exit_code == 0
    mock_api_client.assert_called_with(api_type="admin")


# Additional edge cases


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_firewalls_with_long_description(mock_api_client: MagicMock) -> None:
    """Test listing firewalls with long descriptions that get truncated."""
    firewalls = [
        {
            "id": 1,
            "name": "test-firewall",
            "description": "A" * 100,  # Very long description that will be truncated
            "created_at": "2025-12-14T10:00:00Z",
            "rules": [],
        },
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewalls
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "list"])

    assert result.exit_code == 0
    # Description should be in the output (may or may not be truncated depending on terminal width)
    assert "test-firewall" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_with_all_fields(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test creating a firewall with both name and description."""
    firewall_with_desc = sample_firewall.copy()
    firewall_with_desc["description"] = "Test description"

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = firewall_with_desc
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "web-firewall", "--description", "Test description"])

    assert result.exit_code == 0
    assert "Firewall created successfully" in result.stdout
    assert "Test description" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_description_only(mock_api_client: MagicMock, sample_firewall: dict[str, Any]) -> None:
    """Test updating only firewall description."""
    firewall_with_desc = sample_firewall.copy()
    firewall_with_desc["description"] = "New description"

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall_with_desc
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "update", "1", "--description", "New description"])

    assert result.exit_code == 0
    assert "Firewall updated successfully" in result.stdout
    assert "New description" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_200_status(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall with 200 status code."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "1", "--force"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_with_varying_ports(mock_api_client: MagicMock) -> None:
    """Test listing rules with different port range configurations."""
    rules = [
        {
            "id": 1,
            "direction": "ingress",
            "protocol": "tcp",
            "port_range_min": 80,
            "port_range_max": 80,  # Same min/max
            "remote_ip_prefix": "0.0.0.0/0",
            "action": "allow",
            "priority": 100,
        },
        {
            "id": 2,
            "direction": "ingress",
            "protocol": "tcp",
            "port_range_min": 8000,
            "port_range_max": 9000,  # Different min/max
            "remote_ip_prefix": "0.0.0.0/0",
            "action": "allow",
            "priority": 100,
        },
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rules
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "1"])

    assert result.exit_code == 0
    assert "80" in result.stdout
    assert "8000-9000" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_200_status(mock_api_client: MagicMock) -> None:
    """Test creating a rule with 200 status code."""
    rule = {
        "id": 1,
        "direction": "ingress",
        "protocol": "tcp",
        "port_range_min": 22,
        "port_range_max": 22,
        "remote_ip_prefix": "10.0.0.0/8",
        "action": "allow",
        "priority": 100,
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)  # 200 instead of 201
    mock_response.json.return_value = rule
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "rules", "create", "1", "--direction", "ingress", "--protocol", "tcp"],
    )

    assert result.exit_code == 0
    assert "Firewall rule created successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_200_status(mock_api_client: MagicMock) -> None:
    """Test deleting a rule with 200 status code."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)  # 200 instead of 204
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1", "--force"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout


# ============================================================================
# Additional Coverage Tests - Explicit API Parameter
# ============================================================================


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test getting a firewall with explicit --api parameter."""
    firewall = {
        "id": 1,
        "name": "test-fw",
        "description": "Test firewall",
        "rules": [],
        "created_at": "2024-01-01T00:00:00",
        "updated_at": "2024-01-01T00:00:00",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "get", "1", "--api", "user"])

    assert result.exit_code == 0
    assert "test-fw" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test creating a firewall with explicit --api parameter."""
    firewall = {"id": 1, "name": "new-fw"}

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = firewall
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "create", "--name", "new-fw", "--api", "admin"])

    assert result.exit_code == 0
    assert "created successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="admin")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test updating a firewall with explicit --api parameter."""
    firewall = {"id": 1, "name": "updated-fw"}

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "update", "1", "--name", "updated-fw", "--api", "user"])

    assert result.exit_code == 0
    assert "updated successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_firewall_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test deleting a firewall with explicit --api parameter."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "delete", "1", "--force", "--api", "admin"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="admin")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_list_rules_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test listing rules with explicit --api parameter."""
    rules = [
        {
            "id": 1,
            "direction": "ingress",
            "protocol": "tcp",
            "port_range_min": 22,
            "port_range_max": 22,
            "remote_ip_prefix": "0.0.0.0/0",
            "action": "allow",
            "priority": 100,
        }
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rules
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "list", "1", "--api", "user"])

    assert result.exit_code == 0
    assert "ingress" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test creating a rule with explicit --api parameter."""
    rule = {
        "id": 1,
        "direction": "ingress",
        "protocol": "tcp",
        "action": "allow",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = rule
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "rules", "create", "1", "--direction", "ingress", "--protocol", "tcp", "--api", "admin"],
    )

    assert result.exit_code == 0
    assert "created successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="admin")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test updating a rule with explicit --api parameter."""
    rule = {
        "id": 1,
        "direction": "egress",
        "protocol": "udp",
        "action": "allow",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rule
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "rules", "update", "1", "1", "--protocol", "udp", "--api", "user"],
    )

    assert result.exit_code == 0
    assert "updated successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test deleting a rule with explicit --api parameter."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=204)
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "1", "--force", "--api", "admin"])

    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout
    mock_api_client.assert_called_once_with(api_type="admin")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_by_name_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test getting a firewall by name with explicit --api parameter."""
    firewall = {
        "id": 1,
        "name": "test-fw",
        "description": "Test firewall",
        "created_at": "2024-01-01T00:00:00",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "by-name", "test-fw", "--api", "user"])

    assert result.exit_code == 0
    assert "test-fw" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_get_firewall_clusters_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test getting firewall clusters with explicit --api parameter."""
    clusters = [
        {
            "id": 1,
            "name": "test-cluster",
            "status": "running",
            "created_at": "2024-01-01T00:00:00",
        }
    ]

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = clusters
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "clusters", "1", "--api", "admin"])

    assert result.exit_code == 0
    assert "test-cluster" in result.stdout
    mock_api_client.assert_called_once_with(api_type="admin")


@patch("proxy_platform.commands.firewalls.APIClient")
def test_validate_firewall_deletion_with_explicit_api(mock_api_client: MagicMock) -> None:
    """Test validating firewall deletion with explicit --api parameter."""
    result_data = {"can_delete": True, "reasons": []}

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = result_data
    mock_instance.get.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "validate-deletion", "1", "--api", "user"])

    assert result.exit_code == 0
    assert "can be safely deleted" in result.stdout
    mock_api_client.assert_called_once_with(api_type="user")


# ============================================================================
# Additional Coverage Tests - Optional Response Fields
# ============================================================================


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_firewall_with_description_in_response(mock_api_client: MagicMock) -> None:
    """Test creating a firewall where API response includes description."""
    firewall = {
        "id": 1,
        "name": "new-fw",
        "description": "A new firewall with description",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = firewall
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "create", "--name", "new-fw", "--description", "A new firewall with description"],
    )

    assert result.exit_code == 0
    assert "created successfully" in result.stdout
    assert "A new firewall with description" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_firewall_with_description_in_response(mock_api_client: MagicMock) -> None:
    """Test updating a firewall where API response includes description."""
    firewall = {
        "id": 1,
        "name": "updated-fw",
        "description": "Updated description",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = firewall
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "update", "1", "--name", "updated-fw", "--description", "Updated description"],
    )

    assert result.exit_code == 0
    assert "updated successfully" in result.stdout
    assert "Updated description" in result.stdout


# ============================================================================
# Additional Coverage Tests - Optional Rule Fields
# ============================================================================


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_with_all_optional_fields(mock_api_client: MagicMock) -> None:
    """Test creating a rule with all optional fields (remote_ip, priority, description)."""
    rule = {
        "id": 1,
        "direction": "ingress",
        "protocol": "tcp",
        "port_range_min": 443,
        "port_range_max": 443,
        "remote_ip_prefix": "192.168.1.0/24",
        "action": "allow",
        "priority": 50,
        "description": "HTTPS access from internal network",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=201)
    mock_response.json.return_value = rule
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        [
            "firewall",
            "rules",
            "create",
            "1",
            "--direction",
            "ingress",
            "--protocol",
            "tcp",
            "--port-min",
            "443",
            "--port-max",
            "443",
            "--remote-ip",
            "192.168.1.0/24",
            "--priority",
            "50",
            "--description",
            "HTTPS access from internal network",
        ],
    )

    assert result.exit_code == 0
    assert "created successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_create_rule_error_response(mock_api_client: MagicMock) -> None:
    """Test creating a rule that returns an error response."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=400)
    mock_response.json.return_value = {"detail": "Invalid port range"}
    mock_instance.post.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        ["firewall", "rules", "create", "1", "--direction", "ingress", "--protocol", "tcp"],
    )

    assert result.exit_code == 1
    assert "Error: 400" in result.stdout
    assert "Invalid port range" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_update_rule_with_all_optional_fields(mock_api_client: MagicMock) -> None:
    """Test updating a rule with all optional fields."""
    rule = {
        "id": 1,
        "direction": "egress",
        "protocol": "udp",
        "port_range_min": 53,
        "port_range_max": 53,
        "remote_ip_prefix": "8.8.8.8/32",
        "action": "allow",
        "priority": 10,
        "description": "DNS queries to Google",
    }

    mock_instance = MagicMock()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = rule
    mock_instance.patch.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(
        app,
        [
            "firewall",
            "rules",
            "update",
            "1",
            "1",
            "--direction",
            "egress",
            "--protocol",
            "udp",
            "--action",
            "allow",
            "--port-min",
            "53",
            "--port-max",
            "53",
            "--remote-ip",
            "8.8.8.8/32",
            "--priority",
            "10",
            "--description",
            "DNS queries to Google",
        ],
    )

    assert result.exit_code == 0
    assert "updated successfully" in result.stdout


@patch("proxy_platform.commands.firewalls.APIClient")
def test_delete_rule_error_response(mock_api_client: MagicMock) -> None:
    """Test deleting a rule that returns an error response."""
    mock_instance = MagicMock()
    mock_response = Mock(status_code=404)
    mock_response.json.return_value = {"detail": "Rule not found"}
    mock_instance.delete.return_value = mock_response
    mock_api_client.return_value = mock_instance

    result = runner.invoke(app, ["firewall", "rules", "delete", "1", "999", "--force"])

    assert result.exit_code == 1
    assert "Error: 404" in result.stdout
    assert "Rule not found" in result.stdout
