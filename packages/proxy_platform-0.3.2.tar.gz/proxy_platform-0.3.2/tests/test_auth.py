"""Tests for authentication commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.auth import login, logout, switch, whoami


class TestLogin:
    """Test cases for login command."""

    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.save_tokens")
    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_success_admin_with_credentials(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
        mock_save_tokens: MagicMock,
        mock_set_default: MagicMock,
    ):
        """Test successful login with admin API and provided credentials."""
        mock_get_env.return_value = "local"
        mock_client_instance = MagicMock()
        mock_client_instance.login.return_value = {
            "access_token": "admin-token",
            "refresh_token": "admin-refresh",
        }
        mock_api_client.return_value = mock_client_instance

        login(email="admin@example.com", password="secret", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.login.assert_called_once_with("admin@example.com", "secret")
        mock_save_tokens.assert_called_once_with(admin_token="admin-token", admin_refresh="admin-refresh")
        mock_set_default.assert_called_once_with("admin")

    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.save_tokens")
    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_success_user_with_credentials(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
        mock_save_tokens: MagicMock,
        mock_set_default: MagicMock,
    ):
        """Test successful login with user API and provided credentials."""
        mock_get_env.return_value = "staging"
        mock_client_instance = MagicMock()
        mock_client_instance.login.return_value = {
            "access_token": "user-token",
            "refresh_token": "user-refresh",
        }
        mock_api_client.return_value = mock_client_instance

        login(email="user@example.com", password="password", api="user")

        mock_api_client.assert_called_once_with(api_type="user")
        mock_client_instance.login.assert_called_once_with("user@example.com", "password")
        mock_save_tokens.assert_called_once_with(user_token="user-token", user_refresh="user-refresh")
        mock_set_default.assert_called_once_with("user")

    @patch("proxy_platform.commands.auth.Prompt")
    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.save_tokens")
    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_prompts_for_missing_email(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
        mock_save_tokens: MagicMock,
        mock_set_default: MagicMock,
        mock_prompt: MagicMock,
    ):
        """Test login prompts for email when not provided."""
        mock_get_env.return_value = "local"
        mock_prompt.ask.side_effect = ["prompted@example.com", "prompted-pass"]
        mock_client_instance = MagicMock()
        mock_client_instance.login.return_value = {
            "access_token": "token",
            "refresh_token": "refresh",
        }
        mock_api_client.return_value = mock_client_instance

        login(email=None, password=None, api="user")

        # Should have prompted for both email and password
        assert mock_prompt.ask.call_count == 2
        mock_client_instance.login.assert_called_once_with("prompted@example.com", "prompted-pass")

    @patch("proxy_platform.commands.auth.Prompt")
    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.save_tokens")
    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_prompts_for_missing_password(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
        mock_save_tokens: MagicMock,
        mock_set_default: MagicMock,
        mock_prompt: MagicMock,
    ):
        """Test login prompts for password when not provided."""
        mock_get_env.return_value = "local"
        mock_prompt.ask.return_value = "prompted-password"
        mock_client_instance = MagicMock()
        mock_client_instance.login.return_value = {
            "access_token": "token",
            "refresh_token": "refresh",
        }
        mock_api_client.return_value = mock_client_instance

        login(email="user@example.com", password=None, api="user")

        # Should have prompted for password only
        mock_prompt.ask.assert_called_once()
        mock_client_instance.login.assert_called_once_with("user@example.com", "prompted-password")

    @patch("proxy_platform.commands.auth.console")
    def test_login_invalid_api_type(self, mock_console: MagicMock):
        """Test login with invalid API type."""
        with pytest.raises(typer.Exit) as exc_info:
            login(email="user@example.com", password="pass", api="invalid")

        assert exc_info.value.exit_code == 1
        assert mock_console.print.called

    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_failure(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
    ):
        """Test login failure."""
        mock_get_env.return_value = "local"
        mock_client_instance = MagicMock()
        mock_client_instance.login.side_effect = Exception("Invalid credentials")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            login(email="user@example.com", password="wrongpass", api="user")

        assert exc_info.value.exit_code == 1
        # Check that error message was printed
        assert any("Login failed" in str(call) for call in mock_console.print.call_args_list)

    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.save_tokens")
    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_login_without_refresh_token(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
        mock_save_tokens: MagicMock,
        mock_set_default: MagicMock,
    ):
        """Test login when refresh token is not returned."""
        mock_get_env.return_value = "local"
        mock_client_instance = MagicMock()
        mock_client_instance.login.return_value = {
            "access_token": "token",
            # No refresh_token
        }
        mock_api_client.return_value = mock_client_instance

        login(email="user@example.com", password="pass", api="user")

        mock_save_tokens.assert_called_once_with(user_token="token", user_refresh=None)


class TestLogout:
    """Test cases for logout command."""

    @patch("proxy_platform.commands.auth.clear_tokens")
    @patch("proxy_platform.commands.auth.console")
    def test_logout_success(self, mock_console: MagicMock, mock_clear_tokens: MagicMock):
        """Test successful logout."""
        logout()

        mock_clear_tokens.assert_called_once()
        assert mock_console.print.called


class TestWhoami:
    """Test cases for whoami command."""

    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.get_default_api_type")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_whoami_success_with_default_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
        mock_get_env: MagicMock,
    ):
        """Test whoami with default API type."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "local"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "first_name": "John",
            "last_name": "Doe",
            "email": "john@example.com",
            "id": "123",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        whoami(api=None)

        mock_get_default_api.assert_called_once()
        mock_api_client.assert_called_once_with(api_type="user")
        mock_client_instance.get.assert_called_once_with("/api/v1/users/profile")

    @patch("proxy_platform.commands.auth.get_current_environment")
    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_whoami_success_with_admin_user(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
    ):
        """Test whoami for admin user."""
        mock_get_env.return_value = "staging"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "first_name": "Admin",
            "last_name": "User",
            "email": "admin@example.com",
            "id": "456",
            "is_admin": True,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        whoami(api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        # Check that admin role was printed
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "Admin" in printed_output

    @patch("proxy_platform.commands.auth.console")
    def test_whoami_invalid_api_type(self, mock_console: MagicMock):
        """Test whoami with invalid API type."""
        with pytest.raises(typer.Exit) as exc_info:
            whoami(api="invalid")

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_whoami_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test whoami with error response from API."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"detail": "Unauthorized"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            whoami(api="user")

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.auth.APIClient")
    @patch("proxy_platform.commands.auth.console")
    def test_whoami_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test whoami with exception."""
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            whoami(api="user")

        assert exc_info.value.exit_code == 1


class TestSwitch:
    """Test cases for switch command."""

    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.console")
    def test_switch_to_admin(self, mock_console: MagicMock, mock_set_default: MagicMock):
        """Test switching to admin API."""
        switch(api="admin")

        mock_set_default.assert_called_once_with("admin")
        assert mock_console.print.called

    @patch("proxy_platform.commands.auth.set_default_api_type")
    @patch("proxy_platform.commands.auth.console")
    def test_switch_to_user(self, mock_console: MagicMock, mock_set_default: MagicMock):
        """Test switching to user API."""
        switch(api="user")

        mock_set_default.assert_called_once_with("user")
        assert mock_console.print.called

    @patch("proxy_platform.commands.auth.console")
    def test_switch_invalid_api_type(self, mock_console: MagicMock):
        """Test switch with invalid API type."""
        with pytest.raises(typer.Exit) as exc_info:
            switch(api="invalid")

        assert exc_info.value.exit_code == 1
