"""Tests for development commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.admin.dev import simulate_payment, trigger_deployment


class TestSimulatePayment:
    """Test cases for simulate_payment command."""

    @patch("proxy_platform.commands.admin.dev.get_current_environment")
    @patch("proxy_platform.commands.admin.dev.APIClient")
    @patch("proxy_platform.commands.admin.dev.console")
    def test_simulate_payment_success_with_full_order_id(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
    ):
        """Test simulating payment with full order ID."""
        mock_get_env.return_value = "development"

        # Will be called twice - once for admin, once for user
        mock_admin_client = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "deployment_triggered": False,
        }
        mock_admin_client.post.return_value = mock_response
        mock_api_client.return_value = mock_admin_client

        simulate_payment(
            order_id="order-uuid-123-456-789-012-345678901234",
            status="paid",
        )

        # Should use admin API
        mock_api_client.assert_called_with(api_type="admin")
        mock_admin_client.post.assert_called_once_with(
            "/api/v1/dev/simulate-payment",
            data={
                "order_id": "order-uuid-123-456-789-012-345678901234",
                "payment_status": "paid",
            },
        )

    @patch("proxy_platform.commands.admin.dev.get_current_environment")
    def test_simulate_payment_non_development_environment(
        self,
        mock_get_env: MagicMock,
    ):
        """Test that simulate_payment fails in non-development environment."""
        mock_get_env.return_value = "production"

        with pytest.raises(typer.Exit) as exc_info:
            simulate_payment(order_id="order-123", status="paid")

        assert exc_info.value.exit_code == 1


class TestTriggerDeployment:
    """Test cases for trigger_deployment command."""

    @patch("proxy_platform.commands.admin.dev.get_current_environment")
    @patch("proxy_platform.commands.admin.dev.APIClient")
    @patch("proxy_platform.commands.admin.dev.console")
    def test_trigger_deployment_success_with_full_order_id(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_env: MagicMock,
    ):
        """Test triggering deployment with full order ID."""
        mock_get_env.return_value = "development"

        mock_admin_client = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "deployment_result": {
                "deployment_id": "deploy-123",
                "status": "pending",
            },
        }
        mock_admin_client.post.return_value = mock_response
        mock_api_client.return_value = mock_admin_client

        trigger_deployment(order_id="order-uuid-123-456-789-012-345678901234")

        mock_api_client.assert_called_with(api_type="admin")
        mock_admin_client.post.assert_called_once_with(
            "/api/v1/dev/trigger-deployment",
            data={"order_id": "order-uuid-123-456-789-012-345678901234"},
        )

    @patch("proxy_platform.commands.admin.dev.get_current_environment")
    def test_trigger_deployment_non_development_environment(
        self,
        mock_get_env: MagicMock,
    ):
        """Test that trigger_deployment fails in non-development environment."""
        mock_get_env.return_value = "test"

        with pytest.raises(typer.Exit) as exc_info:
            trigger_deployment(order_id="order-123")

        assert exc_info.value.exit_code == 1


# test
