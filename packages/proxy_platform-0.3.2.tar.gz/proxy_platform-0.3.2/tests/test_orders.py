"""Tests for order commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.orders import (
    create_order,
    get_order,
    list_orders,
)


def _products_response(products=None):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = products or [
        {
            "id": "prod-123",
            "name": "Kubernetes Cluster",
            "product_type": "cluster",
            "description": "K8s cluster",
            "pricing_tiers": [
                {
                    "id": "tier-1",
                    "name": "Starter",
                    "price": 120.0,
                    "currency": "EUR",
                    "billing_interval": "monthly",
                    "specs": {"cpu_cores": 4, "memory_gb": 8, "nodes": 3},
                }
            ],
        }
    ]
    return resp


def _firewalls_response(firewalls=None):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = firewalls or []
    return resp


def _create_response(status=200, order_id="order-123"):
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = {"order_id": order_id, "status": "pending"}
    return resp


def _url_dispatch(url_map):
    """Return a side_effect function that dispatches based on URL substring."""

    def side_effect(url, **kwargs):
        for key, resp in url_map.items():
            if key in url:
                return resp
        raise AssertionError(f"Unexpected GET call: {url}")

    return side_effect


class TestCreateOrder:
    """Test cases for the unified create_order command."""

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_non_interactive_all_flags(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """All flags provided — no prompts shown."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            no_firewall=True,
            yes=True,
            auto_pay=False,
            api=None,
        )

        posted = mock_client.post.call_args[1]["data"]
        assert posted["accepted_documents"] is True
        assert posted["pricing_tier_id"] == "tier-1"

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_single_product_auto_selected(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Single product is auto-selected without prompting."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        create_order(
            product_id=None, tier="Starter", provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
        )

        mock_client.post.assert_called_once()

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_product_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Multiple products trigger interactive selection."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        products = _products_response(
            [
                {
                    "id": "prod-a",
                    "name": "Product A",
                    "product_type": "cluster",
                    "description": "A",
                    "pricing_tiers": [
                        {
                            "id": "tier-a",
                            "name": "Starter",
                            "price": 100.0,
                            "currency": "EUR",
                            "billing_interval": "monthly",
                            "specs": {},
                        }
                    ],
                },
                {
                    "id": "prod-b",
                    "name": "Product B",
                    "product_type": "cluster",
                    "description": "B",
                    "pricing_tiers": [
                        {
                            "id": "tier-b",
                            "name": "Starter",
                            "price": 200.0,
                            "currency": "EUR",
                            "billing_interval": "monthly",
                            "specs": {},
                        }
                    ],
                },
            ]
        )
        mock_client.get.side_effect = _url_dispatch({"products": products, "firewalls": _firewalls_response()})
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1"]

        create_order(
            product_id=None, tier="Starter", provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
        )

        mock_client.post.assert_called_once()

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_fetch_products_fails(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when products fetch fails."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        fail = MagicMock()
        fail.status_code = 500
        mock_client.get.return_value = fail
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(product_id=None, tier="Starter", region=None, no_firewall=True, yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_no_products_available(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when no products are available."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.return_value = _products_response([])
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(product_id=None, tier="Starter", region=None, no_firewall=True, yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_tier_not_found(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when specified tier does not exist."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(product_id=None, tier="NonExistent", region=None, no_firewall=True, yes=True, api=None)

        assert exc_info.value.exit_code == 1
        output = " ".join(str(c) for c in mock_console.print.call_args_list)
        assert "not found" in output.lower() or "Tier" in output

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_no_pricing_tiers(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when product has no pricing tiers."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        products = _products_response(
            [
                {
                    "id": "prod-no-tiers",
                    "name": "No Tiers",
                    "product_type": "test",
                    "description": "Test",
                    "pricing_tiers": [],
                }
            ]
        )
        mock_client.get.side_effect = _url_dispatch({"products": products, "firewalls": _firewalls_response()})
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(product_id=None, tier=None, region=None, no_firewall=True, yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_tier_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Tier selection prompt shown when --tier not given."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1"]

        create_order(
            product_id=None, tier=None, provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
        )

        mock_client.post.assert_called_once()

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_invalid_tier_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Invalid tier selection exits with 1."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_api_client.return_value = mock_client

        mock_prompt.ask.return_value = "999"

        with pytest.raises(typer.Exit) as exc_info:
            create_order(
                product_id=None, tier=None, provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_provider_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Provider selection prompt shown when --provider not given."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1", "1"]  # tier, provider

        create_order(product_id=None, tier=None, provider=None, region="nbg1", no_firewall=True, yes=True, api=None)

        mock_client.post.assert_called_once()

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_non_hetzner_provider_falls_back(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Non-Hetzner provider selection falls back to Hetzner."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1", "2", "1"]  # tier, AWS provider, region

        create_order(product_id=None, tier=None, provider=None, region=None, no_firewall=True, yes=True, api=None)

        output = " ".join(str(c) for c in mock_console.print.call_args_list)
        assert "not yet implemented" in output or "Using Hetzner" in output

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_region_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Region selection prompt shown when --region not given."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1"]  # region

        create_order(
            product_id=None, tier="Starter", provider="hetzner", region=None, no_firewall=True, yes=True, api=None
        )

        mock_client.post.assert_called_once()

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_interactive_firewall_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Firewall selection prompt shown when firewalls exist and no flag given."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        firewalls = _firewalls_response([{"id": "fw-123", "name": "My Firewall", "description": ""}])
        mock_client.get.side_effect = _url_dispatch({"products": _products_response(), "firewalls": firewalls})
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["1"]  # firewall

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            firewall_id=None,
            no_firewall=False,
            yes=True,
            auto_pay=False,
            api=None,
        )

        posted = mock_client.post.call_args[1]["data"]
        assert posted.get("firewall_id") == "fw-123"

    @patch("proxy_platform.commands.orders.Prompt")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_firewall_none_selection(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_prompt
    ):
        """Selecting 'none' for firewall results in no firewall_id in payload."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        firewalls = _firewalls_response([{"id": "fw-123", "name": "FW", "description": ""}])
        mock_client.get.side_effect = _url_dispatch({"products": _products_response(), "firewalls": firewalls})
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        mock_prompt.ask.side_effect = ["none"]  # no firewall

        create_order(
            product_id=None, tier="Starter", provider="hetzner", region="nbg1", firewall_id=None, yes=True, api=None
        )

        posted = mock_client.post.call_args[1]["data"]
        assert "firewall_id" not in posted

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_firewall_flag_matched_by_name(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """--firewall flag matches firewall by name."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        firewalls = _firewalls_response([{"id": "fw-abc", "name": "My Firewall", "description": ""}])
        mock_client.get.side_effect = _url_dispatch({"products": _products_response(), "firewalls": firewalls})
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            firewall_id="My Firewall",
            no_firewall=False,
            yes=True,
            auto_pay=False,
            api=None,
        )

        posted = mock_client.post.call_args[1]["data"]
        assert posted.get("firewall_id") == "fw-abc"

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_firewall_flag_not_found(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when --firewall flag doesn't match any firewall."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        firewalls = _firewalls_response([{"id": "fw-123", "name": "Other", "description": ""}])
        mock_client.get.side_effect = _url_dispatch({"products": _products_response(), "firewalls": firewalls})
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(
                product_id=None,
                tier="Starter",
                provider="hetzner",
                region="nbg1",
                firewall_id="nonexistent",
                yes=True,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_no_firewalls_available(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """No firewalls available — deploys without firewall."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response([])}
        )
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        create_order(
            product_id=None, tier="Starter", provider="hetzner", region="nbg1", firewall_id=None, yes=True, api=None
        )

        posted = mock_client.post.call_args[1]["data"]
        assert "firewall_id" not in posted

    @patch("proxy_platform.commands.orders.typer.confirm")
    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_terms_declined_exits(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env, mock_confirm
    ):
        """Declining terms cancels the order."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_api_client.return_value = mock_client

        mock_confirm.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            create_order(
                product_id=None,
                tier="Starter",
                provider="hetzner",
                region="nbg1",
                no_firewall=True,
                yes=False,
                api=None,
            )

        assert exc_info.value.exit_code == 0

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_order_creation_fails(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Exit 1 when order API returns error."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        fail = MagicMock()
        fail.status_code = 422
        fail.json.return_value = {"detail": "Validation error"}
        mock_client.post.return_value = fail
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(
                product_id=None, tier="Starter", provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_auto_pay_dev_mode(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Payment is simulated in dev mode when auto_pay=True."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "development"
        mock_user_client = MagicMock()
        mock_admin_client = MagicMock()

        mock_user_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_user_client.post.return_value = _create_response(order_id="order-dev-123")

        pay_resp = MagicMock()
        pay_resp.status_code = 200
        pay_resp.json.return_value = {
            "deployment_triggered": True,
            "deployment_result": {"cluster_id": "cluster-456", "status": "pending"},
        }
        mock_admin_client.post.return_value = pay_resp

        mock_api_client.side_effect = [mock_user_client, mock_admin_client]

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            no_firewall=True,
            yes=True,
            auto_pay=True,
            api=None,
        )

        assert mock_admin_client.post.called

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_auto_pay_not_in_dev_mode(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Payment URL shown in production, no auto-pay."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {
            "order_id": "order-prod",
            "status": "pending",
            "payment_url": "https://pay.example.com",
        }
        mock_client.post.return_value = resp
        mock_api_client.return_value = mock_client

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            no_firewall=True,
            yes=True,
            auto_pay=True,
            api=None,
        )

        output = " ".join(str(c) for c in mock_console.print.call_args_list)
        assert "pay.example.com" in output

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_auto_pay_dev_payment_simulation_fails(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env
    ):
        """Handles payment simulation failure gracefully."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "development"
        mock_user_client = MagicMock()
        mock_admin_client = MagicMock()

        mock_user_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_user_client.post.return_value = _create_response()

        fail = MagicMock()
        fail.status_code = 500
        mock_admin_client.post.return_value = fail

        mock_api_client.side_effect = [mock_user_client, mock_admin_client]

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            no_firewall=True,
            yes=True,
            auto_pay=True,
            api=None,
        )

        output = " ".join(str(c) for c in mock_console.print.call_args_list)
        assert "Payment simulation failed" in output

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_auto_pay_dev_no_deployment_triggered(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env
    ):
        """Handles case where payment succeeded but deployment not triggered."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "development"
        mock_user_client = MagicMock()
        mock_admin_client = MagicMock()

        mock_user_client.get.side_effect = _url_dispatch(
            {"products": _products_response(), "firewalls": _firewalls_response()}
        )
        mock_user_client.post.return_value = _create_response()

        pay_resp = MagicMock()
        pay_resp.status_code = 200
        pay_resp.json.return_value = {"deployment_triggered": False}
        mock_admin_client.post.return_value = pay_resp

        mock_api_client.side_effect = [mock_user_client, mock_admin_client]

        create_order(
            product_id=None,
            tier="Starter",
            provider="hetzner",
            region="nbg1",
            no_firewall=True,
            yes=True,
            auto_pay=True,
            api=None,
        )

        output = " ".join(str(c) for c in mock_console.print.call_args_list)
        assert "deployment not triggered automatically" in output

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_exception_exits_with_1(self, mock_console, mock_api_client, mock_get_default_api, mock_get_env):
        """Unexpected exception exits with code 1."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()
        mock_client.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client

        with pytest.raises(typer.Exit) as exc_info:
            create_order(product_id=None, tier="Starter", region=None, no_firewall=True, yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_current_environment")
    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_long_product_description_truncated(
        self, mock_console, mock_api_client, mock_get_default_api, mock_get_env
    ):
        """Long product description is truncated in display."""
        mock_get_default_api.return_value = "user"
        mock_get_env.return_value = "production"
        mock_client = MagicMock()

        products = _products_response(
            [
                {
                    "id": "p1",
                    "name": "P1",
                    "product_type": "t",
                    "description": "A" * 100,
                    "pricing_tiers": [
                        {
                            "id": "tier-1",
                            "name": "Starter",
                            "price": 10.0,
                            "currency": "EUR",
                            "billing_interval": "monthly",
                            "specs": {},
                        }
                    ],
                },
                {
                    "id": "p2",
                    "name": "P2",
                    "product_type": "t",
                    "description": "Short",
                    "pricing_tiers": [
                        {
                            "id": "tier-2",
                            "name": "Starter",
                            "price": 20.0,
                            "currency": "EUR",
                            "billing_interval": "monthly",
                            "specs": {},
                        }
                    ],
                },
            ]
        )
        mock_client.get.side_effect = _url_dispatch({"products": products, "firewalls": _firewalls_response()})
        mock_client.post.return_value = _create_response()
        mock_api_client.return_value = mock_client

        with patch("proxy_platform.commands.orders.Prompt") as mock_prompt:
            mock_prompt.ask.side_effect = ["1"]
            create_order(
                product_id=None, tier="Starter", provider="hetzner", region="nbg1", no_firewall=True, yes=True, api=None
            )

        assert mock_client.post.called


class TestListOrders:
    """Test cases for list_orders command."""

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_success_with_orders_key(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with orders key in response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "order-123-456-789",
                    "description": "Test Order 1",
                    "amount": 10.0,
                    "currency": "EUR",
                    "status": "paid",
                    "created_at": "2024-01-01T10:00:00",
                },
                {
                    "id": "order-456-789-012",
                    "description": "Test Order 2",
                    "amount": "25.50",
                    "currency": "USD",
                    "status": "pending",
                    "created_at": "2024-01-02T11:00:00",
                },
            ],
            "total_count": 2,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=10, api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/users/orders?limit=10")
        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_success_with_items_key(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with items key in response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "order-789",
                    "description": "Item Order",
                    "total_amount": 30.0,
                    "currency": "EUR",
                    "status": "completed",
                    "created_at": "2024-01-03T12:00:00",
                },
            ],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=5, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test listing orders with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "admin-order",
                    "description": "Admin Order",
                    "amount": 100.0,
                    "currency": "EUR",
                    "status": "paid",
                    "created_at": "2024-01-04",
                },
            ],
            "total_count": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=20, api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"orders": [], "total_count": 0}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=10, api=None)

        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No orders found" in printed_output

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_with_invalid_amount(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with invalid amount values."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "order-invalid",
                    "description": "Invalid Amount",
                    "amount": "invalid",
                    "currency": "EUR",
                    "status": "pending",
                    "created_at": "2024-01-05",
                },
                {
                    "id": "order-none",
                    "description": "None Amount",
                    "amount": None,
                    "currency": "EUR",
                    "status": "pending",
                    "created_at": "2024-01-06",
                },
            ],
            "total_count": 2,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=10, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_with_missing_created_at(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with missing created_at."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "order-no-date",
                    "description": "No Date",
                    "amount": 10.0,
                    "currency": "EUR",
                    "status": "pending",
                },
            ],
            "total_count": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_orders(limit=10, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_orders(limit=10, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_list_orders_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing orders with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_orders(limit=10, api=None)

        assert exc_info.value.exit_code == 1


class TestGetOrder:
    """Test cases for get_order command."""

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_success_exact_match(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with exact ID match."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "order-123",
                    "description": "Test Order",
                    "amount": 10.0,
                    "currency": "EUR",
                    "status": "paid",
                    "created_at": "2024-01-01T10:00:00",
                    "paid_at": "2024-01-01T11:00:00",
                    "product_id": "prod-456",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="order-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/users/orders?limit=100")
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "order-123" in printed_output
        assert "Test Order" in printed_output

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_success_partial_match(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with partial ID match."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "order-abc-123",
                    "description": "Partial Match Order",
                    "amount": "15.50",
                    "currency": "USD",
                    "status": "pending",
                    "created_at": "2024-01-02",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="order-abc", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting order with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "admin-order",
                    "description": "Admin Order",
                    "amount": 100.0,
                    "currency": "EUR",
                    "status": "paid",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="admin-order", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_with_items_key(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order when API returns items key."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "order-items",
                    "description": "Items Order",
                    "total_amount": 25.0,
                    "currency": "EUR",
                    "status": "completed",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="order-items", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_minimal_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with minimal details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "minimal-order",
                    "amount": None,
                    "status": "pending",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="minimal-order", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_with_invalid_amount_type(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with amount that raises TypeError."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {
                    "id": "type-error-order",
                    "amount": {"invalid": "dict"},
                    "status": "pending",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_order(order_id="type-error-order", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order that doesn't exist."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "orders": [
                {"id": "other-order", "description": "Other", "amount": 10.0, "status": "paid"},
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_order(order_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "Order not found" in printed_output

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_order(order_id="order-123", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.orders.get_default_api_type")
    @patch("proxy_platform.commands.orders.APIClient")
    @patch("proxy_platform.commands.orders.console")
    def test_get_order_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting order with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_order(order_id="order-123", api=None)

        assert exc_info.value.exit_code == 1
