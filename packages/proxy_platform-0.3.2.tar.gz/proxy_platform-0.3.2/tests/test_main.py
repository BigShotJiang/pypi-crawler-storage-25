"""Tests for main CLI module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

import proxy_platform.main
from proxy_platform import __version__
from proxy_platform.main import env, login_alias, logout_alias, version, whoami_alias


class TestVersion:
    """Test cases for version command."""

    @patch("proxy_platform.main.console")
    def test_version_command(self, mock_console: MagicMock):
        """Test version command shows version number."""
        version()
        mock_console.print.assert_called_once()
        call_args = mock_console.print.call_args[0][0]
        assert __version__ in call_args
        assert "PBD CLI version:" in call_args


class TestEnv:
    """Test cases for env command."""

    @patch("proxy_platform.main.console")
    @patch("proxy_platform.main.get_current_environment")
    def test_env_show_current(self, mock_get_env: MagicMock, mock_console: MagicMock):
        """Test env command with --show flag."""
        mock_get_env.return_value = "development"

        env(environment=None, show=True)

        # Should show current environment
        assert mock_console.print.called
        printed_output = " ".join(str(call[0][0]) for call in mock_console.print.call_args_list)
        assert "development" in printed_output
        assert "Current environment:" in printed_output

    @patch("proxy_platform.main.console")
    @patch("proxy_platform.main.get_current_environment")
    def test_env_no_argument_shows_current(self, mock_get_env: MagicMock, mock_console: MagicMock):
        """Test env command without argument shows current environment."""
        mock_get_env.return_value = "test"

        env(environment=None, show=False)

        # Should show current environment when no environment argument provided
        assert mock_console.print.called
        printed_output = " ".join(str(call[0][0]) for call in mock_console.print.call_args_list)
        assert "test" in printed_output

    @patch("proxy_platform.main.console")
    @patch("proxy_platform.main.set_environment")
    def test_env_switch_to_valid_environment(self, mock_set_env: MagicMock, mock_console: MagicMock):
        """Test switching to a valid environment."""
        env(environment="test", show=False)

        mock_set_env.assert_called_once_with("test")
        assert mock_console.print.called
        printed_output = str(mock_console.print.call_args[0][0])
        assert "test" in printed_output
        assert "Switched to" in printed_output

    @patch("proxy_platform.main.console")
    def test_env_switch_to_invalid_environment(self, mock_console: MagicMock):
        """Test switching to an invalid environment."""
        with pytest.raises(typer.Exit) as exc_info:
            env(environment="invalid", show=False)

        assert exc_info.value.exit_code == 1
        assert mock_console.print.called
        printed_output = str(mock_console.print.call_args_list[0][0][0])
        assert "Error" in printed_output or "Invalid" in printed_output

    @patch("proxy_platform.main.console")
    @patch("proxy_platform.main.get_current_environment")
    def test_env_shows_all_environments(self, mock_get_env: MagicMock, mock_console: MagicMock):
        """Test env command displays all available environments."""
        mock_get_env.return_value = "development"

        env(environment=None, show=False)

        # Should show all environments
        printed_output = " ".join(str(call[0][0]) for call in mock_console.print.call_args_list)
        assert "development" in printed_output
        assert "test" in printed_output
        assert "production" in printed_output


class TestLoginAlias:
    """Test cases for login alias command."""

    @patch("proxy_platform.commands.auth.login")
    def test_login_alias_with_credentials(self, mock_auth_login: MagicMock):
        """Test login alias command with email and password."""
        login_alias(email="test@example.com", password="secret", api="admin")

        mock_auth_login.assert_called_once_with(email="test@example.com", password="secret", api="admin")

    @patch("proxy_platform.commands.auth.login")
    def test_login_alias_default_api(self, mock_auth_login: MagicMock):
        """Test login alias command with default API type."""
        login_alias(email="test@example.com", password="secret", api="user")

        mock_auth_login.assert_called_once_with(email="test@example.com", password="secret", api="user")

    @patch("proxy_platform.commands.auth.login")
    def test_login_alias_without_credentials(self, mock_auth_login: MagicMock):
        """Test login alias command without credentials prompts user."""
        login_alias(email=None, password=None, api="user")

        mock_auth_login.assert_called_once_with(email=None, password=None, api="user")


class TestLogoutAlias:
    """Test cases for logout alias command."""

    @patch("proxy_platform.commands.auth.logout")
    def test_logout_alias(self, mock_auth_logout: MagicMock):
        """Test logout alias command."""
        logout_alias()
        mock_auth_logout.assert_called_once()


class TestWhoamiAlias:
    """Test cases for whoami alias command."""

    @patch("proxy_platform.commands.auth.whoami")
    def test_whoami_alias_default_api(self, mock_auth_whoami: MagicMock):
        """Test whoami alias command with default API."""
        whoami_alias(api=None)
        mock_auth_whoami.assert_called_once_with(api=None)

    @patch("proxy_platform.commands.auth.whoami")
    def test_whoami_alias_with_api_type(self, mock_auth_whoami: MagicMock):
        """Test whoami alias command with specific API type."""
        whoami_alias(api="admin")
        mock_auth_whoami.assert_called_once_with(api="admin")


class TestAppConfiguration:
    """Test app-level configuration."""

    def test_app_name(self):
        """Test app has correct name."""
        assert hasattr(proxy_platform.main, "app")
        # The app is configured with specific properties
        # We can't easily test Typer internals but we can verify the module structure

    def test_command_groups_registered(self):
        """Test that command groups are properly imported."""
        # Verify that the command modules are imported
        from proxy_platform.commands import auth, clusters, deployments, orders, products, users

        assert hasattr(auth, "app")
        assert hasattr(products, "app")
        assert hasattr(orders, "app")
        assert hasattr(clusters, "app")
        assert hasattr(users, "app")
        assert hasattr(deployments, "app")

    def test_version_function_exists(self):
        """Test version function exists."""
        from proxy_platform.main import version

        assert callable(version)

    def test_env_function_exists(self):
        """Test env function exists."""
        from proxy_platform.main import env

        assert callable(env)

    def test_login_alias_exists(self):
        """Test login alias function exists."""
        from proxy_platform.main import login_alias

        assert callable(login_alias)

    def test_logout_alias_exists(self):
        """Test logout alias function exists."""
        from proxy_platform.main import logout_alias

        assert callable(logout_alias)

    def test_whoami_alias_exists(self):
        """Test whoami alias function exists."""
        from proxy_platform.main import whoami_alias

        assert callable(whoami_alias)
