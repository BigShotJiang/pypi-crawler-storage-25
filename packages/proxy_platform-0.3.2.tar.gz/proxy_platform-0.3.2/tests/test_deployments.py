"""Tests for deployment commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.deployments import get_deployment, list_deployments


class TestListDeployments:
    """Test cases for list_deployments command."""

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_list_deployments_success_with_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing deployments with results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "deploy-123",
                    "cluster": {"name": "cluster-1"},
                    "status": "completed",
                    "deployment_type": "initial",
                    "created_at": "2024-01-01",
                },
                {
                    "id": "deploy-456",
                    "cluster": {"name": "cluster-2"},
                    "status": "pending",
                    "deployment_type": "upgrade",
                    "created_at": "2024-01-02",
                },
            ],
            "total": 2,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_deployments(limit=10, api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters?limit=10")
        assert mock_console.print.called

    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_list_deployments_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test listing deployments with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "deploy-789",
                    "cluster": {"name": "admin-cluster"},
                    "status": "running",
                    "deployment_type": "migration",
                    "created_at": "2024-01-03",
                }
            ],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_deployments(limit=5, api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters?limit=5")

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_list_deployments_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing deployments with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [],
            "total": 0,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_deployments(limit=10, api=None)

        # Should show "No deployments found" message
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No deployments found" in printed_output
        assert "Tip" in printed_output

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_list_deployments_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing deployments with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_deployments(limit=10, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_list_deployments_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing deployments with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_deployments(limit=10, api=None)

        assert exc_info.value.exit_code == 1


class TestGetDeployment:
    """Test cases for get_deployment command."""

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_success_full_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with full details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "deploy-123",
            "status": "completed",
            "deployment_type": "initial",
            "cluster": {"name": "cluster-1"},
            "created_at": "2024-01-01T10:00:00",
            "completed_at": "2024-01-01T10:30:00",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="deploy-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/deploy-123/deployment")
        # Check that details were printed
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "deploy-123" in printed_output
        assert "completed" in printed_output

    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting deployment with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "deploy-456",
            "status": "running",
            "deployment_type": "upgrade",
            "cluster": {"name": "admin-cluster"},
            "created_at": "2024-01-02T11:00:00",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="deploy-456", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/deploy-456/deployment")

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_minimal_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with minimal details (no cluster, dates)."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "deploy-minimal",
            "status": "pending",
            # No cluster, created_at, completed_at
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="deploy-minimal", api=None)

        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/deploy-minimal/deployment")
        assert mock_console.print.called

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_with_empty_cluster(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with empty cluster object."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "deploy-789",
            "status": "pending",
            "cluster": {},  # Empty cluster object
            "created_at": "2024-01-03",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="deploy-789", api=None)

        # Empty dict is falsy, so cluster name shouldn't be printed
        assert mock_console.print.called

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Deployment not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_deployment(cluster_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.deployments.get_default_api_type")
    @patch("proxy_platform.commands.deployments.APIClient")
    @patch("proxy_platform.commands.deployments.console")
    def test_get_deployment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_deployment(cluster_id="deploy-123", api=None)

        assert exc_info.value.exit_code == 1
