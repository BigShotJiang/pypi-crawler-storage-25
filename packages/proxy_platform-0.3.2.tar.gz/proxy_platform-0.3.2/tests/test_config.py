"""Tests for configuration module."""

import json
from pathlib import Path
from typing import Any

import pytest

from proxy_platform import config


class TestConfiguration:
    """Test cases for configuration management."""

    def test_ensure_config_dir_creates_directory(self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch):
        """Test that config directory is created if it doesn't exist."""
        monkeypatch.setattr(config, "CONFIG_DIR", temp_config_dir / "new_dir")
        config.ensure_config_dir()
        assert (temp_config_dir / "new_dir").exists()

    def test_get_current_environment_default(self, mock_config_dir: Path):
        """Test getting current environment when no config exists."""
        env = config.get_current_environment()
        assert env == "development"

    def test_set_and_get_environment(self, mock_config_dir: Path):
        """Test setting and retrieving environment."""
        config.set_environment("test")
        env = config.get_current_environment()
        assert env == "test"

    def test_get_api_urls_local(self, mock_config_dir: Path):
        """Test getting API URLs for local environment."""
        config.set_environment("development")
        urls = config.get_api_urls()
        assert urls["admin_api"] == "http://localhost:8001"
        assert urls["user_api"] == "http://localhost:8002"

    def test_get_api_urls_staging(self, mock_config_dir: Path):
        """Test getting API URLs for staging environment."""
        config.set_environment("test")
        urls = config.get_api_urls()
        assert "admin-api.tst.pbd.proxy.nl" in urls["admin_api"]
        assert "api.tst.pbd.proxy.nl" in urls["user_api"]

    def test_save_tokens_admin(self, mock_config_dir: Path):
        """Test saving admin tokens."""
        config.save_tokens(admin_token="admin-token-123", admin_refresh="admin-refresh-123")

        token_file = mock_config_dir / "tokens.json"
        assert token_file.exists()

        with open(token_file) as f:
            data = json.load(f)

        assert data["development"]["admin_token"] == "admin-token-123"
        assert data["development"]["admin_refresh_token"] == "admin-refresh-123"
        assert "admin_token_saved_at" in data["development"]

    def test_save_tokens_user(self, mock_config_dir: Path):
        """Test saving user tokens."""
        config.save_tokens(user_token="user-token-123", user_refresh="user-refresh-123")

        token_file = mock_config_dir / "tokens.json"
        with open(token_file) as f:
            data = json.load(f)

        assert data["development"]["user_token"] == "user-token-123"
        assert data["development"]["user_refresh_token"] == "user-refresh-123"

    def test_get_token_admin(self, mock_config_dir: Path, sample_tokens: dict[str, Any]):
        """Test retrieving admin token."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            json.dump(sample_tokens, f)

        token = config.get_token("admin")
        assert token == sample_tokens["development"]["admin_token"]

    def test_get_token_user(self, mock_config_dir: Path, sample_tokens: dict[str, Any]):
        """Test retrieving user token."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            json.dump(sample_tokens, f)

        token = config.get_token("user")
        assert token == sample_tokens["development"]["user_token"]

    def test_get_token_no_token_file(self, mock_config_dir: Path):
        """Test getting token when no token file exists."""
        token = config.get_token("admin")
        assert token is None

    def test_get_refresh_token(self, mock_config_dir: Path, sample_tokens: dict[str, Any]):
        """Test retrieving refresh token."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            json.dump(sample_tokens, f)

        refresh_token = config.get_refresh_token("admin")
        assert refresh_token == sample_tokens["development"]["admin_refresh_token"]

    def test_clear_tokens(self, mock_config_dir: Path, sample_tokens: dict[str, Any]):
        """Test clearing tokens."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            json.dump(sample_tokens, f)

        config.clear_tokens()

        # File should still exist but current environment tokens should be removed
        assert token_file.exists()
        with open(token_file) as f:
            tokens = json.load(f)
        # "development" is the default environment, should be removed
        assert "development" not in tokens

    def test_get_default_api_type(self, mock_config_dir: Path):
        """Test getting default API type."""
        api_type = config.get_default_api_type()
        assert api_type in ["admin", "user"]

    def test_set_default_api_type(self, mock_config_dir: Path):
        """Test setting default API type."""
        config.set_default_api_type("user")
        api_type = config.get_default_api_type()
        assert api_type == "user"

    def test_token_file_permissions(self, mock_config_dir: Path):
        """Test that token file has secure permissions (0o600)."""
        config.save_tokens(admin_token="test-token")

        token_file = mock_config_dir / "tokens.json"
        # Check file exists
        assert token_file.exists()

        # On Unix systems, check permissions
        import platform
        import stat

        if platform.system() != "Windows":
            file_stat = token_file.stat()
            # File should be readable/writable by owner only
            assert stat.filemode(file_stat.st_mode) == "-rw-------"

    def test_get_current_environment_with_corrupt_json(self, mock_config_dir: Path):
        """Test getting environment when config file has corrupt JSON."""
        config_file = mock_config_dir / "config.json"
        with open(config_file, "w") as f:
            f.write("{invalid json")

        # Should return default "development"
        env = config.get_current_environment()
        assert env == "development"

    def test_set_environment_with_corrupt_json(self, mock_config_dir: Path):
        """Test setting environment when existing config has corrupt JSON."""
        config_file = mock_config_dir / "config.json"
        with open(config_file, "w") as f:
            f.write("{invalid json")

        # Should still work and create new valid config
        config.set_environment("test")
        env = config.get_current_environment()
        assert env == "test"

    def test_save_tokens_with_corrupt_json(self, mock_config_dir: Path):
        """Test saving tokens when existing token file has corrupt JSON."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            f.write("{invalid json")

        # Should still work and create new valid token file
        config.save_tokens(admin_token="new-token")
        token = config.get_token("admin")
        assert token == "new-token"

    def test_get_token_with_corrupt_json(self, mock_config_dir: Path):
        """Test getting token when token file has corrupt JSON."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            f.write("{invalid json")

        # Should return None
        token = config.get_token("admin")
        assert token is None

    def test_get_refresh_token_with_corrupt_json(self, mock_config_dir: Path):
        """Test getting refresh token when token file has corrupt JSON."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            f.write("{invalid json")

        # Should return None
        token = config.get_refresh_token("admin")
        assert token is None

    def test_clear_tokens_with_corrupt_json(self, mock_config_dir: Path):
        """Test clearing tokens when token file has corrupt JSON."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            f.write("{invalid json")

        # Should not raise an error
        config.clear_tokens()
        # File should still exist but be invalid
        assert token_file.exists()

    def test_get_default_api_type_with_corrupt_json(self, mock_config_dir: Path):
        """Test getting default API type when config file has corrupt JSON."""
        config_file = mock_config_dir / "config.json"
        with open(config_file, "w") as f:
            f.write("{invalid json")

        # Should return default "user"
        api_type = config.get_default_api_type()
        assert api_type == "user"

    def test_set_default_api_type_with_corrupt_json(self, mock_config_dir: Path):
        """Test setting default API type when existing config has corrupt JSON."""
        config_file = mock_config_dir / "config.json"
        with open(config_file, "w") as f:
            f.write("{invalid json")

        # Should still work and create new valid config
        config.set_default_api_type("admin")
        api_type = config.get_default_api_type()
        assert api_type == "admin"

    def test_get_token_missing_environment_key(self, mock_config_dir: Path, sample_tokens: dict[str, Any]):
        """Test getting token when current environment is not in tokens."""
        token_file = mock_config_dir / "tokens.json"
        with open(token_file, "w") as f:
            json.dump({"test": {"admin_token": "staging-token"}}, f)

        # Current environment is "development" by default, which is not in the file
        token = config.get_token("admin")
        assert token is None

    def test_get_refresh_token_no_file(self, mock_config_dir: Path):
        """Test getting refresh token when file doesn't exist."""
        token = config.get_refresh_token("admin")
        assert token is None

    def test_clear_tokens_no_file(self, mock_config_dir: Path):
        """Test clearing tokens when file doesn't exist."""
        # Should not raise an error
        config.clear_tokens()
        token_file = mock_config_dir / "tokens.json"
        assert not token_file.exists()

    def test_save_tokens_creates_environment_key(self, mock_config_dir: Path):
        """Test saving tokens creates environment key if it doesn't exist."""
        token_file = mock_config_dir / "tokens.json"
        # Create token file with staging env only
        with open(token_file, "w") as f:
            json.dump({"test": {"admin_token": "staging-token"}}, f)

        # Save token for local env (which doesn't exist yet)
        config.save_tokens(admin_token="local-token")

        with open(token_file) as f:
            tokens = json.load(f)

        # Both environments should now exist
        assert "test" in tokens
        assert "development" in tokens
        assert tokens["development"]["admin_token"] == "local-token"

    def test_clear_tokens_only_removes_current_env(self, mock_config_dir: Path):
        """Test clearing tokens only removes current environment."""
        token_file = mock_config_dir / "tokens.json"
        # Create token file with multiple environments
        with open(token_file, "w") as f:
            json.dump({"development": {"admin_token": "local-token"}, "test": {"admin_token": "staging-token"}}, f)

        # Clear local env tokens
        config.clear_tokens()

        with open(token_file) as f:
            tokens = json.load(f)

        # Local should be removed, staging should remain
        assert "development" not in tokens
        assert "test" in tokens

    def test_save_tokens_multiple_environments(self, mock_config_dir: Path):
        """Test saving tokens for multiple environments."""
        # Save local tokens
        config.set_environment("development")
        config.save_tokens(admin_token="local-token")

        # Save staging tokens
        config.set_environment("test")
        config.save_tokens(admin_token="staging-token")

        # Verify both exist
        token_file = mock_config_dir / "tokens.json"
        with open(token_file) as f:
            data = json.load(f)

        assert data["development"]["admin_token"] == "local-token"
        assert data["test"]["admin_token"] == "staging-token"

    def test_get_token_from_different_environment(self, mock_config_dir: Path):
        """Test getting token switches with environment."""
        # Save tokens for different environments
        config.set_environment("development")
        config.save_tokens(admin_token="local-admin-token")

        config.set_environment("test")
        config.save_tokens(admin_token="staging-admin-token")

        # Switch back to local and verify
        config.set_environment("development")
        token = config.get_token("admin")
        assert token == "local-admin-token"

        # Switch to staging and verify
        config.set_environment("test")
        token = config.get_token("admin")
        assert token == "staging-admin-token"
