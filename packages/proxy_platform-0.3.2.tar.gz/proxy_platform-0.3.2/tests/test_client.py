"""Tests for API client module."""

import base64
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from proxy_platform.client import APIClient


def _make_jwt(payload: dict) -> str:  # type: ignore[type-arg]
    """Build a minimal JWT with the given payload (unsigned)."""

    def b64(data: str) -> str:
        return base64.urlsafe_b64encode(data.encode()).rstrip(b"=").decode()

    header = b64('{"alg":"HS256"}')
    body = b64(json.dumps(payload))
    return f"{header}.{body}.fakesig"


class TestAPIClient:
    """Test cases for APIClient class."""

    def test_init_default_api_type(self, mock_config_dir: Path):
        """Test client initialization with default API type."""
        with patch("proxy_platform.client.get_default_api_type", return_value="admin"):
            client = APIClient()
            assert client.api_type == "admin"
            assert "localhost:8001" in client.base_url

    def test_init_explicit_api_type(self, mock_config_dir: Path):
        """Test client initialization with explicit API type."""
        client = APIClient(api_type="user")
        assert client.api_type == "user"
        assert "localhost:8002" in client.base_url

    def test_is_token_expired_valid_token(self):
        """Test token expiration check with valid token."""
        future_exp = (datetime.now() + timedelta(hours=1)).timestamp()
        token = _make_jwt({"exp": future_exp})

        client = APIClient(api_type="admin")
        assert client._is_token_expired(token) is False

    def test_is_token_expired_expired_token(self):
        """Test token expiration check with expired token."""
        past_exp = (datetime.now() - timedelta(hours=1)).timestamp()
        token = _make_jwt({"exp": past_exp})

        client = APIClient(api_type="admin")
        assert client._is_token_expired(token) is True

    def test_is_token_expired_no_exp_claim(self):
        """Test token expiration check when no exp claim exists."""
        token = _make_jwt({})

        client = APIClient(api_type="admin")
        assert client._is_token_expired(token) is False

    @patch("proxy_platform.client.get_token")
    def test_get_headers_with_token(self, mock_get_token: MagicMock):
        """Test header generation with authentication token."""
        mock_get_token.return_value = "test-token-123"

        client = APIClient(api_type="admin")
        headers = client._get_headers()

        assert headers["Authorization"] == "Bearer test-token-123"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"

    @patch("proxy_platform.client.get_token")
    def test_get_headers_without_token(self, mock_get_token: MagicMock):
        """Test header generation without authentication token."""
        mock_get_token.return_value = None

        client = APIClient(api_type="admin")
        headers = client._get_headers()

        assert "Authorization" not in headers
        assert headers["Content-Type"] == "application/json"

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_get_request_success(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
        mock_requests_response: MagicMock,
    ):
        """Test successful GET request."""
        mock_get_token.return_value = "test-token"
        mock_request.return_value = mock_requests_response

        client = APIClient(api_type="admin")
        response = client.get("/api/v1/users/profile")

        assert response.status_code == 200
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["method"] == "GET"
        assert "/api/v1/users/profile" in kwargs["url"]

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_post_request_with_data(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
        mock_requests_response: MagicMock,
    ):
        """Test POST request with JSON data."""
        mock_get_token.return_value = "test-token"
        mock_request.return_value = mock_requests_response

        client = APIClient(api_type="admin")
        data = {"username": "test@example.com", "password": "secret"}
        response = client.post("/api/v1/auth/login", data=data)

        assert response.status_code == 200
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["method"] == "POST"
        assert kwargs["json"] == data

    @patch("proxy_platform.client.get_token")
    def test_request_without_auth_token_raises_error(self, mock_get_token: MagicMock):
        """Test request without authentication token raises error."""
        mock_get_token.return_value = None

        client = APIClient(api_type="admin")

        with pytest.raises(Exception, match="Not authenticated"):
            client.get("/api/v1/users/profile")

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_request_public_endpoint_without_auth(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
        mock_requests_response: MagicMock,
    ):
        """Test request to public endpoint without auth."""
        mock_get_token.return_value = None
        mock_request.return_value = mock_requests_response

        client = APIClient(api_type="admin")
        response = client.get("/api/v1/health", require_auth=False)

        assert response.status_code == 200

    @patch("proxy_platform.client.requests.request")
    def test_request_connection_error(self, mock_request: MagicMock):
        """Test request handling of connection errors."""
        import requests

        mock_request.side_effect = requests.exceptions.ConnectionError()

        client = APIClient(api_type="admin")

        with pytest.raises(requests.exceptions.ConnectionError):
            client.get("/api/v1/users/profile", require_auth=False)

    @patch("proxy_platform.client.requests.request")
    def test_request_timeout_error(self, mock_request: MagicMock):
        """Test request handling of timeout errors."""
        import requests

        mock_request.side_effect = requests.exceptions.Timeout()

        client = APIClient(api_type="admin")

        with pytest.raises(requests.exceptions.Timeout):
            client.get("/api/v1/users/profile", require_auth=False)

    @patch("proxy_platform.client.requests.request")
    def test_login_success(
        self,
        mock_request: MagicMock,
        mock_successful_login_response: dict[str, Any],
    ):
        """Test successful login."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_successful_login_response
        mock_request.return_value = mock_response

        client = APIClient(api_type="admin")
        result = client.login("test@example.com", "password123")

        assert result["access_token"] == mock_successful_login_response["access_token"]
        assert result["refresh_token"] == mock_successful_login_response["refresh_token"]

    @patch("proxy_platform.client.requests.request")
    def test_login_failure(self, mock_request: MagicMock):
        """Test failed login."""
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"detail": "Invalid credentials"}
        mock_request.return_value = mock_response

        client = APIClient(api_type="admin")

        with pytest.raises(Exception, match="Login failed"):
            client.login("test@example.com", "wrongpassword")

    @patch("proxy_platform.client.requests.post")
    @patch("proxy_platform.client.get_refresh_token")
    @patch("proxy_platform.client.save_tokens")
    def test_refresh_access_token_success(
        self,
        mock_save_tokens: MagicMock,
        mock_get_refresh_token: MagicMock,
        mock_post: MagicMock,
    ):
        """Test successful token refresh."""
        mock_get_refresh_token.return_value = "refresh-token-123"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
        }
        mock_post.return_value = mock_response

        client = APIClient(api_type="admin")
        success = client._refresh_access_token()

        assert success is True
        mock_save_tokens.assert_called_once()

    @patch("proxy_platform.client.get_refresh_token")
    def test_refresh_access_token_no_refresh_token(self, mock_get_refresh_token: MagicMock):
        """Test token refresh when no refresh token available."""
        mock_get_refresh_token.return_value = None

        client = APIClient(api_type="admin")
        success = client._refresh_access_token()

        assert success is False

    @patch("proxy_platform.client.get_refresh_token")
    def test_refresh_access_token_prevents_loop(self, mock_get_refresh_token: MagicMock):
        """Test token refresh prevents infinite loops."""
        mock_get_refresh_token.return_value = "refresh-token"

        client = APIClient(api_type="admin")
        client._token_refreshed = True  # Simulate already refreshed

        success = client._refresh_access_token()

        assert success is False

    @patch("proxy_platform.client.requests.post")
    @patch("proxy_platform.client.get_refresh_token")
    @patch("proxy_platform.client.save_tokens")
    def test_refresh_access_token_user_api(
        self,
        mock_save_tokens: MagicMock,
        mock_get_refresh_token: MagicMock,
        mock_post: MagicMock,
    ):
        """Test successful token refresh for user API."""
        mock_get_refresh_token.return_value = "refresh-token-123"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "new-user-access-token",
            "refresh_token": "new-user-refresh-token",
        }
        mock_post.return_value = mock_response

        client = APIClient(api_type="user")
        success = client._refresh_access_token()

        assert success is True
        # Should call save_tokens with user_token parameter
        mock_save_tokens.assert_called_once_with(
            user_token="new-user-access-token", user_refresh="new-user-refresh-token"
        )

    @patch("proxy_platform.client.requests.post")
    @patch("proxy_platform.client.get_refresh_token")
    def test_refresh_access_token_http_error(
        self,
        mock_get_refresh_token: MagicMock,
        mock_post: MagicMock,
    ):
        """Test token refresh with HTTP error response."""
        mock_get_refresh_token.return_value = "refresh-token-123"
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_post.return_value = mock_response

        client = APIClient(api_type="admin")
        success = client._refresh_access_token()

        assert success is False

    @patch("proxy_platform.client.requests.post")
    @patch("proxy_platform.client.get_refresh_token")
    def test_refresh_access_token_exception(
        self,
        mock_get_refresh_token: MagicMock,
        mock_post: MagicMock,
    ):
        """Test token refresh with exception."""
        mock_get_refresh_token.return_value = "refresh-token-123"
        mock_post.side_effect = Exception("Network error")

        client = APIClient(api_type="admin")
        success = client._refresh_access_token()

        assert success is False

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_put_request(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
        mock_requests_response: MagicMock,
    ):
        """Test PUT request."""
        mock_get_token.return_value = "test-token"
        mock_request.return_value = mock_requests_response

        client = APIClient(api_type="admin")
        data = {"name": "Updated Name"}
        response = client.put("/api/v1/users/123", data=data)

        assert response.status_code == 200
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["method"] == "PUT"
        assert kwargs["json"] == data

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_delete_request(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
        mock_requests_response: MagicMock,
    ):
        """Test DELETE request."""
        mock_get_token.return_value = "test-token"
        mock_request.return_value = mock_requests_response

        client = APIClient(api_type="admin")
        response = client.delete("/api/v1/users/123")

        assert response.status_code == 200
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["method"] == "DELETE"

    @patch("proxy_platform.client.requests.post")
    @patch("proxy_platform.client.get_refresh_token")
    def test_refresh_access_token_missing_access_token(
        self,
        mock_get_refresh_token: MagicMock,
        mock_post: MagicMock,
    ):
        """Test token refresh when response doesn't include access_token."""
        mock_get_refresh_token.return_value = "refresh-token-123"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            # No access_token in response
            "refresh_token": "new-refresh-token",
        }
        mock_post.return_value = mock_response

        client = APIClient(api_type="admin")
        success = client._refresh_access_token()

        # Should return False when access_token is missing
        assert success is False

    @patch("proxy_platform.client.requests.request")
    @patch("proxy_platform.client.get_token")
    def test_request_with_expired_token_refresh_fails(
        self,
        mock_get_token: MagicMock,
        mock_request: MagicMock,
    ):
        """Test request when token is expired and refresh fails."""
        past_exp = (datetime.now() - timedelta(hours=1)).timestamp()
        expired_token = _make_jwt({"exp": past_exp})
        mock_get_token.return_value = expired_token

        client = APIClient(api_type="admin")
        client._token_refreshed = True  # Prevent actual refresh attempt

        with pytest.raises(Exception, match="Token expired"):
            client.get("/api/v1/users/profile")
