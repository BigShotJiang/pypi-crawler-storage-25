"""Tests for product commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.products import get_product, list_products


class TestListProducts:
    """Test cases for list_products command."""

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_success_dict_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing products with dict response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "prod-uuid-123-456",
                    "name": "Basic VPS",
                    "category": "VPS",
                    "price": 10.00,
                    "provider": {"name": "Provider A"},
                },
                {
                    "id": "prod-uuid-789-012",
                    "name": "Advanced VPS",
                    "category": "VPS",
                    "price": 25.50,
                    "provider": {"name": "Provider B"},
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_products(limit=50, api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/products?limit=50")
        assert mock_console.print.called

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_success_list_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing products with list response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {
                "id": "short",
                "name": "Product 1",
                "category": "Cat1",
                "price": 5.00,
                "provider": None,
            }
        ]
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_products(limit=10, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test listing products with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "admin-prod",
                    "name": "Admin Product",
                    "category": "Admin",
                    "price": 100.00,
                    "provider": {"name": "Admin Provider"},
                }
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_products(limit=25, api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing products with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"items": []}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_products(limit=50, api=None)

        # Should show "No products found" message
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No products found" in printed_output

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing products with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_products(limit=50, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_list_products_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing products with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_products(limit=50, api=None)

        assert exc_info.value.exit_code == 1


class TestGetProduct:
    """Test cases for get_product command."""

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_success_direct(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with direct ID match."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "prod-123",
            "name": "Test Product",
            "category": "VPS",
            "price": 15.99,
            "provider": {"name": "Test Provider"},
            "description": "A test product description",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_product(product_id="prod-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_with("/api/v1/products/prod-123")
        # Check that details were printed
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "Test Product" in printed_output

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_partial_id_single_match(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with partial ID that matches one product."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # First response: direct get fails
        mock_direct_response = MagicMock()
        mock_direct_response.status_code = 404

        # Second response: list returns one match
        mock_list_response = MagicMock()
        mock_list_response.status_code = 200
        mock_list_response.json.return_value = {
            "items": [
                {
                    "id": "prod-abc-123",
                    "name": "Matched Product",
                    "category": "VPS",
                    "price": 20.00,
                    "provider": {"name": "Provider"},
                }
            ]
        }

        mock_client_instance.get.side_effect = [mock_direct_response, mock_list_response]
        mock_api_client.return_value = mock_client_instance

        get_product(product_id="prod-abc", api=None)

        # Should have made two calls
        assert mock_client_instance.get.call_count == 2

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_partial_id_multiple_matches(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with partial ID that matches multiple products."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # First response: direct get fails
        mock_direct_response = MagicMock()
        mock_direct_response.status_code = 404

        # Second response: list returns multiple matches
        mock_list_response = MagicMock()
        mock_list_response.status_code = 200
        mock_list_response.json.return_value = {
            "items": [
                {"id": "prod-123", "name": "Product 1"},
                {"id": "prod-124", "name": "Product 2"},
            ]
        }

        mock_client_instance.get.side_effect = [mock_direct_response, mock_list_response]
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_product(product_id="prod-1", api=None)

        assert exc_info.value.exit_code == 1
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "Multiple products match" in printed_output

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_partial_id_no_match(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with partial ID that matches no products."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # First response: direct get fails
        mock_direct_response = MagicMock()
        mock_direct_response.status_code = 404

        # Second response: list returns no matches
        mock_list_response = MagicMock()
        mock_list_response.status_code = 200
        mock_list_response.json.return_value = {"items": [{"id": "other-123", "name": "Other Product"}]}

        mock_client_instance.get.side_effect = [mock_direct_response, mock_list_response]
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_product(product_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1
        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "Product not found" in printed_output

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_list_response_as_list(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product when list endpoint returns a list."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # First response: direct get fails
        mock_direct_response = MagicMock()
        mock_direct_response.status_code = 404

        # Second response: list returns list (not dict)
        mock_list_response = MagicMock()
        mock_list_response.status_code = 200
        mock_list_response.json.return_value = [
            {
                "id": "prod-xyz-456",
                "name": "List Product",
                "category": "Test",
                "price": 30.00,
            }
        ]

        mock_client_instance.get.side_effect = [mock_direct_response, mock_list_response]
        mock_api_client.return_value = mock_client_instance

        get_product(product_id="prod-xyz", api=None)

        assert mock_client_instance.get.call_count == 2

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_list_fails(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product when list endpoint fails."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # First response: direct get fails
        mock_direct_response = MagicMock()
        mock_direct_response.status_code = 404

        # Second response: list also fails
        mock_list_response = MagicMock()
        mock_list_response.status_code = 500

        mock_client_instance.get.side_effect = [mock_direct_response, mock_list_response]
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_product(product_id="test", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_minimal_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with minimal details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "minimal",
            "name": "Minimal Product",
            "price": 5.00,
            # No provider, description, category
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_product(product_id="minimal", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting product with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "admin-prod",
            "name": "Admin Product",
            "price": 100.00,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_product(product_id="admin-prod", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.products.get_default_api_type")
    @patch("proxy_platform.commands.products.APIClient")
    @patch("proxy_platform.commands.products.console")
    def test_get_product_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting product with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_product(product_id="test", api=None)

        assert exc_info.value.exit_code == 1
