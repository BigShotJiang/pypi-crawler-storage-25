"""Tests for cluster commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.clusters import get_cluster, get_deployment, get_firewall, list_clusters


class TestListClusters:
    """Test cases for list_clusters command."""

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_list_clusters_user_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing user clusters."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "id": "cluster-1",
                    "name": "My Cluster",
                    "status": "running",
                    "provider": {"name": "Provider A"},
                    "user": {"email": "user@example.com"},
                }
            ],
            "total": 1,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_clusters(limit=10, api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters?limit=10")
        assert mock_console.print.called

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_list_clusters_no_results(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing clusters with no results."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [],
            "total": 0,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_clusters(limit=10, api=None)

        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No clusters found" in printed_output

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_list_clusters_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing clusters with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_clusters(limit=10, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_list_clusters_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test listing clusters with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_clusters(limit=10, api=None)

        assert exc_info.value.exit_code == 1


class TestGetCluster:
    """Test cases for get_cluster command."""

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_cluster_success_full_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting cluster with full details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "cluster-123",
            "name": "Production Cluster",
            "status": "running",
            "provider": {"name": "AWS"},
            "product": {"name": "Basic VPS"},
            "user": {"email": "owner@example.com"},
            "created_at": "2024-01-01T00:00:00",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_cluster(cluster_id="cluster-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/cluster-123")
        assert mock_console.print.called

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_cluster_minimal_details(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting cluster with minimal details."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "cluster-minimal",
            "name": "Minimal Cluster",
            "status": "pending",
            # No provider, product, user, created_at
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_cluster(cluster_id="cluster-minimal", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_cluster_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting cluster with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "admin-cluster",
            "name": "Admin Cluster",
            "status": "running",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_cluster(cluster_id="admin-cluster", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_cluster_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting cluster with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Cluster not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_cluster(cluster_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_cluster_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting cluster with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Network error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_cluster(cluster_id="test", api=None)

        assert exc_info.value.exit_code == 1


class TestGetDeployment:
    """Test cases for get_deployment command."""

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_deployment_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment info successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "deployment_id": "deploy-123",
            "status": "completed",
            "type": "initial",
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="cluster-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/cluster-123/deployment")
        assert mock_console.print.called

    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_deployment_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting deployment with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "running"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_deployment(cluster_id="cluster-456", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_deployment_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_deployment(cluster_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_deployment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting deployment with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_deployment(cluster_id="test", api=None)

        assert exc_info.value.exit_code == 1


class TestGetFirewall:
    """Test cases for get_firewall command."""

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_firewall_with_rules(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting firewall with rules."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "rules": [
                {
                    "direction": "inbound",
                    "protocol": "tcp",
                    "port": 22,
                    "source_ip": "0.0.0.0/0",
                },
                {
                    "direction": "outbound",
                    "protocol": "tcp",
                    "port": 443,
                    "destination_ip": "0.0.0.0/0",
                },
            ]
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_firewall(cluster_id="cluster-123", api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/clusters/cluster-123/firewall")
        assert mock_console.print.called

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_firewall_no_rules(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting firewall with no rules."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"rules": []}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_firewall(cluster_id="cluster-456", api=None)

        printed_output = " ".join(str(call) for call in mock_console.print.call_args_list)
        assert "No firewall rules configured" in printed_output

    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_firewall_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ):
        """Test getting firewall with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"rules": []}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_firewall(cluster_id="cluster-789", api="admin")

        mock_api_client.assert_called_once_with(api_type="admin")

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_firewall_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting firewall with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_firewall(cluster_id="nonexistent", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.clusters.get_default_api_type")
    @patch("proxy_platform.commands.clusters.APIClient")
    @patch("proxy_platform.commands.clusters.console")
    def test_get_firewall_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ):
        """Test getting firewall with exception."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = Exception("Connection error")
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_firewall(cluster_id="test", api=None)

        assert exc_info.value.exit_code == 1
