"""Tests for user feedback commands module."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from proxy_platform.commands.feedback import (
    add_comment,
    delete_comment,
    delete_feedback,
    get_feedback,
    list_feedback,
    submit_feedback,
    unvote_feedback,
    update_comment,
    update_feedback,
    vote_feedback,
)

SAMPLE_FEEDBACK = {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "title": "Add dark mode",
    "description": "Please add dark mode support",
    "category": "feature_request",
    "status": "open",
    "vote_count": 5,
    "user_has_voted": False,
    "user_name": "Test User",
    "user_email": "test@example.com",
    "jira_ticket": None,
    "solved_in_release": None,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
}

SAMPLE_COMMENT = {
    "id": "comment-uuid-1234",
    "feedback_id": "550e8400-e29b-41d4-a716-446655440000",
    "user_id": "user-uuid-1234",
    "user_name": "Test User",
    "content": "Great idea!",
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
}

SAMPLE_LIST_RESPONSE = {
    "data": [SAMPLE_FEEDBACK],
    "total": 1,
    "page": 1,
    "limit": 20,
    "offset": 0,
    "has_next": False,
    "has_previous": False,
}


class TestSubmitFeedback:
    """Test cases for submit_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_submit_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test submitting feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = SAMPLE_FEEDBACK
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        submit_feedback(
            title="Add dark mode",
            description="Please add dark mode support",
            category="feature_request",
            api=None,
        )

        mock_get_default_api.assert_called_once()
        mock_api_client.assert_called_once_with(api_type="user")
        mock_client_instance.post.assert_called_once_with(
            "/api/v1/feedback",
            data={
                "title": "Add dark mode",
                "description": "Please add dark mode support",
                "category": "feature_request",
            },
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_submit_feedback_with_explicit_api(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
    ) -> None:
        """Test submitting feedback with explicit API type."""
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = SAMPLE_FEEDBACK
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        submit_feedback(
            title="Bug found",
            description="Login is broken",
            category="bug_report",
            api="user",
        )

        mock_api_client.assert_called_once_with(api_type="user")

    @patch("proxy_platform.commands.feedback.console")
    def test_submit_feedback_invalid_category(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test submitting feedback with invalid category."""
        with pytest.raises(typer.Exit) as exc_info:
            submit_feedback(
                title="Test",
                description="Test description",
                category="invalid_category",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_submit_feedback_error_response(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test submitting feedback with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.json.return_value = {"detail": "Validation error"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            submit_feedback(
                title="Test",
                description="Test",
                category="bug_report",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_submit_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test submitting feedback with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection error")

        with pytest.raises(typer.Exit) as exc_info:
            submit_feedback(
                title="Test",
                description="Test",
                category="bug_report",
                api=None,
            )

        assert exc_info.value.exit_code == 1


class TestListFeedback:
    """Test cases for list_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_LIST_RESPONSE
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=20, page=1, category=None, status=None, api=None)

        mock_get_default_api.assert_called_once()
        mock_client_instance.get.assert_called_once_with("/api/v1/feedback", params={"per_page": 20, "page": 1})
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_with_filters(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback with category and status filters."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_LIST_RESPONSE
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=10, page=2, category="bug_report", status="open", api=None)

        mock_client_instance.get.assert_called_once_with(
            "/api/v1/feedback",
            params={"per_page": 10, "page": 2, "category": "bug_report", "status": "open"},
        )

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_with_has_next(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback that has more pages."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [SAMPLE_FEEDBACK],
            "total": 50,
            "page": 1,
            "limit": 20,
            "offset": 0,
            "has_next": True,
            "has_previous": False,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=20, page=1, category=None, status=None, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_empty(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback when no items found."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [],
            "total": 0,
            "page": 1,
            "limit": 20,
            "offset": 0,
            "has_next": False,
            "has_previous": False,
        }
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        list_feedback(limit=20, page=1, category=None, status=None, api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_invalid_category(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test listing feedback with invalid category."""
        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=20, page=1, category="invalid", status=None, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_invalid_status(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test listing feedback with invalid status."""
        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=20, page=1, category=None, status="invalid_status", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback with error response."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal server error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=20, page=1, category=None, status=None, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_list_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test listing feedback with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            list_feedback(limit=20, page=1, category=None, status=None, api=None)

        assert exc_info.value.exit_code == 1


class TestGetFeedback:
    """Test cases for get_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_get_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test getting feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_FEEDBACK
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000", api=None)

        mock_client_instance.get.assert_called_once_with("/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000")
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_get_feedback_with_comments_and_extra_fields(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test getting feedback with comments and extra fields."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        feedback_with_extras = dict(SAMPLE_FEEDBACK)
        feedback_with_extras["user_has_voted"] = True
        feedback_with_extras["jira_ticket"] = "PBD-123"
        feedback_with_extras["solved_in_release"] = "v2.0"
        feedback_with_extras["comments"] = [SAMPLE_COMMENT]
        mock_response.json.return_value = feedback_with_extras
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        get_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000", api=None)

        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_get_feedback_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test getting feedback that doesn't exist."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Feedback not found"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_feedback(feedback_id="nonexistent-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_get_feedback_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test getting feedback with server error."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.get.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            get_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_get_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test getting feedback with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            get_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1


class TestUpdateFeedback:
    """Test cases for update_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        # Mock GET for fetching current values
        get_response = MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = SAMPLE_FEEDBACK

        # Mock PUT for updating
        put_response = MagicMock()
        put_response.status_code = 200
        updated = dict(SAMPLE_FEEDBACK)
        updated["title"] = "Updated title"
        put_response.json.return_value = updated

        mock_client_instance.get.return_value = get_response
        mock_client_instance.put.return_value = put_response
        mock_api_client.return_value = mock_client_instance

        update_feedback(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            title="Updated title",
            description=None,
            category=None,
            api=None,
        )

        mock_client_instance.put.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000",
            data={
                "title": "Updated title",
                "description": SAMPLE_FEEDBACK["description"],
                "category": SAMPLE_FEEDBACK["category"],
            },
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_all_fields(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating all fields of feedback."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        get_response = MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = SAMPLE_FEEDBACK

        put_response = MagicMock()
        put_response.status_code = 200
        put_response.json.return_value = dict(SAMPLE_FEEDBACK)

        mock_client_instance.get.return_value = get_response
        mock_client_instance.put.return_value = put_response
        mock_api_client.return_value = mock_client_instance

        update_feedback(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            title="New title",
            description="New description",
            category="improvement",
            api=None,
        )

        mock_client_instance.put.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000",
            data={
                "title": "New title",
                "description": "New description",
                "category": "improvement",
            },
        )

    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_invalid_category(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test updating feedback with invalid category."""
        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title=None,
                description=None,
                category="invalid",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_no_fields(
        self,
        mock_console: MagicMock,
    ) -> None:
        """Test updating feedback with no fields provided."""
        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title=None,
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_get_fails(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback when initial GET fails."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        get_response = MagicMock()
        get_response.status_code = 404
        mock_client_instance.get.return_value = get_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title="New title",
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_forbidden(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback when user is not the owner."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        get_response = MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = SAMPLE_FEEDBACK

        put_response = MagicMock()
        put_response.status_code = 403
        put_response.json.return_value = {"detail": "Forbidden"}
        mock_client_instance.get.return_value = get_response
        mock_client_instance.put.return_value = put_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title="New title",
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback that doesn't exist (PUT returns 404)."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        get_response = MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = SAMPLE_FEEDBACK

        put_response = MagicMock()
        put_response.status_code = 404
        put_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.get.return_value = get_response
        mock_client_instance.put.return_value = put_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="nonexistent-id",
                title="New title",
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback with other error status."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()

        get_response = MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = SAMPLE_FEEDBACK

        put_response = MagicMock()
        put_response.status_code = 500
        put_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.get.return_value = get_response
        mock_client_instance.put.return_value = put_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title="New title",
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating feedback with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            update_feedback(
                feedback_id="some-id",
                title="New title",
                description=None,
                category=None,
                api=None,
            )

        assert exc_info.value.exit_code == 1


class TestDeleteFeedback:
    """Test cases for delete_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_feedback_success_with_yes(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback successfully with --yes flag."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_feedback(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            yes=True,
            api=None,
        )

        mock_client_instance.delete.assert_called_once_with("/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000")
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    @patch("proxy_platform.commands.feedback.typer.confirm")
    def test_delete_feedback_cancelled(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback when user cancels confirmation."""
        mock_get_default_api.return_value = "user"
        mock_confirm.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(
                feedback_id="some-id",
                yes=False,
                api=None,
            )

        assert exc_info.value.exit_code == 0

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    @patch("proxy_platform.commands.feedback.typer.confirm")
    def test_delete_feedback_confirmed(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback when user confirms."""
        mock_get_default_api.return_value = "user"
        mock_confirm.return_value = True
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_feedback(
            feedback_id="some-id",
            yes=False,
            api=None,
        )

        mock_client_instance.delete.assert_called_once()

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_feedback_forbidden(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback when not the owner."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.json.return_value = {"detail": "Forbidden"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="some-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_feedback_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback that doesn't exist."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="nonexistent-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_feedback_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback with other error."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="some-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting feedback with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            delete_feedback(feedback_id="some-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1


class TestVoteFeedback:
    """Test cases for vote_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_vote_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test voting on feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        vote_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000", api=None)

        mock_client_instance.post.assert_called_once_with("/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000/vote")
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_vote_feedback_already_voted(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test voting when already voted returns 409."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 409
        mock_response.json.return_value = {"detail": "Already voted"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            vote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_vote_feedback_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test voting on non-existent feedback."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            vote_feedback(feedback_id="nonexistent-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_vote_feedback_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test voting with other error status."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            vote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_vote_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test voting with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            vote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1


class TestUnvoteFeedback:
    """Test cases for unvote_feedback command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_unvote_feedback_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test removing vote from feedback successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        unvote_feedback(feedback_id="550e8400-e29b-41d4-a716-446655440000", api=None)

        mock_client_instance.delete.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000/vote"
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_unvote_feedback_not_voted(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test removing vote when not voted returns 404."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "You have not voted on this feedback"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            unvote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_unvote_feedback_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test removing vote with other error status."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            unvote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_unvote_feedback_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test removing vote with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            unvote_feedback(feedback_id="some-id", api=None)

        assert exc_info.value.exit_code == 1


class TestAddComment:
    """Test cases for add_comment command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_add_comment_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test adding a comment successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = SAMPLE_COMMENT
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        add_comment(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            content="Great idea!",
            api=None,
        )

        mock_client_instance.post.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000/comments",
            data={"content": "Great idea!"},
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_add_comment_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test adding comment to non-existent feedback."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            add_comment(feedback_id="nonexistent-id", content="Comment", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_add_comment_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test adding comment with other error."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.post.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            add_comment(feedback_id="some-id", content="Comment", api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_add_comment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test adding comment with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            add_comment(feedback_id="some-id", content="Comment", api=None)

        assert exc_info.value.exit_code == 1


class TestUpdateComment:
    """Test cases for update_comment command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_comment_success(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating a comment successfully."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        updated_comment = dict(SAMPLE_COMMENT)
        updated_comment["content"] = "Updated comment"
        mock_response.json.return_value = updated_comment
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        update_comment(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            comment_id="comment-uuid-1234",
            content="Updated comment",
            api=None,
        )

        mock_client_instance.put.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000/comments/comment-uuid-1234",
            data={"content": "Updated comment"},
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_comment_forbidden(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating comment when not the owner."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.json.return_value = {"detail": "Forbidden"}
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                content="Updated",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_comment_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating non-existent comment."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_comment(
                feedback_id="some-id",
                comment_id="nonexistent-id",
                content="Updated",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_comment_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating comment with other error."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.put.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            update_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                content="Updated",
                api=None,
            )

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_update_comment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test updating comment with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            update_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                content="Updated",
                api=None,
            )

        assert exc_info.value.exit_code == 1


class TestDeleteComment:
    """Test cases for delete_comment command."""

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_comment_success_with_yes(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment successfully with --yes flag."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_comment(
            feedback_id="550e8400-e29b-41d4-a716-446655440000",
            comment_id="comment-uuid-1234",
            yes=True,
            api=None,
        )

        mock_client_instance.delete.assert_called_once_with(
            "/api/v1/feedback/550e8400-e29b-41d4-a716-446655440000/comments/comment-uuid-1234"
        )
        assert mock_console.print.called

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    @patch("proxy_platform.commands.feedback.typer.confirm")
    def test_delete_comment_cancelled(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment when user cancels."""
        mock_get_default_api.return_value = "user"
        mock_confirm.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(
                feedback_id="some-id",
                comment_id="comment-id",
                yes=False,
                api=None,
            )

        assert exc_info.value.exit_code == 0

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    @patch("proxy_platform.commands.feedback.typer.confirm")
    def test_delete_comment_confirmed(
        self,
        mock_confirm: MagicMock,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment when user confirms."""
        mock_get_default_api.return_value = "user"
        mock_confirm.return_value = True
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        delete_comment(
            feedback_id="some-id",
            comment_id="comment-id",
            yes=False,
            api=None,
        )

        mock_client_instance.delete.assert_called_once()

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_comment_forbidden(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment when not the owner."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.json.return_value = {"detail": "Forbidden"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(feedback_id="some-id", comment_id="comment-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_comment_not_found(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting non-existent comment."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Not found"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(feedback_id="some-id", comment_id="nonexistent-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_comment_other_error(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment with other error."""
        mock_get_default_api.return_value = "user"
        mock_client_instance = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client_instance.delete.return_value = mock_response
        mock_api_client.return_value = mock_client_instance

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(feedback_id="some-id", comment_id="comment-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1

    @patch("proxy_platform.commands.feedback.get_default_api_type")
    @patch("proxy_platform.commands.feedback.APIClient")
    @patch("proxy_platform.commands.feedback.console")
    def test_delete_comment_exception(
        self,
        mock_console: MagicMock,
        mock_api_client: MagicMock,
        mock_get_default_api: MagicMock,
    ) -> None:
        """Test deleting comment with exception."""
        mock_get_default_api.return_value = "user"
        mock_api_client.side_effect = Exception("Connection failed")

        with pytest.raises(typer.Exit) as exc_info:
            delete_comment(feedback_id="some-id", comment_id="comment-id", yes=True, api=None)

        assert exc_info.value.exit_code == 1
