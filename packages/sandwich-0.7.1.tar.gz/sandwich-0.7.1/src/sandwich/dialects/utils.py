from typing import Any

from sqlalchemy import Table


def get_columns_list(table: Table, sep: str = ", ", alias: str | None = None):
    alias = alias + "." if alias else ""
    return sep.join([f"{alias or ''}[{fld.name}]" for fld in table.columns.values()])


def parse_auto_generated_header(full_proc_text: str) -> dict[str, Any]:
    started = False
    rows_in_header = 0
    result: dict[str, Any] = {}
    for ln in full_proc_text.splitlines():
        if started:
            rows_in_header += 1
            if ln.lstrip().startswith("Created on"):
                result["created_on"] = ln.split(":", 1)[1].strip()
            elif ln.lstrip().startswith("Updated on"):
                result["updated_on"] = ln.split(":", 1)[1].strip()
            elif ln.strip() == "*/":
                break
            else:
                continue
        if ln.strip() == "/*":
            started = True
            continue
    result["rows_in_header"] = rows_in_header - 1 if rows_in_header > 0 else 0
    return result
