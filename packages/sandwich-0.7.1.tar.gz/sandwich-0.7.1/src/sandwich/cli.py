import click
from sqlalchemy import create_engine

from sandwich.dialects import DialectHandlerFactory
from sandwich.dwh import init_db, register_and_create_entity
from sandwich.modeling.metadata import modeling_metadata

ALLOWED_DIALECTS_LIST = list(DialectHandlerFactory._handlers.keys())
ALLOWED_DIALECTS_STR = ", ".join(ALLOWED_DIALECTS_LIST)
PROFILES_LIST = modeling_metadata.profiles
PROFILES_STR = ", ".join(PROFILES_LIST)


@click.group()
@click.pass_context
@click.version_option()
def sandwich(ctx):
    ctx.auto_envvar_prefix = "SANDWICH"


def validate_dialect(ctx, param, value):
    if value in ALLOWED_DIALECTS_LIST:
        return value
    else:
        ctx.fail(
            f"Wrong `{param.name}` value. Allowed values are [{ALLOWED_DIALECTS_STR}]"
        )


def validate_profile(ctx, param, value):
    if value in PROFILES_LIST:
        return value
    else:
        ctx.fail(f"Wrong `{param.name}` value. Allowed values are [{PROFILES_STR}]")


@sandwich.command()
@click.option(
    "--dialect",
    prompt=f"Dialect [{ALLOWED_DIALECTS_STR}]",
    help=f"Allowed values: [{ALLOWED_DIALECTS_STR}]",
    callback=validate_dialect,
)
@click.option("--server", prompt=True, help="Name of the database server")
@click.option("--db", prompt=True, help="Name of the database")
@click.option(
    "--user", allow_from_autoenv=True, help="Username for the database server"
)
@click.option(
    "--password",
    allow_from_autoenv=True,
    hide_input=True,
    help="Password for the database server",
)
@click.option(
    "--drop",
    is_flag=True,
    confirmation_prompt="Are you sure you want to drop existing database objects before initialization? If you have any entities created they will be lost.",
    help="Drop existing system objects",
)
def init(
    user: str | None,
    password: str | None,
    server: str,
    db: str,
    dialect: str,
    drop: bool,
):
    if dialect == "mssql":
        if user is None:
            url = f"mssql+pymssql://{server}/{db}"
        else:
            url = f"mssql+pymssql://{user}:{password}@{server}/{db}"
    elif dialect == "postgres":
        url = f"postgresql+psycopg2://{user}:{password}@{server}/{db}"
    else:
        raise Exception(
            f"Please provide a valid database type dialect: {ALLOWED_DIALECTS_STR}"
        )

    with create_engine(url).begin() as conn:
        init_db(conn, dialect, drop_existing=drop)


@sandwich.group()
def entity(): ...


@entity.command()
@click.argument("entity")
@click.option(
    "--schema", default="stg", help="Database schema where entity view is located"
)
@click.option(
    "--profile",
    prompt=f"Profile [{PROFILES_STR}]",
    help=f"Allowed values: [{PROFILES_STR}]",
    callback=validate_profile,
)
@click.option(
    "--dialect",
    prompt=f"Dialect [{ALLOWED_DIALECTS_STR}]",
    help=f"Allowed values: [{ALLOWED_DIALECTS_STR}]",
    callback=validate_dialect,
)
@click.option("--server", prompt=True, help="Name of the database server")
@click.option("--db", prompt=True, help="Name of the database")
@click.option(
    "--user", allow_from_autoenv=True, help="Username for the database server"
)
@click.option(
    "--password",
    allow_from_autoenv=True,
    hide_input=True,
    help="Password for the database server",
)
@click.option(
    "--drop",
    is_flag=True,
    confirmation_prompt="Are you sure you want to drop existing database objects before initialization? If you have any entities created they will be lost.",
    help="Drop existing system objects",
)
def add(
    entity: str,
    schema: str,
    profile: str,
    user: str | None,
    password: str | None,
    server: str,
    db: str,
    dialect: str,
    drop: bool,
):
    if dialect == "mssql":
        if user is None:
            url = f"mssql+pymssql://{server}/{db}"
        else:
            url = f"mssql+pymssql://{user}:{password}@{server}/{db}"
    elif dialect == "postgres":
        url = f"postgresql+psycopg2://{user}:{password}@{server}/{db}"
    else:
        raise Exception(
            f"Please provide a valid database type dialect: {ALLOWED_DIALECTS_STR}"
        )

    with create_engine(url).begin() as conn:
        register_and_create_entity(
            entity,
            conn,
            dialect,
            profile,
            schema,
            drop_first=drop,
            verbose=True,
        )
