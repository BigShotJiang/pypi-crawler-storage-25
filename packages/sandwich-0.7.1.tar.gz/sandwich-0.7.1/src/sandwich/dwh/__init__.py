from datetime import datetime

from sqlalchemy import Connection, MetaData, select, Table, text

from sandwich import SANDWICH_VERSION
from sandwich.dialects import DialectHandlerFactory
from sandwich.modeling.dataclasses import StgInfo, Dv2SystemInfo, Dv2Entity
from sandwich.modeling.metadata import modeling_metadata
from sandwich.modeling.strategies import SchemaGenerator, StrategyFactory
from sandwich.modeling.utils import get_stg_info, infer_profile


def register_entity(
    stg_info: StgInfo, profile: str, conn: Connection, verbose: bool = False
) -> Dv2Entity:
    sys_entities = Table("entities", MetaData(), schema="core", autoload_with=conn)
    entity_row = conn.execute(
        select(
            sys_entities.c.created,
            sys_entities.c.profile,
            sys_entities.c.entity_schema,
            sys_entities.c.is_deleted,
        ).where(sys_entities.c.entity_name == stg_info.stg_name)
    ).one_or_none()

    entity = Dv2Entity(
        stg_info.stg_name,
        stg_info.stg_schema,
        profile,
        entity_row.created if entity_row else datetime.now(),
        SANDWICH_VERSION,
    )

    if entity_row is None:
        conn.execute(
            sys_entities.insert().values(
                entity_name=entity.entity_name,
                entity_schema=entity.schema,
                profile=entity.profile,
                version=entity.version,
                created=entity.created_on,
                updated=entity.created_on,
            )
        )
        if verbose:
            print(
                f"[ok] Registered `{entity.entity_name}` for `{entity.profile}` on {entity.created_on}"
            )
    else:
        if (
            entity_row.entity_schema != entity.schema
            and entity_row.is_deleted is False
            and (entity_row.entity_schema, entity.schema)
            not in modeling_metadata.supported_schema_upgrades
        ):
            raise Exception(
                f"This schema upgrade is not supported. You're trying to upgrade `{entity.entity_name}` entity's schema from `{entity_row.entity_schema}` to `{entity.schema}` which is not allowed"
            )
        if (
            entity_row.profile != entity.profile
            and entity_row.is_deleted is False
            and (entity_row.profile, entity.profile)
            not in modeling_metadata.supported_profile_upgrades
        ):
            raise Exception(
                f"This profile upgrade is not supported. You're trying to upgrade `{entity.entity_name}` entity from `{entity_row.profile}` profile to `{entity.profile}` which is not allowed"
            )

        _update_entity(entity, conn, sys_entities, verbose=verbose)

    return entity


def _update_entity(
    entity: Dv2Entity,
    conn: Connection,
    sys_entities: Table,
    verbose: bool = False,
) -> None:
    conn.execute(
        sys_entities.update()
        .where(sys_entities.c.entity_name == entity.entity_name)
        .values(
            updated=datetime.now(),
            profile=entity.profile,
            entity_schema=entity.schema,
            version=entity.version,
            deleted=None,
            is_deleted=False,
        )
    )
    if verbose:
        print(f"[ok] Updated `{entity.entity_name}`")


def generate_schema(
    schema_generator: SchemaGenerator,
    conn: Connection,
    drop_first: bool = False,
    verbose: bool = False,
) -> None:
    tables = schema_generator.make_tables()
    for table_type, table in tables.items():
        if table is not None:
            if drop_first:
                table.drop(conn, checkfirst=True)
                if verbose:
                    print(
                        f"[ok] (possibly) Dropped table [{table.schema}].[{table.name}]"
                    )
            table.create(conn, checkfirst=True)
            if verbose:
                print(f"[ok] (possibly) Created table [{table.schema}].[{table.name}]")

    procedures = schema_generator.make_procedures(tables)
    for proc_type, (proc_code, proc_name, _) in procedures.items():
        conn.execute(text(proc_code))
        if verbose:
            print(f"[ok] Created or altered {proc_name}")


def _generate_schema_for_entity(
    stg_info: StgInfo,
    conn: Connection,
    dialect: str,
    entity: Dv2Entity,
    drop_first: bool = False,
    verbose: bool = False,
) -> None:
    validator = StrategyFactory.create_validator(entity.profile)
    dialect_handler = DialectHandlerFactory.create_handler(dialect)
    sys_info = get_system_info(conn)
    validation_result = validator.validate_staging(stg_info, sys_info)
    schema_generator = StrategyFactory.create_generator(
        dialect_handler, validation_result, entity
    )
    generate_schema(schema_generator, conn, drop_first=drop_first, verbose=verbose)


def register_and_create_entity(
    entity_name: str,
    conn: Connection,
    dialect: str,
    profile: str | None = None,
    schema: str = "stg",
    drop_first: bool = False,
    verbose: bool = False,
) -> None:
    stg_info = get_stg_info(entity_name, schema, conn)
    if profile is None:
        profile = infer_profile(stg_info)
    entity = register_entity(stg_info, profile, conn)
    _generate_schema_for_entity(
        stg_info,
        conn,
        dialect,
        entity,
        drop_first=drop_first,
        verbose=verbose,
    )


def update_registered_entities(
    conn: Connection,
    dialect: str,
    drop_first: bool = False,
    verbose: bool = False,
) -> None:
    sys_info = get_system_info(conn)
    for entity_ in sys_info.entities_list:
        if entity_.version != SANDWICH_VERSION:
            stg_info = get_stg_info(entity_.entity_name, entity_.schema, conn)
            _update_entity(entity_, conn, sys_info.sys_entities, verbose=verbose)
            _generate_schema_for_entity(
                stg_info,
                conn,
                dialect,
                entity_,
                drop_first=drop_first,
                verbose=verbose,
            )


def get_system_info(conn: Connection):
    sys_entities = Table("entities", MetaData(), schema="core", autoload_with=conn)
    select_result = conn.execute(
        sys_entities.select().where(~sys_entities.c.is_deleted)
    )
    return Dv2SystemInfo(
        [
            Dv2Entity(
                en["entity_name"],
                en["entity_schema"],
                en["profile"],
                en["created"],
                en["version"],
            )
            for en in select_result.mappings().all()
        ],
        sys_entities,
    )


def init_db(
    conn: Connection, dialect: str, drop_existing: bool = False, verbose: bool = False
) -> None:
    dialect_handler = DialectHandlerFactory.create_handler(dialect)
    header = modeling_metadata.HEADER_TEMPLATE.format(
        created_on=datetime.now(),
        updated_on=datetime.now(),
        version=SANDWICH_VERSION,
        entity_name="SYSTEM",
    )
    init_scripts = dialect_handler.get_initialization_scripts(header, 66, drop_existing)
    for name, script in init_scripts.items():
        if verbose:
            print(f"[ok] Executing script: {name}")
        conn.execute(text(script))
