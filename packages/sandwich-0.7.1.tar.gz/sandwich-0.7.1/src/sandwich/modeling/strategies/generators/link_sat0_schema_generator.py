from typing import Tuple

from sqlalchemy import Table, MetaData, Column

from sandwich.dialects import DialectHandler
from sandwich.modeling.dataclasses import ValidationResult, Dv2Entity
from sandwich.modeling.metadata import modeling_metadata

from .link_schema_generator import LinkSchemaGenerator


class LinkSat0SchemaGenerator(LinkSchemaGenerator):
    def __init__(
        self,
        dialect_handler: DialectHandler,
        validation_result: ValidationResult,
        entity: Dv2Entity,
    ):
        super().__init__(dialect_handler, validation_result, entity)
        self._on_make_procedures.append(self._make_sat_proc)

    def make_tables(self) -> dict[str, Table]:
        result = super().make_tables()  # link is already there from LinkSchemaGenerator
        result["sat"] = self.make_sat_table()
        return result

    def make_sat_table(self) -> Table:
        entity_name = self._validation_result.entity_name

        # Create sat table
        sat_table = Table(entity_name, MetaData(), schema="sat")

        # own HK
        for hk_key in self._validation_result.hk_keys:
            if hk_key[0] == f"hk_{entity_name}":
                col = Column(hk_key[0], hk_key[1], primary_key=True)
                sat_table.append_column(col)

        # LoadDate
        load_date = modeling_metadata.loaddate
        load_date_type = self._validation_result.system_column_types[load_date]
        load_date_col = Column(load_date, load_date_type, nullable=False)
        sat_table.append_column(load_date_col)

        # RecordSource
        record_source = modeling_metadata.recordsource
        record_source_type = self._validation_result.system_column_types[record_source]
        record_source_col = Column(record_source, record_source_type, nullable=False)
        sat_table.append_column(record_source_col)

        # for transactional links
        for dpc_name, dpc_type in self._validation_result.dependent_child_key.items():
            sat_table.append_column(Column(dpc_name, dpc_type, nullable=False))

        for name_, type_ in self._validation_result.business_column_types.items():
            col = Column(name_, type_, nullable=True)
            sat_table.append_column(col)

        return sat_table

    def make_fact_table(self) -> Table:
        entity_name = self._validation_result.entity_name

        # Create a fact table
        fact_table = Table(entity_name, MetaData(), schema="fact")

        # not own HKs only
        for hk_key in self._validation_result.hk_keys:
            if hk_key[0] != f"hk_{entity_name}":
                col = Column(hk_key[0], hk_key[1], primary_key=True)
                fact_table.append_column(col)

        for name_, type_ in self._validation_result.business_column_types.items():
            col = Column(name_, type_, nullable=True)
            fact_table.append_column(col)

        return fact_table

    def _make_sat_proc(
        self, procedures: dict[str, Tuple[str, str, str]], tables: dict[str, Table]
    ) -> None:
        sat_proc_code, sat_proc_name, sat_call_stmt = (
            self.dialect_handler.make_scd0_sat_proc(
                sat_table=tables["sat"], header=self.header
            )
        )
        procedures["sat"] = (sat_proc_code, sat_proc_name, sat_call_stmt)
