from typing import Tuple, Any

from sqlalchemy import Table, MetaData, Column, UniqueConstraint

from sandwich.dialects import DialectHandler
from sandwich.modeling.dataclasses import ValidationResult, Dv2Entity
from sandwich.modeling.metadata import modeling_metadata

from .base_schema_generator import BaseSchemaGenerator


class LinkSchemaGenerator(BaseSchemaGenerator):
    def __init__(
        self,
        dialect_handler: DialectHandler,
        validation_result: ValidationResult,
        entity: Dv2Entity,
    ):
        super().__init__(dialect_handler, validation_result, entity)
        self._on_make_procedures.append(self._make_all_procs)

    def make_tables(self) -> dict[str, Table]:
        return {
            "link": self.make_link_table(),
        }

    def make_link_table(self) -> Table:
        entity_name = self._validation_result.entity_name

        # Create link table
        link_table = Table(entity_name, MetaData(), schema="link")
        uks: list[str] = []

        # HKs (own and FKs)
        for hk_key in self._validation_result.hk_keys:
            if hk_key[0] == f"hk_{entity_name}":
                col = Column(hk_key[0], hk_key[1], primary_key=True)
            else:
                uks.append(hk_key[0])
                col = Column(hk_key[0], hk_key[1], nullable=False)
            link_table.append_column(col)

        for dpc_name, dpc_type in self._validation_result.dependent_child_key.items():
            link_table.append_column(Column(dpc_name, dpc_type, nullable=False))
            uks.append(dpc_name)

        link_table.append_constraint(UniqueConstraint(*uks))

        # LoadDate
        load_date = modeling_metadata.loaddate
        load_date_type = self._validation_result.system_column_types[load_date]
        load_date_col = Column(load_date, load_date_type, nullable=False)
        link_table.append_column(load_date_col)

        # RecordSource
        record_source = modeling_metadata.recordsource
        record_source_type = self._validation_result.system_column_types[record_source]
        record_source_col = Column(record_source, record_source_type, nullable=False)
        link_table.append_column(record_source_col)

        return link_table

    def _make_all_procs(
        self, procedures: dict[str, Tuple[str, str, str]], tables: dict[str, Table]
    ) -> None:
        if self._validation_result.stg_schema == "proxy":
            stg_proc_code, stg_proc_name, stg_call_stmt = (
                self.dialect_handler.make_stg_materialization_proc(
                    entity_name=self._validation_result.entity_name, header=self.header
                )
            )
            procedures["stg"] = (stg_proc_code, stg_proc_name, stg_call_stmt)

        dpc_keys: list[Tuple[str, Any]] = [
            (k, v) for k, v in self._validation_result.dependent_child_key.items()
        ]
        link_proc_code, link_proc_name, link_call_stmt = (
            self.dialect_handler.make_link_proc(
                link_table=tables["link"],
                hk_keys=self._validation_result.hk_keys + dpc_keys,
                header=self.header,
            )
        )
        procedures["link"] = (link_proc_code, link_proc_name, link_call_stmt)
