from typing import Tuple, override

from sqlalchemy import Column, MetaData, Table

from sandwich.dialects.base import DialectHandler
from sandwich.modeling.dataclasses import ValidationResult, Dv2Entity
from sandwich.modeling.metadata import modeling_metadata

from .hub_schema_generator import HubSchemaGenerator


class HubSat1SchemaGenerator(HubSchemaGenerator):
    def __init__(
        self,
        dialect_handler: DialectHandler,
        validation_result: ValidationResult,
        entity: Dv2Entity,
    ):
        super().__init__(dialect_handler, validation_result, entity)
        self._on_make_procedures.extend([self._make_sat1_proc])

    @override
    def make_tables(self) -> dict[str, Table]:
        result = super().make_tables()  # hub is already there
        result["sat"] = self.make_sat_table()
        return result

    def make_sat_table(self) -> Table:
        entity_name = self._validation_result.entity_name

        # Create sat table
        sat_table = Table(entity_name, MetaData(), schema="sat")

        # BKs
        for bk_key in self._validation_result.bk_keys:
            col = Column(bk_key[0], bk_key[1], nullable=False)
            sat_table.append_column(col)

        # own HK
        for hk_key in self._validation_result.hk_keys:
            if hk_key[0] == f"hk_{entity_name}":
                col = Column(hk_key[0], hk_key[1], primary_key=True)
                sat_table.append_column(col)

        # LoadDate
        load_date = modeling_metadata.loaddate
        load_date_type = self._validation_result.system_column_types[load_date]
        load_date_col = Column(load_date, load_date_type, nullable=False)
        sat_table.append_column(load_date_col)

        # RecordSource
        record_source = modeling_metadata.recordsource
        record_source_type = self._validation_result.system_column_types[record_source]
        record_source_col = Column(record_source, record_source_type, nullable=False)
        sat_table.append_column(record_source_col)

        for name_, type_ in self._validation_result.business_column_types.items():
            col = Column(name_, type_, nullable=True)
            sat_table.append_column(col)

        return sat_table

    def _make_sat1_proc(
        self, procedures: dict[str, Tuple[str, str, str]], tables: dict[str, Table]
    ) -> None:
        sat_proc_code, sat_proc_name, sat_call_stmt = (
            self.dialect_handler.make_scd1_sat_proc(
                sat_table=tables["sat"],
                header=self.header,
            )
        )
        procedures["sat"] = (sat_proc_code, sat_proc_name, sat_call_stmt)
