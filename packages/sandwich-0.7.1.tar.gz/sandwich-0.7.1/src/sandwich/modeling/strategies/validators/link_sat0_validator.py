from .link_based_validator import LinkBasedValidator


class LinkSat0Validator(LinkBasedValidator):
    def __init__(self):
        super().__init__()
