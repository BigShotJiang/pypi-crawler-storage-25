from dataclasses import dataclass
from datetime import datetime
from typing import Any, Tuple

from sqlalchemy import Table


@dataclass(frozen=True)
class Dv2Entity:
    entity_name: str
    schema: str
    profile: str
    created_on: datetime
    version: str


@dataclass(frozen=True)
class StgInfo:
    stg_name: str
    stg_schema: str
    hk_keys: dict[str, Any]
    bk_keys: dict[str, Any]
    sys_columns: dict[str, Any]
    bus_columns: dict[str, Any]
    dependent_child_key: dict[str, Any]


@dataclass(frozen=True)
class Dv2SystemInfo:
    entities_list: list[Dv2Entity]
    sys_entities: Table


class ValidationResult:
    """Wrapper for `StgInfo`.
    Its only purpose is to force the code to execute validation
    by making all code that generates SQL, dependent on `ValidationResult`
    """

    def __init__(self, stg_info: StgInfo) -> None:
        self.stg_info = stg_info

    @property
    def entity_name(self) -> str:
        return self.stg_info.stg_name

    @property
    def stg_schema(self) -> str:
        return self.stg_info.stg_schema

    @property
    def bk_keys(self) -> list[Tuple[str, Any]]:
        return [(nm, tp) for nm, tp in self.stg_info.bk_keys.items()]

    @property
    def hk_keys(self) -> list[Tuple[str, Any]]:
        return [(nm, tp) for nm, tp in self.stg_info.hk_keys.items()]

    @property
    def business_column_types(self) -> dict[str, Any]:
        return self.stg_info.bus_columns

    @property
    def system_column_types(self) -> dict[str, Any]:
        return self.stg_info.sys_columns

    @property
    def dependent_child_key(self) -> dict[str, Any]:
        return self.stg_info.dependent_child_key


# @dataclass(frozen=True)
# class ValidationResult:
#     stg_schema: str
#     entity_name: str
#     bk_keys: list[Tuple[str, Any]]
#     hk_keys: list[Tuple[str, Any]]
#     business_column_types: dict[str, Any]
#     system_column_types: dict[str, Any]
#     profile: str
#     dependent_child_key: dict[str, Any]
