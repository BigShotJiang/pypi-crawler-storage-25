[![PyPI - Version](https://img.shields.io/pypi/v/sandwich)](https://pypi.org/project/sandwich)
[![Documentation](https://img.shields.io/badge/ref-Documentation-blue)](https://22kittens.gitlab.io/sandwich/)

[![mssql job](https://gitlab.com/22kittens/sandwich/-/raw/badges/badges/test-mssql.svg)](https://gitlab.com/22kittens/sandwich/-/commits/dev)
[![postgres job](https://gitlab.com/22kittens/sandwich/-/raw/badges/badges/test-postgres.svg)](https://gitlab.com/22kittens/sandwich/-/commits/dev)
[![coverage](https://gitlab.com/22kittens/sandwich/badges/dev/coverage.svg?job=test-mssql-coverage)](https://gitlab.com/22kittens/sandwich/-/commits/dev)

> :warning: **Pre-alpha version disclaimer** Please note that this package is in a **pre-alpha** version which means it is used internally in a small circle of users and backwards-incompatible changes might be introduced in future releases.

# Welcome

Welcome to the `sandwich` tool documentation.

[Get started](get-started.md) or go straight to the [Tutorial](tutorial.md)

### What is `sandwich`?

`sandwich` is a Data Vault 2.0 scaffolding tool

You can automatically create Data Vault 2.0 entities, such as `hubs`, `links`, `satellites`, 
as well as information layer objects such as `dim` tables from a multidimensional paradigm.  
It also creates procedures for ELT but does not run them!

> `sandwich` does not support `fact` tables automation just because facts usually too specific to be automated.

Simple usage scenario in 3 steps:

1. you manually create an `Employee` view in `stg` schema using your preferable dbms tool such as SSMS or pgAdmin  

2. you call 
   ```shell
   sandwich create --entity=Employee --dialect=mssql --profile=hub-sat2-dim2
   ```
   from terminal, which creates the following objects in the database:  
   
    ```sql
    hub.Emplyee                         -- table
    sat.Emplyee                         -- table
    dim.Emplyee                         -- SCD2 table  
    elt.Populate_hub_Employee           -- proc  
    elt.Populate_sat_Employee           -- proc  
    elt.Populate_dim_Employee           -- proc
    job.Run_all_related_to_Employee     -- proc which calls the 3 procs from above  
    meta.Drop_all_related_to_Employee   -- proc which drops all objects above  
    ```
   
3. you run `job.Run_all_related_to_Employee` manually using your dbms tool or schedule it using a job/cron system you have

## Installation

You can install `sandwich` via pip:

```shell
pip install sandwich
```

## Usage example

```shell
sandwich init --db=DataVault
sandwich entity add Customer --profile=link-sat0
```

For more examples and detailed usage, please refer to the [documentation](https://22kittens.gitlab.io/sandwich).

## Contributing

Contributions are welcome! If you have suggestions, feature requests, or find any bugs, please open an issue or submit a pull request. Make sure to follow the [contribution guidelines](https://22kittens.gitlab.io/sandwich/CONTRIBUTING).

## Acknowledgments

This project is inspired by the beauty of the Data Vault 2.0 [methodology](https://www.scalefree.com/consulting/data-vault-2-0).

## License

This project is licensed under the [MIT License](https://22kittens.gitlab.io/sandwich/LICENSE).
