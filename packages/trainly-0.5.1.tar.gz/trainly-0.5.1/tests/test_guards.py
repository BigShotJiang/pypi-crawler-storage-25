"""Tests for guardrails module."""

import pytest
from unittest.mock import patch, MagicMock
from trainly.guards import Guard, GuardResult, GuardFailure, _parse_on_fail, run_local_guard
from trainly import TrainlyClient


class TestGuardResult:
    def test_passed_result(self):
        r = GuardResult(passed=True)
        assert r.passed is True
        assert r.reason is None

    def test_failed_result_with_reason(self):
        r = GuardResult(passed=False, reason="Too long")
        assert r.passed is False
        assert r.reason == "Too long"


class TestGuardFailure:
    def test_exception_attributes(self):
        e = GuardFailure(
            guard_name="length_check",
            reason="Output exceeds 5000 chars",
            trace_id="tr_abc123",
            attempts=3,
        )
        assert e.guard_name == "length_check"
        assert e.reason == "Output exceeds 5000 chars"
        assert e.trace_id == "tr_abc123"
        assert e.attempts == 3
        assert "length_check" in str(e)

    def test_inherits_from_exception(self):
        e = GuardFailure(guard_name="test", reason="fail")
        assert isinstance(e, Exception)


class TestGuardFactory:
    def test_dashboard_guard(self):
        g = Guard.dashboard()
        assert g.guard_type == "dashboard"
        assert g.on_fail is None  # inherits from decorator default

    def test_dashboard_guard_with_on_fail(self):
        g = Guard.dashboard(on_fail="retry:3")
        assert g.on_fail == "retry:3"

    def test_cost_limit_guard(self):
        g = Guard.cost_limit(max_usd=0.50)
        assert g.guard_type == "cost_limit"
        assert g.config["max_usd"] == 0.50

    def test_cost_limit_with_on_fail(self):
        g = Guard.cost_limit(0.50, on_fail="stop")
        assert g.on_fail == "stop"

    def test_custom_guard_with_function(self):
        def my_check(output: str) -> bool:
            return "hello" in output

        g = Guard.custom(my_check, name="greeting_check")
        assert g.guard_type == "custom"
        assert g.name == "greeting_check"
        assert g.config["fn"] is my_check

    def test_custom_guard_default_name(self):
        def my_check(output: str) -> bool:
            return True

        g = Guard.custom(my_check)
        assert g.name == "my_check"  # uses function name

    def test_guards_true_shorthand(self):
        guards = Guard._normalize(True)
        assert len(guards) == 1
        assert guards[0].guard_type == "dashboard"

    def test_guards_single(self):
        g = Guard.cost_limit(0.50)
        guards = Guard._normalize(g)
        assert len(guards) == 1

    def test_guards_list(self):
        guards = Guard._normalize([Guard.dashboard(), Guard.cost_limit(0.50)])
        assert len(guards) == 2


class TestParseOnFail:
    def test_stop(self):
        result = _parse_on_fail("stop")
        assert result == {"action": "stop"}

    def test_continue(self):
        result = _parse_on_fail("continue")
        assert result == {"action": "continue"}

    def test_retry_n(self):
        result = _parse_on_fail("retry:3")
        assert result == {"action": "retry", "max_retries": 3, "fallback": "stop"}

    def test_retry_n_continue(self):
        result = _parse_on_fail("retry:5:continue")
        assert result == {"action": "retry", "max_retries": 5, "fallback": "continue"}

    def test_invalid_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid on_fail policy"):
            _parse_on_fail("explode")


class TestRunLocalGuard:
    def test_cost_limit_passing(self):
        g = Guard.cost_limit(max_usd=1.00)
        result = run_local_guard(g, "some output", cost=0.25)
        assert result.passed is True
        assert result.reason is None

    def test_cost_limit_failing(self):
        g = Guard.cost_limit(max_usd=0.50)
        result = run_local_guard(g, "some output", cost=0.75)
        assert result.passed is False
        assert "exceeds limit" in result.reason

    def test_custom_guard_returns_true(self):
        def always_pass(output: str) -> bool:
            return True

        g = Guard.custom(always_pass)
        result = run_local_guard(g, "hello")
        assert result.passed is True

    def test_custom_guard_returns_false(self):
        def always_fail(output: str) -> bool:
            return False

        g = Guard.custom(always_fail)
        result = run_local_guard(g, "hello")
        assert result.passed is False
        assert "returned False" in result.reason

    def test_custom_guard_returns_guard_result(self):
        def checker(output: str) -> GuardResult:
            return GuardResult(passed=False, reason="custom reason")

        g = Guard.custom(checker)
        result = run_local_guard(g, "hello")
        assert result.passed is False
        assert result.reason == "custom reason"

    def test_custom_guard_accepts_optional_kwargs(self):
        def checker(output: str, input: str = "", metadata: dict = None) -> bool:
            return input == "prompt" and metadata.get("key") == "val"

        g = Guard.custom(checker)
        result = run_local_guard(
            g, "response", input="prompt", metadata={"key": "val"}
        )
        assert result.passed is True

    def test_custom_guard_bad_return_type_raises(self):
        def bad_guard(output: str):
            return 42

        g = Guard.custom(bad_guard)
        with pytest.raises(TypeError, match="must return bool or GuardResult"):
            run_local_guard(g, "hello")

    def test_dashboard_guard_type_raises(self):
        g = Guard.dashboard()
        with pytest.raises(ValueError, match="Cannot run guard type"):
            run_local_guard(g, "hello")


class TestClientEvaluate:
    def setup_method(self):
        self.client = TrainlyClient(api_key="tk_test", project_id="proj_test")

    @patch.object(TrainlyClient, '_request_with_retry')
    def test_evaluate_returns_results(self, mock_request):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "passed": True,
            "results": [
                {"scorer": "no_pii", "passed": True, "score": 1.0}
            ],
        }
        mock_request.return_value = mock_response

        result = self.client.evaluate(
            input="test input",
            output="test output",
        )

        assert result["passed"] is True
        assert len(result["results"]) == 1
        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "POST"
        assert "/evaluate" in call_args[0][1]

    @patch.object(TrainlyClient, '_request_with_retry')
    def test_evaluate_sends_all_fields(self, mock_request):
        mock_response = MagicMock()
        mock_response.json.return_value = {"passed": True, "results": []}
        mock_request.return_value = mock_response

        self.client.evaluate(
            input="inp",
            output="out",
            model="gpt-4o",
            metadata={"key": "val"},
            tags=["prod"],
        )

        call_kwargs = mock_request.call_args[1]
        payload = call_kwargs["json"]
        assert payload["input"] == "inp"
        assert payload["output"] == "out"
        assert payload["model"] == "gpt-4o"
        assert payload["metadata"] == {"key": "val"}
        assert payload["tags"] == ["prod"]


class TestObserveWithGuards:
    def setup_method(self):
        self.client = TrainlyClient(api_key="tk_test", project_id="proj_test")

    def test_custom_guard_passes(self):
        """Function runs normally when guard passes."""
        def always_pass(output: str) -> bool:
            return True

        @self.client.observe(guards=[Guard.custom(always_pass)])
        def my_fn(query: str) -> str:
            return "hello world"

        result = my_fn("test")
        assert result == "hello world"

    def test_custom_guard_fails_stops(self):
        """GuardFailure raised when guard fails with on_fail='stop'."""
        def always_fail(output: str) -> GuardResult:
            return GuardResult(passed=False, reason="bad output")

        @self.client.observe(guards=[Guard.custom(always_fail)], on_fail="stop")
        def my_fn(query: str) -> str:
            return "hello world"

        with pytest.raises(GuardFailure) as exc_info:
            my_fn("test")
        assert exc_info.value.guard_name == "always_fail"
        assert "bad output" in exc_info.value.reason

    def test_custom_guard_fails_continue(self):
        """Output returned when guard fails with on_fail='continue'."""
        def always_fail(output: str) -> bool:
            return False

        @self.client.observe(guards=[Guard.custom(always_fail)], on_fail="continue")
        def my_fn(query: str) -> str:
            return "hello world"

        result = my_fn("test")
        assert result == "hello world"

    def test_custom_guard_retry_then_pass(self):
        """Function retried until guard passes."""
        call_count = 0

        def pass_on_second(output: str) -> bool:
            return output == "attempt 2"

        @self.client.observe(guards=[Guard.custom(pass_on_second)], on_fail="retry:3")
        def my_fn(query: str) -> str:
            nonlocal call_count
            call_count += 1
            return f"attempt {call_count}"

        result = my_fn("test")
        assert result == "attempt 2"
        assert call_count == 2

    def test_custom_guard_retry_exhausted_stops(self):
        """GuardFailure raised when retries exhausted with default stop."""
        call_count = 0

        def always_fail(output: str) -> bool:
            return False

        @self.client.observe(guards=[Guard.custom(always_fail)], on_fail="retry:2")
        def my_fn(query: str) -> str:
            nonlocal call_count
            call_count += 1
            return "bad"

        with pytest.raises(GuardFailure) as exc_info:
            my_fn("test")
        assert exc_info.value.attempts == 3  # 1 original + 2 retries
        assert call_count == 3

    def test_custom_guard_retry_exhausted_continue(self):
        """Output returned when retries exhausted with continue fallback."""
        def always_fail(output: str) -> bool:
            return False

        @self.client.observe(guards=[Guard.custom(always_fail)], on_fail="retry:1:continue")
        def my_fn(query: str) -> str:
            return "bad"

        result = my_fn("test")
        assert result == "bad"

    @patch.object(TrainlyClient, 'evaluate')
    def test_dashboard_guard_calls_evaluate(self, mock_evaluate):
        """Dashboard guard calls client.evaluate()."""
        mock_evaluate.return_value = {
            "passed": True,
            "results": [{"scorer": "no_pii", "passed": True, "score": 1.0}],
        }

        @self.client.observe(guards=True, on_fail="stop")
        def my_fn(query: str) -> str:
            return "hello world"

        result = my_fn("test")
        assert result == "hello world"
        mock_evaluate.assert_called_once()

    @patch.object(TrainlyClient, 'evaluate')
    def test_dashboard_guard_fails(self, mock_evaluate):
        """Dashboard guard raises GuardFailure when evaluate returns failed."""
        mock_evaluate.return_value = {
            "passed": False,
            "results": [{"scorer": "no_pii", "passed": False, "score": 0.0, "reason": "PII detected"}],
        }

        @self.client.observe(guards=True, on_fail="stop")
        def my_fn(query: str) -> str:
            return "my email is test@test.com"

        with pytest.raises(GuardFailure) as exc_info:
            my_fn("test")
        assert "no_pii" in exc_info.value.guard_name
        assert "PII" in exc_info.value.reason

    def test_per_guard_on_fail_override(self):
        """Per-guard on_fail overrides decorator default."""
        def always_fail(output: str) -> bool:
            return False

        # Decorator default is "stop", but guard overrides to "continue"
        @self.client.observe(
            guards=[Guard.custom(always_fail, on_fail="continue")],
            on_fail="stop",
        )
        def my_fn(query: str) -> str:
            return "hello"

        result = my_fn("test")
        assert result == "hello"

    def test_guards_none_by_default(self):
        """No guards by default — original behavior."""
        @self.client.observe(model="gpt-4o")
        def my_fn(query: str) -> str:
            return "hello"

        result = my_fn("test")
        assert result == "hello"

    def test_local_guards_run_before_remote(self):
        """Local guards run first; if they fail, remote is not called."""
        def local_fail(output: str) -> bool:
            return False

        @self.client.observe(
            guards=[Guard.custom(local_fail, on_fail="stop"), Guard.dashboard()],
            on_fail="stop",
        )
        def my_fn(query: str) -> str:
            return "hello"

        with pytest.raises(GuardFailure) as exc_info:
            my_fn("test")
        assert exc_info.value.guard_name == "local_fail"


class TestPublicImports:
    def test_import_guard(self):
        from trainly import Guard
        assert Guard.dashboard is not None

    def test_import_guard_result(self):
        from trainly import GuardResult
        assert GuardResult(passed=True).passed is True

    def test_import_guard_failure(self):
        from trainly import GuardFailure
        e = GuardFailure(guard_name="test", reason="test")
        assert isinstance(e, Exception)
