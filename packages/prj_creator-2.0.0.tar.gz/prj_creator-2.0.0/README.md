# Project Creator CLI
A Python script to automate creating folders for your projects. Now with a CLI version for versatality and portability.

## How to Start Using

### Installation
You can install `project-creator` globally via **npm** or **pip** for quick access.

**Python (PyPI):**
```python
pip install prj-creator
```

**Node (NPM)**
```node
npm install -g prj-creator
```
### Launching
Run this in the terminal.
```
prj-creator
```

## Avalible Modules

| Flags | Function |
| --- | --- |
| --firmware | Generates a firmware/ folder with an .ino boilerplate. |
| --hardware | Generates a hardware/ folder |
| --req | Creates a requirement.txt for Python dependencies |
| --venv || Setups a local Python Virtual Environment |
| --web | Creates a web/ folder |

## Features
- **Sequential Indexing:** Automatically numbers your projects (e.g., 01.name, 02.name) to keep your root directory organized.
- **Git Auto-Sync:** Initializes a local repository and links your remote origin instantly.
- **License Injection:** Instantly apply MIT or GPL v3 licenses to your code.

## LICENSE
Distributed under the [MIT License](../LICENSE)

###### Made by @DevX-Dragon , a 14 Y/O developer from Sri Lanka.