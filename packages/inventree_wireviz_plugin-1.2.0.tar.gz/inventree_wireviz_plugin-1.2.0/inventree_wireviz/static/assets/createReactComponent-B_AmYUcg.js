const l="0.10.1";function p(e){var t;const o=((t=e==null?void 0:e.version)==null?void 0:t.inventree)||"";l!=o&&console.info(`Plugin version mismatch! Expected version ${l}, got ${o}`)}/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var v={outline:{xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"},filled:{xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"currentColor",stroke:"none"}};/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=window.React.forwardRef,n=window.React.createElement,E=(e,o,t,c)=>{const i=k(({color:w="currentColor",size:s=24,stroke:d=2,title:a,className:h,children:r,...g},m)=>n("svg",{ref:m,...v[e],width:s,height:s,className:["tabler-icon",`tabler-icon-${o}`,h].join(" "),strokeWidth:d,stroke:w,...g},[a&&n("title",{key:"svg-title"},a),...c.map(([u,f])=>n(u,f)),...Array.isArray(r)?r:[r]]));return i.displayName=`${t}`,i};export{p as a,E as c};
//# sourceMappingURL=createReactComponent-B_AmYUcg.js.map
