# SPDX-FileCopyrightText: 2026 Ashlesha T
# SPDX-License-Identifier: MIT
#
# This file is part of CogniRepo — https://github.com/ashlesh-t/cognirepo
# Licensed under MIT. See LICENSE file in repository root.

"""
Utility to load and retrieve the embedding model.
"""
# pylint: disable=import-error
import logging

from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)

# Silence harmless "UNEXPECTED" weight loading reports from transformers
try:
    import transformers.utils.logging as tf_logging
    tf_logging.set_verbosity_error()
except ImportError:
    pass

MODEL = None


def get_model():
    """
    Returns the SentenceTransformer model, loading it if necessary.
    """
    global MODEL  # pylint: disable=global-statement

    if MODEL is None:
        logger.debug("Loading embedding model once...")
        import os  # pylint: disable=import-outside-toplevel
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        MODEL = SentenceTransformer("all-MiniLM-L6-v2")

    return MODEL


def evict_model() -> None:
    """
    Release the in-memory embedding model to free RAM.

    Called by IdleManager after the idle TTL expires.  The next call to
    get_model() will reload the model from disk (~2 s warm-up).
    """
    global MODEL  # pylint: disable=global-statement
    if MODEL is not None:
        MODEL = None
        logger.info("idle: embedding model evicted from memory")
