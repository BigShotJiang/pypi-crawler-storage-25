#!/Users/christmas/opt/anaconda3/bin/python3
# -*- coding: utf-8 -*-
#  日期 : 2025/10/16 14:13
#  作者 : Christmas
#  邮箱 : 273519355@qq.com
#  项目 : Project
#  版本 : python 3
#  摘要 :
"""
xarray.Dataset for wave
"""
from datetime import datetime
from typing import List, Optional, Sequence, Union

import numpy as np
import pandas as pd
import xarray as xr

from .. import Ttime
from .xr_attrs import (add_lat_attrs, add_lon_attrs, add_time_attrs,
                       add_TIME_attrs, add_wave_attrs, compress_scale_offset,
                       fixed_encoding)

__all__ = ['xr_wave_dateset']


def xr_wave_dateset(_lon: np.ndarray,
                    _lat: np.ndarray,
                    _time: Union[
                        Sequence[Union[str, datetime, np.datetime64, pd.Timestamp]],
                        np.ndarray,
                        pd.DatetimeIndex
                        ],
                    _TIME_type: str = 'char',
                    _COMPRESS: bool = True,
                    _ATTRS_GLOBAL: Optional[dict] = None,
                    _ENCODING_GLOBAL: dict = {},
                    **kwargs):
    """
    生成波浪数据的xarray.Dataset
    :param _lon: 经度
    :param _lat: 纬度
    :param _time: 时间
    :param _TIME_type: TIME变量的类型，默认为'char', 可选项为'char', 'str'
    :param _COMPRESS: 是否压缩数据，默认为True

    :param _ATTRS_GLOBAL: 全局属性，默认为None
        product_name: 产品名称
        source: 数据来源
        start: 数据开始时间
        history: 数据处理历史
        program_version: 程序版本

    :param _ENCODING_GLOBAL: 全局编码，默认为None
        engine: h5netcdf(default), netcdf4, scipy
        dtype: float32(default), float64
        complevel: 4(default) 0-9
        zlib: True(default)
        shuffle: True(default)
        fletcher32: True(default)
        contiguous: True(default)

    :param kwargs: swh, mwd, mwp, mwl, pp1d, shww, shts, mdww, mdts, mpww, mpts, hmax,
                    engine, dtype, complevel, zlib, shuffle, fletcher32, contiguous,
                    product_name, source, start
        swh: significant height of combined wind waves and swell(m) 有效波高
        mwd: mean wave direction (deg) 平均波向
        mwp: mean wave period (s) 平均波周期
        mwl: mean wave length (m) 平均波长
        pp1d: peak period (s) 谱峰周期
        shww: significant height of wind waves (m) 风浪有效波高
        shts: significant height of total swell (m) 涌浪有效波高
        mdww: mean direction of wind waves (deg) 风浪波向
        mdts: mean direction of total swell (deg) 涌浪波向
        mpww: mean period of wind waves (s) 风浪平均周期
        mpts: mean period of total swell (s) 涌浪平均周期
        hmax: expected maximum wave height (linear, 1st order) (m) 最大波高
    :return: xarray.Dataset
    """

    if _time[0].__class__ == str:
        Ttimes = Ttime(TIME=_time)
    elif _time[0].__class__ == datetime or _time[0].__class__ == np.datetime64 or _time[0].__class__ == pd.Timestamp:
        Ttimes = Ttime(Times=_time)
    else:
        raise ValueError(_time[0].__class__)

    if _TIME_type == 'char':
        TIME = Ttimes.TIME_char
    elif _TIME_type == 'str':
        TIME = Ttimes.TIME_str
    else:
        raise ValueError(_TIME_type)

    xr_wave = xr.Dataset(
        data_vars={
            "TIME": ("time", TIME)},
        coords={
            "longitude": _lon,
            "latitude": _lat,
            "time": Ttimes.time,
        },
        attrs={}
    )
    xr_wave = add_lon_attrs(xr_wave, lon_name='longitude')
    xr_wave = add_lat_attrs(xr_wave, lat_name='latitude')
    xr_wave = add_time_attrs(xr_wave, time_name='time')
    xr_wave = add_TIME_attrs(xr_wave, TIME_name='TIME', dim_name='DateStr')
    
    if 'swh' in kwargs:
        xr_wave['swh'] = (("time", "latitude", "longitude"), kwargs.get('swh'))
    
    if 'mwd' in kwargs:
        xr_wave['mwd'] = (("time", "latitude", "longitude"), kwargs.get('mwd'))
    
    if 'mwp' in kwargs:
        xr_wave['mwp'] = (("time", "latitude", "longitude"), kwargs.get('mwp'))
    
    if 'mwl' in kwargs:
        xr_wave['mwl'] = (("time", "latitude", "longitude"), kwargs.get('mwl'))
    
    if 'pp1d' in kwargs:
        xr_wave['pp1d'] = (("time", "latitude", "longitude"), kwargs.get('pp1d'))
    
    if 'shww' in kwargs:
        xr_wave['shww'] = (("time", "latitude", "longitude"), kwargs.get('shww'))
    
    if 'shts' in kwargs:
        xr_wave['shts'] = (("time", "latitude", "longitude"), kwargs.get('shts'))
    
    if 'mdww' in kwargs:
        xr_wave['mdww'] = (("time", "latitude", "longitude"), kwargs.get('mdww'))

    if 'mdts' in kwargs:
        xr_wave['mdts'] = (("time", "latitude", "longitude"), kwargs.get('mdts'))
    
    if 'mpww' in kwargs:
        xr_wave['mpww'] = (("time", "latitude", "longitude"), kwargs.get('mpww'))
    
    if 'mpts' in kwargs:
        xr_wave['mpts'] = (("time", "latitude", "longitude"), kwargs.get('mpts'))
    
    if 'hmax' in kwargs:
        xr_wave['hmax'] = (("time", "latitude", "longitude"), kwargs.get('hmax'))

    xr_wave = add_wave_attrs(xr_wave)
    
    # 去掉上面用过的key
    for key in ['swh', 'mwd', 'mwp', 'mwl', 'pp1d', 'shww', 'shts', 'mdww', 'mdts', 'mpww', 'mpts', 'hmax',
                'product_name', 'source', 'start']:
        if key in kwargs:
            kwargs.pop(key)

    if _ATTRS_GLOBAL is not None:
        xr_wave.attrs.update(_ATTRS_GLOBAL)

    xr_wave = fixed_encoding(xr_wave, **_ENCODING_GLOBAL)

    if _COMPRESS:
        xr_wave = compress_scale_offset(xr_wave)

    return xr_wave
