"""Tests for hook script generation.

The hook template is a thin LXC wrapper: it validates layer paths, mounts the
overlayfs, and delegates guest-side config injection to ``kento-inject.sh``
(see ``tests/test_inject.py``). Tests here only assert template structure.
"""

from pathlib import Path

from kento.hook import generate_hook, write_hook


def test_generate_hook_contains_paths():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b:/c", "test")
    assert 'CONTAINER_DIR="/var/lib/lxc/test"' in script
    assert 'LAYERS="/a:/b:/c"' in script
    assert 'NAME="test"' in script


def test_generate_hook_default_state_dir():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert 'STATE_DIR="/var/lib/lxc/test"' in script


def test_generate_hook_custom_state_dir():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test",
                           state_dir=Path("/home/alice/.local/share/kento/test"))
    assert 'STATE_DIR="/home/alice/.local/share/kento/test"' in script
    assert "$STATE_DIR/upper" in script
    assert "$STATE_DIR/work" in script


def test_generate_hook_has_mount_workaround():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "LIBMOUNT_FORCE_MOUNT2=always" in script
    assert "mount -t overlay" in script


def test_generate_hook_validates_layers():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "layer path missing" in script
    assert "kento scrub $NAME" in script


def test_generate_hook_has_pre_start_pre_mount_and_post_stop():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a", "test")
    assert "pre-start|pre-mount)" in script
    assert "post-stop)" in script


def test_generate_hook_is_posix_sh():
    script = generate_hook(Path("/var/lib/lxc/test"), "/a", "test")
    assert script.startswith("#!/bin/sh\n")


def test_generate_hook_uses_lxc_rootfs_path():
    script = generate_hook(Path("/var/lib/lxc/100"), "/a:/b", "test")
    assert "LXC_ROOTFS_PATH" in script
    assert 'ROOTFS="${LXC_ROOTFS_PATH:-$CONTAINER_DIR/rootfs}"' in script


def test_generate_hook_delegates_to_inject_script():
    """After mount, hook invokes the standalone injection script."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "kento-inject.sh" in script
    # Called with ROOTFS and CONTAINER_DIR as positional args.
    assert '"$ROOTFS"' in script
    assert '"$CONTAINER_DIR"' in script


def test_generate_hook_inject_call_after_mount():
    """Injection must run after the overlayfs mount, not before."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    mount_pos = script.index("mount -t overlay")
    inject_pos = script.index("kento-inject.sh")
    assert mount_pos < inject_pos


def test_write_hook(tmp_path):
    hook = write_hook(tmp_path, "/a:/b", "mycontainer")
    assert hook == tmp_path / "kento-hook"
    assert hook.exists()
    assert hook.stat().st_mode & 0o755 == 0o755
    content = hook.read_text()
    assert 'NAME="mycontainer"' in content
    assert 'LAYERS="/a:/b"' in content


# --- Port forwarding (Phase 3) ---


def test_generate_hook_has_start_host_case():
    """Hook template includes start-host case for port forwarding."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "start-host)" in script


def test_generate_hook_has_portfwd_active_cleanup():
    """Hook template cleans up kento-portfwd-active in post-stop."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "kento-portfwd-active" in script


def test_generate_hook_start_host_reads_kento_port():
    """start-host case reads kento-port file."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "kento-port" in script


def test_generate_hook_start_host_uses_nftables():
    """start-host case uses nftables for DNAT."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "nft" in script
    assert "dnat to" in script


def test_generate_hook_start_host_has_ip_discovery():
    """start-host case tries kento-net then lxc-info for IP discovery."""
    script = generate_hook(Path("/var/lib/lxc/test"), "/a:/b", "test")
    assert "kento-net" in script
    assert "lxc-info" in script
