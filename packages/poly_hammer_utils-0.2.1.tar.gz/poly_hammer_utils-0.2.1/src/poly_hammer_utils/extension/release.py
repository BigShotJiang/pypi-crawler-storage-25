import logging
from pathlib import Path
from poly_hammer_utils.constants import ENVIRONMENT
from poly_hammer_utils.github.release import GitHubRelease
from poly_hammer_utils.extension.packager import get_addon_version


logger = logging.getLogger(__name__)


def create_production_release(
        title: str,
        source_folder: Path,
        addon_zip: Path | None = None,
    ):
    if ENVIRONMENT != 'production':
        logger.warning(f'Skipping release creation since current environment "{ENVIRONMENT}" is not "production"')
        return
    
    github_release = GitHubRelease()

    previous_releases = github_release.get_previous_releases()
    tag_name = get_addon_version(source_folder)
    message = ''
    release_notes_path = source_folder / 'release_notes.md'
    if release_notes_path.exists():
        with open(release_notes_path) as release_notes:
            message = release_notes.read()

    if tag_name not in previous_releases:
        logger.info(f'Creating release "{title}"')
        release = github_release.repo.create_git_release(
            name=title,
            message=message,
            tag=tag_name
        )
        if addon_zip:
            logger.info(f'Uploading "{addon_zip}"')
            release.upload_asset(
                path=str(addon_zip),
                name=addon_zip.name,
                content_type='application/zip'
            )
    else:
        logger.warning(f'Release "{tag_name}" already exists!')
        github_release.delete_release(tag_name=tag_name)

        logger.info(f'Overwriting release "{title}"')
        release = github_release.repo.create_git_release(
            name=title,
            message=message,
            tag=tag_name
        )

        if addon_zip:
            logger.info(f'Uploading "{addon_zip}"')
            release.upload_asset(
                path=str(addon_zip),
                name=addon_zip.name,
                content_type='application/zip'
            )
    
    logger.info('Successfully released!')