import os
import logging
import tempfile
import shutil
from pathlib import Path
from poly_hammer_utils.constants import ENVIRONMENT
from poly_hammer_utils.extension.server import update_extension_index
from poly_hammer_utils.extension.packager import (
    package_extension,
    copy_and_rename_addon,
)
from poly_hammer_utils.extension.release import create_production_release


BLENDER_EXTENSION_SERVER_S3_BUCKET = 'poly-hammer-portal-staging-app-data'
if ENVIRONMENT == 'production':
    BLENDER_EXTENSION_SERVER_S3_BUCKET = 'poly-hammer-portal-production-app-data'

BLENDER_EXTENSION_SERVER_S3_FOLDER = 'products/blender-extensions/character_control_rig'
TITLE = 'Character Control Rig'

logger = logging.getLogger(__name__)

def create_release(addon_folder: Path, releases_folder: Path):

    temp_addon_folder = copy_and_rename_addon(addon_folder=addon_folder)

    s3_prefix = BLENDER_EXTENSION_SERVER_S3_FOLDER

    # Create the new .zip files for the addon's various platforms
    addon_zip_files = package_extension(
        source_folder=temp_addon_folder,
        output_folder=releases_folder,
        blender_version=os.environ['BLENDER_VERSION'],
        split_platforms=False,
        docker=True
    )

    # Generate the updated extension index and upload it and the addons .zip file to S3
    update_extension_index(
        repo_folder=releases_folder,
        bucket=BLENDER_EXTENSION_SERVER_S3_BUCKET,
        s3_folder=s3_prefix,
        local_zip_files=addon_zip_files,
        source_folder=temp_addon_folder,
        split_platform=False
    )

    # Create the actual GitHub release (This only creates a release if the current environment is production)
    create_production_release(
        title=TITLE,
        source_folder=addon_folder
    )

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    addons_folder = os.environ.get('ADDONS_FOLDER', Path(os.getcwd()) / 'src' / 'addons')
    addons_folder = Path(addons_folder)

    releases_folder = os.environ.get('RELEASES_FOLDER', Path(tempfile.mkdtemp()))
    releases_folder = Path(releases_folder)

    for addon_name in os.listdir(addons_folder):
        addon_folder = addons_folder / addon_name
        create_release(
            addon_folder=addon_folder,
            releases_folder=releases_folder
        )

    # Clean up the releases folder
    shutil.rmtree(releases_folder, ignore_errors=True)