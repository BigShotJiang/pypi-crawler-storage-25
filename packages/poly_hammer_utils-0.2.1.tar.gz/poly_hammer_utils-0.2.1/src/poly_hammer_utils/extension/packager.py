import os
import sys
import shutil
import tempfile
import zipfile
import tomlkit
import logging
from pathlib import Path
from poly_hammer_utils.constants import IGNORE_PATTERNS
from poly_hammer_utils.utilities import shell, get_blender_executable

logger = logging.getLogger(__name__)

def get_addon_id(
        source_folder: Path,
    ) -> str:
    file_path = source_folder / 'blender_manifest.toml'
    # Read the id from the manifest file
    if file_path.exists():
        manifest_data = tomlkit.parse(file_path.read_text())
        return manifest_data.get('id', '')
    return ''


def get_addon_version(
        source_folder: Path,
    ) -> str:
    file_path = source_folder / 'blender_manifest.toml'
    # Read the version from the manifest file
    if file_path.exists():
        manifest_data = tomlkit.parse(file_path.read_text())
        return manifest_data.get('version', '')
    return ''

def parse_blender_extension_zip_info(url: str) -> tuple[str, str]:
    # parse the platform and arch from the attachment name
    base = Path(url).stem.split('-')[-1]
    platform, arch = base.split('_')
    return platform, arch

def copy_and_rename_addon(addon_folder: Path, ignore_patterns: list[str] | None = None) -> Path:
    """
    Copy the addon folder to a temporary location and optionally ignore specified patterns.

    Args:
        addon_folder (Path): The path to the addon folder to be copied.
        ignore_patterns (list[str] | None, optional): List of patterns to ignore during copying. Defaults to None.

    Returns:
        Path: The path to the copied addon folder in the temporary location.
    """
    temp_addon_folder = Path(tempfile.mkdtemp()) / addon_folder.name

    shutil.copytree(
        addon_folder,
        temp_addon_folder,
        ignore=shutil.ignore_patterns(*(ignore_patterns or IGNORE_PATTERNS))
    )

    return temp_addon_folder

def minimize_platform_bindings(addon_zip_files: list[Path]):
    # removing bindings for non-matching platforms to minimize archive size
    for addon_zip_file in addon_zip_files:
        platform, arch = parse_blender_extension_zip_info(url=addon_zip_file)

        # Rebuild the zip, filtering out bindings for other platforms
        temp_zip_path = addon_zip_file.with_suffix('.tmp')
        with zipfile.ZipFile(addon_zip_file, mode="r") as source_zip:
            with zipfile.ZipFile(temp_zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as dest_zip:
                # Copy existing entries, skipping bindings for non-matching platforms
                for item in source_zip.infolist():
                    if item.filename.startswith('bindings/'):
                        parts = item.filename.split('/')
                        if len(parts) >= 3:
                            entry_platform, entry_arch = parts[1], parts[2]
                            if entry_platform != platform or entry_arch != arch:
                                logger.info(f"Removed non-matching binding: {item.filename}")
                                continue
                    dest_zip.writestr(item, source_zip.read(item.filename))

        # Replace the original zip with the filtered one
        os.replace(temp_zip_path, addon_zip_file)

def package_extension(
        source_folder: Path, 
        output_folder: Path,
        blender_version: str = '4.5',
        split_platforms: bool = False,
        docker: bool = False,
    ) -> list[Path]:
    blender_executable = get_blender_executable(version=blender_version)

    addon_version = get_addon_version(source_folder=source_folder)
    addon_id = get_addon_id(source_folder=source_folder)
    logger.info(f'Packaging extension {addon_id} version: {addon_version}')

    # Ensure output folder exists before Docker mounts it, otherwise Docker
    # creates it as root and the --user flag causes permission errors.
    output_folder.mkdir(parents=True, exist_ok=True)

    if docker:
        # On Linux, set user to avoid permission issues with Docker-created files
        user_flag = ''
        if sys.platform != 'win32':
            user_flag = f'--user {os.getuid()}:{os.getgid()} '
        
        command = (
            f'docker run '
            f'{user_flag}'
            f'-v {source_folder.as_posix()}:/src '
            f'-v {output_folder.as_posix()}:/output '
            f'ghcr.io/poly-hammer/blender-linux:{blender_version} '
            f'blender --command extension build --source-dir /src --output-dir /output'
        )
    else:
        # wrap in quotes for Windows paths with spaces
        if sys.platform == 'win32':
            blender_executable = f'"{blender_executable}"'

        command = f'{blender_executable} --command extension build --source-dir {source_folder.as_posix()} --output-dir {output_folder.as_posix()}'
    
    if split_platforms:
        command += ' --split-platforms'
        
    shell(command, cwd=source_folder)

    return list(output_folder.glob(f'{addon_id}-*.zip'))


def rename_addon(
        toml_file_path: Path,
        constants_file_path: Path,
        addon_id: str,
        new_addon_id: str,
        new_addon_name: str,
):
    # Update the id and name in the blender_manifest.toml
    if not toml_file_path.exists():
        raise FileNotFoundError(f'Manifest file not found: {toml_file_path}')

    manifest_data = tomlkit.parse(toml_file_path.read_text())
    manifest_data['id'] = new_addon_id
    manifest_data['name'] = new_addon_name
    toml_file_path.write_text(tomlkit.dumps(manifest_data))
    logger.info(f'Updated manifest: id="{new_addon_id}", name="{new_addon_name}"')

    # Update ToolInfo.NAME in constants.py
    if not constants_file_path.exists():
        raise FileNotFoundError(f'Constants file not found: {constants_file_path}')

    constants_text = constants_file_path.read_text()
    updated_text = constants_text.replace(
        f'NAME: str = "{addon_id}"',
        f'NAME: str = "{new_addon_id}"',
    )
    if updated_text == constants_text:
        logger.warning(f'Could not find ToolInfo.NAME with value "{addon_id}" in {constants_file_path}')
    else:
        constants_file_path.write_text(updated_text)
        logger.info(f'Updated ToolInfo.NAME to "{new_addon_id}" in {constants_file_path}')

    