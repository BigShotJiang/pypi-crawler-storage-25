import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.validator_resource_samples_response import ValidatorResourceSamplesResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    start: datetime.datetime,
    end: datetime.datetime,
    validator_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 5000,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_start = start.isoformat()
    params["start"] = json_start

    json_end = end.isoformat()
    params["end"] = json_end

    json_validator_hotkey: None | str | Unset
    if isinstance(validator_hotkey, Unset):
        json_validator_hotkey = UNSET
    else:
        json_validator_hotkey = validator_hotkey
    params["validator_hotkey"] = json_validator_hotkey

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/analytics/validator-resources",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ValidatorResourceSamplesResponse | None:
    if response.status_code == 200:
        response_200 = ValidatorResourceSamplesResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ValidatorResourceSamplesResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    start: datetime.datetime,
    end: datetime.datetime,
    validator_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 5000,
) -> Response[HTTPValidationError | ValidatorResourceSamplesResponse]:
    """Validator host resource samples

    Args:
        start (datetime.datetime): Inclusive lower bound (ISO 8601 UTC)
        end (datetime.datetime): Inclusive upper bound (ISO 8601 UTC)
        validator_hotkey (None | str | Unset):
        limit (int | Unset):  Default: 5000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorResourceSamplesResponse]
    """

    kwargs = _get_kwargs(
        start=start,
        end=end,
        validator_hotkey=validator_hotkey,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    start: datetime.datetime,
    end: datetime.datetime,
    validator_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 5000,
) -> HTTPValidationError | ValidatorResourceSamplesResponse | None:
    """Validator host resource samples

    Args:
        start (datetime.datetime): Inclusive lower bound (ISO 8601 UTC)
        end (datetime.datetime): Inclusive upper bound (ISO 8601 UTC)
        validator_hotkey (None | str | Unset):
        limit (int | Unset):  Default: 5000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorResourceSamplesResponse
    """

    return sync_detailed(
        client=client,
        start=start,
        end=end,
        validator_hotkey=validator_hotkey,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    start: datetime.datetime,
    end: datetime.datetime,
    validator_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 5000,
) -> Response[HTTPValidationError | ValidatorResourceSamplesResponse]:
    """Validator host resource samples

    Args:
        start (datetime.datetime): Inclusive lower bound (ISO 8601 UTC)
        end (datetime.datetime): Inclusive upper bound (ISO 8601 UTC)
        validator_hotkey (None | str | Unset):
        limit (int | Unset):  Default: 5000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorResourceSamplesResponse]
    """

    kwargs = _get_kwargs(
        start=start,
        end=end,
        validator_hotkey=validator_hotkey,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    start: datetime.datetime,
    end: datetime.datetime,
    validator_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 5000,
) -> HTTPValidationError | ValidatorResourceSamplesResponse | None:
    """Validator host resource samples

    Args:
        start (datetime.datetime): Inclusive lower bound (ISO 8601 UTC)
        end (datetime.datetime): Inclusive upper bound (ISO 8601 UTC)
        validator_hotkey (None | str | Unset):
        limit (int | Unset):  Default: 5000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorResourceSamplesResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            start=start,
            end=end,
            validator_hotkey=validator_hotkey,
            limit=limit,
        )
    ).parsed
