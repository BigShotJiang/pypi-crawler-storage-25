from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ValidatorResourceSampleEntry")


@_attrs_define
class ValidatorResourceSampleEntry:
    """
    Attributes:
        validator_hotkey (str):
        recorded_at (datetime.datetime):
        cpu_pct (float | None | Unset):
        ram_pct (float | None | Unset):
        disk_pct (float | None | Unset):
        docker_container_count (int | None | Unset):
    """

    validator_hotkey: str
    recorded_at: datetime.datetime
    cpu_pct: float | None | Unset = UNSET
    ram_pct: float | None | Unset = UNSET
    disk_pct: float | None | Unset = UNSET
    docker_container_count: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validator_hotkey = self.validator_hotkey

        recorded_at = self.recorded_at.isoformat()

        cpu_pct: float | None | Unset
        if isinstance(self.cpu_pct, Unset):
            cpu_pct = UNSET
        else:
            cpu_pct = self.cpu_pct

        ram_pct: float | None | Unset
        if isinstance(self.ram_pct, Unset):
            ram_pct = UNSET
        else:
            ram_pct = self.ram_pct

        disk_pct: float | None | Unset
        if isinstance(self.disk_pct, Unset):
            disk_pct = UNSET
        else:
            disk_pct = self.disk_pct

        docker_container_count: int | None | Unset
        if isinstance(self.docker_container_count, Unset):
            docker_container_count = UNSET
        else:
            docker_container_count = self.docker_container_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validator_hotkey": validator_hotkey,
                "recorded_at": recorded_at,
            }
        )
        if cpu_pct is not UNSET:
            field_dict["cpu_pct"] = cpu_pct
        if ram_pct is not UNSET:
            field_dict["ram_pct"] = ram_pct
        if disk_pct is not UNSET:
            field_dict["disk_pct"] = disk_pct
        if docker_container_count is not UNSET:
            field_dict["docker_container_count"] = docker_container_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        validator_hotkey = d.pop("validator_hotkey")

        recorded_at = isoparse(d.pop("recorded_at"))

        def _parse_cpu_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cpu_pct = _parse_cpu_pct(d.pop("cpu_pct", UNSET))

        def _parse_ram_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        ram_pct = _parse_ram_pct(d.pop("ram_pct", UNSET))

        def _parse_disk_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        disk_pct = _parse_disk_pct(d.pop("disk_pct", UNSET))

        def _parse_docker_container_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        docker_container_count = _parse_docker_container_count(d.pop("docker_container_count", UNSET))

        validator_resource_sample_entry = cls(
            validator_hotkey=validator_hotkey,
            recorded_at=recorded_at,
            cpu_pct=cpu_pct,
            ram_pct=ram_pct,
            disk_pct=disk_pct,
            docker_container_count=docker_container_count,
        )

        validator_resource_sample_entry.additional_properties = d
        return validator_resource_sample_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
