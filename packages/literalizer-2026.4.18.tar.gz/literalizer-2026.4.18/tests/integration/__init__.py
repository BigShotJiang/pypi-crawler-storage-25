"""Integration tests for literalizer."""
