structure Check = struct

datatype val_t =
    SStr of string
  | SList of val_t list
val my_data : val_t = SList [
    SStr "SGVsbG8="
]

end
