module Check

type Val =
    | FStr of string
    | FList of Val list
let my_data: Val = FList [
    FStr "SGVsbG8="
]
