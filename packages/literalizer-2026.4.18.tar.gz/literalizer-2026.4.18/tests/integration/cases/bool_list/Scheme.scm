(list
    #t
    #f
    #t
)
