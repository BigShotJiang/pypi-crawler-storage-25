my_data = [
    true,
    false,
    true,
]
