[
    true,
    false,
    true,
]
