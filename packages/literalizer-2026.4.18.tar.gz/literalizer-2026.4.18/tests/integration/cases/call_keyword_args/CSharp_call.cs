using System;
dynamic throttler = new System.Dynamic.ExpandoObject();
dynamic emit(dynamic a) => null;
emit(throttler.check("user_1", 1000.0));
emit(throttler.check("user_2", 2000.5));
