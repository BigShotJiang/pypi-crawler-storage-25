"""modelreins-api — reserved. Install modelreins-worker instead.

See https://modelreins.com/docs/sdk/python
"""
raise ImportError(
    "modelreins-api is a reserved name guard. "
    "Install the real package: pip install modelreins-worker"
)
