# modelreins-api

This name is reserved by [Mediagato](https://modelreins.com) as a
**typosquat guard** for [ModelReins](https://modelreins.com).

You probably want:

```bash
pip install modelreins-worker
```

Docs: <https://modelreins.com/docs/sdk/python>

This package intentionally does nothing.
