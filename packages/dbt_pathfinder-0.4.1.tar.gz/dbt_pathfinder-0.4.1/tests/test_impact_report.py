from pathlib import Path

import pytest

from dbt_pathfinder.commands.impact_report_command import run_impact_report
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError


@pytest.fixture
def manifest_path() -> Path:
    return Path(__file__).parent / "fixtures" / "manifest.json"


@pytest.fixture
def ci_service(manifest_path: Path) -> CIImpactService:
    return CIImpactService.from_manifest(manifest_path)


def test_build_impact_report_from_model(ci_service: CIImpactService) -> None:
    r = ci_service.build_impact_report(input_mode="model", model_ref="stg_orders")
    assert r.input_mode == "model"
    assert r.changed_nodes == ["stg_orders"]
    assert "model.pkg.fct_orders" in r.impacted_by_depth.get(1, [])
    assert r.suggested_test_command.startswith("dbt test")


def test_build_impact_report_from_files_matches_ci_impact(ci_service: CIImpactService) -> None:
    r = ci_service.build_impact_report(
        input_mode="files",
        files=["models/staging/stg_orders.sql"],
    )
    legacy = ci_service.build_result(["models/staging/stg_orders.sql"])
    assert r.changed_nodes == legacy.changed_nodes
    assert r.impacted_by_depth == legacy.impacted_by_depth
    assert r.tests == legacy.tests
    assert r.suggested_build_command == legacy.suggested_command


def test_run_impact_report_mutually_exclusive(ci_service: CIImpactService) -> None:
    with pytest.raises(PathfinderError):
        run_impact_report(
            ci_service,
            model="stg_orders",
            files=["models/staging/stg_orders.sql"],
        )


def test_run_impact_report_github_format(ci_service: CIImpactService) -> None:
    out = run_impact_report(
        ci_service,
        model="stg_orders",
        report_format="github",
        include_columns=True,
    )
    assert "## dbt-pathfinder impact report" in out
    assert "### Downstream (by depth)" in out
    assert "dbt build" in out
    assert "dbt test" in out


def test_run_impact_report_json_has_schema_keys(ci_service: CIImpactService) -> None:
    out = run_impact_report(ci_service, model="stg_orders", report_format="json")
    assert '"input_mode"' in out
    assert '"suggested_test_command"' in out
    assert '"changed_unique_ids"' in out
