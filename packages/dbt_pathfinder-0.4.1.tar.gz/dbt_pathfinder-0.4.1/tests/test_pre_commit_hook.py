from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_pre_commit_main_no_files_exits_zero() -> None:
    r = subprocess.run(
        [sys.executable, "-m", "dbt_pathfinder.hooks.pre_commit", "ci-impact"],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0


def test_pre_commit_ci_impact_with_relative_paths(tmp_path: Path) -> None:
    shutil.copy(ROOT / "tests/fixtures/manifest.json", tmp_path / "manifest.json")
    staging = tmp_path / "models" / "staging"
    staging.mkdir(parents=True)
    (staging / "stg_orders.sql").write_text("select 1\n")

    env = {**os.environ, "DBT_MANIFEST_PATH": str(tmp_path / "manifest.json")}
    r = subprocess.run(
        [
            sys.executable,
            "-m",
            "dbt_pathfinder.hooks.pre_commit",
            "ci-impact",
            "models/staging/stg_orders.sql",
        ],
        cwd=str(tmp_path),
        env=env,
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout)
    assert "stg_orders" in out.get("changed_nodes", [])


def test_pre_commit_pr_risk_fail_on_high(tmp_path: Path) -> None:
    shutil.copy(ROOT / "tests/fixtures/manifest.json", tmp_path / "manifest.json")
    staging = tmp_path / "models" / "staging"
    staging.mkdir(parents=True)
    (staging / "stg_orders.sql").write_text("select 1\n")

    env = {
        **os.environ,
        "DBT_MANIFEST_PATH": str(tmp_path / "manifest.json"),
        "DBT_PATHFINDER_PR_RISK_FAIL_ON": "high",
    }
    r = subprocess.run(
        [
            sys.executable,
            "-m",
            "dbt_pathfinder.hooks.pre_commit",
            "pr-risk",
            "models/staging/stg_orders.sql",
        ],
        cwd=str(tmp_path),
        env=env,
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0 or r.returncode == 1
    data = json.loads(r.stdout)
    score = data.get("score")
    if score == "High":
        assert r.returncode == 1
    else:
        assert r.returncode == 0


def test_pre_commit_pr_risk_without_fail_gate_always_zero_on_success(tmp_path: Path) -> None:
    shutil.copy(ROOT / "tests/fixtures/manifest.json", tmp_path / "manifest.json")
    staging = tmp_path / "models" / "staging"
    staging.mkdir(parents=True)
    (staging / "stg_orders.sql").write_text("select 1\n")

    env = {**os.environ, "DBT_MANIFEST_PATH": str(tmp_path / "manifest.json")}
    env.pop("DBT_PATHFINDER_PR_RISK_FAIL_ON", None)
    r = subprocess.run(
        [
            sys.executable,
            "-m",
            "dbt_pathfinder.hooks.pre_commit",
            "pr-risk",
            "models/staging/stg_orders.sql",
        ],
        cwd=str(tmp_path),
        env=env,
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0
