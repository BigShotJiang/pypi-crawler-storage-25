import json

from dbt_pathfinder.json_schemas import (
    SCHEMA_VERSION,
    dump_schemas_json,
    get_all_schemas_bundle,
    get_ci_impact_result_schema,
)


def test_ci_impact_schema_has_expected_keys() -> None:
    s = get_ci_impact_result_schema()
    assert s["$schema"]
    assert s["$id"]
    assert "properties" in s
    props = s["properties"]
    assert "changed_files" in props
    assert "impacted_by_depth" in props
    assert "suggested_command" in props


def test_dump_schemas_json_valid() -> None:
    raw = dump_schemas_json("ci-impact")
    data = json.loads(raw)
    assert data["title"] == "CIImpactResult"


def test_all_bundle_has_version() -> None:
    b = get_all_schemas_bundle()
    assert b["schema_version"] == SCHEMA_VERSION
    assert "schemas" in b
    assert set(b["schemas"].keys()) == {"ci_impact_result", "impact_report", "risk_result"}
