from pathlib import Path
from subprocess import run

import pytest
from rich.console import Group

from dbt_pathfinder.commands.pr_risk_command import run_pr_risk
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.git_changes import (
    filter_dbt_paths,
    git_diff_changed_paths,
    path_ignored_in_git_diff,
)
from dbt_pathfinder.services.pr_risk_service import PRRiskService


@pytest.fixture
def manifest_path() -> Path:
    return Path(__file__).parent / "fixtures" / "manifest.json"


@pytest.fixture
def pr_service(manifest_path: Path) -> PRRiskService:
    return PRRiskService.from_manifest(manifest_path)


def test_filter_dbt_paths() -> None:
    assert filter_dbt_paths(["a.sql", "b.py", "c.yml"]) == ["a.sql", "c.yml"]


def test_path_ignored_in_git_diff() -> None:
    assert path_ignored_in_git_diff("snapshots/x.sql", ignore_prefixes=["snapshots/"], ignore_globs=())
    assert not path_ignored_in_git_diff("models/x.sql", ignore_prefixes=["snapshots/"], ignore_globs=())
    assert path_ignored_in_git_diff("docs/a.md", ignore_prefixes=(), ignore_globs=["docs/*.md"])


def test_pr_risk_analyze_files_downstream(pr_service: PRRiskService) -> None:
    r = pr_service.analyze_files(["models/staging/stg_orders.sql"])
    assert r.score in {"Low", "Medium", "High"}
    assert any("downstream nodes impacted" in x for x in r.reasons)
    assert r.suggested_build_command.startswith("dbt build")
    assert r.suggested_test_command.startswith("dbt test")
    assert any("node-level DAG lineage" in x for x in r.reasons)
    assert any("exposures depend on nodes" in x for x in r.reasons)
    assert any("DAG fan-out" in x for x in r.reasons)


def test_pr_risk_critical_tag(pr_service: PRRiskService) -> None:
    r = pr_service.analyze_files(
        ["models/staging/stg_orders.sql"],
        critical_tags=frozenset({"finance_critical"}),
    )
    assert any("affects tag: finance_critical" in x for x in r.reasons)


def test_pr_risk_no_matching_paths(pr_service: PRRiskService) -> None:
    r = pr_service.analyze_files(["models/nope.sql"])
    assert any("No manifest nodes matched" in x for x in r.reasons)


def test_run_pr_risk_mutually_exclusive(pr_service: PRRiskService) -> None:
    with pytest.raises(PathfinderError):
        run_pr_risk(pr_service, git_diff="main...HEAD", files=["x.sql"])


def test_run_pr_risk_requires_input(pr_service: PRRiskService) -> None:
    with pytest.raises(PathfinderError):
        run_pr_risk(pr_service, git_diff=None, files=None)


def test_run_pr_risk_empty_git_range(pr_service: PRRiskService) -> None:
    with pytest.raises(PathfinderError):
        run_pr_risk(pr_service, git_diff="   ", files=None)


def test_run_pr_risk_json(pr_service: PRRiskService) -> None:
    out = run_pr_risk(
        pr_service,
        files=["models/staging/stg_orders.sql"],
        output="json",
        ui="rich",
    )
    assert '"score"' in out
    assert "suggested_test_command" in out


def test_run_pr_risk_rich_group(pr_service: PRRiskService) -> None:
    out = run_pr_risk(
        pr_service,
        files=["models/staging/stg_orders.sql"],
        output="text",
        ui="rich",
    )
    assert isinstance(out, Group)


def test_ci_impact_suggested_test_command(manifest_path: Path) -> None:
    ci = CIImpactService.from_manifest(manifest_path)
    ids = ci.resolve_changed_files(["models/staging/stg_orders.sql"])
    assert ci.suggested_test_command(ids) == "dbt test --select stg_orders+"


def test_git_diff_changed_paths(tmp_path: Path) -> None:
    run(["git", "init", "-b", "main"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "config", "user.email", "t@t.com"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "config", "user.name", "t"], cwd=tmp_path, check=True, capture_output=True)
    sql = tmp_path / "models" / "a.sql"
    sql.parent.mkdir(parents=True)
    sql.write_text("select 1")
    run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "checkout", "-b", "feat"], cwd=tmp_path, check=True, capture_output=True)
    b = tmp_path / "models" / "b.sql"
    b.write_text("select 2")
    run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "commit", "-m", "b"], cwd=tmp_path, check=True, capture_output=True)

    paths = git_diff_changed_paths("main...feat", cwd=tmp_path)
    assert "models/b.sql" in paths

    empty = git_diff_changed_paths(
        "main...feat", cwd=tmp_path, ignore_prefixes=["models/"]
    )
    assert empty == []


def test_analyze_diff_no_dbt_files(tmp_path: Path, manifest_path: Path) -> None:
    run(["git", "init", "-b", "main"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "config", "user.email", "t@t.com"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "config", "user.name", "t"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "README.md").write_text("x")
    run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "checkout", "-b", "feat"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "README.md").write_text("y")
    run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    run(["git", "commit", "-m", "doc"], cwd=tmp_path, check=True, capture_output=True)

    svc = PRRiskService.from_manifest(manifest_path)
    r = svc.analyze_diff("main...feat", cwd=tmp_path)
    assert any("dbt project files" in msg.lower() for msg in r.reasons)
