from pathlib import Path

import pytest

from dbt_pathfinder.settings import (
    PathfinderSettings,
    find_config_path,
    load_settings_from_path,
    load_settings_or_fail,
)


def test_load_settings_from_path_minimal(tmp_path: Path) -> None:
    p = tmp_path / ".dbt-pathfinder.toml"
    p.write_text('critical_tags = ["a", "b"]\n', encoding="utf-8")
    s = load_settings_from_path(p)
    assert s.critical_tags == ("a", "b")
    assert s.column_mode_default is False


def test_pathfinder_table_overrides_root(tmp_path: Path) -> None:
    p = tmp_path / ".dbt-pathfinder.toml"
    p.write_text(
        """
column_mode_default = false
fanout_model_successors_threshold = 9

[pathfinder]
column_mode_default = true
fanout_model_successors_threshold = 3
""",
        encoding="utf-8",
    )
    s = load_settings_from_path(p)
    assert s.column_mode_default is True
    assert s.fanout_model_successors_threshold == 3


def test_git_diff_section_merged(tmp_path: Path) -> None:
    p = tmp_path / ".dbt-pathfinder.toml"
    p.write_text(
        """
git_diff_ignore_prefixes = ["macros/"]

[git_diff]
ignore_prefixes = ["snapshots/"]
ignore_globs = ["*.md"]
""",
        encoding="utf-8",
    )
    s = load_settings_from_path(p)
    assert set(s.git_diff_ignore_prefixes) == {"macros/", "snapshots/"}
    assert "*.md" in s.git_diff_ignore_globs


def test_load_settings_or_fail_explicit_missing(tmp_path: Path) -> None:
    missing = tmp_path / "nope.toml"
    with pytest.raises(FileNotFoundError):
        load_settings_or_fail(missing)


def test_load_settings_or_fail_none_uses_defaults_when_no_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("DBT_PATHFINDER_CONFIG", raising=False)

    def _resolve_no_discovered_file(explicit: Path | None) -> Path | None:
        if explicit is not None:
            return explicit.resolve()
        return None

    monkeypatch.setattr("dbt_pathfinder.settings.resolve_settings_path", _resolve_no_discovered_file)
    s, path = load_settings_or_fail(None)
    assert path is None
    assert s == PathfinderSettings()


def test_find_config_path_walks_up(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    nested = root / "a" / "b"
    nested.mkdir(parents=True)
    cfg = root / ".dbt-pathfinder.toml"
    cfg.write_text("column_mode_default = true\n", encoding="utf-8")
    found = find_config_path(nested)
    assert found == cfg.resolve()
