from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from rich.console import Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.impact_report import ImpactReport
from dbt_pathfinder.models.pr_risk import RiskResult


def render_show_rich(payload: Dict[str, Any], verbose: bool = False) -> Group:
    metadata = payload["metadata"]
    columns = metadata.get("columns") or {}

    meta_table = Table(title=f"Node: {payload['node']}", show_header=False)
    meta_table.add_column("key", style="cyan")
    meta_table.add_column("value")
    meta_table.add_row("type", str(metadata.get("resource_type", "unknown")))
    meta_table.add_row("name", str(metadata.get("name", "unknown")))
    if verbose:
        meta_table.add_row("dbt package", str(metadata.get("package_name") or "unknown"))
        meta_table.add_row("definition", str(metadata.get("description") or "(none)"))
        meta_table.add_row(
            "file",
            str(metadata.get("original_file_path") or metadata.get("path") or "(unknown)"),
        )

    upstream_tree = Tree("[bold]Upstream[/bold]")
    upstream = payload["upstream"]
    if upstream:
        for item in upstream:
            upstream_tree.add(item)
    else:
        upstream_tree.add("[dim](none)[/dim]")

    downstream_tree = Tree("[bold]Downstream[/bold]")
    downstream = payload["downstream"]
    if downstream:
        for item in downstream:
            downstream_tree.add(item)
    else:
        downstream_tree.add("[dim](none)[/dim]")

    if not verbose:
        return Group(meta_table, upstream_tree, downstream_tree)

    columns_table = Table(title="Columns", show_header=True)
    columns_table.add_column("name", style="cyan")
    columns_table.add_column("data type", style="magenta")
    columns_table.add_column("description")
    if columns:
        for col_name, col_meta in sorted(columns.items()):
            columns_table.add_row(
                col_name,
                str(col_meta.get("data_type") or "unknown_type"),
                str(col_meta.get("description") or "(no description)"),
            )
    else:
        columns_table.add_row("(none in manifest)", "-", "-")

    return Group(meta_table, columns_table, upstream_tree, downstream_tree)


def render_ci_impact_rich(
    result: CIImpactResult,
    *,
    include_tests: bool = True,
    include_columns: bool = False,
    node_display: Optional[Callable[[str], str]] = None,
) -> Group:
    files_tree = Tree("[bold]Changed files[/bold]")
    if result.changed_files:
        for path in result.changed_files:
            files_tree.add(path)
    else:
        files_tree.add("[dim](none)[/dim]")

    nodes_tree = Tree("[bold]Changed nodes[/bold]")
    if result.changed_nodes:
        for name in result.changed_nodes:
            nodes_tree.add(name)
    else:
        nodes_tree.add("[dim](none)[/dim]")

    downstream_tree = Tree("[bold]Impacted downstream[/bold]")
    if result.impacted_by_depth:
        for depth, nodes in sorted(result.impacted_by_depth.items()):
            branch = downstream_tree.add(f"[cyan]Depth {depth}[/cyan]")
            for uid in nodes:
                label = node_display(uid) if node_display else uid
                branch.add(label)
    else:
        downstream_tree.add("[dim](none)[/dim]")

    parts: List[Any] = [files_tree, nodes_tree, downstream_tree]

    if include_columns:
        col_tree = Tree("[bold]Impacted columns (best-effort)[/bold]")
        if result.column_impact_by_depth:
            for depth, by_node in sorted(result.column_impact_by_depth.items()):
                d_branch = col_tree.add(f"[cyan]Depth {depth}[/cyan]")
                for uid, cols in sorted(by_node.items()):
                    label = node_display(uid) if node_display else uid
                    d_branch.add(f"{label}: {', '.join(cols)}")
        else:
            col_tree.add("[dim](none)[/dim]")
        parts.append(col_tree)

    if include_tests:
        tests_tree = Tree("[bold]Impacted tests[/bold]")
        if result.tests:
            for t in result.tests:
                tests_tree.add(t)
        else:
            tests_tree.add("[dim](none)[/dim]")
        parts.append(tests_tree)

    cmd_panel = Panel(
        result.suggested_command,
        title="[bold]Suggested command[/bold]",
        border_style="green",
    )
    parts.append(cmd_panel)

    return Group(*parts)


def render_impact_report_rich(
    report: ImpactReport,
    *,
    include_tests: bool = True,
    include_columns: bool = False,
    node_display: Optional[Callable[[str], str]] = None,
) -> Group:
    mode = report.input_mode
    subtitle = ""
    if mode == "git_diff" and report.git_diff_range:
        subtitle = f" ({report.git_diff_range})"
    header = Text(f"Input: {mode}", style="bold")
    if subtitle:
        header.append(subtitle, style="dim")

    files_tree = Tree("[bold]Changed files[/bold]")
    if report.changed_files:
        for path in report.changed_files:
            files_tree.add(path)
    else:
        files_tree.add("[dim](none)[/dim]")

    nodes_tree = Tree("[bold]Changed nodes[/bold]")
    if report.changed_nodes:
        for name in report.changed_nodes:
            nodes_tree.add(name)
    else:
        nodes_tree.add("[dim](none)[/dim]")

    downstream_tree = Tree("[bold]Impacted downstream[/bold]")
    if report.impacted_by_depth:
        for depth, nodes in sorted(report.impacted_by_depth.items()):
            branch = downstream_tree.add(f"[cyan]Depth {depth}[/cyan]")
            for uid in nodes:
                label = node_display(uid) if node_display else uid
                branch.add(label)
    else:
        downstream_tree.add("[dim](none)[/dim]")

    parts: List[Any] = [Panel(header, border_style="cyan"), files_tree, nodes_tree, downstream_tree]

    if include_columns:
        col_tree = Tree("[bold]Impacted columns (best-effort)[/bold]")
        if report.column_impact_by_depth:
            for depth, by_node in sorted(report.column_impact_by_depth.items()):
                d_branch = col_tree.add(f"[cyan]Depth {depth}[/cyan]")
                for uid, cols in sorted(by_node.items()):
                    label = node_display(uid) if node_display else uid
                    d_branch.add(f"{label}: {', '.join(cols)}")
        else:
            col_tree.add("[dim](none)[/dim]")
        parts.append(col_tree)

    if include_tests:
        tests_tree = Tree("[bold]Impacted tests[/bold]")
        if report.tests:
            for t in report.tests:
                tests_tree.add(t)
        else:
            tests_tree.add("[dim](none)[/dim]")
        parts.append(tests_tree)

    cmd_text = f"{report.suggested_build_command}\n{report.suggested_test_command}"
    parts.append(Panel(cmd_text, title="[bold]Suggested commands[/bold]", border_style="green"))

    return Group(*parts)


def render_pr_risk_rich(result: RiskResult) -> Group:
    if result.score == "High":
        score_style = "bold red"
    elif result.score == "Medium":
        score_style = "bold yellow"
    else:
        score_style = "bold green"

    header = Text("PR Risk Score: ", style="bold")
    header.append(result.score, style=score_style)

    reasons_tree = Tree("[bold]Reasons[/bold]")
    if result.reasons:
        for r in result.reasons:
            reasons_tree.add(r)
    else:
        reasons_tree.add("[dim](none)[/dim]")

    cmd_table = Table(title="Suggested commands", show_header=False)
    cmd_table.add_column("label", style="cyan")
    cmd_table.add_column("command")
    cmd_table.add_row("build", result.suggested_build_command)
    cmd_table.add_row("test", result.suggested_test_command)

    note = Text(
        "Run from your dbt project root after dbt compile/parse so selectors match the analyzed manifest.",
        style="dim",
    )

    return Group(Panel(header, border_style="cyan"), reasons_tree, cmd_table, note)


def render_impact_rich(payload: Dict[int, List[str]]) -> Tree | Panel:
    if not payload:
        return Panel("No downstream impact.", title="Impact", border_style="yellow")

    tree = Tree("[bold]Downstream Impact[/bold]")
    for depth, nodes in payload.items():
        branch = tree.add(f"[cyan]Depth {depth}[/cyan]")
        for node in nodes:
            branch.add(node)
    return tree


def render_path_rich(nodes: List[str]) -> Text:
    text = Text()
    for idx, node in enumerate(nodes):
        text.append(node, style="green")
        if idx < len(nodes) - 1:
            text.append(" -> ", style="dim")
    return text


def render_path_explain_rich(payload: Dict[str, Any]) -> Group:
    path_text = Text(" -> ".join(payload["path"]), style="green")
    table = Table(title="Path Edge Details")
    table.add_column("edge", style="cyan")
    table.add_column("join keys")
    table.add_column("cardinality", style="magenta")
    table.add_column("confidence", style="yellow")

    for edge in payload["edges"]:
        keys = "\n".join(edge["join_keys"]) if edge["join_keys"] else "(not detected)"
        table.add_row(
            f"{edge['from']} -> {edge['to']}",
            keys,
            edge["cardinality"],
            edge["confidence"],
        )

    return Group(Panel(path_text, title="Path"), table)
