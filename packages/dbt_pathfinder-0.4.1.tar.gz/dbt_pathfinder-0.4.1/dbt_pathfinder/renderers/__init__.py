"""Plain text, Rich, and Markdown renderers for CLI output."""
