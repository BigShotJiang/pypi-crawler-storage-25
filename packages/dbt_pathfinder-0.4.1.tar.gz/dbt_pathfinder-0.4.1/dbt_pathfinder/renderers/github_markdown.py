from __future__ import annotations

from typing import Callable, List, Optional

from dbt_pathfinder.models.impact_report import ImpactReport


def render_impact_report_github(
    report: ImpactReport,
    *,
    node_display: Optional[Callable[[str], str]] = None,
    include_columns: bool = True,
) -> str:
    """Markdown suitable for GitHub PR comments."""
    lines: List[str] = [
        "## dbt-pathfinder impact report",
        "",
    ]
    mode_line = f"**Input:** `{report.input_mode}`"
    if report.input_mode == "git_diff" and report.git_diff_range:
        mode_line += f" · `{report.git_diff_range}`"
    if report.input_mode == "model" and report.changed_nodes:
        mode_line += f" · `{report.changed_nodes[0]}`"
    lines.append(mode_line)
    lines.append("")

    if report.changed_files:
        lines.extend(["### Changed files", "", "| Path |", "| --- |"])
        for p in report.changed_files:
            lines.append(f"| `{p}` |")
        lines.append("")

    lines.extend(["### Changed nodes", "", "| Node |", "| --- |"])
    if report.changed_nodes:
        for n in report.changed_nodes:
            lines.append(f"| `{n}` |")
    else:
        lines.append("| *(none)* |")
    lines.append("")

    lines.extend(["### Downstream (by depth)", "", "| Depth | Nodes |", "| ---: | --- |"])
    if report.impacted_by_depth:
        for depth, uids in sorted(report.impacted_by_depth.items()):
            labels = [node_display(u) if node_display else u for u in uids]
            cell = ", ".join(f"`{x}`" for x in labels)
            lines.append(f"| {depth} | {cell} |")
    else:
        lines.append("| — | *(none)* |")
    lines.append("")

    if include_columns and report.column_impact_by_depth:
        lines.extend(
            [
                "### Impacted columns (best-effort)",
                "",
                "| Depth | Model | Columns |",
                "| ---: | --- | --- |",
            ]
        )
        for depth, by_node in sorted(report.column_impact_by_depth.items()):
            for uid, cols in sorted(by_node.items()):
                label = node_display(uid) if node_display else uid
                col_cell = ", ".join(f"`{c}`" for c in cols)
                lines.append(f"| {depth} | `{label}` | {col_cell} |")
        lines.append("")

    lines.extend(["### Impacted tests", "", "| Test |", "| --- |"])
    if report.tests:
        for t in report.tests:
            lines.append(f"| `{t}` |")
    else:
        lines.append("| *(none)* |")
    lines.append("")

    lines.extend(
        [
            "### Commands",
            "",
            "```bash",
            report.suggested_build_command,
            report.suggested_test_command,
            "```",
        ]
    )
    if include_columns:
        lines.extend(["", "*Column impact uses heuristic SQL parsing; treat as directional, not exhaustive.*"])
    return "\n".join(lines)
