from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.impact_report import ImpactReport
from dbt_pathfinder.models.pr_risk import RiskResult


def render_show(payload: Dict[str, Any], verbose: bool = False) -> str:
    node = payload["node"]
    metadata = payload["metadata"]
    columns = metadata.get("columns") or {}
    lines = [
        f"Node: {node}",
        f"Type: {metadata.get('resource_type', 'unknown')}",
        f"Name: {metadata.get('name', 'unknown')}",
    ]
    if verbose:
        lines.extend(
            [
                f"DBT Package: {metadata.get('package_name') or 'unknown'}",
                f"Definition: {metadata.get('description') or '(none)'}",
                f"File: {metadata.get('original_file_path') or metadata.get('path') or '(unknown)'}",
                "",
                "Columns:",
            ]
        )
        if columns:
            for col_name, col_meta in sorted(columns.items()):
                dtype = col_meta.get("data_type") or "unknown_type"
                desc = col_meta.get("description") or "(no description)"
                lines.append(f"  - {col_name} [{dtype}] - {desc}")
        else:
            lines.append("  (none in manifest)")
        lines.append("")
    lines.append("Upstream:")
    lines.extend([f"  - {item}" for item in payload["upstream"]] or ["  (none)"])
    lines.append("Downstream:")
    lines.extend([f"  - {item}" for item in payload["downstream"]] or ["  (none)"])
    return "\n".join(lines)


def render_impact(payload: Dict[int, List[str]]) -> str:
    if not payload:
        return "No downstream impact."
    lines = []
    for depth, nodes in payload.items():
        lines.append(f"Depth {depth}:")
        lines.extend([f"  - {node}" for node in nodes])
    return "\n".join(lines)


def render_path(nodes: List[str]) -> str:
    return " -> ".join(nodes)


def render_ci_impact(
    result: CIImpactResult,
    *,
    include_tests: bool = True,
    include_columns: bool = False,
    node_display: Optional[Callable[[str], str]] = None,
) -> str:
    lines: List[str] = ["Changed files:"]
    if result.changed_files:
        lines.extend([f"- {p}" for p in result.changed_files])
    else:
        lines.append("- (none)")

    lines.append("")
    lines.append("Changed nodes:")
    if result.changed_nodes:
        lines.extend([f"- {n}" for n in result.changed_nodes])
    else:
        lines.append("- (none)")

    lines.append("")
    lines.append("Impacted downstream:")
    if result.impacted_by_depth:
        for depth, nodes in sorted(result.impacted_by_depth.items()):
            lines.append(f"Depth {depth}:")
            labels = [node_display(n) if node_display else n for n in nodes]
            lines.extend([f"- {label}" for label in labels])
    else:
        lines.append("- (none)")

    if include_columns:
        lines.append("")
        lines.append("Impacted columns (best-effort):")
        if result.column_impact_by_depth:
            for depth, by_node in sorted(result.column_impact_by_depth.items()):
                lines.append(f"Depth {depth}:")
                for uid, cols in sorted(by_node.items()):
                    label = node_display(uid) if node_display else uid
                    lines.append(f"- {label}: {', '.join(cols)}")
        else:
            lines.append("- (none)")

    if include_tests:
        lines.append("")
        lines.append("Impacted tests:")
        if result.tests:
            lines.extend([f"- {t}" for t in result.tests])
        else:
            lines.append("- (none)")

    lines.append("")
    lines.append("Suggested command:")
    lines.append(result.suggested_command)
    return "\n".join(lines)


def render_impact_report(
    report: ImpactReport,
    *,
    include_tests: bool = True,
    include_columns: bool = False,
    node_display: Optional[Callable[[str], str]] = None,
) -> str:
    mode = report.input_mode
    extra = ""
    if mode == "git_diff" and report.git_diff_range:
        extra = f" ({report.git_diff_range})"
    lines: List[str] = [f"Input: {mode}{extra}", ""]

    lines.append("Changed files:")
    if report.changed_files:
        lines.extend([f"- {p}" for p in report.changed_files])
    else:
        lines.append("- (none)")

    lines.extend(["", "Changed nodes:"])
    if report.changed_nodes:
        lines.extend([f"- {n}" for n in report.changed_nodes])
    else:
        lines.append("- (none)")

    lines.extend(["", "Impacted downstream:"])
    if report.impacted_by_depth:
        for depth, nodes in sorted(report.impacted_by_depth.items()):
            lines.append(f"Depth {depth}:")
            labels = [node_display(n) if node_display else n for n in nodes]
            lines.extend([f"- {label}" for label in labels])
    else:
        lines.append("- (none)")

    if include_columns:
        lines.extend(["", "Impacted columns (best-effort):"])
        if report.column_impact_by_depth:
            for depth, by_node in sorted(report.column_impact_by_depth.items()):
                lines.append(f"Depth {depth}:")
                for uid, cols in sorted(by_node.items()):
                    label = node_display(uid) if node_display else uid
                    lines.append(f"- {label}: {', '.join(cols)}")
        else:
            lines.append("- (none)")

    if include_tests:
        lines.extend(["", "Impacted tests:"])
        if report.tests:
            lines.extend([f"- {t}" for t in report.tests])
        else:
            lines.append("- (none)")

    lines.extend(
        [
            "",
            "Suggested commands:",
            report.suggested_build_command,
            report.suggested_test_command,
        ]
    )
    return "\n".join(lines)


def render_pr_risk(result: RiskResult) -> str:
    lines = [f"PR Risk Score: {result.score}", "", "Reasons:"]
    if result.reasons:
        lines.extend([f"- {r}" for r in result.reasons])
    else:
        lines.append("- (none)")
    lines.extend(
        [
            "",
            "Suggested commands (impacted subgraph):",
            result.suggested_build_command,
            result.suggested_test_command,
            "",
            "Note: Run the above from your dbt project root after `dbt compile` (or parse) so selectors match the analyzed manifest.",
        ]
    )
    return "\n".join(lines)


def render_path_explain(payload: Dict[str, Any]) -> str:
    lines = [f"Path: {' -> '.join(payload['path'])}", ""]
    for edge in payload["edges"]:
        lines.append(f"{edge['from']} -> {edge['to']}")
        if edge["join_keys"]:
            lines.append("  Join Keys:")
            lines.extend([f"    - {key}" for key in edge["join_keys"]])
        else:
            lines.append("  Join Keys: (not detected)")
        lines.append(f"  Cardinality: {edge['cardinality']}")
        lines.append(f"  Confidence: {edge['confidence']}")
        lines.append("")
    return "\n".join(lines).rstrip()
