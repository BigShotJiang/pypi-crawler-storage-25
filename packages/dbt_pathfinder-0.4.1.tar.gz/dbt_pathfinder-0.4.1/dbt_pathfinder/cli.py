from __future__ import annotations

from pathlib import Path
from typing import List, Literal, Optional

import typer
from rich.console import Console

from dbt_pathfinder.commands.ci_impact_command import run_ci_impact
from dbt_pathfinder.commands.doctor_command import run_doctor
from dbt_pathfinder.commands.impact_report_command import run_impact_report
from dbt_pathfinder.commands.impact_command import run_impact
from dbt_pathfinder.commands.path_explain_command import run_path_explain
from dbt_pathfinder.commands.pr_risk_command import run_pr_risk
from dbt_pathfinder.commands.path_command import run_path
from dbt_pathfinder.commands.show_command import run_show
from dbt_pathfinder.parser.manifest_parser import ManifestParseError
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pr_risk_service import PRRiskHeuristics, PRRiskService
from dbt_pathfinder.services.pathfinder_service import PathfinderError, PathfinderService
from dbt_pathfinder.cli_support import OPT_CONFIG
from dbt_pathfinder.settings import PathfinderSettings, load_settings_or_fail

app = typer.Typer(
    help="Explore dbt dependency graphs from manifest.json",
    add_completion=True,
)
console = Console()


def _load_cli_settings(config: Optional[Path]) -> tuple[PathfinderSettings, Optional[Path]]:
    try:
        return load_settings_or_fail(config)
    except FileNotFoundError as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


def _effective_include_columns(user: Optional[bool], settings: PathfinderSettings) -> bool:
    if user is not None:
        return user
    return settings.column_mode_default


def _load_service(manifest: str) -> PathfinderService:
    return PathfinderService.from_manifest(manifest)


def _load_ci_impact_service(manifest: str) -> CIImpactService:
    return CIImpactService.from_manifest(manifest)


def _load_pr_risk_service(manifest: str, *, heuristics: PRRiskHeuristics) -> PRRiskService:
    return PRRiskService.from_manifest(manifest, heuristics=heuristics)


@app.command("show", help="Show metadata, upstream, and downstream for one node.")
def show(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    model: str = typer.Option(..., "--model", help="Model name or unique_id"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
    verbose: bool = typer.Option(False, "--verbose", help="Include detailed metadata and columns"),
) -> None:
    try:
        service = _load_service(manifest)
        result = run_show(service, model, ui=ui, verbose=verbose)
        if ui == "rich":
            console.print(result)
        else:
            typer.echo(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command("impact", help="Show downstream impact grouped by dependency depth.")
def impact(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    model: str = typer.Option(..., "--model", help="Model name or unique_id"),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        service = _load_service(manifest)
        result = run_impact(service, model, output=output, ui=ui)
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "ci-impact",
    help="Downstream impact and suggested dbt build selection from changed project files.",
)
def ci_impact(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    files: List[str] = typer.Option(
        ...,
        "--files",
        help="Project-relative path to a changed file (repeat --files for each path).",
    ),
    config: Optional[Path] = OPT_CONFIG,
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option(
        "rich",
        "--ui",
        help="Plain vs Rich terminal output when --output is text (JSON is always plain).",
    ),
    include_tests: bool = typer.Option(
        True,
        "--include-tests/--no-include-tests",
        help="Include impacted tests in the report",
    ),
    include_columns: Optional[bool] = typer.Option(
        None,
        "--include-columns/--no-include-columns",
        help="Column impact mode (default: column_mode_default from config, else off).",
    ),
) -> None:
    settings, _cfg = _load_cli_settings(config)
    try:
        service = _load_ci_impact_service(manifest)
        result = run_ci_impact(
            service,
            files,
            output=output,
            include_tests=include_tests,
            include_columns=_effective_include_columns(include_columns, settings),
            ui=ui,
        )
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "impact-report",
    help="Unified impact report: use --model, --files, or --git-diff (one required).",
)
def impact_report(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="Single node name or unique_id (mutually exclusive with --files / --git-diff).",
    ),
    files: Optional[List[str]] = typer.Option(
        None,
        "--files",
        help="Changed file path (repeat per file). Mutually exclusive with --model / --git-diff.",
    ),
    git_diff: Optional[str] = typer.Option(
        None,
        "--git-diff",
        help="Git revision range (e.g. main...HEAD). Mutually exclusive with --model / --files.",
    ),
    repo_root: Optional[str] = typer.Option(
        None,
        "--repo-root",
        help="Git repo root when using --git-diff (default: current directory).",
    ),
    config: Optional[Path] = OPT_CONFIG,
    report_format: Literal["text", "json", "github"] = typer.Option(
        "text",
        "--format",
        help="text, json (ImpactReport schema), or github (Markdown for PR comments).",
    ),
    ui: Literal["rich", "text"] = typer.Option(
        "rich",
        "--ui",
        help="Plain vs Rich when --format is text.",
    ),
    include_tests: bool = typer.Option(
        True,
        "--include-tests/--no-include-tests",
        help="Include impacted tests in the report",
    ),
    include_columns: Optional[bool] = typer.Option(
        None,
        "--include-columns/--no-include-columns",
        help="Column impact mode (default: column_mode_default from config, else off).",
    ),
) -> None:
    settings, _cfg = _load_cli_settings(config)
    try:
        service = _load_ci_impact_service(manifest)
        root = Path(repo_root).resolve() if repo_root else None
        result = run_impact_report(
            service,
            model=model,
            files=files,
            git_diff=git_diff,
            repo_root=root,
            report_format=report_format,
            include_tests=include_tests,
            include_columns=_effective_include_columns(include_columns, settings),
            ui=ui,
            git_diff_ignore_globs=settings.git_diff_ignore_globs,
            git_diff_ignore_prefixes=settings.git_diff_ignore_prefixes,
        )
        if report_format in ("json", "github") or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "pr-risk",
    help="Score PR risk from git diff or file list using manifest lineage and heuristics.",
)
def pr_risk(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    git_diff: Optional[str] = typer.Option(
        None,
        "--git-diff",
        help="Git revision range (e.g. main...HEAD). Implies paths from git diff.",
    ),
    files: Optional[List[str]] = typer.Option(
        None,
        "--files",
        help="Changed file path (repeat per file). Mutually exclusive with --git-diff.",
    ),
    repo_root: Optional[str] = typer.Option(
        None,
        "--repo-root",
        help="Root of the git repo when using --git-diff (default: current directory).",
    ),
    config: Optional[Path] = OPT_CONFIG,
    critical_tag: List[str] = typer.Option(
        [],
        "--critical-tag",
        help="Tag that increases risk when present on impacted nodes (repeatable; merged with config).",
    ),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option(
        "rich",
        "--ui",
        help="Plain vs Rich terminal output when --output is text.",
    ),
) -> None:
    settings, _cfg = _load_cli_settings(config)
    heur = PRRiskHeuristics(
        fanout_model_successors_threshold=settings.fanout_model_successors_threshold,
        exposure_points_multiplier=settings.exposure_points_multiplier,
        exposure_points_cap=settings.exposure_points_cap,
    )
    tags = frozenset(settings.critical_tags) | frozenset(critical_tag)
    try:
        service = _load_pr_risk_service(manifest, heuristics=heur)
        root = Path(repo_root).resolve() if repo_root else None
        result = run_pr_risk(
            service,
            git_diff=git_diff,
            files=files,
            repo_root=root,
            critical_tags=tags,
            output=output,
            ui=ui,
            ignore_globs=settings.git_diff_ignore_globs,
            ignore_prefixes=settings.git_diff_ignore_prefixes,
        )
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command("path", help="Find shortest path between two nodes.")
def path(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    from_node: str = typer.Option(..., "--from", help="Source model name or unique_id"),
    to_node: str = typer.Option(..., "--to", help="Target model name or unique_id"),
    mode: Literal["directed", "any"] = typer.Option(
        "directed",
        "--mode",
        help="Path traversal mode",
    ),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        directed = mode != "any"
        service = _load_service(manifest)
        result = run_path(service, from_node, to_node, directed=directed, ui=ui)
        if ui == "rich":
            console.print(result)
        else:
            typer.echo(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "path-explain",
    help="Explain path edges with inferred join keys and cardinality.",
)
def path_explain(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    from_node: str = typer.Option(..., "--from", help="Source model name or unique_id"),
    to_node: str = typer.Option(..., "--to", help="Target model name or unique_id"),
    mode: Literal["directed", "any"] = typer.Option(
        "directed",
        "--mode",
        help="Path traversal mode",
    ),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        directed = mode != "any"
        service = _load_service(manifest)
        result = run_path_explain(
            service,
            from_node=from_node,
            to_node=to_node,
            directed=directed,
            output=output,
            ui=ui,
        )
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "json-schema",
    help="Print JSON Schema for --output json payloads (CI impact, impact-report, pr-risk).",
)
def json_schema(
    which: Literal["ci-impact", "impact-report", "pr-risk", "all"] = typer.Option(
        "all",
        "--which",
        help="Which schema to emit, or all in one object.",
    ),
) -> None:
    from dbt_pathfinder.json_schemas import dump_schemas_json

    typer.echo(dump_schemas_json(which))


@app.command(
    "doctor",
    help="Check Python, git, optional config file, and manifest/graph stats.",
)
def doctor(
    manifest: Optional[str] = typer.Option(
        None,
        "--manifest",
        help="Manifest to validate (else try DBT_MANIFEST_PATH, target/manifest.json, manifest.json).",
    ),
    config: Optional[Path] = OPT_CONFIG,
) -> None:
    code = run_doctor(manifest=manifest, config=config, console=console)
    raise typer.Exit(code=code)


if __name__ == "__main__":
    app()
