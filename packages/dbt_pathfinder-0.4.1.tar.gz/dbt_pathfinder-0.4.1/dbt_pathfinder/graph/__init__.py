"""Manifest → directed graph construction."""
