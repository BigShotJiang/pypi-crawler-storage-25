"""Manifest JSON loading and validation."""
