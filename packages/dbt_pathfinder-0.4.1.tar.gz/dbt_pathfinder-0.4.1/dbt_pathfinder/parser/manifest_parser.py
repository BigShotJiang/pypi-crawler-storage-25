from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from pydantic import ValidationError

from dbt_pathfinder.models.manifest import Manifest


class ManifestParseError(ValueError):
    """Raised when a manifest cannot be loaded or validated."""


def _normalize_manifest_payload(raw: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "nodes": raw.get("nodes", {}) or {},
        "sources": raw.get("sources", {}) or {},
        "metrics": raw.get("metrics", {}) or {},
        "exposures": raw.get("exposures", {}) or {},
    }


def parse_manifest(manifest_path: str | Path) -> Manifest:
    path = Path(manifest_path)
    if not path.exists():
        raise ManifestParseError(f"Manifest not found: {path}")
    if not path.is_file():
        raise ManifestParseError(f"Manifest path is not a file: {path}")

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestParseError(f"Manifest is not valid JSON: {path}") from exc
    except OSError as exc:
        raise ManifestParseError(f"Manifest could not be read: {path}") from exc

    try:
        return Manifest.model_validate(_normalize_manifest_payload(payload))
    except ValidationError as exc:
        raise ManifestParseError("Manifest schema validation failed") from exc
