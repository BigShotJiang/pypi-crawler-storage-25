"""
dbt-pathfinder — parse dbt ``manifest.json``, explore lineage, and run CI-oriented impact checks.

Import from submodules (``PathfinderService``, ``CIImpactService``, etc.) or use the ``dbt-pathfinder`` CLI.
"""

from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.impact_report import ImpactReport
from dbt_pathfinder.models.pr_risk import RiskResult
from dbt_pathfinder.json_schemas import (
    SCHEMA_VERSION,
    dump_schemas_json,
    get_all_schemas_bundle,
    get_ci_impact_result_schema,
    get_impact_report_schema,
    get_risk_result_schema,
)

__all__ = [
    "__version__",
    "CIImpactResult",
    "ImpactReport",
    "RiskResult",
    "SCHEMA_VERSION",
    "dump_schemas_json",
    "get_all_schemas_bundle",
    "get_ci_impact_result_schema",
    "get_impact_report_schema",
    "get_risk_result_schema",
]
__version__ = "0.4.0"
