"""Shared project-relative path helpers and dbt file extensions."""

from __future__ import annotations

from pathlib import Path

# Files dbt-pathfinder treats as project assets for CI / git-diff filtering.
DBT_TEXT_EXTENSIONS: tuple[str, ...] = (".sql", ".yml", ".yaml")


def normalize_rel_path(path: str) -> str:
    """Normalize to forward slashes and strip leading ``./``."""
    return Path(path).as_posix().lstrip("./")


def is_dbt_path(path: str) -> bool:
    """True if the path looks like a dbt SQL or YAML project file."""
    lower = path.lower()
    return lower.endswith(DBT_TEXT_EXTENSIONS)
