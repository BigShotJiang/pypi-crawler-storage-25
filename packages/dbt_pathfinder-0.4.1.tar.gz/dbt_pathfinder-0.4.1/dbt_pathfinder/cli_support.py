"""Typer/Click helpers for the ``dbt-pathfinder`` CLI entrypoint."""

from __future__ import annotations

from pathlib import Path
from typing import List

import click
import typer

from dbt_pathfinder.settings import CONFIG_FILENAMES, ENV_CONFIG_PATH


def complete_config_files(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> List[click.shell_completion.CompletionItem]:
    del ctx, param
    items: List[click.shell_completion.CompletionItem] = []
    seen: set[str] = set()
    cur = Path.cwd().resolve()
    for directory in [cur, *cur.parents][:32]:
        for name in CONFIG_FILENAMES:
            path = (directory / name).resolve()
            if not path.is_file():
                continue
            s = str(path)
            if s in seen:
                continue
            seen.add(s)
            if incomplete and not s.startswith(incomplete):
                continue
            items.append(click.shell_completion.CompletionItem(s))
    return items


# Single shared Option instance (Typer + Annotated + ``= None`` breaks Click param naming).
OPT_CONFIG = typer.Option(
    None,
    "--config",
    metavar="PATH",
    envvar=ENV_CONFIG_PATH,
    help="Path to .dbt-pathfinder.toml (optional; otherwise search upward from cwd).",
    exists=False,
    file_okay=True,
    dir_okay=False,
    resolve_path=True,
    shell_complete=complete_config_files,
)
