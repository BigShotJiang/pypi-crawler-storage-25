from __future__ import annotations

import fnmatch
import subprocess
from pathlib import Path
from typing import List, Sequence

from dbt_pathfinder.paths import is_dbt_path, normalize_rel_path
from dbt_pathfinder.services.pathfinder_service import PathfinderError


def path_ignored_in_git_diff(
    rel_path: str,
    *,
    ignore_globs: Sequence[str] = (),
    ignore_prefixes: Sequence[str] = (),
) -> bool:
    """True if a repo-relative path should be dropped before dbt path filtering."""
    p = Path(rel_path).as_posix()
    for pref in ignore_prefixes:
        base = pref.rstrip("/")
        if p == base or p.startswith(pref):
            return True
    for pattern in ignore_globs:
        if fnmatch.fnmatch(p, pattern):
            return True
    return False


def filter_git_diff_paths(
    paths: List[str],
    *,
    ignore_globs: Sequence[str] = (),
    ignore_prefixes: Sequence[str] = (),
) -> List[str]:
    if not ignore_globs and not ignore_prefixes:
        return list(paths)
    return [
        p
        for p in paths
        if not path_ignored_in_git_diff(
            p, ignore_globs=ignore_globs, ignore_prefixes=ignore_prefixes
        )
    ]


def git_diff_changed_paths(
    diff_range: str,
    *,
    cwd: Path,
    ignore_globs: Sequence[str] = (),
    ignore_prefixes: Sequence[str] = (),
) -> List[str]:
    """
    Return project-relative paths changed in ``git diff`` for the given ref range.
    Uses ``git diff --name-only`` (added/copied/modified/renamed/type-changed).
    """
    result = subprocess.run(
        [
            "git",
            "-c",
            "core.quotepath=false",
            "diff",
            "--name-only",
            "--diff-filter=ACMRT",
            diff_range,
        ],
        cwd=str(cwd.resolve()),
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()
        raise PathfinderError(f"git diff failed for {diff_range!r}: {err or 'unknown error'}")

    paths: List[str] = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        paths.append(normalize_rel_path(line))
    return filter_git_diff_paths(
        paths, ignore_globs=ignore_globs, ignore_prefixes=ignore_prefixes
    )


def filter_dbt_paths(paths: List[str]) -> List[str]:
    return [p for p in paths if is_dbt_path(p)]
