from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

CONFIG_FILENAMES: tuple[str, ...] = (".dbt-pathfinder.toml", "dbt-pathfinder.toml")
ENV_CONFIG_PATH = "DBT_PATHFINDER_CONFIG"


def _toml_loads(data: bytes) -> Dict[str, Any]:
    if sys.version_info >= (3, 11):
        import tomllib

        return tomllib.loads(data.decode("utf-8"))
    import tomli

    return tomli.loads(data.decode("utf-8"))


def _normalize_prefixes(prefixes: Iterable[str]) -> List[str]:
    out: List[str] = []
    for p in prefixes:
        s = Path(p).as_posix().lstrip("./")
        if s and not s.endswith("/"):
            s = f"{s}/"
        if s:
            out.append(s)
    return out


class PathfinderSettings(BaseModel):
    """Defaults and repo-local tuning loaded from ``.dbt-pathfinder.toml`` (optional)."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    critical_tags: tuple[str, ...] = Field(default_factory=tuple)
    fanout_model_successors_threshold: int = Field(default=2, ge=1)
    exposure_points_multiplier: int = Field(default=3, ge=0)
    exposure_points_cap: int = Field(default=12, ge=0)
    column_mode_default: bool = False
    git_diff_ignore_globs: tuple[str, ...] = Field(default_factory=tuple)
    git_diff_ignore_prefixes: tuple[str, ...] = Field(default_factory=tuple)

    @field_validator("critical_tags", mode="before")
    @classmethod
    def _coerce_tags(cls, v: Any) -> tuple[str, ...]:
        if v is None:
            return ()
        if isinstance(v, str):
            return tuple(s.strip() for s in v.split(",") if s.strip())
        if isinstance(v, Iterable) and not isinstance(v, (str, bytes)):
            return tuple(str(x).strip() for x in v if str(x).strip())
        raise TypeError("critical_tags must be a list or comma-separated string")

    @field_validator("git_diff_ignore_globs", mode="before")
    @classmethod
    def _coerce_globs(cls, v: Any) -> tuple[str, ...]:
        if v is None:
            return ()
        if isinstance(v, str):
            return tuple(s.strip() for s in v.split(",") if s.strip())
        if isinstance(v, Iterable) and not isinstance(v, (str, bytes)):
            return tuple(str(x).strip() for x in v if str(x).strip())
        raise TypeError("expected list of strings or comma-separated string")

    @field_validator("git_diff_ignore_prefixes", mode="before")
    @classmethod
    def _coerce_prefs(cls, v: Any) -> tuple[str, ...]:
        if v is None:
            return ()
        if isinstance(v, str):
            raw = tuple(s.strip() for s in v.split(",") if s.strip())
        elif isinstance(v, Iterable) and not isinstance(v, (str, bytes)):
            raw = tuple(str(x).strip() for x in v if str(x).strip())
        else:
            raise TypeError("expected list of strings or comma-separated string")
        return tuple(_normalize_prefixes(raw))


def find_config_path(start: Optional[Path] = None) -> Optional[Path]:
    """Walk parents from ``start`` (or cwd) for the first matching config filename."""
    cur = (start or Path.cwd()).resolve()
    for directory in [cur, *cur.parents]:
        for name in CONFIG_FILENAMES:
            candidate = directory / name
            if candidate.is_file():
                return candidate
    return None


def _extract_table(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge supported shapes into flat kwargs for ``PathfinderSettings``.

    Supported:
    - Keys at file root
    - ``[pathfinder]`` table (overrides root for overlapping keys)
    - ``[git_diff]`` for ignore rules (merged with root ``git_diff_*`` keys)
    """
    data = dict(raw)
    section = data.pop("pathfinder", None)
    if section is not None and not isinstance(section, dict):
        raise ValueError("[pathfinder] must be a table")
    git_table = data.pop("git_diff", None)
    if git_table is not None and not isinstance(git_table, dict):
        raise ValueError("[git_diff] must be a table")

    merged: Dict[str, Any] = {**data}
    if section:
        merged.update(section)

    globs: List[str] = []
    prefs: List[str] = []
    if git_table:
        globs.extend(git_table.get("ignore_globs") or [])
        prefs.extend(git_table.get("ignore_prefixes") or [])
    root_globs = merged.pop("git_diff_ignore_globs", None)
    root_prefs = merged.pop("git_diff_ignore_prefixes", None)
    if root_globs is not None:
        globs = list(root_globs) + globs
    if root_prefs is not None:
        prefs = list(root_prefs) + prefs

    if globs:
        merged["git_diff_ignore_globs"] = globs
    if prefs:
        merged["git_diff_ignore_prefixes"] = prefs

    return merged


def load_settings_from_path(path: Path) -> PathfinderSettings:
    raw_bytes = path.read_bytes()
    raw = _toml_loads(raw_bytes)
    if not isinstance(raw, dict):
        raise ValueError("config root must be a TOML table")
    flat = _extract_table(raw)
    return PathfinderSettings.model_validate(flat)


def resolve_settings_path(explicit: Optional[Path]) -> Optional[Path]:
    if explicit is not None:
        return explicit.resolve()
    env = os.environ.get(ENV_CONFIG_PATH, "").strip()
    if env:
        return Path(env).expanduser().resolve()
    return find_config_path()


def load_settings(explicit: Optional[Path] = None) -> PathfinderSettings:
    """
    Load settings from ``explicit``, ``DBT_PATHFINDER_CONFIG``, or an upward search
    for ``.dbt-pathfinder.toml`` / ``dbt-pathfinder.toml``. Missing file → defaults.
    """
    path = resolve_settings_path(explicit)
    if path is None or not path.is_file():
        return PathfinderSettings()
    return load_settings_from_path(path)


def load_settings_or_fail(explicit: Optional[Path]) -> tuple[PathfinderSettings, Optional[Path]]:
    """Like ``load_settings`` but errors if ``explicit`` points to a missing file."""
    if explicit is not None:
        p = explicit.expanduser().resolve()
        if not p.is_file():
            raise FileNotFoundError(f"Config file not found: {p}")
        return load_settings_from_path(p), p
    path = resolve_settings_path(None)
    if path is None or not path.is_file():
        return PathfinderSettings(), path
    return load_settings_from_path(path), path
