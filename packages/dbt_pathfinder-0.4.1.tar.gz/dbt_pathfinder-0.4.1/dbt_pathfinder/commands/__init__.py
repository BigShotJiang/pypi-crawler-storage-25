"""CLI command implementations (invoked from ``cli``)."""
