from __future__ import annotations

import json

from dbt_pathfinder.renderers.rich_renderer import render_impact_rich
from dbt_pathfinder.renderers.text_renderer import render_impact
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.services.pathfinder_service import PathfinderService


def run_impact(service: PathfinderService, model: str, output: str = "text", ui: str = "rich"):
    impact_data = service.impact(model)
    if output == "text":
        if ui == "text":
            return render_impact(impact_data)
        if ui == "rich":
            return render_impact_rich(impact_data)
        raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
    if output == "json":
        return json.dumps(impact_data, indent=2, sort_keys=True)
    raise PathfinderError("Invalid --output. Use 'text' or 'json'.")
