from __future__ import annotations

from dbt_pathfinder.renderers.rich_renderer import render_path_rich
from dbt_pathfinder.renderers.text_renderer import render_path
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.services.pathfinder_service import PathfinderService


def run_path(service: PathfinderService, from_node: str, to_node: str, directed: bool, ui: str = "rich"):
    path_nodes = service.path(from_node, to_node, directed=directed)
    if ui == "text":
        return render_path(path_nodes)
    if ui == "rich":
        return render_path_rich(path_nodes)
    raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
