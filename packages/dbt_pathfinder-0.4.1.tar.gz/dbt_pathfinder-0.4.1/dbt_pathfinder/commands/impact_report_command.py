from __future__ import annotations

import json
from pathlib import Path
from typing import List, Literal, Optional, Sequence

from dbt_pathfinder.renderers.github_markdown import render_impact_report_github
from dbt_pathfinder.renderers.rich_renderer import render_impact_report_rich
from dbt_pathfinder.renderers.text_renderer import render_impact_report
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError


def run_impact_report(
    service: CIImpactService,
    *,
    model: Optional[str] = None,
    files: Optional[List[str]] = None,
    git_diff: Optional[str] = None,
    repo_root: Optional[Path] = None,
    report_format: Literal["text", "json", "github"] = "text",
    include_tests: bool = True,
    include_columns: bool = False,
    ui: str = "rich",
    git_diff_ignore_globs: Sequence[str] = (),
    git_diff_ignore_prefixes: Sequence[str] = (),
):
    has_model = model is not None and bool(model.strip())
    has_files = bool(files)
    has_git = git_diff is not None and bool(git_diff.strip())
    n = int(has_model) + int(has_files) + int(has_git)
    if n != 1:
        raise PathfinderError("Provide exactly one of --model, --files, or --git-diff.")

    if has_model:
        report = service.build_impact_report(
            input_mode="model",
            model_ref=model,
            include_tests=include_tests,
            include_columns=include_columns,
        )
    elif has_files:
        report = service.build_impact_report(
            input_mode="files",
            files=list(files),
            include_tests=include_tests,
            include_columns=include_columns,
        )
    else:
        report = service.build_impact_report(
            input_mode="git_diff",
            git_diff_range=git_diff.strip(),
            cwd=repo_root,
            include_tests=include_tests,
            include_columns=include_columns,
            git_diff_ignore_globs=git_diff_ignore_globs,
            git_diff_ignore_prefixes=git_diff_ignore_prefixes,
        )

    if report_format == "json":
        return json.dumps(report.model_dump(), indent=2, sort_keys=True)
    if report_format == "github":
        return render_impact_report_github(
            report,
            node_display=service.format_node_label,
            include_columns=include_columns,
        )
    if report_format == "text":
        if ui == "text":
            return render_impact_report(
                report,
                include_tests=include_tests,
                include_columns=include_columns,
                node_display=service.format_node_label,
            )
        if ui == "rich":
            return render_impact_report_rich(
                report,
                include_tests=include_tests,
                include_columns=include_columns,
                node_display=service.format_node_label,
            )
        raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
    raise PathfinderError("Invalid --format. Use 'text', 'json', or 'github'.")
