from __future__ import annotations

import json

from dbt_pathfinder.renderers.rich_renderer import render_path_explain_rich
from dbt_pathfinder.renderers.text_renderer import render_path_explain
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.services.pathfinder_service import PathfinderService


def run_path_explain(
    service: PathfinderService,
    from_node: str,
    to_node: str,
    directed: bool,
    output: str = "text",
    ui: str = "rich",
):
    payload = service.explain_path(from_node, to_node, directed=directed)
    if output == "json":
        return json.dumps(payload, indent=2, sort_keys=True)
    if output == "text":
        if ui == "text":
            return render_path_explain(payload)
        if ui == "rich":
            return render_path_explain_rich(payload)
        raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
    raise PathfinderError("Invalid --output. Use 'text' or 'json'.")
