from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import List, Optional

from rich.console import Console
from rich.table import Table

from dbt_pathfinder.graph.graph_builder import build_graph
from dbt_pathfinder.parser.manifest_parser import ManifestParseError, parse_manifest
from dbt_pathfinder.settings import PathfinderSettings, load_settings_or_fail


def _manifest_candidates(cli_path: Optional[str]) -> List[Path]:
    ordered: List[Path] = []
    if cli_path and cli_path.strip():
        ordered.append(Path(cli_path).expanduser().resolve())
    env = os.environ.get("DBT_MANIFEST_PATH", "").strip()
    if env:
        p = Path(env).expanduser().resolve()
        if p not in ordered:
            ordered.append(p)
    for rel in (Path("target") / "manifest.json", Path("manifest.json")):
        p = (Path.cwd() / rel).resolve()
        if p not in ordered:
            ordered.append(p)
    return ordered


def run_doctor(
    *,
    manifest: Optional[str],
    config: Optional[Path],
    console: Console,
) -> int:
    exit_code = 0

    console.print("[bold]dbt-pathfinder doctor[/bold]\n")

    py = sys.version.split()[0]
    console.print(f"Python: {py} ({sys.executable})")
    if sys.version_info < (3, 9):
        console.print("[yellow]Warning: dbt-pathfinder requires Python 3.9+[/yellow]")
        exit_code = 1

    git = shutil.which("git")
    if git:
        console.print(f"git: [green]ok[/green] ({git})")
    else:
        console.print("git: [red]not found on PATH[/red] (git-diff commands will fail)")
        exit_code = 1

    settings: PathfinderSettings
    cfg_resolved: Optional[Path]
    try:
        settings, cfg_resolved = load_settings_or_fail(config)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        return 1

    if cfg_resolved and cfg_resolved.is_file():
        console.print(f"Config: [green]{cfg_resolved}[/green]")
    else:
        console.print("Config: [dim]none found[/dim] (using defaults; see --config / DBT_PATHFINDER_CONFIG)")

    table = Table(title="Effective settings (non-defaults only)", show_header=True)
    table.add_column("Setting")
    table.add_column("Value")
    defaults = PathfinderSettings()
    rows = 0
    if settings.critical_tags:
        table.add_row("critical_tags", ", ".join(settings.critical_tags))
        rows += 1
    if settings.fanout_model_successors_threshold != defaults.fanout_model_successors_threshold:
        table.add_row("fanout_model_successors_threshold", str(settings.fanout_model_successors_threshold))
        rows += 1
    if settings.exposure_points_multiplier != defaults.exposure_points_multiplier:
        table.add_row("exposure_points_multiplier", str(settings.exposure_points_multiplier))
        rows += 1
    if settings.exposure_points_cap != defaults.exposure_points_cap:
        table.add_row("exposure_points_cap", str(settings.exposure_points_cap))
        rows += 1
    if settings.column_mode_default != defaults.column_mode_default:
        table.add_row("column_mode_default", str(settings.column_mode_default))
        rows += 1
    if settings.git_diff_ignore_globs:
        table.add_row("git_diff_ignore_globs", ", ".join(settings.git_diff_ignore_globs))
        rows += 1
    if settings.git_diff_ignore_prefixes:
        table.add_row("git_diff_ignore_prefixes", ", ".join(settings.git_diff_ignore_prefixes))
        rows += 1
    if rows:
        console.print(table)
    else:
        console.print("[dim]All settings at defaults.[/dim]")

    chosen: Optional[Path] = None
    for candidate in _manifest_candidates(manifest):
        if candidate.is_file():
            chosen = candidate
            break

    if chosen is None:
        console.print(
            "\nManifest: [yellow]not found[/yellow] "
            "(tried --manifest, DBT_MANIFEST_PATH, target/manifest.json, ./manifest.json)"
        )
        return exit_code

    console.print(f"\nManifest: [green]{chosen}[/green]")
    try:
        man = parse_manifest(chosen)
    except ManifestParseError as exc:
        console.print(f"[red]Manifest error:[/red] {exc}")
        return 1

    n_models = sum(1 for n in man.nodes.values() if n.resource_type == "model")
    graph = build_graph(man)
    console.print("Graph:")
    console.print(f"  • nodes (graph): {graph.number_of_nodes()}")
    console.print(f"  • edges (graph): {graph.number_of_edges()}")
    console.print(f"  • models (manifest nodes): {n_models}")
    console.print(f"  • exposures: {len(man.exposures)}")
    console.print(f"  • sources: {len(man.sources)}")

    return exit_code
