from __future__ import annotations

import json

from dbt_pathfinder.renderers.rich_renderer import render_ci_impact_rich
from dbt_pathfinder.renderers.text_renderer import render_ci_impact
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError


def run_ci_impact(
    service: CIImpactService,
    files: list[str],
    output: str = "text",
    *,
    include_tests: bool = True,
    include_columns: bool = False,
    ui: str = "rich",
):
    result = service.build_result(files, include_tests=include_tests, include_columns=include_columns)
    if output == "text":
        if ui == "text":
            return render_ci_impact(
                result,
                include_tests=include_tests,
                include_columns=include_columns,
                node_display=service.format_node_label,
            )
        if ui == "rich":
            return render_ci_impact_rich(
                result,
                include_tests=include_tests,
                include_columns=include_columns,
                node_display=service.format_node_label,
            )
        raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
    if output == "json":
        return json.dumps(result.model_dump(), indent=2, sort_keys=True)
    raise PathfinderError("Invalid --output. Use 'text' or 'json'.")
