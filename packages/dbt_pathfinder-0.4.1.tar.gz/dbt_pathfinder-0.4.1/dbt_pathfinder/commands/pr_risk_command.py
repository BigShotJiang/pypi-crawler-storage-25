from __future__ import annotations

import json
from pathlib import Path
from typing import FrozenSet, List, Optional, Sequence

from dbt_pathfinder.renderers.rich_renderer import render_pr_risk_rich
from dbt_pathfinder.renderers.text_renderer import render_pr_risk
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.services.pr_risk_service import PRRiskService


def run_pr_risk(
    service: PRRiskService,
    *,
    git_diff: Optional[str] = None,
    files: Optional[List[str]] = None,
    repo_root: Optional[Path] = None,
    critical_tags: Optional[FrozenSet[str]] = None,
    output: str = "text",
    ui: str = "rich",
    ignore_globs: Sequence[str] = (),
    ignore_prefixes: Sequence[str] = (),
):
    tags = critical_tags or frozenset()
    cwd = repo_root.resolve() if repo_root else None

    if git_diff is not None:
        if files:
            raise PathfinderError("Pass either --git-diff or --files, not both.")
        rng = git_diff.strip()
        if not rng:
            raise PathfinderError("--git-diff range must be non-empty.")
        result = service.analyze_diff(
            rng,
            cwd=cwd,
            critical_tags=tags,
            ignore_globs=ignore_globs,
            ignore_prefixes=ignore_prefixes,
        )
    elif files:
        result = service.analyze_files(list(files), critical_tags=tags)
    else:
        raise PathfinderError("Provide --git-diff RANGE or at least one --files PATH.")

    if output == "json":
        return json.dumps(result.model_dump(), indent=2, sort_keys=True)
    if output == "text":
        if ui == "text":
            return render_pr_risk(result)
        if ui == "rich":
            return render_pr_risk_rich(result)
        raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
    raise PathfinderError("Invalid --output. Use 'text' or 'json'.")
