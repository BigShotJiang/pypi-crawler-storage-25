from __future__ import annotations

from dbt_pathfinder.renderers.rich_renderer import render_show_rich
from dbt_pathfinder.renderers.text_renderer import render_show
from dbt_pathfinder.services.pathfinder_service import PathfinderError
from dbt_pathfinder.services.pathfinder_service import PathfinderService


def run_show(service: PathfinderService, model: str, ui: str = "rich", verbose: bool = False):
    payload = service.show(model)
    if ui == "text":
        return render_show(payload, verbose=verbose)
    if ui == "rich":
        return render_show_rich(payload, verbose=verbose)
    raise PathfinderError("Invalid --ui. Use 'text' or 'rich'.")
