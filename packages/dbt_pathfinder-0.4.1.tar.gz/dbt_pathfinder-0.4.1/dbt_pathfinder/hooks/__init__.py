"""Optional entry points for git hooks (e.g. pre-commit)."""
