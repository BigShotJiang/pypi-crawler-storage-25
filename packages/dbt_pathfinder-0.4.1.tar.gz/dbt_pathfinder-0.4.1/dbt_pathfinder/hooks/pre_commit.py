"""
pre-commit integration: run ``ci-impact`` or ``pr-risk`` on staged dbt files.

Configure in ``.pre-commit-config.yaml`` (see ``examples/pre-commit-config.yaml``).

Environment variables:

* ``DBT_MANIFEST_PATH`` — path to ``manifest.json`` (default: ``target/manifest.json``)
* ``DBT_PATHFINDER_CONFIG`` — optional path to ``.dbt-pathfinder.toml`` (same as CLI ``--config``)
* ``DBT_PATHFINDER_PR_RISK_FAIL_ON`` — if set to ``high`` or ``medium``, ``pr-risk`` exits
  non-zero when the JSON score is at or above that level (after a successful CLI run)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from typing import List, Literal, Optional, Sequence

from dbt_pathfinder.paths import is_dbt_path


def _cli_base() -> List[str]:
    return [sys.executable, "-m", "dbt_pathfinder.cli"]


def _run_ci_impact(manifest: str, files: Sequence[str]) -> subprocess.CompletedProcess[str]:
    args = _cli_base() + [
        "ci-impact",
        "--manifest",
        manifest,
        "--output",
        "json",
        "--ui",
        "text",
    ]
    for f in files:
        args.extend(["--files", f])
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        check=False,
    )


def _run_pr_risk(manifest: str, files: Sequence[str]) -> subprocess.CompletedProcess[str]:
    args = _cli_base() + [
        "pr-risk",
        "--manifest",
        manifest,
        "--output",
        "json",
        "--ui",
        "text",
    ]
    for f in files:
        args.extend(["--files", f])
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        check=False,
    )


def _maybe_fail_pr_risk(stdout: str) -> Optional[int]:
    threshold = (os.environ.get("DBT_PATHFINDER_PR_RISK_FAIL_ON") or "").strip().lower()
    if threshold not in {"high", "medium"}:
        return None
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return None
    score = str(data.get("score", "")).strip()
    order = {"Low": 0, "Medium": 1, "High": 2}
    need = order.get(threshold.capitalize(), -1)
    got = order.get(score, -1)
    if got >= need >= 0:
        print(
            f"dbt-pathfinder: pr-risk score {score!r} meets fail threshold {threshold!r}",
            file=sys.stderr,
        )
        return 1
    return None


def main(argv: Optional[Sequence[str]] = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print(
            "Usage: python -m dbt_pathfinder.hooks.pre_commit {ci-impact|pr-risk} [FILE ...]",
            file=sys.stderr,
        )
        return 2
    cmd: Literal["ci-impact", "pr-risk"]
    raw = argv[0].strip().lower().replace("_", "-")
    if raw in ("ci-impact", "ci_impact", "ciimpact"):
        cmd = "ci-impact"
    elif raw in ("pr-risk", "pr_risk", "prrisk"):
        cmd = "pr-risk"
    else:
        print(f"Unknown command {argv[0]!r}; use ci-impact or pr-risk", file=sys.stderr)
        return 2

    files = [f for f in argv[1:] if is_dbt_path(f)]
    if not files:
        return 0

    manifest = os.environ.get("DBT_MANIFEST_PATH", "target/manifest.json").strip() or "target/manifest.json"

    if cmd == "ci-impact":
        proc = _run_ci_impact(manifest, files)
    else:
        proc = _run_pr_risk(manifest, files)

    if proc.stdout:
        print(proc.stdout.rstrip())
    if proc.stderr:
        print(proc.stderr.rstrip(), file=sys.stderr)
    if proc.returncode != 0:
        return proc.returncode

    if cmd == "pr-risk" and proc.stdout:
        gate = _maybe_fail_pr_risk(proc.stdout)
        if gate is not None:
            return gate

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
