"""
JSON Schema for machine-readable CLI outputs.

Schemas are generated from Pydantic models (serialization mode). When model fields change,
bump ``SCHEMA_VERSION`` and document in the changelog.

Stable programmatic access::

    from dbt_pathfinder.json_schemas import get_all_schemas_bundle
    from dbt_pathfinder import CIImpactResult, ImpactReport, RiskResult
"""

from __future__ import annotations

import importlib.metadata
import json
from typing import Any, Dict, Literal, Union

from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.impact_report import ImpactReport
from dbt_pathfinder.models.pr_risk import RiskResult

# Bump when JSON output shape is intentionally breaking for consumers.
SCHEMA_VERSION = "1"

_JSON_SCHEMA_DRAFT = "https://json-schema.org/draft/2020-12/schema"


def _annotate(schema: Dict[str, Any], *, name: str) -> Dict[str, Any]:
    out = dict(schema)
    out["$schema"] = _JSON_SCHEMA_DRAFT
    out["$id"] = f"urn:dbt-pathfinder:schema:v{SCHEMA_VERSION}:{name}"
    out.setdefault("title", name)
    return out


def get_ci_impact_result_schema() -> Dict[str, Any]:
    """JSON Schema for ``ci-impact --output json`` (``CIImpactResult``)."""
    return _annotate(
        CIImpactResult.model_json_schema(mode="serialization"),
        name="CIImpactResult",
    )


def get_impact_report_schema() -> Dict[str, Any]:
    """JSON Schema for ``impact-report --format json`` (``ImpactReport``)."""
    return _annotate(
        ImpactReport.model_json_schema(mode="serialization"),
        name="ImpactReport",
    )


def get_risk_result_schema() -> Dict[str, Any]:
    """JSON Schema for ``pr-risk --output json`` (``RiskResult``)."""
    return _annotate(
        RiskResult.model_json_schema(mode="serialization"),
        name="RiskResult",
    )


def _package_version() -> str:
    try:
        return importlib.metadata.version("dbt-pathfinder")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0"


def get_all_schemas_bundle() -> Dict[str, Any]:
    """Single object with all schemas plus package metadata for tooling."""
    return {
        "package_version": _package_version(),
        "schema_version": SCHEMA_VERSION,
        "schemas": {
            "ci_impact_result": get_ci_impact_result_schema(),
            "impact_report": get_impact_report_schema(),
            "risk_result": get_risk_result_schema(),
        },
    }


def dump_schemas_json(
    which: Literal["ci-impact", "impact-report", "pr-risk", "all"] = "all",
    *,
    indent: Union[int, None] = 2,
) -> str:
    """Serialize schema(s) to a JSON string."""
    if which == "ci-impact":
        payload: Dict[str, Any] = get_ci_impact_result_schema()
    elif which == "impact-report":
        payload = get_impact_report_schema()
    elif which == "pr-risk":
        payload = get_risk_result_schema()
    else:
        payload = get_all_schemas_bundle()
    return json.dumps(payload, indent=indent, sort_keys=True)
