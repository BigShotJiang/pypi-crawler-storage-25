from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

from dbt_pathfinder.models.ci_impact import CIImpactResult


class ImpactReport(BaseModel):
    """Unified impact output for model, file list, or git diff inputs."""

    input_mode: Literal["model", "files", "git_diff"]
    git_diff_range: Optional[str] = None
    changed_files: list[str] = Field(default_factory=list)
    changed_unique_ids: list[str] = Field(default_factory=list)
    changed_nodes: list[str] = Field(default_factory=list)
    impacted_by_depth: dict[int, list[str]] = Field(default_factory=dict)
    column_impact_by_depth: dict[int, dict[str, list[str]]] = Field(default_factory=dict)
    tests: list[str] = Field(default_factory=list)
    suggested_build_command: str = ""
    suggested_test_command: str = ""

    def to_ci_impact_result(self) -> CIImpactResult:
        """Subset compatible with legacy ``CIImpactResult`` consumers."""
        return CIImpactResult(
            changed_files=self.changed_files,
            changed_nodes=self.changed_nodes,
            impacted_by_depth=self.impacted_by_depth,
            column_impact_by_depth=self.column_impact_by_depth,
            tests=self.tests,
            suggested_command=self.suggested_build_command,
        )
