"""Pydantic models for manifests, reports, and API payloads."""
