from __future__ import annotations

from pydantic import BaseModel, Field


class RiskResult(BaseModel):
    score: str
    reasons: list[str] = Field(default_factory=list)
    suggested_build_command: str = ""
    suggested_test_command: str = ""
