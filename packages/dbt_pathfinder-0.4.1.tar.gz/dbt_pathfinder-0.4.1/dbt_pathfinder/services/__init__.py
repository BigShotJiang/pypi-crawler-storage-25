"""Core graph, impact, and pathfinding services."""
