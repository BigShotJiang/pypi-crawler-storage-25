from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import FrozenSet, List, Optional, Sequence, Set

from dbt_pathfinder.git_changes import filter_dbt_paths, git_diff_changed_paths
from dbt_pathfinder.graph.graph_builder import build_graph
from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.pr_risk import RiskResult
from dbt_pathfinder.parser.manifest_parser import parse_manifest
from dbt_pathfinder.paths import normalize_rel_path
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError, PathfinderService


@dataclass(frozen=True)
class PRRiskHeuristics:
    """Tunable PR-risk scoring knobs (defaults match historical CLI behavior)."""

    fanout_model_successors_threshold: int = 2
    exposure_points_multiplier: int = 3
    exposure_points_cap: int = 12


class PRRiskService:
    """PR risk scoring from manifest DAG lineage (node-level); optional git diff input."""

    def __init__(
        self,
        ci: CIImpactService,
        pathfinder: PathfinderService,
        *,
        heuristics: Optional[PRRiskHeuristics] = None,
    ) -> None:
        self._ci = ci
        self._pf = pathfinder
        self._heuristics = heuristics or PRRiskHeuristics()

    @classmethod
    def from_manifest(
        cls,
        manifest_path: str | Path,
        *,
        heuristics: Optional[PRRiskHeuristics] = None,
    ) -> "PRRiskService":
        manifest = parse_manifest(manifest_path)
        graph = build_graph(manifest)
        return cls(
            CIImpactService(manifest, graph),
            PathfinderService(manifest, graph),
            heuristics=heuristics,
        )

    def analyze_diff(
        self,
        diff_range: str,
        *,
        cwd: Optional[Path] = None,
        critical_tags: Optional[FrozenSet[str]] = None,
        ignore_globs: Sequence[str] = (),
        ignore_prefixes: Sequence[str] = (),
    ) -> RiskResult:
        root = cwd or Path.cwd()
        raw_paths = git_diff_changed_paths(
            diff_range,
            cwd=root,
            ignore_globs=ignore_globs,
            ignore_prefixes=ignore_prefixes,
        )
        dbt_paths = filter_dbt_paths(raw_paths)
        tags = critical_tags or frozenset()
        if raw_paths and not dbt_paths:
            result = self.analyze_files([], critical_tags=tags)
            result.reasons.insert(1, "Git diff contained no dbt project files (.sql/.yml/.yaml).")
            return result
        return self.analyze_files(dbt_paths, critical_tags=tags)

    def analyze_files(self, files: List[str], *, critical_tags: Optional[FrozenSet[str]] = None) -> RiskResult:
        tags = critical_tags or frozenset()
        norm = [normalize_rel_path(f) for f in files]
        changed_ids = self._ci.resolve_changed_files(norm)
        impact = self._ci.build_result(norm, include_tests=True)
        return self.score_risk(impact, changed_unique_ids=changed_ids, critical_tags=tags)

    def score_risk(
        self,
        impact: CIImpactResult,
        *,
        changed_unique_ids: List[str],
        critical_tags: FrozenSet[str],
    ) -> RiskResult:
        reasons: List[str] = []
        points = 0

        reasons.append(
            "Scope: node-level DAG lineage; column-to-column propagation not analyzed "
            "(column uniqueness test gaps are still counted)."
        )

        if not impact.changed_files:
            reasons.append("No files provided for analysis.")
            return RiskResult(score="Low", reasons=reasons, suggested_build_command="dbt build", suggested_test_command="dbt test")

        if not changed_unique_ids and impact.changed_files:
            reasons.append("No manifest nodes matched changed paths (check paths vs manifest original_file_path).")

        downstream_flat: Set[str] = {uid for ids in impact.impacted_by_depth.values() for uid in ids}
        impacted_count = len(downstream_flat)
        if impacted_count:
            reasons.append(f"{impacted_count} downstream nodes impacted")
            points += min(impacted_count, 25)

        max_depth = max(impact.impacted_by_depth.keys()) if impact.impacted_by_depth else 0
        if max_depth > 0:
            reasons.append(f"Impact reaches depth {max_depth}")
            points += max_depth * 2

        anchor = set(changed_unique_ids) | downstream_flat

        h = self._heuristics
        exposure_hits = self._count_exposures_depending_on_anchor(anchor)
        if exposure_hits > 0:
            reasons.append(f"{exposure_hits} exposures depend on nodes in the impacted subgraph")
            exp_pts = exposure_hits * h.exposure_points_multiplier
            points += min(exp_pts, h.exposure_points_cap)

        fanout_models = self._count_models_with_high_downstream_model_fanout(
            anchor, min_successors=h.fanout_model_successors_threshold
        )
        if fanout_models > 0:
            thr = h.fanout_model_successors_threshold
            if fanout_models == 1:
                reasons.append(
                    f"1 model in the impacted subgraph has "
                    f"{thr}+ direct downstream models (DAG fan-out)"
                )
            else:
                reasons.append(
                    f"{fanout_models} models in the impacted subgraph each have "
                    f"{thr}+ direct downstream models (DAG fan-out)"
                )
            points += min(fanout_models * 2, 10)

        if critical_tags:
            matched_tags: Set[str] = set()
            for uid in anchor:
                node = self._ci._node_index.get(uid)
                if not node:
                    continue
                for t in node.tags:
                    if t in critical_tags:
                        matched_tags.add(t)
            for t in sorted(matched_tags):
                reasons.append(f"affects tag: {t}")
                points += 4

        missing_unique = self._count_columns_missing_unique_tests(anchor)
        if missing_unique > 0:
            reasons.append(f"{missing_unique} model columns lack a uniqueness test (manifest-derived)")
            points += min(missing_unique, 12)

        unknown_joins = self._count_unknown_direct_model_joins(changed_unique_ids)
        if unknown_joins > 0:
            reasons.append(
                f"{unknown_joins} direct downstream model joins have unknown cardinality (path-explain heuristic)"
            )
            points += unknown_joins * 2

        score = self._points_to_level(points)

        build_cmd = impact.suggested_command
        test_cmd = self._ci.suggested_test_command(changed_unique_ids)

        return RiskResult(
            score=score,
            reasons=reasons,
            suggested_build_command=build_cmd,
            suggested_test_command=test_cmd,
        )

    def _points_to_level(self, points: int) -> str:
        if points <= 10:
            return "Low"
        if points <= 24:
            return "Medium"
        return "High"

    def _count_exposures_depending_on_anchor(self, anchor: Set[str]) -> int:
        n = 0
        for exp in self._pf.manifest.exposures.values():
            if any(dep in anchor for dep in exp.depends_on.nodes):
                n += 1
        return n

    def _count_models_with_high_downstream_model_fanout(
        self, anchor: Set[str], *, min_successors: int
    ) -> int:
        hits = 0
        for uid in anchor:
            node = self._ci._node_index.get(uid)
            if not node or node.resource_type != "model":
                continue
            n_model_children = sum(
                1
                for s in self._ci.graph.successors(uid)
                if (ch := self._ci._node_index.get(s)) is not None and ch.resource_type == "model"
            )
            if n_model_children >= min_successors:
                hits += 1
        return hits

    def _count_columns_missing_unique_tests(self, anchor: Set[str]) -> int:
        uniq_index = self._pf._build_uniqueness_index()
        missing = 0
        for uid in anchor:
            node = self._ci._node_index.get(uid)
            if not node or node.resource_type != "model":
                continue
            covered = uniq_index.get(uid, {}).get("unique", set())
            for col_name in node.columns.keys():
                if col_name not in covered:
                    missing += 1
        return missing

    def _count_unknown_direct_model_joins(self, changed_unique_ids: List[str]) -> int:
        unknown = 0
        seen: Set[tuple[str, str]] = set()
        for cid in changed_unique_ids:
            node = self._ci._node_index.get(cid)
            if not node or node.resource_type != "model":
                continue
            for succ in self._ci.graph.successors(cid):
                down = self._ci._node_index.get(succ)
                if not down or down.resource_type != "model":
                    continue
                key = (cid, succ)
                if key in seen:
                    continue
                seen.add(key)
                try:
                    payload = self._pf.explain_path(node.name, down.name, directed=True)
                except PathfinderError:
                    continue
                for edge in payload.get("edges", []):
                    if edge.get("cardinality") == "unknown":
                        unknown += 1
                        break
        return unknown
