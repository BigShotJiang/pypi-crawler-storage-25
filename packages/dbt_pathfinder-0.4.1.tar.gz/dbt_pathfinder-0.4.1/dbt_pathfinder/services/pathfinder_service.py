from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
import re
from typing import Any, Dict, List, Optional, Set, Tuple

import networkx as nx

from dbt_pathfinder.graph.graph_builder import build_graph
from dbt_pathfinder.models.manifest import Manifest, ManifestNode
from dbt_pathfinder.parser.manifest_parser import parse_manifest


class PathfinderError(ValueError):
    """Base exception for pathfinder service errors."""


class NodeNotFoundError(PathfinderError):
    """Raised when a node name or unique_id does not resolve."""


class AmbiguousNodeError(PathfinderError):
    """Raised when a shorthand node name maps to multiple nodes."""


class NoPathError(PathfinderError):
    """Raised when no path exists between two nodes."""


class PathfinderService:
    def __init__(self, manifest: Manifest, graph: nx.DiGraph) -> None:
        self.manifest = manifest
        self.graph = graph

    @classmethod
    def from_manifest(cls, manifest_path: str | Path) -> "PathfinderService":
        manifest = parse_manifest(manifest_path)
        graph = build_graph(manifest)
        return cls(manifest=manifest, graph=graph)

    def _resolve_node(self, node_ref: str) -> str:
        if node_ref in self.graph:
            return node_ref

        matches = []
        for unique_id, attrs in self.graph.nodes(data=True):
            if attrs.get("name") == node_ref:
                matches.append(unique_id)

        if not matches:
            raise NodeNotFoundError(f"Node not found: {node_ref}")
        if len(matches) > 1:
            raise AmbiguousNodeError(
                f"Ambiguous node name '{node_ref}'. Use unique_id. Matches: {', '.join(sorted(matches))}"
            )
        return matches[0]

    def show(self, node_ref: str) -> Dict[str, Any]:
        node_id = self._resolve_node(node_ref)
        attrs = dict(self.graph.nodes[node_id])
        upstream = sorted(self.graph.predecessors(node_id))
        downstream = sorted(self.graph.successors(node_id))
        return {
            "node": node_id,
            "metadata": attrs,
            "upstream": upstream,
            "downstream": downstream,
        }

    def impact(self, node_ref: str) -> Dict[int, List[str]]:
        node_id = self._resolve_node(node_ref)
        by_depth: Dict[int, List[str]] = defaultdict(list)
        seen = {node_id}
        queue = deque([(node_id, 0)])

        while queue:
            current, depth = queue.popleft()
            for child in self.graph.successors(current):
                if child in seen:
                    continue
                seen.add(child)
                next_depth = depth + 1
                by_depth[next_depth].append(child)
                queue.append((child, next_depth))

        return {depth: sorted(nodes) for depth, nodes in sorted(by_depth.items())}

    def path(self, from_ref: str, to_ref: str, directed: bool = True) -> List[str]:
        from_node = self._resolve_node(from_ref)
        to_node = self._resolve_node(to_ref)
        graph = self.graph if directed else self.graph.to_undirected()

        try:
            return nx.shortest_path(graph, source=from_node, target=to_node)
        except nx.NetworkXNoPath as exc:
            raise NoPathError(f"No path between '{from_ref}' and '{to_ref}'") from exc

    def _node_index(self) -> Dict[str, ManifestNode]:
        idx: Dict[str, ManifestNode] = {}
        for collection in (self.manifest.nodes, self.manifest.sources, self.manifest.metrics, self.manifest.exposures):
            idx.update(collection)
        return idx

    def _build_uniqueness_index(self) -> Dict[str, Dict[str, Set[str]]]:
        result: Dict[str, Dict[str, Set[str]]] = defaultdict(lambda: {"unique": set(), "not_null": set()})
        node_index = self._node_index()
        for test_node in self.manifest.nodes.values():
            if test_node.resource_type != "test" or not test_node.test_metadata:
                continue
            test_name = str(test_node.test_metadata.get("name", ""))
            kwargs = test_node.test_metadata.get("kwargs") or {}
            column_name = kwargs.get("column_name")
            if not column_name:
                continue
            deps = [dep for dep in test_node.depends_on.nodes if dep in node_index and node_index[dep].resource_type != "test"]
            if not deps:
                continue
            target = deps[0]
            if test_name == "unique":
                result[target]["unique"].add(column_name)
            if test_name == "not_null":
                result[target]["not_null"].add(column_name)
        return result

    def _resolve_ref_call(self, expression: str) -> Optional[str]:
        ref_args = re.findall(r"'([^']+)'|\"([^\"]+)\"", expression)
        flat = [a or b for a, b in ref_args]
        if not flat:
            return None
        if len(flat) == 1:
            return self._resolve_node(flat[0])
        if len(flat) >= 2:
            # ref('package', 'model_name')
            return self._resolve_node(flat[-1])
        return None

    def _resolve_source_call(self, expression: str) -> Optional[str]:
        src_args = re.findall(r"'([^']+)'|\"([^\"]+)\"", expression)
        flat = [a or b for a, b in src_args]
        if len(flat) < 2:
            return None
        source_name = flat[1]
        matches = [
            unique_id
            for unique_id, attrs in self.graph.nodes(data=True)
            if attrs.get("resource_type") == "source" and attrs.get("name") == source_name
        ]
        if len(matches) == 1:
            return matches[0]
        return None

    def _alias_mapping_from_sql(self, sql: str) -> Dict[str, str]:
        alias_map: Dict[str, str] = {}
        pattern = re.compile(
            r"(from|join)\s+\{\{\s*(ref|source)\((?P<expr>[^)]*)\)\s*\}\}\s*(?:as\s+)?(?P<alias>[a-zA-Z_][\w]*)?",
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql):
            call_type = match.group(2).lower()
            expr = match.group("expr")
            alias = match.group("alias")
            resolved = None
            try:
                if call_type == "ref":
                    resolved = self._resolve_ref_call(expr)
                if call_type == "source":
                    resolved = self._resolve_source_call(expr)
            except PathfinderError:
                resolved = None
            if resolved:
                key = alias if alias else resolved.split(".")[-1]
                alias_map[key] = resolved
        return alias_map

    def _extract_join_pairs(self, sql: str) -> List[Tuple[str, str, str, str]]:
        clause_pattern = re.compile(r"\bon\b(?P<cond>.*?)(?=\bjoin\b|\bwhere\b|\bgroup\b|\border\b|$)", re.IGNORECASE | re.DOTALL)
        pair_pattern = re.compile(
            r"([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\s*=\s*([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)",
            re.IGNORECASE,
        )
        pairs: List[Tuple[str, str, str, str]] = []
        for clause in clause_pattern.finditer(sql):
            for pair in pair_pattern.finditer(clause.group("cond")):
                pairs.append((pair.group(1), pair.group(2), pair.group(3), pair.group(4)))
        return pairs

    def _cardinality_for_columns(
        self,
        upstream_id: str,
        upstream_columns: Set[str],
        other_id: Optional[str],
        other_columns: Set[str],
        uniqueness_index: Dict[str, Dict[str, Set[str]]],
    ) -> Tuple[str, str]:
        if not other_id or not upstream_columns or not other_columns:
            return "unknown", "low"
        upstream_unique = upstream_columns.issubset(
            uniqueness_index[upstream_id]["unique"] & uniqueness_index[upstream_id]["not_null"]
        )
        other_unique = other_columns.issubset(uniqueness_index[other_id]["unique"] & uniqueness_index[other_id]["not_null"])
        if upstream_unique and other_unique:
            return "1:1", "medium"
        if upstream_unique and not other_unique:
            return "1:N", "medium"
        if not upstream_unique and other_unique:
            return "N:1", "medium"
        return "N:N", "low"

    def explain_path(self, from_ref: str, to_ref: str, directed: bool = True) -> Dict[str, Any]:
        nodes = self.path(from_ref, to_ref, directed=directed)
        if len(nodes) < 2:
            return {"path": nodes, "edges": []}

        node_index = self._node_index()
        uniqueness_index = self._build_uniqueness_index()
        edge_explanations: List[Dict[str, Any]] = []

        for upstream_id, downstream_id in zip(nodes, nodes[1:]):
            downstream_node = node_index.get(downstream_id)
            sql = (downstream_node.raw_code if downstream_node else None) or (downstream_node.compiled_sql if downstream_node else None) or ""
            alias_map = self._alias_mapping_from_sql(sql)
            pairs = self._extract_join_pairs(sql)

            upstream_aliases = {alias for alias, model_id in alias_map.items() if model_id == upstream_id}
            join_keys: List[str] = []
            upstream_columns: Set[str] = set()
            other_columns: Set[str] = set()
            other_model: Optional[str] = None

            for left_alias, left_col, right_alias, right_col in pairs:
                if left_alias in upstream_aliases:
                    join_keys.append(f"{left_alias}.{left_col} = {right_alias}.{right_col}")
                    upstream_columns.add(left_col)
                    other_columns.add(right_col)
                    other_model = alias_map.get(right_alias, other_model)
                elif right_alias in upstream_aliases:
                    join_keys.append(f"{left_alias}.{left_col} = {right_alias}.{right_col}")
                    upstream_columns.add(right_col)
                    other_columns.add(left_col)
                    other_model = alias_map.get(left_alias, other_model)

            cardinality, confidence = self._cardinality_for_columns(
                upstream_id=upstream_id,
                upstream_columns=upstream_columns,
                other_id=other_model,
                other_columns=other_columns,
                uniqueness_index=uniqueness_index,
            )
            if not join_keys:
                confidence = "low"
                cardinality = "unknown"

            edge_explanations.append(
                {
                    "from": upstream_id,
                    "to": downstream_id,
                    "join_keys": sorted(set(join_keys)),
                    "cardinality": cardinality,
                    "confidence": confidence,
                    "notes": "best-effort inference from model SQL and dbt tests",
                }
            )

        return {"path": nodes, "edges": edge_explanations}
