from __future__ import annotations

from collections import deque
import re
from typing import Dict, List, Literal, Optional, Sequence, Set, Tuple

import networkx as nx

from dbt_pathfinder.git_changes import filter_dbt_paths, git_diff_changed_paths
from dbt_pathfinder.paths import normalize_rel_path
from dbt_pathfinder.graph.graph_builder import build_graph
from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.impact_report import ImpactReport
from dbt_pathfinder.models.manifest import Manifest, ManifestNode
from dbt_pathfinder.parser.manifest_parser import parse_manifest
from dbt_pathfinder.services.pathfinder_service import PathfinderError


class CIImpactService:
    def __init__(self, manifest: Manifest, graph: nx.DiGraph) -> None:
        self.manifest = manifest
        self.graph = graph
        self._node_index: Dict[str, ManifestNode] = {}
        for coll in (manifest.nodes, manifest.sources, manifest.metrics, manifest.exposures):
            self._node_index.update(coll)

    @classmethod
    def from_manifest(cls, manifest_path: str | Path) -> "CIImpactService":
        manifest = parse_manifest(manifest_path)
        graph = build_graph(manifest)
        return cls(manifest=manifest, graph=graph)

    def _original_paths_index(self) -> Dict[str, List[str]]:
        """Map normalized original_file_path -> unique_ids (order of iteration)."""
        by_path: Dict[str, List[str]] = {}
        for unique_id, node in self._node_index.items():
            raw = node.original_file_path
            if not raw:
                continue
            key = normalize_rel_path(raw)
            by_path.setdefault(key, []).append(unique_id)
        return by_path

    def resolve_node_ref(self, node_ref: str) -> str:
        """Resolve model/source name or unique_id to ``unique_id`` (same rules as ``PathfinderService``)."""
        ref = node_ref.strip()
        if ref in self.graph:
            return ref
        matches: List[str] = []
        for unique_id, attrs in self.graph.nodes(data=True):
            if attrs.get("name") == ref:
                matches.append(unique_id)
        if not matches:
            raise PathfinderError(f"Node not found: {node_ref}")
        if len(matches) > 1:
            raise PathfinderError(
                f"Ambiguous node name '{node_ref}'. Use unique_id. Matches: {', '.join(sorted(matches))}"
            )
        return matches[0]

    def resolve_changed_files(self, files: list[str]) -> list[str]:
        """Return unique_ids for manifest nodes whose original_file_path matches a given file."""
        index = self._original_paths_index()
        seen: Set[str] = set()
        ordered: List[str] = []
        for f in files:
            key = normalize_rel_path(f)
            for uid in index.get(key, []):
                if uid not in seen:
                    seen.add(uid)
                    ordered.append(uid)
        return ordered

    def get_downstream_impact(self, nodes: list[str]) -> dict[int, list[str]]:
        """
        Shortest-path depth from any root in ``nodes`` to each reachable node.
        Excludes roots and test nodes from the returned depth map (tests are listed separately).
        """
        seeds = [n for n in nodes if n in self.graph]
        if not seeds:
            return {}

        inf = 10**9
        min_depth: Dict[str, int] = {n: inf for n in self.graph}
        queue: deque[str] = deque()
        for s in seeds:
            min_depth[s] = 0
            queue.append(s)

        while queue:
            u = queue.popleft()
            du = min_depth[u]
            for v in self.graph.successors(u):
                cand = du + 1
                if cand < min_depth[v]:
                    min_depth[v] = cand
                    queue.append(v)

        seed_set = set(seeds)
        by_depth: Dict[int, List[str]] = {}
        for node_id, d in min_depth.items():
            if d <= 0 or d >= inf:
                continue
            if node_id in seed_set:
                continue
            meta = self._node_index.get(node_id)
            if meta and meta.resource_type == "test":
                continue
            by_depth.setdefault(d, []).append(node_id)

        return {depth: sorted(ids) for depth, ids in sorted(by_depth.items())}

    def get_impacted_tests(self, anchor_unique_ids: Set[str]) -> list[str]:
        """Tests that are in the anchor set or depend on any non-test node in the anchor set."""
        anchor_models = {
            uid
            for uid in anchor_unique_ids
            if (m := self._node_index.get(uid)) is not None and m.resource_type != "test"
        }
        names: List[str] = []
        seen: Set[str] = set()
        for node in self.manifest.nodes.values():
            if node.resource_type != "test":
                continue
            uid = node.unique_id
            if uid in anchor_unique_ids and uid not in seen:
                seen.add(uid)
                names.append(node.name)
                continue
            deps = node.depends_on.nodes
            if any(d in anchor_models for d in deps):
                if uid not in seen:
                    seen.add(uid)
                    names.append(node.name)
        return sorted(names)

    def _model_sql(self, unique_id: str) -> str:
        node = self._node_index.get(unique_id)
        if not node:
            return ""
        return (node.raw_code or node.compiled_sql or "").strip()

    def _resolve_ref_call(self, expression: str) -> Optional[str]:
        ref_args = re.findall(r"'([^']+)'|\"([^\"]+)\"", expression)
        flat = [a or b for a, b in ref_args]
        if not flat:
            return None
        if len(flat) == 1:
            return self._resolve_model_name(flat[0])
        return self._resolve_model_name(flat[-1])

    def _resolve_model_name(self, name: str) -> Optional[str]:
        matches: List[str] = []
        for uid, attrs in self.graph.nodes(data=True):
            if attrs.get("name") == name:
                matches.append(uid)
        if len(matches) == 1:
            return matches[0]
        return None

    def _resolve_source_call(self, expression: str) -> Optional[str]:
        src_args = re.findall(r"'([^']+)'|\"([^\"]+)\"", expression)
        flat = [a or b for a, b in src_args]
        if len(flat) < 2:
            return None
        source_name = flat[1]
        matches = [
            unique_id
            for unique_id, attrs in self.graph.nodes(data=True)
            if attrs.get("resource_type") == "source" and attrs.get("name") == source_name
        ]
        if len(matches) == 1:
            return matches[0]
        return None

    def _alias_mapping_from_sql(self, sql: str) -> Dict[str, str]:
        alias_map: Dict[str, str] = {}
        pattern = re.compile(
            r"(from|join)\s+\{\{\s*(ref|source)\((?P<expr>[^)]*)\)\s*\}\}\s*(?:as\s+)?(?P<alias>[a-zA-Z_][\w]*)?",
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql):
            call_type = match.group(2).lower()
            expr = match.group("expr")
            alias = match.group("alias")
            resolved = None
            if call_type == "ref":
                resolved = self._resolve_ref_call(expr)
            if call_type == "source":
                resolved = self._resolve_source_call(expr)
            if resolved:
                key = alias if alias else resolved.split(".")[-1]
                alias_map[key] = resolved
        return alias_map

    def _extract_select_items(self, sql: str) -> List[str]:
        m = re.search(r"\bselect\b(?P<body>.*?)\bfrom\b", sql, re.IGNORECASE | re.DOTALL)
        if not m:
            return []
        body = m.group("body")
        out: List[str] = []
        depth = 0
        buf: List[str] = []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth = max(depth - 1, 0)
            if ch == "," and depth == 0:
                item = "".join(buf).strip()
                if item:
                    out.append(item)
                buf = []
            else:
                buf.append(ch)
        tail = "".join(buf).strip()
        if tail:
            out.append(tail)
        return out

    def _output_alias(self, item: str) -> Optional[str]:
        as_m = re.search(r"\bas\s+([a-zA-Z_][\w]*)\s*$", item, re.IGNORECASE)
        if as_m:
            return as_m.group(1)
        trailing = re.search(r"([a-zA-Z_][\w]*)\s*$", item)
        if trailing and "." not in trailing.group(1):
            return trailing.group(1)
        dotted = re.search(r"([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\s*$", item)
        if dotted:
            return dotted.group(2)
        return None

    def _lineage_for_model(self, unique_id: str) -> Dict[str, Set[Tuple[str, str]]]:
        sql = self._model_sql(unique_id)
        if not sql:
            return {}
        alias_map = self._alias_mapping_from_sql(sql)
        items = self._extract_select_items(sql)
        lineage: Dict[str, Set[Tuple[str, str]]] = {}
        for item in items:
            expr = item.strip()
            if not expr:
                continue
            if expr == "*":
                for up_id in alias_map.values():
                    lineage.setdefault("*", set()).add((up_id, "*"))
                continue
            star_m = re.match(r"([a-zA-Z_][\w]*)\.\*$", expr)
            if star_m:
                alias = star_m.group(1)
                up = alias_map.get(alias)
                if up:
                    lineage.setdefault("*", set()).add((up, "*"))
                continue
            out_col = self._output_alias(expr) or "*"
            refs = re.findall(r"([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)", expr)
            for alias, col in refs:
                up = alias_map.get(alias)
                if not up:
                    continue
                lineage.setdefault(out_col, set()).add((up, col))
        return lineage

    def get_downstream_column_impact(
        self,
        changed_unique_ids: List[str],
        impacted_by_depth: Dict[int, List[str]],
    ) -> Dict[int, Dict[str, List[str]]]:
        impacted_columns: Dict[str, Set[str]] = {}
        for uid in changed_unique_ids:
            node = self._node_index.get(uid)
            if not node or node.resource_type != "model":
                continue
            cols = set(node.columns.keys()) if node.columns else {"*"}
            impacted_columns[uid] = cols

        out: Dict[int, Dict[str, List[str]]] = {}
        for depth in sorted(impacted_by_depth.keys()):
            level: Dict[str, List[str]] = {}
            for uid in impacted_by_depth[depth]:
                node = self._node_index.get(uid)
                if not node or node.resource_type != "model":
                    continue
                lineage = self._lineage_for_model(uid)
                impacted_out_cols: Set[str] = set()
                for out_col, refs in lineage.items():
                    for ref_uid, ref_col in refs:
                        ref_imp = impacted_columns.get(ref_uid)
                        if not ref_imp:
                            continue
                        if ref_col == "*" or "*" in ref_imp or ref_col in ref_imp:
                            impacted_out_cols.add(out_col)
                            break
                if impacted_out_cols:
                    if "*" in impacted_out_cols and node.columns:
                        impacted_out_cols = set(node.columns.keys())
                    impacted_columns[uid] = set(impacted_out_cols)
                    level[uid] = sorted(impacted_out_cols)
            if level:
                out[depth] = level
        return out

    def format_node_label(self, unique_id: str) -> str:
        """Short label for CLI text output (not necessarily unique across packages)."""
        node = self._node_index.get(unique_id)
        if not node:
            return unique_id
        if node.resource_type in ("model", "seed", "snapshot", "test"):
            return node.name
        if node.resource_type == "source":
            pkg = node.package_name or ""
            return f"{pkg}.{node.name}" if pkg else node.name
        return node.name or unique_id

    def _selector_token(self, unique_id: str) -> Optional[str]:
        node = self._node_index.get(unique_id)
        if not node:
            return None
        if node.resource_type == "test":
            return None
        if node.resource_type == "model":
            return node.name
        if node.resource_type == "seed":
            return node.name
        if node.resource_type == "snapshot":
            return node.name
        if node.resource_type == "source":
            pkg = node.package_name or ""
            return f"source:{pkg}:{node.name}"
        return node.unique_id

    def _suggested_build_command(self, changed_unique_ids: list[str]) -> str:
        tokens: List[str] = []
        seen_tok: Set[str] = set()
        for uid in changed_unique_ids:
            tok = self._selector_token(uid)
            if not tok:
                continue
            piece = f"{tok}+"
            if piece not in seen_tok:
                seen_tok.add(piece)
                tokens.append(piece)
        if not tokens:
            return "dbt build"
        return "dbt build --select " + " ".join(tokens)

    def suggested_test_command(self, changed_unique_ids: list[str]) -> str:
        tokens: List[str] = []
        seen_tok: Set[str] = set()
        for uid in changed_unique_ids:
            tok = self._selector_token(uid)
            if not tok:
                continue
            piece = f"{tok}+"
            if piece not in seen_tok:
                seen_tok.add(piece)
                tokens.append(piece)
        if not tokens:
            return "dbt test"
        return "dbt test --select " + " ".join(tokens)

    def build_result(
        self,
        files: list[str],
        *,
        include_tests: bool = True,
        include_columns: bool = False,
    ) -> CIImpactResult:
        norm_files = [normalize_rel_path(f) for f in files]
        changed = self.resolve_changed_files(norm_files)
        impacted = self.get_downstream_impact(changed)

        downstream_flat = {uid for ids in impacted.values() for uid in ids}
        anchor = set(changed) | downstream_flat
        tests: List[str] = []
        if include_tests:
            tests = self.get_impacted_tests(anchor)
        column_impact: Dict[int, Dict[str, List[str]]] = {}
        if include_columns:
            column_impact = self.get_downstream_column_impact(changed, impacted)

        short_names = []
        seen_name: Set[str] = set()
        for uid in changed:
            meta = self._node_index.get(uid)
            label = meta.name if meta else uid
            if label not in seen_name:
                seen_name.add(label)
                short_names.append(label)

        return CIImpactResult(
            changed_files=norm_files,
            changed_nodes=short_names,
            impacted_by_depth=impacted,
            column_impact_by_depth=column_impact,
            tests=tests,
            suggested_command=self._suggested_build_command(changed),
        )

    def build_impact_report(
        self,
        *,
        input_mode: Literal["model", "files", "git_diff"],
        model_ref: Optional[str] = None,
        files: Optional[List[str]] = None,
        git_diff_range: Optional[str] = None,
        cwd: Optional[Path] = None,
        include_tests: bool = True,
        include_columns: bool = False,
        git_diff_ignore_globs: Sequence[str] = (),
        git_diff_ignore_prefixes: Sequence[str] = (),
    ) -> ImpactReport:
        """
        Unified impact report. ``input_mode`` is ``model``, ``files``, or ``git_diff``.
        Caller must pass exactly one input shape; validation is done in the CLI layer.
        """
        norm_files: List[str] = []
        changed: List[str] = []
        stored_git_range: Optional[str] = None

        if input_mode == "model":
            if not model_ref or not model_ref.strip():
                raise PathfinderError("--model must be non-empty.")
            uid = self.resolve_node_ref(model_ref)
            changed = [uid]
            meta = self._node_index.get(uid)
            if meta and meta.original_file_path:
                norm_files = [normalize_rel_path(meta.original_file_path)]
        elif input_mode == "files":
            if not files:
                raise PathfinderError("Provide at least one --files path.")
            norm_files = [normalize_rel_path(f) for f in files]
            changed = self.resolve_changed_files(norm_files)
        elif input_mode == "git_diff":
            if not git_diff_range or not git_diff_range.strip():
                raise PathfinderError("--git-diff range must be non-empty.")
            stored_git_range = git_diff_range.strip()
            root = cwd or Path.cwd()
            raw_paths = git_diff_changed_paths(
                stored_git_range,
                cwd=root,
                ignore_globs=git_diff_ignore_globs,
                ignore_prefixes=git_diff_ignore_prefixes,
            )
            norm_files = filter_dbt_paths(raw_paths)
            changed = self.resolve_changed_files(norm_files)
        else:
            raise PathfinderError(f"Invalid input_mode: {input_mode}")

        impacted = self.get_downstream_impact(changed)
        downstream_flat = {uid for ids in impacted.values() for uid in ids}
        anchor = set(changed) | downstream_flat
        tests: List[str] = []
        if include_tests:
            tests = self.get_impacted_tests(anchor)
        column_impact: Dict[int, Dict[str, List[str]]] = {}
        if include_columns:
            column_impact = self.get_downstream_column_impact(changed, impacted)

        short_names: List[str] = []
        seen_name: Set[str] = set()
        for uid in changed:
            m = self._node_index.get(uid)
            label = m.name if m else uid
            if label not in seen_name:
                seen_name.add(label)
                short_names.append(label)

        return ImpactReport(
            input_mode=input_mode,
            git_diff_range=stored_git_range,
            changed_files=norm_files,
            changed_unique_ids=list(changed),
            changed_nodes=short_names,
            impacted_by_depth=impacted,
            column_impact_by_depth=column_impact,
            tests=tests,
            suggested_build_command=self._suggested_build_command(changed),
            suggested_test_command=self.suggested_test_command(changed),
        )
