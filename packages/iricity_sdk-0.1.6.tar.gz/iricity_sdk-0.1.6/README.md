# iricity-sdk

Thin Python client for:
- catalog
- developer purchase orchestration
- API key creation from a session
- quote
- execute
- wait
- provenance-aware settled responses

## Install from repo

```bash
pip install ./apps/sdk-python
```

## Publish-ready install target

```bash
pip install iricity-sdk
```

## Install Verification

```bash
python -m pip install iricity-sdk
python -c "from iricity_sdk import IricityClient; print(IricityClient.__name__)"
```

## Example

```python
from iricity_sdk import IricityClient

client = IricityClient(api_key="your_api_key")

result = client.run(
    "analysis-job",
    {
        "primary": {
            "documentText": "Paste your source text here...",
            "goal": "Summarize key points and actions",
            "audience": "Operations leadership",
        },
        "options": {
            "outputMode": "brief",
            "urgency": "normal",
            "includeArtifacts": False,
        },
    },
    wait=True,
)

print(result)
```

## Developer Bootstrap Flow

Use a session token when you want to orchestrate the compliant purchase/bootstrap path before switching to an API key.

```python
from iricity_sdk import IricityClient

session_client = IricityClient(session_token="your_session_token")

checkout = session_client.create_pack_checkout_intent("starter-api")
print(checkout["orderId"], checkout["paddle"])

# Finish Paddle checkout in the browser, then poll the order:
order = session_client.wait_for_order(checkout["orderId"])
print(order["status"])

created = session_client.create_api_key(label="cli-bootstrap")
print(created["apiKey"]["token"])
```
