# src/workpeg/config.py
import json
from pathlib import Path


DEFAULT_CONFIG = {
    "function": {
        "entrypoint": "app.main:main",
    },
    "runtime": {
        "default": "cracker",
        "docker": {
            "host": "127.0.0.1",
            "port": 8000,
        },
    },
    "build": {
        "image": None,
    },
}


def deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: str = "workpeg.json") -> dict:
    cfg_path = Path(path)
    if not cfg_path.exists():
        return DEFAULT_CONFIG.copy()

    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    return deep_merge(DEFAULT_CONFIG, data)
