# src/workpeg/runtime.py

import importlib
import json
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Dict, Tuple


DEFAULT_ENTRYPOINT = "app.main:main"
DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 8000


class FunctionRuntimeError(Exception):
    pass


def _json_dump(obj: Any) -> str:
    try:
        return json.dumps(obj)
    except TypeError as exc:
        raise FunctionRuntimeError(
            f"Function returned a non-JSON-serializable value: {exc}"
        ) from exc


def parse_entrypoint(entry: str) -> Tuple[str, str]:
    try:
        module_name, func_name = entry.split(":", 1)
        module_name = module_name.strip()
        func_name = func_name.strip()
        if not module_name or not func_name:
            raise ValueError
        return module_name, func_name
    except ValueError:
        raise FunctionRuntimeError(
            f"Invalid FUNCTION_ENTRYPOINT format: '{entry}'. "
            "Expected 'module.path:func_name'."
        )


def _ensure_cwd_on_syspath() -> None:
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)


def load_function(entry: str | None = None):
    _ensure_cwd_on_syspath()

    entry = entry or os.getenv("FUNCTION_ENTRYPOINT", DEFAULT_ENTRYPOINT)
    module_name, func_name = parse_entrypoint(entry)

    importlib.invalidate_caches()

    # Clear module + parent packages from cache
    parts = module_name.split(".")
    for i in range(len(parts), 0, -1):
        candidate = ".".join(parts[:i])
        sys.modules.pop(candidate, None)

    try:
        module = importlib.import_module(module_name)
    except Exception as exc:
        raise FunctionRuntimeError(
            f"Failed to import module '{module_name}' from '{entry}': {exc}"
        ) from exc

    try:
        fn = getattr(module, func_name)
    except AttributeError as exc:
        raise FunctionRuntimeError(
            f"Module '{module_name}' does not define '{func_name}' from '{entry}'."
        ) from exc

    if not callable(fn):
        raise FunctionRuntimeError(
            f"'{entry}' is not callable. Expected a function."
        )

    return fn


def read_request() -> Dict[str, Any]:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise FunctionRuntimeError("No input received on stdin.")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise FunctionRuntimeError("Input JSON must be a JSON object.")
        return data
    except json.JSONDecodeError as exc:
        raise FunctionRuntimeError(f"Invalid JSON input: {exc}") from exc


def invoke_function(
    fn: Callable[[Dict[str, Any], Dict[str, Any]], Any],
    request: Dict[str, Any],
) -> Tuple[Dict[str, Any], int]:
    try:
        context = request.get("context", {})
        payload = request.get("payload", {})

        if not isinstance(context, dict):
            raise FunctionRuntimeError("Field 'context' must be a JSON object.")
        if not isinstance(payload, dict):
            raise FunctionRuntimeError("Field 'payload' must be a JSON object.")

        result = fn(context, payload)
        return {"status": "success", "result": result}, 0

    except FunctionRuntimeError as e:
        return {
            "status": "error",
            "error_type": "runtime_error",
            "error": str(e),
        }, 1

    except Exception as e:
        trace = traceback.format_exc()
        return {
            "status": "error",
            "error_type": "user_error",
            "error": str(e),
            "trace": trace,
        }, 1


def run_once(entrypoint: str | None = None) -> int:
    try:
        fn = load_function(entrypoint)
        request = read_request()

        response, exit_code = invoke_function(fn, request)

        print(_json_dump(response), flush=True)
        return exit_code

    except FunctionRuntimeError as e:
        err_output = {
            "status": "error",
            "error_type": "runtime_error",
            "error": str(e),
        }
        print(_json_dump(err_output), flush=True)
        print(f"[workpeg runtime] runtime_error: {e}", file=sys.stderr)
        return 1

    except Exception as e:
        trace = traceback.format_exc()
        err_output = {
            "status": "error",
            "error_type": "user_error",
            "error": str(e),
            "trace": trace,
        }
        print(_json_dump(err_output), flush=True)
        print(f"[workpeg runtime] user_error: {e}\n{trace}", file=sys.stderr)
        return 1


def serve(host: str = DEFAULT_HOST,
          port: int = DEFAULT_PORT,
          entrypoint: str | None = None) -> None:
    fn = load_function(entrypoint)

    class Handler(BaseHTTPRequestHandler):
        def _send_json(self, status_code: int, payload: Dict[str, Any]) -> None:
            body = _json_dump(payload).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path == "/healthz":
                self._send_json(200, {"status": "ok"})
                return
            self._send_json(404, {"status": "error", "error": "Not found"})

        def do_POST(self) -> None:
            if self.path != "/invoke":
                self._send_json(404, {"status": "error", "error": "Not found"})
                return

            try:
                content_length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(content_length).decode("utf-8")
                request = json.loads(raw)

                if not isinstance(request, dict):
                    raise FunctionRuntimeError("Input JSON must be a JSON object.")

                response, exit_code = invoke_function(fn, request)
                self._send_json(200 if exit_code == 0 else 400, response)

            except json.JSONDecodeError as exc:
                self._send_json(
                    400,
                    {
                        "status": "error",
                        "error_type": "runtime_error",
                        "error": f"Invalid JSON input: {exc}",
                    },
                )
            except Exception as exc:
                self._send_json(
                    500,
                    {
                        "status": "error",
                        "error_type": "runtime_error",
                        "error": str(exc),
                        "trace": traceback.format_exc(),
                    },
                )

        def log_message(self, fmt: str, *args: Any) -> None:
            print(f"[workpeg runtime] {fmt % args}", file=sys.stderr)

    server = ThreadingHTTPServer((host, port), Handler)
    print(f"[workpeg runtime] listening on http://{host}:{port}", file=sys.stderr)
    server.serve_forever()


def main(argv=None) -> None:
    argv = argv or []
    if "--server" in argv:
        serve()
        return

    sys.exit(run_once())
