# src/workpeg/build.py
import subprocess
from pathlib import Path

from workpeg.config import load_config


def slugify(value: str) -> str:
    return value.lower().replace("_", "-").replace(".", "-").replace(" ", "-")


def default_image_name(project_path: Path) -> str:
    project_name = slugify(project_path.resolve().name)
    return f"workpeg-fn-{project_name}"


def build_image(path: str = ".", tag: str | None = None) -> str:
    project_path = Path(path).resolve()
    cfg = load_config(project_path / "workpeg.json")

    image = tag or cfg.get("build", {}).get("image") or default_image_name(project_path)

    try:
        subprocess.run(
            ["docker", "build", "-t", image, str(project_path)],
            check=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(
            "Docker CLI not found. Install Docker or run this command in an environment "
            "where the 'docker' binary is available."
        ) from exc

    return image
