import argparse
import sys

from workpeg import create_new, runtime, submit, build, run

try:
    from importlib.metadata import version
    __version__ = version("workpeg")
except Exception:
    __version__ = "unknown"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="workpeg",
        description="Workpeg CLI",
    )

    # version flag
    p.add_argument(
        "-v", "--version",
        action="version",
        version=f"workpeg {__version__}",
    )

    # IMPORTANT: no required=True
    sub = p.add_subparsers(dest="command")

    # submit
    submit_p = sub.add_parser("submit", help="Submit a function bundle")
    submit_p.add_argument("ref")
    submit_p.add_argument("--api", default=None)
    submit_p.add_argument("--path", default=None)
    submit_p.add_argument("--timeout", type=int, default=None)
    submit_p.set_defaults(_handler="submit")

    # new-function
    new_p = sub.add_parser("new-function", help="Create a new function project from template")
    new_p.add_argument("path")
    new_p.add_argument("--force", action="store_true")
    new_p.set_defaults(_handler="new-function")

    # runtime
    runtime_p = sub.add_parser("runtime", help="Run the function runtime")
    runtime_p.add_argument("--server", action="store_true")
    runtime_p.set_defaults(_handler="runtime")

    # build
    build_p = sub.add_parser("build", help="Build the function docker image")
    build_p.add_argument("--path", default=".")
    build_p.add_argument("--tag", default=None)
    build_p.set_defaults(_handler="build")

    # run
    run_p = sub.add_parser("run", help="Run the function using a configured runtime")
    run_p.add_argument("--with", dest="with_runtime", choices=["docker", "cracker"])
    run_p.add_argument("--path", default=".")
    run_p.add_argument("--no-build", action="store_true")
    run_p.add_argument("--network", default=None)
    run_p.set_defaults(_handler="run")

    return p


def main(argv=None) -> None:
    argv = argv if argv is not None else sys.argv[1:]
    parser = build_parser()

    if not argv:
        parser.print_help()
        return

    args = parser.parse_args(argv)

    if args._handler == "new-function":
        try:
            out = create_new.create_new_project(args.path, force=args.force)
            print(str(out))
        except create_new.TemplateError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            raise SystemExit(2)
        return

    if args._handler == "runtime":
        runtime_argv = []
        if args.server:
            runtime_argv.append("--server")
        runtime.main(runtime_argv)
        return

    if args._handler == "submit":
        submit_argv = [args.ref]
        if args.api:
            submit_argv += ["--api", args.api]
        if args.path:
            submit_argv += ["--path", args.path]
        if args.timeout is not None:
            submit_argv += ["--timeout", str(args.timeout)]
        submit.main(submit_argv)
        return

    if args._handler == "build":
        image = build.build_image(path=args.path, tag=args.tag)
        print(image)
        return

    if args._handler == "run":
        run_argv = []
        if args.with_runtime:
            run_argv += ["--with", args.with_runtime]
        if args.path:
            run_argv += ["--path", args.path]
        if args.no_build:
            run_argv.append("--no-build")
        if args.network:
            run_argv += ["--network", args.network]
        run.main(run_argv)
        return
