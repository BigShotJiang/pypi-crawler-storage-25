# from pathlib import Path

from workpeg import build


def test_slugify():
    assert build.slugify("My_Function.1") == "my-function-1"


def test_default_image_name(tmp_path):
    project = tmp_path / "My Project"
    project.mkdir()
    assert build.default_image_name(project) == "workpeg-fn-my-project"


def test_build_image_uses_default_name(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text("{}")

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(build.subprocess, "run", fake_run)

    image = build.build_image(path=str(project))
    assert image == "workpeg-fn-demo"

    assert len(calls) == 1
    cmd, check = calls[0]
    assert cmd == ["docker", "build", "-t", "workpeg-fn-demo", str(project.resolve())]
    assert check is True


def test_build_image_uses_explicit_tag(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text("{}")

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(build.subprocess, "run", fake_run)

    image = build.build_image(path=str(project), tag="custom-image")
    assert image == "custom-image"

    cmd, check = calls[0]
    assert cmd == ["docker", "build", "-t", "custom-image", str(project.resolve())]
    assert check is True


def test_build_image_uses_config_image(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"build": {"image": "configured-image"}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(build.subprocess, "run", fake_run)

    image = build.build_image(path=str(project))
    assert image == "configured-image"

    cmd, check = calls[0]
    assert cmd == ["docker", "build", "-t", "configured-image", str(project.resolve())]
    assert check is True
