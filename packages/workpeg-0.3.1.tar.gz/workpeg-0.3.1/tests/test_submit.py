import io
import json
import tarfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import workpeg.submit as submit


# ---------- helpers ----------

def make_jwt_with_payload(payload: dict) -> str:
    """
    Create a fake JWT string where payload is base64url encoded.
    Signature doesn't matter because
    decode_jwt_payload_no_verify doesn't verify.
    """
    import base64

    def b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header = {"alg": "HS256", "typ": "JWT"}
    h = b64url(json.dumps(header).encode("utf-8"))
    p = b64url(json.dumps(payload).encode("utf-8"))
    s = "signature"
    return f"{h}.{p}.{s}"


def list_tar_paths(tar_gz_bytes: bytes) -> list[str]:
    with tarfile.open(fileobj=io.BytesIO(tar_gz_bytes), mode="r:gz") as tar:
        return sorted([m.name for m in tar.getmembers()])


# ---------- unit tests: parse_ref ----------

def test_parse_ref_ok():
    fn, ver = submit.parse_ref("fn_echo:1.0.0")
    assert fn == "fn_echo"
    assert ver == "1.0.0"


@pytest.mark.parametrize("ref", ["fn_only", ":", "fn:", ":1.0.0", "  :  "])
def test_parse_ref_invalid(ref):
    with pytest.raises(SystemExit) as e:
        submit.parse_ref(ref)
    assert e.value.code == 2


def test_parse_ref_trims_spaces():
    fn, ver = submit.parse_ref("  fn  :  1.0.0  ")
    assert fn == "fn"
    assert ver == "1.0.0"


def test_decode_jwt_payload_no_verify_ok():
    payload = {"peg_namespace": "peg-123", "exp": 9999999999}
    token = make_jwt_with_payload(payload)
    out = submit.decode_jwt_payload_no_verify(token)
    assert out["peg_namespace"] == "peg-123"


@pytest.mark.parametrize("token", ["", "a.b", "a.b.c.d", "not-a-jwt"])
def test_decode_jwt_payload_no_verify_bad_format(token):
    with pytest.raises(SystemExit) as e:
        submit.decode_jwt_payload_no_verify(token)
    assert e.value.code == 2


def test_decode_jwt_payload_no_verify_bad_base64():
    # middle segment isn't valid base64url json
    token = "a.!@#.c"
    with pytest.raises(SystemExit) as e:
        submit.decode_jwt_payload_no_verify(token)
    assert e.value.code == 2


# ---------- unit tests: build_tar_gz_bytes ----------

def test_build_tar_gz_bytes_includes_files(tmp_path: Path):
    # create sample function project
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "__init__.py").write_text("")
    (tmp_path / "app" / "main.py").write_text(
        "def main(context,payload): return payload\n")
    (tmp_path / "requirements.txt").write_text("workpeg-sdk\n")

    tgz = submit.build_tar_gz_bytes(tmp_path)
    paths = list_tar_paths(tgz)

    # Expect exact files present
    # tar behavior varies (dir entry optional)
    assert "app" in paths or "app/" in paths
    assert "app/__init__.py" in paths
    assert "app/main.py" in paths
    assert "requirements.txt" in paths


def test_build_tar_gz_bytes_excludes_common_junk(tmp_path: Path):
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "main.py").write_text("x=1\n")

    # junk dirs/files
    (tmp_path / ".git").mkdir()
    (tmp_path / ".git" / "config").write_text("nope")

    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "x.pyc").write_bytes(b"\x00\x01")

    (tmp_path / ".pytest_cache").mkdir()
    (tmp_path / ".pytest_cache" / "state").write_text("nope")

    (tmp_path / ".venv").mkdir()
    (tmp_path / ".venv" / "pyvenv.cfg").write_text("nope")

    (tmp_path / "dist").mkdir()
    (tmp_path / "dist" / "wheel.whl").write_text("nope")

    (tmp_path / ".DS_Store").write_text("nope")

    tgz = submit.build_tar_gz_bytes(tmp_path)
    paths = list_tar_paths(tgz)

    # Included
    assert "app/main.py" in paths

    # Excluded
    assert all(not p.startswith(".git/") for p in paths)
    assert all(not p.startswith("__pycache__/") for p in paths)
    assert all(not p.startswith(".pytest_cache/") for p in paths)
    assert all(not p.startswith(".venv/") for p in paths)
    assert all(not p.startswith("dist/") for p in paths)
    assert ".DS_Store" not in paths


def test_build_tar_gz_bytes_bad_path(tmp_path: Path):
    bad = tmp_path / "does-not-exist"
    with pytest.raises(SystemExit) as e:
        submit.build_tar_gz_bytes(bad)
    assert e.value.code == 2


# ---------- unit tests: submit_bundle (requests.post mocked) ----------

@patch("workpeg.submit.requests.post")
def test_submit_bundle_success_builds_request(mock_post):
    mock_resp = MagicMock()
    mock_resp.status_code = 201
    mock_resp.json.return_value = {"ok": True}
    mock_post.return_value = mock_resp

    out = submit.submit_bundle(
        api_base="https://repo.workpeg.com",
        peg_id="peg-123",
        token="jwt-token",
        function_id="fn_echo",
        version="1.0.0",
        bundle_bytes=b"tgz-bytes",
        timeout_s=60,
    )
    assert out == {"ok": True}

    # Verify request shape
    mock_post.assert_called_once()
    args, kwargs = mock_post.call_args

    assert args[0] == "https://repo.workpeg.com/api/pegs/peg-123/functions/"
    assert kwargs["headers"]["Authorization"] == "Bearer jwt-token"
    assert kwargs["data"] == {"function_id": "fn_echo", "version": "1.0.0"}
    assert "files" in kwargs
    file_tuple = kwargs["files"]["bundle"]
    assert file_tuple[0] == "bundle.tar.gz"
    assert file_tuple[1] == b"tgz-bytes"
    assert file_tuple[2] == "application/gzip"
    assert kwargs["timeout"] == 60


@patch("workpeg.submit.requests.post")
def test_submit_bundle_http_error_json(mock_post):
    mock_resp = MagicMock()
    mock_resp.status_code = 409
    mock_resp.json.return_value = {"detail": "Version already exists."}
    mock_post.return_value = mock_resp

    with pytest.raises(SystemExit) as e:
        submit.submit_bundle(
            api_base="https://repo.workpeg.com",
            peg_id="peg-123",
            token="jwt-token",
            function_id="fn_echo",
            version="1.0.0",
            bundle_bytes=b"tgz-bytes",
        )
    assert e.value.code == 1


@patch("workpeg.submit.requests.post")
def test_submit_bundle_http_error_non_json(mock_post):
    mock_resp = MagicMock()
    mock_resp.status_code = 500
    mock_resp.json.side_effect = ValueError("no json")
    mock_resp.text = "server error"
    mock_post.return_value = mock_resp

    with pytest.raises(SystemExit) as e:
        submit.submit_bundle(
            api_base="https://repo.workpeg.com",
            peg_id="peg-123",
            token="jwt-token",
            function_id="fn_echo",
            version="1.0.0",
            bundle_bytes=b"tgz-bytes",
        )
    assert e.value.code == 1


def test_default_api_base_constant():
    assert submit.DEFAULT_API_BASE == "https://repo.workpeg.com"


def test_main_missing_env_token(monkeypatch, capsys):
    monkeypatch.delenv("WORKPEG_PK", raising=False)
    with pytest.raises(SystemExit) as e:
        submit.main(["fn_echo:1.0.0"])
    assert e.value.code == 2
    err = capsys.readouterr().err
    assert "Missing env var WORKPEG_PK" in err


def test_main_jwt_missing_peg_namespace(monkeypatch, capsys):
    token = make_jwt_with_payload({"exp": 9999999999})
    monkeypatch.setenv("WORKPEG_PK", token)

    with pytest.raises(SystemExit) as e:
        submit.main(["fn_echo:1.0.0"])
    assert e.value.code == 2
    assert "JWT missing peg_namespace" in capsys.readouterr().err


@patch("workpeg.submit.submit_bundle")
def test_main_happy_path_uses_default_api_base(
        mock_submit_bundle, monkeypatch, tmp_path, capsys):
    # minimal project
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "main.py").write_text(
        "def main(context,payload): return payload\n")
    (tmp_path / "requirements.txt").write_text("workpeg-sdk\n")

    payload = {"peg_namespace": "peg-123", "exp": 9999999999}
    token = make_jwt_with_payload(payload)

    monkeypatch.setenv("WORKPEG_PK", token)
    monkeypatch.delenv("WORKPEG_API_BASE", raising=False)  # so default is used

    mock_submit_bundle.return_value = {"created": True}

    submit.main(["fn_echo:1.0.0", "--path", str(tmp_path)])

    out = capsys.readouterr().out
    assert '"created": true' in out.lower()

    mock_submit_bundle.assert_called_once()
    _, kwargs = mock_submit_bundle.call_args
    assert kwargs["api_base"] == "https://repo.workpeg.com"
    assert kwargs["peg_id"] == "peg-123"
    assert kwargs["function_id"] == "fn_echo"
    assert kwargs["version"] == "1.0.0"
    assert kwargs["token"] == token
    assert isinstance(kwargs["bundle_bytes"], (bytes, bytearray))
    assert len(kwargs["bundle_bytes"]) > 0


@patch("workpeg.submit.submit_bundle")
def test_main_overrides_api_base_from_env(
        mock_submit_bundle, monkeypatch, tmp_path):
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "main.py").write_text("x=1\n")

    token = make_jwt_with_payload(
        {"peg_namespace": "peg-999", "exp": 9999999999})
    monkeypatch.setenv("WORKPEG_PK", token)
    monkeypatch.setenv("WORKPEG_API_BASE", "https://staging.repo.workpeg.com")

    mock_submit_bundle.return_value = {"ok": 1}

    submit.main(["fn_echo:1.0.0", "--path", str(tmp_path)])

    _, kwargs = mock_submit_bundle.call_args
    assert kwargs["api_base"] == "https://staging.repo.workpeg.com"
    assert kwargs["peg_id"] == "peg-999"


@patch("workpeg.submit.submit_bundle")
def test_main_overrides_api_base_from_flag(
        mock_submit_bundle, monkeypatch, tmp_path):
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "main.py").write_text("x=1\n")

    token = make_jwt_with_payload(
        {"peg_namespace": "peg-111", "exp": 9999999999})
    monkeypatch.setenv("WORKPEG_PK", token)
    monkeypatch.setenv("WORKPEG_API_BASE", "https://env.repo.workpeg.com")

    mock_submit_bundle.return_value = {"ok": 1}

    submit.main(["fn_echo:1.0.0", "--path", str(tmp_path),
                "--api", "https://flag.repo.workpeg.com"])

    _, kwargs = mock_submit_bundle.call_args
    assert kwargs["api_base"] == "https://flag.repo.workpeg.com"
