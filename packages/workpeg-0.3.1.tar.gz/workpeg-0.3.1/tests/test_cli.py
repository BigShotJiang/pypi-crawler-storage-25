import pytest

from workpeg import cli


def test_cli_no_args_prints_help(monkeypatch, capsys):
    cli.main([])

    captured = capsys.readouterr()
    assert "usage: workpeg" in captured.out


def test_cli_version_long(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main(["--version"])

    assert exc.value.code == 0
    captured = capsys.readouterr()
    assert captured.out.strip().startswith("workpeg ")


def test_cli_version_short(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main(["-v"])

    assert exc.value.code == 0
    captured = capsys.readouterr()
    assert captured.out.strip().startswith("workpeg ")


def test_cli_new_function_success(monkeypatch, capsys):
    monkeypatch.setattr(
        cli.create_new,
        "create_new_project",
        lambda path, force=False: "/tmp/output",
    )

    cli.main(["new-function", "foo"])

    out = capsys.readouterr().out.strip()
    assert out == "/tmp/output"


def test_cli_new_function_template_error(monkeypatch, capsys):
    def fake_create(path, force=False):
        raise cli.create_new.TemplateError("boom")

    monkeypatch.setattr(cli.create_new, "create_new_project", fake_create)

    with pytest.raises(SystemExit) as exc:
        cli.main(["new-function", "foo"])

    assert exc.value.code == 2
    err = capsys.readouterr().err
    assert "ERROR: boom" in err


def test_cli_runtime_default(monkeypatch):
    called = {}

    def fake_runtime_main(argv):
        called["argv"] = argv

    monkeypatch.setattr(cli.runtime, "main", fake_runtime_main)

    cli.main(["runtime"])
    assert called["argv"] == []


def test_cli_runtime_server(monkeypatch):
    called = {}

    def fake_runtime_main(argv):
        called["argv"] = argv

    monkeypatch.setattr(cli.runtime, "main", fake_runtime_main)

    cli.main(["runtime", "--server"])
    assert called["argv"] == ["--server"]


def test_cli_submit(monkeypatch):
    called = {}

    def fake_submit_main(argv):
        called["argv"] = argv

    monkeypatch.setattr(cli.submit, "main", fake_submit_main)

    cli.main([
        "submit",
        "fn_echo:1.0.0",
        "--api", "https://repo.workpeg.com",
        "--path", "/tmp/demo",
        "--timeout", "30",
    ])

    assert called["argv"] == [
        "fn_echo:1.0.0",
        "--api", "https://repo.workpeg.com",
        "--path", "/tmp/demo",
        "--timeout", "30",
    ]


def test_cli_build(monkeypatch, capsys):
    monkeypatch.setattr(
        cli.build,
        "build_image",
        lambda path=".", tag=None: "built-image",
    )

    cli.main(["build"])

    out = capsys.readouterr().out.strip()
    assert out == "built-image"


def test_cli_build_with_args(monkeypatch, capsys):
    called = {}

    def fake_build_image(path=".", tag=None):
        called["path"] = path
        called["tag"] = tag
        return "custom-image"

    monkeypatch.setattr(cli.build, "build_image", fake_build_image)

    cli.main(["build", "--path", "/tmp/demo", "--tag", "custom-image"])

    assert called == {"path": "/tmp/demo", "tag": "custom-image"}
    out = capsys.readouterr().out.strip()
    assert out == "custom-image"


def test_cli_run(monkeypatch):
    called = {}

    def fake_run_main(argv):
        called["argv"] = argv

    monkeypatch.setattr(cli.run, "main", fake_run_main)

    cli.main([
        "run",
        "--with", "docker",
        "--path", "/tmp/demo",
        "--no-build",
        "--network", "workpeg_net",
    ])

    assert called["argv"] == [
        "--with", "docker",
        "--path", "/tmp/demo",
        "--no-build",
        "--network", "workpeg_net",
    ]
