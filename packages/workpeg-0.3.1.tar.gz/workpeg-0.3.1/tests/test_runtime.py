import json
# import sys
# from pathlib import Path

import pytest

from workpeg import runtime


def test_parse_entrypoint_ok():
    assert runtime.parse_entrypoint("app.main:main") == ("app.main", "main")


@pytest.mark.parametrize(
    "entry",
    ["", "app.main", ":", "app.main:", ":main"],
)
def test_parse_entrypoint_invalid(entry):
    with pytest.raises(runtime.FunctionRuntimeError):
        runtime.parse_entrypoint(entry)


def test_ensure_cwd_on_syspath(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(runtime.sys, "path", ["/some/other/path"])
    runtime._ensure_cwd_on_syspath()
    assert runtime.sys.path[0] == str(tmp_path)


def test_load_function_default_entrypoint(monkeypatch, tmp_path):
    app_dir = tmp_path / "app"
    app_dir.mkdir()
    (app_dir / "__init__.py").write_text("")
    (app_dir / "main.py").write_text(
        "def main(context, payload):\n"
        "    return {'ok': True, 'payload': payload}\n"
    )

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    fn = runtime.load_function()
    result = fn({}, {"x": 1})
    assert result == {"ok": True, "payload": {"x": 1}}


def test_load_function_from_env_entrypoint(monkeypatch, tmp_path):
    app_dir = tmp_path / "app"
    app_dir.mkdir()
    (app_dir / "__init__.py").write_text("")
    (app_dir / "main.py").write_text(
        "def handler(context, payload):\n"
        "    return {'message': 'hello'}\n"
    )

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("FUNCTION_ENTRYPOINT", "app.main:handler")

    fn = runtime.load_function()
    assert fn({}, {}) == {"message": "hello"}


def test_load_function_import_error(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("FUNCTION_ENTRYPOINT", "missing.module:main")

    with pytest.raises(runtime.FunctionRuntimeError) as exc:
        runtime.load_function()

    assert "Failed to import module" in str(exc.value)


def test_load_function_missing_attr(monkeypatch, tmp_path):
    app_dir = tmp_path / "app"
    app_dir.mkdir()
    (app_dir / "__init__.py").write_text("")
    (app_dir / "main.py").write_text("x = 1\n")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("FUNCTION_ENTRYPOINT", "app.main:main")

    with pytest.raises(runtime.FunctionRuntimeError) as exc:
        runtime.load_function()

    assert "does not define" in str(exc.value)


def test_json_dump_non_serializable():
    with pytest.raises(runtime.FunctionRuntimeError):
        runtime._json_dump({"bad": {1, 2, 3}})


def test_read_request_ok(monkeypatch):
    monkeypatch.setattr(runtime.sys, "stdin", type(
        "S", (), {"read": lambda self: '{"context": {}, "payload": {}}'})())
    assert runtime.read_request() == {"context": {}, "payload": {}}


def test_read_request_empty(monkeypatch):
    monkeypatch.setattr(runtime.sys, "stdin", type("S", (), {"read": lambda self: "   "})())
    with pytest.raises(runtime.FunctionRuntimeError) as exc:
        runtime.read_request()
    assert "No input received on stdin" in str(exc.value)


def test_read_request_invalid_json(monkeypatch):
    monkeypatch.setattr(runtime.sys, "stdin", type("S", (), {"read": lambda self: '{"bad"'})())
    with pytest.raises(runtime.FunctionRuntimeError) as exc:
        runtime.read_request()
    assert "Invalid JSON input" in str(exc.value)


def test_read_request_not_object(monkeypatch):
    monkeypatch.setattr(runtime.sys, "stdin", type("S", (), {"read": lambda self: '["x"]'})())
    with pytest.raises(runtime.FunctionRuntimeError) as exc:
        runtime.read_request()
    assert "must be a JSON object" in str(exc.value)


def test_invoke_function_success():
    def fn(context, payload):
        return {"echo": payload}

    response, exit_code = runtime.invoke_function(fn, {"context": {}, "payload": {"x": 1}})
    assert exit_code == 0
    assert response == {"status": "success", "result": {"echo": {"x": 1}}}


def test_invoke_function_bad_context():
    def fn(context, payload):
        return payload

    response, exit_code = runtime.invoke_function(fn, {"context": "bad", "payload": {}})
    assert exit_code == 1
    assert response["status"] == "error"
    assert response["error_type"] == "runtime_error"


def test_invoke_function_user_error():
    def fn(context, payload):
        raise ValueError("boom")

    response, exit_code = runtime.invoke_function(fn, {"context": {}, "payload": {}})
    assert exit_code == 1
    assert response["status"] == "error"
    assert response["error_type"] == "user_error"
    assert response["error"] == "boom"
    assert "ValueError: boom" in response["trace"]


def test_run_once_success(monkeypatch, capsys):
    def fake_load_function(entrypoint=None):
        return lambda context, payload: {"hello": payload["name"]}

    def fake_read_request():
        return {"context": {}, "payload": {"name": "world"}}

    monkeypatch.setattr(runtime, "load_function", fake_load_function)
    monkeypatch.setattr(runtime, "read_request", fake_read_request)

    exit_code = runtime.run_once()
    captured = capsys.readouterr()

    assert exit_code == 0
    data = json.loads(captured.out)
    assert data == {"status": "success", "result": {"hello": "world"}}


def test_run_once_runtime_error(monkeypatch, capsys):
    def fake_load_function(entrypoint=None):
        raise runtime.FunctionRuntimeError("bad runtime")

    monkeypatch.setattr(runtime, "load_function", fake_load_function)

    exit_code = runtime.run_once()
    captured = capsys.readouterr()

    assert exit_code == 1
    data = json.loads(captured.out)
    assert data["error_type"] == "runtime_error"
    assert data["error"] == "bad runtime"


def test_main_default_exits(monkeypatch):
    monkeypatch.setattr(runtime, "run_once", lambda: 0)

    with pytest.raises(SystemExit) as exc:
        runtime.main([])

    assert exc.value.code == 0


def test_main_server_mode(monkeypatch):
    called = {}

    def fake_serve(host=runtime.DEFAULT_HOST, port=runtime.DEFAULT_PORT, entrypoint=None):
        called["host"] = host
        called["port"] = port
        called["entrypoint"] = entrypoint

    monkeypatch.setattr(runtime, "serve", fake_serve)

    runtime.main(["--server"])
    assert called == {
        "host": runtime.DEFAULT_HOST,
        "port": runtime.DEFAULT_PORT,
        "entrypoint": None,
    }
