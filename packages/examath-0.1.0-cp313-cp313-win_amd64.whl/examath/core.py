
def dividers(n: int) -> tuple[int]:
	"""Returns a tuple of dividers of a given number with a performance of O(√n)."""
	result = []
	i = 1
	while i*i < n:
		if n%i == 0:
			result.append(i)
			result.append(n//i)
		i+=1
	return tuple(result)


# def factor(n: int) -> tuple[int]:
# 	"""
# 	Renvoie une liste de la décomposition
# 	en facteurs premiers d'une nombre
# 	donné n.
# 	"""
# 	result = []
# 	for prime in imath.get_primes():
# 		while n%prime == 0:
# 			result.append(prime)
# 			n //= prime
# 			if n == 1:
# 				return tuple(result)
# 	raise Exception("Your number was too big and we could'nt decompose it.")
