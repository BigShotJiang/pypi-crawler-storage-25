"""HTTP client for the AIVibe API — independent copy for the MCP server."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

import httpx

from aivibe_mcp import __version__

CONFIG_FILE = Path.home() / ".aivibe" / "config.json"
DEFAULT_API_URL = "https://app.aivibe.so"


def _load_config() -> dict[str, str]:
    """Load config from ~/.aivibe/config.json or env vars."""
    # Env vars take precedence (for Claude Desktop inline config)
    api_key = os.environ.get("AIVIBE_API_KEY")
    api_url = os.environ.get("AIVIBE_API_URL")
    if api_key:
        return {"api_key": api_key, "api_url": api_url or DEFAULT_API_URL}

    # Fall back to config file (shared with CLI)
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())  # type: ignore[no-any-return]

    return {}


def api_get(path: str, params: dict[str, Any] | None = None) -> str:
    """Make a GET request and return JSON as a string for MCP tool responses."""
    config = _load_config()
    api_key = config.get("api_key")
    if not api_key:
        return json.dumps({"error": "No API key configured. Run 'aivibe setup' or set AIVIBE_API_KEY."})

    api_url = config.get("api_url", DEFAULT_API_URL)

    with httpx.Client(
        base_url=api_url,
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    ) as client:
        response = client.get(path, params=params)

    # Check for CLI/MCP version enforcement
    min_version = response.headers.get("x-cli-min-version")
    if min_version and _version_lt(__version__, min_version):
        return json.dumps({
            "error": "mcp_outdated",
            "current": __version__,
            "required": min_version,
            "upgrade_command": "pipx upgrade aivibe-mcp",
        })

    if response.status_code == 401:
        return json.dumps({"error": "Invalid, expired, or revoked API key."})
    if response.status_code == 429:
        return json.dumps({"error": "Rate limit exceeded. Wait a moment and retry."})
    if response.status_code >= 400:
        return json.dumps({"error": f"API returned {response.status_code}"})

    return json.dumps(response.json(), indent=2, default=str)


def api_post(path: str, body: dict[str, Any] | None = None) -> str:
    """Make a POST request and return JSON as a string for MCP tool responses."""
    config = _load_config()
    api_key = config.get("api_key")
    if not api_key:
        return json.dumps({"error": "No API key configured. Run 'aivibe setup' or set AIVIBE_API_KEY."})

    api_url = config.get("api_url", DEFAULT_API_URL)

    with httpx.Client(
        base_url=api_url,
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    ) as client:
        response = client.post(path, json=body)

    min_version = response.headers.get("x-cli-min-version")
    if min_version and _version_lt(__version__, min_version):
        return json.dumps({
            "error": "mcp_outdated",
            "current": __version__,
            "required": min_version,
            "upgrade_command": "pipx upgrade aivibe-mcp",
        })

    if response.status_code == 401:
        return json.dumps({"error": "Invalid, expired, or revoked API key."})
    if response.status_code == 429:
        return json.dumps({"error": "Rate limit exceeded. Wait a moment and retry."})
    if response.status_code >= 400:
        return json.dumps({"error": f"API returned {response.status_code}"})

    return json.dumps(response.json(), indent=2, default=str)


def _version_lt(current: str, minimum: str) -> bool:
    """Compare semver strings."""
    def _parts(v: str) -> tuple[int, ...]:
        return tuple(int(x) for x in v.split("."))
    return _parts(current) < _parts(minimum)
