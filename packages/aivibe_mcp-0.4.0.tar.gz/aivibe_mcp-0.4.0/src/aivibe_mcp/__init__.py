"""AIVibe MCP server — read-only access to platform data for Claude Desktop and Cowork."""

__version__ = "0.4.0"
