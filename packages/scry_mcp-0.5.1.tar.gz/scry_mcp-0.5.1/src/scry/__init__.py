"""scry — marker-indexed SQL cache MCP server."""

__version__ = "0.5.1"
