import typing as t
import asyncio

from .calculated_value import CalculatedValue, gcv
from .calculated_fields import CalculatedFields
from .interpolation_field import InterpolationField
from .stopwatch import Stopwatch, stopwatch
from .avg import Avg
from .flag import Flag

from .. import hints


if t.TYPE_CHECKING:

    @t.overload
    def coalapse[T](
        *items: T | None,
        exception: hints.exception.ex | None = None,
    ) -> T: ...

    @t.overload
    def coalapse[T, TD](
        *items: T | None,
        default: TD,
    ) -> T | TD: ...


def coalapse(
    *items: t.Any | None,
    **kw: t.Any,
) -> t.Any:
    for item in items:
        if item is not None:
            return item

    if 'default' in kw:
        return kw['default']

    if (ex := hints.exception.get_exception(kw.get('exception'))) is not None:
        raise ex

    raise ValueError()


if t.TYPE_CHECKING:

    @t.overload
    def coalapse_lazy[T](
        *items: CalculatedValue[T | None] | T | None,
        exception: hints.exception.ex | None = None,
    ) -> T: ...

    @t.overload
    def coalapse_lazy[T, TD](
        *items: CalculatedValue[T | None] | T | None,
        default: TD,
    ) -> T | TD: ...


def coalapse_lazy(
    *items: CalculatedValue[t.Any] | t.Any | None,
    **kw: t.Any,
) -> t.Any:
    for item in items:
        if (value := gcv(item)) is not None:
            return value

    if 'default' in kw:
        return kw['default']

    if (ex := hints.exception.get_exception(kw.get('exception'))) is not None:
        raise ex

    raise ValueError()


async def invoke[**P, R](
    func: t.Callable[P, R | t.Coroutine[R, t.Any, t.Any]],
    *args: P.args,
    **kwargs: P.kwargs,
) -> R:
    if asyncio.iscoroutine(result := func(*args, **kwargs)):
        return await result
    return result


def partition[T](
    predicate: t.Callable[[T], bool] | None,
    iterable: t.Iterable[T],
) -> tuple[list[T], list[T]]:
    '''
    return: trues, falses
    '''

    trues: list[T] = []
    falses: list[T] = []

    for item in iterable:
        if item is not None if predicate is None else predicate(item):
            trues.append(item)
        else:
            falses.append(item)

    return trues, falses
