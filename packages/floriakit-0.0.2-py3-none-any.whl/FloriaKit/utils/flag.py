import typing as t


class Flag:
    __slots__ = ('_depth',)

    """
    Управляемый флаг с поддержкой контекстного менеджера.

    Предоставляет механизм временного установления флага с
    автоматическим сбросом при выходе из контекста.

    Пример:

    ```python

        flag = Flag()

        ...

        with flag:
            # Флаг установлен в True
            ...

        # Флаг автоматически сброшен в False

        ...

        if flag:
            raise Exception(...)
    ```
    """

    def __init__(self):
        self._depth: int = 0

    def __enter__(self, *args: t.Any, **kwargs: t.Any):
        self._depth += 1

    def __exit__(self, *args: t.Any, **kwargs: t.Any):
        self._depth -= 1

    @property
    def value(self) -> bool:
        """Текущее состояние флага"""
        return self._depth > 0

    def __bool__(self) -> bool:
        """Возвращает текущее состояние флага для использования в условиях"""
        return self.value
