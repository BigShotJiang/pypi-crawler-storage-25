import typing as t

from .. import hints


def raiser(ex: hints.exception.ex) -> t.NoReturn:
    raise hints.exception.get_exception(ex)


if t.TYPE_CHECKING:

    @t.overload
    def not_none[T](
        value: T | None,
        *,
        exception: hints.exception.ex | None = None,
    ) -> T: ...

    @t.overload
    def not_none[T, TD](
        value: T | None,
        *,
        default: TD = None,
    ) -> T | TD: ...


def not_none(value: t.Any, **kw):
    if value is not None:
        return value

    if 'default' in kw:
        return kw['default']

    raiser(kw.get('exception', ValueError('Value is None')))


if t.TYPE_CHECKING:

    @t.overload
    def is_instance[T](
        value: t.Any,
        type_: t.Type[T],
        *,
        exception: hints.exception.ex | None = None,
    ) -> T: ...

    @t.overload
    def is_instance[T, TD](
        value: t.Any,
        type_: t.Type[T],
        *,
        default: TD = None,
    ) -> T | TD: ...


def is_instance(value: t.Any, type_: t.Type[t.Any], **kw):
    if isinstance(value, type_):
        return value

    if 'default' in kw:
        return kw['default']

    raiser(
        kw.get(
            'exception',
            ValueError(f'Value is not instance of {type_.__name__}'),
        )
    )
