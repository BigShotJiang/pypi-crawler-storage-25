import typing as t

from .common import number


vec2 = tuple[number, number]
vec3 = tuple[number, number, number]
vec4 = tuple[number, number, number, number]
