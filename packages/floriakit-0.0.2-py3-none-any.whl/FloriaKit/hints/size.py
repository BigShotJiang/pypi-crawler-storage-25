import typing as t

from .common import number


size2 = tuple[number, number]
size2i = tuple[float, float]
size2f = tuple[int, int]


size3 = tuple[number, number, number]
size3i = tuple[float, float, float]
size3f = tuple[int, int, int]
