import typing as t

number = int | float
