import typing as t

from .common import number


pos2 = tuple[number, number]
pos2i = tuple[float, float]
pos2f = tuple[int, int]


pos3 = tuple[number, number, number]
pos3i = tuple[float, float, float]
pos3f = tuple[int, int, int]
