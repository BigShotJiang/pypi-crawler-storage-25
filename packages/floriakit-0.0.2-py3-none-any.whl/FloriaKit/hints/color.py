import typing as t

from .common import number


rgb = tuple[number, number, number]
rgba = tuple[number, number, number, number]


def get_rgba(color: rgb | rgba) -> rgba:
    match len(color):
        case 3:
            return (*color, 255)  # pyright: ignore[reportReturnType]

        case 4:
            return color  # pyright: ignore[reportReturnType]

        case _:
            raise


def get_rgb(color: rgb | rgba) -> rgb:
    match len(color):
        case 3:
            return color  # pyright: ignore[reportReturnType]

        case 4:
            return color[:3]

        case _:
            raise
