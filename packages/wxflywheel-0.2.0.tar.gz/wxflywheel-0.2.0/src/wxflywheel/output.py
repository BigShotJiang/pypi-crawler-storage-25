from __future__ import annotations

import json
from functools import wraps
from typing import Any, Callable, TypeVar

import click

from wxflywheel.exceptions import SUCCESS_CODE, WxflywheelError

JsonObject = dict[str, Any]
F = TypeVar("F", bound=Callable[..., JsonObject])


def success_payload(data: Any, message: str = "") -> JsonObject:
    return {"code": SUCCESS_CODE, "data": data, "message": message}


def error_payload(code: int, message: str, data: Any = None) -> JsonObject:
    return {"code": code, "data": data, "message": message}


def emit_payload(payload: JsonObject, *, err: bool = False) -> None:
    click.echo(json.dumps(payload, ensure_ascii=False, indent=2), err=err)


def emit_error_payload(code: int, message: str, data: Any = None, *, err: bool = True) -> None:
    emit_payload(error_payload(code, message, data), err=err)


def emit_error(error: WxflywheelError) -> None:
    emit_error_payload(error.code, error.message, error.data)
    raise SystemExit(1)


def json_command(func: F) -> F:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> None:
        try:
            payload = func(*args, **kwargs)
        except WxflywheelError as error:
            emit_error(error)
        else:
            emit_payload(payload)

    return wrapper  # type: ignore[return-value]
