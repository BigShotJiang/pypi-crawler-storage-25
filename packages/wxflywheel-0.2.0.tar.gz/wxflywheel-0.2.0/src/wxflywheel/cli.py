from __future__ import annotations

from collections.abc import Sequence

import click

from wxflywheel.commands.login import login
from wxflywheel.commands.related import related
from wxflywheel.commands.search import search
from wxflywheel.commands.wxindex import wxindex
from wxflywheel.config import DEFAULT_HOST, RuntimeContext
from wxflywheel.output import emit_error_payload


@click.group(name="wxflywheel", invoke_without_command=True)
@click.option(
    "--key",
    envvar="WXFLYWHEEL_KEY",
    default=None,
    help="API key (or set WXFLYWHEEL_KEY).",
)
@click.option(
    "--host",
    envvar="WXFLYWHEEL_HOST",
    default=DEFAULT_HOST,
    show_default=True,
    help="Service base URL (or set WXFLYWHEEL_HOST).",
)
@click.pass_context
def cli(ctx: click.Context, key: str | None, host: str) -> None:
    """wxflywheel CLI."""
    ctx.obj = RuntimeContext.from_values(key=key, host=host)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


cli.add_command(login)
cli.add_command(related)
cli.add_command(search)
cli.add_command(wxindex)


def main(argv: Sequence[str] | None = None) -> int:
    try:
        cli.main(args=list(argv) if argv is not None else None, standalone_mode=False)
    except SystemExit as exit_error:
        exit_code = exit_error.code
        if exit_code is None:
            return 0
        if isinstance(exit_code, int):
            return exit_code
        emit_error_payload(1, str(exit_code))
        return 1
    except click.ClickException as error:
        emit_error_payload(error.exit_code, error.format_message())
        return error.exit_code
    except click.Abort:
        emit_error_payload(1, "Aborted!")
        return 1
    except click.exceptions.Exit as exit_error:
        return exit_error.exit_code
    return 0
