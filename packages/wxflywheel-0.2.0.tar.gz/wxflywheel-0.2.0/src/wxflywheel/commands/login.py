from __future__ import annotations

import click

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command


@click.group()
def login() -> None:
    """Login commands."""


@login.command()
@click.pass_obj
@json_command
def status(runtime: RuntimeContext) -> JsonObject:
    """Read the current login status."""
    client = require_client(runtime)
    return client.get("/v1/login/GetLoginStatus", autoLogin="false")
