from __future__ import annotations

import click

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group()
def search() -> None:
    """Search commands."""


@search.command()
@click.option("--seed", required=True, help="Seed keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, seed: str) -> JsonObject:
    """Aggregate related keywords for a seed term."""
    client = require_client(runtime)
    payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": seed})
    words = payload["data"]["words"]
    return success_payload({"seed": seed, "related": words}, payload["message"])
