from __future__ import annotations

from urllib.parse import quote

import click

from wxflywheel.commands.common import normalize_string_list, require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group()
def wxindex() -> None:
    """WxIndex commands."""


@wxindex.command()
@click.option("--keyword", required=True, help="WxIndex keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, keyword: str) -> JsonObject:
    """Get related keywords from WxIndex."""
    client = require_client(runtime)
    payload = client.get(f"/api/wxindexsug/{quote(keyword, safe='')}")
    words = normalize_string_list(payload["data"])
    return success_payload({"keyword": keyword, "related": words}, payload["message"])
