from __future__ import annotations

from urllib.parse import quote

import click

from wxflywheel.commands.common import normalize_string_list, require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group()
def related() -> None:
    """Cross-source related keyword commands."""


def _deduplicate_preserving_order(words: list[str]) -> list[str]:
    seen: set[str] = set()
    deduplicated: list[str] = []
    for word in words:
        if word in seen:
            continue
        seen.add(word)
        deduplicated.append(word)
    return deduplicated


@related.command()
@click.option("--keyword", "--seed", "keyword", required=True, help="Keyword to aggregate.")
@click.pass_obj
@json_command
def aggregate(runtime: RuntimeContext, keyword: str) -> JsonObject:
    """Aggregate related keywords from Search and WxIndex."""
    client = require_client(runtime)

    search_words: list[str] = []
    wxindex_words: list[str] = []
    errors: dict[str, dict[str, int | str]] = {}
    search_ok = False
    wxindex_ok = False

    try:
        payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": keyword})
        search_ok = True
        raw_words = (
            payload["data"].get("words") if isinstance(payload["data"], dict) else None
        )
        search_words = _deduplicate_preserving_order(normalize_string_list(raw_words))
    except WxflywheelError as error:
        errors["search"] = {"code": error.code, "message": error.message}

    try:
        payload = client.get(f"/api/wxindexsug/{quote(keyword, safe='')}")
        wxindex_ok = True
        wxindex_words = _deduplicate_preserving_order(
            normalize_string_list(payload["data"])
        )
    except WxflywheelError as error:
        errors["wxindex"] = {"code": error.code, "message": error.message}

    if not search_ok and not wxindex_ok:
        first_error = next(iter(errors.values()))
        raise WxflywheelError(
            int(first_error["code"]),
            "Both related keyword sources failed.",
            errors,
        )

    wxindex_set = set(wxindex_words)
    search_set = set(search_words)

    both = [w for w in search_words if w in wxindex_set]
    search_only = [w for w in search_words if w not in wxindex_set]
    wxindex_only = [w for w in wxindex_words if w not in search_set]

    return success_payload({
        "keyword": keyword,
        "related": both + search_only + wxindex_only,
        "from_search": search_words,
        "from_wxindex": wxindex_words,
        "both_sources": both,
        "search_only": search_only,
        "wxindex_only": wxindex_only,
        "errors": errors,
    })
