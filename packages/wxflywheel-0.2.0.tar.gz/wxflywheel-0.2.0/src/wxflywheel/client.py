from __future__ import annotations

from typing import Any

import requests
import requests.exceptions

from wxflywheel.exceptions import NETWORK_ERROR_CODE, SUCCESS_CODE, WxflywheelError
from wxflywheel.output import success_payload


class WxflywheelClient:
    def __init__(self, key: str, host: str):
        self.key = key.strip()
        self.host = host.strip().rstrip("/")

    def get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._request("GET", path, params=params, timeout=30)
        return self._handle_json_response(resp)

    def post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        resp = self._request("POST", path, body=body, timeout=30)
        return self._handle_json_response(resp)

    def raw_get(
        self, path: str, timeout: tuple[float, float | None] = (10, 300), **params: Any
    ) -> requests.Response:
        return self._request("GET", path, params=params, timeout=timeout, stream=True)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        timeout: int | tuple[float, float | None],
        stream: bool = False,
    ) -> requests.Response:
        try:
            return requests.request(
                method,
                f"{self.host}{path}",
                params={"key": self.key, **(params or {})},
                json=body,
                timeout=timeout,
                stream=stream,
            )
        except requests.exceptions.RequestException as exc:
            raise WxflywheelError(NETWORK_ERROR_CODE, str(exc)) from exc

    def _handle_json_response(self, resp: requests.Response) -> dict[str, Any]:
        try:
            data = resp.json()
        except ValueError as exc:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is not JSON (HTTP {resp.status_code}): {resp.text[:200]}",
            ) from exc

        if not isinstance(data, dict):
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is not a JSON object (HTTP {resp.status_code}): {resp.text[:200]}",
            )

        code = self._extract_code(data)
        payload_data = data["data"] if "data" in data else data.get("Data")
        message = self._extract_message(data)

        if code != SUCCESS_CODE:
            raise WxflywheelError(code, message, payload_data)

        return success_payload(payload_data, message)

    @staticmethod
    def _extract_code(data: dict[str, Any]) -> int:
        raw_code = data["code"] if "code" in data else data.get("Code")
        if raw_code is None:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is missing code/Code field: {data}",
            )
        try:
            return int(float(raw_code))
        except (TypeError, ValueError) as exc:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response code is not numeric: {raw_code!r}",
            ) from exc

    @staticmethod
    def _extract_message(data: dict[str, Any]) -> str:
        raw_message = data["message"] if "message" in data else data.get("Text")
        if isinstance(raw_message, str):
            return raw_message
        if raw_message is None:
            return ""
        return str(raw_message)
