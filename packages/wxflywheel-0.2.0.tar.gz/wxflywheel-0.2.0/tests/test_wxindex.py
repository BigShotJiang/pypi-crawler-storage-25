import json
from unittest.mock import patch

from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def test_wxindex_related_outputs_keyword_and_words_on_success(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": ["社群运营", "私域运营", "社群营销"],
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["keyword"] == "社群"
    assert data["data"]["related"] == ["社群运营", "私域运营", "社群营销"]


def test_wxindex_related_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": [], "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_get:
        runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群 运营"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/api/wxindexsug/%E7%A4%BE%E7%BE%A4%20%E8%BF%90%E8%90%A5"
    assert called_params["key"] == "test-key"


def test_wxindex_related_api_error_exits_1(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 300, "data": None, "message": "获取凭证失败"}),
    ):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "获取凭证失败" in err_data["message"]


def test_wxindex_related_normalizes_null_data_to_empty_list(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": None, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["data"]["keyword"] == "社群"
    assert data["data"]["related"] == []


def test_wxindex_related_filters_non_string_items(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": ["社群运营", 1, None], "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["data"]["related"] == ["社群运营"]
