import json
from unittest.mock import patch

import click
import pytest
from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli, main


def test_root_help_does_not_require_key() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, [], env={"WXFLYWHEEL_KEY": ""})
    assert result.exit_code == 0
    assert "Usage:" in result.output
    assert result.stderr == ""


def test_subcommand_help_does_not_require_key() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["login", "--help"], env={"WXFLYWHEEL_KEY": ""})
    assert result.exit_code == 0
    assert "status" in result.output
    assert result.stderr == ""


def test_missing_key_exits_1_with_json_stderr() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["login", "status"], env={"WXFLYWHEEL_KEY": ""})
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -1
    assert "WXFLYWHEEL_KEY" in err_data["message"]
    assert err_data["data"] is None


def test_whitespace_only_key_exits_1() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--key", "   ", "login", "status"])
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -1


def test_host_env_var_passed_to_client(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"loginState": 1}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_get:
        result = runner.invoke(
            cli,
            ["login", "status"],
            env={"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://custom-host:9999"},
        )
    assert result.exit_code == 0
    called_url = mock_get.call_args.args[1]
    assert called_url.startswith("http://custom-host:9999")


def test_main_returns_zero_for_help(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--help"]) == 0
    captured = capsys.readouterr()
    assert "Usage:" in captured.out
    assert captured.err == ""


def test_main_returns_json_for_root_click_parse_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["--bad-option"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "No such option" in err_data["message"]
    assert captured.out == ""


def test_main_returns_json_for_subcommand_click_parse_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["login", "status", "--bad-option"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "No such option" in err_data["message"]
    assert captured.out == ""


def test_main_returns_runtime_exit_code_from_command(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["login", "status"]) == 1
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == -1
    assert "WXFLYWHEEL_KEY" in err_data["message"]
    assert captured.out == ""


def test_main_normalizes_abort_to_json(capsys: pytest.CaptureFixture[str]) -> None:
    with patch("wxflywheel.cli.cli.main", side_effect=click.Abort()):
        assert main([]) == 1
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 1
    assert err_data["message"] == "Aborted!"


def test_main_normalizes_non_integer_system_exit_to_json(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with patch("wxflywheel.cli.cli.main", side_effect=SystemExit("boom")):
        assert main([]) == 1
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 1
    assert err_data["message"] == "boom"
    assert captured.out == ""


def test_main_treats_none_system_exit_as_success(capsys: pytest.CaptureFixture[str]) -> None:
    with patch("wxflywheel.cli.cli.main", side_effect=SystemExit(None)):
        assert main([]) == 0
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


def test_main_returns_click_exit_code() -> None:
    with patch("wxflywheel.cli.cli.main", side_effect=click.exceptions.Exit(3)):
        assert main([]) == 3
