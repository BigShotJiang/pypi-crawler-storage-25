from unittest.mock import MagicMock, patch

import pytest
import requests

from tests.conftest import MockRespFactory
from wxflywheel.client import WxflywheelClient
from wxflywheel.exceptions import WxflywheelError

# ── 成功路径 ──────────────────────────────────────────────────────────────


def test_get_normalizes_uppercase_success_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"Code": 200, "Data": {"items": []}, "Text": ""}),
    ) as mock_get:
        result = client.get("/api/test", keyword="hello")
    mock_get.assert_called_once_with(
        "GET",
        "http://localhost:8011/api/test",
        params={"key": "test-key", "keyword": "hello"},
        json=None,
        timeout=30,
        stream=False,
    )
    assert result == {"code": 200, "data": {"items": []}, "message": ""}


def test_get_normalizes_lowercase_success_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"items": []}, "message": ""}),
    ):
        result = client.get("/api/test")
    assert result == {"code": 200, "data": {"items": []}, "message": ""}


def test_post_returns_standard_payload_on_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {}, "message": ""}),
    ) as mock_post:
        result = client.post("/v1/test/Action", {"Field": "value"})
    mock_post.assert_called_once_with(
        "POST",
        "http://localhost:8011/v1/test/Action",
        params={"key": "test-key"},
        json={"Field": "value"},
        timeout=30,
        stream=False,
    )
    assert result["code"] == 200


def test_host_trailing_slash_stripped(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011/")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {}, "message": ""}),
    ) as mock_get:
        client.get("/api/test")
    called_url = mock_get.call_args.args[1]
    assert called_url == "http://localhost:8011/api/test"


# ── 错误路径 ──────────────────────────────────────────────────────────────


def test_get_raises_wxflywheel_error_on_network_error() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.ConnectionError("refused"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "refused" in exc_info.value.message
    assert exc_info.value.data is None


def test_get_raises_on_non_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": 300, "Data": None, "Text": "账号掉线"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 300
    assert exc_info.value.message == "账号掉线"
    assert exc_info.value.data is None


def test_handle_raises_on_lowercase_error_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"code": 1402, "message": "unauthorized"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 1402
    assert "unauthorized" in exc_info.value.message


def test_handle_raises_on_missing_code_field(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"error": "unexpected"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "missing code/Code" in exc_info.value.message


def test_handle_accepts_numeric_string_code(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": "300", "Text": "error msg"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 300


def test_handle_raises_on_invalid_string_code(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": "N/A", "Text": "error"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "not numeric" in exc_info.value.message


def test_handle_raises_on_non_json_response() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    bad_resp = MagicMock()
    bad_resp.status_code = 502
    bad_resp.text = "<html>Bad Gateway</html>"
    bad_resp.json.side_effect = ValueError("not json")
    with (
        patch("wxflywheel.client.requests.request", return_value=bad_resp),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "502" in exc_info.value.message or "Bad Gateway" in exc_info.value.message


def test_raw_get_returns_response() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_resp = MagicMock()
    fake_resp.status_code = 200
    with patch("wxflywheel.client.requests.request", return_value=fake_resp) as mock_get:
        result = client.raw_get("/api/stream", extra_param="val")
    mock_get.assert_called_once_with(
        "GET",
        "http://localhost:8011/api/stream",
        params={"key": "test-key", "extra_param": "val"},
        json=None,
        timeout=(10, 300),
        stream=True,
    )
    assert result is fake_resp


def test_raw_get_raises_on_network_error() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.Timeout("timed out"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.raw_get("/api/stream")
    assert exc_info.value.code == -999
    assert "timed out" in exc_info.value.message


def test_post_raises_on_network_error() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.ConnectionError("refused"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.post("/v1/test/Action", {"Field": "val"})
    assert exc_info.value.code == -999
    assert "refused" in exc_info.value.message


def test_handle_raises_on_non_dict_json_response() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    list_resp = MagicMock()
    list_resp.status_code = 200
    list_resp.text = "[1, 2, 3]"
    list_resp.json.return_value = [1, 2, 3]
    with (
        patch("wxflywheel.client.requests.request", return_value=list_resp),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "not a JSON object" in exc_info.value.message


def test_post_raises_on_non_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": 403, "Data": None, "Text": "forbidden"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.post("/v1/test/Action", {"Field": "val"})
    assert exc_info.value.code == 403
    assert "forbidden" in exc_info.value.message
    assert exc_info.value.data is None


def test_handle_ignores_http_status_code_when_body_code_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    resp = mock_resp({"Code": 200, "Data": {"loginState": 1}, "Text": ""}, status=500)
    with patch("wxflywheel.client.requests.request", return_value=resp):
        result = client.get("/api/test")
    assert result["code"] == 200
    assert result["data"]["loginState"] == 1


def test_handle_prefers_lowercase_fields_when_both_are_present(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(
            {
                "Code": 200,
                "code": 200,
                "Data": {"old": True},
                "data": {"new": True},
                "message": "ok",
            }
        ),
    ):
        result = client.get("/api/test")
    assert result["data"] == {"new": True}
    assert result["message"] == "ok"


def test_handle_normalizes_missing_message_to_empty_string(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"ok": True}}),
    ):
        result = client.get("/api/test")
    assert result["message"] == ""


def test_handle_stringifies_non_string_message(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"ok": True}, "message": False}),
    ):
        result = client.get("/api/test")
    assert result["message"] == "False"


def test_raw_get_custom_timeout_is_passed_through() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    fake_resp = MagicMock()
    with patch("wxflywheel.client.requests.request", return_value=fake_resp) as mock_get:
        client.raw_get("/api/stream", timeout=(5, 600))
    _, kwargs = mock_get.call_args
    assert kwargs["timeout"] == (5, 600)
    assert kwargs["stream"] is True
