import json
from unittest.mock import patch

from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def test_login_status_outputs_json_on_success(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"loginState": 1, "wxId": "wxid_test"}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["login", "status"], env=ENV)
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["loginState"] == 1


def test_login_status_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_get:
        runner.invoke(cli, ["login", "status"], env=ENV)
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/v1/login/GetLoginStatus"
    assert called_params["key"] == "test-key"
    assert called_params.get("autoLogin") == "false"


def test_login_status_api_error_exits_1(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 300, "data": None, "message": "账号掉线"}),
    ):
        result = runner.invoke(cli, ["login", "status"], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "账号掉线" in err_data["message"]
