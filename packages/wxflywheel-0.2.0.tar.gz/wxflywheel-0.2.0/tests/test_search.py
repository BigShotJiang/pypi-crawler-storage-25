import json
from unittest.mock import patch

from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def test_search_related_outputs_seed_and_words_on_success(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {"words": ["社群营销怎么做", "社群活跃技巧", "社群变现"]},
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["seed"] == "社群运营"
    assert data["data"]["related"] == ["社群营销怎么做", "社群活跃技巧", "社群变现"]


def test_search_related_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"words": []}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    called_url = mock_post.call_args.args[1]
    called_params = mock_post.call_args.kwargs["params"]
    called_json = mock_post.call_args.kwargs["json"]
    assert called_url == "http://localhost:8011/v1/Finder/RelatedKeywords"
    assert called_params["key"] == "test-key"
    assert called_json == {"KeyWord": "社群运营"}


def test_search_related_api_error_exits_1(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 300, "data": None, "message": "关键词不能为空"}),
    ):
        result = runner.invoke(cli, ["search", "related", "--seed", ""], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "关键词不能为空" in err_data["message"]
