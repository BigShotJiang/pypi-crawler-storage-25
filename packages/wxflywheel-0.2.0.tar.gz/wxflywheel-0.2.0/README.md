# wxflywheel

Python CLI for wx-ipad automation.

## Install

Requirement: Python 3.10+

Published package:

```bash
pip install wxflywheel
```

Local development:

```bash
cd cli
make install-dev
```

## Authentication

```bash
export WXFLYWHEEL_KEY=your-api-key
export WXFLYWHEEL_HOST=http://host:8011
```

`WXFLYWHEEL_KEY` is required for API commands. Help output never requires a key.

## Usage

```bash
wxflywheel --help
wxflywheel login --help
wxflywheel login status
wxflywheel related aggregate --keyword "社群运营"
wxflywheel search related --seed "社群运营"
wxflywheel wxindex related --keyword "社群运营"
python -m wxflywheel login status
```

## Current Command Surface

Curated commands are intentionally published one by one. The current public command surface is:

- `wxflywheel login status`
- `wxflywheel related aggregate --keyword "<关键词>"`
- `wxflywheel search related --seed "<种子词>"`
- `wxflywheel wxindex related --keyword "<关键词>"`

## Output Contract

Command execution emits JSON. Help output remains plain text.

- Success: stdout, exit code `0`
- Command/runtime errors: stderr, exit code `1`
- Click argument errors: stderr, exit code `2`

Schema:

```json
{
  "code": 200,
  "data": {},
  "message": ""
}
```

## Adding a Command Module

Curated commands are intentionally added one by one. Do not expose a backend route directly just because it exists.

Minimum standard for a new curated command:

- One command maps to one stable user intent.
- Read-only commands are preferred by default.
- State-changing behavior must be explicit in the command name or behind an opt-in flag.
- Output must stay on the standard `code/data/message` schema.
- Command logic must use shared helpers from [src/wxflywheel/commands/common.py](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/src/wxflywheel/commands/common.py).
- Every new command must ship with tests before registration.

Workflow:

1. Copy [src/wxflywheel/commands/_template.py](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/src/wxflywheel/commands/_template.py).
2. Replace module/action names and API parameters.
3. Add focused tests under [tests](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/tests).
4. Register the command in [src/wxflywheel/cli.py](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/src/wxflywheel/cli.py).
5. Run the release checks before merging.

## Release Checks

Repeatable release verification now lives in [Makefile](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/Makefile):

```bash
make release-check
```

This runs:

- `ruff`
- `mypy`
- `pytest`
- wheel/sdist build
- `twine check`
- editable-command help smoke
- built-wheel install smoke
- package rebuild from a clean `dist/` / `build/` state

The built package ships `py.typed`, so installed type checkers can treat `wxflywheel` as a typed package.

Optional live smoke against a real service:

```bash
export WXFLYWHEEL_HOST=http://host:8011
export WXFLYWHEEL_KEY=your-api-key
make smoke-live
```

## Development

```bash
make install-dev
make release-check
```

## Release Management

- Package changelog: [CHANGELOG.md](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/CHANGELOG.md)
- Release procedure: [RELEASE.md](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/cli/RELEASE.md)
- GitHub Actions:
  - [wxflywheel-ci.yml](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/.github/workflows/wxflywheel-ci.yml)
  - [wxflywheel-release.yml](/Users/wangyiyang/Documents/jianguoyun/我的坚果云/code/ipad/.github/workflows/wxflywheel-release.yml)
