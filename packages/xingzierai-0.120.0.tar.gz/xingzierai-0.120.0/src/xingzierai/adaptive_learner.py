#!/usr/bin/env python3
"""
AdaptiveLearner - 自适应学习器

根据历史数据自动优化路由策略：
1. 收集用户反馈
2. 追踪模型性能
3. 分析路由效果
4. 自动优化规则
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class FeedbackType(str, Enum):
    """反馈类型"""
    POSITIVE = "positive"   # 用户满意
    NEGATIVE = "negative"   # 用户不满意
    NEUTRAL = "neutral"     # 中立


class ModelPerformance(Enum):
    """模型性能评级"""
    EXCELLENT = "excellent"  # 优秀
    GOOD = "good"           # 良好
    AVERAGE = "average"     # 一般
    POOR = "poor"           # 较差


@dataclass
class UserFeedback:
    """用户反馈"""
    id: str
    prompt: str
    response: str
    model_used: str
    feedback: FeedbackType
    timestamp: datetime
    rating: int = 0  # 0-5 星


@dataclass
class ModelMetrics:
    """模型指标"""
    model_name: str
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    avg_latency_ms: float = 0.0
    total_latency_ms: float = 0.0
    avg_quality_score: float = 0.0
    total_quality_score: float = 0.0
    positive_feedback_count: int = 0
    negative_feedback_count: int = 0
    last_updated: Optional[datetime] = None


@dataclass
class RoutingAnalytics:
    """路由分析数据"""
    total_requests: int = 0
    local_model_calls: int = 0
    cloud_model_calls: int = 0
    concurrent_calls: int = 0
    success_rate: float = 0.0
    avg_local_latency_ms: float = 0.0
    avg_cloud_latency_ms: float = 0.0
    cost_savings: float = 0.0
    user_satisfaction: float = 0.0


class FeedbackCollector:
    """
    反馈收集器
    
    收集用户对模型回答的反馈，用于后续分析。
    """

    MAX_FEEDBACK = 1000
    TRUNCATE_TO = 500

    def __init__(self, storage_path: Optional[str] = None):
        if storage_path is None:
            storage_path = Path.home() / ".xingzierai" / "feedback.json"
        
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.feedback_list: List[UserFeedback] = []
        self._save_count = 0
        self._save_threshold = 5
        self._load_feedback()

    def _load_feedback(self):
        try:
            if self.storage_path.exists():
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item in data:
                        self.feedback_list.append(UserFeedback(
                            id=item['id'],
                            prompt=item['prompt'],
                            response=item['response'],
                            model_used=item['model_used'],
                            feedback=FeedbackType(item['feedback']),
                            timestamp=datetime.fromisoformat(item['timestamp']),
                            rating=item.get('rating', 0)
                        ))
                    if len(self.feedback_list) > self.MAX_FEEDBACK:
                        self.feedback_list = self.feedback_list[-self.TRUNCATE_TO:]
        except Exception as e:
            logger.warning(f"Failed to load feedback: %s", e)
            self.feedback_list = []

    def _save_feedback(self):
        try:
            data = []
            for fb in self.feedback_list:
                data.append({
                    'id': fb.id,
                    'prompt': fb.prompt,
                    'response': fb.response,
                    'model_used': fb.model_used,
                    'feedback': fb.feedback.value,
                    'timestamp': fb.timestamp.isoformat(),
                    'rating': fb.rating
                })
            
            tmp = Path(str(self.storage_path) + ".tmp")
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            tmp.replace(self.storage_path)
        except Exception as e:
            logger.warning(f"Failed to save feedback: %s", e)
        finally:
            if len(self.feedback_list) > self.MAX_FEEDBACK:
                self.feedback_list = self.feedback_list[-self.TRUNCATE_TO:]

    def add_feedback(
        self,
        prompt: str,
        response: str,
        model_used: str,
        feedback: FeedbackType,
        rating: int = 0,
    ) -> UserFeedback:
        """
        添加用户反馈
        
        Args:
            prompt: 用户问题
            response: 模型回答
            model_used: 使用的模型
            feedback: 反馈类型
            rating: 评分 (0-5)
            
        Returns:
            UserFeedback: 创建的反馈对象
        """
        import uuid
        
        fb = UserFeedback(
            id=str(uuid.uuid4()),
            prompt=prompt,
            response=response,
            model_used=model_used,
            feedback=feedback,
            timestamp=datetime.now(),
            rating=rating
        )
        
        self.feedback_list.append(fb)
        self._save_count += 1
        if self._save_count >= self._save_threshold:
            self._save_count = 0
            self._save_feedback()
        
        logger.info(f"Added feedback: {feedback.value} for model {model_used}")
        return fb

    def get_feedback_for_model(self, model_name: str) -> List[UserFeedback]:
        """获取指定模型的反馈"""
        return [fb for fb in self.feedback_list if fb.model_used == model_name]

    def get_recent_feedback(self, hours: int = 24) -> List[UserFeedback]:
        """获取最近 N 小时的反馈"""
        cutoff = datetime.now() - timedelta(hours=hours)
        return [fb for fb in self.feedback_list if fb.timestamp > cutoff]

    def get_satisfaction_rate(self, hours: int = 24) -> float:
        """获取用户满意度"""
        recent = self.get_recent_feedback(hours)
        if not recent:
            return 0.0
        
        positive = sum(1 for fb in recent if fb.feedback == FeedbackType.POSITIVE)
        return positive / len(recent)


class PerformanceTracker:
    """
    性能追踪器
    
    追踪各模型的性能指标。
    """

    _PERSIST_PATH = Path.home() / ".xingzierai" / "performance_metrics.json"
    MAX_METRICS = 200
    MAX_CALL_COUNT = 100000
    PERSIST_INTERVAL = 10

    def __init__(self):
        self.model_metrics: Dict[str, ModelMetrics] = {}
        self._op_count = 0
        self._load()

    def _load(self) -> None:
        if not self._PERSIST_PATH.exists():
            return
        try:
            data = json.loads(self._PERSIST_PATH.read_text(encoding="utf-8"))
            for item in data.get("metrics", []):
                name = item.get("model_name", "")
                if not name:
                    continue
                metrics = ModelMetrics(
                    model_name=name,
                    total_calls=item.get("total_calls", 0),
                    successful_calls=item.get("successful_calls", 0),
                    failed_calls=item.get("failed_calls", 0),
                    avg_latency_ms=item.get("avg_latency_ms", 0.0),
                    total_latency_ms=item.get("total_latency_ms", 0.0),
                    avg_quality_score=item.get("avg_quality_score", 0.0),
                    total_quality_score=item.get("total_quality_score", 0.0),
                    positive_feedback_count=item.get("positive_feedback_count", 0),
                    negative_feedback_count=item.get("negative_feedback_count", 0),
                    last_updated=datetime.fromisoformat(item["last_updated"]) if item.get("last_updated") else None,
                )
                self.model_metrics[name] = metrics
            logger.info(f"PerformanceTracker loaded {len(self.model_metrics)} model metrics from disk")
        except Exception as e:
            logger.warning(f"PerformanceTracker failed to load: {e}")

    def _persist(self) -> None:
        try:
            self._PERSIST_PATH.parent.mkdir(parents=True, exist_ok=True)
            items = []
            for m in list(self.model_metrics.values())[-self.MAX_METRICS:]:
                items.append({
                    "model_name": m.model_name,
                    "total_calls": m.total_calls,
                    "successful_calls": m.successful_calls,
                    "failed_calls": m.failed_calls,
                    "avg_latency_ms": m.avg_latency_ms,
                    "total_latency_ms": m.total_latency_ms,
                    "avg_quality_score": m.avg_quality_score,
                    "total_quality_score": m.total_quality_score,
                    "positive_feedback_count": m.positive_feedback_count,
                    "negative_feedback_count": m.negative_feedback_count,
                    "last_updated": m.last_updated.isoformat() if m.last_updated else None,
                })
            tmp = self._PERSIST_PATH.with_suffix(".json.tmp")
            tmp.write_text(
                json.dumps({"metrics": items}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            tmp.replace(self._PERSIST_PATH)
        except Exception as e:
            logger.warning(f"PerformanceTracker failed to persist: {e}")

    def record_call(
        self,
        model_name: str,
        success: bool,
        latency_ms: float,
        quality_score: float = 0.0,
    ):
        """
        记录模型调用
        
        Args:
            model_name: 模型名称
            success: 是否成功
            latency_ms: 延迟（毫秒）
            quality_score: 质量评分 (0-1)
        """
        if model_name not in self.model_metrics:
            if len(self.model_metrics) >= self.MAX_METRICS:
                oldest = min(self.model_metrics.items(), key=lambda x: x[1].last_updated or datetime.min)
                del self.model_metrics[oldest[0]]
            self.model_metrics[model_name] = ModelMetrics(model_name=model_name)

        metrics = self.model_metrics[model_name]
        metrics.total_calls = min(metrics.total_calls + 1, self.MAX_CALL_COUNT)
        
        if success:
            metrics.successful_calls = min(metrics.successful_calls + 1, self.MAX_CALL_COUNT)
            metrics.total_latency_ms += latency_ms
            metrics.avg_latency_ms = metrics.total_latency_ms / max(metrics.successful_calls, 1)
            
            metrics.total_quality_score += quality_score
            metrics.avg_quality_score = metrics.total_quality_score / max(metrics.successful_calls, 1)
        else:
            metrics.failed_calls = min(metrics.failed_calls + 1, self.MAX_CALL_COUNT)
        
        metrics.last_updated = datetime.now()
        self._op_count += 1
        if self._op_count >= self.PERSIST_INTERVAL:
            self._op_count = 0
            self._persist()

    def get_metrics(self, model_name: str) -> Optional[ModelMetrics]:
        """获取模型指标"""
        return self.model_metrics.get(model_name)

    def get_all_metrics(self) -> Dict[str, ModelMetrics]:
        """获取所有模型指标"""
        return self.model_metrics

    def get_performance_rating(self, model_name: str) -> ModelPerformance:
        """获取模型性能评级"""
        metrics = self.get_metrics(model_name)
        if not metrics or metrics.total_calls == 0:
            return ModelPerformance.AVERAGE
        
        success_rate = metrics.successful_calls / metrics.total_calls
        
        if success_rate >= 0.95 and metrics.avg_quality_score >= 0.8:
            return ModelPerformance.EXCELLENT
        elif success_rate >= 0.9 and metrics.avg_quality_score >= 0.6:
            return ModelPerformance.GOOD
        elif success_rate >= 0.8:
            return ModelPerformance.AVERAGE
        else:
            return ModelPerformance.POOR


class RuleOptimizer:
    """
    规则优化器
    
    根据分析结果自动优化路由规则。
    """

    def __init__(self):
        """初始化规则优化器"""
        self.min_confidence_threshold = 0.6
        self.quality_threshold = 0.5

    def analyze_and_suggest(
        self,
        feedback_collector: FeedbackCollector,
        performance_tracker: PerformanceTracker,
    ) -> Dict[str, Any]:
        """
        分析并给出优化建议
        
        Args:
            feedback_collector: 反馈收集器
            performance_tracker: 性能追踪器
            
        Returns:
            Dict: 优化建议
        """
        suggestions = {
            "model_adjustments": [],
            "rule_modifications": [],
            "warnings": []
        }

        # 分析模型性能
        for model_name, metrics in performance_tracker.get_all_metrics().items():
            rating = performance_tracker.get_performance_rating(model_name)
            
            if rating == ModelPerformance.POOR:
                suggestions["warnings"].append(
                    f"模型 {model_name} 性能较差，成功率仅 "
                    f"{metrics.successful_calls/metrics.total_calls*100:.1f}%"
                )
                suggestions["model_adjustments"].append({
                    "model": model_name,
                    "action": "降低优先级",
                    "reason": "性能较差"
                })
            
            elif rating == ModelPerformance.EXCELLENT:
                suggestions["model_adjustments"].append({
                    "model": model_name,
                    "action": "提高优先级",
                    "reason": "性能优秀"
                })

        # 分析用户满意度
        satisfaction = feedback_collector.get_satisfaction_rate(hours=24)
        if satisfaction < 0.6:
            suggestions["warnings"].append(
                f"用户满意度较低: {satisfaction*100:.1f}%"
            )

        # 分析响应时间
        for model_name, metrics in performance_tracker.get_all_metrics().items():
            if model_name == "local" and metrics.avg_latency_ms > 5000:
                suggestions["warnings"].append(
                    f"本地模型响应时间过长: {metrics.avg_latency_ms/1000:.1f}秒"
                )

        return suggestions

    def should_auto_adjust(
        self,
        model_name: str,
        performance_tracker: PerformanceTracker,
        consecutive_failures: int = 3,
    ) -> bool:
        """
        判断是否应该自动调整模型优先级
        
        Args:
            model_name: 模型名称
            performance_tracker: 性能追踪器
            consecutive_failures: 连续失败次数阈值
            
        Returns:
            bool: 是否应该调整
        """
        metrics = performance_tracker.get_metrics(model_name)
        if not metrics:
            return False
        
        # 如果连续失败次数超过阈值
        if metrics.failed_calls >= consecutive_failures:
            return True
        
        # 如果成功率太低
        if metrics.total_calls > 10:
            success_rate = metrics.successful_calls / metrics.total_calls
            if success_rate < 0.7:
                return True
        
        return False


class AdaptiveLearner:
    """
    自适应学习器 - 专注于模型路由优化

    复用 data_flywheel 的交互数据和反馈数据，
    在此基础上叠加模型路由特定的分析。
    """

    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化自适应学习器

        Args:
            storage_path: 反馈数据存储路径（兼容旧数据）
        """
        self.feedback_collector = FeedbackCollector(storage_path)
        self.performance_tracker = PerformanceTracker()
        self.rule_optimizer = RuleOptimizer()

        self._flywheel = None
        self._flywheel_imported = False

        logger.info("AdaptiveLearner: 初始化完成")

    def _get_flywheel(self):
        """Lazy import data_flywheel to avoid circular imports."""
        if not self._flywheel_imported:
            try:
                from .data_flywheel import get_data_flywheel
                self._flywheel = get_data_flywheel()
            except ImportError:
                self._flywheel = None
            self._flywheel_imported = True
        return self._flywheel

    def record_interaction(
        self,
        prompt: str,
        response: str,
        model_used: str,
        success: bool,
        latency_ms: float,
        quality_score: float = 0.0,
    ):
        """
        记录一次交互 - 同时记录到 data_flywheel
        """
        self.performance_tracker.record_call(
            model_name=model_used,
            success=success,
            latency_ms=latency_ms,
            quality_score=quality_score
        )

        flywheel = self._get_flywheel()
        if flywheel:
            from .data_flywheel import InteractionType
            try:
                flywheel.record_interaction(
                    interaction_type=InteractionType.CHAT,
                    agent_name="router",
                    user_input=prompt[:500],
                    system_output=response[:500],
                    model_used=model_used,
                    latency_ms=latency_ms,
                    success=success,
                )
            except Exception as e:
                logger.debug(f"Flywheel recording skipped: {e}")

    def record_feedback(
        self,
        prompt: str,
        response: str,
        model_used: str,
        feedback: FeedbackType,
        rating: int = 0,
    ):
        """
        记录用户反馈 - 同时记录到 data_flywheel
        """
        self.feedback_collector.add_feedback(
            prompt=prompt,
            response=response,
            model_used=model_used,
            feedback=feedback,
            rating=rating
        )

        flywheel = self._get_flywheel()
        if flywheel:
            try:
                flywheel.submit_feedback(
                    interaction_id=f"adaptive_{model_used}_{int(datetime.now().timestamp())}",
                    rating=rating if rating > 0 else (5 if feedback == FeedbackType.POSITIVE else 2),
                    feedback_text=f"model={model_used}, feedback={feedback.value}",
                    tags=[f"model:{model_used}", feedback.value],
                )
            except Exception as e:
                logger.debug(f"Flywheel feedback skipped: {e}")

    def get_routing_analytics(self) -> RoutingAnalytics:
        """
        获取路由分析数据
        
        Returns:
            RoutingAnalytics: 路由分析数据
        """
        analytics = RoutingAnalytics()
        
        # 从性能追踪器获取数据
        all_metrics = self.performance_tracker.get_all_metrics()
        
        for model_name, metrics in all_metrics.items():
            analytics.total_requests += metrics.total_calls
            
            if "local" in model_name.lower() or "ollama" in model_name.lower():
                analytics.local_model_calls += metrics.total_calls
                if metrics.successful_calls > 0:
                    analytics.avg_local_latency_ms = (
                        metrics.avg_latency_ms * 0.5 + 
                        analytics.avg_local_latency_ms * 0.5
                    )
            else:
                analytics.cloud_model_calls += metrics.total_calls
                if metrics.successful_calls > 0:
                    analytics.avg_cloud_latency_ms = (
                        metrics.avg_latency_ms * 0.5 + 
                        analytics.avg_cloud_latency_ms * 0.5
                    )
        
        # 计算成功率
        if analytics.total_requests > 0:
            total_success = sum(
                m.successful_calls for m in all_metrics.values()
            )
            analytics.success_rate = total_success / analytics.total_requests
        
        # 估算节省成本（假设云端每次调用 $0.01，本地免费）
        analytics.cost_savings = analytics.local_model_calls * 0.01
        
        # 用户满意度
        analytics.user_satisfaction = self.feedback_collector.get_satisfaction_rate()
        
        return analytics

    def get_optimization_suggestions(self) -> Dict[str, Any]:
        """
        获取优化建议
        
        Returns:
            Dict: 优化建议
        """
        return self.rule_optimizer.analyze_and_suggest(
            self.feedback_collector,
            self.performance_tracker
        )

    def should_switch_model(
        self,
        current_model: str,
        consecutive_failures: int = 3,
    ) -> bool:
        """
        判断是否应该切换模型
        
        Args:
            current_model: 当前模型
            consecutive_failures: 连续失败次数阈值
            
        Returns:
            bool: 是否应该切换
        """
        return self.rule_optimizer.should_auto_adjust(
            current_model,
            self.performance_tracker,
            consecutive_failures
        )


# 全局单例
_learner: Optional[AdaptiveLearner] = None


def get_adaptive_learner() -> AdaptiveLearner:
    """获取全局自适应学习器实例"""
    global _learner
    if _learner is None:
        _learner = AdaptiveLearner()
    return _learner


__all__ = [
    "AdaptiveLearner",
    "FeedbackCollector",
    "PerformanceTracker",
    "RuleOptimizer",
    "FeedbackType",
    "ModelPerformance",
    "UserFeedback",
    "ModelMetrics",
    "RoutingAnalytics",
    "get_adaptive_learner",
]
