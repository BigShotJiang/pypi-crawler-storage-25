# -*- coding: utf-8 -*-
"""A2A Protocol Data Types."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class A2AMessageType(str, Enum):
    """A2A Message Types."""
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    TASK_RESULT = "task_result"
    HEARTBEAT = "heartbeat"
    AGENT_DISCOVER = "agent_discover"
    AGENT_REGISTER = "agent_register"
    AGENT_UNREGISTER = "agent_unregister"
    ERROR = "error"


class A2ATaskStatus(str, Enum):
    """A2A Task Status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


@dataclass
class A2AAgentInfo:
    """Information about an agent in the A2A network."""
    agent_id: str
    name: str
    description: str = ""
    capabilities: List[str] = field(default_factory=list)
    endpoint: str = ""
    version: str = "1.0.0"
    status: str = "online"
    metadata: Dict[str, Any] = field(default_factory=dict)
    registered_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "description": self.description,
            "capabilities": self.capabilities,
            "endpoint": self.endpoint,
            "version": self.version,
            "status": self.status,
            "metadata": self.metadata,
            "registered_at": self.registered_at.isoformat(),
        }


@dataclass
class A2AMessage:
    """A2A Message structure."""
    id: str
    type: A2AMessageType
    sender: str
    receiver: Optional[str] = None
    session_id: Optional[str] = None
    content: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    correlation_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "sender": self.sender,
            "receiver": self.receiver,
            "session_id": self.session_id,
            "content": self.content,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
            "correlation_id": self.correlation_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "A2AMessage":
        return cls(
            id=data["id"],
            type=A2AMessageType(data["type"]),
            sender=data["sender"],
            receiver=data.get("receiver"),
            session_id=data.get("session_id"),
            content=data.get("content"),
            metadata=data.get("metadata", {}),
            timestamp=datetime.fromisoformat(data["timestamp"]) if data.get("timestamp") else datetime.now(),
            correlation_id=data.get("correlation_id"),
        )


@dataclass
class A2ATask:
    """A2A Task structure."""
    id: str
    agent_id: str
    description: str
    input_data: Any = None
    status: A2ATaskStatus = A2ATaskStatus.PENDING
    priority: int = 0
    timeout: int = 300
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "agent_id": self.agent_id,
            "description": self.description,
            "input_data": self.input_data,
            "status": self.status.value,
            "priority": self.priority,
            "timeout": self.timeout,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "metadata": self.metadata,
        }


@dataclass
class A2ATaskResult:
    """A2A Task Result structure."""
    task_id: str
    status: A2ATaskStatus
    output: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    artifacts: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "status": self.status.value,
            "output": self.output,
            "error": self.error,
            "execution_time": self.execution_time,
            "artifacts": self.artifacts,
            "metadata": self.metadata,
        }
