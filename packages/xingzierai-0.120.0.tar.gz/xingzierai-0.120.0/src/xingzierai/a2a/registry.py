# -*- coding: utf-8 -*-
"""A2A Agent Registry - Central agent discovery and registration."""

import asyncio
import logging
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional

from .protocol import A2AAgentInfo, A2AMessageType
from .exceptions import AgentNotFoundError

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Central registry for agent discovery and registration.
    
    Features:
    - Agent registration/unregistration
    - Agent discovery by capabilities
    - Health checking and heartbeat
    - Agent status tracking
    """

    def __init__(self, heartbeat_timeout: int = 60):
        """Initialize the agent registry.
        
        Args:
            heartbeat_timeout: Seconds before an agent is considered offline
        """
        self._agents: Dict[str, A2AAgentInfo] = {}
        self._handlers: Dict[str, Callable] = {}
        self._lock = asyncio.Lock()
        self._heartbeat_timeout = heartbeat_timeout
        self._last_heartbeat: Dict[str, datetime] = {}
        logger.info("AgentRegistry initialized")

    async def register_agent(
        self,
        agent_id: str,
        name: str,
        endpoint: str,
        capabilities: Optional[List[str]] = None,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> A2AAgentInfo:
        """Register a new agent in the network.
        
        Args:
            agent_id: Unique identifier for the agent
            name: Human-readable name
            endpoint: Agent's API endpoint
            capabilities: List of capabilities this agent supports
            description: Agent description
            metadata: Additional metadata
            
        Returns:
            A2AAgentInfo: The registered agent information
        """
        async with self._lock:
            agent_info = A2AAgentInfo(
                agent_id=agent_id,
                name=name,
                endpoint=endpoint,
                capabilities=capabilities or [],
                description=description,
                metadata=metadata or {},
            )
            self._agents[agent_id] = agent_info
            self._last_heartbeat[agent_id] = datetime.now()
            logger.info(f"Agent registered: {agent_id} ({name}) at {endpoint}")
            return agent_info

    async def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent from the network.
        
        Args:
            agent_id: Agent to unregister
            
        Returns:
            bool: True if agent was unregistered
        """
        async with self._lock:
            if agent_id in self._agents:
                del self._agents[agent_id]
                self._last_heartbeat.pop(agent_id, None)
                logger.info(f"Agent unregistered: {agent_id}")
                return True
            return False

    async def get_agent(self, agent_id: str) -> A2AAgentInfo:
        """Get agent information by ID.
        
        Args:
            agent_id: Agent ID to look up
            
        Returns:
            A2AAgentInfo: Agent information
            
        Raises:
            AgentNotFoundError: If agent not found
        """
        async with self._lock:
            if agent_id not in self._agents:
                raise AgentNotFoundError(f"Agent not found: {agent_id}")
            return self._agents[agent_id]

    async def list_agents(
        self,
        capabilities: Optional[List[str]] = None,
        status: Optional[str] = None,
    ) -> List[A2AAgentInfo]:
        """List all registered agents, optionally filtered.
        
        Args:
            capabilities: Filter by required capabilities
            status: Filter by agent status
            
        Returns:
            List[A2AAgentInfo]: List of matching agents
        """
        async with self._lock:
            agents = list(self._agents.values())
            
            if capabilities:
                agents = [
                    a for a in agents
                    if any(cap in a.capabilities for cap in capabilities)
                ]
            
            if status:
                agents = [a for a in agents if a.status == status]
            
            return agents

    async def heartbeat(self, agent_id: str) -> bool:
        """Update agent heartbeat timestamp.
        
        Args:
            agent_id: Agent sending heartbeat
            
        Returns:
            bool: True if heartbeat was recorded
        """
        async with self._lock:
            if agent_id not in self._agents:
                logger.warning(f"Heartbeat from unknown agent: {agent_id}")
                return False
            
            self._last_heartbeat[agent_id] = datetime.now()
            self._agents[agent_id].status = "online"
            return True

    async def check_health(self) -> Dict[str, List[str]]:
        """Check health of all registered agents.
        
        Returns:
            Dict[str, List[str]]: Dictionary with 'online' and 'offline' agent lists
        """
        async with self._lock:
            now = datetime.now()
            timeout = timedelta(seconds=self._heartbeat_timeout)
            
            online = []
            offline = []
            
            for agent_id, last_heartbeat in self._last_heartbeat.items():
                if now - last_heartbeat < timeout:
                    online.append(agent_id)
                    if agent_id in self._agents:
                        self._agents[agent_id].status = "online"
                else:
                    offline.append(agent_id)
                    if agent_id in self._agents:
                        self._agents[agent_id].status = "offline"
            
            return {"online": online, "offline": offline}

    async def discover_agents(
        self,
        capability: str,
        min_count: int = 1,
    ) -> List[A2AAgentInfo]:
        """Discover agents with a specific capability.
        
        Args:
            capability: Required capability
            min_count: Minimum number of agents required
            
        Returns:
            List[A2AAgentInfo]: List of agents with the capability
            
        Raises:
            AgentNotFoundError: If not enough agents found
        """
        agents = await self.list_agents(capabilities=[capability])
        
        if len(agents) < min_count:
            raise AgentNotFoundError(
                f"Need {min_count} agents with capability '{capability}', "
                f"found {len(agents)}"
            )
        
        return agents

    def register_message_handler(
        self,
        message_type: A2AMessageType,
        handler: Callable,
    ) -> None:
        """Register a handler for a specific message type.
        
        Args:
            message_type: Type of message to handle
            handler: Async function to handle the message
        """
        self._handlers[message_type.value] = handler
        logger.debug(f"Registered handler for: {message_type.value}")

    async def handle_message(self, message: Dict[str, Any]) -> Any:
        """Handle an incoming A2A message.
        
        Args:
            message: Message dictionary
            
        Returns:
            Any: Result from handler
        """
        msg_type = message.get("type")
        handler = self._handlers.get(msg_type)
        
        if handler:
            return await handler(message)
        
        logger.warning(f"No handler for message type: {msg_type}")
        return None

    def generate_task_id(self) -> str:
        """Generate a unique task ID.
        
        Returns:
            str: Unique task ID
        """
        return f"task_{uuid.uuid4().hex[:12]}"

    def generate_message_id(self) -> str:
        """Generate a unique message ID.
        
        Returns:
            str: Unique message ID
        """
        return f"msg_{uuid.uuid4().hex[:12]}"
