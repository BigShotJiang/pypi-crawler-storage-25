#!/usr/bin/env python3 -*-
"""A2A v1.0 JSON-RPC Server - aligned with Google A2A specification.

Implements the standard A2A JSON-RPC endpoints:
- POST /a2a (JSON-RPC 2.0)
- GET /.well-known/agent-card.json (Agent Card discovery)

Reference: https://github.com/google/A2A/tree/main/specification
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from .protocol_v1 import (
    AgentCard,
    A2ATaskV1,
    ArtifactType,
    JSONRPCError,
    JSONRPCRequest,
    JSONRPCResponse,
    TaskArtifact,
    TaskState,
    TaskStatus,
    A2A_METHODS,
)
from .registry import AgentRegistry

logger = logging.getLogger(__name__)


class A2AV1TaskStore:
    """In-memory task store with capacity limits."""

    MAX_TASKS = 500

    def __init__(self):
        self._tasks: Dict[str, A2ATaskV1] = {}
        self._lock = asyncio.Lock()

    async def save(self, task: A2ATaskV1):
        async with self._lock:
            self._tasks[task.id] = task
            if len(self._tasks) > self.MAX_TASKS:
                oldest = sorted(self._tasks.items(), key=lambda x: x[1].status.timestamp)[:50]
                for tid, _ in oldest:
                    del self._tasks[tid]

    async def get(self, task_id: str) -> Optional[A2ATaskV1]:
        async with self._lock:
            return self._tasks.get(task_id)

    async def update_status(self, task_id: str, state: TaskState,
                            message: Optional[Dict] = None):
        async with self._lock:
            task = self._tasks.get(task_id)
            if task:
                old_status = task.status
                task.history.append(old_status)
                task.status = TaskStatus(state=state, message=message)

    async def add_artifact(self, task_id: str, artifact: TaskArtifact):
        async with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.artifacts.append(artifact)

    async def list_tasks(self, session_id: Optional[str] = None) -> List[A2ATaskV1]:
        async with self._lock:
            tasks = list(self._tasks.values())
            if session_id:
                tasks = [t for t in tasks if t.sessionId == session_id]
            return tasks


class A2AV1Server:
    """A2A v1.0 JSON-RPC Server.

    Provides:
    - JSON-RPC 2.0 endpoint at POST /a2a
    - Agent Card at GET /.well-known/agent-card.json
    - Task lifecycle management
    - Handler registration for custom task processing
    """

    def __init__(
        self,
        agent_card: AgentCard,
        registry: Optional[AgentRegistry] = None,
    ):
        self.agent_card = agent_card
        self.registry = registry or AgentRegistry()
        self.task_store = A2AV1TaskStore()
        self._task_handler: Optional[Callable] = None
        self._cancel_handler: Optional[Callable] = None
        self.router = APIRouter(tags=["A2A-v1"])
        self._setup_routes()

    def _setup_routes(self):
        @self.router.get("/.well-known/agent-card.json")
        async def get_agent_card():
            return self.agent_card.to_dict()

        @self.router.post("/a2a")
        async def handle_jsonrpc(request: Request):
            try:
                body = await request.json()
            except Exception:
                resp = JSONRPCResponse(
                    error=JSONRPCError.make(JSONRPCError.PARSE_ERROR, "Parse error"),
                    id=None,
                )
                return JSONResponse(resp.to_dict(), status_code=200)

            if "method" not in body:
                resp = JSONRPCResponse(
                    error=JSONRPCError.make(JSONRPCError.INVALID_REQUEST, "Invalid Request"),
                    id=body.get("id"),
                )
                return JSONResponse(resp.to_dict(), status_code=200)

            rpc = JSONRPCRequest(
                method=body.get("method", ""),
                params=body.get("params", {}),
                id=body.get("id"),
            )

            result = await self._dispatch(rpc)
            resp = JSONRPCResponse(result=result, id=rpc.id)
            return JSONResponse(resp.to_dict(), status_code=200)

    async def _dispatch(self, rpc: JSONRPCRequest) -> Any:
        method = rpc.method
        params = rpc.params

        if method == "agent/card":
            return self.agent_card.to_dict()

        elif method == "tasks/send":
            return await self._handle_task_send(params)

        elif method == "tasks/get":
            return await self._handle_task_get(params)

        elif method == "tasks/cancel":
            return await self._handle_task_cancel(params)

        elif method == "tasks/pushNotification/set":
            return await self._handle_push_notification_set(params)

        elif method == "tasks/pushNotification/get":
            return await self._handle_push_notification_get(params)

        else:
            return JSONRPCError.make(
                JSONRPCError.METHOD_NOT_FOUND,
                f"Method not found: {method}",
            )

    async def _handle_task_send(self, params: Dict[str, Any]) -> Any:
        task_id = params.get("id", uuid.uuid4().hex[:16])
        session_id = params.get("sessionId", uuid.uuid4().hex[:12])
        message = params.get("message", {})
        metadata = params.get("metadata", {})

        existing = await self.task_store.get(task_id)
        if existing:
            await self.task_store.update_status(
                task_id, TaskState.WORKING,
                message=message if isinstance(message, dict) else {"content": message},
            )
            task = await self.task_store.get(task_id)
            return task.to_dict() if task else None

        task = A2ATaskV1(
            id=task_id,
            sessionId=session_id,
            status=TaskStatus(state=TaskState.SUBMITTED),
            metadata=metadata,
        )
        await self.task_store.save(task)

        if self._task_handler:
            asyncio.create_task(
                self._process_task(task_id, message, params)
            )
        else:
            await self.task_store.update_status(task_id, TaskState.COMPLETED)
            artifact = TaskArtifact(
                name="response",
                parts=[{"type": "text", "text": "Task received (no handler)"}],
                lastChunk=True,
            )
            await self.task_store.add_artifact(task_id, artifact)

        task = await self.task_store.get(task_id)
        return task.to_dict() if task else None

    async def _process_task(self, task_id: str, message: Any, params: Dict):
        await self.task_store.update_status(task_id, TaskState.WORKING)
        try:
            result = await self._task_handler(task_id, message, params)
            if result is not None:
                if isinstance(result, str):
                    artifact = TaskArtifact(
                        name="response",
                        parts=[{"type": "text", "text": result}],
                        lastChunk=True,
                    )
                elif isinstance(result, dict):
                    artifact = TaskArtifact(
                        name="response",
                        parts=[{"type": "data", "data": result}],
                        lastChunk=True,
                    )
                else:
                    artifact = TaskArtifact(
                        name="response",
                        parts=[{"type": "text", "text": str(result)}],
                        lastChunk=True,
                    )
                await self.task_store.add_artifact(task_id, artifact)
            await self.task_store.update_status(task_id, TaskState.COMPLETED)
        except asyncio.CancelledError:
            await self.task_store.update_status(task_id, TaskState.CANCELED)
        except Exception as e:
            logger.error(f"A2A task {task_id} failed: {e}")
            await self.task_store.update_status(
                task_id, TaskState.FAILED,
                message={"error": str(e)},
            )

    async def _handle_task_get(self, params: Dict[str, Any]) -> Any:
        task_id = params.get("id")
        if not task_id:
            return JSONRPCError.make(JSONRPCError.INVALID_PARAMS, "Missing task id")

        task = await self.task_store.get(task_id)
        if not task:
            return JSONRPCError.make(JSONRPCError.TASK_NOT_FOUND, f"Task not found: {task_id}")

        history_length = params.get("historyLength", 0)
        result = task.to_dict()
        if history_length > 0:
            result["history"] = task.history[-history_length:]
        else:
            result["history"] = []
        return result

    async def _handle_task_cancel(self, params: Dict[str, Any]) -> Any:
        task_id = params.get("id")
        if not task_id:
            return JSONRPCError.make(JSONRPCError.INVALID_PARAMS, "Missing task id")

        task = await self.task_store.get(task_id)
        if not task:
            return JSONRPCError.make(JSONRPCError.TASK_NOT_FOUND, f"Task not found: {task_id}")

        if task.status.state not in (TaskState.SUBMITTED, TaskState.WORKING):
            return JSONRPCError.make(
                JSONRPCError.TASK_NOT_CANCELABLE,
                f"Task in state {task.status.state.value} cannot be canceled",
            )

        await self.task_store.update_status(task_id, TaskState.CANCELED)
        if self._cancel_handler:
            try:
                await self._cancel_handler(task_id)
            except Exception as e:
                logger.warning(f"Cancel handler error: {e}")

        task = await self.task_store.get(task_id)
        return task.to_dict() if task else None

    async def _handle_push_notification_set(self, params: Dict[str, Any]) -> Any:
        if not self.agent_card.capabilities.get("pushNotifications", False):
            return JSONRPCError.make(
                JSONRPCError.PUSH_NOTIFICATION_NOT_SUPPORTED,
                "Push notifications not supported",
            )
        return {"pushNotificationConfig": params}

    async def _handle_push_notification_get(self, params: Dict[str, Any]) -> Any:
        return {"pushNotificationConfig": None}

    def register_task_handler(self, handler: Callable):
        self._task_handler = handler

    def register_cancel_handler(self, handler: Callable):
        self._cancel_handler = handler

    async def get_status(self) -> Dict[str, Any]:
        tasks = await self.task_store.list_tasks()
        states = {}
        for t in tasks:
            s = t.status.state.value
            states[s] = states.get(s, 0) + 1
        return {
            "agent_id": self.agent_card.agent_id,
            "agent_name": self.agent_card.name,
            "total_tasks": len(tasks),
            "task_states": states,
            "handler_registered": self._task_handler is not None,
        }
