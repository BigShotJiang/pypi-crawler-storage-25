# -*- coding: utf-8 -*-
"""A2A Router - FastAPI router for handling A2A protocol."""

import asyncio
import logging
import time
import uuid
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .protocol import (
    A2AAgentInfo,
    A2AMessage,
    A2AMessageType,
    A2ATask,
    A2ATaskResult,
    A2ATaskStatus,
)
from .registry import AgentRegistry
from .exceptions import A2AError

logger = logging.getLogger(__name__)


class A2ARegisterRequest(BaseModel):
    """Request model for agent registration."""
    agent_id: str
    name: str
    endpoint: str
    capabilities: List[str] = Field(default_factory=list)
    description: str = ""
    metadata: Dict[str, Any] = Field(default_factory=dict)


class A2ATaskRequest(BaseModel):
    """Request model for submitting a task."""
    id: str = Field(default_factory=lambda: f"task_{uuid.uuid4().hex[:12]}")
    agent_id: str
    description: str
    input_data: Any = None
    priority: int = 0
    timeout: int = 300
    metadata: Dict[str, Any] = Field(default_factory=dict)


class A2AMessageRequest(BaseModel):
    """Request model for sending a message."""
    id: str = Field(default_factory=lambda: f"msg_{uuid.uuid4().hex[:12]}")
    type: A2AMessageType = A2AMessageType.TASK_REQUEST
    sender: str
    content: Any = None
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class A2ARouter:
    """FastAPI router for A2A protocol.
    
    Provides endpoints for:
    - Agent registration
    - Task submission
    - Message passing
    - Agent discovery
    """

    def __init__(
        self,
        agent_id: str,
        agent_name: str,
        capabilities: Optional[List[str]] = None,
        description: str = "",
    ):
        """Initialize A2A Router.
        
        Args:
            agent_id: This agent's ID
            agent_name: This agent's name
            capabilities: List of capabilities this agent supports
            description: Agent description
        """
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.capabilities = capabilities or []
        self.description = description
        self.registry = AgentRegistry()
        self.router = APIRouter(prefix="/a2a", tags=["A2A"])
        self._task_handlers: Dict[str, Callable] = {}
        self._message_handlers: Dict[str, Callable] = {}
        self._tasks: Dict[str, A2ATask] = {}
        
        self._setup_routes()

    def _setup_routes(self) -> None:
        """Setup FastAPI routes."""
        
        @self.router.post("/register")
        async def register_agent(request: A2ARegisterRequest) -> Dict[str, Any]:
            """Register an agent in the network."""
            agent_info = await self.registry.register_agent(
                agent_id=request.agent_id,
                name=request.name,
                endpoint=request.endpoint,
                capabilities=request.capabilities,
                description=request.description,
                metadata=request.metadata,
            )
            return agent_info.to_dict()

        @self.router.post("/unregister/{agent_id}")
        async def unregister_agent(agent_id: str) -> Dict[str, str]:
            """Unregister an agent from the network."""
            result = await self.registry.unregister_agent(agent_id)
            return {"success": str(result)}

        @self.router.get("/agents")
        async def list_agents(
            capabilities: Optional[str] = None,
            status: Optional[str] = None,
        ) -> Dict[str, List[Dict[str, Any]]]:
            """List all registered agents."""
            caps = capabilities.split(",") if capabilities else None
            agents = await self.registry.list_agents(
                capabilities=caps,
                status=status,
            )
            return {"agents": [a.to_dict() for a in agents]}

        @self.router.get("/agents/{agent_id}")
        async def get_agent(agent_id: str) -> Dict[str, Any]:
            """Get agent information."""
            try:
                agent = await self.registry.get_agent(agent_id)
                return agent.to_dict()
            except Exception as e:
                raise HTTPException(status_code=404, detail=str(e))

        @self.router.post("/heartbeat/{agent_id}")
        async def heartbeat(agent_id: str) -> Dict[str, str]:
            """Update agent heartbeat."""
            result = await self.registry.heartbeat(agent_id)
            return {"status": "ok" if result else "failed"}

        @self.router.post("/task")
        async def submit_task(request: A2ATaskRequest) -> Dict[str, Any]:
            """Submit a task to this agent."""
            task = A2ATask(
                id=request.id,
                agent_id=request.agent_id,
                description=request.description,
                input_data=request.input_data,
                priority=request.priority,
                timeout=request.timeout,
                metadata=request.metadata,
            )
            
            self._tasks[task.id] = task
            
            handler = self._task_handlers.get(self.agent_id)
            if handler:
                task.status = A2ATaskStatus.RUNNING
                task.started_at = datetime.now()
                
                try:
                    start_time = time.time()
                    result = await handler(task)
                    execution_time = time.time() - start_time
                    
                    task_result = A2ATaskResult(
                        task_id=task.id,
                        status=A2ATaskStatus.COMPLETED,
                        output=result,
                        execution_time=execution_time,
                    )
                except Exception as e:
                    task_result = A2ATaskResult(
                        task_id=task.id,
                        status=A2ATaskStatus.FAILED,
                        error=str(e),
                    )
            else:
                task_result = A2ATaskResult(
                    task_id=task.id,
                    status=A2ATaskStatus.FAILED,
                    error="No handler registered for this agent",
                )
            
            return task_result.to_dict()

        @self.router.get("/task/{task_id}")
        async def get_task_status(task_id: str) -> Dict[str, Any]:
            """Get task status."""
            if task_id in self._tasks:
                task = self._tasks[task_id]
                return task.to_dict()
            raise HTTPException(status_code=404, detail="Task not found")

        @self.router.post("/message")
        async def send_message(request: A2AMessageRequest) -> Dict[str, Any]:
            """Send a message to this agent."""
            message = A2AMessage(
                id=request.id,
                type=request.type,
                sender=request.sender,
                receiver=self.agent_id,
                session_id=request.session_id,
                content=request.content,
                metadata=request.metadata,
            )
            
            handler = self._message_handlers.get(self.agent_id)
            if handler:
                response = await handler(message)
                return response.to_dict() if hasattr(response, 'to_dict') else response
            
            return {"status": "no_handler", "message": "Message received"}

    def register_task_handler(
        self,
        agent_id: str,
        handler: Callable[[A2ATask], Any],
    ) -> None:
        """Register a handler for incoming tasks.
        
        Args:
            agent_id: Agent ID (usually this agent's ID)
            handler: Async function to handle tasks
        """
        self._task_handlers[agent_id] = handler
        logger.info(f"Registered task handler for agent: {agent_id}")

    def register_message_handler(
        self,
        agent_id: str,
        handler: Callable[[A2AMessage], Any],
    ) -> None:
        """Register a handler for incoming messages.
        
        Args:
            agent_id: Agent ID (usually this agent's ID)
            handler: Async function to handle messages
        """
        self._message_handlers[agent_id] = handler
        logger.info(f"Registered message handler for agent: {agent_id}")

    async def register_self(
        self,
        endpoint: str,
    ) -> A2AAgentInfo:
        """Register this agent in the network.
        
        Args:
            endpoint: This agent's endpoint URL
            
        Returns:
            A2AAgentInfo: Registered agent info
        """
        return await self.registry.register_agent(
            agent_id=self.agent_id,
            name=self.agent_name,
            endpoint=endpoint,
            capabilities=self.capabilities,
            description=self.description,
        )

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on all agents.
        
        Returns:
            Dict[str, Any]: Health status
        """
        health = await self.registry.check_health()
        return {
            "agent_id": self.agent_id,
            "status": "healthy",
            "registered_agents": len(self.registry._agents),
            "pending_tasks": len(self._tasks),
            "agent_health": health,
        }
