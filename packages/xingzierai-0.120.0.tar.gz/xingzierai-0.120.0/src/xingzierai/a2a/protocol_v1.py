#!/usr/bin/env python3 -*-
"""Google A2A Protocol v1.0 compliant data types.

Aligned with: https://github.com/google/A2A/tree/main/specification
Key changes from legacy protocol:
- Agent Cards (/.well-known/agent-card.json) for capability discovery
- JSON-RPC 2.0 message format
- Standard task lifecycle: submitted -> working -> completed/failed/canceled
- TaskArtifact for incremental results
- Push notification support
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class TaskState(str, Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    INPUT_REQUIRED = "input-required"
    UNKNOWN = "unknown"


class ArtifactType(str, Enum):
    TEXT = "text"
    FILE = "file"
    DATA = "data"


@dataclass
class AgentCard:
    """Agent Card - capability discovery document.

    Served at: /.well-known/agent-card.json
    Aligned with Google A2A v1.0 specification.
    """
    name: str
    description: str
    url: str
    version: str = "1.0.0"
    agent_id: str = ""
    capabilities: Dict[str, bool] = field(default_factory=lambda: {
        "streaming": True,
        "pushNotifications": False,
        "stateTransitionHistory": True,
    })
    defaultInputModes: List[str] = field(default_factory=lambda: ["text/plain"])
    defaultOutputModes: List[str] = field(default_factory=lambda: ["text/plain"])
    skills: List[Dict[str, Any]] = field(default_factory=list)
    provider: Optional[Dict[str, str]] = None
    documentationUrl: Optional[str] = None
    authentication: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        if not self.agent_id:
            self.agent_id = uuid.uuid4().hex[:12]

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "name": self.name,
            "description": self.description,
            "url": self.url,
            "version": self.version,
            "capabilities": self.capabilities,
            "defaultInputModes": self.defaultInputModes,
            "defaultOutputModes": self.defaultOutputModes,
            "skills": self.skills,
        }
        if self.provider:
            d["provider"] = self.provider
        if self.documentationUrl:
            d["documentationUrl"] = self.documentationUrl
        if self.authentication:
            d["authentication"] = self.authentication
        return d


@dataclass
class TaskArtifact:
    """Artifact produced during task execution."""
    name: str = ""
    description: str = ""
    parts: List[Dict[str, Any]] = field(default_factory=list)
    index: int = 0
    append: bool = False
    lastChunk: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parts": self.parts,
            "index": self.index,
            "append": self.append,
            "lastChunk": self.lastChunk,
        }


@dataclass
class TaskStatus:
    """Status of a task at a point in time."""
    state: TaskState = TaskState.SUBMITTED
    message: Optional[Dict[str, Any]] = None
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = _iso_now()

    def to_dict(self) -> Dict[str, Any]:
        d = {"state": self.state.value, "timestamp": self.timestamp}
        if self.message:
            d["message"] = self.message
        return d


@dataclass
class A2ATaskV1:
    """A2A Task v1.0 - aligned with Google A2A specification."""
    id: str = ""
    sessionId: str = ""
    status: TaskStatus = field(default_factory=TaskStatus)
    artifacts: List[TaskArtifact] = field(default_factory=list)
    history: List[TaskStatus] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex[:16]
        if not self.sessionId:
            self.sessionId = uuid.uuid4().hex[:12]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "sessionId": self.sessionId,
            "status": self.status.to_dict(),
            "artifacts": [a.to_dict() for a in self.artifacts],
            "history": [h.to_dict() for h in self.history],
            "metadata": self.metadata,
        }


@dataclass
class JSONRPCRequest:
    """JSON-RPC 2.0 Request."""
    jsonrpc: str = "2.0"
    method: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    id: Optional[str] = None

    def __post_init__(self):
        if self.id is None:
            self.id = uuid.uuid4().hex[:8]

    def to_dict(self) -> Dict[str, Any]:
        d = {"jsonrpc": self.jsonrpc, "method": self.method, "params": self.params}
        if self.id is not None:
            d["id"] = self.id
        return d


@dataclass
class JSONRPCResponse:
    """JSON-RPC 2.0 Response."""
    jsonrpc: str = "2.0"
    result: Optional[Any] = None
    error: Optional[Dict[str, Any]] = None
    id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {"jsonrpc": self.jsonrpc}
        if self.error is not None:
            d["error"] = self.error
        else:
            d["result"] = self.result
        if self.id is not None:
            d["id"] = self.id
        return d


class JSONRPCError:
    """JSON-RPC 2.0 Error codes."""
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603

    TASK_NOT_FOUND = -32001
    TASK_NOT_CANCELABLE = -32002
    PUSH_NOTIFICATION_NOT_SUPPORTED = -32003
    UNSUPPORTED_OPERATION = -32004

    @classmethod
    def make(cls, code: int, message: str, data: Any = None) -> Dict[str, Any]:
        d = {"code": code, "message": message}
        if data is not None:
            d["data"] = data
        return d


A2A_METHODS = {
    "tasks/send": "Send a task to the agent",
    "tasks/sendSubscribe": "Send a task with SSE streaming",
    "tasks/get": "Get task status and result",
    "tasks/cancel": "Cancel a running task",
    "tasks/pushNotification/set": "Set push notification config",
    "tasks/pushNotification/get": "Get push notification config",
    "tasks/resubscribe": "Reconnect to task event stream",
    "agent/card": "Get agent card",
}


def _iso_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
