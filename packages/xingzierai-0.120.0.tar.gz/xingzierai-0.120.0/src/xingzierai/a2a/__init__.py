# -*- coding: utf-8 -*-
"""XINGZIERAI A2A Protocol - Agent-to-Agent Communication.

This module implements a standardized protocol for inter-agent communication,
aligned with Google A2A v1.0 specification.

Legacy API (pre-v1.0): protocol.py, server.py, client.py
V1.0 API (Google A2A aligned): protocol_v1.py, server_v1.py
"""

from .protocol import (
    A2AMessage,
    A2ATask,
    A2ATaskResult,
    A2AAgentInfo,
    A2AMessageType,
    A2ATaskStatus,
)
from .registry import AgentRegistry
from .client import A2AClient
from .server import A2ARouter
from .exceptions import A2AError, AgentNotFoundError, TaskTimeoutError
from .protocol_v1 import (
    AgentCard,
    A2ATaskV1,
    TaskState,
    TaskStatus,
    TaskArtifact,
    JSONRPCRequest,
    JSONRPCResponse,
    JSONRPCError,
    A2A_METHODS,
)
from .server_v1 import A2AV1Server, A2AV1TaskStore

__all__ = [
    "A2AMessage",
    "A2ATask",
    "A2ATaskResult",
    "A2AAgentInfo",
    "A2AMessageType",
    "A2ATaskStatus",
    "AgentRegistry",
    "A2AClient",
    "A2ARouter",
    "A2AError",
    "AgentNotFoundError",
    "TaskTimeoutError",
    "AgentCard",
    "A2ATaskV1",
    "TaskState",
    "TaskStatus",
    "TaskArtifact",
    "JSONRPCRequest",
    "JSONRPCResponse",
    "JSONRPCError",
    "A2A_METHODS",
    "A2AV1Server",
    "A2AV1TaskStore",
]
