# -*- coding: utf-8 -*-
"""A2A Protocol Exceptions."""


class A2AError(Exception):
    """Base exception for A2A protocol errors."""
    pass


class AgentNotFoundError(A2AError):
    """Raised when an agent cannot be found."""
    pass


class TaskTimeoutError(A2AError):
    """Raised when a task times out."""
    pass


class TaskCancelledError(A2AError):
    """Raised when a task is cancelled."""
    pass


class AgentOfflineError(A2AError):
    """Raised when attempting to communicate with an offline agent."""
    pass


class CapabilityNotSupportedError(A2AError):
    """Raised when an agent doesn't support a required capability."""
    pass
