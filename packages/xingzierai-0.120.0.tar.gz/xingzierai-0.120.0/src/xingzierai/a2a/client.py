# -*- coding: utf-8 -*-
"""A2A Client - Client for communicating with other agents."""

import asyncio
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from .protocol import (
    A2AMessage,
    A2AMessageType,
    A2ATask,
    A2ATaskResult,
    A2ATaskStatus,
)
from .exceptions import AgentNotFoundError, TaskTimeoutError, AgentOfflineError

logger = logging.getLogger(__name__)


class A2AClient:
    """Client for agent-to-agent communication.
    
    Features:
    - Task submission and result retrieval
    - Asynchronous message passing
    - Connection pooling
    - Automatic retry
    """

    def __init__(
        self,
        agent_id: str,
        registry: Optional[Any] = None,
        timeout: int = 300,
        max_retries: int = 3,
    ):
        """Initialize A2A Client.
        
        Args:
            agent_id: This agent's ID
            registry: Agent registry instance
            timeout: Default task timeout in seconds
            max_retries: Maximum number of retries
        """
        self.agent_id = agent_id
        self.registry = registry
        self.timeout = timeout
        self.max_retries = max_retries
        self._session: Optional[aiohttp.ClientSession] = None
        self._pending_tasks: Dict[str, asyncio.Future] = {}

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self) -> None:
        """Close the client and cleanup resources."""
        if self._session and not self._session.closed:
            await self._session.close()
        
        for task in self._pending_tasks.values():
            task.cancel()

    async def send_task(
        self,
        target_agent_id: str,
        task_description: str,
        input_data: Optional[Any] = None,
        timeout: Optional[int] = None,
        priority: int = 0,
    ) -> A2ATaskResult:
        """Send a task to another agent and wait for result.
        
        Args:
            target_agent_id: Target agent ID
            task_description: Description of the task
            input_data: Input data for the task
            timeout: Task timeout in seconds
            priority: Task priority (higher = more urgent)
            
        Returns:
            A2ATaskResult: Result from the target agent
            
        Raises:
            AgentNotFoundError: If target agent not found
            TaskTimeoutError: If task times out
        """
        if self.registry:
            try:
                agent_info = await self.registry.get_agent(target_agent_id)
                if agent_info.status == "offline":
                    raise AgentOfflineError(f"Agent {target_agent_id} is offline")
                endpoint = agent_info.endpoint
            except Exception as e:
                raise AgentNotFoundError(f"Cannot find agent {target_agent_id}: {e}")
        else:
            raise AgentNotFoundError("No registry configured")

        task = A2ATask(
            id=f"task_{uuid.uuid4().hex[:12]}",
            agent_id=self.agent_id,
            description=task_description,
            input_data=input_data,
            priority=priority,
            timeout=timeout or self.timeout,
        )

        timeout_seconds = timeout or self.timeout
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                return await self._send_task_with_timeout(
                    endpoint, task, timeout_seconds
                )
            except Exception as e:
                last_error = e
                logger.warning(
                    f"Task {task.id} failed (attempt {attempt + 1}/{self.max_retries}): {e}"
                )
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
        
        raise TaskTimeoutError(f"Task failed after {self.max_retries} attempts: {last_error}")

    async def _send_task_with_timeout(
        self,
        endpoint: str,
        task: A2ATask,
        timeout: int,
    ) -> A2ATaskResult:
        """Send task with timeout."""
        session = await self._get_session()
        
        url = f"{endpoint.rstrip('/')}/a2a/task"
        
        async with session.post(
            url,
            json=task.to_dict(),
            timeout=aiohttp.ClientTimeout(total=timeout),
        ) as response:
            if response.status == 200:
                data = await response.json()
                return A2ATaskResult(
                    task_id=data["task_id"],
                    status=A2ATaskStatus(data["status"]),
                    output=data.get("output"),
                    error=data.get("error"),
                    execution_time=data.get("execution_time", 0.0),
                    artifacts=data.get("artifacts", []),
                    metadata=data.get("metadata", {}),
                )
            else:
                raise A2AError(f"Task failed with status {response.status}")

    async def send_message(
        self,
        target_agent_id: str,
        content: Any,
        session_id: Optional[str] = None,
    ) -> A2AMessage:
        """Send a message to another agent.
        
        Args:
            target_agent_id: Target agent ID
            content: Message content
            session_id: Optional session ID for conversation
            
        Returns:
            A2AMessage: Response message
        """
        if self.registry:
            agent_info = await self.registry.get_agent(target_agent_id)
            endpoint = agent_info.endpoint
        else:
            raise AgentNotFoundError("No registry configured")

        message = A2AMessage(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            type=A2AMessageType.TASK_REQUEST,
            sender=self.agent_id,
            receiver=target_agent_id,
            session_id=session_id,
            content=content,
        )

        session = await self._get_session()
        url = f"{endpoint.rstrip('/')}/a2a/message"
        
        async with session.post(url, json=message.to_dict()) as response:
            if response.status == 200:
                data = await response.json()
                return A2AMessage.from_dict(data)
            else:
                raise A2AError(f"Message failed with status {response.status}")

    async def discover_agents(
        self,
        capability: Optional[str] = None,
    ) -> List[Any]:
        """Discover available agents.
        
        Args:
            capability: Optional capability to filter by
            
        Returns:
            List[Any]: List of available agents
        """
        if self.registry:
            return await self.registry.list_agents(capabilities=[capability] if capability else None)
        return []

    async def delegate_task(
        self,
        target_agent_id: str,
        task: A2ATask,
    ) -> str:
        """Delegate a task to another agent (fire and forget).
        
        Args:
            target_agent_id: Target agent ID
            task: Task to delegate
            
        Returns:
            str: Task ID
        """
        if self.registry:
            agent_info = await self.registry.get_agent(target_agent_id)
            endpoint = agent_info.endpoint
        else:
            raise AgentNotFoundError("No registry configured")

        session = await self._get_session()
        url = f"{endpoint.rstrip('/')}/a2a/task"
        
        async with session.post(url, json=task.to_dict()) as response:
            if response.status in (200, 202):
                data = await response.json()
                return data.get("task_id", task.id)
            else:
                raise A2AError(f"Task delegation failed with status {response.status}")
