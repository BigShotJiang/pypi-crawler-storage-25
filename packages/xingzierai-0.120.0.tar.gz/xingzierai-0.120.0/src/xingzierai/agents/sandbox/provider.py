#!/usr/bin/env python3 -*-
"""Sandbox provider abstraction for XINGZIER AI.

Supports multiple sandbox backends:
1. LocalProcess (default) - existing SandboxExecutor with resource limits
2. Docker - Docker container isolation with filesystem/network boundaries
3. E2B - cloud sandbox via E2B Code Interpreter

Design inspired by OpenAI Agents SDK's multi-provider sandbox architecture.
Each provider implements the same SandboxProvider interface, allowing
seamless switching between local development and production isolation.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SandboxType(str, Enum):
    LOCAL = "local"
    DOCKER = "docker"
    E2B = "e2b"


@dataclass
class SandboxManifest:
    """Declarative permission control for sandbox execution.

    Inspired by OpenAI Agents SDK Manifest.
    Defines what the agent can access inside the sandbox.
    """
    allowed_commands: List[str] = field(default_factory=lambda: ["*"])
    denied_commands: List[str] = field(default_factory=lambda: [
        "rm -rf /", "mkfs", "dd if=/dev/zero", ":(){ :|:& };:",
        "shutdown", "reboot", "init 0",
    ])
    allowed_paths: List[str] = field(default_factory=lambda: ["/workspace"])
    denied_paths: List[str] = field(default_factory=lambda: ["/etc/shadow", "/root/.ssh"])
    network_enabled: bool = True
    max_execution_time: int = 300
    max_memory_mb: int = 512
    max_output_bytes: int = 10 * 1024 * 1024
    env_vars: Dict[str, str] = field(default_factory=dict)

    def is_command_allowed(self, command: str) -> bool:
        cmd_lower = command.strip().lower()
        for denied in self.denied_commands:
            if denied.lower() in cmd_lower:
                return False
        if "*" not in self.allowed_commands:
            base_cmd = cmd_lower.split()[0] if cmd_lower.split() else ""
            if base_cmd not in [c.lower() for c in self.allowed_commands]:
                return False
        return True

    def is_path_allowed(self, path: str) -> bool:
        resolved = str(Path(path).resolve())
        for denied in self.denied_paths:
            if resolved.startswith(denied):
                return False
        if "*" not in self.allowed_paths:
            allowed = any(resolved.startswith(p) for p in self.allowed_paths)
            if not allowed:
                return False
        return True


@dataclass
class SandboxResult:
    """Result from sandbox execution."""
    exit_code: int = -1
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    error: Optional[str] = None
    duration: float = 0.0
    sandbox_id: str = ""
    files_created: List[str] = field(default_factory=list)
    files_modified: List[str] = field(default_factory=list)


class SandboxProvider(ABC):
    """Abstract base class for sandbox providers."""

    @abstractmethod
    async def create(self, manifest: Optional[SandboxManifest] = None) -> str:
        """Create a new sandbox instance. Returns sandbox_id."""

    @abstractmethod
    async def execute(self, sandbox_id: str, command: str,
                      cwd: Optional[str] = None,
                      env: Optional[Dict[str, str]] = None,
                      timeout: Optional[int] = None) -> SandboxResult:
        """Execute command in sandbox."""

    @abstractmethod
    async def read_file(self, sandbox_id: str, path: str) -> str:
        """Read file from sandbox."""

    @abstractmethod
    async def write_file(self, sandbox_id: str, path: str, content: str) -> bool:
        """Write file to sandbox."""

    @abstractmethod
    async def list_files(self, sandbox_id: str, path: str = "/workspace") -> List[str]:
        """List files in sandbox directory."""

    @abstractmethod
    async def destroy(self, sandbox_id: str) -> bool:
        """Destroy sandbox instance."""

    @abstractmethod
    async def is_available(self) -> bool:
        """Check if this provider is available."""


class LocalProcessSandbox(SandboxProvider):
    """Local process sandbox using existing SandboxExecutor.

    No filesystem isolation - only resource limits and process management.
    Suitable for development and trusted environments.
    """

    def __init__(self):
        self._sandboxes: Dict[str, dict] = {}

    async def create(self, manifest: Optional[SandboxManifest] = None) -> str:
        import uuid
        sandbox_id = uuid.uuid4().hex[:12]
        self._sandboxes[sandbox_id] = {
            "manifest": manifest or SandboxManifest(),
            "created_at": time.time(),
            "cwd": "/workspace",
        }
        return sandbox_id

    async def execute(self, sandbox_id: str, command: str,
                      cwd: Optional[str] = None,
                      env: Optional[Dict[str, str]] = None,
                      timeout: Optional[int] = None) -> SandboxResult:
        if sandbox_id not in self._sandboxes:
            return SandboxResult(error=f"Sandbox {sandbox_id} not found")

        sb = self._sandboxes[sandbox_id]
        manifest = sb["manifest"]

        if not manifest.is_command_allowed(command):
            return SandboxResult(error=f"Command denied by manifest: {command}")

        try:
            from xingzierai.tools.sandbox import SandboxExecutor, ResourceLimits
            limits = ResourceLimits(
                timeout=timeout or manifest.max_execution_time,
                memory_limit_mb=manifest.max_memory_mb,
                network_enabled=manifest.network_enabled,
            )
            executor = SandboxExecutor(limits=limits)
            result = await executor.execute(command, cwd=cwd, env=env)
            await executor._cleanup()
            return SandboxResult(
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                timed_out=result.timed_out,
                duration=result.duration,
                sandbox_id=sandbox_id,
            )
        except Exception as e:
            return SandboxResult(error=str(e), sandbox_id=sandbox_id)

    async def read_file(self, sandbox_id: str, path: str) -> str:
        try:
            manifest = self._sandboxes.get(sandbox_id)
            if manifest and not manifest.is_path_allowed(path):
                return f"Error: Path '{path}' is not allowed by sandbox policy"
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Error reading file: {e}"

    async def write_file(self, sandbox_id: str, path: str, content: str) -> bool:
        try:
            manifest = self._sandboxes.get(sandbox_id)
            if manifest and not manifest.is_path_allowed(path):
                logger.warning("Sandbox write blocked: path '%s' not allowed", path)
                return False
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return True
        except Exception:
            return False

    async def list_files(self, sandbox_id: str, path: str = "/workspace") -> List[str]:
        try:
            return [str(p) for p in Path(path).rglob("*") if p.is_file()][:100]
        except Exception:
            return []

    async def destroy(self, sandbox_id: str) -> bool:
        return self._sandboxes.pop(sandbox_id, None) is not None

    async def is_available(self) -> bool:
        return True


class DockerSandbox(SandboxProvider):
    """Docker container sandbox with filesystem and network isolation.

    Uses Docker API to create isolated containers for agent execution.
    Each sandbox is a separate container with its own filesystem.
    """

    _IMAGE = "xingzierai-sandbox:latest"
    _WORKSPACE = "/workspace"

    def __init__(self):
        self._containers: Dict[str, dict] = {}
        self._docker_available: Optional[bool] = None

    async def is_available(self) -> bool:
        if self._docker_available is not None:
            return self._docker_available
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "version", "--format", "{{.Server.Version}}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            self._docker_available = proc.returncode == 0
            if self._docker_available:
                logger.info(f"DockerSandbox: Docker available, version={stdout.decode().strip()}")
        except Exception:
            self._docker_available = False
            logger.info("DockerSandbox: Docker not available")
        return self._docker_available

    async def create(self, manifest: Optional[SandboxManifest] = None) -> str:
        if not await self.is_available():
            raise RuntimeError("Docker is not available")

        import uuid
        sandbox_id = uuid.uuid4().hex[:12]
        manifest = manifest or SandboxManifest()

        run_args = [
            "docker", "run", "-d",
            "--name", f"xingzierai-sandbox-{sandbox_id}",
            "-w", self._WORKSPACE,
            "-m", f"{manifest.max_memory_mb}m",
            "--cpus", "1.0",
            "--pids-limit", "64",
        ]

        if not manifest.network_enabled:
            run_args.append("--network=none")

        for k, v in manifest.env_vars.items():
            run_args.extend(["-e", f"{k}={v}"])

        run_args.extend([self._IMAGE, "sleep", str(manifest.max_execution_time + 60)])

        try:
            proc = await asyncio.create_subprocess_exec(
                *run_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)

            if proc.returncode != 0:
                err = stderr.decode().strip()
                logger.error(f"DockerSandbox: create failed: {err}")
                raise RuntimeError(f"Docker create failed: {err}")

            container_id = stdout.decode().strip()[:12]
            self._containers[sandbox_id] = {
                "container_id": container_id,
                "manifest": manifest,
                "created_at": time.time(),
            }
            logger.info(f"DockerSandbox: created {sandbox_id} (container={container_id})")
            return sandbox_id

        except asyncio.TimeoutError:
            raise RuntimeError("Docker create timed out")
        except FileNotFoundError:
            self._docker_available = False
            raise RuntimeError("Docker command not found")

    async def execute(self, sandbox_id: str, command: str,
                      cwd: Optional[str] = None,
                      env: Optional[Dict[str, str]] = None,
                      timeout: Optional[int] = None) -> SandboxResult:
        if sandbox_id not in self._containers:
            return SandboxResult(error=f"Sandbox {sandbox_id} not found")

        sb = self._containers[sandbox_id]
        manifest = sb["manifest"]

        if not manifest.is_command_allowed(command):
            return SandboxResult(error=f"Command denied by manifest: {command}")

        exec_timeout = timeout or manifest.max_execution_time
        container_name = f"xingzierai-sandbox-{sandbox_id}"

        exec_args = [
            "docker", "exec",
            "-w", cwd or self._WORKSPACE,
        ]
        if env:
            for k, v in env.items():
                exec_args.extend(["-e", f"{k}={v}"])

        exec_args.extend([container_name, "sh", "-c", command])

        start = time.monotonic()
        try:
            proc = await asyncio.create_subprocess_exec(
                *exec_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=exec_timeout
            )
            duration = time.monotonic() - start

            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")

            if len(stdout_str.encode("utf-8")) > manifest.max_output_bytes:
                stdout_str = stdout_str[:manifest.max_output_bytes] + "\n... [truncated]"
            if len(stderr_str.encode("utf-8")) > manifest.max_output_bytes:
                stderr_str = stderr_str[:manifest.max_output_bytes] + "\n... [truncated]"

            return SandboxResult(
                exit_code=proc.returncode or 0,
                stdout=stdout_str,
                stderr=stderr_str,
                duration=duration,
                sandbox_id=sandbox_id,
            )

        except asyncio.TimeoutError:
            return SandboxResult(
                timed_out=True,
                error=f"Execution timed out after {exec_timeout}s",
                duration=time.monotonic() - start,
                sandbox_id=sandbox_id,
            )
        except Exception as e:
            return SandboxResult(error=str(e), sandbox_id=sandbox_id)

    async def read_file(self, sandbox_id: str, path: str) -> str:
        result = await self.execute(
            sandbox_id, f"cat {shlex.quote(path)}", timeout=10,
        )
        if result.error:
            return f"Error: {result.error}"
        return result.stdout

    async def write_file(self, sandbox_id: str, path: str, content: str) -> bool:
        result = await self.execute(
            sandbox_id,
            f"mkdir -p {shlex.quote(os.path.dirname(path))} && cat > {shlex.quote(path)} << 'XINGZIERAI_EOF'\n{content}\nXINGZIERAI_EOF",
            timeout=10,
        )
        return result.exit_code == 0

    async def list_files(self, sandbox_id: str, path: str = "/workspace") -> List[str]:
        result = await self.execute(
            sandbox_id, f"find '{path}' -maxdepth 3 -type f 2>/dev/null | head -100",
            timeout=10,
        )
        if result.exit_code == 0:
            return [l.strip() for l in result.stdout.split("\n") if l.strip()]
        return []

    async def destroy(self, sandbox_id: str) -> bool:
        if sandbox_id not in self._containers:
            return False
        container_name = f"xingzierai-sandbox-{sandbox_id}"
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "rm", "-f", container_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=10)
        except Exception as e:
            logger.warning(f"DockerSandbox: destroy error: {e}")
        self._containers.pop(sandbox_id, None)
        return True


class E2BSandbox(SandboxProvider):
    """E2B cloud sandbox provider.

    Uses E2B Code Interpreter for fully isolated cloud execution.
    Requires E2B_API_KEY environment variable.
    """

    def __init__(self):
        self._sandboxes: Dict[str, Any] = {}
        self._e2b_available: Optional[bool] = None

    async def is_available(self) -> bool:
        if self._e2b_available is not None:
            return self._e2b_available
        try:
            import e2b_code_interpreter
            api_key = os.getenv("E2B_API_KEY")
            self._e2b_available = api_key is not None and len(api_key) > 0
            if self._e2b_available:
                logger.info("E2BSandbox: E2B API key found")
            else:
                logger.info("E2BSandbox: E2B_API_KEY not set")
        except ImportError:
            self._e2b_available = False
            logger.info("E2BSandbox: e2b_code_interpreter not installed")
        return self._e2b_available

    async def create(self, manifest: Optional[SandboxManifest] = None) -> str:
        if not await self.is_available():
            raise RuntimeError("E2B is not available (install e2b-code-interpreter and set E2B_API_KEY)")

        import uuid
        from e2b_code_interpreter import Sandbox

        sandbox_id = uuid.uuid4().hex[:12]
        manifest = manifest or SandboxManifest()

        try:
            sb = Sandbox(timeout=manifest.max_execution_time)
            self._sandboxes[sandbox_id] = {
                "sandbox": sb,
                "manifest": manifest,
                "created_at": time.time(),
            }
            logger.info(f"E2BSandbox: created {sandbox_id}")
            return sandbox_id
        except Exception as e:
            raise RuntimeError(f"E2B create failed: {e}")

    async def execute(self, sandbox_id: str, command: str,
                      cwd: Optional[str] = None,
                      env: Optional[Dict[str, str]] = None,
                      timeout: Optional[int] = None) -> SandboxResult:
        if sandbox_id not in self._sandboxes:
            return SandboxResult(error=f"Sandbox {sandbox_id} not found")

        sb_data = self._sandboxes[sandbox_id]
        e2b_sb = sb_data["sandbox"]
        manifest = sb_data["manifest"]

        if not manifest.is_command_allowed(command):
            return SandboxResult(error=f"Command denied by manifest: {command}")

        start = time.monotonic()
        try:
            exec_cmd = command
            if cwd:
                exec_cmd = f"cd {cwd} && {command}"

            execution = e2b_sb.run_code(exec_cmd, timeout=timeout or manifest.max_execution_time)
            duration = time.monotonic() - start

            stdout = ""
            stderr = ""
            if execution.logs:
                stdout = "\n".join(str(l) for l in execution.logs)
            if execution.error:
                stderr = str(execution.error)

            return SandboxResult(
                exit_code=0 if not execution.error else 1,
                stdout=stdout,
                stderr=stderr,
                duration=duration,
                sandbox_id=sandbox_id,
            )
        except Exception as e:
            return SandboxResult(
                error=str(e),
                duration=time.monotonic() - start,
                sandbox_id=sandbox_id,
            )

    async def read_file(self, sandbox_id: str, path: str) -> str:
        if sandbox_id not in self._sandboxes:
            return f"Error: Sandbox {sandbox_id} not found"
        e2b_sb = self._sandboxes[sandbox_id]["sandbox"]
        try:
            content = e2b_sb.files.read(path)
            return content
        except Exception as e:
            return f"Error reading file: {e}"

    async def write_file(self, sandbox_id: str, path: str, content: str) -> bool:
        if sandbox_id not in self._sandboxes:
            return False
        e2b_sb = self._sandboxes[sandbox_id]["sandbox"]
        try:
            e2b_sb.files.write(path, content)
            return True
        except Exception:
            return False

    async def list_files(self, sandbox_id: str, path: str = "/workspace") -> List[str]:
        result = await self.execute(sandbox_id, f"find '{path}' -maxdepth 3 -type f 2>/dev/null | head -100")
        if result.exit_code == 0:
            return [l.strip() for l in result.stdout.split("\n") if l.strip()]
        return []

    async def destroy(self, sandbox_id: str) -> bool:
        if sandbox_id not in self._sandboxes:
            return False
        e2b_sb = self._sandboxes[sandbox_id]["sandbox"]
        try:
            e2b_sb.close()
        except Exception as e:
            logger.warning(f"E2BSandbox: destroy error: {e}")
        self._sandboxes.pop(sandbox_id, None)
        return True


class SandboxManager:
    """Central manager for sandbox providers.

    Automatically selects the best available provider:
    1. E2B (cloud, best isolation) - if E2B_API_KEY is set
    2. Docker (local, good isolation) - if Docker is available
    3. LocalProcess (no isolation) - always available as fallback

    Usage:
        manager = SandboxManager()
        sandbox_id = await manager.create(manifest)
        result = await manager.execute(sandbox_id, "python script.py")
        await manager.destroy(sandbox_id)
    """

    def __init__(self, preferred: Optional[SandboxType] = None):
        self._providers: Dict[SandboxType, SandboxProvider] = {
            SandboxType.LOCAL: LocalProcessSandbox(),
            SandboxType.DOCKER: DockerSandbox(),
            SandboxType.E2B: E2BSandbox(),
        }
        self._preferred = preferred
        self._active_provider: Optional[SandboxType] = None
        self._active_sandboxes: Dict[str, SandboxType] = {}

    async def _select_provider(self) -> SandboxType:
        if self._active_provider is not None:
            return self._active_provider

        if self._preferred:
            provider = self._providers.get(self._preferred)
            if provider and await provider.is_available():
                self._active_provider = self._preferred
                return self._preferred

        for st in [SandboxType.E2B, SandboxType.DOCKER, SandboxType.LOCAL]:
            provider = self._providers.get(st)
            if provider and await provider.is_available():
                self._active_provider = st
                logger.info(f"SandboxManager: selected {st.value} provider")
                return st

        self._active_provider = SandboxType.LOCAL
        return SandboxType.LOCAL

    async def create(self, manifest: Optional[SandboxManifest] = None) -> str:
        provider_type = await self._select_provider()
        provider = self._providers[provider_type]
        sandbox_id = await provider.create(manifest)
        self._active_sandboxes[sandbox_id] = provider_type
        return sandbox_id

    async def execute(self, sandbox_id: str, command: str,
                      cwd: Optional[str] = None,
                      env: Optional[Dict[str, str]] = None,
                      timeout: Optional[int] = None) -> SandboxResult:
        provider_type = self._active_sandboxes.get(sandbox_id)
        if provider_type is None:
            return SandboxResult(error=f"Sandbox {sandbox_id} not found")
        provider = self._providers[provider_type]
        return await provider.execute(sandbox_id, command, cwd, env, timeout)

    async def read_file(self, sandbox_id: str, path: str) -> str:
        provider_type = self._active_sandboxes.get(sandbox_id)
        if provider_type is None:
            return f"Error: Sandbox {sandbox_id} not found"
        return await self._providers[provider_type].read_file(sandbox_id, path)

    async def write_file(self, sandbox_id: str, path: str, content: str) -> bool:
        provider_type = self._active_sandboxes.get(sandbox_id)
        if provider_type is None:
            return False
        return await self._providers[provider_type].write_file(sandbox_id, path, content)

    async def list_files(self, sandbox_id: str, path: str = "/workspace") -> List[str]:
        provider_type = self._active_sandboxes.get(sandbox_id)
        if provider_type is None:
            return []
        return await self._providers[provider_type].list_files(sandbox_id, path)

    async def destroy(self, sandbox_id: str) -> bool:
        provider_type = self._active_sandboxes.pop(sandbox_id, None)
        if provider_type is None:
            return False
        return await self._providers[provider_type].destroy(sandbox_id)

    async def destroy_all(self):
        for sid in list(self._active_sandboxes.keys()):
            await self.destroy(sid)

    async def get_status(self) -> Dict[str, Any]:
        availability = {}
        for st, provider in self._providers.items():
            availability[st.value] = await provider.is_available()
        return {
            "active_provider": self._active_provider.value if self._active_provider else None,
            "availability": availability,
            "active_sandboxes": len(self._active_sandboxes),
        }
