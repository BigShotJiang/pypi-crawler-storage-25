#!/usr/bin/env python3 -*-
"""Multi-mode orchestration for XINGZIER AI.

Extends Orchestrator-Workers with 4 orchestration patterns:
1. HIERARCHICAL - Manager decomposes, workers execute (existing)
2. SWARM - Multiple agents work in parallel, emergent coordination
3. PIPELINE - Chain of agents, each processing and passing output
4. CONSENSUS - Multiple agents analyze independently, vote on result

Reference: 2026 research on multi-agent coordination patterns.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class OrchestrationMode(str, Enum):
    HIERARCHICAL = "hierarchical"
    SWARM = "swarm"
    PIPELINE = "pipeline"
    CONSENSUS = "consensus"


@dataclass
class OrchestrationResult:
    mode: OrchestrationMode
    task_id: str
    output: Any = None
    outputs: List[Any] = field(default_factory=list)
    votes: Dict[str, int] = field(default_factory=dict)
    consensus_reached: bool = False
    duration: float = 0.0
    worker_count: int = 0
    error: Optional[str] = None


@dataclass
class WorkerSpec:
    worker_id: str
    capability: str = "general"
    handler: Optional[Callable] = None


class HierarchicalOrchestrator:
    """Manager decomposes task → workers execute → results aggregated."""

    async def execute(self, task: str, workers: List[WorkerSpec],
                      decompose_fn: Callable,
                      aggregate_fn: Callable) -> OrchestrationResult:
        start = time.time()
        task_id = uuid.uuid4().hex[:12]
        try:
            subtasks = await decompose_fn(task, len(workers))
            results = await asyncio.gather(*[
                self._execute_subtask(subtask, workers, i % len(workers))
                for i, subtask in enumerate(subtasks)
            ], return_exceptions=True)
            valid = [r for r in results if not isinstance(r, Exception)]
            output = await aggregate_fn(task, valid)
            return OrchestrationResult(
                mode=OrchestrationMode.HIERARCHICAL,
                task_id=task_id, output=output,
                outputs=valid, duration=time.time() - start,
                worker_count=len(workers),
            )
        except Exception as e:
            return OrchestrationResult(
                mode=OrchestrationMode.HIERARCHICAL,
                task_id=task_id, error=str(e),
                duration=time.time() - start,
            )

    async def _execute_subtask(self, subtask: str, workers: List[WorkerSpec],
                                worker_idx: int) -> Any:
        worker = workers[worker_idx % len(workers)]
        if worker.handler:
            return await worker.handler(subtask)
        return f"[Worker {worker.worker_id}]: {subtask}"


class SwarmOrchestrator:
    """Multiple agents work on the same task in parallel, best result selected."""

    def __init__(self, selection_strategy: str = "best"):
        self.selection_strategy = selection_strategy

    async def execute(self, task: str, workers: List[WorkerSpec],
                      evaluate_fn: Optional[Callable] = None) -> OrchestrationResult:
        start = time.time()
        task_id = uuid.uuid4().hex[:12]
        try:
            results = await asyncio.gather(*[
                self._execute_worker(task, w) for w in workers
            ], return_exceptions=True)
            valid = [(i, r) for i, r in enumerate(results) if not isinstance(r, Exception)]

            if not valid:
                return OrchestrationResult(
                    mode=OrchestrationMode.SWARM, task_id=task_id,
                    error="All workers failed", duration=time.time() - start,
                )

            if evaluate_fn:
                scored = []
                for i, r in valid:
                    score = await evaluate_fn(task, r)
                    scored.append((score, r))
                scored.sort(key=lambda x: x[0], reverse=True)
                output = scored[0][1]
            else:
                output = valid[0][1]

            return OrchestrationResult(
                mode=OrchestrationMode.SWARM, task_id=task_id,
                output=output, outputs=[r for _, r in valid],
                duration=time.time() - start, worker_count=len(workers),
            )
        except Exception as e:
            return OrchestrationResult(
                mode=OrchestrationMode.SWARM, task_id=task_id,
                error=str(e), duration=time.time() - start,
            )

    async def _execute_worker(self, task: str, worker: WorkerSpec) -> Any:
        if worker.handler:
            return await worker.handler(task)
        return f"[Swarm {worker.worker_id}]: processed"


class PipelineOrchestrator:
    """Chain of agents, each processing and passing output to the next."""

    async def execute(self, task: str, workers: List[WorkerSpec],
                      transform_fn: Optional[Callable] = None) -> OrchestrationResult:
        start = time.time()
        task_id = uuid.uuid4().hex[:12]
        current_input = task
        outputs = []

        try:
            for i, worker in enumerate(workers):
                if worker.handler:
                    result = await worker.handler(current_input)
                else:
                    result = f"[Pipeline {worker.worker_id}]: {current_input}"

                if transform_fn:
                    result = await transform_fn(i, result)

                outputs.append(result)
                current_input = result

            return OrchestrationResult(
                mode=OrchestrationMode.PIPELINE, task_id=task_id,
                output=current_input, outputs=outputs,
                duration=time.time() - start, worker_count=len(workers),
            )
        except Exception as e:
            return OrchestrationResult(
                mode=OrchestrationMode.PIPELINE, task_id=task_id,
                output=current_input, outputs=outputs,
                error=str(e), duration=time.time() - start,
            )


class ConsensusOrchestrator:
    """Multiple agents analyze independently, vote on result.

    Voting strategies:
    - majority: Most common answer wins
    - weighted: Weight votes by agent confidence/reliability
    - unanimous: Require all agents agree
    """

    def __init__(self, strategy: str = "majority", min_agreement: float = 0.5):
        self.strategy = strategy
        self.min_agreement = min_agreement

    async def execute(self, task: str, workers: List[WorkerSpec],
                      compare_fn: Optional[Callable] = None) -> OrchestrationResult:
        start = time.time()
        task_id = uuid.uuid4().hex[:12]

        try:
            results = await asyncio.gather(*[
                self._execute_worker(task, w) for w in workers
            ], return_exceptions=True)
            valid = [(i, r) for i, r in enumerate(results) if not isinstance(r, Exception)]

            if not valid:
                return OrchestrationResult(
                    mode=OrchestrationMode.CONSENSUS, task_id=task_id,
                    error="All workers failed", duration=time.time() - start,
                )

            if compare_fn:
                groups: Dict[str, List[Any]] = {}
                for i, r in valid:
                    key = await compare_fn(r)
                    groups.setdefault(key, []).append(r)
            else:
                str_results = [str(r) for _, r in valid]
                groups: Dict[str, List[Any]] = {}
                for r in str_results:
                    groups.setdefault(r, []).append(r)

            votes = {k: len(v) for k, v in groups.items()}
            total = sum(votes.values())

            if self.strategy == "majority":
                best_key = max(votes, key=votes.get)
                consensus = votes[best_key] / total >= self.min_agreement
                output = groups[best_key][0]
            elif self.strategy == "unanimous":
                consensus = len(votes) == 1
                output = valid[0][1] if consensus else None
            else:
                best_key = max(votes, key=votes.get)
                consensus = votes[best_key] / total >= self.min_agreement
                output = groups[best_key][0]

            return OrchestrationResult(
                mode=OrchestrationMode.CONSENSUS, task_id=task_id,
                output=output, outputs=[r for _, r in valid],
                votes=votes, consensus_reached=consensus,
                duration=time.time() - start, worker_count=len(workers),
            )
        except Exception as e:
            return OrchestrationResult(
                mode=OrchestrationMode.CONSENSUS, task_id=task_id,
                error=str(e), duration=time.time() - start,
            )

    async def _execute_worker(self, task: str, worker: WorkerSpec) -> Any:
        if worker.handler:
            return await worker.handler(task)
        return f"[Consensus {worker.worker_id}]: analyzed"


class MultiModeOrchestrator:
    """Unified orchestrator supporting all 4 modes."""

    def __init__(self):
        self._hierarchical = HierarchicalOrchestrator()
        self._swarm = SwarmOrchestrator()
        self._pipeline = PipelineOrchestrator()
        self._consensus = ConsensusOrchestrator()

    async def execute(
        self,
        mode: OrchestrationMode,
        task: str,
        workers: List[WorkerSpec],
        decompose_fn: Optional[Callable] = None,
        aggregate_fn: Optional[Callable] = None,
        evaluate_fn: Optional[Callable] = None,
        transform_fn: Optional[Callable] = None,
        compare_fn: Optional[Callable] = None,
    ) -> OrchestrationResult:
        if mode == OrchestrationMode.HIERARCHICAL:
            return await self._hierarchical.execute(
                task, workers, decompose_fn or self._default_decompose,
                aggregate_fn or self._default_aggregate,
            )
        elif mode == OrchestrationMode.SWARM:
            return await self._swarm.execute(task, workers, evaluate_fn)
        elif mode == OrchestrationMode.PIPELINE:
            return await self._pipeline.execute(task, workers, transform_fn)
        elif mode == OrchestrationMode.CONSENSUS:
            return await self._consensus.execute(task, workers, compare_fn)
        else:
            return OrchestrationResult(
                mode=mode, task_id="error",
                error=f"Unknown mode: {mode}",
            )

    async def _default_decompose(self, task: str, num_workers: int) -> List[str]:
        return [f"Subtask {i+1} of: {task}" for i in range(min(num_workers, 3))]

    async def _default_aggregate(self, task: str, results: List[Any]) -> str:
        return "\n".join(str(r) for r in results)
