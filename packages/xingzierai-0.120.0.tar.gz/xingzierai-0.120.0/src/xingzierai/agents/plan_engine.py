# -*- coding: utf-8 -*-
"""Plan Mode: Automatic task decomposition with progress tracking.

This module provides the PlanEngine class for breaking down complex tasks
into step-by-step plans with real-time progress tracking and automatic
rollback on failure.

Inspired by OpenAkita's Plan Mode.
"""

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class PlanStatus(Enum):
    """Plan execution status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    CANCELLED = "cancelled"


class StepStatus(Enum):
    """Step execution status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class PlanStep:
    """A single step in a plan."""
    step_id: str
    description: str
    status: StepStatus = StepStatus.PENDING
    result: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    dependencies: List[str] = field(default_factory=list)
    checkpoint_id: Optional[str] = None


@dataclass
class Plan:
    """A plan containing multiple steps."""
    plan_id: str
    original_task: str
    steps: List[PlanStep] = field(default_factory=list)
    status: PlanStatus = PlanStatus.PENDING
    current_step_index: int = 0
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    rollback_count: int = 0
    max_rollback: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Checkpoint:
    """A checkpoint for rollback functionality."""
    checkpoint_id: str
    plan_id: str
    step_id: str
    state: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    description: str = ""


class PlanQueue:
    """Manage task queue with overflow protection."""

    MAX_FAILURES = 5
    MAX_TASKS = 1000
    TASK_TTL_SECONDS = 86400  # 24 hours

    def __init__(self) -> None:
        self.tasks: List[Dict[str, Any]] = []
        self.fail_count: int = 0
        self._last_cleanup: float = time.time()


class PlanEngine:
    """
    Plan Mode engine for automatic task decomposition.

    Features:
    - Automatic task decomposition using LLM
    - Step-by-step execution with progress tracking
    - Checkpoint creation before each step
    - Automatic rollback on failure
    - Strategy switching on repeated failures

    Usage:
        engine = PlanEngine(agent=my_agent)
        plan = await engine.create_plan("Build a web scraper")
        result = await engine.execute_plan(plan)
    """

    def __init__(
        self,
        agent: Any,
        max_steps: int = 10,
        max_rollback: int = 3,
        enable_checkpoint: bool = True,
    ):
        """Initialize PlanEngine.

        Args:
            agent: The agent instance for task decomposition and execution.
            max_steps: Maximum number of steps in a plan.
            max_rollback: Maximum number of rollbacks allowed.
            enable_checkpoint: Whether to enable checkpoint/rollback.
        """
        self.agent = agent
        self.max_steps = max_steps
        self.max_rollback = max_rollback
        self.enable_checkpoint = enable_checkpoint

        self.MAX_ACTIVE_PLANS = 100

        self._checkpoints: Dict[str, Checkpoint] = {}
        self._plan_state: Dict[str, Any] = {}
        self._active_plans: Dict[str, Plan] = {}

        self._strategy_switch_count: Dict[str, int] = {}
        self._failed_strategies: Dict[str, Set[str]] = {}

    async def create_plan(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Plan:
        """Create a plan by decomposing a task.

        Args:
            task: The task description to decompose.
            context: Optional context information.

        Returns:
            Plan object with decomposed steps.
        """
        plan_id = f"plan_{uuid.uuid4().hex[:8]}"

        prompt = self._build_decomposition_prompt(task, context)
        response = await self._call_agent(prompt)

        steps = self._parse_steps_from_response(response, task)

        if not steps:
            steps = [
                PlanStep(
                    step_id=f"{plan_id}_step_1",
                    description=task,
                )
            ]

        for i, step in enumerate(steps):
            step.step_id = f"{plan_id}_step_{i + 1}"

        plan = Plan(
            plan_id=plan_id,
            original_task=task,
            steps=steps[:self.max_steps],
        )

        self._active_plans[plan_id] = plan
        self._plan_state[plan_id] = {
            "context": context or {},
            "original_task": task,
        }

        logger.info(f"Created plan {plan_id} with {len(steps)} steps")
        return plan

    def _build_decomposition_prompt(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Build prompt for task decomposition."""
        context_str = ""
        if context:
            context_str = "\n\nContext:\n" + json.dumps(context, ensure_ascii=False, indent=2)

        return f"""You are a task planning assistant. Decompose the following task into clear, actionable steps.

Task: {task}{context_str}

Requirements:
1. Break down into 3-8 logical steps
2. Each step should be independently actionable
3. Include dependencies between steps if any
4. Focus on the essential steps to complete the task

Format your response as a JSON array of step objects:
{{
  "steps": [
    {{
      "description": "Clear description of what to do in this step",
      "dependencies": ["step_id"] // if this step depends on others
    }}
  ]
}}

Respond ONLY with the JSON array, no other text."""

    async def _call_agent(self, prompt: str, max_retries: int = 3) -> str:
        """Call the agent to process a prompt with retry logic."""
        last_error = None
        for attempt in range(max_retries):
            try:
                from xingzierai.agentscope_core.message import Msg

                msg = Msg(
                    name="user",
                    role="user",
                    content=[{"type": "text", "text": prompt}],
                )

                response = await self.agent.reply([msg])

                if hasattr(response, "content"):
                    if isinstance(response.content, list):
                        for block in response.content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                return block.get("text", "")
                        return str(response.content[0]) if response.content else ""
                    return str(response.content)
                return str(response)

            except Exception as e:
                last_error = e
                logger.warning(
                    "Agent call attempt %d/%d failed: %s",
                    attempt + 1,
                    max_retries,
                    e,
                )
                if attempt < max_retries - 1:
                    await asyncio.sleep(1.0 * (attempt + 1))

        logger.error("Agent call failed after %d retries: %s", max_retries, last_error)
        raise last_error

    def _parse_steps_from_response(
        self,
        response: str,
        original_task: str,
    ) -> List[PlanStep]:
        """Parse steps from agent response."""
        import re

        try:
            json_match = re.search(r'\{[\s\S]*"steps"[\s\S]*\}', response)
            if json_match:
                data = json.loads(json_match.group())
                steps = []
                for i, step_data in enumerate(data.get("steps", [])):
                    step = PlanStep(
                        step_id=f"step_{i + 1}",
                        description=step_data.get("description", ""),
                        dependencies=step_data.get("dependencies", []),
                    )
                    steps.append(step)
                return steps
        except json.JSONDecodeError:
            pass

        lines = response.strip().split("\n")
        steps = []
        for i, line in enumerate(lines):
            line = line.strip()
            if line and (line.startswith("-") or line.startswith("*") or line[0].isdigit()):
                desc = re.sub(r'^[-*\d.]+\s*', '', line).strip()
                if desc:
                    steps.append(PlanStep(
                        step_id=f"step_{len(steps) + 1}",
                        description=desc,
                    ))

        return steps[:self.max_steps]

    async def execute_plan(
        self,
        plan: Plan,
        execute_fn: Optional[Callable[[PlanStep], Any]] = None,
        progress_callback: Optional[Callable[[Plan, PlanStep], None]] = None,
    ) -> Plan:
        """Execute a plan with step-by-step execution.

        Args:
            plan: The plan to execute.
            execute_fn: Optional function to execute each step.
                If None, uses the agent directly.
            progress_callback: Optional callback for progress updates.

        Returns:
            The executed plan with results.
        """
        if plan.status == PlanStatus.COMPLETED:
            logger.warning(f"Plan {plan.plan_id} already completed")
            return plan

        plan.status = PlanStatus.IN_PROGRESS
        plan.started_at = time.time()

        logger.info(f"Executing plan {plan.plan_id}: {plan.original_task}")

        while plan.current_step_index < len(plan.steps):
            step = plan.steps[plan.current_step_index]

            if plan.rollback_count >= plan.max_rollback:
                logger.warning(f"Plan {plan.plan_id} exceeded max rollback limit")
                plan.status = PlanStatus.FAILED
                break

            if execute_fn:
                result = await self._execute_step_with_checkpoint(
                    plan, step, execute_fn
                )
            else:
                result = await self._execute_step_direct(plan, step)

            if progress_callback:
                progress_callback(plan, step)

            if step.status == StepStatus.FAILED:
                if self.enable_checkpoint:
                    rollback_success = await self._rollback_to_checkpoint(plan)
                    if not rollback_success:
                        plan.status = PlanStatus.FAILED
                        break
                else:
                    plan.status = PlanStatus.FAILED
                    break
            else:
                plan.current_step_index += 1

        if plan.status == PlanStatus.IN_PROGRESS:
            plan.status = PlanStatus.COMPLETED
            plan.completed_at = time.time()

        logger.info(
            f"Plan {plan.plan_id} {plan.status.value}: "
            f"{plan.current_step_index}/{len(plan.steps)} steps completed"
        )

        self.clear_completed_plans()

        return plan

    async def _execute_step_with_checkpoint(
        self,
        plan: Plan,
        step: PlanStep,
        execute_fn: Callable[[PlanStep], Any],
    ) -> PlanStep:
        """Execute a step with checkpoint support."""
        checkpoint_id = f"cp_{plan.plan_id}_{step.step_id}"
        self._save_checkpoint(
            Checkpoint(
                checkpoint_id=checkpoint_id,
                plan_id=plan.plan_id,
                step_id=step.step_id,
                state=dict(self._plan_state.get(plan.plan_id, {})),
                description=f"Before step: {step.description}",
            )
        )
        step.checkpoint_id = checkpoint_id

        return await self._execute_step_core(plan, step, execute_fn)

    async def _execute_step_direct(
        self,
        plan: Plan,
        step: PlanStep,
    ) -> PlanStep:
        """Execute step directly using the agent."""
        async def default_execute(s: PlanStep) -> str:
            prompt = f"""Execute this step: {s.description}

Original task: {plan.original_task}

Provide the result of completing this step."""
            return await self._call_agent(prompt)

        return await self._execute_step_core(plan, step, default_execute)

    async def _execute_step_core(
        self,
        plan: Plan,
        step: PlanStep,
        execute_fn: Callable[[PlanStep], Any],
    ) -> PlanStep:
        """Core step execution logic."""
        step.status = StepStatus.IN_PROGRESS
        step.started_at = time.time()

        try:
            result = await execute_fn(step)
            step.result = str(result) if result else None
            step.status = StepStatus.COMPLETED
            logger.debug(f"Step {step.step_id} completed: {step.result[:100] if step.result else 'empty'}...")

        except Exception as e:
            step.status = StepStatus.FAILED
            step.error = str(e)
            logger.warning(f"Step {step.step_id} failed: {e}")

            self._strategy_switch_count[plan.plan_id] = \
                self._strategy_switch_count.get(plan.plan_id, 0) + 1

        finally:
            step.completed_at = time.time()

        return step

    def _save_checkpoint(self, checkpoint: Checkpoint) -> None:
        """Save a checkpoint."""
        self._checkpoints[checkpoint.checkpoint_id] = checkpoint
        logger.debug(f"Saved checkpoint {checkpoint.checkpoint_id}")

    async def _rollback_to_checkpoint(self, plan: Plan) -> bool:
        """Rollback plan to last checkpoint."""
        if not self.enable_checkpoint:
            return False

        plan.rollback_count += 1
        logger.info(
            f"Rolling back plan {plan.plan_id} "
            f"(attempt {plan.rollback_count}/{plan.max_rollback})"
        )

        checkpoints = [
            cp for cp in self._checkpoints.values()
            if cp.plan_id == plan.plan_id
        ]

        if not checkpoints:
            logger.warning(f"No checkpoints found for plan {plan.plan_id}")
            return False

        checkpoints.sort(key=lambda x: x.timestamp, reverse=True)
        last_checkpoint = checkpoints[0]

        self._plan_state[plan.plan_id] = last_checkpoint.state

        target_step_index = 0
        for i, step in enumerate(plan.steps):
            if step.step_id == last_checkpoint.step_id:
                target_step_index = i
                break

        for i in range(target_step_index, len(plan.steps)):
            step = plan.steps[i]
            if step.status == StepStatus.COMPLETED:
                step.status = StepStatus.PENDING
                step.result = None

        plan.current_step_index = target_step_index
        plan.status = PlanStatus.IN_PROGRESS

        logger.info(
            f"Rolled back to checkpoint {last_checkpoint.checkpoint_id}, "
            f"resuming at step {plan.current_step_index}"
        )

        return True

    def get_plan_progress(self, plan: Plan) -> Dict[str, Any]:
        """Get plan progress information.

        Returns:
            Dict with progress details.
        """
        completed = sum(
            1 for s in plan.steps if s.status == StepStatus.COMPLETED
        )
        failed = sum(1 for s in plan.steps if s.status == StepStatus.FAILED)

        return {
            "plan_id": plan.plan_id,
            "status": plan.status.value,
            "total_steps": len(plan.steps),
            "completed_steps": completed,
            "failed_steps": failed,
            "current_step": plan.current_step_index,
            "progress_percent": (
                (completed / len(plan.steps) * 100)
                if plan.steps else 0
            ),
            "rollback_count": plan.rollback_count,
            "elapsed_time": (
                (plan.completed_at or time.time()) - plan.started_at
            ) if plan.started_at else 0,
        }

    def cancel_plan(self, plan: Plan) -> Plan:
        """Cancel a running plan.

        Args:
            plan: The plan to cancel.

        Returns:
            The cancelled plan.
        """
        if plan.status == PlanStatus.IN_PROGRESS:
            plan.status = PlanStatus.CANCELLED
            plan.completed_at = time.time()
            logger.info(f"Plan {plan.plan_id} cancelled")

        return plan

    def get_active_plan(self, plan_id: str) -> Optional[Plan]:
        """Get an active plan by ID."""
        return self._active_plans.get(plan_id)

    def list_active_plans(self) -> List[Plan]:
        """List all active plans."""
        return [
            p for p in self._active_plans.values()
            if p.status == PlanStatus.IN_PROGRESS
        ]

    def clear_completed_plans(self) -> int:
        """Clear completed/failed plans from memory.

        Returns:
            Number of plans cleared.
        """
        to_remove = [
            pid for pid, p in self._active_plans.items()
            if p.status in (
                PlanStatus.COMPLETED,
                PlanStatus.FAILED,
                PlanStatus.CANCELLED,
                PlanStatus.ROLLED_BACK,
            )
        ]

        for pid in to_remove:
            del self._active_plans[pid]
            self._plan_state.pop(pid, None)
            self._strategy_switch_count.pop(pid, None)
            self._failed_strategies.pop(pid, None)

        checkpoints_to_remove = [
            cp_id for cp_id, cp in self._checkpoints.items()
            if cp.plan_id in to_remove
        ]
        for cp_id in checkpoints_to_remove:
            del self._checkpoints[cp_id]

        if len(self._active_plans) > self.MAX_ACTIVE_PLANS:
            excess = sorted(
                self._active_plans.items(),
                key=lambda x: x[1].created_at,
            )[:len(self._active_plans) - self.MAX_ACTIVE_PLANS]
            for pid, _ in excess:
                del self._active_plans[pid]
                self._plan_state.pop(pid, None)
                self._strategy_switch_count.pop(pid, None)
                self._failed_strategies.pop(pid, None)
            logger.warning(f"PlanEngine evicted {len(excess)} excess active plans")

        return len(to_remove)


class PlanModeMixin:
    """
    Mixin class to add Plan Mode capability to an agent.

    Usage:
        class MyAgent(PlanModeMixin, ReActAgent):
            def __init__(self, ...):
                super().__init__(...)
                self._init_plan_mode()
    """

    def _init_plan_mode(
        self,
        max_steps: int = 10,
        max_rollback: int = 3,
        enable_checkpoint: bool = True,
    ) -> None:
        """Initialize Plan Mode components.

        Args:
            max_steps: Maximum steps per plan.
            max_rollback: Maximum rollback attempts.
            enable_checkpoint: Enable checkpoint/rollback.
        """
        self.plan_engine = PlanEngine(
            agent=self,
            max_steps=max_steps,
            max_rollback=max_rollback,
            enable_checkpoint=enable_checkpoint,
        )
        self._plan_mode_enabled = True
        self._current_plan: Optional[Plan] = None

    async def create_and_execute_plan(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
        progress_callback: Optional[Callable[[Plan, PlanStep], None]] = None,
    ) -> Plan:
        """Create and execute a plan for a complex task.

        Args:
            task: The task to plan and execute.
            context: Optional context information.
            progress_callback: Optional progress callback.

        Returns:
            The executed plan.
        """
        if not getattr(self, "_plan_mode_enabled", False):
            raise RuntimeError("Plan mode not initialized")

        self._current_plan = await self.plan_engine.create_plan(task, context)
        return await self.plan_engine.execute_plan(
            self._current_plan,
            progress_callback=progress_callback,
        )

    def get_current_plan(self) -> Optional[Plan]:
        """Get the current active plan."""
        return self._current_plan

    def cancel_current_plan(self) -> Optional[Plan]:
        """Cancel the current plan if running."""
        if self._current_plan:
            return self.plan_engine.cancel_plan(self._current_plan)
        return None


__all__ = [
    "PlanEngine",
    "PlanModeMixin",
    "Plan",
    "PlanStep",
    "PlanStatus",
    "StepStatus",
    "Checkpoint",
]
