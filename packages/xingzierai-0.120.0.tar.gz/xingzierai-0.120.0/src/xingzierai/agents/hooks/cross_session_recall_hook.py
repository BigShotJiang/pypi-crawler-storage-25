# -*- coding: utf-8 -*-
"""Cross-session memory recall hook for pre-reasoning memory injection.

Extracted from react_agent.py reply() method to comply with architecture rule:
"不能写具体业务逻辑 in react_agent.py"

This hook:
1. Reads cross-session memory context via CrossSessionMemory
2. Searches MDRM cone graph memories
3. Formats memory bundles into injectable context
4. Returns memory_context string for system prompt injection
"""
import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class CrossSessionRecallHook:
    """Pre-reasoning hook for cross-session memory recall and MDRM search.

    Returns a dict with 'memory_context' key for system prompt injection.
    """

    def __init__(self, max_entries: int = 3, max_mdrm_results: int = 2, min_tier: int = 2, min_strength: float = 0.3):
        self.max_entries = max_entries
        self.max_mdrm_results = max_mdrm_results
        self.min_tier = min_tier
        self.min_strength = min_strength

    async def __call__(
        self,
        agent,
        kwargs: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        query = self._extract_query(agent, kwargs)
        if not query:
            return None

        memory_context = ""
        bundles: List[Dict] = []

        try:
            from ..cross_session_memory import CrossSessionMemory, MemoryType, MemoryScope

            session_id = getattr(agent, '_request_context', {}).get("session_id", "")
            agent_id = getattr(agent, '_request_context', {}).get("agent_id", "")
            csm = CrossSessionMemory.get_instance()

            async def _read_cross_session():
                try:
                    return await csm.get_context(
                        current_query=query,
                        agent_id=agent_id,
                        session_id=session_id,
                        max_entries=self.max_entries,
                        min_tier=self.min_tier,
                        min_strength=self.min_strength,
                    )
                except Exception as _csm_read_err:
                    logger.debug("Cross-session memory read failed: %s", _csm_read_err)
                    return ""

            async def _search_mdrm():
                mdrm_hook = getattr(agent, '_mdrm_hook', None)
                if not mdrm_hook or not query:
                    return []
                try:
                    return await mdrm_hook.search_memories(
                        query=query,
                        max_results=self.max_mdrm_results,
                        use_graph_route=True,
                    )
                except Exception as _mdrm_search_err:
                    logger.debug("MDRM memory search failed: %s", _mdrm_search_err)
                    return []

            past_context, bundles = await asyncio.gather(
                _read_cross_session(),
                _search_mdrm(),
            )

            if past_context:
                memory_context += "\n\n【跨会话记忆】以下是来自其他会话的相关记忆：\n" + past_context
        except Exception as e:
            logger.debug("Cross-session memory read failed: %s", e)
            bundles = []

        if bundles:
            memory_parts = []
            for i, bundle in enumerate(bundles, 1):
                ep = bundle.get("episode", {})
                ep_content = ep.get("content", "")
                if not ep_content:
                    continue
                points = bundle.get("facet_points", [])
                point_texts = [p.get("content", "") for p in points[:3] if p.get("content")]
                memory_parts.append(
                    f"[记忆{i}] {ep_content}"
                    + (" " + "; ".join(point_texts) if point_texts else "")
                )
            if memory_parts:
                memory_context = (
                    "\n\n【相关记忆】以下是与用户问题相关的历史记忆，"
                    "回答时可参考：\n"
                    + "\n".join(memory_parts)
                )
                logger.info(
                    "Recalled %d memory bundles for query: %s",
                    len(bundles),
                    query[:50],
                )

        if memory_context:
            return {"memory_context": memory_context}
        return None

    def _extract_query(self, agent, kwargs: Any) -> Optional[str]:
        msg = kwargs.get("msg")
        if msg is None:
            return None
        last_msg = msg[-1] if isinstance(msg, list) else msg
        from xingzierai.agentscope_core.message import Msg
        if isinstance(last_msg, Msg):
            return last_msg.get_text_content()
        return None
