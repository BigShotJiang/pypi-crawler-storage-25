EXTRACTION_PROMPT = """Analyze the following conversation and extract structured memories.

Organize the extraction as a Cone Graph with these layers:
1. Episode: A bounded semantic focus - an incident, decision process, or workflow (1 per conversation turn)
2. Facet: One dimension of that Episode - a topical cross-section (1-3 per Episode)
3. FacetPoint: An atomic assertion or fact derived from a Facet (1-3 per Facet)
4. Entity: Named things - people, tools, metrics - that appear across layers

Conversation:
{conversation}

Respond in JSON format:
{{
  "episode": {{
    "title": "Brief title for this conversation turn",
    "summary": "Concise summary of what happened",
    "type": "event|decision|fact|goal"
  }},
  "facets": [
    {{
      "title": "Dimension name",
      "summary": "What this dimension covers"
    }}
  ],
  "facet_points": [
    {{
      "facet_index": 0,
      "content": "Atomic fact or assertion",
      "entities": ["entity_name"]
    }}
  ],
  "entities": [
    {{
      "name": "Entity name",
      "type": "person|tool|metric|place|other"
    }}
  ],
  "relationships": [
    {{
      "from": "episode|facet_N|point_N|entity_N",
      "to": "episode|facet_N|point_N|entity_N",
      "relation": "contains|has_facet|has_point|mentions|causes|depends_on|related_to",
      "edge_text": "Natural language description of this relationship"
    }}
  ]
}}

Only include significant information. If nothing important, return empty structures."""
