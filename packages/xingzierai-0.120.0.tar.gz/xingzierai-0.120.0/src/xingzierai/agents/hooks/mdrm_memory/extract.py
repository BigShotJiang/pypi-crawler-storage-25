import json
import logging
from typing import Any, AsyncGenerator, Dict, List, Optional

from .extraction import EXTRACTION_PROMPT

logger = logging.getLogger(__name__)


async def extract_cone_graph(conversation: str, chat_model) -> Optional[Dict[str, Any]]:
    if not chat_model:
        return None

    try:
        prompt = EXTRACTION_PROMPT.format(conversation=conversation)
        messages = [
            {"role": "system", "content": "You are a structured memory extraction assistant."},
            {"role": "user", "content": prompt},
        ]

        response = await chat_model(messages, temperature=0.3, max_tokens=3000)

        if isinstance(response, AsyncGenerator):
            chunks = []
            async for chunk in response:
                if hasattr(chunk, 'content') and chunk.content:
                    for block in chunk.content:
                        if hasattr(block, 'text') and block.text:
                            chunks.append(block.text)
            content = "".join(chunks)
        elif hasattr(response, 'content'):
            content = ""
            for block in response.content:
                if hasattr(block, 'text') and block.text:
                    content += block.text
        elif isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = str(response) if response else ""

        if not content:
            logger.debug("MDRM hook: extraction returned empty content")
            return None

        json_start = content.find("{")
        json_end = content.rfind("}")
        if json_start == -1 or json_end == -1:
            logger.debug("MDRM hook: no JSON found in extraction response")
            return None

        json_str = content[json_start:json_end + 1]
        result = json.loads(json_str)

        logger.info(f"MDRM hook: extracted cone graph with episode='{result.get('episode', {}).get('title', 'N/A')}'")
        return result

    except json.JSONDecodeError as e:
        logger.warning(f"MDRM hook: failed to parse extraction JSON: {e}")
        return None
    except Exception as e:
        logger.error(f"MDRM hook: error extracting memories: {e}")
        return None
