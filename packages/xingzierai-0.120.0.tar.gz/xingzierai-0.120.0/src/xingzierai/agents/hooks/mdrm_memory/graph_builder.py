import logging
from datetime import datetime
from typing import Any, Dict, List

from xingzierai.memory.mdrm import (
    MDRMGraph,
    MDRMNode,
    MDRMEdge,
    MDRMNodeType,
    MDRMConeLayer,
    MDRMRelationType,
    MDRMStore,
)

logger = logging.getLogger(__name__)


def _create_episode_node(episode_data: Dict, context_messages: List) -> MDRMNode:
    return MDRMNode(
        node_type=MDRMNodeType(episode_data.get("type", "event")),
        cone_layer=MDRMConeLayer.EPISODE,
        content=episode_data.get("summary", ""),
        metadata={
            "title": episode_data.get("title", ""),
            "context_message_count": len(context_messages),
            "extracted_at": datetime.now().isoformat(),
        },
        confidence=0.9,
    )


def _create_facet_nodes(facets_data: List, episode: MDRMNode, episode_title: str, graph: MDRMGraph, node_refs: Dict) -> None:
    for idx, facet_data in enumerate(facets_data):
        facet = MDRMNode(
            node_type=MDRMNodeType.FACT,
            cone_layer=MDRMConeLayer.FACET,
            content=facet_data.get("summary", ""),
            metadata={"title": facet_data.get("title", ""), "facet_index": idx},
            confidence=0.8,
        )
        graph.add_node(facet)
        node_refs[f"facet_{idx}"] = facet

        edge = MDRMEdge(
            source_id=episode.id,
            target_id=facet.id,
            relation_type=MDRMRelationType.HAS_FACET,
            edge_text=f"Episode '{episode_title}' has facet '{facet_data.get('title', '')}'",
            weight=2.0,
        )
        graph.add_edge(edge)


def _create_facet_point_nodes(points_data: List, node_refs: Dict, graph: MDRMGraph) -> None:
    for idx, point_data in enumerate(points_data):
        facet_idx = point_data.get("facet_index", 0)
        point = MDRMNode(
            node_type=MDRMNodeType.FACT,
            cone_layer=MDRMConeLayer.FACET_POINT,
            content=point_data.get("content", ""),
            metadata={"facet_index": facet_idx, "entities": point_data.get("entities", [])},
            confidence=0.95,
        )
        graph.add_node(point)
        node_refs[f"point_{idx}"] = point

        facet_key = f"facet_{facet_idx}"
        if facet_key in node_refs:
            edge = MDRMEdge(
                source_id=node_refs[facet_key].id,
                target_id=point.id,
                relation_type=MDRMRelationType.HAS_POINT,
                edge_text=f"Facet contains atomic point: {point.content[:50]}...",
                weight=3.0,
            )
            graph.add_edge(edge)


def _create_entity_nodes(entities_data: List, node_refs: Dict, graph: MDRMGraph) -> None:
    for idx, entity_data in enumerate(entities_data):
        entity_name = entity_data.get("name", "")
        existing = None
        for node in graph.nodes.values():
            if node.cone_layer == MDRMConeLayer.ENTITY and node.content == entity_name:
                existing = node
                break

        if existing:
            node_refs[f"entity_{idx}"] = existing
        else:
            entity = MDRMNode(
                node_type=MDRMNodeType.FACT,
                cone_layer=MDRMConeLayer.ENTITY,
                content=entity_name,
                metadata={"entity_type": entity_data.get("type", "other")},
                confidence=1.0,
            )
            graph.add_node(entity)
            node_refs[f"entity_{idx}"] = entity


def _create_relationship_edges(relationships_data: List, node_refs: Dict, graph: MDRMGraph) -> None:
    for rel_data in relationships_data:
        from_key = rel_data.get("from", "")
        to_key = rel_data.get("to", "")
        if from_key in node_refs and to_key in node_refs:
            try:
                relation_type = MDRMRelationType(rel_data.get("relation", "related_to"))
            except ValueError:
                relation_type = MDRMRelationType.RELATED_TO

            edge = MDRMEdge(
                source_id=node_refs[from_key].id,
                target_id=node_refs[to_key].id,
                relation_type=relation_type,
                edge_text=rel_data.get("edge_text", ""),
                weight=2.0,
                metadata={"auto_extracted": True},
            )
            graph.add_edge(edge)


async def store_cone_graph(graph: MDRMGraph, extraction_result: Dict, context_messages: List, store) -> None:
    if not graph:
        return

    episode_data = extraction_result.get("episode")
    if not episode_data:
        return

    node_refs: Dict[str, MDRMNode] = {}

    episode = _create_episode_node(episode_data, context_messages)
    graph.add_node(episode)
    node_refs["episode"] = episode
    logger.info(f"Added Episode: {episode.content[:50]}...")

    _create_facet_nodes(extraction_result.get("facets", []), episode, episode_data.get("title", ""), graph, node_refs)
    _create_facet_point_nodes(extraction_result.get("facet_points", []), node_refs, graph)
    _create_entity_nodes(extraction_result.get("entities", []), node_refs, graph)
    _create_relationship_edges(extraction_result.get("relationships", []), node_refs, graph)

    await connect_similar_memories(graph, {k: v for k, v in node_refs.items() if not k.startswith("entity_")})
    await store.save_graph(graph)

    logger.info(f"Stored Cone Graph: 1 Episode, {len(extraction_result.get('facets', []))} Facets, {len(extraction_result.get('facet_points', []))} Points, {len(extraction_result.get('entities', []))} Entities")


async def connect_similar_memories(graph: MDRMGraph, new_nodes: Dict[str, MDRMNode]) -> None:
    if not graph:
        return

    for new_node in new_nodes.values():
        for existing_id, existing_node in graph.nodes.items():
            if existing_id == new_node.id:
                continue

            new_words = set(new_node.content.lower().split())
            existing_words = set(existing_node.content.lower().split())
            common_words = new_words & existing_words

            if len(common_words) >= 3:
                similarity = len(common_words) / max(len(new_words), len(existing_words))
                if similarity >= 0.3:
                    edge = MDRMEdge(
                        source_id=new_node.id,
                        target_id=existing_id,
                        relation_type=MDRMRelationType.RELATED_TO,
                        edge_text=f"Similar content: shares {', '.join(list(common_words)[:3])}",
                        weight=similarity * 10,
                        metadata={"auto_extracted": True, "similarity": similarity, "common_words": list(common_words)[:5]},
                    )
                    graph.add_edge(edge)
