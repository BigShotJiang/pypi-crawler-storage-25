try:
    from xingzierai.agents.model_factory import create_model_and_formatter
    def load_chat_model():
        try:
            model, formatter = create_model_and_formatter()
            return model
        except Exception:
            return None
except ImportError:
    def load_chat_model():
        return None
