import logging
from typing import Any, Dict, List, Optional

from xingzierai.memory.mdrm import MDRMGraph, MDRMStore

from .extract import extract_cone_graph
from .graph_builder import store_cone_graph
from .retrieval import search_memories as _search_memories
from .text_utils import build_conversation_text, get_memory_stats

logger = logging.getLogger(__name__)


class MDRMMemoryHook:
    def __init__(
        self,
        agent_id: str,
        graph_name: Optional[str] = None,
        extract_interval: int = 5,
        max_nodes: int = 500,
        store_backend: str = "sqlite",
        store_path: Optional[str] = None,
    ):
        self.agent_id = agent_id
        self.graph_name = graph_name or f"agent_{agent_id}_memory"
        self.extract_interval = extract_interval
        self.max_nodes = max_nodes
        self.store_backend = store_backend
        self.store_path = store_path

        self._graph: Optional[MDRMGraph] = None
        self._store: Optional[MDRMStore] = None
        self._chat_model = None
        self._turn_count = 0
        self._initialized = False

    async def _initialize(self) -> bool:
        if self._initialized:
            return True

        try:
            self._store = MDRMStore(
                backend=self.store_backend,
                path=self.store_path,
                graph_name=self.graph_name,
            )
            self._graph = await self._store.load_graph(self.graph_name)

            if not self._graph:
                self._graph = MDRMGraph(name=self.graph_name)

            from xingzierai.agents.hooks.mdrm_memory._model_loader import load_chat_model
            self._chat_model = load_chat_model()

            self._initialized = True
            logger.info(f"MDRMMemoryHook initialized: graph={self.graph_name}, nodes={len(self._graph.nodes)}")
            return True

        except Exception as e:
            logger.error(f"MDRMMemoryHook initialization failed: {e}")
            return False

    async def __call__(self, agent, kwargs, output=None):
        if not await self._initialize():
            return None

        messages = kwargs.get("messages", [])
        if not messages:
            return None

        self._turn_count += 1
        if self._turn_count % self.extract_interval != 0:
            return None

        if len(self._graph.nodes) >= self.max_nodes:
            logger.info(f"MDRM hook: max nodes reached ({self.max_nodes}), skipping extraction")
            return None

        conversation = build_conversation_text(messages)
        if not conversation.strip():
            return None

        result = await extract_cone_graph(conversation, self._chat_model)
        if result:
            await store_cone_graph(self._graph, result, messages, self._store)
            logger.info(f"MDRM hook: stored extraction for turn {self._turn_count}")

        return None

    async def search_memories(self, query: str, max_results: int = 5, use_graph_route: bool = True) -> List[Dict[str, Any]]:
        if not await self._initialize() or not self._graph:
            return []
        return await _search_memories(self._graph, query, max_results, use_graph_route)

    def get_stats(self) -> Dict[str, Any]:
        return get_memory_stats(self._graph, self.graph_name)
