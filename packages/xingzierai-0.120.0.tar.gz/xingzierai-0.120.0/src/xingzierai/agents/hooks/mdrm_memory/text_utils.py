from typing import Any, Dict, List

from xingzierai.memory.mdrm import MDRMGraph


def build_conversation_text(messages: List[Any]) -> str:
    lines = []
    for msg in messages:
        if isinstance(msg, dict):
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
        else:
            role = getattr(msg, "role", "unknown")
            content = getattr(msg, "content", "")

        if isinstance(content, list):
            text_parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
                elif isinstance(block, dict):
                    text_parts.append(block.get("text", ""))
            content = " ".join(text_parts)

        if content:
            lines.append(f"{role.upper()}: {content[:500]}")

    return "\n\n".join(lines)


def get_memory_stats(graph: MDRMGraph, graph_name: str) -> Dict[str, Any]:
    if not graph:
        return {"initialized": False}

    node_types = {}
    cone_layers = {}
    for node in graph.nodes.values():
        t = node.node_type.value
        node_types[t] = node_types.get(t, 0) + 1
        cl = node.cone_layer.value
        cone_layers[cl] = cone_layers.get(cl, 0) + 1

    return {
        "initialized": True,
        "graph_name": graph_name,
        "total_nodes": len(graph.nodes),
        "total_edges": len(graph.edges),
        "node_types": node_types,
        "cone_layers": cone_layers,
    }
