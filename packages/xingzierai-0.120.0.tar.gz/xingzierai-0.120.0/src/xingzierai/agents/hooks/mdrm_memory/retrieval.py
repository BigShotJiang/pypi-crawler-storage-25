import logging
from typing import Any, Dict, List

from xingzierai.memory.mdrm import MDRMGraph, GraphRouter

logger = logging.getLogger(__name__)


async def search_memories(
    graph: MDRMGraph,
    query: str,
    max_results: int = 5,
    use_graph_route: bool = True,
) -> List[Dict[str, Any]]:
    if not graph:
        return []

    if use_graph_route and len(graph.nodes) > 5:
        router = GraphRouter(graph)
        bundles = router.route_search(query, top_k=max_results)
        return [bundle.to_dict() for bundle in bundles]

    return _keyword_search(graph, query, max_results)


def _keyword_search(graph: MDRMGraph, query: str, max_results: int) -> List[Dict[str, Any]]:
    query_lower = query.lower()
    query_words = set(query_lower.split())
    results = []

    for node_id, node in graph.nodes.items():
        content_lower = node.content.lower()
        score = 0.0

        if query_lower in content_lower:
            score += 2.0

        content_words = set(content_lower.split())
        common = query_words & content_words
        score += len(common) * 0.5

        if any(word in content_lower for word in ["decided", "decision", "决定"]):
            if "decision" in query_lower or "决定" in query_lower:
                score += 0.5

        if score > 0:
            neighbors = graph.get_neighbors(node_id)
            neighbor_contents = [n.content for n in neighbors[:3]]
            results.append({
                "id": node_id,
                "content": node.content,
                "type": node.node_type.value,
                "cone_layer": node.cone_layer.value,
                "score": score,
                "confidence": node.confidence,
                "related": neighbor_contents,
                "created_at": node.created_at,
            })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:max_results]
