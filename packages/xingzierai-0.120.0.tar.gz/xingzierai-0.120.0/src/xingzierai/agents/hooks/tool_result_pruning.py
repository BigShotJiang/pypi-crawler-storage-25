# -*- coding: utf-8 -*-
"""Post-acting hook for tool result pruning.

Ported from QwenPaw's LightContextManager._prune_tool_result().

This hook runs after every tool call (_acting) to immediately truncate
large tool results, keeping the context lean. Without this, tool outputs
accumulate in full size and cause context overflow after just a few rounds.

Key design (from QwenPaw):
- Recent tool results (last N) keep more bytes
- Older tool results are aggressively truncated to old_max_bytes
- Truncated content is saved to disk files with a reference path
- Exempt tools (e.g., read_file for certain extensions) keep full content
"""
from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

from xingzierai.agentscope_core.agent import ReActAgent
from xingzierai.agentscope_core.message import Msg

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

DEFAULT_RECENT_MAX_BYTES = 20000
DEFAULT_OLD_MAX_BYTES = 3000
DEFAULT_RECENT_N = 2
TRUNCATION_MARKER = "... [truncated"

DEFAULT_EXEMPT_TOOL_NAMES: frozenset[str] = frozenset()
DEFAULT_EXEMPT_FILE_EXTENSIONS: frozenset[str] = frozenset(
    [".md", ".txt", ".py", ".json", ".yaml", ".yml", ".toml"],
)

_tool_result_cache_dir: Path | None = None


def _get_tool_result_cache_dir() -> Path:
    global _tool_result_cache_dir
    if _tool_result_cache_dir is None:
        _tool_result_cache_dir = Path.home() / ".xingzierai" / "tool_results_cache"
        _tool_result_cache_dir.mkdir(parents=True, exist_ok=True)
    return _tool_result_cache_dir


def _truncate_content(content: str, max_bytes: int, file_path: str | None = None) -> str:
    if not content:
        return content

    try:
        content_bytes = len(content.encode("utf-8"))
    except UnicodeEncodeError:
        return content

    if content_bytes <= max_bytes + 100:
        return content

    if TRUNCATION_MARKER in content:
        if content_bytes <= max_bytes + 100:
            return content
        truncated = content[:max_bytes]
    else:
        if file_path is None:
            cache_dir = _get_tool_result_cache_dir()
            try:
                fp = cache_dir / f"{uuid.uuid4().hex}.txt"
                fp.write_text(content, encoding="utf-8")
                file_path = str(fp)
            except OSError as e:
                logger.warning("Failed to save truncated content to file: %s", e)
                file_path = None

        truncated = content[:max_bytes]

    notice = f"\n{TRUNCATION_MARKER}, {content_bytes} bytes -> {max_bytes} bytes]"
    if file_path:
        notice += f"\nFull content saved to: {file_path}"
    return truncated + notice


class ToolResultPruningHook:
    """Post-acting hook that prunes large tool results immediately.

    Ported from QwenPaw's LightContextManager._prune_tool_result().

    Key improvements:
    - Exempt tool names: certain tools (e.g., read_file for code) keep
      full content to avoid losing important context
    - Exempt file extensions: read_file calls for certain extensions
      (e.g., .md, .py) are not truncated
    - File offloading: truncated content is saved to disk with a
      reference path, so the agent can still access it if needed
    """

    def __init__(
        self,
        recent_max_bytes: int = DEFAULT_RECENT_MAX_BYTES,
        old_max_bytes: int = DEFAULT_OLD_MAX_BYTES,
        recent_n: int = DEFAULT_RECENT_N,
        exempt_tool_names: frozenset[str] | None = None,
        exempt_file_extensions: frozenset[str] | None = None,
    ):
        self.recent_max_bytes = recent_max_bytes
        self.old_max_bytes = old_max_bytes
        self.recent_n = recent_n
        self.exempt_tool_names = exempt_tool_names or DEFAULT_EXEMPT_TOOL_NAMES
        self.exempt_file_extensions = exempt_file_extensions or DEFAULT_EXEMPT_FILE_EXTENSIONS

    async def __call__(
        self,
        agent: ReActAgent,
        kwargs: dict[str, Any],
        output: Any = None,
    ) -> dict[str, Any] | None:
        messages = agent.memory.content
        if not messages:
            return None

        pruned = self._prune_tool_results(messages)
        if pruned > 0:
            logger.debug("ToolResultPruningHook: pruned %d tool result blocks", pruned)

        return None

    def _detect_exempt_tool_ids(self, messages: list) -> set[str]:
        """Detect tool_use IDs that should be exempt from pruning.

        Ported from QwenPaw's LightContextManager._prune_tool_result().
        Tools in exempt_tool_names and read_file for exempt file
        extensions are not truncated.
        """
        exempt_ids: set[str] = set()

        for msg in messages:
            content = getattr(msg, "content", None)
            if not isinstance(content, list):
                continue

            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_use":
                    continue

                tool_id = block.get("id", "")
                if not tool_id:
                    continue

                tool_name = block.get("name", "").lower()
                if tool_name in self.exempt_tool_names:
                    exempt_ids.add(tool_id)
                    continue

                if tool_name == "read_file":
                    raw_input = (block.get("raw_input") or "").lower()
                    for ext in self.exempt_file_extensions:
                        if ext in raw_input:
                            exempt_ids.add(tool_id)
                            break

        return exempt_ids

    def _prune_tool_results(self, messages: list) -> int:
        if not messages:
            return 0

        recent_count = 0
        for msg in reversed(messages):
            content = getattr(msg, "content", None)
            if not isinstance(content, list):
                break
            has_tool_result = any(
                isinstance(b, dict) and b.get("type") == "tool_result"
                for b in content
            )
            if not has_tool_result:
                break
            recent_count += 1

        split_index = max(0, len(messages) - max(recent_count, self.recent_n))

        exempt_ids = self._detect_exempt_tool_ids(messages)

        pruned = 0
        for idx, msg in enumerate(messages):
            content = getattr(msg, "content", None)
            if not isinstance(content, list):
                continue

            is_recent = idx >= split_index

            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_result":
                    continue

                tool_id = block.get("id", "")
                if tool_id in exempt_ids:
                    max_bytes = self.recent_max_bytes
                else:
                    max_bytes = self.recent_max_bytes if is_recent else self.old_max_bytes

                output = block.get("output")
                if not output:
                    continue

                if isinstance(output, str):
                    original_len = len(output)
                    truncated = _truncate_content(output, max_bytes)
                    if len(truncated) < original_len:
                        block["output"] = truncated
                        pruned += 1
                elif isinstance(output, list):
                    for sub in output:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            text = sub.get("text", "")
                            original_len = len(text)
                            truncated = _truncate_content(text, max_bytes)
                            if len(truncated) < original_len:
                                sub["text"] = truncated
                                pruned += 1

        return pruned
