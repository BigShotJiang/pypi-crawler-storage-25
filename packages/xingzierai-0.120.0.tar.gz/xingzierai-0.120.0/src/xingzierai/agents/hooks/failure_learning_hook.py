# -*- coding: utf-8 -*-
"""Failure learning hook for automatic KappaEngine reflection.

When a tool call fails, this hook automatically triggers KappaEngine
reflection to extract structured experience from the failure.

This closes the loop: tool failure → signal detection → Kappa reflection
→ experience pack creation → future failure avoidance.
"""
import asyncio
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class FailureLearningHook:
    """Post-acting hook that captures tool failures and feeds them to KappaEngine.

    Registered as a post-acting hook on XingzierAIAgent, it inspects
    tool call results for failure signals and triggers asynchronous
    KappaEngine reflection when failures are detected.

    This creates an automatic learning loop:
        Tool Failure → KappaEngine.reflect_and_create() → ExperiencePack
        → Future find_relevant() → Failure Avoidance
    """

    FAILURE_INDICATORS = [
        "error", "failed", "exception", "traceback",
        "错误", "失败", "异常", "超时",
    ]

    def __init__(self, min_error_length: int = 10):
        self._min_error_length = min_error_length

    async def __call__(
        self,
        agent,
        kwargs: Dict[str, Any],
        output: Any = None,
    ) -> None:
        tool_call = kwargs.get("tool_call", {})
        tool_name = tool_call.get("name", "") if isinstance(tool_call, dict) else ""
        tool_args = tool_call.get("arguments", {}) if isinstance(tool_call, dict) else {}

        if not tool_name:
            return None

        error_text = self._extract_error_text(output)
        if not error_text:
            return None

        task_desc = self._build_task_description(tool_name, tool_args)

        try:
            from ..evolution.kappa import KappaEngine
            from ..evolution.signal_detector import SignalDetector

            detector = SignalDetector()
            signal = detector.detect_failure(error_text, context={"tool": tool_name})
            if signal is None:
                return None

            kappa = KappaEngine.get_instance()
            if kappa is None:
                return None

            async def _reflect():
                try:
                    await kappa.reflect_and_create(
                        task=task_desc,
                        error=error_text[:2000],
                        context={"tool_name": tool_name, "signal_severity": signal.severity.value},
                    )
                    logger.info(
                        "FailureLearningHook: triggered Kappa reflection for tool %s failure",
                        tool_name,
                    )
                except Exception as e:
                    logger.debug("Kappa reflection failed: %s", e)

            _task = asyncio.create_task(_reflect())
            if not hasattr(agent, '_background_tasks'):
                agent._background_tasks = set()
            agent._background_tasks.add(_task)
            _task.add_done_callback(agent._background_tasks.discard)

        except Exception as e:
            logger.debug("FailureLearningHook failed: %s", e)

        return None

    def _extract_error_text(self, output: Any) -> Optional[str]:
        if output is None:
            return None

        text = ""
        if isinstance(output, dict):
            text = output.get("content", "") or output.get("error", "") or str(output)
        elif hasattr(output, "get_text_content"):
            text = output.get_text_content() or ""
        else:
            text = str(output)

        if len(text) < self._min_error_length:
            return None

        text_lower = text.lower()
        if any(indicator in text_lower for indicator in self.FAILURE_INDICATORS):
            return text[:2000]

        return None

    def _build_task_description(self, tool_name: str, tool_args: Dict) -> str:
        args_summary = ""
        if isinstance(tool_args, dict):
            parts = []
            for k, v in list(tool_args.items())[:3]:
                parts.append(f"{k}={str(v)[:100]}")
            args_summary = ", ".join(parts)
        return f"Execute tool {tool_name}({args_summary})" if args_summary else f"Execute tool {tool_name}"
