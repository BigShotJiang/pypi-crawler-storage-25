# -*- coding: utf-8 -*-
"""Agent hooks package.

This package provides hook implementations for XingzierAIAgent that follow
AgentScope's hook interface (any Callable).

Available Hooks:
    - BootstrapHook: First-time setup guidance
    - MemoryCompactionHook: Automatic context window management
    - MDRMMemoryHook: Automatic structured memory extraction and storage
    - FailureLearningHook: Automatic Kappa reflection on tool failures
"""

from .bootstrap import BootstrapHook
from .memory_compaction import MemoryCompactionHook
from .mdrm_memory import MDRMMemoryHook
from .failure_learning_hook import FailureLearningHook

__all__ = [
    "BootstrapHook",
    "MemoryCompactionHook",
    "MDRMMemoryHook",
    "FailureLearningHook",
]
