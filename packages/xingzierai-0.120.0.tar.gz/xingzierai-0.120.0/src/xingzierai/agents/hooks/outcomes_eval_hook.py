# -*- coding: utf-8 -*-
"""Outcomes evaluation hook for post-reasoning self-assessment.

Extracted from react_agent.py reply() method to comply with architecture rule:
"不能写具体业务逻辑 in react_agent.py"

This hook evaluates response quality using OutcomeEvaluator and records
failures to OutcomeTracker for KTO training signal generation.
"""
import asyncio
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _feed_routing_outcome(query: Optional[str], evaluation: Any) -> None:
    if not query:
        return
    try:
        from ...task_classifier import get_unified_model_router
        router = get_unified_model_router()
        quality_score = getattr(evaluation, "weighted_score", 0.5)
        passed = getattr(evaluation, "passed", False)
        router.record_outcome(
            prompt=query[:500],
            model_tier=2,
            model_name="cloud",
            success=passed,
            quality_score=quality_score,
            latency_ms=0.0,
            cost_usd=0.0,
        )
    except Exception as e:
        logger.debug("Feed routing outcome failed: %s", e)


class OutcomesEvalHook:
    """Post-reasoning hook for automated outcomes self-evaluation.

    Evaluates response quality against criteria and records failures
    for the self-evolution KTO training loop.
    """

    DEFAULT_CRITERIA = [
        {
            "name": "no_errors",
            "criterion_type": "NO_ERROR",
            "threshold": 0.8,
            "required": True,
        },
        {
            "name": "relevance",
            "criterion_type": "KEYWORD_COVERAGE",
            "threshold": 0.2,
            "weight": 0.5,
            "required": False,
        },
    ]

    def __init__(self, criteria_config: Optional[list] = None):
        self.criteria_config = criteria_config or self.DEFAULT_CRITERIA

    async def __call__(
        self,
        agent,
        kwargs: Dict[str, Any],
        output: Any = None,
    ) -> None:
        if output is None:
            return None

        query = self._extract_query(agent, kwargs)
        response_text = output.get_text_content() if hasattr(output, 'get_text_content') else ""
        if not response_text:
            return None

        try:
            from ..outcomes_evaluator import OutcomeEvaluator, OutcomeTracker, SuccessCriterion, CriterionType

            def _simple_tokenize(text: str) -> list:
                if not text:
                    return []
                try:
                    import jieba
                    return [t for t in jieba.cut(text) if t.strip()]
                except ImportError:
                    return text.split()

            tracker = OutcomeTracker.get_instance()
            evaluator = OutcomeEvaluator()

            criteria = []
            for cfg in self.criteria_config:
                params = {}
                if cfg.get("criterion_type") == "KEYWORD_COVERAGE" and query:
                    params = {"keywords": _simple_tokenize(query)[:10]}
                criteria.append(SuccessCriterion(
                    name=cfg["name"],
                    criterion_type=CriterionType[cfg["criterion_type"]],
                    threshold=cfg.get("threshold", 0.5),
                    weight=cfg.get("weight", 1.0),
                    required=cfg.get("required", False),
                    params=params,
                ))

            async def _evaluate_and_record():
                try:
                    evaluation = await evaluator.evaluate(response_text, criteria)
                    if evaluation:
                        tracker.record(evaluation)
                        _feed_routing_outcome(query, evaluation)
                except Exception as e:
                    logger.debug("Outcomes evaluation task failed: %s", e)

            _eval_task = asyncio.create_task(_evaluate_and_record())
            if not hasattr(agent, '_background_tasks'):
                agent._background_tasks = set()
            agent._background_tasks.add(_eval_task)
            _eval_task.add_done_callback(agent._background_tasks.discard)
        except Exception as e:
            logger.debug("Outcomes evaluation failed: %s", e)

        return None

    def _extract_query(self, agent, kwargs: Any) -> Optional[str]:
        msg = kwargs.get("msg")
        if msg is None:
            return None
        last_msg = msg[-1] if isinstance(msg, list) else msg
        from xingzierai.agentscope_core.message import Msg
        if isinstance(last_msg, Msg):
            return last_msg.get_text_content()
        return None
