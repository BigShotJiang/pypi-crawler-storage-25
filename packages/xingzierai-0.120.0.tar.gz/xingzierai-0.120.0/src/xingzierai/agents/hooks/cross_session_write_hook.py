# -*- coding: utf-8 -*-
"""Cross-session memory write hook for post-reasoning memory persistence.

Extracted from react_agent.py reply() method to comply with architecture rule:
"不能写具体业务逻辑 in react_agent.py"

This hook writes Q&A pairs to CrossSessionMemory after each reply.
"""
import asyncio
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class CrossSessionWriteHook:
    """Post-reasoning hook for writing cross-session memory.

    Writes Q&A pairs as EPISODIC memories with AGENT_SHARED scope.
    """

    def __init__(self, importance: float = 0.5, max_query_len: int = 200, max_response_len: int = 500):
        self.importance = importance
        self.max_query_len = max_query_len
        self.max_response_len = max_response_len

    async def __call__(
        self,
        agent,
        kwargs: Dict[str, Any],
        output: Any = None,
    ) -> None:
        if output is None:
            return None

        query = self._extract_query(agent, kwargs)
        if not query:
            return None

        response_text = output.get_text_content() if hasattr(output, 'get_text_content') else ""
        if not response_text:
            return None

        try:
            from ..cross_session_memory import CrossSessionMemory, MemoryType, MemoryScope

            session_id = getattr(agent, '_request_context', {}).get("session_id", "")
            agent_id = getattr(agent, '_request_context', {}).get("agent_id", "")
            csm = CrossSessionMemory.get_instance()

            from ..utils import _tokenize

            task = asyncio.create_task(csm.write(
                content=f"Q: {query[:self.max_query_len]}\nA: {response_text[:self.max_response_len]}",
                memory_type=MemoryType.EPISODIC,
                scope=MemoryScope.AGENT_SHARED,
                agent_id=agent_id,
                session_id=session_id,
                tags=_tokenize(query)[:10],
                importance=self.importance,
            ))

            if not hasattr(agent, '_background_tasks'):
                agent._background_tasks = set()
            agent._background_tasks.add(task)
            task.add_done_callback(agent._background_tasks.discard)
        except Exception as e:
            logger.debug("Cross-session memory write failed: %s", e)

        return None

    def _extract_query(self, agent, kwargs: Any) -> Optional[str]:
        msg = kwargs.get("msg")
        if msg is None:
            return None
        last_msg = msg[-1] if isinstance(msg, list) else msg
        from xingzierai.agentscope_core.message import Msg
        if isinstance(last_msg, Msg):
            return last_msg.get_text_content()
        return None
