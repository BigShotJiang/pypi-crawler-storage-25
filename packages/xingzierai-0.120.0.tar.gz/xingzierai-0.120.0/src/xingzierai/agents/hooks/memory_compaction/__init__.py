# -*- coding: utf-8 -*-
"""Memory compaction package - refactored from monolithic memory_compaction.py.

This package provides memory compaction features:
- Proactive context compression during conversations
- Multi-level compression strategies (light/medium/heavy)
- Anchor preservation for critical information
- Adaptive learning and self-optimization
- Circuit breaker and graceful degradation
"""

from .text_utils import (
    _ANCHOR_PATTERNS,
    _FILE_PATH_PATTERN,
    _URL_PATTERN,
    _CODE_REF_PATTERN,
    _extract_anchors,
    _deduplicate_anchors,
    _validate_anchors,
    _messages_to_text,
    _apply_density_gradient,
)
from .compression_config import (
    _CompactionTimer,
    _log_compaction_performance,
    _CompressionLevel,
)
from .hook import MemoryCompactionHook
from .dream import DREAM_OPTIMIZATION_PROMPT, get_dream_prompt

__all__ = [
    "MemoryCompactionHook",
    "get_dream_prompt",
    "DREAM_OPTIMIZATION_PROMPT",
    "_extract_anchors",
    "_deduplicate_anchors",
    "_validate_anchors",
    "_messages_to_text",
    "_apply_density_gradient",
    "_CompactionTimer",
    "_log_compaction_performance",
    "_CompressionLevel",
]
