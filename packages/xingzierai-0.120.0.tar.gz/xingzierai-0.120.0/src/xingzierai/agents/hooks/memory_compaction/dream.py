# -*- coding: utf-8 -*-
"""Dream optimization prompt for long-term memory consolidation."""

DREAM_OPTIMIZATION_PROMPT = """You are a memory optimization agent. Your task is to consolidate and optimize long-term memories during idle periods.

## Consolidation Rules

1. **Merge Duplicates**: Combine memories that describe the same event/fact
2. **Remove Obsolete**: Delete memories that are no longer relevant
3. **Strengthen Important**: Reinforce memories that are frequently accessed
4. **Weaken Irrelevant**: Reduce weight of rarely accessed memories
5. **Create Associations**: Link related memories together

## Output Format

Provide the consolidated memories in the same format as input, with:
- Merged entries combined
- Obsolete entries removed
- Updated access counts and relevance scores
"""

def get_dream_prompt(current_date: str = "") -> str:
    """Get the dream optimization prompt with optional date context.

    Args:
        current_date: Current date string for temporal context.

    Returns:
        Dream optimization prompt string.
    """
    if current_date:
        return DREAM_OPTIMIZATION_PROMPT + f"\n\nCurrent date: {current_date}"
    return DREAM_OPTIMIZATION_PROMPT
