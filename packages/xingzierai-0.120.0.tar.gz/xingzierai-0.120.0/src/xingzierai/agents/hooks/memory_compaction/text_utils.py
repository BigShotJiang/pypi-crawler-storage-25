# -*- coding: utf-8 -*-
"""Text processing utilities for memory compaction."""

import re as _re
from typing import Any

_ANCHOR_PATTERNS = [
    "must", "must not", "never", "always", "critical", "important",
    "essential", "required", "mandatory", "key", "vital", "crucial",
    "注意", "必须", "不要", "绝不", "关键", "重要", "务必",
    "记住", "切记", "核心", "根本", "底线",
]

_FILE_PATH_PATTERN = _re.compile(
    r'(?:/[\w\-./]+\.[\w]+|[A-Za-z]:\\[\w\-./\\]+\.[\w]+)'
)
_URL_PATTERN = _re.compile(
    r"https?://[\w\-._~:/?#\[\]@!$&'()*+,;=%]+"
)
_CODE_REF_PATTERN = _re.compile(
    r'(?:class|def|function|import|from|return|if|else|for|while)\s+\w+'
)


def _extract_anchors(messages: list) -> list[str]:
    """Extract anchor phrases that must be preserved during compaction."""
    anchors = []
    for msg in messages:
        content = ""
        if isinstance(msg, dict):
            content = str(msg.get("content", ""))
        else:
            content = str(getattr(msg, "content", "") or "")
        if not content:
            continue
        for pattern in _ANCHOR_PATTERNS:
            if pattern in content.lower():
                sentence_start = content.lower().find(pattern)
                start = max(0, sentence_start - 30)
                end = min(len(content), sentence_start + len(pattern) + 50)
                anchors.append(content[start:end].strip())
    return anchors


def _deduplicate_anchors(anchors: list[str]) -> list[str]:
    """Remove duplicate and near-duplicate anchors."""
    if not anchors:
        return []
    unique = [anchors[0]]
    for anchor in anchors[1:]:
        is_dup = False
        for existing in unique:
            overlap = len(set(anchor.lower().split()) & set(existing.lower().split()))
            total = len(set(anchor.lower().split()) | set(existing.lower().split()))
            if total > 0 and overlap / total > 0.7:
                is_dup = True
                break
        if not is_dup:
            unique.append(anchor)
    return unique


def _validate_anchors(summary: str, anchors: list[str]) -> float:
    """Validate that anchors are preserved in the summary. Returns preservation ratio."""
    if not anchors:
        return 1.0
    preserved = 0
    summary_lower = summary.lower()
    for anchor in anchors:
        anchor_words = set(anchor.lower().split())
        if any(w in summary_lower for w in anchor_words if len(w) > 3):
            preserved += 1
    return preserved / len(anchors)


def _messages_to_text(messages: list, density: str = "full") -> str:
    """Convert messages to text with density control.

    Args:
        messages: List of message objects.
        density: "full", "medium", or "sparse".

    Returns:
        Text representation of messages.
    """
    parts = []
    for msg in messages:
        role = ""
        content = ""
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = str(msg.get("content", "") or "")
        else:
            role = getattr(msg, "role", "") or ""
            content = str(getattr(msg, "content", "") or "")

        if density == "sparse" and role == "assistant":
            content = content[:200] + "..." if len(content) > 200 else content
        elif density == "medium" and role == "assistant":
            content = content[:500] + "..." if len(content) > 500 else content

        parts.append(f"[{role}]: {content}")

    return "\n".join(parts)


def _apply_density_gradient(
    messages: list,
    token_counts: list[int],
    max_tokens: int,
) -> list:
    """Apply three-level density gradient compression.

    Recent messages: full density
    Middle messages: medium density (truncate assistant to 500 chars)
    Old messages: sparse density (truncate assistant to 200 chars)

    Returns messages that fit within max_tokens.
    """
    if not messages or not token_counts:
        return list(messages) if messages else []

    n = len(messages)
    if n <= 3:
        return list(messages)

    recent_boundary = max(0, n - 3)
    middle_boundary = max(0, n - 8)

    result = []
    total_tokens = 0

    for i, msg in enumerate(messages):
        tc = token_counts[i] if i < len(token_counts) else 0

        if i >= recent_boundary:
            estimated_tc = tc
        elif i >= middle_boundary:
            estimated_tc = tc // 2
        else:
            estimated_tc = tc // 4

        if total_tokens + estimated_tc <= max_tokens:
            result.append(msg)
            total_tokens += estimated_tc
        else:
            break

    return result
