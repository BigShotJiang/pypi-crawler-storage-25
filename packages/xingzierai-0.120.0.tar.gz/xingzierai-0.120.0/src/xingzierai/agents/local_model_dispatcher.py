# -*- coding: utf-8 -*-
"""Local Model Dispatcher - Routes system-internal tasks to locally trained small models.

This module implements the "self-optimizing" loop:
1. System uses LLM for internal tasks (memory compaction, fact extraction, etc.)
2. Each LLM call's I/O is captured as training data
3. When enough data accumulates, a small model is automatically trained
4. Future calls are routed to the local model instead of the LLM
5. The system gradually becomes more self-sufficient, reducing API costs

Task types that can be offloaded:
- "memory_compact": Compress conversation history into summary
- "fact_extract": Extract key facts from text
- "query_rewrite": Rewrite search queries for better retrieval
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_DATA_DIR = Path.home() / ".xingzierai" / "auto_train_data"
_REGISTRY_FILE = Path.home() / ".xingzierai" / "local_dispatcher_registry.json"
_AUTO_TRAIN_THRESHOLD = 50
_MAX_SAMPLES_PER_TASK = 500


class EarlyStopping:
    def __init__(self, patience: int = 5, min_delta: float = 0.001):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float("inf")

    def should_stop(self, current_loss: float) -> bool:
        if current_loss < self.best_loss - self.min_delta:
            self.best_loss = current_loss
            self.counter = 0
        else:
            self.counter += 1
        return self.counter >= self.patience


class TokenEconomicsTracker:
    """Tracks token usage and cost savings from local model dispatch.

    Inspired by the Token Economics insight: inference cost accounts for
    90%+ of total AI spending. Every call routed to a local model saves
    real money and reduces latency.
    """

    def __init__(self):
        self._stats: Dict[str, dict] = {}
        self._total_local_calls = 0
        self._total_llm_calls = 0
        self._total_tokens_saved = 0
        self._cost_per_1k_input = 0.003
        self._cost_per_1k_output = 0.015

    def record_local_call(self, task_type: str, input_tokens: int = 0, output_tokens: int = 0):
        self._total_local_calls += 1
        estimated_input = input_tokens or 200
        estimated_output = output_tokens or 100
        self._total_tokens_saved += estimated_input + estimated_output
        if task_type not in self._stats:
            self._stats[task_type] = {"local_calls": 0, "llm_calls": 0, "tokens_saved": 0}
        self._stats[task_type]["local_calls"] += 1
        self._stats[task_type]["tokens_saved"] += estimated_input + estimated_output

    def record_llm_call(self, task_type: str, input_tokens: int = 0, output_tokens: int = 0):
        self._total_llm_calls += 1
        if task_type not in self._stats:
            self._stats[task_type] = {"local_calls": 0, "llm_calls": 0, "tokens_saved": 0}
        self._stats[task_type]["llm_calls"] += 1

    def get_savings(self) -> dict:
        total_calls = self._total_local_calls + self._total_llm_calls
        local_rate = self._total_local_calls / total_calls if total_calls > 0 else 0
        input_savings = self._total_tokens_saved * 0.6 * self._cost_per_1k_input / 1000
        output_savings = self._total_tokens_saved * 0.4 * self._cost_per_1k_output / 1000
        total_savings = input_savings + output_savings

        return {
            "total_local_calls": self._total_local_calls,
            "total_llm_calls": self._total_llm_calls,
            "local_rate": round(local_rate, 3),
            "tokens_saved": self._total_tokens_saved,
            "estimated_savings_usd": round(total_savings, 4),
            "per_task": dict(self._stats),
        }


class TrainingDataCollector:
    """Collects I/O pairs from LLM calls for future small model training."""

    _PII_PATTERNS = {
        'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        'phone_cn': r'\b1[3-9]\d{9}\b',
        'id_card_cn': r'\b\d{17}[\dXx]\b',
        'bank_card': r'\b\d{16,19}\b',
        'ip_addr': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
    }

    def __init__(self):
        _DATA_DIR.mkdir(parents=True, exist_ok=True)

    @classmethod
    def _scrub_pii(cls, text: str) -> str:
        import re
        for pii_type, pattern in cls._PII_PATTERNS.items():
            text = re.sub(pattern, f'[{pii_type}_REDACTED]', text)
        return text

    @staticmethod
    def _passes_quality_filter(input_text: str, output_text: str) -> bool:
        if len(input_text.strip()) < 5 or len(output_text.strip()) < 10:
            return False
        if len(input_text) > 8192 or len(output_text) > 8192:
            return False
        if input_text.strip() == output_text.strip():
            return False
        if output_text.lower()[:50].startswith("error") or output_text.lower()[:50].startswith("sorry, i can"):
            return False
        return True

    def collect(self, task_type: str, input_text: str, output_text: str) -> None:
        if not self._passes_quality_filter(input_text, output_text):
            return
        input_text = self._scrub_pii(input_text)
        output_text = self._scrub_pii(output_text)

        data_file = _DATA_DIR / f"{task_type}.jsonl"
        try:
            count = self.count(task_type)
            if count >= _MAX_SAMPLES_PER_TASK:
                return
            entry = {
                "prompt": input_text[:4000],
                "response": output_text[:4000],
                "ts": time.time(),
            }
            with open(data_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.debug("Failed to collect training data: %s", e)

    def count(self, task_type: str) -> int:
        data_file = _DATA_DIR / f"{task_type}.jsonl"
        if not data_file.exists():
            return 0
        try:
            with open(data_file, encoding="utf-8") as f:
                return sum(1 for _ in f)
        except Exception as _count_err:
            logger.debug("Failed to count data lines: %s", _count_err)
            return 0

    def get_data_path(self, task_type: str) -> Optional[Path]:
        p = _DATA_DIR / f"{task_type}.jsonl"
        return p if p.exists() else None

    def get_all_counts(self) -> Dict[str, int]:
        result = {}
        if _DATA_DIR.exists():
            for f in _DATA_DIR.glob("*.jsonl"):
                task_type = f.stem
                result[task_type] = self.count(task_type)
        return result


class _LocalModelEntry:
    """A loaded local model for a specific task type."""

    def __init__(self, task_type: str, model_path: str, tokenizer_path: str):
        self.task_type = task_type
        self.model_path = model_path
        self.tokenizer_path = tokenizer_path
        self._model = None
        self._tokenizer = None
        self._loaded = False
        self._load_error = None

    def _load(self):
        if self._loaded:
            return self._model is not None
        try:
            import torch
            from ..model_trainer.model import SmallLM
            from ..model_trainer.dataset import load_tokenizer
            from ..model_trainer.manager import TrainingManager

            self._tokenizer = load_tokenizer(self.tokenizer_path)
            mgr = TrainingManager.get_instance()
            job = mgr.get_job_by_model_path(self.model_path)
            if job and job.architecture:
                arch = job.architecture
            else:
                meta_path = Path(self.model_path).parent / "meta.json"
                if meta_path.exists():
                    meta = json.loads(meta_path.read_text())
                    from ..model_trainer.schema import ModelArchitecture
                    arch = ModelArchitecture(**meta.get("architecture", {}))
                else:
                    self._load_error = "No architecture info"
                    self._loaded = True
                    return False

            self._model = SmallLM(
                vocab_size=arch.vocab_size,
                dim=arch.dim,
                n_layers=arch.n_layers,
                n_heads=arch.n_heads,
                mlp_ratio=arch.mlp_ratio,
                max_seq_len=arch.max_seq_len,
            )
            state = torch.load(self.model_path, map_location="cpu", weights_only=True)
            self._model.load_state_dict(state)
            self._model.eval()
            self._loaded = True
            return True
        except Exception as e:
            self._load_error = str(e)
            self._loaded = True
            logger.debug("Failed to load local model for %s: %s", self.task_type, e)
            return False

    def generate(self, prompt: str, max_new_tokens: int = 128, temperature: float = 0.3) -> Optional[str]:
        if not self._load():
            return None
        try:
            import torch
            tokens = self._tokenizer.encode(prompt)
            if len(tokens) > self._model.arch.max_seq_len - max_new_tokens:
                tokens = tokens[:self._model.arch.max_seq_len - max_new_tokens]
            input_ids = torch.tensor([tokens], dtype=torch.long)
            with torch.no_grad():
                output = self._model.generate(
                    input_ids,
                    max_new_tokens=max_new_tokens,
                    temperature=temperature,
                    top_k=40,
                )
            generated = output[0].tolist()
            if len(generated) > len(tokens):
                new_tokens = generated[len(tokens):]
                return self._tokenizer.decode(new_tokens)
            return None
        except Exception as e:
            logger.debug("Local model generation failed for %s: %s", self.task_type, e)
            return None


class LocalModelDispatcher:
    """Routes system-internal tasks to locally trained small models.

    Usage:
        dispatcher = LocalModelDispatcher.get_instance()
        result = await dispatcher.dispatch(
            task_type="memory_compact",
            input_text=conversation_text,
            fallback_fn=lambda: llm_call(...),
        )
    """

    _instance: Optional["LocalModelDispatcher"] = None

    def __init__(self):
        self._models: Dict[str, _LocalModelEntry] = {}
        self._collector = TrainingDataCollector()
        self._auto_train_pending: Dict[str, bool] = {}
        self._quality_validator = None
        self._version_manager = None
        self._evolution_sync = None
        self._token_economics = TokenEconomicsTracker()
        self._background_tasks: set = set()
        self._load_registry()

    @classmethod
    def get_instance(cls) -> "LocalModelDispatcher":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    def collect_training_data(self, task_type: str, input_text: str, output_text: str) -> None:
        self._collector.collect(task_type, input_text, output_text)

    def get_model_entry(self, task_type: str) -> Optional["_LocalModelEntry"]:
        return self._models.get(task_type)

    def get_all_model_entries(self) -> Dict[str, "_LocalModelEntry"]:
        return dict(self._models)

    def get_collector_stats(self) -> Dict[str, Any]:
        return self._collector.get_all_counts()

    @property
    def quality_validator(self):
        if self._quality_validator is None:
            from .evolution_bridges import QualityValidator
            self._quality_validator = QualityValidator()
        return self._quality_validator

    @property
    def version_manager(self):
        if self._version_manager is None:
            from .evolution_bridges import ModelVersionManager
            self._version_manager = ModelVersionManager()
        return self._version_manager

    @property
    def evolution_sync(self):
        if self._evolution_sync is None:
            from .evolution_bridges import EvolutionModelSync
            self._evolution_sync = EvolutionModelSync()
        return self._evolution_sync

    def _load_registry(self):
        if _REGISTRY_FILE.exists():
            try:
                data = json.loads(_REGISTRY_FILE.read_text(encoding="utf-8"))
                for task_type, info in data.get("models", {}).items():
                    self._models[task_type] = _LocalModelEntry(
                        task_type=task_type,
                        model_path=info["model_path"],
                        tokenizer_path=info["tokenizer_path"],
                    )
                logger.info(
                    "Loaded %d local model(s) from registry: %s",
                    len(self._models),
                    list(self._models.keys()),
                )
            except Exception as e:
                logger.warning("Failed to load dispatcher registry: %s", e)

    def _save_registry(self):
        _REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "models": {
                task_type: {
                    "model_path": entry.model_path,
                    "tokenizer_path": entry.tokenizer_path,
                }
                for task_type, entry in self._models.items()
            }
        }
        tmp = _REGISTRY_FILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
        tmp.replace(_REGISTRY_FILE)

    def has_local_model(self, task_type: str) -> bool:
        return task_type in self._models

    async def register_local_model(
        self, task_type: str, model_path: str, tokenizer_path: str,
        validate: bool = True, llm_fn=None,
    ) -> Dict[str, Any]:
        if task_type in self._models:
            self.version_manager.archive_current(task_type)

        if validate:
            result = await self.quality_validator.validate(
                task_type, model_path, tokenizer_path, llm_fn=llm_fn,
            )
            if not result.get("passed", True):
                logger.warning(
                    "Model for %s failed quality validation: %s",
                    task_type, result,
                )
                return {"registered": False, "validation": result}

        self._models[task_type] = _LocalModelEntry(
            task_type=task_type,
            model_path=model_path,
            tokenizer_path=tokenizer_path,
        )
        self._save_registry()
        logger.info("Registered local model for task: %s", task_type)
        return {"registered": True}

    def unregister_local_model(self, task_type: str) -> None:
        if task_type in self._models:
            del self._models[task_type]
            self._save_registry()

    async def dispatch(
        self,
        task_type: str,
        input_text: str,
        fallback_fn: Optional[Callable] = None,
        max_new_tokens: int = 128,
        temperature: float = 0.3,
        collect_data: bool = True,
    ) -> str:
        """Route a task to local model or fallback to LLM.

        Args:
            task_type: Type of task (e.g., "memory_compact")
            input_text: Input text for the task
            fallback_fn: Async or sync function to call if no local model
            max_new_tokens: Max tokens for local model generation
            temperature: Temperature for local model generation
            collect_data: Whether to collect I/O for future training

        Returns:
            Result text from local model or fallback
        """
        if task_type in self._models:
            invalidated = self.evolution_sync.is_task_invalidated(task_type)
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self._models[task_type].generate(
                    input_text, max_new_tokens, temperature
                ),
            )
            if result is not None:
                self._token_economics.record_local_call(task_type)
                if invalidated and fallback_fn is not None:
                    if asyncio.iscoroutinefunction(fallback_fn):
                        llm_result = await fallback_fn()
                    else:
                        llm_result = fallback_fn()
                    self.evolution_sync.validate_and_resolve(
                        task_type, llm_result, result
                    )
                return result
            logger.info(
                "Local model for %s failed, falling back to free model", task_type
            )

        try:
            from .free_model_registry import get_free_model_registry
            registry = get_free_model_registry()
            best = registry.get_best_free_model(need_tool_calling=False)
            if best is not None:
                import aiohttp
                import time as _time
                start = _time.time()
                async with aiohttp.ClientSession() as session:
                    payload = {
                        "model": best.model_id,
                        "messages": [{"role": "user", "content": input_text}],
                        "max_tokens": max_new_tokens,
                        "temperature": temperature,
                    }
                    async with session.post(
                        "https://opencode.ai/zen/v1/chat/completions",
                        json=payload,
                        timeout=aiohttp.ClientTimeout(total=30),
                    ) as resp:
                        latency_ms = (_time.time() - start) * 1000
                        if resp.status == 200:
                            data = await resp.json()
                            choices = data.get("choices", [])
                            if choices:
                                content = choices[0].get("message", {}).get("content", "")
                                if content and len(content.strip()) > 10:
                                    registry.record_result(best.model_id, True, latency_ms)
                                    logger.info(
                                        "Free model %s handled %s (cost=$0.00, %.0fms)",
                                        best.model_id, task_type, latency_ms,
                                    )
                                    return content.strip()
                        registry.record_result(best.model_id, False, latency_ms)
        except Exception as e:
            logger.debug("Free model dispatch failed for %s: %s", task_type, e)

        if fallback_fn is None:
            return ""

        if asyncio.iscoroutinefunction(fallback_fn):
            result = await fallback_fn()
        else:
            result = fallback_fn()

        self._token_economics.record_llm_call(task_type)

        if collect_data and result and input_text:
            self.collect_training_data(task_type, input_text, result)
            await self._check_auto_train(task_type)

        return result

    async def _check_auto_train(self, task_type: str) -> None:
        if self.has_local_model(task_type):
            return
        if self._auto_train_pending.get(task_type):
            return
        count = self._collector.count(task_type)
        if count >= _AUTO_TRAIN_THRESHOLD:
            self._auto_train_pending[task_type] = True
            task = asyncio.create_task(self._auto_train(task_type))
            self._background_tasks.add(task)
            task.add_done_callback(self._background_tasks.discard)

    async def _auto_train(self, task_type: str) -> None:
        try:
            logger.info(
                "Auto-training small model for task: %s (%d samples)",
                task_type,
                self._collector.count(task_type),
            )
            data_path = self._collector.get_data_path(task_type)
            if not data_path:
                return

            from ..model_trainer.manager import TrainingManager
            from ..model_trainer.schema import (
                CreateTrainingJobRequest,
                TrainingConfig,
                TrainingMode,
                architecture_from_depth,
            )

            mgr = TrainingManager.get_instance()

            raw = data_path.read_text(encoding="utf-8").strip()
            samples = [json.loads(line) for line in raw.split("\n") if line.strip()]

            sft_items = []
            for s in samples:
                sft_items.append({"prompt": s["prompt"], "response": s["response"]})

            config = TrainingConfig(
                mode=TrainingMode.SFT,
                epochs=5,
                batch_size=4,
                learning_rate=1e-4,
                warmup_steps=50,
                weight_decay=0.01,
                grad_clip=1.0,
                save_every=200,
                eval_every=100,
                device="auto",
            )

            req = CreateTrainingJobRequest(
                name=f"auto_{task_type}",
                description=f"Auto-trained model for {task_type}",
                depth=4,
                config=config,
                sft_data=sft_items,
            )

            job = mgr.create_job(req)
            logger.info(
                "Auto-training job created: %s (%s params)",
                job.id,
                f"{job.param_count / 1e6:.1f}M",
            )

            mgr.start_job(job.id)

            for _ in range(300):
                await asyncio.sleep(2)
                job = mgr.get_job(job.id)
                if job.status in ("completed", "failed", "cancelled"):
                    break

            if job.status == "completed" and job.model_save_path:
                model_path = str(Path(job.model_save_path) / "best_model.pt")
                tokenizer_path = str(Path(job.model_save_path) / "tokenizer.json")

                if Path(model_path).exists():
                    await self.register_local_model(task_type, model_path, tokenizer_path)
                    logger.info(
                        "Auto-training completed! Local model registered for: %s",
                        task_type,
                    )
            else:
                logger.warning(
                    "Auto-training for %s ended with status: %s",
                    task_type,
                    job.status,
                )

        except Exception as e:
            logger.error("Auto-training failed for %s: %s", task_type, e)
        finally:
            self._auto_train_pending.pop(task_type, None)

    def get_status(self) -> Dict[str, Any]:
        models = {}
        for task_type, entry in self._models.items():
            models[task_type] = {
                "model_path": entry.model_path,
                "loaded": entry._loaded,
                "load_error": entry._load_error,
            }

        data_counts = self._collector.get_all_counts()

        version_info = {}
        for task_type in self._models:
            versions = self.version_manager.list_versions(task_type)
            if versions:
                version_info[task_type] = {
                    "current_version": len(versions),
                    "latest_archive": versions[-1].get("version_id") if versions else None,
                }

        invalidated = list(self.evolution_sync._invalidated_tasks) if self._evolution_sync else []

        return {
            "registered_models": models,
            "training_data_counts": data_counts,
            "auto_train_threshold": _AUTO_TRAIN_THRESHOLD,
            "pending_auto_train": list(self._auto_train_pending.keys()),
            "version_info": version_info,
            "invalidated_tasks": invalidated,
            "token_economics": self._token_economics.get_savings(),
        }


def get_local_model_dispatcher() -> LocalModelDispatcher:
    return LocalModelDispatcher.get_instance()
