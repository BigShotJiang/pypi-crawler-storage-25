---
name: ai-self-evolution-lite
description: "Lightweight self-evolution methodology for Agent runtime. Invoke when user says 'evolve' or '进化' for guided self-improvement. | Agent运行时的轻量级自进化方法论。当用户说'evolve'或'进化'时触发引导式自我改进。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🧬",
        "requires": {}
      }
  }
---
# AI Self-Evolution (Lite)

Guided self-improvement methodology for Agent runtime. This is the L1 methodology layer — the full evolution engine runs in the TRAE IDE Skill and Evolution Daemon.

## When to Use

- User says "evolve", "进化", "self-improve", or "自主进化"
- User wants the Agent to improve itself
- User asks about the Agent's evolution capabilities

## Evolution Modes

| Mode | Trigger | Human Checkpoint |
|------|---------|-----------------|
| Autonomous | "自主进化" / "autonomous evolve" | Only for red-level files |
| Supervised | "进化" / "evolve" | Every step |
| Emergency | "紧急修复" / "emergency" | Before and after fix |

## 13-Step Evolution Flow (Summary)

1. **State Init**: Read evolution state, check service availability
2. **Tech Research**: 4-dimension competitive research (academic/competitor/open-source/protocol)
3. **AGENT.md Audit**: Check documentation-code consistency
4. **Source Audit**: 12-item audit checklist
5. **Dynamic Planning**: Safety level (green/yellow/red) + execution path
6. **Git Checkpoint**: Backup before evolution
7. **Incremental Execution**: Single-file changes with verification gates
8. **Auto Rollback**: 4-level rollback (file/hot/git/service)
9. **Test Verification**: 9-item test suite
10. **State Update**: Update state.json + bug patterns
11. **AGENT.md Sync**: Update module docs after code changes
12. **Git Commit**: Commit with gate information
13. **Self Reflection**: 14-item reflection → auto-convert to next actions

## Safety Level Classification

| Level | File Types | Required Gates | Executor |
|-------|-----------|---------------|----------|
| 🟢 Green | Docs, configs, styles, tests | GATE 1 | Agent |
| 🟡 Yellow | Backend logic, frontend pages | GATE 1-8 | Agent |
| 🔴 Red | react_agent, chat lib, console.py | GATE 1-12.5 | Daemon preferred |

## 4-Level Rollback

| Level | Method | When to Use |
|-------|--------|-------------|
| L1 | File restore | Single file issue |
| L2 | Hot rollback (importlib) | Hot replacement issue |
| L3 | Git checkpoint reset | Multi-file issue |
| L4 | Service restart | Service crash |

## Reflection → Action Conversion

| Reflection Finding | Auto-Converts To |
|-------------------|-----------------|
| New evolution direction | direction_priority entry |
| New bug pattern | bug_patterns candidate |
| High-risk module | audit_scope.high_risk_modules |
| Code quality issue | direction_priority weight adjustment |
| Performance insight | discovery_rate weight update |

## Important Notes

- This is the **L1 methodology layer** only
- Full evolution execution (L3) requires the TRAE IDE Skill or Evolution Daemon
- The Agent can guide users through the methodology but cannot execute code changes autonomously
- Always confirm with the user before making any changes
- Red-level files should be handled by the Daemon, not the Agent directly

## Red Flags

- Attempting to modify react_agent.py without Daemon
- Skipping verification gates
- No git checkpoint before changes
- Evolution without reflection
- Not recording new bug patterns
