---
name: train_model
description: "Use this skill when the user wants to train, fine-tune, or create a small language model, OR when asking about local model dispatch status. Triggers include: '训练模型', '训练小模型', 'train model', 'fine-tune', '微调', '创建模型', '我想训练', '做个AI模型', '小模型状态', '本地模型', '调度状态', '自动训练'. The system can train models from scratch on user-provided text data, or fine-tune with Q&A pairs. The system also automatically collects training data from internal LLM calls and auto-trains small models to replace them."
metadata: { "builtin_skill_version": "2.0", "xingzierai.emoji": "🧠" }
---

# Model Training Skill (Deep Integration)

You can help users train their own small language models directly in this system. No internet, no API costs, runs on local hardware.

## Two Modes of Operation

### Mode 1: User-Initiated Training
When a user explicitly asks to train a model.

### Mode 2: Auto-Dispatch (System Self-Optimization)
The system automatically identifies internal tasks that can be handled by small models:
- **memory_compact**: Compress conversation history into summary
- **fact_extract**: Extract key facts from text
- **query_rewrite**: Rewrite search queries for better retrieval

The system collects I/O data from LLM calls. When 50+ samples accumulate, it auto-trains a small model. Once trained, future calls go to the local model instead of the LLM.

## Quick Start

### Check Dispatch Status
When user asks about local models or auto-training:
```
train_model(action="dispatch_status")
```
This shows which tasks have local models deployed and training data collection progress.

### Create Training Job
```
train_model(
    action="create",
    name="my_model",
    depth=4,
    mode="pretrain",  # or "sft"
    dataset_text="...",  # for pretrain
    # OR sft_data=[{"prompt":"...", "response":"..."}]  # for sft
    epochs=3,
    device="auto"
)
```

### Monitor Progress
```
train_model(action="status", job_id="<job_id>")
```

### Test the Model
```
train_model(action="generate", job_id="<job_id>", prompt="Hello", max_new_tokens=50)
```

### Register as Chat Model
```
train_model(action="register", job_id="<job_id>", display_name="My Custom Model")
```

### Deploy as System Task Model
After training, deploy the model to handle a specific system task:
```
train_model(action="dispatch_register", job_id="<job_id>", task_type="memory_compact")
```
Valid task types: "memory_compact", "fact_extract", "query_rewrite"

### Remove System Task Model
```
train_model(action="dispatch_unregister", task_type="memory_compact")
```

## Model Size Guide

| Depth | Params | Hardware | Use Case |
|-------|--------|----------|----------|
| 2 | ~0.6M | CPU | Quick test, simple tasks |
| 4 | ~1.8M | CPU/GPU | System task dispatch (recommended) |
| 8 | ~10.5M | GPU | Chat models, complex tasks |
| 12 | ~33.8M | GPU 8GB+ | Advanced chat models |

## Training Modes

### Pretrain Mode
- Provide raw text (articles, books, documents)
- Model learns language patterns from the text
- Good for: domain-specific text generation

### SFT Mode (Supervised Fine-Tuning)
- Provide Q&A pairs (prompt + response)
- Model learns to answer questions
- Good for: creating chat assistants, task-specific models

## Auto-Dispatch Flow

1. System uses LLM for internal tasks (memory compaction, fact extraction, etc.)
2. Each LLM call's input/output is captured as training data
3. When 50+ samples accumulate, a small model is auto-trained
4. Future calls are routed to the local model instead of the LLM
5. The system gradually becomes more self-sufficient

## Tips
- Use `dispatch_status` to check how the system is learning
- depth=4 is recommended for system task models (fast, efficient)
- More training data = better results
- After registering as chat model, tell user to go to Settings > Models to switch
