---
name: diagnostic-methodology
description: "Root cause analysis using 5 Why method and extend-one-insight-to-three pattern. Invoke when debugging issues, investigating failures, or user says 'root cause' / '5 Why' / '根本原因'. | 使用5Why方法和举一反三模式进行根因分析。当调试问题、调查故障时，或用户说'根本原因'/'5Why'时触发。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🔬",
        "requires": {}
      }
  }
---
# Diagnostic Methodology

Find the root cause, not just the symptom. Fix the system, not the incident.

## Overview

When something breaks, the instinct is to patch the symptom. This skill enforces two systematic methods:

1. **5 Why Method**: Ask "why" five times to reach the root cause
2. **Extend-One-Insight-to-Three**: When you find one problem, check for similar problems elsewhere

## When to Use

**Activate this skill when:**
- User reports a bug or error
- Something fails in production or testing
- User says "root cause", "5 Why", "根本原因"
- After any incident that needs post-mortem
- When a fix seems too simple for the symptom

**Do not activate for:**
- Known issues with known fixes
- Trivial typos or configuration errors

## Method 1: 5 Why Analysis

### Process

1. **State the problem** clearly and specifically
2. **Ask "Why?"** and document the answer
3. **Repeat** until you reach a root cause (usually 3-5 levels)
4. **Verify** the root cause by tracing forward
5. **Fix** the root cause, not the symptom

### Example

```
Problem: Chat response is blank

Why 1: Why is the chat response blank?
  → The SSE stream ended without sending content

Why 2: Why did the SSE stream end without content?
  → The LLM returned an empty response

Why 3: Why did the LLM return an empty response?
  → The context was compressed too aggressively

Why 4: Why was the context compressed too aggressively?
  → The compression prompt has no minimum length constraint

Why 5: Why is there no minimum length constraint?
  → The compression prompt was not designed with quality constraints

Root Cause: Compression prompt lacks output quality constraints
Fix: Add minimum length and completeness requirements to compression prompt
```

### Rules

- Each "Why" must be answered with a **fact**, not a guess
- If you can't answer a "Why", you need more data
- The root cause must be **actionable** (you can fix it)
- The root cause must be **specific** (not "bad design")
- Stop when the answer points to a process/system issue, not a person

## Method 2: Extend-One-Insight-to-Three

When you find one problem, check for similar problems in three dimensions:

### Dimension 1: Same Code, Same Pattern

Check if the same problematic pattern exists elsewhere in the same file or module.

```
Found: Silent catch in file_reader.py line 42
Check: Are there other silent catches in file_reader.py?
Check: Are there silent catches in other tools?
```

### Dimension 2: Same Pattern, Different Module

Check if the same anti-pattern exists in related modules.

```
Found: Unbounded dict growth in cross_session_memory.py
Check: Are there other unbounded dicts in memory/ module?
Check: Are there unbounded dicts in agents/ module?
```

### Dimension 3: Same Root Cause, Different Symptom

Check if the same root cause could produce different symptoms.

```
Found: Missing error handling causes blank response
Check: Could missing error handling cause data loss?
Check: Could missing error handling cause security issues?
```

## Integration with Bug Pattern Knowledge Base

After completing diagnosis:

1. **Record the bug pattern** if it's new
2. **Update existing pattern** if it's a known variant
3. **Tag the entropy type** (structural/information/thermodynamic/cognitive/style)
4. **Document the fix method** for future reference

## Output Format

```markdown
## Diagnostic Report

### Problem Statement
[Clear, specific problem description]

### 5 Why Analysis
1. Why: [Answer]
2. Why: [Answer]
3. Why: [Answer]
4. Why: [Answer]
5. Why: [Answer]

### Root Cause
[Specific, actionable root cause]

### Fix
[Fix for the root cause, not the symptom]

### Extend-One-Insight-to-Three
- Same code, same pattern: [Findings]
- Same pattern, different module: [Findings]
- Same root cause, different symptom: [Findings]

### Bug Pattern
- ID: [BP-XXX or NEW]
- Entropy Type: [structural/information/thermodynamic/cognitive/style]
- Fix Method: [Description]
```

## Red Flags

- Stopping at "human error" as root cause
- Fixing symptoms instead of root causes
- Not checking for similar issues elsewhere
- Not recording new bug patterns
- Root cause is too vague to be actionable
