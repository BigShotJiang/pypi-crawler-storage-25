---
name: skill-creator
description: "Creates new SKILLs for the XINGZIERAI workspace. Invoke when user wants to create/add/custom skill, or asks how to make a skill. | 为XINGZIERAI工作区创建新技能。当用户想创建/添加/自定义技能，或询问如何制作技能时触发。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🛠️",
        "requires": {}
      }
  }
---
# Skill Creator

Creates new SKILLs for the XINGZIERAI workspace.

## When to Use

**Activate this skill when:**
- User wants to create a new skill
- User wants to add a custom skill to the workspace
- User asks to set up a skill template
- User asks "how to create a skill"
- User mentions creating/adding/making any skill

## SKILL Structure

A valid SKILL requires:

1. **Directory**: `src/xingzierai/agents/skills/<skill-name>/` (builtin) or `<workspace>/customized_skills/<skill-name>/` (custom)
2. **File**: `SKILL.md` inside the directory
3. **Optional**: `references/` subdirectory for reference docs
4. **Optional**: `scripts/` subdirectory for executable scripts

## SKILL.md Format

```markdown
---
name: "<skill-name>"
description: "<concise description covering: (1) what the skill does, (2) when to invoke it. Keep under 200 characters for best display. | <Chinese description>"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "<emoji>",
        "requires": {}
      }
  }
---
# <Skill Title>

<Detailed instructions, usage guidelines, and examples>
```

## Required Fields

| Field | Location | Description |
|-------|----------|-------------|
| `name` | frontmatter | Unique identifier for the skill |
| `description` | frontmatter | Must include (1) what the skill does AND (2) when to invoke it. Bilingual (English | Chinese) recommended. |
| `metadata` | frontmatter | Contains `builtin_skill_version` and `xingzierai` config |
| `metadata.builtin_skill_version` | frontmatter | Version string, e.g. "1.0" |
| `metadata.xingzierai.emoji` | frontmatter | Emoji for UI display |
| `metadata.xingzierai.requires` | frontmatter | Dependencies on other skills |
| `detail` | body | Full markdown content after frontmatter |

## Creation Steps

1. Ask user for skill name and purpose
2. When generating the `description` field, ALWAYS include:
   - What the skill does (functionality)
   - When to invoke it (trigger conditions/scenarios)
   - Bilingual: English | Chinese
   - Example: "Does X. Invoke when Y. | 做X。当Y时触发。"
3. Create directory: `src/xingzierai/agents/skills/<skill-name>/` (for builtin) or `<workspace>/customized_skills/<skill-name>/` (for custom)
4. Create `SKILL.md` with proper frontmatter and content
5. The skill will be automatically scanned for security before enabling

## Security Scanning

All skills are scanned before creation and enabling. The scanner checks for:
- Command injection
- Prompt injection
- Data exfiltration
- Obfuscated code
- Resource abuse
- Social engineering
- Supply chain attacks
- Unauthorized tool use
- Hardcoded secrets

If the scan fails, the skill will not be created. Fix the issues and try again.

## Example

To create a "code-reviewer" skill:

```bash
mkdir -p src/xingzierai/agents/skills/code-reviewer
```

Then create `src/xingzierai/agents/skills/code-reviewer/SKILL.md`:

```markdown
---
name: "code-reviewer"
description: "Reviews code for best practices, bugs, and improvements. Invoke when user asks for code review or before merging changes. | 审查代码的最佳实践、Bug和改进。当用户要求代码审查或合并变更前触发。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🔍",
        "requires": {}
      }
  }
---
# Code Reviewer

This skill reviews code and provides feedback...
```
