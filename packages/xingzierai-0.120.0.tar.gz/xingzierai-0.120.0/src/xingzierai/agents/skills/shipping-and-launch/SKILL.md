---
name: shipping-and-launch
description: "Pre-launch checklists, feature flag lifecycle, staged rollouts, rollback procedures, monitoring setup. Invoke when preparing to deploy to production, or when user says /ship. | 上线前检查清单、特性开关生命周期、分阶段发布、回滚流程、监控设置。准备部署到生产环境时，或用户说 /ship 时触发。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🚀",
        "requires": {}
      }
  }
---
# Shipping and Launch

Ship with confidence. Faster is safer when you have the right safeguards.

## Overview

Shipping is not the end—it's a transition from development to production. This skill ensures safe rollout through feature flags, staged rollouts, monitoring, and rollback procedures.

Key principles:
- **Feature flags**: Every significant change is behind a flag
- **Staged rollout**: Start small, expand gradually
- **Rollback capability**: Always have a way to revert
- **Monitoring**: Watch for problems in production

## When to Use

**Activate this skill when:**
- User says `/ship` or asks to "deploy" or "launch"
- Feature is complete and ready for production
- Preparing to enable a feature flag in production
- Rolling out a new capability

**Do not activate for:**
- Development/testing environments
- Revert operations (use rollback directly)

## Process

### Step 1: Pre-Launch Checklist

```markdown
## Pre-Launch Checklist

### Code Quality
- [ ] All tests passing
- [ ] Code reviewed and approved
- [ ] No blocking issues in review
- [ ] Test coverage adequate

### Feature Flags
- [ ] Feature flag exists for new functionality
- [ ] Default state is OFF
- [ ] Flag is controllable in production

### Monitoring
- [ ] Metrics for new functionality defined
- [ ] Alerts configured for errors
- [ ] Dashboard updated

### Rollback
- [ ] Rollback procedure documented
- [ ] Previous version is deployable
- [ ] Data migration rollback tested (if applicable)

### Documentation
- [ ] Changelog updated
- [ ] Runbook updated
- [ ] Team notified of change
```

### Step 2: Staged Rollout

Follow this rollout sequence:

**Stage 1: Internal (0-5%)**
- Enable for internal users only
- Monitor for 24-48 hours
- Watch error rates and user feedback

**Stage 2: Beta (5-25%)**
- Enable for beta users
- Monitor for 48-72 hours
- Collect metrics and feedback

**Stage 3: General (25-100%)**
- Gradually increase traffic
- Monitor at each stage
- Full rollout over 1-2 weeks

### Step 3: Feature Flag Lifecycle

1. Feature flag created -> Default OFF
2. Development complete -> INTERNAL
3. Internal testing passed -> BETA
4. Beta testing passed -> ROLLOUT
5. Rollout complete -> FULL
6. Cleanup needed -> REMOVED

### Step 4: Rollback Procedure

If issues detected:

1. **Immediate**: Disable feature flag
2. **Assess**: Determine root cause
3. **Communicate**: Notify team of issue
4. **Fix**: Address in development
5. **Test**: Verify fix in staging
6. **Resume**: Continue rollout when ready

### Step 5: Post-Launch Monitoring

After each stage, verify:

- **Error rates**: No increase from baseline
- **Latency**: No significant regression
- **Metrics**: Expected behavior in dashboards
- **User feedback**: No negative signals

### Step 6: Documentation

Update for production:

1. **Changelog**: What changed, why
2. **Runbook**: How to operate, troubleshoot
3. **Alerts**: What to watch for
4. **Metrics**: What to measure

## Rationalizations

| Excuse | Rebuttal |
|--------|----------|
| "It's working in dev, it'll work in prod" | Production load and data are different. Stage rollout. |
| "Feature flags slow me down" | Flags enable safe rollout. The overhead is necessary. |
| "I'll monitor after launch" | By then it's too late. Monitor during rollout. |
| "Rollback is too hard" | Harder to debug in production. Practice rollback first. |

## Red Flags

- No feature flag for significant change
- Direct rollout to 100% without staging
- No monitoring for new functionality
- Rollback procedure not documented
- Changes going to production without review

## Verification

**Evidence that shipping is safe:**

- [ ] Pre-launch checklist completed
- [ ] Feature flag used for new functionality
- [ ] Staged rollout followed (not direct to 100%)
- [ ] Monitoring in place
- [ ] Rollback procedure documented
- [ ] Team notified of change
