---
name: chat-regression-tests
description: "18 test cases for chat system regression protection. Invoke when modifying chat-related code, SSE streaming, or frontend rendering. | 18个聊天系统回归测试用例。当修改聊天相关代码、SSE流或前端渲染时触发。"
metadata:
  {
    "builtin_skill_version": "1.0",
    "xingzierai":
      {
        "emoji": "🧪",
        "requires": {}
      }
  }
---
# Chat Regression Tests

18 test cases protecting the chat system from regressions.

## When to Use

- Before merging changes to chat-related code
- After modifying SSE streaming logic
- After modifying frontend chat components
- After modifying react_agent.py
- As part of pre-launch verification

## Test Cases

### TC-1: Long Context No Interruption
- **Test**: Send a message requiring 2000+ character response
- **Verify**: Response is complete, not truncated
- **Error keywords**: "stream ended prematurely", "incomplete response"

### TC-2: SSE Stream No Message Loss
- **Test**: Send 5 rapid messages
- **Verify**: All 5 responses are received, event count matches
- **Error keywords**: "missing response", "event count mismatch"

### TC-3: Health Check No Stream Interruption
- **Test**: Start a long response, then trigger health check
- **Verify**: Active stream continues, health check returns OK
- **Error keywords**: "stream interrupted by health check"

### TC-4: SSE Active No Refresh
- **Test**: Try to refresh page during active SSE stream
- **Verify**: Confirmation dialog appears, or stream completes before refresh
- **Error keywords**: "data loss on refresh"

### TC-5: Session Switch No Message Loss
- **Test**: Switch between sessions rapidly
- **Verify**: Messages in each session are complete
- **Error keywords**: "cross-session message leak"

### TC-6: Delete Session Auto Switch
- **Test**: Delete current session
- **Verify**: Automatically switches to adjacent session
- **Error keywords**: "no active session after delete"

### TC-7: Stop Button Interrupts Tool
- **Test**: Start a tool execution, click stop
- **Verify**: Tool execution is interrupted, partial result shown
- **Error keywords**: "tool execution not interruptible"

### TC-8: Tool Exception No Empty Result
- **Test**: Trigger a tool that throws an exception
- **Verify**: Error message is displayed, not blank
- **Error keywords**: "empty response after tool error"

### TC-9: stateMapRef Unbounded Growth Prevention
- **Test**: Send 100+ messages in one session
- **Verify**: Memory usage stabilizes, doesn't grow linearly
- **Error keywords**: "memory leak in stateMapRef"

### TC-10: ReadableStream Reader Release
- **Test**: Start and stop multiple streams rapidly
- **Verify**: No "reader already released" errors in console
- **Error keywords**: "reader is already released", "ReadableStream"

### TC-11: Empty Response Fallback
- **Test**: Trigger a scenario that produces empty LLM response
- **Verify**: Fallback message is shown, not blank
- **Error keywords**: "blank response", "empty message"

### TC-12: SSE Progressive Timeout
- **Test**: Start a long tool execution (>60s)
- **Verify**: Stream doesn't timeout during tool execution
- **Error keywords**: "SSE timeout during tool execution"

### TC-13: Error Message Localization
- **Test**: Trigger various error conditions
- **Verify**: Error messages are in Chinese (for zh locale)
- **Error keywords**: "unlocalized error message"

### TC-14: API Check No Chat Block
- **Test**: Start chat while API health check is running
- **Verify**: Chat is not blocked by health check
- **Error keywords**: "chat blocked by API check"

### TC-15: Page Refresh No Message Loss
- **Test**: Send messages, refresh page
- **Verify**: All messages are restored from backend
- **Error keywords**: "messages lost after refresh"

### TC-16: Thinking-Only No Empty Error
- **Test**: Trigger a thinking-only response (no content)
- **Verify**: Thinking content is displayed, no error thrown
- **Error keywords**: "thinking-only triggers error"

### TC-17: SSE Buffer Overflow Resource Release
- **Test**: Send very large response (>100KB)
- **Verify**: Buffer is released after processing, no memory leak
- **Error keywords**: "buffer overflow", "memory not released"

### TC-18: SSE Completed ReadLoop Continue
- **Test**: Normal stream completion
- **Verify**: readLoop terminates cleanly after "completed" event
- **Error keywords**: "readLoop continues after completed"

### TC-19: Backend Unavailable Graceful Degradation
- **Test**: Stop backend service (port 8565), then open frontend
- **Verify**: Shows "Service unavailable" or "Backend not running" message, NOT misleading error like "Is VITE_API_BASE_URL configured correctly?"
- **Error keywords**: "Unexpected API response", "VITE_API_BASE_URL", "502 Bad Gateway"

### TC-20: API Response Type Mismatch Detection
- **Test**: Mock backend to return JSON object instead of expected array
- **Verify**: Frontend shows descriptive error with response type info, NOT generic "Unexpected API response"
- **Error keywords**: "expected array, got object", "type mismatch"

## Verification Command

After modifying chat-related code, run:

```bash
python3 scripts/sse_debug.py --quick
```

## Red Flags

- Any TC that previously passed now fails
- New TC needed for a bug not covered above
- Test passes locally but fails in production
