# -*- coding: utf-8 -*-
"""CoPaw Agents Module.

This module provides the main agent implementation and supporting utilities
for building AI agents with tools, skills, and memory management.

Public API:
- CoPawAgent: Main agent class
- create_model_and_formatter: Factory for creating models and formatters

Example:
    >>> from xingzierai.agents import CoPawAgent, create_model_and_formatter
    >>> agent = CoPawAgent()
    >>> # Or with custom model
    >>> model, formatter = create_model_and_formatter()
"""

# CoPawAgent is lazy-loaded so that importing agents.skills_manager (e.g.
# from CLI init_cmd/skills_cmd) does not pull react_agent, agentscope, tools.
# pylint: disable=undefined-all-variable
__all__ = [
    "CoPawAgent",
    "create_model_and_formatter",
    "PlanEngine",
    "PlanModeMixin",
    "PriorityQueue",
    "StopCommandMixin",
    "PersonaManager",
    "PersonaMixin",
    "PersonaType",
    "PERSONAS",
]


def __getattr__(name: str):
    """Lazy load heavy imports."""
    if name == "CoPawAgent":
        from .react_agent import CoPawAgent

        return CoPawAgent
    if name == "create_model_and_formatter":
        from .model_factory import create_model_and_formatter

        return create_model_and_formatter
    if name == "PlanEngine":
        from .plan_engine import PlanEngine

        return PlanEngine
    if name == "PlanModeMixin":
        from .plan_engine import PlanModeMixin

        return PlanModeMixin
    if name == "PriorityQueue":
        from .priority_queue import PriorityQueue

        return PriorityQueue
    if name == "StopCommandMixin":
        from .priority_queue import StopCommandMixin

        return StopCommandMixin
    if name == "PersonaManager":
        from .persona import PersonaManager

        return PersonaManager
    if name == "PersonaMixin":
        from .persona import PersonaMixin

        return PersonaMixin
    if name == "PersonaType":
        from .persona import PersonaType

        return PersonaType
    if name == "PERSONAS":
        from .persona import PERSONAS

        return PERSONAS
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
