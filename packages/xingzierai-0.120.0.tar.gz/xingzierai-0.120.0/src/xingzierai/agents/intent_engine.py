# -*- coding: utf-8 -*-
"""Intent Engine - 意图引擎.

Maintains user preferences and provides proactive suggestions based on
system evolution and user behavior patterns.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .evolution.engine import PatchResult

logger = logging.getLogger(__name__)


class PreferenceLevel(str, Enum):
    PREF_LOW = "low"
    PREF_NORMAL = "normal"
    PREF_HIGH = "high"


@dataclass
class UserPreference:
    key: str
    value: Any
    level: PreferenceLevel = field(default_factory=lambda: PreferenceLevel.PREF_NORMAL)
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class UserProfile:
    user_id: str
    preferences: Dict[str, UserPreference] = field(default_factory=dict)
    behavior_history: List[Dict[str, Any]] = field(default_factory=list)
    interaction_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now().isoformat())

    def add_behavior(self, behavior_type: str, details: Dict[str, Any]) -> None:
        self.behavior_history.append({
            "type": behavior_type,
            "details": details,
            "timestamp": datetime.now().isoformat(),
        })
        if len(self.behavior_history) > 100:
            self.behavior_history = self.behavior_history[-100:]

    def set_preference(self, key: str, value: Any, level: PreferenceLevel = None) -> None:
        if level is None:
            level = PreferenceLevel.PREF_NORMAL
        self.preferences[key] = UserPreference(
            key=key,
            value=value,
            level=level,
            updated_at=datetime.now().isoformat(),
        )

    def get_preference(self, key: str, default: Any = None) -> Any:
        pref = self.preferences.get(key)
        return pref.value if pref else default


class ProactiveSuggestion:
    """Represents a proactive suggestion to the user."""

    def __init__(
        self,
        suggestion_id: str,
        title: str,
        description: str,
        action_type: str,
        priority: str = "normal",
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.suggestion_id = suggestion_id
        self.title = title
        self.description = description
        self.action_type = action_type
        self.priority = priority
        self.metadata = metadata or {}
        self.created_at = datetime.now().isoformat()
        self.dismissed = False
        self.applied = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suggestion_id": self.suggestion_id,
            "title": self.title,
            "description": self.description,
            "action_type": self.action_type,
            "priority": self.priority,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "dismissed": self.dismissed,
            "applied": self.applied,
        }


class IntentEngine:
    """Intent Engine - 意图引擎.

    Maintains user preferences and generates proactive suggestions
    when the system performs significant self-evolution.

    Principles (from Yi Jing):
    - Harmony with user workflow
    - Proactive but non-intrusive
    - Learning from user feedback
    """

    def __init__(
        self,
        workspace_dir: Path,
        profile_path: Optional[Path] = None,
    ):
        self.workspace_dir = workspace_dir
        self.profile_path = profile_path or (workspace_dir / "user_profile.json")
        self.suggestions_path = workspace_dir / "suggestions.json"

        self._profile: Optional[UserProfile] = None
        self._suggestions: List[ProactiveSuggestion] = []
        self._load_profile()

    def _load_profile(self) -> None:
        """Load user profile from disk."""
        if self.profile_path.exists():
            try:
                data = json.loads(self.profile_path.read_text(encoding="utf-8"))
                prefs = {}
                for k, v in data.get("preferences", {}).items():
                    prefs[k] = UserPreference(
                        key=v["key"],
                        value=v["value"],
                        level=PreferenceLevel(v.get("level", "normal")),
                        updated_at=v.get("updated_at", datetime.now().isoformat()),
                    )

                self._profile = UserProfile(
                    user_id=data.get("user_id", "default"),
                    preferences=prefs,
                    behavior_history=data.get("behavior_history", []),
                    interaction_count=data.get("interaction_count", 0),
                    created_at=data.get("created_at", datetime.now().isoformat()),
                    last_seen=data.get("last_seen", datetime.now().isoformat()),
                )
                logger.info(f"Loaded user profile: {self._profile.user_id}")
            except Exception as e:
                logger.warning(f"Failed to load profile: {e}")
                self._profile = UserProfile(user_id="default")
        else:
            self._profile = UserProfile(user_id="default")

        self._load_suggestions()

    def _load_suggestions(self) -> None:
        """Load pending suggestions from disk."""
        if self.suggestions_path.exists():
            try:
                data = json.loads(self.suggestions_path.read_text(encoding="utf-8"))
                for s in data.get("suggestions", []):
                    suggestion = ProactiveSuggestion(
                        suggestion_id=s["suggestion_id"],
                        title=s["title"],
                        description=s["description"],
                        action_type=s["action_type"],
                        priority=s.get("priority", "normal"),
                        metadata=s.get("metadata", {}),
                    )
                    suggestion.dismissed = s.get("dismissed", False)
                    suggestion.applied = s.get("applied", False)
                    self._suggestions.append(suggestion)
            except Exception as e:
                logger.warning(f"Failed to load suggestions: {e}")

    def _save_profile(self) -> None:
        """Save user profile to disk."""
        if not self._profile:
            return

        data = {
            "user_id": self._profile.user_id,
            "preferences": {
                k: {
                    "key": v.key,
                    "value": v.value,
                    "level": v.level.value,
                    "updated_at": v.updated_at,
                }
                for k, v in self._profile.preferences.items()
            },
            "behavior_history": self._profile.behavior_history[-50:],
            "interaction_count": self._profile.interaction_count,
            "created_at": self._profile.created_at,
            "last_seen": datetime.now().isoformat(),
        }

        self.profile_path.parent.mkdir(parents=True, exist_ok=True)
        self.profile_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def _save_suggestions(self) -> None:
        """Save suggestions to disk."""
        data = {
            "suggestions": [s.to_dict() for s in self._suggestions[-20:]]
        }
        self.suggestions_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    @property
    def profile(self) -> UserProfile:
        if not self._profile:
            self._load_profile()
        return self._profile

    def update_preference(
        self,
        key: str,
        value: Any,
        level: PreferenceLevel = None,
    ) -> None:
        """Update a user preference.

        Args:
            key: Preference key
            value: Preference value
            level: How important this preference is
        """
        if level is None:
            level = PreferenceLevel.PREF_NORMAL
        self.profile.set_preference(key, value, level)
        self._save_profile()
        logger.info(f"Updated preference: {key} = {value} (level: {level})")

    def record_behavior(
        self,
        behavior_type: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Record a user behavior for learning.

        Args:
            behavior_type: Type of behavior
            details: Additional details
        """
        self.profile.add_behavior(behavior_type, details or {})
        self.profile.interaction_count += 1
        self.profile.last_seen = datetime.now().isoformat()
        self._save_profile()

    def should_auto_execute(self, action_type: str) -> bool:
        """Determine if an action should be auto-executed based on preferences.

        Args:
            action_type: Type of action

        Returns:
            True if auto-execution is preferred
        """
        auto_execute = self.profile.get_preference("auto_execute_low_risk", True)
        hates_waiting = self.profile.get_preference("hates_waiting", False)

        if hates_waiting and action_type in ("patch", "fix", "refactor"):
            return True

        if auto_execute and action_type in ("skill_update", "tool_fix"):
            return True

        return False

    def generate_evolution_suggestion(
        self,
        evolution_type: str,
        details: Dict[str, Any],
        test_passed: bool = True,
    ) -> Optional[ProactiveSuggestion]:
        """Generate a proactive suggestion after system evolution.

        Args:
            evolution_type: Type of evolution (e.g., 'skill_update', 'core_patch')
            details: Evolution details
            test_passed: Whether tests passed

        Returns:
            ProactiveSuggestion if conditions are met
        """
        if not test_passed:
            return None

        suggestion_id = f"sug_{datetime.now().strftime('%Y%m%d%H%M%S')}"

        if evolution_type == "skill_update":
            title = f"系统已自我优化: {details.get('skill_name', '技能')}"
            description = (
                f"系统已完成 {details.get('skill_name', '技能')} 的升级，"
                f"测试 100% 通过。准备就绪，是否立即应用？"
            )
            action_type = "apply_skill_update"

        elif evolution_type == "core_patch":
            title = f"核心模块更新待审批"
            description = (
                f"系统已为核心模块 {details.get('module_name', 'Unknown')} "
                f"准备好更新补丁。请确认是否批准？"
            )
            action_type = "approve_core_patch"

        elif evolution_type == "bug_fix":
            title = f"Bug 已修复"
            description = (
                f"系统已自动修复 {details.get('bug_description', '问题')}。"
                f"修复已通过验证，是否需要通知您？"
            )
            action_type = "notify_fix"

        else:
            title = f"系统升级完成"
            description = f"系统已完成升级，准备就绪。"
            action_type = "general_update"

        suggestion = ProactiveSuggestion(
            suggestion_id=suggestion_id,
            title=title,
            description=description,
            action_type=action_type,
            priority=details.get("priority", "normal"),
            metadata=details,
        )

        self._suggestions.append(suggestion)
        self._save_suggestions()

        logger.info(f"Generated proactive suggestion: {title}")
        return suggestion

    def get_pending_suggestions(self) -> List[ProactiveSuggestion]:
        """Get all pending (not dismissed) suggestions."""
        return [s for s in self._suggestions if not s.dismissed and not s.applied]

    def dismiss_suggestion(self, suggestion_id: str) -> bool:
        """Dismiss a suggestion.

        Args:
            suggestion_id: ID of suggestion to dismiss

        Returns:
            True if dismissed successfully
        """
        for s in self._suggestions:
            if s.suggestion_id == suggestion_id:
                s.dismissed = True
                self._save_suggestions()
                logger.info(f"Dismissed suggestion: {suggestion_id}")
                return True
        return False

    def apply_suggestion(self, suggestion_id: str) -> bool:
        """Mark a suggestion as applied.

        Args:
            suggestion_id: ID of suggestion to mark as applied

        Returns:
            True if applied successfully
        """
        for s in self._suggestions:
            if s.suggestion_id == suggestion_id:
                s.applied = True
                self._save_suggestions()
                logger.info(f"Applied suggestion: {suggestion_id}")
                return True
        return False

    def get_user_workflow_analysis(self) -> Dict[str, Any]:
        """Analyze user's workflow patterns."""
        behaviors = self.profile.behavior_history

        action_counts: Dict[str, int] = {}
        for b in behaviors:
            action_type = b.get("type", "unknown")
            action_counts[action_type] = action_counts.get(action_type, 0) + 1

        avg_interactions_per_day = 0
        if behaviors:
            try:
                first_behavior = datetime.fromisoformat(behaviors[0]["timestamp"])
                last_behavior = datetime.fromisoformat(behaviors[-1]["timestamp"])
                days = max(1, (last_behavior - first_behavior).days)
                avg_interactions_per_day = self.profile.interaction_count / days
            except Exception:
                pass

        return {
            "user_id": self.profile.user_id,
            "total_interactions": self.profile.interaction_count,
            "avg_interactions_per_day": round(avg_interactions_per_day, 1),
            "action_distribution": action_counts,
            "preferences": {
                k: {"value": v.value, "level": v.level.value}
                for k, v in self.profile.preferences.items()
            },
            "last_seen": self.profile.last_seen,
        }


def create_intent_engine(workspace_dir: Optional[Path] = None) -> IntentEngine:
    """Factory function to create an IntentEngine.

    Args:
        workspace_dir: Workspace directory

    Returns:
        Configured IntentEngine instance
    """
    workspace = workspace_dir or Path.cwd()
    return IntentEngine(workspace_dir=workspace)
