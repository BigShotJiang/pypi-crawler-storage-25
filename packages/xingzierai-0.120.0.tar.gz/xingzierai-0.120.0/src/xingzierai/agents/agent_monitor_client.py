# -*- coding: utf-8 -*-
"""Agent Monitor Client - Lightweight activity monitoring for agents."""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class AgentMonitorConfig:
    agent_id: str = "default"
    enabled: bool = True
    report_interval: float = 5.0
    max_events: int = 1000


class AgentMonitorClient:
    """Lightweight agent activity monitor.

    Records agent events for observability without external dependencies.
    """

    def __init__(self, config: AgentMonitorConfig):
        self.config = config
        self._events: List[Dict[str, Any]] = []
        self._started = False

    def start(self) -> None:
        self._started = True

    def stop(self) -> None:
        self._started = False

    def log_activity(
        self,
        message: str,
        activity_type: str = "generic",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not self.config.enabled or not self._started:
            return

        event = {
            "agent_id": self.config.agent_id,
            "type": activity_type,
            "message": message[:500],
            "metadata": metadata or {},
            "timestamp": time.time(),
        }
        self._events.append(event)

        if len(self._events) > self.config.max_events:
            self._events = self._events[-self.config.max_events:]

    def get_events(self, limit: int = 100) -> List[Dict[str, Any]]:
        return self._events[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        return {
            "agent_id": self.config.agent_id,
            "enabled": self.config.enabled,
            "started": self._started,
            "total_events": len(self._events),
        }
