# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core._logging import logger


class ModuleContextService:
    """Module context service for auto-loading AGENT.md files.

    When the Agent operates on a file, this service automatically loads
    the relevant AGENT.md from the file's directory and parent directories,
    providing precise module-level context for the AI.
    """

    def __init__(self, project_root: Optional[str] = None):
        self._project_root = Path(project_root) if project_root else None
        self._cache: dict[str, str] = {}

    def get_context_for_path(self, file_path: str) -> str:
        """Get relevant AGENT.md content for a file path.

        Searches from the file's directory up to the project root,
        collecting all AGENT.md files found along the way.

        Args:
            file_path: The file path the Agent is working on

        Returns:
            Concatenated AGENT.md content from all relevant directories
        """
        if file_path in self._cache:
            return self._cache[file_path]

        contexts = []
        path = Path(file_path).resolve()

        if self._project_root:
            root = self._project_root.resolve()
        else:
            root = path.root

        current = path.parent if path.is_file() else path

        while current >= root:
            agent_md = current / "AGENT.md"
            if agent_md.exists():
                try:
                    content = agent_md.read_text(encoding="utf-8")
                    rel_path = current.relative_to(root) if self._project_root else current
                    contexts.append(f"## Module: {rel_path}\n\n{content}")
                except Exception as e:
                    logger.debug("Failed to read AGENT.md at %s: %s", agent_md, e)
            parent = current.parent
            if parent == current:
                break
            current = parent

        result = "\n\n---\n\n".join(reversed(contexts))
        self._cache[file_path] = result
        return result

    def get_context_for_directory(self, directory: str) -> str:
        """Get AGENT.md content for a specific directory."""
        agent_md = Path(directory) / "AGENT.md"
        if agent_md.exists():
            try:
                return agent_md.read_text(encoding="utf-8")
            except Exception:
                return ""
        return ""

    def sync_after_change(
        self,
        file_path: str,
        change_description: str,
    ) -> list[str]:
        """After code changes, identify which AGENT.md files might need updating.

        Returns:
            List of AGENT.md paths that should be reviewed for updates
        """
        self._cache.pop(file_path, None)

        stale_agents = []
        path = Path(file_path).resolve()

        if self._project_root:
            root = self._project_root.resolve()
        else:
            root = path.root

        current = path.parent
        while current >= root:
            agent_md = current / "AGENT.md"
            if agent_md.exists():
                stale_agents.append(str(agent_md))
            parent = current.parent
            if parent == current:
                break
            current = parent

        return stale_agents

    def audit_staleness(self) -> list[dict]:
        """Audit all AGENT.md files for staleness.

        Returns:
            List of dicts with path and last_modified info
        """
        if not self._project_root:
            return []

        results = []
        for agent_md in self._project_root.rglob("AGENT.md"):
            try:
                stat = agent_md.stat()
                results.append({
                    "path": str(agent_md.relative_to(self._project_root)),
                    "last_modified": stat.st_mtime,
                    "size_bytes": stat.st_size,
                })
            except Exception:
                continue

        return results
