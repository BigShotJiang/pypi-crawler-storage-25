# -*- coding: utf-8 -*-
"""Factory for creating chat models and formatters.

This module provides a unified factory for creating chat model instances
and their corresponding formatters based on configuration.

Example:
    >>> from xingzierai.agents.model_factory import create_model_and_formatter
    >>> model, formatter = create_model_and_formatter()
"""


import logging
from typing import List, Sequence, Tuple, Type, Any, Union, Optional

from xingzierai.agentscope_core.formatter import FormatterBase, OpenAIChatFormatter
from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.model import ChatModelBase, OpenAIChatModel

try:
    from xingzierai.agentscope_core.formatter import AnthropicChatFormatter
    from xingzierai.agentscope_core.model import AnthropicChatModel
except ImportError:  # pragma: no cover - compatibility fallback
    AnthropicChatFormatter = None
    AnthropicChatModel = None

try:
    from xingzierai.agentscope_core.formatter import GeminiChatFormatter
    from xingzierai.agentscope_core.model import GeminiChatModel
except ImportError:  # pragma: no cover - compatibility fallback
    GeminiChatFormatter = None
    GeminiChatModel = None

from .utils.tool_message_utils import _sanitize_tool_messages
from ..providers import ProviderManager
from ..providers.retry_chat_model import RetryChatModel, RetryConfig, FallbackChatModel
from ..token_usage import TokenRecordingModelWrapper


def _file_url_to_path(url: str) -> str:
    """
    Strip file:// to path. On Windows file:///C:/path -> C:/path not /C:/path.
    """
    s = url.removeprefix("file://")
    # Windows: file:///C:/path yields "/C:/path"; remove leading slash.
    if len(s) >= 3 and s.startswith("/") and s[1].isalpha() and s[2] == ":":
        s = s[1:]
    return s


logger = logging.getLogger(__name__)


# Mapping from chat model class to formatter class
_CHAT_MODEL_FORMATTER_MAP: dict[Type[ChatModelBase], Type[FormatterBase]] = {
    OpenAIChatModel: OpenAIChatFormatter,
}
if AnthropicChatModel is not None and AnthropicChatFormatter is not None:
    _CHAT_MODEL_FORMATTER_MAP[AnthropicChatModel] = AnthropicChatFormatter
if GeminiChatModel is not None and GeminiChatFormatter is not None:
    _CHAT_MODEL_FORMATTER_MAP[GeminiChatModel] = GeminiChatFormatter


def _get_formatter_for_chat_model(
    chat_model_class: Type[ChatModelBase],
) -> Type[FormatterBase]:
    """Get the appropriate formatter class for a chat model.

    Args:
        chat_model_class: The chat model class

    Returns:
        Corresponding formatter class, defaults to OpenAIChatFormatter
    """
    return _CHAT_MODEL_FORMATTER_MAP.get(
        chat_model_class,
        OpenAIChatFormatter,
    )


# pylint: disable-next=too-many-statements
def _create_file_block_support_formatter(
    base_formatter_class: Type[FormatterBase],
) -> Type[FormatterBase]:
    """Create a formatter class with file block support.

    This factory function extends any Formatter class to support file blocks
    in tool results, which are not natively supported by AgentScope.

    Args:
        base_formatter_class: Base formatter class to extend

    Returns:
        Enhanced formatter class with file block support
    """

    class FileBlockSupportFormatter(base_formatter_class):
        """Formatter with file block support for tool results."""

        # pylint: disable=too-many-branches
        async def _format(self, msgs):
            """Override to sanitize tool messages, handle thinking blocks,
            and relay ``extra_content`` (Gemini thought_signature).

            This prevents OpenAI API errors from improperly paired
            tool messages, preserves reasoning_content from "thinking"
            blocks that the base formatter skips, and ensures
            ``extra_content`` on tool_use blocks (e.g. Gemini
            thought_signature) is carried through to the API request.
            """
            msgs = _sanitize_tool_messages(msgs)

            reasoning_contents = {}
            extra_contents: dict[str, Any] = {}
            for msg in msgs:
                if msg.role != "assistant":
                    continue
                for block in msg.get_content_blocks():
                    if block.get("type") == "thinking":
                        thinking = block.get("thinking", "")
                        if thinking:
                            reasoning_contents[id(msg)] = thinking
                        break
                for block in msg.get_content_blocks():
                    if (
                        block.get("type") == "tool_use"
                        and "extra_content" in block
                    ):
                        extra_contents[block["id"]] = block["extra_content"]

            # Convert file:// URLs to paths,
            # TODO: remove this after AgentScope updated
            for msg in msgs:
                for block in msg.get_content_blocks():
                    if block.get("type") == "audio":
                        source = block.get("source")
                        if (
                            isinstance(source, dict)
                            and source.get("type") == "url"
                            and isinstance(source.get("url"), str)
                            and source["url"].startswith("file://")
                        ):
                            source["url"] = _file_url_to_path(source["url"])

            _RC_PLACEHOLDER = "\x00rc_placeholder"
            thinking_only_ids: set[int] = set()
            for msg in msgs:
                if msg.role != "assistant" or id(msg) not in reasoning_contents:
                    continue
                if isinstance(msg.content, list) and msg.content:
                    has_non_thinking = any(
                        b.get("type") != "thinking" for b in msg.content
                    )
                    if not has_non_thinking:
                        thinking_only_ids.add(id(msg))
                        msg.content = [
                            *msg.content,
                            TextBlock(type="text", text=_RC_PLACEHOLDER),
                        ]

            messages = await super()._format(msgs)

            for msg in msgs:
                if id(msg) in thinking_only_ids:
                    msg.content = [
                        b
                        for b in msg.content
                        if not (
                            b.get("type") == "text"
                            and b.get("text") == _RC_PLACEHOLDER
                        )
                    ]

            if extra_contents:
                for message in messages:
                    for tc in message.get("tool_calls", []):
                        ec = extra_contents.get(tc.get("id"))
                        if ec:
                            tc["extra_content"] = ec

            if reasoning_contents:
                aligned_reasoning = []
                for m in (msg for msg in msgs if msg.role == "assistant"):
                    aligned_reasoning.append(
                        reasoning_contents.get(id(m)),
                    )

                out_assistant = [
                    m for m in messages if m.get("role") == "assistant"
                ]

                if len(aligned_reasoning) != len(out_assistant):
                    logger.warning(
                        "Assistant message count mismatch after formatting "
                        "(%d expected survivors, %d actual). "
                        "Skipping reasoning_content injection.",
                        len(aligned_reasoning),
                        len(out_assistant),
                    )
                else:
                    for i, out_msg in enumerate(out_assistant):
                        rc = aligned_reasoning[i]
                        if rc:
                            out_msg["reasoning_content"] = rc
                        content = out_msg.get("content")
                        if isinstance(content, list) and len(content) == 1:
                            block = content[0]
                            if (
                                isinstance(block, dict)
                                and block.get("type") == "text"
                                and block.get("text") == _RC_PLACEHOLDER
                            ):
                                out_msg["content"] = None

            return _strip_top_level_message_name(messages)

        @staticmethod
        def convert_tool_result_to_string(
            output: Union[str, List[dict]],
        ) -> tuple[str, Sequence[Tuple[str, dict]]]:
            """Extend parent class to support file blocks.

            Uses try-first strategy for compatibility with parent class.

            Args:
                output: Tool result output (string or list of blocks)

            Returns:
                Tuple of (text_representation, multimodal_data)
            """
            if isinstance(output, str):
                return output, []

            # Try parent class method first
            try:
                return base_formatter_class.convert_tool_result_to_string(
                    output,
                )
            except ValueError as e:
                if "Unsupported block type: file" not in str(e):
                    raise

                # Handle output containing file blocks
                textual_output = []
                multimodal_data = []

                for block in output:
                    if not isinstance(block, dict) or "type" not in block:
                        raise ValueError(
                            f"Invalid block: {block}, "
                            "expected a dict with 'type' key",
                        ) from e

                    if block["type"] == "file":
                        file_path = block.get("path", "") or block.get(
                            "url",
                            "",
                        )
                        file_name = block.get("name", file_path)

                        textual_output.append(
                            f"The returned file '{file_name}' "
                            f"can be found at: {file_path}",
                        )
                        multimodal_data.append((file_path, block))
                    else:
                        # Delegate other block types to parent class
                        (
                            text,
                            data,
                        ) = base_formatter_class.convert_tool_result_to_string(
                            [block],
                        )
                        textual_output.append(text)
                        multimodal_data.extend(data)

                if len(textual_output) == 0:
                    return "", multimodal_data
                elif len(textual_output) == 1:
                    return textual_output[0], multimodal_data
                else:
                    return (
                        "\n".join("- " + _ for _ in textual_output),
                        multimodal_data,
                    )

    FileBlockSupportFormatter.__name__ = (
        f"FileBlockSupport{base_formatter_class.__name__}"
    )
    return FileBlockSupportFormatter


def _strip_top_level_message_name(
    messages: list[dict],
) -> list[dict]:
    """Strip top-level `name` from OpenAI chat messages.

    Some strict OpenAI-compatible backends reject `messages[*].name`
    (especially for assistant/tool roles) and may return 500/400 on
    follow-up turns. Keep function/tool names unchanged.
    """
    for message in messages:
        message.pop("name", None)
    return messages


def create_model_and_formatter(
    agent_id: Optional[str] = None,
) -> Tuple[ChatModelBase, FormatterBase]:
    """Factory method to create model and formatter instances.

    This method handles both local and remote models, selecting the
    appropriate chat model class and formatter based on configuration.

    When intelligent routing is enabled (AgentsLLMRoutingConfig.enabled),
    a RoutingChatModel is returned that routes between local, cloud, and
    free model slots based on task complexity.

    Args:
        agent_id: Optional agent ID to load agent-specific model config.
            If None, tries to get from context, then falls back to global.

    Returns:
        Tuple of (model_instance, formatter_instance)

    Example:
        >>> model, formatter = create_model_and_formatter()
    """
    from ..app.agent_context import get_current_agent_id
    from ..config.config import load_agent_config

    if agent_id is None:
        try:
            agent_id = get_current_agent_id()
        except Exception as _aid_err:
            logger.debug("Failed to get current agent_id: %s", _aid_err)

    routing_cfg = _load_routing_config(agent_id)
    if routing_cfg and routing_cfg.enabled:
        routed = _create_routed_model_and_formatter(agent_id, routing_cfg)
        if routed is not None:
            return routed

    model_slot = None
    retry_config = None
    agent_generate_kwargs = None
    if agent_id:
        try:
            agent_config = load_agent_config(agent_id)
            model_slot = agent_config.active_model
            retry_config = RetryConfig(
                enabled=agent_config.running.llm_retry_enabled,
                max_retries=agent_config.running.llm_max_retries,
                backoff_base=agent_config.running.llm_backoff_base,
                backoff_cap=agent_config.running.llm_backoff_cap,
            )
            agent_generate_kwargs = agent_config.running.agent_generate_kwargs
        except Exception as _cfg_err:
            logger.debug("Failed to load agent config for retries: %s", _cfg_err)

    if model_slot and model_slot.provider_id and model_slot.model:
        manager = ProviderManager.get_instance()
        provider = manager.get_provider(model_slot.provider_id)
        if provider is None:
            raise ValueError(
                f"Provider '{model_slot.provider_id}' not found.",
            )
        if provider.is_local:
            from ..local_models import create_local_chat_model

            local_kwargs = {**provider.generate_kwargs}
            if agent_generate_kwargs:
                local_kwargs.update(agent_generate_kwargs)
            if "max_tokens" not in local_kwargs:
                local_kwargs["max_tokens"] = None
            model = create_local_chat_model(
                model_id=model_slot.model,
                stream=True,
                generate_kwargs=local_kwargs,
            )
        else:
            from ..providers.param_adapter import create_provider_specific_kwargs
            
            merged_kwargs = {**provider.generate_kwargs}
            if agent_generate_kwargs:
                merged_kwargs.update(agent_generate_kwargs)
            
            adapted_kwargs = create_provider_specific_kwargs(
                model_slot.provider_id, merged_kwargs
            )
            model = provider.get_chat_model_instance(model_slot.model)
            if hasattr(model, '_generate_kwargs'):
                model._generate_kwargs = adapted_kwargs
            elif hasattr(model, 'generate_kwargs'):
                model.generate_kwargs = adapted_kwargs
        provider_id = model_slot.provider_id
    else:
        model = ProviderManager.get_active_chat_model()
        global_model = ProviderManager.get_instance().get_active_model()
        if not global_model:
            raise ValueError(
                "No active model configured. "
                "Please configure a model using 'xingzierai models config' "
                "or set an agent-specific model.",
            )
        provider_id = global_model.provider_id

    max_input_tokens = None
    if agent_id:
        try:
            agent_config = load_agent_config(agent_id)
            max_input_tokens = agent_config.running.max_input_length
        except Exception as _max_tok_err:
            logger.debug("Failed to load max_input_tokens from config: %s", _max_tok_err)
    if max_input_tokens is None:
        max_input_tokens = _get_max_input_tokens()
    formatter = _create_formatter_instance(model.__class__, max_tokens=max_input_tokens)

    wrapped_model = TokenRecordingModelWrapper(provider_id, model)
    wrapped_model = RetryChatModel(
        wrapped_model,
        retry_config=retry_config,
    )
    wrapped_model = FallbackChatModel(
        wrapped_model,
        provider_id=provider_id,
    )

    return wrapped_model, formatter


def _load_routing_config(agent_id: str | None):
    from ..config.config import load_agent_config
    try:
        if agent_id:
            agent_config = load_agent_config(agent_id)
            return getattr(agent_config, "llm_routing", None)
    except Exception as _routing_err:
        logger.debug("Failed to load routing config: %s", _routing_err)
    return None


def _create_routed_model_and_formatter(agent_id, routing_cfg):
    from .routing_chat_model import RoutingChatModel, RoutingEndpoint
    from ..config.config import load_agent_config

    manager = ProviderManager.get_instance()

    local_ep = _build_endpoint(manager, routing_cfg.local)
    cloud_ep = _build_endpoint(manager, routing_cfg.cloud)
    free_ep = _build_endpoint(manager, routing_cfg.free)

    if cloud_ep is None:
        try:
            agent_config = load_agent_config(agent_id)
            if agent_config and agent_config.active_model:
                cloud_ep = _build_endpoint(manager, agent_config.active_model)
                if cloud_ep:
                    logger.info(
                        "RoutingChatModel: using active_model %s/%s as cloud fallback",
                        cloud_ep.provider_id,
                        cloud_ep.model_name,
                    )
        except Exception as _cloud_fb_err:
            logger.debug("Cloud fallback from active_model failed: %s", _cloud_fb_err)

    if not any([local_ep, cloud_ep, free_ep]):
        logger.warning("Routing enabled but no endpoints available, falling back to direct model")
        return None

    primary_ep = free_ep or cloud_ep or local_ep
    formatter = _create_formatter_instance(
        primary_ep.model.__class__,
        max_tokens=_get_max_input_tokens(),
    )

    routing_model = RoutingChatModel(
        local_endpoint=local_ep,
        cloud_endpoint=cloud_ep,
        free_endpoint=free_ep,
        routing_cfg=routing_cfg,
    )

    wrapped = TokenRecordingModelWrapper(
        primary_ep.provider_id, routing_model
    )
    wrapped = RetryChatModel(wrapped)
    wrapped = FallbackChatModel(
        wrapped, provider_id=primary_ep.provider_id
    )

    return wrapped, formatter


def _build_endpoint(manager, slot_cfg):
    from .routing_chat_model import RoutingEndpoint

    if slot_cfg is None or not slot_cfg.provider_id or not slot_cfg.model:
        return None

    provider = manager.get_provider(slot_cfg.provider_id)
    if provider is None:
        return None

    try:
        if provider.is_local:
            from ..local_models import create_local_chat_model
            model = create_local_chat_model(
                model_id=slot_cfg.model,
                stream=True,
                generate_kwargs=provider.generate_kwargs,
            )
        else:
            model = provider.get_chat_model_instance(slot_cfg.model)

        formatter_class = _get_formatter_for_chat_model(model.__class__)
        return RoutingEndpoint(
            provider_id=slot_cfg.provider_id,
            model_name=slot_cfg.model,
            model=model,
            formatter=formatter_class(),
            formatter_family=formatter_class,
        )
    except Exception as e:
        logger.warning(
            "Failed to build endpoint for %s/%s: %s",
            slot_cfg.provider_id,
            slot_cfg.model,
            e,
        )
        return None


def _get_max_input_tokens() -> int | None:
    try:
        from ..config import load_config
        config = load_config()
        agents_config = getattr(config, "agents", None)
        if agents_config:
            default_running = getattr(agents_config, "default_running", None)
            if default_running and hasattr(default_running, "max_input_length"):
                return default_running.max_input_length
        return None
    except Exception as _max_inp_err:
        logger.debug("Failed to get max input tokens: %s", _max_inp_err)
        return None


def _create_formatter_instance(
    chat_model_class: Type[ChatModelBase],
    max_tokens: int | None = None,
) -> FormatterBase:
    """Create a formatter instance for the given chat model class.

    The formatter is enhanced with file block support for handling
    file outputs in tool results.

    Args:
        chat_model_class: The chat model class

    Returns:
        Formatter instance with file block support
    """
    base_formatter_class = _get_formatter_for_chat_model(chat_model_class)
    formatter_class = _create_file_block_support_formatter(
        base_formatter_class,
    )
    kwargs: dict[str, Any] = {}
    if max_tokens is not None:
        kwargs["max_tokens"] = max_tokens
    if issubclass(
        base_formatter_class,
        (OpenAIChatFormatter, GeminiChatFormatter),
    ):
        kwargs["promote_tool_result_images"] = True
    return formatter_class(**kwargs)


def get_smart_llm_client():
    """
    获取 SmartLLMClient 实例
    
    提供统一的智能模型切换客户端，自动处理：
    1. 模型选择
    2. 用量监控（80% 阈值）
    3. 429 限流自动切换
    4. 本地模型兜底
    
    Returns:
        SmartLLMClient: 智能 LLM 客户端实例
    
    Example:
        >>> client = get_smart_llm_client()
        >>> response = await client.ask("生成原理图")
    """
    from ..smart_llm_client import SmartLLMClient
    
    # 单例模式：避免重复创建实例
    if not hasattr(get_smart_llm_client, '_instance') or get_smart_llm_client._instance is None:
        config_path = None
        from pathlib import Path
        
        possible_paths = [
            Path.cwd() / "config.yaml",
            Path.home() / ".xingzierai" / "config.yaml",
        ]
        
        for path in possible_paths:
            if path.exists():
                config_path = str(path)
                break
        
        get_smart_llm_client._instance = SmartLLMClient(config_path=config_path)
    
    return get_smart_llm_client._instance


__all__ = [
    "create_model_and_formatter",
    "get_smart_llm_client",
]
