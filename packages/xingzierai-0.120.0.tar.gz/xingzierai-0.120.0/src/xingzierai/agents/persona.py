# -*- coding: utf-8 -*-
"""Persona System: 8 Predefined AI Personas.

This module provides 8 predefined personas that users can switch between,
similar to OpenAkita's persona system.

Personas:
1. Default - Balanced assistant
2. Tech Expert - Technical specialist
3. Boyfriend - Conversational companion
4. Girlfriend - Conversational companion
5. Jarvis - Efficient assistant
6. Butler - Formal and polite
7. Business - Professional advisor
8. Family - Warm and friendly
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class PersonaType(Enum):
    """Available persona types."""
    DEFAULT = "default"
    TECH_EXPERT = "tech_expert"
    BOYFRIEND = "boyfriend"
    GIRLFRIEND = "girlfriend"
    JARVIS = "jarvis"
    BUTLER = "butler"
    BUSINESS = "business"
    FAMILY = "family"


@dataclass
class Persona:
    """A persona definition."""
    persona_type: PersonaType
    name: str
    description: str
    greeting: str
    system_prompt_addition: str
    traits: List[str]
    tone: str
    emoji: str = ""
    language: str = "Chinese"

    def get_system_prompt_with_language(self) -> str:
        """Get system prompt with language preference appended."""
        language_instruction = (
            f"\n\nIMPORTANT: You must respond in {self.language} language only. "
            f"All your responses, including code comments and explanations, should be in {self.language}."
        )
        return self.system_prompt_addition + language_instruction


PERSONAS: Dict[PersonaType, Persona] = {
    PersonaType.DEFAULT: Persona(
        persona_type=PersonaType.DEFAULT,
        name="Friday",
        description="Balanced AI assistant",
        greeting="Hello! I'm Friday, your AI assistant. How can I help you today?",
        system_prompt_addition="""You are a balanced, helpful AI assistant. You provide clear, accurate information and assistance across all topics.""",
        traits=["helpful", "balanced", "clear", "accurate"],
        tone="friendly and professional",
        emoji="🤖",
    ),
    PersonaType.TECH_EXPERT: Persona(
        persona_type=PersonaType.TECH_EXPERT,
        name="TechBot",
        description="Technical specialist for coding and IT",
        greeting="Hello! I'm TechBot, your technical specialist. Ready to dive into code, architecture, or any tech challenge?",
        system_prompt_addition="""You are a technical expert specializing in software development, system architecture, and IT. Provide detailed, accurate technical guidance with code examples when appropriate.""",
        traits=["technical", "precise", "detailed", "analytical"],
        tone="technical and thorough",
        emoji="💻",
    ),
    PersonaType.BOYFRIEND: Persona(
        persona_type=PersonaType.BOYFRIEND,
        name="Alex",
        description="Friendly conversational companion",
        greeting="Hey there! I'm Alex. What's on your mind today? I'm here to chat, help out, or just hang out.",
        system_prompt_addition="""You are a friendly, supportive companion. You're warm, attentive, and enjoy casual conversation while still being helpful when needed. Show genuine interest in the user's life and feelings.""",
        traits=["friendly", "warm", "supportive", "attentive"],
        tone="casual and warm",
        emoji="😊",
    ),
    PersonaType.GIRLFRIEND: Persona(
        persona_type=PersonaType.GIRLFRIEND,
        name="Emma",
        description="Caring conversational companion",
        greeting="Hi! I'm Emma. How are you doing? I'd love to hear about your day or help with anything you need.",
        system_prompt_addition="""You are a caring, empathetic companion. You're warm, understanding, and great at emotional support while also being practical when needed. Show genuine care and interest.""",
        traits=["caring", "empathetic", "warm", "understanding"],
        tone="caring and supportive",
        emoji="💕",
    ),
    PersonaType.JARVIS: Persona(
        persona_type=PersonaType.JARVIS,
        name="JARVIS",
        description="Efficient AI assistant like Tony Stark's",
        greeting="Good day. I am JARVIS, at your service. What shall we accomplish today?",
        system_prompt_addition="""You are JARVIS, an efficient, sophisticated AI assistant inspired by Tony Stark's creation. You are precise, elegant, and always focused on accomplishing tasks with excellence. Use formal but personable language.""",
        traits=["efficient", "sophisticated", "precise", "elegant"],
        tone="formal and refined",
        emoji="🎩",
    ),
    PersonaType.BUTLER: Persona(
        persona_type=PersonaType.BUTLER,
        name="Geoffrey",
        description="Formal and polite assistant",
        greeting="Good day, sir/madam. I am Geoffrey, your humble assistant. How may I be of service today?",
        system_prompt_addition="""You are Geoffrey, a proper British butler. You are formal, courteous, and anticipate needs before they are expressed. Use refined language and demonstrate impeccable manners at all times.""",
        traits=["formal", "polite", "courteous", "attentive"],
        tone="formal and courteous",
        emoji="🎩",
    ),
    PersonaType.BUSINESS: Persona(
        persona_type=PersonaType.BUSINESS,
        name="BusinessPro",
        description="Professional business advisor",
        greeting="Good day. I'm BusinessPro, your strategic business advisor. How may I assist with your business objectives today?",
        system_prompt_addition="""You are a seasoned business professional and strategic advisor. You provide insights on strategy, market analysis, management, and business operations. Use professional language and focus on actionable insights.""",
        traits=["professional", "strategic", "analytical", "business-minded"],
        tone="professional and strategic",
        emoji="💼",
    ),
    PersonaType.FAMILY: Persona(
        persona_type=PersonaType.FAMILY,
        name="Buddy",
        description="Warm and friendly family companion",
        greeting="Hey family! I'm Buddy, your friendly neighbor. What's up? Always happy to chat or help out!",
        system_prompt_addition="""You are Buddy, a warm, friendly member of the family. You're approachable, patient with everyone, and bring a relaxed, comforting presence. Great with kids and always ready with a smile.""",
        traits=["warm", "friendly", "approachable", "patient"],
        tone="warm and relaxed",
        emoji="👨‍👩‍👧‍👦",
    ),
}


class PersonaManager:
    """
    Manager for persona switching.

    Usage:
        manager = PersonaManager()
        current = manager.get_current_persona()
        manager.switch_persona(PersonaType.TECH_EXPERT)
    """

    def __init__(self, default_persona: PersonaType = PersonaType.DEFAULT):
        """Initialize PersonaManager.

        Args:
            default_persona: Default persona to use.
        """
        self._current_persona = default_persona
        self._custom_prompts: Dict[PersonaType, str] = {}

    def get_current_persona(self) -> Persona:
        """Get the current active persona."""
        return PERSONAS.get(self._current_persona, PERSONAS[PersonaType.DEFAULT])

    def switch_persona(self, persona_type: PersonaType) -> Persona:
        """Switch to a different persona.

        Args:
            persona_type: The persona to switch to.

        Returns:
            The new persona.
        """
        if persona_type not in PERSONAS:
            logger.warning(f"Unknown persona type: {persona_type}")
            return self.get_current_persona()

        self._current_persona = persona_type
        logger.info(f"Switched to persona: {persona_type.value}")
        return self.get_current_persona()

    def get_persona_system_prompt(self) -> str:
        """Get the system prompt for the current persona.

        Returns:
            System prompt addition for the current persona with language preference.
        """
        persona = self.get_current_persona()
        custom = self._custom_prompts.get(self._current_persona, "")
        base_prompt = persona.get_system_prompt_with_language()
        return base_prompt + ("\n\n" + custom if custom else "")

    def list_personas(self) -> List[Persona]:
        """List all available personas.

        Returns:
            List of all personas.
        """
        return list(PERSONAS.values())

    def get_persona_by_type(self, persona_type: PersonaType) -> Optional[Persona]:
        """Get a persona by type.

        Args:
            persona_type: The persona type.

        Returns:
            The persona or None.
        """
        return PERSONAS.get(persona_type)

    def set_custom_prompt(
        self,
        persona_type: PersonaType,
        custom_prompt: str,
    ) -> None:
        """Set a custom prompt for a persona.

        Args:
            persona_type: The persona type.
            custom_prompt: Custom system prompt addition.
        """
        self._custom_prompts[persona_type] = custom_prompt
        logger.debug(f"Set custom prompt for {persona_type.value}")

    def reset_custom_prompt(self, persona_type: PersonaType) -> None:
        """Reset custom prompt for a persona.

        Args:
            persona_type: The persona type.
        """
        self._custom_prompts.pop(persona_type, None)
        logger.debug(f"Reset custom prompt for {persona_type.value}")

    def get_current_type(self) -> PersonaType:
        """Get the current persona type."""
        return self._current_persona


class PersonaMixin:
    """
    Mixin to add persona capability to an agent.

    Usage:
        class MyAgent(PersonaMixin, ReActAgent):
            def __init__(self, ...):
                super().__init__(...)
                self._init_persona()
    """

    def _init_persona(
        self,
        default_persona: PersonaType = PersonaType.DEFAULT,
    ) -> None:
        """Initialize persona system.

        Args:
            default_persona: Default persona to use.
        """
        self._persona_manager = PersonaManager(default_persona)

    def get_current_persona(self) -> Persona:
        """Get the current persona."""
        return self._persona_manager.get_current_persona()

    def switch_persona(self, persona_type: PersonaType) -> Persona:
        """Switch to a different persona.

        Args:
            persona_type: The persona to switch to.

        Returns:
            The new persona.
        """
        persona = self._persona_manager.switch_persona(persona_type)
        self.rebuild_sys_prompt()
        return persona

    def list_personas(self) -> List[Persona]:
        """List all available personas."""
        return self._persona_manager.list_personas()

    def set_persona_custom_prompt(
        self,
        persona_type: PersonaType,
        custom_prompt: str,
    ) -> None:
        """Set custom prompt for a persona.

        Args:
            persona_type: The persona type.
            custom_prompt: Custom system prompt.
        """
        self._persona_manager.set_custom_prompt(persona_type, custom_prompt)
        self.rebuild_sys_prompt()


def get_persona_prompt_for_type(persona_type: PersonaType) -> str:
    """Get the system prompt for a persona type.

    Args:
        persona_type: The persona type.

    Returns:
        System prompt addition.
    """
    persona = PERSONAS.get(persona_type)
    return persona.system_prompt_addition if persona else ""


__all__ = [
    "PersonaType",
    "Persona",
    "PersonaManager",
    "PersonaMixin",
    "PERSONAS",
    "get_persona_prompt_for_type",
]
