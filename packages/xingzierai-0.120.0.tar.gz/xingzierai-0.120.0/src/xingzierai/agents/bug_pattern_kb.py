# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core._logging import logger


class BugSeverity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class BugStatus(Enum):
    ACTIVE = "active"
    FIXED = "fixed"
    CANDIDATE = "candidate"


@dataclass
class BugPattern:
    id: str
    title: str
    description: str
    severity: BugSeverity
    status: BugStatus
    source: str
    entropy_type: str = ""
    fix_method: str = ""
    affected_files: list[str] = field(default_factory=list)
    error_signature: str = ""
    discovered_at: str = ""


BUILTIN_BUG_PATTERNS = [
    BugPattern(
        id="BP-001",
        title="Frontend render blank after hot reload",
        description="Chat page renders blank after HMR hot reload due to stale state references",
        severity=BugSeverity.HIGH,
        status=BugStatus.FIXED,
        source="skill",
        entropy_type="structural",
        fix_method="Force full page refresh on HMR",
        affected_files=["console/src/pages/Chat/index.tsx"],
    ),
    BugPattern(
        id="BP-002",
        title="SSE stream drops messages during high frequency",
        description="SSE events are lost when chunks arrive faster than React can process them",
        severity=BugSeverity.HIGH,
        status=BugStatus.FIXED,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="rAF throttling for SSE updates",
        affected_files=["console/src/lib/@agentscope-ai/chat/"],
    ),
    BugPattern(
        id="BP-003",
        title="Dark mode color inconsistency",
        description="Hardcoded colors break dark mode, causing invisible text or elements",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="style",
        fix_method="Replace with CSS variables",
        affected_files=["console/src/pages/Chat/index.tsx"],
    ),
    BugPattern(
        id="BP-004",
        title="Global variable shared state",
        description="Module-level global variables cause state inconsistency across sessions",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="daemon",
        entropy_type="structural",
        fix_method="Use React Context or Zustand store",
        affected_files=["console/src/pages/Chat/index.tsx"],
    ),
    BugPattern(
        id="BP-005",
        title="Export missing after refactor",
        description="Component exports are accidentally removed during file refactoring",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="daemon",
        entropy_type="information",
        fix_method="Add export verification gate",
        affected_files=["console/src/"],
    ),
    BugPattern(
        id="BP-006",
        title="Path traversal in file operations",
        description="File read/write operations don't validate paths, allowing directory traversal",
        severity=BugSeverity.CRITICAL,
        status=BugStatus.FIXED,
        source="daemon",
        entropy_type="information",
        fix_method="Validate resolved path is within workspace",
        affected_files=["src/xingzierai/agents/tools/file_io.py"],
    ),
    BugPattern(
        id="BP-007",
        title="Memory leak in infinite-growth data structures",
        description="Dicts and Lists grow without bounds, causing OOM over time",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="Add MAX_ENTRIES constant and cleanup logic",
        affected_files=["src/xingzierai/agents/cross_session_memory.py"],
    ),
    BugPattern(
        id="BP-008",
        title="SSE stream active flag race condition",
        description="__sseStreamActive boolean flag causes race conditions with concurrent streams",
        severity=BugSeverity.HIGH,
        status=BugStatus.FIXED,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="Replace boolean with counter",
        affected_files=["console/src/pages/Chat/index.tsx"],
    ),
    BugPattern(
        id="BP-009",
        title="Silent catch blocks hide errors",
        description="Empty catch blocks silently swallow errors, making debugging impossible",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="cognitive",
        fix_method="Add logging or fallback logic in catch blocks",
        affected_files=["console/src/"],
    ),
    BugPattern(
        id="BP-010",
        title="Babel _loop infinite loop in compiled JS",
        description="Babel compiles for...of+await into _loop pattern that can hang indefinitely",
        severity=BugSeverity.CRITICAL,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="Avoid for...of with await, use for...of without await or Promise.all",
        affected_files=["console/src/lib/@agentscope-ai/chat/"],
    ),
    BugPattern(
        id="BP-011",
        title="Hot replacement failure cascading",
        description="importlib.reload fails when dependent modules have already changed",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="structural",
        fix_method="Reload in reverse dependency order with fallback to restart",
        affected_files=["src/xingzierai/agents/evolution/engine.py"],
    ),
    BugPattern(
        id="BP-012",
        title="Context compression output too short",
        description="LLM over-compresses context, producing responses that are too brief",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="cognitive",
        fix_method="Add minimum length constraint in compression prompt",
        affected_files=["src/xingzierai/agents/context_manager/"],
    ),
    BugPattern(
        id="BP-013",
        title="API response type mismatch",
        description="Backend returns Object but frontend expects Array, causing runtime crash",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="information",
        fix_method="Add type guards and runtime validation on API responses",
        affected_files=["console/src/lib/", "src/xingzierai/app/routers/"],
    ),
    BugPattern(
        id="BP-014",
        title="Race condition in concurrent tool calls",
        description="Parallel tool calls modify shared state without synchronization",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="structural",
        fix_method="Use asyncio.Lock or threading.Lock for shared mutable state",
        affected_files=["src/xingzierai/agents/react_agent.py"],
    ),
    BugPattern(
        id="BP-015",
        title="Event listener leak in React components",
        description="addEventListener without matching removeEventListener causes memory leak",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="Use useEffect cleanup function to remove listeners",
        affected_files=["console/src/"],
    ),
    BugPattern(
        id="BP-016",
        title="Unbounded cache growth in embedding service",
        description="Embedding cache grows without eviction policy, causing OOM",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="thermodynamic",
        fix_method="Implement LRU cache with max size limit",
        affected_files=["src/xingzierai/agents/memory/"],
    ),
    BugPattern(
        id="BP-017",
        title="Circular import in evolution modules",
        description="Circular imports between engine, event_bus, and config_manager cause ImportError",
        severity=BugSeverity.CRITICAL,
        status=BugStatus.FIXED,
        source="evolution",
        entropy_type="structural",
        fix_method="Use lazy imports inside functions to break circular dependency",
        affected_files=["src/xingzierai/agents/evolution/"],
    ),
    BugPattern(
        id="BP-018",
        title="WebSocket connection not cleaned up on unmount",
        description="WebSocket connections persist after component unmount, leaking resources",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="thermodynamic",
        fix_method="Close WebSocket in useEffect cleanup",
        affected_files=["console/src/pages/"],
    ),
    BugPattern(
        id="BP-019",
        title="Stale closure in async callbacks",
        description="Async callbacks capture stale state from closure, using outdated values",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="cognitive",
        fix_method="Use useRef for mutable values accessed in async callbacks",
        affected_files=["console/src/"],
    ),
    BugPattern(
        id="BP-020",
        title="File descriptor leak in subprocess calls",
        description="subprocess.Popen without proper cleanup leaks file descriptors",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="thermodynamic",
        fix_method="Use context manager (with statement) for subprocess calls",
        affected_files=["src/xingzierai/agents/tools/"],
    ),
    BugPattern(
        id="BP-021",
        title="Missing error boundary in React tree",
        description="Unhandled promise rejections crash the entire React component tree",
        severity=BugSeverity.HIGH,
        status=BugStatus.ACTIVE,
        source="skill",
        entropy_type="cognitive",
        fix_method="Add ErrorBoundary component wrapping risky subtrees",
        affected_files=["console/src/"],
    ),
    BugPattern(
        id="BP-022",
        title="Zombie process from orphaned subprocess",
        description="Child processes become zombies when parent doesn't call wait()",
        severity=BugSeverity.MEDIUM,
        status=BugStatus.ACTIVE,
        source="evolution",
        entropy_type="thermodynamic",
        fix_method="Use subprocess.run() or ensure wait()/communicate() is called",
        affected_files=["src/xingzierai/agents/tools/"],
    ),
]


class BugPatternKnowledgeBase:
    """Bug pattern knowledge base for querying known risks and auto-discovering new patterns."""

    def __init__(self, state_path: Optional[str] = None, subscribe_events: bool = True):
        self._patterns: dict[str, BugPattern] = {}
        self._state_path = state_path
        for bp in BUILTIN_BUG_PATTERNS:
            self._patterns[bp.id] = bp
        if state_path:
            self._load_state(state_path)
        if subscribe_events:
            self._subscribe_gate_failed_events()

    def _subscribe_gate_failed_events(self):
        try:
            from xingzierai.agents.evolution.event_bus import (
                EvolutionEventType,
                get_evolution_bus,
            )

            bus = get_evolution_bus()
            bus.subscribe(EvolutionEventType.GATE_FAILED, self._on_gate_failed)
            logger.info("BugPatternKnowledgeBase subscribed to GATE_FAILED events")
        except Exception as e:
            logger.debug("Failed to subscribe to GATE_FAILED events: %s", e)

    def _on_gate_failed(self, event):
        try:
            data = event.data if hasattr(event, "data") else {}
            error_signature = ""
            for gate in data.get("failed_gates", []):
                error_signature += f"GATE-{gate.get('gate_id')}:{gate.get('message', '')};"
            for v in data.get("rule_violations", []):
                error_signature += f"RULE-{v.get('rule_id')}:{v.get('message', '')};"

            if error_signature:
                self.auto_discover(error_signature, context=str(data))
        except Exception as e:
            logger.debug("BugPatternKB event handler error: %s", e)

    def query_by_file(self, file_path: str) -> list[BugPattern]:
        """Query bug patterns related to a file path."""
        path_lower = file_path.lower().replace("\\", "/")
        results = []
        for bp in self._patterns.values():
            if bp.status == BugStatus.FIXED:
                continue
            for affected in bp.affected_files:
                if affected.lower().replace("\\", "/") in path_lower:
                    results.append(bp)
                    break
        return results

    def query_by_symptom(self, symptom: str) -> list[BugPattern]:
        """Query bug patterns by symptom description."""
        symptom_lower = symptom.lower()
        results = []
        for bp in self._patterns.values():
            if bp.status == BugStatus.FIXED:
                continue
            searchable = f"{bp.title} {bp.description} {bp.error_signature}".lower()
            words = symptom_lower.split()
            if any(w in searchable for w in words if len(w) > 3):
                results.append(bp)
        return results

    def query_by_entropy_type(self, entropy_type: str) -> list[BugPattern]:
        """Query bug patterns by entropy type."""
        return [
            bp for bp in self._patterns.values()
            if bp.entropy_type == entropy_type and bp.status != BugStatus.FIXED
        ]

    def auto_discover(self, error_signature: str, context: str = "") -> Optional[BugPattern]:
        """Attempt to auto-discover a new bug pattern from an error signature."""
        for bp in self._patterns.values():
            if bp.error_signature and bp.error_signature in error_signature:
                return bp

        new_id = f"BP-{len(self._patterns) + 1:03d}"
        candidate = BugPattern(
            id=new_id,
            title=f"Auto-discovered: {error_signature[:60]}",
            description=context or error_signature,
            severity=BugSeverity.MEDIUM,
            status=BugStatus.CANDIDATE,
            source="auto",
            error_signature=error_signature,
            discovered_at=datetime.now().isoformat(),
        )
        self._patterns[new_id] = candidate
        logger.info("Auto-discovered new bug pattern: %s", new_id)
        return candidate

    def apply_fix(self, pattern_id: str) -> Optional[str]:
        """Get the fix method for a known bug pattern."""
        bp = self._patterns.get(pattern_id)
        if bp and bp.fix_method:
            return bp.fix_method
        return None

    def get_active_patterns(self) -> list[BugPattern]:
        """Get all active (non-fixed) bug patterns."""
        return [bp for bp in self._patterns.values() if bp.status != BugStatus.FIXED]

    def get_all_patterns(self) -> list[BugPattern]:
        """Get all bug patterns including fixed ones."""
        return list(self._patterns.values())

    def _load_state(self, path: str) -> None:
        try:
            state_file = Path(path)
            if state_file.exists():
                data = json.loads(state_file.read_text(encoding="utf-8"))
                for bp_data in data.get("bug_patterns", []):
                    bp = BugPattern(
                        id=bp_data.get("id", ""),
                        title=bp_data.get("title", ""),
                        description=bp_data.get("description", ""),
                        severity=BugSeverity(bp_data.get("severity", "medium")),
                        status=BugStatus(bp_data.get("status", "candidate")),
                        source=bp_data.get("source", "auto"),
                        entropy_type=bp_data.get("entropy_type", ""),
                        fix_method=bp_data.get("fix_method", ""),
                        affected_files=bp_data.get("affected_files", []),
                        error_signature=bp_data.get("error_signature", ""),
                        discovered_at=bp_data.get("discovered_at", ""),
                    )
                    if bp.id and bp.id not in self._patterns:
                        self._patterns[bp.id] = bp
        except Exception as e:
            logger.debug("Failed to load bug pattern state from %s: %s", path, e)
