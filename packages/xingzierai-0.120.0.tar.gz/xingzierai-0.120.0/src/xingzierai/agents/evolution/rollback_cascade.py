# -*- coding: utf-8 -*-
"""Evolution Rollback Cascade - Automatic cascade rollback when patches fail."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class CascadeStatus(str, Enum):
    PENDING = "pending"
    ROLLING_BACK = "rolling_back"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class CascadeStep:
    patch_id: str
    generation: int
    rolled_back: bool = False
    rollback_time: Optional[float] = None
    error: Optional[str] = None


@dataclass
class CascadeResult:
    cascade_id: str
    trigger_patch_id: str
    status: CascadeStatus
    steps: List[CascadeStep] = field(default_factory=list)
    total_rolled_back: int = 0
    started_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cascade_id": self.cascade_id,
            "trigger_patch_id": self.trigger_patch_id,
            "status": self.status.value,
            "steps": [
                {
                    "patch_id": s.patch_id,
                    "generation": s.generation,
                    "rolled_back": s.rolled_back,
                    "rollback_time": s.rollback_time,
                    "error": s.error,
                }
                for s in self.steps
            ],
            "total_rolled_back": self.total_rolled_back,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


class RollbackCascade:
    MAX_CASCADE_DEPTH = 10
    MAX_HISTORY = 100

    def __init__(self):
        self._history: List[CascadeResult] = []

    def execute_cascade(
        self,
        trigger_patch_id: str,
        lineage_tracker: Any,
        engine: Any = None,
        max_depth: int = 3,
    ) -> CascadeResult:
        result = CascadeResult(
            cascade_id=f"cascade_{int(time.time() * 1000)}",
            trigger_patch_id=trigger_patch_id,
            status=CascadeStatus.PENDING,
        )

        try:
            result.status = CascadeStatus.ROLLING_BACK

            ancestors = self._get_ancestor_chain(trigger_patch_id, lineage_tracker, max_depth)
            if not ancestors:
                logger.info("No ancestors found for cascade rollback of %s", trigger_patch_id)
                result.status = CascadeStatus.COMPLETED
                result.completed_at = time.time()
                self._add_to_history(result)
                return result

            for patch_id, generation in ancestors:
                step = CascadeStep(patch_id=patch_id, generation=generation)
                try:
                    if lineage_tracker:
                        lineage_tracker.mark_rolled_back(patch_id, reason="cascade_rollback")
                    step.rolled_back = True
                    step.rollback_time = time.time()
                    result.total_rolled_back += 1
                    logger.info("Cascade rolled back patch %s (gen %d)", patch_id, generation)
                except Exception as e:
                    step.error = str(e)
                    logger.error("Failed to cascade rollback patch %s: %s", patch_id, e)

                result.steps.append(step)

            if engine:
                self._notify_engine(engine, result)

            result.status = CascadeStatus.COMPLETED
        except Exception as e:
            result.status = CascadeStatus.FAILED
            logger.error("Cascade rollback failed: %s", e)

        result.completed_at = time.time()
        self._add_to_history(result)
        return result

    def _get_ancestor_chain(
        self,
        patch_id: str,
        lineage_tracker: Any,
        max_depth: int,
    ) -> List[tuple]:
        chain: List[tuple] = []
        visited: Set[str] = set()
        current_id = patch_id
        depth = 0

        while current_id and depth < max_depth and current_id not in visited:
            visited.add(current_id)
            try:
                if lineage_tracker:
                    lineage = lineage_tracker.get_lineage(current_id)
                    if lineage and lineage.parent_id:
                        parent_id = lineage.parent_id
                        chain.append((current_id, depth))
                        current_id = parent_id
                        depth += 1
                    else:
                        break
                else:
                    break
            except Exception as _lineage_err:
                logger.debug("Lineage traversal failed at %s: %s", current_id, _lineage_err)
                break

        return chain

    def _notify_engine(self, engine: Any, result: CascadeResult) -> None:
        try:
            if hasattr(engine, "record_change"):
                engine.record_change(
                    description=f"Cascade rollback: {result.total_rolled_back} patches rolled back",
                    change_type="cascade_rollback",
                )
        except Exception as e:
            logger.warning("Failed to notify engine of cascade: %s", e)

    def _add_to_history(self, result: CascadeResult) -> None:
        self._history.append(result)
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]

    def get_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        return [r.to_dict() for r in self._history[-limit:]]

    def get_stats(self) -> Dict[str, Any]:
        total = len(self._history)
        completed = sum(1 for r in self._history if r.status == CascadeStatus.COMPLETED)
        failed = sum(1 for r in self._history if r.status == CascadeStatus.FAILED)
        total_patches = sum(r.total_rolled_back for r in self._history)
        return {
            "total_cascades": total,
            "completed": completed,
            "failed": failed,
            "total_patches_rolled_back": total_patches,
            "avg_patches_per_cascade": total_patches / max(total, 1),
        }


_cascade_instance: Optional[RollbackCascade] = None


def get_rollback_cascade() -> RollbackCascade:
    global _cascade_instance
    if _cascade_instance is None:
        _cascade_instance = RollbackCascade()
    return _cascade_instance
