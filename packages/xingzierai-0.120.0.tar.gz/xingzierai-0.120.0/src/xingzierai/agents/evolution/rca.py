# -*- coding: utf-8 -*-
"""Root Cause Analysis (RCA) Module - Core feature from JiuwenClaw.

This module implements the execution-to-learning closed loop:
Execution → Failure → Learning → Optimization → Re-execution

When the agent fails or receives negative feedback, it performs root cause
analysis to generate targeted optimization strategies.
"""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import hashlib

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class RCACategory(str, Enum):
    """Categories of root cause analysis."""
    INPUT_VALIDATION = "input_validation"
    TOOL_EXECUTION = "tool_execution"
    CONTEXT_OVERFLOW = "context_overflow"
    MODEL_LIMITATION = "model_limitation"
    TIMEOUT = "timeout"
    PERMISSION_DENIED = "permission_denied"
    NETWORK_ERROR = "network_error"
    SYNTAX_ERROR = "syntax_error"
    LOGIC_ERROR = "logic_error"
    RESOURCE_LIMIT = "resource_limit"
    UNKNOWN = "unknown"


class RCAConfidence(str, Enum):
    """Confidence levels for RCA results."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class ErrorPattern:
    """Pattern of errors detected."""
    pattern: str
    frequency: int
    first_seen: float
    last_seen: float
    category: RCACategory
    solutions: List[str] = field(default_factory=list)


@dataclass
class RootCauseResult:
    """Result of root cause analysis."""
    root_cause: str
    category: RCACategory
    confidence: RCAConfidence
    evidence: List[str] = field(default_factory=list)
    suggested_fixes: List[str] = field(default_factory=list)
    affected_components: List[str] = field(default_factory=list)
    retry_recommended: bool = False
    optimization_strategy: Optional[str] = None


@dataclass
class RCAExecution:
    """Record of an RCA execution."""
    execution_id: str
    timestamp: float
    task_input: str
    task_output: Optional[str]
    error_message: Optional[str]
    user_feedback: Optional[str]
    analysis_result: Optional[RootCauseResult]
    optimization_applied: bool = False
    retry_success: Optional[bool] = None


@dataclass
class RCAConfig:
    """Configuration for RCA system."""
    enabled: bool = True
    min_error_count_for_pattern: int = 3
    pattern_window_hours: int = 24
    max_patterns_stored: int = 100
    auto_apply_confident_fixes: bool = False
    high_confidence_threshold: float = 0.8
    medium_confidence_threshold: float = 0.5
    enable_feedback_learning: bool = True
    enable_retry_optimization: bool = True


class RCAPatternMatcher:
    """Pattern matching for error categorization."""

    PATTERNS = {
        RCACategory.INPUT_VALIDATION: [
            (r"(?i)invalid.*input", 0.9),
            (r"(?i)missing.*required.*param", 0.9),
            (r"(?i)validation.*error", 0.8),
            (r"(?i)input.*too.*long", 0.8),
            (r"(?i)cannot.*parse", 0.7),
            (r"(?i)malformed", 0.8),
        ],
        RCACategory.TOOL_EXECUTION: [
            (r"(?i)tool.*not.*found", 0.9),
            (r"(?i)tool.*execution.*failed", 0.9),
            (r"(?i)command.*not.*found", 0.8),
            (r"(?i)permission.*denied", 0.9),
            (r"(?i)cannot.*execute", 0.7),
            (r"(?i)tool.*timeout", 0.8),
        ],
        RCACategory.CONTEXT_OVERFLOW: [
            (r"(?i)context.*overflow", 0.95),
            (r"(?i)token.*limit", 0.95),
            (r"(?i)too.*many.*tokens", 0.9),
            (r"(?i)context.*length", 0.9),
            (r"(?i)max.*tokens.*exceeded", 0.95),
        ],
        RCACategory.MODEL_LIMITATION: [
            (r"(?i)model.*cannot", 0.8),
            (r"(?i)model.*does.*not.*support", 0.85),
            (r"(?i)unsupported.*operation", 0.7),
            (r"(?i)capability.*not.*available", 0.75),
        ],
        RCACategory.TIMEOUT: [
            (r"(?i)timeout", 0.95),
            (r"(?i)timed.*out", 0.95),
            (r"(?i)took.*too.*long", 0.8),
            (r"(?i)deadline.*exceeded", 0.9),
        ],
        RCACategory.PERMISSION_DENIED: [
            (r"(?i)permission.*denied", 0.95),
            (r"(?i)access.*denied", 0.95),
            (r"(?i)not.*authorized", 0.9),
            (r"(?i)forbidden", 0.9),
        ],
        RCACategory.NETWORK_ERROR: [
            (r"(?i)connection.*error", 0.9),
            (r"(?i)network.*error", 0.9),
            (r"(?i)connection.*refused", 0.9),
            (r"(?i)dns.*error", 0.85),
            (r"(?i)ssl.*error", 0.85),
        ],
        RCACategory.SYNTAX_ERROR: [
            (r"(?i)syntax.*error", 0.95),
            (r"(?i)parse.*error", 0.9),
            (r"(?i)unexpected.*token", 0.9),
            (r"(?i)invalid.*syntax", 0.95),
        ],
        RCACategory.LOGIC_ERROR: [
            (r"(?i)logic.*error", 0.8),
            (r"(?i)incorrect.*result", 0.7),
            (r"(?i)wrong.*value", 0.6),
            (r"(?i)unexpected.*behavior", 0.7),
        ],
        RCACategory.RESOURCE_LIMIT: [
            (r"(?i)memory.*error", 0.9),
            (r"(?i)out.*of.*memory", 0.9),
            (r"(?i)disk.*full", 0.9),
            (r"(?i)resource.*exhausted", 0.85),
            (r"(?i)rate.*limit", 0.9),
        ],
    }

    @classmethod
    def categorize_error(cls, error_message: str) -> Tuple[RCACategory, float]:
        """Categorize an error message.

        Args:
            error_message: The error message to categorize.

        Returns:
            Tuple of (category, confidence_score)
        """
        error_lower = error_message.lower()
        best_category = RCACategory.UNKNOWN
        best_score = 0.0

        for category, patterns in cls.PATTERNS.items():
            for pattern, base_score in patterns:
                if re.search(pattern, error_lower):
                    if base_score > best_score:
                        best_score = base_score
                        best_category = category

        return best_category, best_score


class RCASolutionGenerator:
    """Generate solutions based on error categories."""

    SOLUTIONS = {
        RCACategory.INPUT_VALIDATION: [
            "Validate and sanitize input before processing",
            "Add input length limits and type checking",
            "Provide clearer error messages for invalid input",
            "Implement input preprocessing pipeline",
        ],
        RCACategory.TOOL_EXECUTION: [
            "Check tool availability and permissions",
            "Add error handling for tool failures",
            "Implement tool timeout and retry logic",
            "Verify tool configuration and dependencies",
        ],
        RCACategory.CONTEXT_OVERFLOW: [
            "Implement context compression",
            "Summarize older conversation history",
            "Use selective context retention",
            "Split task into smaller subtasks",
        ],
        RCACategory.MODEL_LIMITATION: [
            "Use a more capable model for this task",
            "Break down the task into simpler steps",
            "Implement fallback to alternative model",
            "Enhance prompt with examples",
        ],
        RCACategory.TIMEOUT: [
            "Increase timeout duration",
            "Optimize execution path",
            "Implement async processing",
            "Reduce task complexity",
        ],
        RCACategory.PERMISSION_DENIED: [
            "Check file/directory permissions",
            "Run with appropriate privileges",
            "Use sandboxed execution environment",
            "Configure access control lists",
        ],
        RCACategory.NETWORK_ERROR: [
            "Implement retry with exponential backoff",
            "Add network error handling",
            "Use offline mode when possible",
            "Check network connectivity",
        ],
        RCACategory.SYNTAX_ERROR: [
            "Fix syntax in generated code",
            "Add syntax validation",
            "Use linter for code validation",
            "Implement code generation templates",
        ],
        RCACategory.LOGIC_ERROR: [
            "Review and fix business logic",
            "Add debugging output",
            "Implement unit tests for logic",
            "Enhance prompt with better examples",
        ],
        RCACategory.RESOURCE_LIMIT: [
            "Optimize resource usage",
            "Implement streaming for large data",
            "Use pagination for large results",
            "Add resource monitoring",
        ],
    }

    @classmethod
    def generate_solutions(
        cls,
        category: RCACategory,
        error_message: str,
        context: Dict[str, Any],
    ) -> List[str]:
        """Generate potential solutions for an error.

        Args:
            category: The error category.
            error_message: The error message.
            context: Additional context about the execution.

        Returns:
            List of potential solutions.
        """
        solutions = cls.SOLUTIONS.get(category, [
            "Review error details and try again",
            "Break down the task into smaller steps",
            "Check system logs for more details",
        ])

        if "file" in error_message.lower() or "path" in error_message.lower():
            solutions.append("Verify file path is correct and accessible")

        if "json" in error_message.lower():
            solutions.append("Validate JSON syntax")

        return solutions


class RCARepository:
    """Storage for RCA data."""

    def __init__(self, workspace_dir: Path):
        self.workspace_dir = workspace_dir
        self.rca_dir = workspace_dir / "rca_analysis"
        self.rca_dir.mkdir(parents=True, exist_ok=True)
        self.executions_file = self.rca_dir / "executions.jsonl"
        self.patterns_file = self.rca_dir / "patterns.json"
        self.optimizations_file = self.rca_dir / "optimizations.json"

    def _ensure_file(self, path: Path) -> None:
        if not path.exists():
            path.write_text("" if path.suffix == ".jsonl" else "[]", encoding="utf-8")

    def save_execution(self, execution: RCAExecution) -> None:
        """Save an RCA execution record."""
        self._ensure_file(self.executions_file)
        
        exec_dict = {
            "execution_id": execution.execution_id,
            "timestamp": execution.timestamp,
            "task_input": execution.task_input,
            "task_output": execution.task_output,
            "error_message": execution.error_message,
            "user_feedback": execution.user_feedback,
            "optimization_applied": execution.optimization_applied,
            "retry_success": execution.retry_success,
        }
        
        if execution.analysis_result:
            exec_dict["analysis_result"] = {
                "root_cause": execution.analysis_result.root_cause,
                "category": execution.analysis_result.category.value,
                "confidence": execution.analysis_result.confidence.value,
                "evidence": execution.analysis_result.evidence,
                "suggested_fixes": execution.analysis_result.suggested_fixes,
                "affected_components": execution.analysis_result.affected_components,
                "retry_recommended": execution.analysis_result.retry_recommended,
                "optimization_strategy": execution.analysis_result.optimization_strategy,
            }
        
        with open(self.executions_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(exec_dict, ensure_ascii=False) + "\n")

    def get_executions(
        self,
        limit: int = 100,
        error_only: bool = False,
    ) -> List[RCAExecution]:
        """Get RCA execution records."""
        if not self.executions_file.exists():
            return []

        executions = []
        try:
            with open(self.executions_file, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        if error_only and not data.get("error_message"):
                            continue
                        
                        analysis_result = None
                        if data.get("analysis_result"):
                            ar = data["analysis_result"]
                            analysis_result = RootCauseResult(
                                root_cause=ar.get("root_cause", ""),
                                category=RCACategory(ar.get("category", "unknown")),
                                confidence=RCAConfidence(ar.get("confidence", "low")),
                                evidence=ar.get("evidence", []),
                                suggested_fixes=ar.get("suggested_fixes", []),
                                affected_components=ar.get("affected_components", []),
                                retry_recommended=ar.get("retry_recommended", False),
                                optimization_strategy=ar.get("optimization_strategy"),
                            )
                        
                        executions.append(RCAExecution(
                            execution_id=data.get("execution_id", ""),
                            timestamp=data.get("timestamp", 0),
                            task_input=data.get("task_input", ""),
                            task_output=data.get("task_output"),
                            error_message=data.get("error_message"),
                            user_feedback=data.get("user_feedback"),
                            analysis_result=analysis_result,
                            optimization_applied=data.get("optimization_applied", False),
                            retry_success=data.get("retry_success"),
                        ))
                    except (json.JSONDecodeError, TypeError):
                        continue

            return executions[-limit:] if len(executions) > limit else executions
        except Exception as e:
            logger.error(f"Failed to read RCA executions: {e}")
            return []

    def save_pattern(self, pattern: ErrorPattern) -> None:
        """Save an error pattern."""
        self._ensure_file(self.patterns_file)
        try:
            patterns = []
            if self.patterns_file.exists():
                content = self.patterns_file.read_text(encoding="utf-8")
                if content:
                    patterns = json.loads(content)

            pattern_dict = {
                "pattern": pattern.pattern,
                "frequency": pattern.frequency,
                "first_seen": pattern.first_seen,
                "last_seen": pattern.last_seen,
                "category": pattern.category.value,
                "solutions": pattern.solutions,
            }

            existing_idx = None
            for i, p in enumerate(patterns):
                if p.get("pattern") == pattern.pattern:
                    existing_idx = i
                    break

            if existing_idx is not None:
                patterns[existing_idx] = pattern_dict
            else:
                patterns.append(pattern_dict)

            patterns = patterns[-100:]
            atomic_write(self.patterns_file, json.dumps(patterns, ensure_ascii=False, indent=2))
        except Exception as e:
            logger.error(f"Failed to save pattern: {e}")

    def get_patterns(self, category: Optional[RCACategory] = None) -> List[ErrorPattern]:
        """Get stored error patterns."""
        if not self.patterns_file.exists():
            return []

        try:
            content = self.patterns_file.read_text(encoding="utf-8")
            if not content:
                return []

            patterns = json.loads(content)
            result = []
            for p in patterns:
                if category and p.get("category") != category.value:
                    continue
                result.append(ErrorPattern(
                    pattern=p["pattern"],
                    frequency=p["frequency"],
                    first_seen=p["first_seen"],
                    last_seen=p["last_seen"],
                    category=RCACategory(p["category"]),
                    solutions=p.get("solutions", []),
                ))

            return sorted(result, key=lambda x: x.frequency, reverse=True)
        except Exception as e:
            logger.error(f"Failed to get patterns: {e}")
            return []

    def save_optimization(self, execution_id: str, optimization: Dict[str, Any]) -> None:
        """Save an optimization applied."""
        self._ensure_file(self.optimizations_file)
        try:
            optimizations = []
            if self.optimizations_file.exists():
                content = self.optimizations_file.read_text(encoding="utf-8")
                if content:
                    optimizations = json.loads(content)

            optimizations.append({
                "execution_id": execution_id,
                "timestamp": time.time(),
                **optimization,
            })

            atomic_write(self.optimizations_file, json.dumps(optimizations, ensure_ascii=False, indent=2))
        except Exception as e:
            logger.error(f"Failed to save optimization: {e}")


class RootCauseAnalyzer:
    """
    Root Cause Analysis System.

    Implements the execution-to-learning closed loop from JiuwenClaw:
    Execution → Failure → Learning → Optimization → Re-execution

    Features:
    - Error pattern detection and categorization
    - Root cause identification with confidence scores
    - Solution generation based on error categories
    - Pattern learning from multiple failures
    - Feedback-driven optimization
    """

    def __init__(
        self,
        workspace_dir: Path,
        config: Optional[RCAConfig] = None,
    ):
        self.repo = RCARepository(workspace_dir)
        self.config = config or RCAConfig()
        self._execution_cache: Dict[str, RCAExecution] = {}

    MAX_EXECUTION_CACHE = 500

    def _enforce_cache_limit(self) -> None:
        if len(self._execution_cache) <= self.MAX_EXECUTION_CACHE:
            return
        sorted_keys = sorted(
            self._execution_cache.keys(),
            key=lambda k: self._execution_cache[k].timestamp,
        )
        for k in sorted_keys[:len(self._execution_cache) - self.MAX_EXECUTION_CACHE]:
            del self._execution_cache[k]

    def analyze_failure(
        self,
        task_input: str,
        task_output: Optional[str],
        error_message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> RootCauseResult:
        """Analyze a failure and determine root cause.

        Args:
            task_input: The original task input.
            task_output: The task output (may be None or partial).
            error_message: The error message.
            context: Additional context about the execution.

        Returns:
            RootCauseResult with analysis findings.
        """
        if not self.config.enabled:
            return RootCauseResult(
                root_cause="RCA disabled",
                category=RCACategory.UNKNOWN,
                confidence=RCAConfidence.LOW,
            )

        context = context or {}

        category, category_score = RCAPatternMatcher.categorize_error(error_message)

        confidence = RCAConfidence.LOW
        if category_score >= self.config.high_confidence_threshold:
            confidence = RCAConfidence.HIGH
        elif category_score >= self.config.medium_confidence_threshold:
            confidence = RCAConfidence.MEDIUM

        solutions = RCASolutionGenerator.generate_solutions(
            category, error_message, context
        )

        evidence = [
            f"Error matched pattern with score {category_score:.2f}",
            f"Category: {category.value}",
        ]

        if task_input:
            evidence.append(f"Input length: {len(task_input)} chars")

        if task_output:
            evidence.append(f"Output length: {len(task_output)} chars")

        affected_components = self._identify_affected_components(
            error_message, context
        )

        retry_recommended = self._should_retry(category, confidence)

        optimization_strategy = self._generate_optimization_strategy(
            category, confidence, context
        )

        result = RootCauseResult(
            root_cause=self._summarize_root_cause(category, error_message),
            category=category,
            confidence=confidence,
            evidence=evidence,
            suggested_fixes=solutions,
            affected_components=affected_components,
            retry_recommended=retry_recommended,
            optimization_strategy=optimization_strategy,
        )

        self._update_patterns(category, error_message, solutions)

        return result

    def analyze_feedback(
        self,
        task_input: str,
        task_output: str,
        user_feedback: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> RootCauseResult:
        """Analyze user feedback to determine issues.

        Args:
            task_input: The original task input.
            task_output: The task output that user provided feedback on.
            user_feedback: User's feedback (e.g., "that's wrong", "try differently").
            context: Additional context.

        Returns:
            RootCauseResult with analysis.
        """
        if not self.config.enabled or not self.config.enable_feedback_learning:
            return RootCauseResult(
                root_cause="Feedback learning disabled",
                category=RCACategory.UNKNOWN,
                confidence=RCAConfidence.LOW,
            )

        context = context or {}

        feedback_lower = user_feedback.lower()

        if any(word in feedback_lower for word in ["wrong", "incorrect", "error", "mistake", "bad"]):
            category = RCACategory.LOGIC_ERROR
            confidence = RCAConfidence.MEDIUM
        elif any(word in feedback_lower for word in ["not", "cannot", "don't", "doesn't"]):
            category = RCACategory.INPUT_VALIDATION
            confidence = RCAConfidence.MEDIUM
        elif any(word in feedback_lower for word in ["slow", "long", "timeout", "take"]):
            category = RCACategory.TIMEOUT
            confidence = RCAConfidence.MEDIUM
        elif any(word in feedback_lower for word in ["different", "another", "other", "try"]):
            category = RCACategory.MODEL_LIMITATION
            confidence = RCAConfidence.LOW
        else:
            category = RCACategory.UNKNOWN
            confidence = RCAConfidence.LOW

        solutions = RCASolutionGenerator.generate_solutions(
            category, user_feedback, context
        )

        return RootCauseResult(
            root_cause=f"User feedback indicates: {user_feedback}",
            category=category,
            confidence=confidence,
            evidence=[f"User said: {user_feedback}"],
            suggested_fixes=solutions,
            affected_components=["output_generation"],
            retry_recommended=True,
            optimization_strategy=self._generate_optimization_strategy(
                category, confidence, context
            ),
        )

    def record_execution(
        self,
        execution_id: str,
        task_input: str,
        task_output: Optional[str],
        error_message: Optional[str],
        user_feedback: Optional[str] = None,
        analysis_result: Optional[RootCauseResult] = None,
    ) -> None:
        """Record an execution for learning.

        Args:
            execution_id: Unique execution identifier.
            task_input: Task input.
            task_output: Task output.
            error_message: Error message if any.
            user_feedback: User feedback if any.
            analysis_result: RCA result if analysis was performed.
        """
        execution = RCAExecution(
            execution_id=execution_id,
            timestamp=time.time(),
            task_input=task_input[:500] if task_input else "",
            task_output=task_output[:500] if task_output else None,
            error_message=error_message,
            user_feedback=user_feedback,
            analysis_result=analysis_result,
        )

        self.repo.save_execution(execution)
        self._execution_cache[execution_id] = execution
        self._enforce_cache_limit()

    def apply_optimization(
        self,
        execution_id: str,
        optimization_type: str,
        details: Dict[str, Any],
    ) -> bool:
        """Record an optimization applied.

        Args:
            execution_id: The execution ID to optimize.
            optimization_type: Type of optimization applied.
            details: Details of the optimization.

        Returns:
            True if successful.
        """
        self.repo.save_optimization(execution_id, {
            "type": optimization_type,
            "details": details,
        })

        if execution_id in self._execution_cache:
            self._execution_cache[execution_id].optimization_applied = True

        logger.info(f"Applied optimization for {execution_id}: {optimization_type}")
        return True

    def get_analysis_report(
        self,
        time_window_hours: int = 24,
    ) -> Dict[str, Any]:
        """Get a comprehensive analysis report.

        Args:
            time_window_hours: Time window to analyze.

        Returns:
            Report dictionary.
        """
        cutoff = time.time() - (time_window_hours * 3600)
        executions = self.repo.get_executions(limit=1000)

        recent = [e for e in executions if e.timestamp >= cutoff]
        failed = [e for e in recent if e.error_message or e.user_feedback]

        category_counts: Dict[str, int] = {}
        for exec in failed:
            if exec.analysis_result:
                cat = exec.analysis_result.category.value
                category_counts[cat] = category_counts.get(cat, 0) + 1

        patterns = self.repo.get_patterns()
        top_patterns = patterns[:10]

        return {
            "time_window_hours": time_window_hours,
            "total_executions": len(recent),
            "failed_executions": len(failed),
            "failure_rate": len(failed) / len(recent) if recent else 0,
            "category_distribution": category_counts,
            "top_error_patterns": [
                {
                    "pattern": p.pattern,
                    "frequency": p.frequency,
                    "category": p.category.value,
                }
                for p in top_patterns
            ],
            "generated_at": datetime.now().isoformat(),
        }

    def _identify_affected_components(
        self,
        error_message: str,
        context: Dict[str, Any],
    ) -> List[str]:
        """Identify components affected by the error."""
        components = []
        error_lower = error_message.lower()

        if any(word in error_lower for word in ["file", "read", "write", "path"]):
            components.append("file_system")
        if any(word in error_lower for word in ["api", "http", "request"]):
            components.append("api_client")
        if any(word in error_lower for word in ["model", "llm", "generate"]):
            components.append("llm")
        if any(word in error_lower for word in ["tool", "execute"]):
            components.append("tool_executor")
        if any(word in error_lower for word in ["memory", "token"]):
            components.append("memory_manager")

        if not components:
            components.append("unknown")

        return components

    def _should_retry(
        self,
        category: RCACategory,
        confidence: RCAConfidence,
    ) -> bool:
        """Determine if retry is recommended."""
        if confidence == RCAConfidence.HIGH:
            return category not in [
                RCACategory.MODEL_LIMITATION,
                RCACategory.RESOURCE_LIMIT,
            ]
        elif confidence == RCAConfidence.MEDIUM:
            return category in [
                RCACategory.TIMEOUT,
                RCACategory.NETWORK_ERROR,
                RCACategory.TOOL_EXECUTION,
            ]
        return False

    def _generate_optimization_strategy(
        self,
        category: RCACategory,
        confidence: RCAConfidence,
        context: Dict[str, Any],
    ) -> Optional[str]:
        """Generate an optimization strategy."""
        strategies = {
            RCACategory.CONTEXT_OVERFLOW: "Compress context and retry with summary",
            RCACategory.TIMEOUT: "Increase timeout and simplify task",
            RCACategory.TOOL_EXECUTION: "Retry with error handling",
            RCACategory.NETWORK_ERROR: "Retry with exponential backoff",
            RCACategory.INPUT_VALIDATION: "Validate and sanitize input",
        }

        base_strategy = strategies.get(category)

        if confidence == RCAConfidence.HIGH:
            return f"CONFIDENT: {base_strategy or 'Apply standard retry'}"
        elif confidence == RCAConfidence.MEDIUM:
            return f"POSSIBLE: Consider {base_strategy or 'alternative approach'}"

        return None

    def _summarize_root_cause(self, category: RCACategory, error: str) -> str:
        """Summarize the root cause."""
        cause_templates = {
            RCACategory.INPUT_VALIDATION: "Input validation failed",
            RCACategory.TOOL_EXECUTION: "Tool execution error",
            RCACategory.CONTEXT_OVERFLOW: "Context length exceeded",
            RCACategory.MODEL_LIMITATION: "Model capability limitation",
            RCACategory.TIMEOUT: "Operation timeout",
            RCACategory.PERMISSION_DENIED: "Permission denied",
            RCACategory.NETWORK_ERROR: "Network communication error",
            RCACategory.SYNTAX_ERROR: "Syntax error in generated code",
            RCACategory.LOGIC_ERROR: "Logic error in execution",
            RCACategory.RESOURCE_LIMIT: "Resource limit exceeded",
            RCACategory.UNKNOWN: "Unknown error",
        }

        return cause_templates.get(category, "Unknown error")

    def _update_patterns(
        self,
        category: RCACategory,
        error_message: str,
        solutions: List[str],
    ) -> None:
        """Update error patterns."""
        error_hash = hashlib.md5(
            error_message.encode()
        ).hexdigest()[:16]

        patterns = self.repo.get_patterns(category)
        existing = None

        for p in patterns:
            if error_hash in p.pattern or p.pattern in error_message:
                existing = p
                break

        if existing:
            existing.frequency += 1
            existing.last_seen = time.time()
            if solutions:
                existing.solutions = list(set(existing.solutions + solutions))[:5]
        else:
            existing = ErrorPattern(
                pattern=error_hash,
                frequency=1,
                first_seen=time.time(),
                last_seen=time.time(),
                category=category,
                solutions=solutions[:3],
            )

        self.repo.save_pattern(existing)


RootCauseAnalysis = RootCauseAnalyzer
RCA = RootCauseAnalyzer
