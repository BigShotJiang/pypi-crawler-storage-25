# -*- coding: utf-8 -*-
"""Skill Evolution Manager - Orchestrates skill evolution lifecycle."""

import json
import logging
import os
from pathlib import Path
from typing import Optional, List

from .schema import EvolutionRecord
from ._utils import atomic_write
from .signal_detector import SignalDetector, EvolutionSignal
from .evolver import SkillEvolver

logger = logging.getLogger(__name__)


class SkillEvolutionManager:
    def __init__(
        self,
        skills_dir: str,
        workspace_dir: Optional[str] = None,
        signal_detector: Optional[SignalDetector] = None,
        evolver: Optional[SkillEvolver] = None,
    ):
        self.skills_dir = Path(skills_dir)
        self.signal_detector = signal_detector or SignalDetector()
        if evolver is not None:
            self.evolver = evolver
        else:
            ws = Path(workspace_dir) if workspace_dir else Path(skills_dir) / ".evolution_workspace"
            self.evolver = SkillEvolver(workspace_dir=ws)

    def get_evolutions_path(self, skill_name: str) -> Path:
        skill_path = self.skills_dir / skill_name
        return skill_path / "evolutions.json"

    def load_evolutions(self, skill_name: str) -> EvolutionRecord:
        evolutions_path = self.get_evolutions_path(skill_name)
        if evolutions_path.exists():
            try:
                with open(evolutions_path, "r", encoding="utf-8") as f:
                    return EvolutionRecord.from_json(f.read())
            except Exception as e:
                logger.warning(f"Failed to load evolutions for {skill_name}: {e}")
        return EvolutionRecord(skill_id=skill_name)

    def save_evolutions(self, skill_name: str, record: EvolutionRecord) -> None:
        evolutions_path = self.get_evolutions_path(skill_name)
        evolutions_path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(evolutions_path, record.to_json())

    def scan_and_process(
        self,
        skill_name: str,
        tool_name: Optional[str] = None,
        tool_result: Optional[str] = None,
        user_message: Optional[str] = None,
    ) -> bool:
        signal: Optional[EvolutionSignal] = None

        if tool_result:
            signal = self.signal_detector.detect_from_tool_result(
                tool_name or "unknown",
                tool_result,
                skill_name,
            )

        if not signal and user_message:
            signal = self.signal_detector.detect_from_user_message(
                user_message,
                skill_name,
            )

        if signal:
            record = self.load_evolutions(skill_name)
            from .schema import EvolutionChange, EvolutionEntry
            from datetime import datetime as dt
            change = EvolutionChange(
                section="behavior",
                action=EvolutionChange.__dataclass_fields__.get("action") and EvolutionChange.action or None,
                content=signal.raw_text[:500],
                relevant=True,
            )
            entry = EvolutionEntry(
                source=signal.signal_type.value,
                timestamp=dt.now().isoformat(),
                context=signal.context[:500] if signal.context else "",
                change=change.to_dict() if hasattr(change, "to_dict") else {},
                applied=False,
            )
            record.add_entry(entry)
            self.save_evolutions(skill_name, record)
            logger.info(f"Evolution recorded for skill '{skill_name}': {entry.id}")
            return True

        return False

    def solidify_skill(self, skill_name: str) -> bool:
        skill_md_path = self.skills_dir / skill_name / "SKILL.md"
        if not skill_md_path.exists():
            logger.warning(f"SKILL.md not found for skill '{skill_name}'")
            return False

        try:
            with open(skill_md_path, "r", encoding="utf-8") as f:
                skill_content = f.read()

            record = self.load_evolutions(skill_name)
            unapplied = [e for e in record.entries if not e.applied]

            if not unapplied:
                logger.info(f"No unapplied evolutions for skill '{skill_name}'")
                return True

            for entry in unapplied:
                change_content = entry.change if isinstance(entry.change, str) else json.dumps(entry.change, ensure_ascii=False)
                section_header = f"## {entry.source}"
                if section_header in skill_content:
                    skill_content = skill_content.replace(
                        section_header,
                        f"{section_header}\n\n> Evolution ({entry.timestamp}): {change_content[:200]}",
                    )
                else:
                    skill_content += f"\n\n## Auto-Evolved ({entry.timestamp})\n\n{change_content[:500]}\n"
                entry.applied = True

            atomic_write(skill_md_path, skill_content)

            self.save_evolutions(skill_name, record)
            logger.info(f"Solidified {len(unapplied)} evolutions into SKILL.md for '{skill_name}'")
            return True

        except Exception as e:
            logger.error(f"Failed to solidify skill '{skill_name}': {e}")
            return False

    def list_pending_evolutions(self, skill_name: str) -> List[dict]:
        record = self.load_evolutions(skill_name)
        return [
            {
                "id": e.id,
                "source": e.source,
                "timestamp": e.timestamp,
                "context": e.context,
                "change": e.change,
                "applied": e.applied,
            }
            for e in record.entries
            if not e.applied
        ]

    def get_all_skills_with_evolutions(self) -> List[str]:
        if not self.skills_dir.exists():
            return []
        return [d.name for d in self.skills_dir.iterdir() if d.is_dir() and (d / "evolutions.json").exists()]