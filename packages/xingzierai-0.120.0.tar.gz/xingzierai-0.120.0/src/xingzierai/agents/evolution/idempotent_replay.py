# -*- coding: utf-8 -*-
"""Idempotent Experience Replay - Inspired by IDER (2025).

IDER key insight:
- Idempotent property: repeated function applications yield the same output
- Idempotence distillation loss: feed current model output back to old checkpoint,
  minimize distance between reprocessed output and original
- Prevents catastrophic forgetting in continual learning

This module provides:
1. IdempotentReplayBuffer: Experience replay with idempotent filtering
2. ReplayRecord: A single replay record with quality scoring
3. ReplayQualityScorer: Score and filter replay records by quality
"""

import json
import logging
import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ReplayRecord:
    id: str = ""
    task_type: str = ""
    input_text: str = ""
    output_text: str = ""
    quality_score: float = 0.0
    replay_count: int = 0
    last_replayed_at: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    source: str = ""
    is_idempotent: bool = False
    idempotency_score: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "task_type": self.task_type,
            "input_text": self.input_text[:500],
            "output_text": self.output_text[:500],
            "quality_score": self.quality_score,
            "replay_count": self.replay_count,
            "last_replayed_at": self.last_replayed_at,
            "created_at": self.created_at,
            "source": self.source,
            "is_idempotent": self.is_idempotent,
            "idempotency_score": self.idempotency_score,
        }


class ReplayQualityScorer:
    """Score replay records by quality for selective replay."""

    def score(self, record: ReplayRecord) -> float:
        score = 0.0

        if record.quality_score > 0:
            score += record.quality_score * 0.4

        if record.is_idempotent:
            score += 0.3
        score += record.idempotency_score * 0.2

        if record.replay_count == 0:
            score += 0.1

        return min(score, 1.0)


class IdempotentReplayBuffer:
    """Experience replay buffer with idempotent filtering.

    Inspired by IDER (2025):
    - Only admit high-quality, idempotent experiences
    - Verify idempotency: reprocessing yields same output
    - Prioritize novel experiences over repeated ones
    - Prevent catastrophic forgetting through selective replay

    Usage:
        buffer = IdempotentReplayBuffer()
        buffer.add(task_type="deploy", input="deploy app", output="success", quality=0.9)
        records = buffer.sample(task_type="deploy", n=5)
    """

    MAX_BUFFER_SIZE = 3000
    MIN_QUALITY_THRESHOLD = 0.5
    IDEMPOTENCY_THRESHOLD = 0.7

    def __init__(self, storage_dir: Optional[str] = None):
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "replay_buffer"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._buffer: Dict[str, List[ReplayRecord]] = defaultdict(list)
        self._scorer = ReplayQualityScorer()
        self._load()

    def add(
        self,
        task_type: str,
        input_text: str,
        output_text: str,
        quality_score: float = 0.0,
        source: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[ReplayRecord]:
        if quality_score < self.MIN_QUALITY_THRESHOLD:
            return None

        is_idempotent, idem_score = self._check_idempotency(task_type, input_text, output_text)

        record = ReplayRecord(
            id=f"replay_{int(time.time() * 1000)}",
            task_type=task_type,
            input_text=input_text[:4000],
            output_text=output_text[:4000],
            quality_score=quality_score,
            source=source,
            is_idempotent=is_idempotent,
            idempotency_score=idem_score,
            metadata=metadata or {},
        )

        self._buffer[task_type].append(record)
        self._enforce_max_size(task_type)
        self._persist(record)

        return record

    def sample(
        self,
        task_type: Optional[str] = None,
        n: int = 5,
        min_quality: float = 0.3,
        prefer_idempotent: bool = True,
    ) -> List[ReplayRecord]:
        candidates = []
        if task_type:
            candidates = self._buffer.get(task_type, [])
        else:
            for records in self._buffer.values():
                candidates.extend(records)

        candidates = [r for r in candidates if r.quality_score >= min_quality]
        if not candidates:
            return []

        scored = []
        for record in candidates:
            score = self._scorer.score(record)
            if prefer_idempotent and record.is_idempotent:
                score += 0.2
            scored.append((record, score))

        scored.sort(key=lambda x: x[1], reverse=True)

        results = [r for r, _ in scored[:n]]
        for record in results:
            record.replay_count += 1
            record.last_replayed_at = datetime.now().isoformat()

        return results

    def get_stats(self) -> Dict[str, Any]:
        total = sum(len(records) for records in self._buffer.values())
        idempotent = sum(
            1 for records in self._buffer.values()
            for r in records if r.is_idempotent
        )
        by_type: Dict[str, int] = {k: len(v) for k, v in self._buffer.items()}
        avg_quality = 0.0
        if total > 0:
            avg_quality = sum(
                r.quality_score for records in self._buffer.values() for r in records
            ) / total

        return {
            "total_records": total,
            "idempotent_records": idempotent,
            "idempotency_rate": round(idempotent / max(total, 1), 3),
            "by_task_type": by_type,
            "avg_quality": round(avg_quality, 3),
            "capacity": self.MAX_BUFFER_SIZE,
        }

    def _check_idempotency(
        self,
        task_type: str,
        input_text: str,
        output_text: str,
    ) -> Tuple[bool, float]:
        existing = self._buffer.get(task_type, [])
        if not existing:
            return True, 1.0

        input_words = set(input_text.lower().split())
        for record in existing[-50:]:
            existing_input_words = set(record.input_text.lower().split())
            overlap = input_words & existing_input_words
            union = input_words | existing_input_words
            if union and len(overlap) / len(union) > 0.8:
                output_words = set(output_text.lower().split())
                existing_output_words = set(record.output_text.lower().split())
                out_overlap = output_words & existing_output_words
                out_union = output_words | existing_output_words
                if out_union:
                    sim = len(out_overlap) / len(out_union)
                    return sim >= self.IDEMPOTENCY_THRESHOLD, sim

        return True, 1.0

    def _enforce_max_size(self, task_type: str) -> None:
        records = self._buffer[task_type]
        if len(records) <= self.MAX_BUFFER_SIZE:
            return

        scored = [(r, self._scorer.score(r)) for r in records]
        scored.sort(key=lambda x: x[1])
        to_remove = len(records) - self.MAX_BUFFER_SIZE
        for record, _ in scored[:to_remove]:
            records.remove(record)

    def _persist(self, record: ReplayRecord) -> None:
        try:
            filepath = self._storage_dir / f"{record.task_type}.jsonl"
            with open(filepath, "a", encoding="utf-8") as f:
                f.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")
        except Exception as e:
            logger.warning("Failed to persist replay record: %s", e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return
        for filepath in self._storage_dir.glob("*.jsonl"):
            task_type = filepath.stem
            try:
                lines = filepath.read_text(encoding="utf-8").strip().split("\n")
                for line in lines[-self.MAX_BUFFER_SIZE:]:
                    if not line.strip():
                        continue
                    data = json.loads(line)
                    record = ReplayRecord(
                        id=data.get("id", ""),
                        task_type=data.get("task_type", task_type),
                        input_text=data.get("input_text", ""),
                        output_text=data.get("output_text", ""),
                        quality_score=data.get("quality_score", 0.0),
                        replay_count=data.get("replay_count", 0),
                        last_replayed_at=data.get("last_replayed_at", ""),
                        created_at=data.get("created_at", ""),
                        source=data.get("source", ""),
                        is_idempotent=data.get("is_idempotent", False),
                        idempotency_score=data.get("idempotency_score", 0.0),
                    )
                    self._buffer[task_type].append(record)
            except Exception as e:
                logger.warning("Failed to load replay buffer from %s: %s", filepath, e)


def get_replay_buffer() -> IdempotentReplayBuffer:
    return IdempotentReplayBuffer()
