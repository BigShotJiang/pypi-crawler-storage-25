# -*- coding: utf-8 -*-
"""Evolution Loop Monitor - Track and auto-trigger the self-evolution loop.

Monitors the health of the entire self-evolution closed loop:
  Data Collection → Quality Assessment → Training → Validation → Deployment

Key metrics:
- Data collection rate (interactions/hour)
- KTO data readiness (desirable/undesirable ratio)
- Bridge sync health (DataFlywheel + Kappa sync status)
- Distillation health (principles created/validated)
- Model validation pass rate
- Evolution loop completion time

Auto-triggers evolution when:
- KTO data exceeds minimum threshold
- Outcome evaluation success rate drops below threshold
- Bridge sync hasn't run in >2 hours
"""

import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from threading import Lock

from ._utils import atomic_write
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class LoopHealth(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    STALLED = "stalled"
    UNKNOWN = "unknown"


class TriggerReason(str, Enum):
    KTO_DATA_READY = "kto_data_ready"
    SUCCESS_RATE_DROP = "success_rate_drop"
    BRIDGE_SYNC_STALE = "bridge_sync_stale"
    DISTILLATION_NEEDED = "distillation_needed"
    SCHEDULED = "scheduled"
    MANUAL = "manual"
    EXPERIENCE_POOL_LOW = "experience_pool_low"
    PATCH_ROLLBACK_HIGH = "patch_rollback_high"


@dataclass
class LoopMetrics:
    data_collection_rate: float = 0.0
    kto_desirable_count: int = 0
    kto_undesirable_count: int = 0
    kto_ratio: float = 0.0
    kto_ready: bool = False
    bridge_last_sync: Optional[str] = None
    bridge_sync_age_hours: float = 0.0
    distillation_principles_count: int = 0
    distillation_active_count: int = 0
    outcome_success_rate: float = 0.0
    outcome_total_evaluations: int = 0
    model_validation_pass_rate: float = 0.0
    experience_pool_size: int = 0
    patch_lineage_active: int = 0
    patch_lineage_rollback_rate: float = 0.0
    loop_health: LoopHealth = LoopHealth.UNKNOWN
    last_evolution_time: Optional[str] = None
    evolution_count_24h: int = 0


@dataclass
class EvolutionTrigger:
    reason: TriggerReason
    description: str
    priority: float = 0.5
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)


class EvolutionLoopMonitor:
    """Monitor and auto-trigger the self-evolution closed loop.

    Usage:
        monitor = EvolutionLoopMonitor()
        metrics = monitor.collect_metrics()
        triggers = monitor.check_triggers(metrics)
        if triggers:
            for trigger in triggers:
                monitor.execute_trigger(trigger)
    """

    KTO_MIN_SAMPLES = 32
    SUCCESS_RATE_THRESHOLD = 0.7
    BRIDGE_SYNC_MAX_AGE_HOURS = 2.0
    DISTILLATION_MIN_PRINCIPLES = 5
    EVOLUTION_MAX_PER_24H = 10

    def __init__(self, storage_dir: Optional[str] = None):
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "evolution_monitor"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._evolution_history: deque = deque(maxlen=100)
        self._lock = Lock()
        self._load_history()
        self._metrics_cache: Optional[LoopMetrics] = None
        self._metrics_cache_time: float = 0
        self._METRICS_CACHE_TTL = 60.0

    def collect_metrics(self) -> LoopMetrics:
        import time as _time
        now = _time.time()
        if self._metrics_cache and (now - self._metrics_cache_time) < self._METRICS_CACHE_TTL:
            return self._metrics_cache

        metrics = LoopMetrics()

        self._collect_kto_metrics(metrics)
        self._collect_bridge_metrics(metrics)
        self._collect_distillation_metrics(metrics)
        self._collect_outcome_metrics(metrics)
        self._collect_experience_pool_metrics(metrics)
        self._collect_patch_lineage_metrics(metrics)

        metrics.loop_health = self._assess_health(metrics)

        self._metrics_cache = metrics
        self._metrics_cache_time = now

        return metrics

    def check_triggers(self, metrics: LoopMetrics) -> List[EvolutionTrigger]:
        triggers = []

        if metrics.kto_ready and not self._recent_evolution_for(TriggerReason.KTO_DATA_READY):
            triggers.append(EvolutionTrigger(
                reason=TriggerReason.KTO_DATA_READY,
                description=f"KTO data ready: {metrics.kto_desirable_count} desirable, "
                           f"{metrics.kto_undesirable_count} undesirable samples",
                priority=0.8,
                metadata={"kto_desirable": metrics.kto_desirable_count,
                         "kto_undesirable": metrics.kto_undesirable_count},
            ))

        if (metrics.outcome_success_rate < self.SUCCESS_RATE_THRESHOLD
                and metrics.outcome_total_evaluations >= 10
                and not self._recent_evolution_for(TriggerReason.SUCCESS_RATE_DROP)):
            triggers.append(EvolutionTrigger(
                reason=TriggerReason.SUCCESS_RATE_DROP,
                description=f"Outcome success rate dropped to {metrics.outcome_success_rate:.1%}",
                priority=0.9,
                metadata={"success_rate": metrics.outcome_success_rate},
            ))

        if (metrics.bridge_sync_age_hours > self.BRIDGE_SYNC_MAX_AGE_HOURS
                and not self._recent_evolution_for(TriggerReason.BRIDGE_SYNC_STALE)):
            triggers.append(EvolutionTrigger(
                reason=TriggerReason.BRIDGE_SYNC_STALE,
                description=f"Bridge sync stale: {metrics.bridge_sync_age_hours:.1f} hours ago",
                priority=0.6,
                metadata={"sync_age_hours": metrics.bridge_sync_age_hours},
            ))

        if (metrics.distillation_principles_count < self.DISTILLATION_MIN_PRINCIPLES
                and metrics.data_collection_rate > 0
                and not self._recent_evolution_for(TriggerReason.DISTILLATION_NEEDED)):
            triggers.append(EvolutionTrigger(
                reason=TriggerReason.DISTILLATION_NEEDED,
                description=f"Only {metrics.distillation_principles_count} distilled principles, "
                           f"need at least {self.DISTILLATION_MIN_PRINCIPLES}",
                priority=0.5,
            ))

        triggers.sort(key=lambda t: t.priority, reverse=True)
        return triggers

    def record_evolution(self, trigger: EvolutionTrigger, success: bool) -> None:
        with self._lock:
            self._evolution_history.append({
                "reason": trigger.reason.value,
                "description": trigger.description,
                "priority": trigger.priority,
                "success": success,
                "timestamp": datetime.now().isoformat(),
            })
            self._persist_history()

    def execute_trigger(self, trigger: EvolutionTrigger) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "trigger": trigger.reason.value,
            "action": "none",
            "success": False,
        }

        try:
            if trigger.reason == TriggerReason.KTO_DATA_READY:
                result["action"] = "kto_training_initiated"
                result["success"] = True
            elif trigger.reason == TriggerReason.SUCCESS_RATE_DROP:
                from .self_distillation import get_distillation_loop
                loop = get_distillation_loop()
                stats = loop.distill_from_outcomes(hours=24)
                result["action"] = "distillation_triggered"
                result["principles_created"] = stats.get("principles_created", 0)
                result["success"] = True
            elif trigger.reason == TriggerReason.BRIDGE_SYNC_STALE:
                result["action"] = "bridge_sync_requested"
                result["success"] = True
            elif trigger.reason == TriggerReason.DISTILLATION_NEEDED:
                from .self_distillation import get_distillation_loop
                loop = get_distillation_loop()
                stats = loop.distill_from_outcomes(hours=48)
                result["action"] = "distillation_triggered"
                result["principles_created"] = stats.get("principles_created", 0)
                result["success"] = True
            elif trigger.reason == TriggerReason.EXPERIENCE_POOL_LOW:
                result["action"] = "experience_collection_suggested"
                result["success"] = True
            elif trigger.reason == TriggerReason.PATCH_ROLLBACK_HIGH:
                result["action"] = "safety_review_suggested"
                result["success"] = True

            self.record_evolution(trigger, result["success"])
            self._metrics_cache = None
        except Exception as e:
            logger.error("Failed to execute trigger %s: %s", trigger.reason.value, e)
            result["error"] = str(e)

        return result

    def get_dashboard(self) -> Dict[str, Any]:
        metrics = self.collect_metrics()
        triggers = self.check_triggers(metrics)

        return {
            "loop_health": metrics.loop_health.value,
            "kto_status": {
                "desirable": metrics.kto_desirable_count,
                "undesirable": metrics.kto_undesirable_count,
                "ratio": round(metrics.kto_ratio, 3),
                "ready": metrics.kto_ready,
            },
            "bridge_status": {
                "last_sync": metrics.bridge_last_sync,
                "sync_age_hours": round(metrics.bridge_sync_age_hours, 1),
                "stale": metrics.bridge_sync_age_hours > self.BRIDGE_SYNC_MAX_AGE_HOURS,
            },
            "distillation_status": {
                "total_principles": metrics.distillation_principles_count,
                "active_principles": metrics.distillation_active_count,
            },
            "outcome_status": {
                "success_rate": round(metrics.outcome_success_rate, 3),
                "total_evaluations": metrics.outcome_total_evaluations,
            },
            "experience_pool_size": metrics.experience_pool_size,
            "patch_lineage": {
                "active": metrics.patch_lineage_active,
                "rollback_rate": round(metrics.patch_lineage_rollback_rate, 3),
            },
            "pending_triggers": [
                {"reason": t.reason.value, "priority": t.priority, "description": t.description}
                for t in triggers
            ],
            "evolution_count_24h": metrics.evolution_count_24h,
            "timestamp": datetime.now().isoformat(),
        }

    def _collect_kto_metrics(self, metrics: LoopMetrics) -> None:
        try:
            from ...model_trainer.kto_trainer import KTODataCollector
            collector = KTODataCollector()
            counts = collector.get_all_counts()
            total_desirable = sum(c.get("desirable", 0) for c in counts.values())
            total_undesirable = sum(c.get("undesirable", 0) for c in counts.values())
            total = total_desirable + total_undesirable

            metrics.kto_desirable_count = total_desirable
            metrics.kto_undesirable_count = total_undesirable
            metrics.kto_ratio = total_desirable / max(total, 1)
            metrics.kto_ready = total >= self.KTO_MIN_SAMPLES
        except Exception as e:
            logger.debug("Failed to collect KTO metrics: %s", e)

    def _collect_bridge_metrics(self, metrics: LoopMetrics) -> None:
        try:
            sync_file = Path.home() / ".xingzierai" / "evolution_model_sync.json"
            if sync_file.exists():
                data = json.loads(sync_file.read_text(encoding="utf-8"))
                metrics.bridge_last_sync = data.get("updated_at")
                if metrics.bridge_last_sync:
                    sync_time = datetime.fromisoformat(metrics.bridge_last_sync)
                    metrics.bridge_sync_age_hours = (datetime.now() - sync_time).total_seconds() / 3600
        except Exception as e:
            logger.debug("Failed to collect bridge metrics: %s", e)

    def _collect_distillation_metrics(self, metrics: LoopMetrics) -> None:
        try:
            from .self_distillation import SelfDistillationLoop
            loop = SelfDistillationLoop()
            stats = loop.get_stats()
            metrics.distillation_principles_count = stats.get("total_principles", 0)
            metrics.distillation_active_count = stats.get("by_status", {}).get("active", 0)
        except Exception as e:
            logger.debug("Failed to collect distillation metrics: %s", e)

    def _collect_outcome_metrics(self, metrics: LoopMetrics) -> None:
        try:
            outcomes_file = Path.home() / ".xingzierai" / "outcomes" / "outcome_records.json"
            if outcomes_file.exists():
                data = json.loads(outcomes_file.read_text(encoding="utf-8"))
                records = data if isinstance(data, list) else data.get("records", [])
                recent = [r for r in records[-100:]]
                if recent:
                    passed = sum(1 for r in recent if r.get("overall_passed", False))
                    metrics.outcome_success_rate = passed / len(recent)
                    metrics.outcome_total_evaluations = len(recent)
        except Exception as e:
            logger.debug("Failed to collect outcome metrics: %s", e)

    def _collect_experience_pool_metrics(self, metrics: LoopMetrics) -> None:
        try:
            from .experience_sharing import ExperienceSharingPool
            pool = ExperienceSharingPool()
            stats = pool.get_stats()
            metrics.experience_pool_size = stats.get("total_experiences", 0)
        except Exception as e:
            logger.debug("Failed to collect experience pool metrics: %s", e)

    def _collect_patch_lineage_metrics(self, metrics: LoopMetrics) -> None:
        try:
            from .patch_lineage import PatchLineageTracker
            tracker = PatchLineageTracker()
            stats = tracker.get_stats()
            metrics.patch_lineage_active = stats.active_patches
            metrics.patch_lineage_rollback_rate = stats.rollback_rate
        except Exception as e:
            logger.debug("Failed to collect patch lineage metrics: %s", e)

    def _assess_health(self, metrics: LoopMetrics) -> LoopHealth:
        issues = 0

        if metrics.kto_ratio < 0.3 and metrics.kto_desirable_count + metrics.kto_undesirable_count > 10:
            issues += 1

        if metrics.bridge_sync_age_hours > self.BRIDGE_SYNC_MAX_AGE_HOURS * 2:
            issues += 1

        if metrics.outcome_success_rate < self.SUCCESS_RATE_THRESHOLD and metrics.outcome_total_evaluations >= 10:
            issues += 1

        if metrics.patch_lineage_rollback_rate > 0.5:
            issues += 1

        if issues == 0:
            return LoopHealth.HEALTHY
        elif issues <= 2:
            return LoopHealth.DEGRADED
        else:
            return LoopHealth.STALLED

    def _recent_evolution_for(self, reason: TriggerReason, hours: float = 1.0) -> bool:
        cutoff = datetime.now() - timedelta(hours=hours)
        with self._lock:
            for entry in self._evolution_history:
                try:
                    entry_time = datetime.fromisoformat(entry.get("timestamp", ""))
                    if entry_time > cutoff and entry.get("reason") == reason.value:
                        return True
                except (ValueError, TypeError):
                    continue
        return False

    def _persist_history(self) -> None:
        try:
            filepath = self._storage_dir / "evolution_history.json"
            atomic_write(
                filepath,
                json.dumps(list(self._evolution_history), indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning("Failed to persist evolution history: %s", e)

    def _load_history(self) -> None:
        filepath = self._storage_dir / "evolution_history.json"
        if not filepath.exists():
            return
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
            for entry in data[-100:]:
                self._evolution_history.append(entry)
        except Exception as e:
            logger.warning("Failed to load evolution history: %s", e)


def get_evolution_monitor() -> EvolutionLoopMonitor:
    return EvolutionLoopMonitor()
