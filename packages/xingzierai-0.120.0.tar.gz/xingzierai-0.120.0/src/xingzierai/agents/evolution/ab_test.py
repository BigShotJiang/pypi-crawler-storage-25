# -*- coding: utf-8 -*-
"""Evolution A/B Testing Framework - Deploy to subset, measure, expand."""

from __future__ import annotations

from ._utils import atomic_write

import json
import logging
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class ExperimentStatus(str, Enum):
    DRAFT = "draft"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class VariantResult(str, Enum):
    WIN = "win"
    LOSE = "lose"
    INCONCLUSIVE = "inconclusive"


@dataclass
class ExperimentVariant:
    name: str
    description: str = ""
    config: Dict[str, Any] = field(default_factory=dict)
    traffic_percent: float = 50.0
    success_count: int = 0
    failure_count: int = 0
    total_latency_ms: float = 0.0
    quality_scores: List[float] = field(default_factory=list)

    @property
    def total_count(self) -> int:
        return self.success_count + self.failure_count

    @property
    def success_rate(self) -> float:
        return self.success_count / max(self.total_count, 1)

    @property
    def avg_latency_ms(self) -> float:
        return self.total_latency_ms / max(self.total_count, 1)

    @property
    def avg_quality(self) -> float:
        return sum(self.quality_scores) / max(len(self.quality_scores), 1)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "traffic_percent": self.traffic_percent,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "success_rate": round(self.success_rate, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "avg_quality": round(self.avg_quality, 4),
        }


@dataclass
class Experiment:
    id: str
    name: str
    description: str = ""
    status: ExperimentStatus = ExperimentStatus.DRAFT
    variants: List[ExperimentVariant] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    ended_at: Optional[float] = None
    min_sample_size: int = 30
    confidence_threshold: float = 0.95
    winner: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "status": self.status.value,
            "variants": [v.to_dict() for v in self.variants],
            "created_at": self.created_at,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "min_sample_size": self.min_sample_size,
            "confidence_threshold": self.confidence_threshold,
            "winner": self.winner,
        }


class ABTestFramework:
    MAX_EXPERIMENTS = 50

    def __init__(self, storage_dir: Optional[str] = None):
        self._storage_dir = Path(storage_dir) if storage_dir else Path.home() / ".xingzierai" / "ab_tests"
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._experiments: Dict[str, Experiment] = {}
        self._assignment_cache: Dict[str, str] = {}
        self._load()

    def create_experiment(
        self,
        name: str,
        variants: List[Dict[str, Any]],
        description: str = "",
        min_sample_size: int = 30,
    ) -> Experiment:
        exp_id = f"exp_{int(time.time() * 1000)}"
        exp_variants = []
        for v in variants:
            exp_variants.append(ExperimentVariant(
                name=v.get("name", "variant"),
                description=v.get("description", ""),
                config=v.get("config", {}),
                traffic_percent=v.get("traffic_percent", 50.0),
            ))
        exp = Experiment(
            id=exp_id,
            name=name,
            description=description,
            variants=exp_variants,
            min_sample_size=min_sample_size,
        )
        self._experiments[exp_id] = exp
        self._persist(exp)
        return exp

    def start_experiment(self, experiment_id: str) -> Optional[Experiment]:
        exp = self._experiments.get(experiment_id)
        if not exp:
            return None
        if len(exp.variants) < 2:
            logger.error("Experiment needs at least 2 variants")
            return None
        exp.status = ExperimentStatus.RUNNING
        exp.started_at = time.time()
        self._persist(exp)
        return exp

    def assign_variant(self, experiment_id: str, agent_id: str) -> Optional[str]:
        exp = self._experiments.get(experiment_id)
        if not exp or exp.status != ExperimentStatus.RUNNING:
            return None
        cache_key = f"{experiment_id}:{agent_id}"
        if cache_key in self._assignment_cache:
            return self._assignment_cache[cache_key]
        rand = random.random() * 100
        cumulative = 0.0
        for variant in exp.variants:
            cumulative += variant.traffic_percent
            if rand <= cumulative:
                self._assignment_cache[cache_key] = variant.name
                return variant.name
        default = exp.variants[0].name
        self._assignment_cache[cache_key] = default
        return default

    def record_result(
        self,
        experiment_id: str,
        variant_name: str,
        success: bool,
        latency_ms: float = 0.0,
        quality_score: float = 0.0,
    ) -> bool:
        exp = self._experiments.get(experiment_id)
        if not exp or exp.status != ExperimentStatus.RUNNING:
            return False
        for variant in exp.variants:
            if variant.name == variant_name:
                if success:
                    variant.success_count += 1
                else:
                    variant.failure_count += 1
                variant.total_latency_ms += latency_ms
                if quality_score > 0:
                    variant.quality_scores.append(quality_score)
                    if len(variant.quality_scores) > 500:
                        variant.quality_scores = variant.quality_scores[-500:]
                break
        self._persist(exp)
        self._check_completion(exp)
        return True

    def _check_completion(self, exp: Experiment) -> None:
        for variant in exp.variants:
            if variant.total_count < exp.min_sample_size:
                return
        best = max(exp.variants, key=lambda v: v.success_rate)
        worst = min(exp.variants, key=lambda v: v.success_rate)
        if best.success_rate == worst.success_rate:
            return
        from math import sqrt
        p1 = best.success_rate
        p2 = worst.success_rate
        n1 = max(best.total_count, 1)
        n2 = max(worst.total_count, 1)
        se = sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
        if se == 0:
            return
        z_score = abs(p1 - p2) / se
        if z_score >= 1.96:
            exp.winner = best.name
            exp.status = ExperimentStatus.COMPLETED
            exp.ended_at = time.time()
            self._persist(exp)
            logger.info("Experiment %s completed! Winner: %s (z=%.2f)", exp.id, best.name, z_score)

    def get_experiment(self, experiment_id: str) -> Optional[Experiment]:
        return self._experiments.get(experiment_id)

    def list_experiments(self, status: Optional[ExperimentStatus] = None) -> List[Experiment]:
        exps = list(self._experiments.values())
        if status:
            exps = [e for e in exps if e.status == status]
        return sorted(exps, key=lambda e: e.created_at, reverse=True)

    def get_stats(self) -> Dict[str, Any]:
        by_status: Dict[str, int] = {}
        for exp in self._experiments.values():
            by_status[exp.status.value] = by_status.get(exp.status.value, 0) + 1
        return {
            "total_experiments": len(self._experiments),
            "by_status": by_status,
            "active_count": sum(1 for e in self._experiments.values() if e.status == ExperimentStatus.RUNNING),
        }

    def _persist(self, exp: Experiment) -> None:
        try:
            filepath = self._storage_dir / f"{exp.id}.json"
            atomic_write(filepath, json.dumps(exp.to_dict(), ensure_ascii=False, indent=2))
        except Exception as e:
            logger.error("Failed to persist experiment %s: %s", exp.id, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return
        for filepath in self._storage_dir.glob("exp_*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                variants = []
                for vd in data.get("variants", []):
                    variants.append(ExperimentVariant(
                        name=vd["name"],
                        description=vd.get("description", ""),
                        config=vd.get("config", {}),
                        traffic_percent=vd.get("traffic_percent", 50.0),
                        success_count=vd.get("success_count", 0),
                        failure_count=vd.get("failure_count", 0),
                        total_latency_ms=vd.get("total_latency_ms", 0.0),
                        quality_scores=vd.get("quality_scores", []),
                    ))
                exp = Experiment(
                    id=data["id"],
                    name=data["name"],
                    description=data.get("description", ""),
                    status=ExperimentStatus(data.get("status", "draft")),
                    variants=variants,
                    created_at=data.get("created_at", time.time()),
                    started_at=data.get("started_at"),
                    ended_at=data.get("ended_at"),
                    min_sample_size=data.get("min_sample_size", 30),
                    confidence_threshold=data.get("confidence_threshold", 0.95),
                    winner=data.get("winner"),
                )
                self._experiments[exp.id] = exp
            except Exception as e:
                logger.warning("Failed to load experiment from %s: %s", filepath, e)
        logger.info("Loaded %d A/B test experiments", len(self._experiments))


_abtest_instance: Optional[ABTestFramework] = None


def get_abtest_framework() -> ABTestFramework:
    global _abtest_instance
    if _abtest_instance is None:
        _abtest_instance = ABTestFramework()
    return _abtest_instance
