# -*- coding: utf-8 -*-
"""Evolution Event Bus - Cross-module communication for evolution events."""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class EvolutionEventType(str, Enum):
    PATCH_APPLIED = "patch_applied"
    PATCH_ROLLED_BACK = "patch_rolled_back"
    PRINCIPLE_CREATED = "principle_created"
    PRINCIPLE_DEPRECATED = "principle_deprecated"
    EXPERIENCE_PUBLISHED = "experience_published"
    EXPERIENCE_FUSED = "experience_fused"
    CALIBRATION_RECORDED = "calibration_recorded"
    SAFETY_VIOLATION = "safety_violation"
    EVOLUTION_TRIGGERED = "evolution_triggered"
    EVOLUTION_COMPLETED = "evolution_completed"
    EVOLUTION_FAILED = "evolution_failed"
    BRIDGE_SYNCED = "bridge_synced"
    KTO_DATA_READY = "kto_data_ready"
    OUTCOME_EVALUATED = "outcome_evaluated"
    REPLAY_ADDED = "replay_added"
    LOOP_HEALTH_CHANGED = "loop_health_changed"
    GATE_FAILED = "gate_failed"
    BUG_PATTERN_DISCOVERED = "bug_pattern_discovered"
    REFLECTION_COMPLETED = "reflection_completed"


@dataclass
class EvolutionEvent:
    event_type: EvolutionEventType
    source: str
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    event_id: str = ""

    def __post_init__(self):
        if not self.event_id:
            self.event_id = f"{self.event_type.value}_{int(self.timestamp * 1000)}"


EventHandler = Callable[[EvolutionEvent], None]
AsyncEventHandler = Callable[[EvolutionEvent], Any]


class EvolutionEventBus:
    MAX_HISTORY = 500
    MAX_HANDLERS_PER_TYPE = 20

    def __init__(self):
        self._handlers: Dict[str, List[EventHandler]] = defaultdict(list)
        self._async_handlers: Dict[str, List[AsyncEventHandler]] = defaultdict(list)
        self._history: List[EvolutionEvent] = []
        self._subscribers: Set[str] = set()

    def subscribe(self, event_type: EvolutionEventType, handler: EventHandler) -> bool:
        key = event_type.value
        if len(self._handlers[key]) >= self.MAX_HANDLERS_PER_TYPE:
            logger.warning("Max handlers reached for %s", key)
            return False
        self._handlers[key].append(handler)
        self._subscribers.add(handler.__name__ if hasattr(handler, "__name__") else str(id(handler)))
        return True

    def subscribe_async(self, event_type: EvolutionEventType, handler: AsyncEventHandler) -> bool:
        key = event_type.value
        if len(self._async_handlers[key]) >= self.MAX_HANDLERS_PER_TYPE:
            logger.warning("Max async handlers reached for %s", key)
            return False
        self._async_handlers[key].append(handler)
        return True

    def unsubscribe(self, event_type: EvolutionEventType, handler: EventHandler) -> bool:
        key = event_type.value
        if handler in self._handlers[key]:
            self._handlers[key].remove(handler)
            return True
        return False

    def publish(self, event: EvolutionEvent) -> int:
        delivered = 0
        key = event.event_type.value

        for handler in self._handlers.get(key, []):
            try:
                handler(event)
                delivered += 1
            except Exception as e:
                logger.error("Event handler error for %s: %s", key, e)

        for handler in self._handlers.get("*", []):
            try:
                handler(event)
                delivered += 1
            except Exception as e:
                logger.error("Wildcard handler error: %s", e)

        self._history.append(event)
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]

        logger.debug("Published event %s to %d handlers", event.event_type.value, delivered)
        return delivered

    async def publish_async(self, event: EvolutionEvent) -> int:
        delivered = self.publish(event)
        key = event.event_type.value

        for handler in self._async_handlers.get(key, []):
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    await result
                delivered += 1
            except Exception as e:
                logger.error("Async event handler error for %s: %s", key, e)

        return delivered

    def get_history(
        self,
        event_type: Optional[EvolutionEventType] = None,
        source: Optional[str] = None,
        limit: int = 50,
    ) -> List[EvolutionEvent]:
        events = self._history
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if source:
            events = [e for e in events if e.source == source]
        return events[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = defaultdict(int)
        by_source: Dict[str, int] = defaultdict(int)
        for event in self._history:
            by_type[event.event_type.value] += 1
            by_source[event.source] += 1
        return {
            "total_events": len(self._history),
            "by_type": dict(by_type),
            "by_source": dict(by_source),
            "subscribers": len(self._subscribers),
            "handler_count": sum(len(v) for v in self._handlers.values()) + sum(len(v) for v in self._async_handlers.values()),
        }

    def clear_history(self) -> None:
        self._history.clear()


_bus_instance: Optional[EvolutionEventBus] = None


def get_evolution_bus() -> EvolutionEventBus:
    global _bus_instance
    if _bus_instance is None:
        _bus_instance = EvolutionEventBus()
    return _bus_instance
