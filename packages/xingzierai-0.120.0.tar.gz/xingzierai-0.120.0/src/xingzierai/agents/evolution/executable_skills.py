#!/usr/bin/env python3 -*-
"""Executable Skills - upgrade from Kappa text experience to executable Python modules.

Inspired by AgentFactory (arXiv:2603.18000):
- Skills are stored as executable Python code, not just text descriptions
- 3-stage lifecycle: Install (build) -> Self-Evolve (improve) -> Deploy (use)
- Skills are self-contained modules with standard documentation
- Token consumption reduced by 57% vs text-based experience (AgentFactory result)

Each skill is a Python module with:
- docstring: Description and usage
- execute() function: The actual skill logic
- validate() function: Pre-execution validation
- metadata: Category, triggers, success rate
"""

from __future__ import annotations

import asyncio
import importlib
import importlib.util
import json
import logging
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_SKILLS_DIR = Path.home() / ".xingzierai" / "executable_skills"


class SkillStage(str, Enum):
    INSTALL = "install"
    SELF_EVOLVE = "self_evolve"
    DEPLOY = "deploy"


class SkillStatus(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ERROR = "error"


@dataclass
class SkillMetadata:
    name: str
    category: str = "general"
    triggers: List[str] = field(default_factory=list)
    description: str = ""
    version: str = "1.0.0"
    author: str = "xingzierai"
    success_rate: float = 0.0
    invocation_count: int = 0
    last_used: float = 0.0
    created_at: float = 0.0
    stage: SkillStage = SkillStage.INSTALL
    status: SkillStatus = SkillStatus.DRAFT
    source_experience_id: str = ""

    def __post_init__(self):
        if self.created_at == 0.0:
            self.created_at = time.time()

    def to_dict(self) -> Dict:
        return {
            "name": self.name, "category": self.category,
            "triggers": self.triggers, "description": self.description,
            "version": self.version, "author": self.author,
            "success_rate": self.success_rate,
            "invocation_count": self.invocation_count,
            "last_used": self.last_used, "created_at": self.created_at,
            "stage": self.stage.value, "status": self.status.value,
            "source_experience_id": self.source_experience_id,
        }


SKILL_TEMPLATE = '''#!/usr/bin/env python3
"""Skill: {name}

{description}

Category: {category}
Triggers: {triggers}
Version: {version}
Author: {author}
"""

from typing import Any, Dict, Optional


SKILL_METADATA = {{
    "name": "{name}",
    "category": "{category}",
    "triggers": {triggers_list},
    "description": """{description}""",
    "version": "{version}",
}}


async def validate(context: Dict[str, Any]) -> bool:
    """Pre-execution validation. Return True if skill is applicable."""
    return True


async def execute(context: Dict[str, Any]) -> Dict[str, Any]:
    """Execute the skill logic.

    Args:
        context: Execution context with keys:
            - task: The task description
            - agent_id: The agent executing
            - session_id: The session ID
            - tools: Available tools
            - memory: Memory access

    Returns:
        Result dict with keys:
            - success: bool
            - output: str
            - error: Optional[str]
    """
    task = context.get("task", "")
    # TODO: Implement skill logic
    return {{
        "success": True,
        "output": f"Skill {{SKILL_METADATA['name']}} executed for: {{task}}",
        "error": None,
    }}
'''


class ExecutableSkillManager:
    """Manager for executable skills.

    Handles skill creation, loading, execution, and lifecycle management.
    """

    MAX_SKILLS = 200

    def __init__(self, skills_dir: Optional[str] = None):
        self._skills_dir = Path(skills_dir) if skills_dir else _SKILLS_DIR
        self._skills: Dict[str, SkillMetadata] = {}
        self._modules: Dict[str, Any] = {}
        self._load_all()

    def _load_all(self):
        self._skills_dir.mkdir(parents=True, exist_ok=True)
        meta_path = self._skills_dir / "registry.json"
        if meta_path.exists():
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
                for name, meta_dict in data.items():
                    self._skills[name] = SkillMetadata(**{k: v for k, v in meta_dict.items()
                                                          if k in SkillMetadata.__dataclass_fields__})
                    if meta_dict.get("stage") == SkillStage.DEPLOY.value:
                        self._load_module(name)
            except Exception as e:
                logger.warning(f"ExecutableSkillManager: load error: {e}")

    def _save_registry(self):
        meta_path = self._skills_dir / "registry.json"
        data = {name: meta.to_dict() for name, meta in self._skills.items()}
        meta_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _load_module(self, name: str) -> Optional[Any]:
        skill_path = self._skills_dir / f"{name}.py"
        if not skill_path.exists():
            return None
        try:
            spec = importlib.util.spec_from_file_location(f"xingzierai_skill_{name}", str(skill_path))
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                self._modules[name] = module
                return module
        except Exception as e:
            logger.warning(f"ExecutableSkillManager: load module {name} error: {e}")
            if name in self._skills:
                self._skills[name].status = SkillStatus.ERROR
        return None

    def create_skill(self, name: str, category: str = "general",
                     triggers: Optional[List[str]] = None,
                     description: str = "",
                     code: Optional[str] = None,
                     source_experience_id: str = "") -> SkillMetadata:
        safe_name = name.replace(" ", "_").replace("-", "_").lower()
        safe_name = "".join(c for c in safe_name if c.isalnum() or c == "_")
        if not safe_name:
            safe_name = f"skill_{uuid.uuid4().hex[:6]}"

        triggers = triggers or [safe_name]
        meta = SkillMetadata(
            name=safe_name, category=category, triggers=triggers,
            description=description or f"Executable skill: {name}",
            source_experience_id=source_experience_id,
        )

        skill_path = self._skills_dir / f"{safe_name}.py"
        if code:
            skill_path.write_text(code, encoding="utf-8")
        else:
            generated = SKILL_TEMPLATE.format(
                name=safe_name, category=category,
                description=description or f"Executable skill: {name}",
                triggers=", ".join(triggers),
                triggers_list=json.dumps(triggers),
                version="1.0.0", author="xingzierai",
            )
            skill_path.write_text(generated, encoding="utf-8")

        self._skills[safe_name] = meta
        self._save_registry()
        logger.info(f"ExecutableSkillManager: created skill '{safe_name}' at {skill_path}")
        return meta

    async def execute_skill(self, name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if name not in self._skills:
            return {"success": False, "error": f"Skill not found: {name}"}

        meta = self._skills[name]
        if meta.status not in (SkillStatus.VALIDATED, SkillStatus.ACTIVE):
            return {"success": False, "error": f"Skill status is {meta.status.value}, not executable"}

        module = self._modules.get(name)
        if module is None:
            module = self._load_module(name)
        if module is None:
            return {"success": False, "error": f"Failed to load skill module: {name}"}

        try:
            validate_fn = getattr(module, "validate", None)
            if validate_fn:
                valid = await validate_fn(context) if asyncio.iscoroutinefunction(validate_fn) else validate_fn(context)
                if not valid:
                    return {"success": False, "error": "Skill validation failed"}

            execute_fn = getattr(module, "execute", None)
            if execute_fn is None:
                return {"success": False, "error": "Skill has no execute() function"}

            result = await execute_fn(context) if asyncio.iscoroutinefunction(execute_fn) else execute_fn(context)

            meta.invocation_count += 1
            meta.last_used = time.time()
            if result.get("success", False):
                meta.success_rate = (
                    meta.success_rate * (meta.invocation_count - 1) + 1.0
                ) / meta.invocation_count
            else:
                meta.success_rate = (
                    meta.success_rate * (meta.invocation_count - 1)
                ) / meta.invocation_count

            if meta.invocation_count >= 3 and meta.success_rate >= 0.7:
                meta.status = SkillStatus.ACTIVE
                meta.stage = SkillStage.DEPLOY

            self._save_registry()
            return result

        except Exception as e:
            logger.error(f"ExecutableSkillManager: execute {name} error: {e}")
            return {"success": False, "error": str(e)}

    def find_skill(self, task: str) -> Optional[str]:
        task_lower = task.lower()
        best_match = None
        best_score = 0.0

        for name, meta in self._skills.items():
            if meta.status not in (SkillStatus.VALIDATED, SkillStatus.ACTIVE):
                continue
            for trigger in meta.triggers:
                if trigger.lower() in task_lower:
                    score = meta.success_rate * 0.5 + len(trigger) / max(len(task_lower), 1) * 0.5
                    if score > best_score:
                        best_score = score
                        best_match = name

        return best_match

    def list_skills(self, status: Optional[SkillStatus] = None) -> List[Dict]:
        skills = []
        for name, meta in self._skills.items():
            if status and meta.status != status:
                continue
            skills.append(meta.to_dict())
        return skills

    def upgrade_from_kappa(self, experience_id: str, name: str,
                           category: str, triggers: List[str],
                           description: str, code: str) -> SkillMetadata:
        return self.create_skill(
            name=name, category=category, triggers=triggers,
            description=description, code=code,
            source_experience_id=experience_id,
        )
