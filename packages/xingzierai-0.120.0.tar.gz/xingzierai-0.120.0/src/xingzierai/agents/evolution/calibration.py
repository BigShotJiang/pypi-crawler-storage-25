# -*- coding: utf-8 -*-
"""Agent Confidence Calibration - Brier Score based calibration.

Research shows AI agents are systematically overconfident:
- Anthropic (2025): Agent self-evaluation has 92% error rate on subjective tasks
- Solution: Brier Score calibration to adjust confidence to match actual accuracy

Brier Score = (1/N) * Σ(forecast - outcome)²
- Perfect calibration: Brier = 0
- Always wrong: Brier = 1
- Random guessing: Brier = 0.25

This module provides:
1. ConfidenceCalibrator: Track and calibrate agent confidence
2. CalibrationRecord: Individual calibration data point
3. CalibrationReport: Summary of calibration state
4. Auto-adjustment: Apply calibration to raw confidence scores
"""

import json
import logging
import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class CalibrationRecord:
    agent_name: str
    task_type: str
    predicted_confidence: float
    actual_outcome: bool
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    task_id: str = ""

    @property
    def brier_contribution(self) -> float:
        return (self.predicted_confidence - float(self.actual_outcome)) ** 2


@dataclass
class CalibrationBin:
    lower: float
    upper: float
    predictions: List[float] = field(default_factory=list)
    outcomes: List[bool] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.predictions)

    @property
    def avg_confidence(self) -> float:
        return sum(self.predictions) / max(len(self.predictions), 1)

    @property
    def accuracy(self) -> float:
        if not self.outcomes:
            return 0.0
        return sum(1 for o in self.outcomes if o) / len(self.outcomes)


@dataclass
class CalibrationReport:
    agent_name: str
    brier_score: float = 0.0
    total_records: int = 0
    calibration_error: float = 0.0
    overconfidence: float = 0.0
    underconfidence: float = 0.0
    bins: List[Dict[str, Any]] = field(default_factory=list)
    adjustment_factor: float = 1.0
    is_well_calibrated: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_name": self.agent_name,
            "brier_score": round(self.brier_score, 4),
            "total_records": self.total_records,
            "calibration_error": round(self.calibration_error, 4),
            "overconfidence": round(self.overconfidence, 4),
            "underconfidence": round(self.underconfidence, 4),
            "adjustment_factor": round(self.adjustment_factor, 4),
            "is_well_calibrated": self.is_well_calibrated,
            "bins": self.bins,
        }


class ConfidenceCalibrator:
    """Track and calibrate agent confidence using Brier Score.

    Usage:
        calibrator = ConfidenceCalibrator()
        calibrator.record("react_agent", "deploy", predicted=0.9, actual=True)
        calibrator.record("react_agent", "debug", predicted=0.8, actual=False)

        # Get calibrated confidence
        adjusted = calibrator.calibrate("react_agent", raw_confidence=0.9)

        # Get calibration report
        report = calibrator.get_report("react_agent")
    """

    MAX_RECORDS_PER_AGENT = 1000
    CALIBRATION_THRESHOLD = 0.1
    N_BINS = 10

    def __init__(self, storage_dir: Optional[str] = None):
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "calibration"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._records: Dict[str, List[CalibrationRecord]] = defaultdict(list)
        self._adjustment_cache: Dict[str, float] = {}
        self._load()

    def record(
        self,
        agent_name: str,
        task_type: str,
        predicted_confidence: float,
        actual_outcome: bool,
        task_id: str = "",
    ) -> None:
        predicted_confidence = max(0.0, min(1.0, predicted_confidence))

        rec = CalibrationRecord(
            agent_name=agent_name,
            task_type=task_type,
            predicted_confidence=predicted_confidence,
            actual_outcome=actual_outcome,
            task_id=task_id,
        )
        self._records[agent_name].append(rec)

        if len(self._records[agent_name]) > self.MAX_RECORDS_PER_AGENT:
            self._records[agent_name] = self._records[agent_name][-self.MAX_RECORDS_PER_AGENT:]

        self._adjustment_cache.pop(agent_name, None)
        self._persist(agent_name)

    def calibrate(self, agent_name: str, raw_confidence: float) -> float:
        raw_confidence = max(0.0, min(1.0, raw_confidence))

        if agent_name not in self._adjustment_cache:
            self._adjustment_cache[agent_name] = self._compute_adjustment(agent_name)

        factor = self._adjustment_cache[agent_name]
        adjusted = raw_confidence * factor
        return max(0.0, min(1.0, adjusted))

    def get_report(self, agent_name: str) -> CalibrationReport:
        records = self._records.get(agent_name, [])
        report = CalibrationReport(agent_name=agent_name)

        if not records:
            report.is_well_calibrated = True
            return report

        report.total_records = len(records)

        brier = sum(r.brier_contribution for r in records) / len(records)
        report.brier_score = brier

        bins = self._compute_bins(records)
        report.bins = [
            {
                "range": f"[{b.lower:.1f}, {b.upper:.1f})",
                "count": b.count,
                "avg_confidence": round(b.avg_confidence, 3),
                "accuracy": round(b.accuracy, 3),
                "gap": round(b.avg_confidence - b.accuracy, 3),
            }
            for b in bins
        ]

        ece = 0.0
        total = len(records)
        for b in bins:
            if b.count > 0:
                ece += abs(b.avg_confidence - b.accuracy) * (b.count / total)
        report.calibration_error = ece

        overconf = 0.0
        underconf = 0.0
        for b in bins:
            if b.count > 0:
                gap = b.avg_confidence - b.accuracy
                if gap > 0:
                    overconf += gap * (b.count / total)
                else:
                    underconf += abs(gap) * (b.count / total)
        report.overconfidence = overconf
        report.underconfidence = underconf

        report.adjustment_factor = self._compute_adjustment(agent_name)
        report.is_well_calibrated = ece < self.CALIBRATION_THRESHOLD

        return report

    def get_all_reports(self) -> Dict[str, CalibrationReport]:
        return {name: self.get_report(name) for name in self._records}

    def get_stats(self) -> Dict[str, Any]:
        all_reports = self.get_all_reports()
        return {
            "agents_tracked": len(all_reports),
            "reports": {name: r.to_dict() for name, r in all_reports.items()},
            "total_records": sum(r.total_records for r in all_reports.values()),
        }

    def _compute_adjustment(self, agent_name: str) -> float:
        records = self._records.get(agent_name, [])
        if len(records) < 10:
            return 1.0

        recent = records[-100:]
        avg_predicted = sum(r.predicted_confidence for r in recent) / len(recent)
        actual_success_rate = sum(1 for r in recent if r.actual_outcome) / len(recent)

        if avg_predicted > 0:
            return actual_success_rate / avg_predicted
        return 1.0

    def _compute_bins(self, records: List[CalibrationRecord]) -> List[CalibrationBin]:
        bins = []
        for i in range(self.N_BINS):
            lower = i / self.N_BINS
            upper = (i + 1) / self.N_BINS
            bin_records = [
                r for r in records
                if lower <= r.predicted_confidence < upper
            ]
            b = CalibrationBin(lower=lower, upper=upper)
            b.predictions = [r.predicted_confidence for r in bin_records]
            b.outcomes = [r.actual_outcome for r in bin_records]
            bins.append(b)
        return bins

    def _persist(self, agent_name: str) -> None:
        try:
            filepath = self._storage_dir / f"{agent_name}.json"
            records = self._records.get(agent_name, [])
            data = [
                {
                    "agent_name": r.agent_name,
                    "task_type": r.task_type,
                    "predicted_confidence": r.predicted_confidence,
                    "actual_outcome": r.actual_outcome,
                    "timestamp": r.timestamp,
                    "task_id": r.task_id,
                }
                for r in records[-self.MAX_RECORDS_PER_AGENT:]
            ]
            atomic_write(
                filepath,
                json.dumps(data, indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning("Failed to persist calibration for %s: %s", agent_name, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return
        for filepath in self._storage_dir.glob("*.json"):
            try:
                agent_name = filepath.stem
                data = json.loads(filepath.read_text(encoding="utf-8"))
                for entry in data:
                    rec = CalibrationRecord(
                        agent_name=entry.get("agent_name", agent_name),
                        task_type=entry.get("task_type", ""),
                        predicted_confidence=entry.get("predicted_confidence", 0.5),
                        actual_outcome=entry.get("actual_outcome", False),
                        timestamp=entry.get("timestamp", ""),
                        task_id=entry.get("task_id", ""),
                    )
                    self._records[agent_name].append(rec)
            except Exception as e:
                logger.warning("Failed to load calibration from %s: %s", filepath, e)


def get_calibrator() -> ConfidenceCalibrator:
    return ConfidenceCalibrator()
