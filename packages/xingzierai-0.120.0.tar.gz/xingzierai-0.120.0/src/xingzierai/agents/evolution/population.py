#!/usr/bin/env python3 -*-
"""Population Evolution - multi-variant parallel evolution with Darwinian selection.

Inspired by Darwin Godel Machine (DGM, ICLR 2026, arXiv:2603.19461):
- Maintain a population of agent variants (Archive)
- Open-ended exploration from different starting points
- Fitness evaluation on benchmarks
- Darwinian selection: keep high-fitness, discard low-fitness
- Crossover: merge successful strategies from different variants
- Patch lineage tracking for full evolution history

Key insight from DGM: Open-ended exploration prevents premature convergence
and achieves SWE-bench 20%→50% improvement.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_ARCHIVE_DIR = Path.home() / ".xingzierai" / "evolution_archive"


class VariantStatus(str, Enum):
    ACTIVE = "active"
    EVALUATING = "evaluating"
    ARCHIVED = "archived"
    DEAD = "dead"


@dataclass
class FitnessScore:
    benchmark: str = ""
    score: float = 0.0
    evaluated_at: float = 0.0
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentVariant:
    """A single agent variant in the population."""
    variant_id: str = ""
    parent_id: Optional[str] = None
    generation: int = 0
    status: VariantStatus = VariantStatus.ACTIVE
    config: Dict[str, Any] = field(default_factory=dict)
    patches: List[str] = field(default_factory=list)
    fitness_scores: List[FitnessScore] = field(default_factory=list)
    created_at: float = 0.0
    last_evaluated: float = 0.0

    def __post_init__(self):
        if not self.variant_id:
            self.variant_id = uuid.uuid4().hex[:10]
        if self.created_at == 0.0:
            self.created_at = time.time()

    @property
    def avg_fitness(self) -> float:
        if not self.fitness_scores:
            return 0.0
        return sum(fs.score for fs in self.fitness_scores) / len(self.fitness_scores)

    def to_dict(self) -> Dict:
        return {
            "variant_id": self.variant_id,
            "parent_id": self.parent_id,
            "generation": self.generation,
            "status": self.status.value,
            "config": self.config,
            "patches": self.patches,
            "fitness_scores": [
                {"benchmark": fs.benchmark, "score": fs.score,
                 "evaluated_at": fs.evaluated_at, "details": fs.details}
                for fs in self.fitness_scores
            ],
            "avg_fitness": self.avg_fitness,
            "created_at": self.created_at,
            "last_evaluated": self.last_evaluated,
        }


@dataclass
class CrossoverResult:
    child_id: str = ""
    parent_a_id: str = ""
    parent_b_id: str = ""
    merged_patches: List[str] = field(default_factory=list)
    merged_config: Dict[str, Any] = field(default_factory=dict)


class EvolutionArchive:
    """Archive of all agent variants, forming a tree structure.

    Key insight from DGM: The archive preserves ALL variants (not just the best),
    enabling open-ended exploration from any historical point.
    """

    MAX_VARIANTS = 200

    def __init__(self, archive_dir: Optional[str] = None):
        self._dir = Path(archive_dir) if archive_dir else _ARCHIVE_DIR
        self._variants: Dict[str, AgentVariant] = {}
        self._load()

    def _load(self):
        self._dir.mkdir(parents=True, exist_ok=True)
        meta_path = self._dir / "archive.json"
        if meta_path.exists():
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
                for v_dict in data.get("variants", []):
                    variant = AgentVariant(
                        variant_id=v_dict["variant_id"],
                        parent_id=v_dict.get("parent_id"),
                        generation=v_dict.get("generation", 0),
                        status=VariantStatus(v_dict.get("status", "active")),
                        config=v_dict.get("config", {}),
                        patches=v_dict.get("patches", []),
                        created_at=v_dict.get("created_at", 0),
                        last_evaluated=v_dict.get("last_evaluated", 0),
                    )
                    for fs_dict in v_dict.get("fitness_scores", []):
                        variant.fitness_scores.append(FitnessScore(
                            benchmark=fs_dict.get("benchmark", ""),
                            score=fs_dict.get("score", 0),
                            evaluated_at=fs_dict.get("evaluated_at", 0),
                            details=fs_dict.get("details", {}),
                        ))
                    self._variants[variant.variant_id] = variant
            except Exception as e:
                logger.warning(f"EvolutionArchive: load error: {e}")

    def _save(self):
        meta_path = self._dir / "archive.json"
        data = {
            "variants": [v.to_dict() for v in self._variants.values()],
            "updated_at": time.time(),
        }
        tmp_path = meta_path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(str(tmp_path), str(meta_path))

    def add(self, variant: AgentVariant):
        self._variants[variant.variant_id] = variant
        if len(self._variants) > self.MAX_VARIANTS:
            dead = [v for v in self._variants.values() if v.status == VariantStatus.DEAD]
            dead.sort(key=lambda v: v.avg_fitness)
            for v in dead[:len(self._variants) - self.MAX_VARIANTS + 10]:
                del self._variants[v.variant_id]
        self._save()

    def get(self, variant_id: str) -> Optional[AgentVariant]:
        return self._variants.get(variant_id)

    def get_active(self) -> List[AgentVariant]:
        return [v for v in self._variants.values() if v.status == VariantStatus.ACTIVE]

    def get_best(self, n: int = 5) -> List[AgentVariant]:
        active = self.get_active()
        active.sort(key=lambda v: v.avg_fitness, reverse=True)
        return active[:n]

    def get_children(self, parent_id: str) -> List[AgentVariant]:
        return [v for v in self._variants.values() if v.parent_id == parent_id]

    def get_lineage(self, variant_id: str) -> List[AgentVariant]:
        lineage = []
        current = self._variants.get(variant_id)
        while current:
            lineage.append(current)
            if current.parent_id:
                current = self._variants.get(current.parent_id)
            else:
                break
        return lineage


class PopulationEvolution:
    """Population-based evolution engine.

    Manages a population of agent variants and evolves them using:
    1. Mutation: Modify a variant's config/patches
    2. Crossover: Merge successful strategies from two variants
    3. Selection: Keep high-fitness variants, discard low-fitness
    4. Exploration: Branch from different archive points
    """

    MAX_ACTIVE_VARIANTS = 5
    SELECTION_PRESSURE = 0.5

    def __init__(self, archive: Optional[EvolutionArchive] = None):
        self.archive = archive or EvolutionArchive()
        self._evaluate_fn: Optional[Callable] = None
        self._mutate_fn: Optional[Callable] = None

    def register_evaluator(self, fn: Callable):
        self._evaluate_fn = fn

    def register_mutator(self, fn: Callable):
        self._mutate_fn = fn

    async def evolve_one_generation(self) -> Dict[str, Any]:
        active = self.archive.get_active()

        if len(active) < self.MAX_ACTIVE_VARIANTS:
            seed = self.archive.get_best(1)
            if seed:
                new_variant = self._mutate(seed[0])
                self.archive.add(new_variant)
                active = self.archive.get_active()

        if self._evaluate_fn:
            for variant in active:
                if variant.status == VariantStatus.ACTIVE:
                    variant.status = VariantStatus.EVALUATING
                    try:
                        score = await self._evaluate_fn(variant)
                        variant.fitness_scores.append(FitnessScore(
                            benchmark="auto", score=score,
                            evaluated_at=time.time(),
                        ))
                        variant.last_evaluated = time.time()
                        variant.status = VariantStatus.ACTIVE
                    except Exception as e:
                        logger.error(f"PopulationEvolution: evaluate {variant.variant_id} error: {e}")
                        variant.status = VariantStatus.ACTIVE

        if len(active) >= 3:
            best = self.archive.get_best(2)
            if len(best) >= 2:
                child = self._crossover(best[0], best[1])
                self.archive.add(child)

        self._select()
        self.archive._save()

        return {
            "active_count": len(self.archive.get_active()),
            "best_fitness": self.archive.get_best(1)[0].avg_fitness if self.archive.get_best(1) else 0,
            "total_variants": len(self.archive._variants),
        }

    def _mutate(self, parent: AgentVariant) -> AgentVariant:
        new_config = dict(parent.config)
        if self._mutate_fn:
            new_config = self._mutate_fn(parent.config)

        return AgentVariant(
            parent_id=parent.variant_id,
            generation=parent.generation + 1,
            config=new_config,
            patches=list(parent.patches) + [f"mutation_{uuid.uuid4().hex[:6]}"],
        )

    def _crossover(self, parent_a: AgentVariant, parent_b: AgentVariant) -> AgentVariant:
        merged_config = {}
        for key in set(list(parent_a.config.keys()) + list(parent_b.config.keys())):
            if key in parent_a.config and key in parent_b.config:
                merged_config[key] = parent_a.config[key] if parent_a.avg_fitness >= parent_b.avg_fitness else parent_b.config[key]
            elif key in parent_a.config:
                merged_config[key] = parent_a.config[key]
            else:
                merged_config[key] = parent_b.config[key]

        return AgentVariant(
            parent_id=parent_a.variant_id,
            generation=max(parent_a.generation, parent_b.generation) + 1,
            config=merged_config,
            patches=list(set(parent_a.patches + parent_b.patches)),
        )

    def _select(self):
        active = self.archive.get_active()
        if len(active) <= self.MAX_ACTIVE_VARIANTS:
            return

        active.sort(key=lambda v: v.avg_fitness, reverse=True)
        survivors = active[:self.MAX_ACTIVE_VARIANTS]
        survivor_ids = {v.variant_id for v in survivors}

        for v in active:
            if v.variant_id not in survivor_ids:
                v.status = VariantStatus.DEAD
