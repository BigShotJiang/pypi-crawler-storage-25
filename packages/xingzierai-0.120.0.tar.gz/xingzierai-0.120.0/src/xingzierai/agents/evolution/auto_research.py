#!/usr/bin/env python3 -*-
"""Auto-Research - autonomous hypothesis-verification-learning loop.

Inspired by Karpathy's AutoResearch (2026.3, 20.9K GitHub Stars):
- Fixed time budget per experiment (5 minutes)
- Single metric (val_bpb) for fair comparison across architectures
- program.md paradigm: human writes strategy, agent writes code
- ~700 lines Python, 100 experiments/night

Key insight: Cheap verification is the foundation of autonomous loops.
The cheaper the verification, the faster the loop.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_RESEARCH_DIR = Path.home() / ".xingzierai" / "auto_research"


class ExperimentStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class Hypothesis:
    """A testable hypothesis for improvement."""
    id: str = ""
    description: str = ""
    rationale: str = ""
    expected_improvement: str = ""
    risk_level: str = "low"
    created_at: float = 0.0

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex[:8]
        if self.created_at == 0.0:
            self.created_at = time.time()


@dataclass
class Experiment:
    """A single experiment to test a hypothesis."""
    id: str = ""
    hypothesis_id: str = ""
    status: ExperimentStatus = ExperimentStatus.PENDING
    code_changes: str = ""
    metric_before: float = 0.0
    metric_after: float = 0.0
    metric_delta: float = 0.0
    duration_seconds: float = 0.0
    error: str = ""
    created_at: float = 0.0
    completed_at: float = 0.0

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex[:8]
        if self.created_at == 0.0:
            self.created_at = time.time()

    @property
    def is_improvement(self) -> bool:
        return self.metric_delta > 0


@dataclass
class ResearchProgram:
    """The research strategy document (program.md paradigm)."""
    goal: str = ""
    metric: str = "val_bpb"
    time_budget_minutes: int = 5
    max_experiments: int = 100
    constraints: List[str] = field(default_factory=list)
    strategies: List[str] = field(default_factory=list)


class AutoResearchEngine:
    """Autonomous research engine.

    Implements the hypothesis-verification-learning loop:
    1. Generate hypothesis from observations
    2. Design experiment to test hypothesis
    3. Execute experiment with time budget
    4. Evaluate results against metric
    5. Learn: if improvement, keep; if not, record why
    6. Generate new hypothesis from learnings
    """

    def __init__(self, program: Optional[ResearchProgram] = None):
        self.program = program or ResearchProgram()
        self._hypotheses: Dict[str, Hypothesis] = {}
        self._experiments: Dict[str, Experiment] = {}
        self._experiment_fn: Optional[Callable] = None
        self._evaluate_fn: Optional[Callable] = None
        self._hypothesis_fn: Optional[Callable] = None
        self._dir = _RESEARCH_DIR
        self._dir.mkdir(parents=True, exist_ok=True)

    def register_experiment_fn(self, fn: Callable):
        self._experiment_fn = fn

    def register_evaluate_fn(self, fn: Callable):
        self._evaluate_fn = fn

    def register_hypothesis_fn(self, fn: Callable):
        self._hypothesis_fn = fn

    async def run_cycle(self, max_experiments: int = 10) -> Dict[str, Any]:
        start = time.time()
        improvements = 0
        failures = 0

        for i in range(max_experiments):
            hypothesis = await self._generate_hypothesis()
            if hypothesis is None:
                break

            experiment = await self._run_experiment(hypothesis)
            if experiment is None:
                continue

            if experiment.is_improvement:
                improvements += 1
            else:
                failures += 1

            if time.time() - start > self.program.time_budget_minutes * 60:
                break

        return {
            "total_experiments": improvements + failures,
            "improvements": improvements,
            "failures": failures,
            "improvement_rate": improvements / max(improvements + failures, 1),
            "duration_seconds": time.time() - start,
        }

    async def _generate_hypothesis(self) -> Optional[Hypothesis]:
        if self._hypothesis_fn:
            try:
                h_data = await self._hypothesis_fn(self._get_context())
                if isinstance(h_data, dict):
                    h = Hypothesis(**{k: v for k, v in h_data.items() if k in Hypothesis.__dataclass_fields__})
                    self._hypotheses[h.id] = h
                    return h
            except Exception as e:
                logger.error(f"AutoResearch: hypothesis generation error: {e}")
        return None

    async def _run_experiment(self, hypothesis: Hypothesis) -> Optional[Experiment]:
        experiment = Experiment(hypothesis_id=hypothesis.id)

        if self._evaluate_fn:
            try:
                experiment.metric_before = await self._evaluate_fn()
            except Exception:
                experiment.metric_before = 0.0

        if self._experiment_fn:
            try:
                experiment.status = ExperimentStatus.RUNNING
                result = await asyncio.wait_for(
                    self._experiment_fn(hypothesis),
                    timeout=self.program.time_budget_minutes * 60,
                )
                experiment.code_changes = str(result)[:1000]
                experiment.status = ExperimentStatus.COMPLETED
            except asyncio.TimeoutError:
                experiment.status = ExperimentStatus.TIMEOUT
                experiment.error = "Experiment timed out"
            except Exception as e:
                experiment.status = ExperimentStatus.FAILED
                experiment.error = str(e)
        else:
            experiment.status = ExperimentStatus.COMPLETED

        if self._evaluate_fn and experiment.status == ExperimentStatus.COMPLETED:
            try:
                experiment.metric_after = await self._evaluate_fn()
                experiment.metric_delta = experiment.metric_after - experiment.metric_before
            except Exception:
                pass

        experiment.completed_at = time.time()
        experiment.duration_seconds = experiment.completed_at - experiment.created_at
        self._experiments[experiment.id] = experiment
        return experiment

    def _get_context(self) -> Dict[str, Any]:
        recent = sorted(self._experiments.values(), key=lambda e: e.created_at, reverse=True)[:10]
        return {
            "program": {
                "goal": self.program.goal,
                "metric": self.program.metric,
                "strategies": self.program.strategies,
            },
            "recent_experiments": [
                {"id": e.id, "delta": e.metric_delta, "status": e.status.value, "error": e.error}
                for e in recent
            ],
            "improvement_rate": sum(1 for e in self._experiments.values() if e.is_improvement) / max(len(self._experiments), 1),
        }

    def get_results(self) -> Dict[str, Any]:
        improvements = [e for e in self._experiments.values() if e.is_improvement]
        return {
            "total_experiments": len(self._experiments),
            "improvements": len(improvements),
            "improvement_rate": len(improvements) / max(len(self._experiments), 1),
            "best_delta": max((e.metric_delta for e in improvements), default=0),
            "hypotheses_generated": len(self._hypotheses),
        }
