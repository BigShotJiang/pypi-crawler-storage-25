# -*- coding: utf-8 -*-
"""Evolution Metrics Collector - Prometheus-compatible metrics for monitoring."""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class MetricPoint:
    name: str
    value: float
    timestamp: float = field(default_factory=time.time)
    labels: Dict[str, str] = field(default_factory=dict)


class MetricsCollector:
    MAX_POINTS = 10000
    FLUSH_INTERVAL = 60

    def __init__(self):
        self._counters: Dict[str, float] = defaultdict(float)
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, List[float]] = defaultdict(list)
        self._timeseries: Dict[str, List[MetricPoint]] = defaultdict(list)

    def increment(self, name: str, value: float = 1.0, labels: Optional[Dict[str, str]] = None) -> None:
        key = self._make_key(name, labels)
        self._counters[key] += value
        self._add_timeseries(name, self._counters[key], labels)

    def gauge(self, name: str, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        key = self._make_key(name, labels)
        self._gauges[key] = value
        self._add_timeseries(name, value, labels)

    def histogram(self, name: str, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        key = self._make_key(name, labels)
        self._histograms[key].append(value)
        if len(self._histograms[key]) > 1000:
            self._histograms[key] = self._histograms[key][-1000:]

    def timer(self, name: str, labels: Optional[Dict[str, str]] = None):
        start = time.time()
        class _Timer:
            def __init__(self, collector, n, l, s):
                self._collector = collector
                self._name = n
                self._labels = l
                self._start = s
            def __enter__(self):
                return self
            def __exit__(self, *args):
                elapsed = time.time() - self._start
                self._collector.histogram(self._name, elapsed, self._labels)
        return _Timer(self, name, labels, start)

    def get_counter(self, name: str, labels: Optional[Dict[str, str]] = None) -> float:
        return self._counters.get(self._make_key(name, labels), 0.0)

    def get_gauge(self, name: str, labels: Optional[Dict[str, str]] = None) -> Optional[float]:
        return self._gauges.get(self._make_key(name, labels))

    def get_histogram_stats(self, name: str, labels: Optional[Dict[str, str]] = None) -> Dict[str, float]:
        values = self._histograms.get(self._make_key(name, labels), [])
        if not values:
            return {"count": 0, "min": 0, "max": 0, "avg": 0, "p50": 0, "p95": 0, "p99": 0}
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "avg": sum(sorted_vals) / n,
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[int(n * 0.95)],
            "p99": sorted_vals[min(int(n * 0.99), n - 1)],
        }

    def get_all_metrics(self) -> Dict[str, Any]:
        return {
            "counters": dict(self._counters),
            "gauges": dict(self._gauges),
            "histograms": {k: self.get_histogram_stats_raw(k) for k in self._histograms},
            "timeseries_count": sum(len(v) for v in self._timeseries.values()),
        }

    def get_prometheus_format(self) -> str:
        lines = []
        for key, value in self._counters.items():
            name, labels = self._parse_key(key)
            labels_str = self._format_labels(labels) if labels else ""
            lines.append(f"# TYPE {name} counter")
            lines.append(f"{name}{labels_str} {value}")
        for key, value in self._gauges.items():
            name, labels = self._parse_key(key)
            labels_str = self._format_labels(labels) if labels else ""
            lines.append(f"# TYPE {name} gauge")
            lines.append(f"{name}{labels_str} {value}")
        return "\n".join(lines) + "\n"

    def _make_key(self, name: str, labels: Optional[Dict[str, str]] = None) -> str:
        if not labels:
            return name
        label_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"

    def _parse_key(self, key: str):
        if "{" not in key:
            return key, {}
        name = key[:key.index("{")]
        labels_str = key[key.index("{") + 1:key.index("}")]
        labels = {}
        for part in labels_str.split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                labels[k] = v
        return name, labels

    def _format_labels(self, labels: Dict[str, str]) -> str:
        return "{" + ",".join(f'{k}="{v}"' for k, v in sorted(labels.items())) + "}"

    def get_histogram_stats_raw(self, key: str) -> Dict[str, float]:
        values = self._histograms.get(key, [])
        if not values:
            return {"count": 0}
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "avg": sum(sorted_vals) / n,
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[int(n * 0.95)],
        }

    def _add_timeseries(self, name: str, value: float, labels: Optional[Dict[str, str]]) -> None:
        key = self._make_key(name, labels)
        self._timeseries[key].append(MetricPoint(name=name, value=value, labels=labels or {}))
        if len(self._timeseries[key]) > self.MAX_POINTS:
            self._timeseries[key] = self._timeseries[key][-self.MAX_POINTS:]


_metrics_instance: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    global _metrics_instance
    if _metrics_instance is None:
        _metrics_instance = MetricsCollector()
    return _metrics_instance
