# -*- coding: utf-8 -*-
"""Evolution Governor - 进化仲裁器.

Based on Yi Jing (《易经》) philosophy - the principle of Tai Ji (太极).
Controls which modules can be hot-patched vs which require review.

Core modules (核心模块) are protected - they require manual review.
Plugins and skills (插件与技能) can be hot-patched directly.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class PatchStrategy(str, Enum):
    HOT_PATCH = "hot_patch"
    REVIEW_REQUIRED = "review_required"
    REJECTED = "rejected"
    DEFERRED = "deferred"


class ModuleTier(str, Enum):
    CORE = "core"
    PLUGIN = "plugin"
    SKILL = "skill"
    UNKNOWN = "unknown"


@dataclass
class PatchRequest:
    file_path: str
    new_code: str
    target_module: Optional[str]
    task_id: Optional[str]
    strategy: PatchStrategy = PatchStrategy.HOT_PATCH
    tier: ModuleTier = ModuleTier.UNKNOWN
    reason: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ReviewRequest:
    request_id: str
    file_path: str
    new_code: str
    reason: str
    tier: ModuleTier
    created_at: str
    status: str = "pending"
    approved: bool = False
    approver: Optional[str] = None
    approved_at: Optional[str] = None


@dataclass
class GovernorMetrics:
    total_requests: int = 0
    hot_patches: int = 0
    review_requests: int = 0
    rejected: int = 0
    core_modules_protected: int = 0
    last_governance_time: Optional[str] = None


class EvolutionGovernor:
    """Evolution Governor - 进化仲裁器.

    Implements the Tai Ji principle of balance between:
    - Yin (阴): Protection of core systems (review required)
    - Yang (阳): Dynamic evolution of plugins/skills (hot patch)

    CORE_MODULES are protected and require review before modification.
    PLUGINS and SKILLS can be hot-patched directly.
    """

    CORE_MODULES: Set[str] = {
        "kernel",
        "router",
        "daemon",
        "memory",
        "model_router",
        "protocol",
        "evolution",
        "governor",
        "agent",
    }

    PROTECTED_PATTERNS: List[str] = [
        "agents/react_agent",
        "agents/model_factory",
        "core/model_router",
        "code_engine/daemon",
        "agents/evolution/engine",
        "agents/evolution/governor",
    ]

    SKILL_PATTERNS: List[str] = [
        "skills/",
        "plugins/",
        "tools/",
    ]

    def __init__(
        self,
        workspace_dir: Path,
        dev_env_dir: Optional[Path] = None,
        auto_create_dirs: bool = True,
    ):
        self.workspace_dir = workspace_dir
        self.dev_env_dir = dev_env_dir or (workspace_dir / "dev_env")
        self.patches_dir = self.dev_env_dir / "patches"
        self.reviews_dir = self.dev_env_dir / "reviews"
        self.profiles_dir = self.dev_env_dir / "profiles"

        if auto_create_dirs:
            self.patches_dir.mkdir(parents=True, exist_ok=True)
            self.reviews_dir.mkdir(parents=True, exist_ok=True)
            self.profiles_dir.mkdir(parents=True, exist_ok=True)

        self._metrics = GovernorMetrics()
        self._review_cache: Dict[str, ReviewRequest] = {}

    def classify_module(self, file_path: str) -> ModuleTier:
        """Classify the module tier based on file path.

        Args:
            file_path: Path to the module file

        Returns:
            ModuleTier classification
        """
        file_path_lower = file_path.lower()

        for pattern in self.PROTECTED_PATTERNS:
            if pattern.lower() in file_path_lower:
                return ModuleTier.CORE

        for pattern in self.SKILL_PATTERNS:
            if pattern.lower() in file_path_lower:
                return ModuleTier.SKILL

        filename = Path(file_path).name.lower()
        if filename.endswith("_core.py") or filename.startswith("kernel"):
            return ModuleTier.CORE

        if "plugin" in file_path_lower or "skill" in file_path_lower:
            return ModuleTier.PLUGIN

        return ModuleTier.UNKNOWN

    def determine_patch_strategy(
        self,
        file_path: str,
        task_id: Optional[str] = None,
        auto_approve: bool = False,
    ) -> PatchRequest:
        """Determine the appropriate patch strategy for a file.

        Args:
            file_path: Path to the file to be patched
            task_id: Optional task ID that triggered this patch
            auto_approve: If True, skip review for non-core modules

        Returns:
            PatchRequest with strategy determination
        """
        self._metrics.total_requests += 1
        self._metrics.last_governance_time = datetime.now().isoformat()

        tier = self.classify_module(file_path)
        request_id = f"req_{datetime.now().strftime('%Y%m%d%H%M%S')}_{hash(file_path) % 10000:04d}"

        if tier == ModuleTier.CORE:
            self._metrics.core_modules_protected += 1
            self._metrics.review_requests += 1

            review_request = ReviewRequest(
                request_id=request_id,
                file_path=file_path,
                new_code="",
                reason=f"Core module protection triggered",
                tier=tier,
                created_at=datetime.now().isoformat(),
            )
            self._create_review_request(review_request)

            return PatchRequest(
                file_path=file_path,
                new_code="",
                target_module=None,
                task_id=task_id,
                strategy=PatchStrategy.REVIEW_REQUIRED,
                tier=tier,
                reason=f"Core module requires review before modification",
            )

        if tier == ModuleTier.SKILL or tier == ModuleTier.PLUGIN:
            self._metrics.hot_patches += 1
            return PatchRequest(
                file_path=file_path,
                new_code="",
                target_module=None,
                task_id=task_id,
                strategy=PatchStrategy.HOT_PATCH,
                tier=tier,
                reason=f"{tier.value} module can be hot-patched",
            )

        if auto_approve:
            self._metrics.hot_patches += 1
            return PatchRequest(
                file_path=file_path,
                new_code="",
                target_module=None,
                task_id=task_id,
                strategy=PatchStrategy.HOT_PATCH,
                tier=tier,
                reason="Auto-approved non-core module",
            )

        self._metrics.review_requests += 1
        review_request = ReviewRequest(
            request_id=request_id,
            file_path=file_path,
            new_code="",
            reason=f"Unknown module tier requires review",
            tier=tier,
            created_at=datetime.now().isoformat(),
        )
        self._create_review_request(review_request)

        return PatchRequest(
            file_path=file_path,
            new_code="",
            target_module=None,
            task_id=task_id,
            strategy=PatchStrategy.REVIEW_REQUIRED,
            tier=tier,
            reason="Unknown module requires manual review",
        )

    def _create_review_request(self, review: ReviewRequest) -> None:
        """Create a review request file for core module modifications."""
        review_file = self.reviews_dir / f"{review.request_id}.json"

        review_data = {
            "request_id": review.request_id,
            "file_path": review.file_path,
            "new_code": review.new_code,
            "reason": review.reason,
            "tier": review.tier.value,
            "created_at": review.created_at,
            "status": review.status,
            "approved": review.approved,
            "approver": review.approver,
            "approved_at": review.approved_at,
        }

        atomic_write(
            review_file,
            json.dumps(review_data, indent=2, ensure_ascii=False),
        )

        self._review_cache[review.request_id] = review
        logger.info(f"Created review request: {review.request_id} for {review.file_path}")

    def save_patch_to_dev_env(
        self,
        file_path: str,
        new_code: str,
        task_id: Optional[str] = None,
    ) -> Path:
        """Save a core module patch to dev_env for review.

        Args:
            file_path: Path to the file
            new_code: New code content
            task_id: Optional task ID

        Returns:
            Path to the saved patch file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_filename = Path(file_path).name
        patch_filename = f"{timestamp}_{safe_filename}"
        patch_path = self.patches_dir / patch_filename

        patch_data = {
            "original_path": file_path,
            "patch_path": str(patch_path),
            "task_id": task_id,
            "created_at": datetime.now().isoformat(),
            "code": new_code,
            "status": "pending_review",
        }

        atomic_write(
            patch_path,
            json.dumps(patch_data, indent=2, ensure_ascii=False),
        )

        logger.info(f"Saved patch to dev_env: {patch_path}")
        return patch_path

    def approve_review_request(
        self,
        request_id: str,
        approver: str = "system",
    ) -> bool:
        """Approve a pending review request.

        Args:
            request_id: ID of the review request
            approver: Who approved (default: system)

        Returns:
            True if approved successfully
        """
        review_file = self.reviews_dir / f"{request_id}.json"

        if not review_file.exists():
            logger.warning(f"Review request not found: {request_id}")
            return False

        try:
            data = json.loads(review_file.read_text(encoding="utf-8"))
            data["status"] = "approved"
            data["approved"] = True
            data["approver"] = approver
            data["approved_at"] = datetime.now().isoformat()

            atomic_write(
                review_file,
                json.dumps(data, indent=2, ensure_ascii=False),
            )

            if request_id in self._review_cache:
                self._review_cache[request_id].approved = True
                self._review_cache[request_id].approver = approver
                self._review_cache[request_id].approved_at = data["approved_at"]

            logger.info(f"Approved review request: {request_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to approve review request: {e}")
            return False

    def reject_review_request(
        self,
        request_id: str,
        reason: str = "Rejected by governance",
    ) -> bool:
        """Reject a pending review request.

        Args:
            request_id: ID of the review request
            reason: Reason for rejection

        Returns:
            True if rejected successfully
        """
        review_file = self.reviews_dir / f"{request_id}.json"

        if not review_file.exists():
            return False

        try:
            data = json.loads(review_file.read_text(encoding="utf-8"))
            data["status"] = "rejected"
            data["rejection_reason"] = reason

            atomic_write(
                review_file,
                json.dumps(data, indent=2, ensure_ascii=False),
            )

            self._metrics.rejected += 1
            logger.info(f"Rejected review request: {request_id} - {reason}")
            return True

        except Exception as e:
            logger.error(f"Failed to reject review request: {e}")
            return False

    def get_pending_reviews(self) -> List[ReviewRequest]:
        """Get all pending review requests.

        Returns:
            List of pending ReviewRequest objects
        """
        pending = []

        for review_file in self.reviews_dir.glob("*.json"):
            try:
                data = json.loads(review_file.read_text(encoding="utf-8"))
                if data.get("status") == "pending":
                    pending.append(ReviewRequest(
                        request_id=data["request_id"],
                        file_path=data["file_path"],
                        new_code=data.get("new_code", ""),
                        reason=data.get("reason", ""),
                        tier=ModuleTier(data.get("tier", "unknown")),
                        created_at=data.get("created_at", ""),
                        status=data.get("status", "pending"),
                        approved=data.get("approved", False),
                        approver=data.get("approver"),
                        approved_at=data.get("approved_at"),
                    ))
            except Exception as _review_parse_err:
                logger.debug("Skipping malformed review file: %s", _review_parse_err)
                continue

        return sorted(pending, key=lambda x: x.created_at, reverse=True)

    def get_metrics(self) -> GovernorMetrics:
        return self._metrics

    def auto_apply_approved(self, engine: Any = None) -> List[Dict[str, Any]]:
        results = []
        approved = []
        for review_file in self.reviews_dir.glob("*.json"):
            try:
                data = json.loads(review_file.read_text(encoding="utf-8"))
                if data.get("status") == "approved" and data.get("applied") is not True:
                    approved.append((review_file, data))
            except Exception as _approved_parse_err:
                logger.debug("Skipping malformed approved review file: %s", _approved_parse_err)
                continue

        for review_file, data in approved:
            try:
                file_path = data.get("file_path", "")
                new_code = data.get("new_code", "")
                if not file_path or not new_code:
                    continue

                if engine:
                    from .engine import apply_patch
                    result = apply_patch(file_path, new_code)
                    data["applied"] = True
                    data["applied_at"] = datetime.now().isoformat()
                    data["apply_result"] = result.__dict__ if hasattr(result, "__dict__") else str(result)
                    atomic_write(
                        review_file,
                        json.dumps(data, indent=2, ensure_ascii=False),
                    )
                    results.append({
                        "request_id": data.get("request_id"),
                        "file_path": file_path,
                        "applied": True,
                    })
                else:
                    results.append({
                        "request_id": data.get("request_id"),
                        "file_path": file_path,
                        "applied": False,
                        "error": "No engine provided",
                    })
            except Exception as e:
                results.append({
                    "request_id": data.get("request_id"),
                    "applied": False,
                    "error": str(e),
                })

        return results

    def persist_metrics(self) -> None:
        try:
            metrics_file = self.workspace_dir / "governor_metrics.json"
            atomic_write(
                metrics_file,
                json.dumps({
                    "total_requests": self._metrics.total_requests,
                    "hot_patches": self._metrics.hot_patches,
                    "review_requests": self._metrics.review_requests,
                    "rejected": self._metrics.rejected,
                    "core_modules_protected": self._metrics.core_modules_protected,
                }, ensure_ascii=False, indent=2),
            )
        except Exception as e:
            logger.warning("Failed to persist governor metrics: %s", e)

    def load_metrics(self) -> None:
        try:
            metrics_file = self.workspace_dir / "governor_metrics.json"
            if metrics_file.exists():
                data = json.loads(metrics_file.read_text(encoding="utf-8"))
                self._metrics.total_requests = data.get("total_requests", 0)
                self._metrics.hot_patches = data.get("hot_patches", 0)
                self._metrics.review_requests = data.get("review_requests", 0)
                self._metrics.rejected = data.get("rejected", 0)
                self._metrics.core_modules_protected = data.get("core_modules_protected", 0)
        except Exception as e:
            logger.warning("Failed to load governor metrics: %s", e)

    def generate_tai_ji_report(self) -> Dict[str, Any]:
        """Generate a governance report following Tai Ji philosophy.

        Returns:
            Dict with yin/yang balance analysis
        """
        yin_count = self._metrics.core_modules_protected
        yang_count = self._metrics.hot_patches

        total = yin_count + yang_count if yin_count + yang_count > 0 else 1

        return {
            "timestamp": datetime.now().isoformat(),
            "philosophy": "Tai Ji (太极) - Balance of Protection and Evolution",
            "yin_analysis": {
                "core_modules_protected": yin_count,
                "review_requests": self._metrics.review_requests,
                "rejected": self._metrics.rejected,
                "balance": round(yin_count / total * 100, 1),
            },
            "yang_analysis": {
                "hot_patches": yang_count,
                "total_patches": self._metrics.total_requests,
                "balance": round(yang_count / total * 100, 1),
            },
            "total_requests": self._metrics.total_requests,
            "protection_ratio": f"{yin_count}:{yang_count}",
            "harmony_status": "Balanced" if 0.3 <= (yang_count / total) <= 0.7 else "Unbalanced",
        }


def create_governor(workspace_dir: Optional[Path] = None) -> EvolutionGovernor:
    """Factory function to create an EvolutionGovernor.

    Args:
        workspace_dir: Workspace directory (defaults to current directory)

    Returns:
        Configured EvolutionGovernor instance
    """
    workspace = workspace_dir or Path.cwd()
    return EvolutionGovernor(workspace_dir=workspace)
