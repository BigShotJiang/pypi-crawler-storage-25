# -*- coding: utf-8 -*-
"""Evolution Introspection - Self-reflection and meta-learning for the evolution system."""

from __future__ import annotations

from ._utils import atomic_write

import json
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ReflectionType(str, Enum):
    PATCH_EFFECTIVENESS = "patch_effectiveness"
    DISTILLATION_QUALITY = "distillation_quality"
    CALIBRATION_ACCURACY = "calibration_accuracy"
    SAFETY_POLICY_EFFECTIVENESS = "safety_policy_effectiveness"
    EVOLUTION_VELOCITY = "evolution_velocity"
    RESOURCE_EFFICIENCY = "resource_efficiency"


class InsightSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class Insight:
    insight_id: str
    reflection_type: ReflectionType
    severity: InsightSeverity
    title: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    recommendation: str = ""
    created_at: float = field(default_factory=time.time)
    acknowledged: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "insight_id": self.insight_id,
            "reflection_type": self.reflection_type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "evidence": self.evidence,
            "recommendation": self.recommendation,
            "created_at": self.created_at,
            "acknowledged": self.acknowledged,
        }


@dataclass
class EvolutionSnapshot:
    timestamp: float = field(default_factory=time.time)
    total_patches: int = 0
    successful_patches: int = 0
    rolled_back_patches: int = 0
    total_principles: int = 0
    validated_principles: int = 0
    avg_calibration_error: float = 0.0
    safety_violations: int = 0
    evolution_count_24h: int = 0
    avg_evolution_duration_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "total_patches": self.total_patches,
            "successful_patches": self.successful_patches,
            "rolled_back_patches": self.rolled_back_patches,
            "total_principles": self.total_principles,
            "validated_principles": self.validated_principles,
            "avg_calibration_error": self.avg_calibration_error,
            "safety_violations": self.safety_violations,
            "evolution_count_24h": self.evolution_count_24h,
            "avg_evolution_duration_ms": self.avg_evolution_duration_ms,
        }


class EvolutionIntrospector:
    MAX_SNAPSHOTS = 1440
    MAX_INSIGHTS = 100
    SNAPSHOT_INTERVAL = 60

    def __init__(self, storage_dir: Optional[str] = None):
        self._storage_dir = Path(storage_dir) if storage_dir else Path.home() / ".xingzierai" / "evolution_introspect"
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._snapshots: List[EvolutionSnapshot] = []
        self._insights: List[Insight] = []
        self._last_snapshot_time: float = 0
        self._insight_counter: int = 0
        self._load()

    def take_snapshot(self, metrics: Dict[str, Any]) -> EvolutionSnapshot:
        snapshot = EvolutionSnapshot(
            total_patches=metrics.get("total_patches", 0),
            successful_patches=metrics.get("successful_patches", 0),
            rolled_back_patches=metrics.get("rolled_back_patches", 0),
            total_principles=metrics.get("total_principles", 0),
            validated_principles=metrics.get("validated_principles", 0),
            avg_calibration_error=metrics.get("avg_calibration_error", 0.0),
            safety_violations=metrics.get("safety_violations", 0),
            evolution_count_24h=metrics.get("evolution_count_24h", 0),
            avg_evolution_duration_ms=metrics.get("avg_evolution_duration_ms", 0.0),
        )
        self._snapshots.append(snapshot)
        if len(self._snapshots) > self.MAX_SNAPSHOTS:
            self._snapshots = self._snapshots[-self.MAX_SNAPSHOTS:]
        self._last_snapshot_time = time.time()
        self._persist()
        return snapshot

    def reflect(self) -> List[Insight]:
        if len(self._snapshots) < 2:
            return []

        new_insights = []
        current = self._snapshots[-1]
        previous = self._snapshots[-2]

        patch_insights = self._reflect_on_patches(current, previous)
        new_insights.extend(patch_insights)

        distill_insights = self._reflect_on_distillation(current, previous)
        new_insights.extend(distill_insights)

        calibration_insights = self._reflect_on_calibration(current, previous)
        new_insights.extend(calibration_insights)

        safety_insights = self._reflect_on_safety(current, previous)
        new_insights.extend(safety_insights)

        velocity_insights = self._reflect_on_velocity(current, previous)
        new_insights.extend(velocity_insights)

        for insight in new_insights:
            self._insight_counter += 1

        for insight in new_insights:
            if self._is_duplicate(insight):
                continue
            self._insights.append(insight)
        if len(self._insights) > self.MAX_INSIGHTS:
            self._insights = self._insights[-self.MAX_INSIGHTS:]
        self._persist()

        return [i for i in new_insights if not self._is_duplicate(i)]

    def _is_duplicate(self, insight: Insight) -> bool:
        for existing in self._insights:
            if (existing.reflection_type == insight.reflection_type
                    and existing.title == insight.title
                    and not existing.acknowledged):
                return True
        return False

    def _reflect_on_patches(self, current: EvolutionSnapshot, previous: EvolutionSnapshot) -> List[Insight]:
        insights = []
        if current.total_patches > 0:
            rollback_rate = current.rolled_back_patches / current.total_patches
            if rollback_rate > 0.3:
                insights.append(Insight(
                    insight_id=f"ins_patch_{int(time.time() * 1000)}_{self._insight_counter}",
                    reflection_type=ReflectionType.PATCH_EFFECTIVENESS,
                    severity=InsightSeverity.WARNING,
                    title="High patch rollback rate",
                    description=f"Rollback rate is {rollback_rate:.1%}, indicating patches may be poorly validated before application",
                    evidence={"rollback_rate": rollback_rate, "total_patches": current.total_patches, "rolled_back": current.rolled_back_patches},
                    recommendation="Increase pre-application validation strictness; add more test coverage before applying patches",
                ))
        return insights

    def _reflect_on_distillation(self, current: EvolutionSnapshot, previous: EvolutionSnapshot) -> List[Insight]:
        insights = []
        if current.total_principles > 0:
            validation_rate = current.validated_principles / current.total_principles
            if validation_rate < 0.5:
                insights.append(Insight(
                    insight_id=f"ins_dist_{int(time.time() * 1000)}_{self._insight_counter}",
                    reflection_type=ReflectionType.DISTILLATION_QUALITY,
                    severity=InsightSeverity.INFO,
                    title="Low principle validation rate",
                    description=f"Only {validation_rate:.1%} of principles are validated. Many may be low quality.",
                    evidence={"validation_rate": validation_rate, "total": current.total_principles, "validated": current.validated_principles},
                    recommendation="Increase auto-validation threshold; add more outcome-based validation",
                ))
        return insights

    def _reflect_on_calibration(self, current: EvolutionSnapshot, previous: EvolutionSnapshot) -> List[Insight]:
        insights = []
        if current.avg_calibration_error > 0.2:
            insights.append(Insight(
                insight_id=f"ins_cal_{int(time.time() * 1000)}_{self._insight_counter}",
                reflection_type=ReflectionType.CALIBRATION_ACCURACY,
                severity=InsightSeverity.WARNING,
                title="High calibration error",
                description=f"Average calibration error is {current.avg_calibration_error:.3f}, agents may be significantly miscalibrated",
                evidence={"avg_error": current.avg_calibration_error},
                recommendation="Collect more calibration data; consider non-linear calibration methods",
            ))
        return insights

    def _reflect_on_safety(self, current: EvolutionSnapshot, previous: EvolutionSnapshot) -> List[Insight]:
        insights = []
        if current.safety_violations > previous.safety_violations + 3:
            insights.append(Insight(
                insight_id=f"ins_safe_{int(time.time() * 1000)}_{self._insight_counter}",
                reflection_type=ReflectionType.SAFETY_POLICY_EFFECTIVENESS,
                severity=InsightSeverity.CRITICAL,
                title="Increasing safety violations",
                description=f"Safety violations increased from {previous.safety_violations} to {current.safety_violations}",
                evidence={"previous": previous.safety_violations, "current": current.safety_violations},
                recommendation="Review and tighten safety policies; check for new attack vectors",
            ))
        return insights

    def _reflect_on_velocity(self, current: EvolutionSnapshot, previous: EvolutionSnapshot) -> List[Insight]:
        insights = []
        if current.evolution_count_24h < 2 and current.total_patches > 10:
            insights.append(Insight(
                insight_id=f"ins_vel_{int(time.time() * 1000)}_{self._insight_counter}",
                reflection_type=ReflectionType.EVOLUTION_VELOCITY,
                severity=InsightSeverity.INFO,
                title="Low evolution velocity",
                description=f"Only {current.evolution_count_24h} evolutions in last 24h despite having {current.total_patches} patches",
                evidence={"evolution_count_24h": current.evolution_count_24h, "total_patches": current.total_patches},
                recommendation="Check if evolution loop is stalled; verify trigger conditions are being met",
            ))
        return insights

    def get_insights(
        self,
        severity: Optional[InsightSeverity] = None,
        unacknowledged_only: bool = False,
        limit: int = 20,
    ) -> List[Insight]:
        insights = self._insights
        if severity:
            insights = [i for i in insights if i.severity == severity]
        if unacknowledged_only:
            insights = [i for i in insights if not i.acknowledged]
        return insights[-limit:]

    def acknowledge_insight(self, insight_id: str) -> bool:
        for insight in self._insights:
            if insight.insight_id == insight_id:
                insight.acknowledged = True
                return True
        return False

    def get_stats(self) -> Dict[str, Any]:
        by_severity: Dict[str, int] = defaultdict(int)
        by_type: Dict[str, int] = defaultdict(int)
        unacknowledged = 0
        for insight in self._insights:
            by_severity[insight.severity.value] += 1
            by_type[insight.reflection_type.value] += 1
            if not insight.acknowledged:
                unacknowledged += 1
        return {
            "total_insights": len(self._insights),
            "unacknowledged": unacknowledged,
            "snapshots_count": len(self._snapshots),
            "by_severity": dict(by_severity),
            "by_type": dict(by_type),
        }

    def _persist(self) -> None:
        try:
            snapshots_file = self._storage_dir / "snapshots.json"
            atomic_write(snapshots_file, json.dumps([s.to_dict() for s in self._snapshots], ensure_ascii=False))
            insights_file = self._storage_dir / "insights.json"
            atomic_write(insights_file, json.dumps([i.to_dict() for i in self._insights], ensure_ascii=False))
        except Exception as e:
            logger.warning("Failed to persist introspector data: %s", e)

    def _load(self) -> None:
        snapshots_file = self._storage_dir / "snapshots.json"
        if snapshots_file.exists():
            try:
                data = json.loads(snapshots_file.read_text(encoding="utf-8"))
                self._snapshots = []
                for item in data[-self.MAX_SNAPSHOTS:]:
                    self._snapshots.append(EvolutionSnapshot(
                        timestamp=item.get("timestamp", 0),
                        total_patches=item.get("total_patches", 0),
                        successful_patches=item.get("successful_patches", 0),
                        rolled_back_patches=item.get("rolled_back_patches", 0),
                        total_principles=item.get("total_principles", 0),
                        validated_principles=item.get("validated_principles", 0),
                        avg_calibration_error=item.get("avg_calibration_error", 0.0),
                        safety_violations=item.get("safety_violations", 0),
                        evolution_count_24h=item.get("evolution_count_24h", 0),
                        avg_evolution_duration_ms=item.get("avg_evolution_duration_ms", 0.0),
                    ))
            except Exception as e:
                logger.warning("Failed to load snapshots: %s", e)

        insights_file = self._storage_dir / "insights.json"
        if insights_file.exists():
            try:
                data = json.loads(insights_file.read_text(encoding="utf-8"))
                self._insights = []
                for item in data[-self.MAX_INSIGHTS:]:
                    self._insights.append(Insight(
                        insight_id=item.get("insight_id", ""),
                        reflection_type=ReflectionType(item.get("reflection_type", "patch_effectiveness")),
                        severity=InsightSeverity(item.get("severity", "info")),
                        title=item.get("title", ""),
                        description=item.get("description", ""),
                        evidence=item.get("evidence", {}),
                        recommendation=item.get("recommendation", ""),
                        created_at=item.get("created_at", 0),
                        acknowledged=item.get("acknowledged", False),
                    ))
            except Exception as e:
                logger.warning("Failed to load insights: %s", e)


_introspector_instance: Optional[EvolutionIntrospector] = None


def get_evolution_introspector() -> EvolutionIntrospector:
    global _introspector_instance
    if _introspector_instance is None:
        _introspector_instance = EvolutionIntrospector()
    return _introspector_instance
