# -*- coding: utf-8 -*-
"""Evolution Configuration Manager - Dynamic configuration for the evolution system."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path

from ._utils import atomic_write
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class EvolutionConfig:
    auto_evolution_enabled: bool = False
    min_evolution_interval_seconds: int = 300
    max_evolution_per_24h: int = 10
    safety_guard_level: str = "standard"
    calibration_sample_size: int = 100
    distillation_confidence_threshold: float = 0.6
    patch_max_risk_level: str = "medium"
    experience_pool_max_size: int = 500
    replay_buffer_max_size: int = 3000
    ab_test_min_sample_size: int = 30
    ab_test_confidence_threshold: float = 0.95
    pipeline_auto_run: bool = False
    pipeline_min_interval_seconds: int = 300
    signal_detection_enabled: bool = True
    introspection_enabled: bool = True
    coordinator_max_concurrent_tasks: int = 5
    rollback_cascade_max_depth: int = 3
    metrics_export_enabled: bool = True
    event_bus_enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvolutionConfig":
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)


class EvolutionConfigManager:
    CONFIG_FILENAME = "evolution_config.json"

    def __init__(self, config_dir: Optional[str] = None):
        self._config_dir = Path(config_dir) if config_dir else Path.home() / ".xingzierai" / "config"
        self._config_dir.mkdir(parents=True, exist_ok=True)
        self._config = EvolutionConfig()
        self._config_history: List[Dict[str, Any]] = []
        self._load()

    def get_config(self) -> EvolutionConfig:
        return self._config

    def update_config(self, updates: Dict[str, Any]) -> EvolutionConfig:
        old_config = self._config.to_dict()
        for key, value in updates.items():
            if hasattr(self._config, key):
                expected_type = type(getattr(self._config, key))
                if not isinstance(value, expected_type) and value is not None:
                    try:
                        value = expected_type(value)
                    except (ValueError, TypeError):
                        logger.warning("Invalid type for %s: expected %s, got %s", key, expected_type.__name__, type(value).__name__)
                        continue
                setattr(self._config, key, value)
            else:
                logger.warning("Unknown config key: %s", key)

        issues = self.validate_config()
        if issues:
            critical_keywords = ["should be >=", "must be", "Invalid"]
            critical_issues = [i for i in issues if any(kw in i for kw in critical_keywords)]
            if critical_issues:
                logger.error("Critical config validation issues, rolling back: %s", critical_issues)
                for key in updates:
                    if hasattr(self._config, key) and key in old_config:
                        setattr(self._config, key, old_config[key])
                return self._config
            logger.warning("Config validation issues: %s", issues)

        self._config_history.append({
            "timestamp": time.time(),
            "old": old_config,
            "new": updates,
        })
        if len(self._config_history) > 50:
            self._config_history = self._config_history[-50:]

        self._save()
        logger.info("Config updated: %s", list(updates.keys()))
        return self._config

    def reset_config(self) -> EvolutionConfig:
        self._config = EvolutionConfig()
        self._save()
        logger.info("Config reset to defaults")
        return self._config

    def get_config_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        return self._config_history[-limit:]

    def validate_config(self, config: Optional[EvolutionConfig] = None) -> List[str]:
        issues = []
        c = config or self._config

        if c.min_evolution_interval_seconds < 60:
            issues.append("min_evolution_interval_seconds should be >= 60")
        if c.max_evolution_per_24h > 50:
            issues.append("max_evolution_per_24h should be <= 50 for safety")
        if c.safety_guard_level not in ("permissive", "standard", "strict", "prohibited"):
            issues.append(f"Invalid safety_guard_level: {c.safety_guard_level}")
        if c.distillation_confidence_threshold < 0 or c.distillation_confidence_threshold > 1:
            issues.append("distillation_confidence_threshold must be between 0 and 1")
        if c.patch_max_risk_level not in ("low", "medium", "high", "critical"):
            issues.append(f"Invalid patch_max_risk_level: {c.patch_max_risk_level}")
        if c.ab_test_min_sample_size < 10:
            issues.append("ab_test_min_sample_size should be >= 10 for statistical significance")
        if c.rollback_cascade_max_depth > 10:
            issues.append("rollback_cascade_max_depth should be <= 10 to prevent excessive rollback")

        return issues

    def _save(self) -> None:
        try:
            filepath = self._config_dir / self.CONFIG_FILENAME
            atomic_write(
                filepath,
                json.dumps(self._config.to_dict(), indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.error("Failed to save config: %s", e)

    def _load(self) -> None:
        filepath = self._config_dir / self.CONFIG_FILENAME
        if not filepath.exists():
            return
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
            candidate = EvolutionConfig.from_dict(data)
            issues = self.validate_config(candidate)
            if issues:
                logger.warning("Loaded config has validation issues, using defaults: %s", issues)
            else:
                self._config = candidate
                logger.info("Loaded evolution config from %s", filepath)
        except Exception as e:
            logger.warning("Failed to load config, using defaults: %s", e)


_config_manager_instance: Optional[EvolutionConfigManager] = None


def get_evolution_config_manager() -> EvolutionConfigManager:
    global _config_manager_instance
    if _config_manager_instance is None:
        _config_manager_instance = EvolutionConfigManager()
    return _config_manager_instance
