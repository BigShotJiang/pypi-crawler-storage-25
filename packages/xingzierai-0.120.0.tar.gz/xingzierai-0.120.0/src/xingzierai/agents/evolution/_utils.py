# -*- coding: utf-8 -*-
"""Shared utilities for the evolution module."""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)


def atomic_write(path: Path, content: str) -> None:
    tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp_path, str(path))
    except Exception as _atomic_err:
        logger.debug("Atomic write failed for %s: %s", path, _atomic_err)
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
