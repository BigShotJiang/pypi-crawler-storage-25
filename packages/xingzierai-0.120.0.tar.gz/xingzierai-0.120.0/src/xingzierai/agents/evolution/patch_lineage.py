# -*- coding: utf-8 -*-
"""Patch Lineage Tracker - Track evolution genealogy inspired by DGM/HyperAgents.

Darwin Godel Machine (Sakana AI, 2025) key insight:
- Maintain an archive of ALL discovered agents as stepping stones
- Track patch lineage for audit and rollback
- Allow branching from diverse stepping stones

HyperAgents (Meta, 2026) key insight:
- "Patch lineage" tracking system maintains genealogical records
- Support rollback and improvement trajectory analysis

This module provides:
1. PatchLineageTracker: Track the genealogy of all code patches
2. PatchRecord: A single patch with full lineage metadata
3. LineageGraph: Navigate the patch ancestry tree
4. RollbackAdvisor: Suggest the best rollback point based on lineage
"""

import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class PatchStatus(str, Enum):
    PENDING = "pending"
    APPLIED = "applied"
    VALIDATED = "validated"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"
    SUPERSEDED = "superseded"


class PatchRisk(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class PatchRecord:
    id: str = field(default_factory=lambda: f"patch_{uuid.uuid4().hex[:8]}")
    parent_id: Optional[str] = None
    file_path: str = ""
    description: str = ""
    risk_level: PatchRisk = PatchRisk.MEDIUM
    status: PatchStatus = PatchStatus.PENDING
    diff_summary: str = ""
    lines_added: int = 0
    lines_removed: int = 0
    validation_score: float = 0.0
    applied_at: Optional[str] = None
    validated_at: Optional[str] = None
    rolled_back_at: Optional[str] = None
    rollback_reason: str = ""
    source: str = ""
    generation: int = 0
    child_ids: List[str] = field(default_factory=list)
    checkpoint_hash: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "parent_id": self.parent_id,
            "file_path": self.file_path,
            "description": self.description,
            "risk_level": self.risk_level.value,
            "status": self.status.value,
            "diff_summary": self.diff_summary,
            "lines_added": self.lines_added,
            "lines_removed": self.lines_removed,
            "validation_score": self.validation_score,
            "applied_at": self.applied_at,
            "validated_at": self.validated_at,
            "rolled_back_at": self.rolled_back_at,
            "rollback_reason": self.rollback_reason,
            "source": self.source,
            "generation": self.generation,
            "child_ids": self.child_ids,
            "checkpoint_hash": self.checkpoint_hash,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PatchRecord":
        data["risk_level"] = PatchRisk(data.get("risk_level", "medium"))
        data["status"] = PatchStatus(data.get("status", "pending"))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class LineageStats:
    total_patches: int = 0
    active_patches: int = 0
    rolled_back_patches: int = 0
    failed_patches: int = 0
    max_generation: int = 0
    avg_validation_score: float = 0.0
    rollback_rate: float = 0.0
    by_risk: Dict[str, int] = field(default_factory=dict)
    by_source: Dict[str, int] = field(default_factory=dict)
    by_file: Dict[str, int] = field(default_factory=dict)


class RollbackAdvisor:
    """Suggests the best rollback point based on lineage analysis."""

    def suggest_rollback_point(
        self,
        current_patch_id: str,
        patches: Dict[str, PatchRecord],
    ) -> Optional[PatchRecord]:
        current = patches.get(current_patch_id)
        if not current:
            return None

        ancestors = self._get_ancestors(current_patch_id, patches)
        if not ancestors:
            return None

        validated_ancestors = [
            a for a in ancestors
            if a.status == PatchStatus.VALIDATED and a.validation_score >= 0.7
        ]

        if validated_ancestors:
            return max(validated_ancestors, key=lambda a: a.validation_score)

        applied_ancestors = [
            a for a in ancestors
            if a.status == PatchStatus.APPLIED
        ]
        if applied_ancestors:
            return applied_ancestors[-1]

        return ancestors[-1] if ancestors else None

    def _get_ancestors(
        self,
        patch_id: str,
        patches: Dict[str, PatchRecord],
    ) -> List[PatchRecord]:
        ancestors = []
        current = patches.get(patch_id)
        visited: Set[str] = set()

        while current and current.parent_id and current.parent_id not in visited:
            visited.add(current.parent_id)
            parent = patches.get(current.parent_id)
            if parent:
                ancestors.append(parent)
                current = parent
            else:
                break

        return ancestors


class PatchLineageTracker:
    """Track the genealogy of all code patches for audit and rollback.

    Inspired by DGM's archive of all discovered agents and HyperAgents'
    patch lineage tracking system.

    Key features:
    - Track parent-child relationships between patches
    - Support branching from any point in the lineage
    - Calculate generation depth
    - Suggest optimal rollback points
    - Analyze improvement trajectories

    Usage:
        tracker = PatchLineageTracker()
        patch_id = tracker.record_patch(file_path="agents/react_agent.py", ...)
        tracker.mark_applied(patch_id, checkpoint_hash="abc123")
        tracker.mark_validated(patch_id, score=0.85)
        rollback_to = tracker.suggest_rollback(patch_id)
    """

    MAX_PATCHES = 5000

    def __init__(self, storage_dir: Optional[str] = None):
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "patch_lineage"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._patches: Dict[str, PatchRecord] = {}
        self._file_index: Dict[str, List[str]] = defaultdict(list)
        self._rollback_advisor = RollbackAdvisor()
        self._load()

    def record_patch(
        self,
        file_path: str,
        description: str = "",
        parent_id: Optional[str] = None,
        risk_level: PatchRisk = PatchRisk.MEDIUM,
        diff_summary: str = "",
        lines_added: int = 0,
        lines_removed: int = 0,
        source: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        generation = 0
        if parent_id and parent_id in self._patches:
            generation = self._patches[parent_id].generation + 1
            self._patches[parent_id].child_ids.append(None)  # placeholder

        patch = PatchRecord(
            file_path=file_path,
            description=description,
            parent_id=parent_id,
            risk_level=risk_level,
            diff_summary=diff_summary,
            lines_added=lines_added,
            lines_removed=lines_removed,
            source=source,
            generation=generation,
            metadata=metadata or {},
        )

        if parent_id and parent_id in self._patches:
            self._patches[parent_id].child_ids[-1] = patch.id

        self._patches[patch.id] = patch
        self._file_index[file_path].append(patch.id)
        self._persist(patch)

        self._enforce_max_patches()
        logger.info("Recorded patch %s for %s (gen=%d, risk=%s)",
                     patch.id, file_path, generation, risk_level.value)
        return patch.id

    def mark_applied(self, patch_id: str, checkpoint_hash: Optional[str] = None) -> bool:
        patch = self._patches.get(patch_id)
        if not patch:
            return False

        patch.status = PatchStatus.APPLIED
        patch.applied_at = datetime.now().isoformat()
        patch.checkpoint_hash = checkpoint_hash
        self._persist(patch)
        logger.info("Patch %s marked as applied (checkpoint=%s)", patch_id, checkpoint_hash)
        return True

    def mark_validated(self, patch_id: str, score: float = 1.0) -> bool:
        patch = self._patches.get(patch_id)
        if not patch:
            return False

        patch.status = PatchStatus.VALIDATED
        patch.validated_at = datetime.now().isoformat()
        patch.validation_score = score
        self._persist(patch)
        logger.info("Patch %s validated (score=%.2f)", patch_id, score)
        return True

    def mark_rolled_back(self, patch_id: str, reason: str = "") -> bool:
        patch = self._patches.get(patch_id)
        if not patch:
            return False

        patch.status = PatchStatus.ROLLED_BACK
        patch.rolled_back_at = datetime.now().isoformat()
        patch.rollback_reason = reason
        self._persist(patch)

        for child_id in patch.child_ids:
            child = self._patches.get(child_id)
            if child and child.status in (PatchStatus.APPLIED, PatchStatus.VALIDATED):
                self.mark_rolled_back(child_id, f"Parent {patch_id} rolled back: {reason}")

        logger.info("Patch %s rolled back: %s", patch_id, reason)
        return True

    def mark_failed(self, patch_id: str, reason: str = "") -> bool:
        patch = self._patches.get(patch_id)
        if not patch:
            return False

        patch.status = PatchStatus.FAILED
        patch.rollback_reason = reason
        self._persist(patch)
        logger.info("Patch %s failed: %s", patch_id, reason)
        return True

    def suggest_rollback(self, patch_id: str) -> Optional[PatchRecord]:
        return self._rollback_advisor.suggest_rollback_point(patch_id, self._patches)

    def get_lineage(self, patch_id: str) -> List[PatchRecord]:
        lineage = []
        current_id = patch_id
        visited: Set[str] = set()

        while current_id and current_id not in visited:
            visited.add(current_id)
            patch = self._patches.get(current_id)
            if not patch:
                break
            lineage.append(patch)
            current_id = patch.parent_id

        lineage.reverse()
        return lineage

    def get_branches(self, patch_id: str) -> Dict[str, List[PatchRecord]]:
        patch = self._patches.get(patch_id)
        if not patch:
            return {}

        branches: Dict[str, List[PatchRecord]] = {}
        for child_id in patch.child_ids:
            child = self._patches.get(child_id)
            if child:
                branch_name = f"{child.file_path}:{child.id}"
                branches[branch_name] = self._get_descendants(child_id)

        return branches

    def get_file_history(self, file_path: str) -> List[PatchRecord]:
        patch_ids = self._file_index.get(file_path, [])
        return [self._patches[pid] for pid in patch_ids if pid in self._patches]

    def get_latest_validated(self, file_path: str) -> Optional[PatchRecord]:
        history = self.get_file_history(file_path)
        validated = [p for p in history if p.status == PatchStatus.VALIDATED]
        return validated[-1] if validated else None

    def get_stats(self) -> LineageStats:
        total = len(self._patches)
        active = sum(1 for p in self._patches.values()
                     if p.status in (PatchStatus.APPLIED, PatchStatus.VALIDATED))
        rolled_back = sum(1 for p in self._patches.values()
                         if p.status == PatchStatus.ROLLED_BACK)
        failed = sum(1 for p in self._patches.values()
                    if p.status == PatchStatus.FAILED)

        by_risk: Dict[str, int] = defaultdict(int)
        by_source: Dict[str, int] = defaultdict(int)
        by_file: Dict[str, int] = defaultdict(int)

        for p in self._patches.values():
            by_risk[p.risk_level.value] += 1
            by_source[p.source] += 1
            by_file[p.file_path] += 1

        scores = [p.validation_score for p in self._patches.values()
                  if p.validation_score > 0]

        return LineageStats(
            total_patches=total,
            active_patches=active,
            rolled_back_patches=rolled_back,
            failed_patches=failed,
            max_generation=max((p.generation for p in self._patches.values()), default=0),
            avg_validation_score=sum(scores) / len(scores) if scores else 0.0,
            rollback_rate=rolled_back / max(total, 1),
            by_risk=dict(by_risk),
            by_source=dict(by_source),
            by_file=dict(by_file),
        )

    def analyze_improvement_trajectory(self, file_path: str) -> Dict[str, Any]:
        history = self.get_file_history(file_path)
        if not history:
            return {"file_path": file_path, "trajectory": "no_patches"}

        validated = [p for p in history if p.status == PatchStatus.VALIDATED]
        rolled_back = [p for p in history if p.status == PatchStatus.ROLLED_BACK]

        score_trend = [p.validation_score for p in validated if p.validation_score > 0]

        improving = len(score_trend) >= 2 and score_trend[-1] > score_trend[0]

        return {
            "file_path": file_path,
            "total_patches": len(history),
            "validated": len(validated),
            "rolled_back": len(rolled_back),
            "improving": improving,
            "score_trend": score_trend,
            "latest_score": score_trend[-1] if score_trend else None,
            "latest_patch": history[-1].id if history else None,
            "recommendation": self._trajectory_recommendation(history, validated, rolled_back),
        }

    def _trajectory_recommendation(
        self,
        history: List[PatchRecord],
        validated: List[PatchRecord],
        rolled_back: List[PatchRecord],
    ) -> str:
        if not validated:
            return "No validated patches yet. Continue with caution."

        if len(rolled_back) > len(validated):
            return "High rollback rate. Consider reviewing the approach or reducing risk."

        if len(validated) >= 3:
            latest_scores = [p.validation_score for p in validated[-3:]]
            if all(s >= 0.8 for s in latest_scores):
                return "Stable improvement trajectory. Safe to continue evolving."

        return "Moderate trajectory. Monitor validation scores closely."

    def _get_descendants(self, patch_id: str) -> List[PatchRecord]:
        descendants = []
        patch = self._patches.get(patch_id)
        if not patch:
            return descendants

        descendants.append(patch)
        for child_id in patch.child_ids:
            descendants.extend(self._get_descendants(child_id))

        return descendants

    def _enforce_max_patches(self) -> None:
        if len(self._patches) <= self.MAX_PATCHES:
            return

        deprecated = [p for p in self._patches.values()
                      if p.status in (PatchStatus.ROLLED_BACK, PatchStatus.FAILED)]
        deprecated.sort(key=lambda p: p.generation)

        to_remove = min(len(deprecated), len(self._patches) - self.MAX_PATCHES)
        for patch in deprecated[:to_remove]:
            self._patches.pop(patch.id, None)
            filepath = self._storage_dir / f"{patch.id}.json"
            if filepath.exists():
                filepath.unlink()

        logger.info("Enforced max patches %d, removed %d deprecated", self.MAX_PATCHES, to_remove)

    def _persist(self, patch: PatchRecord) -> None:
        try:
            filepath = self._storage_dir / f"{patch.id}.json"
            atomic_write(
                filepath,
                json.dumps(patch.to_dict(), indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning("Failed to persist patch %s: %s", patch.id, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return

        for filepath in self._storage_dir.glob("*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                patch = PatchRecord.from_dict(data)
                self._patches[patch.id] = patch
                self._file_index[patch.file_path].append(patch.id)
            except Exception as e:
                logger.warning("Failed to load patch %s: %s", filepath, e)

        logger.info("Loaded %d patch records", len(self._patches))


def get_lineage_tracker() -> PatchLineageTracker:
    return PatchLineageTracker()
