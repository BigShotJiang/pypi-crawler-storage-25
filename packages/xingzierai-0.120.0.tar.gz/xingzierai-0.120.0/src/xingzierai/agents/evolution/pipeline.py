# -*- coding: utf-8 -*-
"""Evolution Loop Automation - Fully automated evolution pipeline."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class PipelineStage(str, Enum):
    SIGNAL_COLLECTION = "signal_collection"
    ANALYSIS = "analysis"
    PLANNING = "planning"
    SAFETY_REVIEW = "safety_review"
    EXECUTION = "execution"
    VALIDATION = "validation"
    DEPLOYMENT = "deployment"
    MONITORING = "monitoring"


class PipelineStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class PipelineRun:
    run_id: str
    status: PipelineStatus = PipelineStatus.IDLE
    current_stage: PipelineStage = PipelineStage.SIGNAL_COLLECTION
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    stages_completed: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    result: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "status": self.status.value,
            "current_stage": self.current_stage.value,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "stages_completed": self.stages_completed,
            "errors": self.errors,
            "result": self.result,
        }


class EvolutionPipeline:
    MAX_RUNS = 50
    STAGE_ORDER = [
        PipelineStage.SIGNAL_COLLECTION,
        PipelineStage.ANALYSIS,
        PipelineStage.PLANNING,
        PipelineStage.SAFETY_REVIEW,
        PipelineStage.EXECUTION,
        PipelineStage.VALIDATION,
        PipelineStage.DEPLOYMENT,
        PipelineStage.MONITORING,
    ]

    def __init__(self):
        self._stage_handlers: Dict[PipelineStage, Callable] = {}
        self._runs: List[PipelineRun] = []
        self._current_run: Optional[PipelineRun] = None
        self._auto_run_enabled = False
        self._min_interval_seconds = 300
        self._last_run_time: float = 0

    def register_stage_handler(self, stage: PipelineStage, handler: Callable) -> None:
        self._stage_handlers[stage] = handler

    async def run_pipeline(self, force: bool = False) -> PipelineRun:
        now = time.time()
        if not force and (now - self._last_run_time) < self._min_interval_seconds:
            logger.info("Pipeline run skipped - minimum interval not reached")
            run = PipelineRun(run_id=f"skip_{int(now * 1000)}", status=PipelineStatus.IDLE)
            return run

        run = PipelineRun(
            run_id=f"pipeline_{int(now * 1000)}",
            status=PipelineStatus.RUNNING,
            started_at=now,
        )
        self._current_run = run

        for stage in self.STAGE_ORDER:
            run.current_stage = stage
            handler = self._stage_handlers.get(stage)

            if handler:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        stage_result = await handler(run)
                    else:
                        stage_result = handler(run)

                    run.stages_completed.append(stage.value)
                    if isinstance(stage_result, dict):
                        run.result.update(stage_result)

                except Exception as e:
                    error_msg = f"Stage {stage.value} failed: {str(e)}"
                    run.errors.append(error_msg)
                    logger.error("Pipeline stage %s failed: %s", stage.value, e)

                    if stage in (PipelineStage.SAFETY_REVIEW, PipelineStage.EXECUTION):
                        run.status = PipelineStatus.FAILED
                        break
            else:
                run.stages_completed.append(stage.value)

        if run.status == PipelineStatus.RUNNING:
            run.status = PipelineStatus.COMPLETED

        run.completed_at = time.time()
        self._last_run_time = time.time()
        self._runs.append(run)
        if len(self._runs) > self.MAX_RUNS:
            self._runs = self._runs[-self.MAX_RUNS:]
        self._current_run = None

        logger.info("Pipeline run %s completed: %s", run.run_id, run.status.value)
        return run

    def get_current_run(self) -> Optional[PipelineRun]:
        return self._current_run

    def get_run_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        return [r.to_dict() for r in self._runs[-limit:]]

    def get_stats(self) -> Dict[str, Any]:
        completed = sum(1 for r in self._runs if r.status == PipelineStatus.COMPLETED)
        failed = sum(1 for r in self._runs if r.status == PipelineStatus.FAILED)
        total_stages = sum(len(r.stages_completed) for r in self._runs)
        avg_duration = 0.0
        durations = [
            r.completed_at - r.started_at
            for r in self._runs
            if r.started_at and r.completed_at
        ]
        if durations:
            avg_duration = sum(durations) / len(durations)

        return {
            "total_runs": len(self._runs),
            "completed": completed,
            "failed": failed,
            "success_rate": completed / max(len(self._runs), 1),
            "avg_duration_seconds": round(avg_duration, 2),
            "total_stages_completed": total_stages,
            "auto_run_enabled": self._auto_run_enabled,
            "current_status": self._current_run.status.value if self._current_run else "idle",
        }

    def enable_auto_run(self, min_interval_seconds: int = 300) -> None:
        self._auto_run_enabled = True
        self._min_interval_seconds = min_interval_seconds
        logger.info("Auto-run enabled with interval %ds", min_interval_seconds)

    def disable_auto_run(self) -> None:
        self._auto_run_enabled = False
        logger.info("Auto-run disabled")


_pipeline_instance: Optional[EvolutionPipeline] = None


def get_evolution_pipeline() -> EvolutionPipeline:
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = EvolutionPipeline()
        _pipeline_instance.register_stage_handler(PipelineStage.SIGNAL_COLLECTION, _default_signal_collection)
        _pipeline_instance.register_stage_handler(PipelineStage.ANALYSIS, _default_analysis)
        _pipeline_instance.register_stage_handler(PipelineStage.SAFETY_REVIEW, _default_safety_review)
        _pipeline_instance.register_stage_handler(PipelineStage.VALIDATION, _default_validation)
        _pipeline_instance.register_stage_handler(PipelineStage.MONITORING, _default_monitoring)
    return _pipeline_instance


async def _default_signal_collection(run: PipelineRun) -> Dict[str, Any]:
    from .signal_detector import SignalDetector
    detector = SignalDetector()
    stats = detector.get_signal_stats()
    return {"signals": stats}


async def _default_analysis(run: PipelineRun) -> Dict[str, Any]:
    from .loop_monitor import get_evolution_monitor
    monitor = get_evolution_monitor()
    metrics = monitor.collect_metrics()
    return {"loop_health": metrics.loop_health.value if hasattr(metrics.loop_health, "value") else str(metrics.loop_health)}


async def _default_safety_review(run: PipelineRun) -> Dict[str, Any]:
    from .safety_guard import get_modification_guard
    guard = get_modification_guard()
    stats = guard.get_stats()
    return {"safety_guard": stats}


async def _default_validation(run: PipelineRun) -> Dict[str, Any]:
    return {"validation": "passed"}


async def _default_monitoring(run: PipelineRun) -> Dict[str, Any]:
    from .metrics import get_metrics_collector
    collector = get_metrics_collector()
    return {"metrics": collector.get_all_metrics()}
