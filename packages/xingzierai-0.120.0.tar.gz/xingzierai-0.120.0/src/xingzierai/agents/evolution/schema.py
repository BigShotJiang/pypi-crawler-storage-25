# -*- coding: utf-8 -*-
"""Evolution schema definitions."""

from dataclasses import dataclass, field
from typing import Optional, List
from enum import Enum
import json


class EvolutionAction(Enum):
    APPEND = "append"
    REPLACE = "replace"
    CREATE = "create"


@dataclass
class EvolutionChange:
    section: str
    action: EvolutionAction
    content: str
    relevant: bool = True


@dataclass
class EvolutionEntry:
    id: str
    source: str
    timestamp: str
    context: str
    change: dict
    applied: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "source": self.source,
            "timestamp": self.timestamp,
            "context": self.context,
            "change": self.change,
            "applied": self.applied,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "EvolutionEntry":
        change_data = data.get("change", {})
        if isinstance(change_data, dict):
            change = EvolutionChange(
                section=change_data.get("section", ""),
                action=EvolutionAction(change_data.get("action", "append")),
                content=change_data.get("content", ""),
                relevant=change_data.get("relevant", True),
            )
        else:
            change = EvolutionChange(
                section="",
                action=EvolutionAction.APPEND,
                content=str(change_data),
            )
        return cls(
            id=data.get("id", ""),
            source=data.get("source", ""),
            timestamp=data.get("timestamp", ""),
            context=data.get("context", ""),
            change=change.to_dict() if isinstance(change, EvolutionChange) else change_data,
            applied=data.get("applied", False),
        )


@dataclass
class EvolutionRecord:
    skill_id: str
    version: str = "1.0.0"
    updated_at: str = ""
    entries: List[EvolutionEntry] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "skill_id": self.skill_id,
            "version": self.version,
            "updated_at": self.updated_at,
            "entries": [e.to_dict() if isinstance(e, EvolutionEntry) else e for e in self.entries],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "EvolutionRecord":
        entries = [EvolutionEntry.from_dict(e) if isinstance(e, dict) else e for e in data.get("entries", [])]
        return cls(
            skill_id=data.get("skill_id", ""),
            version=data.get("version", "1.0.0"),
            updated_at=data.get("updated_at", ""),
            entries=entries,
        )

    def add_entry(self, entry: EvolutionEntry) -> None:
        self.entries.append(entry)
        from datetime import datetime, timezone
        self.updated_at = datetime.now(timezone.utc).isoformat()

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)

    @classmethod
    def from_json(cls, json_str: str) -> "EvolutionRecord":
        return cls.from_dict(json.loads(json_str))