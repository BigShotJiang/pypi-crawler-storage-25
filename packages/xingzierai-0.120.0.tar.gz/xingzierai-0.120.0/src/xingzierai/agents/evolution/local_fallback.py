# -*- coding: utf-8 -*-
"""Local Fallback Mixin - Local small model integration for error recovery."""

from __future__ import annotations

import ast
import asyncio
import builtins
import logging
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Type, TYPE_CHECKING

from xingzierai.agentscope_core.model import ChatModelBase

if TYPE_CHECKING:
    from xingzierai.utils.error_analyzer import ErrorAnalysis, ErrorCategory

logger = logging.getLogger(__name__)


class FallbackStatus(str, Enum):
    IDLE = "idle"
    ANALYZING = "analyzing"
    GENERATING_PATCH = "generating_patch"
    EXECUTING_PATCH = "executing_patch"
    FAILED = "failed"
    SUCCESS = "success"


@dataclass
class FallbackResult:
    success: bool
    status: FallbackStatus
    error_category: Optional[str] = None
    patch_script: Optional[str] = None
    execution_result: Optional[Any] = None
    error_message: Optional[str] = None
    used_local_model: bool = False
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class LocalFallbackConfig:
    enabled: bool = True
    ollama_base_url: str = "http://127.0.0.1:11434"
    fallback_model: str = "qwen2.5:1.5b"
    max_analysis_time: float = 10.0
    auto_execute_patches: bool = False
    require_approval: bool = True
    patch_storage_dir: str = "data/fallback_patches"


class LocalFallbackMixin:
    """Mixin that provides local small model fallback when cloud models fail.

    When the main model (Cloud Model) throws an error:
    1. Capture the exception and extract error details
    2. Call local small model with error logs and stack trace
    3. Small model outputs a fix script or degradation instruction
    4. System executes the fix (with optional approval)

    Features:
    - Integrates with existing LocalErrorAnalyzer
    - Supports Ollama backend for local inference
    - Generates Python fix scripts from error context
    - Sandboxed execution with rollback support
    - Falls back to rule-based fixes when model unavailable
    """

    def __init__(
        self,
        config: Optional[LocalFallbackConfig] = None,
        local_error_analyzer: Optional[Any] = None,
        evolution_engine: Optional[Any] = None,
        **kwargs,
    ):
        self._fallback_config = config or LocalFallbackConfig()
        self._error_analyzer = local_error_analyzer
        self._evolution_engine = evolution_engine
        self._status = FallbackStatus.IDLE
        self._patch_history: List[FallbackResult] = []
        self._pending_approvals: Dict[str, FallbackResult] = {}

    MAX_PATCH_HISTORY = 100
    MAX_PENDING_APPROVALS = 50
    PENDING_APPROVAL_TTL = 86400

    def _enforce_limits(self) -> None:
        if len(self._patch_history) > self.MAX_PATCH_HISTORY:
            self._patch_history = self._patch_history[-self.MAX_PATCH_HISTORY:]
        now = time.time()
        expired = [k for k, v in self._pending_approvals.items()
                   if now - getattr(v, "timestamp", 0) > self.PENDING_APPROVAL_TTL]
        for k in expired:
            del self._pending_approvals[k]
        if len(self._pending_approvals) > self.MAX_PENDING_APPROVALS:
            oldest = sorted(self._pending_approvals.items(),
                          key=lambda x: getattr(x[1], "timestamp", 0))[:len(self._pending_approvals) - self.MAX_PENDING_APPROVALS]
            for k, _ in oldest:
                del self._pending_approvals[k]

    @property
    def status(self) -> FallbackStatus:
        return self._status

    def is_retryable_error(self, error: Exception) -> bool:
        """Check if error should trigger local fallback."""
        if not self._fallback_config.enabled:
            return False

        error_str = str(error).lower()
        retryable_patterns = [
            "429",
            "rate limit",
            "timeout",
            "502",
            "503",
            "504",
            "connection",
            "network",
            "timeout",
        ]
        return any(p.lower() in error_str for p in retryable_patterns)

    async def handle_error_with_fallback(
        self,
        error: Exception,
        context: Optional[Dict[str, Any]] = None,
    ) -> FallbackResult:
        """Handle an error by analyzing with local model and generating fix.

        Args:
            error: The exception to handle
            context: Additional context (file path, module, etc.)

        Returns:
            FallbackResult with analysis and potential fix
        """
        if not self._fallback_config.enabled:
            return FallbackResult(
                success=False,
                status=FallbackStatus.FAILED,
                error_message="Fallback disabled",
            )

        self._status = FallbackStatus.ANALYZING
        error_info = self._extract_error_info(error, context)

        try:
            if self._error_analyzer:
                error_analysis = await self._error_analyzer.analyze_error(
                    error, context
                )
                error_info["analysis"] = error_analysis
                error_info["category"] = (
                    error_analysis.category.value
                    if hasattr(error_analysis, "category")
                    else "unknown"
                )

            if self._should_generate_patch(error_info):
                self._status = FallbackStatus.GENERATING_PATCH
                patch_result = await self._generate_fallback_patch(error_info)
                if patch_result:
                    return await self._execute_or_queue_patch(patch_result, error_info)

            self._status = FallbackStatus.IDLE
            return FallbackResult(
                success=False,
                status=FallbackStatus.IDLE,
                error_category=error_info.get("category"),
                error_message=str(error),
            )

        except Exception as e:
            logger.error(f"Fallback handling failed: {e}")
            self._status = FallbackStatus.FAILED
            return FallbackResult(
                success=False,
                status=FallbackStatus.FAILED,
                error_message=f"Fallback analysis failed: {e}",
            )

    def _extract_error_info(
        self,
        error: Exception,
        context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Extract structured information from an exception."""
        return {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
            "context": context or {},
            "timestamp": datetime.now().isoformat(),
        }

    def _should_generate_patch(self, error_info: Dict[str, Any]) -> bool:
        """Determine if a patch should be generated for this error."""
        category = error_info.get("category", "")

        patch_eligible = [
            "rate_limit",
            "timeout",
            "connection",
            "server_error",
            "invalid_request",
        ]
        return category in patch_eligible

    async def _generate_fallback_patch(
        self,
        error_info: Dict[str, Any],
    ) -> Optional[str]:
        """Generate a fallback patch script using local model.

        Returns Python code that can fix the issue, or None if generation failed.
        """
        if not self._is_local_model_available():
            logger.info("Local model not available, skipping patch generation")
            return None

        try:
            patch_prompt = self._build_patch_prompt(error_info)
            response = await self._call_local_model(patch_prompt)

            if response:
                script = self._extract_code_from_response(response)
                if script and self._validate_patch_script(script):
                    logger.info("Generated fallback patch script")
                    return script

        except Exception as e:
            logger.warning(f"Patch generation failed: {e}")

        return None

    def _is_local_model_available(self) -> bool:
        """Check if local Ollama model is available."""
        try:
            import ollama
            client = ollama.AsyncClient(
                host=self._fallback_config.ollama_base_url,
                timeout=3.0,
            )
            return True
        except ImportError:
            logger.debug("Ollama not installed")
            return False
        except Exception as _ollama_err:
            logger.debug("Ollama health check failed: %s", _ollama_err)
            return False

    def _build_patch_prompt(self, error_info: Dict[str, Any]) -> str:
        """Build a prompt for local model to generate fix script."""
        context = error_info.get("context", {})
        file_path = context.get("file_path", "unknown")
        module_name = context.get("module", "unknown")

        return f"""You are an AI code repair assistant. Generate a Python fix script for the following error.

ERROR TYPE: {error_info['type']}
ERROR MESSAGE: {error_info['message']}
FILE: {file_path}
MODULE: {module_name}

TIMESTAMP: {error_info['timestamp']}

Generate a Python script that:
1. Fixes or works around the error
2. Includes proper error handling
3. Can be executed safely

If this is a rate limit error, generate a decorator or wrapper that adds retry logic.
If this is a timeout error, generate code that increases timeout or uses streaming.
If this is a configuration error, generate the correct configuration.

Respond ONLY with valid Python code, no explanations or markdown.
Start with "# -*- coding: utf-8 -*-"
"""

    async def _call_local_model(self, prompt: str) -> Optional[str]:
        """Call local Ollama model for patch generation."""
        try:
            import ollama

            client = ollama.AsyncClient(
                host=self._fallback_config.ollama_base_url,
                timeout=self._fallback_config.max_analysis_time,
            )

            response = await client.chat(
                model=self._fallback_config.fallback_model,
                messages=[{"role": "user", "content": prompt}],
                options={
                    "temperature": 0.1,
                    "num_predict": 1000,
                },
            )

            if hasattr(response, "message"):
                return response.message.get("content", "")
            elif isinstance(response, dict):
                return response.get("message", {}).get("content", "")

        except Exception as e:
            logger.warning(f"Local model call failed: {e}")

        return None

    def _extract_code_from_response(self, response: str) -> Optional[str]:
        """Extract Python code from model response."""
        import re

        code_match = re.search(
            r"```python\s*([\s\S]*?)\s*```",
            response,
            re.MULTILINE,
        )
        if code_match:
            return code_match.group(1).strip()

        code_match = re.search(
            r"^(#.*\n)+[\s\S]*?(?=\n\n|\Z)",
            response,
            re.MULTILINE,
        )
        if code_match:
            return code_match.group(0).strip()

        if response.startswith("# -*-"):
            return response.strip()

        return None

    def _validate_patch_script(self, script: str) -> bool:
        """Validate that a patch script is safe to execute using AST analysis."""
        if not script or len(script) < 10:
            return False

        if len(script) > 10000:
            logger.warning("Patch script exceeds maximum length of 10000 characters")
            return False

        dangerous_names = {
            "os", "sys", "subprocess", "importlib", "imp",
            "eval", "exec", "compile", "open", "file",
            "shutil", "urllib", "requests", "socket",
            "__import__", "reload", "breakpoint",
        }

        try:
            tree = ast.parse(script, filename="<fallback_patch>")

            for node in ast.walk(tree):
                if isinstance(node, ast.Name):
                    if node.id in dangerous_names:
                        logger.warning(f"Patch script contains dangerous name: {node.id}")
                        return False
                elif isinstance(node, ast.Attribute):
                    if isinstance(node.value, ast.Name):
                        if node.value.id in dangerous_names:
                            logger.warning(f"Patch script contains dangerous attribute access: {node.value.id}.{node.attr}")
                            return False
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name) and node.func.id in dangerous_names:
                        logger.warning(f"Patch script contains dangerous call: {node.func.id}")
                        return False
                    if isinstance(node.func, ast.Attribute):
                        attr_name = node.func.attr
                        if attr_name in ("system", "popen", "spawn", "call", "run", "exec"):
                            logger.warning(f"Patch script contains dangerous method: {attr_name}")
                            return False

            return True
        except SyntaxError as e:
            logger.warning(f"Patch script has syntax error: {e}")
            return False
        except ValueError as e:
            if "source code" in str(e).lower():
                logger.warning(f"Patch script contains null bytes or encoding issues: {e}")
                return False
            raise

    def _create_safe_namespace(self, error_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create a sandboxed namespace for patch execution."""
        safe_builtins = {
            name: getattr(builtins, name)
            for name in dir(builtins)
            if not name.startswith('_')
        }
        safe_builtins = {k: v for k, v in safe_builtins.items() if callable(v) or k in ('True', 'False', 'None')}

        namespace = {
            "__name__": "fallback_patch",
            "__file__": error_info.get("context", {}).get("file_path", "unknown"),
            "__builtins__": safe_builtins,
            "dict": dict,
            "list": list,
            "tuple": tuple,
            "set": set,
            "str": str,
            "int": int,
            "float": float,
            "bool": bool,
            "len": len,
            "range": range,
            "enumerate": enumerate,
            "zip": zip,
            "map": map,
            "filter": filter,
            "sorted": sorted,
            "reversed": reversed,
            "any": any,
            "all": all,
            "min": min,
            "max": max,
            "abs": abs,
            "round": round,
            "isinstance": isinstance,
            "issubclass": issubclass,
            "hasattr": hasattr,
            "getattr": getattr,
            "setattr": setattr,
            "print": print,
        }
        return namespace

    async def _execute_or_queue_patch(
        self,
        patch_script: str,
        error_info: Dict[str, Any],
    ) -> FallbackResult:
        """Execute patch immediately or queue for approval."""
        result = FallbackResult(
            success=True,
            status=FallbackStatus.GENERATING_PATCH,
            patch_script=patch_script,
            used_local_model=self._is_local_model_available(),
        )

        if self._fallback_config.require_approval:
            patch_id = f"patch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            self._pending_approvals[patch_id] = result
            result.status = FallbackStatus.IDLE
            logger.info(f"Patch queued for approval: {patch_id}")
            return result

        return await self._execute_patch(patch_script, error_info)

    async def _execute_patch(
        self,
        patch_script: str,
        error_info: Dict[str, Any],
    ) -> FallbackResult:
        """Execute a patch script and return the result."""
        self._status = FallbackStatus.EXECUTING_PATCH

        try:
            if not self._validate_patch_script(patch_script):
                logger.warning("Patch script validation failed before execution")
                return FallbackResult(
                    success=False,
                    status=FallbackStatus.FAILED,
                    patch_script=patch_script,
                    error_message="Patch script validation failed",
                    used_local_model=self._is_local_model_available(),
                )

            namespace = self._create_safe_namespace(error_info)

            compiled = compile(patch_script, "<fallback_patch>", "exec", flags=0, dont_inherit=True)
            exec(compiled, namespace)

            result = FallbackResult(
                success=True,
                status=FallbackStatus.SUCCESS,
                patch_script=patch_script,
                execution_result={k: v for k, v in namespace.items() if not k.startswith('__')},
                used_local_model=self._is_local_model_available(),
            )
            self._patch_history.append(result)
            self._enforce_limits()
            self._status = FallbackStatus.IDLE
            logger.info("Patch executed successfully")
            return result

        except Exception as e:
            logger.error(f"Patch execution failed: {e}")
            self._status = FallbackStatus.FAILED
            result = FallbackResult(
                success=False,
                status=FallbackStatus.FAILED,
                patch_script=patch_script,
                error_message=f"Execution failed: {e}",
                used_local_model=self._is_local_model_available(),
            )
            self._patch_history.append(result)
            self._enforce_limits()
            return result

    async def approve_pending_patch(self, patch_id: str) -> FallbackResult:
        """Approve and execute a pending patch.

        Args:
            patch_id: ID of the patch to approve

        Returns:
            FallbackResult from patch execution
        """
        if patch_id not in self._pending_approvals:
            return FallbackResult(
                success=False,
                status=FallbackStatus.FAILED,
                error_message=f"Patch not found: {patch_id}",
            )

        result = self._pending_approvals.pop(patch_id)
        if result.patch_script:
            return await self._execute_patch(
                result.patch_script,
                {"context": {}},
            )
        return result

    def reject_pending_patch(self, patch_id: str) -> bool:
        """Reject a pending patch.

        Args:
            patch_id: ID of the patch to reject

        Returns:
            True if patch was found and rejected
        """
        if patch_id in self._pending_approvals:
            del self._pending_approvals[patch_id]
            logger.info(f"Patch rejected: {patch_id}")
            return True
        return False

    def get_pending_patches(self) -> List[Dict[str, Any]]:
        """Get list of pending patches awaiting approval."""
        return [
            {
                "id": patch_id,
                "script": result.patch_script,
                "timestamp": result.timestamp,
            }
            for patch_id, result in self._pending_approvals.items()
        ]

    def get_patch_history(self) -> List[FallbackResult]:
        """Get history of executed patches."""
        return self._patch_history.copy()

    def clear_patch_history(self) -> None:
        """Clear patch history."""
        self._patch_history.clear()


def create_local_fallback_mixin(
    ollama_base_url: str = "http://127.0.0.1:11434",
    fallback_model: str = "qwen2.5:1.5b",
    require_approval: bool = True,
) -> LocalFallbackMixin:
    """Factory function to create a LocalFallbackMixin.

    Args:
        ollama_base_url: URL of Ollama service
        fallback_model: Model to use for fallback
        require_approval: Whether to require approval before applying patches

    Returns:
        Configured LocalFallbackMixin instance
    """
    from xingzierai.utils.error_analyzer import get_error_analyzer

    config = LocalFallbackConfig(
        ollama_base_url=ollama_base_url,
        fallback_model=fallback_model,
        require_approval=require_approval,
    )

    return LocalFallbackMixin(
        config=config,
        local_error_analyzer=get_error_analyzer(),
    )
