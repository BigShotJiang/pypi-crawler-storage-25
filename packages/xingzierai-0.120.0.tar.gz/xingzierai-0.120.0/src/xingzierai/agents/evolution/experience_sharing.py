# -*- coding: utf-8 -*-
"""Experience Sharing Pool - Cross-agent experience sharing inspired by GEA.

GEA (Group-Evolving Agents, 2025) key insight:
- Treat a GROUP of agents as the fundamental evolutionary unit
- Enable explicit experience sharing and reuse within the group
- Overcome limitation of isolated evolutionary branches

This module provides:
1. ExperienceSharingPool: Global singleton pool for cross-agent experience sharing
2. SharedExperience: Experience record with source agent tracking
3. ExperienceFusion: Merge complementary experiences from different agents

The pool connects to KappaEngine but adds:
- Source agent tracking (which agent contributed this experience)
- Experience fusion (merge overlapping experiences from different agents)
- Popularity-based ranking (experiences used by more agents rank higher)
- Automatic deduplication (similar experiences are merged)
"""

import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional, Set, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class SharingScope(str, Enum):
    GLOBAL = "global"
    TEAM = "team"
    AGENT_PAIR = "agent_pair"


class FusionStrategy(str, Enum):
    MERGE = "merge"
    KEEP_BEST = "keep_best"
    UNION = "union"


@dataclass
class SharedExperience:
    id: str = field(default_factory=lambda: f"se_{uuid.uuid4().hex[:8]}")
    source_agent: str = ""
    category: str = ""
    trigger_conditions: List[str] = field(default_factory=list)
    solution: str = ""
    anti_patterns: List[str] = field(default_factory=list)
    confidence: float = 0.0
    success_count: int = 0
    failure_count: int = 0
    consumer_agents: Set[str] = field(default_factory=set)
    fusion_count: int = 0
    parent_ids: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "source_agent": self.source_agent,
            "category": self.category,
            "trigger_conditions": self.trigger_conditions,
            "solution": self.solution,
            "anti_patterns": self.anti_patterns,
            "confidence": self.confidence,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "consumer_agents": list(self.consumer_agents),
            "fusion_count": self.fusion_count,
            "parent_ids": self.parent_ids,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SharedExperience":
        data["consumer_agents"] = set(data.get("consumer_agents", []))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class FusionResult:
    merged_experience: Optional[SharedExperience] = None
    removed_ids: List[str] = field(default_factory=list)
    fusion_strategy: str = ""
    similarity: float = 0.0


class ExperienceSharingPool:
    """Global experience sharing pool for cross-agent knowledge transfer.

    Inspired by GEA's group-based evolution:
    - Agents share experiences through a common pool
    - Experiences from different agents can be fused
    - Popular experiences (used by many agents) rank higher
    - Deduplication prevents redundant experiences

    Usage:
        pool = ExperienceSharingPool()
        pool.publish(agent_name="react_agent", experience=pack)
        relevant = pool.query(agent_name="react_agent", task="deploy service")
    """

    MAX_POOL_SIZE = 2000
    SIMILARITY_THRESHOLD = 0.7

    _instance: Optional["ExperienceSharingPool"] = None
    _lock = Lock()

    def __new__(cls, storage_dir: Optional[str] = None):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, storage_dir: Optional[str] = None):
        if self._initialized:
            return

        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "experience_pool"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._pool: Dict[str, SharedExperience] = {}
        self._agent_index: Dict[str, Set[str]] = defaultdict(set)
        self._category_index: Dict[str, Set[str]] = defaultdict(set)
        self._load()
        self._initialized = True
        logger.info("ExperienceSharingPool initialized with %d experiences", len(self._pool))

    def publish(
        self,
        agent_name: str,
        experience: Any,
        scope: SharingScope = SharingScope.GLOBAL,
    ) -> SharedExperience:
        with self._lock:
            shared = self._convert_to_shared(agent_name, experience)

            similar = self._find_similar(shared)
            if similar and similar.similarity >= self.SIMILARITY_THRESHOLD:
                fusion = self._fuse(shared, similar.merged_experience, FusionStrategy.MERGE)
                if fusion.merged_experience:
                    for rid in fusion.removed_ids:
                        self._remove(rid)
                    self._pool[fusion.merged_experience.id] = fusion.merged_experience
                    self._update_indices(fusion.merged_experience)
                    self._persist(fusion.merged_experience)
                    logger.info(
                        "Fused experience from %s with existing %s (sim=%.2f)",
                        agent_name, fusion.merged_experience.id, similar.similarity,
                    )
                    return fusion.merged_experience

            self._pool[shared.id] = shared
            self._agent_index[agent_name].add(shared.id)
            self._category_index[shared.category].add(shared.id)
            self._persist(shared)

            self._enforce_max_size()
            logger.info("Published experience %s from agent %s", shared.id, agent_name)
            return shared

    def query(
        self,
        agent_name: str,
        task: str,
        category: Optional[str] = None,
        max_results: int = 5,
        exclude_own: bool = False,
    ) -> List[SharedExperience]:
        with self._lock:
            task_lower = task.lower()
            task_words = set(task_lower.split())

            scored: List[Tuple[SharedExperience, float]] = []
            for exp in self._pool.values():
                if exclude_own and exp.source_agent == agent_name:
                    continue
                if category and exp.category != category:
                    continue
                if exp.confidence < 0.2:
                    continue

                score = self._compute_relevance(exp, task_words, task_lower, agent_name)
                if score > 0:
                    scored.append((exp, score))

            scored.sort(key=lambda x: x[1], reverse=True)
            results = [exp for exp, _ in scored[:max_results]]

            for exp in results:
                exp.consumer_agents.add(agent_name)
                exp.updated_at = datetime.now().isoformat()

            return results

    def record_application(
        self,
        experience_id: str,
        agent_name: str,
        success: bool,
    ) -> None:
        with self._lock:
            exp = self._pool.get(experience_id)
            if not exp:
                return

            if success:
                exp.success_count += 1
            else:
                exp.failure_count += 1

            total = exp.success_count + exp.failure_count
            if total > 0:
                exp.confidence = exp.success_count / total

            exp.consumer_agents.add(agent_name)
            exp.updated_at = datetime.now().isoformat()
            self._persist(exp)

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            total = len(self._pool)
            by_category: Dict[str, int] = defaultdict(int)
            by_agent: Dict[str, int] = defaultdict(int)
            total_consumers = 0
            total_fusions = 0

            for exp in self._pool.values():
                by_category[exp.category] += 1
                by_agent[exp.source_agent] += 1
                total_consumers += len(exp.consumer_agents)
                total_fusions += exp.fusion_count

            return {
                "total_experiences": total,
                "by_category": dict(by_category),
                "by_agent": dict(by_agent),
                "total_consumer_connections": total_consumers,
                "total_fusions": total_fusions,
                "avg_confidence": sum(e.confidence for e in self._pool.values()) / max(total, 1),
                "pool_capacity": self.MAX_POOL_SIZE,
            }

    def _convert_to_shared(self, agent_name: str, experience: Any) -> SharedExperience:
        if isinstance(experience, SharedExperience):
            experience.source_agent = agent_name
            return experience

        trigger_conditions = []
        solution = ""
        anti_patterns = []
        category = ""
        confidence = 0.0
        exp_id = f"se_{uuid.uuid4().hex[:8]}"

        if hasattr(experience, "trigger_conditions"):
            trigger_conditions = list(experience.trigger_conditions)
        if hasattr(experience, "solution"):
            solution = experience.solution
        if hasattr(experience, "anti_patterns"):
            anti_patterns = list(experience.anti_patterns)
        if hasattr(experience, "category"):
            category = experience.category.value if hasattr(experience.category, "value") else str(experience.category)
        if hasattr(experience, "confidence"):
            confidence = experience.confidence
        if hasattr(experience, "id"):
            exp_id = f"se_{experience.id}"

        return SharedExperience(
            id=exp_id,
            source_agent=agent_name,
            category=category,
            trigger_conditions=trigger_conditions,
            solution=solution,
            anti_patterns=anti_patterns,
            confidence=confidence,
        )

    def _find_similar(self, exp: SharedExperience) -> Optional[FusionResult]:
        best: Optional[SharedExperience] = None
        best_sim = 0.0

        for existing in self._pool.values():
            if existing.source_agent == exp.source_agent:
                continue
            if existing.category != exp.category and existing.category and exp.category:
                continue

            sim = self._compute_similarity(exp, existing)
            if sim > best_sim:
                best_sim = sim
                best = existing

        if best and best_sim >= self.SIMILARITY_THRESHOLD:
            return FusionResult(
                merged_experience=best,
                similarity=best_sim,
            )
        return None

    def _compute_similarity(self, a: SharedExperience, b: SharedExperience) -> float:
        a_words = set()
        for cond in a.trigger_conditions:
            a_words.update(cond.lower().split())
        a_words.update(a.solution.lower().split())

        b_words = set()
        for cond in b.trigger_conditions:
            b_words.update(cond.lower().split())
        b_words.update(b.solution.lower().split())

        if not a_words or not b_words:
            return 0.0

        intersection = a_words & b_words
        union = a_words | b_words
        jaccard = len(intersection) / len(union)

        category_bonus = 0.1 if a.category == b.category and a.category else 0.0

        return min(jaccard + category_bonus, 1.0)

    def _fuse(
        self,
        new_exp: SharedExperience,
        existing: SharedExperience,
        strategy: FusionStrategy = FusionStrategy.MERGE,
    ) -> FusionResult:
        removed_ids = []

        if strategy == FusionStrategy.MERGE:
            merged_triggers = list(set(existing.trigger_conditions + new_exp.trigger_conditions))
            merged_anti = list(set(existing.anti_patterns + new_exp.anti_patterns))

            if len(new_exp.solution) > len(existing.solution) and new_exp.confidence >= existing.confidence:
                merged_solution = new_exp.solution
            else:
                merged_solution = existing.solution

            total_success = existing.success_count + new_exp.success_count
            total_failure = existing.failure_count + new_exp.failure_count
            total = total_success + total_failure
            merged_confidence = total_success / total if total > 0 else max(existing.confidence, new_exp.confidence)

            merged = SharedExperience(
                id=existing.id,
                source_agent=existing.source_agent,
                category=existing.category or new_exp.category,
                trigger_conditions=merged_triggers,
                solution=merged_solution,
                anti_patterns=merged_anti,
                confidence=merged_confidence,
                success_count=total_success,
                failure_count=total_failure,
                consumer_agents=existing.consumer_agents | new_exp.consumer_agents,
                fusion_count=existing.fusion_count + 1,
                parent_ids=existing.parent_ids + [new_exp.id],
                created_at=existing.created_at,
                updated_at=datetime.now().isoformat(),
                metadata={
                    **existing.metadata,
                    "fused_from": new_exp.source_agent,
                    "fusion_time": datetime.now().isoformat(),
                },
            )

            return FusionResult(
                merged_experience=merged,
                removed_ids=removed_ids,
                fusion_strategy=strategy.value,
                similarity=self._compute_similarity(new_exp, existing),
            )

        if strategy == FusionStrategy.KEEP_BEST:
            best = new_exp if new_exp.confidence >= existing.confidence else existing
            worst = existing if best is new_exp else new_exp
            best.consumer_agents = best.consumer_agents | worst.consumer_agents
            best.success_count += worst.success_count
            best.failure_count += worst.failure_count
            best.fusion_count += 1
            best.parent_ids.append(worst.id)
            best.updated_at = datetime.now().isoformat()
            return FusionResult(
                merged_experience=best,
                removed_ids=[worst.id],
                fusion_strategy=strategy.value,
                similarity=self._compute_similarity(new_exp, existing),
            )

        if strategy == FusionStrategy.UNION:
            all_triggers = list(set(existing.trigger_conditions + new_exp.trigger_conditions))
            all_anti = list(set(existing.anti_patterns + new_exp.anti_patterns))
            combined_solution = existing.solution
            if new_exp.solution not in combined_solution:
                combined_solution += "\n\n--- Alternative ---\n" + new_exp.solution
            total_success = existing.success_count + new_exp.success_count
            total_failure = existing.failure_count + new_exp.failure_count
            total = total_success + total_failure
            merged = SharedExperience(
                id=existing.id,
                source_agent=existing.source_agent,
                category=existing.category or new_exp.category,
                trigger_conditions=all_triggers,
                solution=combined_solution,
                anti_patterns=all_anti,
                confidence=total_success / total if total > 0 else max(existing.confidence, new_exp.confidence),
                success_count=total_success,
                failure_count=total_failure,
                consumer_agents=existing.consumer_agents | new_exp.consumer_agents,
                fusion_count=existing.fusion_count + 1,
                parent_ids=existing.parent_ids + [new_exp.id],
                created_at=existing.created_at,
                updated_at=datetime.now().isoformat(),
                metadata={**existing.metadata, "fused_from": new_exp.source_agent, "fusion_strategy": "union"},
            )
            return FusionResult(
                merged_experience=merged,
                removed_ids=[new_exp.id],
                fusion_strategy=strategy.value,
                similarity=self._compute_similarity(new_exp, existing),
            )

        return FusionResult(fusion_strategy=strategy.value)

    def _compute_relevance(
        self,
        exp: SharedExperience,
        task_words: Set[str],
        task_lower: str,
        agent_name: str,
    ) -> float:
        score = 0.0

        for cond in exp.trigger_conditions:
            cond_words = set(cond.lower().split())
            overlap = task_words & cond_words
            score += len(overlap) * 0.5

        for word in task_words:
            if word in exp.solution.lower():
                score += 0.3

        score += exp.confidence * 0.5

        consumer_count = len(exp.consumer_agents)
        if consumer_count > 0:
            score *= (1.0 + 0.1 * min(consumer_count, 10))

        if exp.source_agent != agent_name:
            score *= 1.2

        if exp.fusion_count > 0:
            score *= (1.0 + 0.05 * min(exp.fusion_count, 5))

        return score

    def _remove(self, exp_id: str) -> None:
        exp = self._pool.pop(exp_id, None)
        if exp:
            for agent, ids in self._agent_index.items():
                ids.discard(exp_id)
            self._category_index.get(exp.category, set()).discard(exp_id)
            filepath = self._storage_dir / f"{exp_id}.json"
            if filepath.exists():
                filepath.unlink()

    def _update_indices(self, exp: SharedExperience) -> None:
        self._agent_index[exp.source_agent].add(exp.id)
        if exp.category:
            self._category_index[exp.category].add(exp.id)

    def _enforce_max_size(self) -> None:
        if len(self._pool) <= self.MAX_POOL_SIZE:
            return

        sorted_exps = sorted(
            self._pool.values(),
            key=lambda e: (e.confidence * 0.4 + e.success_count * 0.3 + len(e.consumer_agents) * 0.3),
        )

        to_remove = len(self._pool) - self.MAX_POOL_SIZE
        for exp in sorted_exps[:to_remove]:
            self._remove(exp.id)

        logger.info("Enforced max pool size %d, removed %d", self.MAX_POOL_SIZE, to_remove)

    def _persist(self, exp: SharedExperience) -> None:
        try:
            filepath = self._storage_dir / f"{exp.id}.json"
            atomic_write(
                filepath,
                json.dumps(exp.to_dict(), indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning("Failed to persist shared experience %s: %s", exp.id, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return

        for filepath in self._storage_dir.glob("*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                exp = SharedExperience.from_dict(data)
                self._pool[exp.id] = exp
                self._update_indices(exp)
            except Exception as e:
                logger.warning("Failed to load shared experience %s: %s", filepath, e)


def get_sharing_pool() -> ExperienceSharingPool:
    return ExperienceSharingPool()
