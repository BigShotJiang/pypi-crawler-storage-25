# -*- coding: utf-8 -*-
"""Unified Evolution Storage - Pluggable storage backend for evolution data."""

from __future__ import annotations

import json
import logging
import shutil
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class StorageBackend(ABC):
    @abstractmethod
    def save(self, collection: str, key: str, data: Dict[str, Any]) -> bool:
        ...

    @abstractmethod
    def load(self, collection: str, key: str) -> Optional[Dict[str, Any]]:
        ...

    @abstractmethod
    def delete(self, collection: str, key: str) -> bool:
        ...

    @abstractmethod
    def list_keys(self, collection: str) -> List[str]:
        ...

    @abstractmethod
    def count(self, collection: str) -> int:
        ...


class JsonFileBackend(StorageBackend):
    def __init__(self, base_dir: str):
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)

    def _collection_dir(self, collection: str) -> Path:
        d = self._base_dir / collection
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _key_path(self, collection: str, key: str) -> Path:
        safe_key = key.replace("/", "_").replace("..", "_")
        return self._collection_dir(collection) / f"{safe_key}.json"

    def save(self, collection: str, key: str, data: Dict[str, Any]) -> bool:
        try:
            path = self._key_path(collection, key)
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(path)
            return True
        except Exception as e:
            logger.error("Failed to save %s/%s: %s", collection, key, e)
            return False

    def load(self, collection: str, key: str) -> Optional[Dict[str, Any]]:
        try:
            path = self._key_path(collection, key)
            if not path.exists():
                return None
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.error("Failed to load %s/%s: %s", collection, key, e)
            return None

    def delete(self, collection: str, key: str) -> bool:
        try:
            path = self._key_path(collection, key)
            if path.exists():
                path.unlink()
                return True
            return False
        except Exception as e:
            logger.error("Failed to delete %s/%s: %s", collection, key, e)
            return False

    def list_keys(self, collection: str) -> List[str]:
        d = self._collection_dir(collection)
        return [p.stem for p in d.glob("*.json")]

    def count(self, collection: str) -> int:
        return len(self.list_keys(collection))


class JsonlAppendBackend(StorageBackend):
    MAX_LINES = 5000

    def __init__(self, base_dir: str):
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)

    def _collection_path(self, collection: str) -> Path:
        safe = collection.replace("/", "_").replace("..", "_")
        return self._base_dir / f"{safe}.jsonl"

    def save(self, collection: str, key: str, data: Dict[str, Any]) -> bool:
        try:
            path = self._collection_path(collection)
            record = {"_key": key, **data}
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
            self._rotate(path)
            return True
        except Exception as e:
            logger.error("Failed to append %s/%s: %s", collection, key, e)
            return False

    def load(self, collection: str, key: str) -> Optional[Dict[str, Any]]:
        path = self._collection_path(collection)
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        if data.get("_key") == key:
                            data.pop("_key", None)
                            return data
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.error("Failed to load %s/%s: %s", collection, key, e)
        return None

    def delete(self, collection: str, key: str) -> bool:
        path = self._collection_path(collection)
        if not path.exists():
            return False
        try:
            lines = []
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        if data.get("_key") != key:
                            lines.append(line)
                    except json.JSONDecodeError:
                        lines.append(line)
            tmp = Path(str(path) + ".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                f.writelines(lines)
            tmp.replace(path)
            return True
        except Exception as e:
            logger.error("Failed to delete %s/%s: %s", collection, key, e)
            return False

    def list_keys(self, collection: str) -> List[str]:
        path = self._collection_path(collection)
        if not path.exists():
            return []
        keys = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        if "_key" in data:
                            keys.append(data["_key"])
                    except json.JSONDecodeError:
                        continue
        except Exception as _read_err:
            logger.debug("Failed to read collection %s: %s", collection, _read_err)
            pass
        return keys

    def count(self, collection: str) -> int:
        return len(self.list_keys(collection))

    def _rotate(self, path: Path) -> None:
        if not path.exists():
            return
        try:
            line_count = 0
            with open(path, "r", encoding="utf-8") as f:
                for _ in f:
                    line_count += 1
            if line_count > self.MAX_LINES:
                lines = []
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip():
                            lines.append(line)
                tmp = Path(str(path) + ".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    for line in lines[-self.MAX_LINES:]:
                        f.write(line)
                tmp.replace(path)
        except Exception as e:
            logger.warning("Failed to rotate %s: %s", path, e)


class EvolutionStorage:
    DEFAULT_BASE_DIR = str(Path.home() / ".xingzierai" / "evolution_storage")

    def __init__(self, backend: Optional[StorageBackend] = None, base_dir: Optional[str] = None):
        if backend:
            self._backend = backend
        else:
            self._backend = JsonFileBackend(base_dir or self.DEFAULT_BASE_DIR)

    def save(self, collection: str, key: str, data: Dict[str, Any]) -> bool:
        return self._backend.save(collection, key, data)

    def load(self, collection: str, key: str) -> Optional[Dict[str, Any]]:
        return self._backend.load(collection, key)

    def delete(self, collection: str, key: str) -> bool:
        return self._backend.delete(collection, key)

    def list_keys(self, collection: str) -> List[str]:
        return self._backend.list_keys(collection)

    def count(self, collection: str) -> int:
        return self._backend.count(collection)

    def save_many(self, collection: str, items: Dict[str, Dict[str, Any]]) -> int:
        saved = 0
        for key, data in items.items():
            if self.save(collection, key, data):
                saved += 1
        return saved

    def load_many(self, collection: str, keys: List[str]) -> Dict[str, Optional[Dict[str, Any]]]:
        return {key: self.load(collection, key) for key in keys}

    def get_stats(self) -> Dict[str, Any]:
        return {
            "backend_type": type(self._backend).__name__,
            "collections": {},
        }


_storage_instance: Optional[EvolutionStorage] = None


def get_evolution_storage(base_dir: Optional[str] = None) -> EvolutionStorage:
    global _storage_instance
    if _storage_instance is None:
        _storage_instance = EvolutionStorage(base_dir=base_dir)
    return _storage_instance
