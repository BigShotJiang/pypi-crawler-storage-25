# -*- coding: utf-8 -*-
"""Signal Detector - Monitors for error patterns, user corrections, and outcome signals."""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class SignalType(str, Enum):
    EXECUTION_FAILURE = "execution_failure"
    USER_CORRECTION = "user_correction"
    OUTCOME_DEGRADATION = "outcome_degradation"
    PERFORMANCE_REGRESSION = "performance_regression"
    SAFETY_VIOLATION = "safety_violation"
    PATTERN_ANOMALY = "pattern_anomaly"


class SignalSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class EvolutionSignal:
    signal_type: SignalType
    skill_name: str
    context: str
    raw_text: str
    timestamp: float = field(default_factory=time.time)
    severity: SignalSeverity = SignalSeverity.MEDIUM
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_type": self.signal_type.value,
            "skill_name": self.skill_name,
            "context": self.context[:500],
            "raw_text": self.raw_text[:500],
            "timestamp": self.timestamp,
            "severity": self.severity.value,
            "metadata": self.metadata,
        }


class SignalDetector:
    MAX_SIGNAL_HISTORY = 200

    FAILURE_KEYWORDS_EN = [
        "error", "exception", "failed", "failure", "timeout",
        "connection error", "econnrefused", "enoent",
        "permission denied", "command not found", "not found",
        "invalid", "refused", "timed out", "failed to",
        "could not", "unable to", "crashed", "segfault",
        "out of memory", "oom", "stack overflow",
    ]

    FAILURE_KEYWORDS_ZH = [
        "错误", "异常", "失败", "超时", "无法连接",
        "拒绝访问", "找不到", "无效", "内存不足", "崩溃",
        "无法", "不能", "未找到", "权限不足",
    ]

    CORRECTION_PATTERNS_EN = [
        r"(?i)(wrong|incorrect|not right)",
        r"(?i)(should be|ought to be|must be)",
        r"(?i)(actually|no,?\s*I)",
        r"(?i)(I meant|I wanted|I was trying)",
        r"(?i)(that'?s? not|never mind)",
        r"(?i)(different from|different than)",
        r"(?i)(not that|that'?s? it)",
    ]

    CORRECTION_PATTERNS_ZH = [
        r"不对|错了|不是这样",
        r"应该是|必须|需要",
        r"其实|实际上",
        r"我想说的是|我的意思是",
        r"不是那个|不对不对",
    ]

    NEGATIVE_SENTIMENT_ZH = [
        r"不好用|太难用|垃圾|废物",
        r"太慢|太卡|卡死|崩溃",
        r"什么破|什么烂|差劲",
    ]

    def __init__(self, persist_dir: Optional[str] = None):
        self._persist_dir = Path(persist_dir) if persist_dir else Path.home() / ".xingzierai" / "signals"
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._signal_history: List[EvolutionSignal] = []
        self._failure_pattern_en = re.compile(
            "|".join(rf"\b{kw}\b" for kw in self.FAILURE_KEYWORDS_EN),
            re.IGNORECASE,
        )
        self._failure_pattern_zh = re.compile(
            "|".join(self.FAILURE_KEYWORDS_ZH),
        )
        self._correction_patterns_en = [re.compile(p) for p in self.CORRECTION_PATTERNS_EN]
        self._correction_patterns_zh = [re.compile(p) for p in self.CORRECTION_PATTERNS_ZH]
        self._negative_patterns_zh = [re.compile(p) for p in self.NEGATIVE_SENTIMENT_ZH]
        self._load()

    def detect_failure(
        self,
        text: str,
        skill_name: str,
        context: str = "",
        severity: SignalSeverity = SignalSeverity.MEDIUM,
    ) -> Optional[EvolutionSignal]:
        if self._failure_pattern_en.search(text) or self._failure_pattern_zh.search(text):
            signal = EvolutionSignal(
                signal_type=SignalType.EXECUTION_FAILURE,
                skill_name=skill_name,
                context=context,
                raw_text=text,
                severity=severity,
            )
            self._record_signal(signal)
            return signal
        return None

    def detect_correction(
        self,
        text: str,
        skill_name: str,
        severity: SignalSeverity = SignalSeverity.LOW,
    ) -> Optional[EvolutionSignal]:
        for pattern in self._correction_patterns_en + self._correction_patterns_zh:
            if pattern.search(text):
                signal = EvolutionSignal(
                    signal_type=SignalType.USER_CORRECTION,
                    skill_name=skill_name,
                    context="",
                    raw_text=text,
                    severity=severity,
                )
                self._record_signal(signal)
                return signal
        return None

    def detect_from_tool_result(
        self,
        tool_name: str,
        result: str,
        skill_name: str,
    ) -> Optional[EvolutionSignal]:
        return self.detect_failure(result, skill_name, context=f"Tool: {tool_name}")

    def detect_from_user_message(
        self,
        message: str,
        skill_name: str,
    ) -> Optional[EvolutionSignal]:
        correction = self.detect_correction(message, skill_name)
        if correction:
            return correction
        for pattern in self._negative_patterns_zh:
            if pattern.search(message):
                signal = EvolutionSignal(
                    signal_type=SignalType.USER_CORRECTION,
                    skill_name=skill_name,
                    context="negative_sentiment",
                    raw_text=message,
                    severity=SignalSeverity.HIGH,
                )
                self._record_signal(signal)
                return signal
        return None

    def detect_from_outcome(
        self,
        skill_name: str,
        success_rate: float,
        previous_rate: float,
        threshold: float = 0.1,
    ) -> Optional[EvolutionSignal]:
        if previous_rate - success_rate > threshold:
            signal = EvolutionSignal(
                signal_type=SignalType.OUTCOME_DEGRADATION,
                skill_name=skill_name,
                context=f"success_rate dropped from {previous_rate:.2f} to {success_rate:.2f}",
                raw_text=f"Outcome degradation: {previous_rate:.2f} -> {success_rate:.2f}",
                severity=SignalSeverity.HIGH,
                metadata={"previous_rate": previous_rate, "current_rate": success_rate},
            )
            self._record_signal(signal)
            return signal
        return None

    def detect_performance_regression(
        self,
        skill_name: str,
        current_latency: float,
        baseline_latency: float,
        threshold_ratio: float = 2.0,
    ) -> Optional[EvolutionSignal]:
        if current_latency > baseline_latency * threshold_ratio:
            signal = EvolutionSignal(
                signal_type=SignalType.PERFORMANCE_REGRESSION,
                skill_name=skill_name,
                context=f"latency regressed from {baseline_latency:.0f}ms to {current_latency:.0f}ms",
                raw_text=f"Performance regression: {baseline_latency:.0f}ms -> {current_latency:.0f}ms",
                severity=SignalSeverity.MEDIUM,
                metadata={"baseline_ms": baseline_latency, "current_ms": current_latency},
            )
            self._record_signal(signal)
            return signal
        return None

    def get_recent_signals(
        self,
        skill_name: Optional[str] = None,
        signal_type: Optional[SignalType] = None,
        limit: int = 20,
    ) -> List[EvolutionSignal]:
        signals = self._signal_history
        if skill_name:
            signals = [s for s in signals if s.skill_name == skill_name]
        if signal_type:
            signals = [s for s in signals if s.signal_type == signal_type]
        return signals[-limit:]

    def get_signal_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = {}
        by_severity: Dict[str, int] = {}
        for signal in self._signal_history:
            by_type[signal.signal_type.value] = by_type.get(signal.signal_type.value, 0) + 1
            by_severity[signal.severity.value] = by_severity.get(signal.severity.value, 0) + 1
        return {
            "total_signals": len(self._signal_history),
            "by_type": by_type,
            "by_severity": by_severity,
        }

    def _record_signal(self, signal: EvolutionSignal) -> None:
        self._signal_history.append(signal)
        if len(self._signal_history) > self.MAX_SIGNAL_HISTORY:
            self._signal_history = self._signal_history[-self.MAX_SIGNAL_HISTORY:]
        self._persist_signal(signal)

    def _persist_signal(self, signal: EvolutionSignal) -> None:
        try:
            filepath = self._persist_dir / f"signal_{int(signal.timestamp * 1000)}.json"
            atomic_write(
                filepath,
                json.dumps(signal.to_dict(), ensure_ascii=False, indent=2),
            )
        except Exception as e:
            logger.warning("Failed to persist signal: %s", e)

    def _load(self) -> None:
        if not self._persist_dir.exists():
            return
        signals = []
        for filepath in sorted(self._persist_dir.glob("signal_*.json"))[-self.MAX_SIGNAL_HISTORY:]:
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                signals.append(EvolutionSignal(
                    signal_type=SignalType(data["signal_type"]),
                    skill_name=data["skill_name"],
                    context=data.get("context", ""),
                    raw_text=data.get("raw_text", ""),
                    timestamp=data.get("timestamp", 0),
                    severity=SignalSeverity(data.get("severity", "medium")),
                    metadata=data.get("metadata", {}),
                ))
            except Exception as _parse_err:
                logger.debug("Skipping malformed signal file: %s", _parse_err)
                continue
        self._signal_history = signals
        logger.info("Loaded %d signals from disk", len(signals))
