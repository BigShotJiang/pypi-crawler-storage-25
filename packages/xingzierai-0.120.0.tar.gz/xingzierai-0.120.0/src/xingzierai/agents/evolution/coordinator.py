# -*- coding: utf-8 -*-
"""Evolution Coordinator - Multi-agent evolution coordination via AgentBus."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class CoordinationStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EvolutionTaskType(str, Enum):
    PATCH_APPLICATION = "patch_application"
    DISTILLATION = "distillation"
    CALIBRATION = "calibration"
    BRIDGE_SYNC = "bridge_sync"
    SAFETY_REVIEW = "safety_review"
    A_B_TEST = "a_b_test"
    MEMORY_CONSOLIDATION = "memory_consolidation"


@dataclass
class EvolutionTask:
    task_id: str
    task_type: EvolutionTaskType
    description: str
    assigned_agent: str = ""
    status: CoordinationStatus = CoordinationStatus.PENDING
    priority: float = 0.5
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type.value,
            "description": self.description,
            "assigned_agent": self.assigned_agent,
            "status": self.status.value,
            "priority": self.priority,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "result": self.result,
            "dependencies": self.dependencies,
        }


@dataclass
class AgentCapability:
    agent_id: str
    supported_task_types: List[EvolutionTaskType] = field(default_factory=list)
    current_load: int = 0
    max_load: int = 5
    success_rate: float = 1.0
    avg_latency_ms: float = 0.0


AGENT_ROLE_TEMPLATES: Dict[str, Dict[str, Any]] = {
    "researcher": {
        "role": "researcher",
        "description": "Research and information gathering specialist",
        "supported_task_types": [EvolutionTaskType.SAFETY_REVIEW],
        "system_prompt_template": "You are a research specialist. Focus on gathering accurate information, analyzing data, and providing evidence-based insights.",
        "tools": ["web_search", "knowledge_search", "memory_search"],
        "max_load": 3,
    },
    "coder": {
        "role": "coder",
        "description": "Code generation and debugging specialist",
        "supported_task_types": [EvolutionTaskType.PATCH_APPLICATION],
        "system_prompt_template": "You are a coding specialist. Focus on writing clean, efficient code and debugging issues systematically.",
        "tools": ["code_execute", "file_read", "file_write"],
        "max_load": 5,
    },
    "analyst": {
        "role": "analyst",
        "description": "Data analysis and visualization specialist",
        "supported_task_types": [EvolutionTaskType.CALIBRATION, EvolutionTaskType.A_B_TEST],
        "system_prompt_template": "You are a data analyst. Focus on extracting insights from data and creating clear visualizations.",
        "tools": ["code_execute", "file_read", "web_search"],
        "max_load": 3,
    },
    "writer": {
        "role": "writer",
        "description": "Content creation and documentation specialist",
        "supported_task_types": [EvolutionTaskType.MEMORY_CONSOLIDATION],
        "system_prompt_template": "You are a writing specialist. Focus on creating clear, well-structured content.",
        "tools": ["file_read", "file_write", "memory_search"],
        "max_load": 5,
    },
    "coordinator": {
        "role": "coordinator",
        "description": "Task decomposition and multi-agent orchestration specialist",
        "supported_task_types": [EvolutionTaskType.BRIDGE_SYNC, EvolutionTaskType.DISTILLATION],
        "system_prompt_template": "You are a task coordinator. Focus on decomposing complex tasks and orchestrating multiple agents.",
        "tools": ["orchestrate", "memory_search", "memory_write"],
        "max_load": 3,
    },
}


def get_role_template(role: str) -> Optional[Dict[str, Any]]:
    return AGENT_ROLE_TEMPLATES.get(role)


def list_role_templates() -> List[Dict[str, Any]]:
    return list(AGENT_ROLE_TEMPLATES.values())


class EvolutionCoordinator:
    MAX_TASKS = 200
    MAX_HISTORY = 100
    MAX_AGENTS = 50
    TASK_TTL_SECONDS = 3600

    def __init__(self, storage_dir: Optional[str] = None):
        self._storage_dir = Path(storage_dir) if storage_dir else Path.home() / ".xingzierai" / "evolution_coord"
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._tasks: Dict[str, EvolutionTask] = {}
        self._completed_history: List[EvolutionTask] = []
        self._agents: Dict[str, AgentCapability] = {}
        self._task_handlers: Dict[EvolutionTaskType, Callable] = {}
        self._id_counter: int = 0

    def register_agent(self, capability: AgentCapability) -> None:
        self._agents[capability.agent_id] = capability
        if len(self._agents) > self.MAX_AGENTS:
            oldest_keys = list(self._agents.keys())[:len(self._agents) - self.MAX_AGENTS]
            for key in oldest_keys:
                self._agents.pop(key, None)
        logger.info("Registered agent %s with capabilities: %s", capability.agent_id, [t.value for t in capability.supported_task_types])

    def register_handler(self, task_type: EvolutionTaskType, handler: Callable) -> None:
        self._task_handlers[task_type] = handler

    def submit_task(
        self,
        task_type: EvolutionTaskType,
        description: str,
        priority: float = 0.5,
        dependencies: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> EvolutionTask:
        task_id = f"evotask_{int(time.time() * 1000)}_{self._id_counter}"
        self._id_counter += 1
        task = EvolutionTask(
            task_id=task_id,
            task_type=task_type,
            description=description,
            priority=priority,
            dependencies=dependencies or [],
            metadata=metadata or {},
        )
        self._tasks[task_id] = task
        self._enforce_max_tasks()
        logger.info("Submitted evolution task %s: %s", task_id, description)
        return task

    def assign_task(self, task_id: str) -> Optional[str]:
        task = self._tasks.get(task_id)
        if not task or task.status != CoordinationStatus.PENDING:
            return None

        for dep_id in task.dependencies:
            dep = self._tasks.get(dep_id)
            if dep and dep.status not in (CoordinationStatus.COMPLETED,):
                return None

        best_agent = self._find_best_agent(task.task_type)
        if best_agent:
            task.assigned_agent = best_agent
            task.status = CoordinationStatus.IN_PROGRESS
            task.started_at = time.time()
            self._agents[best_agent].current_load += 1
            return best_agent
        return None

    def _find_best_agent(self, task_type: EvolutionTaskType) -> Optional[str]:
        candidates = []
        for agent in self._agents.values():
            if task_type in agent.supported_task_types and agent.current_load < agent.max_load:
                score = agent.success_rate * 0.6 + (1 - agent.current_load / max(agent.max_load, 1)) * 0.4
                candidates.append((agent.agent_id, score))
        if not candidates:
            return None
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0]

    async def execute_task(self, task_id: str) -> Dict[str, Any]:
        task = self._tasks.get(task_id)
        if not task:
            return {"error": "Task not found"}

        handler = self._task_handlers.get(task.task_type)
        if not handler:
            task.status = CoordinationStatus.FAILED
            task.result = {"error": f"No handler for task type {task.task_type.value}"}
            return task.result

        try:
            if asyncio.iscoroutinefunction(handler):
                result = await handler(task)
            else:
                result = handler(task)

            task.status = CoordinationStatus.COMPLETED
            task.completed_at = time.time()
            task.result = result if isinstance(result, dict) else {"result": str(result)}

            if task.assigned_agent in self._agents:
                self._agents[task.assigned_agent].current_load = max(0, self._agents[task.assigned_agent].current_load - 1)
                self._agents[task.assigned_agent].success_rate = (
                    self._agents[task.assigned_agent].success_rate * 0.9 + 1.0 * 0.1
                )

        except Exception as e:
            task.status = CoordinationStatus.FAILED
            task.completed_at = time.time()
            task.result = {"error": str(e)}
            if task.assigned_agent in self._agents:
                self._agents[task.assigned_agent].current_load = max(0, self._agents[task.assigned_agent].current_load - 1)
                self._agents[task.assigned_agent].success_rate = (
                    self._agents[task.assigned_agent].success_rate * 0.9 + 0.0 * 0.1
                )
            logger.error("Task %s failed: %s", task_id, e)

        self._completed_history.append(task)
        if len(self._completed_history) > self.MAX_HISTORY:
            self._completed_history = self._completed_history[-self.MAX_HISTORY:]
        self._tasks.pop(task_id, None)

        return task.result

    def get_pending_tasks(self, task_type: Optional[EvolutionTaskType] = None) -> List[EvolutionTask]:
        tasks = [t for t in self._tasks.values() if t.status == CoordinationStatus.PENDING]
        if task_type:
            tasks = [t for t in tasks if t.task_type == task_type]
        return sorted(tasks, key=lambda t: t.priority, reverse=True)

    def get_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = defaultdict(int)
        by_status: Dict[str, int] = defaultdict(int)
        for task in list(self._tasks.values()) + self._completed_history:
            by_type[task.task_type.value] += 1
            by_status[task.status.value] += 1
        return {
            "active_tasks": len(self._tasks),
            "completed_tasks": len(self._completed_history),
            "registered_agents": len(self._agents),
            "by_type": dict(by_type),
            "by_status": dict(by_status),
        }

    def _enforce_max_tasks(self) -> None:
        if len(self._tasks) <= self.MAX_TASKS:
            return
        now = time.time()
        stale_ids = [
            tid for tid, t in self._tasks.items()
            if t.status in (CoordinationStatus.COMPLETED, CoordinationStatus.CANCELLED)
            or (now - t.created_at > self.TASK_TTL_SECONDS)
        ]
        for tid in stale_ids[:len(self._tasks) - self.MAX_TASKS]:
            self._tasks.pop(tid, None)


_coordinator_instance: Optional[EvolutionCoordinator] = None


def get_evolution_coordinator() -> EvolutionCoordinator:
    global _coordinator_instance
    if _coordinator_instance is None:
        _coordinator_instance = EvolutionCoordinator()
    return _coordinator_instance
