# -*- coding: utf-8 -*-
"""Agent Population - Darwinian evolution with population diversity (inspired by Meta HyperAgents).

Maintains a population of agent variants, applies selection pressure,
allows successful traits to cross-fuse, and tracks genealogy for rollback.
"""

from __future__ import annotations

import json
import logging
import random
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class VariantStatus(str, Enum):
    ACTIVE = "active"
    EVALUATING = "evaluating"
    DEPRECATED = "deprecated"
    FAILED = "failed"


class SelectionPressure(str, Enum):
    FITNESS_PROPORTIONATE = "fitness_proportionate"
    TOURNAMENT = "tournament"
    RANK_BASED = "rank_based"
    RANDOM = "random"


@dataclass
class AgentVariant:
    variant_id: str
    generation: int = 0
    parent_ids: List[str] = field(default_factory=list)
    status: VariantStatus = VariantStatus.ACTIVE
    fitness_score: float = 0.5
    task_successes: int = 0
    task_failures: int = 0
    total_latency_ms: float = 0.0
    config: Dict[str, Any] = field(default_factory=dict)
    traits: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    last_evaluated_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        total = self.task_successes + self.task_failures
        return self.task_successes / max(total, 1)

    @property
    def avg_latency_ms(self) -> float:
        total = self.task_successes + self.task_failures
        return self.total_latency_ms / max(total, 1)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "variant_id": self.variant_id,
            "generation": self.generation,
            "parent_ids": self.parent_ids,
            "status": self.status.value,
            "fitness_score": round(self.fitness_score, 4),
            "task_successes": self.task_successes,
            "task_failures": self.task_failures,
            "success_rate": round(self.success_rate, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "config": self.config,
            "traits": self.traits,
            "created_at": self.created_at,
            "last_evaluated_at": self.last_evaluated_at,
        }


@dataclass
class CrossFusionResult:
    child_id: str
    parent_ids: List[str]
    inherited_traits: Dict[str, Any]
    mutation_traits: Dict[str, Any]
    generation: int


class AgentPopulation:
    MAX_POPULATION = 20
    MAX_GENERATIONS = 50
    MUTATION_RATE = 0.15
    CROSSOVER_RATE = 0.3
    ELITISM_COUNT = 2
    FITNESS_DECAY = 0.95

    def __init__(self, storage_dir: Optional[str] = None):
        self._storage_dir = Path(storage_dir) if storage_dir else Path.home() / ".xingzierai" / "agent_population"
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._population: Dict[str, AgentVariant] = {}
        self._current_generation: int = 0
        self._selection_method = SelectionPressure.TOURNAMENT
        self._tournament_size = 3
        self._id_counter: int = 0
        self._load()

    def seed_population(self, base_config: Dict[str, Any], count: int = 5) -> List[AgentVariant]:
        variants = []
        for i in range(count):
            variant_id = f"variant_gen0_{i}"
            traits = self._generate_random_traits()
            variant = AgentVariant(
                variant_id=variant_id,
                generation=0,
                config=base_config,
                traits=traits,
            )
            self._population[variant_id] = variant
            variants.append(variant)
            self._persist_variant(variant)
        logger.info("Seeded population with %d variants", count)
        return variants

    def record_task_result(
        self,
        variant_id: str,
        success: bool,
        latency_ms: float = 0.0,
        quality_score: float = 0.0,
    ) -> None:
        variant = self._population.get(variant_id)
        if not variant:
            return
        if success:
            variant.task_successes += 1
        else:
            variant.task_failures += 1
        variant.total_latency_ms += latency_ms
        variant.last_evaluated_at = time.time()

        variant.fitness_score = self._compute_fitness(variant, quality_score)
        self._persist_variant(variant)

    def _compute_fitness(self, variant: AgentVariant, quality_bonus: float = 0.0) -> float:
        success_component = variant.success_rate * 0.5
        latency_component = 0.0
        if variant.avg_latency_ms > 0:
            latency_component = max(0, 1.0 - variant.avg_latency_ms / 10000.0) * 0.2
        quality_component = quality_bonus * 0.3
        return min(1.0, success_component + latency_component + quality_component)

    def select_variant(self) -> Optional[AgentVariant]:
        active = [v for v in self._population.values() if v.status == VariantStatus.ACTIVE]
        if not active:
            return None

        if self._selection_method == SelectionPressure.TOURNAMENT:
            candidates = random.sample(active, min(self._tournament_size, len(active)))
            return max(candidates, key=lambda v: v.fitness_score)
        elif self._selection_method == SelectionPressure.FITNESS_PROPORTIONATE:
            total_fitness = sum(v.fitness_score for v in active)
            if total_fitness == 0:
                return random.choice(active)
            r = random.random() * total_fitness
            cumulative = 0.0
            for v in active:
                cumulative += v.fitness_score
                if cumulative >= r:
                    return v
            return active[-1]
        elif self._selection_method == SelectionPressure.RANK_BASED:
            sorted_variants = sorted(active, key=lambda v: v.fitness_score)
            n = len(sorted_variants)
            weights = [(i + 1) / (n * (n + 1) / 2) for i in range(n)]
            return random.choices(sorted_variants, weights=weights, k=1)[0]
        else:
            return random.choice(active)

    def evolve_generation(self) -> List[AgentVariant]:
        active = [v for v in self._population.values() if v.status == VariantStatus.ACTIVE]
        if len(active) < 2:
            logger.warning("Not enough active variants for evolution")
            return []

        self._current_generation += 1
        if self._current_generation > self.MAX_GENERATIONS:
            logger.info("Max generations reached")
            return []

        new_variants = []

        sorted_active = sorted(active, key=lambda v: v.fitness_score, reverse=True)
        for i in range(min(self.ELITISM_COUNT, len(sorted_active))):
            elite = sorted_active[i]
            elite_copy = AgentVariant(
                variant_id=f"variant_gen{self._current_generation}_elite{i}",
                generation=self._current_generation,
                parent_ids=[elite.variant_id],
                config=elite.config.copy(),
                traits=elite.traits.copy(),
                fitness_score=elite.fitness_score * self.FITNESS_DECAY,
            )
            self._population[elite_copy.variant_id] = elite_copy
            new_variants.append(elite_copy)

        num_offspring = max(1, len(active) // 2)
        for i in range(num_offspring):
            if random.random() < self.CROSSOVER_RATE:
                parent1 = self.select_variant()
                parent2 = self.select_variant()
                if parent1 and parent2:
                    child = self._crossover(parent1, parent2, i)
                    self._population[child.variant_id] = child
                    new_variants.append(child)
            else:
                parent = self.select_variant()
                if parent:
                    child = self._mutate(parent, i)
                    self._population[child.variant_id] = child
                    new_variants.append(child)

        for variant in active:
            if variant not in sorted_active[:self.ELITISM_COUNT]:
                if variant.fitness_score < 0.3:
                    variant.status = VariantStatus.DEPRECATED
                    self._persist_variant(variant)

        self._enforce_population_limit()
        for v in new_variants:
            self._persist_variant(v)

        logger.info("Evolved generation %d: %d new variants", self._current_generation, len(new_variants))
        return new_variants

    def _crossover(self, parent1: AgentVariant, parent2: AgentVariant, index: int) -> AgentVariant:
        child_traits = {}
        all_keys = set(parent1.traits.keys()) | set(parent2.traits.keys())
        for key in all_keys:
            if key in parent1.traits and key in parent2.traits:
                child_traits[key] = random.choice([parent1.traits[key], parent2.traits[key]])
            elif key in parent1.traits:
                child_traits[key] = parent1.traits[key]
            else:
                child_traits[key] = parent2.traits[key]

        child_id = f"variant_gen{self._current_generation}_cross{index}"
        return AgentVariant(
            variant_id=child_id,
            generation=self._current_generation,
            parent_ids=[parent1.variant_id, parent2.variant_id],
            traits=child_traits,
            config=parent1.config if parent1.fitness_score >= parent2.fitness_score else parent2.config,
        )

    def _mutate(self, parent: AgentVariant, index: int) -> AgentVariant:
        child_traits = parent.traits.copy()
        mutations = self._generate_random_traits()
        for key, value in mutations.items():
            if random.random() < self.MUTATION_RATE:
                child_traits[key] = value

        child_id = f"variant_gen{self._current_generation}_mut{index}"
        return AgentVariant(
            variant_id=child_id,
            generation=self._current_generation,
            parent_ids=[parent.variant_id],
            traits=child_traits,
            config=parent.config.copy(),
        )

    def _generate_random_traits(self) -> Dict[str, Any]:
        return {
            "exploration_rate": round(random.uniform(0.1, 0.5), 2),
            "confidence_threshold": round(random.uniform(0.5, 0.9), 2),
            "retry_limit": random.randint(1, 5),
            "temperature": round(random.uniform(0.0, 1.0), 2),
            "max_context_tokens": random.choice([2048, 4096, 8192]),
        }

    def _enforce_population_limit(self) -> None:
        if len(self._population) <= self.MAX_POPULATION:
            return
        deprecated = [
            v for v in self._population.values()
            if v.status in (VariantStatus.DEPRECATED, VariantStatus.FAILED)
        ]
        deprecated.sort(key=lambda v: v.fitness_score)
        for v in deprecated[:len(self._population) - self.MAX_POPULATION]:
            self._population.pop(v.variant_id, None)
            variant_file = self._storage_dir / f"{v.variant_id}.json"
            if variant_file.exists():
                variant_file.unlink(missing_ok=True)
        if len(self._population) <= self.MAX_POPULATION:
            return
        all_variants = sorted(self._population.values(), key=lambda v: v.fitness_score)
        for v in all_variants[:len(self._population) - self.MAX_POPULATION]:
            self._population.pop(v.variant_id, None)
            variant_file = self._storage_dir / f"{v.variant_id}.json"
            if variant_file.exists():
                variant_file.unlink(missing_ok=True)

    def get_population_stats(self) -> Dict[str, Any]:
        active = [v for v in self._population.values() if v.status == VariantStatus.ACTIVE]
        by_status: Dict[str, int] = defaultdict(int)
        for v in self._population.values():
            by_status[v.status.value] += 1
        return {
            "total_variants": len(self._population),
            "active_variants": len(active),
            "current_generation": self._current_generation,
            "by_status": dict(by_status),
            "avg_fitness": sum(v.fitness_score for v in active) / max(len(active), 1) if active else 0,
            "best_fitness": max((v.fitness_score for v in active), default=0),
            "selection_method": self._selection_method.value,
        }

    def get_variant(self, variant_id: str) -> Optional[AgentVariant]:
        return self._population.get(variant_id)

    def list_variants(self, status: Optional[VariantStatus] = None) -> List[AgentVariant]:
        variants = list(self._population.values())
        if status:
            variants = [v for v in variants if v.status == status]
        return sorted(variants, key=lambda v: v.fitness_score, reverse=True)

    def _persist_variant(self, variant: AgentVariant) -> None:
        try:
            filepath = self._storage_dir / f"{variant.variant_id}.json"
            atomic_write(filepath, json.dumps(variant.to_dict(), ensure_ascii=False, indent=2))
        except Exception as e:
            logger.error("Failed to persist variant %s: %s", variant.variant_id, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return
        for filepath in self._storage_dir.glob("variant_*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                variant = AgentVariant(
                    variant_id=data["variant_id"],
                    generation=data.get("generation", 0),
                    parent_ids=data.get("parent_ids", []),
                    status=VariantStatus(data.get("status", "active")),
                    fitness_score=data.get("fitness_score", 0.5),
                    task_successes=data.get("task_successes", 0),
                    task_failures=data.get("task_failures", 0),
                    total_latency_ms=data.get("total_latency_ms", 0.0),
                    config=data.get("config", {}),
                    traits=data.get("traits", {}),
                    created_at=data.get("created_at", time.time()),
                    last_evaluated_at=data.get("last_evaluated_at"),
                )
                self._population[variant.variant_id] = variant
                if variant.generation > self._current_generation:
                    self._current_generation = variant.generation
            except Exception as e:
                logger.warning("Failed to load variant from %s: %s", filepath, e)
        logger.info("Loaded %d agent variants, generation %d", len(self._population), self._current_generation)


_population_instance: Optional[AgentPopulation] = None


def get_agent_population() -> AgentPopulation:
    global _population_instance
    if _population_instance is None:
        _population_instance = AgentPopulation()
    return _population_instance
