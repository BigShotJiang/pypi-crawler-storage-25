# -*- coding: utf-8 -*-
"""Self-Distillation Loop - Offline trajectory distillation inspired by EvolveR.

EvolveR (2025) key insight:
- Offline Self-Distillation: Synthesize interaction trajectories into a structured
  repository of abstract, reusable strategic principles
- Online Interaction: Actively retrieve distilled principles to guide decision-making
- Policy reinforcement: Iteratively update the agent based on performance

This module provides:
1. SelfDistillationLoop: The main distillation engine
2. StrategicPrinciple: A distilled, reusable strategic principle
3. TrajectoryAnalyzer: Analyze interaction trajectories for pattern extraction
4. PrincipleRetriever: Retrieve relevant principles for a given task

The distillation process:
  Interaction Trajectories → Pattern Extraction → Principle Abstraction →
  Validation → Storage → Retrieval for future tasks
"""

import asyncio
import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class PrincipleStatus(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    ACTIVE = "active"
    DEPRECATED = "deprecated"


class PrincipleCategory(str, Enum):
    REASONING = "reasoning"
    TOOL_SELECTION = "tool_selection"
    ERROR_RECOVERY = "error_recovery"
    TASK_DECOMPOSITION = "task_decomposition"
    COMMUNICATION = "communication"
    OPTIMIZATION = "optimization"
    SAFETY = "safety"


@dataclass
class StrategicPrinciple:
    id: str = field(default_factory=lambda: f"sp_{uuid.uuid4().hex[:8]}")
    name: str = ""
    category: PrincipleCategory = PrincipleCategory.REASONING
    status: PrincipleStatus = PrincipleStatus.DRAFT
    abstract_rule: str = ""
    concrete_examples: List[str] = field(default_factory=list)
    applicability_conditions: List[str] = field(default_factory=list)
    counter_examples: List[str] = field(default_factory=list)
    source_trajectory_ids: List[str] = field(default_factory=list)
    validation_count: int = 0
    application_count: int = 0
    success_rate: float = 0.0
    confidence: float = 0.0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category.value,
            "status": self.status.value,
            "abstract_rule": self.abstract_rule,
            "concrete_examples": self.concrete_examples,
            "applicability_conditions": self.applicability_conditions,
            "counter_examples": self.counter_examples,
            "source_trajectory_ids": self.source_trajectory_ids,
            "validation_count": self.validation_count,
            "application_count": self.application_count,
            "success_rate": self.success_rate,
            "confidence": self.confidence,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StrategicPrinciple":
        data["category"] = PrincipleCategory(data.get("category", "reasoning"))
        data["status"] = PrincipleStatus(data.get("status", "draft"))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class TrajectorySnippet:
    task: str = ""
    actions_taken: List[str] = field(default_factory=list)
    outcome: str = ""
    success: bool = False
    agent_name: str = ""
    timestamp: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DistillationResult:
    principles_created: int = 0
    principles_updated: int = 0
    principles_deprecated: int = 0
    trajectories_processed: int = 0
    distillation_time_ms: float = 0.0


class TrajectoryAnalyzer:
    """Analyzes interaction trajectories to extract patterns."""

    def analyze_success_trajectory(self, trajectory: TrajectorySnippet) -> Optional[StrategicPrinciple]:
        if not trajectory.success or not trajectory.actions_taken:
            return None

        actions_str = "; ".join(trajectory.actions_taken)
        abstract_rule = self._abstract_pattern(trajectory.task, actions_str, trajectory.outcome)

        if not abstract_rule:
            return None

        return StrategicPrinciple(
            name=self._generate_name(trajectory),
            category=self._categorize(trajectory),
            status=PrincipleStatus.DRAFT,
            abstract_rule=abstract_rule,
            concrete_examples=[f"Task: {trajectory.task[:200]} → {trajectory.outcome[:200]}"],
            applicability_conditions=self._extract_conditions(trajectory),
            source_trajectory_ids=[trajectory.timestamp] if trajectory.timestamp else [],
            confidence=0.5,
        )

    def analyze_failure_trajectory(self, trajectory: TrajectorySnippet) -> Optional[StrategicPrinciple]:
        if trajectory.success or not trajectory.actions_taken:
            return None

        counter_examples = [f"Failed: {trajectory.task[:200]} → {trajectory.outcome[:200]}"]

        return StrategicPrinciple(
            name=f"Avoid: {trajectory.task[:30]}",
            category=PrincipleCategory.ERROR_RECOVERY,
            status=PrincipleStatus.DRAFT,
            abstract_rule=f"When task involves '{trajectory.task[:50]}', avoid: {'; '.join(trajectory.actions_taken[:3])}",
            counter_examples=counter_examples,
            applicability_conditions=[f"Task similar to: {trajectory.task[:50]}"],
            source_trajectory_ids=[trajectory.timestamp] if trajectory.timestamp else [],
            confidence=0.3,
        )

    def _abstract_pattern(self, task: str, actions: str, outcome: str) -> str:
        task_lower = task.lower()

        if any(kw in task_lower for kw in ["deploy", "部署", "发布"]):
            return "For deployment tasks: verify environment first, then deploy with health check"
        if any(kw in task_lower for kw in ["debug", "调试", "修复"]):
            return "For debugging: reproduce the error, isolate the cause, apply minimal fix"
        if any(kw in task_lower for kw in ["search", "搜索", "查询"]):
            return "For search tasks: use specific queries, verify results, refine if needed"
        if any(kw in task_lower for kw in ["write", "写", "创建"]):
            return "For creation tasks: plan structure first, implement incrementally, validate"
        if any(kw in task_lower for kw in ["analyze", "分析", "评估"]):
            return "For analysis: gather data first, apply systematic framework, draw conclusions"

        if actions and outcome:
            return f"Pattern: {actions[:100]} → {outcome[:100]}"

        return ""

    def _categorize(self, trajectory: TrajectorySnippet) -> PrincipleCategory:
        task_lower = trajectory.task.lower()
        if any(kw in task_lower for kw in ["tool", "function", "call"]):
            return PrincipleCategory.TOOL_SELECTION
        if any(kw in task_lower for kw in ["error", "fail", "debug"]):
            return PrincipleCategory.ERROR_RECOVERY
        if any(kw in task_lower for kw in ["decompose", "split", "break down"]):
            return PrincipleCategory.TASK_DECOMPOSITION
        if any(kw in task_lower for kw in ["safe", "security", "guard"]):
            return PrincipleCategory.SAFETY
        if any(kw in task_lower for kw in ["optimize", "fast", "efficient"]):
            return PrincipleCategory.OPTIMIZATION
        if any(kw in task_lower for kw in ["communicate", "explain", "respond"]):
            return PrincipleCategory.COMMUNICATION
        return PrincipleCategory.REASONING

    def _extract_conditions(self, trajectory: TrajectorySnippet) -> List[str]:
        conditions = []
        task_lower = trajectory.task.lower()

        if any(kw in task_lower for kw in ["deploy", "部署"]):
            conditions.append("Deployment-related tasks")
        if any(kw in task_lower for kw in ["api", "接口"]):
            conditions.append("API-related tasks")
        if any(kw in task_lower for kw in ["data", "数据"]):
            conditions.append("Data-related tasks")
        if any(kw in task_lower for kw in ["model", "模型"]):
            conditions.append("Model-related tasks")

        if not conditions:
            conditions.append(f"Tasks similar to: {trajectory.task[:50]}")

        return conditions

    def _generate_name(self, trajectory: TrajectorySnippet) -> str:
        return f"{trajectory.category.value if hasattr(trajectory, 'category') else 'strategy'}: {trajectory.task[:30]}"


class PrincipleRetriever:
    """Retrieves relevant strategic principles for a given task."""

    def retrieve(
        self,
        task: str,
        principles: Dict[str, StrategicPrinciple],
        max_results: int = 3,
        min_confidence: float = 0.3,
    ) -> List[StrategicPrinciple]:
        task_lower = task.lower()
        task_words = set(task_lower.split())

        scored: List[Tuple[StrategicPrinciple, float]] = []
        for principle in principles.values():
            if principle.status == PrincipleStatus.DEPRECATED:
                continue
            if principle.confidence < min_confidence:
                continue

            score = self._compute_relevance(principle, task_words, task_lower)
            if score > 0:
                scored.append((principle, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [p for p, _ in scored[:max_results]]

    def _compute_relevance(
        self,
        principle: StrategicPrinciple,
        task_words: Set[str],
        task_lower: str,
    ) -> float:
        score = 0.0

        for cond in principle.applicability_conditions:
            cond_words = set(cond.lower().split())
            overlap = task_words & cond_words
            score += len(overlap) * 0.5

        for word in task_words:
            if word in principle.abstract_rule.lower():
                score += 0.3

        score += principle.confidence * 0.4

        if principle.status == PrincipleStatus.ACTIVE:
            score *= 1.3
        elif principle.status == PrincipleStatus.VALIDATED:
            score *= 1.1

        if principle.success_rate > 0:
            score *= (0.5 + principle.success_rate * 0.5)

        return score


class SelfDistillationLoop:
    """Self-Distillation Loop inspired by EvolveR.

    Two-phase lifecycle:
    1. Offline Self-Distillation: Synthesize interaction trajectories into
       abstract, reusable strategic principles
    2. Online Retrieval: Actively retrieve distilled principles to guide
       decision-making in new tasks

    Usage:
        loop = SelfDistillationLoop()
        loop.distill(trajectories)
        principles = loop.retrieve_principles("deploy the application")
    """

    MAX_PRINCIPLES = 500
    AUTO_VALIDATE_THRESHOLD = 3
    AUTO_ACTIVATE_THRESHOLD = 6
    DEPRECATE_THRESHOLD = 0.2

    def __init__(
        self,
        storage_dir: Optional[str] = None,
        llm_fn: Optional[Callable] = None,
    ):
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "distilled_principles"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self.llm_fn = llm_fn
        self._analyzer = TrajectoryAnalyzer()
        self._retriever = PrincipleRetriever()
        self._principles: Dict[str, StrategicPrinciple] = {}
        self._load()

    async def distill(
        self,
        trajectories: List[TrajectorySnippet],
    ) -> DistillationResult:
        start_time = time.time()
        result = DistillationResult(trajectories_processed=len(trajectories))

        for trajectory in trajectories:
            principle = None
            if trajectory.success:
                principle = self._analyzer.analyze_success_trajectory(trajectory)
            else:
                principle = self._analyzer.analyze_failure_trajectory(trajectory)

            if principle is None:
                continue

            if self.llm_fn:
                principle = await self._llm_refine_principle(principle, trajectory)

            existing = self._find_similar_principle(principle)
            if existing:
                self._merge_principle(existing, principle)
                result.principles_updated += 1
            else:
                self._principles[principle.id] = principle
                result.principles_created += 1

            self._persist_principle(principle)

        deprecated = self._check_deprecations()
        result.principles_deprecated = deprecated

        self._enforce_max_principles()

        result.distillation_time_ms = (time.time() - start_time) * 1000
        logger.info(
            "Distillation complete: %d created, %d updated, %d deprecated from %d trajectories",
            result.principles_created, result.principles_updated,
            result.principles_deprecated, len(trajectories),
        )
        return result

    def distill_sync(self, trajectories: List[TrajectorySnippet]) -> DistillationResult:
        try:
            loop = asyncio.get_running_loop()
            if loop.is_running():
                return self._distill_sync_impl(trajectories)
        except RuntimeError:
            pass
        return asyncio.run(self.distill(trajectories))

    def _distill_sync_impl(self, trajectories: List[TrajectorySnippet]) -> DistillationResult:
        start_time = time.time()
        result = DistillationResult(trajectories_processed=len(trajectories))

        for trajectory in trajectories:
            principle = None
            if trajectory.success:
                principle = self._analyzer.analyze_success_trajectory(trajectory)
            else:
                principle = self._analyzer.analyze_failure_trajectory(trajectory)

            if principle is None:
                continue

            existing = self._find_similar_principle(principle)
            if existing:
                self._merge_principle(existing, principle)
                result.principles_updated += 1
            else:
                self._principles[principle.id] = principle
                result.principles_created += 1

            self._persist_principle(principle)

        deprecated = self._check_deprecations()
        result.principles_deprecated = deprecated
        self._enforce_max_principles()
        result.distillation_time_ms = (time.time() - start_time) * 1000
        return result

    def distill_from_data_flywheel(self, hours: int = 168) -> DistillationResult:
        try:
            from ...data_flywheel import DataFlywheel

            flywheel = DataFlywheel()
            records = flywheel.collector.get_recent(hours=hours)

            trajectories = []
            for record in records:
                trajectory = TrajectorySnippet(
                    task=record.user_input[:500],
                    actions_taken=[f"Used model: {record.model_used}"],
                    outcome=record.system_output[:500],
                    success=record.success,
                    agent_name=record.agent_name,
                    timestamp=record.timestamp.isoformat() if hasattr(record.timestamp, 'isoformat') else str(record.timestamp),
                )
                trajectories.append(trajectory)

            import asyncio
            try:
                loop = asyncio.get_running_loop()
                if loop.is_running():
                    result = DistillationResult(
                        trajectories_processed=len(trajectories),
                        principles_created=0,
                    )
                    for trajectory in trajectories:
                        if trajectory.success:
                            principle = self._analyzer.analyze_success_trajectory(trajectory)
                        else:
                            principle = self._analyzer.analyze_failure_trajectory(trajectory)
                        if principle:
                            existing = self._find_similar_principle(principle)
                            if existing:
                                self._merge_principle(existing, principle)
                                result.principles_updated += 1
                            else:
                                self._principles[principle.id] = principle
                                result.principles_created += 1
                            self._persist_principle(principle)
                    return result
            except RuntimeError:
                pass

            return asyncio.run(self.distill(trajectories))

        except Exception as e:
            logger.error("Failed to distill from DataFlywheel: %s", e)
            return DistillationResult()

    def distill_from_outcomes(self, hours: int = 168) -> DistillationResult:
        try:
            outcomes_dir = Path.home() / ".xingzierai" / "outcomes"
            records_file = outcomes_dir / "outcome_records.json"
            if not records_file.exists():
                return DistillationResult()

            data = json.loads(records_file.read_text(encoding="utf-8"))
            records = data if isinstance(data, list) else data.get("records", [])

            trajectories = []
            for rec in records[-200:]:
                trajectory = TrajectorySnippet(
                    task=rec.get("task_description", "")[:500],
                    actions_taken=rec.get("suggestions", [])[:5],
                    outcome=rec.get("result", "")[:500],
                    success=rec.get("overall_passed", False),
                    agent_name=rec.get("agent_name", "unknown"),
                    timestamp=rec.get("timestamp", ""),
                )
                trajectories.append(trajectory)

            import asyncio
            try:
                loop = asyncio.get_running_loop()
                if loop.is_running():
                    result = DistillationResult(trajectories_processed=len(trajectories))
                    for trajectory in trajectories:
                        if trajectory.success:
                            principle = self._analyzer.analyze_success_trajectory(trajectory)
                        else:
                            principle = self._analyzer.analyze_failure_trajectory(trajectory)
                        if principle:
                            existing = self._find_similar_principle(principle)
                            if existing:
                                self._merge_principle(existing, principle)
                                result.principles_updated += 1
                            else:
                                self._principles[principle.id] = principle
                                result.principles_created += 1
                            self._persist_principle(principle)
                    return result
            except RuntimeError:
                pass

            return asyncio.run(self.distill(trajectories))

        except Exception as e:
            logger.error("Failed to distill from outcomes: %s", e)
            return DistillationResult()

    def retrieve_principles(
        self,
        task: str,
        max_results: int = 3,
        min_confidence: float = 0.3,
    ) -> List[StrategicPrinciple]:
        return self._retriever.retrieve(task, self._principles, max_results, min_confidence)

    def format_principles_for_prompt(self, task: str, max_principles: int = 3) -> str:
        principles = self.retrieve_principles(task, max_results=max_principles)
        if not principles:
            return ""

        lines = ["[Distilled Strategic Principles - apply if relevant]"]
        for i, p in enumerate(principles, 1):
            lines.append(f"{i}. {p.abstract_rule}")
            if p.applicability_conditions:
                lines.append(f"   When: {'; '.join(p.applicability_conditions[:2])}")
            if p.counter_examples:
                lines.append(f"   Avoid: {p.counter_examples[0][:100]}")

        return "\n".join(lines)

    def record_principle_application(
        self,
        principle_id: str,
        success: bool,
    ) -> None:
        principle = self._principles.get(principle_id)
        if not principle:
            return

        principle.application_count += 1
        if success:
            principle.validation_count += 1

        total = principle.validation_count + (principle.application_count - principle.validation_count)
        if total > 0:
            principle.success_rate = principle.validation_count / total

        principle.confidence = min(principle.confidence + (0.05 if success else -0.1), 1.0)
        principle.confidence = max(principle.confidence, 0.0)

        if principle.status == PrincipleStatus.DRAFT and principle.validation_count >= self.AUTO_VALIDATE_THRESHOLD:
            principle.status = PrincipleStatus.VALIDATED
            logger.info("Principle validated: %s", principle.name)

        if principle.status == PrincipleStatus.VALIDATED and principle.validation_count >= self.AUTO_ACTIVATE_THRESHOLD:
            principle.status = PrincipleStatus.ACTIVE
            logger.info("Principle activated: %s", principle.name)

        if principle.confidence < self.DEPRECATE_THRESHOLD and principle.application_count >= 5:
            principle.status = PrincipleStatus.DEPRECATED
            logger.info("Principle deprecated: %s", principle.name)

        principle.updated_at = datetime.now().isoformat()
        self._persist_principle(principle)

    def get_stats(self) -> Dict[str, Any]:
        total = len(self._principles)
        by_status: Dict[str, int] = defaultdict(int)
        by_category: Dict[str, int] = defaultdict(int)

        for p in self._principles.values():
            by_status[p.status.value] += 1
            by_category[p.category.value] += 1

        return {
            "total_principles": total,
            "by_status": dict(by_status),
            "by_category": dict(by_category),
            "avg_confidence": sum(p.confidence for p in self._principles.values()) / max(total, 1),
            "total_applications": sum(p.application_count for p in self._principles.values()),
            "capacity": self.MAX_PRINCIPLES,
        }

    async def _llm_refine_principle(
        self,
        principle: StrategicPrinciple,
        trajectory: TrajectorySnippet,
    ) -> StrategicPrinciple:
        if not self.llm_fn:
            return principle

        try:
            prompt = (
                f"Refine this strategic principle into a concise, abstract rule:\n\n"
                f"Task: {trajectory.task[:300]}\n"
                f"Actions: {'; '.join(trajectory.actions_taken[:5])}\n"
                f"Outcome: {trajectory.outcome[:300]}\n"
                f"Success: {trajectory.success}\n\n"
                f"Current draft: {principle.abstract_rule}\n\n"
                f"Provide a refined abstract rule (one sentence) and applicability conditions.\n"
                f"Output JSON: {{\"abstract_rule\": \"...\", \"applicability_conditions\": [\"...\"]}}"
            )

            if asyncio.iscoroutinefunction(self.llm_fn):
                response = await self.llm_fn(prompt)
            else:
                response = self.llm_fn(prompt)

            refined = self._parse_llm_response(str(response))
            if refined:
                principle.abstract_rule = refined.get("abstract_rule", principle.abstract_rule)
                if refined.get("applicability_conditions"):
                    principle.applicability_conditions = refined["applicability_conditions"]
                principle.confidence = min(principle.confidence + 0.2, 1.0)

        except Exception as e:
            logger.warning("LLM principle refinement failed: %s", e)

        return principle

    def _parse_llm_response(self, response: str) -> Optional[Dict[str, Any]]:
        try:
            start = response.find("{")
            end = response.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(response[start:end])
        except (json.JSONDecodeError, Exception):
            pass
        return None

    def _find_similar_principle(self, principle: StrategicPrinciple) -> Optional[StrategicPrinciple]:
        principle_words = set(principle.abstract_rule.lower().split())
        if not principle_words:
            return None

        best: Optional[StrategicPrinciple] = None
        best_sim = 0.0

        for existing in self._principles.values():
            if existing.category != principle.category:
                continue

            existing_words = set(existing.abstract_rule.lower().split())
            if not existing_words:
                continue

            intersection = principle_words & existing_words
            union = principle_words | existing_words
            jaccard = len(intersection) / len(union)

            if jaccard > best_sim and jaccard >= 0.5:
                best_sim = jaccard
                best = existing

        return best

    def _merge_principle(self, existing: StrategicPrinciple, new: StrategicPrinciple) -> None:
        existing.concrete_examples.extend(new.concrete_examples)
        existing.concrete_examples = existing.concrete_examples[-10:]

        existing.applicability_conditions = list(
            set(existing.applicability_conditions + new.applicability_conditions)
        )

        existing.counter_examples.extend(new.counter_examples)
        existing.counter_examples = existing.counter_examples[-5:]

        existing.source_trajectory_ids.extend(new.source_trajectory_ids)

        if new.confidence > existing.confidence:
            existing.abstract_rule = new.abstract_rule

        existing.confidence = min(
            (existing.confidence + new.confidence) / 2 + 0.1,
            1.0,
        )

        existing.updated_at = datetime.now().isoformat()

    def _check_deprecations(self) -> int:
        deprecated = 0
        for principle in self._principles.values():
            if (principle.confidence < self.DEPRECATE_THRESHOLD
                    and principle.application_count >= 5
                    and principle.status != PrincipleStatus.DEPRECATED):
                principle.status = PrincipleStatus.DEPRECATED
                deprecated += 1
                self._persist_principle(principle)
        return deprecated

    def _enforce_max_principles(self) -> None:
        if len(self._principles) <= self.MAX_PRINCIPLES:
            return

        active = [p for p in self._principles.values() if p.status != PrincipleStatus.DEPRECATED]
        if len(active) <= self.MAX_PRINCIPLES:
            return

        sorted_principles = sorted(active, key=lambda p: p.confidence * 0.5 + p.success_rate * 0.5)
        to_remove = len(active) - self.MAX_PRINCIPLES

        for principle in sorted_principles[:to_remove]:
            principle.status = PrincipleStatus.DEPRECATED
            self._persist_principle(principle)

        logger.info("Enforced max principles %d, deprecated %d", self.MAX_PRINCIPLES, to_remove)

    def _persist_principle(self, principle: StrategicPrinciple) -> None:
        try:
            filepath = self._storage_dir / f"{principle.id}.json"
            atomic_write(
                filepath,
                json.dumps(principle.to_dict(), indent=2, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning("Failed to persist principle %s: %s", principle.id, e)

    def _load(self) -> None:
        if not self._storage_dir.exists():
            return

        for filepath in self._storage_dir.glob("*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                principle = StrategicPrinciple.from_dict(data)
                self._principles[principle.id] = principle
            except Exception as e:
                logger.warning("Failed to load principle %s: %s", filepath, e)

        logger.info("Loaded %d distilled principles", len(self._principles))


def get_distillation_loop() -> SelfDistillationLoop:
    return SelfDistillationLoop()
