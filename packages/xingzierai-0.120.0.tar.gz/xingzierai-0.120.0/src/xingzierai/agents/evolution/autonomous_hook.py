# -*- coding: utf-8 -*-
"""Autonomous Worker Hook -断点续传 and retry logic for agents."""

from __future__ import annotations

from ._utils import atomic_write

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, TYPE_CHECKING

from xingzierai.agentscope_core.message import Msg

if TYPE_CHECKING:
    from ..memory.memory_manager import MemoryManager

logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUSPENDED = "suspended"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class RetryStrategy(str, Enum):
    EXPONENTIAL_BACKOFF = "exponential_backoff"
    LINEAR_BACKOFF = "linear_backoff"
    FIXED_DELAY = "fixed_delay"
    IMMEDIATE = "immediate"


@dataclass
class TaskContext:
    task_id: str
    description: str
    status: TaskStatus
    created_at: str
    updated_at: str
    retry_count: int = 0
    max_retries: int = 3
    next_retry_at: Optional[str] = None
    last_error: Optional[str] = None
    result: Optional[Any] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RetryConfig:
    max_retries: int = 3
    initial_delay: float = 60.0
    max_delay: float = 3600.0
    backoff_multiplier: float = 2.0
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF
    retryable_errors: tuple = (
        "429",
        "502",
        "503",
        "504",
        "timeout",
        "rate limit",
        "connection",
    )


class AutonomousTaskRegistry:
    """Registry for tracking autonomous tasks with persistence."""

    MAX_TASKS = 500

    def __init__(self, memory_manager: Optional["MemoryManager"] = None, persist_dir: Optional[str] = None):
        self.memory_manager = memory_manager
        self._tasks: Dict[str, TaskContext] = {}
        self._persist_dir = Path(persist_dir) if persist_dir else Path.home() / ".xingzierai" / "autonomous_tasks"
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._load_from_memory()

    def _load_from_memory(self) -> None:
        try:
            persist_file = self._persist_dir / "tasks.json"
            if persist_file.exists():
                data = json.loads(persist_file.read_text(encoding="utf-8"))
                for tid, tdata in data.items():
                    self._tasks[tid] = TaskContext(
                        task_id=tdata["task_id"],
                        description=tdata["description"],
                        status=TaskStatus(tdata["status"]),
                        created_at=tdata["created_at"],
                        updated_at=tdata["updated_at"],
                        retry_count=tdata.get("retry_count", 0),
                        max_retries=tdata.get("max_retries", 3),
                        next_retry_at=tdata.get("next_retry_at"),
                        last_error=tdata.get("last_error"),
                        result=tdata.get("result"),
                        metadata=tdata.get("metadata", {}),
                    )
                logger.info(f"Loaded {len(self._tasks)} tasks from disk")
        except Exception as e:
            logger.warning(f"Failed to load tasks from memory: {e}")

    def _save_to_memory(self) -> None:
        try:
            self._enforce_max_tasks()
            persist_file = self._persist_dir / "tasks.json"
            data = {}
            for tid, task in self._tasks.items():
                data[tid] = {
                    "task_id": task.task_id,
                    "description": task.description,
                    "status": task.status.value,
                    "created_at": task.created_at,
                    "updated_at": task.updated_at,
                    "retry_count": task.retry_count,
                    "max_retries": task.max_retries,
                    "next_retry_at": task.next_retry_at,
                    "last_error": task.last_error,
                    "metadata": task.metadata,
                }
            atomic_write(persist_file, json.dumps(data, ensure_ascii=False, indent=2))
        except Exception as e:
            logger.warning(f"Failed to save tasks to memory: {e}")

    def _enforce_max_tasks(self) -> None:
        if len(self._tasks) <= self.MAX_TASKS:
            return
        completed = [t for t in self._tasks.values() if t.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED)]
        completed.sort(key=lambda t: t.updated_at, reverse=True)
        for task in completed[len(self._tasks) - self.MAX_TASKS:]:
            self._tasks.pop(task.task_id, None)

    def register_task(
        self,
        task_id: str,
        description: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> TaskContext:
        now = datetime.now().isoformat()
        task = TaskContext(
            task_id=task_id,
            description=description,
            status=TaskStatus.PENDING,
            created_at=now,
            updated_at=now,
            metadata=metadata or {},
        )
        self._tasks[task_id] = task
        self._save_to_memory()
        logger.info(f"Registered task: {task_id}")
        return task

    def get_task(self, task_id: str) -> Optional[TaskContext]:
        return self._tasks.get(task_id)

    def update_task(
        self,
        task_id: str,
        status: Optional[TaskStatus] = None,
        result: Any = None,
        error: Optional[str] = None,
    ) -> bool:
        task = self._tasks.get(task_id)
        if not task:
            return False

        if status:
            task.status = status
        if result is not None:
            task.result = result
        if error:
            task.last_error = error

        task.updated_at = datetime.now().isoformat()
        self._save_to_memory()
        return True

    def suspend_task(
        self,
        task_id: str,
        next_retry_at: Optional[datetime] = None,
        delay_seconds: Optional[float] = None,
        error: Optional[str] = None,
    ) -> bool:
        task = self._tasks.get(task_id)
        if not task:
            return False

        task.status = TaskStatus.SUSPENDED
        task.retry_count += 1
        task.last_error = error
        task.updated_at = datetime.now().isoformat()

        if next_retry_at:
            task.next_retry_at = next_retry_at.isoformat()
        elif delay_seconds:
            task.next_retry_at = (
                datetime.now() + timedelta(seconds=delay_seconds)
            ).isoformat()

        self._save_to_memory()
        logger.info(
            f"Suspended task {task_id}, retry #{task.retry_count} "
            f"scheduled at {task.next_retry_at}"
        )
        return True

    def list_tasks(
        self,
        status_filter: Optional[TaskStatus] = None,
    ) -> List[TaskContext]:
        if status_filter is None:
            return list(self._tasks.values())
        return [t for t in self._tasks.values() if t.status == status_filter]

    def get_pending_retries(self) -> List[TaskContext]:
        now = datetime.now()
        pending = []
        for task in self._tasks.values():
            if task.status == TaskStatus.SUSPENDED and task.next_retry_at:
                retry_time = datetime.fromisoformat(task.next_retry_at)
                if retry_time <= now:
                    pending.append(task)
        return pending


class AutonomousWorkerMixin:
    """Mixin that provides autonomous断点续传 (checkpoint/resume) capability.

    When errors like 429 Rate Limit or 502 Bad Gateway are detected,
    tasks are automatically suspended and scheduled for retry via Cron.
    """

    def __init__(
        self,
        memory_manager: Optional["MemoryManager"] = None,
        retry_config: Optional[RetryConfig] = None,
        cron_scheduler: Optional[Any] = None,
        **kwargs,
    ):
        self._autonomous_registry = AutonomousTaskRegistry(memory_manager)
        self._retry_config = retry_config or RetryConfig()
        self._cron_scheduler = cron_scheduler
        self._suspended_tasks: Dict[str, asyncio.Task] = {}
        self._original_reply = None
        self._background_tasks: Set[asyncio.Task] = set()

    def is_retryable_error(self, error: Exception) -> bool:
        """Check if an error is retryable based on configured patterns."""
        error_str = str(error).lower()
        return any(
            pattern.lower() in error_str
            for pattern in self._retry_config.retryable_errors
        )

    def calculate_retry_delay(self, retry_count: int) -> float:
        """Calculate delay based on retry strategy."""
        delay = self._retry_config.initial_delay * (
            self._retry_config.backoff_multiplier ** retry_count
        )
        return min(delay, self._retry_config.max_delay)

    def suspend_and_schedule_retry(
        self,
        task_id: str,
        error: Exception,
        coro_func: Callable,
        *args,
        **kwargs,
    ) -> Optional[asyncio.Task]:
        """Suspend current task and schedule a retry.

        Args:
            task_id: Unique task identifier
            error: The error that caused the suspension
            coro_func: Async function to retry
            *args: Arguments for coro_func
            **kwargs: Keyword arguments for coro_func

        Returns:
            asyncio.Task for the scheduled retry, or None if max retries exceeded
        """
        task = self._autonomous_registry.get_task(task_id)
        if not task:
            logger.warning(f"Task {task_id} not found in registry")
            return None

        if task.retry_count >= self._retry_config.max_retries:
            self._autonomous_registry.update_task(
                task_id,
                status=TaskStatus.FAILED,
                error=f"Max retries ({self._retry_config.max_retries}) exceeded: {error}",
            )
            logger.error(f"Task {task_id} failed: max retries exceeded")
            return None

        delay = self.calculate_retry_delay(task.retry_count)
        next_retry = datetime.now() + timedelta(seconds=delay)

        self._autonomous_registry.suspend_task(
            task_id,
            next_retry_at=next_retry,
            error=str(error),
        )

        if self._cron_scheduler:
            self._schedule_cron_retry(task_id, next_retry, coro_func, *args, **kwargs)
        else:
            self._schedule_direct_retry(task_id, delay, coro_func, *args, **kwargs)

        return self._suspended_tasks.get(task_id)

    def _schedule_direct_retry(
        self,
        task_id: str,
        delay: float,
        coro_func: Callable,
        *args,
        **kwargs,
    ) -> asyncio.Task:
        """Schedule a direct async retry after delay."""
        async def delayed_retry():
            await asyncio.sleep(delay)
            self._autonomous_registry.update_task(task_id, status=TaskStatus.RUNNING)
            try:
                result = await coro_func(*args, **kwargs)
                self._autonomous_registry.update_task(
                    task_id,
                    status=TaskStatus.COMPLETED,
                    result=result,
                )
                return result
            except Exception as e:
                logger.error(f"Retry failed for task {task_id}: {e}")
                self.suspend_and_schedule_retry(task_id, e, coro_func, *args, **kwargs)
                return None

        task = asyncio.create_task(delayed_retry())
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        self._suspended_tasks[task_id] = task
        self._cleanup_suspended_tasks()
        return task

    def _cleanup_suspended_tasks(self) -> None:
        done_ids = [tid for tid, t in self._suspended_tasks.items() if t.done()]
        for tid in done_ids:
            del self._suspended_tasks[tid]

    def _schedule_cron_retry(
        self,
        task_id: str,
        next_retry: datetime,
        coro_func: Callable,
        *args,
        **kwargs,
    ) -> None:
        """Schedule retry via Cron system."""
        if not self._cron_scheduler:
            return

        try:
            job_spec = {
                "id": f"autonomous_retry_{task_id}",
                "name": f"Retry task {task_id}",
                "cron_expr": self._datetime_to_cron(next_retry),
                "enabled": True,
            }
            logger.info(f"Scheduled Cron retry for task {task_id} at {next_retry}")
        except Exception as e:
            logger.warning(f"Failed to schedule cron retry: {e}")
            self._schedule_direct_retry(task_id, 60, coro_func, *args, **kwargs)

    @staticmethod
    def _datetime_to_cron(dt: datetime) -> str:
        """Convert datetime to cron expression (every minute after the time)."""
        return f"{dt.minute} {dt.hour} {dt.day} {dt.month} *"

    async def process_pending_retries(self) -> List[str]:
        """Process all pending task retries.

        Returns:
            List of task_ids that were processed
        """
        pending = self._autonomous_registry.get_pending_retries()
        processed = []

        for task in pending:
            if task.task_id in self._suspended_tasks:
                existing = self._suspended_tasks[task.task_id]
                if not existing.done():
                    continue

            logger.info(f"Processing pending retry for task: {task.task_id}")
            processed.append(task.task_id)

        return processed

    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """Get the current status of a task."""
        task = self._autonomous_registry.get_task(task_id)
        return task.status if task else None

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a running or suspended task."""
        if task_id in self._suspended_tasks:
            task = self._suspended_tasks.pop(task_id)
            if not task.done():
                task.cancel()
            logger.info(f"Cancelled task: {task_id}")

        task = self._autonomous_registry.get_task(task_id)
        if task:
            self._autonomous_registry.update_task(
                task_id,
                status=TaskStatus.CANCELLED,
            )
            return True
        return False


class ErrorAwareTaskWrapper:
    """Wrapper that adds error awareness and retry capability to async functions."""

    def __init__(
        self,
        worker: AutonomousWorkerMixin,
        task_id: str,
    ):
        self.worker = worker
        self.task_id = task_id

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_val and self.worker.is_retryable_error(exc_val):
            logger.warning(
                f"Retryable error in task {self.task_id}: {exc_val}"
            )
            return True
        return False


def create_autonomous_worker(
    memory_manager: Optional["MemoryManager"] = None,
    max_retries: int = 3,
    initial_delay: float = 60.0,
) -> AutonomousWorkerMixin:
    """Factory function to create an AutonomousWorkerMixin.

    Args:
        memory_manager: Optional memory manager for persistence
        max_retries: Maximum number of retry attempts
        initial_delay: Initial delay in seconds before first retry

    Returns:
        Configured AutonomousWorkerMixin instance
    """
    retry_config = RetryConfig(
        max_retries=max_retries,
        initial_delay=initial_delay,
    )
    return AutonomousWorkerMixin(
        memory_manager=memory_manager,
        retry_config=retry_config,
    )
