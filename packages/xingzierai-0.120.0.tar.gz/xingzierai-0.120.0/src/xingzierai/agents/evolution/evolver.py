# -*- coding: utf-8 -*-
"""Skill Self-Evolution System - Enables skills to learn and improve from experience."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
import hashlib

logger = logging.getLogger(__name__)


class EvolutionStatus(str, Enum):
    """Skill evolution status."""
    STABLE = "stable"
    LEARNING = "learning"
    EVOLVING = "evolving"
    DEGRADED = "degraded"
    UNKNOWN = "unknown"


class ImprovementType(str, Enum):
    """Types of skill improvements."""
    ACCURACY = "accuracy"
    SPEED = "speed"
    RELIABILITY = "reliability"
    COVERAGE = "coverage"
    USER_FEEDBACK = "user_feedback"
    PATTERN_LEARNED = "pattern_learned"
    ERROR_REDUCTION = "error_reduction"


@dataclass
class ExecutionRecord:
    """Record of a single skill execution."""
    skill_name: str
    timestamp: float
    execution_time: float
    success: bool
    input_summary: str
    output_summary: str
    error_message: Optional[str] = None
    user_rating: Optional[int] = None
    feedback: Optional[str] = None
    patterns_identified: List[str] = field(default_factory=list)
    improvements_made: List[str] = field(default_factory=list)


@dataclass
class SkillEvolutionMetrics:
    """Metrics for skill evolution."""
    total_executions: int = 0
    successful_executions: int = 0
    failed_executions: int = 0
    average_execution_time: float = 0.0
    success_rate: float = 0.0
    last_execution_time: float = 0.0
    last_success_time: float = 0.0
    last_failure_time: float = 0.0
    common_patterns: List[str] = field(default_factory=list)
    common_errors: List[str] = field(default_factory=list)
    improvement_history: List[Dict[str, Any]] = field(default_factory=list)
    evolution_status: EvolutionStatus = EvolutionStatus.UNKNOWN
    confidence_score: float = 0.0
    suggested_improvements: List[str] = field(default_factory=list)


@dataclass
class SkillEvolutionConfig:
    """Configuration for skill self-evolution."""
    enabled: bool = True
    min_samples_for_learning: int = 10
    min_success_rate_to_learn: float = 0.7
    max_execution_time_for_speed: float = 5.0
    auto_improve_threshold: float = 0.9
    learning_window_days: int = 7
    pattern_match_threshold: float = 0.8
    enable_user_feedback: bool = True
    enable_auto_optimization: bool = True
    max_history_records: int = 1000


class SkillEvolutionStore:
    """Storage for skill evolution data."""

    MAX_EXECUTIONS = 1000

    def __init__(self, workspace_dir: Path):
        self.workspace_dir = workspace_dir
        self.evolution_dir = workspace_dir / "skill_evolution"
        self.evolution_dir.mkdir(parents=True, exist_ok=True)
        self.executions_file = self.evolution_dir / "executions.jsonl"
        self.metrics_file = self.evolution_dir / "metrics.json"
        self.patterns_file = self.evolution_dir / "patterns.json"
        self.improvements_file = self.evolution_dir / "improvements.json"
        self._executions_index: Dict[str, List[float]] = {}
        self.MAX_INDEX_ENTRIES_PER_SKILL = 500

    def _ensure_file_exists(self, filepath: Path) -> None:
        if not filepath.exists():
            filepath.write_text("{}" if filepath.suffix == ".json" else "", encoding="utf-8")

    def _rotate_jsonl(self, filepath: Path) -> None:
        if not filepath.exists():
            return
        try:
            lines = []
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        lines.append(line)
            if len(lines) > self.MAX_EXECUTIONS:
                with open(filepath, "w", encoding="utf-8") as f:
                    for line in lines[-self.MAX_EXECUTIONS:]:
                        f.write(line)
        except Exception as e:
            logger.warning(f"Failed to rotate {filepath}: {e}")

    def save_execution(self, record: ExecutionRecord) -> None:
        self._ensure_file_exists(self.executions_file)
        with open(self.executions_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record.__dict__, ensure_ascii=False) + "\n")
        self._rotate_jsonl(self.executions_file)
        if record.skill_name not in self._executions_index:
            self._executions_index[record.skill_name] = []
        self._executions_index[record.skill_name].append(record.timestamp)
        if len(self._executions_index[record.skill_name]) > self.MAX_INDEX_ENTRIES_PER_SKILL:
            self._executions_index[record.skill_name] = self._executions_index[record.skill_name][-self.MAX_INDEX_ENTRIES_PER_SKILL:]

    def get_executions(self, skill_name: str, limit: int = 100) -> List[ExecutionRecord]:
        """Get execution records for a skill."""
        if not self.executions_file.exists():
            return []

        records = []
        try:
            with open(self.executions_file, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        if data.get("skill_name") == skill_name:
                            records.append(ExecutionRecord(**data))
                    except (json.JSONDecodeError, TypeError):
                        continue

            return records[-limit:] if len(records) > limit else records
        except Exception as e:
            logger.error(f"Failed to read executions: {e}")
            return []

    def save_metrics(self, skill_name: str, metrics: SkillEvolutionMetrics) -> None:
        """Save skill metrics."""
        self._ensure_file_exists(self.metrics_file)
        try:
            all_metrics = {}
            if self.metrics_file.exists():
                content = self.metrics_file.read_text(encoding="utf-8")
                if content:
                    all_metrics = json.loads(content)

            all_metrics[skill_name] = {
                "total_executions": metrics.total_executions,
                "successful_executions": metrics.successful_executions,
                "failed_executions": metrics.failed_executions,
                "average_execution_time": metrics.average_execution_time,
                "success_rate": metrics.success_rate,
                "last_execution_time": metrics.last_execution_time,
                "last_success_time": metrics.last_success_time,
                "last_failure_time": metrics.last_failure_time,
                "common_patterns": metrics.common_patterns,
                "common_errors": metrics.common_errors,
                "improvement_history": metrics.improvement_history,
                "evolution_status": metrics.evolution_status.value,
                "confidence_score": metrics.confidence_score,
                "suggested_improvements": metrics.suggested_improvements,
                "updated_at": datetime.now().isoformat(),
            }

            tmp = self.metrics_file.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(all_metrics, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.metrics_file)
        except Exception as e:
            logger.error(f"Failed to save metrics for {skill_name}: {e}")

    def get_metrics(self, skill_name: str) -> Optional[SkillEvolutionMetrics]:
        """Get skill metrics."""
        if not self.metrics_file.exists():
            return None

        try:
            content = self.metrics_file.read_text(encoding="utf-8")
            if not content:
                return None

            all_metrics = json.loads(content)
            if skill_name not in all_metrics:
                return None

            data = all_metrics[skill_name]
            data["evolution_status"] = EvolutionStatus(data.get("evolution_status", "unknown"))
            return SkillEvolutionMetrics(**data)
        except Exception as e:
            logger.error(f"Failed to get metrics for {skill_name}: {e}")
            return None

    def save_patterns(self, skill_name: str, patterns: Dict[str, Any]) -> None:
        """Save learned patterns for a skill."""
        self._ensure_file_exists(self.patterns_file)
        try:
            all_patterns = {}
            if self.patterns_file.exists():
                content = self.patterns_file.read_text(encoding="utf-8")
                if content:
                    all_patterns = json.loads(content)

            all_patterns[skill_name] = {
                "patterns": patterns,
                "updated_at": datetime.now().isoformat(),
            }

            tmp = self.patterns_file.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(all_patterns, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.patterns_file)
        except Exception as e:
            logger.error(f"Failed to save patterns for {skill_name}: {e}")

    def get_patterns(self, skill_name: str) -> Dict[str, Any]:
        """Get learned patterns for a skill."""
        if not self.patterns_file.exists():
            return {}

        try:
            content = self.patterns_file.read_text(encoding="utf-8")
            if not content:
                return {}

            all_patterns = json.loads(content)
            return all_patterns.get(skill_name, {}).get("patterns", {})
        except Exception as e:
            logger.error(f"Failed to get patterns for {skill_name}: {e}")
            return {}

    def save_improvement(self, skill_name: str, improvement: Dict[str, Any]) -> None:
        """Save improvement record for a skill."""
        self._ensure_file_exists(self.improvements_file)
        try:
            all_improvements = {}
            if self.improvements_file.exists():
                content = self.improvements_file.read_text(encoding="utf-8")
                if content:
                    all_improvements = json.loads(content)

            if skill_name not in all_improvements:
                all_improvements[skill_name] = []

            all_improvements[skill_name].append({
                **improvement,
                "timestamp": datetime.now().isoformat(),
            })

            tmp = self.improvements_file.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(all_improvements, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.improvements_file)
        except Exception as e:
            logger.error(f"Failed to save improvement for {skill_name}: {e}")


class SkillSelfEvolution:
    """
    Skill Self-Evolution System

    Enables skills to learn and improve from experience through:
    - Execution tracking and analysis
    - Pattern recognition from successful executions
    - Error pattern detection and avoidance
    - User feedback integration
    - Performance optimization
    """

    def __init__(
        self,
        workspace_dir: Path,
        config: Optional[SkillEvolutionConfig] = None,
    ):
        self.store = SkillEvolutionStore(workspace_dir)
        self.config = config or SkillEvolutionConfig()

    def record_execution(
        self,
        skill_name: str,
        execution_time: float,
        success: bool,
        input_data: Any,
        output_data: Any,
        error: Optional[str] = None,
    ) -> None:
        """Record a skill execution for learning."""
        if not self.config.enabled:
            return

        input_summary = self._summarize_data(input_data)
        output_summary = self._summarize_data(output_data)

        record = ExecutionRecord(
            skill_name=skill_name,
            timestamp=time.time(),
            execution_time=execution_time,
            success=success,
            input_summary=input_summary,
            output_summary=output_summary,
            error_message=error,
        )

        self.store.save_execution(record)
        self._update_metrics(skill_name)

        if success and self._should_learn(skill_name):
            self._learn_from_success(skill_name, record)
        elif not success:
            self._learn_from_failure(skill_name, record)

    def record_user_feedback(
        self,
        skill_name: str,
        execution_timestamp: float,
        rating: int,
        feedback: Optional[str] = None,
    ) -> None:
        if not self.config.enabled or not self.config.enable_user_feedback:
            return

        executions = self.store.get_executions(skill_name)
        updated = False
        for record in reversed(executions):
            if abs(record.timestamp - execution_timestamp) < 1.0:
                record.user_rating = rating
                record.feedback = feedback
                updated = True
                break

        if updated:
            self.store.save_execution(ExecutionRecord(
                skill_name=skill_name,
                timestamp=execution_timestamp,
                execution_time=0,
                success=True,
                input_summary="feedback_update",
                output_summary=f"rating={rating}",
                user_rating=rating,
                feedback=feedback,
            ))

        self._update_metrics(skill_name)
        if rating >= 4:
            self._learn_from_positive_feedback(skill_name, rating, feedback)
        elif rating <= 2:
            self._learn_from_negative_feedback(skill_name, rating, feedback)

    def get_metrics(self, skill_name: str) -> SkillEvolutionMetrics:
        """Get evolution metrics for a skill."""
        metrics = self.store.get_metrics(skill_name)
        if metrics is None:
            metrics = SkillEvolutionMetrics()
            metrics.evolution_status = EvolutionStatus.UNKNOWN

        suggestions = self._generate_improvement_suggestions(skill_name, metrics)
        metrics.suggested_improvements = suggestions

        return metrics

    def get_all_metrics(self) -> Dict[str, SkillEvolutionMetrics]:
        """Get evolution metrics for all skills."""
        metrics_file = self.store.evolution_dir / "metrics.json"
        if not metrics_file.exists():
            return {}

        try:
            content = metrics_file.read_text(encoding="utf-8")
            if not content:
                return {}

            all_data = json.loads(content)
            result = {}
            for skill_name, data in all_data.items():
                data["evolution_status"] = EvolutionStatus(data.get("evolution_status", "unknown"))
                result[skill_name] = SkillEvolutionMetrics(**data)

            return result
        except Exception as e:
            logger.error(f"Failed to get all metrics: {e}")
            return {}

    def _should_learn(self, skill_name: str) -> bool:
        """Determine if the system should learn from recent executions."""
        metrics = self.store.get_metrics(skill_name)
        if metrics is None:
            return False

        if metrics.total_executions < self.config.min_samples_for_learning:
            return False

        if metrics.success_rate < self.config.min_success_rate_to_learn:
            return False

        return True

    def _update_metrics(self, skill_name: str) -> None:
        """Update metrics for a skill based on execution history."""
        executions = self.store.get_executions(skill_name)
        if not executions:
            return

        recent_cutoff = time.time() - (self.config.learning_window_days * 24 * 3600)
        recent_executions = [e for e in executions if e.timestamp >= recent_cutoff]

        if not recent_executions:
            return

        total = len(recent_executions)
        successful = sum(1 for e in recent_executions if e.success)
        failed = total - successful

        total_time = sum(e.execution_time for e in recent_executions)
        avg_time = total_time / total if total > 0 else 0.0

        last_exec = recent_executions[-1]
        last_success = max((e.timestamp for e in recent_executions if e.success), default=0.0)
        last_failure = max((e.timestamp for e in recent_executions if not e.success), default=0.0)

        common_errors = self._analyze_common_errors(recent_executions)
        common_patterns = self._analyze_common_patterns(recent_executions)

        success_rate = successful / total if total > 0 else 0.0
        confidence = self._calculate_confidence(recent_executions)

        status = self._determine_status(success_rate, avg_time, common_errors)

        metrics = SkillEvolutionMetrics(
            total_executions=total,
            successful_executions=successful,
            failed_executions=failed,
            average_execution_time=avg_time,
            success_rate=success_rate,
            last_execution_time=last_exec.timestamp,
            last_success_time=last_success,
            last_failure_time=last_failure,
            common_patterns=common_patterns,
            common_errors=common_errors,
            evolution_status=status,
            confidence_score=confidence,
        )

        self.store.save_metrics(skill_name, metrics)

    def _analyze_common_errors(self, executions: List[ExecutionRecord]) -> List[str]:
        """Analyze common errors from executions."""
        error_counts: Dict[str, int] = {}
        for exec in executions:
            if not exec.success and exec.error_message:
                error_key = self._normalize_error(exec.error_message)
                error_counts[error_key] = error_counts.get(error_key, 0) + 1

        sorted_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)
        return [e[0] for e in sorted_errors[:5]]

    def _analyze_common_patterns(self, executions: List[ExecutionRecord]) -> List[str]:
        """Analyze common success patterns from executions."""
        pattern_counts: Dict[str, int] = {}
        for exec in executions:
            if exec.success and exec.patterns_identified:
                for pattern in exec.patterns_identified:
                    pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1

        sorted_patterns = sorted(pattern_counts.items(), key=lambda x: x[1], reverse=True)
        return [p[0] for p in sorted_patterns[:5]]

    def _normalize_error(self, error: str) -> str:
        """Normalize error message for grouping."""
        error = error.lower().strip()
        error = error.replace("'", "").replace('"', "")
        words = error.split()
        if len(words) > 5:
            words = words[:5]
        return " ".join(words)

    def _calculate_confidence(self, executions: List[ExecutionRecord]) -> float:
        """Calculate confidence score based on consistency."""
        if len(executions) < 5:
            return 0.0

        successful = [e for e in executions if e.success]
        if not successful:
            return 0.0

        times = [e.execution_time for e in successful]
        avg_time = sum(times) / len(times)
        variance = sum((t - avg_time) ** 2 for t in times) / len(times)

        consistency = 1.0 / (1.0 + variance)
        coverage = min(len(successful) / self.config.min_samples_for_learning, 1.0)

        return (consistency * 0.4 + coverage * 0.6)

    def _determine_status(
        self,
        success_rate: float,
        avg_time: float,
        common_errors: List[str],
    ) -> EvolutionStatus:
        """Determine the evolution status of a skill."""
        if success_rate >= self.config.auto_improve_threshold:
            if avg_time <= self.config.max_execution_time_for_speed:
                return EvolutionStatus.STABLE
            return EvolutionStatus.LEARNING

        if success_rate >= 0.7:
            return EvolutionStatus.LEARNING

        if success_rate >= 0.5:
            return EvolutionStatus.EVOLVING

        if common_errors:
            return EvolutionStatus.DEGRADED

        return EvolutionStatus.UNKNOWN

    def _learn_from_success(self, skill_name: str, record: ExecutionRecord) -> None:
        """Learn from successful execution."""
        improvement = {
            "type": ImprovementType.ACCURACY.value,
            "description": f"Successful execution recorded at {datetime.now().isoformat()}",
            "execution_time": record.execution_time,
            "input_pattern": record.input_summary[:100],
        }

        patterns = self.store.get_patterns(skill_name)
        if "successful_inputs" not in patterns:
            patterns["successful_inputs"] = []

        patterns["successful_inputs"].append({
            "input": record.input_summary[:200],
            "timestamp": record.timestamp,
            "execution_time": record.execution_time,
        })

        if len(patterns["successful_inputs"]) > 100:
            patterns["successful_inputs"] = patterns["successful_inputs"][-100:]

        self.store.save_patterns(skill_name, patterns)
        self.store.save_improvement(skill_name, improvement)

    def _learn_from_failure(self, skill_name: str, record: ExecutionRecord) -> None:
        """Learn from failed execution."""
        improvement = {
            "type": ImprovementType.ERROR_REDUCTION.value,
            "description": f"Failure pattern recorded: {record.error_message}",
            "error": record.error_message,
        }

        patterns = self.store.get_patterns(skill_name)
        if "failure_patterns" not in patterns:
            patterns["failure_patterns"] = []

        patterns["failure_patterns"].append({
            "error": record.error_message,
            "input": record.input_summary[:200],
            "timestamp": record.timestamp,
        })

        if len(patterns["failure_patterns"]) > 50:
            patterns["failure_patterns"] = patterns["failure_patterns"][-50:]

        self.store.save_patterns(skill_name, patterns)
        self.store.save_improvement(skill_name, improvement)

    def _learn_from_positive_feedback(
        self,
        skill_name: str,
        rating: int,
        feedback: Optional[str],
    ) -> None:
        """Learn from positive user feedback."""
        improvement = {
            "type": ImprovementType.USER_FEEDBACK.value,
            "rating": rating,
            "feedback": feedback,
        }

        self.store.save_improvement(skill_name, improvement)

    def _learn_from_negative_feedback(
        self,
        skill_name: str,
        rating: int,
        feedback: Optional[str],
    ) -> None:
        """Learn from negative user feedback."""
        improvement = {
            "type": ImprovementType.USER_FEEDBACK.value,
            "rating": rating,
            "feedback": feedback,
            "needs_attention": True,
        }

        self.store.save_improvement(skill_name, improvement)

    def _generate_improvement_suggestions(
        self,
        skill_name: str,
        metrics: SkillEvolutionMetrics,
    ) -> List[str]:
        """Generate improvement suggestions based on metrics."""
        suggestions = []

        if metrics.success_rate < 0.7:
            suggestions.append(
                f"Success rate ({metrics.success_rate:.1%}) is below threshold. "
                "Consider reviewing error patterns and improving input validation."
            )

        if metrics.average_execution_time > self.config.max_execution_time_for_speed:
            suggestions.append(
                f"Average execution time ({metrics.average_execution_time:.2f}s) exceeds target. "
                "Consider optimizing the skill implementation."
            )

        if metrics.common_errors:
            suggestions.append(
                f"Common errors detected: {', '.join(metrics.common_errors[:3])}. "
                "Review these patterns to improve reliability."
            )

        if metrics.total_executions < self.config.min_samples_for_learning:
            suggestions.append(
                f"Only {metrics.total_executions} executions recorded. "
                f"Need {self.config.min_samples_for_learning} samples for meaningful analysis."
            )

        if metrics.confidence_score < 0.5:
            suggestions.append(
                f"Low confidence score ({metrics.confidence_score:.2f}). "
                "More consistent usage will improve recommendations."
            )

        if metrics.evolution_status == EvolutionStatus.STABLE:
            suggestions.append(
                "Skill is performing stably. Consider expanding its capabilities."
            )

        if metrics.evolution_status == EvolutionStatus.LEARNING:
            suggestions.append(
                "Skill is learning and improving. Continue using it to gather more data."
            )

        if not suggestions:
            suggestions.append("Skill is performing optimally. Keep up the good work!")

        return suggestions

    def _summarize_data(self, data: Any) -> str:
        """Create a summary of input/output data."""
        if data is None:
            return ""

        if isinstance(data, str):
            return data[:500]

        if isinstance(data, dict):
            keys = list(data.keys())[:10]
            return f"dict with keys: {', '.join(keys)}"

        if isinstance(data, (list, tuple)):
            return f"list with {len(data)} items"

        return str(type(data).__name__)

    def get_best_practices(self, skill_name: str) -> List[Dict[str, Any]]:
        """Get best practices learned from successful executions."""
        patterns = self.store.get_patterns(skill_name)
        successful_inputs = patterns.get("successful_inputs", [])

        if not successful_inputs:
            return []

        best_practices = []
        for item in successful_inputs[-10:]:
            best_practices.append({
                "input": item.get("input", ""),
                "execution_time": item.get("execution_time", 0),
                "timestamp": item.get("timestamp", 0),
            })

        return best_practices

    def should_recommend_skill(self, skill_name: str, task_type: str) -> tuple[bool, float]:
        """Check if a skill should be recommended for a task type."""
        metrics = self.get_metrics(skill_name)

        confidence = metrics.confidence_score
        success_rate = metrics.success_rate

        if metrics.total_executions < 3:
            return False, 0.0

        recommendation_score = (confidence * 0.4 + success_rate * 0.6)

        should_recommend = (
            recommendation_score >= 0.5 and
            metrics.evolution_status not in [EvolutionStatus.DEGRADED, EvolutionStatus.UNKNOWN]
        )

        return should_recommend, recommendation_score

    def get_evolution_report(self, skill_name: str) -> Dict[str, Any]:
        """Generate a comprehensive evolution report for a skill."""
        metrics = self.get_metrics(skill_name)
        patterns = self.store.get_patterns(skill_name)
        best_practices = self.get_best_practices(skill_name)

        return {
            "skill_name": skill_name,
            "metrics": {
                "total_executions": metrics.total_executions,
                "success_rate": metrics.success_rate,
                "average_execution_time": metrics.average_execution_time,
                "confidence_score": metrics.confidence_score,
                "evolution_status": metrics.evolution_status.value,
            },
            "patterns_learned": {
                "common_patterns": metrics.common_patterns,
                "common_errors": metrics.common_errors,
                "successful_inputs_count": len(patterns.get("successful_inputs", [])),
                "failure_patterns_count": len(patterns.get("failure_patterns", [])),
            },
            "best_practices": best_practices,
            "suggested_improvements": metrics.suggested_improvements,
            "generated_at": datetime.now().isoformat(),
        }


SkillEvolver = SkillSelfEvolution