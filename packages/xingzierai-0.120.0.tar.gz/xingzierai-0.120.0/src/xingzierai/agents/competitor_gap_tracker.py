# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core._logging import logger


class GapPriority(Enum):
    P0 = "P0"
    P1 = "P1"
    P2 = "P2"


class GapStatus(Enum):
    IMPLEMENTED = "implemented"
    IN_PROGRESS = "in_progress"
    PLANNED = "planned"
    DEFERRED = "deferred"


@dataclass
class CompetitorGap:
    id: str
    name: str
    description: str
    priority: GapPriority
    status: GapStatus
    competitor: str = ""
    evidence: str = ""
    implemented_at: str = ""
    notes: str = ""


BUILTIN_GAPS = [
    CompetitorGap(id="GAP-001", name="Process Sandbox", description="Sandboxed code execution environment", priority=GapPriority.P0, status=GapStatus.IMPLEMENTED, competitor="OpenAI"),
    CompetitorGap(id="GAP-002", name="Vector Retrieval", description="Semantic search with vector embeddings", priority=GapPriority.P0, status=GapStatus.IMPLEMENTED, competitor="Anthropic"),
    CompetitorGap(id="GAP-003", name="A2A Protocol", description="Agent-to-Agent standard protocol", priority=GapPriority.P0, status=GapStatus.IMPLEMENTED, competitor="Google"),
    CompetitorGap(id="GAP-004", name="Observability", description="Full observability stack (traces, metrics, logs)", priority=GapPriority.P0, status=GapStatus.IMPLEMENTED, competitor="Langfuse"),
    CompetitorGap(id="GAP-005", name="Computer Use", description="GUI interaction capability", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="Anthropic"),
    CompetitorGap(id="GAP-006", name="Durable Execution", description="Persistent workflow execution with checkpoints", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="Temporal"),
    CompetitorGap(id="GAP-007", name="MCP Server", description="Model Context Protocol server support", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="Anthropic"),
    CompetitorGap(id="GAP-008", name="Multi-Orchestration", description="Multiple orchestration patterns (Sequential/Parallel/Router/Debate)", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="CrewAI"),
    CompetitorGap(id="GAP-009", name="Adaptive Thinking", description="Dynamic reasoning depth based on task complexity", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="DeepSeek"),
    CompetitorGap(id="GAP-010", name="Encoding Gate", description="Code generation with quality gates", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="Cursor"),
    CompetitorGap(id="GAP-011", name="Executable Skills", description="Skills as executable Python modules (not just prompts)", priority=GapPriority.P1, status=GapStatus.IMPLEMENTED, competitor="AgentFactory"),
    CompetitorGap(id="GAP-012", name="Population Evolution", description="Multi-variant parallel evolution with selection", priority=GapPriority.P2, status=GapStatus.IMPLEMENTED, competitor="OpenAI"),
    CompetitorGap(id="GAP-013", name="Multimodal Memory", description="Memory supporting images, audio, and video", priority=GapPriority.P2, status=GapStatus.IMPLEMENTED, competitor="Google"),
    CompetitorGap(id="GAP-014", name="Retrieval Agent", description="Specialized agent for information retrieval", priority=GapPriority.P2, status=GapStatus.IMPLEMENTED, competitor="Perplexity"),
    CompetitorGap(id="GAP-015", name="Agent Payment Protocol", description="Standardized payment protocol for agent services", priority=GapPriority.P2, status=GapStatus.DEFERRED, competitor="OpenAI"),
    CompetitorGap(id="GAP-016", name="MCP Apps", description="MCP-based application marketplace", priority=GapPriority.P2, status=GapStatus.DEFERRED, competitor="Anthropic"),
]


class CompetitorGapTracker:
    """Track competitive gaps against industry benchmarks."""

    def __init__(self, state_path: Optional[str] = None):
        self._gaps: dict[str, CompetitorGap] = {}
        self._state_path = state_path
        for gap in BUILTIN_GAPS:
            self._gaps[gap.id] = gap
        if state_path:
            self._load_state(state_path)

    def get_gaps_by_priority(self, priority: str) -> list[CompetitorGap]:
        """Get gaps filtered by priority level."""
        try:
            p = GapPriority(priority)
        except ValueError:
            return []
        return [g for g in self._gaps.values() if g.priority == p]

    def get_gaps_by_status(self, status: str) -> list[CompetitorGap]:
        """Get gaps filtered by status."""
        try:
            s = GapStatus(status)
        except ValueError:
            return []
        return [g for g in self._gaps.values() if g.status == s]

    def update_gap_status(self, gap_id: str, status: str) -> Optional[CompetitorGap]:
        """Update the status of a gap."""
        gap = self._gaps.get(gap_id)
        if gap:
            try:
                gap.status = GapStatus(status)
                if status == "implemented":
                    gap.implemented_at = datetime.now().isoformat()
            except ValueError:
                pass
        return gap

    def suggest_evolution_direction(self) -> list[CompetitorGap]:
        """Suggest evolution directions based on gap priorities and status."""
        not_implemented = [
            g for g in self._gaps.values()
            if g.status in (GapStatus.PLANNED, GapStatus.DEFERRED)
        ]
        return sorted(not_implemented, key=lambda g: g.priority.value)

    def get_summary(self) -> dict:
        """Get a summary of all gaps."""
        total = len(self._gaps)
        by_status = {}
        by_priority = {}
        for gap in self._gaps.values():
            by_status[gap.status.value] = by_status.get(gap.status.value, 0) + 1
            by_priority[gap.priority.value] = by_priority.get(gap.priority.value, 0) + 1
        return {
            "total": total,
            "by_status": by_status,
            "by_priority": by_priority,
            "coverage": by_status.get("implemented", 0) / total * 100 if total > 0 else 0,
        }

    def _load_state(self, path: str) -> None:
        try:
            state_file = Path(path)
            if state_file.exists():
                data = json.loads(state_file.read_text(encoding="utf-8"))
                for gap_data in data.get("competitor_gaps", []):
                    gap = CompetitorGap(
                        id=gap_data.get("id", ""),
                        name=gap_data.get("name", ""),
                        description=gap_data.get("description", ""),
                        priority=GapPriority(gap_data.get("priority", "P2")),
                        status=GapStatus(gap_data.get("status", "planned")),
                        competitor=gap_data.get("competitor", ""),
                        evidence=gap_data.get("evidence", ""),
                        implemented_at=gap_data.get("implemented_at", ""),
                        notes=gap_data.get("notes", ""),
                    )
                    if gap.id:
                        self._gaps[gap.id] = gap
        except Exception as e:
            logger.debug("Failed to load competitor gap state from %s: %s", path, e)
