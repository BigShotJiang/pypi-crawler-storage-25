# -*- coding: utf-8 -*-
"""RolloutMixin - Integration mixin for adding rollout tracking to agents.

This module provides RolloutMixin that can be added to any agent
to enable tree-structured reasoning with backtracking.

Usage:
    class MyAgent(RolloutMixin, SomeBaseAgent):
        def __init__(self, ...):
            super().__init__(...)
            self._init_rollout(enable_rollout=True)

        async def some_method(self):
            self.record_llm_call(prompt, response)
            # ... rest of method
"""

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..agent_loop.rollout import (
    RolloutTree,
    RolloutNode,
    RolloutManager,
    Action,
    Observation,
    StateSnapshot,
    NodeStatus,
)
from ..agent_loop.branch_strategy import (
    SmartBranchSelector,
    AdaptiveBranchingController,
    BranchingPolicy,
)
from ..agent_loop.persistence import RolloutPersistence

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class RolloutMixin:
    """Mixin class that adds rollout tracking to any agent.

    This mixin provides:
    1. RolloutManager for tree-structured reasoning
    2. SmartBranchSelector for intelligent branching
    3. AdaptiveBranchingController for learning from failures
    4. RolloutPersistence for saving/loading rollout trees

    The mixin is designed to be non-invasive - it only adds
    optional tracking and doesn't modify base agent behavior.

    Usage:
        class MyAgent(RolloutMixin, SomeBaseAgent):
            pass

        # Or in __init__ of any class:
        self._init_rollout(enable_rollout=True)
    """

    def __init__(
        self,
        enable_rollout: bool = False,
        rollout_config: Optional[Dict[str, Any]] = None,
    ):
        """Initialize rollout tracking.

        Args:
            enable_rollout: Whether to enable rollout tracking
            rollout_config: Configuration for rollout system
        """
        self._rollout_enabled = enable_rollout
        self._rollout_config = rollout_config or {}
        self._rollout_manager: Optional[RolloutManager] = None
        self._rollout_tree: Optional[RolloutTree] = None
        self._branch_selector: Optional[SmartBranchSelector] = None
        self._branch_controller: Optional[AdaptiveBranchingController] = None
        self._persistence: Optional[RolloutPersistence] = None
        self._rollout_session_id: Optional[str] = None
        self._backtrack_count: int = 0
        self._start_time: float = 0.0

    def _init_rollout(
        self,
        enable_rollout: bool = True,
        session_id: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize rollout tracking subsystem.

        Call this in your agent's __init__ after super().__init__().

        Args:
            enable_rollout: Enable rollout tracking
            session_id: Optional session ID for persistence
            config: Optional configuration dict
        """
        self._rollout_enabled = enable_rollout
        self._rollout_config = config or {}
        self._rollout_session_id = session_id or f"session_{int(time.time())}"

        if enable_rollout:
            self._setup_rollout_manager()
            self._setup_branch_selector()
            self._setup_persistence()

            logger.info(
                f"Rollout tracking initialized for session {self._rollout_session_id}"
            )

    def _setup_rollout_manager(self) -> None:
        """Setup rollout manager."""
        max_depth = self._rollout_config.get("max_depth", 50)
        max_nodes = self._rollout_config.get("max_nodes", 500)

        self._rollout_manager = RolloutManager(
            max_depth=max_depth,
            max_nodes=max_nodes,
            branch_on_error=self._rollout_config.get("branch_on_error", True),
            backtrack_on_failed_validation=self._rollout_config.get(
                "backtrack_on_failed_validation", True
            ),
            auto_explore_branches=self._rollout_config.get("auto_explore_branches", False),
        )

        self._rollout_tree = self._rollout_manager.tree

        self._rollout_manager.on_backtrack(self._on_rollout_backtrack)
        self._rollout_manager.on_branch(self._on_rollout_branch)

    def _setup_branch_selector(self) -> None:
        """Setup branch selector and controller."""
        policy = BranchingPolicy(
            max_branches_per_node=self._rollout_config.get("max_branches_per_node", 3),
            max_total_branches=self._rollout_config.get("max_total_branches", 20),
            branch_on_error=self._rollout_config.get("branch_on_error", True),
            min_error_count_for_branch=self._rollout_config.get(
                "min_error_count_for_branch", 1
            ),
        )

        self._branch_selector = SmartBranchSelector(policy=policy)
        self._branch_controller = AdaptiveBranchingController(
            selector=self._branch_selector,
            learning_rate=self._rollout_config.get("learning_rate", 0.1),
        )

    def _setup_persistence(self) -> None:
        """Setup rollout persistence."""
        base_dir = self._rollout_config.get("persistence_dir", None)
        auto_save = self._rollout_config.get("auto_save", True)
        save_interval = self._rollout_config.get("save_interval", 30.0)

        self._persistence = RolloutPersistence(
            base_dir=base_dir,
            auto_save=auto_save,
            save_interval=save_interval,
        )

        if self._rollout_session_id and self._persistence.exists(self._rollout_session_id):
            loaded_tree = self._persistence.load(self._rollout_session_id)
            if loaded_tree:
                self._rollout_tree = loaded_tree
                self._rollout_manager = RolloutManager()
                self._rollout_manager._rollout_enabled = True
                logger.info(f"Restored rollout tree for session {self._rollout_session_id}")

    def initialize_rollout(
        self,
        initial_prompt: str,
        context: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[RolloutNode]:
        """Initialize a new rollout with initial prompt.

        Args:
            initial_prompt: User's initial prompt
            context: Initial conversation context

        Returns:
            Root node of the rollout tree, or None if disabled
        """
        if not self._rollout_enabled or not self._rollout_manager:
            return None

        self._start_time = time.time()

        context = context or []
        root = self._rollout_manager.initialize(
            initial_prompt=initial_prompt,
            context=context,
            budget=getattr(self, "budget", None),
            breaker=getattr(self, "breaker", None),
        )

        if self._persistence and self._rollout_session_id:
            self._persistence.save(self._rollout_session_id, self._rollout_tree)

        return root

    def record_llm_call(
        self,
        prompt: Any,
        response: Any,
        snapshot_before: bool = True,
    ) -> Optional[RolloutNode]:
        """Record an LLM call in the rollout tree.

        Args:
            prompt: The prompt sent to LLM
            response: The response from LLM
            snapshot_before: Whether to capture state before the call

        Returns:
            The created node, or None if rollout disabled
        """
        if not self._rollout_manager or not self._rollout_enabled:
            return None

        return self._rollout_manager.record_llm_call(
            prompt=prompt,
            response=response,
            snapshot_before=snapshot_before,
        )

    def record_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        result: Any,
        error: Optional[str] = None,
    ) -> Optional[RolloutNode]:
        """Record a tool call in the rollout tree.

        Args:
            tool_name: Name of the tool called
            arguments: Tool arguments
            result: Tool execution result
            error: Error message if tool failed

        Returns:
            The created node, or None if rollout disabled
        """
        if not self._rollout_manager or not self._rollout_enabled:
            return None

        node = self._rollout_manager.record_tool_call(
            tool_name=tool_name,
            arguments=arguments,
            result=result,
            error=error,
        )

        if error and self._branch_controller:
            branch_name = self._branch_selector.suggest_branch_type(
                error=error,
                task_complexity=0.5,
            )
            self._branch_controller.record_branch_used(branch_name, success=False)

        if self._should_persist():
            self._persist_rollout()

        return node

    def record_evaluation(
        self,
        verdict: str,
        score: float,
        issues: List[str],
    ) -> Optional[RolloutNode]:
        """Record an evaluation step.

        Args:
            verdict: Evaluation verdict (approve/reject/needs_revision)
            score: Evaluation score
            issues: List of issues found

        Returns:
            The created node, or None if rollout disabled
        """
        if not self._rollout_manager or not self._rollout_enabled:
            return None

        node = self._rollout_manager.record_evaluation(
            verdict=verdict,
            score=score,
            issues=issues,
        )

        if verdict == "reject" and self._branch_controller:
            current = self._rollout_manager.tree.get_current_node()
            if current:
                self._branch_controller.record_branch_outcome(
                    branch_name=current.branch_name or "unknown",
                    success=False,
                    final_node_id=current.id,
                )

        return node

    def trigger_backtrack(
        self,
        to_node_id: Optional[str] = None,
        reason: str = "evaluation_failed",
    ) -> Optional[Any]:
        """Trigger backtracking to a previous state.

        Args:
            to_node_id: Target node ID to backtrack to (current if None)
            reason: Reason for backtracking

        Returns:
            BacktrackResult, or None if failed
        """
        if not self._rollout_manager:
            return None

        result = self._rollout_manager.trigger_backtrack(
            to_node_id=to_node_id,
            reason=reason,
        )

        if result:
            self._backtrack_count += 1

            if self._branch_controller:
                current = self._rollout_manager.tree.get_current_node()
                if current:
                    self._branch_controller.record_branch_outcome(
                        branch_name=current.branch_name or "unknown",
                        success=False,
                        final_node_id=current.id,
                    )

            logger.info(
                f"Backtrack #{self._backtrack_count}: to={result.target_node_id}, "
                f"reason={reason}"
            )

            if self._should_persist():
                self._persist_rollout()

        return result

    def trigger_branch(
        self,
        branch_name: str,
        reason: str,
    ) -> Optional[RolloutNode]:
        """Trigger creation of an alternative branch.

        Args:
            branch_name: Name for the new branch
            reason: Reason for branching

        Returns:
            The new branch node, or None
        """
        if not self._rollout_manager:
            return None

        node = self._rollout_manager.trigger_branch(
            branch_name=branch_name,
            reason=reason,
        )

        if node and self._branch_selector:
            self._branch_selector.record_branch_used(branch_name)

        if node and self._should_persist():
            self._persist_rollout()

        return node

    def should_create_branch(self, error: Optional[str] = None) -> bool:
        """Determine if a new branch should be created.

        Args:
            error: Optional error message

        Returns:
            True if branching is recommended
        """
        if not self._branch_selector or not self._rollout_tree:
            return False

        current = self._rollout_tree.get_current_node()
        if not current:
            return False

        return self._branch_selector.should_create_branch(
            tree=self._rollout_tree,
            node_id=current.id,
            error=error,
        )

    def suggest_branch_type(self, error: Optional[str] = None) -> str:
        """Suggest the best branch type for the situation.

        Args:
            error: Optional error message

        Returns:
            Suggested branch type name
        """
        if self._branch_controller:
            return self._branch_controller.suggest_next_branch(error=error)

        if self._branch_selector:
            return self._branch_selector.suggest_branch_type(error=error)

        return "retry_different_approach"

    def get_rollout_tree(self) -> Optional[RolloutTree]:
        """Get the underlying rollout tree.

        Returns:
            The RolloutTree instance, or None if disabled
        """
        return self._rollout_tree

    def get_rollout_stats(self) -> Dict[str, Any]:
        """Get rollout statistics.

        Returns:
            Dict with rollout metrics
        """
        if not self._rollout_tree:
            return {"enabled": False}

        stats = self._rollout_tree.get_statistics()

        if self._branch_controller:
            controller_stats = self._branch_controller.get_statistics()
            stats["branch_confidences"] = controller_stats.get("confidence_scores", {})
            stats["success_rates"] = controller_stats.get("success_rates", {})

        stats["backtrack_count"] = self._backtrack_count
        stats["total_duration"] = time.time() - self._start_time if self._start_time > 0 else 0.0

        return stats

    def get_best_result(self) -> Dict[str, Any]:
        """Get the best result from the rollout tree.

        Returns:
            Dict with best path and result
        """
        if not self._rollout_manager:
            return {"path": [], "nodes": [], "result": None}

        return self._rollout_manager.get_best_result()

    def _on_rollout_backtrack(self, result: Any) -> None:
        """Internal callback for backtrack events."""
        logger.debug(
            f"Rollout backtrack: to={result.target_node_id}, "
            f"abandoned={result.abandoned_branch_size}"
        )

    def _on_rollout_branch(self, node: RolloutNode, reason: str) -> None:
        """Internal callback for branch events."""
        logger.debug(f"Rollout branch: {node.branch_name} from {reason}")

    def _should_persist(self) -> bool:
        """Check if rollout should be persisted now."""
        return (
            self._persistence is not None and
            self._rollout_session_id is not None and
            self._rollout_config.get("auto_save", True)
        )

    def _persist_rollout(self) -> None:
        """Persist rollout tree to disk."""
        if self._persistence and self._rollout_tree and self._rollout_session_id:
            self._persistence.save(self._rollout_session_id, self._rollout_tree)

    def clear_rollout(self) -> None:
        """Clear rollout tree and reset state."""
        if self._rollout_tree:
            self._rollout_tree = RolloutTree(
                max_depth=self._rollout_config.get("max_depth", 50),
                max_nodes=self._rollout_config.get("max_nodes", 500),
            )
            self._setup_rollout_manager()

        self._backtrack_count = 0

        if self._persistence and self._rollout_session_id:
            self._persistence.delete(self._rollout_session_id)

        logger.info(f"Rollout cleared for session {self._rollout_session_id}")

    @property
    def rollout_enabled(self) -> bool:
        """Check if rollout tracking is enabled."""
        return self._rollout_enabled

    @property
    def backtrack_count(self) -> int:
        """Get number of backtracks performed."""
        return self._backtrack_count


def create_rollout_agent_wrapper(
    agent: Any,
    enable_rollout: bool = True,
    session_id: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
) -> Any:
    """Create a wrapper that adds rollout tracking to any agent.

    This function monkey-patches the agent to add rollout capabilities
    without modifying the original class.

    Args:
        agent: The agent instance to wrap
        enable_rollout: Enable rollout tracking
        session_id: Optional session ID
        config: Optional configuration

    Returns:
        The same agent instance with rollout mixin applied
    """
    rollout = RolloutMixin()
    rollout._init_rollout(
        enable_rollout=enable_rollout,
        session_id=session_id,
        config=config,
    )

    for attr_name in dir(rollout):
        if attr_name.startswith("_init_rollout") or attr_name.startswith("record_") or attr_name.startswith("trigger_") or attr_name.startswith("should_") or attr_name.startswith("get_rollout") or attr_name.startswith("clear_rollout") or attr_name.startswith("_setup_") or attr_name.startswith("_on_rollout") or attr_name.startswith("_should_") or attr_name.startswith("_persist_") or attr_name in ("rollout_enabled", "backtrack_count", "initialize_rollout"):
            if not hasattr(agent, attr_name):
                setattr(agent, attr_name, getattr(rollout, attr_name))

    agent._rollout_mixin = rollout

    return agent
