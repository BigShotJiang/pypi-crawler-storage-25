# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core._logging import logger


class RuleSeverity(Enum):
    BLOCKING = "blocking"
    WARNING = "warning"
    FYI = "fyi"


@dataclass
class RuleViolation:
    rule_id: str
    rule_name: str
    severity: RuleSeverity
    message: str
    iron_law: str = ""
    entropy_type: str = ""
    line_number: int = 0


@dataclass
class Rule:
    id: str
    name: str
    category: str
    severity: RuleSeverity
    iron_law: str
    entropy_type: str
    violation_message: str
    check_pattern: str = ""
    check_fn: str = ""


ARCHITECTURE_IRON_LAWS = [
    Rule(
        id="AIL-1", name="chat_only_entry", category="architecture",
        severity=RuleSeverity.BLOCKING, iron_law="1", entropy_type="structural",
        violation_message="Chat is the only entry point for user interaction",
    ),
    Rule(
        id="AIL-2", name="local_model_priority", category="architecture",
        severity=RuleSeverity.WARNING, iron_law="2", entropy_type="thermodynamic",
        violation_message="Local small models should be preferred over cloud APIs",
    ),
    Rule(
        id="AIL-3", name="evolution_closed_loop", category="architecture",
        severity=RuleSeverity.WARNING, iron_law="3", entropy_type="cognitive",
        violation_message="Self-evolution must form a closed loop with verification",
    ),
    Rule(
        id="AIL-4", name="cross_session_persistence", category="architecture",
        severity=RuleSeverity.BLOCKING, iron_law="4", entropy_type="cognitive",
        violation_message="Critical data must persist across sessions",
    ),
    Rule(
        id="AIL-5", name="multi_agent_coordination", category="architecture",
        severity=RuleSeverity.WARNING, iron_law="5", entropy_type="structural",
        violation_message="Multi-agent coordination must use standard protocols",
    ),
    Rule(
        id="AIL-6", name="compliance_first", category="architecture",
        severity=RuleSeverity.BLOCKING, iron_law="6", entropy_type="information",
        violation_message="Compliance > Evaluation > Feature Extension",
    ),
]

ARCHITECTURE_RED_LINES = [
    Rule(
        id="ARL-1", name="no_global_shared_state", category="red_line",
        severity=RuleSeverity.BLOCKING, iron_law="2", entropy_type="structural",
        violation_message="No global mutable shared state between modules",
        check_fn="check_global_mutable_state",
    ),
    Rule(
        id="ARL-2", name="no_business_in_react_agent", category="red_line",
        severity=RuleSeverity.BLOCKING, iron_law="2", entropy_type="structural",
        violation_message="react_agent.py must not contain business logic",
    ),
    Rule(
        id="ARL-3", name="no_unpersisted_memory", category="red_line",
        severity=RuleSeverity.BLOCKING, iron_law="4", entropy_type="cognitive",
        violation_message="Memory must be persisted to disk, not held only in RAM",
    ),
    Rule(
        id="ARL-4", name="no_sync_http", category="red_line",
        severity=RuleSeverity.BLOCKING, iron_law="1", entropy_type="thermodynamic",
        violation_message="No synchronous HTTP calls in async context",
    ),
    Rule(
        id="ARL-5", name="no_api_breaking_changes", category="red_line",
        severity=RuleSeverity.BLOCKING, iron_law="6", entropy_type="information",
        violation_message="No breaking changes to public API without version bump",
    ),
    Rule(
        id="ARL-6", name="no_untested_logic", category="red_line",
        severity=RuleSeverity.WARNING, iron_law="3", entropy_type="information",
        violation_message="Business logic changes must include tests",
    ),
]

ENTROPY_REDUCTION_RULES = [
    Rule(
        id="ER-1", name="file_size_limit", category="entropy",
        severity=RuleSeverity.BLOCKING, iron_law="2", entropy_type="structural",
        violation_message="File exceeds 400 lines (Iron Law 2: Compartmentalization)",
        check_fn="check_file_size",
    ),
    Rule(
        id="ER-2", name="no_new_any_types", category="entropy",
        severity=RuleSeverity.WARNING, iron_law="3", entropy_type="information",
        violation_message="New `any` types increase information entropy (Iron Law 3: Negative Entropy Flow)",
        check_fn="check_any_types",
    ),
    Rule(
        id="ER-3", name="no_silent_catch", category="entropy",
        severity=RuleSeverity.BLOCKING, iron_law="5", entropy_type="cognitive",
        violation_message="Silent catch blocks destroy information (Iron Law 5: Information Conservation)",
        check_fn="check_silent_catch",
    ),
    Rule(
        id="ER-4", name="no_global_variables", category="entropy",
        severity=RuleSeverity.BLOCKING, iron_law="2", entropy_type="structural",
        violation_message="Module-level mutable global variables violate compartmentalization (Iron Law 2)",
        check_fn="check_global_mutable_vars",
    ),
    Rule(
        id="ER-5", name="no_important_css", category="entropy",
        severity=RuleSeverity.WARNING, iron_law="7", entropy_type="style",
        violation_message="!important increases style entropy (Iron Law 7: Delta First)",
        check_pattern=r"!important",
    ),
    Rule(
        id="ER-6", name="no_inline_isDark", category="entropy",
        severity=RuleSeverity.WARNING, iron_law="1", entropy_type="style",
        violation_message="Inline isDark ternary increases style entropy (Iron Law 1: Openness First)",
        check_fn="check_inline_isDark",
    ),
    Rule(
        id="ER-7", name="no_irreversible_ops", category="entropy",
        severity=RuleSeverity.WARNING, iron_law="4", entropy_type="cognitive",
        violation_message="Irreversible operations violate reversibility (Iron Law 4)",
    ),
]

DATA_PERSISTENCE_RULES = [
    Rule(
        id="DP-1", name="no_ram_only_memory", category="data_persistence",
        severity=RuleSeverity.BLOCKING, iron_law="4", entropy_type="cognitive",
        violation_message="Critical data must be persisted to disk, not held only in RAM",
        check_fn="check_ram_only_state",
    ),
    Rule(
        id="DP-2", name="no_unpersisted_session_data", category="data_persistence",
        severity=RuleSeverity.BLOCKING, iron_law="4", entropy_type="cognitive",
        violation_message="Session data must survive process restart",
    ),
    Rule(
        id="DP-3", name="write_before_confirm", category="data_persistence",
        severity=RuleSeverity.WARNING, iron_law="4", entropy_type="cognitive",
        violation_message="Data should be written to persistent storage before confirming to user",
    ),
]

KARPATHY_CODE_RULES = [
    Rule(
        id="KC-1", name="no_deep_nesting", category="karpathy",
        severity=RuleSeverity.WARNING, iron_law="2", entropy_type="structural",
        violation_message="Deep nesting (>4 levels) increases cognitive load",
        check_fn="check_deep_nesting",
    ),
    Rule(
        id="KC-2", name="no_magic_numbers", category="karpathy",
        severity=RuleSeverity.WARNING, iron_law="3", entropy_type="cognitive",
        violation_message="Magic numbers should be named constants",
        check_fn="check_magic_numbers",
    ),
    Rule(
        id="KC-3", name="no_long_functions", category="karpathy",
        severity=RuleSeverity.WARNING, iron_law="2", entropy_type="structural",
        violation_message="Functions exceeding 50 lines should be decomposed",
        check_fn="check_long_functions",
    ),
    Rule(
        id="KC-4", name="prefer_early_return", category="karpathy",
        severity=RuleSeverity.FYI, iron_law="2", entropy_type="structural",
        violation_message="Prefer early return over deep if-else nesting",
    ),
]

HOOK_SEPARATION_RULES = [
    Rule(
        id="HS-1", name="single_concern_per_hook", category="hook_separation",
        severity=RuleSeverity.WARNING, iron_law="2", entropy_type="structural",
        violation_message="Each React Hook should handle a single concern",
    ),
    Rule(
        id="HS-2", name="no_side_effects_in_render", category="hook_separation",
        severity=RuleSeverity.BLOCKING, iron_law="2", entropy_type="structural",
        violation_message="Side effects must not occur during render phase",
    ),
    Rule(
        id="HS-3", name="no_business_logic_in_ui_hook", category="hook_separation",
        severity=RuleSeverity.WARNING, iron_law="2", entropy_type="structural",
        violation_message="Business logic should not be mixed with UI rendering hooks",
    ),
]

_SILENT_CATCH_ALLOWED = frozenset({
    "NotImplementedError", "KeyboardInterrupt", "CancelledError",
    "SystemExit", "GeneratorExit", "asyncio.CancelledError",
})

_ANY_TYPE_PATTERN = re.compile(r":\s*any\b(?!\s*\()", re.IGNORECASE)
_ANY_TYPE_EXCLUDE = re.compile(r":\s*Any\b|from typing import|import typing", re.IGNORECASE)


class RuleEngine:
    """Project rule engine for checking architecture constraints and entropy reduction."""

    ALL_RULES = ARCHITECTURE_IRON_LAWS + ARCHITECTURE_RED_LINES + ENTROPY_REDUCTION_RULES + DATA_PERSISTENCE_RULES + KARPATHY_CODE_RULES + HOOK_SEPARATION_RULES

    def __init__(self):
        self._rules_by_category: dict[str, list[Rule]] = {}
        for rule in self.ALL_RULES:
            self._rules_by_category.setdefault(rule.category, []).append(rule)
        self._check_fns = {
            "check_global_mutable_state": self._check_global_mutable_state,
            "check_file_size": self._check_file_size_rule,
            "check_any_types": self._check_any_types,
            "check_silent_catch": self._check_silent_catch,
            "check_global_mutable_vars": self._check_global_mutable_vars,
            "check_inline_isDark": self._check_inline_isDark,
            "check_ram_only_state": self._check_ram_only_state,
            "check_deep_nesting": self._check_deep_nesting,
            "check_magic_numbers": self._check_magic_numbers,
            "check_long_functions": self._check_long_functions,
        }

    def check_file_content(
        self,
        file_path: str,
        content: str,
        categories: Optional[list[str]] = None,
    ) -> list[RuleViolation]:
        violations = []
        rules = self._get_rules(categories)

        for rule in rules:
            if rule.check_fn:
                fn = self._check_fns.get(rule.check_fn)
                if fn:
                    fn_violations = fn(file_path, content, rule)
                    violations.extend(fn_violations)
            elif rule.check_pattern:
                for i, line in enumerate(content.split("\n"), 1):
                    if re.search(rule.check_pattern, line):
                        violations.append(RuleViolation(
                            rule_id=rule.id, rule_name=rule.name,
                            severity=rule.severity, message=rule.violation_message,
                            iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                            line_number=i,
                        ))
                        break

        return violations

    def check_before_write(self, file_path: str, content: str) -> list[RuleViolation]:
        return self.check_file_content(file_path, content)

    def get_blocking_violations(self, violations: list[RuleViolation]) -> list[RuleViolation]:
        return [v for v in violations if v.severity == RuleSeverity.BLOCKING]

    def get_entropy_impact(self, violations: list[RuleViolation]) -> str:
        if not violations:
            return "neutral"
        if self.get_blocking_violations(violations):
            return "increasing"
        return "neutral"

    def format_violations(self, violations: list[RuleViolation]) -> str:
        if not violations:
            return "No rule violations found."
        lines = []
        for v in violations:
            icon = {"blocking": "🔴", "warning": "🟡", "fyi": "ℹ️"}.get(v.severity.value, "❓")
            line = f"{icon} [{v.rule_id}] {v.rule_name}: {v.message}"
            if v.iron_law:
                line += f" (Iron Law {v.iron_law})"
            if v.line_number:
                line += f" (line {v.line_number})"
            lines.append(line)
        return "\n".join(lines)

    def _get_rules(self, categories: Optional[list[str]] = None) -> list[Rule]:
        if not categories:
            return self.ALL_RULES
        rules = []
        for cat in categories:
            rules.extend(self._rules_by_category.get(cat, []))
        return rules

    def _check_global_mutable_state(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        violations = []
        mutable_types = {"dict", "list", "set", "defaultdict", "OrderedDict", "deque"}
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("\"\"\"") or stripped.startswith("'''"):
                continue
            if "=" not in stripped:
                continue
            if stripped.startswith("_") and stripped.endswith("= []") or stripped.endswith("= {}") or stripped.endswith("= set()"):
                prefix = stripped.split("=")[0].strip()
                if prefix.isupper():
                    continue
                violations.append(RuleViolation(
                    rule_id=rule.id, rule_name=rule.name,
                    severity=rule.severity, message=f"{rule.violation_message} (line: {stripped[:80]})",
                    iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                    line_number=i,
                ))
        return violations

    def _check_file_size_rule(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        line_count = content.count("\n") + 1
        ext = Path(file_path).suffix
        limit = 400
        if ext in (".css", ".less", ".scss"):
            limit = 300
        elif ext not in (".py", ".ts", ".tsx", ".js", ".jsx"):
            limit = 500
        if line_count > limit:
            return [RuleViolation(
                rule_id=rule.id, rule_name=rule.name,
                severity=rule.severity,
                message=f"{rule.violation_message} (current: {line_count} lines, limit: {limit})",
                iron_law=rule.iron_law, entropy_type=rule.entropy_type,
            )]
        return []

    def _check_any_types(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith((".ts", ".tsx")):
            return []
        violations = []
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("*") or stripped.startswith("/*"):
                continue
            if ": any" in stripped.lower() and ": any(" not in stripped.lower():
                if ": Any" not in stripped:
                    violations.append(RuleViolation(
                        rule_id=rule.id, rule_name=rule.name,
                        severity=rule.severity,
                        message=f"{rule.violation_message} (line: {stripped[:80]})",
                        iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                        line_number=i,
                    ))
                    break
        return violations

    def _check_ram_only_state(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith(".py"):
            return []
        violations = []
        ram_patterns = [
            (r"self\._\w+\s*:\s*dict\s*=\s*\{\}", "In-memory dict without disk persistence"),
            (r"self\._\w+\s*:\s*list\s*=\s*\[\]", "In-memory list without disk persistence"),
        ]
        for pattern, desc in ram_patterns:
            for i, line in enumerate(content.split("\n"), 1):
                if re.search(pattern, line):
                    violations.append(RuleViolation(
                        rule_id=rule.id, rule_name=rule.name,
                        severity=rule.severity,
                        message=f"{rule.violation_message} ({desc} at line {i})",
                        iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                        line_number=i,
                    ))
                    break
        return violations

    def _check_deep_nesting(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        violations = []
        max_nesting = 0
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or stripped.startswith("\"\"\"") or stripped.startswith("'''"):
                continue
            indent = len(line) - len(line.lstrip())
            if line.startswith(" "):
                nesting = indent // 4
                if nesting > max_nesting:
                    max_nesting = nesting
        if max_nesting > 4:
            violations.append(RuleViolation(
                rule_id=rule.id, rule_name=rule.name,
                severity=rule.severity,
                message=f"{rule.violation_message} (max nesting: {max_nesting} levels)",
                iron_law=rule.iron_law, entropy_type=rule.entropy_type,
            ))
        return violations

    def _check_magic_numbers(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith((".py", ".ts", ".tsx", ".js")):
            return []
        violations = []
        magic_pattern = re.compile(r'(?<![.\w])(\d{2,})+(?![.\w])')
        found = set()
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
                continue
            if "import " in stripped or "from " in stripped:
                continue
            for match in magic_pattern.finditer(stripped):
                num = match.group(1)
                if num not in ("0", "1", "2", "10", "100", "1000") and num not in found:
                    found.add(num)
        if len(found) > 3:
            violations.append(RuleViolation(
                rule_id=rule.id, rule_name=rule.name,
                severity=rule.severity,
                message=f"{rule.violation_message} (found {len(found)} magic numbers: {', '.join(list(found)[:5])})",
                iron_law=rule.iron_law, entropy_type=rule.entropy_type,
            ))
        return violations

    def _check_long_functions(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith(".py"):
            return []
        violations = []
        in_function = False
        func_name = ""
        func_start = 0
        func_indent = 0
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("def "):
                if in_function:
                    func_lines = i - func_start
                    if func_lines > 50:
                        violations.append(RuleViolation(
                            rule_id=rule.id, rule_name=rule.name,
                            severity=rule.severity,
                            message=f"{rule.violation_message} ({func_name}: {func_lines} lines)",
                            iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                            line_number=func_start,
                        ))
                in_function = True
                func_name = stripped.split("(")[0].replace("def ", "")
                func_start = i
                func_indent = len(line) - len(line.lstrip())
            elif in_function:
                if stripped and not stripped.startswith("#"):
                    current_indent = len(line) - len(line.lstrip())
                    if current_indent <= func_indent and stripped:
                        func_lines = i - func_start
                        if func_lines > 50:
                            violations.append(RuleViolation(
                                rule_id=rule.id, rule_name=rule.name,
                                severity=rule.severity,
                                message=f"{rule.violation_message} ({func_name}: {func_lines} lines)",
                                iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                                line_number=func_start,
                            ))
                        in_function = False
        if in_function:
            func_lines = content.count("\n") - func_start + 1
            if func_lines > 50:
                violations.append(RuleViolation(
                    rule_id=rule.id, rule_name=rule.name,
                    severity=rule.severity,
                    message=f"{rule.violation_message} ({func_name}: {func_lines} lines)",
                    iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                    line_number=func_start,
                ))
        return violations

    def _check_silent_catch(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        violations = []
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            match = re.match(r"except\s+(\w+)\s*:\s*pass", stripped)
            if match:
                exc_type = match.group(1)
                if exc_type not in _SILENT_CATCH_ALLOWED:
                    violations.append(RuleViolation(
                        rule_id=rule.id, rule_name=rule.name,
                        severity=rule.severity,
                        message=f"{rule.violation_message} (except {exc_type}: pass at line {i})",
                        iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                        line_number=i,
                    ))
        return violations

    def _check_global_mutable_vars(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith(".py"):
            return []
        violations = []
        mutable_assigns = re.compile(
            r"^([a-zA-Z_]\w*)\s*=\s*(\{|\[|set\(|dict\(|list\(|Dict|List|defaultdict)"
        )
        indent_level = 0
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("\"\"\"") or stripped.startswith("'''"):
                continue
            if stripped.startswith("def ") or stripped.startswith("class ") or stripped.startswith("@"):
                indent_level = len(line) - len(line.lstrip())
                continue
            if stripped.startswith("if ") or stripped.startswith("for ") or stripped.startswith("while "):
                continue
            current_indent = len(line) - len(line.lstrip())
            if current_indent > 0:
                continue
            match = mutable_assigns.match(stripped)
            if match:
                var_name = match.group(1)
                if var_name.isupper():
                    continue
                if var_name.startswith("_"):
                    continue
                violations.append(RuleViolation(
                    rule_id=rule.id, rule_name=rule.name,
                    severity=rule.severity,
                    message=f"{rule.violation_message} (variable: {var_name})",
                    iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                    line_number=i,
                ))
        return violations

    def _check_inline_isDark(self, file_path: str, content: str, rule: Rule) -> list[RuleViolation]:
        if not file_path.endswith((".tsx", ".jsx", ".ts", ".js")):
            return []
        violations = []
        for i, line in enumerate(content.split("\n"), 1):
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("*") or stripped.startswith("/*"):
                continue
            if "isDark" in stripped and "?" in stripped and ":" in stripped:
                if "isDark" in stripped.split("?")[0]:
                    violations.append(RuleViolation(
                        rule_id=rule.id, rule_name=rule.name,
                        severity=rule.severity,
                        message=f"{rule.violation_message} (line: {stripped[:80]})",
                        iron_law=rule.iron_law, entropy_type=rule.entropy_type,
                        line_number=i,
                    ))
                    break
        return violations
