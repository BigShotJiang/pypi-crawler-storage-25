#!/usr/bin/env python3
"""LLM Circuit Breaker - LLM调用熔断器

当某个模型连续失败时，自动熔断，避免持续重试浪费时间和资源。
熔断后进入半开状态，允许探测请求，成功则恢复。

状态机:
  CLOSED → (失败数达阈值) → OPEN → (冷却时间到) → HALF_OPEN → (探测成功) → CLOSED
                                                     → (探测失败) → OPEN

设计原则:
1. 每个模型独立熔断，互不影响
2. 熔断状态持久化到磁盘，重启后恢复
3. 线程安全，异步友好
4. MAX_BREAKERS限制，防止内存泄漏
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class BreakerState:
    model_name: str = ""
    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    opened_at: float = 0.0
    half_open_attempts: int = 0
    total_trips: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_name": self.model_name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "last_failure_time": self.last_failure_time,
            "last_success_time": self.last_success_time,
            "opened_at": self.opened_at,
            "half_open_attempts": self.half_open_attempts,
            "total_trips": self.total_trips,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BreakerState":
        return cls(
            model_name=data.get("model_name", ""),
            state=CircuitState(data.get("state", "closed")),
            failure_count=data.get("failure_count", 0),
            success_count=data.get("success_count", 0),
            last_failure_time=data.get("last_failure_time", 0.0),
            last_success_time=data.get("last_success_time", 0.0),
            opened_at=data.get("opened_at", 0.0),
            half_open_attempts=data.get("half_open_attempts", 0),
            total_trips=data.get("total_trips", 0),
        )


@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    success_threshold: int = 3
    cooldown_seconds: float = 60.0
    half_open_max_attempts: int = 1
    window_seconds: float = 300.0
    max_breakers: int = 50


class LLMCircuitBreaker:
    FAILURE_THRESHOLD = int(os.getenv("XINGZIERAI_CB_FAILURE_THRESHOLD", "5"))
    SUCCESS_THRESHOLD = int(os.getenv("XINGZIERAI_CB_SUCCESS_THRESHOLD", "3"))
    COOLDOWN_SECONDS = float(os.getenv("XINGZIERAI_CB_COOLDOWN", "60"))
    HALF_OPEN_MAX_ATTEMPTS = 1
    WINDOW_SECONDS = float(os.getenv("XINGZIERAI_CB_WINDOW", "300"))
    MAX_BREAKERS = 50
    MAX_COUNT = 1000
    STALE_OPEN_SECONDS = 3600
    ADAPTIVE_COOLDOWN_MULTIPLIER = 1.5
    MAX_COOLDOWN_SECONDS = 600

    _PERSIST_FILE = Path.home() / ".xingzierai" / "circuit_breakers.json"

    def __init__(self, config: Optional[CircuitBreakerConfig] = None):
        if config:
            self.FAILURE_THRESHOLD = config.failure_threshold
            self.SUCCESS_THRESHOLD = config.success_threshold
            self.COOLDOWN_SECONDS = config.cooldown_seconds
            self.HALF_OPEN_MAX_ATTEMPTS = config.half_open_max_attempts
            self.WINDOW_SECONDS = config.window_seconds
            self.MAX_BREAKERS = config.max_breakers

        self._breakers: Dict[str, BreakerState] = {}
        self._lock = asyncio.Lock()
        self._persist_count = 0
        self._persist_threshold = 5
        self._load()

    def _load(self):
        try:
            if self._PERSIST_FILE.exists():
                data = json.loads(self._PERSIST_FILE.read_text(encoding="utf-8"))
                for item in data.get("breakers", []):
                    bs = BreakerState.from_dict(item)
                    if bs.model_name:
                        if bs.state == CircuitState.OPEN and bs.opened_at > 0:
                            elapsed = time.time() - bs.opened_at
                            if elapsed > self.STALE_OPEN_SECONDS:
                                bs.state = CircuitState.HALF_OPEN
                                bs.half_open_attempts = 0
                                logger.info(
                                    "LLMCircuitBreaker: %s stale OPEN (%.0fh) → HALF_OPEN on load",
                                    bs.model_name, elapsed / 3600,
                                )
                        bs.failure_count = min(bs.failure_count, self.MAX_COUNT)
                        bs.success_count = min(bs.success_count, self.MAX_COUNT)
                        self._breakers[bs.model_name] = bs
                logger.info("LLMCircuitBreaker: loaded %d breaker states", len(self._breakers))
        except Exception as e:
            logger.warning("LLMCircuitBreaker: failed to load state: %s", e)

    def _persist(self):
        try:
            self._PERSIST_FILE.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "breakers": [bs.to_dict() for bs in self._breakers.values()],
                "saved_at": time.time(),
            }
            tmp = self._PERSIST_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._PERSIST_FILE)
        except Exception as e:
            logger.warning("LLMCircuitBreaker: failed to persist state: %s", e)

    def _maybe_persist(self):
        self._persist_count += 1
        if self._persist_count >= self._persist_threshold:
            self._persist_count = 0
            self._persist()

    def _get_or_create(self, model_name: str) -> BreakerState:
        if model_name not in self._breakers:
            if len(self._breakers) >= self.MAX_BREAKERS:
                oldest_key = min(self._breakers, key=lambda k: self._breakers[k].last_failure_time)
                del self._breakers[oldest_key]
            self._breakers[model_name] = BreakerState(model_name=model_name)
        return self._breakers[model_name]

    def _is_in_window(self, bs: BreakerState) -> bool:
        if bs.last_failure_time <= 0:
            return False
        return (time.time() - bs.last_failure_time) < self.WINDOW_SECONDS

    async def can_proceed(self, model_name: str) -> bool:
        async with self._lock:
            bs = self._get_or_create(model_name)

            if bs.state == CircuitState.CLOSED:
                return True

            if bs.state == CircuitState.OPEN:
                cooldown = min(
                    self.COOLDOWN_SECONDS * (self.ADAPTIVE_COOLDOWN_MULTIPLIER ** min(bs.total_trips, 5)),
                    self.MAX_COOLDOWN_SECONDS,
                )
                elapsed = time.time() - bs.opened_at
                if elapsed >= cooldown:
                    bs.state = CircuitState.HALF_OPEN
                    bs.half_open_attempts = 0
                    logger.info(
                        "LLMCircuitBreaker: %s OPEN→HALF_OPEN (cooled %.1fs, cooldown=%.1fs, trips=%d)",
                        model_name, elapsed, cooldown, bs.total_trips,
                    )
                    self._maybe_persist()
                    return True
                return False

            if bs.state == CircuitState.HALF_OPEN:
                if bs.half_open_attempts < self.HALF_OPEN_MAX_ATTEMPTS:
                    return True
                return False

            return True

    async def record_success(self, model_name: str):
        async with self._lock:
            bs = self._get_or_create(model_name)
            bs.success_count = min(bs.success_count + 1, self.MAX_COUNT)
            bs.last_success_time = time.time()

            if bs.state == CircuitState.HALF_OPEN:
                if bs.success_count >= self.SUCCESS_THRESHOLD:
                    bs.state = CircuitState.CLOSED
                    bs.failure_count = 0
                    bs.success_count = 0
                    bs.half_open_attempts = 0
                    logger.info("LLMCircuitBreaker: %s HALF_OPEN→CLOSED (recovered)", model_name)
                else:
                    bs.half_open_attempts += 1
            elif bs.state == CircuitState.CLOSED:
                if self._is_in_window(bs):
                    bs.failure_count = max(0, bs.failure_count - 1)

            self._maybe_persist()

    async def record_failure(self, model_name: str):
        async with self._lock:
            bs = self._get_or_create(model_name)
            bs.failure_count = min(bs.failure_count + 1, self.MAX_COUNT)
            bs.last_failure_time = time.time()

            if bs.state == CircuitState.HALF_OPEN:
                bs.state = CircuitState.OPEN
                bs.opened_at = time.time()
                bs.total_trips += 1
                bs.half_open_attempts = 0
                logger.warning(
                    "LLMCircuitBreaker: %s HALF_OPEN→OPEN (probe failed, trips=%d)",
                    model_name, bs.total_trips,
                )
            elif bs.state == CircuitState.CLOSED:
                if bs.failure_count >= self.FAILURE_THRESHOLD:
                    bs.state = CircuitState.OPEN
                    bs.opened_at = time.time()
                    bs.total_trips += 1
                    logger.warning(
                        "LLMCircuitBreaker: %s CLOSED→OPEN (failures=%d, trips=%d)",
                        model_name, bs.failure_count, bs.total_trips,
                    )

            self._maybe_persist()

    async def get_state(self, model_name: str) -> CircuitState:
        async with self._lock:
            bs = self._get_or_create(model_name)
            if bs.state == CircuitState.OPEN:
                elapsed = time.time() - bs.opened_at
                if elapsed >= self.COOLDOWN_SECONDS:
                    bs.state = CircuitState.HALF_OPEN
                    bs.half_open_attempts = 0
            return bs.state

    async def reset(self, model_name: str):
        async with self._lock:
            if model_name in self._breakers:
                self._breakers[model_name] = BreakerState(model_name=model_name)
                self._maybe_persist()
                logger.info("LLMCircuitBreaker: %s reset to CLOSED", model_name)

    async def reset_all(self):
        async with self._lock:
            self._breakers.clear()
            self._persist()
            logger.info("LLMCircuitBreaker: all breakers reset")

    def get_stats(self) -> Dict[str, Any]:
        result = {}
        for name, bs in self._breakers.items():
            result[name] = {
                "state": bs.state.value,
                "failure_count": bs.failure_count,
                "success_count": bs.success_count,
                "total_trips": bs.total_trips,
                "last_failure_ago": round(time.time() - bs.last_failure_time, 1) if bs.last_failure_time > 0 else None,
                "opened_ago": round(time.time() - bs.opened_at, 1) if bs.opened_at > 0 else None,
            }
        return result


_default_breaker: Optional["LLMCircuitBreaker"] = None


def get_circuit_breaker(config: Optional[CircuitBreakerConfig] = None) -> LLMCircuitBreaker:
    global _default_breaker
    if _default_breaker is None:
        _default_breaker = LLMCircuitBreaker(config)
    return _default_breaker


__all__ = [
    "LLMCircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitState",
    "BreakerState",
    "get_circuit_breaker",
]
