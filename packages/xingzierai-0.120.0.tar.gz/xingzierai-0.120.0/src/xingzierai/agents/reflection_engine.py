# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from xingzierai.agentscope_core._logging import logger


class ReflectionCategory(Enum):
    NEW_DIRECTION = "new_direction"
    NEW_BUG_PATTERN = "new_bug_pattern"
    HIGH_RISK_MODULE = "high_risk_module"
    CODE_QUALITY = "code_quality"
    PERFORMANCE = "performance"
    ARCHITECTURE = "architecture"


class ActionableStatus(Enum):
    PENDING = "pending"
    APPLIED = "applied"
    DISMISSED = "dismissed"


@dataclass
class ActionableItem:
    category: ReflectionCategory
    title: str
    description: str
    priority: str
    target: str
    status: ActionableStatus = ActionableStatus.PENDING
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


REFLECTION_QUESTIONS = [
    "Did the change achieve its stated goal?",
    "Were there any unexpected side effects?",
    "Is the code more or less complex after this change?",
    "Did this change introduce any new dependencies?",
    "Are there any new edge cases to consider?",
    "Could this change affect performance?",
    "Is there a simpler way to achieve the same result?",
    "Does this change follow the project's architecture principles?",
    "Were any existing patterns broken by this change?",
    "Should any documentation be updated?",
    "Are there any new bug patterns to record?",
    "Is there a new evolution direction to explore?",
    "Should any module be flagged as high-risk?",
    "Does this change affect the entropy index?",
]


class ReflectionEngine:
    """Reflection engine that converts execution results into actionable improvements.

    After each evolution cycle or significant code change, this engine
    analyzes the results and generates actionable items that feed back
    into the next cycle.
    """

    def __init__(self):
        self._history: list[dict] = []

    def reflect(self, execution_result: dict) -> list[ActionableItem]:
        """Analyze execution results and extract actionable items.

        Args:
            execution_result: Dict containing:
                - goal: What was attempted
                - outcome: success/partial/failure
                - changes: List of file changes
                - errors: List of errors encountered
                - metrics: Performance/quality metrics

        Returns:
            List of actionable items for the next cycle
        """
        items = []

        goal = execution_result.get("goal", "")
        outcome = execution_result.get("outcome", "unknown")
        errors = execution_result.get("errors", [])
        changes = execution_result.get("changes", [])
        metrics = execution_result.get("metrics", {})

        if errors:
            for error in errors:
                error_str = str(error)
                items.append(ActionableItem(
                    category=ReflectionCategory.NEW_BUG_PATTERN,
                    title=f"Bug pattern from error: {error_str[:60]}",
                    description=error_str,
                    priority="P1",
                    target="bug_pattern_kb",
                ))

        if outcome == "partial":
            items.append(ActionableItem(
                category=ReflectionCategory.CODE_QUALITY,
                title=f"Incomplete execution: {goal[:60]}",
                description=f"Goal was only partially achieved: {goal}",
                priority="P1",
                target="direction_priority",
            ))

        if len(changes) > 5:
            items.append(ActionableItem(
                category=ReflectionCategory.HIGH_RISK_MODULE,
                title=f"Large change set: {len(changes)} files",
                description=f"Changes touched {len(changes)} files, consider splitting",
                priority="P2",
                target="audit_scope",
            ))

        entropy_change = metrics.get("entropy_change", 0)
        if entropy_change > 0:
            items.append(ActionableItem(
                category=ReflectionCategory.ARCHITECTURE,
                title=f"Entropy increased by {entropy_change:.1f}",
                description="This change increased system entropy. Consider refactoring.",
                priority="P1",
                target="direction_priority",
            ))

        if metrics.get("new_dependencies"):
            items.append(ActionableItem(
                category=ReflectionCategory.NEW_DIRECTION,
                title="New dependencies introduced",
                description=f"New deps: {metrics['new_dependencies']}",
                priority="P2",
                target="direction_priority",
            ))

        self._history.append({
            "timestamp": datetime.now().isoformat(),
            "goal": goal,
            "outcome": outcome,
            "items_generated": len(items),
        })

        return items

    def auto_convert(self, items: list[ActionableItem]) -> dict:
        """Convert actionable items into state updates.

        Returns:
            Dict with keys matching state.json structure:
            - direction_priority: New evolution directions
            - bug_patterns: New bug pattern candidates
            - audit_scope: Updated audit scope
        """
        updates = {
            "direction_priority": [],
            "bug_patterns": [],
            "audit_scope": {"high_risk_modules": []},
        }

        for item in items:
            if item.status != ActionableStatus.PENDING:
                continue

            if item.category == ReflectionCategory.NEW_DIRECTION:
                updates["direction_priority"].append({
                    "direction": item.title,
                    "priority": item.priority,
                    "description": item.description,
                })
                item.status = ActionableStatus.APPLIED

            elif item.category == ReflectionCategory.NEW_BUG_PATTERN:
                updates["bug_patterns"].append({
                    "title": item.title,
                    "description": item.description,
                    "source": "reflection",
                    "severity": "medium",
                    "status": "candidate",
                })
                item.status = ActionableStatus.APPLIED

            elif item.category == ReflectionCategory.HIGH_RISK_MODULE:
                updates["audit_scope"]["high_risk_modules"].append(item.target)
                item.status = ActionableStatus.APPLIED

        return updates

    def get_reflection_questions(self) -> list[str]:
        """Get the standard reflection questions for post-evolution review."""
        return REFLECTION_QUESTIONS.copy()
