# -*- coding: utf-8 -*-
"""Evolution Bridges - Connects DataFlywheel, Kappa, and Evolution Daemon
to the LocalModelDispatcher for unified self-evolution.

Bridges:
1. DataFlywheelBridge: High-quality interactions → training data
2. KappaTrainingBridge: Experience packs → SFT training data
3. EvolutionModelSync: Daemon code changes → model validation
4. QualityValidator: Validate model output before deployment
5. ModelVersionManager: Version tracking + rollback
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_VERSIONS_DIR = Path.home() / ".xingzierai" / "model_versions"


class DataFlywheelBridge:
    """Bridges DataFlywheel interactions to TrainingDataCollector.

    Only high-quality interactions (user rating >= 4, auto_audit = PASS)
    are forwarded as training data. Bad cases go to Kappa instead.
    """

    def __init__(self):
        self._last_sync_time: Optional[datetime] = None

    def sync_interactions(self, max_records: int = 100) -> Dict[str, int]:
        try:
            from ..data_flywheel import DataFlywheel, FeedbackChannel, AuditResult
            from .local_model_dispatcher import LocalModelDispatcher

            flywheel = DataFlywheel()
            dispatcher = LocalModelDispatcher.get_instance()

            records = flywheel.collector.get_recent(hours=168)
            if not records:
                return {"synced": 0, "skipped": 0}

            feedbacks = list(flywheel.feedback._feedbacks)
            feedback_by_interaction = {}
            for fb in feedbacks:
                feedback_by_interaction[fb.interaction_id] = fb

            synced = 0
            skipped = 0

            for record in records[-max_records:]:
                fb = feedback_by_interaction.get(record.id)
                if not fb:
                    if record.success and record.latency_ms < 15000:
                        task_type = self._classify_interaction(record)
                        if task_type:
                            dispatcher.collect_training_data(
                                task_type=task_type,
                                input_text=record.user_input[:4000],
                                output_text=record.system_output[:4000],
                            )
                            synced += 1
                        else:
                            skipped += 1
                    else:
                        skipped += 1
                    continue

                if fb.channel == FeedbackChannel.AUTO_AUDIT and fb.audit_result == AuditResult.PASS:
                    task_type = self._classify_interaction(record)
                    if task_type:
                        dispatcher.collect_training_data(
                            task_type=task_type,
                            input_text=record.user_input[:4000],
                            output_text=record.system_output[:4000],
                        )
                        synced += 1
                    else:
                        skipped += 1
                elif fb.channel == FeedbackChannel.USER and fb.rating >= 4:
                    task_type = self._classify_interaction(record)
                    if task_type:
                        dispatcher.collect_training_data(
                            task_type=task_type,
                            input_text=record.user_input[:4000],
                            output_text=record.system_output[:4000],
                        )
                        synced += 1
                    else:
                        skipped += 1
                else:
                    skipped += 1

            self._last_sync_time = datetime.now()
            logger.info("DataFlywheelBridge synced %d records, skipped %d", synced, skipped)
            return {"synced": synced, "skipped": skipped}

        except Exception as e:
            logger.error("DataFlywheelBridge sync failed: %s", e)
            return {"synced": 0, "skipped": 0, "error": str(e)}

    def _classify_interaction(self, record) -> Optional[str]:
        meta = record.metadata or {}
        explicit_type = meta.get("task_type")
        if explicit_type:
            return explicit_type

        output = record.system_output.lower()
        user_input = record.user_input.lower()

        if any(kw in output for kw in ["摘要", "总结", "summary", "compress"]):
            return "memory_compact"
        if any(kw in output for kw in ["事实", "关键信息", "fact", "key point"]):
            return "fact_extract"
        if any(kw in user_input for kw in ["搜索", "检索", "search", "query", "查找"]):
            return "query_rewrite"

        return None


class KappaTrainingBridge:
    """Bridges Kappa experience packs to SFT training data.

    When an experience pack reaches ACTIVE status (validated 6+ times),
    it's converted to SFT format and fed to TrainingDataCollector.
    """

    def sync_experience_packs(self) -> Dict[str, int]:
        try:
            from .evolution.kappa import KappaEngine, ExperienceStatus
            from .local_model_dispatcher import LocalModelDispatcher

            kappa = KappaEngine()
            dispatcher = LocalModelDispatcher.get_instance()

            all_packs = kappa.get_all_packs()
            synced = 0
            skipped = 0

            for pack in all_packs:
                if pack.status != ExperienceStatus.ACTIVE:
                    skipped += 1
                    continue

                if pack.confidence < 0.5:
                    skipped += 1
                    continue

                prompt = self._pack_to_prompt(pack)
                response = self._pack_to_response(pack)

                if prompt and response:
                    dispatcher.collect_training_data(
                        task_type="kappa_skill",
                        input_text=prompt[:4000],
                        output_text=response[:4000],
                    )
                    synced += 1
                else:
                    skipped += 1

            logger.info("KappaTrainingBridge synced %d packs, skipped %d", synced, skipped)
            return {"synced": synced, "skipped": skipped}

        except Exception as e:
            logger.error("KappaTrainingBridge sync failed: %s", e)
            return {"synced": 0, "skipped": 0, "error": str(e)}

    def _pack_to_prompt(self, pack) -> str:
        parts = []
        if pack.trigger_conditions:
            parts.append("触发条件: " + "; ".join(pack.trigger_conditions))
        if pack.description:
            parts.append("描述: " + pack.description)
        if pack.pre_conditions:
            parts.append("前置条件: " + "; ".join(pack.pre_conditions))
        return "\n".join(parts) if parts else ""

    def _pack_to_response(self, pack) -> str:
        parts = []
        if pack.solution:
            parts.append("解决方案: " + pack.solution)
        if pack.anti_patterns:
            parts.append("避免: " + "; ".join(pack.anti_patterns))
        if pack.post_conditions:
            parts.append("后置条件: " + "; ".join(pack.post_conditions))
        return "\n".join(parts) if parts else ""


class QualityValidator:
    """Validates local model output quality before deployment.

    Compares local model output against LLM output on a set of test inputs.
    Only deploys if the local model passes quality threshold.
    """

    async def validate(
        self,
        task_type: str,
        model_path: str,
        tokenizer_path: str,
        test_inputs: Optional[List[str]] = None,
        llm_fn=None,
        min_similarity: float = 0.3,
    ) -> Dict[str, Any]:
        try:
            from .local_model_dispatcher import _LocalModelEntry

            entry = _LocalModelEntry(task_type, model_path, tokenizer_path)
            if not entry._load():
                return {"passed": False, "reason": "model_load_failed", "error": entry._load_error}

            if test_inputs is None:
                test_inputs = self._default_test_inputs(task_type)

            if not test_inputs:
                return {"passed": True, "reason": "no_test_inputs", "scores": []}

            scores = []
            for test_input in test_inputs:
                local_output = entry.generate(test_input, max_new_tokens=128, temperature=0.3)
                if local_output is None:
                    scores.append(0.0)
                    continue

                if llm_fn is not None:
                    try:
                        import asyncio
                        if asyncio.iscoroutinefunction(llm_fn):
                            llm_output = await llm_fn(test_input)
                        else:
                            llm_output = llm_fn(test_input)
                        score = self._compute_similarity(local_output, llm_output) if llm_output else 0.0
                    except Exception as _sim_err:
                        logger.debug("LLM similarity comparison failed: %s", _sim_err)
                        score = self._heuristic_score(local_output, task_type)
                else:
                    score = self._heuristic_score(local_output, task_type)

                scores.append(score)

            avg_score = sum(scores) / len(scores) if scores else 0
            passed = avg_score >= min_similarity

            return {
                "passed": passed,
                "avg_score": round(avg_score, 3),
                "scores": [round(s, 3) for s in scores],
                "threshold": min_similarity,
            }

        except Exception as e:
            return {"passed": False, "reason": "validation_error", "error": str(e)}

    def _default_test_inputs(self, task_type: str) -> List[str]:
        defaults = {
            "memory_compact": [
                "User: 你好，我想了解一下Python编程\nAssistant: Python是一种流行的编程语言...",
                "User: 帮我查一下明天的天气\nAssistant: 明天北京晴，温度15-25度",
                "User: 什么是机器学习？\nAssistant: 机器学习是AI的一个分支，通过数据训练模型...",
            ],
            "fact_extract": [
                "张三是一名软件工程师，他在北京工作，擅长Python和Java。",
                "会议定于明天下午3点在3号会议室举行，主题是Q3规划。",
                "这个项目的截止日期是下周五，需要完成前端和后端的集成测试。",
            ],
            "query_rewrite": [
                "怎么用Python",
                "天气怎么样",
                "机器学习入门",
            ],
        }
        return defaults.get(task_type, [])

    def _compute_similarity(self, output_a: str, output_b: str) -> float:
        if not output_a or not output_b:
            return 0.0
        semantic = self._semantic_similarity(output_a, output_b)
        if semantic is not None:
            return semantic
        set_a = set(output_a.lower().split())
        set_b = set(output_b.lower().split())
        if not set_a or not set_b:
            return 0.0
        intersection = set_a & set_b
        union = set_a | set_b
        return len(intersection) / len(union)

    def _semantic_similarity(self, text_a: str, text_b: str) -> Optional[float]:
        try:
            from .embedding_loader import get_embedder
            import numpy as np
            loader = get_embedder()
            loader.preload("paraphrase-multilingual-MiniLM-L12-v2")
            if not loader.is_available:
                return None
            embeddings = loader.encode([text_a[:512], text_b[:512]])
            a_norm = embeddings[0] / (np.linalg.norm(embeddings[0]) + 1e-10)
            b_norm = embeddings[1] / (np.linalg.norm(embeddings[1]) + 1e-10)
            return float(np.dot(a_norm, b_norm))
        except Exception as _embed_err:
            logger.debug("Embedding similarity failed: %s", _embed_err)
            return None

    def _heuristic_score(self, output: str, task_type: str) -> float:
        if not output or len(output.strip()) < 5:
            return 0.0
        if len(output) > 500:
            return 0.3
        if any(kw in output for kw in ["错误", "error", "失败", "failed"]):
            return 0.2
        return 0.5


class ModelVersionManager:
    """Manages model versions with rollback capability.

    Each time a model is registered for a task, the previous version
    is archived. If the new model performs poorly, it can be rolled back.
    """

    def __init__(self):
        _VERSIONS_DIR.mkdir(parents=True, exist_ok=True)

    def archive_current(self, task_type: str) -> Optional[str]:
        try:
            from .local_model_dispatcher import LocalModelDispatcher

            dispatcher = LocalModelDispatcher.get_instance()
            if not dispatcher.has_local_model(task_type):
                return None

            entry = dispatcher.get_model_entry(task_type)
            if not entry:
                return None

            version_id = f"v_{int(time.time())}"
            version_dir = _VERSIONS_DIR / task_type / version_id
            version_dir.mkdir(parents=True, exist_ok=True)

            model_src = Path(entry.model_path)
            tokenizer_src = Path(entry.tokenizer_path)

            if model_src.exists():
                if model_src.is_dir():
                    shutil.copytree(model_src, version_dir / model_src.name, dirs_exist_ok=True)
                else:
                    shutil.copy2(model_src, version_dir / model_src.name)
            if tokenizer_src.exists():
                if tokenizer_src.is_dir():
                    shutil.copytree(tokenizer_src, version_dir / tokenizer_src.name, dirs_exist_ok=True)
                else:
                    shutil.copy2(tokenizer_src, version_dir / tokenizer_src.name)

            meta = {
                "version_id": version_id,
                "task_type": task_type,
                "model_path": entry.model_path,
                "tokenizer_path": entry.tokenizer_path,
                "archived_at": datetime.now().isoformat(),
            }
            (version_dir / "meta.json").write_text(
                json.dumps(meta, ensure_ascii=False, indent=2)
            )

            logger.info("Archived model version %s for task %s", version_id, task_type)
            return version_id

        except Exception as e:
            logger.error("Failed to archive model version: %s", e)
            return None

    def list_versions(self, task_type: str) -> List[Dict[str, Any]]:
        task_dir = _VERSIONS_DIR / task_type
        if not task_dir.exists():
            return []
        versions = []
        for v_dir in sorted(task_dir.iterdir()):
            if v_dir.is_dir():
                meta_file = v_dir / "meta.json"
                if meta_file.exists():
                    try:
                        meta = json.loads(meta_file.read_text(encoding="utf-8"))
                        versions.append(meta)
                    except Exception as _meta_err:
                        logger.debug("Skipping corrupt version meta %s: %s", meta_file, _meta_err)
        return versions

    async def rollback(self, task_type: str, version_id: Optional[str] = None) -> bool:
        try:
            from .local_model_dispatcher import LocalModelDispatcher

            versions = self.list_versions(task_type)
            if not versions:
                logger.warning("No versions to rollback for task %s", task_type)
                return False

            if version_id is None:
                target = versions[-1]
            else:
                target = next((v for v in versions if v["version_id"] == version_id), None)
                if target is None:
                    logger.warning("Version %s not found for task %s", version_id, task_type)
                    return False

            version_dir = _VERSIONS_DIR / task_type / target["version_id"]
            model_path = str(version_dir / Path(target["model_path"]).name)
            tokenizer_path = str(version_dir / Path(target["tokenizer_path"]).name)

            if not Path(model_path).exists():
                logger.error("Model file not found: %s", model_path)
                return False

            dispatcher = LocalModelDispatcher.get_instance()
            await dispatcher.register_local_model(task_type, model_path, tokenizer_path)
            logger.info("Rolled back task %s to version %s", task_type, target["version_id"])
            return True

        except Exception as e:
            logger.error("Rollback failed: %s", e)
            return False


class EvolutionModelSync:
    """Syncs Evolution Daemon code changes with LocalModelDispatcher.

    After the daemon modifies code, this bridge:
    1. Notifies the dispatcher that models may need re-validation
    2. On next dispatch, compares local model vs LLM output
    3. If quality dropped, triggers retraining
    """

    MAX_INVALIDATED_TASKS = 50
    CACHE_TTL_SECONDS = 60

    def __init__(self):
        self._invalidated_tasks: set = set()
        self._sync_file = Path.home() / ".xingzierai" / "evolution_model_sync.json"
        self._cache_loaded_at: float = 0

    def notify_evolution_completed(self, changed_files: List[str] = None) -> None:
        affected = self._detect_affected_tasks(changed_files or [])
        for task_type in affected:
            self._invalidated_tasks.add(task_type)
            logger.info("Invalidated local model for task %s due to code evolution", task_type)
        if len(self._invalidated_tasks) > self.MAX_INVALIDATED_TASKS:
            self._invalidated_tasks = set(list(self._invalidated_tasks)[-self.MAX_INVALIDATED_TASKS:])
        self._persist()

    def is_task_invalidated(self, task_type: str) -> bool:
        now = time.time()
        if now - self._cache_loaded_at > self.CACHE_TTL_SECONDS:
            self._load()
        return task_type in self._invalidated_tasks

    def validate_and_resolve(self, task_type: str, llm_output: str, local_output: str) -> bool:
        validator = QualityValidator()
        score = validator._compute_similarity(local_output, llm_output)

        if score >= 0.3:
            self._invalidated_tasks.discard(task_type)
            self._persist()
            logger.info("Task %s validated after evolution (score=%.3f)", task_type, score)
            return True
        else:
            logger.warning(
                "Task %s quality dropped after evolution (score=%.3f), triggering retrain",
                task_type, score,
            )
            self._invalidated_tasks.discard(task_type)
            self._persist()
            return False

    def _detect_affected_tasks(self, changed_files: List[str]) -> List[str]:
        affected = []
        file_str = " ".join(changed_files).lower()
        if any(kw in file_str for kw in ["memory", "compact", "auto_compact"]):
            affected.append("memory_compact")
        if any(kw in file_str for kw in ["fact", "extract", "summarize"]):
            affected.append("fact_extract")
        if any(kw in file_str for kw in ["query", "rewrite", "rag", "retrieval"]):
            affected.append("query_rewrite")
        return affected

    def _persist(self):
        try:
            self._sync_file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._sync_file.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({
                "invalidated_tasks": list(self._invalidated_tasks),
                "updated_at": datetime.now().isoformat(),
            }, ensure_ascii=False, indent=2))
            tmp.replace(self._sync_file)
        except Exception as e:
            logger.warning("Failed to persist evolution sync state: %s", e)

    def _load(self):
        try:
            if self._sync_file.exists():
                data = json.loads(self._sync_file.read_text(encoding="utf-8"))
                self._invalidated_tasks = set(data.get("invalidated_tasks", []))
        except Exception as e:
            logger.warning("Failed to load evolution sync state: %s", e)


async def run_all_bridges() -> Dict[str, Any]:
    """Run all bridge sync operations. Called periodically or on-demand."""
    results = {}
    loop = asyncio.get_running_loop()

    dfb = DataFlywheelBridge()
    results["data_flywheel"] = await loop.run_in_executor(None, dfb.sync_interactions)

    ktb = KappaTrainingBridge()
    results["kappa"] = await loop.run_in_executor(None, ktb.sync_experience_packs)

    return results
