# -*- coding: utf-8 -*-
"""Slash command definitions for the development lifecycle.

Maps slash commands to skills, providing metadata for both
backend command handling and frontend UI rendering.
"""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class SlashCommand:
    command: str
    skill_name: str
    label: str
    description: str
    emoji: str
    phase: str
    prompt_prefix: str
    requires_args: bool = True


SLASH_COMMANDS: list[SlashCommand] = [
    SlashCommand(
        command="spec",
        skill_name="spec-driven-development",
        label="Spec",
        description="Define what to build before writing any code",
        emoji="📋",
        phase="DEFINE",
        prompt_prefix="Write a PRD for: ",
    ),
    SlashCommand(
        command="plan",
        skill_name="planning-and-task-breakdown",
        label="Plan",
        description="Decompose specs into small, verifiable tasks",
        emoji="📐",
        phase="PLAN",
        prompt_prefix="Break down this spec into tasks: ",
    ),
    SlashCommand(
        command="build",
        skill_name="incremental-implementation",
        label="Build",
        description="Build incrementally with thin vertical slices",
        emoji="🔨",
        phase="BUILD",
        prompt_prefix="Implement incrementally: ",
    ),
    SlashCommand(
        command="test",
        skill_name="test-driven-development",
        label="Test",
        description="Prove it works with tests. Red-Green-Refactor",
        emoji="✅",
        phase="VERIFY",
        prompt_prefix="Write tests for: ",
    ),
    SlashCommand(
        command="review",
        skill_name="code-review-and-quality",
        label="Review",
        description="Five-axis code review with staff engineer standard",
        emoji="🔍",
        phase="REVIEW",
        prompt_prefix="Review code for: ",
    ),
    SlashCommand(
        command="ship",
        skill_name="shipping-and-launch",
        label="Ship",
        description="Ship to production with confidence",
        emoji="🚀",
        phase="SHIP",
        prompt_prefix="Prepare to ship: ",
    ),
]

SLASH_COMMAND_MAP: dict[str, SlashCommand] = {
    sc.command: sc for sc in SLASH_COMMANDS
}

PHASE_ORDER = ["DEFINE", "PLAN", "BUILD", "VERIFY", "REVIEW", "SHIP"]


def get_slash_commands() -> list[dict]:
    """Return slash commands as serializable dicts for API responses."""
    return [
        {
            "command": sc.command,
            "skill_name": sc.skill_name,
            "label": sc.label,
            "description": sc.description,
            "emoji": sc.emoji,
            "phase": sc.phase,
            "prompt_prefix": sc.prompt_prefix,
            "requires_args": sc.requires_args,
        }
        for sc in SLASH_COMMANDS
    ]


def get_slash_command(command: str) -> SlashCommand | None:
    """Get a slash command by its command name."""
    return SLASH_COMMAND_MAP.get(command)
