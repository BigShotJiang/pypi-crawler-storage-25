# -*- coding: utf-8 -*-
"""Outcomes Self-Evaluation System.

Enterprise-level self-evaluation that defines success criteria,
iterates until criteria are met, and integrates with the ReAct loop.

Architecture:
- OutcomeEvaluator: Main evaluator that checks results against criteria
- SuccessCriteria: Structured definition of what "success" looks like
- EvaluationLoop: Iterative refinement loop (plan → execute → evaluate → refine)
- OutcomeTracker: Track evaluation history and improvement trends

Key principles:
1. Every task has explicit success criteria before execution
2. Results are automatically evaluated against criteria
3. If criteria not met, the system iterates with refinement
4. Evaluation history drives strategy adaptation
5. Integrates with HierarchicalEvaluator and Kappa experience packs
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_OUTCOMES_DIR = Path.home() / ".xingzierai" / "outcomes"


class CriterionType(str, Enum):
    EXACT_MATCH = "exact_match"
    CONTAINS = "contains"
    KEYWORD_COVERAGE = "keyword_coverage"
    LENGTH_RANGE = "length_range"
    CUSTOM_SCORE = "custom_score"
    NO_ERROR = "no_error"
    COMPLETENESS = "completeness"
    LLM_JUDGE = "llm_judge"
    AGENT_JUDGE = "agent_judge"


class EvaluationStatus(str, Enum):
    PENDING = "pending"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class SuccessCriterion:
    criterion_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    name: str = ""
    description: str = ""
    criterion_type: CriterionType = CriterionType.CONTAINS
    threshold: float = 0.7
    weight: float = 1.0
    required: bool = True
    params: dict = field(default_factory=dict)


@dataclass
class CriterionResult:
    criterion_id: str = ""
    name: str = ""
    status: EvaluationStatus = EvaluationStatus.PENDING
    score: float = 0.0
    passed: bool = False
    details: str = ""
    suggestions: List[str] = field(default_factory=list)


@dataclass
class OutcomeEvaluation:
    evaluation_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    task_description: str = ""
    result: str = ""
    criteria: List[SuccessCriterion] = field(default_factory=list)
    criterion_results: List[CriterionResult] = field(default_factory=list)
    overall_score: float = 0.0
    overall_passed: bool = False
    iteration: int = 0
    max_iterations: int = 3
    refinement_suggestions: List[str] = field(default_factory=list)
    improvement_trajectory: List[float] = field(default_factory=list)
    total_time_ms: float = 0.0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class OutcomeRecord:
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    task: str = ""
    final_result: str = ""
    total_iterations: int = 0
    final_score: float = 0.0
    success: bool = False
    criteria_met: int = 0
    criteria_total: int = 0
    improvement_trajectory: List[float] = field(default_factory=list)
    strategies_tried: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


class OutcomeEvaluator:
    """Evaluates task results against defined success criteria.

    Supports multiple criterion types:
    - exact_match: Result must exactly match expected value
    - contains: Result must contain expected keywords/phrases
    - keyword_coverage: Percentage of expected keywords present
    - length_range: Result length must be within range
    - custom_score: Custom scoring function
    - no_error: Result must not contain error indicators
    - completeness: Result must address all aspects of the task
    - llm_judge: LLM-as-Judge semantic evaluation
    """

    def __init__(self, llm_model=None):
        self._custom_scorers: Dict[str, Callable] = {}
        self._llm_model = llm_model
        self._MAX_CUSTOM_SCORERS = 20

    def set_llm_model(self, model) -> None:
        self._llm_model = model

    async def llm_judge_evaluate(
        self,
        result: str,
        task: str = "",
        criterion_description: str = "",
    ) -> CriterionResult:
        cr = CriterionResult(name="llm_judge")
        if not self._llm_model:
            cr.score = 0.5
            cr.passed = True
            cr.details = "LLM judge not available, defaulting to pass"
            cr.status = EvaluationStatus.PASSED
            return cr

        prompt = (
            f"Evaluate the following AI response on a scale of 1-5.\n\n"
            f"Task: {task[:500]}\n"
            f"Evaluation Criterion: {criterion_description[:200]}\n"
            f"Response: {result[:2000]}\n\n"
            f"Rate 1-5 based on: relevance, accuracy, completeness, helpfulness.\n"
            f"Output ONLY valid JSON: {{\"score\": <1-5>, \"reasoning\": \"<brief explanation>\"}}"
        )

        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(None, self._llm_model, prompt)
            response_text = response.text if hasattr(response, "text") else str(response)
            import re
            json_start = response_text.find("{")
            json_end = response_text.rfind("}")
            if json_start != -1 and json_end > json_start:
                json_str = response_text[json_start:json_end + 1]
                data = json.loads(json_str)
                raw_score = float(data.get("score", 3))
                cr.score = min(1.0, max(0.0, raw_score / 5.0))
                cr.passed = cr.score >= 0.6
                cr.details = data.get("reasoning", "")[:200]
            else:
                cr.score = 0.0
                cr.passed = False
                cr.details = "Could not parse LLM judge response"
        except Exception as e:
            cr.score = 0.0
            cr.passed = False
            cr.details = f"LLM judge error: {str(e)[:100]}"

        cr.status = EvaluationStatus.PASSED if cr.passed else EvaluationStatus.FAILED
        return cr

    async def agent_judge_evaluate(
        self,
        result: str,
        task: str = "",
        criterion_description: str = "",
        evaluation_dimensions: Optional[List[str]] = None,
    ) -> CriterionResult:
        cr = CriterionResult(name="agent_judge")
        if not self._llm_model:
            cr.score = 0.5
            cr.passed = True
            cr.details = "Agent judge not available, defaulting to pass"
            cr.status = EvaluationStatus.PASSED
            return cr

        dimensions = evaluation_dimensions or ["correctness", "completeness", "helpfulness"]
        dimensions_str = ", ".join(dimensions)

        prompt = (
            f"You are an expert evaluator. Evaluate the following AI response across multiple dimensions.\n\n"
            f"Task: {task[:500]}\n"
            f"Evaluation Criterion: {criterion_description[:200]}\n"
            f"Response: {result[:2000]}\n\n"
            f"Rate each dimension on a scale of 1-5: {dimensions_str}\n"
            f"Also provide an overall assessment and specific improvement suggestions.\n"
            f"Output ONLY valid JSON:\n"
            '{"dimensions": {"dim_name": score}, "overall_score": <1-5>, '
            '"reasoning": "<brief explanation>", "suggestions": ["<suggestion1>"]}'
        )

        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(None, self._llm_model, prompt)
            response_text = response.text if hasattr(response, "text") else str(response)
            import re
            json_match = re.search(r'\{[^}]+\}', response_text, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                raw_overall = float(data.get("overall_score", 3))
                cr.score = min(1.0, max(0.0, raw_overall / 5.0))
                cr.passed = cr.score >= 0.6
                dim_scores = data.get("dimensions", {})
                dim_details = "; ".join(f"{k}={v}" for k, v in dim_scores.items())
                cr.details = f"AgentJudge({dim_details}) | {data.get('reasoning', '')[:150]}"
                suggestions = data.get("suggestions", [])
                if suggestions:
                    cr.suggestions.extend(suggestions[:3])
            else:
                cr.score = 0.0
                cr.passed = False
                cr.details = "Could not parse agent judge response"
        except Exception as e:
            cr.score = 0.0
            cr.passed = False
            cr.details = f"Agent judge error: {str(e)[:100]}"

        cr.status = EvaluationStatus.PASSED if cr.passed else EvaluationStatus.FAILED
        return cr

    def register_scorer(self, name: str, scorer: Callable[[str, dict], float]) -> None:
        if len(self._custom_scorers) >= self._MAX_CUSTOM_SCORERS:
            oldest_key = next(iter(self._custom_scorers))
            del self._custom_scorers[oldest_key]
            logger.warning("[OutcomeEvaluator] action=scorer_evicted name=%s", oldest_key)
        self._custom_scorers[name] = scorer

    async def evaluate_criterion(
        self,
        result: str,
        criterion: SuccessCriterion,
    ) -> CriterionResult:
        cr = CriterionResult(
            criterion_id=criterion.criterion_id,
            name=criterion.name,
        )

        try:
            if criterion.criterion_type == CriterionType.EXACT_MATCH:
                expected = criterion.params.get("expected", "")
                score = 1.0 if result.strip() == expected.strip() else 0.0
                cr.score = score
                cr.passed = score >= criterion.threshold
                cr.details = f"Expected: '{expected[:50]}', Got: '{result[:50]}'"

            elif criterion.criterion_type == CriterionType.CONTAINS:
                expected_items = criterion.params.get("items", [])
                if isinstance(expected_items, str):
                    expected_items = [expected_items]
                found = sum(1 for item in expected_items if item.lower() in result.lower())
                score = found / max(1, len(expected_items))
                cr.score = score
                cr.passed = score >= criterion.threshold
                missing = [item for item in expected_items if item.lower() not in result.lower()]
                cr.details = f"Found {found}/{len(expected_items)} items"
                if missing:
                    cr.suggestions.append(f"Include these missing items: {missing}")

            elif criterion.criterion_type == CriterionType.KEYWORD_COVERAGE:
                keywords = criterion.params.get("keywords", [])
                found = sum(1 for kw in keywords if kw.lower() in result.lower())
                score = found / max(1, len(keywords))
                cr.score = score
                cr.passed = score >= criterion.threshold
                missing_kw = [kw for kw in keywords if kw.lower() not in result.lower()]
                cr.details = f"Keyword coverage: {found}/{len(keywords)}"
                if missing_kw:
                    cr.suggestions.append(f"Add coverage for keywords: {missing_kw[:5]}")

            elif criterion.criterion_type == CriterionType.LENGTH_RANGE:
                min_len = criterion.params.get("min", 0)
                max_len = criterion.params.get("max", float("inf"))
                length = len(result)
                if min_len <= length <= max_len:
                    score = 1.0
                elif length < min_len:
                    score = length / max(1, min_len)
                else:
                    score = max(0.0, 1.0 - (length - max_len) / max(1, max_len))
                cr.score = score
                cr.passed = score >= criterion.threshold
                cr.details = f"Length: {length} (range: {min_len}-{max_len})"

            elif criterion.criterion_type == CriterionType.NO_ERROR:
                error_indicators = criterion.params.get(
                    "error_indicators",
                    ["error", "failed", "exception", "traceback", "无法", "失败"],
                )
                found_errors = [e for e in error_indicators if e.lower() in result.lower()]
                score = 1.0 - (len(found_errors) / max(1, len(error_indicators)))
                cr.score = score
                cr.passed = score >= criterion.threshold
                if found_errors:
                    cr.details = f"Found error indicators: {found_errors}"
                    cr.suggestions.append("Fix the errors and retry")

            elif criterion.criterion_type == CriterionType.COMPLETENESS:
                aspects = criterion.params.get("aspects", [])
                addressed = sum(1 for aspect in aspects if aspect.lower() in result.lower())
                score = addressed / max(1, len(aspects))
                cr.score = score
                cr.passed = score >= criterion.threshold
                unaddressed = [a for a in aspects if a.lower() not in result.lower()]
                cr.details = f"Addressed {addressed}/{len(aspects)} aspects"
                if unaddressed:
                    cr.suggestions.append(f"Address these aspects: {unaddressed}")

            elif criterion.criterion_type == CriterionType.CUSTOM_SCORE:
                scorer_name = criterion.params.get("scorer", "")
                scorer = self._custom_scorers.get(scorer_name)
                if scorer:
                    score = scorer(result, criterion.params)
                    cr.score = score
                    cr.passed = score >= criterion.threshold
                    cr.details = f"Custom scorer '{scorer_name}': {score:.2f}"
                else:
                    cr.score = 0.0
                    cr.passed = False
                    cr.details = f"Custom scorer '{scorer_name}' not found"

            elif criterion.criterion_type == CriterionType.LLM_JUDGE:
                cr = await self.llm_judge_evaluate(
                    result,
                    task=criterion.params.get("task", ""),
                    criterion_description=criterion.description,
                )
                cr.criterion_id = criterion.criterion_id
                cr.name = criterion.name

            elif criterion.criterion_type == CriterionType.AGENT_JUDGE:
                cr = await self.agent_judge_evaluate(
                    result,
                    task=criterion.params.get("task", ""),
                    criterion_description=criterion.description,
                    evaluation_dimensions=criterion.params.get("dimensions", ["correctness", "completeness", "helpfulness"]),
                )
                cr.criterion_id = criterion.criterion_id
                cr.name = criterion.name

        except Exception as e:
            cr.score = 0.0
            cr.passed = False
            cr.details = f"Evaluation error: {str(e)}"

        cr.status = EvaluationStatus.PASSED if cr.passed else EvaluationStatus.FAILED
        return cr

    async def evaluate(
        self,
        result: str,
        criteria: List[SuccessCriterion],
    ) -> OutcomeEvaluation:
        evaluation = OutcomeEvaluation(result=result, criteria=criteria)

        total_weight = sum(c.weight for c in criteria)
        weighted_score = 0.0
        all_required_passed = True

        for criterion in criteria:
            cr = await self.evaluate_criterion(result, criterion)
            evaluation.criterion_results.append(cr)
            weighted_score += cr.score * criterion.weight

            if criterion.required and not cr.passed:
                all_required_passed = False

            if not cr.passed and cr.suggestions:
                evaluation.refinement_suggestions.extend(cr.suggestions)

        if total_weight < 0.01:
            evaluation.overall_score = 0.0
        else:
            evaluation.overall_score = weighted_score / total_weight
        evaluation.overall_passed = all_required_passed and evaluation.overall_score >= 0.7

        return evaluation

    def quality_gate_check(
        self,
        evaluation: OutcomeEvaluation,
        gate_threshold: float = 0.8,
        strict_required: bool = True,
    ) -> dict:
        if strict_required:
            required_failed = [
                cr.name for cr in evaluation.criterion_results
                if cr.required and not cr.passed
            ]
        else:
            required_failed = []

        score_passed = evaluation.overall_score >= gate_threshold
        status = "passed"
        if required_failed:
            status = "blocked"
        elif not score_passed:
            status = "below_threshold"

        return {
            "status": status,
            "score": round(evaluation.overall_score, 3),
            "threshold": gate_threshold,
            "score_passed": score_passed,
            "required_criteria_failed": required_failed,
            "total_criteria": len(evaluation.criterion_results),
            "passed_criteria": sum(1 for cr in evaluation.criterion_results if cr.passed),
        }


class EvaluationLoop:
    """Iterative evaluation loop: plan → execute → evaluate → refine.

    Integrates with the ReAct agent loop to add self-evaluation:
    1. Define success criteria for the task
    2. Execute the task (via agent)
    3. Evaluate result against criteria
    4. If not passed, generate refinement suggestions
    5. Re-execute with refined approach
    6. Repeat until criteria met or max iterations reached
    """

    def __init__(
        self,
        evaluator: Optional[OutcomeEvaluator] = None,
        max_iterations: int = 3,
        score_improvement_threshold: float = 0.05,
    ):
        self.evaluator = evaluator or OutcomeEvaluator()
        self.max_iterations = max_iterations
        self.score_improvement_threshold = score_improvement_threshold

    async def run(
        self,
        task: str,
        execute_fn: Callable[[str, Optional[str]], Any],
        criteria: Optional[List[SuccessCriterion]] = None,
    ) -> OutcomeEvaluation:
        if not criteria:
            criteria = self._auto_generate_criteria(task)

        best_evaluation = None
        best_result = ""
        trajectory = []

        for iteration in range(self.max_iterations):
            start_time = time.time()

            refinement_context = ""
            if iteration > 0 and best_evaluation and not best_evaluation.overall_passed:
                suggestions = best_evaluation.refinement_suggestions[:5]
                refinement_context = (
                    f"\n\n[Self-Evaluation Feedback - Iteration {iteration}]:\n"
                    f"Previous score: {best_evaluation.overall_score:.2f}\n"
                    f"Improvement suggestions:\n"
                    + "\n".join(f"- {s}" for s in suggestions)
                )

            try:
                result = await execute_fn(task, refinement_context)
                result_str = str(result) if result else ""
            except Exception as e:
                result_str = f"Execution error: {str(e)}"

            evaluation = await self.evaluator.evaluate(result_str, criteria)
            evaluation.iteration = iteration
            evaluation.task_description = task
            evaluation.total_time_ms = (time.time() - start_time) * 1000

            trajectory.append(evaluation.overall_score)

            if best_evaluation is None or evaluation.overall_score > best_evaluation.overall_score:
                best_evaluation = evaluation
                best_result = result_str

            if evaluation.overall_passed:
                logger.info(
                    "Evaluation passed at iteration %d with score %.2f",
                    iteration, evaluation.overall_score,
                )
                break

            if iteration > 0 and len(trajectory) >= 2:
                improvement = trajectory[-1] - trajectory[-2]
                if improvement < self.score_improvement_threshold and improvement >= 0:
                    logger.info(
                        "Score improvement %.3f below threshold, stopping iteration",
                        improvement,
                    )
                    break

            logger.info(
                "Iteration %d: score=%.2f, passed=%s, refining...",
                iteration, evaluation.overall_score, evaluation.overall_passed,
            )

        if best_evaluation:
            best_evaluation.improvement_trajectory = trajectory

        return best_evaluation or OutcomeEvaluation(
            task_description=task,
            result="No evaluation completed",
            overall_passed=False,
        )

    def _auto_generate_criteria(self, task: str) -> List[SuccessCriterion]:
        try:
            import jieba
            keywords = [t for t in jieba.cut(task) if t.strip()][:10]
        except ImportError:
            keywords = task.split()[:10]

        criteria = [
            SuccessCriterion(
                name="no_errors",
                description="Result should not contain error indicators",
                criterion_type=CriterionType.NO_ERROR,
                threshold=0.8,
                required=True,
            ),
            SuccessCriterion(
                name="relevance",
                description="Result should contain keywords from the task",
                criterion_type=CriterionType.KEYWORD_COVERAGE,
                threshold=0.3,
                weight=0.8,
                required=False,
                params={"keywords": keywords},
            ),
            SuccessCriterion(
                name="sufficient_detail",
                description="Result should have adequate length",
                criterion_type=CriterionType.LENGTH_RANGE,
                threshold=0.5,
                weight=0.5,
                required=False,
                params={"min": 20, "max": 50000},
            ),
        ]
        return criteria


class OutcomeTracker:
    """Tracks evaluation history and improvement trends.

    Provides:
    - Record evaluation outcomes for learning
    - Analyze improvement trends over time
    - Identify common failure patterns
    - Feed insights back to Kappa experience packs
    """

    _instance: Optional["OutcomeTracker"] = None
    MAX_RECORDS = 500
    MAX_CUSTOM_SCORERS = 20

    def __init__(self):
        _OUTCOMES_DIR.mkdir(parents=True, exist_ok=True)
        self._records: List[OutcomeRecord] = []
        self._op_count = 0
        self._persist_interval = 5
        self._last_persist_time = time.time()
        self._persist_interval_seconds = 60
        self._failure_pattern_cache: Dict[str, int] = {}
        self._cache_last_updated = 0.0
        self._CACHE_TTL_SECONDS = 300
        self._load()

    @classmethod
    def get_instance(cls) -> "OutcomeTracker":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    def clear_old_records(self, max_age_days: int = 30) -> int:
        if not self._records:
            return 0
        try:
            from datetime import timezone
            cutoff = datetime.now(timezone.utc) - __import__('datetime').timedelta(days=max_age_days)
            before = len(self._records)
            self._records = [
                r for r in self._records
                if datetime.fromisoformat(r.created_at).replace(tzinfo=timezone.utc if datetime.fromisoformat(r.created_at).tzinfo is None else None) > cutoff
            ]
            removed = before - len(self._records)
            if removed > 0:
                self._persist()
            return removed
        except Exception as e:
            logger.warning("[OutcomeTracker] action=clear_old_records_failed error=%s", e)
            return 0

    def _load(self):
        records_file = _OUTCOMES_DIR / "outcome_records.json"
        if records_file.exists():
            try:
                data = json.loads(records_file.read_text(encoding="utf-8"))
                for item in data[-self.MAX_RECORDS:]:
                    self._records.append(OutcomeRecord(
                        record_id=item.get("record_id", uuid.uuid4().hex[:8]),
                        task=item.get("task", ""),
                        final_result=item.get("final_result", "")[:500],
                        total_iterations=item.get("total_iterations", 0),
                        final_score=item.get("final_score", 0.0),
                        success=item.get("success", False),
                        criteria_met=item.get("criteria_met", 0),
                        criteria_total=item.get("criteria_total", 0),
                        improvement_trajectory=item.get("improvement_trajectory", []),
                        strategies_tried=item.get("strategies_tried", []),
                        created_at=item.get("created_at", datetime.now().isoformat()),
                    ))
                logger.info("[OutcomeTracker] action=loaded_records count=%d", len(self._records))
            except Exception as e:
                logger.warning("[OutcomeTracker] action=load_failed error=%s", e)

    def _persist(self):
        try:
            self._records = self._records[-self.MAX_RECORDS:]
            data = []
            for r in self._records:
                data.append({
                    "record_id": r.record_id,
                    "task": r.task[:200],
                    "final_result": r.final_result[:500],
                    "total_iterations": r.total_iterations,
                    "final_score": r.final_score,
                    "success": r.success,
                    "criteria_met": r.criteria_met,
                    "criteria_total": r.criteria_total,
                    "improvement_trajectory": r.improvement_trajectory,
                    "strategies_tried": r.strategies_tried,
                    "created_at": r.created_at,
                })
            records_file = _OUTCOMES_DIR / "outcome_records.json"
            tmp_file = str(records_file) + ".tmp"
            Path(tmp_file).write_text(json.dumps(data, ensure_ascii=False, indent=2))
            os.replace(tmp_file, str(records_file))
        except Exception as e:
            logger.warning("[OutcomeTracker] action=persist_failed error=%s", e)

    def record(self, evaluation: OutcomeEvaluation) -> str:
        record = OutcomeRecord(
            task=evaluation.task_description[:200],
            final_result=evaluation.result[:500],
            total_iterations=evaluation.iteration + 1,
            final_score=evaluation.overall_score,
            success=evaluation.overall_passed,
            criteria_met=sum(1 for cr in evaluation.criterion_results if cr.passed),
            criteria_total=len(evaluation.criterion_results),
            improvement_trajectory=evaluation.improvement_trajectory,
        )
        self._records.append(record)
        self._op_count += 1
        should_persist = (
            self._op_count >= self._persist_interval
            or (time.time() - self._last_persist_time) >= self._persist_interval_seconds
        )
        if should_persist:
            self._op_count = 0
            self._last_persist_time = time.time()
            self._persist()
        self._feed_kto(evaluation)
        return record.record_id

    def _feed_kto(self, evaluation: OutcomeEvaluation) -> None:
        try:
            from ..model_trainer.kto_trainer import KTODataCollector
            collector = KTODataCollector()
            collector.collect(
                task_type="outcomes_eval",
                input_text=evaluation.task_description[:4000],
                output_text=evaluation.result[:4000],
                is_desirable=evaluation.overall_passed,
                score=evaluation.overall_score,
            )
        except Exception as e:
            logger.debug("KTO auto-feed skipped: %s", e)

    def get_trends(self, limit: int = 50) -> dict:
        recent = self._records[-limit:]
        if not recent:
            return {"total": 0, "success_rate": 0.0, "avg_score": 0.0}

        success_count = sum(1 for r in recent if r.success)
        avg_score = sum(r.final_score for r in recent) / len(recent)
        avg_iterations = sum(r.total_iterations for r in recent) / len(recent)

        score_trend = self._compute_score_trend(recent)
        window_size = max(1, len(recent) // 3)
        early_scores = [r.final_score for r in recent[:window_size]]
        late_scores = [r.final_score for r in recent[-window_size:]]
        early_avg = sum(early_scores) / len(early_scores) if early_scores else 0.0
        late_avg = sum(late_scores) / len(late_scores) if late_scores else 0.0
        improvement_delta = round(late_avg - early_avg, 3)

        return {
            "total": len(recent),
            "success_rate": success_count / len(recent),
            "avg_score": avg_score,
            "avg_iterations": avg_iterations,
            "recent_scores": [r.final_score for r in recent[-10:]],
            "score_trend": score_trend,
            "improvement_delta": improvement_delta,
            "early_avg_score": round(early_avg, 3),
            "late_avg_score": round(late_avg, 3),
        }

    @staticmethod
    def _compute_score_trend(records: list) -> str:
        if len(records) < 3:
            return "insufficient_data"
        n = len(records)
        half = n // 2
        first_half = records[:half]
        second_half = records[half:]
        first_avg = sum(r.final_score for r in first_half) / len(first_half)
        second_avg = sum(r.final_score for r in second_half) / len(second_half)
        delta = second_avg - first_avg
        if delta > 0.05:
            return "improving"
        if delta < -0.05:
            return "declining"
        return "stable"

    def get_common_failures(self, limit: int = 10) -> List[dict]:
        failed = [r for r in self._records if not r.success]
        now = time.time()
        if now - self._cache_last_updated > self._CACHE_TTL_SECONDS:
            self._failure_pattern_cache.clear()
            for r in failed:
                key = r.task[:60].strip()
                if key:
                    self._failure_pattern_cache[key] = self._failure_pattern_cache.get(key, 0) + 1
            self._cache_last_updated = now
            if len(self._failure_pattern_cache) > 100:
                sorted_patterns = sorted(self._failure_pattern_cache.items(), key=lambda x: x[1], reverse=True)
                self._failure_pattern_cache = dict(sorted_patterns[:100])
        recurring = [
            {"task_pattern": k, "count": v}
            for k, v in sorted(self._failure_pattern_cache.items(), key=lambda x: x[1], reverse=True)
            if v > 1
        ][:5]
        return [
            {
                "task": r.task[:100],
                "score": r.final_score,
                "iterations": r.total_iterations,
                "criteria_met": f"{r.criteria_met}/{r.criteria_total}",
            }
            for r in failed[-limit:]
        ] + [{"recurring_patterns": recurring}]

    def get_stats(self) -> dict:
        total = len(self._records)
        success_rate = sum(1 for r in self._records if r.success) / max(1, total)
        scores = [r.final_score for r in self._records] if total > 0 else []
        avg_score = sum(scores) / len(scores) if scores else 0.0
        min_score = min(scores) if scores else 0.0
        max_score = max(scores) if scores else 0.0
        score_variance = 0.0
        if len(scores) > 1:
            mean = avg_score
            score_variance = sum((s - mean) ** 2 for s in scores) / (len(scores) - 1)
        return {
            "total_records": total,
            "success_rate": success_rate,
            "avg_score": round(avg_score, 3),
            "min_score": round(min_score, 3),
            "max_score": round(max_score, 3),
            "score_variance": round(score_variance, 4),
            "trends": self.get_trends(),
        }
