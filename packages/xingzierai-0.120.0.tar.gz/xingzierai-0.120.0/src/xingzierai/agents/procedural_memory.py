#!/usr/bin/env python3
"""Procedural Memory - 程序性记忆系统

存储和检索工具用法、工作流规则、操作步骤等程序性知识。
与Episodic Memory（具体事件）和Semantic Memory（事实概念）互补。

Procedural Memory特点:
1. 存储"如何做"的知识：工具调用模式、工作流步骤、最佳实践
2. 通过成功/失败反馈自动强化或弱化
3. Ebbinghaus衰减率极低(0.08)，程序性记忆一旦学会就不易遗忘
4. 检索时按匹配度和强化次数排序

数据模型:
  Procedure: 工具名+触发条件+步骤+成功率+强化次数
"""

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_PERSIST_DIR = Path.home() / ".xingzierai" / "procedural_memory"


@dataclass
class ProcedureStep:
    order: int = 0
    action: str = ""
    tool_name: str = ""
    params_template: str = ""
    expected_outcome: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "order": self.order,
            "action": self.action,
            "tool_name": self.tool_name,
            "params_template": self.params_template,
            "expected_outcome": self.expected_outcome,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProcedureStep":
        return cls(
            order=data.get("order", 0),
            action=data.get("action", ""),
            tool_name=data.get("tool_name", ""),
            params_template=data.get("params_template", ""),
            expected_outcome=data.get("expected_outcome", ""),
        )


@dataclass
class Procedure:
    procedure_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str = ""
    trigger_pattern: str = ""
    tool_name: str = ""
    steps: List[ProcedureStep] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    reinforcement: float = 1.0
    last_used_at: float = 0.0
    created_at: float = field(default_factory=time.time)
    tags: List[str] = field(default_factory=list)
    namespace: str = "default"

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.5
        return self.success_count / total

    @property
    def is_reliable(self) -> bool:
        return self.success_rate >= 0.7 and (self.success_count + self.failure_count) >= 3

    def to_dict(self) -> Dict[str, Any]:
        return {
            "procedure_id": self.procedure_id,
            "name": self.name,
            "trigger_pattern": self.trigger_pattern,
            "tool_name": self.tool_name,
            "steps": [s.to_dict() for s in self.steps],
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "reinforcement": self.reinforcement,
            "last_used_at": self.last_used_at,
            "created_at": self.created_at,
            "tags": self.tags,
            "namespace": self.namespace,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Procedure":
        return cls(
            procedure_id=data.get("procedure_id", uuid.uuid4().hex[:12]),
            name=data.get("name", ""),
            trigger_pattern=data.get("trigger_pattern", ""),
            tool_name=data.get("tool_name", ""),
            steps=[ProcedureStep.from_dict(s) for s in data.get("steps", [])],
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
            reinforcement=data.get("reinforcement", 1.0),
            last_used_at=data.get("last_used_at", 0.0),
            created_at=data.get("created_at", time.time()),
            tags=data.get("tags", []),
            namespace=data.get("namespace", "default"),
        )


class ProceduralMemoryStore:
    MAX_PROCEDURES = 2000
    DECAY_RATE = 0.08
    REINFORCE_FACTOR = 0.3
    MIN_REINFORCEMENT = 0.1
    CLEANUP_INTERVAL = 120
    PERSIST_INTERVAL = 10
    MAX_COUNT = 500
    STALE_DAYS = 30

    def __init__(self, persist_dir: Optional[Path] = None):
        self._persist_dir = persist_dir or _PERSIST_DIR
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._procedures: Dict[str, Procedure] = {}
        self._index_by_tool: Dict[str, set] = {}
        self._index_by_tag: Dict[str, set] = {}
        self._lock = asyncio.Lock()
        self._op_count = 0
        self._last_cleanup = 0.0
        self._load()

    def _load(self):
        data_file = self._persist_dir / "procedures.json"
        if data_file.exists():
            try:
                data = json.loads(data_file.read_text(encoding="utf-8"))
                for item in data.get("procedures", []):
                    proc = Procedure.from_dict(item)
                    self._procedures[proc.procedure_id] = proc
                    self._update_indexes(proc)
                logger.info("ProceduralMemory: loaded %d procedures", len(self._procedures))
            except Exception as e:
                logger.warning("ProceduralMemory: failed to load: %s", e)

    def _persist(self):
        try:
            data = {
                "procedures": [p.to_dict() for p in self._procedures.values()],
                "saved_at": time.time(),
            }
            tmp = self._persist_dir / "procedures.json.tmp"
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._persist_dir / "procedures.json")
        except Exception as e:
            logger.warning("ProceduralMemory: failed to persist: %s", e)

    def _maybe_persist(self):
        self._op_count += 1
        if self._op_count >= self.PERSIST_INTERVAL:
            self._op_count = 0
            self._persist()

    def _update_indexes(self, proc: Procedure):
        if proc.tool_name:
            self._index_by_tool.setdefault(proc.tool_name, set()).add(proc.procedure_id)
        for tag in proc.tags:
            self._index_by_tag.setdefault(tag, set()).add(proc.procedure_id)

    def _remove_from_indexes(self, proc: Procedure):
        if proc.tool_name in self._index_by_tool:
            self._index_by_tool[proc.tool_name].discard(proc.procedure_id)
        for tag in proc.tags:
            if tag in self._index_by_tag:
                self._index_by_tag[tag].discard(proc.procedure_id)

    def _maybe_cleanup(self):
        now = time.time()
        if now - self._last_cleanup < self.CLEANUP_INTERVAL:
            return
        self._last_cleanup = now

        to_remove = []
        stale_threshold = self.STALE_DAYS * 86400
        for pid, proc in self._procedures.items():
            age = now - proc.created_at
            elapsed = now - proc.last_used_at if proc.last_used_at > 0 else age
            decay = self.DECAY_RATE * elapsed / 86400.0
            proc.reinforcement = max(self.MIN_REINFORCEMENT, proc.reinforcement - decay)
            if proc.reinforcement <= self.MIN_REINFORCEMENT and proc.success_count + proc.failure_count < 2:
                to_remove.append(pid)
            elif proc.last_used_at > 0 and (now - proc.last_used_at) > stale_threshold and not proc.is_reliable:
                to_remove.append(pid)
            proc.success_count = min(proc.success_count, self.MAX_COUNT)
            proc.failure_count = min(proc.failure_count, self.MAX_COUNT)

        for pid in to_remove:
            self._remove_from_indexes(self._procedures[pid])
            del self._procedures[pid]

        if to_remove:
            logger.info("ProceduralMemory: cleaned up %d unused procedures", len(to_remove))

    async def store(self, procedure: Procedure) -> str:
        async with self._lock:
            if len(self._procedures) >= self.MAX_PROCEDURES:
                weakest = min(self._procedures.items(), key=lambda x: x[1].reinforcement)
                self._remove_from_indexes(weakest[1])
                del self._procedures[weakest[0]]

            self._procedures[procedure.procedure_id] = procedure
            self._update_indexes(procedure)
            self._maybe_persist()
            return procedure.procedure_id

    async def lookup_by_tool(self, tool_name: str, limit: int = 10) -> List[Procedure]:
        async with self._lock:
            pids = self._index_by_tool.get(tool_name, set())
            results = []
            for pid in pids:
                if pid in self._procedures:
                    results.append(self._procedures[pid])
            results.sort(key=lambda p: (p.reinforcement, p.success_rate), reverse=True)
            return results[:limit]

    async def lookup_by_trigger(self, query: str, limit: int = 10) -> List[Procedure]:
        async with self._lock:
            self._maybe_cleanup()
            query_lower = query.lower()
            scored: List[Tuple[float, Procedure]] = []
            for proc in self._procedures.values():
                score = 0.0
                if proc.trigger_pattern and proc.trigger_pattern.lower() in query_lower:
                    score += 0.5
                if proc.name and proc.name.lower() in query_lower:
                    score += 0.3
                for tag in proc.tags:
                    if tag.lower() in query_lower:
                        score += 0.1
                score *= proc.reinforcement
                score += proc.success_rate * 0.2
                if score > 0:
                    scored.append((score, proc))

            scored.sort(key=lambda x: x[0], reverse=True)
            return [p for _, p in scored[:limit]]

    async def record_outcome(self, procedure_id: str, success: bool):
        async with self._lock:
            proc = self._procedures.get(procedure_id)
            if proc is None:
                return

            if success:
                proc.success_count = min(proc.success_count + 1, self.MAX_COUNT)
                proc.reinforcement = min(2.0, proc.reinforcement + self.REINFORCE_FACTOR)
            else:
                proc.failure_count = min(proc.failure_count + 1, self.MAX_COUNT)
                proc.reinforcement = max(self.MIN_REINFORCEMENT, proc.reinforcement - self.REINFORCE_FACTOR * 0.5)

            proc.last_used_at = time.time()
            self._maybe_persist()

    async def get_or_create_for_tool(self, tool_name: str, trigger_pattern: str = "") -> Procedure:
        async with self._lock:
            pids = self._index_by_tool.get(tool_name, set())
            for pid in pids:
                proc = self._procedures.get(pid)
                if proc and (not trigger_pattern or proc.trigger_pattern == trigger_pattern):
                    return proc

            proc = Procedure(
                tool_name=tool_name,
                trigger_pattern=trigger_pattern,
                name=f"{tool_name}_procedure",
                tags=[tool_name],
            )
            self._procedures[proc.procedure_id] = proc
            self._update_indexes(proc)
            self._maybe_persist()
            return proc

    def get_stats(self) -> Dict[str, Any]:
        total = len(self._procedures)
        reliable = sum(1 for p in self._procedures.values() if p.is_reliable)
        by_tool: Dict[str, int] = {}
        for proc in self._procedures.values():
            by_tool[proc.tool_name] = by_tool.get(proc.tool_name, 0) + 1
        return {
            "total_procedures": total,
            "reliable_procedures": reliable,
            "by_tool": by_tool,
            "max_procedures": self.MAX_PROCEDURES,
        }


_default_store: Optional["ProceduralMemoryStore"] = None


def get_procedural_memory() -> ProceduralMemoryStore:
    global _default_store
    if _default_store is None:
        _default_store = ProceduralMemoryStore()
    return _default_store


__all__ = [
    "ProceduralMemoryStore",
    "Procedure",
    "ProcedureStep",
    "get_procedural_memory",
]
