# -*- coding: utf-8 -*-
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core._logging import logger
from xingzierai.agents.rule_engine import RuleEngine, RuleViolation, RuleSeverity
from xingzierai.agents.workflow_parser import WorkflowParser


class GateStatus(Enum):
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class GateResult:
    gate_id: float
    name: str
    status: GateStatus
    message: str = ""
    auto_fix_available: bool = False


@dataclass
class VerificationResult:
    safety_level: str
    total_gates: int
    passed: int
    failed: int
    skipped: int
    gate_results: list[GateResult] = field(default_factory=list)
    rule_violations: list[RuleViolation] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.failed == 0 and not any(
            v.severity == RuleSeverity.BLOCKING for v in self.rule_violations
        )


GATE_DEFINITIONS = {
    1: {"name": "Syntax Validation", "auto": True},
    2: {"name": "Import/Export Validation", "auto": True},
    2.5: {"name": "Code Quality", "auto": True},
    3: {"name": "Path Safety", "auto": True},
    4: {"name": "Git Checkpoint", "auto": True},
    5: {"name": "Apply Changes", "auto": True},
    6: {"name": "Service Health", "auto": True},
    7: {"name": "SSE Stream Test", "auto": True},
    8: {"name": "System Test", "auto": True},
    9: {"name": "Dual File Sync", "auto": True},
    10: {"name": "Frontend Render", "auto": True},
    11: {"name": "Hot Replacement", "auto": True},
    12: {"name": "Security + Data Loop", "auto": True},
    12.5: {"name": "Security Loop Verification", "auto": True},
}


class VerificationGateEngine:
    """Verification gate engine for code quality checks during evolution."""

    def __init__(self, workspace_dir: Optional[str] = None):
        self._workspace = workspace_dir
        self._rule_engine = RuleEngine()
        self._workflow_parser = WorkflowParser()

    async def run_gates(
        self,
        file_paths: list[str],
        safety_level: str = "yellow",
        fix_mode: bool = False,
    ) -> VerificationResult:
        """Run verification gates for the given files.

        Args:
            file_paths: List of file paths to verify
            safety_level: green/yellow/red - determines which gates to run
            fix_mode: Whether to attempt auto-fix for failures

        Returns:
            VerificationResult with gate results and rule violations
        """
        required_gates = self._workflow_parser.get_required_gates(safety_level)
        all_gate_results = []
        all_violations = []

        for file_path in file_paths:
            try:
                content = Path(file_path).read_text(encoding="utf-8", errors="replace")
            except Exception:
                content = ""

            violations = self._rule_engine.check_before_write(file_path, content)
            all_violations.extend(violations)

        for gate_id in required_gates:
            gate_def = GATE_DEFINITIONS.get(gate_id, {"name": f"Gate {gate_id}", "auto": False})
            result = await self._run_single_gate(gate_id, gate_def, file_paths, fix_mode)
            all_gate_results.append(result)

        passed = sum(1 for r in all_gate_results if r.status == GateStatus.PASSED)
        failed = sum(1 for r in all_gate_results if r.status == GateStatus.FAILED)
        skipped = sum(1 for r in all_gate_results if r.status == GateStatus.SKIPPED)

        result = VerificationResult(
            safety_level=safety_level,
            total_gates=len(required_gates),
            passed=passed,
            failed=failed,
            skipped=skipped,
            gate_results=all_gate_results,
            rule_violations=all_violations,
        )

        if failed > 0:
            self._publish_gate_failed_event(result, file_paths)

        return result

    def _publish_gate_failed_event(self, result: VerificationResult, file_paths: list[str]):
        try:
            from xingzierai.agents.evolution.event_bus import (
                EvolutionEventBus,
                EvolutionEvent,
                EvolutionEventType,
                get_evolution_bus,
            )

            bus = get_evolution_bus()
            failed_gates = [gr for gr in result.gate_results if gr.status == GateStatus.FAILED]
            bus.publish(EvolutionEvent(
                event_type=EvolutionEventType.GATE_FAILED,
                source="verification_gate_engine",
                data={
                    "safety_level": result.safety_level,
                    "failed_gates": [
                        {"gate_id": gr.gate_id, "name": gr.name, "message": gr.message}
                        for gr in failed_gates
                    ],
                    "rule_violations": [
                        {"rule_id": v.rule_id, "rule_name": v.rule_name, "message": v.message}
                        for v in result.rule_violations
                        if v.severity == RuleSeverity.BLOCKING
                    ],
                    "file_paths": file_paths,
                },
            ))
        except Exception as e:
            logger.debug("Failed to publish GATE_FAILED event: %s", e)

    async def run_single_gate(
        self,
        gate_id: float,
        file_paths: list[str],
    ) -> GateResult:
        """Run a single verification gate."""
        gate_def = GATE_DEFINITIONS.get(gate_id, {"name": f"Gate {gate_id}", "auto": False})
        return await self._run_single_gate(gate_id, gate_def, file_paths, False)

    async def _run_single_gate(
        self,
        gate_id: float,
        gate_def: dict,
        file_paths: list[str],
        fix_mode: bool,
    ) -> GateResult:
        """Execute a single verification gate."""
        name = gate_def.get("name", f"Gate {gate_id}")

        if gate_id == 1:
            return await self._gate_syntax(file_paths)
        elif gate_id == 2:
            return await self._gate_imports(file_paths)
        elif gate_id == 2.5:
            return await self._gate_code_quality(file_paths)
        elif gate_id == 3:
            return await self._gate_path_safety(file_paths)
        else:
            return GateResult(
                gate_id=gate_id,
                name=name,
                status=GateStatus.SKIPPED,
                message="Gate requires external tools or services",
            )

    async def _gate_syntax(self, file_paths: list[str]) -> GateResult:
        """GATE 1: Syntax validation."""
        errors = []
        for fp in file_paths:
            if not self._is_path_in_workspace(fp):
                errors.append(f"{fp}: Path outside workspace")
                continue
            ext = Path(fp).suffix
            try:
                content = Path(fp).read_text(encoding="utf-8", errors="replace")
                if ext == ".py":
                    compile(content, fp, "exec")
                elif ext in (".json",):
                    import json
                    json.loads(content)
            except SyntaxError as e:
                errors.append(f"{fp}: {e}")
            except json.JSONDecodeError as e:
                errors.append(f"{fp}: {e}")
            except Exception as e:
                errors.append(f"{fp}: {type(e).__name__}: {e}")

        if errors:
            return GateResult(
                gate_id=1,
                name="Syntax Validation",
                status=GateStatus.FAILED,
                message="; ".join(errors),
            )
        return GateResult(
            gate_id=1,
            name="Syntax Validation",
            status=GateStatus.PASSED,
            message="All files pass syntax check",
        )

    async def _gate_imports(self, file_paths: list[str]) -> GateResult:
        """GATE 2: Import validation for Python files."""
        errors = []
        for fp in file_paths:
            if not fp.endswith(".py"):
                continue
            if not self._is_path_in_workspace(fp):
                errors.append(f"{fp}: Path outside workspace")
                continue
            try:
                content = Path(fp).read_text(encoding="utf-8", errors="replace")
                import py_compile
                import tempfile
                with tempfile.NamedTemporaryFile(suffix=".py", delete=True) as tmp:
                    tmp.write(content.encode("utf-8"))
                    tmp.flush()
                    py_compile.compile(tmp.name, doraise=True)
            except py_compile.PyCompileError as e:
                errors.append(f"{fp}: {e}")

        if errors:
            return GateResult(
                gate_id=2,
                name="Import/Export Validation",
                status=GateStatus.FAILED,
                message="; ".join(errors),
            )
        return GateResult(
            gate_id=2,
            name="Import/Export Validation",
            status=GateStatus.PASSED,
            message="All Python files pass import check",
        )

    async def _gate_code_quality(self, file_paths: list[str]) -> GateResult:
        errors = []
        for fp in file_paths:
            if not self._is_path_in_workspace(fp):
                continue
            try:
                content = Path(fp).read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for i, line in enumerate(content.split("\n"), 1):
                stripped = line.strip()
                for char in stripped:
                    if ord(char) > 0xFF and ord(char) < 0x3000:
                        if fp.endswith((".py", ".ts", ".tsx", ".js", ".jsx")):
                            errors.append(f"{fp}:{i}: Fullwidth character detected (U+{ord(char):04X})")
                            break

            if fp.endswith((".ts", ".tsx", ".js", ".jsx")):
                has_default_export = any("export default" in l for l in content.split("\n"))
                has_named_export = any("export " in l and "export default" not in l for l in content.split("\n"))
                if not has_default_export and not has_named_export:
                    if "function " in content or "const " in content:
                        pass

            violations = self._rule_engine.check_file_content(fp, content, categories=["entropy", "karpathy"])
            blocking = self._rule_engine.get_blocking_violations(violations)
            for v in blocking:
                errors.append(f"{fp}: {v.rule_id} {v.rule_name}: {v.message}")

        if errors:
            return GateResult(
                gate_id=2.5,
                name="Code Quality",
                status=GateStatus.FAILED,
                message="; ".join(errors[:10]),
                auto_fix_available=True,
            )
        return GateResult(
            gate_id=2.5,
            name="Code Quality",
            status=GateStatus.PASSED,
            message="All files pass code quality checks",
        )

    async def _gate_path_safety(self, file_paths: list[str]) -> GateResult:
        """GATE 3: Path safety validation."""
        errors = []
        for fp in file_paths:
            if not self._is_path_in_workspace(fp):
                errors.append(f"{fp}: Path outside workspace")
            if any(part.startswith("..") for part in Path(fp).parts):
                errors.append(f"{fp}: Relative path traversal detected")

        if errors:
            return GateResult(
                gate_id=3,
                name="Path Safety",
                status=GateStatus.FAILED,
                message="; ".join(errors),
            )
        return GateResult(
            gate_id=3,
            name="Path Safety",
            status=GateStatus.PASSED,
            message="All paths are safe",
        )

    def _is_path_in_workspace(self, file_path: str) -> bool:
        """Check if a file path is within the workspace directory."""
        if not self._workspace:
            return True
        try:
            resolved = Path(file_path).resolve()
            workspace = Path(self._workspace).resolve()
            resolved.relative_to(workspace)
            return True
        except ValueError:
            return False
