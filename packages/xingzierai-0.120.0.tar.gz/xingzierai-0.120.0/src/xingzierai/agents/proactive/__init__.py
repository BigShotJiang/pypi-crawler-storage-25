# -*- coding: utf-8 -*-
"""Proactive Mode — agent proactively serves when idle.

Ported from QwenPaw's proactive module with XINGZIER AI adaptations.
"""

from .proactive_types import ProactiveConfig, ProactiveTask, ProactiveQueryResult
from .proactive_trigger import (
    enable_proactive_for_session,
    disable_proactive_for_session,
    is_proactive_enabled,
    get_proactive_config,
)

__all__ = [
    "ProactiveConfig",
    "ProactiveTask",
    "ProactiveQueryResult",
    "enable_proactive_for_session",
    "disable_proactive_for_session",
    "is_proactive_enabled",
    "get_proactive_config",
]
