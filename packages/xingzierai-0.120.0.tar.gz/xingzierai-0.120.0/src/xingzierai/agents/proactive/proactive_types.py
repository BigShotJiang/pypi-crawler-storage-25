# -*- coding: utf-8 -*-
"""Type definitions for proactive conversation feature."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class ProactiveConfig:
    enabled: bool = False
    idle_minutes: int = 30
    last_user_interaction: Optional[datetime] = None
    running_task_id: Optional[str] = None
    mode_enabled_time: Optional[datetime] = None


@dataclass
class ProactiveTask:
    task: str
    query: str
    priority: int
    reason: str


@dataclass
class ProactiveQueryResult:
    query: str
    success: bool
    data: Optional[str] = None
    error: Optional[str] = None
