# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml

from xingzierai.agentscope_core._logging import logger


@dataclass
class SafetyLevel:
    level: str
    color: str
    required_gates: list[int]
    description: str


SAFETY_LEVELS = {
    "green": SafetyLevel(
        level="green",
        color="🟢",
        required_gates=[1],
        description="Docs, configs, styles, tests - minimal verification",
    ),
    "yellow": SafetyLevel(
        level="yellow",
        color="🟡",
        required_gates=[1, 2, 3, 4, 5, 6, 7, 8],
        description="Backend logic, frontend pages (non-chat) - standard verification",
    ),
    "red": SafetyLevel(
        level="red",
        color="🔴",
        required_gates=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        description="react_agent, chat lib, console.py - full verification",
    ),
}

GREEN_PATTERNS = [
    ".md", ".txt", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".css", ".less", ".scss", ".svg",
    "_test.py", "_tests.py", "test_", "tests/",
    "__init__.py",
]

RED_PATTERNS = [
    "react_agent.py",
    "chat/", "Chat/", "@agentscope-ai/chat/",
    "console.py",
    "useChatRequest", "useChatController",
    "ChatAnywhereSessionsContext",
    "plan_engine.py",
    "rule_engine.py",
]


class WorkflowParser:
    """Parse WORKFLOW.md and provide AI-executable project standards."""

    def __init__(self, workflow_path: Optional[str] = None, project_root: Optional[str] = None):
        self._workflow_path = workflow_path
        self._data: dict = {}
        self._project_root = project_root
        if workflow_path:
            self._load(workflow_path)
        elif project_root:
            self._auto_discover(project_root)

    def _auto_discover(self, project_root: str) -> None:
        root = Path(project_root)
        candidates = [
            root / "WORKFLOW.md",
            root / "docs" / "WORKFLOW.md",
            root / ".xingzierai" / "WORKFLOW.md",
            root / "WORKFLOW.yaml",
            root / "WORKFLOW.yml",
            root / ".xingzierai" / "workflow.yaml",
        ]
        for candidate in candidates:
            if candidate.exists():
                self._workflow_path = str(candidate)
                self._load(str(candidate))
                logger.info("Auto-discovered workflow: %s", candidate)
                return
        logger.debug("No WORKFLOW file found in %s", project_root)

    def _load(self, path: str) -> None:
        try:
            content = Path(path).read_text(encoding="utf-8")
            if path.endswith((".yaml", ".yml")):
                self._data = yaml.safe_load(content) or {}
                self._load_from_yaml()
            else:
                sections = {}
                current_section = None
                for line in content.split("\n"):
                    stripped = line.strip()
                    if stripped.startswith("## "):
                        current_section = stripped[3:].strip()
                        sections[current_section] = []
                    elif current_section and stripped:
                        sections[current_section].append(line)
                self._data = sections
        except Exception as e:
            logger.debug("Failed to load workflow from %s: %s", path, e)

    def _load_from_yaml(self) -> None:
        if not isinstance(self._data, dict):
            return
        global SAFETY_LEVELS
        safety_config = self._data.get("safety_levels", {})
        for level_name, config in safety_config.items():
            if isinstance(config, dict) and "required_gates" in config:
                SAFETY_LEVELS[level_name] = SafetyLevel(
                    level=level_name,
                    color=config.get("color", "⚪"),
                    required_gates=config["required_gates"],
                    description=config.get("description", ""),
                )
        global GREEN_PATTERNS, RED_PATTERNS
        if "green_patterns" in self._data:
            GREEN_PATTERNS = self._data["green_patterns"]
        if "red_patterns" in self._data:
            RED_PATTERNS = self._data["red_patterns"]

    def get_safety_level(self, file_path: str) -> SafetyLevel:
        """Determine safety level based on file path."""
        path_lower = file_path.lower().replace("\\", "/")

        for pattern in RED_PATTERNS:
            if pattern.lower() in path_lower:
                return SAFETY_LEVELS["red"]

        for pattern in GREEN_PATTERNS:
            if pattern.lower() in path_lower:
                return SAFETY_LEVELS["green"]

        if "src/xingzierai/" in path_lower or "console/src/pages/" in path_lower:
            return SAFETY_LEVELS["yellow"]

        return SAFETY_LEVELS["green"]

    def get_required_gates(self, safety_level: str) -> list[int]:
        """Get required verification gates for a safety level."""
        level = SAFETY_LEVELS.get(safety_level)
        if level:
            return level.required_gates
        return [1]

    def get_evolution_mode(self, trigger: str) -> dict:
        """Get evolution mode configuration based on trigger."""
        modes = {
            "autonomous": {
                "name": "Autonomous Evolution",
                "trigger": ["自主进化", "autonomous evolve"],
                "human_checkpoint": "only for red files without Daemon",
            },
            "supervised": {
                "name": "Supervised Evolution",
                "trigger": ["进化", "evolve"],
                "human_checkpoint": "every step",
            },
            "emergency": {
                "name": "Emergency Fix",
                "trigger": ["紧急修复", "emergency"],
                "human_checkpoint": "before and after fix",
            },
        }
        trigger_lower = trigger.lower()
        for mode_config in modes.values():
            for t in mode_config["trigger"]:
                if t in trigger_lower:
                    return mode_config
        return modes["supervised"]

    def get_code_standards(self) -> dict:
        """Get code standards from workflow."""
        return {
            "max_file_lines": 400,
            "max_hook_lines": 100,
            "max_component_lines": 200,
            "test_pyramid": {"unit": 80, "integration": 15, "e2e": 5},
            "entropy_target": 2.5,
        }
