# -*- coding: utf-8 -*-
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any
from uuid import uuid4

from acp import (
    Agent,
    InitializeResponse,
    LoadSessionResponse,
    NewSessionResponse,
    PromptResponse,
    SetSessionModelResponse,
    run_agent,
    start_tool_call,
    text_block,
    tool_content,
    update_agent_message,
    update_agent_thought,
    update_tool_call,
)
from acp.interfaces import Client
from acp.schema import (
    AgentCapabilities,
    AgentMessageChunk,
    AudioContentBlock,
    ClientCapabilities,
    CloseSessionResponse,
    EmbeddedResourceContentBlock,
    HttpMcpServer,
    ImageContentBlock,
    Implementation,
    ListSessionsResponse,
    McpServerStdio,
    ResourceContentBlock,
    ResumeSessionResponse,
    SessionCapabilities,
    SessionCloseCapabilities,
    SessionConfigOptionSelect,
    SessionConfigSelectOption,
    SessionInfo,
    SessionListCapabilities,
    SessionResumeCapabilities,
    SetSessionConfigOptionResponse,
    SseMcpServer,
    TextContentBlock,
)

from xingzierai.agentscope_core.message import Msg
from xingzierai.agentscope_runtime.engine.schemas.agent_schemas import (
    AgentRequest,
    Message,
)
from xingzierai.__version__ import __version__
from xingzierai.constant import WORKING_DIR
from xingzierai.config.config import ModelSlotConfig
from xingzierai.providers.provider_manager import ProviderManager

logger = logging.getLogger(__name__)


PromptBlocks = list[
    TextContentBlock
    | ImageContentBlock
    | AudioContentBlock
    | ResourceContentBlock
    | EmbeddedResourceContentBlock
]


def _extract_text(blocks: PromptBlocks) -> str:
    parts: list[str] = []
    for block in blocks:
        if isinstance(block, dict):
            text = block.get("text", "")
        elif isinstance(block, TextContentBlock):
            text = block.text
        else:
            text = getattr(block, "text", "")
        if text:
            parts.append(str(text))
    return "\n".join(parts)


class _StreamTracker:
    def __init__(self) -> None:
        self._prev_text: str = ""
        self._prev_thinking: str = ""
        self._seen_tool_ids: set[str] = set()

    def delta_text(self, cumulative: str) -> str:
        if cumulative.startswith(self._prev_text):
            delta = cumulative[len(self._prev_text):]
        else:
            delta = cumulative
        self._prev_text = cumulative
        return delta

    def delta_thinking(self, cumulative: str) -> str:
        if cumulative.startswith(self._prev_thinking):
            delta = cumulative[len(self._prev_thinking):]
        else:
            delta = cumulative
        self._prev_thinking = cumulative
        return delta

    def is_new_tool_call(self, tool_id: str) -> bool:
        if tool_id in self._seen_tool_ids:
            return False
        self._seen_tool_ids.add(tool_id)
        return True


def _msg_to_updates(
    msg: Any,
    tracker: _StreamTracker | None = None,
) -> list[Any]:
    updates: list[Any] = []
    metadata = getattr(msg, "metadata", {}) or {}
    content = getattr(msg, "content", None)
    role = getattr(msg, "role", "assistant")

    if role == "system":
        if isinstance(content, list):
            _content_blocks_to_updates(content, updates, tracker)
        if not updates:
            text = _get_msg_text(msg)
            if text:
                updates.append(update_agent_thought(text_block(text)))
        return updates

    tool_calls = metadata.get("tool_calls")
    if isinstance(tool_calls, list):
        for tc in tool_calls:
            if not isinstance(tc, dict):
                continue
            tc_id = str(tc.get("id") or uuid4().hex[:8])
            if not tracker or tracker.is_new_tool_call(tc_id):
                updates.append(
                    start_tool_call(
                        tc_id,
                        str(tc.get("name") or "tool"),
                        status="in_progress",
                    ),
                )
        return updates

    tool_responses = metadata.get("tool_responses")
    if isinstance(tool_responses, list):
        for tr in tool_responses:
            if not isinstance(tr, dict):
                continue
            updates.append(
                update_tool_call(
                    str(tr.get("id") or uuid4().hex[:8]),
                    status="completed",
                    content=[
                        tool_content(
                            text_block(
                                _extract_tool_output(tr.get("output", "")),
                            ),
                        ),
                    ],
                ),
            )
        return updates

    if isinstance(content, list):
        _content_blocks_to_updates(content, updates, tracker)

    if not updates:
        text = _get_msg_text(msg)
        if text:
            if tracker:
                text = tracker.delta_text(text)
            if text:
                updates.append(update_agent_message(text_block(text)))

    return updates


def _content_blocks_to_updates(
    content: list[Any],
    updates: list[Any],
    tracker: _StreamTracker | None = None,
) -> None:
    for block in content:
        block_type, block_data = _normalise_block(block)
        if block_type == "thinking":
            _emit_thinking(block_data, tracker, updates)
        elif block_type == "text":
            _emit_text(block_data, tracker, updates)
        elif block_type == "tool_use":
            tc_id = str(block_data.get("id") or uuid4().hex[:8])
            if not tracker or tracker.is_new_tool_call(tc_id):
                updates.append(
                    start_tool_call(
                        tc_id,
                        str(block_data.get("name") or "tool"),
                        status="in_progress",
                    ),
                )
        elif block_type == "tool_result":
            updates.append(
                update_tool_call(
                    str(block_data.get("id") or uuid4().hex[:8]),
                    status="completed",
                    content=[
                        tool_content(
                            text_block(
                                _extract_tool_output(
                                    block_data.get("output", ""),
                                ),
                            ),
                        ),
                    ],
                ),
            )


def _extract_tool_output(output: Any) -> str:
    if isinstance(output, str):
        return output
    if isinstance(output, list):
        parts = []
        for item in output:
            if isinstance(item, dict):
                parts.append(item.get("text", str(item)))
            else:
                parts.append(str(item))
        return "\n".join(parts)
    return str(output)


def _normalise_block(block: Any) -> tuple[str, dict[str, Any]]:
    if isinstance(block, dict):
        return block.get("type", "text"), block
    btype = getattr(block, "type", "text") or "text"
    data: dict[str, Any] = {}
    for attr in ("text", "thinking", "id", "name", "output"):
        val = getattr(block, attr, None)
        if val is not None:
            data[attr] = val
    return btype, data


def _emit_thinking(
    data: dict[str, Any],
    tracker: _StreamTracker | None,
    updates: list[Any],
) -> None:
    thinking = data.get("thinking", "")
    if tracker:
        thinking = tracker.delta_thinking(thinking)
    if thinking:
        updates.append(update_agent_thought(text_block(thinking)))


def _emit_text(
    data: dict[str, Any],
    tracker: _StreamTracker | None,
    updates: list[Any],
) -> None:
    text = data.get("text", "")
    if tracker:
        text = tracker.delta_text(text)
    if text:
        updates.append(update_agent_message(text_block(text)))


def _get_msg_text(msg: Any) -> str:
    get_text = getattr(msg, "get_text_content", None)
    if callable(get_text):
        return get_text() or ""
    content = getattr(msg, "content", "")
    if isinstance(content, str):
        return content
    return ""


class XingzierAIACPAgent(Agent):
    _conn: Client

    MODE_CONFIG_ID = "mode"
    MODE_DEFAULT = "default"
    MODE_BYPASS = "bypassPermissions"

    def __init__(
        self,
        agent_id: str | None = None,
        workspace_dir: Path | None = None,
    ):
        self._agent_id = agent_id
        self._workspace_dir = workspace_dir
        self._sessions: dict[str, dict[str, Any]] = {}
        self._cancel_events: dict[str, asyncio.Event] = {}
        self._workspace: Any | None = None
        self._workspace_ready = False

    def on_connect(self, conn: Client) -> None:
        self._conn = conn

    def _resolve_agent_id(self) -> str:
        if self._agent_id is not None:
            return self._agent_id

        from xingzierai.config.utils import load_config

        config = load_config()
        agents_cfg = getattr(config, "agents", None)
        if agents_cfg is not None:
            aid = getattr(agents_cfg, "active_agent", None)
            if aid:
                return aid
        return "default"

    def _resolve_workspace_dir(self, agent_id: str) -> Path:
        if self._workspace_dir is not None:
            return self._workspace_dir
        return WORKING_DIR / "workspaces" / agent_id

    async def _ensure_workspace(self) -> Any:
        if self._workspace is not None and self._workspace_ready:
            runner = self._workspace.runner
            if runner is None:
                raise RuntimeError(
                    "Workspace runner is not available after startup",
                )
            return runner

        from xingzierai.app.workspace.workspace import Workspace

        agent_id = self._resolve_agent_id()
        workspace_dir = self._resolve_workspace_dir(agent_id)

        workspace = Workspace(
            agent_id=agent_id,
            workspace_dir=str(workspace_dir),
        )
        await workspace.start()

        runner = workspace.runner
        if runner is None:
            raise RuntimeError(
                "Workspace started but runner is not available.",
            )
        await runner.init_handler()

        self._workspace = workspace
        self._workspace_ready = True
        logger.info(
            "XINGZIERAI ACP Agent workspace started: agent_id=%s workspace=%s",
            agent_id,
            workspace_dir,
        )
        return runner

    async def _shutdown_workspace(self) -> None:
        if self._workspace is not None:
            try:
                await self._workspace.stop(final=True)
            except Exception as _stop_err:
                logger.exception("Error stopping ACP workspace: %s", _stop_err)
            self._workspace = None
            self._workspace_ready = False

    async def initialize(
        self,
        protocol_version: int,
        client_capabilities: ClientCapabilities | None = None,
        client_info: Implementation | None = None,
        **kwargs: Any,
    ) -> InitializeResponse:
        logger.info(
            "ACP initialize: version=%d client=%s",
            protocol_version,
            client_info,
        )
        return InitializeResponse(
            protocol_version=protocol_version,
            agent_capabilities=AgentCapabilities(
                load_session=True,
                session_capabilities=SessionCapabilities(
                    close=SessionCloseCapabilities(),
                    list=SessionListCapabilities(),
                    resume=SessionResumeCapabilities(),
                ),
            ),
            agent_info=Implementation(
                name="xingzierai",
                title="XINGZIER AI",
                version=__version__,
            ),
        )

    async def new_session(
        self,
        cwd: str,
        mcp_servers: (
            list[HttpMcpServer | SseMcpServer | McpServerStdio] | None
        ) = None,
        **kwargs: Any,
    ) -> NewSessionResponse:
        session_id = uuid4().hex
        self._sessions[session_id] = {
            "cwd": cwd,
            "user_id": f"acp_{session_id[:8]}",
            "mode": self.MODE_DEFAULT,
        }
        logger.info("ACP new_session: id=%s cwd=%s", session_id, cwd)
        return NewSessionResponse(
            session_id=session_id,
            config_options=self._build_config_options(session_id),
        )

    async def load_session(
        self,
        cwd: str,
        session_id: str,
        mcp_servers: (
            list[HttpMcpServer | SseMcpServer | McpServerStdio] | None
        ) = None,
        **kwargs: Any,
    ) -> LoadSessionResponse | None:
        self._sessions[session_id] = {
            "cwd": cwd,
            "user_id": f"acp_{session_id[:8]}",
            "mode": self.MODE_DEFAULT,
        }
        logger.info("ACP load_session: id=%s cwd=%s", session_id, cwd)
        return LoadSessionResponse()

    async def prompt(
        self,
        prompt: PromptBlocks,
        session_id: str,
        message_id: str | None = None,
        **kwargs: Any,
    ) -> PromptResponse:
        logger.info("ACP prompt: session=%s", session_id)

        text = _extract_text(prompt)
        if not text:
            return PromptResponse(stop_reason="end_turn")

        runner = await self._ensure_workspace()
        session_info = self._sessions.get(session_id, {})
        user_id = session_info.get("user_id", f"acp_{session_id[:8]}")

        cancel_event = asyncio.Event()
        self._cancel_events[session_id] = cancel_event

        msgs = [
            Msg(name="user", role="user", content=text),
        ]

        session_mode = session_info.get("mode", self.MODE_DEFAULT)
        request_context: dict[str, str] = {}
        if session_mode == self.MODE_BYPASS:
            request_context["_headless_tool_guard"] = "false"

        request = AgentRequest(
            input=[
                Message(
                    role="user",
                    content=[{"type": "text", "text": text}],
                ),
            ],
            session_id=session_id,
            user_id=user_id,
            request_context=request_context or None,
        )

        tracker = _StreamTracker()

        try:
            async for msg, _is_last in runner.query_handler(msgs, request=request):
                if cancel_event.is_set():
                    logger.info("ACP prompt cancelled: session=%s", session_id)
                    break

                updates = _msg_to_updates(msg, tracker)
                for upd in updates:
                    await self._conn.session_update(
                        session_id=session_id,
                        update=upd,
                    )

                await self._emit_usage_if_available(session_id)
        except Exception as _prompt_err:
            logger.exception("ACP prompt error: session=%s: %s", session_id, _prompt_err)
        finally:
            self._cancel_events.pop(session_id, None)

        await self._emit_usage_if_available(session_id)

        return PromptResponse(stop_reason="end_turn")

    async def close_session(
        self,
        session_id: str,
        **kwargs: Any,
    ) -> CloseSessionResponse | None:
        logger.info("ACP close_session: session=%s", session_id)
        self._sessions.pop(session_id, None)
        self._cancel_events.pop(session_id, None)
        return CloseSessionResponse()

    async def list_sessions(
        self,
        cursor: str | None = None,
        cwd: str | None = None,
        **kwargs: Any,
    ) -> ListSessionsResponse:
        logger.info("ACP list_sessions: cwd=%s", cwd)
        sessions: list[SessionInfo] = []
        for sid, info in self._sessions.items():
            sess_cwd = info.get("cwd", "")
            if cwd is not None and sess_cwd != cwd:
                continue
            sessions.append(
                SessionInfo(
                    session_id=sid,
                    cwd=sess_cwd,
                    title=f"ACP session {sid[:8]}",
                ),
            )
        return ListSessionsResponse(sessions=sessions)

    async def resume_session(
        self,
        cwd: str,
        session_id: str,
        mcp_servers: (
            list[HttpMcpServer | SseMcpServer | McpServerStdio] | None
        ) = None,
        **kwargs: Any,
    ) -> ResumeSessionResponse:
        logger.info("ACP resume_session: id=%s cwd=%s", session_id, cwd)
        if session_id not in self._sessions:
            self._sessions[session_id] = {
                "cwd": cwd,
                "user_id": f"acp_{session_id[:8]}",
                "mode": self.MODE_DEFAULT,
            }
        else:
            self._sessions[session_id]["cwd"] = cwd
        return ResumeSessionResponse()

    async def set_session_model(
        self,
        model_id: str,
        session_id: str,
        **kwargs: Any,
    ) -> SetSessionModelResponse | None:
        logger.info(
            "ACP set_session_model: session=%s model=%s",
            session_id,
            model_id,
        )
        try:
            await self._switch_model(model_id)
        except Exception as _switch_err:
            logger.exception("Failed to switch model to %s: %s", model_id, _switch_err)
            return None
        logger.info(
            "Model switched to %s for agent %s",
            model_id,
            self._resolve_agent_id(),
        )
        return SetSessionModelResponse()

    async def set_config_option(
        self,
        config_id: str,
        session_id: str,
        value: str | bool,
        **kwargs: Any,
    ) -> SetSessionConfigOptionResponse | None:
        logger.info(
            "ACP set_config_option: session=%s config=%s value=%s",
            session_id,
            config_id,
            value,
        )
        if config_id == self.MODE_CONFIG_ID:
            if value not in (self.MODE_DEFAULT, self.MODE_BYPASS):
                raise ValueError(
                    f"Invalid mode value: {value!r}. "
                    f"Must be '{self.MODE_DEFAULT}' or '{self.MODE_BYPASS}'.",
                )
            str_value = str(value)
            if str_value == self.MODE_BYPASS:
                logger.warning(
                    "Tool guard DISABLED for session %s", session_id,
                )
            if session_id in self._sessions:
                self._sessions[session_id]["mode"] = str_value
            return SetSessionConfigOptionResponse(
                config_options=self._build_config_options(session_id),
            )
        return None

    async def cancel(self, session_id: str, **kwargs: Any) -> None:
        logger.info("ACP cancel: session=%s", session_id)
        event = self._cancel_events.get(session_id)
        if event is not None:
            event.set()

    async def _emit_usage_if_available(self, session_id: str) -> None:
        usage_meta = self._pop_session_usage(session_id)
        if usage_meta:
            await self._conn.session_update(
                session_id=session_id,
                update=AgentMessageChunk(
                    sessionUpdate="agent_message_chunk",
                    content=text_block(""),
                    field_meta=usage_meta,
                ),
            )

    @staticmethod
    def _pop_session_usage(session_id: str) -> dict[str, Any] | None:
        try:
            from xingzierai.token_usage.model_wrapper import (
                TokenRecordingModelWrapper,
            )

            raw = TokenRecordingModelWrapper.pop_usage_for_session(session_id)
        except Exception as _usage_err:
            logger.debug("Token usage pop failed: %s", _usage_err)
            return None
        if not raw:
            return None
        return {
            "usage": {
                "inputTokens": raw.get("prompt_tokens", 0),
                "outputTokens": raw.get("completion_tokens", 0),
                "totalTokens": raw.get("total_tokens", 0),
            },
        }

    def _get_session_mode(self, session_id: str) -> str:
        info = self._sessions.get(session_id)
        if info is not None:
            return info.get("mode", self.MODE_DEFAULT)
        return self.MODE_DEFAULT

    def _build_config_options(
        self,
        session_id: str,
    ) -> list[SessionConfigOptionSelect]:
        current_mode = self._get_session_mode(session_id)
        return [
            SessionConfigOptionSelect(
                type="select",
                id=self.MODE_CONFIG_ID,
                name="Session Mode",
                category="mode",
                description=(
                    "Controls tool guard and permission behavior. "
                    "'Bypass Permissions' disables all security checks."
                ),
                current_value=current_mode,
                options=[
                    SessionConfigSelectOption(
                        value=self.MODE_DEFAULT,
                        name="Default",
                        description="Normal mode with Tool Guard enabled",
                    ),
                    SessionConfigSelectOption(
                        value=self.MODE_BYPASS,
                        name="Bypass Permissions",
                        description="Skip all tool guard security checks",
                    ),
                ],
            ),
        ]

    async def _switch_model(self, model_spec: str) -> None:
        if ":" in model_spec:
            provider_id, model_id = model_spec.split(":", 1)
        else:
            provider_id, model_id = "", model_spec

        manager = ProviderManager.get_instance()

        if provider_id:
            provider = manager.get_provider(provider_id)
            if not provider:
                raise ValueError(f"Provider {provider_id!r} not found")
            if not provider.has_model(model_id):
                raise ValueError(
                    f"Model {model_id!r} not found in provider {provider_id!r}",
                )
        else:
            all_infos = await manager.list_provider_info()
            matched = False
            for pinfo in all_infos:
                all_models = list(pinfo.models) + list(pinfo.extra_models)
                if any(m.id == model_id for m in all_models):
                    provider_id = pinfo.id
                    matched = True
                    break
            if not matched:
                raise ValueError(
                    f"Model {model_id!r} not found in any provider",
                )

        from xingzierai.config.config import load_agent_config, save_agent_config

        agent_id = self._resolve_agent_id()
        agent_config = load_agent_config(agent_id)
        agent_config.active_model = ModelSlotConfig(
            provider_id=provider_id,
            model=model_id,
        )
        save_agent_config(agent_id, agent_config)


async def run_xingzierai_agent(
    agent_id: str | None = None,
    workspace_dir: Path | None = None,
) -> None:
    agent = XingzierAIACPAgent(
        agent_id=agent_id,
        workspace_dir=workspace_dir,
    )
    try:
        await run_agent(agent, use_unstable_protocol=True)
    finally:
        await agent._shutdown_workspace()
