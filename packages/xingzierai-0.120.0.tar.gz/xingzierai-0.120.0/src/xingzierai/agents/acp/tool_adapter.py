# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any

from xingzierai.agentscope_core.tool import ToolResponse

from .core import ACPErrors
from .service import ACPService


def _tool_response_from_acp(
    result: dict[str, Any],
    agent: str,
) -> ToolResponse:
    status = result.get("status", "completed")
    event = result.get("event") or {}
    suspended = result.get("suspended_permission")

    if status == "permission_required" and suspended is not None:
        options = getattr(suspended, "options", []) or []
        option_lines = []
        for idx, opt in enumerate(options):
            if isinstance(opt, dict):
                opt_id = opt.get("optionId") or opt.get("option_id") or str(idx)
                label = opt.get("title") or opt.get("name") or opt_id
                option_lines.append(f"  [{idx}] {label} (id: {opt_id})")
        options_text = "\n".join(option_lines) if option_lines else "  (no options)"

        title = getattr(suspended, "summary", None) or getattr(
            suspended, "tool_name", "external-agent",
        )
        return ToolResponse(
            content=(
                f"ACP agent '{agent}' is requesting permission for: {title}\n"
                f"Options:\n{options_text}\n"
                f"Use 'acp_resume' with the option id to proceed."
            ),
        )

    text = ""
    if isinstance(event, dict):
        text = event.get("text", "")
    if not text:
        text = f"(ACP agent '{agent}' completed with no output)"
    return ToolResponse(content=text)


async def delegate_to_acp_agent(
    *,
    service: ACPService,
    chat_id: str,
    agent: str,
    prompt: str,
    cwd: str = ".",
    on_message: Any = None,
    restart: bool = False,
) -> ToolResponse:
    prompt_blocks = [{"type": "text", "text": prompt}]

    async def _default_message_handler(
        payload: dict[str, Any],
        is_last: bool,
    ) -> None:
        pass

    handler = on_message or _default_message_handler

    try:
        result = await service.run_turn(
            chat_id=chat_id,
            agent=agent,
            prompt_blocks=prompt_blocks,
            cwd=cwd,
            on_message=handler,
            restart=restart,
        )
    except ACPErrors as exc:
        return ToolResponse(
            content=f"ACP error ({agent}): {exc}",
        )
    except Exception as exc:
        return ToolResponse(
            content=f"ACP unexpected error ({agent}): {exc}",
        )

    return _tool_response_from_acp(result, agent)


async def resume_acp_permission(
    *,
    service: ACPService,
    acp_session_id: str,
    option_id: str,
    on_message: Any = None,
) -> ToolResponse:
    async def _default_message_handler(
        payload: dict[str, Any],
        is_last: bool,
    ) -> None:
        pass

    handler = on_message or _default_message_handler

    try:
        result = await service.resume_permission(
            acp_session_id=acp_session_id,
            option_id=option_id,
            on_message=handler,
        )
    except ACPErrors as exc:
        return ToolResponse(
            content=f"ACP resume error: {exc}",
        )
    except Exception as exc:
        return ToolResponse(
            content=f"ACP resume unexpected error: {exc}",
        )

    return _tool_response_from_acp(result, "acp")
