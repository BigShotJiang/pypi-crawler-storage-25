# -*- coding: utf-8 -*-
"""Brain-Hand Decoupling Architecture (Anthropic Managed Agents inspired).

Implements the Session-Harness-Sandbox pattern:
- Session: Append-only event log, persists independently
- Harness: Stateless orchestration layer (the "brain")
- Sandbox: Disposable execution environment (the "hands")

Key principles:
1. Brain crashes don't lose work (session persists)
2. Sandbox crashes are recovered by killing + restarting (cattle mode)
3. Credentials never reach the sandbox (vault proxy)
4. Each component can fail or be replaced independently

Reference: Anthropic "Scaling Managed Agents: Decoupling the brain from the hands" (April 2026)
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import signal
import subprocess
import sys
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_SESSION_DIR = Path.home() / ".xingzierai" / "sessions"


class EventType(str, Enum):
    USER_INPUT = "user_input"
    LLM_DECISION = "llm_decision"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    MEMORY_OP = "memory_op"
    SYSTEM = "system"
    ERROR = "error"


@dataclass
class Event:
    event_type: EventType
    content: dict
    session_id: str = ""
    agent_id: str = ""
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: dict = field(default_factory=dict)


class Session:
    """Append-only event log - the persistent state layer.

    Events are never deleted or modified, only appended.
    This is the 'black box' that survives crashes.
    """

    MAX_EVENTS = 5000
    INDEX_SAVE_INTERVAL = int(os.getenv("XINGZIERAI_SESSION_INDEX_INTERVAL", "10"))

    def __init__(self, session_id: str):
        self.session_id = session_id
        self._dir = _SESSION_DIR / session_id
        self._dir.mkdir(parents=True, exist_ok=True)
        self._event_file = self._dir / "events.jsonl"
        self._index_file = self._dir / "index.json"
        self._event_count = 0
        self._truncated = False
        self._dirty_count = 0
        self._load_index()

    def _load_index(self):
        if self._index_file.exists():
            try:
                data = json.loads(self._index_file.read_text(encoding="utf-8"))
                self._event_count = data.get("count", 0)
            except Exception as _idx_err:
                logger.debug("Failed to load session index: %s", _idx_err)

    def _save_index(self):
        tmp = self._index_file.with_suffix(".tmp")
        tmp.write_text(json.dumps({
            "count": self._event_count,
            "session_id": self.session_id,
            "updated_at": datetime.now().isoformat(),
        }, ensure_ascii=False, indent=2))
        tmp.replace(self._index_file)

    def append(self, event: Event) -> str:
        event.session_id = self.session_id
        with open(self._event_file, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "event_id": event.event_id,
                "event_type": event.event_type.value,
                "content": event.content,
                "session_id": event.session_id,
                "agent_id": event.agent_id,
                "timestamp": event.timestamp,
                "metadata": event.metadata,
            }, ensure_ascii=False) + "\n")
        self._event_count += 1
        self._dirty_count += 1
        if self._event_count > self.MAX_EVENTS and not self._truncated:
            self._truncate_old_events()
        if self._dirty_count >= self.INDEX_SAVE_INTERVAL:
            self._dirty_count = 0
            self._save_index()
        return event.event_id

    def query(
        self,
        event_type: Optional[EventType] = None,
        since: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[dict]:
        events = []
        if not self._event_file.exists():
            return events
        with open(self._event_file, encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line.strip())
                    if event_type and e.get("event_type") != event_type.value:
                        continue
                    if since and e.get("timestamp", "") < since:
                        continue
                    events.append(e)
                except Exception as _parse_err:
                    logger.debug("Skipping malformed event line: %s", _parse_err)
                    continue
        return events[offset:offset + limit]

    def replay(self, since: Optional[str] = None) -> List[dict]:
        return self.query(since=since, limit=10000)

    @property
    def event_count(self) -> int:
        return self._event_count

    def get_last_position(self) -> Optional[str]:
        events = self.query(limit=1, offset=max(0, self._event_count - 1))
        if events:
            return events[0].get("event_id")
        return None

    def _truncate_old_events(self) -> None:
        keep_count = self.MAX_EVENTS // 2
        if self._event_count <= keep_count:
            return

        if not self._event_file.exists():
            return

        all_events = self.replay()
        if len(all_events) <= keep_count:
            return

        kept = all_events[-keep_count:]
        backup = self._event_file.with_suffix(".jsonl.bak")
        self._event_file.rename(backup)

        tmp = self._event_file.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            for e in kept:
                f.write(json.dumps(e, ensure_ascii=False) + "\n")
        tmp.replace(self._event_file)

        self._event_count = len(kept)
        self._truncated = True
        logger.warning(
            "[Session] action=truncated session=%s before=%d after=%d",
            self.session_id, len(all_events), len(kept),
        )


class SessionManager:
    """Manages multiple sessions."""

    def __init__(self):
        _SESSION_DIR.mkdir(parents=True, exist_ok=True)

    def create_session(self, agent_id: str = "") -> Session:
        session_id = f"s_{uuid.uuid4().hex[:8]}_{int(time.time())}"
        session = Session(session_id)
        session.append(Event(
            event_type=EventType.SYSTEM,
            content={"action": "session_created", "agent_id": agent_id},
        ))
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        session_dir = _SESSION_DIR / session_id
        if session_dir.exists():
            return Session(session_id)
        return None

    def list_sessions(self) -> List[dict]:
        sessions = []
        if _SESSION_DIR.exists():
            for d in sorted(_SESSION_DIR.iterdir(), reverse=True):
                if d.is_dir() and (d / "index.json").exists():
                    try:
                        data = json.loads((d / "index.json").read_text(encoding="utf-8"))
                        sessions.append(data)
                    except Exception as _session_load_err:
                        logger.debug("Skipping corrupt session index %s: %s", d.name, _session_load_err)
        return sessions


class SandboxState(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    CRASHED = "crashed"
    KILLED = "killed"


@dataclass
class SandboxConfig:
    timeout: float = 60.0
    max_memory_mb: int = 512
    cpu_limit: float = 1.0
    allowed_commands: List[str] = field(default_factory=lambda: [
        "python3", "node", "git", "ls", "cat", "head", "tail", "grep",
        "find", "wc", "sort", "uniq", "curl", "echo",
    ])
    blocked_commands: List[str] = field(default_factory=lambda: [
        "rm -rf /", "sudo", "mkfs", "dd if=", ":(){ :|:& };:",
    ])
    network_allowed: bool = True
    filesystem_roots: List[str] = field(default_factory=list)


class Sandbox:
    """Disposable execution environment - the 'hands'.

    Sandboxes are treated as cattle: replaced rather than repaired.
    When a sandbox crashes, it's killed and a new one is provisioned.
    """

    def __init__(
        self,
        sandbox_id: str,
        config: SandboxConfig = None,
    ):
        self.sandbox_id = sandbox_id
        self.config = config or SandboxConfig()
        self.state = SandboxState.IDLE
        self._created_at = time.time()
        self._last_used = time.time()
        self._execution_count = 0
        self._error_count = 0

    async def execute(self, tool_name: str, params: dict) -> dict:
        self.state = SandboxState.RUNNING
        self._last_used = time.time()
        self._execution_count += 1

        try:
            result = await asyncio.wait_for(
                self._do_execute(tool_name, params),
                timeout=self.config.timeout,
            )
            self.state = SandboxState.IDLE
            return result
        except asyncio.TimeoutError:
            self.state = SandboxState.CRASHED
            self._error_count += 1
            return {"error": f"Execution timed out after {self.config.timeout}s"}
        except Exception as e:
            self.state = SandboxState.CRASHED
            self._error_count += 1
            return {"error": str(e)}

    async def _do_execute(self, tool_name: str, params: dict) -> dict:
        if tool_name == "shell":
            return await self._execute_shell(params)
        elif tool_name == "read_file":
            return await self._execute_read_file(params)
        elif tool_name == "write_file":
            return await self._execute_write_file(params)
        else:
            return await self._execute_generic(tool_name, params)

    async def _execute_shell(self, params: dict) -> dict:
        command = params.get("command", "")
        if not self._is_command_allowed(command):
            return {"error": f"Command not allowed: {command[:50]}"}

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=self.config.timeout,
            )
            return {
                "stdout": stdout.decode("utf-8", errors="replace")[:10000],
                "stderr": stderr.decode("utf-8", errors="replace")[:5000],
                "exit_code": proc.returncode,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"error": "Command timed out"}

    async def _execute_read_file(self, params: dict) -> dict:
        path = params.get("path", "")
        try:
            p = Path(path).resolve()
            if not p.exists():
                return {"error": f"File not found: {path}"}
            content = p.read_text(encoding="utf-8", errors="replace")[:50000]
            return {"content": content, "path": str(p)}
        except Exception as e:
            return {"error": str(e)}

    async def _execute_write_file(self, params: dict) -> dict:
        path = params.get("path", "")
        content = params.get("content", "")
        try:
            p = Path(path).resolve()
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return {"success": True, "path": str(p), "bytes": len(content)}
        except Exception as e:
            return {"error": str(e)}

    async def _execute_generic(self, tool_name: str, params: dict) -> dict:
        return {"tool": tool_name, "params": params, "status": "executed_in_sandbox"}

    def _is_command_allowed(self, command: str) -> bool:
        try:
            parts = shlex.split(command)
        except ValueError:
            logger.warning("[Sandbox] action=command_parse_failed command=%.50s", command[:50])
            return False

        if not parts:
            return False

        cmd_name = os.path.basename(parts[0].lower())

        dangerous_commands = {
            "rm", "sudo", "mkfs", "dd", "fork", "kill", "killall",
            "reboot", "shutdown", "halt", "poweroff", "init",
            ":()", "exec", "eval", "source", "chmod", "chown",
        }

        if cmd_name in dangerous_commands:
            logger.warning("[Sandbox] action=command_blocked cmd=%s", cmd_name)
            return False

        blocked_patterns = [
            "rm -rf /", "rm -rf /*", "fork bomb", ":(){", "dd if=",
        ]

        for pattern in blocked_patterns:
            if pattern in command:
                logger.warning("[Sandbox] action=command_blocked_pattern pattern=%s", pattern)
                return False

        return True

    def kill(self):
        self.state = SandboxState.KILLED

    def is_healthy(self) -> bool:
        return self.state in (SandboxState.IDLE, SandboxState.RUNNING)

    @property
    def stats(self) -> dict:
        return {
            "sandbox_id": self.sandbox_id,
            "state": self.state.value,
            "created_at": self._created_at,
            "last_used": self._last_used,
            "execution_count": self._execution_count,
            "error_count": self._error_count,
        }


class SandboxPool:
    """Pool of disposable sandboxes - cattle mode.

    Sandboxes are provisioned on demand and replaced when they crash.
    """

    MAX_POOL_SIZE = int(os.getenv("XINGZIERAI_SB_MAX_POOL", "10"))

    def __init__(self, pool_size: int = 3, config: SandboxConfig = None):
        self.pool_size = min(pool_size, self.MAX_POOL_SIZE)
        self.config = config or SandboxConfig()
        self._sandboxes: Dict[str, Sandbox] = {}
        self._assignment: Dict[str, str] = {}
        self._IDLE_TIMEOUT_SECONDS = 600
        self._last_cleanup_time = 0.0

    def _cleanup_idle_sandboxes(self):
        now = time.time()
        if now - self._last_cleanup_time < 300:
            return
        self._last_cleanup_time = now
        idle_ids = []
        for sid, sb in self._sandboxes.items():
            if sb.state == SandboxState.IDLE:
                try:
                    last_used = sb._last_used if isinstance(sb._last_used, (int, float)) else datetime.fromisoformat(sb._last_used).timestamp()
                except (ValueError, OSError, TypeError):
                    last_used = 0
                if now - last_used > self._IDLE_TIMEOUT_SECONDS:
                    idle_ids.append(sid)
        for sid in idle_ids:
            sb = self._sandboxes.get(sid)
            if sb:
                sb.kill()
            del self._sandboxes[sid]
            for agent_id, assigned_sid in list(self._assignment.items()):
                if assigned_sid == sid:
                    del self._assignment[agent_id]
        if idle_ids:
            logger.info("[SandboxPool] action=cleanup_idle count=%d timeout=%ds", len(idle_ids), self._IDLE_TIMEOUT_SECONDS)

    def provision(self, agent_id: str = "") -> Sandbox:
        self._cleanup_idle_sandboxes()
        if len(self._sandboxes) >= self.MAX_POOL_SIZE:
            oldest_id = min(self._sandboxes.keys(),
                            key=lambda sid: self._sandboxes[sid]._last_used)
            old_sb = self._sandboxes.pop(oldest_id)
            old_sb.kill()
            for aid, asid in list(self._assignment.items()):
                if asid == oldest_id:
                    del self._assignment[aid]
            logger.warning("[SandboxPool] action=evict max=%d evicted=%s", self.MAX_POOL_SIZE, oldest_id)
        sandbox_id = f"sb_{uuid.uuid4().hex[:8]}"
        sandbox = Sandbox(sandbox_id, self.config)
        self._sandboxes[sandbox_id] = sandbox
        if agent_id:
            self._assignment[agent_id] = sandbox_id
        logger.info("[SandboxPool] action=provision sandbox=%s agent=%s", sandbox_id, agent_id)
        return sandbox

    def get_or_provision(self, agent_id: str) -> Sandbox:
        self._cleanup_idle_sandboxes()
        sandbox_id = self._assignment.get(agent_id)
        if sandbox_id and sandbox_id in self._sandboxes:
            sb = self._sandboxes[sandbox_id]
            if sb.is_healthy():
                return sb
            else:
                self._replace_sandbox(sandbox_id)

        return self.provision(agent_id)

    def _replace_sandbox(self, sandbox_id: str):
        old = self._sandboxes.get(sandbox_id)
        if old:
            old.kill()
            del self._sandboxes[sandbox_id]
            logger.info("[SandboxPool] action=kill_crashed sandbox=%s", sandbox_id)

    async def execute(self, agent_id: str, tool_name: str, params: dict) -> dict:
        sandbox = self.get_or_provision(agent_id)
        result = await sandbox.execute(tool_name, params)

        if not sandbox.is_healthy():
            self._replace_sandbox(sandbox.sandbox_id)
            del self._assignment[agent_id]
            logger.info("[SandboxPool] action=crash_recovery sandbox=%s", sandbox.sandbox_id)

        return result

    def get_stats(self) -> dict:
        return {
            "pool_size": len(self._sandboxes),
            "healthy": sum(1 for s in self._sandboxes.values() if s.is_healthy()),
            "sandboxes": {sid: sb.stats for sid, sb in self._sandboxes.items()},
        }


class VaultProxy:
    """Credential vault - credentials never reach the sandbox.

    Inspired by Anthropic's vault architecture:
    - Git tokens injected during init but unavailable to generated code
    - OAuth tokens sit in secure vault, accessed through proxy
    - Agent never sees raw authentication material
    """

    SENSITIVE_ENV_VARS = [
        "API_KEY", "SECRET", "PASSWORD", "TOKEN",
        "XEVOLVE_API_KEY", "DATABASE_URL",
    ]

    def __init__(self):
        self._vault: Dict[str, str] = {}
        self._audit_log: deque = deque(maxlen=1000)
        self._audit_file = Path.home() / ".xingzierai" / "vault" / "audit.jsonl"
        self._load_vault()
        self._load_audit_log()

    def _load_audit_log(self):
        if self._audit_file.exists():
            try:
                with open(self._audit_file, "r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            entry = json.loads(line.strip())
                            self._audit_log.append(entry)
                        except json.JSONDecodeError:
                            continue
            except Exception as _audit_load_err:
                logger.debug("Failed to load audit log: %s", _audit_load_err)

    def _save_audit_entry(self, entry: dict):
        try:
            self._audit_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._audit_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as _audit_save_err:
            logger.debug("Failed to save audit entry: %s", _audit_save_err)

    def _load_vault(self):
        vault_file = Path.home() / ".xingzierai" / "vault" / "secrets.json"
        if vault_file.exists():
            try:
                data = json.loads(vault_file.read_text(encoding="utf-8"))
                self._vault = data
            except Exception as _vault_load_err:
                logger.debug("Failed to load vault: %s", _vault_load_err)

    def store(self, key: str, value: str):
        self._vault[key] = value
        self._persist()
        self._audit("store", key)

    def get(self, key: str) -> Optional[str]:
        value = self._vault.get(key)
        self._audit("access", key, granted=value is not None)
        return value

    def proxy_call(self, service: str, request: dict) -> dict:
        """Proxy an API call using stored credentials.

        The caller never sees the credentials - they're injected here.
        """
        credential_key = f"{service}:api_key"
        api_key = self._vault.get(credential_key)

        if not api_key:
            self._audit("proxy_denied", service, granted=False)
            return {"error": f"No credentials stored for {service}"}

        self._audit("proxy_call", service, granted=True)

        return {
            "service": service,
            "status": "proxied",
            "note": "Credentials injected by vault, not exposed to caller",
        }

    def filter_env(self, env: dict) -> dict:
        """Remove sensitive variables from environment dict."""
        filtered = {}
        for key, value in env.items():
            if not any(s in key.upper() for s in self.SENSITIVE_ENV_VARS):
                filtered[key] = value
        return filtered

    def get_safe_env(self) -> dict:
        """Get environment dict with sensitive vars removed."""
        return self.filter_env(dict(os.environ))

    def _audit(self, action: str, resource: str, granted: bool = True):
        entry = {
            "action": action,
            "resource": resource,
            "granted": granted,
            "timestamp": datetime.now().isoformat(),
        }
        self._audit_log.append(entry)
        self._save_audit_entry(entry)

    def _persist(self):
        vault_dir = Path.home() / ".xingzierai" / "vault"
        vault_dir.mkdir(parents=True, exist_ok=True)
        vault_file = vault_dir / "secrets.json"
        tmp = vault_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._vault, ensure_ascii=False, indent=2))
        tmp.replace(vault_file)
        vault_file.chmod(0o600)

    def get_audit_log(self, limit: int = 50) -> List[dict]:
        return list(self._audit_log)[-limit:]


class Harness:
    """Stateless orchestration layer - the 'brain'.

    Calls the LLM, routes tool results, manages context.
    Because it's stateless, it can be replaced instantly:
    a crash is caught, a new harness wakes with wake(session_id),
    and execution resumes from the last event.
    """

    def __init__(
        self,
        session: Session,
        sandbox_pool: SandboxPool,
        vault: VaultProxy,
        agent_id: str = "",
    ):
        self.session = session
        self.sandbox_pool = sandbox_pool
        self.vault = vault
        self.agent_id = agent_id
        self._is_running = False

    async def process_user_input(self, user_input: str) -> AsyncIterator[dict]:
        self._is_running = True

        self.session.append(Event(
            event_type=EventType.USER_INPUT,
            content={"text": user_input},
            agent_id=self.agent_id,
        ))

        yield {
            "type": "status",
            "message": "Processing input...",
        }

        self.session.append(Event(
            event_type=EventType.LLM_DECISION,
            content={"action": "thinking", "input_length": len(user_input)},
            agent_id=self.agent_id,
        ))

        yield {
            "type": "decision",
            "message": "LLM decision recorded",
        }

        self._is_running = False

    async def execute_tool(self, tool_name: str, params: dict) -> dict:
        self.session.append(Event(
            event_type=EventType.TOOL_CALL,
            content={"tool": tool_name, "params": str(params)[:1000]},
            agent_id=self.agent_id,
        ))

        safe_env = self.vault.get_safe_env()
        params["_env"] = safe_env

        result = await self.sandbox_pool.execute(self.agent_id, tool_name, params)

        self.session.append(Event(
            event_type=EventType.TOOL_RESULT,
            content={"tool": tool_name, "result": str(result)[:2000]},
            agent_id=self.agent_id,
        ))

        return result

    def wake(self, session_id: str) -> bool:
        """Wake up with an existing session (crash recovery)."""
        session = SessionManager().get_session(session_id)
        if session:
            self.session = session
            logger.info("[Harness] action=wake session=%s events=%d", session_id, session.event_count)
            return True
        return False

    @property
    def is_running(self) -> bool:
        return self._is_running


class ManagedAgentOrchestrator:
    """Top-level orchestrator combining Session + Harness + Sandbox + Vault.

    This is the main entry point for the brain-hand architecture.
    """

    _instance: Optional["ManagedAgentOrchestrator"] = None
    _lock: Optional[asyncio.Lock] = None
    MAX_HARNESSES = int(os.getenv("XINGZIERAI_MA_MAX_HARNESSES", "50"))

    def __init__(self):
        self.session_mgr = SessionManager()
        self.sandbox_pool = SandboxPool()
        self.vault = VaultProxy()
        self._harnesses: Dict[str, Harness] = {}

    @classmethod
    def get_instance(cls) -> "ManagedAgentOrchestrator":
        if cls._instance is None:
            if cls._lock is None:
                cls._lock = asyncio.Lock()
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    def create_agent(self, agent_id: str) -> Harness:
        if len(self._harnesses) >= self.MAX_HARNESSES:
            oldest_id = next(iter(self._harnesses))
            del self._harnesses[oldest_id]
            logger.warning("[ManagedAgent] action=harness_evict max=%d evicted=%s", self.MAX_HARNESSES, oldest_id)
        session = self.session_mgr.create_session(agent_id)
        harness = Harness(session, self.sandbox_pool, self.vault, agent_id)
        self._harnesses[agent_id] = harness
        return harness

    def get_harness(self, agent_id: str) -> Optional[Harness]:
        return self._harnesses.get(agent_id)

    def recover_harness(self, agent_id: str, session_id: str) -> Optional[Harness]:
        if len(self._harnesses) >= self.MAX_HARNESSES:
            oldest_id = next(iter(self._harnesses))
            del self._harnesses[oldest_id]
            logger.warning("[ManagedAgent] action=harness_evict max=%d evicted=%s", self.MAX_HARNESSES, oldest_id)
        session = self.session_mgr.get_session(session_id)
        if not session:
            return None
        harness = Harness(session, self.sandbox_pool, self.vault, agent_id)
        self._harnesses[agent_id] = harness
        logger.info("[ManagedAgent] action=recover agent=%s session=%s", agent_id, session_id)
        return harness

    def get_status(self) -> dict:
        return {
            "active_harnesses": len(self._harnesses),
            "sandbox_pool": self.sandbox_pool.get_stats(),
            "vault_audit_entries": len(self.vault._audit_log),
            "sessions": self.session_mgr.list_sessions()[:10],
        }
