# -*- coding: utf-8 -*-
# flake8: noqa: E501
# pylint: disable=line-too-long
import os
from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse
from xingzierai.agentscope_core._logging import logger

from ...constant import WORKING_DIR
from ...config.context import get_current_workspace_dir
from .utils import truncate_file_output, read_file_safe


_PROJECT_ROOT_MARKERS = ["src/xingzierai", "console/src", "xingzierai-evolution/src"]

_AUDIT_LOG_PATH = Path(WORKING_DIR) / ".evolution" / "audit.log"


def _lightweight_verify(file_path: str, content: str) -> list[str]:
    """Lightweight verification for file writes (GATE 1 + GATE 3).

    Checks syntax and path safety before writing.
    Returns list of warnings (does not block writes).
    """
    warnings = []

    ext = Path(file_path).suffix
    if ext == ".py" and content.strip():
        try:
            compile(content, file_path, "exec")
        except SyntaxError as e:
            warnings.append("SYNTAX ERROR: %s (line %d)" % (e.msg, e.lineno or 0))
            logger.warning("Lightweight verify: syntax error in %s: %s", file_path, e)

    if any(part.startswith("..") for part in Path(file_path).parts):
        warnings.append("PATH WARNING: Relative path traversal detected in %s" % file_path)
        logger.warning("Lightweight verify: path traversal in %s", file_path)

    if warnings:
        logger.info("Lightweight verify warnings for %s: %s", file_path, warnings)

    return warnings


def _audit_log(action: str, file_path: str, blocked: bool, reason: str = ""):
    try:
        _AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        import datetime
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status = "BLOCKED" if blocked else "ALLOWED"
        line = "[%s] %s %s %s" % (ts, status, action, file_path)
        if reason:
            line += " reason=%s" % reason
        with open(_AUDIT_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as _audit_err:
        logger.debug("Audit log write failed: %s", _audit_err)


def _is_project_source_file(resolved_path: str) -> bool:
    """Check if the file is part of the XINGZIERAI project source code.

    If so, the agent should use request_evolution() instead of write_file()
    to ensure safety checks (validation, git checkpoint, rollback).
    """
    try:
        real_path = Path(resolved_path).resolve()
        project_root = Path(WORKING_DIR).resolve()
        try:
            real_path.relative_to(project_root)
        except ValueError:
            return False
        for marker in _PROJECT_ROOT_MARKERS:
            marker_path = (project_root / marker).resolve()
            try:
                real_path.relative_to(marker_path)
                return True
            except ValueError:
                continue
    except Exception as _path_resolve_err:
        logger.debug("Path resolution failed for %s: %s", resolved_path, _path_resolve_err)
    return False


_SENSITIVE_PATHS = [
    "/etc/shadow", "/etc/passwd", "/etc/ssh/", "/etc/gshadow",
    "/.ssh/", "/.gnupg/", "/.aws/", "/.kube/",
    "/.env", "/.git/", "/.config/credentials",
]

def _is_path_within_allowed_bounds(resolved_path: str) -> bool:
    """Check if a resolved path is within the allowed workspace bounds."""
    resolved = Path(resolved_path).resolve()
    workspace_dir = Path(get_current_workspace_dir() or WORKING_DIR).resolve()
    try:
        resolved.relative_to(workspace_dir)
        return True
    except ValueError:
        pass
    for sensitive in _SENSITIVE_PATHS:
        if str(resolved).startswith(sensitive) or str(resolved) == sensitive.rstrip("/"):
            return False
    return True

def _resolve_file_path(file_path: str) -> str:
    """Resolve file path: use absolute path as-is,
    resolve relative path from current workspace or WORKING_DIR.

    Args:
        file_path: The input file path (absolute or relative).

    Returns:
        The resolved absolute file path as string.

    Raises:
        ValueError: If the resolved path is outside allowed workspace bounds.
    """
    path = Path(file_path).expanduser().resolve()
    if path.is_absolute():
        resolved = str(path)
    else:
        workspace_dir = get_current_workspace_dir() or WORKING_DIR
        resolved = str((Path(workspace_dir) / file_path).resolve())
    workspace_dir = Path(get_current_workspace_dir() or WORKING_DIR).resolve()
    try:
        Path(resolved).relative_to(workspace_dir)
    except ValueError:
        if not _is_path_within_allowed_bounds(resolved):
            raise ValueError(
                "Path traversal detected: '%s' resolves outside workspace '%s'" % (file_path, workspace_dir)
            )
    return resolved


async def read_file(  # pylint: disable=too-many-return-statements
    file_path: str,
    start_line: Optional[int] = None,
    end_line: Optional[int] = None,
) -> ToolResponse:
    """Read a file. Relative paths resolve from WORKING_DIR.

    Use start_line/end_line to read a specific line range (output includes
    line numbers). Omit both to read the full file.

    Args:
        file_path (`str`):
            Path to the file.
        start_line (`int`, optional):
            First line to read (1-based, inclusive).
        end_line (`int`, optional):
            Last line to read (1-based, inclusive).
    """

    # Convert start_line/end_line to int if they are strings
    if start_line is not None:
        try:
            start_line = int(start_line)
        except (ValueError, TypeError):
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Error: start_line must be an integer, got {start_line!r}.",
                    ),
                ],
            )

    if end_line is not None:
        try:
            end_line = int(end_line)
        except (ValueError, TypeError):
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Error: end_line must be an integer, got {end_line!r}.",
                    ),
                ],
            )

    file_path = _resolve_file_path(file_path)

    if not os.path.exists(file_path):
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: The file {file_path} does not exist.",
                ),
            ],
        )

    if not os.path.isfile(file_path):
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: The path {file_path} is not a file.",
                ),
            ],
        )

    try:
        content = read_file_safe(file_path)
        all_lines = content.split("\n")
        total = len(all_lines)

        # Determine read range
        s = max(1, start_line if start_line is not None else 1)
        e = min(total, end_line if end_line is not None else total)

        if s > total:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Error: start_line {s} exceeds file length ({total} lines).",
                    ),
                ],
            )

        if s > e:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Error: start_line ({s}) > end_line ({e}).",
                    ),
                ],
            )

        # Extract selected lines
        selected_content = "\n".join(all_lines[s - 1 : e])

        # Apply smart truncation (consistent with shell output format)
        text = truncate_file_output(
            selected_content,
            start_line=s,
            total_lines=total,
        )

        # Add continuation hint if partial read without truncation
        if text == selected_content and e < total:
            remaining = total - e
            text = (
                f"{file_path}  (lines {s}-{e} of {total})\n{text}\n\n"
                f"[{remaining} more lines. Use start_line={e + 1} to continue.]"
            )

        return ToolResponse(
            content=[TextBlock(type="text", text=text)],
        )

    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: Read file failed due to \n{e}",
                ),
            ],
        )


async def write_file(
    file_path: str,
    content: str,
) -> ToolResponse:
    """Create or overwrite a file. Relative paths resolve from WORKING_DIR.

    Args:
        file_path (`str`):
            Path to the file. Required.
        content (`str`):
            Content to write to the file. Required.

    Example:
        write_file(file_path="/path/to/file.txt", content="Hello World")
    """

    # Validate parameters with detailed error messages
    if file_path is None:
        logger.error("write_file called with file_path=None")
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "Error: Missing required parameter 'file_path'.\n\n"
                        "Correct usage:\n"
                        '  write_file(file_path="/path/to/file.txt", content="your content")\n\n'
                        "Parameters:\n"
                        "  - file_path (str, required): Path to the file\n"
                        "  - content (str, required): Content to write"
                    ),
                ),
            ],
        )

    if content is None:
        logger.error("write_file called with content=None for file_path=%s", file_path)
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "Error: Missing required parameter 'content'.\n\n"
                        "Correct usage:\n"
                        f'  write_file(file_path="{file_path}", content="your content")\n\n'
                        "Parameters:\n"
                        "  - file_path (str, required): Path to the file\n"
                        "  - content (str, required): Content to write"
                    ),
                ),
            ],
        )

    if not isinstance(file_path, str):
        logger.error(
            "write_file called with invalid file_path type: %s (%s)",
            file_path,
            type(file_path).__name__,
        )
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Error: Parameter 'file_path' must be a string, got {type(file_path).__name__}.\n\n"
                        "Correct usage:\n"
                        '  write_file(file_path="/path/to/file.txt", content="your content")'
                    ),
                ),
            ],
        )

    if not isinstance(content, str):
        logger.error(
            "write_file called with invalid content type for file %s: %s (%s)",
            file_path,
            content,
            type(content).__name__,
        )
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Error: Parameter 'content' must be a string, got {type(content).__name__}.\n\n"
                        "Correct usage:\n"
                        f'  write_file(file_path="{file_path}", content="your content")'
                    ),
                ),
            ],
        )

    if not file_path.strip():
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Error: Parameter 'file_path' cannot be empty.",
                ),
            ],
        )

    resolved_path = _resolve_file_path(file_path)
    logger.info("Writing file: %s -> %s (%d bytes)", file_path, resolved_path, len(content))

    _lightweight_verify(resolved_path, content)

    if _is_project_source_file(resolved_path):
        _audit_log("write_file", resolved_path, blocked=True, reason="project source file")
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "BLOCKED: Cannot directly modify XINGZIERAI project source code with write_file().\n\n"
                        "To modify the project's own source code, you MUST use the request_evolution() tool instead.\n"
                        "The evolution system provides safety guarantees:\n"
                        "  - Git checkpoint before changes (rollback if needed)\n"
                        "  - Code validation (syntax, imports, file path safety)\n"
                        "  - System restart and health check after changes\n"
                        "  - Automated testing to verify nothing is broken\n\n"
                        "Example:\n"
                        '  request_evolution(prompt="Add a version badge to App.tsx", file_path="console/src/App.tsx")'
                    ),
                ),
            ],
        )

    try:
        tmp_path = resolved_path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as file:
            file.write(content)
        os.replace(tmp_path, resolved_path)
        logger.info("Successfully wrote %d bytes to %s", len(content), resolved_path)
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Wrote {len(content)} bytes to {resolved_path}.",
                ),
            ],
        )
    except Exception as e:
        logger.error("Failed to write file %s: %s", resolved_path, str(e))
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: Write file failed due to \n{e}",
                ),
            ],
        )


# pylint: disable=too-many-return-statements
async def edit_file(
    file_path: str,
    old_text: str,
    new_text: str,
) -> ToolResponse:
    """Find-and-replace text in a file. All occurrences of old_text are
    replaced with new_text. Relative paths resolve from WORKING_DIR.

    Args:
        file_path (`str`):
            Path to the file.
        old_text (`str`):
            Exact text to find.
        new_text (`str`):
            Replacement text.
    """

    if not file_path:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Error: No `file_path` provided.",
                ),
            ],
        )

    resolved_path = _resolve_file_path(file_path)

    if _is_project_source_file(resolved_path):
        _audit_log("edit_file", resolved_path, blocked=True, reason="project source file")
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "BLOCKED: Cannot directly modify XINGZIERAI project source code with edit_file().\n\n"
                        "To modify the project's own source code, you MUST use the request_evolution() tool instead.\n"
                        "The evolution system provides safety guarantees:\n"
                        "  - Git checkpoint before changes (rollback if needed)\n"
                        "  - Code validation (syntax, imports, file path safety)\n"
                        "  - System restart and health check after changes\n"
                        "  - Automated testing to verify nothing is broken\n\n"
                        "Example:\n"
                        '  request_evolution(prompt="Change button text from Stop to Terminate", file_path="console/src/components/TaskQueuePanel/index.tsx")'
                    ),
                ),
            ],
        )

    if not os.path.exists(resolved_path):
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: The file {resolved_path} does not exist.",
                ),
            ],
        )

    if not os.path.isfile(resolved_path):
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: The path {resolved_path} is not a file.",
                ),
            ],
        )

    try:
        content = read_file_safe(resolved_path)
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: Read file failed due to \n{e}",
                ),
            ],
        )

    if old_text not in content:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: The text to replace was not found in {file_path}.",
                ),
            ],
        )

    new_content = content.replace(old_text, new_text)
    write_response = await write_file(
        file_path=resolved_path,
        content=new_content,
    )

    if write_response.content and len(write_response.content) > 0:
        write_text = write_response.content[0].get("text", "")
        if write_text.startswith("Error:"):
            return write_response

    return ToolResponse(
        content=[
            TextBlock(
                type="text",
                text=f"Successfully replaced text in {file_path}.",
            ),
        ],
    )


async def append_file(
    file_path: str,
    content: str,
) -> ToolResponse:
    """Append content to the end of a file. Relative paths resolve from
    WORKING_DIR.

    Args:
        file_path (`str`):
            Path to the file.
        content (`str`):
            Content to append.
    """

    if not file_path:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Error: No `file_path` provided.",
                ),
            ],
        )

    file_path = _resolve_file_path(file_path)

    if _is_project_source_file(file_path):
        _audit_log("append_file", file_path, blocked=True, reason="project source file")
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "BLOCKED: Cannot directly modify XINGZIERAI project source code with append_file().\n\n"
                        "To modify the project's own source code, you MUST use the request_evolution() tool instead."
                    ),
                ),
            ],
        )

    try:
        with open(file_path, "a", encoding="utf-8") as file:
            file.write(content)
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Appended {len(content)} bytes to {file_path}.",
                ),
            ],
        )
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: Append file failed due to \n{e}",
                ),
            ],
        )
