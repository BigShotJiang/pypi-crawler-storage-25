# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import logging
import os
from typing import Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse
from xingzierai.utils.async_utils import run_async_safe

logger = logging.getLogger(__name__)


def _get_acp_service():
    from xingzierai.agents.acp.service import get_acp_service
    from xingzierai.config.utils import load_config

    config = load_config()
    agent_id = getattr(config.agents, "active_agent", None) or "default"
    service = get_acp_service(agent_id)
    if service is None:
        from xingzierai.agents.acp.service import init_acp_service

        service = init_acp_service(agent_id, config.acp)
    return service


def _get_chat_id() -> str:
    from xingzierai.app.runner.task_tracker import TaskTracker

    tracker = TaskTracker.get_instance()
    if tracker is not None:
        current = tracker.current_task
        if current is not None:
            return getattr(current, "session_id", "acp-default")
    return "acp-default"


def delegate_external_agent(
    runner: str,
    prompt: str,
    cwd: Optional[str] = None,
    restart: bool = False,
) -> ToolResponse:
    """Delegate a task to an external ACP agent (OpenCode, Claude Code, Codex, etc.).

    This tool allows XINGZIERAI to call external coding agents via the
    Agent Client Protocol (ACP). The external agent can read, write, and
    modify files in the specified working directory.

    Available agents (configured in config.json acp.agents):
    - opencode: OpenCode (free, built-in models)
    - qwen_code: Qwen Code
    - claude_code: Claude Code
    - codex: OpenAI Codex

    Args:
        runner: The ACP agent name to delegate to (e.g. "opencode", "claude_code").
        prompt: The task description to send to the external agent.
        cwd: Working directory for the agent. Defaults to the project root.
        restart: Whether to restart the agent session. Default False.

    Returns:
        `ToolResponse`: The result from the external agent, or permission
        request if the agent needs user confirmation.
    """
    try:
        service = _get_acp_service()
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP service initialization failed: {e}",
                )
            ],
        )

    if runner not in service.config.agents:
        available = ", ".join(
            name for name, cfg in service.config.agents.items() if cfg.enabled
        )
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Unknown ACP agent: '{runner}'. "
                        f"Available agents: {available}"
                    ),
                )
            ],
        )

    agent_cfg = service.config.agents[runner]
    if not agent_cfg.enabled:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP agent '{runner}' is disabled. Enable it in config.json.",
                )
            ],
        )

    working_dir = cwd or os.getcwd()

    chat_id = _get_chat_id()

    async def _on_message(payload, is_last):
        pass

    try:
        result = run_async_safe(
            service.run_turn(
                chat_id=chat_id,
                agent=runner,
                prompt_blocks=[{"type": "text", "text": prompt}],
                cwd=working_dir,
                on_message=_on_message,
                restart=restart,
            ),
        )
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP agent '{runner}' error: {e}",
                )
            ],
        )

    status = result.get("status", "completed")
    event = result.get("event") or {}
    suspended = result.get("suspended_permission")

    if status == "permission_required" and suspended is not None:
        options = getattr(suspended, "options", []) or []
        option_lines = []
        for idx, opt in enumerate(options):
            if isinstance(opt, dict):
                opt_id = opt.get("optionId") or opt.get("option_id") or str(idx)
                label = opt.get("title") or opt.get("name") or opt_id
                option_lines.append(f"  [{idx}] {label} (id: {opt_id})")
        options_text = "\n".join(option_lines) if option_lines else "  (no options)"

        title = getattr(suspended, "summary", None) or getattr(
            suspended, "tool_name", "external-agent",
        )
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"ACP agent '{runner}' is requesting permission for: {title}\n"
                        f"Options:\n{options_text}\n"
                        f"Use 'acp_resume' tool with session_id and option_id to proceed."
                    ),
                )
            ],
        )

    text = ""
    if isinstance(event, dict):
        text = event.get("text", "")
    if not text:
        text = f"(ACP agent '{runner}' completed with no output)"
    return ToolResponse(content=[TextBlock(type="text", text=text)])


def acp_resume(
    session_id: str,
    option_id: str,
) -> ToolResponse:
    """Resume an ACP agent session after a permission request.

    When an ACP agent requests permission (e.g. to write a file), use this
    tool to approve or deny the request by selecting an option.

    Args:
        session_id: The ACP session ID from the permission request.
        option_id: The option ID to select from the permission options.

    Returns:
        `ToolResponse`: The result after resuming the agent.
    """
    try:
        service = _get_acp_service()
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP service initialization failed: {e}",
                )
            ],
        )

    async def _on_message(payload, is_last):
        pass

    try:
        result = run_async_safe(
            service.resume_permission(
                acp_session_id=session_id,
                option_id=option_id,
                on_message=_on_message,
            ),
        )
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP resume error: {e}",
                )
            ],
        )

    status = result.get("status", "completed")
    event = result.get("event") or {}

    text = ""
    if isinstance(event, dict):
        text = event.get("text", "")
    if not text:
        text = "(ACP agent resumed and completed with no output)"
    return ToolResponse(content=[TextBlock(type="text", text=text)])


def acp_list_agents() -> ToolResponse:
    """List all available ACP agents and their status.

    Returns:
        `ToolResponse`: List of available ACP agents with their configuration.
    """
    try:
        service = _get_acp_service()
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"ACP service initialization failed: {e}",
                )
            ],
        )

    lines = ["Available ACP Agents:\n"]
    for name, cfg in service.config.agents.items():
        status = "enabled" if cfg.enabled else "disabled"
        lines.append(
            f"  - {name}: {status} (command: {cfg.command} {' '.join(cfg.args)})"
        )
    return ToolResponse(
        content=[TextBlock(type="text", text="\n".join(lines))],
    )
