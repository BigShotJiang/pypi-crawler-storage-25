# -*- coding: utf-8 -*-
"""Shell command execution - legacy compatibility layer.

This module delegates to the new BashTool implementation to avoid
code duplication while maintaining backward compatibility.
"""

from pathlib import Path
from typing import Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse


async def execute_shell_command(
    command: str,
    timeout: int = 60,
    cwd: Optional[Path] = None,
) -> ToolResponse:
    """Execute shell command via BashTool.

    Legacy compatibility wrapper that delegates to the new BashTool
    implementation which includes sandbox isolation and dangerous
    command filtering.
    """
    try:
        from xingzierai.tools.bash import BashTool

        tool = BashTool()
        result = await tool.execute_legacy(command=command, timeout=timeout, cwd=cwd)
        return result

    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Error: Shell command execution failed due to \n{e}",
                ),
            ],
        )
