# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

from xingzierai.utils.async_utils import run_async_safe

logger = logging.getLogger(__name__)

_TRAINERS_DIR = Path.home() / ".xingzierai" / "model_trainer"


def train_model(
    action: str,
    name: str = "",
    depth: int = 4,
    mode: str = "pretrain",
    dataset_text: str = "",
    sft_data: str = "[]",
    epochs: int = 3,
    batch_size: int = 8,
    learning_rate: float = 3e-4,
    device: str = "auto",
    job_id: str = "",
    prompt: str = "",
    max_new_tokens: int = 64,
    temperature: float = 0.8,
    top_k: int = 40,
    display_name: str = "",
    task_type: str = "",
    use_lora: bool = False,
    lora_rank: int = 8,
    lora_alpha: float = 16.0,
    lora_init: str = "lora",
    version_id: str = "",
) -> str:
    """Train, monitor, test, or register a small language model. Also manage auto-dispatch of system tasks to local models.

    Actions:
    - "create": Create and start a training job. Returns job_id.
    - "status": Check training progress. Requires job_id.
    - "list": List all training jobs.
    - "generate": Test a trained model with a prompt. Requires job_id and prompt.
    - "register": Register a trained model as a local chat model. Requires job_id.
    - "stop": Stop a running training job. Requires job_id.
    - "dispatch_status": Show which system tasks are routed to local models and training data collection progress.
    - "dispatch_register": Register a trained model for a specific system task. Requires job_id and task_type.
    - "dispatch_unregister": Remove a local model from a system task. Requires task_type.
    - "dispatch_rollback": Rollback a task's model to a previous version. Requires task_type, optional version_id.
    - "bridge_sync": Sync data from DataFlywheel and Kappa to training data collector.

    Args:
        action: One of "create", "status", "list", "generate", "register", "stop", "dispatch_status", "dispatch_register", "dispatch_unregister", "dispatch_rollback", "bridge_sync"
        name: Job name (for create)
        depth: Model depth/complexity dial (2-32). depth=2 is tiny/CPU, depth=8 is medium, depth=24 is GPT-2 scale
        mode: "pretrain" (learn from text) or "sft" (learn from Q&A pairs)
        dataset_text: Raw text for pretraining (for create with mode=pretrain)
        sft_data: JSON array of {"prompt": "...", "response": "..."} pairs (for create with mode=sft)
        epochs: Number of training epochs (default 3)
        batch_size: Batch size (default 8)
        learning_rate: Learning rate (default 0.0003)
        device: "auto", "cpu", "cuda", or "mps"
        job_id: Training job ID (for status/generate/register/stop/dispatch_register)
        prompt: Text prompt for generation (for generate)
        max_new_tokens: Max tokens to generate (default 64)
        temperature: Sampling temperature (default 0.8)
        top_k: Top-K sampling (default 40)
        display_name: Human-readable name when registering (default: job name)
        task_type: System task type for dispatch operations (e.g., "memory_compact", "fact_extract", "query_rewrite")
        use_lora: Enable LoRA fine-tuning (only train 0.1-1% of parameters)
        lora_rank: LoRA rank (default 8). Higher = more capacity but more params
        lora_alpha: LoRA alpha/scaling (default 16.0)
        lora_init: LoRA init method: "lora" (standard), "pissa" (SVD-based, faster convergence), "singlora" (single matrix)
        version_id: Version ID for rollback (optional, defaults to latest)

    Returns:
        JSON string with action result
    """
    try:
        from ...model_trainer.manager import TrainingManager
        from ...model_trainer.schema import (
            CreateTrainingJobRequest,
            TrainingConfig,
            TrainingMode,
            SFTDataItem,
            architecture_from_depth,
        )

        mgr = TrainingManager.get_instance()

        if action == "create":
            if not dataset_text and sft_data == "[]":
                return json.dumps({
                    "error": "No training data provided. Please provide dataset_text for pretrain or sft_data for SFT mode.",
                    "hint": "Example: train_model(action='create', name='my_model', depth=4, mode='pretrain', dataset_text='Your text here...')",
                })

            config = TrainingConfig(
                mode=TrainingMode(mode),
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                warmup_steps=100,
                weight_decay=0.01,
                grad_clip=1.0,
                save_every=500,
                eval_every=200,
                device=device,
            )

            if use_lora:
                config.lora_config = {
                    "rank": lora_rank,
                    "alpha": lora_alpha,
                    "dropout": 0.0,
                    "init_method": lora_init,
                }

            parsed_sft = None
            if mode == "sft" and sft_data and sft_data != "[]":
                try:
                    raw = json.loads(sft_data) if isinstance(sft_data, str) else sft_data
                    parsed_sft = [SFTDataItem(**item) for item in raw]
                except Exception as e:
                    return json.dumps({"error": f"Invalid sft_data format: {e}"})

            req = CreateTrainingJobRequest(
                name=name or "untitled",
                depth=depth,
                config=config,
                dataset_text=dataset_text if mode == "pretrain" else None,
                sft_data=parsed_sft,
            )

            job = mgr.create_job(req)
            arch = job.architecture
            param_str = f"{job.param_count/1e6:.1f}M" if job.param_count < 1e9 else f"{job.param_count/1e9:.2f}B"

            started = mgr.start_job(job.id)

            return json.dumps({
                "action": "create",
                "job_id": job.id,
                "name": job.name,
                "status": started.status,
                "architecture": f"dim={arch.dim} layers={arch.n_layers} heads={arch.n_heads} seq={arch.max_seq_len}",
                "param_count": param_str,
                "mode": mode,
                "message": f"Training job '{job.name}' created and started! ({param_str} params, depth={depth})",
            }, ensure_ascii=False)

        elif action == "status":
            if not job_id:
                return json.dumps({"error": "job_id required for status check"})
            job = mgr.get_job(job_id)
            pct = (job.current_step / job.total_steps * 100) if job.total_steps > 0 else 0
            return json.dumps({
                "action": "status",
                "job_id": job.id,
                "name": job.name,
                "status": job.status,
                "progress": f"{pct:.1f}%",
                "step": f"{job.current_step}/{job.total_steps}",
                "epoch": job.current_epoch,
                "train_loss": round(job.train_loss, 4) if job.train_loss > 0 else None,
                "best_loss": round(job.best_loss, 4) if job.best_loss < float("inf") else None,
                "param_count": job.param_count,
            }, ensure_ascii=False)

        elif action == "list":
            jobs = mgr.list_jobs()
            result = []
            for j in jobs:
                pct = (j.current_step / j.total_steps * 100) if j.total_steps > 0 else 0
                param_str = f"{j.param_count/1e6:.1f}M" if j.param_count < 1e9 else f"{j.param_count/1e9:.2f}B"
                result.append({
                    "id": j.id,
                    "name": j.name,
                    "status": j.status,
                    "progress": f"{pct:.0f}%",
                    "params": param_str,
                    "loss": round(j.train_loss, 4) if j.train_loss > 0 else None,
                })
            return json.dumps({"action": "list", "jobs": result}, ensure_ascii=False)

        elif action == "generate":
            if not job_id or not prompt:
                return json.dumps({"error": "job_id and prompt required for generation"})
            text = mgr.generate(job_id, prompt, max_new_tokens, temperature, top_k)
            return json.dumps({
                "action": "generate",
                "job_id": job_id,
                "prompt": prompt,
                "generated_text": text,
            }, ensure_ascii=False)

        elif action == "register":
            if not job_id:
                return json.dumps({"error": "job_id required for registration"})
            return _register_trained_model(mgr, job_id, display_name)

        elif action == "stop":
            if not job_id:
                return json.dumps({"error": "job_id required to stop"})
            job = mgr.stop_job(job_id)
            return json.dumps({
                "action": "stop",
                "job_id": job.id,
                "status": job.status,
            })

        elif action == "dispatch_status":
            return _dispatch_status()

        elif action == "dispatch_register":
            if not job_id or not task_type:
                return json.dumps({"error": "job_id and task_type required for dispatch_register"})
            return _dispatch_register(mgr, job_id, task_type)

        elif action == "dispatch_unregister":
            if not task_type:
                return json.dumps({"error": "task_type required for dispatch_unregister"})
            return _dispatch_unregister(task_type)

        elif action == "dispatch_rollback":
            if not task_type:
                return json.dumps({"error": "task_type required for dispatch_rollback"})
            return _dispatch_rollback(task_type, version_id)

        elif action == "bridge_sync":
            return _bridge_sync()

        else:
            return json.dumps({
                "error": f"Unknown action: {action}",
                "valid_actions": ["create", "status", "list", "generate", "register", "stop", "dispatch_status", "dispatch_register", "dispatch_unregister"],
            })

    except ImportError as e:
        return json.dumps({
            "error": f"Model training not available: {e}",
            "hint": "Install PyTorch: pip install torch",
        })
    except Exception as e:
        logger.exception("train_model tool error")
        return json.dumps({"error": str(e)})


def _register_trained_model(mgr, job_id: str, display_name: str = "") -> str:
    from ...model_trainer.manager import TrainingManager

    job = mgr.get_job(job_id)
    if job.status != "completed":
        return json.dumps({
            "error": f"Job status is '{job.status}', must be 'completed' to register",
        })

    model_dir = Path(job.model_save_path) if job.model_save_path else None
    if not model_dir or not (model_dir / "best_model.pt").exists():
        return json.dumps({"error": "Trained model files not found"})

    name = display_name or job.name or job_id
    model_id = f"trained/{job_id}"
    model_file = str(model_dir / "best_model.pt")
    tokenizer_file = str(model_dir / "tokenizer.json")

    reg_dir = _TRAINERS_DIR / "registered" / job_id
    reg_dir.mkdir(parents=True, exist_ok=True)

    import shutil
    shutil.copy2(model_file, reg_dir / "best_model.pt")
    shutil.copy2(tokenizer_file, reg_dir / "tokenizer.json")

    meta = {
        "id": model_id,
        "name": name,
        "job_id": job_id,
        "architecture": job.architecture.model_dump(),
        "param_count": job.param_count,
        "best_loss": job.best_loss if job.best_loss < float("inf") else None,
        "model_path": str(reg_dir / "best_model.pt"),
        "tokenizer_path": str(reg_dir / "tokenizer.json"),
    }
    (reg_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2))

    try:
        from ...local_models.manager import _load_manifest, _save_manifest
        from ...local_models.schema import LocalModelInfo, BackendType, DownloadSource

        info = LocalModelInfo(
            id=model_id,
            repo_id=f"trained/{name}",
            filename="best_model.pt",
            backend=BackendType.LLAMACPP,
            source=DownloadSource.HUGGINGFACE,
            file_size=(reg_dir / "best_model.pt").stat().st_size,
            local_path=str(reg_dir / "best_model.pt"),
            display_name=f"🧠 {name} (自训练)",
        )

        manifest = _load_manifest()
        manifest.models[info.id] = info
        _save_manifest(manifest)

        try:
            from ...providers.provider_manager import ProviderManager
            ProviderManager.get_instance().update_local_models()
        except Exception as _provider_err:
            logger.debug("Failed to update local models in provider: %s", _provider_err)

        return json.dumps({
            "action": "register",
            "job_id": job_id,
            "model_id": model_id,
            "display_name": info.display_name,
            "message": f"Model '{name}' registered as local model! Go to Settings > Models to select it.",
        }, ensure_ascii=False)

    except Exception as e:
        logger.warning("Failed to register in local model manifest: %s", e)
        return json.dumps({
            "action": "register",
            "job_id": job_id,
            "model_id": model_id,
            "message": f"Model files saved. Manual registration needed: {e}",
        })


def _dispatch_status() -> str:
    try:
        from ..local_model_dispatcher import LocalModelDispatcher
        dispatcher = LocalModelDispatcher.get_instance()
        status = dispatcher.get_status()

        task_descriptions = {
            "memory_compact": "记忆压缩 - 将对话历史压缩为摘要",
            "fact_extract": "事实提取 - 从文本中提取关键事实",
            "query_rewrite": "查询改写 - 优化搜索查询",
        }

        lines = ["📊 本地小模型调度状态\n"]

        if status["registered_models"]:
            lines.append("✅ 已部署的本地模型:")
            for task_type, info in status["registered_models"].items():
                desc = task_descriptions.get(task_type, task_type)
                lines.append(f"  🧠 {task_type}: {desc}")
        else:
            lines.append("⏳ 尚未部署任何本地模型（系统正在收集训练数据）")

        if status["training_data_counts"]:
            lines.append("\n📁 训练数据收集进度:")
            for task_type, count in status["training_data_counts"].items():
                desc = task_descriptions.get(task_type, task_type)
                threshold = status["auto_train_threshold"]
                bar_len = min(int(count / threshold * 20), 20)
                bar = "█" * bar_len + "░" * (20 - bar_len)
                lines.append(f"  {task_type}: [{bar}] {count}/{threshold} ({desc})")
        else:
            lines.append("\n📁 暂无训练数据（使用系统后会自动收集）")

        if status["pending_auto_train"]:
            lines.append(f"\n🔄 正在自动训练: {', '.join(status['pending_auto_train'])}")

        lines.append(f"\n💡 自动训练阈值: {status['auto_train_threshold']} 条样本")
        lines.append("💡 系统会在日常工作中自动收集训练数据，达到阈值后自动训练小模型")

        econ = status.get("token_economics", {})
        if econ:
            lines.append(f"\n💰 Token经济学:")
            lines.append(f"  本地模型调用: {econ.get('total_local_calls', 0)} 次")
            lines.append(f"  LLM回退调用: {econ.get('total_llm_calls', 0)} 次")
            lines.append(f"  本地化率: {econ.get('local_rate', 0):.1%}")
            lines.append(f"  节省Token: {econ.get('tokens_saved', 0):,}")
            lines.append(f"  预估节省: ${econ.get('estimated_savings_usd', 0):.4f}")
            if econ.get('estimated_savings_usd', 0) > 0:
                lines.append("  💡 推理成本占AI总支出90%+，本地模型越多越省钱！")

        return json.dumps({
            "action": "dispatch_status",
            "status": status,
            "message": "\n".join(lines),
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def _dispatch_register(mgr, job_id: str, task_type: str) -> str:
    valid_tasks = ["memory_compact", "fact_extract", "query_rewrite"]
    if task_type not in valid_tasks:
        return json.dumps({
            "error": f"Invalid task_type: {task_type}",
            "valid_types": valid_tasks,
        })

    try:
        job = mgr.get_job(job_id)
        if job.status != "completed":
            return json.dumps({"error": f"Job status is '{job.status}', must be 'completed'"})

        model_dir = Path(job.model_save_path) if job.model_save_path else None
        if not model_dir or not (model_dir / "best_model.pt").exists():
            return json.dumps({"error": "Trained model files not found"})

        model_path = str(model_dir / "best_model.pt")
        tokenizer_path = str(model_dir / "tokenizer.json")

        from ..local_model_dispatcher import LocalModelDispatcher
        dispatcher = LocalModelDispatcher.get_instance()
        run_async_safe(dispatcher.register_local_model(task_type, model_path, tokenizer_path))

        task_descriptions = {
            "memory_compact": "记忆压缩",
            "fact_extract": "事实提取",
            "query_rewrite": "查询改写",
        }

        return json.dumps({
            "action": "dispatch_register",
            "job_id": job_id,
            "task_type": task_type,
            "message": f"✅ 已将模型部署为{task_descriptions.get(task_type, task_type)}任务的小模型！系统将优先使用此本地模型处理该任务。",
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def _dispatch_unregister(task_type: str) -> str:
    try:
        from ..local_model_dispatcher import LocalModelDispatcher
        dispatcher = LocalModelDispatcher.get_instance()

        if not dispatcher.has_local_model(task_type):
            return json.dumps({"error": f"No local model registered for task: {task_type}"})

        dispatcher.unregister_local_model(task_type)
        return json.dumps({
            "action": "dispatch_unregister",
            "task_type": task_type,
            "message": f"已移除 {task_type} 任务的本地模型，系统将回退到使用大模型。",
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def _dispatch_rollback(task_type: str, version_id: str = "") -> str:
    try:
        from ..local_model_dispatcher import LocalModelDispatcher
        from ..evolution_bridges import ModelVersionManager

        dispatcher = LocalModelDispatcher.get_instance()
        vm = ModelVersionManager()

        vid = version_id if version_id else None
        success = run_async_safe(vm.rollback(task_type, vid))

        if success:
            return json.dumps({
                "action": "dispatch_rollback",
                "task_type": task_type,
                "version_id": version_id or "latest",
                "message": f"✅ 已将 {task_type} 任务回滚到之前的模型版本。",
            }, ensure_ascii=False)
        else:
            return json.dumps({
                "action": "dispatch_rollback",
                "task_type": task_type,
                "message": f"❌ 回滚失败，没有可用的历史版本。",
            }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def _bridge_sync() -> str:
    try:
        from ..evolution_bridges import run_all_bridges
        results = run_all_bridges()

        lines = ["🔄 数据桥接同步结果\n"]

        df_result = results.get("data_flywheel", {})
        lines.append(f"📊 DataFlywheel: 同步 {df_result.get('synced', 0)} 条, 跳过 {df_result.get('skipped', 0)} 条")

        kappa_result = results.get("kappa", {})
        lines.append(f"🧠 Kappa经验包: 同步 {kappa_result.get('synced', 0)} 个, 跳过 {kappa_result.get('skipped', 0)} 个")

        total_synced = df_result.get("synced", 0) + kappa_result.get("synced", 0)
        if total_synced > 0:
            lines.append(f"\n✅ 共同步 {total_synced} 条新训练数据")
        else:
            lines.append("\n💡 暂无新数据同步（使用系统后会自动积累）")

        return json.dumps({
            "action": "bridge_sync",
            "results": results,
            "message": "\n".join(lines),
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})
