# -*- coding: utf-8 -*-
"""Trae IDE Integration Tool - lightweight bridge for XINGZIERAI ↔ Trae IDE.

This tool provides a clean integration point for XINGZIERAI Agent to
interact with Trae IDE when it is available. It is designed around
Trae IDE's actual MCP extension capabilities.

Architecture:
    XINGZIERAI Agent → trae_ide_tool → Trae IDE MCP Extension

This replaces the old 3-layer architecture:
    (Old) Agent → TraeMCPClient → MCP Server(2024) → Trae IDE

Usage:
    from xingzierai.agents.tools.trae_ide_tool import trae_ide_execute

    result = await trae_ide_execute(
        action="edit_file",
        params={"path": "src/main.py", "content": "..."},
    )
"""

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse

logger = logging.getLogger(__name__)


class TraeIDEAction(str, Enum):
    EDIT_FILE = "edit_file"
    READ_FILE = "read_file"
    LIST_FILES = "list_files"
    RUN_COMMAND = "run_command"
    SEARCH_CODE = "search_code"
    DIAGNOSTICS = "diagnostics"


@dataclass
class TraeIDEConfig:
    enabled: bool = False
    mcp_endpoint: str = "http://127.0.0.1:2024/mcp/invoke"
    health_endpoint: str = "http://127.0.0.1:2024/health"
    timeout: int = 30
    max_retries: int = 2


_config = TraeIDEConfig()


def configure_trae_ide(**kwargs):
    for k, v in kwargs.items():
        if hasattr(_config, k):
            setattr(_config, k, v)


def is_trae_ide_available() -> bool:
    if not _config.enabled:
        return False
    try:
        import requests
        resp = requests.get(_config.health_endpoint, timeout=2)
        return resp.status_code == 200
    except Exception as _health_err:
        logger.debug("Trae IDE health check failed: %s", _health_err)
        return False


async def _call_trae_ide(action: str, params: Dict[str, Any]) -> Dict[str, Any]:
    if not _config.enabled:
        return {"ok": False, "error": "Trae IDE integration is not enabled"}

    try:
        import httpx

        payload = {
            "tool": action,
            "params": params,
        }

        async with httpx.AsyncClient(timeout=_config.timeout) as client:
            for attempt in range(_config.max_retries + 1):
                try:
                    resp = await client.post(_config.mcp_endpoint, json=payload)
                    if resp.status_code == 200:
                        return resp.json()
                    return {"ok": False, "error": f"HTTP {resp.status_code}"}
                except (httpx.ConnectError, httpx.TimeoutException) as e:
                    if attempt == _config.max_retries:
                        return {"ok": False, "error": str(e)}
                    await asyncio.sleep(0.5 * (2 ** attempt))

    except ImportError:
        return {"ok": False, "error": "httpx not installed"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def trae_ide_execute(
    action: str,
    params: Optional[Dict[str, Any]] = None,
) -> ToolResponse:
    """Execute an action via Trae IDE MCP extension.

    Args:
        action: The action to perform (edit_file, read_file, list_files,
                run_command, search_code, diagnostics)
        params: Action-specific parameters

    Returns:
        ToolResponse with the result
    """
    params = params or {}

    result = await _call_trae_ide(action, params)

    if result.get("ok"):
        content = json.dumps(result, ensure_ascii=False, indent=2)
        return ToolResponse(content=[TextBlock(type="text", text=content)])

    error_msg = result.get("error", "Unknown error")
    return ToolResponse(
        content=[TextBlock(type="text", text=f"Trae IDE error: {error_msg}")]
    )


async def trae_ide_edit_file(
    file_path: str,
    content: str,
    create_if_missing: bool = True,
) -> ToolResponse:
    """Edit a file via Trae IDE."""
    return await trae_ide_execute(
        action=TraeIDEAction.EDIT_FILE.value,
        params={"path": file_path, "content": content, "create_if_missing": create_if_missing},
    )


async def trae_ide_read_file(file_path: str) -> ToolResponse:
    """Read a file via Trae IDE."""
    return await trae_ide_execute(
        action=TraeIDEAction.READ_FILE.value,
        params={"path": file_path},
    )


async def trae_ide_run_command(
    command: str,
    cwd: Optional[str] = None,
    timeout: int = 30,
) -> ToolResponse:
    """Run a command via Trae IDE."""
    return await trae_ide_execute(
        action=TraeIDEAction.RUN_COMMAND.value,
        params={"command": command, "cwd": cwd, "timeout": timeout},
    )


async def trae_ide_search_code(
    query: str,
    file_pattern: Optional[str] = None,
) -> ToolResponse:
    """Search code via Trae IDE."""
    return await trae_ide_execute(
        action=TraeIDEAction.SEARCH_CODE.value,
        params={"query": query, "file_pattern": file_pattern},
    )
