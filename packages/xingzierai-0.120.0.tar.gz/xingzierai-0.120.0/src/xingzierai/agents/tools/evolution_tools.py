# -*- coding: utf-8 -*-
"""Evolution tool for XINGZIERAI Agent.

Allows the agent to trigger self-evolution by calling the evolution daemon.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
import urllib.request
import urllib.error
from typing import Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse

logger = logging.getLogger(__name__)

EVOLUTION_DAEMON_URL = os.getenv("XINGZIERAI_EVOLUTION_DAEMON_URL", "http://localhost:8580")
DAEMON_STARTUP_TIMEOUT = 15


def _ensure_daemon_running() -> bool:
    """Check if daemon is running, try to start it if not."""
    # Try to connect to daemon directly using urllib
    print(f"[EvolutionTool] Checking daemon at {EVOLUTION_DAEMON_URL}/api/health", file=os.sys.stderr)
    try:
        req = urllib.request.Request(f"{EVOLUTION_DAEMON_URL}/api/health", method='GET')
        with urllib.request.urlopen(req, timeout=3) as resp:
            resp_data = resp.read()
            print(f"[EvolutionTool] Got response: {resp_data[:200]}", file=os.sys.stderr)
            try:
                data = json.loads(resp_data)
                status = data.get("status")
                print(f"[EvolutionTool] Parsed status: {status}", file=os.sys.stderr)
                if status == "healthy":
                    print("[EvolutionTool] ✅ Daemon is healthy!", file=os.sys.stderr)
                    return True
                else:
                    print(f"[EvolutionTool] ❌ Unexpected status: {status}", file=os.sys.stderr)
                    return False
            except json.JSONDecodeError as e:
                print(f"[EvolutionTool] ❌ Invalid JSON response: {e}", file=os.sys.stderr)
                return False
    except urllib.error.URLError as e:
        # Connection refused or other URL error - daemon not running
        print(f"[EvolutionTool] ❌ Connection refused: {e}", file=os.sys.stderr)
    except Exception as e:
        # Other errors, log for debugging
        print(f"[EvolutionTool] ❌ Health check error: {type(e).__name__}: {e}", file=os.sys.stderr)

    # Daemon not running, try to start it
    print("[EvolutionTool] Daemon not running, attempting to start...", file=os.sys.stderr)

    project_root = _find_project_root()
    if not project_root:
        logger.error("[EvolutionTool] Cannot find project root")
        return False

    script_path = os.path.join(project_root, "xingzierai-evolution", "scripts", "xevolve.sh")
    if not os.path.exists(script_path):
        logger.error(f"[EvolutionTool] Script not found: {script_path}")
        return False

    try:
        proc = subprocess.Popen(
            ["bash", script_path, "start"],
            cwd=project_root,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

        start_time = time.time()
        while time.time() - start_time < DAEMON_STARTUP_TIMEOUT:
            try:
                req = urllib.request.Request(
                    f"{EVOLUTION_DAEMON_URL}/api/health", method='GET'
                )
                with urllib.request.urlopen(req, timeout=2) as resp:
                    data = json.loads(resp.read())
                    if data.get("status") == "healthy":
                        logger.info("[EvolutionTool] Daemon started successfully (pid=%d)", proc.pid)
                        return True
            except Exception as e:
                logger.debug(f"[EvolutionTool] Health check attempt failed: {e}")
                pass
            time.sleep(1)

        logger.error("[EvolutionTool] Daemon failed to start within timeout")
        return False

    except Exception as e:
        logger.error(f"[EvolutionTool] Failed to start daemon: {e}")
        return False


def _find_project_root() -> Optional[str]:
    """Find the XINGZIERAI project root directory.
    
    Optimization: Uses multiple strategies for fast lookup:
    1. Direct import of xingzierai module (fastest)
    2. Check WORKING_DIR environment variable
    3. Walk up from this file's location (limited depth)
    4. Walk up from cwd (limited depth)
    """
    try:
        import xingzierai
        module_path = os.path.dirname(os.path.abspath(xingzierai.__file__))
        project_root = os.path.dirname(os.path.dirname(module_path))
        if os.path.exists(os.path.join(project_root, "src", "xingzierai")):
            return project_root
    except Exception as _import_err:
        logger.debug("Failed to import xingzierai for project root lookup: %s", _import_err)

    if os.getenv("WORKING_DIR"):
        working = os.getenv("WORKING_DIR")
        if os.path.exists(os.path.join(working, "src", "xingzierai")):
            return working

    this_file_dir = os.path.dirname(os.path.abspath(__file__))
    for path in list(_parent_dirs(this_file_dir, 8)):
        if os.path.exists(os.path.join(path, "src", "xingzierai")):
            return path

    cwd = os.getcwd()
    for path in [cwd] + list(_parent_dirs(cwd, 5)):
        if os.path.exists(os.path.join(path, "src", "xingzierai")):
            return path
    return None


def _parent_dirs(path: str, depth: int):
    current = path
    for _ in range(depth):
        parent = os.path.dirname(current)
        if parent == current:
            break
        yield parent
        current = parent


def request_evolution(
    prompt: str,
    file_path: Optional[str] = None,
    auto_apply: bool = False,
    rollback_on_failure: bool = True,
) -> ToolResponse:
    """Request XINGZIERAI to evolve/upgrade its own underlying code.

    IMPORTANT: "Your evolution" means modifying XINGZIERAI's OWN source code.
    - Source code: src/xingzierai/
    - Frontend code: console/src/
    - Evolution toolkit: xingzierai-evolution/

    When the user says "your evolution" or "evolve yourself" or any variation,
    they mean modifying XINGZIERAI's own code.

    Common use cases:
    - "Test your evolution" -> trigger a small evolution to verify the system works
    - "Evolve your frontend" -> modify console/src/ files
    - "Add a feature to yourself" -> modify src/xingzierai/ files
    - "Fix a bug in your code" -> modify src/xingzierai/ files

    Args:
        prompt: Description of what to evolve. Be specific about what
            changes you want. Example: "Add a dark mode toggle to settings page"
        file_path: Target file path relative to project root.
            Example: "src/xingzierai/app/routers/settings.py"
            Example: "console/src/App.tsx"
            Example: "console/src/styles/theme.css"
            If not specified, the LLM will determine the appropriate file.
        auto_apply: Whether to automatically apply changes. Default True.
        rollback_on_failure: Whether to rollback if tests fail. Default True.

    Returns:
        `ToolResponse`: Evolution request status and request ID for tracking progress.
    """
    if not _ensure_daemon_running():
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "Evolution daemon is not running and could not be started automatically.\n"
                        "Please start it manually:\n"
                        "  cd /path/to/XINGZIERAI\n"
                        "  bash xingzierai-evolution/scripts/xevolve.sh start"
                    ),
                )
            ],
        )

    try:
        data = json.dumps({
            "prompt": prompt,
            "file_path": file_path,
            "auto_apply": auto_apply,
            "rollback_on_failure": rollback_on_failure,
            "test_timeout": 300.0,
        }).encode()

        req = urllib.request.Request(
            f"{EVOLUTION_DAEMON_URL}/api/evolve",
            data=data,
            headers={"Content-Type": "application/json"},
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            request_id = result.get("request_id", "unknown")

        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Evolution request accepted! Request ID: {request_id}\n\n"
                        f"The evolution daemon is now processing your request.\n"
                        f"Steps: generate code → git checkpoint → apply changes → restart → test\n\n"
                        f"Use check_evolution_status with request_id '{request_id}' "
                        f"to check progress.\n\n"
                        f"IMPORTANT: The system will restart during evolution. "
                        f"After restart, refresh your browser to continue using the evolved system."
                    ),
                )
            ],
        )

    except urllib.error.HTTPError as e:
        if e.code == 409:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=(
                            "Another evolution is already in progress. "
                            "Please wait for it to complete before requesting a new one."
                        ),
                    )
                ],
            )
        error_body = e.read().decode() if e.fp else "Unknown error"
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Evolution request failed (HTTP {e.code}): {error_body}",
                )
            ],
        )
    except urllib.error.URLError:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Evolution daemon is not reachable after startup attempt.",
                )
            ],
        )
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Evolution request failed: {e}",
                )
            ],
        )


def check_evolution_status(request_id: str) -> ToolResponse:
    """Check the status of an evolution request.

    Args:
        request_id: The request ID returned by request_evolution.

    Returns:
        `ToolResponse`: Current status of the evolution request.
    """
    try:
        req = urllib.request.Request(
            f"{EVOLUTION_DAEMON_URL}/api/progress/{request_id}",
        )

        with urllib.request.urlopen(req, timeout=5) as resp:
            result = json.loads(resp.read())

        phase = result.get("phase", "unknown")
        message = result.get("message", "")
        step = result.get("step", "?")
        total = result.get("total_steps", "?")

        if phase == "completed":
            result_data = result.get("result", {})
            success = result_data.get("success", False)
            tests = result_data.get("tests_passed", False)
            rollback = result_data.get("rollback_performed", False)

            status_msg = (
                f"Evolution COMPLETED!\n"
                f"  Success: {success}\n"
                f"  Tests passed: {tests}\n"
                f"  Rollback performed: {rollback}\n"
            )
            if not success:
                status_msg += f"  Error: {result_data.get('error', 'Unknown')}\n"
            if success:
                status_msg += "\n  The system has been upgraded. Please refresh your browser."
            return ToolResponse(
                content=[TextBlock(type="text", text=status_msg)],
            )

        elif phase == "failed":
            result_data = result.get("result", {})
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=(
                            f"Evolution FAILED!\n"
                            f"  Error: {result_data.get('error', 'Unknown')}\n"
                            f"  Rollback performed: {result_data.get('rollback_performed', False)}\n"
                            f"  The system should still be running normally."
                        ),
                    )
                ],
            )

        else:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Evolution in progress: Step {step}/{total} - {message} (phase: {phase})",
                    )
                ],
            )

    except urllib.error.URLError:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Evolution daemon is not reachable. The system may be restarting.",
                )
            ],
        )
    except Exception as e:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=f"Status check failed: {e}",
                )
            ],
        )
