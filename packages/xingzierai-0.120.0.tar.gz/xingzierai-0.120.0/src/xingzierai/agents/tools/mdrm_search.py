# -*- coding: utf-8 -*-
"""MDRM search tool for structured memory retrieval."""
from typing import TYPE_CHECKING

from xingzierai.agentscope_core.tool import ToolResponse
from xingzierai.agentscope_core.message import TextBlock

if TYPE_CHECKING:
    from xingzierai.agents.hooks.mdrm_memory import MDRMMemoryHook


def create_mdrm_search_tool(mdrm_hook: "MDRMMemoryHook"):
    """Create an mdrm_search tool function with bound MDRM hook.
    
    Args:
        mdrm_hook: MDRMMemoryHook instance to use for searching
        
    Returns:
        An async function that can be registered as a tool
    """
    
    async def mdrm_search(
        query: str,
        max_results: int = 5,
    ) -> ToolResponse:
        """
        Search structured memories in MDRM graph database.
        
        Use this tool when you need to recall specific events, decisions, facts,
        or goals from previous conversations. This searches the structured memory
        network which contains automatically extracted important information.
        
        Args:
            query (`str`):
                The search query to find relevant memories.
                Examples: "What decisions did we make about the architecture?",
                         "What were the goals for this project?",
                         "Tell me about the meeting with the team"
            max_results (`int`, optional):
                Maximum number of memory results to return. Defaults to 5.
                
        Returns:
            `ToolResponse`:
                Search results with memory content, type (event/fact/decision/goal),
                confidence score, and related memories.
        """
        if mdrm_hook is None:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text="MDRM memory system is not enabled.",
                    ),
                ],
            )
        
        try:
            results = await mdrm_hook.search_memories(
                query=query,
                max_results=max_results,
            )
            
            if not results:
                return ToolResponse(
                    content=[
                        TextBlock(
                            type="text",
                            text=f"No memories found for query: '{query}'",
                        ),
                    ],
                )
            
            # Format results
            lines = [f"Found {len(results)} relevant memories:\n"]
            
            for i, result in enumerate(results, 1):
                mem_type = result.get('type', 'unknown').upper()
                content = result.get('content', '')
                confidence = result.get('confidence', 0.0)
                lines.append(f"\n{i}. [{mem_type}] {content}")
                lines.append(f"   Confidence: {confidence:.1%}")
                
                if result.get('related'):
                    lines.append(f"   Related: {', '.join(result['related'][:3])}")
                
                created_at = result.get('created_at', '')
                lines.append(f"   Created: {created_at[:10] if created_at else 'unknown'}")
            
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text="\n".join(lines),
                    ),
                ],
            )
            
        except Exception as e:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text=f"Error searching MDRM memories: {e}",
                    ),
                ],
            )
    
    return mdrm_search
