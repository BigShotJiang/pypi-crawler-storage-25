# -*- coding: utf-8 -*-
"""Enterprise tools for multi-agent coordination, cross-session memory, and outcomes evaluation."""

import asyncio
import json
import logging
from typing import Optional

from xingzierai.utils.async_utils import run_async_safe

logger = logging.getLogger(__name__)


def _run_async(coro):
    return run_async_safe(coro)


ALLOWED_ACTIONS = frozenset([
    "orchestrate", "orch_status", "orch_list",
    "memory_write", "memory_search", "memory_context", "memory_stats",
    "memory_consolidate", "memory_link",
    "eval_define", "eval_run", "eval_trends", "eval_failures", "eval_stats",
    "upload_error_logs", "error_logs_stats",
])
MAX_TASK_LENGTH = 50000
MAX_RESULT_LENGTH = 100000


def enterprise_tools(action: str, **kwargs) -> str:
    """Enterprise-level AI platform tools.

    Actions:
        - orchestrate: Coordinate multi-agent task (Orchestrator-Workers)
        - orch_status: Get orchestrator status
        - orch_list: List recent orchestrations
        - memory_write: Write to cross-session persistent memory
        - memory_search: Search across sessions
        - memory_context: Get relevant context from past sessions
        - memory_stats: Get memory statistics
        - memory_consolidate: Consolidate episodic memories into semantic knowledge
        - memory_link: Auto-link related sessions
        - eval_define: Define success criteria for a task
        - eval_run: Evaluate a result against criteria
        - eval_trends: Get evaluation trends
        - eval_failures: Get common failure patterns
        - eval_stats: Get evaluation statistics
        - upload_error_logs: Upload local error logs to XINGZIER AI server
        - error_logs_stats: Get local error log statistics

    Args:
        action: The action to perform
        **kwargs: Action-specific parameters

    Returns:
        JSON string with action result
    """
    try:
        if action not in ALLOWED_ACTIONS:
            return json.dumps({"error": f"Unknown action: {action}"}, ensure_ascii=False)

        task = kwargs.get("task", "")
        if isinstance(task, str) and len(task) > MAX_TASK_LENGTH:
            return json.dumps({"error": f"Task too long: {len(task)} > {MAX_TASK_LENGTH}"}, ensure_ascii=False)
        if action == "orchestrate":
            return _orchestrate(**kwargs)
        elif action == "orch_status":
            return _orch_status()
        elif action == "orch_list":
            return _orch_list(**kwargs)
        elif action == "memory_write":
            return _run_async(_memory_write(**kwargs))
        elif action == "memory_search":
            return _run_async(_memory_search(**kwargs))
        elif action == "memory_context":
            return _run_async(_memory_context(**kwargs))
        elif action == "memory_stats":
            return _run_async(_memory_stats())
        elif action == "memory_consolidate":
            return _run_async(_memory_consolidate(**kwargs))
        elif action == "memory_link":
            return _run_async(_memory_link(**kwargs))
        elif action == "eval_define":
            return _eval_define(**kwargs)
        elif action == "eval_run":
            return _eval_run(**kwargs)
        elif action == "eval_trends":
            return _eval_trends()
        elif action == "eval_failures":
            return _eval_failures()
        elif action == "eval_stats":
            return _eval_stats()
        elif action == "upload_error_logs":
            return _run_async(_upload_error_logs(**kwargs))
        elif action == "error_logs_stats":
            return _error_logs_stats()
        else:
            return json.dumps({"error": f"Unknown action: {action}"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


def _orchestrate(**kwargs) -> str:
    from .orchestrator_workers import OrchestratorWorkers, WorkerCapability
    orch = OrchestratorWorkers.get_instance()
    task = kwargs.get("task", "")
    max_subtasks = kwargs.get("max_subtasks", 5)
    timeout = kwargs.get("timeout_seconds", 300.0)
    quality_threshold = kwargs.get("quality_threshold", 0.7)
    max_retries = kwargs.get("max_retries", 1)

    try:
        result = run_async_safe(
            orch.orchestrate(
                task=task,
                max_subtasks=max_subtasks,
                timeout_seconds=timeout,
                quality_threshold=quality_threshold,
                max_retries=max_retries,
            )
        )
        return json.dumps({
            "orchestration_id": result.orchestration_id,
            "success": result.success,
            "quality_score": result.quality_score,
            "total_time_ms": result.total_time_ms,
            "subtask_count": len(result.subtasks),
            "workers_used": result.workers_used,
            "final_result": str(result.final_result)[:2000] if result.final_result else "",
            "retry_count": result.retry_count,
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


def _orch_status() -> str:
    from .orchestrator_workers import OrchestratorWorkers
    orch = OrchestratorWorkers.get_instance()
    return json.dumps(orch.get_status(), ensure_ascii=False)


def _orch_list(**kwargs) -> str:
    from .orchestrator_workers import OrchestratorWorkers
    orch = OrchestratorWorkers.get_instance()
    limit = kwargs.get("limit", 20)
    return json.dumps(orch.list_orchestrations(limit), ensure_ascii=False)


async def _memory_write(**kwargs) -> str:
    from .cross_session_memory import CrossSessionMemory, MemoryType, MemoryScope
    csm = CrossSessionMemory.get_instance()
    entry_id = await csm.write(
        content=kwargs.get("content", ""),
        memory_type=MemoryType(kwargs.get("memory_type", "episodic")),
        scope=MemoryScope(kwargs.get("scope", "agent_shared")),
        agent_id=kwargs.get("agent_id", ""),
        session_id=kwargs.get("session_id", ""),
        namespace=kwargs.get("namespace", "default"),
        tags=kwargs.get("tags", []),
        entities=kwargs.get("entities", []),
        importance=kwargs.get("importance", 0.5),
    )
    return json.dumps({"entry_id": entry_id, "status": "written"}, ensure_ascii=False)


async def _memory_search(**kwargs) -> str:
    from .cross_session_memory import CrossSessionMemory, MemoryType, MemoryScope
    csm = CrossSessionMemory.get_instance()
    results = await csm.search(
        query=kwargs.get("query", ""),
        agent_id=kwargs.get("agent_id") or None,
        session_id=kwargs.get("session_id") or None,
        namespace=kwargs.get("namespace") or None,
        tags=kwargs.get("tags") or None,
        entities=kwargs.get("entities") or None,
        limit=kwargs.get("limit", 20),
    )
    return json.dumps([
        {
            "entry_id": r.entry_id,
            "content": r.content[:300],
            "type": r.memory_type.value,
            "importance": r.importance,
            "created_at": r.created_at,
        }
        for r in results
    ], ensure_ascii=False)


async def _memory_context(**kwargs) -> str:
    from .cross_session_memory import CrossSessionMemory
    csm = CrossSessionMemory.get_instance()
    context = await csm.get_context(
        current_query=kwargs.get("query", ""),
        agent_id=kwargs.get("agent_id", ""),
        session_id=kwargs.get("session_id", ""),
        max_entries=kwargs.get("max_entries", 5),
    )
    return json.dumps({"context": context}, ensure_ascii=False)


async def _memory_stats() -> str:
    from .cross_session_memory import CrossSessionMemory
    csm = CrossSessionMemory.get_instance()
    return json.dumps(await csm.get_stats(), ensure_ascii=False)


async def _memory_consolidate(**kwargs) -> str:
    from .cross_session_memory import CrossSessionMemory
    csm = CrossSessionMemory.get_instance()
    count = await csm.consolidate(
        agent_id=kwargs.get("agent_id", ""),
        namespace=kwargs.get("namespace", "default"),
    )
    return json.dumps({"consolidated_count": count}, ensure_ascii=False)


async def _memory_link(**kwargs) -> str:
    from .cross_session_memory import CrossSessionMemory
    csm = CrossSessionMemory.get_instance()
    session_id = kwargs.get("session_id", "")
    count = await csm.auto_link_sessions(session_id)
    return json.dumps({"linked_count": count}, ensure_ascii=False)


def _eval_define(**kwargs) -> str:
    from .outcomes_evaluator import SuccessCriterion, CriterionType
    criteria = []
    raw_criteria = kwargs.get("criteria", [])
    for c in raw_criteria:
        criteria.append(SuccessCriterion(
            name=c.get("name", ""),
            description=c.get("description", ""),
            criterion_type=CriterionType(c.get("type", "contains")),
            threshold=c.get("threshold", 0.7),
            weight=c.get("weight", 1.0),
            required=c.get("required", True),
            params=c.get("params", {}),
        ))
    return json.dumps({
        "criteria_count": len(criteria),
        "criteria": [
            {"name": c.name, "type": c.criterion_type.value, "threshold": c.threshold}
            for c in criteria
        ],
    }, ensure_ascii=False)


def _eval_run(**kwargs) -> str:
    from .outcomes_evaluator import OutcomeEvaluator, OutcomeTracker, SuccessCriterion, CriterionType
    result_text = kwargs.get("result", "")
    raw_criteria = kwargs.get("criteria", [])

    criteria = []
    for c in raw_criteria:
        criteria.append(SuccessCriterion(
            name=c.get("name", ""),
            criterion_type=CriterionType(c.get("type", "contains")),
            threshold=c.get("threshold", 0.7),
            weight=c.get("weight", 1.0),
            required=c.get("required", True),
            params=c.get("params", {}),
        ))

    if not criteria:
        criteria = [
            SuccessCriterion(name="no_errors", criterion_type=CriterionType.NO_ERROR, threshold=0.8, required=True),
            SuccessCriterion(name="relevance", criterion_type=CriterionType.KEYWORD_COVERAGE, threshold=0.3, weight=0.5, required=False, params={"keywords": kwargs.get("task", "").split()[:8]}),
        ]

    evaluator = OutcomeEvaluator()
    evaluation = evaluator.evaluate(result_text, criteria)

    tracker = OutcomeTracker.get_instance()
    tracker.record(evaluation)

    return json.dumps({
        "overall_score": evaluation.overall_score,
        "overall_passed": evaluation.overall_passed,
        "criterion_results": [
            {"name": cr.name, "score": cr.score, "passed": cr.passed, "details": cr.details}
            for cr in evaluation.criterion_results
        ],
        "suggestions": evaluation.refinement_suggestions[:5],
    }, ensure_ascii=False)


def _eval_trends() -> str:
    from .outcomes_evaluator import OutcomeTracker
    tracker = OutcomeTracker.get_instance()
    return json.dumps(tracker.get_trends(), ensure_ascii=False)


def _eval_failures() -> str:
    from .outcomes_evaluator import OutcomeTracker
    tracker = OutcomeTracker.get_instance()
    return json.dumps(tracker.get_common_failures(), ensure_ascii=False)


def _eval_stats() -> str:
    from .outcomes_evaluator import OutcomeTracker
    tracker = OutcomeTracker.get_instance()
    return json.dumps(tracker.get_stats(), ensure_ascii=False)


async def _upload_error_logs(**kwargs) -> str:
    from ...utils.error_reporter import get_error_reporter
    reporter = get_error_reporter()
    server_url = kwargs.get("server_url")
    result = await reporter.upload(server_url=server_url)
    return json.dumps({
        "success": result.success,
        "accepted": result.accepted,
        "duplicates_skipped": result.duplicates_skipped,
        "error_message": result.error_message,
    }, ensure_ascii=False)


def _error_logs_stats() -> str:
    from ...utils.error_reporter import get_error_reporter
    reporter = get_error_reporter()
    return json.dumps(reporter.get_stats(), ensure_ascii=False)
