#!/usr/bin/env python3 -*-
"""Computer Use tool - screen observation and action loop.

Enables the agent to observe and interact with GUI applications:
- Screenshot capture for visual observation
- Mouse click at coordinates
- Keyboard text input
- Key press (Enter, Tab, Escape, etc.)
- Scroll up/down
- Safety boundaries: operation approval, frequency limits, forbidden zones

Inspired by Anthropic Computer Use (OSWorld 72.5%) and Perplexity Personal Computer.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse

logger = logging.getLogger(__name__)


class ComputerAction(str, Enum):
    SCREENSHOT = "screenshot"
    CLICK = "click"
    DOUBLE_CLICK = "double_click"
    RIGHT_CLICK = "right_click"
    TYPE_TEXT = "type_text"
    KEY_PRESS = "key_press"
    HOTKEY = "hotkey"
    SCROLL = "scroll"
    DRAG = "drag"
    MOVE_TO = "move_to"


@dataclass
class SafetyBoundary:
    """Safety boundaries for Computer Use operations."""
    max_operations_per_minute: int = 30
    forbidden_zones: List[Tuple[int, int, int, int]] = field(default_factory=list)
    require_approval_for: List[ComputerAction] = field(default_factory=lambda: [
        ComputerAction.KEY_PRESS,
    ])
    screenshot_interval_ms: int = 500
    max_drag_distance: int = 500


@dataclass
class OperationRecord:
    """Record of a computer use operation."""
    action: ComputerAction
    params: Dict[str, Any]
    timestamp: float
    approved: bool = True


class ComputerUseController:
    """Controller for Computer Use operations with safety boundaries."""

    def __init__(self, safety: Optional[SafetyBoundary] = None):
        self.safety = safety or SafetyBoundary()
        self._operation_history: List[OperationRecord] = []
        self._last_screenshot_time: float = 0.0
        self._pyautogui_available: Optional[bool] = None

    def _check_rate_limit(self) -> bool:
        now = time.time()
        recent = [r for r in self._operation_history if now - r.timestamp < 60]
        return len(recent) < self.safety.max_operations_per_minute

    def _check_forbidden_zone(self, x: int, y: int) -> bool:
        for x1, y1, x2, y2 in self.safety.forbidden_zones:
            if x1 <= x <= x2 and y1 <= y <= y2:
                return False
        return True

    def _needs_approval(self, action: ComputerAction) -> bool:
        return action in self.safety.require_approval_for

    def _record(self, action: ComputerAction, params: Dict, approved: bool = True):
        self._operation_history.append(
            OperationRecord(action=action, params=params, timestamp=time.time(), approved=approved)
        )
        if len(self._operation_history) > 1000:
            self._operation_history = self._operation_history[-500:]

    async def _get_pyautogui(self):
        if self._pyautogui_available is None:
            try:
                import pyautogui
                self._pyautogui_available = True
                pyautogui.FAILSAFE = True
                pyautogui.PAUSE = 0.05
            except ImportError:
                self._pyautogui_available = False
        if not self._pyautogui_available:
            raise RuntimeError("pyautogui not installed. Install with: pip install pyautogui")
        import pyautogui
        return pyautogui

    async def screenshot(self, path: str = "") -> ToolResponse:
        now = time.time()
        if now - self._last_screenshot_time < self.safety.screenshot_interval_ms / 1000:
            await asyncio.sleep(self.safety.screenshot_interval_ms / 1000)

        path = (path or "").strip()
        if not path:
            base_dir = os.path.expanduser("~/.xingzierai/computer_use")
            os.makedirs(base_dir, exist_ok=True)
            path = os.path.join(base_dir, f"screenshot_{int(now)}.png")

        try:
            import mss
            with mss.mss() as sct:
                sct.shot(mon=0, output=path)
            self._last_screenshot_time = time.time()
            self._record(ComputerAction.SCREENSHOT, {"path": path})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "screenshot",
                    "path": os.path.abspath(path),
                    "message": "Screenshot captured. Use view_image tool to analyze it.",
                }, ensure_ascii=False))],
            )
        except ImportError:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "mss not installed. pip install mss",
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def click(self, x: int, y: int, button: str = "left",
                    clicks: int = 1) -> ToolResponse:
        if not self._check_rate_limit():
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "Rate limit exceeded. Wait before next operation.",
                }, ensure_ascii=False))],
            )
        if not self._check_forbidden_zone(x, y):
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": f"Click at ({x},{y}) is in a forbidden zone.",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            pyautogui.click(x=x, y=y, button=button, clicks=clicks)
            action = ComputerAction.CLICK if clicks == 1 else ComputerAction.DOUBLE_CLICK
            self._record(action, {"x": x, "y": y, "button": button, "clicks": clicks})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "click",
                    "x": x, "y": y, "button": button, "clicks": clicks,
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def type_text(self, text: str, interval: float = 0.02) -> ToolResponse:
        if not self._check_rate_limit():
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "Rate limit exceeded.",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            pyautogui.typewrite(text, interval=interval) if all(ord(c) < 128 for c in text) else pyautogui.write(text)
            self._record(ComputerAction.TYPE_TEXT, {"text_length": len(text)})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "type_text",
                    "text_length": len(text),
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def key_press(self, key: str) -> ToolResponse:
        if not self._check_rate_limit():
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "Rate limit exceeded.",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            pyautogui.press(key)
            self._record(ComputerAction.KEY_PRESS, {"key": key})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "key_press", "key": key,
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def hotkey(self, *keys: str) -> ToolResponse:
        if not self._check_rate_limit():
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "Rate limit exceeded.",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            pyautogui.hotkey(*keys)
            self._record(ComputerAction.HOTKEY, {"keys": list(keys)})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "hotkey", "keys": list(keys),
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def scroll(self, direction: str = "down", amount: int = 3,
                     x: Optional[int] = None, y: Optional[int] = None) -> ToolResponse:
        if not self._check_rate_limit():
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": "Rate limit exceeded.",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            clicks = amount if direction == "down" else -amount
            kwargs = {}
            if x is not None and y is not None:
                kwargs["x"] = x
                kwargs["y"] = y
            pyautogui.scroll(clicks, **kwargs)
            self._record(ComputerAction.SCROLL, {"direction": direction, "amount": amount})
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "scroll",
                    "direction": direction, "amount": amount,
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def drag(self, start_x: int, start_y: int, end_x: int, end_y: int,
                   duration: float = 0.5) -> ToolResponse:
        dist = ((end_x - start_x) ** 2 + (end_y - start_y) ** 2) ** 0.5
        if dist > self.safety.max_drag_distance:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": f"Drag distance {dist:.0f}px exceeds max {self.safety.max_drag_distance}px",
                }, ensure_ascii=False))],
            )
        try:
            pyautogui = await self._get_pyautogui()
            pyautogui.moveTo(start_x, start_y)
            pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
            self._record(ComputerAction.DRAG, {
                "start": [start_x, start_y], "end": [end_x, end_y], "distance": int(dist),
            })
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "drag",
                    "start": [start_x, start_y], "end": [end_x, end_y],
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )

    async def get_screen_size(self) -> ToolResponse:
        try:
            pyautogui = await self._get_pyautogui()
            w, h = pyautogui.size()
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "screen_size",
                    "width": w, "height": h,
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )


_controller: Optional[ComputerUseController] = None


def get_computer_use_controller() -> ComputerUseController:
    global _controller
    if _controller is None:
        _controller = ComputerUseController()
    return _controller


async def computer_use(action: str, **kwargs) -> ToolResponse:
    """Computer Use tool - observe and interact with the screen.

    Actions:
    - screenshot: Capture screen. Params: path (optional)
    - click: Click at position. Params: x, y, button ("left"/"right"), clicks (1/2)
    - type_text: Type text. Params: text
    - key_press: Press a key. Params: key (e.g. "enter", "tab", "escape")
    - hotkey: Press key combo. Params: keys (e.g. "ctrl", "c")
    - scroll: Scroll. Params: direction ("up"/"down"), amount
    - drag: Drag from A to B. Params: start_x, start_y, end_x, end_y
    - screen_size: Get screen dimensions. No params.

    Safety: Rate limited (30/min), forbidden zones, drag distance limit.
    """
    ctrl = get_computer_use_controller()
    action_enum = ComputerAction(action.lower())

    if action_enum == ComputerAction.SCREENSHOT:
        return await ctrl.screenshot(kwargs.get("path", ""))
    elif action_enum == ComputerAction.CLICK:
        return await ctrl.click(
            int(kwargs.get("x", 0)), int(kwargs.get("y", 0)),
            kwargs.get("button", "left"), int(kwargs.get("clicks", 1)),
        )
    elif action_enum == ComputerAction.DOUBLE_CLICK:
        return await ctrl.click(
            int(kwargs.get("x", 0)), int(kwargs.get("y", 0)),
            kwargs.get("button", "left"), 2,
        )
    elif action_enum == ComputerAction.RIGHT_CLICK:
        return await ctrl.click(
            int(kwargs.get("x", 0)), int(kwargs.get("y", 0)),
            "right", 1,
        )
    elif action_enum == ComputerAction.TYPE_TEXT:
        return await ctrl.type_text(kwargs.get("text", ""))
    elif action_enum == ComputerAction.KEY_PRESS:
        return await ctrl.key_press(kwargs.get("key", "enter"))
    elif action_enum == ComputerAction.HOTKEY:
        keys = kwargs.get("keys", [])
        if isinstance(keys, str):
            keys = [k.strip() for k in keys.split(",")]
        return await ctrl.hotkey(*keys)
    elif action_enum == ComputerAction.SCROLL:
        return await ctrl.scroll(
            kwargs.get("direction", "down"), int(kwargs.get("amount", 3)),
            kwargs.get("x"), kwargs.get("y"),
        )
    elif action_enum == ComputerAction.DRAG:
        return await ctrl.drag(
            int(kwargs.get("start_x", 0)), int(kwargs.get("start_y", 0)),
            int(kwargs.get("end_x", 0)), int(kwargs.get("end_y", 0)),
            float(kwargs.get("duration", 0.5)),
        )
    elif action_enum == ComputerAction.MOVE_TO:
        try:
            pyautogui = await ctrl._get_pyautogui()
            pyautogui.moveTo(int(kwargs.get("x", 0)), int(kwargs.get("y", 0)))
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": True, "action": "move_to",
                }, ensure_ascii=False))],
            )
        except Exception as e:
            return ToolResponse(
                content=[TextBlock(type="text", text=json.dumps({
                    "ok": False, "error": str(e),
                }, ensure_ascii=False))],
            )
    else:
        return ToolResponse(
            content=[TextBlock(type="text", text=json.dumps({
                "ok": False, "error": f"Unknown action: {action}. Valid: screenshot, click, double_click, right_click, type_text, key_press, hotkey, scroll, drag, move_to",
            }, ensure_ascii=False))],
        )
