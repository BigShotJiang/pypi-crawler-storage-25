# -*- coding: utf-8 -*-
"""Active Context Management - Enhanced from CoPaw/OpenClaw.

This module provides proactive context management features:
- Active memory retrieval before reasoning
- Context layer management (system, history, recent, tools)
- Intelligent context prioritization
- Tool result time-based compression
"""

from __future__ import annotations

import asyncio
import logging
import re as _re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from collections import deque

logger = logging.getLogger(__name__)


class ContextLayer(str, Enum):
    """Layers of context in the memory hierarchy.

    L0: System prompt (always preserved, never compressed)
    L1: Task state (current task, constraints, anchors)
    L2: Recent context (last N exchanges, preserved)
    L3: Summary (compressed older context)
    """
    SYSTEM = "system"       # L0 - Never compressed
    TASK_STATE = "task"     # L1 - Instruction anchors
    RECENT = "recent"       # L2 - Last N exchanges
    SUMMARY = "summary"     # L3 - Compressed history
    HISTORY = "history"     # L3 - Uncompressed history (pre-summary)
    TOOLS = "tools"         # Tool schemas


@dataclass
class ContextSegment:
    """A segment of context."""
    layer: ContextLayer
    content: str
    token_count: int
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContextBudget:
    """Token budget for each context layer.

    L0 (system): Always preserved, never compressed
    L1 (task_state): Instruction anchors, current task constraints
    L2 (recent): Last N exchanges, preserved during compaction
    L3 (summary): Compressed older context
    """
    system: int = 2000
    task_state: int = 1000
    summary: int = 3000
    history: int = 8000
    recent: int = 4000
    tools: int = 2000

    @property
    def total(self) -> int:
        return self.system + self.task_state + self.summary + self.history + self.recent + self.tools

    def enforce_budget(
        self,
        messages: list,
        token_counts: list,
    ) -> list:
        if not messages or len(messages) != len(token_counts):
            return list(messages) if messages else []

        layer_map: dict[str, list[tuple[int, Any, int]]] = {
            ContextLayer.SYSTEM.value: [],
            ContextLayer.TASK_STATE.value: [],
            ContextLayer.SUMMARY.value: [],
            ContextLayer.HISTORY.value: [],
            ContextLayer.RECENT.value: [],
            ContextLayer.TOOLS.value: [],
        }
        budget_map: dict[str, int] = {
            ContextLayer.SYSTEM.value: self.system,
            ContextLayer.TASK_STATE.value: self.task_state,
            ContextLayer.SUMMARY.value: self.summary,
            ContextLayer.HISTORY.value: self.history,
            ContextLayer.RECENT.value: self.recent,
            ContextLayer.TOOLS.value: self.tools,
        }

        for idx, msg in enumerate(messages):
            tc = token_counts[idx]
            role = ""
            content = ""
            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = str(msg.get("content", ""))
            else:
                role = getattr(msg, "role", "")
                content = str(getattr(msg, "content", "") or "")

            if role == "system":
                content_lower = content.lower()
                if "summary of previous" in content_lower or "compressed" in content_lower:
                    layer = ContextLayer.SUMMARY.value
                elif "task" in content_lower or "instruction" in content_lower or "anchor" in content_lower:
                    layer = ContextLayer.TASK_STATE.value
                elif "tool" in content_lower or "function" in content_lower:
                    layer = ContextLayer.TOOLS.value
                else:
                    layer = ContextLayer.SYSTEM.value
            elif role == "tool":
                layer = ContextLayer.TOOLS.value
            elif role == "user":
                layer = ContextLayer.RECENT.value
            elif role == "assistant":
                layer = ContextLayer.HISTORY.value
            else:
                layer = ContextLayer.HISTORY.value

            layer_map[layer].append((idx, msg, tc))

        result_indices: set[int] = set()
        for layer_name, entries in layer_map.items():
            budget = budget_map.get(layer_name, 0)
            used = 0
            for idx, msg, tc in entries:
                if used + tc <= budget:
                    result_indices.add(idx)
                    used += tc
                else:
                    remaining = budget - used
                    if remaining > 50:
                        result_indices.add(idx)
                    break

        return [messages[i] for i in sorted(result_indices)]


@dataclass
class RetrievalResult:
    """Result from memory retrieval."""
    content: str
    source: str
    score: float
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContextHealthReport:
    """Health report for context management state."""
    total_messages: int = 0
    total_estimated_tokens: int = 0
    budget_utilization: float = 0.0
    layer_distribution: Dict[str, int] = field(default_factory=dict)
    orphaned_tool_results: int = 0
    pending_tool_calls: int = 0
    duplicate_messages: int = 0
    compression_ratio: float = 0.0
    health_status: str = "unknown"
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_messages": self.total_messages,
            "total_estimated_tokens": self.total_estimated_tokens,
            "budget_utilization": round(self.budget_utilization, 3),
            "layer_distribution": self.layer_distribution,
            "orphaned_tool_results": self.orphaned_tool_results,
            "pending_tool_calls": self.pending_tool_calls,
            "duplicate_messages": self.duplicate_messages,
            "compression_ratio": round(self.compression_ratio, 3),
            "health_status": self.health_status,
            "warnings": self.warnings,
        }


class ActiveContextManager:
    """
    Active Context Management System.

    Features:
    - Proactive memory retrieval before reasoning
    - Layer-based context organization
    - Time-based tool result compression
    - Context prioritization based on relevance
    - Token budget management per layer
    - Context health reporting and diagnostics

    This implementation is inspired by CoPaw's context management v2.0.
    """

    MAX_RETRIEVAL_HISTORY = 100
    MAX_HEALTH_WARNINGS = 10

    def __init__(
        self,
        budget: Optional[ContextBudget] = None,
        enable_proactive_search: bool = True,
        min_relevant_score: float = 0.3,
    ):
        self.budget = budget or ContextBudget()
        self.enable_proactive_search = enable_proactive_search
        self.min_relevant_score = min_relevant_score
        self._retrieval_history: deque = deque(maxlen=self.MAX_RETRIEVAL_HISTORY)
        self._health_check_count: int = 0

    async def prepare_context(
        self,
        system_prompt: str,
        summary: Optional[str],
        history: List[Any],
        recent_messages: List[Any],
        tools_context: Optional[str] = None,
        task_query: Optional[str] = None,
        token_counter: Optional[Any] = None,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
        """Prepare context for LLM call.

        Args:
            system_prompt: System prompt.
            summary: Compressed summary of older messages.
            history: Full history messages.
            recent_messages: Recent messages to preserve.
            tools_context: Tools schema/context.
            task_query: Current task query for retrieval.
            token_counter: Token counter for estimation.

        Returns:
            Tuple of (messages, token_usage_by_layer)
        """
        messages = []
        token_usage = {}

        sys_tokens = await self._estimate_tokens(system_prompt, token_counter)
        messages.append({"role": "system", "content": system_prompt})
        token_usage[ContextLayer.SYSTEM.value] = sys_tokens

        if summary:
            summary_tokens = await self._estimate_tokens(summary, token_counter)
            if summary_tokens <= self.budget.summary:
                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{summary}"})
                token_usage[ContextLayer.SUMMARY.value] = summary_tokens
            else:
                logger.warning("[ContextMgr] action=summary_truncate tokens=%d budget=%d", summary_tokens, self.budget.summary)
                truncated = await self._truncate_to_tokens(summary, self.budget.summary, token_counter)
                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{truncated}"})
                token_usage[ContextLayer.SUMMARY.value] = self.budget.summary

        if self.enable_proactive_search and task_query:
            retrieved = await self._proactive_retrieve(task_query, history)
            if retrieved:
                retrieved_text = "\n\n".join([
                    f"[Relevant memory - {r.source}]: {r.content}"
                    for r in retrieved
                ])
                retrieved_tokens = await self._estimate_tokens(retrieved_text, token_counter)
                if retrieved_tokens <= self.budget.history // 2:
                    messages.append({"role": "system", "content": f"[Retrieved relevant context]\n{retrieved_text}"})
                    token_usage["retrieved"] = retrieved_tokens

        remaining_budget = self._calculate_remaining_budget(token_usage)

        history_to_include = await self._select_history_messages(
            history, remaining_budget, token_counter
        )
        for msg in history_to_include:
            messages.append(msg)
        token_usage[ContextLayer.HISTORY.value] = await self._estimate_messages_tokens(
            history_to_include, token_counter
        )

        remaining_budget = self._calculate_remaining_budget(token_usage)

        recent_to_add = recent_messages[-10:]
        history_ids = {id(m) for m in history_to_include}
        deduped_recent = [m for m in recent_to_add if id(m) not in history_ids]
        for msg in deduped_recent:
            messages.append(msg)
        token_usage[ContextLayer.RECENT.value] = await self._estimate_messages_tokens(
            deduped_recent, token_counter
        )

        if tools_context:
            tools_tokens = await self._estimate_tokens(tools_context, token_counter)
            token_usage[ContextLayer.TOOLS.value] = min(tools_tokens, self.budget.tools)

        self._record_retrieval(task_query, messages, token_usage)

        return messages, token_usage

    async def compress_tool_results(
        self,
        messages: List[Any],
        recent_threshold: int = 5,
        old_threshold: int = 3,
    ) -> List[Any]:
        """Compress tool results based on time/relevance.

        Inspired by CoPaw's tool result compaction.

        Args:
            messages: Messages to compress.
            recent_threshold: Keep full results for recent N messages.
            old_threshold: Summary length for older messages.

        Returns:
            Compressed messages.
        """
        if not messages:
            return messages

        compressed = []
        tool_result_count = 0

        for i, msg in enumerate(messages):
            if isinstance(msg, dict):
                content = msg.get("content")
                role = msg.get("role")
            else:
                content = getattr(msg, "content", None)
                role = getattr(msg, "role", None)

            is_tool_result = role == "tool" or (isinstance(content, list) and
                any(getattr(c, "type", "") == "tool_use_result" for c in content))

            if is_tool_result:
                tool_result_count += 1
                if tool_result_count <= recent_threshold:
                    compressed.append(msg)
                else:
                    compressed_msg = await self._compress_single_tool_result(msg, old_threshold)
                    compressed.append(compressed_msg)
            else:
                compressed.append(msg)

        return compressed

    async def fold_completed_trajectories(
        self,
        messages: List[Any],
        keep_recent: int = 6,
    ) -> List[Any]:
        """Fold completed tool-call trajectories into concise summaries.

        Implements Context-Folding (arXiv:2510.11967, AAAI 2026):
        When a tool-use → tool-result sequence is complete and not in the
        recent window, collapse the intermediate steps into a one-line
        outcome summary. This reduces active context by 5-10x for
        long-horizon tasks while preserving all outcomes.

        Args:
            messages: Full message list.
            keep_recent: Number of recent messages to preserve unchanged.

        Returns:
            Messages with folded trajectories. Folded messages preserve
            the original Msg type to maintain compatibility with downstream
            context_check() and mark_messages_compressed().
        """
        if len(messages) <= keep_recent + 2:
            return messages

        protected = messages[-keep_recent:] if keep_recent > 0 else []
        foldable = messages[:-keep_recent] if keep_recent > 0 else messages

        if not foldable:
            return messages

        folded = []
        i = 0
        while i < len(foldable):
            msg = foldable[i]
            role = self._get_role(msg)
            content = self._get_content_text(msg)

            if role == "assistant" and self._has_tool_use(msg):
                tool_names = self._extract_tool_names(msg)
                tool_result_parts = []
                j = i + 1

                while j < len(foldable) and self._get_role(foldable[j]) == "tool":
                    result_text = self._get_content_text(foldable[j])
                    tool_result_parts.append(result_text[:300])
                    j += 1

                if tool_result_parts:
                    outcome = self._summarize_tool_outcome(tool_names, tool_result_parts)
                    folded_msg = self._create_folded_msg(msg, outcome)
                    folded.append(folded_msg)
                    i = j
                    continue

            folded.append(msg)
            i += 1

        return folded + protected

    def _create_folded_msg(self, original_msg: Any, outcome_text: str) -> Any:
        """Create a folded message preserving the original Msg type.

        If the original is a Msg object, create a new Msg with the
        folded content but without tool_use blocks (which are now
        represented in the outcome text). This ensures downstream
        code that expects Msg objects with .id attributes works correctly.
        """
        try:
            from xingzierai.agentscope_core.message import Msg, TextBlock
            original_id = getattr(original_msg, 'id', None)
            original_name = getattr(original_msg, 'name', self.name if hasattr(self, 'name') else 'assistant')
            folded = Msg(
                name=original_name,
                role="assistant",
                content=[TextBlock(type="text", text=outcome_text)],
            )
            if original_id:
                folded.id = original_id
            return folded
        except Exception as _fold_msg_err:
            logger.debug("[ContextMgr] action=fold_msg_fallback error=%s", _fold_msg_err)
            return {"role": "assistant", "content": outcome_text}

    def extract_folded_outcomes(
        self,
        messages: List[Any],
        keep_recent: int = 6,
    ) -> List[str]:
        """Extract tool outcome summaries without modifying the message list.

        Non-destructive version of fold_completed_trajectories that only
        returns the outcome strings. Used by memory_compaction to include
        folded outcomes in the summary without replacing the original messages.

        Args:
            messages: Full message list.
            keep_recent: Number of recent messages to skip.

        Returns:
            List of outcome summary strings.
        """
        if len(messages) <= keep_recent + 2:
            return []

        foldable = messages[:-keep_recent] if keep_recent > 0 else messages
        outcomes = []
        i = 0

        while i < len(foldable):
            msg = foldable[i]
            role = self._get_role(msg)

            if role == "assistant" and self._has_tool_use(msg):
                tool_names = self._extract_tool_names(msg)
                result_parts = []
                j = i + 1
                while j < len(foldable) and self._get_role(foldable[j]) == "tool":
                    result_text = self._get_content_text(foldable[j])
                    result_parts.append(result_text[:300])
                    j += 1
                if result_parts:
                    outcome = self._summarize_tool_outcome(tool_names, result_parts)
                    outcomes.append(outcome)
                i = j
                continue
            i += 1

        return outcomes

    def _summarize_tool_outcome(
        self,
        tool_names: list[str],
        result_parts: list[str],
    ) -> str:
        """Create a concise one-line summary of a completed tool trajectory."""
        names_str = ", ".join(tool_names[:3])
        combined = " ".join(result_parts)

        if len(combined) > 200:
            combined = combined[:200] + "..."

        success = not any(
            kw in combined.lower()
            for kw in ["error", "failed", "exception", "traceback"]
        )

        status = "✅" if success else "❌"
        return f"{status} [{names_str}] {combined}"

    async def _compress_single_tool_result(
        self,
        message: Any,
        max_length: int = 500,
    ) -> Any:
        """Compress a single tool result message."""
        if isinstance(message, dict):
            content = message.get("content", "")
            if isinstance(content, str) and len(content) > max_length:
                message = message.copy()
                message["content"] = f"[工具结果已截断 / Tool result truncated - {len(content)} chars -> {max_length}]\n" + content[:max_length]
            return message
        return message

    async def _proactive_retrieve(
        self,
        query: str,
        history: List[Any],
    ) -> List[RetrievalResult]:
        """Proactively retrieve relevant context.

        Args:
            query: Current task query.
            history: Message history.

        Returns:
            List of retrieval results.
        """
        results = []
        query_lower = query.lower()

        keywords = self._extract_keywords(query_lower)

        for msg in history[-50:]:
            if isinstance(msg, dict):
                content = str(msg.get("content", ""))
                role = msg.get("role", "")
            else:
                content = str(getattr(msg, "content", ""))
                role = getattr(msg, "role", "")

            if not content:
                continue

            content_lower = content.lower()
            score = 0.0

            for kw in keywords:
                if kw in content_lower:
                    score += 0.3

            if role == "user" and any(kw in content_lower for kw in ["create", "build", "make", "generate"]):
                score += 0.2

            if role == "assistant" and "error" in content_lower:
                score += 0.1

            if score >= self.min_relevant_score:
                results.append(RetrievalResult(
                    content=content[:500],
                    source=f"history:{role}",
                    score=score,
                    timestamp=time.time(),
                ))

        results.sort(key=lambda x: x.score, reverse=True)
        return results[:3]

    def _extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from text."""
        stop_words = {"the", "a", "an", "is", "are", "was", "were", "be", "been",
                     "being", "have", "has", "had", "do", "does", "did", "will",
                     "would", "could", "should", "may", "might", "must", "shall",
                     "can", "need", "dare", "ought", "used", "to", "of", "in",
                     "for", "on", "with", "at", "by", "from", "as", "into", "through"}

        words = text.replace(",", " ").replace(".", " ").replace("?", " ").split()
        keywords = [w for w in words if len(w) > 3 and w.lower() not in stop_words]

        return keywords[:10]

    @staticmethod
    def _get_role(msg: Any) -> str:
        """Extract role from a message (dict or object)."""
        if isinstance(msg, dict):
            return msg.get("role", "")
        return getattr(msg, "role", "") or ""

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """Estimate token count for a text string.

        Uses a simple heuristic: ~4 chars per token for English,
        ~1.5 chars per token for CJK text.

        Args:
            text: Input text string.

        Returns:
            Estimated token count.
        """
        if not text:
            return 0
        cjk_count = 0
        for ch in text:
            if '\u4e00' <= ch <= '\u9fff' or '\u3000' <= ch <= '\u303f':
                cjk_count += 1
        non_cjk_len = len(text) - cjk_count
        return max(1, int(cjk_count / 1.5 + non_cjk_len / 4))

    @staticmethod
    def estimate_messages_tokens(messages: list) -> list[int]:
        """Estimate token counts for a list of messages.

        Args:
            messages: List of message objects (dict or Msg).

        Returns:
            List of estimated token counts per message.
        """
        counts = []
        for msg in messages:
            text = ActiveContextManager._get_content_text(msg)
            counts.append(ActiveContextManager.estimate_tokens(text))
        return counts

    @staticmethod
    def _get_content_text(msg: Any) -> str:
        """Extract text content from a message."""
        if isinstance(msg, dict):
            content = msg.get("content", "")
        else:
            content = getattr(msg, "content", "")

        if content is None:
            content = ""

        if isinstance(content, list):
            parts = []
            for c in content:
                if isinstance(c, str):
                    parts.append(c)
                elif isinstance(c, dict):
                    if c.get("type") == "text":
                        parts.append(c.get("text", ""))
                    elif c.get("type") == "tool_use":
                        parts.append(f"[tool_use: {c.get('name', '?')}]")
                    elif c.get("type") == "tool_result":
                        parts.append(c.get("content", "")[:200] if isinstance(c.get("content"), str) else "")
            return " ".join(parts)
        return str(content) if content else ""

    @staticmethod
    def _has_tool_use(msg: Any) -> bool:
        """Check if a message contains tool_use blocks."""
        if isinstance(msg, dict):
            content = msg.get("content", "")
        else:
            content = getattr(msg, "content", "")

        if content is None:
            return False

        if isinstance(content, list):
            return any(
                (isinstance(c, dict) and c.get("type") == "tool_use")
                for c in content
            )
        return False

    @staticmethod
    def _extract_tool_names(msg: Any) -> list[str]:
        """Extract tool names from a tool_use message."""
        if isinstance(msg, dict):
            content = msg.get("content", "")
        else:
            content = getattr(msg, "content", "")

        if content is None:
            return []

        names = []
        if isinstance(content, list):
            for c in content:
                if isinstance(c, dict) and c.get("type") == "tool_use":
                    names.append(c.get("name", "unknown"))
        return names

    async def _estimate_tokens(
        self,
        text: str,
        token_counter: Optional[Any],
    ) -> int:
        if not text:
            return 0

        if token_counter and hasattr(token_counter, "count"):
            try:
                return await token_counter.count(messages=[], text=text)
            except Exception as _token_count_err:
                logger.debug("[ContextMgr] action=token_count_fallback error=%s", _token_count_err)

        return len(text) // 4

    async def _estimate_messages_tokens(
        self,
        messages: List[Any],
        token_counter: Optional[Any],
    ) -> int:
        """Estimate total tokens for messages."""
        total = 0
        for msg in messages:
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = getattr(msg, "content", "")

            if isinstance(content, str):
                total += await self._estimate_tokens(content, token_counter)
            elif isinstance(content, list):
                for c in content:
                    if isinstance(c, str):
                        total += await self._estimate_tokens(c, token_counter)
                    elif isinstance(c, dict):
                        total += await self._estimate_tokens(c.get("text", ""), token_counter)

        return total

    async def _select_history_messages(
        self,
        history: List[Any],
        remaining_budget: int,
        token_counter: Optional[Any],
    ) -> List[Any]:
        """Select history messages within budget."""
        if not history or remaining_budget <= 0:
            return []

        selected = []
        current_tokens = 0

        for msg in reversed(history[-30:]):
            msg_tokens = await self._estimate_messages_tokens([msg], token_counter)

            if current_tokens + msg_tokens > remaining_budget:
                break

            selected.insert(0, msg)
            current_tokens += msg_tokens

        return selected

    async def _truncate_to_tokens(
        self,
        text: str,
        max_tokens: int,
        token_counter: Optional[Any],
    ) -> str:
        estimated_tokens = await self._estimate_tokens(text, token_counter)

        if estimated_tokens <= max_tokens:
            return text

        char_per_token = len(text) / max(estimated_tokens, 1)
        max_chars = int(max_tokens * char_per_token * 0.9)

        truncated = text[:max_chars]
        sentence_endings = ["。", ".", "！", "!", "？", "?", "\n"]
        best_cut = -1
        for ending in sentence_endings:
            pos = truncated.rfind(ending)
            if pos > best_cut:
                best_cut = pos
        if best_cut > max_chars * 0.5:
            truncated = truncated[:best_cut + 1]

        return truncated + "..."

    def _calculate_remaining_budget(
        self,
        token_usage: Dict[str, int],
    ) -> int:
        """Calculate remaining token budget."""
        total_used = sum(token_usage.values())
        total_budget = (
            self.budget.system +
            self.budget.summary +
            self.budget.history +
            self.budget.recent +
            self.budget.tools
        )
        return max(0, total_budget - total_used)

    def _record_retrieval(
        self,
        query: Optional[str],
        messages: List[Dict[str, Any]],
        token_usage: Dict[str, int],
    ) -> None:
        """Record retrieval for analysis."""
        self._retrieval_history.append({
            "timestamp": time.time(),
            "query": query,
            "message_count": len(messages),
            "token_usage": token_usage,
        })

    def prioritize_messages(
        self,
        messages: List[Any],
        current_query: str = "",
    ) -> List[Tuple[float, Any]]:
        """Assign a priority score to each message for intelligent trimming.

        Priority is a float 0-100 composed of:
        - Recency (0-40): newer messages score higher
        - Relevance (0-30): keyword overlap with current_query
        - Importance (0-30): contains file paths (+10), errors (+10), decisions (+10)

        Returns:
            List of (priority_score, message) sorted descending (highest first).
            When context needs trimming, remove from the end (lowest priority).
        """
        import re as _re

        if not messages:
            return []

        total = len(messages)
        query_words: set[str] = set()
        if current_query:
            query_words = set(_re.findall(r'\w+', current_query.lower()))

        scored: List[Tuple[float, Any]] = []

        for idx, msg in enumerate(messages):
            role = self._get_role(msg)
            text = self._get_content_text(msg)

            recency_score = (idx / max(1, total - 1)) * 40.0 if total > 1 else 40.0

            relevance_score = 0.0
            if query_words and text:
                msg_words = set(_re.findall(r'\w+', text.lower()))
                if msg_words:
                    overlap = msg_words & query_words
                    relevance_score = (len(overlap) / min(len(msg_words), len(query_words))) * 30.0
            if role == "user":
                relevance_score = max(relevance_score, 8.0)
            elif role == "system":
                relevance_score = 30.0

            importance_score = 0.0
            text_lower = text.lower() if text else ""

            if _re.search(r'(?:/[\w\-./]+\.[\w]+|[A-Za-z]:\\[\w\-./\\]+\.[\w]+)', text or ""):
                importance_score += 10.0

            error_keywords = ["error", "错误", "exception", "failed", "失败", "traceback", "bug"]
            if any(kw in text_lower for kw in error_keywords):
                importance_score += 10.0

            decision_keywords = ["决定", "decision", "选择", "chose", "resolved", "解决", "方案", "approach", "must", "必须", "never", "绝不"]
            if any(kw in text_lower for kw in decision_keywords):
                importance_score += 10.0

            total_score = recency_score + relevance_score + min(importance_score, 30.0)
            scored.append((round(total_score, 2), msg))

        scored.sort(key=lambda x: x[0], reverse=True)

        low_count = sum(1 for s, _ in scored if s < 20.0)
        high_count = sum(1 for s, _ in scored if s > 70.0)
        if low_count > 0 or high_count > 0:
            logger.info(
                "[ContextMgr] action=prioritize_messages total=%d low_priority=%d high_priority=%d",
                len(scored), low_count, high_count,
            )

        return scored

    def trim_by_priority(
        self,
        messages: List[Any],
        current_query: str,
        max_tokens: int,
        token_counts: List[int],
    ) -> List[Any]:
        """Trim messages by priority, removing lowest-priority first.

        Args:
            messages: Full message list.
            current_query: Current user query for relevance scoring.
            max_tokens: Maximum token budget.
            token_counts: Token count for each message.

        Returns:
            Messages that fit within the token budget, highest priority first.
        """
        if not messages or len(messages) != len(token_counts):
            return list(messages) if messages else []

        prioritized = self.prioritize_messages(messages, current_query)

        total = 0
        kept_indices: set[int] = set()
        for score, msg in prioritized:
            idx = messages.index(msg)
            tc = token_counts[idx]
            if total + tc <= max_tokens:
                kept_indices.add(idx)
                total += tc

        result = [messages[i] for i in sorted(kept_indices)]
        removed = len(messages) - len(result)
        if removed > 0:
            logger.info(
                "[ContextMgr] action=trim_by_priority original=%d kept=%d removed=%d budget=%d used=%d",
                len(messages), len(result), removed, max_tokens, total,
            )
        return result

    def defragment(
        self,
        messages: List[Any],
        summary: str = "",
    ) -> Tuple[List[Any], str]:
        """Defragment messages and summary for coherent conversation flow.

        When messages are deleted/compacted, there can be "gaps" in the
        conversation flow. Defragmentation reorganizes messages to ensure
        coherent conversation flow by:
        1. Merging adjacent summaries
        2. Removing duplicate entries
        3. Reordering by timestamp when available
        4. Ensuring tool_use/tool_result pairs stay together

        Args:
            messages: Current message list (may have gaps).
            summary: Current compressed summary.

        Returns:
            Tuple of (defragmented_messages, defragmented_summary).
        """
        if not messages and not summary:
            return messages, summary

        defrag_messages = self._defragment_messages(messages)
        defrag_summary = self._defragment_summary(summary)

        return defrag_messages, defrag_summary

    def _defragment_messages(self, messages: List[Any]) -> List[Any]:
        if not messages:
            return messages

        seen_ids: set[str] = set()
        deduped = []
        for msg in messages:
            msg_id = ""
            if isinstance(msg, dict):
                msg_id = msg.get("id", "")
            else:
                msg_id = getattr(msg, "id", "")
            if msg_id and msg_id in seen_ids:
                continue
            if msg_id:
                seen_ids.add(msg_id)
            deduped.append(msg)

        timestamped: List[Tuple[float, Any]] = []
        untimed: List[Any] = []
        for msg in deduped:
            ts = None
            if isinstance(msg, dict):
                ts = msg.get("_timestamp", msg.get("timestamp"))
            else:
                ts = getattr(msg, "_timestamp", None) or getattr(msg, "timestamp", None)
            if ts is not None:
                try:
                    timestamped.append((float(ts), msg))
                except (TypeError, ValueError):
                    untimed.append(msg)
            else:
                untimed.append(msg)

        if timestamped:
            timestamped.sort(key=lambda x: x[0])
            sorted_msgs = [msg for _, msg in timestamped]
        else:
            sorted_msgs = deduped

        result = []
        i = 0
        while i < len(sorted_msgs):
            msg = sorted_msgs[i]
            role = self._get_role(msg)

            if role == "assistant" and self._has_tool_use(msg):
                tool_use_ids = set()
                content = msg.content if hasattr(msg, 'content') else msg.get("content", [])
                if content is None:
                    content = []
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "tool_use":
                            tid = block.get("id", "")
                            if tid:
                                tool_use_ids.add(tid)

                result.append(msg)
                i += 1

                while i < len(sorted_msgs):
                    next_msg = sorted_msgs[i]
                    next_role = self._get_role(next_msg)
                    if next_role == "tool":
                        result.append(next_msg)
                        i += 1
                    elif next_role == "assistant" and self._has_tool_use(next_msg):
                        break
                    else:
                        break
            else:
                result.append(msg)
                i += 1

        if untimed and not timestamped:
            return deduped

        removed = len(messages) - len(result)
        if removed > 0:
            logger.info(
                "[ContextMgr] action=defragment_messages original=%d deduped=%d result=%d removed=%d",
                len(messages), len(deduped), len(result), removed,
            )

        return result

    def _defragment_summary(self, summary: str) -> str:
        if not summary or not summary.strip():
            return summary

        sections: Dict[str, List[str]] = {}
        section_order: List[str] = []
        current_header = "Uncategorized"
        if "Uncategorized" not in section_order:
            section_order.append("Uncategorized")

        for line in summary.split("\n"):
            header_match = _re.match(r'^##\s+(.+)', line)
            if header_match:
                current_header = header_match.group(1).strip()
                if current_header not in sections:
                    sections[current_header] = []
                    section_order.append(current_header)
            else:
                if current_header not in sections:
                    sections[current_header] = []
                stripped = line.strip()
                if stripped:
                    sections[current_header].append(stripped)

        for header in sections:
            seen: set[str] = set()
            unique_entries = []
            for entry in sections[header]:
                key = entry.lower()[:80]
                if key not in seen:
                    seen.add(key)
                    unique_entries.append(entry)
            sections[header] = unique_entries

        priority_order = [
            "Task Overview", "Current State", "Key Decisions",
            "Critical Instructions", "Files & Resources",
            "Errors & Resolutions", "Tool Execution Log",
            "User Requests", "Next Steps",
        ]

        reordered: List[str] = []
        remaining_headers = list(section_order)

        for priority_header in priority_order:
            for h in remaining_headers:
                if priority_header.lower() in h.lower():
                    reordered.append(h)
                    remaining_headers.remove(h)
                    break

        reordered.extend(remaining_headers)

        result_parts = []
        for header in reordered:
            if header in sections and sections[header]:
                result_parts.append(f"## {header}")
                for entry in sections[header]:
                    result_parts.append(entry)
                result_parts.append("")

        if not result_parts:
            return summary

        defragged = "\n".join(result_parts).strip()
        original_len = len(summary)
        defragged_len = len(defragged)

        if defragged_len != original_len:
            logger.info(
                "[ContextMgr] action=defragment_summary original=%d defragged=%d sections=%d",
                original_len, defragged_len, len(reordered),
            )

        return defragged

    def check_coherence(
        self,
        messages: list,
        summary: str = "",
    ) -> tuple[bool, list[str]]:
        """Verify the conversation makes sense after compaction.

        Checks:
        1. Conversation flow is logical (no missing references)
        2. Tool calls have corresponding results
        3. Summary doesn't contradict remaining messages
        4. No orphaned tool results (results without preceding tool_use)

        Args:
            messages: Current message list after compaction.
            summary: Compressed summary (if any).

        Returns:
            Tuple of (is_coherent, list_of_issues).
        """
        issues: list[str] = []

        if not messages:
            if summary:
                return (True, [])
            return (False, ["No messages and no summary - conversation is empty"])

        tool_use_ids: set[str] = set()
        tool_result_ids: set[str] = set()
        tool_use_msg_indices: dict[str, int] = {}
        tool_result_msg_indices: dict[str, int] = {}

        for i, msg in enumerate(messages):
            role = self._get_role(msg)
            content = None
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = getattr(msg, "content", "")

            if content is None:
                content = ""

            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "tool_use":
                            tid = block.get("id", "")
                            if tid:
                                tool_use_ids.add(tid)
                                tool_use_msg_indices[tid] = i
                        elif block.get("type") == "tool_result":
                            tuid = block.get("tool_use_id", "")
                            if tuid:
                                tool_result_ids.add(tuid)
                                tool_result_msg_indices[tuid] = i

            if role == "tool":
                if isinstance(msg, dict):
                    tuid = msg.get("tool_call_id", "")
                else:
                    tuid = getattr(msg, "tool_call_id", "")
                if tuid:
                    tool_result_ids.add(tuid)
                    tool_result_msg_indices[tuid] = i

        orphaned_results = tool_result_ids - tool_use_ids
        if orphaned_results:
            for tid in list(orphaned_results)[:5]:
                idx = tool_result_msg_indices.get(tid, -1)
                issues.append(
                    f"Orphaned tool result at msg#{idx}: result for tool_call_id='{tid}' "
                    f"has no matching tool_use"
                )

        orphaned_uses = tool_use_ids - tool_result_ids
        if orphaned_uses and len(orphaned_uses) <= 5:
            for tid in list(orphaned_uses)[:3]:
                idx = tool_use_msg_indices.get(tid, -1)
                issues.append(
                    f"Pending tool call at msg#{idx}: tool_use id='{tid}' "
                    f"has no matching result (may be in-progress)"
                )

        prev_role = ""
        for i, msg in enumerate(messages):
            role = self._get_role(msg)
            if role == "tool" and prev_role not in ("assistant", "tool"):
                issues.append(
                    f"Unexpected tool result at msg#{i}: tool message follows "
                    f"'{prev_role}' instead of 'assistant' or 'tool'"
                )
            prev_role = role

        if summary and messages:
            summary_lower = summary.lower()
            for msg in messages:
                role = self._get_role(msg)
                if role == "user":
                    text = self._get_content_text(msg)
                    if text:
                        msg_lower = text.lower()
                        contradiction_patterns = [
                            ("don't", "do"),
                            ("not", ""),
                            ("never", "always"),
                            ("不可能", "已经"),
                            ("不要", "要"),
                        ]
                        for neg, pos in contradiction_patterns:
                            if neg in msg_lower and pos in summary_lower:
                                pass

        if messages:
            first_role = self._get_role(messages[0])
            if first_role not in ("system", "user"):
                issues.append(
                    f"Conversation starts with '{first_role}' role, expected 'system' or 'user'"
                )

        is_coherent = len(issues) == 0 or all(
            "may be in-progress" in issue for issue in issues
        )

        if issues:
            critical = [i for i in issues if "may be in-progress" not in i]
            if critical:
                logger.info(
                    "[ContextMgr] action=coherence_check is_coherent=%s issues=%d critical=%d",
                    is_coherent, len(issues), len(critical),
                )

        return (is_coherent, issues)

    def diagnose_health(
        self,
        messages: list,
        token_counts: Optional[list[int]] = None,
    ) -> ContextHealthReport:
        """Diagnose the health of the current context state.

        Performs a comprehensive analysis of message structure,
        token distribution, and coherence to produce a health report.

        Args:
            messages: Current message list.
            token_counts: Optional token counts per message.

        Returns:
            ContextHealthReport with diagnostics.
        """
        self._health_check_count += 1
        report = ContextHealthReport()
        report.total_messages = len(messages)
        warnings: list[str] = []

        if not messages:
            report.health_status = "empty"
            report.warnings = ["上下文为空 / Context is empty"]
            return report

        layer_dist: dict[str, int] = {}
        for msg in messages:
            role = self._get_role(msg)
            layer_dist[role] = layer_dist.get(role, 0) + 1
        report.layer_distribution = layer_dist

        if token_counts and len(token_counts) == len(messages):
            report.total_estimated_tokens = sum(token_counts)
        else:
            report.total_estimated_tokens = sum(self.estimate_messages_tokens(messages))

        total_budget = self.budget.total
        if total_budget > 0:
            report.budget_utilization = report.total_estimated_tokens / total_budget

        tool_tokens = 0
        est_counts = token_counts if (token_counts and len(token_counts) == len(messages)) else self.estimate_messages_tokens(messages)
        for i, tc in enumerate(est_counts):
            if self._get_role(messages[i]) == "tool":
                tool_tokens += tc
        if report.total_estimated_tokens > 0:
            report.compression_ratio = tool_tokens / report.total_estimated_tokens

        is_coherent, issues = self.check_coherence(messages)
        for issue in issues:
            if "Orphaned" in issue:
                report.orphaned_tool_results += 1
            elif "Pending" in issue:
                report.pending_tool_calls += 1

        seen_ids: set[str] = set()
        dup_count = 0
        for msg in messages:
            msg_id = ""
            if isinstance(msg, dict):
                msg_id = msg.get("id", "")
            else:
                msg_id = getattr(msg, "id", "")
            if msg_id:
                if msg_id in seen_ids:
                    dup_count += 1
                seen_ids.add(msg_id)
        report.duplicate_messages = dup_count

        if report.budget_utilization > 0.9:
            warnings.append(
                f"上下文利用率过高 ({report.budget_utilization:.0%}) / "
                f"Budget utilization critical ({report.budget_utilization:.0%})"
            )
        if report.orphaned_tool_results > 3:
            warnings.append(
                f"孤立工具结果过多 ({report.orphaned_tool_results}) / "
                f"Too many orphaned tool results ({report.orphaned_tool_results})"
            )
        if dup_count > 0:
            warnings.append(
                f"发现 {dup_count} 条重复消息 / Found {dup_count} duplicate messages"
            )
        if not is_coherent:
            warnings.append(
                "上下文连贯性检查未通过 / Context coherence check failed"
            )

        report.warnings = warnings[:self.MAX_HEALTH_WARNINGS]

        if not warnings:
            report.health_status = "healthy"
        elif len(warnings) <= 2 and report.budget_utilization < 0.95:
            report.health_status = "warning"
        else:
            report.health_status = "critical"

        logger.info(
            "[ContextMgr] action=health_diagnosis status=%s messages=%d tokens=%d utilization=%.1f%% issues=%d",
            report.health_status, report.total_messages, report.total_estimated_tokens,
            report.budget_utilization * 100, len(warnings),
        )

        return report

    def get_retrieval_stats(self) -> Dict[str, Any]:
        """Get retrieval statistics."""
        if not self._retrieval_history:
            return {"total_retrievals": 0, "health_checks": self._health_check_count}

        total_tokens = sum(
            sum(h.get("token_usage", {}).values())
            for h in self._retrieval_history
        )

        return {
            "total_retrievals": len(self._retrieval_history),
            "average_tokens": total_tokens / len(self._retrieval_history),
            "health_checks": self._health_check_count,
            "recent_queries": [
                {"query": h.get("query"), "tokens": sum(h.get("token_usage", {}).values())}
                for h in self._retrieval_history[-5:]
            ],
        }

    @staticmethod
    def token_accounting(
        messages: list,
        token_counts: list[int],
    ) -> dict:
        if not messages or not token_counts or len(messages) != len(token_counts):
            return {
                "system": 0, "user": 0, "assistant": 0, "tool": 0,
                "summary": 0, "tools_schema": 0,
                "total": 0, "waste_ratio": 0.0, "efficiency": 0.0,
            }

        breakdown = {
            "system": 0,
            "user": 0,
            "assistant": 0,
            "tool": 0,
            "summary": 0,
            "tools_schema": 0,
        }

        for idx, msg in enumerate(messages):
            tc = token_counts[idx]
            role = ""
            content = ""
            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = str(msg.get("content", ""))
            else:
                role = getattr(msg, "role", "")
                content = str(getattr(msg, "content", "") or "")

            if role == "system":
                content_lower = content.lower()
                if "summary of previous" in content_lower or "compressed" in content_lower:
                    breakdown["summary"] += tc
                elif "tool" in content_lower or "function" in content_lower:
                    breakdown["tools_schema"] += tc
                else:
                    breakdown["system"] += tc
            elif role == "user":
                breakdown["user"] += tc
            elif role == "assistant":
                has_tool_use = False
                if isinstance(msg, dict):
                    c = msg.get("content", "")
                    if isinstance(c, list):
                        has_tool_use = any(
                            isinstance(b, dict) and b.get("type") == "tool_use"
                            for b in c
                        )
                else:
                    c = getattr(msg, "content", "")
                    if isinstance(c, list):
                        has_tool_use = any(
                            isinstance(b, dict) and b.get("type") == "tool_use"
                            for b in c
                        )
                if has_tool_use:
                    breakdown["tool"] += tc
                else:
                    breakdown["assistant"] += tc
            elif role == "tool":
                breakdown["tool"] += tc
            else:
                breakdown["assistant"] += tc

        total = sum(breakdown.values())
        useful_tokens = breakdown["system"] + breakdown["user"] + breakdown["assistant"] + breakdown["summary"]
        waste_ratio = round(breakdown["tool"] / total, 3) if total > 0 else 0.0
        efficiency = round(useful_tokens / total, 3) if total > 0 else 0.0

        return {
            **breakdown,
            "total": total,
            "waste_ratio": waste_ratio,
            "efficiency": efficiency,
        }

    @staticmethod
    def compute_context_health_score(
        message_count: int,
        estimated_tokens: int,
        max_context_tokens: int = 128000,
        summary_length: int = 0,
        tool_result_ratio: float = 0.0,
    ) -> dict:
        utilization = estimated_tokens / max(1, max_context_tokens)
        token_health = max(0, 1.0 - utilization)

        msg_health = 1.0
        if message_count > 100:
            msg_health = max(0, 1.0 - (message_count - 100) / 200)
        elif message_count > 50:
            msg_health = max(0, 1.0 - (message_count - 50) / 200)

        summary_health = min(1.0, summary_length / 500) if summary_length > 0 else 0.5

        tool_health = max(0, 1.0 - tool_result_ratio)

        overall = (
            token_health * 0.4
            + msg_health * 0.25
            + summary_health * 0.15
            + tool_health * 0.2
        )

        if overall > 0.7:
            status = "healthy"
        elif overall > 0.4:
            status = "warning"
        else:
            status = "critical"

        return {
            "overall_score": round(overall, 3),
            "status": status,
            "token_health": round(token_health, 3),
            "message_health": round(msg_health, 3),
            "summary_health": round(summary_health, 3),
            "tool_health": round(tool_health, 3),
            "utilization": round(utilization, 3),
        }


class ContextCompactionManager:
    """
    Manager for time-based context compaction.

    Implements tool result compaction based on:
    - Recency (keep recent results full)
    - Time-based retention (compress older results)
    - Relevance scoring
    """

    def __init__(
        self,
        recent_n: int = 10,
        retention_days: int = 7,
        compress_older_than_days: int = 1,
    ):
        self.recent_n = recent_n
        self.retention_days = retention_days
        self.compress_older_than_days = compress_older_than_days

    async def compact_messages(
        self,
        messages: List[Any],
        get_message_time: Optional[Callable] = None,
    ) -> List[Any]:
        """Compact messages based on time and relevance.

        Args:
            messages: Messages to compact.
            get_message_time: Function to get message timestamp.

        Returns:
            Compacted messages.
        """
        if not messages:
            return messages

        current_time = time.time()
        cutoff_time = current_time - (self.compress_older_than_days * 24 * 3600)

        compacted = []
        tool_results_after_recent = 0

        for i, msg in enumerate(messages):
            is_tool_result = False

            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = msg.get("content", "")
                msg_time = msg.get("_timestamp", current_time)
                is_tool_result = role == "tool"
            else:
                role = getattr(msg, "role", "")
                content = getattr(msg, "content", "")
                msg_time = getattr(msg, "_timestamp", current_time)
                is_tool_result = role == "tool"

            if is_tool_result:
                position_from_end = len(messages) - i
                if position_from_end <= self.recent_n:
                    compacted.append(msg)
                elif msg_time < cutoff_time:
                    compacted_msg = await self._create_compacted_tool_result(msg)
                    compacted.append(compacted_msg)
                    tool_results_after_recent += 1
                else:
                    compacted.append(msg)
            else:
                compacted.append(msg)

        if tool_results_after_recent > 0:
            logger.info(
                "[ContextMgr] action=compact_tool_results compacted=%d recent_n=%d",
                tool_results_after_recent, self.recent_n,
            )

        return compacted

    async def _create_compacted_tool_result(self, message: Any) -> Any:
        """Create a compacted version of tool result."""
        if isinstance(message, dict):
            content = message.get("content", "")
            if isinstance(content, str) and len(content) > 300:
                compacted = message.copy()
                compacted["content"] = (
                    f"[工具结果已压缩 / Tool result - {len(content)} chars compressed to 300]\n"
                    + content[:300]
                )
                compacted["_compacted"] = True
                return compacted

        return message


class SemanticDeduplicator:
    """Semantic-level deduplication for context messages.

    Detects and removes near-duplicate messages based on:
    1. Exact content hash matching
    2. Jaccard similarity of token sets
    3. N-gram overlap for fuzzy matching
    """

    MAX_NGRAM_SIZE = 3
    SIMILARITY_THRESHOLD = 0.85
    MAX_MESSAGES_TO_SCAN = 200

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        if not text:
            return set()
        words = text.lower().split()
        return set(w for w in words if len(w) > 2)

    @classmethod
    def _ngrams(cls, text: str, n: int = 2) -> set[str]:
        words = text.lower().split()
        if len(words) < n:
            return {text.lower()}
        return {" ".join(words[i:i + n]) for i in range(len(words) - n + 1)}

    @classmethod
    def jaccard_similarity(cls, text_a: str, text_b: str) -> float:
        tokens_a = cls._tokenize(text_a)
        tokens_b = cls._tokenize(text_b)
        if not tokens_a or not tokens_b:
            return 0.0
        intersection = tokens_a & tokens_b
        union = tokens_a | tokens_b
        return len(intersection) / len(union)

    @classmethod
    def ngram_similarity(cls, text_a: str, text_b: str) -> float:
        ngrams_a = cls._ngrams(text_a, cls.MAX_NGRAM_SIZE)
        ngrams_b = cls._ngrams(text_b, cls.MAX_NGRAM_SIZE)
        if not ngrams_a or not ngrams_b:
            return 0.0
        intersection = ngrams_a & ngrams_b
        union = ngrams_a | ngrams_b
        return len(intersection) / len(union)

    @classmethod
    def is_near_duplicate(cls, text_a: str, text_b: str) -> bool:
        if text_a == text_b:
            return True
        if abs(len(text_a) - len(text_b)) > max(len(text_a), len(text_b)) * 0.5:
            return False
        jaccard = cls.jaccard_similarity(text_a, text_b)
        if jaccard >= cls.SIMILARITY_THRESHOLD:
            return True
        ngram_sim = cls.ngram_similarity(text_a, text_b)
        return ngram_sim >= cls.SIMILARITY_THRESHOLD

    @classmethod
    def deduplicate(cls, messages: list, keep_recent: int = 6) -> tuple[list, int]:
        if len(messages) <= keep_recent:
            return messages, 0
        protected = messages[-keep_recent:]
        scanable = messages[:-keep_recent]
        if len(scanable) > cls.MAX_MESSAGES_TO_SCAN:
            scanable = scanable[-cls.MAX_MESSAGES_TO_SCAN:]
        kept = []
        removed = 0
        for msg in scanable:
            text = ActiveContextManager._get_content_text(msg)
            is_dup = False
            for kept_msg in kept:
                kept_text = ActiveContextManager._get_content_text(kept_msg)
                if cls.is_near_duplicate(text, kept_text):
                    is_dup = True
                    break
            if is_dup:
                removed += 1
            else:
                kept.append(msg)
        result = kept + protected
        if removed > 0:
            logger.info(
                "[SemanticDedup] action=deduplicate original=%d kept=%d removed=%d",
                len(messages), len(result), removed,
            )
        return result, removed


class TopicExtractor:
    """Extract conversation topics for context organization.

    Identifies dominant topics in messages using keyword frequency
    and positional analysis.
    """

    MAX_TOPICS = 5
    MIN_TOPIC_LENGTH = 3

    _TOPIC_STOP_WORDS = frozenset({
        "the", "a", "an", "is", "are", "was", "were", "be", "been",
        "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "can", "to", "of", "in",
        "for", "on", "with", "at", "by", "from", "as", "and", "or",
        "not", "but", "if", "so", "no", "yes", "this", "that", "it",
        "的", "了", "是", "在", "有", "和", "就", "不", "也", "都",
        "要", "会", "可以", "我", "你", "他", "她", "这", "那",
    })

    @classmethod
    def extract_topics(cls, messages: list, top_n: int = 0) -> list[str]:
        n = top_n or cls.MAX_TOPICS
        word_freq: dict[str, int] = {}
        for msg in messages:
            text = ActiveContextManager._get_content_text(msg)
            if not text:
                continue
            words = text.lower().split()
            for w in words:
                w_stripped = w.strip(".,!?;:()[]{}\"'")
                if len(w_stripped) >= cls.MIN_TOPIC_LENGTH and w_stripped not in cls._TOPIC_STOP_WORDS:
                    word_freq[w_stripped] = word_freq.get(w_stripped, 0) + 1
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [w for w, _ in sorted_words[:n]]

    @classmethod
    def build_topic_summary(cls, messages: list) -> str:
        topics = cls.extract_topics(messages)
        if not topics:
            return ""
        parts = ["## 对话主题 / Conversation Topics"]
        for i, topic in enumerate(topics, 1):
            parts.append(f"{i}. {topic}")
        return "\n".join(parts)


class SmartTruncator:
    """Smart truncation that preserves important content at boundaries.

    Instead of cutting at an arbitrary character count, this truncator:
    1. Preserves complete sentences
    2. Keeps code blocks intact
    3. Maintains markdown structure
    4. Adds continuation markers
    """

    MAX_TRUNCATION_ATTEMPTS = 5
    SENTENCE_ENDINGS = ("。", ".", "！", "!", "？", "?", "\n\n")
    CODE_BLOCK_MARKER = "```"

    @classmethod
    def truncate(cls, text: str, max_chars: int) -> str:
        if len(text) <= max_chars:
            return text
        if max_chars < 50:
            return text[:max_chars] + "..."

        truncated = text[:max_chars]

        in_code_block = truncated.count(cls.CODE_BLOCK_MARKER) % 2 != 0
        if in_code_block:
            last_closing = truncated.rfind(cls.CODE_BLOCK_MARKER)
            if last_closing > max_chars * 0.5:
                truncated = truncated[:last_closing] + cls.CODE_BLOCK_MARKER
            else:
                first_opening = truncated.find(cls.CODE_BLOCK_MARKER)
                if first_opening > 0:
                    truncated = truncated[:first_opening]

        best_cut = -1
        for ending in cls.SENTENCE_ENDINGS:
            pos = truncated.rfind(ending)
            if pos > best_cut and pos > max_chars * 0.4:
                best_cut = pos
        if best_cut > 0:
            truncated = truncated[:best_cut + 1]

        truncated = truncated.rstrip() + "\n\n[... 内容已截断 / Content truncated ...]"
        return truncated

    @classmethod
    def truncate_messages(cls, messages: list, max_total_chars: int) -> list:
        if not messages:
            return messages
        total = sum(len(ActiveContextManager._get_content_text(m)) for m in messages)
        if total <= max_total_chars:
            return messages

        budget_per_msg = max_total_chars // max(1, len(messages))
        result = []
        for msg in messages:
            text = ActiveContextManager._get_content_text(msg)
            if len(text) <= budget_per_msg:
                result.append(msg)
            else:
                truncated_text = cls.truncate(text, budget_per_msg)
                if isinstance(msg, dict):
                    new_msg = dict(msg)
                    new_msg["content"] = truncated_text
                    result.append(new_msg)
                else:
                    try:
                        from xingzierai.agentscope_core.message import Msg, TextBlock
                        new_msg = Msg(
                            name=getattr(msg, 'name', ''),
                            role=getattr(msg, 'role', ''),
                            content=[TextBlock(type="text", text=truncated_text)],
                        )
                        result.append(new_msg)
                    except Exception:
                        result.append(msg)
        return result


class ContextHealthMonitor:
    """Continuous context health monitoring with alerting.

    Tracks context health metrics over time and generates alerts
    when health degrades, enabling proactive intervention.
    """

    MAX_HISTORY = 500
    ALERT_COOLDOWN = 60.0

    def __init__(self):
        self._history: deque = deque(maxlen=self.MAX_HISTORY)
        self._last_alert_time: float = 0.0
        self._alert_count: int = 0

    def record(self, health_score: float, message_count: int, token_estimate: int) -> None:
        self._history.append({
            "timestamp": time.time(),
            "health_score": health_score,
            "message_count": message_count,
            "token_estimate": token_estimate,
        })

    def should_alert(self, current_score: float) -> bool:
        if current_score > 0.6:
            return False
        now = time.time()
        if now - self._last_alert_time < self.ALERT_COOLDOWN:
            return False
        if len(self._history) < 3:
            return current_score < 0.4
        recent = list(self._history)[-5:]
        avg_recent = sum(h["health_score"] for h in recent) / len(recent)
        if current_score < avg_recent * 0.8:
            self._last_alert_time = now
            self._alert_count += 1
            return True
        return False

    def get_trend(self, window_seconds: float = 300) -> str:
        if len(self._history) < 3:
            return "stable"
        now = time.time()
        cutoff = now - window_seconds
        recent = [h for h in self._history if h["timestamp"] >= cutoff]
        if len(recent) < 3:
            return "stable"
        first_half = recent[:len(recent) // 2]
        second_half = recent[len(recent) // 2:]
        avg_first = sum(h["health_score"] for h in first_half) / len(first_half)
        avg_second = sum(h["health_score"] for h in second_half) / len(second_half)
        diff = avg_second - avg_first
        if diff > 0.1:
            return "improving"
        elif diff < -0.1:
            return "degrading"
        return "stable"

    def get_stats(self) -> dict:
        return {
            "sample_count": len(self._history),
            "alert_count": self._alert_count,
            "trend": self.get_trend(),
        }


class ContextWindowBudgetPlanner:
    """Dynamic context window budget planner.

    Allocates token budgets to different context layers based on
    the current conversation state and query complexity.
    """

    def __init__(self, max_context_tokens: int = 128000):
        self._max_context_tokens = max_context_tokens
        self._allocation_history: deque = deque(maxlen=100)

    def plan_budget(
        self,
        query_complexity: str = "moderate",
        current_message_count: int = 0,
        has_active_tools: bool = False,
    ) -> ContextBudget:
        total = self._max_context_tokens
        if query_complexity == "simple":
            budget = ContextBudget(
                system=min(2000, total // 20),
                task_state=min(500, total // 40),
                summary=min(2000, total // 10),
                history=min(4000, total // 5),
                recent=min(2000, total // 10),
                tools=min(1000, total // 20),
            )
        elif query_complexity == "complex":
            budget = ContextBudget(
                system=min(3000, total // 15),
                task_state=min(1500, total // 20),
                summary=min(5000, total // 6),
                history=min(15000, total // 2),
                recent=min(6000, total // 8),
                tools=min(3000, total // 10),
            )
        else:
            budget = ContextBudget(
                system=min(2500, total // 17),
                task_state=min(1000, total // 30),
                summary=min(3000, total // 8),
                history=min(8000, total // 4),
                recent=min(4000, total // 10),
                tools=min(2000, total // 15),
            )

        if has_active_tools:
            budget.tools = min(budget.tools + 1000, total // 10)
            budget.history = max(budget.history - 1000, total // 10)

        if current_message_count > 100:
            budget.summary = min(budget.summary + 2000, total // 5)
            budget.history = max(budget.history - 2000, total // 10)

        self._allocation_history.append({
            "timestamp": time.time(),
            "complexity": query_complexity,
            "message_count": current_message_count,
            "budget_total": budget.total,
        })

        return budget

    def get_stats(self) -> dict:
        return {
            "max_context_tokens": self._max_context_tokens,
            "allocations": len(self._allocation_history),
        }


class ContextRecoveryManager:
    """Manages context recovery after failures.

    When context is corrupted or lost, this manager provides
    multiple recovery strategies with increasing aggressiveness.
    """

    MAX_RECOVERY_ATTEMPTS = 3
    BACKUP_RETENTION_COUNT = 5

    def __init__(self, session_dir: Optional[str] = None):
        self._session_dir = Path(session_dir) if session_dir else None
        self._recovery_history: list[dict] = []

    async def attempt_recovery(
        self,
        agent: Any,
        strategy: str = "reload_session",
    ) -> bool:
        for attempt in range(self.MAX_RECOVERY_ATTEMPTS):
            try:
                if strategy == "reload_session" and self._session_dir:
                    success = await self._reload_from_session(agent)
                    if success:
                        self._record_recovery(strategy, attempt, True)
                        return True
                elif strategy == "rebuild_from_summary":
                    success = await self._rebuild_from_summary(agent)
                    if success:
                        self._record_recovery(strategy, attempt, True)
                        return True
                elif strategy == "fresh_start":
                    await self._fresh_start(agent)
                    self._record_recovery(strategy, attempt, True)
                    return True
            except Exception as e:
                logger.warning(
                    "[ContextRecovery] action=recovery_attempt strategy=%s attempt=%d error=%s",
                    strategy, attempt, e,
                )
            await asyncio.sleep(0.5 * (attempt + 1))

        self._record_recovery(strategy, self.MAX_RECOVERY_ATTEMPTS, False)
        return False

    async def _reload_from_session(self, agent: Any) -> bool:
        if not self._session_dir:
            return False
        session_file = self._session_dir / "session.json"
        if not session_file.exists():
            return False
        logger.info("[ContextRecovery] action=reload_session path=%s", session_file)
        return True

    async def _rebuild_from_summary(self, agent: Any) -> bool:
        if not hasattr(agent, 'memory'):
            return False
        summary = agent.memory.get_compressed_summary() if hasattr(agent.memory, 'get_compressed_summary') else ""
        if not summary:
            return False
        logger.info("[ContextRecovery] action=rebuild_from_summary summary_len=%d", len(summary))
        return True

    async def _fresh_start(self, agent: Any) -> None:
        if hasattr(agent, 'memory') and hasattr(agent.memory, 'clear'):
            await agent.memory.clear()
        logger.info("[ContextRecovery] action=fresh_start agent=%s", getattr(agent, 'name', 'unknown'))

    def _record_recovery(self, strategy: str, attempts: int, success: bool) -> None:
        self._recovery_history.append({
            "timestamp": time.time(),
            "strategy": strategy,
            "attempts": attempts,
            "success": success,
        })
        if len(self._recovery_history) > 100:
            self._recovery_history = self._recovery_history[-100:]

    def get_stats(self) -> dict:
        total = len(self._recovery_history)
        successes = sum(1 for r in self._recovery_history if r["success"])
        return {
            "total_recoveries": total,
            "success_rate": round(successes / max(1, total), 3),
            "recent_recoveries": self._recovery_history[-10:],
        }


ActiveContext = ActiveContextManager
ContextCompaction = ContextCompactionManager


class ProgressiveLoader:
    """Progressive context loading - only load context layers as needed.

    Reduces initial token usage for simple queries by loading context
    in layers: system prompt + last 3 messages first, then summary,
    then full history on demand.

    Layer loading order:
    1. CORE: system prompt + last 3 messages (always loaded)
    2. SUMMARY: compressed summary of older context
    3. HISTORY: full uncompressed history
    """

    CORE_RECENT_MESSAGES = 3

    def __init__(
        self,
        budget: Optional[ContextBudget] = None,
        token_counter: Optional[Any] = None,
    ) -> None:
        self.budget = budget or ContextBudget()
        self._token_counter = token_counter
        self._loaded_layers: set[ContextLayer] = set()
        self._core_messages: list[dict] = []
        self._summary_messages: list[dict] = []
        self._history_messages: list[dict] = []
        self._system_prompt: str = ""
        self._summary_text: Optional[str] = None
        self._full_history: list[Any] = []
        self._load_stats: dict[str, Any] = {
            "total_loads": 0,
            "core_only_hits": 0,
            "summary_hits": 0,
            "history_hits": 0,
            "tokens_saved_vs_full": 0,
        }

    def load_core(
        self,
        system_prompt: str,
        recent_messages: list[Any],
    ) -> list[dict]:
        """Load the core layer: system prompt + last N messages.

        This is the minimum context needed for any query.
        """
        self._system_prompt = system_prompt
        self._core_messages = [{"role": "system", "content": system_prompt}]

        recent = recent_messages[-self.CORE_RECENT_MESSAGES:]
        for msg in recent:
            if isinstance(msg, dict):
                self._core_messages.append(msg)
            else:
                role = getattr(msg, "role", "")
                content = getattr(msg, "content", "")
                if isinstance(content, list):
                    self._core_messages.append({"role": role, "content": content})
                else:
                    self._core_messages.append({"role": role, "content": str(content)})

        self._loaded_layers.add(ContextLayer.SYSTEM)
        self._loaded_layers.add(ContextLayer.RECENT)
        self._load_stats["total_loads"] += 1
        self._load_stats["core_only_hits"] += 1

        full_token_estimate = self._estimate_full_tokens(recent_messages)
        core_token_estimate = self._estimate_messages_tokens_sync(self._core_messages)
        self._load_stats["tokens_saved_vs_full"] += max(0, full_token_estimate - core_token_estimate)

        return list(self._core_messages)

    def load_layer(self, layer: ContextLayer) -> list[dict]:
        """Load an additional context layer.

        Args:
            layer: The context layer to load (SUMMARY or HISTORY).

        Returns:
            All currently loaded messages including the new layer.
        """
        if layer in self._loaded_layers:
            return self.get_loaded_messages()

        if layer == ContextLayer.SUMMARY and self._summary_text:
            summary_msg = {
                "role": "system",
                "content": f"[Summary of previous conversation]\n{self._summary_text}",
            }
            self._summary_messages = [summary_msg]
            self._loaded_layers.add(ContextLayer.SUMMARY)
            self._load_stats["summary_hits"] += 1

        elif layer == ContextLayer.HISTORY and self._full_history:
            history_msgs = []
            for msg in self._full_history:
                if isinstance(msg, dict):
                    history_msgs.append(msg)
                else:
                    role = getattr(msg, "role", "")
                    content = getattr(msg, "content", "")
                    if isinstance(content, list):
                        history_msgs.append({"role": role, "content": content})
                    else:
                        history_msgs.append({"role": role, "content": str(content)})
            self._history_messages = history_msgs
            self._loaded_layers.add(ContextLayer.HISTORY)
            self._load_stats["history_hits"] += 1

        return self.get_loaded_messages()

    def set_summary(self, summary_text: Optional[str]) -> None:
        self._summary_text = summary_text

    def set_history(self, history: list[Any]) -> None:
        self._full_history = list(history)

    def get_loaded_messages(self) -> list[dict]:
        """Get all currently loaded messages in correct order."""
        result = []
        result.extend(self._core_messages[:1])  # system prompt
        result.extend(self._summary_messages)
        result.extend(self._history_messages)
        result.extend(self._core_messages[1:])  # recent messages
        return result

    def needs_more_context(self, model_response: str) -> bool:
        """Determine if the model response suggests more context is needed.

        Detects patterns where the model indicates it lacks context.
        """
        if ContextLayer.HISTORY in self._loaded_layers:
            return False

        need_context_patterns = [
            "i don't have enough context",
            "i need more information",
            "i cannot see the previous",
            "based on what i can see",
            "from the limited context",
            "i don't have access to",
            "没有足够的上下文",
            "需要更多信息",
            "无法看到之前的",
            "根据可见的上下文",
        ]
        response_lower = model_response.lower()
        return any(p in response_lower for p in need_context_patterns)

    def get_next_layer(self) -> Optional[ContextLayer]:
        """Get the next layer that should be loaded."""
        if ContextLayer.SUMMARY not in self._loaded_layers and self._summary_text:
            return ContextLayer.SUMMARY
        if ContextLayer.HISTORY not in self._loaded_layers and self._full_history:
            return ContextLayer.HISTORY
        return None

    def get_load_stats(self) -> dict[str, Any]:
        return dict(self._load_stats)

    def estimate_query_complexity(self, query: str) -> str:
        """Estimate the complexity of a query to determine context needs.

        Args:
            query: The user's query text.

        Returns:
            "simple", "moderate", or "complex"
        """
        if not query:
            return "simple"

        query_lower = query.lower()
        complex_indicators = [
            "analyze", "compare", "explain", "research", "investigate",
            "分析", "比较", "解释", "研究", "调查",
            "multiple", "several", "all of", "each",
            "多个", "所有", "每个",
        ]
        moderate_indicators = [
            "how", "why", "what if", "describe",
            "如何", "为什么", "描述",
        ]

        complex_count = sum(1 for ind in complex_indicators if ind in query_lower)
        moderate_count = sum(1 for ind in moderate_indicators if ind in query_lower)

        if complex_count >= 2 or len(query) > 200:
            return "complex"
        elif complex_count >= 1 or moderate_count >= 2:
            return "moderate"
        return "simple"

    def select_layers_for_query(self, query: str) -> list[ContextLayer]:
        """Select which context layers to load based on query complexity.

        Args:
            query: The user's query text.

        Returns:
            List of ContextLayer values to load.
        """
        complexity = self.estimate_query_complexity(query)
        layers = [ContextLayer.SYSTEM, ContextLayer.RECENT]

        if complexity in ("moderate", "complex"):
            layers.append(ContextLayer.SUMMARY)

        if complexity == "complex":
            layers.append(ContextLayer.HISTORY)

        logger.info(
            "[ContextMgr] action=adaptive_layer_selection complexity=%s layers=%s",
            complexity, [l.value for l in layers],
        )
        return layers

    def reset(self) -> None:
        self._loaded_layers.clear()
        self._core_messages.clear()
        self._summary_messages.clear()
        self._history_messages.clear()
        self._system_prompt = ""
        self._summary_text = None
        self._full_history.clear()

    def _estimate_full_tokens(self, all_messages: list[Any]) -> int:
        total = len(self._system_prompt) // 4
        for msg in all_messages:
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = str(getattr(msg, "content", "") or "")
            if isinstance(content, list):
                for c in content:
                    if isinstance(c, str):
                        total += len(c) // 4
                    elif isinstance(c, dict):
                        total += len(c.get("text", "")) // 4
            else:
                total += len(str(content)) // 4
        return total

    def _estimate_messages_tokens_sync(self, messages: list[dict]) -> int:
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(content) // 4
            elif isinstance(content, list):
                for c in content:
                    if isinstance(c, str):
                        total += len(c) // 4
                    elif isinstance(c, dict):
                        total += len(c.get("text", "")) // 4
        return total


class _PoolSlot:
    __slots__ = ("layer", "budget", "used", "entries")

    def __init__(self, layer: ContextLayer, budget: int) -> None:
        self.layer = layer
        self.budget = budget
        self.used = 0
        self.entries: list[tuple[str, int]] = []

    def check_in(self, content: str, tokens: int) -> bool:
        if self.used + tokens > self.budget:
            while self.entries and self.used + tokens > self.budget:
                _, evicted_tokens = self.entries.pop(0)
                self.used -= evicted_tokens
            if self.used + tokens > self.budget:
                return False
        self.entries.append((content, tokens))
        self.used += tokens
        return True

    def check_out(self) -> str:
        if not self.entries:
            return ""
        content, tokens = self.entries.pop(0)
        self.used = max(0, self.used - tokens)
        return content


class ContextPool:
    """Pre-allocated memory pool for context window slots.

    Each context layer gets a fixed token budget.  Content is checked in
    to a slot; when the slot is full, older content is automatically
    evicted (FIFO).  This prevents any single type of content from
    monopolizing the context window.
    """

    MAX_ENTRIES_PER_SLOT = 200

    def __init__(self, budget: ContextBudget | None = None) -> None:
        self._budget = budget or ContextBudget()
        self._slots: dict[str, _PoolSlot] = {
            ContextLayer.SYSTEM.value: _PoolSlot(ContextLayer.SYSTEM, self._budget.system),
            ContextLayer.TASK_STATE.value: _PoolSlot(ContextLayer.TASK_STATE, self._budget.task_state),
            ContextLayer.RECENT.value: _PoolSlot(ContextLayer.RECENT, self._budget.recent),
            ContextLayer.SUMMARY.value: _PoolSlot(ContextLayer.SUMMARY, self._budget.summary),
            ContextLayer.HISTORY.value: _PoolSlot(ContextLayer.HISTORY, self._budget.history),
            ContextLayer.TOOLS.value: _PoolSlot(ContextLayer.TOOLS, self._budget.tools),
        }

    def check_in(self, layer: ContextLayer, content: str, tokens: int) -> bool:
        slot = self._slots.get(layer.value)
        if slot is None:
            return False
        result = slot.check_in(content, tokens)
        if len(slot.entries) > self.MAX_ENTRIES_PER_SLOT:
            slot.entries = slot.entries[-self.MAX_ENTRIES_PER_SLOT:]
        return result

    def check_out(self, layer: ContextLayer) -> str:
        slot = self._slots.get(layer.value)
        if slot is None:
            return ""
        return slot.check_out()

    def get_usage(self) -> dict[str, dict[str, int]]:
        result: dict[str, dict[str, int]] = {}
        for name, slot in self._slots.items():
            result[name] = {
                "budget": slot.budget,
                "used": slot.used,
                "entries": len(slot.entries),
                "available": slot.budget - slot.used,
            }
        return result

    def get_health(self) -> dict:
        total_budget = 0
        total_used = 0
        critical_layers: list[str] = []
        for name, slot in self._slots.items():
            total_budget += slot.budget
            total_used += slot.used
            if slot.budget > 0 and slot.used / slot.budget > 0.9:
                critical_layers.append(name)
        utilization = total_used / max(1, total_budget)
        if utilization > 0.9:
            status = "critical"
        elif utilization > 0.7:
            status = "warning"
        else:
            status = "healthy"
        return {
            "status": status,
            "utilization": round(utilization, 3),
            "total_budget": total_budget,
            "total_used": total_used,
            "critical_layers": critical_layers,
        }

    def reset(self) -> None:
        for slot in self._slots.values():
            slot.entries.clear()
            slot.used = 0

    def smart_evict(self, target_layer: ContextLayer, needed_tokens: int) -> int:
        """Evict entries from lower-priority layers to make room.

        Priority order (lowest first): HISTORY, SUMMARY, TASK_STATE, RECENT
        SYSTEM is never evicted.

        Args:
            target_layer: The layer that needs more space.
            needed_tokens: How many tokens are needed.

        Returns:
            Number of tokens freed.
        """
        if target_layer == ContextLayer.SYSTEM:
            return 0

        freed = 0
        eviction_order = [
            ContextLayer.HISTORY,
            ContextLayer.SUMMARY,
            ContextLayer.TASK_STATE,
        ]

        for layer in eviction_order:
            if layer == target_layer:
                continue
            slot = self._slots.get(layer.value)
            if slot is None:
                continue
            while slot.entries and freed < needed_tokens:
                content, tokens = slot.entries.pop(0)
                slot.used = max(0, slot.used - tokens)
                freed += tokens
                logger.info(
                    "[ContextMgr] action=smart_evict from=%s tokens=%d freed_total=%d needed=%d",
                    layer.value, tokens, freed, needed_tokens,
                )
            if freed >= needed_tokens:
                break

        return freed


class ConversationState(str, Enum):
    IDLE = "idle"
    WORKING = "working"
    WAITING_FOR_INPUT = "waiting_for_input"
    TOOL_EXECUTION = "tool_execution"
    COMPACTION = "compaction"
    ERROR = "error"


_VALID_TRANSITIONS: dict[ConversationState, set[ConversationState]] = {
    ConversationState.IDLE: {
        ConversationState.WORKING,
        ConversationState.WAITING_FOR_INPUT,
        ConversationState.ERROR,
    },
    ConversationState.WORKING: {
        ConversationState.TOOL_EXECUTION,
        ConversationState.COMPACTION,
        ConversationState.WAITING_FOR_INPUT,
        ConversationState.IDLE,
        ConversationState.ERROR,
    },
    ConversationState.WAITING_FOR_INPUT: {
        ConversationState.WORKING,
        ConversationState.IDLE,
        ConversationState.ERROR,
    },
    ConversationState.TOOL_EXECUTION: {
        ConversationState.WORKING,
        ConversationState.COMPACTION,
        ConversationState.WAITING_FOR_INPUT,
        ConversationState.IDLE,
        ConversationState.ERROR,
    },
    ConversationState.COMPACTION: {
        ConversationState.WORKING,
        ConversationState.IDLE,
        ConversationState.ERROR,
    },
    ConversationState.ERROR: {
        ConversationState.IDLE,
        ConversationState.WORKING,
    },
}

_NON_COMPACTABLE_STATES = frozenset({
    ConversationState.TOOL_EXECUTION,
    ConversationState.COMPACTION,
})


class ConversationStateMachine:
    """State machine for tracking conversation state.

    States: idle, working, waiting_for_input, tool_execution, compaction, error

    The state machine enforces valid transitions and uses the current
    state to inform compaction decisions. For example, compaction is
    not allowed during tool execution or during an ongoing compaction.

    Usage:
        sm = ConversationStateMachine()
        sm.transition(ConversationState.WORKING)
        sm.transition(ConversationState.TOOL_EXECUTION)
        assert not sm.can_compact()
        sm.transition(ConversationState.WORKING)
        assert sm.can_compact()
    """

    MAX_TRANSITION_HISTORY = 100

    def __init__(self) -> None:
        self._state = ConversationState.IDLE
        self._transition_history: list[tuple[float, ConversationState, ConversationState]] = []
        self._state_entered_at: float = time.time()
        self._total_time_by_state: dict[ConversationState, float] = {
            s: 0.0 for s in ConversationState
        }

    def current_state(self) -> ConversationState:
        return self._state

    def transition(self, new_state: ConversationState) -> bool:
        """Transition to a new state.

        Only valid transitions are allowed. Invalid transitions are
        logged and rejected.

        Args:
            new_state: The target state.

        Returns:
            True if the transition was successful, False otherwise.
        """
        if new_state == self._state:
            return True

        allowed = _VALID_TRANSITIONS.get(self._state, set())
        if new_state not in allowed:
            logger.warning(
                "[ContextMgr] action=invalid_state_transition from=%s to=%s allowed=%s",
                self._state.value, new_state.value, {s.value for s in allowed},
            )
            return False

        now = time.time()
        elapsed = now - self._state_entered_at
        self._total_time_by_state[self._state] = self._total_time_by_state.get(self._state, 0.0) + elapsed

        old_state = self._state
        self._transition_history.append((now, old_state, new_state))
        if len(self._transition_history) > self.MAX_TRANSITION_HISTORY:
            self._transition_history = self._transition_history[-self.MAX_TRANSITION_HISTORY:]

        self._state = new_state
        self._state_entered_at = now

        logger.info(
            "[ContextMgr] action=state_transition from=%s to=%s elapsed_in_old=%.1fs",
            old_state.value, new_state.value, elapsed,
        )
        return True

    def can_compact(self) -> bool:
        """Check if compaction is allowed in the current state.

        Compaction is not allowed during:
        - tool_execution: tool results may be incomplete
        - compaction: already compacting, prevent re-entrancy

        Returns:
            True if compaction is allowed, False otherwise.
        """
        return self._state not in _NON_COMPACTABLE_STATES

    def force_transition(self, new_state: ConversationState) -> None:
        """Force a state transition regardless of validity.

        Used for error recovery when the state machine needs to be
        reset to a known good state.

        Args:
            new_state: The target state.
        """
        now = time.time()
        elapsed = now - self._state_entered_at
        self._total_time_by_state[self._state] = self._total_time_by_state.get(self._state, 0.0) + elapsed

        old_state = self._state
        self._transition_history.append((now, old_state, new_state))
        if len(self._transition_history) > self.MAX_TRANSITION_HISTORY:
            self._transition_history = self._transition_history[-self.MAX_TRANSITION_HISTORY:]

        self._state = new_state
        self._state_entered_at = now

        logger.info(
            "[ContextMgr] action=force_state_transition from=%s to=%s",
            old_state.value, new_state.value,
        )

    def get_state_duration(self) -> float:
        """Get how long we've been in the current state (seconds)."""
        return time.time() - self._state_entered_at

    def get_transition_history(self, limit: int = 20) -> list[dict]:
        """Get recent transition history.

        Args:
            limit: Maximum number of transitions to return.

        Returns:
            List of transition dicts with timestamp, from, to keys.
        """
        recent = self._transition_history[-limit:]
        return [
            {
                "timestamp": ts,
                "from": old.value,
                "to": new.value,
            }
            for ts, old, new in recent
        ]

    def get_state_stats(self) -> dict:
        """Get statistics about time spent in each state.

        Returns:
            Dict mapping state name to total seconds spent.
        """
        current_elapsed = time.time() - self._state_entered_at
        stats = {}
        for state in ConversationState:
            total = self._total_time_by_state.get(state, 0.0)
            if state == self._state:
                total += current_elapsed
            stats[state.value] = round(total, 1)
        stats["current_state"] = self._state.value
        stats["current_duration"] = round(current_elapsed, 1)
        stats["can_compact"] = self.can_compact()
        stats["total_transitions"] = len(self._transition_history)
        return stats

    def is_stuck(self, threshold_seconds: float = 300.0) -> bool:
        """Detect if the state machine appears stuck in a non-idle state.

        Args:
            threshold_seconds: How long in a non-idle state before
                considering it stuck.

        Returns:
            True if the current state has been active for longer than
            the threshold and is not IDLE.
        """
        if self._state == ConversationState.IDLE:
            return False
        duration = time.time() - self._state_entered_at
        if duration > threshold_seconds:
            logger.warning(
                "[ContextMgr] action=stuck_detected state=%s duration=%.1fs threshold=%.1fs",
                self._state.value, duration, threshold_seconds,
            )
            return True
        return False

    def get_transition_rate(self, window_seconds: float = 60.0) -> float:
        """Calculate the transition rate over a recent time window.

        Args:
            window_seconds: Time window to consider.

        Returns:
            Transitions per second in the window.
        """
        if not self._transition_history:
            return 0.0
        now = time.time()
        cutoff = now - window_seconds
        recent = [t for t, _, _ in self._transition_history if t >= cutoff]
        if not recent:
            return 0.0
        return len(recent) / window_seconds

    def reset(self) -> None:
        self._state = ConversationState.IDLE
        self._state_entered_at = time.time()
        self._transition_history.clear()
        self._total_time_by_state = {s: 0.0 for s in ConversationState}


class ErrorRecoveryStrategy(str, Enum):
    RETRY = "retry"
    COMPACT = "compact"
    TRIM = "trim"
    FALLBACK_MODEL = "fallback_model"
    GRACEFUL_DEGRADE = "graceful_degrade"


class ContextAwareErrorRecovery:
    """Context-aware error recovery with different strategies for different error types.

    Maps error types to appropriate recovery strategies based on:
    - Error severity (transient vs permanent)
    - Context state (healthy vs critical)
    - Recovery history (avoid repeating failed strategies)
    """

    MAX_RECOVERY_HISTORY = 100
    MAX_STRATEGY_ATTEMPTS = 3
    _instance: "ContextAwareErrorRecovery | None" = None

    def __init__(self) -> None:
        self._recovery_history: list[dict] = []
        self._strategy_failure_counts: dict[str, int] = {}

    @classmethod
    def get_instance(cls) -> "ContextAwareErrorRecovery":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def classify_error(self, error: Exception) -> str:
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        if 'timeout' in error_str or 'timedout' in error_type:
            return "timeout"
        if 'context' in error_str and ('exceed' in error_str or 'too long' in error_str or 'too many token' in error_str):
            return "context_overflow"
        if 'rate' in error_str and 'limit' in error_str:
            return "rate_limit"
        if '401' in error_str or 'unauthorized' in error_str or 'auth' in error_type:
            return "auth_error"
        if 'network' in error_str or 'connection' in error_str or 'connecterror' in error_type:
            return "network_error"
        if '400' in error_str or 'bad_request' in error_str:
            return "bad_request"
        if '500' in error_str or 'internal' in error_str or 'server_error' in error_str:
            return "server_error"
        return "unknown"

    def get_strategy(self, error_type: str, context_health: str = "healthy") -> ErrorRecoveryStrategy:
        strategy_map: dict[str, list[ErrorRecoveryStrategy]] = {
            "timeout": [ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.FALLBACK_MODEL],
            "context_overflow": [ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],
            "rate_limit": [ErrorRecoveryStrategy.FALLBACK_MODEL, ErrorRecoveryStrategy.RETRY],
            "auth_error": [ErrorRecoveryStrategy.FALLBACK_MODEL, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],
            "network_error": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.FALLBACK_MODEL],
            "bad_request": [ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.COMPACT],
            "server_error": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.FALLBACK_MODEL],
            "unknown": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],
        }

        if context_health == "critical":
            if error_type not in ("context_overflow", "bad_request"):
                return ErrorRecoveryStrategy.GRACEFUL_DEGRADE

        strategies = strategy_map.get(error_type, strategy_map["unknown"])
        for strategy in strategies:
            key = f"{error_type}:{strategy.value}"
            if self._strategy_failure_counts.get(key, 0) < self.MAX_STRATEGY_ATTEMPTS:
                return strategy

        return ErrorRecoveryStrategy.GRACEFUL_DEGRADE

    def record_recovery(self, error_type: str, strategy: ErrorRecoveryStrategy, success: bool) -> None:
        self._recovery_history.append({
            "timestamp": time.time(),
            "error_type": error_type,
            "strategy": strategy.value,
            "success": success,
        })
        if len(self._recovery_history) > self.MAX_RECOVERY_HISTORY:
            self._recovery_history = self._recovery_history[-self.MAX_RECOVERY_HISTORY:]

        key = f"{error_type}:{strategy.value}"
        if not success:
            self._strategy_failure_counts[key] = self._strategy_failure_counts.get(key, 0) + 1
        else:
            self._strategy_failure_counts.pop(key, None)

    def get_recovery_stats(self) -> dict:
        total = len(self._recovery_history)
        if total == 0:
            return {"total_recoveries": 0, "success_rate": 0.0, "strategy_distribution": {}}
        successes = sum(1 for r in self._recovery_history if r["success"])
        distribution: dict[str, int] = {}
        for r in self._recovery_history:
            s = r["strategy"]
            distribution[s] = distribution.get(s, 0) + 1
        return {
            "total_recoveries": total,
            "success_rate": round(successes / total, 3),
            "strategy_distribution": distribution,
            "failed_strategies": dict(self._strategy_failure_counts),
        }


class AdaptiveCompactionStrategy(str, Enum):
    CONSERVATIVE = "conservative"
    BALANCED = "balanced"
    AGGRESSIVE = "aggressive"
    EMERGENCY = "emergency"


class AdaptiveCompactionController:
    """Adaptive compaction controller that selects strategy based on context pressure.

    Monitors context pressure and selects the appropriate compaction strategy:
    - CONSERVATIVE: Low pressure (< 0.6), preserve more context
    - BALANCED: Medium pressure (0.6-0.8), standard compaction
    - AGGRESSIVE: High pressure (0.8-0.9), aggressive compaction
    - EMERGENCY: Critical pressure (> 0.9), emergency trimming

    The controller also tracks strategy effectiveness to improve future decisions.
    """

    MAX_HISTORY = 200
    PRESSURE_WINDOW_SECONDS = 300

    def __init__(self):
        self._strategy_history: list[dict] = []
        self._pressure_samples: list[tuple[float, float]] = []
        self._strategy_effectiveness: dict[str, list[float]] = {
            s.value: [] for s in AdaptiveCompactionStrategy
        }

    def select_strategy(self, pressure: float, message_count: int = 0) -> AdaptiveCompactionStrategy:
        if pressure > 0.9:
            strategy = AdaptiveCompactionStrategy.EMERGENCY
        elif pressure > 0.8:
            strategy = AdaptiveCompactionStrategy.AGGRESSIVE
        elif pressure > 0.6:
            strategy = AdaptiveCompactionStrategy.BALANCED
        else:
            strategy = AdaptiveCompactionStrategy.CONSERVATIVE

        self._pressure_samples.append((time.time(), pressure))
        if len(self._pressure_samples) > self.MAX_HISTORY:
            self._pressure_samples = self._pressure_samples[-self.MAX_HISTORY:]

        if message_count > 150 and strategy == AdaptiveCompactionStrategy.CONSERVATIVE:
            strategy = AdaptiveCompactionStrategy.BALANCED

        if self._is_pressure_escalating():
            if strategy == AdaptiveCompactionStrategy.CONSERVATIVE:
                strategy = AdaptiveCompactionStrategy.BALANCED
            elif strategy == AdaptiveCompactionStrategy.BALANCED:
                strategy = AdaptiveCompactionStrategy.AGGRESSIVE

        logger.info(
            "[AdaptiveCompaction] action=strategy_selected pressure=%.3f strategy=%s msg_count=%d",
            pressure, strategy.value, message_count,
        )
        return strategy

    def _is_pressure_escalating(self) -> bool:
        if len(self._pressure_samples) < 3:
            return False
        now = time.time()
        recent = [(ts, p) for ts, p in self._pressure_samples
                  if now - ts < self.PRESSURE_WINDOW_SECONDS]
        if len(recent) < 3:
            return False
        first_third = recent[:len(recent) // 3]
        last_third = recent[-(len(recent) // 3):]
        avg_early = sum(p for _, p in first_third) / len(first_third)
        avg_late = sum(p for _, p in last_third) / len(last_third)
        return avg_late > avg_early * 1.15

    def record_outcome(
        self,
        strategy: AdaptiveCompactionStrategy,
        pressure_before: float,
        pressure_after: float,
        messages_removed: int,
    ) -> None:
        effectiveness = 0.0
        if pressure_before > 0:
            effectiveness = (pressure_before - pressure_after) / pressure_before
        self._strategy_effectiveness[strategy.value].append(effectiveness)
        if len(self._strategy_effectiveness[strategy.value]) > 50:
            self._strategy_effectiveness[strategy.value] = \
                self._strategy_effectiveness[strategy.value][-50:]
        self._strategy_history.append({
            "timestamp": time.time(),
            "strategy": strategy.value,
            "pressure_before": round(pressure_before, 3),
            "pressure_after": round(pressure_after, 3),
            "messages_removed": messages_removed,
            "effectiveness": round(effectiveness, 3),
        })
        if len(self._strategy_history) > self.MAX_HISTORY:
            self._strategy_history = self._strategy_history[-self.MAX_HISTORY:]

    def get_strategy_params(self, strategy: AdaptiveCompactionStrategy) -> dict:
        params_map = {
            AdaptiveCompactionStrategy.CONSERVATIVE: {
                "keep_recent": 12,
                "density": "full",
                "max_compact_ratio": 0.3,
                "preserve_anchors": True,
            },
            AdaptiveCompactionStrategy.BALANCED: {
                "keep_recent": 8,
                "density": "medium",
                "max_compact_ratio": 0.5,
                "preserve_anchors": True,
            },
            AdaptiveCompactionStrategy.AGGRESSIVE: {
                "keep_recent": 5,
                "density": "light",
                "max_compact_ratio": 0.7,
                "preserve_anchors": True,
            },
            AdaptiveCompactionStrategy.EMERGENCY: {
                "keep_recent": 3,
                "density": "light",
                "max_compact_ratio": 0.9,
                "preserve_anchors": True,
            },
        }
        return params_map.get(strategy, params_map[AdaptiveCompactionStrategy.BALANCED])

    def get_stats(self) -> dict:
        avg_effectiveness = {}
        for strategy_name, scores in self._strategy_effectiveness.items():
            if scores:
                avg_effectiveness[strategy_name] = round(sum(scores) / len(scores), 3)
            else:
                avg_effectiveness[strategy_name] = 0.0
        return {
            "total_decisions": len(self._strategy_history),
            "avg_effectiveness_by_strategy": avg_effectiveness,
            "pressure_samples": len(self._pressure_samples),
            "is_escalating": self._is_pressure_escalating(),
        }


class ContextPressureMonitor:
    """Monitors context pressure over time and generates alerts.

    Tracks pressure trends and provides early warning when context
    is approaching critical levels, enabling proactive compaction
    before emergency trimming is needed.
    """

    MAX_SAMPLES = 500
    ALERT_COOLDOWN_SECONDS = 60

    def __init__(self):
        self._samples: deque = deque(maxlen=self.MAX_SAMPLES)
        self._last_alert_time: float = 0.0
        self._alert_count: int = 0

    def record(self, pressure: float, message_count: int, estimated_tokens: int) -> None:
        self._samples.append({
            "timestamp": time.time(),
            "pressure": pressure,
            "message_count": message_count,
            "estimated_tokens": estimated_tokens,
        })

    def should_alert(self, current_pressure: float) -> bool:
        now = time.time()
        if now - self._last_alert_time < self.ALERT_COOLDOWN_SECONDS:
            return False
        if current_pressure < 0.7:
            return False
        if len(self._samples) < 5:
            return current_pressure > 0.8
        recent = list(self._samples)[-10:]
        avg_recent = sum(s["pressure"] for s in recent) / len(recent)
        if current_pressure > avg_recent * 1.1 and current_pressure > 0.75:
            self._last_alert_time = now
            self._alert_count += 1
            return True
        return False

    def get_trend(self, window_seconds: float = 300) -> str:
        if len(self._samples) < 3:
            return "stable"
        now = time.time()
        cutoff = now - window_seconds
        recent = [s for s in self._samples if s["timestamp"] >= cutoff]
        if len(recent) < 3:
            return "stable"
        first_half = recent[:len(recent) // 2]
        second_half = recent[len(recent) // 2:]
        avg_first = sum(s["pressure"] for s in first_half) / len(first_half)
        avg_second = sum(s["pressure"] for s in second_half) / len(second_half)
        diff = avg_second - avg_first
        if diff > 0.1:
            return "rising"
        elif diff < -0.1:
            return "falling"
        return "stable"

    def predict_time_to_critical(self, threshold: float = 0.9) -> Optional[float]:
        if len(self._samples) < 10:
            return None
        recent = list(self._samples)[-20:]
        if len(recent) < 5:
            return None
        pressures = [s["pressure"] for s in recent]
        timestamps = [s["timestamp"] for s in recent]
        if len(pressures) < 5:
            return None
        time_span = timestamps[-1] - timestamps[0]
        if time_span < 1:
            return None
        pressure_change = pressures[-1] - pressures[0]
        rate = pressure_change / time_span
        if rate <= 0:
            return None
        current = pressures[-1]
        if current >= threshold:
            return 0.0
        remaining = threshold - current
        return remaining / rate

    def get_stats(self) -> dict:
        return {
            "sample_count": len(self._samples),
            "alert_count": self._alert_count,
            "trend": self.get_trend(),
            "time_to_critical": self.predict_time_to_critical(),
        }


class ProgressiveCompactionManager:
    """Multi-pass progressive compaction with quality validation.

    Instead of a single compaction pass, this manager applies compaction
    in progressive rounds, validating quality after each round:

    1. First pass: Context-Folding (collapse completed tool trajectories)
    2. Second pass: Density-gradient compression (full→medium→light)
    3. Third pass: Emergency trimming (if still over budget)

    Each pass validates that anchor preservation remains above threshold.
    """

    MIN_ANCHOR_PRESERVATION = 0.5
    MAX_PASSES = 3

    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):
        self._ctx_manager = ctx_manager or ActiveContextManager()
        self._pass_stats: list[dict] = []

    async def compact_progressive(
        self,
        messages: list,
        pressure: float,
        max_context_tokens: int = 128000,
    ) -> tuple[list, dict]:
        controller = AdaptiveCompactionController()
        strategy = controller.select_strategy(pressure, len(messages))
        params = controller.get_strategy_params(strategy)

        result_messages = list(messages)
        pass_results = []
        total_removed = 0

        for pass_num in range(1, self.MAX_PASSES + 1):
            if pass_num == 1:
                result_messages = self._ctx_manager.fold_completed_trajectories(
                    result_messages,
                    keep_recent=params["keep_recent"],
                )
                pass_result = {"pass": 1, "action": "context_folding", "messages_after": len(result_messages)}
            elif pass_num == 2:
                result_messages = await self._ctx_manager.compress_tool_results(
                    result_messages,
                    recent_threshold=params["keep_recent"],
                    old_threshold=200 if params["density"] == "light" else 500,
                )
                pass_result = {"pass": 2, "action": "tool_result_compression", "messages_after": len(result_messages)}
            else:
                token_counts = self._ctx_manager.estimate_messages_tokens(result_messages)
                total_tokens = sum(token_counts)
                if total_tokens > max_context_tokens * 0.85:
                    result_messages = self._ctx_manager.trim_by_priority(
                        result_messages,
                        "",
                        int(max_context_tokens * 0.7),
                        token_counts,
                    )
                    pass_result = {"pass": 3, "action": "priority_trimming", "messages_after": len(result_messages)}
                else:
                    pass_result = {"pass": 3, "action": "skipped", "reason": "within_budget"}

            removed = len(messages) - len(result_messages)
            total_removed += removed
            pass_results.append(pass_result)

            is_coherent, issues = self._ctx_manager.check_coherence(result_messages)
            if not is_coherent and issues:
                critical_issues = [i for i in issues if "in-progress" not in i]
                if critical_issues:
                    logger.warning(
                        "[ProgressiveCompaction] action=coherence_issue pass=%d issues=%d",
                        pass_num, len(critical_issues),
                    )

        summary = {
            "strategy": strategy.value,
            "passes": pass_results,
            "total_removed": total_removed,
            "original_count": len(messages),
            "final_count": len(result_messages),
        }
        self._pass_stats.append(summary)
        if len(self._pass_stats) > 100:
            self._pass_stats = self._pass_stats[-100:]

        return result_messages, summary

    def get_stats(self) -> dict:
        if not self._pass_stats:
            return {"total_compactions": 0}
        return {
            "total_compactions": len(self._pass_stats),
            "avg_reduction": round(
                sum(s.get("total_removed", 0) for s in self._pass_stats) / len(self._pass_stats), 1
            ),
            "strategy_distribution": {
                s: sum(1 for p in self._pass_stats if p.get("strategy") == s)
                for s in set(p.get("strategy", "") for p in self._pass_stats)
            },
        }


class ContextPreWarmer:
    """Pre-warm context by loading relevant memories before reasoning.

    Reduces cold-start latency by proactively fetching context
    that is likely to be needed based on the current query.
    """

    MAX_CACHED_QUERIES = 50
    CACHE_TTL_SECONDS = 300.0

    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):
        self._ctx_manager = ctx_manager or ActiveContextManager()
        self._query_cache: dict[str, tuple[float, list[RetrievalResult]]] = {}

    async def prewarm(
        self,
        query: str,
        history: list,
        max_results: int = 3,
    ) -> list[RetrievalResult]:
        now = time.time()
        cached = self._query_cache.get(query)
        if cached is not None:
            ts, results = cached
            if now - ts < self.CACHE_TTL_SECONDS:
                return results[:max_results]

        results = await self._ctx_manager._proactive_retrieve(query, history)
        self._query_cache[query] = (now, results)
        if len(self._query_cache) > self.MAX_CACHED_QUERIES:
            oldest_key = min(self._query_cache, key=lambda k: self._query_cache[k][0])
            del self._query_cache[oldest_key]

        return results[:max_results]

    def invalidate(self, query: Optional[str] = None) -> None:
        if query:
            self._query_cache.pop(query, None)
        else:
            self._query_cache.clear()

    def get_stats(self) -> dict:
        now = time.time()
        active = sum(
            1 for _, (ts, _) in self._query_cache.items()
            if now - ts < self.CACHE_TTL_SECONDS
        )
        return {
            "cached_queries": len(self._query_cache),
            "active_entries": active,
            "max_cache_size": self.MAX_CACHED_QUERIES,
            "cache_ttl_seconds": self.CACHE_TTL_SECONDS,
        }


class TokenEstimationCache:
    """LRU cache for token estimation to avoid repeated computation.

    Caches token counts for message content hashes, reducing
    CPU overhead for repeated token estimation calls.
    """

    MAX_CACHE_SIZE = 500
    _instance: "TokenEstimationCache | None" = None

    def __init__(self):
        self._cache: dict[str, tuple[int, float]] = {}
        self._hits = 0
        self._misses = 0

    @classmethod
    def get_instance(cls) -> "TokenEstimationCache":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _content_hash(self, content: str) -> str:
        if len(content) <= 64:
            return content
        import hashlib
        return hashlib.md5(content.encode("utf-8", errors="surrogatepass")).hexdigest()

    def get_or_compute(self, content: str, estimator: Callable[[str], int]) -> int:
        key = self._content_hash(content)
        now = time.time()
        cached = self._cache.get(key)
        if cached is not None:
            tokens, ts = cached
            if now - ts < 600:
                self._hits += 1
                return tokens

        self._misses += 1
        tokens = estimator(content)
        self._cache[key] = (tokens, now)
        if len(self._cache) > self.MAX_CACHE_SIZE:
            oldest_key = min(self._cache, key=lambda k: self._cache[k][1])
            del self._cache[oldest_key]
        return tokens

    def invalidate(self) -> None:
        self._cache.clear()

    def batch_compute(
        self,
        contents: list[str],
        estimator: Callable[[str], int],
    ) -> list[int]:
        results = []
        for content in contents:
            results.append(self.get_or_compute(content, estimator))
        return results

    def get_stats(self) -> dict:
        total = self._hits + self._misses
        hit_rate = round(self._hits / max(1, total), 3)
        return {
            "cache_size": len(self._cache),
            "max_size": self.MAX_CACHE_SIZE,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
        }


class ContextWindowGuard:
    """Guard that prevents context window overflow before LLM calls.

    Provides a final safety check before sending context to the model,
    ensuring the total token count stays within the configured limit.
    """

    SAFETY_MARGIN = 0.05

    def __init__(self, max_context_tokens: int = 128000):
        self._max_context_tokens = max_context_tokens
        self._guard_checks = 0
        self._guard_triggers = 0

    def check_and_trim(
        self,
        messages: list,
        token_counts: list[int],
        budget: Optional[ContextBudget] = None,
    ) -> tuple[list, list[int], bool]:
        self._guard_checks += 1
        if not messages or not token_counts or len(messages) != len(token_counts):
            return messages, token_counts, False

        total = sum(token_counts)
        limit = int(self._max_context_tokens * (1 - self.SAFETY_MARGIN))

        if total <= limit:
            return messages, token_counts, False

        self._guard_triggers += 1
        ctx_mgr = ActiveContextManager()
        if budget is None:
            budget = ContextBudget()

        trimmed = budget.enforce_budget(messages, token_counts)
        new_counts = [
            ActiveContextManager.estimate_tokens(
                ActiveContextManager._get_content_text(m)
            )
            for m in trimmed
        ]

        logger.info(
            "[ContextWindowGuard] action=trim_triggered original=%d trimmed=%d total_tokens=%d limit=%d",
            len(messages), len(trimmed), total, limit,
        )
        return trimmed, new_counts, True

    def get_stats(self) -> dict:
        return {
            "max_context_tokens": self._max_context_tokens,
            "safety_margin": self.SAFETY_MARGIN,
            "guard_checks": self._guard_checks,
            "guard_triggers": self._guard_triggers,
            "trigger_rate": round(
                self._guard_triggers / max(1, self._guard_checks), 3
            ),
        }


class ContextSnapshotManager:
    """Captures and stores context state snapshots for debugging.

    When context issues occur (overflow, compression failure, etc.),
    this manager captures a snapshot of the current context state
    for post-mortem analysis.
    """

    MAX_SNAPSHOTS = 20
    MAX_SNAPSHOT_SIZE = 50000

    def __init__(self):
        self._snapshots: list[dict] = []

    def capture(
        self,
        trigger: str,
        message_count: int = 0,
        estimated_tokens: int = 0,
        pressure: float = 0.0,
        state: str = "unknown",
        extra: dict | None = None,
    ) -> None:
        snapshot = {
            "timestamp": time.time(),
            "trigger": trigger,
            "message_count": message_count,
            "estimated_tokens": estimated_tokens,
            "pressure": round(pressure, 3),
            "state": state,
        }
        if extra:
            snapshot["extra"] = {k: str(v)[:200] for k, v in extra.items()}
        self._snapshots.append(snapshot)
        if len(self._snapshots) > self.MAX_SNAPSHOTS:
            self._snapshots = self._snapshots[-self.MAX_SNAPSHOTS:]

    def get_recent(self, limit: int = 10) -> list[dict]:
        return self._snapshots[-limit:]

    def get_stats(self) -> dict:
        if not self._snapshots:
            return {"total_snapshots": 0, "triggers": {}}
        triggers: dict[str, int] = {}
        for s in self._snapshots:
            t = s.get("trigger", "unknown")
            triggers[t] = triggers.get(t, 0) + 1
        return {
            "total_snapshots": len(self._snapshots),
            "triggers": triggers,
            "last_snapshot": self._snapshots[-1] if self._snapshots else None,
        }


class ContextBudgetManager:
    """Manages context token budget allocation across subsystems.

    Tracks how the context window budget is allocated and consumed:
    - System prompt tokens
    - Conversation history tokens
    - Tool call/result tokens
    - Reserved tokens for response generation
    - Safety margin

    Provides budget planning to prevent context overflow before it happens.
    """

    MAX_BUDGET_HISTORY = 200

    def __init__(self, max_context_tokens: int = 128 * 1024):
        self._max_context_tokens = max_context_tokens
        self._safety_margin = 0.1
        self._response_reserve = 0.15
        self._budget_history: list[dict] = []
        self._allocation = {
            "system_prompt": 0,
            "conversation_history": 0,
            "tool_calls": 0,
            "tool_results": 0,
            "compressed_summary": 0,
            "reserved_response": int(max_context_tokens * self._response_reserve),
            "safety_margin": int(max_context_tokens * self._safety_margin),
        }

    def update_allocation(self, **kwargs: int) -> None:
        for key, value in kwargs.items():
            if key in self._allocation:
                self._allocation[key] = value
        self._budget_history.append({
            "timestamp": time.time(),
            "allocation": dict(self._allocation),
            "total_consumed": self._get_consumed(),
            "remaining": self._get_remaining(),
        })
        if len(self._budget_history) > self.MAX_BUDGET_HISTORY:
            self._budget_history = self._budget_history[-self.MAX_BUDGET_HISTORY:]

    def _get_consumed(self) -> int:
        skip_keys = {"reserved_response", "safety_margin"}
        return sum(v for k, v in self._allocation.items() if k not in skip_keys)

    def _get_remaining(self) -> int:
        consumed = self._get_consumed()
        reserved = self._allocation["reserved_response"] + self._allocation["safety_margin"]
        return max(0, self._max_context_tokens - consumed - reserved)

    def get_budget_report(self) -> dict:
        consumed = self._get_consumed()
        remaining = self._get_remaining()
        total_available = self._max_context_tokens
        utilization = consumed / max(1, total_available)
        return {
            "max_context_tokens": self._max_context_tokens,
            "consumed_tokens": consumed,
            "remaining_tokens": remaining,
            "reserved_response": self._allocation["reserved_response"],
            "safety_margin": self._allocation["safety_margin"],
            "utilization": round(utilization, 3),
            "allocation": dict(self._allocation),
            "budget_status": (
                "critical" if utilization > 0.9
                else "warning" if utilization > 0.75
                else "healthy"
            ),
        }

    def can_fit(self, estimated_tokens: int) -> bool:
        return estimated_tokens <= self._get_remaining()

    def get_stats(self) -> dict:
        return {
            "budget_reports": len(self._budget_history),
            "current_budget": self.get_budget_report(),
        }


class ContextHealthAPI:
    """Unified API for context health diagnostics and monitoring.

    Aggregates data from all context subsystems:
    - ActiveContextManager health reports
    - ContextPressureMonitor trends
    - ContextHealthMonitor alerts
    - TokenEstimationCache stats
    - ContextWindowGuard stats
    - AdaptiveCompactionController stats
    - ConversationStateMachine state
    """

    _instance: "ContextHealthAPI | None" = None

    def __init__(self):
        self._ctx_manager = ActiveContextManager()
        self._pressure_monitor = ContextPressureMonitor()
        self._health_monitor = ContextHealthMonitor()
        self._token_cache = TokenEstimationCache.get_instance()
        self._window_guard = ContextWindowGuard()
        self._compaction_controller = AdaptiveCompactionController()
        self._state_machine = ConversationStateMachine()
        self._error_recovery = ContextAwareErrorRecovery.get_instance()
        self._circuit_breaker = ContextCircuitBreaker()
        self._rate_limiter = ContextOperationRateLimiter()
        self._metrics_aggregator = ContextMetricsAggregator()
        self._budget_manager = ContextBudgetManager()
        self._snapshot_manager = ContextSnapshotManager()
        self._last_full_report_time: float = 0.0
        self._report_count: int = 0

    @classmethod
    def get_instance(cls) -> "ContextHealthAPI":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get_full_report(self, messages: list = None) -> dict:
        self._report_count += 1
        self._last_full_report_time = time.time()

        report = {
            "timestamp": time.time(),
            "report_count": self._report_count,
            "state_machine": self._state_machine.get_state_stats(),
            "pressure": self._pressure_monitor.get_stats(),
            "health_monitor": self._health_monitor.get_stats(),
            "token_cache": self._token_cache.get_stats(),
            "window_guard": self._window_guard.get_stats(),
            "compaction": self._compaction_controller.get_stats(),
            "error_recovery": self._error_recovery.get_recovery_stats(),
            "circuit_breaker": self._circuit_breaker.get_stats(),
            "rate_limiter": self._rate_limiter.get_stats(),
            "metrics": self._metrics_aggregator.get_stats(),
            "budget": self._budget_manager.get_budget_report(),
            "snapshots": self._snapshot_manager.get_stats(),
        }

        if messages is not None:
            health = self._ctx_manager.diagnose_health(messages)
            report["context_health"] = health.to_dict()
            token_counts = self._ctx_manager.estimate_messages_tokens(messages)
            report["token_accounting"] = self._ctx_manager.token_accounting(messages, token_counts)

        return report

    def get_summary(self) -> dict:
        return {
            "state": self._state_machine.current_state().value,
            "can_compact": self._state_machine.can_compact(),
            "pressure_trend": self._pressure_monitor.get_trend(),
            "time_to_critical": self._pressure_monitor.predict_time_to_critical(),
            "token_cache_hit_rate": self._token_cache.get_stats().get("hit_rate", 0.0),
            "guard_trigger_rate": self._window_guard.get_stats().get("trigger_rate", 0.0),
            "circuit_breaker_state": self._circuit_breaker.get_state(),
            "budget_status": self._budget_manager.get_budget_report().get("budget_status", "unknown"),
            "snapshot_count": len(self._snapshot_manager._snapshots),
            "report_count": self._report_count,
        }

    def record_pressure(self, pressure: float, message_count: int, estimated_tokens: int) -> None:
        self._pressure_monitor.record(pressure, message_count, estimated_tokens)
        self._health_monitor.record(pressure, message_count, estimated_tokens)

    def transition_state(self, new_state: ConversationState) -> bool:
        return self._state_machine.transition(new_state)

    def get_subsystem(self, name: str) -> Any:
        subsystems = {
            "pressure_monitor": self._pressure_monitor,
            "health_monitor": self._health_monitor,
            "token_cache": self._token_cache,
            "window_guard": self._window_guard,
            "compaction_controller": self._compaction_controller,
            "state_machine": self._state_machine,
            "error_recovery": self._error_recovery,
            "circuit_breaker": self._circuit_breaker,
            "rate_limiter": self._rate_limiter,
            "metrics_aggregator": self._metrics_aggregator,
            "budget_manager": self._budget_manager,
            "snapshot_manager": self._snapshot_manager,
        }
        return subsystems.get(name)


class ContextUtilizationPredictor:
    """Predict context utilization trend for proactive intervention.

    Uses linear regression on recent pressure samples to predict
    when the context will reach critical levels, enabling early
    compaction before emergency trimming is needed.
    """

    MAX_SAMPLES = 100
    PREDICTION_HORIZON_SECONDS = 300

    def __init__(self):
        self._samples: deque = deque(maxlen=self.MAX_SAMPLES)
        self._predictions: list[dict] = []

    def record(self, pressure: float, message_count: int, estimated_tokens: int) -> None:
        self._samples.append({
            "timestamp": time.time(),
            "pressure": pressure,
            "message_count": message_count,
            "estimated_tokens": estimated_tokens,
        })

    def predict_pressure_at(self, target_seconds: float) -> Optional[float]:
        if len(self._samples) < 5:
            return None
        now = time.time()
        recent = [s for s in self._samples if now - s["timestamp"] < self.PREDICTION_HORIZON_SECONDS]
        if len(recent) < 5:
            return None
        timestamps = [s["timestamp"] - recent[0]["timestamp"] for s in recent]
        pressures = [s["pressure"] for s in recent]
        n = len(recent)
        sum_x = sum(timestamps)
        sum_y = sum(pressures)
        sum_xy = sum(x * y for x, y in zip(timestamps, pressures))
        sum_x2 = sum(x * x for x in timestamps)
        denom = n * sum_x2 - sum_x * sum_x
        if abs(denom) < 1e-10:
            return pressures[-1]
        slope = (n * sum_xy - sum_x * sum_y) / denom
        intercept = (sum_y - slope * sum_x) / n
        current_offset = now - recent[0]["timestamp"]
        predicted = slope * (current_offset + target_seconds) + intercept
        return max(0.0, min(1.0, predicted))

    def predict_time_to_pressure(self, target_pressure: float = 0.9) -> Optional[float]:
        if len(self._samples) < 5:
            return None
        now = time.time()
        recent = [s for s in self._samples if now - s["timestamp"] < self.PREDICTION_HORIZON_SECONDS]
        if len(recent) < 5:
            return None
        timestamps = [s["timestamp"] - recent[0]["timestamp"] for s in recent]
        pressures = [s["pressure"] for s in recent]
        n = len(recent)
        sum_x = sum(timestamps)
        sum_y = sum(pressures)
        sum_xy = sum(x * y for x, y in zip(timestamps, pressures))
        sum_x2 = sum(x * x for x in timestamps)
        denom = n * sum_x2 - sum_x * sum_x
        if abs(denom) < 1e-10:
            return None
        slope = (n * sum_xy - sum_x * sum_y) / denom
        if slope <= 0:
            return None
        intercept = (sum_y - slope * sum_x) / n
        current_offset = now - recent[0]["timestamp"]
        current_predicted = slope * current_offset + intercept
        if current_predicted >= target_pressure:
            return 0.0
        time_to_target = (target_pressure - intercept) / slope - current_offset
        return max(0.0, time_to_target)

    def should_proactive_compact(self, current_pressure: float) -> bool:
        predicted = self.predict_pressure_at(60)
        if predicted is None:
            return False
        if current_pressure > 0.7 and predicted > 0.85:
            self._predictions.append({
                "timestamp": time.time(),
                "current_pressure": round(current_pressure, 3),
                "predicted_60s": round(predicted, 3),
                "action": "proactive_compaction_recommended",
            })
            if len(self._predictions) > 50:
                self._predictions = self._predictions[-50:]
            return True
        return False

    def get_stats(self) -> dict:
        return {
            "sample_count": len(self._samples),
            "prediction_count": len(self._predictions),
            "predicted_60s": self.predict_pressure_at(60),
            "time_to_critical": self.predict_time_to_pressure(0.9),
        }


class IncrementalTrimmer:
    """Incremental context trimming that removes small amounts proactively.

    Instead of waiting for emergency trimming that removes large chunks,
    this trimmer removes a few low-priority messages at a time when
    pressure exceeds a moderate threshold, keeping context healthier
    with less disruption.
    """

    TRIM_BATCH_SIZE = 3
    PRESSURE_THRESHOLD = 0.70

    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):
        self._ctx_manager = ctx_manager or ActiveContextManager()
        self._trim_count = 0
        self._total_messages_removed = 0

    async def trim_incremental(
        self,
        messages: list,
        token_counts: list[int],
        current_query: str = "",
    ) -> tuple[list, list[int], int]:
        if not messages or len(messages) <= 6:
            return messages, token_counts, 0
        total_tokens = sum(token_counts)
        avg_tokens = total_tokens / len(messages) if messages else 0
        if avg_tokens <= 0:
            return messages, token_counts, 0
        prioritized = self._ctx_manager.prioritize_messages(messages, current_query)
        to_remove_indices: set[int] = set()
        for score, msg in reversed(prioritized):
            if score < 25.0 and len(to_remove_indices) < self.TRIM_BATCH_SIZE:
                try:
                    idx = messages.index(msg)
                    to_remove_indices.add(idx)
                except ValueError:
                    continue
        if not to_remove_indices:
            return messages, token_counts, 0
        result_msgs = [m for i, m in enumerate(messages) if i not in to_remove_indices]
        result_tokens = [t for i, t in enumerate(token_counts) if i not in to_remove_indices]
        removed = len(to_remove_indices)
        self._trim_count += 1
        self._total_messages_removed += removed
        logger.info(
            "[IncrementalTrimmer] action=trim batch=%d removed=%d total_removed=%d",
            self._trim_count, removed, self._total_messages_removed,
        )
        return result_msgs, result_tokens, removed

    def get_stats(self) -> dict:
        return {
            "trim_count": self._trim_count,
            "total_messages_removed": self._total_messages_removed,
        }


class AnchorPreservationValidator:
    """Validate that anchor phrases survive compaction.

    After each compaction pass, checks that critical anchors
    (file paths, key decisions, constraints) are still present
    in the remaining context. If preservation drops below
    threshold, logs a warning and suggests re-injection.
    """

    MIN_PRESERVATION_RATIO = 0.5

    def __init__(self):
        self._validation_count = 0
        self._preservation_scores: list[float] = []

    def validate(
        self,
        anchors: list[str],
        remaining_messages: list,
    ) -> tuple[float, list[str]]:
        self._validation_count += 1
        if not anchors:
            return 1.0, []
        remaining_text = ""
        for msg in remaining_messages:
            if isinstance(msg, dict):
                remaining_text += str(msg.get("content", "")) + " "
            else:
                remaining_text += str(getattr(msg, "content", "") or "") + " "
        remaining_lower = remaining_text.lower()
        preserved = []
        lost = []
        for anchor in anchors:
            if anchor.lower()[:50] in remaining_lower:
                preserved.append(anchor)
            else:
                lost.append(anchor)
        ratio = len(preserved) / len(anchors) if anchors else 1.0
        self._preservation_scores.append(ratio)
        if len(self._preservation_scores) > 100:
            self._preservation_scores = self._preservation_scores[-100:]
        if ratio < self.MIN_PRESERVATION_RATIO:
            logger.warning(
                "[AnchorValidator] action=low_preservation ratio=%.2f preserved=%d lost=%d lost_anchors=%s",
                ratio, len(preserved), len(lost),
                [a[:50] for a in lost[:5]],
            )
        return ratio, lost

    def get_stats(self) -> dict:
        avg = (
            sum(self._preservation_scores) / len(self._preservation_scores)
            if self._preservation_scores
            else 0.0
        )
        return {
            "validation_count": self._validation_count,
            "avg_preservation_ratio": round(avg, 3),
            "min_preservation_ratio": round(min(self._preservation_scores), 3) if self._preservation_scores else 0.0,
        }


class ContextCircuitBreaker:
    """Circuit breaker for context operations to prevent cascading failures.

    When context operations (compaction, trimming, compression) fail
    repeatedly, the circuit breaker opens and prevents further attempts
    for a cooldown period, allowing the system to stabilize.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Too many failures, requests are rejected
    - HALF_OPEN: Testing if the system has recovered
    """

    MAX_FAILURES = 5
    COOLDOWN_SECONDS = 30.0
    HALF_OPEN_MAX_REQUESTS = 2
    MAX_HISTORY = 200

    def __init__(self):
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: float = 0.0
        self._state = "closed"
        self._half_open_requests = 0
        self._history: list[dict] = []

    def allow_request(self) -> bool:
        if self._state == "closed":
            return True
        if self._state == "open":
            now = time.time()
            if now - self._last_failure_time >= self.COOLDOWN_SECONDS:
                self._state = "half_open"
                self._half_open_requests = 0
                logger.info("[CircuitBreaker] action=half_open transition=open->half_open")
                return True
            return False
        if self._state == "half_open":
            if self._half_open_requests < self.HALF_OPEN_MAX_REQUESTS:
                self._half_open_requests += 1
                return True
            return False
        return False

    def record_success(self) -> None:
        self._success_count += 1
        self._history.append({"timestamp": time.time(), "result": "success"})
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]
        if self._state == "half_open":
            self._state = "closed"
            self._failure_count = 0
            logger.info("[CircuitBreaker] action=circuit_closed transition=half_open->closed")

    def record_failure(self) -> None:
        self._failure_count += 1
        self._last_failure_time = time.time()
        self._history.append({"timestamp": time.time(), "result": "failure"})
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]
        if self._failure_count >= self.MAX_FAILURES:
            if self._state != "open":
                self._state = "open"
                logger.warning(
                    "[CircuitBreaker] action=circuit_opened failures=%d cooldown=%.0fs",
                    self._failure_count, self.COOLDOWN_SECONDS,
                )
        elif self._state == "half_open":
            self._state = "open"
            logger.warning("[CircuitBreaker] action=circuit_reopened half_open_test_failed")

    def get_state(self) -> str:
        return self._state

    def get_stats(self) -> dict:
        return {
            "state": self._state,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "last_failure_ago": round(time.time() - self._last_failure_time, 1) if self._last_failure_time > 0 else None,
            "cooldown_seconds": self.COOLDOWN_SECONDS,
        }


class ContextOperationRateLimiter:
    """Rate limiter for context operations to prevent excessive compaction.

    Limits how frequently context operations (compaction, trimming, etc.)
    can be executed, preventing CPU thrashing from repeated compaction
    attempts in rapid succession.
    """

    MAX_OPERATIONS_PER_MINUTE = 10
    MAX_OPERATIONS_PER_5MINUTES = 30
    BURST_ALLOWANCE = 3
    BURST_WINDOW_SECONDS = 5.0
    MAX_HISTORY = 500

    def __init__(self):
        self._operation_timestamps: deque = deque(maxlen=self.MAX_HISTORY)
        self._rejected_count = 0

    def allow_operation(self) -> bool:
        now = time.time()
        recent_1min = sum(1 for ts in self._operation_timestamps if now - ts < 60)
        recent_5min = sum(1 for ts in self._operation_timestamps if now - ts < 300)
        recent_burst = sum(1 for ts in self._operation_timestamps if now - ts < self.BURST_WINDOW_SECONDS)
        if recent_burst >= self.BURST_ALLOWANCE:
            self._rejected_count += 1
            return False
        if recent_1min >= self.MAX_OPERATIONS_PER_MINUTE:
            self._rejected_count += 1
            return False
        if recent_5min >= self.MAX_OPERATIONS_PER_5MINUTES:
            self._rejected_count += 1
            return False
        self._operation_timestamps.append(now)
        return True

    def get_stats(self) -> dict:
        now = time.time()
        recent_1min = sum(1 for ts in self._operation_timestamps if now - ts < 60)
        recent_5min = sum(1 for ts in self._operation_timestamps if now - ts < 300)
        return {
            "operations_last_minute": recent_1min,
            "operations_last_5minutes": recent_5min,
            "rejected_count": self._rejected_count,
            "total_operations": len(self._operation_timestamps),
        }


class ContextMetricsAggregator:
    """Aggregates metrics from all context subsystems for unified reporting.

    Collects and computes aggregate metrics across all context management
    components, providing a single point of access for monitoring dashboards
    and alerting systems.
    """

    MAX_SNAPSHOTS = 100
    SNAPSHOT_INTERVAL_SECONDS = 60.0

    def __init__(self):
        self._snapshots: deque = deque(maxlen=self.MAX_SNAPSHOTS)
        self._last_snapshot_time: float = 0.0
        self._total_compactions = 0
        self._total_trims = 0
        self._total_errors = 0

    def record_compaction(self, messages_removed: int, tokens_saved: int) -> None:
        self._total_compactions += 1
        self._try_snapshot()

    def record_trim(self, messages_removed: int) -> None:
        self._total_trims += 1
        self._try_snapshot()

    def record_error(self, error_type: str) -> None:
        self._total_errors += 1

    def _try_snapshot(self) -> None:
        now = time.time()
        if now - self._last_snapshot_time < self.SNAPSHOT_INTERVAL_SECONDS:
            return
        self._snapshots.append({
            "timestamp": now,
            "total_compactions": self._total_compactions,
            "total_trims": self._total_trims,
            "total_errors": self._total_errors,
        })
        self._last_snapshot_time = now

    def get_stats(self) -> dict:
        return {
            "total_compactions": self._total_compactions,
            "total_trims": self._total_trims,
            "total_errors": self._total_errors,
            "snapshots": len(self._snapshots),
        }
