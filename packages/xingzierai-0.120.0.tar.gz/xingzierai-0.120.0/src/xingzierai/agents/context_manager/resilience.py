# -*- coding: utf-8 -*-
"""Error recovery, circuit breaker, rate limiting for context operations."""

from __future__ import annotations
import asyncio
import logging
import time
from typing import Any, Dict, List, Optional
from .models import ErrorRecoveryStrategy

logger = logging.getLogger(__name__)

class ContextRecoveryManager:

    """Manages context recovery after failures.



    When context is corrupted or lost, this manager provides

    multiple recovery strategies with increasing aggressiveness.

    """



    MAX_RECOVERY_ATTEMPTS = 3

    BACKUP_RETENTION_COUNT = 5



    def __init__(self, session_dir: Optional[str] = None):

        self._session_dir = Path(session_dir) if session_dir else None

        self._recovery_history: list[dict] = []



    async def attempt_recovery(

        self,

        agent: Any,

        strategy: str = "reload_session",

    ) -> bool:

        for attempt in range(self.MAX_RECOVERY_ATTEMPTS):

            try:

                if strategy == "reload_session" and self._session_dir:

                    success = await self._reload_from_session(agent)

                    if success:

                        self._record_recovery(strategy, attempt, True)

                        return True

                elif strategy == "rebuild_from_summary":

                    success = await self._rebuild_from_summary(agent)

                    if success:

                        self._record_recovery(strategy, attempt, True)

                        return True

                elif strategy == "fresh_start":

                    await self._fresh_start(agent)

                    self._record_recovery(strategy, attempt, True)

                    return True

            except Exception as e:

                logger.warning(

                    "[ContextRecovery] action=recovery_attempt strategy=%s attempt=%d error=%s",

                    strategy, attempt, e,

                )

            await asyncio.sleep(0.5 * (attempt + 1))



        self._record_recovery(strategy, self.MAX_RECOVERY_ATTEMPTS, False)

        return False



    async def _reload_from_session(self, agent: Any) -> bool:

        if not self._session_dir:

            return False

        session_file = self._session_dir / "session.json"

        if not session_file.exists():

            return False

        logger.info("[ContextRecovery] action=reload_session path=%s", session_file)

        return True



    async def _rebuild_from_summary(self, agent: Any) -> bool:

        if not hasattr(agent, 'memory'):

            return False

        summary = agent.memory.get_compressed_summary() if hasattr(agent.memory, 'get_compressed_summary') else ""

        if not summary:

            return False

        logger.info("[ContextRecovery] action=rebuild_from_summary summary_len=%d", len(summary))

        return True



    async def _fresh_start(self, agent: Any) -> None:

        if hasattr(agent, 'memory') and hasattr(agent.memory, 'clear'):

            await agent.memory.clear()

        logger.info("[ContextRecovery] action=fresh_start agent=%s", getattr(agent, 'name', 'unknown'))



    def _record_recovery(self, strategy: str, attempts: int, success: bool) -> None:

        self._recovery_history.append({

            "timestamp": time.time(),

            "strategy": strategy,

            "attempts": attempts,

            "success": success,

        })

        if len(self._recovery_history) > 100:

            self._recovery_history = self._recovery_history[-100:]



    def get_stats(self) -> dict:

        total = len(self._recovery_history)

        successes = sum(1 for r in self._recovery_history if r["success"])

        return {

            "total_recoveries": total,

            "success_rate": round(successes / max(1, total), 3),

            "recent_recoveries": self._recovery_history[-10:],

        }




class ContextAwareErrorRecovery:

    """Context-aware error recovery with different strategies for different error types.



    Maps error types to appropriate recovery strategies based on:

    - Error severity (transient vs permanent)

    - Context state (healthy vs critical)

    - Recovery history (avoid repeating failed strategies)

    """



    MAX_RECOVERY_HISTORY = 100

    MAX_STRATEGY_ATTEMPTS = 3

    _instance: "ContextAwareErrorRecovery | None" = None



    def __init__(self) -> None:

        self._recovery_history: list[dict] = []

        self._strategy_failure_counts: dict[str, int] = {}



    @classmethod

    def get_instance(cls) -> "ContextAwareErrorRecovery":

        if cls._instance is None:

            cls._instance = cls()

        return cls._instance



    def classify_error(self, error: Exception) -> str:

        error_str = str(error).lower()

        error_type = type(error).__name__.lower()



        if 'timeout' in error_str or 'timedout' in error_type:

            return "timeout"

        if 'context' in error_str and ('exceed' in error_str or 'too long' in error_str or 'too many token' in error_str):

            return "context_overflow"

        if 'rate' in error_str and 'limit' in error_str:

            return "rate_limit"

        if '401' in error_str or 'unauthorized' in error_str or 'auth' in error_type:

            return "auth_error"

        if 'network' in error_str or 'connection' in error_str or 'connecterror' in error_type:

            return "network_error"

        if '400' in error_str or 'bad_request' in error_str:

            return "bad_request"

        if '500' in error_str or 'internal' in error_str or 'server_error' in error_str:

            return "server_error"

        return "unknown"



    def get_strategy(self, error_type: str, context_health: str = "healthy") -> ErrorRecoveryStrategy:

        strategy_map: dict[str, list[ErrorRecoveryStrategy]] = {

            "timeout": [ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.FALLBACK_MODEL],

            "context_overflow": [ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],

            "rate_limit": [ErrorRecoveryStrategy.FALLBACK_MODEL, ErrorRecoveryStrategy.RETRY],

            "auth_error": [ErrorRecoveryStrategy.FALLBACK_MODEL, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],

            "network_error": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.FALLBACK_MODEL],

            "bad_request": [ErrorRecoveryStrategy.TRIM, ErrorRecoveryStrategy.COMPACT],

            "server_error": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.FALLBACK_MODEL],

            "unknown": [ErrorRecoveryStrategy.RETRY, ErrorRecoveryStrategy.COMPACT, ErrorRecoveryStrategy.GRACEFUL_DEGRADE],

        }



        if context_health == "critical":

            if error_type not in ("context_overflow", "bad_request"):

                return ErrorRecoveryStrategy.GRACEFUL_DEGRADE



        strategies = strategy_map.get(error_type, strategy_map["unknown"])

        for strategy in strategies:

            key = f"{error_type}:{strategy.value}"

            if self._strategy_failure_counts.get(key, 0) < self.MAX_STRATEGY_ATTEMPTS:

                return strategy



        return ErrorRecoveryStrategy.GRACEFUL_DEGRADE



    def record_recovery(self, error_type: str, strategy: ErrorRecoveryStrategy, success: bool) -> None:

        self._recovery_history.append({

            "timestamp": time.time(),

            "error_type": error_type,

            "strategy": strategy.value,

            "success": success,

        })

        if len(self._recovery_history) > self.MAX_RECOVERY_HISTORY:

            self._recovery_history = self._recovery_history[-self.MAX_RECOVERY_HISTORY:]



        key = f"{error_type}:{strategy.value}"

        if not success:

            self._strategy_failure_counts[key] = self._strategy_failure_counts.get(key, 0) + 1

        else:

            self._strategy_failure_counts.pop(key, None)



    def get_recovery_stats(self) -> dict:

        total = len(self._recovery_history)

        if total == 0:

            return {"total_recoveries": 0, "success_rate": 0.0, "strategy_distribution": {}}

        successes = sum(1 for r in self._recovery_history if r["success"])

        distribution: dict[str, int] = {}

        for r in self._recovery_history:

            s = r["strategy"]

            distribution[s] = distribution.get(s, 0) + 1

        return {

            "total_recoveries": total,

            "success_rate": round(successes / total, 3),

            "strategy_distribution": distribution,

            "failed_strategies": dict(self._strategy_failure_counts),

        }




class ContextCircuitBreaker:

    """Circuit breaker for context operations to prevent cascading failures.



    When context operations (compaction, trimming, compression) fail

    repeatedly, the circuit breaker opens and prevents further attempts

    for a cooldown period, allowing the system to stabilize.



    States:

    - CLOSED: Normal operation, requests pass through

    - OPEN: Too many failures, requests are rejected

    - HALF_OPEN: Testing if the system has recovered

    """



    MAX_FAILURES = 5

    COOLDOWN_SECONDS = 30.0

    HALF_OPEN_MAX_REQUESTS = 2

    MAX_HISTORY = 200



    def __init__(self):

        self._failure_count = 0

        self._success_count = 0

        self._last_failure_time: float = 0.0

        self._state = "closed"

        self._half_open_requests = 0

        self._history: list[dict] = []



    def allow_request(self) -> bool:

        if self._state == "closed":

            return True

        if self._state == "open":

            now = time.time()

            if now - self._last_failure_time >= self.COOLDOWN_SECONDS:

                self._state = "half_open"

                self._half_open_requests = 0

                logger.info("[CircuitBreaker] action=half_open transition=open->half_open")

                return True

            return False

        if self._state == "half_open":

            if self._half_open_requests < self.HALF_OPEN_MAX_REQUESTS:

                self._half_open_requests += 1

                return True

            return False

        return False



    def record_success(self) -> None:

        self._success_count += 1

        self._history.append({"timestamp": time.time(), "result": "success"})

        if len(self._history) > self.MAX_HISTORY:

            self._history = self._history[-self.MAX_HISTORY:]

        if self._state == "half_open":

            self._state = "closed"

            self._failure_count = 0

            logger.info("[CircuitBreaker] action=circuit_closed transition=half_open->closed")



    def record_failure(self) -> None:

        self._failure_count += 1

        self._last_failure_time = time.time()

        self._history.append({"timestamp": time.time(), "result": "failure"})

        if len(self._history) > self.MAX_HISTORY:

            self._history = self._history[-self.MAX_HISTORY:]

        if self._failure_count >= self.MAX_FAILURES:

            if self._state != "open":

                self._state = "open"

                logger.warning(

                    "[CircuitBreaker] action=circuit_opened failures=%d cooldown=%.0fs",

                    self._failure_count, self.COOLDOWN_SECONDS,

                )

        elif self._state == "half_open":

            self._state = "open"

            logger.warning("[CircuitBreaker] action=circuit_reopened half_open_test_failed")



    def get_state(self) -> str:

        return self._state



    def get_stats(self) -> dict:

        return {

            "state": self._state,

            "failure_count": self._failure_count,

            "success_count": self._success_count,

            "last_failure_ago": round(time.time() - self._last_failure_time, 1) if self._last_failure_time > 0 else None,

            "cooldown_seconds": self.COOLDOWN_SECONDS,

        }




class ContextOperationRateLimiter:

    """Rate limiter for context operations to prevent excessive compaction.



    Limits how frequently context operations (compaction, trimming, etc.)

    can be executed, preventing CPU thrashing from repeated compaction

    attempts in rapid succession.

    """



    MAX_OPERATIONS_PER_MINUTE = 10

    MAX_OPERATIONS_PER_5MINUTES = 30

    BURST_ALLOWANCE = 3

    BURST_WINDOW_SECONDS = 5.0

    MAX_HISTORY = 500



    def __init__(self):

        self._operation_timestamps: deque = deque(maxlen=self.MAX_HISTORY)

        self._rejected_count = 0



    def allow_operation(self) -> bool:

        now = time.time()

        recent_1min = sum(1 for ts in self._operation_timestamps if now - ts < 60)

        recent_5min = sum(1 for ts in self._operation_timestamps if now - ts < 300)

        recent_burst = sum(1 for ts in self._operation_timestamps if now - ts < self.BURST_WINDOW_SECONDS)

        if recent_burst >= self.BURST_ALLOWANCE:

            self._rejected_count += 1

            return False

        if recent_1min >= self.MAX_OPERATIONS_PER_MINUTE:

            self._rejected_count += 1

            return False

        if recent_5min >= self.MAX_OPERATIONS_PER_5MINUTES:

            self._rejected_count += 1

            return False

        self._operation_timestamps.append(now)

        return True



    def get_stats(self) -> dict:

        now = time.time()

        recent_1min = sum(1 for ts in self._operation_timestamps if now - ts < 60)

        recent_5min = sum(1 for ts in self._operation_timestamps if now - ts < 300)

        return {

            "operations_last_minute": recent_1min,

            "operations_last_5minutes": recent_5min,

            "rejected_count": self._rejected_count,

            "total_operations": len(self._operation_timestamps),

        }

