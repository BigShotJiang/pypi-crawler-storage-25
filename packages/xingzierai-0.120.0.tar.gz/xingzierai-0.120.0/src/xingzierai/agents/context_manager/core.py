# -*- coding: utf-8 -*-
"""Core context manager - context preparation, compression, prioritization."""

from __future__ import annotations
import logging
import re as _re
import time
from collections import deque
from typing import Any, Dict, List, Optional, Tuple
from .models import ContextBudget, ContextLayer, ContextHealthReport, RetrievalResult

logger = logging.getLogger(__name__)

class ActiveContextManager:

    """

    Active Context Management System.



    Features:

    - Proactive memory retrieval before reasoning

    - Layer-based context organization

    - Time-based tool result compression

    - Context prioritization based on relevance

    - Token budget management per layer

    - Context health reporting and diagnostics



    This implementation is inspired by CoPaw's context management v2.0.

    """



    MAX_RETRIEVAL_HISTORY = 100

    MAX_HEALTH_WARNINGS = 10



    def __init__(

        self,

        budget: Optional[ContextBudget] = None,

        enable_proactive_search: bool = True,

        min_relevant_score: float = 0.3,

    ):

        self.budget = budget or ContextBudget()

        self.enable_proactive_search = enable_proactive_search

        self.min_relevant_score = min_relevant_score

        self._retrieval_history: deque = deque(maxlen=self.MAX_RETRIEVAL_HISTORY)

        self._health_check_count: int = 0



    async def prepare_context(

        self,

        system_prompt: str,

        summary: Optional[str],

        history: List[Any],

        recent_messages: List[Any],

        tools_context: Optional[str] = None,

        task_query: Optional[str] = None,

        token_counter: Optional[Any] = None,

    ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:

        """Prepare context for LLM call.



        Args:

            system_prompt: System prompt.

            summary: Compressed summary of older messages.

            history: Full history messages.

            recent_messages: Recent messages to preserve.

            tools_context: Tools schema/context.

            task_query: Current task query for retrieval.

            token_counter: Token counter for estimation.



        Returns:

            Tuple of (messages, token_usage_by_layer)

        """

        messages = []

        token_usage = {}



        sys_tokens = await self._estimate_tokens(system_prompt, token_counter)

        messages.append({"role": "system", "content": system_prompt})

        token_usage[ContextLayer.SYSTEM.value] = sys_tokens



        if summary:

            summary_tokens = await self._estimate_tokens(summary, token_counter)

            if summary_tokens <= self.budget.summary:

                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{summary}"})

                token_usage[ContextLayer.SUMMARY.value] = summary_tokens

            else:

                logger.warning("[ContextMgr] action=summary_truncate tokens=%d budget=%d", summary_tokens, self.budget.summary)

                truncated = await self._truncate_to_tokens(summary, self.budget.summary, token_counter)

                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{truncated}"})

                token_usage[ContextLayer.SUMMARY.value] = self.budget.summary



        if self.enable_proactive_search and task_query:

            retrieved = await self._proactive_retrieve(task_query, history)

            if retrieved:

                retrieved_text = "\n\n".join([

                    f"[Relevant memory - {r.source}]: {r.content}"

                    for r in retrieved

                ])

                retrieved_tokens = await self._estimate_tokens(retrieved_text, token_counter)

                if retrieved_tokens <= self.budget.history // 2:

                    messages.append({"role": "system", "content": f"[Retrieved relevant context]\n{retrieved_text}"})

                    token_usage["retrieved"] = retrieved_tokens



        remaining_budget = self._calculate_remaining_budget(token_usage)



        history_to_include = await self._select_history_messages(

            history, remaining_budget, token_counter

        )

        for msg in history_to_include:

            messages.append(msg)

        token_usage[ContextLayer.HISTORY.value] = await self._estimate_messages_tokens(

            history_to_include, token_counter

        )



        remaining_budget = self._calculate_remaining_budget(token_usage)



        recent_to_add = recent_messages[-10:]

        history_ids = {id(m) for m in history_to_include}

        deduped_recent = [m for m in recent_to_add if id(m) not in history_ids]

        for msg in deduped_recent:

            messages.append(msg)

        token_usage[ContextLayer.RECENT.value] = await self._estimate_messages_tokens(

            deduped_recent, token_counter

        )



        if tools_context:

            tools_tokens = await self._estimate_tokens(tools_context, token_counter)

            token_usage[ContextLayer.TOOLS.value] = min(tools_tokens, self.budget.tools)



        self._record_retrieval(task_query, messages, token_usage)



        return messages, token_usage



    async def compress_tool_results(

        self,

        messages: List[Any],

        recent_threshold: int = 5,

        old_threshold: int = 3,

    ) -> List[Any]:

        """Compress tool results based on time/relevance.



        Inspired by CoPaw's tool result compaction.



        Args:

            messages: Messages to compress.

            recent_threshold: Keep full results for recent N messages.

            old_threshold: Summary length for older messages.



        Returns:

            Compressed messages.

        """

        if not messages:

            return messages



        compressed = []

        tool_result_count = 0



        for i, msg in enumerate(messages):

            if isinstance(msg, dict):

                content = msg.get("content")

                role = msg.get("role")

            else:

                content = getattr(msg, "content", None)

                role = getattr(msg, "role", None)



            is_tool_result = role == "tool" or (isinstance(content, list) and

                any(getattr(c, "type", "") == "tool_use_result" for c in content))



            if is_tool_result:

                tool_result_count += 1

                if tool_result_count <= recent_threshold:

                    compressed.append(msg)

                else:

                    compressed_msg = await self._compress_single_tool_result(msg, old_threshold)

                    compressed.append(compressed_msg)

            else:

                compressed.append(msg)



        return compressed



    async def fold_completed_trajectories(

        self,

        messages: List[Any],

        keep_recent: int = 6,

    ) -> List[Any]:

        """Fold completed tool-call trajectories into concise summaries.



        Implements Context-Folding (arXiv:2510.11967, AAAI 2026):

        When a tool-use → tool-result sequence is complete and not in the

        recent window, collapse the intermediate steps into a one-line

        outcome summary. This reduces active context by 5-10x for

        long-horizon tasks while preserving all outcomes.



        Args:

            messages: Full message list.

            keep_recent: Number of recent messages to preserve unchanged.



        Returns:

            Messages with folded trajectories. Folded messages preserve

            the original Msg type to maintain compatibility with downstream

            context_check() and mark_messages_compressed().

        """

        if len(messages) <= keep_recent + 2:

            return messages



        protected = messages[-keep_recent:] if keep_recent > 0 else []

        foldable = messages[:-keep_recent] if keep_recent > 0 else messages



        if not foldable:

            return messages



        folded = []

        i = 0

        while i < len(foldable):

            msg = foldable[i]

            role = self._get_role(msg)

            content = self._get_content_text(msg)



            if role == "assistant" and self._has_tool_use(msg):

                tool_names = self._extract_tool_names(msg)

                tool_result_parts = []

                j = i + 1



                while j < len(foldable) and self._get_role(foldable[j]) == "tool":

                    result_text = self._get_content_text(foldable[j])

                    tool_result_parts.append(result_text[:300])

                    j += 1



                if tool_result_parts:

                    outcome = self._summarize_tool_outcome(tool_names, tool_result_parts)

                    folded_msg = self._create_folded_msg(msg, outcome)

                    folded.append(folded_msg)

                    i = j

                    continue



            folded.append(msg)

            i += 1



        return folded + protected



    def _create_folded_msg(self, original_msg: Any, outcome_text: str) -> Any:

        """Create a folded message preserving the original Msg type.



        If the original is a Msg object, create a new Msg with the

        folded content but without tool_use blocks (which are now

        represented in the outcome text). This ensures downstream

        code that expects Msg objects with .id attributes works correctly.

        """

        try:

            from xingzierai.agentscope_core.message import Msg, TextBlock

            original_id = getattr(original_msg, 'id', None)

            original_name = getattr(original_msg, 'name', self.name if hasattr(self, 'name') else 'assistant')

            folded = Msg(

                name=original_name,

                role="assistant",

                content=[TextBlock(type="text", text=outcome_text)],

            )

            if original_id:

                folded.id = original_id

            return folded

        except Exception as _fold_msg_err:

            logger.debug("[ContextMgr] action=fold_msg_fallback error=%s", _fold_msg_err)

            return {"role": "assistant", "content": outcome_text}



    def extract_folded_outcomes(

        self,

        messages: List[Any],

        keep_recent: int = 6,

    ) -> List[str]:

        """Extract tool outcome summaries without modifying the message list.



        Non-destructive version of fold_completed_trajectories that only

        returns the outcome strings. Used by memory_compaction to include

        folded outcomes in the summary without replacing the original messages.



        Args:

            messages: Full message list.

            keep_recent: Number of recent messages to skip.



        Returns:

            List of outcome summary strings.

        """

        if len(messages) <= keep_recent + 2:

            return []



        foldable = messages[:-keep_recent] if keep_recent > 0 else messages

        outcomes = []

        i = 0



        while i < len(foldable):

            msg = foldable[i]

            role = self._get_role(msg)



            if role == "assistant" and self._has_tool_use(msg):

                tool_names = self._extract_tool_names(msg)

                result_parts = []

                j = i + 1

                while j < len(foldable) and self._get_role(foldable[j]) == "tool":

                    result_text = self._get_content_text(foldable[j])

                    result_parts.append(result_text[:300])

                    j += 1

                if result_parts:

                    outcome = self._summarize_tool_outcome(tool_names, result_parts)

                    outcomes.append(outcome)

                i = j

                continue

            i += 1



        return outcomes



    def _summarize_tool_outcome(

        self,

        tool_names: list[str],

        result_parts: list[str],

    ) -> str:

        """Create a concise one-line summary of a completed tool trajectory."""

        names_str = ", ".join(tool_names[:3])

        combined = " ".join(result_parts)



        if len(combined) > 200:

            combined = combined[:200] + "..."



        success = not any(

            kw in combined.lower()

            for kw in ["error", "failed", "exception", "traceback"]

        )



        status = "✅" if success else "❌"

        return f"{status} [{names_str}] {combined}"



    async def _compress_single_tool_result(

        self,

        message: Any,

        max_length: int = 500,

    ) -> Any:

        """Compress a single tool result message."""

        if isinstance(message, dict):

            content = message.get("content", "")

            if isinstance(content, str) and len(content) > max_length:

                message = message.copy()

                message["content"] = f"[工具结果已截断 / Tool result truncated - {len(content)} chars -> {max_length}]\n" + content[:max_length]

            return message

        return message



    async def _proactive_retrieve(

        self,

        query: str,

        history: List[Any],

    ) -> List[RetrievalResult]:

        """Proactively retrieve relevant context.



        Args:

            query: Current task query.

            history: Message history.



        Returns:

            List of retrieval results.

        """

        results = []

        query_lower = query.lower()



        keywords = self._extract_keywords(query_lower)



        for msg in history[-50:]:

            if isinstance(msg, dict):

                content = str(msg.get("content", ""))

                role = msg.get("role", "")

            else:

                content = str(getattr(msg, "content", ""))

                role = getattr(msg, "role", "")



            if not content:

                continue



            content_lower = content.lower()

            score = 0.0



            for kw in keywords:

                if kw in content_lower:

                    score += 0.3



            if role == "user" and any(kw in content_lower for kw in ["create", "build", "make", "generate"]):

                score += 0.2



            if role == "assistant" and "error" in content_lower:

                score += 0.1



            if score >= self.min_relevant_score:

                results.append(RetrievalResult(

                    content=content[:500],

                    source=f"history:{role}",

                    score=score,

                    timestamp=time.time(),

                ))



        results.sort(key=lambda x: x.score, reverse=True)

        return results[:3]



    def _extract_keywords(self, text: str) -> List[str]:

        """Extract keywords from text."""

        stop_words = {"the", "a", "an", "is", "are", "was", "were", "be", "been",

                     "being", "have", "has", "had", "do", "does", "did", "will",

                     "would", "could", "should", "may", "might", "must", "shall",

                     "can", "need", "dare", "ought", "used", "to", "of", "in",

                     "for", "on", "with", "at", "by", "from", "as", "into", "through"}



        words = text.replace(",", " ").replace(".", " ").replace("?", " ").split()

        keywords = [w for w in words if len(w) > 3 and w.lower() not in stop_words]



        return keywords[:10]



    @staticmethod

    def _get_role(msg: Any) -> str:

        """Extract role from a message (dict or object)."""

        if isinstance(msg, dict):

            return msg.get("role", "")

        return getattr(msg, "role", "") or ""



    @staticmethod

    def estimate_tokens(text: str) -> int:

        """Estimate token count for a text string.



        Uses a simple heuristic: ~4 chars per token for English,

        ~1.5 chars per token for CJK text.



        Args:

            text: Input text string.



        Returns:

            Estimated token count.

        """

        if not text:

            return 0

        cjk_count = 0

        for ch in text:

            if '\u4e00' <= ch <= '\u9fff' or '\u3000' <= ch <= '\u303f':

                cjk_count += 1

        non_cjk_len = len(text) - cjk_count

        return max(1, int(cjk_count / 1.5 + non_cjk_len / 4))



    @staticmethod

    def estimate_messages_tokens(messages: list) -> list[int]:

        """Estimate token counts for a list of messages.



        Args:

            messages: List of message objects (dict or Msg).



        Returns:

            List of estimated token counts per message.

        """

        counts = []

        for msg in messages:

            text = ActiveContextManager._get_content_text(msg)

            counts.append(ActiveContextManager.estimate_tokens(text))

        return counts



    @staticmethod

    def _get_content_text(msg: Any) -> str:

        """Extract text content from a message."""

        if isinstance(msg, dict):

            content = msg.get("content", "")

        else:

            content = getattr(msg, "content", "")



        if content is None:

            content = ""



        if isinstance(content, list):

            parts = []

            for c in content:

                if isinstance(c, str):

                    parts.append(c)

                elif isinstance(c, dict):

                    if c.get("type") == "text":

                        parts.append(c.get("text", ""))

                    elif c.get("type") == "tool_use":

                        parts.append(f"[tool_use: {c.get('name', '?')}]")

                    elif c.get("type") == "tool_result":

                        parts.append(c.get("content", "")[:200] if isinstance(c.get("content"), str) else "")

            return " ".join(parts)

        return str(content) if content else ""



    @staticmethod

    def _has_tool_use(msg: Any) -> bool:

        """Check if a message contains tool_use blocks."""

        if isinstance(msg, dict):

            content = msg.get("content", "")

        else:

            content = getattr(msg, "content", "")



        if content is None:

            return False



        if isinstance(content, list):

            return any(

                (isinstance(c, dict) and c.get("type") == "tool_use")

                for c in content

            )

        return False



    @staticmethod

    def _extract_tool_names(msg: Any) -> list[str]:

        """Extract tool names from a tool_use message."""

        if isinstance(msg, dict):

            content = msg.get("content", "")

        else:

            content = getattr(msg, "content", "")



        if content is None:

            return []



        names = []

        if isinstance(content, list):

            for c in content:

                if isinstance(c, dict) and c.get("type") == "tool_use":

                    names.append(c.get("name", "unknown"))

        return names



    async def _estimate_tokens(

        self,

        text: str,

        token_counter: Optional[Any],

    ) -> int:

        if not text:

            return 0



        if token_counter and hasattr(token_counter, "count"):

            try:

                return await token_counter.count(messages=[], text=text)

            except Exception as _token_count_err:

                logger.debug("[ContextMgr] action=token_count_fallback error=%s", _token_count_err)



        return len(text) // 4



    async def _estimate_messages_tokens(

        self,

        messages: List[Any],

        token_counter: Optional[Any],

    ) -> int:

        """Estimate total tokens for messages."""

        total = 0

        for msg in messages:

            if isinstance(msg, dict):

                content = msg.get("content", "")

            else:

                content = getattr(msg, "content", "")



            if isinstance(content, str):

                total += await self._estimate_tokens(content, token_counter)

            elif isinstance(content, list):

                for c in content:

                    if isinstance(c, str):

                        total += await self._estimate_tokens(c, token_counter)

                    elif isinstance(c, dict):

                        total += await self._estimate_tokens(c.get("text", ""), token_counter)



        return total



    async def _select_history_messages(

        self,

        history: List[Any],

        remaining_budget: int,

        token_counter: Optional[Any],

    ) -> List[Any]:

        """Select history messages within budget."""

        if not history or remaining_budget <= 0:

            return []



        selected = []

        current_tokens = 0



        for msg in reversed(history[-30:]):

            msg_tokens = await self._estimate_messages_tokens([msg], token_counter)



            if current_tokens + msg_tokens > remaining_budget:

                break



            selected.insert(0, msg)

            current_tokens += msg_tokens



        return selected



    async def _truncate_to_tokens(

        self,

        text: str,

        max_tokens: int,

        token_counter: Optional[Any],

    ) -> str:

        estimated_tokens = await self._estimate_tokens(text, token_counter)



        if estimated_tokens <= max_tokens:

            return text



        char_per_token = len(text) / max(estimated_tokens, 1)

        max_chars = int(max_tokens * char_per_token * 0.9)



        truncated = text[:max_chars]

        sentence_endings = ["。", ".", "！", "!", "？", "?", "\n"]

        best_cut = -1

        for ending in sentence_endings:

            pos = truncated.rfind(ending)

            if pos > best_cut:

                best_cut = pos

        if best_cut > max_chars * 0.5:

            truncated = truncated[:best_cut + 1]



        return truncated + "..."



    def _calculate_remaining_budget(

        self,

        token_usage: Dict[str, int],

    ) -> int:

        """Calculate remaining token budget."""

        total_used = sum(token_usage.values())

        total_budget = (

            self.budget.system +

            self.budget.summary +

            self.budget.history +

            self.budget.recent +

            self.budget.tools

        )

        return max(0, total_budget - total_used)



    def _record_retrieval(

        self,

        query: Optional[str],

        messages: List[Dict[str, Any]],

        token_usage: Dict[str, int],

    ) -> None:

        """Record retrieval for analysis."""

        self._retrieval_history.append({

            "timestamp": time.time(),

            "query": query,

            "message_count": len(messages),

            "token_usage": token_usage,

        })



    def prioritize_messages(

        self,

        messages: List[Any],

        current_query: str = "",

    ) -> List[Tuple[float, Any]]:

        """Assign a priority score to each message for intelligent trimming.



        Priority is a float 0-100 composed of:

        - Recency (0-40): newer messages score higher

        - Relevance (0-30): keyword overlap with current_query

        - Importance (0-30): contains file paths (+10), errors (+10), decisions (+10)



        Returns:

            List of (priority_score, message) sorted descending (highest first).

            When context needs trimming, remove from the end (lowest priority).

        """

        import re as _re



        if not messages:

            return []



        total = len(messages)

        query_words: set[str] = set()

        if current_query:

            query_words = set(_re.findall(r'\w+', current_query.lower()))



        scored: List[Tuple[float, Any]] = []



        for idx, msg in enumerate(messages):

            role = self._get_role(msg)

            text = self._get_content_text(msg)



            recency_score = (idx / max(1, total - 1)) * 40.0 if total > 1 else 40.0



            relevance_score = 0.0

            if query_words and text:

                msg_words = set(_re.findall(r'\w+', text.lower()))

                if msg_words:

                    overlap = msg_words & query_words

                    relevance_score = (len(overlap) / min(len(msg_words), len(query_words))) * 30.0

            if role == "user":

                relevance_score = max(relevance_score, 8.0)

            elif role == "system":

                relevance_score = 30.0



            importance_score = 0.0

            text_lower = text.lower() if text else ""



            if _re.search(r'(?:/[\w\-./]+\.[\w]+|[A-Za-z]:\\[\w\-./\\]+\.[\w]+)', text or ""):

                importance_score += 10.0



            error_keywords = ["error", "错误", "exception", "failed", "失败", "traceback", "bug"]

            if any(kw in text_lower for kw in error_keywords):

                importance_score += 10.0



            decision_keywords = ["决定", "decision", "选择", "chose", "resolved", "解决", "方案", "approach", "must", "必须", "never", "绝不"]

            if any(kw in text_lower for kw in decision_keywords):

                importance_score += 10.0



            total_score = recency_score + relevance_score + min(importance_score, 30.0)

            scored.append((round(total_score, 2), msg))



        scored.sort(key=lambda x: x[0], reverse=True)



        low_count = sum(1 for s, _ in scored if s < 20.0)

        high_count = sum(1 for s, _ in scored if s > 70.0)

        if low_count > 0 or high_count > 0:

            logger.info(

                "[ContextMgr] action=prioritize_messages total=%d low_priority=%d high_priority=%d",

                len(scored), low_count, high_count,

            )



        return scored



    def trim_by_priority(

        self,

        messages: List[Any],

        current_query: str,

        max_tokens: int,

        token_counts: List[int],

    ) -> List[Any]:

        """Trim messages by priority, removing lowest-priority first.



        Args:

            messages: Full message list.

            current_query: Current user query for relevance scoring.

            max_tokens: Maximum token budget.

            token_counts: Token count for each message.



        Returns:

            Messages that fit within the token budget, highest priority first.

        """

        if not messages or len(messages) != len(token_counts):

            return list(messages) if messages else []



        prioritized = self.prioritize_messages(messages, current_query)



        total = 0

        kept_indices: set[int] = set()

        for score, msg in prioritized:

            idx = messages.index(msg)

            tc = token_counts[idx]

            if total + tc <= max_tokens:

                kept_indices.add(idx)

                total += tc



        result = [messages[i] for i in sorted(kept_indices)]

        removed = len(messages) - len(result)

        if removed > 0:

            logger.info(

                "[ContextMgr] action=trim_by_priority original=%d kept=%d removed=%d budget=%d used=%d",

                len(messages), len(result), removed, max_tokens, total,

            )

        return result



    def defragment(

        self,

        messages: List[Any],

        summary: str = "",

    ) -> Tuple[List[Any], str]:

        """Defragment messages and summary for coherent conversation flow.



        When messages are deleted/compacted, there can be "gaps" in the

        conversation flow. Defragmentation reorganizes messages to ensure

        coherent conversation flow by:

        1. Merging adjacent summaries

        2. Removing duplicate entries

        3. Reordering by timestamp when available

        4. Ensuring tool_use/tool_result pairs stay together



        Args:

            messages: Current message list (may have gaps).

            summary: Current compressed summary.



        Returns:

            Tuple of (defragmented_messages, defragmented_summary).

        """

        if not messages and not summary:

            return messages, summary



        defrag_messages = self._defragment_messages(messages)

        defrag_summary = self._defragment_summary(summary)



        return defrag_messages, defrag_summary



    def _defragment_messages(self, messages: List[Any]) -> List[Any]:

        if not messages:

            return messages



        seen_ids: set[str] = set()

        deduped = []

        for msg in messages:

            msg_id = ""

            if isinstance(msg, dict):

                msg_id = msg.get("id", "")

            else:

                msg_id = getattr(msg, "id", "")

            if msg_id and msg_id in seen_ids:

                continue

            if msg_id:

                seen_ids.add(msg_id)

            deduped.append(msg)



        timestamped: List[Tuple[float, Any]] = []

        untimed: List[Any] = []

        for msg in deduped:

            ts = None

            if isinstance(msg, dict):

                ts = msg.get("_timestamp", msg.get("timestamp"))

            else:

                ts = getattr(msg, "_timestamp", None) or getattr(msg, "timestamp", None)

            if ts is not None:

                try:

                    timestamped.append((float(ts), msg))

                except (TypeError, ValueError):

                    untimed.append(msg)

            else:

                untimed.append(msg)



        if timestamped:

            timestamped.sort(key=lambda x: x[0])

            sorted_msgs = [msg for _, msg in timestamped]

        else:

            sorted_msgs = deduped



        result = []

        i = 0

        while i < len(sorted_msgs):

            msg = sorted_msgs[i]

            role = self._get_role(msg)



            if role == "assistant" and self._has_tool_use(msg):

                tool_use_ids = set()

                content = msg.content if hasattr(msg, 'content') else msg.get("content", [])

                if content is None:

                    content = []

                if isinstance(content, list):

                    for block in content:

                        if isinstance(block, dict) and block.get("type") == "tool_use":

                            tid = block.get("id", "")

                            if tid:

                                tool_use_ids.add(tid)



                result.append(msg)

                i += 1



                while i < len(sorted_msgs):

                    next_msg = sorted_msgs[i]

                    next_role = self._get_role(next_msg)

                    if next_role == "tool":

                        result.append(next_msg)

                        i += 1

                    elif next_role == "assistant" and self._has_tool_use(next_msg):

                        break

                    else:

                        break

            else:

                result.append(msg)

                i += 1



        if untimed and not timestamped:

            return deduped



        removed = len(messages) - len(result)

        if removed > 0:

            logger.info(

                "[ContextMgr] action=defragment_messages original=%d deduped=%d result=%d removed=%d",

                len(messages), len(deduped), len(result), removed,

            )



        return result



    def _defragment_summary(self, summary: str) -> str:

        if not summary or not summary.strip():

            return summary



        sections: Dict[str, List[str]] = {}

        section_order: List[str] = []

        current_header = "Uncategorized"

        if "Uncategorized" not in section_order:

            section_order.append("Uncategorized")



        for line in summary.split("\n"):

            header_match = _re.match(r'^##\s+(.+)', line)

            if header_match:

                current_header = header_match.group(1).strip()

                if current_header not in sections:

                    sections[current_header] = []

                    section_order.append(current_header)

            else:

                if current_header not in sections:

                    sections[current_header] = []

                stripped = line.strip()

                if stripped:

                    sections[current_header].append(stripped)



        for header in sections:

            seen: set[str] = set()

            unique_entries = []

            for entry in sections[header]:

                key = entry.lower()[:80]

                if key not in seen:

                    seen.add(key)

                    unique_entries.append(entry)

            sections[header] = unique_entries



        priority_order = [

            "Task Overview", "Current State", "Key Decisions",

            "Critical Instructions", "Files & Resources",

            "Errors & Resolutions", "Tool Execution Log",

            "User Requests", "Next Steps",

        ]



        reordered: List[str] = []

        remaining_headers = list(section_order)



        for priority_header in priority_order:

            for h in remaining_headers:

                if priority_header.lower() in h.lower():

                    reordered.append(h)

                    remaining_headers.remove(h)

                    break



        reordered.extend(remaining_headers)



        result_parts = []

        for header in reordered:

            if header in sections and sections[header]:

                result_parts.append(f"## {header}")

                for entry in sections[header]:

                    result_parts.append(entry)

                result_parts.append("")



        if not result_parts:

            return summary



        defragged = "\n".join(result_parts).strip()

        original_len = len(summary)

        defragged_len = len(defragged)



        if defragged_len != original_len:

            logger.info(

                "[ContextMgr] action=defragment_summary original=%d defragged=%d sections=%d",

                original_len, defragged_len, len(reordered),

            )



        return defragged



    def check_coherence(

        self,

        messages: list,

        summary: str = "",

    ) -> tuple[bool, list[str]]:

        """Verify the conversation makes sense after compaction.



        Checks:

        1. Conversation flow is logical (no missing references)

        2. Tool calls have corresponding results

        3. Summary doesn't contradict remaining messages

        4. No orphaned tool results (results without preceding tool_use)



        Args:

            messages: Current message list after compaction.

            summary: Compressed summary (if any).



        Returns:

            Tuple of (is_coherent, list_of_issues).

        """

        issues: list[str] = []



        if not messages:

            if summary:

                return (True, [])

            return (False, ["No messages and no summary - conversation is empty"])



        tool_use_ids: set[str] = set()

        tool_result_ids: set[str] = set()

        tool_use_msg_indices: dict[str, int] = {}

        tool_result_msg_indices: dict[str, int] = {}



        for i, msg in enumerate(messages):

            role = self._get_role(msg)

            content = None

            if isinstance(msg, dict):

                content = msg.get("content", "")

            else:

                content = getattr(msg, "content", "")



            if content is None:

                content = ""



            if isinstance(content, list):

                for block in content:

                    if isinstance(block, dict):

                        if block.get("type") == "tool_use":

                            tid = block.get("id", "")

                            if tid:

                                tool_use_ids.add(tid)

                                tool_use_msg_indices[tid] = i

                        elif block.get("type") == "tool_result":

                            tuid = block.get("tool_use_id", "")

                            if tuid:

                                tool_result_ids.add(tuid)

                                tool_result_msg_indices[tuid] = i



            if role == "tool":

                if isinstance(msg, dict):

                    tuid = msg.get("tool_call_id", "")

                else:

                    tuid = getattr(msg, "tool_call_id", "")

                if tuid:

                    tool_result_ids.add(tuid)

                    tool_result_msg_indices[tuid] = i



        orphaned_results = tool_result_ids - tool_use_ids

        if orphaned_results:

            for tid in list(orphaned_results)[:5]:

                idx = tool_result_msg_indices.get(tid, -1)

                issues.append(

                    f"Orphaned tool result at msg#{idx}: result for tool_call_id='{tid}' "

                    f"has no matching tool_use"

                )



        orphaned_uses = tool_use_ids - tool_result_ids

        if orphaned_uses and len(orphaned_uses) <= 5:

            for tid in list(orphaned_uses)[:3]:

                idx = tool_use_msg_indices.get(tid, -1)

                issues.append(

                    f"Pending tool call at msg#{idx}: tool_use id='{tid}' "

                    f"has no matching result (may be in-progress)"

                )



        prev_role = ""

        for i, msg in enumerate(messages):

            role = self._get_role(msg)

            if role == "tool" and prev_role not in ("assistant", "tool"):

                issues.append(

                    f"Unexpected tool result at msg#{i}: tool message follows "

                    f"'{prev_role}' instead of 'assistant' or 'tool'"

                )

            prev_role = role



        if summary and messages:

            summary_lower = summary.lower()

            for msg in messages:

                role = self._get_role(msg)

                if role == "user":

                    text = self._get_content_text(msg)

                    if text:

                        msg_lower = text.lower()

                        contradiction_patterns = [

                            ("don't", "do"),

                            ("not", ""),

                            ("never", "always"),

                            ("不可能", "已经"),

                            ("不要", "要"),

                        ]

                        for neg, pos in contradiction_patterns:

                            if neg in msg_lower and pos in summary_lower:

                                pass



        if messages:

            first_role = self._get_role(messages[0])

            if first_role not in ("system", "user"):

                issues.append(

                    f"Conversation starts with '{first_role}' role, expected 'system' or 'user'"

                )



        is_coherent = len(issues) == 0 or all(

            "may be in-progress" in issue for issue in issues

        )



        if issues:

            critical = [i for i in issues if "may be in-progress" not in i]

            if critical:

                logger.info(

                    "[ContextMgr] action=coherence_check is_coherent=%s issues=%d critical=%d",

                    is_coherent, len(issues), len(critical),

                )



        return (is_coherent, issues)



    def diagnose_health(

        self,

        messages: list,

        token_counts: Optional[list[int]] = None,

    ) -> ContextHealthReport:

        """Diagnose the health of the current context state.



        Performs a comprehensive analysis of message structure,

        token distribution, and coherence to produce a health report.



        Args:

            messages: Current message list.

            token_counts: Optional token counts per message.



        Returns:

            ContextHealthReport with diagnostics.

        """

        self._health_check_count += 1

        report = ContextHealthReport()

        report.total_messages = len(messages)

        warnings: list[str] = []



        if not messages:

            report.health_status = "empty"

            report.warnings = ["上下文为空 / Context is empty"]

            return report



        layer_dist: dict[str, int] = {}

        for msg in messages:

            role = self._get_role(msg)

            layer_dist[role] = layer_dist.get(role, 0) + 1

        report.layer_distribution = layer_dist



        if token_counts and len(token_counts) == len(messages):

            report.total_estimated_tokens = sum(token_counts)

        else:

            report.total_estimated_tokens = sum(self.estimate_messages_tokens(messages))



        total_budget = self.budget.total

        if total_budget > 0:

            report.budget_utilization = report.total_estimated_tokens / total_budget



        tool_tokens = 0

        est_counts = token_counts if (token_counts and len(token_counts) == len(messages)) else self.estimate_messages_tokens(messages)

        for i, tc in enumerate(est_counts):

            if self._get_role(messages[i]) == "tool":

                tool_tokens += tc

        if report.total_estimated_tokens > 0:

            report.compression_ratio = tool_tokens / report.total_estimated_tokens



        is_coherent, issues = self.check_coherence(messages)

        for issue in issues:

            if "Orphaned" in issue:

                report.orphaned_tool_results += 1

            elif "Pending" in issue:

                report.pending_tool_calls += 1



        seen_ids: set[str] = set()

        dup_count = 0

        for msg in messages:

            msg_id = ""

            if isinstance(msg, dict):

                msg_id = msg.get("id", "")

            else:

                msg_id = getattr(msg, "id", "")

            if msg_id:

                if msg_id in seen_ids:

                    dup_count += 1

                seen_ids.add(msg_id)

        report.duplicate_messages = dup_count



        if report.budget_utilization > 0.9:

            warnings.append(

                f"上下文利用率过高 ({report.budget_utilization:.0%}) / "

                f"Budget utilization critical ({report.budget_utilization:.0%})"

            )

        if report.orphaned_tool_results > 3:

            warnings.append(

                f"孤立工具结果过多 ({report.orphaned_tool_results}) / "

                f"Too many orphaned tool results ({report.orphaned_tool_results})"

            )

        if dup_count > 0:

            warnings.append(

                f"发现 {dup_count} 条重复消息 / Found {dup_count} duplicate messages"

            )

        if not is_coherent:

            warnings.append(

                "上下文连贯性检查未通过 / Context coherence check failed"

            )



        report.warnings = warnings[:self.MAX_HEALTH_WARNINGS]



        if not warnings:

            report.health_status = "healthy"

        elif len(warnings) <= 2 and report.budget_utilization < 0.95:

            report.health_status = "warning"

        else:

            report.health_status = "critical"



        logger.info(

            "[ContextMgr] action=health_diagnosis status=%s messages=%d tokens=%d utilization=%.1f%% issues=%d",

            report.health_status, report.total_messages, report.total_estimated_tokens,

            report.budget_utilization * 100, len(warnings),

        )



        return report



    def get_retrieval_stats(self) -> Dict[str, Any]:

        """Get retrieval statistics."""

        if not self._retrieval_history:

            return {"total_retrievals": 0, "health_checks": self._health_check_count}



        total_tokens = sum(

            sum(h.get("token_usage", {}).values())

            for h in self._retrieval_history

        )



        return {

            "total_retrievals": len(self._retrieval_history),

            "average_tokens": total_tokens / len(self._retrieval_history),

            "health_checks": self._health_check_count,

            "recent_queries": [

                {"query": h.get("query"), "tokens": sum(h.get("token_usage", {}).values())}

                for h in self._retrieval_history[-5:]

            ],

        }



    @staticmethod

    def token_accounting(

        messages: list,

        token_counts: list[int],

    ) -> dict:

        if not messages or not token_counts or len(messages) != len(token_counts):

            return {

                "system": 0, "user": 0, "assistant": 0, "tool": 0,

                "summary": 0, "tools_schema": 0,

                "total": 0, "waste_ratio": 0.0, "efficiency": 0.0,

            }



        breakdown = {

            "system": 0,

            "user": 0,

            "assistant": 0,

            "tool": 0,

            "summary": 0,

            "tools_schema": 0,

        }



        for idx, msg in enumerate(messages):

            tc = token_counts[idx]

            role = ""

            content = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = str(msg.get("content", ""))

            else:

                role = getattr(msg, "role", "")

                content = str(getattr(msg, "content", "") or "")



            if role == "system":

                content_lower = content.lower()

                if "summary of previous" in content_lower or "compressed" in content_lower:

                    breakdown["summary"] += tc

                elif "tool" in content_lower or "function" in content_lower:

                    breakdown["tools_schema"] += tc

                else:

                    breakdown["system"] += tc

            elif role == "user":

                breakdown["user"] += tc

            elif role == "assistant":

                has_tool_use = False

                if isinstance(msg, dict):

                    c = msg.get("content", "")

                    if isinstance(c, list):

                        has_tool_use = any(

                            isinstance(b, dict) and b.get("type") == "tool_use"

                            for b in c

                        )

                else:

                    c = getattr(msg, "content", "")

                    if isinstance(c, list):

                        has_tool_use = any(

                            isinstance(b, dict) and b.get("type") == "tool_use"

                            for b in c

                        )

                if has_tool_use:

                    breakdown["tool"] += tc

                else:

                    breakdown["assistant"] += tc

            elif role == "tool":

                breakdown["tool"] += tc

            else:

                breakdown["assistant"] += tc



        total = sum(breakdown.values())

        useful_tokens = breakdown["system"] + breakdown["user"] + breakdown["assistant"] + breakdown["summary"]

        waste_ratio = round(breakdown["tool"] / total, 3) if total > 0 else 0.0

        efficiency = round(useful_tokens / total, 3) if total > 0 else 0.0



        return {

            **breakdown,

            "total": total,

            "waste_ratio": waste_ratio,

            "efficiency": efficiency,

        }



    @staticmethod

    def compute_context_health_score(

        message_count: int,

        estimated_tokens: int,

        max_context_tokens: int = 128000,

        summary_length: int = 0,

        tool_result_ratio: float = 0.0,

    ) -> dict:

        utilization = estimated_tokens / max(1, max_context_tokens)

        token_health = max(0, 1.0 - utilization)



        msg_health = 1.0

        if message_count > 100:

            msg_health = max(0, 1.0 - (message_count - 100) / 200)

        elif message_count > 50:

            msg_health = max(0, 1.0 - (message_count - 50) / 200)



        summary_health = min(1.0, summary_length / 500) if summary_length > 0 else 0.5



        tool_health = max(0, 1.0 - tool_result_ratio)



        overall = (

            token_health * 0.4

            + msg_health * 0.25

            + summary_health * 0.15

            + tool_health * 0.2

        )



        if overall > 0.7:

            status = "healthy"

        elif overall > 0.4:

            status = "warning"

        else:

            status = "critical"



        return {

            "overall_score": round(overall, 3),

            "status": status,

            "token_health": round(token_health, 3),

            "message_health": round(msg_health, 3),

            "summary_health": round(summary_health, 3),

            "tool_health": round(tool_health, 3),

            "utilization": round(utilization, 3),

        }





