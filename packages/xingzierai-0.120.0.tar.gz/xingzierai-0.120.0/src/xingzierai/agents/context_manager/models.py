# -*- coding: utf-8 -*-
"""Data models and enumerations for context management."""

from __future__ import annotations
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

class ContextLayer(str, Enum):

    """Layers of context in the memory hierarchy.



    L0: System prompt (always preserved, never compressed)

    L1: Task state (current task, constraints, anchors)

    L2: Recent context (last N exchanges, preserved)

    L3: Summary (compressed older context)

    """

    SYSTEM = "system"       # L0 - Never compressed

    TASK_STATE = "task"     # L1 - Instruction anchors

    RECENT = "recent"       # L2 - Last N exchanges

    SUMMARY = "summary"     # L3 - Compressed history

    HISTORY = "history"     # L3 - Uncompressed history (pre-summary)

    TOOLS = "tools"         # Tool schemas




class ContextSegment:

    """A segment of context."""

    layer: ContextLayer

    content: str

    token_count: int

    timestamp: float

    metadata: Dict[str, Any] = field(default_factory=dict)




class ContextBudget:

    """Token budget for each context layer.



    L0 (system): Always preserved, never compressed

    L1 (task_state): Instruction anchors, current task constraints

    L2 (recent): Last N exchanges, preserved during compaction

    L3 (summary): Compressed older context

    """

    system: int = 2000

    task_state: int = 1000

    summary: int = 3000

    history: int = 8000

    recent: int = 4000

    tools: int = 2000



    @property

    def total(self) -> int:

        return self.system + self.task_state + self.summary + self.history + self.recent + self.tools



    def enforce_budget(

        self,

        messages: list,

        token_counts: list,

    ) -> list:

        if not messages or len(messages) != len(token_counts):

            return list(messages) if messages else []



        layer_map: dict[str, list[tuple[int, Any, int]]] = {

            ContextLayer.SYSTEM.value: [],

            ContextLayer.TASK_STATE.value: [],

            ContextLayer.SUMMARY.value: [],

            ContextLayer.HISTORY.value: [],

            ContextLayer.RECENT.value: [],

            ContextLayer.TOOLS.value: [],

        }

        budget_map: dict[str, int] = {

            ContextLayer.SYSTEM.value: self.system,

            ContextLayer.TASK_STATE.value: self.task_state,

            ContextLayer.SUMMARY.value: self.summary,

            ContextLayer.HISTORY.value: self.history,

            ContextLayer.RECENT.value: self.recent,

            ContextLayer.TOOLS.value: self.tools,

        }



        for idx, msg in enumerate(messages):

            tc = token_counts[idx]

            role = ""

            content = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = str(msg.get("content", ""))

            else:

                role = getattr(msg, "role", "")

                content = str(getattr(msg, "content", "") or "")



            if role == "system":

                content_lower = content.lower()

                if "summary of previous" in content_lower or "compressed" in content_lower:

                    layer = ContextLayer.SUMMARY.value

                elif "task" in content_lower or "instruction" in content_lower or "anchor" in content_lower:

                    layer = ContextLayer.TASK_STATE.value

                elif "tool" in content_lower or "function" in content_lower:

                    layer = ContextLayer.TOOLS.value

                else:

                    layer = ContextLayer.SYSTEM.value

            elif role == "tool":

                layer = ContextLayer.TOOLS.value

            elif role == "user":

                layer = ContextLayer.RECENT.value

            elif role == "assistant":

                layer = ContextLayer.HISTORY.value

            else:

                layer = ContextLayer.HISTORY.value



            layer_map[layer].append((idx, msg, tc))



        result_indices: set[int] = set()

        for layer_name, entries in layer_map.items():

            budget = budget_map.get(layer_name, 0)

            used = 0

            for idx, msg, tc in entries:

                if used + tc <= budget:

                    result_indices.add(idx)

                    used += tc

                else:

                    remaining = budget - used

                    if remaining > 50:

                        result_indices.add(idx)

                    break



        return [messages[i] for i in sorted(result_indices)]


class RetrievalResult:

    """Result from memory retrieval."""

    content: str

    source: str

    score: float

    timestamp: float

    metadata: Dict[str, Any] = field(default_factory=dict)


class ContextHealthReport:

    """Health report for context management state."""

    total_messages: int = 0

    total_estimated_tokens: int = 0

    budget_utilization: float = 0.0

    layer_distribution: Dict[str, int] = field(default_factory=dict)

    orphaned_tool_results: int = 0

    pending_tool_calls: int = 0

    duplicate_messages: int = 0

    compression_ratio: float = 0.0

    health_status: str = "unknown"

    warnings: List[str] = field(default_factory=list)



    def to_dict(self) -> Dict[str, Any]:

        return {

            "total_messages": self.total_messages,

            "total_estimated_tokens": self.total_estimated_tokens,

            "budget_utilization": round(self.budget_utilization, 3),

            "layer_distribution": self.layer_distribution,

            "orphaned_tool_results": self.orphaned_tool_results,

            "pending_tool_calls": self.pending_tool_calls,

            "duplicate_messages": self.duplicate_messages,

            "compression_ratio": round(self.compression_ratio, 3),

            "health_status": self.health_status,

            "warnings": self.warnings,

        }


class ConversationState(str, Enum):

    IDLE = "idle"

    WORKING = "working"

    WAITING_FOR_INPUT = "waiting_for_input"

    TOOL_EXECUTION = "tool_execution"

    COMPACTION = "compaction"

    ERROR = "error"




class ErrorRecoveryStrategy(str, Enum):

    RETRY = "retry"

    COMPACT = "compact"

    TRIM = "trim"

    FALLBACK_MODEL = "fallback_model"

    GRACEFUL_DEGRADE = "graceful_degrade"




class AdaptiveCompactionStrategy(str, Enum):

    CONSERVATIVE = "conservative"

    BALANCED = "balanced"

    AGGRESSIVE = "aggressive"

    EMERGENCY = "emergency"



