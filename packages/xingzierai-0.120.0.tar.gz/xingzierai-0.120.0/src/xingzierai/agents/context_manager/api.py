# -*- coding: utf-8 -*-
"""Unified context health API - aggregates all subsystems."""

from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional
from .models import ConversationState
from .core import ActiveContextManager
from .compaction import AdaptiveCompactionController
from .monitoring import ContextHealthMonitor, ContextPressureMonitor, ContextMetricsAggregator, ContextSnapshotManager
from .budget import ContextBudgetManager
from .state import ConversationStateMachine
from .resilience import ContextAwareErrorRecovery, ContextCircuitBreaker, ContextOperationRateLimiter
from .guard import ContextWindowGuard, TokenEstimationCache

logger = logging.getLogger(__name__)

class ContextHealthAPI:

    """Unified API for context health diagnostics and monitoring.



    Aggregates data from all context subsystems:

    - ActiveContextManager health reports

    - ContextPressureMonitor trends

    - ContextHealthMonitor alerts

    - TokenEstimationCache stats

    - ContextWindowGuard stats

    - AdaptiveCompactionController stats

    - ConversationStateMachine state

    """



    _instance: "ContextHealthAPI | None" = None



    def __init__(self):

        self._ctx_manager = ActiveContextManager()

        self._pressure_monitor = ContextPressureMonitor()

        self._health_monitor = ContextHealthMonitor()

        self._token_cache = TokenEstimationCache.get_instance()

        self._window_guard = ContextWindowGuard()

        self._compaction_controller = AdaptiveCompactionController()

        self._state_machine = ConversationStateMachine()

        self._error_recovery = ContextAwareErrorRecovery.get_instance()

        self._circuit_breaker = ContextCircuitBreaker()

        self._rate_limiter = ContextOperationRateLimiter()

        self._metrics_aggregator = ContextMetricsAggregator()

        self._budget_manager = ContextBudgetManager()

        self._snapshot_manager = ContextSnapshotManager()

        self._last_full_report_time: float = 0.0

        self._report_count: int = 0



    @classmethod

    def get_instance(cls) -> "ContextHealthAPI":

        if cls._instance is None:

            cls._instance = cls()

        return cls._instance



    def get_full_report(self, messages: list = None) -> dict:

        self._report_count += 1

        self._last_full_report_time = time.time()



        report = {

            "timestamp": time.time(),

            "report_count": self._report_count,

            "state_machine": self._state_machine.get_state_stats(),

            "pressure": self._pressure_monitor.get_stats(),

            "health_monitor": self._health_monitor.get_stats(),

            "token_cache": self._token_cache.get_stats(),

            "window_guard": self._window_guard.get_stats(),

            "compaction": self._compaction_controller.get_stats(),

            "error_recovery": self._error_recovery.get_recovery_stats(),

            "circuit_breaker": self._circuit_breaker.get_stats(),

            "rate_limiter": self._rate_limiter.get_stats(),

            "metrics": self._metrics_aggregator.get_stats(),

            "budget": self._budget_manager.get_budget_report(),

            "snapshots": self._snapshot_manager.get_stats(),

        }



        if messages is not None:

            health = self._ctx_manager.diagnose_health(messages)

            report["context_health"] = health.to_dict()

            token_counts = self._ctx_manager.estimate_messages_tokens(messages)

            report["token_accounting"] = self._ctx_manager.token_accounting(messages, token_counts)



        return report



    def get_summary(self) -> dict:

        return {

            "state": self._state_machine.current_state().value,

            "can_compact": self._state_machine.can_compact(),

            "pressure_trend": self._pressure_monitor.get_trend(),

            "time_to_critical": self._pressure_monitor.predict_time_to_critical(),

            "token_cache_hit_rate": self._token_cache.get_stats().get("hit_rate", 0.0),

            "guard_trigger_rate": self._window_guard.get_stats().get("trigger_rate", 0.0),

            "circuit_breaker_state": self._circuit_breaker.get_state(),

            "budget_status": self._budget_manager.get_budget_report().get("budget_status", "unknown"),

            "snapshot_count": len(self._snapshot_manager._snapshots),

            "report_count": self._report_count,

        }



    def record_pressure(self, pressure: float, message_count: int, estimated_tokens: int) -> None:

        self._pressure_monitor.record(pressure, message_count, estimated_tokens)

        self._health_monitor.record(pressure, message_count, estimated_tokens)



    def transition_state(self, new_state: ConversationState) -> bool:

        return self._state_machine.transition(new_state)



    def get_subsystem(self, name: str) -> Any:

        subsystems = {

            "pressure_monitor": self._pressure_monitor,

            "health_monitor": self._health_monitor,

            "token_cache": self._token_cache,

            "window_guard": self._window_guard,

            "compaction_controller": self._compaction_controller,

            "state_machine": self._state_machine,

            "error_recovery": self._error_recovery,

            "circuit_breaker": self._circuit_breaker,

            "rate_limiter": self._rate_limiter,

            "metrics_aggregator": self._metrics_aggregator,

            "budget_manager": self._budget_manager,

            "snapshot_manager": self._snapshot_manager,

        }

        return subsystems.get(name)



