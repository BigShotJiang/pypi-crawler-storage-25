# -*- coding: utf-8 -*-
"""Context budget planning, token budget allocation, memory pool management."""

from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional
from .models import ContextBudget, ContextLayer

logger = logging.getLogger(__name__)

class ContextWindowBudgetPlanner:

    """Dynamic context window budget planner.



    Allocates token budgets to different context layers based on

    the current conversation state and query complexity.

    """



    def __init__(self, max_context_tokens: int = 128000):

        self._max_context_tokens = max_context_tokens

        self._allocation_history: deque = deque(maxlen=100)



    def plan_budget(

        self,

        query_complexity: str = "moderate",

        current_message_count: int = 0,

        has_active_tools: bool = False,

    ) -> ContextBudget:

        total = self._max_context_tokens

        if query_complexity == "simple":

            budget = ContextBudget(

                system=min(2000, total // 20),

                task_state=min(500, total // 40),

                summary=min(2000, total // 10),

                history=min(4000, total // 5),

                recent=min(2000, total // 10),

                tools=min(1000, total // 20),

            )

        elif query_complexity == "complex":

            budget = ContextBudget(

                system=min(3000, total // 15),

                task_state=min(1500, total // 20),

                summary=min(5000, total // 6),

                history=min(15000, total // 2),

                recent=min(6000, total // 8),

                tools=min(3000, total // 10),

            )

        else:

            budget = ContextBudget(

                system=min(2500, total // 17),

                task_state=min(1000, total // 30),

                summary=min(3000, total // 8),

                history=min(8000, total // 4),

                recent=min(4000, total // 10),

                tools=min(2000, total // 15),

            )



        if has_active_tools:

            budget.tools = min(budget.tools + 1000, total // 10)

            budget.history = max(budget.history - 1000, total // 10)



        if current_message_count > 100:

            budget.summary = min(budget.summary + 2000, total // 5)

            budget.history = max(budget.history - 2000, total // 10)



        self._allocation_history.append({

            "timestamp": time.time(),

            "complexity": query_complexity,

            "message_count": current_message_count,

            "budget_total": budget.total,

        })



        return budget



    def get_stats(self) -> dict:

        return {

            "max_context_tokens": self._max_context_tokens,

            "allocations": len(self._allocation_history),

        }




class _PoolSlot:

    __slots__ = ("layer", "budget", "used", "entries")



    def __init__(self, layer: ContextLayer, budget: int) -> None:

        self.layer = layer

        self.budget = budget

        self.used = 0

        self.entries: list[tuple[str, int]] = []



    def check_in(self, content: str, tokens: int) -> bool:

        if self.used + tokens > self.budget:

            while self.entries and self.used + tokens > self.budget:

                _, evicted_tokens = self.entries.pop(0)

                self.used -= evicted_tokens

            if self.used + tokens > self.budget:

                return False

        self.entries.append((content, tokens))

        self.used += tokens

        return True



    def check_out(self) -> str:

        if not self.entries:

            return ""

        content, tokens = self.entries.pop(0)

        self.used = max(0, self.used - tokens)

        return content




class ContextPool:

    """Pre-allocated memory pool for context window slots.



    Each context layer gets a fixed token budget.  Content is checked in

    to a slot; when the slot is full, older content is automatically

    evicted (FIFO).  This prevents any single type of content from

    monopolizing the context window.

    """



    MAX_ENTRIES_PER_SLOT = 200



    def __init__(self, budget: ContextBudget | None = None) -> None:

        self._budget = budget or ContextBudget()

        self._slots: dict[str, _PoolSlot] = {

            ContextLayer.SYSTEM.value: _PoolSlot(ContextLayer.SYSTEM, self._budget.system),

            ContextLayer.TASK_STATE.value: _PoolSlot(ContextLayer.TASK_STATE, self._budget.task_state),

            ContextLayer.RECENT.value: _PoolSlot(ContextLayer.RECENT, self._budget.recent),

            ContextLayer.SUMMARY.value: _PoolSlot(ContextLayer.SUMMARY, self._budget.summary),

            ContextLayer.HISTORY.value: _PoolSlot(ContextLayer.HISTORY, self._budget.history),

            ContextLayer.TOOLS.value: _PoolSlot(ContextLayer.TOOLS, self._budget.tools),

        }



    def check_in(self, layer: ContextLayer, content: str, tokens: int) -> bool:

        slot = self._slots.get(layer.value)

        if slot is None:

            return False

        result = slot.check_in(content, tokens)

        if len(slot.entries) > self.MAX_ENTRIES_PER_SLOT:

            slot.entries = slot.entries[-self.MAX_ENTRIES_PER_SLOT:]

        return result



    def check_out(self, layer: ContextLayer) -> str:

        slot = self._slots.get(layer.value)

        if slot is None:

            return ""

        return slot.check_out()



    def get_usage(self) -> dict[str, dict[str, int]]:

        result: dict[str, dict[str, int]] = {}

        for name, slot in self._slots.items():

            result[name] = {

                "budget": slot.budget,

                "used": slot.used,

                "entries": len(slot.entries),

                "available": slot.budget - slot.used,

            }

        return result



    def get_health(self) -> dict:

        total_budget = 0

        total_used = 0

        critical_layers: list[str] = []

        for name, slot in self._slots.items():

            total_budget += slot.budget

            total_used += slot.used

            if slot.budget > 0 and slot.used / slot.budget > 0.9:

                critical_layers.append(name)

        utilization = total_used / max(1, total_budget)

        if utilization > 0.9:

            status = "critical"

        elif utilization > 0.7:

            status = "warning"

        else:

            status = "healthy"

        return {

            "status": status,

            "utilization": round(utilization, 3),

            "total_budget": total_budget,

            "total_used": total_used,

            "critical_layers": critical_layers,

        }



    def reset(self) -> None:

        for slot in self._slots.values():

            slot.entries.clear()

            slot.used = 0



    def smart_evict(self, target_layer: ContextLayer, needed_tokens: int) -> int:

        """Evict entries from lower-priority layers to make room.



        Priority order (lowest first): HISTORY, SUMMARY, TASK_STATE, RECENT

        SYSTEM is never evicted.



        Args:

            target_layer: The layer that needs more space.

            needed_tokens: How many tokens are needed.



        Returns:

            Number of tokens freed.

        """

        if target_layer == ContextLayer.SYSTEM:

            return 0



        freed = 0

        eviction_order = [

            ContextLayer.HISTORY,

            ContextLayer.SUMMARY,

            ContextLayer.TASK_STATE,

        ]



        for layer in eviction_order:

            if layer == target_layer:

                continue

            slot = self._slots.get(layer.value)

            if slot is None:

                continue

            while slot.entries and freed < needed_tokens:

                content, tokens = slot.entries.pop(0)

                slot.used = max(0, slot.used - tokens)

                freed += tokens

                logger.info(

                    "[ContextMgr] action=smart_evict from=%s tokens=%d freed_total=%d needed=%d",

                    layer.value, tokens, freed, needed_tokens,

                )

            if freed >= needed_tokens:

                break



        return freed




class ContextBudgetManager:

    """Manages context token budget allocation across subsystems.



    Tracks how the context window budget is allocated and consumed:

    - System prompt tokens

    - Conversation history tokens

    - Tool call/result tokens

    - Reserved tokens for response generation

    - Safety margin



    Provides budget planning to prevent context overflow before it happens.

    """



    MAX_BUDGET_HISTORY = 200



    def __init__(self, max_context_tokens: int = 128 * 1024):

        self._max_context_tokens = max_context_tokens

        self._safety_margin = 0.1

        self._response_reserve = 0.15

        self._budget_history: list[dict] = []

        self._allocation = {

            "system_prompt": 0,

            "conversation_history": 0,

            "tool_calls": 0,

            "tool_results": 0,

            "compressed_summary": 0,

            "reserved_response": int(max_context_tokens * self._response_reserve),

            "safety_margin": int(max_context_tokens * self._safety_margin),

        }



    def update_allocation(self, **kwargs: int) -> None:

        for key, value in kwargs.items():

            if key in self._allocation:

                self._allocation[key] = value

        self._budget_history.append({

            "timestamp": time.time(),

            "allocation": dict(self._allocation),

            "total_consumed": self._get_consumed(),

            "remaining": self._get_remaining(),

        })

        if len(self._budget_history) > self.MAX_BUDGET_HISTORY:

            self._budget_history = self._budget_history[-self.MAX_BUDGET_HISTORY:]



    def _get_consumed(self) -> int:

        skip_keys = {"reserved_response", "safety_margin"}

        return sum(v for k, v in self._allocation.items() if k not in skip_keys)



    def _get_remaining(self) -> int:

        consumed = self._get_consumed()

        reserved = self._allocation["reserved_response"] + self._allocation["safety_margin"]

        return max(0, self._max_context_tokens - consumed - reserved)



    def get_budget_report(self) -> dict:

        consumed = self._get_consumed()

        remaining = self._get_remaining()

        total_available = self._max_context_tokens

        utilization = consumed / max(1, total_available)

        return {

            "max_context_tokens": self._max_context_tokens,

            "consumed_tokens": consumed,

            "remaining_tokens": remaining,

            "reserved_response": self._allocation["reserved_response"],

            "safety_margin": self._allocation["safety_margin"],

            "utilization": round(utilization, 3),

            "allocation": dict(self._allocation),

            "budget_status": (

                "critical" if utilization > 0.9

                else "warning" if utilization > 0.75

                else "healthy"

            ),

        }



    def can_fit(self, estimated_tokens: int) -> bool:

        return estimated_tokens <= self._get_remaining()



    def get_stats(self) -> dict:

        return {

            "budget_reports": len(self._budget_history),

            "current_budget": self.get_budget_report(),

        }



