# -*- coding: utf-8 -*-
"""Conversation state machine for context lifecycle management."""

from __future__ import annotations
import logging
import time
from typing import Any, Dict, List, Optional
from .models import ConversationState

logger = logging.getLogger(__name__)

_VALID_TRANSITIONS: dict[ConversationState, set[ConversationState]] = {

    ConversationState.IDLE: {

        ConversationState.WORKING,

        ConversationState.WAITING_FOR_INPUT,

        ConversationState.ERROR,

    },

    ConversationState.WORKING: {

        ConversationState.TOOL_EXECUTION,

        ConversationState.COMPACTION,

        ConversationState.WAITING_FOR_INPUT,

        ConversationState.IDLE,

        ConversationState.ERROR,

    },

    ConversationState.WAITING_FOR_INPUT: {

        ConversationState.WORKING,

        ConversationState.IDLE,

        ConversationState.ERROR,

    },

    ConversationState.TOOL_EXECUTION: {

        ConversationState.WORKING,

        ConversationState.COMPACTION,

        ConversationState.WAITING_FOR_INPUT,

        ConversationState.IDLE,

        ConversationState.ERROR,

    },

    ConversationState.COMPACTION: {

        ConversationState.WORKING,

        ConversationState.IDLE,

        ConversationState.ERROR,

    },

    ConversationState.ERROR: {

        ConversationState.IDLE,

        ConversationState.WORKING,

    },

}



_NON_COMPACTABLE_STATES = frozenset({

    ConversationState.TOOL_EXECUTION,

    ConversationState.COMPACTION,

})


class ConversationStateMachine:

    """State machine for tracking conversation state.



    States: idle, working, waiting_for_input, tool_execution, compaction, error



    The state machine enforces valid transitions and uses the current

    state to inform compaction decisions. For example, compaction is

    not allowed during tool execution or during an ongoing compaction.



    Usage:

        sm = ConversationStateMachine()

        sm.transition(ConversationState.WORKING)

        sm.transition(ConversationState.TOOL_EXECUTION)

        assert not sm.can_compact()

        sm.transition(ConversationState.WORKING)

        assert sm.can_compact()

    """



    MAX_TRANSITION_HISTORY = 100



    def __init__(self) -> None:

        self._state = ConversationState.IDLE

        self._transition_history: list[tuple[float, ConversationState, ConversationState]] = []

        self._state_entered_at: float = time.time()

        self._total_time_by_state: dict[ConversationState, float] = {

            s: 0.0 for s in ConversationState

        }



    def current_state(self) -> ConversationState:

        return self._state



    def transition(self, new_state: ConversationState) -> bool:

        """Transition to a new state.



        Only valid transitions are allowed. Invalid transitions are

        logged and rejected.



        Args:

            new_state: The target state.



        Returns:

            True if the transition was successful, False otherwise.

        """

        if new_state == self._state:

            return True



        allowed = _VALID_TRANSITIONS.get(self._state, set())

        if new_state not in allowed:

            logger.warning(

                "[ContextMgr] action=invalid_state_transition from=%s to=%s allowed=%s",

                self._state.value, new_state.value, {s.value for s in allowed},

            )

            return False



        now = time.time()

        elapsed = now - self._state_entered_at

        self._total_time_by_state[self._state] = self._total_time_by_state.get(self._state, 0.0) + elapsed



        old_state = self._state

        self._transition_history.append((now, old_state, new_state))

        if len(self._transition_history) > self.MAX_TRANSITION_HISTORY:

            self._transition_history = self._transition_history[-self.MAX_TRANSITION_HISTORY:]



        self._state = new_state

        self._state_entered_at = now



        logger.info(

            "[ContextMgr] action=state_transition from=%s to=%s elapsed_in_old=%.1fs",

            old_state.value, new_state.value, elapsed,

        )

        return True



    def can_compact(self) -> bool:

        """Check if compaction is allowed in the current state.



        Compaction is not allowed during:

        - tool_execution: tool results may be incomplete

        - compaction: already compacting, prevent re-entrancy



        Returns:

            True if compaction is allowed, False otherwise.

        """

        return self._state not in _NON_COMPACTABLE_STATES



    def force_transition(self, new_state: ConversationState) -> None:

        """Force a state transition regardless of validity.



        Used for error recovery when the state machine needs to be

        reset to a known good state.



        Args:

            new_state: The target state.

        """

        now = time.time()

        elapsed = now - self._state_entered_at

        self._total_time_by_state[self._state] = self._total_time_by_state.get(self._state, 0.0) + elapsed



        old_state = self._state

        self._transition_history.append((now, old_state, new_state))

        if len(self._transition_history) > self.MAX_TRANSITION_HISTORY:

            self._transition_history = self._transition_history[-self.MAX_TRANSITION_HISTORY:]



        self._state = new_state

        self._state_entered_at = now



        logger.info(

            "[ContextMgr] action=force_state_transition from=%s to=%s",

            old_state.value, new_state.value,

        )



    def get_state_duration(self) -> float:

        """Get how long we've been in the current state (seconds)."""

        return time.time() - self._state_entered_at



    def get_transition_history(self, limit: int = 20) -> list[dict]:

        """Get recent transition history.



        Args:

            limit: Maximum number of transitions to return.



        Returns:

            List of transition dicts with timestamp, from, to keys.

        """

        recent = self._transition_history[-limit:]

        return [

            {

                "timestamp": ts,

                "from": old.value,

                "to": new.value,

            }

            for ts, old, new in recent

        ]



    def get_state_stats(self) -> dict:

        """Get statistics about time spent in each state.



        Returns:

            Dict mapping state name to total seconds spent.

        """

        current_elapsed = time.time() - self._state_entered_at

        stats = {}

        for state in ConversationState:

            total = self._total_time_by_state.get(state, 0.0)

            if state == self._state:

                total += current_elapsed

            stats[state.value] = round(total, 1)

        stats["current_state"] = self._state.value

        stats["current_duration"] = round(current_elapsed, 1)

        stats["can_compact"] = self.can_compact()

        stats["total_transitions"] = len(self._transition_history)

        return stats



    def is_stuck(self, threshold_seconds: float = 300.0) -> bool:

        """Detect if the state machine appears stuck in a non-idle state.



        Args:

            threshold_seconds: How long in a non-idle state before

                considering it stuck.



        Returns:

            True if the current state has been active for longer than

            the threshold and is not IDLE.

        """

        if self._state == ConversationState.IDLE:

            return False

        duration = time.time() - self._state_entered_at

        if duration > threshold_seconds:

            logger.warning(

                "[ContextMgr] action=stuck_detected state=%s duration=%.1fs threshold=%.1fs",

                self._state.value, duration, threshold_seconds,

            )

            return True

        return False



    def get_transition_rate(self, window_seconds: float = 60.0) -> float:

        """Calculate the transition rate over a recent time window.



        Args:

            window_seconds: Time window to consider.



        Returns:

            Transitions per second in the window.

        """

        if not self._transition_history:

            return 0.0

        now = time.time()

        cutoff = now - window_seconds

        recent = [t for t, _, _ in self._transition_history if t >= cutoff]

        if not recent:

            return 0.0

        return len(recent) / window_seconds



    def reset(self) -> None:

        self._state = ConversationState.IDLE

        self._state_entered_at = time.time()

        self._transition_history.clear()

        self._total_time_by_state = {s: 0.0 for s in ConversationState}



