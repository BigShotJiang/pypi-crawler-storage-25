# -*- coding: utf-8 -*-
"""Progressive context loading and pre-warming."""

from __future__ import annotations
import asyncio
import logging
import time
from typing import Any, Dict, List, Optional
from .models import ContextBudget, ContextLayer, RetrievalResult
from .core import ActiveContextManager

logger = logging.getLogger(__name__)

class ProgressiveLoader:

    """Progressive context loading - only load context layers as needed.



    Reduces initial token usage for simple queries by loading context

    in layers: system prompt + last 3 messages first, then summary,

    then full history on demand.



    Layer loading order:

    1. CORE: system prompt + last 3 messages (always loaded)

    2. SUMMARY: compressed summary of older context

    3. HISTORY: full uncompressed history

    """



    CORE_RECENT_MESSAGES = 3



    def __init__(

        self,

        budget: Optional[ContextBudget] = None,

        token_counter: Optional[Any] = None,

    ) -> None:

        self.budget = budget or ContextBudget()

        self._token_counter = token_counter

        self._loaded_layers: set[ContextLayer] = set()

        self._core_messages: list[dict] = []

        self._summary_messages: list[dict] = []

        self._history_messages: list[dict] = []

        self._system_prompt: str = ""

        self._summary_text: Optional[str] = None

        self._full_history: list[Any] = []

        self._load_stats: dict[str, Any] = {

            "total_loads": 0,

            "core_only_hits": 0,

            "summary_hits": 0,

            "history_hits": 0,

            "tokens_saved_vs_full": 0,

        }



    def load_core(

        self,

        system_prompt: str,

        recent_messages: list[Any],

    ) -> list[dict]:

        """Load the core layer: system prompt + last N messages.



        This is the minimum context needed for any query.

        """

        self._system_prompt = system_prompt

        self._core_messages = [{"role": "system", "content": system_prompt}]



        recent = recent_messages[-self.CORE_RECENT_MESSAGES:]

        for msg in recent:

            if isinstance(msg, dict):

                self._core_messages.append(msg)

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    self._core_messages.append({"role": role, "content": content})

                else:

                    self._core_messages.append({"role": role, "content": str(content)})



        self._loaded_layers.add(ContextLayer.SYSTEM)

        self._loaded_layers.add(ContextLayer.RECENT)

        self._load_stats["total_loads"] += 1

        self._load_stats["core_only_hits"] += 1



        full_token_estimate = self._estimate_full_tokens(recent_messages)

        core_token_estimate = self._estimate_messages_tokens_sync(self._core_messages)

        self._load_stats["tokens_saved_vs_full"] += max(0, full_token_estimate - core_token_estimate)



        return list(self._core_messages)



    def load_layer(self, layer: ContextLayer) -> list[dict]:

        """Load an additional context layer.



        Args:

            layer: The context layer to load (SUMMARY or HISTORY).



        Returns:

            All currently loaded messages including the new layer.

        """

        if layer in self._loaded_layers:

            return self.get_loaded_messages()



        if layer == ContextLayer.SUMMARY and self._summary_text:

            summary_msg = {

                "role": "system",

                "content": f"[Summary of previous conversation]\n{self._summary_text}",

            }

            self._summary_messages = [summary_msg]

            self._loaded_layers.add(ContextLayer.SUMMARY)

            self._load_stats["summary_hits"] += 1



        elif layer == ContextLayer.HISTORY and self._full_history:

            history_msgs = []

            for msg in self._full_history:

                if isinstance(msg, dict):

                    history_msgs.append(msg)

                else:

                    role = getattr(msg, "role", "")

                    content = getattr(msg, "content", "")

                    if isinstance(content, list):

                        history_msgs.append({"role": role, "content": content})

                    else:

                        history_msgs.append({"role": role, "content": str(content)})

            self._history_messages = history_msgs

            self._loaded_layers.add(ContextLayer.HISTORY)

            self._load_stats["history_hits"] += 1



        return self.get_loaded_messages()



    def set_summary(self, summary_text: Optional[str]) -> None:

        self._summary_text = summary_text



    def set_history(self, history: list[Any]) -> None:

        self._full_history = list(history)



    def get_loaded_messages(self) -> list[dict]:

        """Get all currently loaded messages in correct order."""

        result = []

        result.extend(self._core_messages[:1])  # system prompt

        result.extend(self._summary_messages)

        result.extend(self._history_messages)

        result.extend(self._core_messages[1:])  # recent messages

        return result



    def needs_more_context(self, model_response: str) -> bool:

        """Determine if the model response suggests more context is needed.



        Detects patterns where the model indicates it lacks context.

        """

        if ContextLayer.HISTORY in self._loaded_layers:

            return False



        need_context_patterns = [

            "i don't have enough context",

            "i need more information",

            "i cannot see the previous",

            "based on what i can see",

            "from the limited context",

            "i don't have access to",

            "没有足够的上下文",

            "需要更多信息",

            "无法看到之前的",

            "根据可见的上下文",

        ]

        response_lower = model_response.lower()

        return any(p in response_lower for p in need_context_patterns)



    def get_next_layer(self) -> Optional[ContextLayer]:

        """Get the next layer that should be loaded."""

        if ContextLayer.SUMMARY not in self._loaded_layers and self._summary_text:

            return ContextLayer.SUMMARY

        if ContextLayer.HISTORY not in self._loaded_layers and self._full_history:

            return ContextLayer.HISTORY

        return None



    def get_load_stats(self) -> dict[str, Any]:

        return dict(self._load_stats)



    def estimate_query_complexity(self, query: str) -> str:

        """Estimate the complexity of a query to determine context needs.



        Args:

            query: The user's query text.



        Returns:

            "simple", "moderate", or "complex"

        """

        if not query:

            return "simple"



        query_lower = query.lower()

        complex_indicators = [

            "analyze", "compare", "explain", "research", "investigate",

            "分析", "比较", "解释", "研究", "调查",

            "multiple", "several", "all of", "each",

            "多个", "所有", "每个",

        ]

        moderate_indicators = [

            "how", "why", "what if", "describe",

            "如何", "为什么", "描述",

        ]



        complex_count = sum(1 for ind in complex_indicators if ind in query_lower)

        moderate_count = sum(1 for ind in moderate_indicators if ind in query_lower)



        if complex_count >= 2 or len(query) > 200:

            return "complex"

        elif complex_count >= 1 or moderate_count >= 2:

            return "moderate"

        return "simple"



    def select_layers_for_query(self, query: str) -> list[ContextLayer]:

        """Select which context layers to load based on query complexity.



        Args:

            query: The user's query text.



        Returns:

            List of ContextLayer values to load.

        """

        complexity = self.estimate_query_complexity(query)

        layers = [ContextLayer.SYSTEM, ContextLayer.RECENT]



        if complexity in ("moderate", "complex"):

            layers.append(ContextLayer.SUMMARY)



        if complexity == "complex":

            layers.append(ContextLayer.HISTORY)



        logger.info(

            "[ContextMgr] action=adaptive_layer_selection complexity=%s layers=%s",

            complexity, [l.value for l in layers],

        )

        return layers



    def reset(self) -> None:

        self._loaded_layers.clear()

        self._core_messages.clear()

        self._summary_messages.clear()

        self._history_messages.clear()

        self._system_prompt = ""

        self._summary_text = None

        self._full_history.clear()



    def _estimate_full_tokens(self, all_messages: list[Any]) -> int:

        total = len(self._system_prompt) // 4

        for msg in all_messages:

            if isinstance(msg, dict):

                content = msg.get("content", "")

            else:

                content = str(getattr(msg, "content", "") or "")

            if isinstance(content, list):

                for c in content:

                    if isinstance(c, str):

                        total += len(c) // 4

                    elif isinstance(c, dict):

                        total += len(c.get("text", "")) // 4

            else:

                total += len(str(content)) // 4

        return total



    def _estimate_messages_tokens_sync(self, messages: list[dict]) -> int:

        total = 0

        for msg in messages:

            content = msg.get("content", "")

            if isinstance(content, str):

                total += len(content) // 4

            elif isinstance(content, list):

                for c in content:

                    if isinstance(c, str):

                        total += len(c) // 4

                    elif isinstance(c, dict):

                        total += len(c.get("text", "")) // 4

        return total




class ContextPreWarmer:

    """Pre-warm context by loading relevant memories before reasoning.



    Reduces cold-start latency by proactively fetching context

    that is likely to be needed based on the current query.

    """



    MAX_CACHED_QUERIES = 50

    CACHE_TTL_SECONDS = 300.0



    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):

        self._ctx_manager = ctx_manager or ActiveContextManager()

        self._query_cache: dict[str, tuple[float, list[RetrievalResult]]] = {}



    async def prewarm(

        self,

        query: str,

        history: list,

        max_results: int = 3,

    ) -> list[RetrievalResult]:

        now = time.time()

        cached = self._query_cache.get(query)

        if cached is not None:

            ts, results = cached

            if now - ts < self.CACHE_TTL_SECONDS:

                return results[:max_results]



        results = await self._ctx_manager._proactive_retrieve(query, history)

        self._query_cache[query] = (now, results)

        if len(self._query_cache) > self.MAX_CACHED_QUERIES:

            oldest_key = min(self._query_cache, key=lambda k: self._query_cache[k][0])

            del self._query_cache[oldest_key]



        return results[:max_results]



    def invalidate(self, query: Optional[str] = None) -> None:

        if query:

            self._query_cache.pop(query, None)

        else:

            self._query_cache.clear()



    def get_stats(self) -> dict:

        now = time.time()

        active = sum(

            1 for _, (ts, _) in self._query_cache.items()

            if now - ts < self.CACHE_TTL_SECONDS

        )

        return {

            "cached_queries": len(self._query_cache),

            "active_entries": active,

            "max_cache_size": self.MAX_CACHED_QUERIES,

            "cache_ttl_seconds": self.CACHE_TTL_SECONDS,

        }



