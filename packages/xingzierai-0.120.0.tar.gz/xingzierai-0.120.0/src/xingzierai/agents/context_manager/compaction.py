# -*- coding: utf-8 -*-
"""Context compaction - deduplication, topic extraction, truncation, adaptive compaction."""

from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional
from .models import AdaptiveCompactionStrategy
from .core import ActiveContextManager

logger = logging.getLogger(__name__)

class ContextCompactionManager:

    """

    Manager for time-based context compaction.



    Implements tool result compaction based on:

    - Recency (keep recent results full)

    - Time-based retention (compress older results)

    - Relevance scoring

    """



    def __init__(

        self,

        recent_n: int = 10,

        retention_days: int = 7,

        compress_older_than_days: int = 1,

    ):

        self.recent_n = recent_n

        self.retention_days = retention_days

        self.compress_older_than_days = compress_older_than_days



    async def compact_messages(

        self,

        messages: List[Any],

        get_message_time: Optional[Callable] = None,

    ) -> List[Any]:

        """Compact messages based on time and relevance.



        Args:

            messages: Messages to compact.

            get_message_time: Function to get message timestamp.



        Returns:

            Compacted messages.

        """

        if not messages:

            return messages



        current_time = time.time()

        cutoff_time = current_time - (self.compress_older_than_days * 24 * 3600)



        compacted = []

        tool_results_after_recent = 0



        for i, msg in enumerate(messages):

            is_tool_result = False



            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                msg_time = msg.get("_timestamp", current_time)

                is_tool_result = role == "tool"

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                msg_time = getattr(msg, "_timestamp", current_time)

                is_tool_result = role == "tool"



            if is_tool_result:

                position_from_end = len(messages) - i

                if position_from_end <= self.recent_n:

                    compacted.append(msg)

                elif msg_time < cutoff_time:

                    compacted_msg = await self._create_compacted_tool_result(msg)

                    compacted.append(compacted_msg)

                    tool_results_after_recent += 1

                else:

                    compacted.append(msg)

            else:

                compacted.append(msg)



        if tool_results_after_recent > 0:

            logger.info(

                "[ContextMgr] action=compact_tool_results compacted=%d recent_n=%d",

                tool_results_after_recent, self.recent_n,

            )



        return compacted



    async def _create_compacted_tool_result(self, message: Any) -> Any:

        """Create a compacted version of tool result."""

        if isinstance(message, dict):

            content = message.get("content", "")

            if isinstance(content, str) and len(content) > 300:

                compacted = message.copy()

                compacted["content"] = (

                    f"[工具结果已压缩 / Tool result - {len(content)} chars compressed to 300]\n"

                    + content[:300]

                )

                compacted["_compacted"] = True

                return compacted



        return message




class SemanticDeduplicator:

    """Semantic-level deduplication for context messages.



    Detects and removes near-duplicate messages based on:

    1. Exact content hash matching

    2. Jaccard similarity of token sets

    3. N-gram overlap for fuzzy matching

    """



    MAX_NGRAM_SIZE = 3

    SIMILARITY_THRESHOLD = 0.85

    MAX_MESSAGES_TO_SCAN = 200



    @staticmethod

    def _tokenize(text: str) -> set[str]:

        if not text:

            return set()

        words = text.lower().split()

        return set(w for w in words if len(w) > 2)



    @classmethod

    def _ngrams(cls, text: str, n: int = 2) -> set[str]:

        words = text.lower().split()

        if len(words) < n:

            return {text.lower()}

        return {" ".join(words[i:i + n]) for i in range(len(words) - n + 1)}



    @classmethod

    def jaccard_similarity(cls, text_a: str, text_b: str) -> float:

        tokens_a = cls._tokenize(text_a)

        tokens_b = cls._tokenize(text_b)

        if not tokens_a or not tokens_b:

            return 0.0

        intersection = tokens_a & tokens_b

        union = tokens_a | tokens_b

        return len(intersection) / len(union)



    @classmethod

    def ngram_similarity(cls, text_a: str, text_b: str) -> float:

        ngrams_a = cls._ngrams(text_a, cls.MAX_NGRAM_SIZE)

        ngrams_b = cls._ngrams(text_b, cls.MAX_NGRAM_SIZE)

        if not ngrams_a or not ngrams_b:

            return 0.0

        intersection = ngrams_a & ngrams_b

        union = ngrams_a | ngrams_b

        return len(intersection) / len(union)



    @classmethod

    def is_near_duplicate(cls, text_a: str, text_b: str) -> bool:

        if text_a == text_b:

            return True

        if abs(len(text_a) - len(text_b)) > max(len(text_a), len(text_b)) * 0.5:

            return False

        jaccard = cls.jaccard_similarity(text_a, text_b)

        if jaccard >= cls.SIMILARITY_THRESHOLD:

            return True

        ngram_sim = cls.ngram_similarity(text_a, text_b)

        return ngram_sim >= cls.SIMILARITY_THRESHOLD



    @classmethod

    def deduplicate(cls, messages: list, keep_recent: int = 6) -> tuple[list, int]:

        if len(messages) <= keep_recent:

            return messages, 0

        protected = messages[-keep_recent:]

        scanable = messages[:-keep_recent]

        if len(scanable) > cls.MAX_MESSAGES_TO_SCAN:

            scanable = scanable[-cls.MAX_MESSAGES_TO_SCAN:]

        kept = []

        removed = 0

        for msg in scanable:

            text = ActiveContextManager._get_content_text(msg)

            is_dup = False

            for kept_msg in kept:

                kept_text = ActiveContextManager._get_content_text(kept_msg)

                if cls.is_near_duplicate(text, kept_text):

                    is_dup = True

                    break

            if is_dup:

                removed += 1

            else:

                kept.append(msg)

        result = kept + protected

        if removed > 0:

            logger.info(

                "[SemanticDedup] action=deduplicate original=%d kept=%d removed=%d",

                len(messages), len(result), removed,

            )

        return result, removed




class TopicExtractor:

    """Extract conversation topics for context organization.



    Identifies dominant topics in messages using keyword frequency

    and positional analysis.

    """



    MAX_TOPICS = 5

    MIN_TOPIC_LENGTH = 3



    _TOPIC_STOP_WORDS = frozenset({

        "the", "a", "an", "is", "are", "was", "were", "be", "been",

        "have", "has", "had", "do", "does", "did", "will", "would",

        "could", "should", "may", "might", "can", "to", "of", "in",

        "for", "on", "with", "at", "by", "from", "as", "and", "or",

        "not", "but", "if", "so", "no", "yes", "this", "that", "it",

        "的", "了", "是", "在", "有", "和", "就", "不", "也", "都",

        "要", "会", "可以", "我", "你", "他", "她", "这", "那",

    })



    @classmethod

    def extract_topics(cls, messages: list, top_n: int = 0) -> list[str]:

        n = top_n or cls.MAX_TOPICS

        word_freq: dict[str, int] = {}

        for msg in messages:

            text = ActiveContextManager._get_content_text(msg)

            if not text:

                continue

            words = text.lower().split()

            for w in words:

                w_stripped = w.strip(".,!?;:()[]{}\"'")

                if len(w_stripped) >= cls.MIN_TOPIC_LENGTH and w_stripped not in cls._TOPIC_STOP_WORDS:

                    word_freq[w_stripped] = word_freq.get(w_stripped, 0) + 1

        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)

        return [w for w, _ in sorted_words[:n]]



    @classmethod

    def build_topic_summary(cls, messages: list) -> str:

        topics = cls.extract_topics(messages)

        if not topics:

            return ""

        parts = ["## 对话主题 / Conversation Topics"]

        for i, topic in enumerate(topics, 1):

            parts.append(f"{i}. {topic}")

        return "\n".join(parts)




class SmartTruncator:

    """Smart truncation that preserves important content at boundaries.



    Instead of cutting at an arbitrary character count, this truncator:

    1. Preserves complete sentences

    2. Keeps code blocks intact

    3. Maintains markdown structure

    4. Adds continuation markers

    """



    MAX_TRUNCATION_ATTEMPTS = 5

    SENTENCE_ENDINGS = ("。", ".", "！", "!", "？", "?", "\n\n")

    CODE_BLOCK_MARKER = "```"



    @classmethod

    def truncate(cls, text: str, max_chars: int) -> str:

        if len(text) <= max_chars:

            return text

        if max_chars < 50:

            return text[:max_chars] + "..."



        truncated = text[:max_chars]



        in_code_block = truncated.count(cls.CODE_BLOCK_MARKER) % 2 != 0

        if in_code_block:

            last_closing = truncated.rfind(cls.CODE_BLOCK_MARKER)

            if last_closing > max_chars * 0.5:

                truncated = truncated[:last_closing] + cls.CODE_BLOCK_MARKER

            else:

                first_opening = truncated.find(cls.CODE_BLOCK_MARKER)

                if first_opening > 0:

                    truncated = truncated[:first_opening]



        best_cut = -1

        for ending in cls.SENTENCE_ENDINGS:

            pos = truncated.rfind(ending)

            if pos > best_cut and pos > max_chars * 0.4:

                best_cut = pos

        if best_cut > 0:

            truncated = truncated[:best_cut + 1]



        truncated = truncated.rstrip() + "\n\n[... 内容已截断 / Content truncated ...]"

        return truncated



    @classmethod

    def truncate_messages(cls, messages: list, max_total_chars: int) -> list:

        if not messages:

            return messages

        total = sum(len(ActiveContextManager._get_content_text(m)) for m in messages)

        if total <= max_total_chars:

            return messages



        budget_per_msg = max_total_chars // max(1, len(messages))

        result = []

        for msg in messages:

            text = ActiveContextManager._get_content_text(msg)

            if len(text) <= budget_per_msg:

                result.append(msg)

            else:

                truncated_text = cls.truncate(text, budget_per_msg)

                if isinstance(msg, dict):

                    new_msg = dict(msg)

                    new_msg["content"] = truncated_text

                    result.append(new_msg)

                else:

                    try:

                        from xingzierai.agentscope_core.message import Msg, TextBlock

                        new_msg = Msg(

                            name=getattr(msg, 'name', ''),

                            role=getattr(msg, 'role', ''),

                            content=[TextBlock(type="text", text=truncated_text)],

                        )

                        result.append(new_msg)

                    except Exception:

                        result.append(msg)

        return result




class AdaptiveCompactionController:

    """Adaptive compaction controller that selects strategy based on context pressure.



    Monitors context pressure and selects the appropriate compaction strategy:

    - CONSERVATIVE: Low pressure (< 0.6), preserve more context

    - BALANCED: Medium pressure (0.6-0.8), standard compaction

    - AGGRESSIVE: High pressure (0.8-0.9), aggressive compaction

    - EMERGENCY: Critical pressure (> 0.9), emergency trimming



    The controller also tracks strategy effectiveness to improve future decisions.

    """



    MAX_HISTORY = 200

    PRESSURE_WINDOW_SECONDS = 300



    def __init__(self):

        self._strategy_history: list[dict] = []

        self._pressure_samples: list[tuple[float, float]] = []

        self._strategy_effectiveness: dict[str, list[float]] = {

            s.value: [] for s in AdaptiveCompactionStrategy

        }



    def select_strategy(self, pressure: float, message_count: int = 0) -> AdaptiveCompactionStrategy:

        if pressure > 0.9:

            strategy = AdaptiveCompactionStrategy.EMERGENCY

        elif pressure > 0.8:

            strategy = AdaptiveCompactionStrategy.AGGRESSIVE

        elif pressure > 0.6:

            strategy = AdaptiveCompactionStrategy.BALANCED

        else:

            strategy = AdaptiveCompactionStrategy.CONSERVATIVE



        self._pressure_samples.append((time.time(), pressure))

        if len(self._pressure_samples) > self.MAX_HISTORY:

            self._pressure_samples = self._pressure_samples[-self.MAX_HISTORY:]



        if message_count > 150 and strategy == AdaptiveCompactionStrategy.CONSERVATIVE:

            strategy = AdaptiveCompactionStrategy.BALANCED



        if self._is_pressure_escalating():

            if strategy == AdaptiveCompactionStrategy.CONSERVATIVE:

                strategy = AdaptiveCompactionStrategy.BALANCED

            elif strategy == AdaptiveCompactionStrategy.BALANCED:

                strategy = AdaptiveCompactionStrategy.AGGRESSIVE



        logger.info(

            "[AdaptiveCompaction] action=strategy_selected pressure=%.3f strategy=%s msg_count=%d",

            pressure, strategy.value, message_count,

        )

        return strategy



    def _is_pressure_escalating(self) -> bool:

        if len(self._pressure_samples) < 3:

            return False

        now = time.time()

        recent = [(ts, p) for ts, p in self._pressure_samples

                  if now - ts < self.PRESSURE_WINDOW_SECONDS]

        if len(recent) < 3:

            return False

        first_third = recent[:len(recent) // 3]

        last_third = recent[-(len(recent) // 3):]

        avg_early = sum(p for _, p in first_third) / len(first_third)

        avg_late = sum(p for _, p in last_third) / len(last_third)

        return avg_late > avg_early * 1.15



    def record_outcome(

        self,

        strategy: AdaptiveCompactionStrategy,

        pressure_before: float,

        pressure_after: float,

        messages_removed: int,

    ) -> None:

        effectiveness = 0.0

        if pressure_before > 0:

            effectiveness = (pressure_before - pressure_after) / pressure_before

        self._strategy_effectiveness[strategy.value].append(effectiveness)

        if len(self._strategy_effectiveness[strategy.value]) > 50:
            self._strategy_effectiveness[strategy.value] = \
                self._strategy_effectiveness[strategy.value][-50:]

        self._strategy_history.append({

            "timestamp": time.time(),

            "strategy": strategy.value,

            "pressure_before": round(pressure_before, 3),

            "pressure_after": round(pressure_after, 3),

            "messages_removed": messages_removed,

            "effectiveness": round(effectiveness, 3),

        })

        if len(self._strategy_history) > self.MAX_HISTORY:

            self._strategy_history = self._strategy_history[-self.MAX_HISTORY:]



    def get_strategy_params(self, strategy: AdaptiveCompactionStrategy) -> dict:

        params_map = {

            AdaptiveCompactionStrategy.CONSERVATIVE: {

                "keep_recent": 12,

                "density": "full",

                "max_compact_ratio": 0.3,

                "preserve_anchors": True,

            },

            AdaptiveCompactionStrategy.BALANCED: {

                "keep_recent": 8,

                "density": "medium",

                "max_compact_ratio": 0.5,

                "preserve_anchors": True,

            },

            AdaptiveCompactionStrategy.AGGRESSIVE: {

                "keep_recent": 5,

                "density": "light",

                "max_compact_ratio": 0.7,

                "preserve_anchors": True,

            },

            AdaptiveCompactionStrategy.EMERGENCY: {

                "keep_recent": 3,

                "density": "light",

                "max_compact_ratio": 0.9,

                "preserve_anchors": True,

            },

        }

        return params_map.get(strategy, params_map[AdaptiveCompactionStrategy.BALANCED])



    def get_stats(self) -> dict:

        avg_effectiveness = {}

        for strategy_name, scores in self._strategy_effectiveness.items():

            if scores:

                avg_effectiveness[strategy_name] = round(sum(scores) / len(scores), 3)

            else:

                avg_effectiveness[strategy_name] = 0.0

        return {

            "total_decisions": len(self._strategy_history),

            "avg_effectiveness_by_strategy": avg_effectiveness,

            "pressure_samples": len(self._pressure_samples),

            "is_escalating": self._is_pressure_escalating(),

        }




class ProgressiveCompactionManager:

    """Multi-pass progressive compaction with quality validation.



    Instead of a single compaction pass, this manager applies compaction

    in progressive rounds, validating quality after each round:



    1. First pass: Context-Folding (collapse completed tool trajectories)

    2. Second pass: Density-gradient compression (full→medium→light)

    3. Third pass: Emergency trimming (if still over budget)



    Each pass validates that anchor preservation remains above threshold.

    """



    MIN_ANCHOR_PRESERVATION = 0.5

    MAX_PASSES = 3



    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):

        self._ctx_manager = ctx_manager or ActiveContextManager()

        self._pass_stats: list[dict] = []



    async def compact_progressive(

        self,

        messages: list,

        pressure: float,

        max_context_tokens: int = 128000,

    ) -> tuple[list, dict]:

        controller = AdaptiveCompactionController()

        strategy = controller.select_strategy(pressure, len(messages))

        params = controller.get_strategy_params(strategy)



        result_messages = list(messages)

        pass_results = []

        total_removed = 0



        for pass_num in range(1, self.MAX_PASSES + 1):

            if pass_num == 1:

                result_messages = self._ctx_manager.fold_completed_trajectories(

                    result_messages,

                    keep_recent=params["keep_recent"],

                )

                pass_result = {"pass": 1, "action": "context_folding", "messages_after": len(result_messages)}

            elif pass_num == 2:

                result_messages = await self._ctx_manager.compress_tool_results(

                    result_messages,

                    recent_threshold=params["keep_recent"],

                    old_threshold=200 if params["density"] == "light" else 500,

                )

                pass_result = {"pass": 2, "action": "tool_result_compression", "messages_after": len(result_messages)}

            else:

                token_counts = self._ctx_manager.estimate_messages_tokens(result_messages)

                total_tokens = sum(token_counts)

                if total_tokens > max_context_tokens * 0.85:

                    result_messages = self._ctx_manager.trim_by_priority(

                        result_messages,

                        "",

                        int(max_context_tokens * 0.7),

                        token_counts,

                    )

                    pass_result = {"pass": 3, "action": "priority_trimming", "messages_after": len(result_messages)}

                else:

                    pass_result = {"pass": 3, "action": "skipped", "reason": "within_budget"}



            removed = len(messages) - len(result_messages)

            total_removed += removed

            pass_results.append(pass_result)



            is_coherent, issues = self._ctx_manager.check_coherence(result_messages)

            if not is_coherent and issues:

                critical_issues = [i for i in issues if "in-progress" not in i]

                if critical_issues:

                    logger.warning(

                        "[ProgressiveCompaction] action=coherence_issue pass=%d issues=%d",

                        pass_num, len(critical_issues),

                    )



        summary = {

            "strategy": strategy.value,

            "passes": pass_results,

            "total_removed": total_removed,

            "original_count": len(messages),

            "final_count": len(result_messages),

        }

        self._pass_stats.append(summary)

        if len(self._pass_stats) > 100:

            self._pass_stats = self._pass_stats[-100:]



        return result_messages, summary



    def get_stats(self) -> dict:

        if not self._pass_stats:

            return {"total_compactions": 0}

        return {

            "total_compactions": len(self._pass_stats),

            "avg_reduction": round(

                sum(s.get("total_removed", 0) for s in self._pass_stats) / len(self._pass_stats), 1

            ),

            "strategy_distribution": {

                s: sum(1 for p in self._pass_stats if p.get("strategy") == s)

                for s in set(p.get("strategy", "") for p in self._pass_stats)

            },

        }




class IncrementalTrimmer:

    """Incremental context trimming that removes small amounts proactively.



    Instead of waiting for emergency trimming that removes large chunks,

    this trimmer removes a few low-priority messages at a time when

    pressure exceeds a moderate threshold, keeping context healthier

    with less disruption.

    """



    TRIM_BATCH_SIZE = 3

    PRESSURE_THRESHOLD = 0.70



    def __init__(self, ctx_manager: Optional[ActiveContextManager] = None):

        self._ctx_manager = ctx_manager or ActiveContextManager()

        self._trim_count = 0

        self._total_messages_removed = 0



    async def trim_incremental(

        self,

        messages: list,

        token_counts: list[int],

        current_query: str = "",

    ) -> tuple[list, list[int], int]:

        if not messages or len(messages) <= 6:

            return messages, token_counts, 0

        total_tokens = sum(token_counts)

        avg_tokens = total_tokens / len(messages) if messages else 0

        if avg_tokens <= 0:

            return messages, token_counts, 0

        prioritized = self._ctx_manager.prioritize_messages(messages, current_query)

        to_remove_indices: set[int] = set()

        for score, msg in reversed(prioritized):

            if score < 25.0 and len(to_remove_indices) < self.TRIM_BATCH_SIZE:

                try:

                    idx = messages.index(msg)

                    to_remove_indices.add(idx)

                except ValueError:

                    continue

        if not to_remove_indices:

            return messages, token_counts, 0

        result_msgs = [m for i, m in enumerate(messages) if i not in to_remove_indices]

        result_tokens = [t for i, t in enumerate(token_counts) if i not in to_remove_indices]

        removed = len(to_remove_indices)

        self._trim_count += 1

        self._total_messages_removed += removed

        logger.info(

            "[IncrementalTrimmer] action=trim batch=%d removed=%d total_removed=%d",

            self._trim_count, removed, self._total_messages_removed,

        )

        return result_msgs, result_tokens, removed



    def get_stats(self) -> dict:

        return {

            "trim_count": self._trim_count,

            "total_messages_removed": self._total_messages_removed,

        }

