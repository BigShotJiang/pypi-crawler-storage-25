# -*- coding: utf-8 -*-
"""Context management package - refactored from monolithic context_manager.py.

This package provides proactive context management features:
- Active memory retrieval before reasoning
- Context layer management (system, history, recent, tools)
- Intelligent context prioritization
- Tool result time-based compression
"""

from .models import (
    ContextLayer,
    ContextSegment,
    ContextBudget,
    RetrievalResult,
    ContextHealthReport,
    ConversationState,
    ErrorRecoveryStrategy,
    AdaptiveCompactionStrategy,
)
from .core import ActiveContextManager
from .compaction import (
    ContextCompactionManager,
    SemanticDeduplicator,
    TopicExtractor,
    SmartTruncator,
    AdaptiveCompactionController,
    ProgressiveCompactionManager,
    IncrementalTrimmer,
)
from .monitoring import (
    ContextHealthMonitor,
    ContextPressureMonitor,
    ContextUtilizationPredictor,
    ContextSnapshotManager,
    ContextMetricsAggregator,
)
from .budget import (
    ContextWindowBudgetPlanner,
    ContextBudgetManager,
    ContextPool,
)
from .loading import ProgressiveLoader, ContextPreWarmer
from .state import ConversationStateMachine
from .resilience import (
    ContextRecoveryManager,
    ContextAwareErrorRecovery,
    ContextCircuitBreaker,
    ContextOperationRateLimiter,
)
from .guard import (
    ContextWindowGuard,
    TokenEstimationCache,
    AnchorPreservationValidator,
)
from .api import ContextHealthAPI

ActiveContext = ActiveContextManager
ContextCompaction = ContextCompactionManager

__all__ = [
    "ContextLayer",
    "ContextSegment",
    "ContextBudget",
    "RetrievalResult",
    "ContextHealthReport",
    "ActiveContextManager",
    "ActiveContext",
    "ContextCompactionManager",
    "ContextCompaction",
    "SemanticDeduplicator",
    "TopicExtractor",
    "SmartTruncator",
    "ContextHealthMonitor",
    "ContextWindowBudgetPlanner",
    "ContextRecoveryManager",
    "ProgressiveLoader",
    "ContextPool",
    "ConversationState",
    "ConversationStateMachine",
    "ErrorRecoveryStrategy",
    "ContextAwareErrorRecovery",
    "AdaptiveCompactionStrategy",
    "AdaptiveCompactionController",
    "ContextPressureMonitor",
    "ProgressiveCompactionManager",
    "ContextPreWarmer",
    "TokenEstimationCache",
    "ContextWindowGuard",
    "ContextSnapshotManager",
    "ContextBudgetManager",
    "ContextHealthAPI",
    "ContextUtilizationPredictor",
    "IncrementalTrimmer",
    "AnchorPreservationValidator",
    "ContextCircuitBreaker",
    "ContextOperationRateLimiter",
    "ContextMetricsAggregator",
]
