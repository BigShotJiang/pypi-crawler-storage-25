# -*- coding: utf-8 -*-
"""Context health monitoring, pressure tracking, utilization prediction, snapshots, metrics."""

from __future__ import annotations
import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

class ContextHealthMonitor:

    """Continuous context health monitoring with alerting.



    Tracks context health metrics over time and generates alerts

    when health degrades, enabling proactive intervention.

    """



    MAX_HISTORY = 500

    ALERT_COOLDOWN = 60.0



    def __init__(self):

        self._history: deque = deque(maxlen=self.MAX_HISTORY)

        self._last_alert_time: float = 0.0

        self._alert_count: int = 0



    def record(self, health_score: float, message_count: int, token_estimate: int) -> None:

        self._history.append({

            "timestamp": time.time(),

            "health_score": health_score,

            "message_count": message_count,

            "token_estimate": token_estimate,

        })



    def should_alert(self, current_score: float) -> bool:

        if current_score > 0.6:

            return False

        now = time.time()

        if now - self._last_alert_time < self.ALERT_COOLDOWN:

            return False

        if len(self._history) < 3:

            return current_score < 0.4

        recent = list(self._history)[-5:]

        avg_recent = sum(h["health_score"] for h in recent) / len(recent)

        if current_score < avg_recent * 0.8:

            self._last_alert_time = now

            self._alert_count += 1

            return True

        return False



    def get_trend(self, window_seconds: float = 300) -> str:

        if len(self._history) < 3:

            return "stable"

        now = time.time()

        cutoff = now - window_seconds

        recent = [h for h in self._history if h["timestamp"] >= cutoff]

        if len(recent) < 3:

            return "stable"

        first_half = recent[:len(recent) // 2]

        second_half = recent[len(recent) // 2:]

        avg_first = sum(h["health_score"] for h in first_half) / len(first_half)

        avg_second = sum(h["health_score"] for h in second_half) / len(second_half)

        diff = avg_second - avg_first

        if diff > 0.1:

            return "improving"

        elif diff < -0.1:

            return "degrading"

        return "stable"



    def get_stats(self) -> dict:

        return {

            "sample_count": len(self._history),

            "alert_count": self._alert_count,

            "trend": self.get_trend(),

        }




class ContextPressureMonitor:

    """Monitors context pressure over time and generates alerts.



    Tracks pressure trends and provides early warning when context

    is approaching critical levels, enabling proactive compaction

    before emergency trimming is needed.

    """



    MAX_SAMPLES = 500

    ALERT_COOLDOWN_SECONDS = 60



    def __init__(self):

        self._samples: deque = deque(maxlen=self.MAX_SAMPLES)

        self._last_alert_time: float = 0.0

        self._alert_count: int = 0



    def record(self, pressure: float, message_count: int, estimated_tokens: int) -> None:

        self._samples.append({

            "timestamp": time.time(),

            "pressure": pressure,

            "message_count": message_count,

            "estimated_tokens": estimated_tokens,

        })



    def should_alert(self, current_pressure: float) -> bool:

        now = time.time()

        if now - self._last_alert_time < self.ALERT_COOLDOWN_SECONDS:

            return False

        if current_pressure < 0.7:

            return False

        if len(self._samples) < 5:

            return current_pressure > 0.8

        recent = list(self._samples)[-10:]

        avg_recent = sum(s["pressure"] for s in recent) / len(recent)

        if current_pressure > avg_recent * 1.1 and current_pressure > 0.75:

            self._last_alert_time = now

            self._alert_count += 1

            return True

        return False



    def get_trend(self, window_seconds: float = 300) -> str:

        if len(self._samples) < 3:

            return "stable"

        now = time.time()

        cutoff = now - window_seconds

        recent = [s for s in self._samples if s["timestamp"] >= cutoff]

        if len(recent) < 3:

            return "stable"

        first_half = recent[:len(recent) // 2]

        second_half = recent[len(recent) // 2:]

        avg_first = sum(s["pressure"] for s in first_half) / len(first_half)

        avg_second = sum(s["pressure"] for s in second_half) / len(second_half)

        diff = avg_second - avg_first

        if diff > 0.1:

            return "rising"

        elif diff < -0.1:

            return "falling"

        return "stable"



    def predict_time_to_critical(self, threshold: float = 0.9) -> Optional[float]:

        if len(self._samples) < 10:

            return None

        recent = list(self._samples)[-20:]

        if len(recent) < 5:

            return None

        pressures = [s["pressure"] for s in recent]

        timestamps = [s["timestamp"] for s in recent]

        if len(pressures) < 5:

            return None

        time_span = timestamps[-1] - timestamps[0]

        if time_span < 1:

            return None

        pressure_change = pressures[-1] - pressures[0]

        rate = pressure_change / time_span

        if rate <= 0:

            return None

        current = pressures[-1]

        if current >= threshold:

            return 0.0

        remaining = threshold - current

        return remaining / rate



    def get_stats(self) -> dict:

        return {

            "sample_count": len(self._samples),

            "alert_count": self._alert_count,

            "trend": self.get_trend(),

            "time_to_critical": self.predict_time_to_critical(),

        }




class ContextSnapshotManager:

    """Captures and stores context state snapshots for debugging.



    When context issues occur (overflow, compression failure, etc.),

    this manager captures a snapshot of the current context state

    for post-mortem analysis.

    """



    MAX_SNAPSHOTS = 20

    MAX_SNAPSHOT_SIZE = 50000



    def __init__(self):

        self._snapshots: list[dict] = []



    def capture(

        self,

        trigger: str,

        message_count: int = 0,

        estimated_tokens: int = 0,

        pressure: float = 0.0,

        state: str = "unknown",

        extra: dict | None = None,

    ) -> None:

        snapshot = {

            "timestamp": time.time(),

            "trigger": trigger,

            "message_count": message_count,

            "estimated_tokens": estimated_tokens,

            "pressure": round(pressure, 3),

            "state": state,

        }

        if extra:

            snapshot["extra"] = {k: str(v)[:200] for k, v in extra.items()}

        self._snapshots.append(snapshot)

        if len(self._snapshots) > self.MAX_SNAPSHOTS:

            self._snapshots = self._snapshots[-self.MAX_SNAPSHOTS:]



    def get_recent(self, limit: int = 10) -> list[dict]:

        return self._snapshots[-limit:]



    def get_stats(self) -> dict:

        if not self._snapshots:

            return {"total_snapshots": 0, "triggers": {}}

        triggers: dict[str, int] = {}

        for s in self._snapshots:

            t = s.get("trigger", "unknown")

            triggers[t] = triggers.get(t, 0) + 1

        return {

            "total_snapshots": len(self._snapshots),

            "triggers": triggers,

            "last_snapshot": self._snapshots[-1] if self._snapshots else None,

        }




class ContextUtilizationPredictor:

    """Predict context utilization trend for proactive intervention.



    Uses linear regression on recent pressure samples to predict

    when the context will reach critical levels, enabling early

    compaction before emergency trimming is needed.

    """



    MAX_SAMPLES = 100

    PREDICTION_HORIZON_SECONDS = 300



    def __init__(self):

        self._samples: deque = deque(maxlen=self.MAX_SAMPLES)

        self._predictions: list[dict] = []



    def record(self, pressure: float, message_count: int, estimated_tokens: int) -> None:

        self._samples.append({

            "timestamp": time.time(),

            "pressure": pressure,

            "message_count": message_count,

            "estimated_tokens": estimated_tokens,

        })



    def predict_pressure_at(self, target_seconds: float) -> Optional[float]:

        if len(self._samples) < 5:

            return None

        now = time.time()

        recent = [s for s in self._samples if now - s["timestamp"] < self.PREDICTION_HORIZON_SECONDS]

        if len(recent) < 5:

            return None

        timestamps = [s["timestamp"] - recent[0]["timestamp"] for s in recent]

        pressures = [s["pressure"] for s in recent]

        n = len(recent)

        sum_x = sum(timestamps)

        sum_y = sum(pressures)

        sum_xy = sum(x * y for x, y in zip(timestamps, pressures))

        sum_x2 = sum(x * x for x in timestamps)

        denom = n * sum_x2 - sum_x * sum_x

        if abs(denom) < 1e-10:

            return pressures[-1]

        slope = (n * sum_xy - sum_x * sum_y) / denom

        intercept = (sum_y - slope * sum_x) / n

        current_offset = now - recent[0]["timestamp"]

        predicted = slope * (current_offset + target_seconds) + intercept

        return max(0.0, min(1.0, predicted))



    def predict_time_to_pressure(self, target_pressure: float = 0.9) -> Optional[float]:

        if len(self._samples) < 5:

            return None

        now = time.time()

        recent = [s for s in self._samples if now - s["timestamp"] < self.PREDICTION_HORIZON_SECONDS]

        if len(recent) < 5:

            return None

        timestamps = [s["timestamp"] - recent[0]["timestamp"] for s in recent]

        pressures = [s["pressure"] for s in recent]

        n = len(recent)

        sum_x = sum(timestamps)

        sum_y = sum(pressures)

        sum_xy = sum(x * y for x, y in zip(timestamps, pressures))

        sum_x2 = sum(x * x for x in timestamps)

        denom = n * sum_x2 - sum_x * sum_x

        if abs(denom) < 1e-10:

            return None

        slope = (n * sum_xy - sum_x * sum_y) / denom

        if slope <= 0:

            return None

        intercept = (sum_y - slope * sum_x) / n

        current_offset = now - recent[0]["timestamp"]

        current_predicted = slope * current_offset + intercept

        if current_predicted >= target_pressure:

            return 0.0

        time_to_target = (target_pressure - intercept) / slope - current_offset

        return max(0.0, time_to_target)



    def should_proactive_compact(self, current_pressure: float) -> bool:

        predicted = self.predict_pressure_at(60)

        if predicted is None:

            return False

        if current_pressure > 0.7 and predicted > 0.85:

            self._predictions.append({

                "timestamp": time.time(),

                "current_pressure": round(current_pressure, 3),

                "predicted_60s": round(predicted, 3),

                "action": "proactive_compaction_recommended",

            })

            if len(self._predictions) > 50:

                self._predictions = self._predictions[-50:]

            return True

        return False



    def get_stats(self) -> dict:

        return {

            "sample_count": len(self._samples),

            "prediction_count": len(self._predictions),

            "predicted_60s": self.predict_pressure_at(60),

            "time_to_critical": self.predict_time_to_pressure(0.9),

        }




class ContextMetricsAggregator:

    """Aggregates metrics from all context subsystems for unified reporting.



    Collects and computes aggregate metrics across all context management

    components, providing a single point of access for monitoring dashboards

    and alerting systems.

    """



    MAX_SNAPSHOTS = 100

    SNAPSHOT_INTERVAL_SECONDS = 60.0



    def __init__(self):

        self._snapshots: deque = deque(maxlen=self.MAX_SNAPSHOTS)

        self._last_snapshot_time: float = 0.0

        self._total_compactions = 0

        self._total_trims = 0

        self._total_errors = 0



    def record_compaction(self, messages_removed: int, tokens_saved: int) -> None:

        self._total_compactions += 1

        self._try_snapshot()



    def record_trim(self, messages_removed: int) -> None:

        self._total_trims += 1

        self._try_snapshot()



    def record_error(self, error_type: str) -> None:

        self._total_errors += 1



    def _try_snapshot(self) -> None:

        now = time.time()

        if now - self._last_snapshot_time < self.SNAPSHOT_INTERVAL_SECONDS:

            return

        self._snapshots.append({

            "timestamp": now,

            "total_compactions": self._total_compactions,

            "total_trims": self._total_trims,

            "total_errors": self._total_errors,

        })

        self._last_snapshot_time = now



    def get_stats(self) -> dict:

        return {

            "total_compactions": self._total_compactions,

            "total_trims": self._total_trims,

            "total_errors": self._total_errors,

            "snapshots": len(self._snapshots),

        }

