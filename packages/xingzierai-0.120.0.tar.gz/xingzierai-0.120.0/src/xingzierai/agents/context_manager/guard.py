# -*- coding: utf-8 -*-
"""Context window guard, token estimation cache, anchor preservation validation."""

from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional
from .models import ContextBudget
from .core import ActiveContextManager

logger = logging.getLogger(__name__)

class TokenEstimationCache:

    """LRU cache for token estimation to avoid repeated computation.



    Caches token counts for message content hashes, reducing

    CPU overhead for repeated token estimation calls.

    """



    MAX_CACHE_SIZE = 500

    _instance: "TokenEstimationCache | None" = None



    def __init__(self):

        self._cache: dict[str, tuple[int, float]] = {}

        self._hits = 0

        self._misses = 0



    @classmethod

    def get_instance(cls) -> "TokenEstimationCache":

        if cls._instance is None:

            cls._instance = cls()

        return cls._instance



    def _content_hash(self, content: str) -> str:

        if len(content) <= 64:

            return content

        import hashlib

        return hashlib.md5(content.encode("utf-8", errors="surrogatepass")).hexdigest()



    def get_or_compute(self, content: str, estimator: Callable[[str], int]) -> int:

        key = self._content_hash(content)

        now = time.time()

        cached = self._cache.get(key)

        if cached is not None:

            tokens, ts = cached

            if now - ts < 600:

                self._hits += 1

                return tokens



        self._misses += 1

        tokens = estimator(content)

        self._cache[key] = (tokens, now)

        if len(self._cache) > self.MAX_CACHE_SIZE:

            oldest_key = min(self._cache, key=lambda k: self._cache[k][1])

            del self._cache[oldest_key]

        return tokens



    def invalidate(self) -> None:

        self._cache.clear()



    def batch_compute(

        self,

        contents: list[str],

        estimator: Callable[[str], int],

    ) -> list[int]:

        results = []

        for content in contents:

            results.append(self.get_or_compute(content, estimator))

        return results



    def get_stats(self) -> dict:

        total = self._hits + self._misses

        hit_rate = round(self._hits / max(1, total), 3)

        return {

            "cache_size": len(self._cache),

            "max_size": self.MAX_CACHE_SIZE,

            "hits": self._hits,

            "misses": self._misses,

            "hit_rate": hit_rate,

        }




class ContextWindowGuard:

    """Guard that prevents context window overflow before LLM calls.



    Provides a final safety check before sending context to the model,

    ensuring the total token count stays within the configured limit.

    """



    SAFETY_MARGIN = 0.05



    def __init__(self, max_context_tokens: int = 128000):

        self._max_context_tokens = max_context_tokens

        self._guard_checks = 0

        self._guard_triggers = 0



    def check_and_trim(

        self,

        messages: list,

        token_counts: list[int],

        budget: Optional[ContextBudget] = None,

    ) -> tuple[list, list[int], bool]:

        self._guard_checks += 1

        if not messages or not token_counts or len(messages) != len(token_counts):

            return messages, token_counts, False



        total = sum(token_counts)

        limit = int(self._max_context_tokens * (1 - self.SAFETY_MARGIN))



        if total <= limit:

            return messages, token_counts, False



        self._guard_triggers += 1

        ctx_mgr = ActiveContextManager()

        if budget is None:

            budget = ContextBudget()



        trimmed = budget.enforce_budget(messages, token_counts)

        new_counts = [

            ActiveContextManager.estimate_tokens(

                ActiveContextManager._get_content_text(m)

            )

            for m in trimmed

        ]



        logger.info(

            "[ContextWindowGuard] action=trim_triggered original=%d trimmed=%d total_tokens=%d limit=%d",

            len(messages), len(trimmed), total, limit,

        )

        return trimmed, new_counts, True



    def get_stats(self) -> dict:

        return {

            "max_context_tokens": self._max_context_tokens,

            "safety_margin": self.SAFETY_MARGIN,

            "guard_checks": self._guard_checks,

            "guard_triggers": self._guard_triggers,

            "trigger_rate": round(

                self._guard_triggers / max(1, self._guard_checks), 3

            ),

        }




class AnchorPreservationValidator:

    """Validate that anchor phrases survive compaction.



    After each compaction pass, checks that critical anchors

    (file paths, key decisions, constraints) are still present

    in the remaining context. If preservation drops below

    threshold, logs a warning and suggests re-injection.

    """



    MIN_PRESERVATION_RATIO = 0.5



    def __init__(self):

        self._validation_count = 0

        self._preservation_scores: list[float] = []



    def validate(

        self,

        anchors: list[str],

        remaining_messages: list,

    ) -> tuple[float, list[str]]:

        self._validation_count += 1

        if not anchors:

            return 1.0, []

        remaining_text = ""

        for msg in remaining_messages:

            if isinstance(msg, dict):

                remaining_text += str(msg.get("content", "")) + " "

            else:

                remaining_text += str(getattr(msg, "content", "") or "") + " "

        remaining_lower = remaining_text.lower()

        preserved = []

        lost = []

        for anchor in anchors:

            if anchor.lower()[:50] in remaining_lower:

                preserved.append(anchor)

            else:

                lost.append(anchor)

        ratio = len(preserved) / len(anchors) if anchors else 1.0

        self._preservation_scores.append(ratio)

        if len(self._preservation_scores) > 100:

            self._preservation_scores = self._preservation_scores[-100:]

        if ratio < self.MIN_PRESERVATION_RATIO:

            logger.warning(

                "[AnchorValidator] action=low_preservation ratio=%.2f preserved=%d lost=%d lost_anchors=%s",

                ratio, len(preserved), len(lost),

                [a[:50] for a in lost[:5]],

            )

        return ratio, lost



    def get_stats(self) -> dict:

        avg = (

            sum(self._preservation_scores) / len(self._preservation_scores)

            if self._preservation_scores

            else 0.0

        )

        return {

            "validation_count": self._validation_count,

            "avg_preservation_ratio": round(avg, 3),

            "min_preservation_ratio": round(min(self._preservation_scores), 3) if self._preservation_scores else 0.0,

        }



