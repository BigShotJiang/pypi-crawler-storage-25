# -*- coding: utf-8 -*-
from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class RollbackLevel(Enum):
    FILE = 1
    HOT = 2
    GIT_CHECKPOINT = 3
    SERVICE_RESTART = 4


@dataclass
class RollbackResult:
    level: RollbackLevel
    success: bool
    message: str
    details: dict = field(default_factory=dict)


class RollbackChain:
    """4-level rollback strategy chain for evolution safety.

    Level 1: File-level rollback - restore original file content from backup
    Level 2: Hot rollback - use CodeEvolutionEngine._rollback() without restart
    Level 3: Git checkpoint rollback - git reset --hard [hash]
    Level 4: Service restart - restart the backend services
    """

    def __init__(
        self,
        workspace_dir: Optional[str] = None,
        backup_dir: str = "backups",
    ):
        self._workspace_dir = workspace_dir
        self._backup_dir = backup_dir
        self._file_backups: dict[str, str] = {}

    def save_file_backup(self, file_path: str, content: str) -> None:
        self._file_backups[file_path] = content

    async def execute_rollback(self, level: int, context: dict) -> RollbackResult:
        try:
            rollback_level = RollbackLevel(level)
        except ValueError:
            return RollbackResult(
                level=RollbackLevel(level),
                success=False,
                message=f"Invalid rollback level: {level}",
            )

        if rollback_level == RollbackLevel.FILE:
            return self._rollback_file(context)
        elif rollback_level == RollbackLevel.HOT:
            return await self._rollback_hot(context)
        elif rollback_level == RollbackLevel.GIT_CHECKPOINT:
            return self._rollback_git(context)
        elif rollback_level == RollbackLevel.SERVICE_RESTART:
            return await self._rollback_service_restart(context)

        return RollbackResult(level=rollback_level, success=False, message="Unknown level")

    def auto_select_level(self, error: Exception) -> int:
        error_str = str(error).lower()
        if "syntax" in error_str or "indent" in error_str:
            return RollbackLevel.FILE.value
        if "import" in error_str or "module" in error_str:
            return RollbackLevel.HOT.value
        if "cascade" in error_str or "multiple" in error_str or "dependency" in error_str:
            return RollbackLevel.GIT_CHECKPOINT.value
        if "oom" in error_str or "segfault" in error_str or "crash" in error_str:
            return RollbackLevel.SERVICE_RESTART.value
        return RollbackLevel.GIT_CHECKPOINT.value

    def _rollback_file(self, context: dict) -> RollbackResult:
        file_path = context.get("file_path", "")
        original_content = self._file_backups.get(file_path) or context.get("original_content")

        if not file_path or not original_content:
            return RollbackResult(
                level=RollbackLevel.FILE,
                success=False,
                message="Missing file_path or original_content for file-level rollback",
            )

        try:
            Path(file_path).write_text(original_content, encoding="utf-8")
            self._file_backups.pop(file_path, None)
            logger.info("Level 1 rollback: restored %s", file_path)
            return RollbackResult(
                level=RollbackLevel.FILE,
                success=True,
                message=f"File-level rollback: restored {file_path}",
                details={"file_path": file_path},
            )
        except Exception as e:
            logger.error("Level 1 rollback failed: %s", e)
            return RollbackResult(
                level=RollbackLevel.FILE,
                success=False,
                message=f"File-level rollback failed: {e}",
            )

    async def _rollback_hot(self, context: dict) -> RollbackResult:
        file_path = context.get("file_path", "")
        backup_path = context.get("backup_path", "")
        module_name = context.get("module_name")

        if not file_path or not backup_path:
            return RollbackResult(
                level=RollbackLevel.HOT,
                success=False,
                message="Missing file_path or backup_path for hot rollback",
            )

        try:
            if Path(backup_path).exists():
                shutil.copy2(backup_path, file_path)
                logger.info("Level 2 rollback: hot-swapped %s from %s", file_path, backup_path)

            if module_name:
                try:
                    import importlib
                    import sys
                    if module_name in sys.modules:
                        importlib.reload(sys.modules[module_name])
                        logger.info("Level 2 rollback: reloaded module %s", module_name)
                except Exception as reload_err:
                    logger.warning("Module reload failed during hot rollback: %s", reload_err)

            return RollbackResult(
                level=RollbackLevel.HOT,
                success=True,
                message=f"Hot rollback: restored {file_path} and reloaded",
                details={"file_path": file_path, "module_name": module_name},
            )
        except Exception as e:
            logger.error("Level 2 rollback failed: %s", e)
            return RollbackResult(
                level=RollbackLevel.HOT,
                success=False,
                message=f"Hot rollback failed: {e}",
            )

    def _rollback_git(self, context: dict) -> RollbackResult:
        commit_hash = context.get("commit_hash", "")
        project_root = context.get("project_root", self._workspace_dir)

        if not commit_hash or not project_root:
            return RollbackResult(
                level=RollbackLevel.GIT_CHECKPOINT,
                success=False,
                message="Missing commit_hash or project_root for git rollback",
            )

        try:
            target_files = context.get("target_files")
            if target_files:
                result = subprocess.run(
                    ["git", "checkout", commit_hash, "--"] + target_files,
                    cwd=project_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            else:
                subprocess.run(
                    ["git", "stash", "--include-untracked"],
                    cwd=project_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                result = subprocess.run(
                    ["git", "reset", "--hard", commit_hash],
                    cwd=project_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )

            success = result.returncode == 0
            logger.info("Level 3 rollback: git %s to %s", "success" if success else "failed", commit_hash)
            return RollbackResult(
                level=RollbackLevel.GIT_CHECKPOINT,
                success=success,
                message=f"Git checkpoint rollback to {commit_hash[:8]}: {'OK' if success else result.stderr[:200]}",
                details={"commit_hash": commit_hash, "project_root": project_root},
            )
        except Exception as e:
            logger.error("Level 3 rollback failed: %s", e)
            return RollbackResult(
                level=RollbackLevel.GIT_CHECKPOINT,
                success=False,
                message=f"Git rollback failed: {e}",
            )

    async def _rollback_service_restart(self, context: dict) -> RollbackResult:
        project_root = context.get("project_root", self._workspace_dir)
        results = []

        try:
            for cmd_name, cmd in [
                ("uvicorn", ["pkill", "-f", "uvicorn xingzierai"]),
                ("daemon", ["pkill", "-f", "evolution_daemon"]),
            ]:
                try:
                    subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                    results.append(f"{cmd_name}: stopped")
                except Exception as e:
                    results.append(f"{cmd_name}: stop failed ({e})")

            import asyncio
            await asyncio.sleep(2)

            try:
                subprocess.run(
                    ["python3", "-m", "xingzierai.app.main"],
                    cwd=project_root,
                    capture_output=True,
                    text=True,
                    timeout=10,
                    start_new_session=True,
                )
                results.append("main: restart initiated")
            except Exception as e:
                results.append(f"main: restart failed ({e})")

            logger.info("Level 4 rollback: service restart - %s", "; ".join(results))
            return RollbackResult(
                level=RollbackLevel.SERVICE_RESTART,
                success=True,
                message=f"Service restart: {'; '.join(results)}",
                details={"results": results},
            )
        except Exception as e:
            logger.error("Level 4 rollback failed: %s", e)
            return RollbackResult(
                level=RollbackLevel.SERVICE_RESTART,
                success=False,
                message=f"Service restart failed: {e}",
            )
