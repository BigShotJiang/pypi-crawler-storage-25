#!/usr/bin/env python3
"""
EmbeddingLoader - 统一的Embedding模型加载器

解决中国网络无法直连HuggingFace的问题：
1. 优先使用本地缓存
2. HuggingFace镜像站(hf-mirror.com)自动切换
3. API Embedding降级(OpenCode免费模型)
4. 关键词匹配最终降级

使用方式：
    from xingzierai.agents.embedding_loader import get_embedder
    embedder = get_embedder()
    vectors = embedder.encode(["hello", "world"])
"""

import asyncio
import logging
import os
import threading
import time
from enum import Enum
from typing import Any, Dict, List, Optional, Union

import numpy as np

logger = logging.getLogger(__name__)


class EmbeddingBackend(str, Enum):
    SENTENCE_TRANSFORMERS = "sentence_transformers"
    API_EMBEDDING = "api_embedding"
    KEYWORD_FALLBACK = "keyword_fallback"


HF_MIRROR_URL = "https://hf-mirror.com"
DEFAULT_ST_MODEL = "all-MiniLM-L6-v2"
DEFAULT_ML_MODEL = "paraphrase-multilingual-MiniLM-L12-v2"
KEYWORD_FALLBACK_DIM = 384


class EmbeddingLoader:
    MAX_API_COUNT = 1000
    API_ENCODE_RETRIES = 2

    def __init__(self):
        self._st_embedder: Optional[Any] = None
        self._backend: EmbeddingBackend = EmbeddingBackend.KEYWORD_FALLBACK
        self._model_name: str = ""
        self._lock = threading.Lock()
        self._preload_task: Optional[threading.Thread] = None
        self._dimension: int = KEYWORD_FALLBACK_DIM
        self._preload_started_at: float = 0.0
        self._preload_finished: bool = False
        self._api_encode_fail_count: int = 0
        self._api_encode_success_count: int = 0
        self._api_endpoint: str = ""
        self._api_key: Optional[str] = None
        self._api_model: str = ""

    @property
    def backend(self) -> EmbeddingBackend:
        return self._backend

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def is_available(self) -> bool:
        return self._backend != EmbeddingBackend.KEYWORD_FALLBACK

    @property
    def is_ready(self) -> bool:
        return self._preload_finished

    def preload(self, model_name: str = DEFAULT_ST_MODEL):
        """后台预加载embedding模型"""
        if self._st_embedder is not None or self._preload_task is not None:
            return

        if "HF_ENDPOINT" not in os.environ:
            os.environ["HF_ENDPOINT"] = HF_MIRROR_URL
        if "HUGGINGFACE_HUB_URL" not in os.environ:
            os.environ["HUGGINGFACE_HUB_URL"] = HF_MIRROR_URL

        self._preload_started_at = time.time()

        def _load():
            try:
                embedder = self._try_load_st(model_name)
                if embedder is not None:
                    with self._lock:
                        self._st_embedder = embedder
                        self._backend = EmbeddingBackend.SENTENCE_TRANSFORMERS
                        self._model_name = model_name
                        self._dimension = embedder.get_embedding_dimension()
                    logger.info(
                        f"EmbeddingLoader: {model_name} loaded "
                        f"(dim={self._dimension}, backend=sentence_transformers)"
                    )
                    return

                logger.info("EmbeddingLoader: sentence-transformers unavailable, trying API embedding")
                if self._try_api_embedding():
                    return

                logger.warning("EmbeddingLoader: all backends failed, using keyword fallback")
                with self._lock:
                    self._backend = EmbeddingBackend.KEYWORD_FALLBACK
                    self._dimension = KEYWORD_FALLBACK_DIM
            except Exception as e:
                logger.warning(f"EmbeddingLoader: preload failed: {e}")
                with self._lock:
                    self._backend = EmbeddingBackend.KEYWORD_FALLBACK
                    self._dimension = KEYWORD_FALLBACK_DIM
            finally:
                self._preload_finished = True
                elapsed = time.time() - self._preload_started_at
                logger.info(f"EmbeddingLoader: preload finished in {elapsed:.1f}s (backend={self._backend.value})")

        self._preload_task = threading.Thread(target=_load, daemon=True)
        self._preload_task.start()

    def _try_load_st(self, model_name: str) -> Optional[Any]:
        """尝试加载sentence-transformers模型，支持HuggingFace镜像站"""
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            logger.info("EmbeddingLoader: sentence-transformers not installed")
            return None

        cache_dir = os.path.expanduser("~/.cache/huggingface/hub")
        local_model_path = os.path.join(cache_dir, f"models--{model_name.replace('/', '--')}")

        if os.path.exists(local_model_path):
            try:
                logger.info(f"EmbeddingLoader: loading from local cache: {local_model_path}")
                return SentenceTransformer(model_name)
            except Exception as e:
                logger.warning(f"EmbeddingLoader: local cache load failed: {e}")

        try:
            os.environ["HF_ENDPOINT"] = HF_MIRROR_URL
            os.environ["HUGGINGFACE_HUB_URL"] = HF_MIRROR_URL
            logger.info(f"EmbeddingLoader: trying HF mirror: {HF_MIRROR_URL}")
            return SentenceTransformer(model_name)
        except Exception as e:
            logger.warning(f"EmbeddingLoader: HF mirror failed: {e}")

        try:
            if "HF_ENDPOINT" in os.environ:
                del os.environ["HF_ENDPOINT"]
            if "HUGGINGFACE_HUB_URL" in os.environ:
                del os.environ["HUGGINGFACE_HUB_URL"]
            logger.info("EmbeddingLoader: trying direct HuggingFace download")
            return SentenceTransformer(model_name)
        except Exception as e:
            logger.warning(f"EmbeddingLoader: direct download failed: {e}")

        return None

    def _try_api_embedding(self) -> bool:
        """尝试使用API embedding（多种来源）"""
        providers = [
            ("opencode", "https://opencode.ai/zen/v1/embeddings", None, "text-embedding-ada-002"),
            ("siliconflow", "https://api.siliconflow.cn/v1/embeddings", os.getenv("SILICONFLOW_API_KEY"), "BAAI/bge-small-en-v1.5"),
        ]

        for provider_name, endpoint, api_key, model in providers:
            try:
                import json as _json
                import urllib.request

                payload = _json.dumps({
                    "model": model,
                    "input": "test",
                }).encode()
                headers = {"Content-Type": "application/json"}
                if api_key:
                    headers["Authorization"] = f"Bearer {api_key}"

                req = urllib.request.Request(endpoint, data=payload, headers=headers)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = _json.loads(resp.read())
                    if data.get("data") and data["data"][0].get("embedding"):
                        with self._lock:
                            self._backend = EmbeddingBackend.API_EMBEDDING
                            self._model_name = f"{provider_name}:embedding"
                            self._dimension = len(data["data"][0]["embedding"])
                            self._api_endpoint = endpoint
                            self._api_key = api_key
                            self._api_model = model
                        logger.info(f"EmbeddingLoader: API embedding available via {provider_name} (dim={self._dimension})")
                        return True
            except Exception as e:
                logger.debug(f"EmbeddingLoader: {provider_name} embedding not available: {e}")

        return False

    def encode(self, texts: Union[str, List[str]], **kwargs) -> np.ndarray:
        """编码文本为向量"""
        if isinstance(texts, str):
            texts = [texts]

        if self._backend == EmbeddingBackend.SENTENCE_TRANSFORMERS and self._st_embedder is not None:
            try:
                return self._st_embedder.encode(texts, show_progress_bar=False, **kwargs)
            except Exception as e:
                logger.warning(f"EmbeddingLoader: ST encode failed: {e}")

        if self._backend == EmbeddingBackend.API_EMBEDDING:
            try:
                result = self._api_encode(texts)
                self._api_encode_success_count = min(self._api_encode_success_count + 1, self.MAX_API_COUNT)
                return result
            except Exception as e:
                self._api_encode_fail_count = min(self._api_encode_fail_count + 1, self.MAX_API_COUNT)
                logger.warning(f"EmbeddingLoader: API encode failed ({self._api_encode_fail_count}): {e}")
                if self._api_encode_fail_count >= 5 and self._api_encode_success_count == 0:
                    logger.warning("EmbeddingLoader: API embedding consistently failing, degrading to keyword")
                    with self._lock:
                        self._backend = EmbeddingBackend.KEYWORD_FALLBACK

        return self._keyword_encode(texts)

    async def async_encode(self, texts: Union[str, List[str]], **kwargs) -> np.ndarray:
        """异步编码文本为向量"""
        if isinstance(texts, str):
            texts = [texts]

        if self._backend == EmbeddingBackend.SENTENCE_TRANSFORMERS and self._st_embedder is not None:
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(
                    None, lambda: self._st_embedder.encode(texts, show_progress_bar=False, **kwargs)
                )
            except Exception as e:
                logger.warning(f"EmbeddingLoader: async ST encode failed: {e}")

        if self._backend == EmbeddingBackend.API_EMBEDDING:
            try:
                return await self._async_api_encode(texts)
            except Exception as e:
                logger.warning(f"EmbeddingLoader: async API encode failed: {e}")

        return self._keyword_encode(texts)

    def _api_encode(self, texts: List[str]) -> np.ndarray:
        """使用API进行embedding，带重试"""
        import json
        import urllib.request

        endpoint = self._api_endpoint or "https://opencode.ai/zen/v1/embeddings"
        model = self._api_model or "text-embedding-ada-002"
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        all_embeddings = []
        batch_size = 8
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            payload = json.dumps({
                "model": model,
                "input": batch,
            }).encode()
            last_error = None
            for attempt in range(self.API_ENCODE_RETRIES + 1):
                try:
                    req = urllib.request.Request(endpoint, data=payload, headers=headers)
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        data = json.loads(resp.read())
                        for item in sorted(data["data"], key=lambda x: x["index"]):
                            all_embeddings.append(item["embedding"])
                        last_error = None
                        break
                except Exception as e:
                    last_error = e
                    if attempt < self.API_ENCODE_RETRIES:
                        time.sleep(1)
            if last_error:
                raise last_error

        return np.array(all_embeddings, dtype=np.float32)

    async def _async_api_encode(self, texts: List[str]) -> np.ndarray:
        """异步使用API进行embedding"""
        import aiohttp

        endpoint = self._api_endpoint or "https://opencode.ai/zen/v1/embeddings"
        model = self._api_model or "text-embedding-ada-002"
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        all_embeddings = []
        batch_size = 8
        async with aiohttp.ClientSession() as session:
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                payload = {
                    "model": model,
                    "input": batch,
                }
                last_error = None
                for attempt in range(self.API_ENCODE_RETRIES + 1):
                    try:
                        async with session.post(
                            endpoint,
                            json=payload,
                            headers=headers,
                            timeout=aiohttp.ClientTimeout(total=30),
                        ) as resp:
                            data = await resp.json()
                            for item in sorted(data["data"], key=lambda x: x["index"]):
                                all_embeddings.append(item["embedding"])
                            last_error = None
                            break
                    except Exception as e:
                        last_error = e
                        if attempt < self.API_ENCODE_RETRIES:
                            await asyncio.sleep(1)
                if last_error:
                    raise last_error

        return np.array(all_embeddings, dtype=np.float32)

    def _keyword_encode(self, texts: List[str]) -> np.ndarray:
        """关键词匹配降级：使用TF-IDF风格的特征向量"""
        from collections import Counter
        import hashlib
        import re

        dim = KEYWORD_FALLBACK_DIM
        result = np.zeros((len(texts), dim), dtype=np.float32)

        for i, text in enumerate(texts):
            words = re.findall(r'\w+', text.lower())
            bigrams = [f"{words[j]}_{words[j+1]}" for j in range(len(words) - 1)]
            tokens = words + bigrams
            token_counts = Counter(tokens)
            for token, count in token_counts.items():
                h = int(hashlib.md5(token.encode()).hexdigest()[:8], 16)
                idx = h % dim
                result[i][idx] += count
            norm = np.linalg.norm(result[i])
            if norm > 0:
                result[i] /= norm

        return result

    def get_stats(self) -> Dict[str, Any]:
        return {
            "backend": self._backend.value,
            "model_name": self._model_name,
            "dimension": self._dimension,
            "is_available": self.is_available,
            "is_ready": self._preload_finished,
            "api_encode_success": self._api_encode_success_count,
            "api_encode_fail": self._api_encode_fail_count,
        }


_loader: Optional[EmbeddingLoader] = None


def get_embedder() -> EmbeddingLoader:
    global _loader
    if _loader is None:
        _loader = EmbeddingLoader()
        _loader.preload()
    return _loader
