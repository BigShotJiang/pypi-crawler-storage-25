# -*- coding: utf-8 -*-
"""Orchestrator-Workers Multi-Agent Coordination Pattern.

Enterprise-level multi-agent coordination that integrates with:
- ManagedAgentOrchestrator (brain-hand architecture)
- OrgOrchestrator (organization management)
- MultiAgentManager (workspace management)
- OrgBlackboard (shared memory)

Pattern: Orchestrator decomposes tasks → Workers execute in parallel → Results aggregated.

Key design:
1. Task decomposition: LLM breaks complex tasks into subtasks
2. Worker assignment: Match subtasks to best-fit agents by capability
3. Parallel execution: Workers run concurrently with shared blackboard
4. Result aggregation: Combine worker outputs into coherent final result
5. Quality gate: Self-evaluate before returning, retry if needed
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path

from xingzierai.utils.async_utils import run_async_safe
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_ORCH_DIR = Path.home() / ".xingzierai" / "orchestration"


class TaskStatus(str, Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class WorkerCapability(str, Enum):
    CODE = "code"
    RESEARCH = "research"
    WRITING = "writing"
    ANALYSIS = "analysis"
    DATA = "data"
    GENERAL = "general"


@dataclass
class SubTask:
    task_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    description: str = ""
    capability: WorkerCapability = WorkerCapability.GENERAL
    status: TaskStatus = TaskStatus.PENDING
    assigned_worker: str = ""
    result: Any = None
    error: str = ""
    priority: int = 0
    dependencies: List[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


@dataclass
class WorkerProfile:
    worker_id: str
    capabilities: List[WorkerCapability] = field(default_factory=lambda: [WorkerCapability.GENERAL])
    max_concurrent: int = 3
    current_load: int = 0
    success_rate: float = 1.0
    avg_latency_ms: float = 0.0
    total_tasks: int = 0
    failed_tasks: int = 0


@dataclass
class OrchestrationResult:
    orchestration_id: str
    original_task: str
    subtasks: List[SubTask]
    final_result: Any = None
    success: bool = False
    total_time_ms: float = 0.0
    workers_used: List[str] = field(default_factory=list)
    quality_score: float = 0.0
    retry_count: int = 0
    completed_at: float = 0.0


class AgentBus:
    """Publish-subscribe message bus for inter-agent communication."""

    MAX_TOPICS = 100
    MAX_QUEUES_PER_TOPIC = 20

    def __init__(self):
        self._subscribers: Dict[str, List[asyncio.Queue]] = {}
        self._history: deque = deque(maxlen=1000)

    async def publish(self, topic: str, message: dict, sender: str = "") -> None:
        entry = {
            "topic": topic,
            "message": message,
            "sender": sender,
            "timestamp": datetime.now().isoformat(),
            "msg_id": uuid.uuid4().hex[:8],
        }
        self._history.append(entry)

        queues = self._subscribers.get(topic, [])
        dead_queues = []
        for q in queues:
            try:
                q.put_nowait(entry)
            except asyncio.QueueFull:
                pass
            except RuntimeError:
                dead_queues.append(q)
        for dq in dead_queues:
            queues.remove(dq)

    def subscribe(self, topic: str) -> asyncio.Queue:
        if len(self._subscribers) >= self.MAX_TOPICS and topic not in self._subscribers:
            oldest_topic = next(iter(self._subscribers))
            del self._subscribers[oldest_topic]
        if topic not in self._subscribers:
            self._subscribers[topic] = []
        if len(self._subscribers[topic]) >= self.MAX_QUEUES_PER_TOPIC:
            self._subscribers[topic].pop(0)
        q = asyncio.Queue(maxsize=100)
        self._subscribers[topic].append(q)
        return q

    def unsubscribe(self, topic: str, queue: asyncio.Queue) -> None:
        if topic in self._subscribers:
            try:
                self._subscribers[topic].remove(queue)
            except ValueError:
                pass

    def get_history(self, topic: Optional[str] = None, limit: int = 50) -> List[dict]:
        entries = self._history
        if topic:
            entries = [e for e in entries if e["topic"] == topic]
        return entries[-limit:]


class TaskBoard:
    """Shared task board for orchestrator-workers coordination.

    Integrates with OrgBlackboard for persistent shared state.
    """

    MAX_COMPLETED_TASKS = 500

    def __init__(self):
        self._tasks: Dict[str, SubTask] = {}
        self._results: Dict[str, Any] = {}
        self._lock = asyncio.Lock()

    def _cleanup_completed(self):
        completed_ids = [
            tid for tid, t in self._tasks.items()
            if t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)
        ]
        if len(completed_ids) <= self.MAX_COMPLETED_TASKS:
            return
        completed_ids.sort(key=lambda tid: self._tasks[tid].completed_at or "")
        remove_ids = completed_ids[:len(completed_ids) - self.MAX_COMPLETED_TASKS]
        for tid in remove_ids:
            self._tasks.pop(tid, None)
            self._results.pop(tid, None)

    async def post_task(self, task: SubTask) -> str:
        async with self._lock:
            self._tasks[task.task_id] = task
        return task.task_id

    async def claim_task(self, task_id: str, worker_id: str) -> Optional[SubTask]:
        async with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status == TaskStatus.PENDING:
                task.status = TaskStatus.ASSIGNED
                task.assigned_worker = worker_id
                task.started_at = datetime.now().isoformat()
                return task
        return None

    async def complete_task(self, task_id: str, result: Any, success: bool = True) -> None:
        async with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.COMPLETED if success else TaskStatus.FAILED
                task.result = result
                task.completed_at = datetime.now().isoformat()
                self._results[task_id] = result
                self._cleanup_completed()

    async def reset_task(self, task_id: str) -> None:
        async with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.PENDING
                task.result = None
                task.error = ""
                task.assigned_worker = None
                task.completed_at = None

    async def get_available_tasks(
        self,
        capability: Optional[WorkerCapability] = None,
        worker_id: str = "",
    ) -> List[SubTask]:
        async with self._lock:
            available = []
            for task in self._tasks.values():
                if task.status != TaskStatus.PENDING:
                    continue
                if capability and task.capability != capability:
                    continue
                if task.dependencies:
                    all_done = all(
                        self._tasks.get(dep_id, SubTask(status=TaskStatus.COMPLETED)).status == TaskStatus.COMPLETED
                        for dep_id in task.dependencies
                    )
                    if not all_done:
                        continue
                available.append(task)
        available.sort(key=lambda t: t.priority, reverse=True)
        return available

    async def get_task(self, task_id: str) -> Optional[SubTask]:
        return self._tasks.get(task_id)

    async def get_results(self) -> Dict[str, Any]:
        return dict(self._results)

    async def get_status(self) -> dict:
        status_counts = {}
        for task in self._tasks.values():
            s = task.status.value
            status_counts[s] = status_counts.get(s, 0) + 1
        return {
            "total_tasks": len(self._tasks),
            "by_status": status_counts,
            "completed_results": len(self._results),
        }


class CollaboratorKnowledgeModel:
    """OSC-style Collaborator Knowledge Model for cognitive state tracking.

    Tracks each worker's:
    - Knowledge domains: accumulated expertise from completed tasks
    - Knowledge freshness: how recently expertise was demonstrated
    - Cognitive load: current task burden and stress estimation
    - Collaboration graph: inter-worker cooperation history

    Used to align task assignment with workers' actual cognitive states,
    not just declared capabilities.
    """

    _KNOWLEDGE_DECAY_HALF_LIFE = 3600
    _MAX_DOMAIN_TERMS = 50
    _MAX_COLLAB_ENTRIES = 200

    def __init__(self):
        self._domain_knowledge: Dict[str, Dict[str, float]] = {}
        self._last_active: Dict[str, float] = {}
        self._collab_graph: Dict[str, List[tuple[str, float, float]]] = {}

    def _extract_terms(self, text: str) -> list[str]:
        import re
        words = re.findall(r'[a-zA-Z\u4e00-\u9fff]{2,}', text.lower())
        stop = {'the', 'and', 'for', 'with', 'this', 'that', 'from', 'have',
                'are', 'was', 'were', 'been', 'has', 'had', 'not', 'but',
                'all', 'can', 'will', 'would', 'could', 'should', 'may',
                '的', '了', '在', '是', '我', '有', '和', '就', '不', '人',
                '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去',
                '你', '会', '着', '没有', '看', '好', '自己', '这', '他', '她'}
        return [w for w in words if w not in stop]

    def record_task_result(self, worker_id: str, task_desc: str, success: bool, result: Any = None):
        now = time.time()
        self._last_active[worker_id] = now

        if not success:
            return

        terms = self._extract_terms(task_desc)
        if worker_id not in self._domain_knowledge:
            self._domain_knowledge[worker_id] = {}

        for term in terms[:10]:
            old = self._domain_knowledge[worker_id].get(term, 0.0)
            self._domain_knowledge[worker_id][term] = min(old + 0.3, 1.0)

        if len(self._domain_knowledge[worker_id]) > self._MAX_DOMAIN_TERMS:
            sorted_terms = sorted(
                self._domain_knowledge[worker_id].items(),
                key=lambda x: x[1],
            )
            for term, _ in sorted_terms[:10]:
                del self._domain_knowledge[worker_id][term]

        result_str = str(result)[:200] if result else ""
        result_terms = self._extract_terms(result_str)
        for term in result_terms[:5]:
            old = self._domain_knowledge[worker_id].get(term, 0.0)
            self._domain_knowledge[worker_id][term] = min(old + 0.15, 1.0)

    def record_collaboration(self, worker_a: str, worker_b: str, success: bool):
        now = time.time()
        for wid, other in [(worker_a, worker_b), (worker_b, worker_a)]:
            if wid not in self._collab_graph:
                self._collab_graph[wid] = []
            self._collab_graph[wid].append((other, now, 1.0 if success else 0.3))
            if len(self._collab_graph[wid]) > self._MAX_COLLAB_ENTRIES:
                self._collab_graph[wid] = self._collab_graph[wid][-self._MAX_COLLAB_ENTRIES:]

    def knowledge_match_score(self, worker_id: str, task_desc: str) -> float:
        if worker_id not in self._domain_knowledge:
            return 0.3

        now = time.time()
        terms = self._extract_terms(task_desc)
        if not terms:
            return 0.3

        scores = []
        for term in terms:
            knowledge = self._domain_knowledge[worker_id].get(term, 0.0)
            last_active = self._last_active.get(worker_id, 0)
            age = max(now - last_active, 0)
            decay = 2.0 ** (-age / self._KNOWLEDGE_DECAY_HALF_LIFE)
            scores.append(knowledge * decay)

        if not scores:
            return 0.3
        return sum(scores) / len(scores)

    def collaboration_score(self, worker_a: str, worker_b: str) -> float:
        if worker_a not in self._collab_graph:
            return 0.0
        now = time.time()
        entries = self._collab_graph.get(worker_a, [])
        scores = []
        for other, ts, quality in entries:
            if other == worker_b:
                age = max(now - ts, 0)
                decay = 2.0 ** (-age / 7200)
                scores.append(quality * decay)
        if not scores:
            return 0.0
        return sum(scores) / len(scores)

    def get_knowledge_summary(self, worker_id: str) -> dict:
        domains = self._domain_knowledge.get(worker_id, {})
        top_domains = sorted(domains.items(), key=lambda x: x[1], reverse=True)[:5]
        return {
            "worker_id": worker_id,
            "top_domains": [{"term": t, "strength": s} for t, s in top_domains],
            "domain_count": len(domains),
            "last_active": self._last_active.get(worker_id, 0),
            "collab_partners": len(self._collab_graph.get(worker_id, [])),
        }

    def cleanup_stale(self, max_age_seconds: float = 86400):
        now = time.time()
        stale = [wid for wid, last in self._last_active.items() if now - last > max_age_seconds]
        for wid in stale:
            self._domain_knowledge.pop(wid, None)
            self._last_active.pop(wid, None)
            self._collab_graph.pop(wid, None)


class WorkerPool:
    """Pool of worker agents with capability-based routing.
    
    Enhanced with:
    - OSC-style CKM for knowledge-aware task assignment
    - Failure-aware routing: recent failures deprioritize workers
    - Recency bias: workers that recently succeeded on similar tasks get bonus
    - Health monitoring: track worker responsiveness and error rates
    """

    MAX_FAILURE_HISTORY = 100
    FAILURE_DECAY_HALF_LIFE = 600
    MAX_HEALTH_CHECKS = 50
    HEALTH_CHECK_INTERVAL_SECONDS = 60
    UNHEALTHY_THRESHOLD = 0.3

    def __init__(self, ckm: Optional[CollaboratorKnowledgeModel] = None):
        self._workers: Dict[str, WorkerProfile] = {}
        self._agent_refs: Dict[str, Any] = {}
        self._ckm = ckm or CollaboratorKnowledgeModel()
        self._recent_failures: deque = deque(maxlen=self.MAX_FAILURE_HISTORY)
        self._health_checks: deque = deque(maxlen=self.MAX_HEALTH_CHECKS)
        self._unhealthy_workers: Dict[str, float] = {}

    def check_worker_health(self, worker_id: str) -> dict:
        profile = self._workers.get(worker_id)
        if not profile:
            return {"worker_id": worker_id, "status": "unknown"}
        now = time.time()
        recent_failures = sum(
            1 for f in self._recent_failures
            if f["worker_id"] == worker_id and now - f["timestamp"] < 300
        )
        health_score = 1.0
        if profile.total_tasks > 0:
            health_score = profile.success_rate
        if recent_failures > 3:
            health_score *= 0.5
        status = "healthy"
        if health_score < self.UNHEALTHY_THRESHOLD:
            status = "unhealthy"
            self._unhealthy_workers[worker_id] = now
        elif health_score < 0.6:
            status = "degraded"
        else:
            self._unhealthy_workers.pop(worker_id, None)
        result = {
            "worker_id": worker_id,
            "status": status,
            "health_score": round(health_score, 3),
            "success_rate": round(profile.success_rate, 3),
            "current_load": f"{profile.current_load}/{profile.max_concurrent}",
            "recent_failures_5m": recent_failures,
        }
        self._health_checks.append({"timestamp": now, **result})
        return result

    def record_failure_event(self, worker_id: str, capability: WorkerCapability, task_desc: str) -> None:
        self._recent_failures.append({
            "worker_id": worker_id,
            "capability": capability.value,
            "task_desc": task_desc[:200],
            "timestamp": time.time(),
        })

    def _failure_avoidance_score(self, worker_id: str, capability: WorkerCapability) -> float:
        if not self._recent_failures:
            return 1.0
        now = time.time()
        relevant = [
            f for f in self._recent_failures
            if f["worker_id"] == worker_id and f["capability"] == capability.value
        ]
        if not relevant:
            return 1.0
        weighted_failures = 0.0
        total_weight = 0.0
        for f in relevant:
            age = max(now - f["timestamp"], 0)
            decay = 2.0 ** (-age / self.FAILURE_DECAY_HALF_LIFE)
            weighted_failures += decay
            total_weight += decay
        if total_weight == 0:
            return 1.0
        normalized = weighted_failures / max(1, len(relevant))
        return max(0.1, 1.0 - normalized)

    def find_best_worker(self, capability: WorkerCapability, task_desc: str = "") -> Optional[str]:
        best_id = None
        best_score = -1.0
        for wid, profile in self._workers.items():
            if capability not in profile.capabilities and WorkerCapability.GENERAL not in profile.capabilities:
                continue
            if profile.current_load >= profile.max_concurrent:
                continue
            cap_match = 1.0 if capability in profile.capabilities else 0.5
            load_factor = 1.0 - (profile.current_load / profile.max_concurrent)
            knowledge_score = self._ckm.knowledge_match_score(wid, task_desc) if task_desc else 0.3
            failure_avoidance = self._failure_avoidance_score(wid, capability)
            health_penalty = 0.0
            if wid in self._unhealthy_workers:
                health_penalty = 0.5
            score = (
                cap_match * 0.25
                + profile.success_rate * 0.15
                + load_factor * 0.15
                + knowledge_score * 0.25
                + failure_avoidance * 0.20
                - health_penalty
            )
            if score > best_score:
                best_score = score
                best_id = wid
        if best_id and best_id in self._unhealthy_workers:
            logger.warning(
                "[WorkerPool] action=assigning_unhealthy worker=%s score=%.3f",
                best_id, best_score,
            )
        return best_id

    def register_worker(
        self,
        worker_id: str,
        capabilities: List[WorkerCapability],
        agent_ref: Any = None,
        max_concurrent: int = 3,
    ) -> None:
        self._workers[worker_id] = WorkerProfile(
            worker_id=worker_id,
            capabilities=capabilities,
            max_concurrent=max_concurrent,
        )
        if agent_ref:
            self._agent_refs[worker_id] = agent_ref
        logger.info("[WorkerPool] action=register worker=%s capabilities=%s", worker_id, [c.value for c in capabilities])

    def unregister_worker(self, worker_id: str) -> None:
        self._workers.pop(worker_id, None)
        self._agent_refs.pop(worker_id, None)

    def get_worker(self, worker_id: str) -> Optional[WorkerProfile]:
        return self._workers.get(worker_id)

    def increment_load(self, worker_id: str) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.current_load += 1
            w.total_tasks += 1

    def decrement_load(self, worker_id: str, success: bool = True) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.current_load = max(0, w.current_load - 1)
            if not success:
                w.failed_tasks += 1
                w.success_rate = 1.0 - (w.failed_tasks / max(1, w.total_tasks))

    def get_status(self) -> dict:
        return {
            "total_workers": len(self._workers),
            "unhealthy_workers": len(self._unhealthy_workers),
            "workers": {
                wid: {
                    "capabilities": [c.value for c in w.capabilities],
                    "load": f"{w.current_load}/{w.max_concurrent}",
                    "success_rate": f"{w.success_rate:.1%}",
                    "total_tasks": w.total_tasks,
                    "health": "unhealthy" if wid in self._unhealthy_workers else "healthy",
                }
                for wid, w in self._workers.items()
            },
        }


class OrchestratorWorkers:
    """Orchestrator-Workers pattern implementation.

    The orchestrator:
    1. Receives a complex task
    2. Decomposes it into subtasks (using LLM or rules)
    3. Assigns subtasks to workers based on capability matching
    4. Monitors progress via TaskBoard
    5. Aggregates results when all subtasks complete
    6. Self-evaluates the final result quality
    """

    _instance: Optional["OrchestratorWorkers"] = None

    def __init__(self):
        self.bus = AgentBus()
        self.task_board = TaskBoard()
        self.worker_pool = WorkerPool()
        self._orchestrations: Dict[str, OrchestrationResult] = {}
        self._running = False
        self._llm = None
        self._MAX_ORCHESTRATIONS = 100
        self._ORCHESTRATION_TTL_SECONDS = 3600
        self._last_cleanup_time = 0.0
        _ORCH_DIR.mkdir(parents=True, exist_ok=True)

    def set_llm(self, model) -> None:
        self._llm = model

    @classmethod
    def get_instance(cls) -> "OrchestratorWorkers":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    def _cleanup_expired_orchestrations(self):
        now = time.time()
        if now - self._last_cleanup_time < 300:
            return
        self._last_cleanup_time = now
        expired_ids = []
        cutoff = now - self._ORCHESTRATION_TTL_SECONDS
        for orch_id, result in self._orchestrations.items():
            if result.completed_at > 0 and result.completed_at < cutoff:
                expired_ids.append(orch_id)
        for orch_id in expired_ids:
            del self._orchestrations[orch_id]
            try:
                orch_file = _ORCH_DIR / f"{orch_id}.json"
                if orch_file.exists():
                    orch_file.unlink()
            except OSError:
                pass
        if expired_ids:
            logger.info("[Orchestrator] action=cleanup_expired count=%d ttl=%ds", len(expired_ids), self._ORCHESTRATION_TTL_SECONDS)
        self.worker_pool._ckm.cleanup_stale()

    async def orchestrate(
        self,
        task: str,
        max_subtasks: int = 5,
        timeout_seconds: float = 300.0,
        quality_threshold: float = 0.7,
        max_retries: int = 1,
    ) -> OrchestrationResult:
        orch_id = f"orch_{uuid.uuid4().hex[:8]}"
        start_time = time.time()
        self._cleanup_expired_orchestrations()

        result = OrchestrationResult(
            orchestration_id=orch_id,
            original_task=task,
            subtasks=[],
        )

        for attempt in range(max_retries + 1):
            result.retry_count = attempt

            subtasks = await self._decompose_task(task, max_subtasks)
            result.subtasks = subtasks

            for st in subtasks:
                await self.task_board.post_task(st)

            await self.bus.publish("orchestration.started", {
                "orchestration_id": orch_id,
                "task": task[:200],
                "subtask_count": len(subtasks),
            })

            execution_ok = await self._execute_subtasks(subtasks, timeout_seconds)
            if not execution_ok:
                result.success = False
                result.final_result = "Execution timed out or failed"
                continue

            aggregated = await self._aggregate_results(subtasks)
            result.final_result = aggregated

            quality = await self._evaluate_quality(task, aggregated)
            result.quality_score = quality

            if quality >= quality_threshold:
                result.success = True
                break
            else:
                logger.info(
                    "[Orchestrator] action=quality_below_threshold orch=%s quality=%.2f threshold=%.2f retry=%d/%d",
                    orch_id, quality, quality_threshold, attempt + 1, max_retries,
                )
                await self.task_board.complete_task("__reset__", None)
                for st in subtasks:
                    await self.task_board.reset_task(st.task_id)
                    st.status = TaskStatus.PENDING
                    st.result = None
                    st.error = ""
                result.subtasks = subtasks

        result.total_time_ms = (time.time() - start_time) * 1000
        result.completed_at = time.time()
        result.workers_used = list({
            st.assigned_worker for st in result.subtasks if st.assigned_worker
        })

        self._orchestrations[orch_id] = result
        if len(self._orchestrations) > self._MAX_ORCHESTRATIONS:
            oldest = next(iter(self._orchestrations))
            del self._orchestrations[oldest]
        await self._persist_result(result)

        await self.bus.publish("orchestration.completed", {
            "orchestration_id": orch_id,
            "success": result.success,
            "quality_score": result.quality_score,
            "total_time_ms": result.total_time_ms,
        })

        return result

    async def _decompose_task(self, task: str, max_subtasks: int) -> List[SubTask]:
        llm_subtasks = await self._llm_decompose(task, max_subtasks)
        if llm_subtasks:
            return llm_subtasks

        subtasks = []

        capability_map = {
            "代码": WorkerCapability.CODE,
            "code": WorkerCapability.CODE,
            "编程": WorkerCapability.CODE,
            "研究": WorkerCapability.RESEARCH,
            "research": WorkerCapability.RESEARCH,
            "搜索": WorkerCapability.RESEARCH,
            "写作": WorkerCapability.WRITING,
            "writing": WorkerCapability.WRITING,
            "文档": WorkerCapability.WRITING,
            "分析": WorkerCapability.ANALYSIS,
            "analysis": WorkerCapability.ANALYSIS,
            "数据": WorkerCapability.DATA,
            "data": WorkerCapability.DATA,
            "统计": WorkerCapability.DATA,
        }

        parts = [p.strip() for p in task.replace("；", ";").replace("，然后", ";").replace("，接着", ";").split(";") if p.strip()]

        if not parts:
            parts = [task]

        if len(parts) == 1 and len(parts[0]) > 100:
            parts = [task]

        for i, part in enumerate(parts[:max_subtasks]):
            cap = WorkerCapability.GENERAL
            part_lower = part.lower()
            for keyword, capability in capability_map.items():
                if keyword in part_lower:
                    cap = capability
                    break

            subtasks.append(SubTask(
                description=part,
                capability=cap,
                priority=max_subtasks - i,
            ))

        return subtasks

    async def _llm_decompose(self, task: str, max_subtasks: int) -> Optional[List[SubTask]]:
        if not self._llm:
            return None

        prompt = (
            f"Break down the following task into {max_subtasks} or fewer subtasks.\n"
            f"Each subtask should have: id, description, dependencies (list of ids), priority (1-5, 5=highest).\n\n"
            f"Task: {task}\n\n"
            f'Output ONLY valid JSON array:\n'
            f'[{{"id": "sub1", "description": "...", "dependencies": [], "priority": 3}}]'
        )

        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(None, lambda: self._llm(prompt))
            text = response.text if hasattr(response, "text") else str(response)
            import re
            json_match = re.search(r'\[.*\]', text, re.DOTALL)
            if not json_match:
                return None

            data = json.loads(json_match.group())
            if not isinstance(data, list) or not data:
                return None

            subtasks = []
            for item in data[:max_subtasks]:
                deps = item.get("dependencies", [])
                if isinstance(deps, str):
                    deps = [d.strip() for d in deps.split(",") if d.strip()]
                subtasks.append(SubTask(
                    task_id=item.get("id", f"sub{len(subtasks)+1}"),
                    description=item.get("description", ""),
                    dependencies=deps,
                    priority=min(5, max(1, item.get("priority", 3))),
                ))
            return subtasks
        except Exception as e:
            logger.debug("LLM decomposition failed, falling back to rule-based: %s", e)
            return None

    async def _execute_subtasks(self, subtasks: List[SubTask], timeout: float) -> bool:
        pending = [st for st in subtasks if st.status == TaskStatus.PENDING]
        if not pending:
            return True

        has_deps = any(st.dependencies for st in pending)
        if has_deps:
            return await self._execute_dag(subtasks, timeout)

        async def _run_subtask(st: SubTask) -> None:
            worker_id = self.worker_pool.find_best_worker(st.capability, st.description)
            if not worker_id:
                st.status = TaskStatus.FAILED
                st.error = f"No available worker for capability {st.capability.value}"
                logger.warning("[Orchestrator] action=no_worker capability=%s task=%s", st.capability.value, st.task_id)
                return

            st.assigned_worker = worker_id
            st.status = TaskStatus.RUNNING
            st.started_at = datetime.now().isoformat()
            self.worker_pool.increment_load(worker_id)

            try:
                agent_ref = self.worker_pool._agent_refs.get(worker_id)
                if agent_ref and hasattr(agent_ref, "reply"):
                    msg_result = await asyncio.wait_for(
                        agent_ref.reply(st.description),
                        timeout=timeout / max(1, len(subtasks)),
                    )
                    st.result = str(msg_result) if msg_result else ""
                    st.status = TaskStatus.COMPLETED
                else:
                    st.result = f"[Worker {worker_id} processed: {st.description[:100]}]"
                    st.status = TaskStatus.COMPLETED

                st.completed_at = datetime.now().isoformat()
                await self.task_board.complete_task(st.task_id, st.result, success=True)
                self.worker_pool.decrement_load(worker_id, success=True)
                self.worker_pool._ckm.record_task_result(
                    worker_id, st.description, success=True, result=st.result,
                )

            except asyncio.TimeoutError:
                st.status = TaskStatus.FAILED
                st.error = "Subtask timed out"
                self.worker_pool.decrement_load(worker_id, success=False)
                self.worker_pool._ckm.record_task_result(
                    worker_id, st.description, success=False,
                )
                self.worker_pool.record_failure_event(worker_id, st.capability, st.description)
            except Exception as e:
                st.status = TaskStatus.FAILED
                st.error = str(e)
                self.worker_pool.decrement_load(worker_id, success=False)
                self.worker_pool._ckm.record_task_result(
                    worker_id, st.description, success=False,
                )
                self.worker_pool.record_failure_event(worker_id, st.capability, st.description)

        async def _run_with_backoff(st: SubTask, max_retries: int = 3, base_delay: float = 1.0) -> None:
            for attempt in range(max_retries):
                try:
                    await _run_subtask(st)
                    if st.status == TaskStatus.COMPLETED:
                        return
                except Exception as _retry_err:
                    logger.debug("Subtask retry attempt %d failed: %s", attempt, _retry_err)
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt)
                    await asyncio.sleep(delay)

        _background_tasks: set = set()

        def _track(task: asyncio.Task) -> None:
            _background_tasks.add(task)
            task.add_done_callback(_background_tasks.discard)

        tasks = [asyncio.create_task(_run_with_backoff(st)) for st in pending]
        for t in tasks:
            _track(t)
        try:
            await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            for t in tasks:
                if not t.done():
                    t.cancel()
            return False

        return all(st.status == TaskStatus.COMPLETED for st in subtasks)

    async def _execute_dag(self, subtasks: List[SubTask], timeout: float) -> bool:
        id_map = {st.task_id: st for st in subtasks}
        completed_ids: set = set()
        failed_ids: set = set()

        for st in subtasks:
            for dep_id in st.dependencies:
                if dep_id not in id_map:
                    logger.warning(
                        "[Orchestrator] action=unknown_dependency task=%s dep=%s",
                        st.task_id, dep_id,
                    )
                    st.status = TaskStatus.FAILED
                    st.error = f"Unknown dependency: {dep_id}"
                    failed_ids.add(st.task_id)

        def _get_ready() -> List[SubTask]:
            ready = []
            for st in subtasks:
                if st.status != TaskStatus.PENDING:
                    continue
                if st.task_id in completed_ids or st.task_id in failed_ids:
                    continue
                deps_met = all(
                    d in completed_ids for d in st.dependencies
                    if d in id_map
                )
                deps_failed = any(
                    d in failed_ids for d in st.dependencies
                    if d in id_map
                )
                if deps_failed:
                    st.status = TaskStatus.FAILED
                    st.error = f"Dependency failed"
                    failed_ids.add(st.task_id)
                    continue
                if deps_met:
                    ready.append(st)
            return ready

        start_time = time.time()
        while True:
            ready = _get_ready()
            if not ready:
                break

            elapsed = time.time() - start_time
            remaining_timeout = max(10, timeout - elapsed)
            current_timeout = remaining_timeout

            async def _run_one(st: SubTask, _timeout: float) -> None:
                worker_id = self.worker_pool.find_best_worker(st.capability, st.description)
                if not worker_id:
                    st.status = TaskStatus.FAILED
                    st.error = f"No worker for {st.capability.value}"
                    logger.warning("[Orchestrator] action=dag_no_worker capability=%s task=%s", st.capability.value, st.task_id)
                    return
                st.assigned_worker = worker_id
                st.status = TaskStatus.RUNNING
                st.started_at = datetime.now().isoformat()
                self.worker_pool.increment_load(worker_id)
                try:
                    agent_ref = self.worker_pool._agent_refs.get(worker_id)
                    if agent_ref and hasattr(agent_ref, "reply"):
                        msg_result = await asyncio.wait_for(
                            agent_ref.reply(st.description),
                            timeout=_timeout / max(1, len(ready)),
                        )
                        st.result = str(msg_result) if msg_result else ""
                        st.status = TaskStatus.COMPLETED
                    else:
                        st.result = f"[Worker {worker_id} processed: {st.description[:100]}]"
                        st.status = TaskStatus.COMPLETED
                    st.completed_at = datetime.now().isoformat()
                    self.worker_pool.decrement_load(worker_id, success=True)
                    self.worker_pool._ckm.record_task_result(
                        worker_id, st.description, success=True, result=st.result,
                    )
                except asyncio.TimeoutError:
                    st.status = TaskStatus.FAILED
                    st.error = "Subtask timed out"
                    self.worker_pool.decrement_load(worker_id, success=False)
                    self.worker_pool._ckm.record_task_result(
                        worker_id, st.description, success=False,
                    )
                    self.worker_pool.record_failure_event(worker_id, st.capability, st.description)
                except Exception as e:
                    st.status = TaskStatus.FAILED
                    st.error = str(e)
                    self.worker_pool.decrement_load(worker_id, success=False)
                    self.worker_pool._ckm.record_task_result(
                        worker_id, st.description, success=False,
                    )
                    self.worker_pool.record_failure_event(worker_id, st.capability, st.description)

            _bg_tasks: set = set()

            def _track2(task: asyncio.Task) -> None:
                _bg_tasks.add(task)
                task.add_done_callback(_bg_tasks.discard)

            tasks = [asyncio.create_task(_run_one(st, current_timeout)) for st in ready]
            for t in tasks:
                _track2(t)
            try:
                await asyncio.wait_for(
                    asyncio.gather(*tasks, return_exceptions=True),
                    timeout=remaining_timeout,
                )
            except asyncio.TimeoutError:
                for t in tasks:
                    if not t.done():
                        t.cancel()

            for st in ready:
                if st.status == TaskStatus.COMPLETED:
                    completed_ids.add(st.task_id)
                elif st.status == TaskStatus.FAILED:
                    failed_ids.add(st.task_id)

            if time.time() - start_time > timeout:
                break

        return all(st.status == TaskStatus.COMPLETED for st in subtasks)

    async def _aggregate_results(self, subtasks: List[SubTask]) -> str:
        completed = [st for st in subtasks if st.status == TaskStatus.COMPLETED and st.result]
        if not completed:
            failed = [st for st in subtasks if st.status == TaskStatus.FAILED]
            errors = "; ".join(f"{st.description}: {st.error}" for st in failed)
            return f"Task failed. Errors: {errors}"

        if len(completed) == 1:
            return str(completed[0].result)

        parts = []
        for i, st in enumerate(completed, 1):
            parts.append(f"## Part {i}: {st.description}\n{st.result}")

        return "\n\n".join(parts)

    async def _evaluate_quality(self, original_task: str, result: str) -> float:
        if not result or "failed" in result.lower():
            return 0.0

        score = 0.5

        if len(result) > 50:
            score += 0.1
        if len(result) > 200:
            score += 0.1

        try:
            import jieba
            task_keywords = set(t for t in jieba.cut(original_task) if t.strip())
        except ImportError:
            task_keywords = set(original_task.lower().split())
        result_lower = result.lower()
        keyword_coverage = sum(1 for kw in task_keywords if kw in result_lower) / max(1, len(task_keywords))
        score += keyword_coverage * 0.2

        if "error" in result.lower() or "failed" in result.lower():
            score -= 0.2

        return max(0.0, min(1.0, score))

    async def _persist_result(self, result: OrchestrationResult) -> None:
        try:
            data = {
                "orchestration_id": result.orchestration_id,
                "original_task": result.original_task[:500],
                "success": result.success,
                "quality_score": result.quality_score,
                "total_time_ms": result.total_time_ms,
                "subtask_count": len(result.subtasks),
                "workers_used": result.workers_used,
                "retry_count": result.retry_count,
                "timestamp": datetime.now().isoformat(),
            }
            fpath = _ORCH_DIR / f"{result.orchestration_id}.json"
            tmp = fpath.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
            tmp.replace(fpath)
        except Exception as e:
            logger.warning("[Orchestrator] action=persist_failed error=%s", e)

    def get_status(self) -> dict:
        task_board_status = {"total_tasks": 0}
        if self._orchestrations:
            try:
                task_board_status = run_async_safe(self.task_board.get_status())
            except Exception as _tb_err:
                logger.debug("Task board status lookup failed: %s", _tb_err)
                task_board_status = {"total_tasks": len(self.task_board._tasks)}
        return {
            "total_orchestrations": len(self._orchestrations),
            "worker_pool": self.worker_pool.get_status(),
            "task_board": task_board_status,
            "recent_orchestrations": [
                {
                    "id": r.orchestration_id,
                    "success": r.success,
                    "quality": r.quality_score,
                    "time_ms": r.total_time_ms,
                }
                for r in list(self._orchestrations.values())[-10:]
            ],
        }

    def get_orchestration(self, orch_id: str) -> Optional[OrchestrationResult]:
        return self._orchestrations.get(orch_id)

    def list_orchestrations(self, limit: int = 20) -> List[dict]:
        results = []
        for r in list(self._orchestrations.values())[-limit:]:
            results.append({
                "orchestration_id": r.orchestration_id,
                "original_task": r.original_task[:100],
                "success": r.success,
                "quality_score": r.quality_score,
                "total_time_ms": r.total_time_ms,
                "subtask_count": len(r.subtasks),
                "workers_used": r.workers_used,
                "retry_count": r.retry_count,
            })
        return results


class SideEffectTracker:
    """Tracks side effects of tool calls for safety and rollback."""

    IRREVERSIBLE_TOOLS = {"delete_file", "shell_exec", "write_file"}
    _instance = None

    def __init__(self):
        self._effects: deque = deque(maxlen=500)

    @classmethod
    def get_instance(cls) -> "SideEffectTracker":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def track(self, tool_name: str, args: Dict, result: str = "") -> Dict:
        effect = {
            "tool": tool_name,
            "args": {k: str(v)[:200] for k, v in args.items()} if isinstance(args, dict) else str(args)[:200],
            "result_summary": str(result)[:200],
            "timestamp": time.time(),
            "irreversible": tool_name in self.IRREVERSIBLE_TOOLS,
        }
        self._effects.append(effect)
        return effect

    def get_effects(self, limit: int = 50) -> List[Dict]:
        return list(self._effects)[-limit:]

    def has_irreversible(self) -> bool:
        return any(e["irreversible"] for e in self._effects)

    def clear(self) -> None:
        self._effects.clear()
