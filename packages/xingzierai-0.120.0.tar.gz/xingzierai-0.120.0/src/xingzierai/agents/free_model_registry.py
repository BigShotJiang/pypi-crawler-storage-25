#!/usr/bin/env python3
"""
FreeModelRegistry - 免费模型能力注册表

追踪免费模型的能力：
- 是否支持工具调用
- 是否是推理模型（reasoning-only）
- 健康状态
- 响应延迟

数据来源：
1. 静态注册（已知能力）
2. 运行时探测（实际测试）
3. OpenCode /models API 发现
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class FreeModelCapability(str, Enum):
    TOOL_CALLING = "tool_calling"
    REASONING_ONLY = "reasoning_only"
    CHAT_ONLY = "chat_only"
    STREAMING = "streaming"
    IMAGE_INPUT = "image_input"


class FreeModelHealth(str, Enum):
    UNKNOWN = "unknown"
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    DOWN = "down"


@dataclass
class FreeModelProfile:
    model_id: str
    provider_id: str
    capabilities: List[FreeModelCapability] = field(default_factory=list)
    health: FreeModelHealth = FreeModelHealth.UNKNOWN
    avg_latency_ms: float = 0.0
    last_checked: float = 0.0
    success_count: int = 0
    fail_count: int = 0
    cost_per_1k_tokens: float = 0.0

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        if total == 0:
            return 0.0
        return self.success_count / total

    @property
    def supports_tool_calling(self) -> bool:
        return FreeModelCapability.TOOL_CALLING in self.capabilities

    @property
    def is_reasoning_only(self) -> bool:
        return FreeModelCapability.REASONING_ONLY in self.capabilities


STATIC_PROFILES: Dict[str, FreeModelProfile] = {
    "nemotron-3-super-free": FreeModelProfile(
        model_id="nemotron-3-super-free",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.CHAT_ONLY,
            FreeModelCapability.STREAMING,
            FreeModelCapability.REASONING_ONLY,
        ],
        health=FreeModelHealth.HEALTHY,
        cost_per_1k_tokens=0.0,
    ),
    "big-pickle": FreeModelProfile(
        model_id="big-pickle",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.REASONING_ONLY,
        ],
        health=FreeModelHealth.DEGRADED,
        cost_per_1k_tokens=0.0,
    ),
    "minimax-m2.5-free": FreeModelProfile(
        model_id="minimax-m2.5-free",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.CHAT_ONLY,
            FreeModelCapability.REASONING_ONLY,
        ],
        health=FreeModelHealth.HEALTHY,
        cost_per_1k_tokens=0.0,
    ),
    "hy3-preview-free": FreeModelProfile(
        model_id="hy3-preview-free",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.CHAT_ONLY,
            FreeModelCapability.REASONING_ONLY,
        ],
        health=FreeModelHealth.HEALTHY,
        cost_per_1k_tokens=0.0,
    ),
    "ling-2.6-flash-free": FreeModelProfile(
        model_id="ling-2.6-flash-free",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.CHAT_ONLY,
        ],
        health=FreeModelHealth.DOWN,
        cost_per_1k_tokens=0.0,
    ),
    "trinity-large-preview-free": FreeModelProfile(
        model_id="trinity-large-preview-free",
        provider_id="opencode",
        capabilities=[
            FreeModelCapability.CHAT_ONLY,
        ],
        health=FreeModelHealth.DOWN,
        cost_per_1k_tokens=0.0,
    ),
}

MAX_PROFILES = 50
HEALTH_CHECK_INTERVAL = int(os.getenv("XINGZIERAI_FREE_MODEL_CHECK_INTERVAL", "300"))
HEALTHY_CACHE_TTL = 60
PERSIST_PATH = Path.home() / ".xingzierai" / "free_model_profiles.json"
STALE_THRESHOLD_SECONDS = 86400
MAX_SUCCESS_FAIL_COUNT = 1000


class FreeModelRegistry:
    def __init__(self):
        self._profiles: Dict[str, FreeModelProfile] = dict(STATIC_PROFILES)
        self._last_health_check: float = 0.0
        self._last_discover: float = 0.0
        self._persist_path = PERSIST_PATH
        self._health_check_task: Optional[asyncio.Task] = None
        self._healthy_cache: List[FreeModelProfile] = []
        self._chat_cache: List[FreeModelProfile] = []
        self._cache_ts: float = 0.0
        self._load()

    def _refresh_cache(self):
        now = time.time()
        if now - self._cache_ts < HEALTHY_CACHE_TTL and self._healthy_cache:
            return
        self._healthy_cache = [
            p for p in self._profiles.values()
            if p.health in (FreeModelHealth.HEALTHY, FreeModelHealth.UNKNOWN)
        ]
        self._chat_cache = [
            p for p in self._healthy_cache
            if not p.is_reasoning_only
        ]
        self._cache_ts = now

    async def start_background_tasks(self):
        """Start periodic health check and discovery tasks."""
        if self._health_check_task is None:
            self._health_check_task = asyncio.create_task(self._periodic_maintenance())
            logger.info("FreeModelRegistry: background maintenance started")

    async def _periodic_maintenance(self):
        """Periodically discover new models and health-check existing ones."""
        while True:
            try:
                await asyncio.sleep(HEALTH_CHECK_INTERVAL)

                if time.time() - self._last_discover > 3600:
                    discovered = await self.discover_opencode_models()
                    if discovered:
                        logger.info(f"FreeModelRegistry: discovered {len(discovered)} new models")
                    self._last_discover = time.time()

                results = await self.health_check_all()
                healthy = sum(1 for v in results.values() if v.get("health") == "healthy")
                logger.info(f"FreeModelRegistry: health check complete, {healthy}/{len(results)} healthy")
                self._last_health_check = time.time()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"FreeModelRegistry: maintenance error: {e}")

    def get_profile(self, model_id: str) -> Optional[FreeModelProfile]:
        return self._profiles.get(model_id)

    def get_healthy_models(self) -> List[FreeModelProfile]:
        self._refresh_cache()
        return list(self._healthy_cache)

    def get_tool_calling_models(self) -> List[FreeModelProfile]:
        self._refresh_cache()
        return [
            p for p in self._healthy_cache
            if p.supports_tool_calling
        ]

    def get_chat_models(self) -> List[FreeModelProfile]:
        self._refresh_cache()
        return list(self._chat_cache)

    def get_best_free_model(self, need_tool_calling: bool = False) -> Optional[FreeModelProfile]:
        if need_tool_calling:
            candidates = self.get_tool_calling_models()
        else:
            candidates = self.get_chat_models()

        if not candidates:
            candidates = self.get_healthy_models()

        if not candidates:
            return None

        candidates.sort(key=lambda p: (
            0 if p.health == FreeModelHealth.HEALTHY else 1,
            -p.success_rate,
            p.avg_latency_ms if p.avg_latency_ms > 0 else float('inf'),
        ))
        return candidates[0]

    def record_result(self, model_id: str, success: bool, latency_ms: float = 0.0):
        profile = self._profiles.get(model_id)
        if profile is None:
            profile = FreeModelProfile(model_id=model_id, provider_id="opencode")
            self._profiles[model_id] = profile

        if success:
            profile.success_count += 1
            profile.health = FreeModelHealth.HEALTHY
        else:
            profile.fail_count += 1
            if profile.success_rate < 0.3 and profile.fail_count >= 3:
                profile.health = FreeModelHealth.DOWN

        if profile.success_count > MAX_SUCCESS_FAIL_COUNT:
            profile.success_count = MAX_SUCCESS_FAIL_COUNT
        if profile.fail_count > MAX_SUCCESS_FAIL_COUNT:
            profile.fail_count = MAX_SUCCESS_FAIL_COUNT

        if latency_ms > 0:
            if profile.avg_latency_ms == 0:
                profile.avg_latency_ms = latency_ms
            else:
                profile.avg_latency_ms = 0.7 * profile.avg_latency_ms + 0.3 * latency_ms

        profile.last_checked = time.time()
        self._cache_ts = 0.0
        self._persist()

    def register_model(self, profile: FreeModelProfile):
        if len(self._profiles) >= MAX_PROFILES and profile.model_id not in self._profiles:
            oldest = min(self._profiles.values(), key=lambda p: p.last_checked)
            del self._profiles[oldest.model_id]
        self._profiles[profile.model_id] = profile
        self._persist()

    async def probe_model(self, model_id: str, base_url: str = "https://opencode.ai/zen/v1") -> FreeModelProfile:
        import aiohttp

        profile = self._profiles.get(model_id, FreeModelProfile(
            model_id=model_id, provider_id="opencode"
        ))

        start = time.time()
        try:
            async with aiohttp.ClientSession() as session:
                payload = {
                    "model": model_id,
                    "messages": [{"role": "user", "content": "Hi"}],
                    "max_tokens": 5,
                }
                async with session.post(
                    f"{base_url}/chat/completions",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    latency_ms = (time.time() - start) * 1000
                    if resp.status == 200:
                        data = await resp.json()
                        content = ""
                        choices = data.get("choices", [])
                        if choices:
                            content = choices[0].get("message", {}).get("content", "")
                        if content:
                            profile.health = FreeModelHealth.HEALTHY
                            if FreeModelCapability.CHAT_ONLY not in profile.capabilities:
                                profile.capabilities.append(FreeModelCapability.CHAT_ONLY)
                        else:
                            profile.health = FreeModelHealth.DEGRADED
                            if FreeModelCapability.REASONING_ONLY not in profile.capabilities:
                                profile.capabilities.append(FreeModelCapability.REASONING_ONLY)
                        profile.success_count += 1
                        profile.avg_latency_ms = latency_ms
                    else:
                        profile.fail_count += 1
                        if profile.fail_count >= 3:
                            profile.health = FreeModelHealth.DOWN
        except Exception as e:
            profile.fail_count += 1
            profile.health = FreeModelHealth.DOWN
            logger.warning(f"FreeModelRegistry: probe {model_id} failed: {e}")

        profile.last_checked = time.time()
        self._profiles[model_id] = profile
        self._persist()
        return profile

    async def discover_opencode_models(self) -> List[FreeModelProfile]:
        import aiohttp

        discovered = []
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "https://opencode.ai/zen/v1/models",
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        for m in data.get("data", []):
                            mid = m.get("id", "")
                            if "free" in mid.lower() or mid == "big-pickle":
                                existing = self._profiles.get(mid)
                                if existing is None:
                                    profile = FreeModelProfile(
                                        model_id=mid,
                                        provider_id="opencode",
                                        capabilities=[FreeModelCapability.CHAT_ONLY],
                                        health=FreeModelHealth.UNKNOWN,
                                        cost_per_1k_tokens=0.0,
                                    )
                                    self._profiles[mid] = profile
                                    discovered.append(profile)
                                    logger.info(f"FreeModelRegistry: 发现新免费模型 {mid}")
        except Exception as e:
            logger.warning(f"FreeModelRegistry: discover failed: {e}")

        if discovered:
            self._persist()
        return discovered

    async def health_check_all(self) -> Dict[str, Any]:
        """Probe all registered free models concurrently and return updated stats."""
        results = {}
        tasks = []
        model_ids = list(self._profiles.keys())

        async def _probe_one(mid: str):
            try:
                profile = await self.probe_model(mid)
                return mid, {
                    "health": profile.health.value,
                    "latency_ms": round(profile.avg_latency_ms, 1),
                }
            except Exception as e:
                return mid, {"health": "error", "error": str(e)}

        for mid in model_ids:
            tasks.append(asyncio.create_task(_probe_one(mid)))

        completed = await asyncio.gather(*tasks, return_exceptions=True)
        for result in completed:
            if isinstance(result, Exception):
                continue
            mid, data = result
            results[mid] = data

        return results

    def get_stats(self) -> Dict[str, Any]:
        healthy = sum(1 for p in self._profiles.values() if p.health == FreeModelHealth.HEALTHY)
        degraded = sum(1 for p in self._profiles.values() if p.health == FreeModelHealth.DEGRADED)
        down = sum(1 for p in self._profiles.values() if p.health == FreeModelHealth.DOWN)
        unknown = sum(1 for p in self._profiles.values() if p.health == FreeModelHealth.UNKNOWN)
        tool_capable = sum(1 for p in self._profiles.values() if p.supports_tool_calling)
        return {
            "total_models": len(self._profiles),
            "healthy": healthy,
            "degraded": degraded,
            "down": down,
            "unknown": unknown,
            "tool_calling_capable": tool_capable,
            "models": {
                mid: {
                    "health": p.health.value,
                    "capabilities": [c.value for c in p.capabilities],
                    "success_rate": round(p.success_rate, 2),
                    "avg_latency_ms": round(p.avg_latency_ms, 1),
                    "supports_tool_calling": p.supports_tool_calling,
                    "is_reasoning_only": p.is_reasoning_only,
                }
                for mid, p in self._profiles.items()
            },
        }

    def _persist(self):
        try:
            self._persist_path.parent.mkdir(parents=True, exist_ok=True)
            data = {}
            for mid, p in self._profiles.items():
                data[mid] = {
                    "model_id": p.model_id,
                    "provider_id": p.provider_id,
                    "capabilities": [c.value for c in p.capabilities],
                    "health": p.health.value,
                    "avg_latency_ms": p.avg_latency_ms,
                    "last_checked": p.last_checked,
                    "success_count": p.success_count,
                    "fail_count": p.fail_count,
                    "cost_per_1k_tokens": p.cost_per_1k_tokens,
                }
            tmp = self._persist_path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            tmp.replace(self._persist_path)
        except Exception as e:
            logger.warning(f"FreeModelRegistry: persist failed: {e}")

    def _load(self):
        try:
            if not self._persist_path.exists():
                return
            with open(self._persist_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for mid, d in data.items():
                if mid in self._profiles:
                    p = self._profiles[mid]
                    p.health = FreeModelHealth(d.get("health", "unknown"))
                    p.avg_latency_ms = d.get("avg_latency_ms", 0.0)
                    p.last_checked = d.get("last_checked", 0.0)
                    p.success_count = min(d.get("success_count", 0), MAX_SUCCESS_FAIL_COUNT)
                    p.fail_count = min(d.get("fail_count", 0), MAX_SUCCESS_FAIL_COUNT)
                    saved_caps = d.get("capabilities", [])
                    p.capabilities = [
                        FreeModelCapability(c) for c in saved_caps
                        if c in [cap.value for cap in FreeModelCapability]
                    ]
                    if p.last_checked > 0 and (time.time() - p.last_checked) > STALE_THRESHOLD_SECONDS:
                        p.health = FreeModelHealth.UNKNOWN
                        logger.info(f"FreeModelRegistry: {mid} stale (>24h), reset to UNKNOWN")
                else:
                    p = FreeModelProfile(
                        model_id=mid,
                        provider_id=d.get("provider_id", "opencode"),
                        capabilities=[
                            FreeModelCapability(c) for c in d.get("capabilities", [])
                            if c in [cap.value for cap in FreeModelCapability]
                        ],
                        health=FreeModelHealth(d.get("health", "unknown")),
                        avg_latency_ms=d.get("avg_latency_ms", 0.0),
                        last_checked=d.get("last_checked", 0.0),
                        success_count=min(d.get("success_count", 0), MAX_SUCCESS_FAIL_COUNT),
                        fail_count=min(d.get("fail_count", 0), MAX_SUCCESS_FAIL_COUNT),
                        cost_per_1k_tokens=d.get("cost_per_1k_tokens", 0.0),
                    )
                    self._profiles[mid] = p
            if len(self._profiles) > MAX_PROFILES:
                sorted_profiles = sorted(
                    self._profiles.items(), key=lambda x: x[1].last_checked
                )
                self._profiles = dict(sorted_profiles[-MAX_PROFILES:])
        except Exception as e:
            logger.warning(f"FreeModelRegistry: load failed: {e}")


_registry: Optional[FreeModelRegistry] = None


def get_free_model_registry() -> FreeModelRegistry:
    global _registry
    if _registry is None:
        _registry = FreeModelRegistry()
    return _registry
