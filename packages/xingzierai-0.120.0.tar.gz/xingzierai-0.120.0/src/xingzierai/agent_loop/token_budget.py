# -*- coding: utf-8 -*-
"""TokenBudget - Dynamic token budget monitoring.

From Claude Code architecture:
- Token Budget dynamic monitoring
- 14.7万 safe line (vs 700K token redundancy in traditional systems)
- Dead loop circuit breaker protection
- Progressive context compression (3-stage density gradient)

Three-stage density gradient:
1. Full fidelity (recent messages)
2. Summarized (mid-range messages)
3. Key facts only (old messages)
"""

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class BudgetLevel(str, Enum):
    """Token budget alert levels."""
    NORMAL = "normal"
    CAUTION = "caution"
    WARNING = "warning"
    CRITICAL = "critical"
    EXCEEDED = "exceeded"


@dataclass
class BudgetPolicy:
    """Policy for token budget management.

    Inspired by Claude Code's 147K safe line:
    - Total context window typically 128K-200K tokens
    - Safe operating line at ~70% of max
    - Caution at 50%, Warning at 65%, Critical at 75%
    """
    max_tokens: int = 200000
    safe_line: int = 147000
    caution_threshold: float = 0.50
    warning_threshold: float = 0.65
    critical_threshold: float = 0.75
    auto_compact_at: float = 0.70
    hard_stop_at: float = 0.90
    reserve_for_response: int = 8000
    max_iterations: int = 50
    max_tool_calls_per_iteration: int = 10


@dataclass
class BudgetSnapshot:
    """Snapshot of current token budget state."""
    total_used: int = 0
    total_budget: int = 0
    usage_ratio: float = 0.0
    level: BudgetLevel = BudgetLevel.NORMAL
    prompt_tokens: int = 0
    completion_tokens: int = 0
    system_prompt_tokens: int = 0
    compressed_summary_tokens: int = 0
    recent_messages_tokens: int = 0
    available_for_response: int = 0
    iteration_count: int = 0
    tool_call_count: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_used": self.total_used,
            "total_budget": self.total_budget,
            "usage_ratio": self.usage_ratio,
            "level": self.level.value,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "available_for_response": self.available_for_response,
            "iteration_count": self.iteration_count,
            "tool_call_count": self.tool_call_count,
        }


class TokenBudget:
    """Dynamic token budget monitor with circuit breaker.

    Features:
    - Real-time token usage tracking
    - Multi-level alerts (caution → warning → critical → exceeded)
    - Auto-compact trigger at threshold
    - Hard stop to prevent context overflow
    - Iteration and tool call limits
    - Three-stage density gradient for memory compression

    Usage:
        budget = TokenBudget(BudgetPolicy(max_tokens=128000))

        # Before each LLM call
        snapshot = budget.check(tokens_used=50000)
        if snapshot.level == BudgetLevel.CRITICAL:
            # Force compaction
            await compact_memory()
    """

    def __init__(self, policy: Optional[BudgetPolicy] = None):
        """Initialize token budget monitor.

        Args:
            policy: Budget policy configuration
        """
        self.policy = policy or BudgetPolicy()
        self._total_used = 0
        self._prompt_tokens = 0
        self._completion_tokens = 0
        self._system_prompt_tokens = 0
        self._compressed_summary_tokens = 0
        self._recent_messages_tokens = 0
        self._iteration_count = 0
        self._tool_call_count = 0
        self._callbacks: Dict[BudgetLevel, List[Callable]] = {
            level: [] for level in BudgetLevel
        }
        self._compaction_triggered = False

    def check(self, tokens_used: Optional[int] = None) -> BudgetSnapshot:
        """Check current budget status.

        Args:
            tokens_used: Optional explicit token count

        Returns:
            BudgetSnapshot with current state
        """
        if tokens_used is not None:
            self._total_used = tokens_used

        usage_ratio = self._total_used / self.policy.max_tokens if self.policy.max_tokens > 0 else 0
        available = self.policy.max_tokens - self._total_used - self.policy.reserve_for_response

        level = self._determine_level(usage_ratio)

        snapshot = BudgetSnapshot(
            total_used=self._total_used,
            total_budget=self.policy.max_tokens,
            usage_ratio=usage_ratio,
            level=level,
            prompt_tokens=self._prompt_tokens,
            completion_tokens=self._completion_tokens,
            system_prompt_tokens=self._system_prompt_tokens,
            compressed_summary_tokens=self._compressed_summary_tokens,
            recent_messages_tokens=self._recent_messages_tokens,
            available_for_response=max(available, 0),
            iteration_count=self._iteration_count,
            tool_call_count=self._tool_call_count,
        )

        self._trigger_callbacks(level, snapshot)

        return snapshot

    def _determine_level(self, usage_ratio: float) -> BudgetLevel:
        """Determine budget alert level.

        Args:
            usage_ratio: Current usage ratio

        Returns:
            BudgetLevel
        """
        if usage_ratio >= self.policy.hard_stop_at:
            return BudgetLevel.EXCEEDED
        if usage_ratio >= self.policy.critical_threshold:
            return BudgetLevel.CRITICAL
        if usage_ratio >= self.policy.warning_threshold:
            return BudgetLevel.WARNING
        if usage_ratio >= self.policy.caution_threshold:
            return BudgetLevel.CAUTION
        return BudgetLevel.NORMAL

    def record_usage(
        self,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
    ) -> BudgetSnapshot:
        """Record token usage from an LLM call.

        Args:
            prompt_tokens: Tokens used in prompt
            completion_tokens: Tokens used in completion

        Returns:
            Updated BudgetSnapshot
        """
        self._prompt_tokens += prompt_tokens
        self._completion_tokens += completion_tokens
        self._total_used = self._prompt_tokens + self._completion_tokens

        return self.check()

    def record_iteration(self) -> BudgetSnapshot:
        """Record an agent loop iteration.

        Returns:
            Updated BudgetSnapshot
        """
        self._iteration_count += 1
        return self.check()

    def record_tool_call(self) -> BudgetSnapshot:
        """Record a tool call.

        Returns:
            Updated BudgetSnapshot
        """
        self._tool_call_count += 1
        return self.check()

    def should_compact(self) -> bool:
        """Check if memory compaction should be triggered.

        Returns:
            True if compaction should be triggered
        """
        snapshot = self.check()
        return snapshot.level in (BudgetLevel.WARNING, BudgetLevel.CRITICAL)

    def should_stop(self) -> bool:
        """Check if the agent loop should stop.

        Returns:
            True if the loop should stop
        """
        snapshot = self.check()
        if snapshot.level == BudgetLevel.EXCEEDED:
            return True
        if self._iteration_count >= self.policy.max_iterations:
            return True
        if self._tool_call_count >= self.policy.max_tool_calls_per_iteration * self._iteration_count:
            return True
        return False

    def get_compression_strategy(self) -> Dict[str, Any]:
        """Get the recommended compression strategy based on current usage.

        Three-stage density gradient:
        1. Full fidelity (recent N messages)
        2. Summarized (mid-range messages)
        3. Key facts only (old messages)

        Returns:
            Compression strategy configuration
        """
        snapshot = self.check()

        if snapshot.level == BudgetLevel.NORMAL:
            return {
                "strategy": "none",
                "full_fidelity_count": 20,
                "summarize_threshold": None,
            }

        if snapshot.level == BudgetLevel.CAUTION:
            return {
                "strategy": "mild",
                "full_fidelity_count": 10,
                "summarize_threshold": 20,
                "key_facts_threshold": 50,
            }

        if snapshot.level == BudgetLevel.WARNING:
            return {
                "strategy": "moderate",
                "full_fidelity_count": 5,
                "summarize_threshold": 10,
                "key_facts_threshold": 30,
            }

        # CRITICAL or EXCEEDED
        return {
            "strategy": "aggressive",
            "full_fidelity_count": 3,
            "summarize_threshold": 5,
            "key_facts_threshold": 15,
        }

    def register_callback(
        self,
        level: BudgetLevel,
        callback: Callable,
    ) -> None:
        """Register a callback for a budget level change.

        Args:
            level: Budget level to trigger on
            callback: Function to call
        """
        self._callbacks[level].append(callback)

    def _trigger_callbacks(
        self,
        level: BudgetLevel,
        snapshot: BudgetSnapshot,
    ) -> None:
        """Trigger registered callbacks for the given level.

        Args:
            level: Current budget level
            snapshot: Current budget snapshot
        """
        for callback in self._callbacks.get(level, []):
            try:
                callback(snapshot)
            except Exception as e:
                logger.warning(f"Budget callback error: {e}")

    def reset(self) -> None:
        """Reset the budget tracker."""
        self._total_used = 0
        self._prompt_tokens = 0
        self._completion_tokens = 0
        self._iteration_count = 0
        self._tool_call_count = 0
        self._compaction_triggered = False
