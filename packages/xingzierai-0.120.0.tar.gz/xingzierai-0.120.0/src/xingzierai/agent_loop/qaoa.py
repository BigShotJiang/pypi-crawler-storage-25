# -*- coding: utf-8 -*-
"""QAOA - Unified Evaluation Representation.

Query-Action-Observation-Answer representation inspired by UniToolCall.
Converts different evaluation benchmarks into a unified format.

This enables:
- Fine-grained evaluation at function-call, turn, and conversation levels
- Consistent metrics across different evaluation scenarios
- Better error analysis and debugging
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union


class EvaluationLevel(str, Enum):
    """Granularity levels for evaluation, inspired by UniToolCall."""

    FUNCTION = "function"
    TURN = "turn"
    CONVERSATION = "conversation"


class QAOAStatus(str, Enum):
    """Status of a QAOA instance."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Query:
    """Represents the input query/request in a QAOA instance."""

    text: str
    intent: Optional[str] = None
    required_tools: List[str] = field(default_factory=list)
    expected_outcome: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Action:
    """Represents an action (tool call or LLM response) in a QAOA instance."""

    action_type: str
    tool_name: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None
    llm_response: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)
    execution_time: Optional[float] = None
    success: bool = True
    error: Optional[str] = None


@dataclass
class Observation:
    """Represents the observation (tool result or LLM input) in a QAOA instance."""

    content: Any
    observation_type: str
    source: str
    timestamp: datetime = field(default_factory=datetime.now)
    related_action_id: Optional[str] = None


@dataclass
class Answer:
    """Represents the final answer in a QAOA instance."""

    text: Optional[str] = None
    confidence: float = 0.0
    tools_used: List[str] = field(default_factory=list)
    reasoning_chain: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class QAOAResult:
    """Result of evaluating a QAOA instance."""

    level: EvaluationLevel
    qaoa_id: str

    query: Query
    actions: List[Action] = field(default_factory=list)
    observations: List[Observation] = field(default_factory=list)
    answer: Optional[Answer] = None

    status: QAOAStatus = QAOAStatus.PENDING
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None

    metrics: Dict[str, float] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def mark_started(self) -> None:
        """Mark the QAOA as in progress."""
        self.status = QAOAStatus.IN_PROGRESS

    def mark_completed(
        self,
        answer: Optional[Answer] = None,
        metrics: Optional[Dict[str, float]] = None,
    ) -> None:
        """Mark the QAOA as completed."""
        self.status = QAOAStatus.COMPLETED
        self.end_time = datetime.now()
        if answer:
            self.answer = answer
        if metrics:
            self.metrics.update(metrics)

    def mark_failed(self, error: str) -> None:
        """Mark the QAOA as failed."""
        self.status = QAOAStatus.FAILED
        self.end_time = datetime.now()
        self.errors.append(error)

    @property
    def duration(self) -> Optional[float]:
        """Get duration in seconds."""
        if self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "qaoa_id": self.qaoa_id,
            "level": self.level.value,
            "status": self.status.value,
            "query": {
                "text": self.query.text,
                "intent": self.query.intent,
                "required_tools": self.query.required_tools,
            },
            "actions": [
                {
                    "action_type": a.action_type,
                    "tool_name": a.tool_name,
                    "parameters": a.parameters,
                    "success": a.success,
                    "execution_time": a.execution_time,
                }
                for a in self.actions
            ],
            "observations": [
                {
                    "content": str(o.content)[:200],
                    "observation_type": o.observation_type,
                    "source": o.source,
                }
                for o in self.observations
            ],
            "answer": (
                {
                    "text": self.answer.text[:500] if self.answer.text else None,
                    "confidence": self.answer.confidence,
                    "tools_used": self.answer.tools_used,
                }
                if self.answer
                else None
            ),
            "metrics": self.metrics,
            "duration": self.duration,
            "errors": self.errors,
        }


@dataclass
class FunctionLevelMetrics:
    """Metrics at the function-call level."""

    exact_match: bool = False
    parameter_match: bool = False
    tool_correct: bool = False
    parameters: Dict[str, Any] = field(default_factory=dict)
    expected_parameters: Dict[str, Any] = field(default_factory=dict)
    missing_parameters: List[str] = field(default_factory=list)
    extra_parameters: List[str] = field(default_factory=list)
    wrong_parameter_types: Dict[str, str] = field(default_factory=dict)

    @property
    def precision(self) -> float:
        """Calculate parameter precision."""
        total = len(self.parameters) + len(self.expected_parameters)
        if total == 0:
            return 1.0
        correct = len(self.parameters) - len(self.extra_parameters)
        return max(0.0, correct / len(self.expected_parameters)) if self.expected_parameters else 1.0

    @property
    def recall(self) -> float:
        """Calculate parameter recall."""
        if not self.expected_parameters:
            return 1.0
        correct = len(self.parameters) - len(self.missing_parameters)
        return max(0.0, correct / len(self.expected_parameters))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exact_match": self.exact_match,
            "parameter_match": self.parameter_match,
            "tool_correct": self.tool_correct,
            "precision": self.precision,
            "recall": self.recall,
            "missing_parameters": self.missing_parameters,
            "extra_parameters": self.extra_parameters,
            "wrong_parameter_types": self.wrong_parameter_types,
        }


@dataclass
class TurnLevelMetrics:
    """Metrics at the turn level."""

    actions_in_turn: int = 0
    successful_actions: int = 0
    failed_actions: int = 0
    observation_gaps: int = 0
    context_preservation: float = 0.0
    coherence_score: float = 0.0

    @property
    def action_success_rate(self) -> float:
        """Calculate action success rate."""
        if self.actions_in_turn == 0:
            return 0.0
        return self.successful_actions / self.actions_in_turn

    @property
    def completion_rate(self) -> float:
        """Calculate turn completion rate."""
        if self.actions_in_turn == 0:
            return 0.0
        return (self.actions_in_turn - self.observation_gaps) / self.actions_in_turn

    def to_dict(self) -> Dict[str, Any]:
        return {
            "actions_in_turn": self.actions_in_turn,
            "successful_actions": self.successful_actions,
            "failed_actions": self.failed_actions,
            "action_success_rate": self.action_success_rate,
            "context_preservation": self.context_preservation,
            "coherence_score": self.coherence_score,
            "completion_rate": self.completion_rate,
        }


@dataclass
class ConversationLevelMetrics:
    """Metrics at the conversation level."""

    total_turns: int = 0
    completed_turns: int = 0
    failed_turns: int = 0
    total_tool_calls: int = 0
    successful_tool_calls: int = 0
    average_turn_length: float = 0.0
    goal_achievement: float = 0.0
    coherence_across_turns: float = 0.0

    @property
    def turn_completion_rate(self) -> float:
        """Calculate turn completion rate."""
        if self.total_turns == 0:
            return 0.0
        return self.completed_turns / self.total_turns

    @property
    def tool_call_success_rate(self) -> float:
        """Calculate tool call success rate."""
        if self.total_tool_calls == 0:
            return 0.0
        return self.successful_tool_calls / self.total_tool_calls

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_turns": self.total_turns,
            "completed_turns": self.completed_turns,
            "failed_turns": self.failed_turns,
            "turn_completion_rate": self.turn_completion_rate,
            "total_tool_calls": self.total_tool_calls,
            "successful_tool_calls": self.successful_tool_calls,
            "tool_call_success_rate": self.tool_call_success_rate,
            "goal_achievement": self.goal_achievement,
            "coherence_across_turns": self.coherence_across_turns,
        }


class QAOEvaluator:
    """Evaluator that uses QAOA representation for fine-grained evaluation.

    Inspired by UniToolCall's evaluation approach, this evaluator
    provides metrics at three levels: function, turn, and conversation.
    """

    def __init__(
        self,
        strict_mode: bool = True,
        coherence_threshold: float = 0.7,
    ):
        """Initialize QAOEvaluator.

        Args:
            strict_mode: If True, require exact matches
            coherence_threshold: Minimum coherence score to pass
        """
        self.strict_mode = strict_mode
        self.coherence_threshold = coherence_threshold
        self._history: List[QAOAResult] = []

    def evaluate_function(
        self,
        action: Action,
        expected_tool: str,
        expected_params: Dict[str, Any],
    ) -> FunctionLevelMetrics:
        """Evaluate a single function call.

        Args:
            action: The action to evaluate
            expected_tool: Expected tool name
            expected_params: Expected parameters

        Returns:
            FunctionLevelMetrics with evaluation results
        """
        metrics = FunctionLevelMetrics(
            expected_parameters=expected_params,
            parameters=action.parameters or {},
        )

        metrics.tool_correct = action.tool_name == expected_tool

        if metrics.tool_correct:
            metrics.parameter_match = self._check_params_match(
                action.parameters or {},
                expected_params,
            )
            metrics.exact_match = metrics.parameter_match

            if not metrics.parameter_match:
                actual_params = action.parameters or {}
                metrics.missing_parameters = [
                    k for k in expected_params if k not in actual_params
                ]
                metrics.extra_parameters = [
                    k for k in actual_params if k not in expected_params
                ]

        return metrics

    def evaluate_turn(
        self,
        actions: List[Action],
        observations: List[Observation],
        expected_outcome: Optional[str] = None,
    ) -> TurnLevelMetrics:
        """Evaluate a single turn.

        Args:
            actions: Actions in the turn
            observations: Observations in the turn
            expected_outcome: Optional expected outcome

        Returns:
            TurnLevelMetrics with evaluation results
        """
        metrics = TurnLevelMetrics(
            actions_in_turn=len(actions),
            successful_actions=sum(1 for a in actions if a.success),
            failed_actions=sum(1 for a in actions if not a.success),
            observation_gaps=max(0, len(actions) - len(observations)),
        )

        if observations and actions:
            metrics.context_preservation = self._calculate_context_preservation(
                actions, observations
            )

        metrics.coherence_score = min(
            metrics.action_success_rate,
            metrics.completion_rate,
            metrics.context_preservation,
        )

        return metrics

    def evaluate_conversation(
        self,
        qaoa_results: List[QAOAResult],
        goal: Optional[str] = None,
    ) -> ConversationLevelMetrics:
        """Evaluate entire conversation.

        Args:
            qaoa_results: List of QAOA results for each turn
            goal: Optional goal description

        Returns:
            ConversationLevelMetrics with evaluation results
        """
        total_actions = sum(len(r.actions) for r in qaoa_results)
        total_successful = sum(
            sum(1 for a in r.actions if a.success) for r in qaoa_results
        )

        metrics = ConversationLevelMetrics(
            total_turns=len(qaoa_results),
            completed_turns=sum(1 for r in qaoa_results if r.status == QAOAStatus.COMPLETED),
            failed_turns=sum(1 for r in qaoa_results if r.status == QAOAStatus.FAILED),
            total_tool_calls=total_actions,
            successful_tool_calls=total_successful,
        )

        if qaoa_results:
            metrics.average_turn_length = total_actions / len(qaoa_results)

        if goal:
            metrics.goal_achievement = self._calculate_goal_achievement(qaoa_results, goal)

        metrics.coherence_across_turns = self._calculate_coherence(qaoa_results)

        return metrics

    def evaluate_qaoa(
        self,
        qaoa: QAOAResult,
        expected_tool: Optional[str] = None,
        expected_params: Optional[Dict[str, Any]] = None,
    ) -> QAOAResult:
        """Perform full evaluation on a QAOA instance.

        Args:
            qaoa: The QAOA to evaluate
            expected_tool: Expected tool name (for function level)
            expected_params: Expected parameters (for function level)

        Returns:
            The same QAOA with updated metrics
        """
        qaoa.mark_started()
        self._history.append(qaoa)

        try:
            if qaoa.level == EvaluationLevel.FUNCTION:
                if expected_tool and qaoa.actions:
                    func_metrics = self.evaluate_function(
                        qaoa.actions[0],
                        expected_tool,
                        expected_params or {},
                    )
                    qaoa.metrics.update(func_metrics.to_dict())

            elif qaoa.level == EvaluationLevel.TURN:
                turn_metrics = self.evaluate_turn(
                    qaoa.actions,
                    qaoa.observations,
                    qaoa.query.expected_outcome,
                )
                qaoa.metrics.update(turn_metrics.to_dict())

            elif qaoa.level == EvaluationLevel.CONVERSATION:
                conv_metrics = self.evaluate_conversation([qaoa])
                qaoa.metrics.update(conv_metrics.to_dict())

            qoa_answer = Answer(
                text="Evaluation completed",
                confidence=qaoa.metrics.get("coherence_score", 0.5),
                tools_used=[a.tool_name for a in qaoa.actions if a.tool_name],
            )
            qaoa.mark_completed(answer=qoa_answer)

        except Exception as e:
            qaoa.mark_failed(str(e))

        return qaoa

    def _check_params_match(
        self,
        actual: Dict[str, Any],
        expected: Dict[str, Any],
    ) -> bool:
        """Check if parameters match."""
        if self.strict_mode:
            return actual == expected
        return all(actual.get(k) == v for k, v in expected.items())

    def _calculate_context_preservation(
        self,
        actions: List[Action],
        observations: List[Observation],
    ) -> float:
        """Calculate how well context is preserved between actions and observations."""
        if not observations:
            return 0.0

        action_obs_pairs = min(len(actions), len(observations))
        if action_obs_pairs == 0:
            return 0.0

        preserved = sum(
            1
            for i, obs in enumerate(observations[:action_obs_pairs])
            if obs.related_action_id or obs.source == "tool"
        )

        return preserved / action_obs_pairs

    def _calculate_goal_achievement(
        self,
        qaoa_results: List[QAOAResult],
        goal: str,
    ) -> float:
        """Calculate goal achievement score."""
        if not qaoa_results:
            return 0.0

        completed = sum(
            1 for r in qaoa_results if r.status == QAOAStatus.COMPLETED
        )
        return completed / len(qaoa_results)

    def _calculate_coherence(self, qaoa_results: List[QAOAResult]) -> float:
        """Calculate coherence score across turns."""
        if len(qaoa_results) <= 1:
            return 1.0

        coherence_scores = []
        for r in qaoa_results:
            if r.metrics:
                coherence_scores.append(r.metrics.get("coherence_score", 0.0))

        return sum(coherence_scores) / len(coherence_scores) if coherence_scores else 0.0

    def get_history(self) -> List[QAOAResult]:
        """Get evaluation history."""
        return self._history.copy()

    def clear_history(self) -> None:
        """Clear evaluation history."""
        self._history.clear()

    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        if not self._history:
            return {"total_evaluated": 0}

        return {
            "total_evaluated": len(self._history),
            "by_level": {
                level.value: sum(
                    1 for r in self._history if r.level == level
                )
                for level in EvaluationLevel
            },
            "by_status": {
                status.value: sum(
                    1 for r in self._history if r.status == status
                )
                for status in QAOAStatus
            },
            "average_coherence": sum(
                r.metrics.get("coherence_score", 0.0) for r in self._history
            ) / len(self._history),
        }