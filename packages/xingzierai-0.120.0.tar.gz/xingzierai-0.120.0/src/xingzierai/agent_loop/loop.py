# -*- coding: utf-8 -*-
"""AgentLoop - Dual-Layer Decoupled Architecture.

Core innovation from Claude Code:
1. Session Layer (Generator): LLM Prompt interaction
2. Execution Layer (State Machine): Tool execution flow
3. AsyncGenerator streaming: 200ms first-byte response
4. Yield-based state slicing: UI stays 100% non-blocking

Architecture:
    ┌─────────────────────────────────────┐
    │           Session Layer             │
    │  (Generator - LLM Interaction)      │
    │  ┌─────────────────────────────┐    │
    │  │  System Prompt Management   │    │
    │  │  Context Assembly           │    │
    │  │  LLM API Call              │    │
    │  │  Response Parsing           │    │
    │  └─────────────────────────────┘    │
    └──────────────┬──────────────────────┘
                   │ AsyncGenerator Yield
    ┌──────────────▼──────────────────────┐
    │         Evaluator Layer             │
    │  (SkepticEvaluator)                 │
    │  ┌─────────────────────────────┐    │
    │  │  Output Validation          │    │
    │  │  Context Anxiety Detection  │    │
    │  │  Quality Assessment         │    │
    │  └─────────────────────────────┘    │
    └──────────────┬──────────────────────┘
                   │
    ┌──────────────▼──────────────────────┐
    │        Execution Layer              │
    │  (State Machine)                    │
    │  ┌─────────────────────────────┐    │
    │  │  Tool Dispatch              │    │
    │  │  Result Collection          │    │
    │  │  State Transition           │    │
    │  │  Error Recovery             │    │
    │  └─────────────────────────────┘    │
    └──────────────┬──────────────────────┘
                   │
    ┌──────────────▼──────────────────────┐
    │        Safety Layer                 │
    │  ┌─────────────────────────────┐    │
    │  │  TokenBudget Monitor        │    │
    │  │  CircuitBreaker             │    │
    │  │  Permission Matrix          │    │
    │  └─────────────────────────────┘    │
    └─────────────────────────────────────┘
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional

from .evaluator import EvaluationVerdict, EvaluationResult, SkepticEvaluator
from .token_budget import BudgetLevel, BudgetPolicy, BudgetSnapshot, TokenBudget
from .circuit_breaker import BreakerConfig, BreakerState, CircuitBreaker
from ..tools.executor import StreamingToolExecutor, ToolCallRequest, ExecutionStrategy

logger = logging.getLogger(__name__)


class LoopState(str, Enum):
    """Agent loop states."""
    IDLE = "idle"
    THINKING = "thinking"
    EVALUATING = "evaluating"
    EXECUTING = "executing"
    COMPACTING = "compacting"
    WAITING_INPUT = "waiting_input"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    CIRCUIT_OPEN = "circuit_open"


class LoopEvent(str, Enum):
    """Events emitted by the agent loop."""
    STATE_CHANGE = "state_change"
    LLM_CALL_START = "llm_call_start"
    LLM_CALL_END = "llm_call_end"
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_END = "tool_call_end"
    EVALUATION_RESULT = "evaluation_result"
    BUDGET_WARNING = "budget_warning"
    CIRCUIT_BREAK = "circuit_break"
    COMPACTION = "compaction"
    YIELD = "yield"
    ERROR = "error"
    COMPLETE = "complete"


@dataclass
class LoopStep:
    """A single step in the agent loop."""
    id: str = field(default_factory=lambda: f"step_{uuid.uuid4().hex[:8]}")
    state: LoopState = LoopState.IDLE
    input: Any = None
    output: Any = None
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    evaluation: Optional[EvaluationResult] = None
    budget_snapshot: Optional[BudgetSnapshot] = None
    timestamp: float = field(default_factory=time.time)
    duration: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "state": self.state.value,
            "tool_calls": self.tool_calls,
            "evaluation": self.evaluation.to_dict() if self.evaluation else None,
            "budget": self.budget_snapshot.to_dict() if self.budget_snapshot else None,
            "duration": self.duration,
        }


@dataclass
class LoopResult:
    """Final result of the agent loop."""
    output: Any = None
    steps: List[LoopStep] = field(default_factory=list)
    total_duration: float = 0.0
    total_llm_calls: int = 0
    total_tool_calls: int = 0
    total_tokens: int = 0
    final_state: LoopState = LoopState.COMPLETED
    evaluation: Optional[EvaluationResult] = None
    budget_snapshot: Optional[BudgetSnapshot] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "output": self.output,
            "steps": [s.to_dict() for s in self.steps],
            "total_duration": self.total_duration,
            "total_llm_calls": self.total_llm_calls,
            "total_tool_calls": self.total_tool_calls,
            "total_tokens": self.total_tokens,
            "final_state": self.final_state.value,
            "evaluation": self.evaluation.to_dict() if self.evaluation else None,
            "budget": self.budget_snapshot.to_dict() if self.budget_snapshot else None,
        }


class AgentLoop:
    """Dual-layer decoupled agent loop.

    Architecture based on Claude Code's design:
    - Session Layer: LLM interaction
    - Execution Layer: State machine
    - AsyncGenerator streaming for real-time output
    - TokenBudget + CircuitBreaker for safety

    Usage:
        loop = AgentLoop(
            llm_fn=my_llm_function,
            tool_executor=my_tool_executor,
        )

        # Streaming execution
        async for event in loop.run("Write a hello world program"):
            print(event["type"], event.get("data"))

        # Or collect all results
        result = await loop.run_sync("Write a hello world program")
    """

    def __init__(
        self,
        llm_fn: Callable,
        tool_executor: Optional[Callable] = None,
        evaluator: Optional[SkepticEvaluator] = None,
        budget_policy: Optional[BudgetPolicy] = None,
        breaker_config: Optional[BreakerConfig] = None,
        max_iterations: int = 50,
        enable_evaluation: bool = True,
        enable_streaming: bool = True,
        parallel_executor: Optional[StreamingToolExecutor] = None,
        parallel_strategy: ExecutionStrategy = ExecutionStrategy.PARALLEL_SAFE,
    ):
        """Initialize agent loop.

        Args:
            llm_fn: Async function for LLM calls
            tool_executor: Async function for tool execution (single tool)
            evaluator: Skeptic evaluator instance
            budget_policy: Token budget policy
            breaker_config: Circuit breaker config
            max_iterations: Maximum loop iterations
            enable_evaluation: Enable evaluator layer
            enable_streaming: Enable AsyncGenerator streaming
            parallel_executor: StreamingToolExecutor for parallel tool execution
            parallel_strategy: Execution strategy for parallel tools
        """
        self.llm_fn = llm_fn
        self.tool_executor = tool_executor
        self.parallel_executor = parallel_executor
        self.parallel_strategy = parallel_strategy
        self.evaluator = evaluator or SkepticEvaluator()
        self.budget = TokenBudget(budget_policy)
        self.breaker = CircuitBreaker(breaker_config)
        self.max_iterations = max_iterations
        self.enable_evaluation = enable_evaluation
        self.enable_streaming = enable_streaming

        self._state = LoopState.IDLE
        self._steps: List[LoopStep] = []
        self._event_handlers: Dict[LoopEvent, List[Callable]] = {
            event: [] for event in LoopEvent
        }
        self._context: List[Dict[str, Any]] = []
        self._cancelled = False
        self._consecutive_llm_failures = 0

    @property
    def state(self) -> LoopState:
        """Get current loop state."""
        return self._state

    async def run(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        context: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Run the agent loop with AsyncGenerator streaming.

        This implements Claude Code's yield-based state slicing:
        - Each state transition yields an event
        - UI stays 100% non-blocking
        - Natural cancellation semantics

        Args:
            prompt: User prompt
            system_prompt: System prompt
            context: Initial conversation context

        Yields:
            Event dictionaries with type and data
        """
        start_time = time.time()
        self._cancelled = False
        self._steps.clear()
        self._context = context or []

        yield await self._emit(LoopEvent.STATE_CHANGE, {
            "from": LoopState.IDLE.value,
            "to": LoopState.THINKING.value,
        })

        self._set_state(LoopState.THINKING)

        self._context.append({"role": "user", "content": prompt})

        iteration = 0
        while iteration < self.max_iterations and not self._cancelled:
            iteration += 1

            # Safety checks
            if self.breaker.should_break():
                yield await self._emit(LoopEvent.CIRCUIT_BREAK, {
                    "state": self.breaker.state.value,
                    "snapshot": self.breaker.get_snapshot().to_dict(),
                })
                self._set_state(LoopState.CIRCUIT_OPEN)
                break

            if self.budget.should_stop():
                yield await self._emit(LoopEvent.BUDGET_WARNING, {
                    "level": BudgetLevel.EXCEEDED.value,
                    "snapshot": self.budget.check().to_dict(),
                })
                break

            step = LoopStep(state=LoopState.THINKING)
            step_start = time.time()

            # === Session Layer: LLM Call ===
            yield await self._emit(LoopEvent.LLM_CALL_START, {
                "iteration": iteration,
            })

            self.breaker.record_llm_call()
            budget_before = self.budget.check()

            try:
                llm_result = await self.llm_fn(
                    messages=self._context,
                    system_prompt=system_prompt,
                )
            except Exception as e:
                self._consecutive_llm_failures += 1
                self.breaker.record_failure(error=str(e))
                yield await self._emit(LoopEvent.ERROR, {"error": str(e)})
                step.state = LoopState.FAILED
                step.duration = time.time() - step_start
                self._steps.append(step)
                if self._consecutive_llm_failures >= 3:
                    logger.error("AgentLoop: %d consecutive LLM failures, breaking loop", self._consecutive_llm_failures)
                    break
                continue

            # Record token usage
            self._consecutive_llm_failures = 0
            if hasattr(llm_result, 'usage') and llm_result.usage:
                self.budget.record_usage(
                    prompt_tokens=getattr(llm_result.usage, 'prompt_tokens', 0),
                    completion_tokens=getattr(llm_result.usage, 'completion_tokens', 0),
                )

            self.budget.record_iteration()
            budget_after = self.budget.check()
            step.budget_snapshot = budget_after

            yield await self._emit(LoopEvent.LLM_CALL_END, {
                "iteration": iteration,
                "budget": budget_after.to_dict(),
            })

            # Parse LLM response
            response_content = self._extract_content(llm_result)
            tool_calls = self._extract_tool_calls(llm_result)

            step.output = response_content
            step.tool_calls = tool_calls

            # Add assistant response to context
            self._context.append({"role": "assistant", "content": response_content})

            # === Evaluator Layer ===
            if self.enable_evaluation and response_content and not tool_calls:
                yield await self._emit(LoopEvent.STATE_CHANGE, {
                    "from": LoopState.THINKING.value,
                    "to": LoopState.EVALUATING.value,
                })
                self._set_state(LoopState.EVALUATING)

                eval_result = await self.evaluator.evaluate(
                    task=prompt,
                    output=response_content,
                    context={
                        "token_usage_ratio": budget_after.usage_ratio,
                        "iteration_ratio": iteration / self.max_iterations,
                    },
                )
                step.evaluation = eval_result

                yield await self._emit(LoopEvent.EVALUATION_RESULT, {
                    "verdict": eval_result.verdict.value,
                    "score": eval_result.score,
                    "issues": eval_result.issues,
                })

                if eval_result.verdict == EvaluationVerdict.APPROVE:
                    # Output accepted
                    yield await self._emit(LoopEvent.YIELD, {
                        "type": "final_output",
                        "content": response_content,
                    })
                    step.state = LoopState.COMPLETED
                    step.duration = time.time() - step_start
                    self._steps.append(step)
                    break

                elif eval_result.verdict == EvaluationVerdict.REJECT:
                    # Force revision
                    self._context.append({
                        "role": "user",
                        "content": f"Your previous response was rejected. Issues: {'; '.join(eval_result.issues)}. Please revise.",
                    })

                # NEEDS_REVISION - continue loop

            elif not tool_calls and response_content:
                # No evaluation, accept output directly
                yield await self._emit(LoopEvent.YIELD, {
                    "type": "output",
                    "content": response_content,
                })
                step.state = LoopState.COMPLETED
                step.duration = time.time() - step_start
                self._steps.append(step)
                break

            # === Execution Layer: Tool Calls ===
            if tool_calls and (self.tool_executor or self.parallel_executor):
                yield await self._emit(LoopEvent.STATE_CHANGE, {
                    "from": LoopState.THINKING.value,
                    "to": LoopState.EXECUTING.value,
                })
                self._set_state(LoopState.EXECUTING)

                # Use parallel execution if available and multiple tools
                if self.parallel_executor and len(tool_calls) > 1:
                    async for event_data in self._execute_tools_parallel(tool_calls, iteration):
                        yield event_data
                else:
                    # Fall back to serial execution
                    for tc in tool_calls:
                        tool_name = tc.get("name", tc.get("function", {}).get("name", "unknown"))

                        yield await self._emit(LoopEvent.TOOL_CALL_START, {
                            "tool": tool_name,
                            "iteration": iteration,
                        })

                        try:
                            tool_result = await self.tool_executor(tc)
                            self.breaker.record_success(tool_name)

                            yield await self._emit(LoopEvent.TOOL_CALL_END, {
                                "tool": tool_name,
                                "status": "success",
                            })

                            self._context.append({
                                "role": "tool",
                                "name": tool_name,
                                "content": str(tool_result),
                            })

                        except Exception as e:
                            self.breaker.record_failure(tool_name, str(e))

                            yield await self._emit(LoopEvent.TOOL_CALL_END, {
                                "tool": tool_name,
                                "status": "error",
                                "error": str(e),
                            })

                            self._context.append({
                                "role": "tool",
                                "name": tool_name,
                                "content": f"Error: {e}",
                            })

                        self.budget.record_tool_call()

            # === Memory Compaction ===
            if self.budget.should_compact():
                yield await self._emit(LoopEvent.COMPACTION, {
                    "strategy": self.budget.get_compression_strategy(),
                })
                self._set_state(LoopState.COMPACTING)

            step.duration = time.time() - step_start
            self._steps.append(step)

            # Yield intermediate state
            yield await self._emit(LoopEvent.YIELD, {
                "type": "step_complete",
                "step": step.to_dict(),
                "iteration": iteration,
            })

        # Final state
        total_duration = time.time() - start_time
        final_state = self._state

        if not self._cancelled and final_state not in (
            LoopState.CIRCUIT_OPEN,
            LoopState.FAILED,
        ):
            self._set_state(LoopState.COMPLETED)

        yield await self._emit(LoopEvent.COMPLETE, {
            "final_state": self._state.value,
            "total_duration": total_duration,
            "total_steps": len(self._steps),
            "total_llm_calls": self.breaker.get_snapshot().total_llm_calls,
            "total_tool_calls": self.breaker.get_snapshot().total_tool_calls,
        })

    async def run_sync(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        context: Optional[List[Dict[str, Any]]] = None,
    ) -> LoopResult:
        """Run the agent loop and collect all results.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            context: Initial context

        Returns:
            LoopResult with complete execution details
        """
        start_time = time.time()
        final_output = None
        final_evaluation = None

        async for event in self.run(prompt, system_prompt, context):
            if event.get("type") == LoopEvent.YIELD.value:
                data = event.get("data", {})
                if data.get("type") == "final_output":
                    final_output = data.get("content")
                elif data.get("type") == "output":
                    final_output = data.get("content")

            elif event.get("type") == LoopEvent.EVALUATION_RESULT.value:
                data = event.get("data", {})
                final_evaluation = EvaluationResult(
                    verdict=EvaluationVerdict(data["verdict"]),
                    score=data.get("score", 0),
                    issues=data.get("issues", []),
                )

        breaker_snapshot = self.breaker.get_snapshot()

        return LoopResult(
            output=final_output,
            steps=self._steps,
            total_duration=time.time() - start_time,
            total_llm_calls=breaker_snapshot.total_llm_calls,
            total_tool_calls=breaker_snapshot.total_tool_calls,
            final_state=self._state,
            evaluation=final_evaluation,
            budget_snapshot=self.budget.check(),
        )

    def cancel(self) -> None:
        """Cancel the running loop."""
        self._cancelled = True
        self._set_state(LoopState.CANCELLED)

    def on(self, event: LoopEvent, handler: Callable) -> "AgentLoop":
        """Register an event handler.

        Args:
            event: Event type
            handler: Async function to handle the event

        Returns:
            Self for chaining
        """
        self._event_handlers[event].append(handler)
        return self

    def _set_state(self, new_state: LoopState) -> None:
        """Set loop state."""
        self._state = new_state

    async def _execute_tools_parallel(
        self,
        tool_calls: List[Dict[str, Any]],
        iteration: int,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Execute multiple tools in parallel using StreamingToolExecutor.

        This method converts LLM tool calls to ToolCallRequest format,
        executes them in parallel, and yields events for each result.

        Args:
            tool_calls: List of tool calls from LLM
            iteration: Current iteration number

        Yields:
            Event dictionaries for tool execution progress
        """
        requests = []
        call_id_to_tool_name = {}

        for tc in tool_calls:
            tool_name = tc.get("name", tc.get("function", {}).get("name", "unknown"))
            input_data = tc.get("arguments", tc.get("input", {}))
            call_id = tc.get("id", f"call_{uuid.uuid4().hex[:8]}")

            requests.append(ToolCallRequest(
                tool_name=tool_name,
                input_data=input_data,
                call_id=call_id,
            ))
            call_id_to_tool_name[call_id] = tool_name

            yield await self._emit(LoopEvent.TOOL_CALL_START, {
                "tool": tool_name,
                "call_id": call_id,
                "iteration": iteration,
                "parallel": True,
            })

        yield await self._emit(LoopEvent.TOOL_CALL_START, {
            "execution_mode": "parallel",
            "total_tools": len(requests),
            "strategy": self.parallel_strategy.value,
        })

        tool_results = {}
        async for event in self.parallel_executor.execute_streaming(
            requests,
            strategy=self.parallel_strategy,
        ):
            event_type = event.event_type

            if event_type == "tool_result":
                result = event.data
                tool_name = call_id_to_tool_name.get(result.call_id, "unknown")

                if result.success:
                    self.breaker.record_success(tool_name)
                    tool_results[result.call_id] = str(result.result)

                    yield await self._emit(LoopEvent.TOOL_CALL_END, {
                        "tool": tool_name,
                        "call_id": result.call_id,
                        "status": "success",
                        "execution_time": result.execution_time,
                        "parallel": True,
                    })

                    self._context.append({
                        "role": "tool",
                        "name": tool_name,
                        "content": str(result.result),
                    })
                else:
                    self.breaker.record_failure(tool_name, str(result.error))
                    tool_results[result.call_id] = f"Error: {result.error}"

                    yield await self._emit(LoopEvent.TOOL_CALL_END, {
                        "tool": tool_name,
                        "call_id": result.call_id,
                        "status": "error",
                        "error": str(result.error),
                        "parallel": True,
                    })

                    self._context.append({
                        "role": "tool",
                        "name": tool_name,
                        "content": f"Error: {result.error}",
                    })

                self.budget.record_tool_call()

            elif event_type == "phase_start":
                logger.info(f"Parallel execution phase: {event.data}")

            elif event_type == "execution_error":
                logger.error(f"Parallel execution error: {event.data}")

        yield await self._emit(LoopEvent.TOOL_CALL_END, {
            "execution_mode": "parallel",
            "total_tools": len(requests),
            "completed": len(tool_results),
        })

    async def _emit(
        self,
        event_type: LoopEvent,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Emit an event.

        Args:
            event_type: Type of event
            data: Event data

        Returns:
            Event dictionary
        """
        event = {
            "type": event_type.value,
            "data": data,
            "timestamp": time.time(),
            "state": self._state.value,
        }

        for handler in self._event_handlers.get(event_type, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
            except Exception as e:
                logger.warning(f"Event handler error: {e}")

        return event

    def _extract_content(self, llm_result: Any) -> str:
        """Extract text content from LLM result."""
        if isinstance(llm_result, str):
            return llm_result
        if hasattr(llm_result, 'content'):
            content = llm_result.content
            if isinstance(content, list):
                return " ".join(
                    block.text if hasattr(block, 'text') else str(block)
                    for block in content
                )
            return str(content)
        return str(llm_result)

    def _extract_tool_calls(self, llm_result: Any) -> List[Dict[str, Any]]:
        """Extract tool calls from LLM result."""
        if hasattr(llm_result, 'tool_calls'):
            return [
                {
                    "name": tc.function.name if hasattr(tc, 'function') else tc.get("name"),
                    "arguments": tc.function.arguments if hasattr(tc, 'function') else tc.get("arguments"),
                }
                for tc in llm_result.tool_calls
            ]
        if isinstance(llm_result, dict):
            return llm_result.get("tool_calls", [])
        return []
