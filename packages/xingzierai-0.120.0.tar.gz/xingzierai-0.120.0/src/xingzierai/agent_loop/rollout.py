# -*- coding: utf-8 -*-
"""Rollout - Tree-structured reasoning path tracking with backtracking.

From OpenAI Codex architecture:
- Rollout tree records complete reasoning path
- Each node stores action + observation + state snapshot
- Supports branching (exploring alternatives) and backtracking
- Enables "try, fail, revert, try again" workflow

Core innovation:
- Traditional agent loops are LINEAR: one path, no backtracking
- Rollout enables TREE exploration: try multiple paths, revert failed ones
- State snapshots enable complete state restoration

Architecture:
    Root (Initial Request)
        │
        ├── Node A (Action: read_file)
        │       └── Node A1 (Observation: file content)
        │               └── Node A1a (Action: write_file) → Success
        │
        └── Node B (Alternative: use different approach)
                └── Node B1 (Observation: ...)
                        └── ...

When Node A1a fails validation:
    1. backtrack(Node A1)
    2. Try alternative: branch(Node A, "different write approach")
    3. Rollback to Node A state
    4. Continue from Node A with new child
"""

import copy
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class NodeStatus(str, Enum):
    """Status of a rollout node."""
    PENDING = "pending"       # Node created, not yet executed
    RUNNING = "running"       # Currently executing
    COMPLETED = "completed"   # Successfully completed
    FAILED = "failed"         # Execution failed
    ABANDONED = "abandoned"   # Abandoned due to backtracking


@dataclass
class Action:
    """Represents an action taken by the agent."""
    action_type: str                          # e.g., "llm_call", "tool_call", "compaction"
    content: Any = None                       # Action details (LLM prompt, tool call, etc.)
    tool_name: Optional[str] = None          # For tool calls
    tool_arguments: Optional[Dict] = None   # For tool calls
    reasoning: Optional[str] = None          # Agent's reasoning for this action

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_type": self.action_type,
            "content": self.content,
            "tool_name": self.tool_name,
            "tool_arguments": self.tool_arguments,
            "reasoning": self.reasoning,
        }


@dataclass
class Observation:
    """Represents an observation result from an action."""
    observation_type: str                    # e.g., "llm_response", "tool_result", "error"
    content: Any = None                      # Observation content
    success: bool = True                     # Whether the action succeeded
    error_message: Optional[str] = None     # Error details if failed
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "observation_type": self.observation_type,
            "content": self.content,
            "success": self.success,
            "error_message": self.error_message,
            "metadata": self.metadata,
        }


@dataclass
class StateSnapshot:
    """Complete state snapshot for rollback.

    Captures everything needed to restore agent state at a specific point:
    - Conversation context
    - Token budget state
    - Circuit breaker state
    - Tool execution history
    - Memory contents (if applicable)
    """
    context: List[Dict[str, Any]]            # Conversation messages
    budget_used: int = 0                    # Tokens used
    budget_iterations: int = 0              # Iteration count
    budget_tool_calls: int = 0              # Tool call count
    breaker_failures: int = 0               # Circuit breaker failures
    breaker_successes: int = 0             # Circuit breaker successes
    breaker_state: str = "closed"           # Circuit breaker state
    total_llm_calls: int = 0              # Total LLM calls
    total_tool_calls: int = 0             # Total tool calls
    execution_time: float = 0.0           # Elapsed time
    timestamp: float = field(default_factory=time.time)

    @classmethod
    def capture(
        cls,
        context: List[Dict[str, Any]],
        budget: Any = None,
        breaker: Any = None,
        start_time: float = 0.0,
    ) -> "StateSnapshot":
        """Capture current state snapshot.

        Args:
            context: Current conversation context
            budget: TokenBudget instance (optional)
            breaker: CircuitBreaker instance (optional)
            start_time: Loop start time for execution tracking

        Returns:
            StateSnapshot with current state
        """
        snapshot = cls(context=copy.deepcopy(context))

        if budget:
            snapshot.budget_used = budget._total_used
            snapshot.budget_iterations = budget._iteration_count
            snapshot.budget_tool_calls = budget._tool_call_count

        if breaker:
            snapshot.breaker_failures = breaker._failure_count
            snapshot.breaker_successes = breaker._success_count
            snapshot.breaker_state = breaker._state.value
            snapshot.total_llm_calls = breaker._total_llm_calls
            snapshot.total_tool_calls = breaker._total_tool_calls

        snapshot.execution_time = time.time() - start_time

        return snapshot

    def restore(
        self,
        context: List[Dict[str, Any]],
        budget: Any = None,
        breaker: Any = None,
    ) -> None:
        """Restore state from this snapshot.

        Args:
            context: Conversation context to restore into (will be cleared and refilled)
            budget: TokenBudget instance to restore (optional)
            breaker: CircuitBreaker instance to restore (optional)
        """
        context.clear()
        context.extend(copy.deepcopy(self.context))

        if budget:
            budget._total_used = self.budget_used
            budget._iteration_count = self.budget_iterations
            budget._tool_call_count = self.budget_tool_calls

        if breaker:
            breaker._failure_count = self.breaker_failures
            breaker._success_count = self.breaker_successes
            breaker._total_llm_calls = self.total_llm_calls
            breaker._total_tool_calls = self.total_tool_calls

    def to_dict(self) -> Dict[str, Any]:
        return {
            "context_length": len(self.context),
            "budget_used": self.budget_used,
            "budget_iterations": self.budget_iterations,
            "budget_tool_calls": self.budget_tool_calls,
            "breaker_failures": self.breaker_failures,
            "breaker_state": self.breaker_state,
            "total_llm_calls": self.total_llm_calls,
            "total_tool_calls": self.total_tool_calls,
            "execution_time": self.execution_time,
            "timestamp": self.timestamp,
        }


@dataclass
class RolloutNode:
    """A single node in the reasoning rollout tree.

    Each node represents one step in the agent's reasoning:
    - The action taken (LLM call, tool execution, etc.)
    - The observation received (response, result, error)
    - A snapshot of state BEFORE the action was taken

    The tree structure allows:
    - Branching: exploring alternative actions from the same parent
    - Backtracking: reverting to a previous state and trying differently
    """
    id: str = field(default_factory=lambda: f"node_{uuid.uuid4().hex[:8]}")
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)

    action: Optional[Action] = None
    observation: Optional[Observation] = None
    status: NodeStatus = NodeStatus.PENDING

    state_snapshot: Optional[StateSnapshot] = None

    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    duration: float = 0.0

    depth: int = 0
    branch_name: Optional[str] = None          # Human-readable branch identifier
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "action": self.action.to_dict() if self.action else None,
            "observation": self.observation.to_dict() if self.observation else None,
            "status": self.status.value,
            "state_snapshot": self.state_snapshot.to_dict() if self.state_snapshot else None,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "duration": self.duration,
            "depth": self.depth,
            "branch_name": self.branch_name,
            "metadata": self.metadata,
        }

    def is_leaf(self) -> bool:
        """Check if this node is a leaf (no children)."""
        return len(self.children_ids) == 0

    def is_root(self) -> bool:
        """Check if this is the root node."""
        return self.parent_id is None


@dataclass
class BacktrackResult:
    """Result of a backtrack operation."""
    target_node_id: str
    restored_state: StateSnapshot
    abandoned_branch_size: int       # Number of nodes abandoned
    new_branch_name: str


class RolloutTree:
    """Tree-structured reasoning path tracker with backtracking support.

    Key features:
    1. Tree structure: supports branching (multiple alternatives)
    2. State snapshots: each node captures state before action
    3. Backtracking: revert to previous state and try alternative
    4. Branch exploration: explore multiple paths simultaneously

    Usage:
        tree = RolloutTree()

        # Create root node
        root = tree.create_root()

        # Advance with first action
        node_a = tree.advance(root.id, action=Action(...), snapshot=StateSnapshot.capture(...))
        tree.complete_node(node_a.id, observation=Observation(...))

        # Try an alternative path (branch)
        node_b = tree.branch(root.id, "alternative_approach")
        tree.advance(node_b.id, action=Action(...))
        tree.complete_node(node_b.id, observation=Observation(...))

        # Backtrack from failed path
        result = tree.backtrack(node_a.id)
        # Now can try new branch from root

        # Get best path (for final result)
        best_path = tree.get_best_path()
    """

    def __init__(
        self,
        max_depth: int = 50,
        max_nodes: int = 500,
        enable_auto_abandon: bool = True,
        abandon_threshold: float = 0.3,
    ):
        """Initialize rollout tree.

        Args:
            max_depth: Maximum tree depth to prevent infinite growth
            max_nodes: Maximum total nodes (triggers pruning if exceeded)
            enable_auto_abandon: Auto-abandon low-quality branches
            abandon_threshold: Score threshold below which branches are abandoned
        """
        self.nodes: Dict[str, RolloutNode] = {}
        self.root_id: Optional[str] = None
        self.current_id: Optional[str] = None
        self.max_depth = max_depth
        self.max_nodes = max_nodes
        self.enable_auto_abandon = enable_auto_abandon
        self.abandon_threshold = abandon_threshold

        self._node_count = 0
        self._branch_counter = 0

    def create_root(
        self,
        initial_action: Optional[Action] = None,
        initial_snapshot: Optional[StateSnapshot] = None,
    ) -> RolloutNode:
        """Create the root node of the tree.

        Args:
            initial_action: Optional initial action to record
            initial_snapshot: Optional initial state snapshot

        Returns:
            The root RolloutNode
        """
        node = RolloutNode(
            id=f"root_{uuid.uuid4().hex[:8]}",
            parent_id=None,
            depth=0,
            action=initial_action,
            status=NodeStatus.PENDING,
            state_snapshot=initial_snapshot,
            branch_name="root",
        )

        self.nodes[node.id] = node
        self.root_id = node.id
        self.current_id = node.id
        self._node_count = 1

        logger.debug("Created root node: %s", node.id)
        return node

    def advance(
        self,
        parent_id: str,
        action: Action,
        snapshot: StateSnapshot,
        branch_name: Optional[str] = None,
    ) -> Optional[RolloutNode]:
        """Create a new child node and advance to it.

        Args:
            parent_id: ID of the parent node
            action: Action taken at this step
            snapshot: State snapshot BEFORE the action
            branch_name: Optional human-readable branch name

        Returns:
            The new child RolloutNode, or None if parent not found or max depth exceeded
        """
        parent = self.nodes.get(parent_id)
        if not parent:
            logger.warning("Parent node not found: %s", parent_id)
            return None

        if parent.depth >= self.max_depth:
            logger.warning("Max depth exceeded (%d), not creating child node", self.max_depth)
            return None

        if self._node_count >= self.max_nodes:
            self._prune_oldest_branches()
            if self._node_count >= self.max_nodes:
                logger.error("Max nodes exceeded after pruning, cannot advance")
                return None

        node = RolloutNode(
            id=f"node_{uuid.uuid4().hex[:8]}",
            parent_id=parent_id,
            depth=parent.depth + 1,
            action=action,
            status=NodeStatus.RUNNING,
            state_snapshot=snapshot,
            branch_name=branch_name or parent.branch_name,
        )

        self.nodes[node.id] = node
        parent.children_ids.append(node.id)
        self.current_id = node.id
        self._node_count += 1

        logger.debug(
            "Advanced from %s to %s (depth=%d, action=%s)",
            parent_id, node.id, node.depth, action.action_type
        )

        return node

    def complete_node(
        self,
        node_id: str,
        observation: Observation,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Mark a node as completed with observation.

        Args:
            node_id: ID of the node to complete
            observation: The observation result
            metadata: Optional additional metadata

        Returns:
            True if node was found and updated
        """
        node = self.nodes.get(node_id)
        if not node:
            logger.warning("Node not found for completion: %s", node_id)
            return False

        node.observation = observation
        node.status = NodeStatus.COMPLETED if observation.success else NodeStatus.FAILED
        node.completed_at = time.time()
        node.duration = node.completed_at - node.created_at

        if metadata:
            node.metadata.update(metadata)

        logger.debug(
            "Completed node %s: %s (duration=%.2fs)",
            node_id, observation.observation_type, node.duration
        )

        return True

    def branch(
        self,
        from_node_id: str,
        branch_name: str,
        snapshot: Optional[StateSnapshot] = None,
    ) -> Optional[RolloutNode]:
        """Create a new branch from an existing node.

        This creates an alternative path from the same parent,
        allowing exploration of different approaches.

        Args:
            from_node_id: ID of the node to branch from
            branch_name: Human-readable name for this branch
            snapshot: State snapshot for the branch (uses from_node's if not provided)

        Returns:
            The new branch RolloutNode, or None if source not found
        """
        source = self.nodes.get(from_node_id)
        if not source:
            logger.warning("Source node not found for branching: %s", from_node_id)
            return None

        self._branch_counter += 1
        branch_suffix = f"{branch_name}_{self._branch_counter}"

        use_snapshot = snapshot if snapshot is not None else source.state_snapshot

        sibling_count = len([
            n for n in self.nodes.values()
            if n.parent_id == source.parent_id
        ])

        node = RolloutNode(
            id=f"branch_{uuid.uuid4().hex[:8]}",
            parent_id=source.parent_id,
            depth=source.depth,
            status=NodeStatus.PENDING,
            state_snapshot=copy.deepcopy(use_snapshot) if use_snapshot else None,
            branch_name=branch_suffix,
            metadata={"branched_from": from_node_id, "branch_index": sibling_count},
        )

        self.nodes[node.id] = node
        if source.parent_id:
            parent = self.nodes[source.parent_id]
            parent.children_ids.append(node.id)

        self.current_id = node.id
        self._node_count += 1

        logger.info(
            "Created branch '%s' from node %s (depth=%d)",
            branch_name, from_node_id, node.depth
        )

        return node

    def backtrack(
        self,
        to_node_id: str,
        abandon_reason: str = "manual_backtrack",
    ) -> Optional[BacktrackResult]:
        """Backtrack to a previous node, abandoning current branch.

        This is the core feature for "try, fail, revert, try again":
        1. Captures the state at target node
        2. Marks all nodes in current path (from current back to target) as ABANDONED
        3. Restores state snapshot at target
        4. Advances current pointer to target

        Args:
            to_node_id: ID of the node to backtrack to
            abandon_reason: Reason for abandoning the branch

        Returns:
            BacktrackResult with details, or None if target not found
        """
        target = self.nodes.get(to_node_id)
        if not target:
            logger.warning("Target node not found for backtrack: %s", to_node_id)
            return None

        current = self.nodes.get(self.current_id)
        if not current:
            logger.warning("Current node not found")
            return None

        abandoned_ids = []
        node = current
        while node and node.id != to_node_id:
            abandoned_ids.append(node.id)
            node.status = NodeStatus.ABANDONED
            node.metadata["abandon_reason"] = abandon_reason
            node.metadata["abandoned_at"] = time.time()
            node = self.nodes.get(node.parent_id) if node.parent_id else None

        if not node or node.id != to_node_id:
            logger.error("Could not find path from current to target")
            return None

        self.current_id = to_node_id

        result = BacktrackResult(
            target_node_id=to_node_id,
            restored_state=copy.deepcopy(target.state_snapshot) if target.state_snapshot else StateSnapshot(context=[]),
            abandoned_branch_size=len(abandoned_ids),
            new_branch_name=f"backtrack_from_{current.id}",
        )

        logger.info(
            "Backtracked from %s to %s, abandoned %d nodes",
            current.id, to_node_id, len(abandoned_ids)
        )

        return result

    def get_best_path(
        self,
        score_fn: Optional[Callable[[RolloutNode], float]] = None,
    ) -> List[RolloutNode]:
        """Get the best path from root to a leaf node.

        Uses score function to evaluate nodes if provided,
        otherwise defaults to: completed nodes with highest depth.

        Args:
            score_fn: Optional function(node) -> score to evaluate node quality

        Returns:
            List of nodes from root to best leaf
        """
        if not self.root_id:
            return []

        if score_fn is None:
            def score_fn(node: RolloutNode) -> float:
                if node.status != NodeStatus.COMPLETED:
                    return -1000.0
                return node.depth + (node.metadata.get("quality_score", 0.0))

        best_leaf = None
        best_score = float('-inf')

        for node in self.nodes.values():
            if node.is_leaf() and node.status == NodeStatus.COMPLETED:
                score = score_fn(node)
                if score > best_score:
                    best_score = score
                    best_leaf = node

        if not best_leaf:
            for node in self.nodes.values():
                if node.is_leaf() and node.status != NodeStatus.ABANDONED:
                    score = score_fn(node)
                    if score > best_score:
                        best_score = score
                        best_leaf = node

        if not best_leaf:
            return [self.nodes[self.root_id]]

        path = []
        node = best_leaf
        while node:
            path.insert(0, node)
            node = self.nodes.get(node.parent_id) if node.parent_id else None

        return path

    def get_path_to_root(self, node_id: str) -> List[RolloutNode]:
        """Get the path from a node back to root.

        Args:
            node_id: ID of the starting node

        Returns:
            List of nodes from root to the specified node
        """
        path = []
        node = self.nodes.get(node_id)

        while node:
            path.insert(0, node)
            node = self.nodes.get(node.parent_id) if node.parent_id else None

        return path

    def get_current_node(self) -> Optional[RolloutNode]:
        """Get the current active node."""
        return self.nodes.get(self.current_id) if self.current_id else None

    def get_all_branches(self) -> Dict[str, List[RolloutNode]]:
        """Get all branches grouped by branch name.

        Returns:
            Dict mapping branch_name -> list of nodes in that branch
        """
        branches: Dict[str, List[RolloutNode]] = {}

        for node in self.nodes.values():
            branch = node.branch_name or "unknown"
            if branch not in branches:
                branches[branch] = []
            branches[branch].append(node)

        return branches

    def get_statistics(self) -> Dict[str, Any]:
        """Get tree statistics.

        Returns:
            Dict with tree metrics
        """
        if not self.root_id:
            return {
                "total_nodes": 0,
                "max_depth": 0,
                "branch_count": 0,
                "completed_nodes": 0,
                "failed_nodes": 0,
                "abandoned_nodes": 0,
            }

        status_counts = {s: 0 for s in NodeStatus}
        max_depth = 0
        branch_names = set()

        for node in self.nodes.values():
            status_counts[node.status] += 1
            max_depth = max(max_depth, node.depth)
            if node.branch_name:
                branch_names.add(node.branch_name)

        return {
            "total_nodes": len(self.nodes),
            "max_depth": max_depth,
            "branch_count": len(branch_names),
            "completed_nodes": status_counts[NodeStatus.COMPLETED],
            "failed_nodes": status_counts[NodeStatus.FAILED],
            "abandoned_nodes": status_counts[NodeStatus.ABANDONED],
            "pending_nodes": status_counts[NodeStatus.PENDING],
            "running_nodes": status_counts[NodeStatus.RUNNING],
            "branches": list(branch_names),
            "current_node_id": self.current_id,
            "root_node_id": self.root_id,
        }

    def _prune_oldest_branches(self) -> int:
        """Prune oldest/abandoned branches to reduce node count.

        Returns:
            Number of nodes pruned
        """
        pruned = 0

        abandoned_nodes = [
            n for n in self.nodes.values()
            if n.status == NodeStatus.ABANDONED
        ]

        for node in abandoned_nodes:
            if self._node_count - pruned <= self.max_nodes // 2:
                break

            descendants = self._get_descendants(node.id)
            for desc_id in descendants:
                if desc_id in self.nodes:
                    del self.nodes[desc_id]
                    pruned += 1

            if node.id in self.nodes:
                del self.nodes[node.id]
                pruned += 1

        self._node_count = len(self.nodes)

        logger.info("Pruned %d nodes, %d remaining", pruned, self._node_count)

        return pruned

    def _get_descendants(self, node_id: str) -> List[str]:
        """Get all descendant node IDs for a node.

        Args:
            node_id: ID of the node

        Returns:
            List of descendant IDs (including indirect)
        """
        descendants = []
        queue = list(self.nodes.get(node_id, RolloutNode()).children_ids)

        while queue:
            child_id = queue.pop(0)
            descendants.append(child_id)
            child = self.nodes.get(child_id)
            if child:
                queue.extend(child.children_ids)

        return descendants

    def to_dict(self) -> Dict[str, Any]:
        """Export tree to dictionary format.

        Returns:
            Dict representation of the tree
        """
        return {
            "statistics": self.get_statistics(),
            "nodes": {node_id: node.to_dict() for node_id, node in self.nodes.items()},
        }


class RolloutManager:
    """Manager for RolloutTree integration with AgentLoop.

    Provides high-level API for:
    - Wrapping LLM calls and tool executions with rollout tracking
    - Automatic state snapshot capture and restoration
    - Branch exploration strategies
    - Backtracking triggers

    Usage:
        manager = RolloutManager(agent_loop)

        # Wrap LLM call
        async for event in manager.run_with_rollout("Write a program"):
            if event.get("type") == "backtrack_needed":
                # Handle backtracking
                manager.backtrack_to(node_id)

        # Get best result
        result = manager.get_best_result()
    """

    def __init__(
        self,
        max_depth: int = 50,
        max_nodes: int = 500,
        auto_explore_branches: bool = False,
        branch_on_error: bool = True,
        backtrack_on_failed_validation: bool = True,
    ):
        """Initialize rollout manager.

        Args:
            max_depth: Maximum rollout tree depth
            max_nodes: Maximum total nodes in tree
            auto_explore_branches: Automatically explore alternative branches
            branch_on_error: Create alternative branch when step fails
            backtrack_on_failed_validation: Backtrack when evaluation fails
        """
        self.tree = RolloutTree(max_depth=max_depth, max_nodes=max_nodes)
        self.auto_explore_branches = auto_explore_branches
        self.branch_on_error = branch_on_error
        self.backtrack_on_failed_validation = backtrack_on_failed_validation

        self._start_time: float = 0.0
        self._context: List[Dict[str, Any]] = []
        self._budget: Any = None
        self._breaker: Any = None

        self._on_backtrack_callbacks: List[Callable] = []
        self._on_branch_callbacks: List[Callable] = []

    def initialize(
        self,
        initial_prompt: str,
        context: List[Dict[str, Any]],
        budget: Any = None,
        breaker: Any = None,
    ) -> RolloutNode:
        """Initialize rollout with initial prompt.

        Args:
            initial_prompt: User's initial prompt
            context: Initial conversation context
            budget: TokenBudget instance
            breaker: CircuitBreaker instance

        Returns:
            Root node of the rollout tree
        """
        self._start_time = time.time()
        self._context = context
        self._budget = budget
        self._breaker = breaker

        context_copy = copy.deepcopy(context)
        context_copy.append({"role": "user", "content": initial_prompt})

        snapshot = StateSnapshot.capture(
            context=context_copy,
            budget=budget,
            breaker=breaker,
            start_time=self._start_time,
        )

        initial_action = Action(
            action_type="initial_request",
            content=initial_prompt,
        )

        root = self.tree.create_root(
            initial_action=initial_action,
            initial_snapshot=snapshot,
        )

        logger.info("Initialized rollout tree with root: %s", root.id)

        return root

    def record_llm_call(
        self,
        prompt: Any,
        response: Any,
        snapshot_before: bool = True,
    ) -> Optional[RolloutNode]:
        """Record an LLM call as a node.

        Args:
            prompt: The prompt sent to LLM
            response: The response from LLM
            snapshot_before: Whether to capture state before the call

        Returns:
            The created node, or None if no current node
        """
        current = self.tree.get_current_node()
        if not current:
            return None

        action = Action(
            action_type="llm_call",
            content={
                "prompt": str(prompt)[:500] if prompt else None,
                "response_preview": str(response)[:500] if response else None,
            },
        )

        snapshot = None
        if snapshot_before:
            snapshot = StateSnapshot.capture(
                context=self._context,
                budget=self._budget,
                breaker=self._breaker,
                start_time=self._start_time,
            )

        node = self.tree.advance(
            parent_id=current.id,
            action=action,
            snapshot=snapshot,
        )

        if node and response:
            observation = Observation(
                observation_type="llm_response",
                content=str(response)[:1000] if response else None,
                success=True,
            )
            self.tree.complete_node(node.id, observation)

        return node

    def record_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        result: Any,
        error: Optional[str] = None,
    ) -> Optional[RolloutNode]:
        """Record a tool call as a node.

        Args:
            tool_name: Name of the tool called
            arguments: Tool arguments
            result: Tool execution result
            error: Error message if tool failed

        Returns:
            The created node, or None if no current node
        """
        current = self.tree.get_current_node()
        if not current:
            return None

        snapshot = StateSnapshot.capture(
            context=self._context,
            budget=self._budget,
            breaker=self._breaker,
            start_time=self._start_time,
        )

        action = Action(
            action_type="tool_call",
            tool_name=tool_name,
            tool_arguments=arguments,
        )

        node = self.tree.advance(
            parent_id=current.id,
            action=action,
            snapshot=snapshot,
        )

        if node:
            observation = Observation(
                observation_type="tool_result",
                content=str(result)[:500] if result else None,
                success=error is None,
                error_message=error,
            )
            self.tree.complete_node(node.id, observation)

        return node

    def record_evaluation(
        self,
        verdict: str,
        score: float,
        issues: List[str],
    ) -> Optional[RolloutNode]:
        """Record an evaluation step.

        Args:
            verdict: Evaluation verdict (approve/reject/needs_revision)
            score: Evaluation score
            issues: List of issues found

        Returns:
            The created node, or None if no current node
        """
        current = self.tree.get_current_node()
        if not current:
            return None

        snapshot = StateSnapshot.capture(
            context=self._context,
            budget=self._budget,
            breaker=self._breaker,
            start_time=self._start_time,
        )

        action = Action(
            action_type="evaluation",
            content={"verdict": verdict, "score": score},
        )

        node = self.tree.advance(
            parent_id=current.id,
            action=action,
            snapshot=snapshot,
        )

        if node:
            observation = Observation(
                observation_type="evaluation_result",
                content={"verdict": verdict, "score": score, "issues": issues},
                success=verdict in ("approve", "needs_revision"),
                metadata={"score": score, "issues": issues},
            )
            self.tree.complete_node(node.id, observation, metadata={"quality_score": score})

            if verdict == "reject" and self.backtrack_on_failed_validation:
                logger.info("Evaluation rejected, triggering backtrack check")

        return node

    def trigger_branch(
        self,
        branch_name: str,
        reason: str,
    ) -> Optional[RolloutNode]:
        """Trigger creation of an alternative branch.

        Args:
            branch_name: Name for the new branch
            reason: Reason for branching

        Returns:
            The new branch node, or None
        """
        current = self.tree.get_current_node()
        if not current:
            return None

        branch_node = self.tree.branch(
            from_node_id=current.parent_id or self.tree.root_id,
            branch_name=branch_name,
        )

        if branch_node:
            for callback in self._on_branch_callbacks:
                try:
                    callback(branch_node, reason)
                except Exception as e:
                    logger.warning("Branch callback error: %s", e)

        return branch_node

    def trigger_backtrack(
        self,
        to_node_id: Optional[str] = None,
        reason: str = "evaluation_failed",
    ) -> Optional[BacktrackResult]:
        """Trigger backtracking to a previous state.

        Args:
            to_node_id: Target node ID to backtrack to (current if None)
            reason: Reason for backtracking

        Returns:
            BacktrackResult with details, or None
        """
        if to_node_id is None:
            to_node_id = self.tree.current_id

        result = self.tree.backtrack(to_node_id, abandon_reason=reason)

        if result:
            result.restored_state.restore(
                context=self._context,
                budget=self._budget,
                breaker=self._breaker,
            )

            for callback in self._on_backtrack_callbacks:
                try:
                    callback(result)
                except Exception as e:
                    logger.warning("Backtrack callback error: %s", e)

        return result

    def on_backtrack(self, callback: Callable) -> "RolloutManager":
        """Register a callback for backtrack events.

        Args:
            callback: Function(BacktrackResult) to call

        Returns:
            Self for chaining
        """
        self._on_backtrack_callbacks.append(callback)
        return self

    def on_branch(self, callback: Callable) -> "RolloutManager":
        """Register a callback for branch events.

        Args:
            callback: Function(new_node, reason) to call

        Returns:
            Self for chaining
        """
        self._on_branch_callbacks.append(callback)
        return self

    def get_best_result(self) -> Dict[str, Any]:
        """Get the best result from the rollout tree.

        Returns:
            Dict with best path and result
        """
        best_path = self.tree.get_best_path()

        if not best_path:
            return {"path": [], "result": None}

        final_node = best_path[-1]

        return {
            "path": [n.id for n in best_path],
            "path_nodes": best_path,
            "final_node": final_node,
            "final_observation": final_node.observation.to_dict() if final_node.observation else None,
            "statistics": self.tree.get_statistics(),
        }

    def get_tree(self) -> RolloutTree:
        """Get the underlying rollout tree.

        Returns:
            The RolloutTree instance
        """
        return self.tree
