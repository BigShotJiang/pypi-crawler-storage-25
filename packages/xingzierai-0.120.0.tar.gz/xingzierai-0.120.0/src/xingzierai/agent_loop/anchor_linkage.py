# -*- coding: utf-8 -*-
"""Anchor Linkage Mechanism for multi-turn coherence.

This module provides cross-turn dependency tracking for agent conversations,
inspired by UniToolCall's Anchor Linkage mechanism.

Key concepts:
- Anchor: A marker in a turn that can be referenced by future turns
- AnchorReference: A reference to an anchor from a previous turn
- AnchorChain: A chain of related turns connected by anchors
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class AnchorType(str, Enum):
    """Types of anchors that can be created during conversation."""

    TOOL_RESULT = "tool_result"
    CONTEXT = "context"
    DECISION = "decision"
    STATE = "state"
    CUSTOM = "custom"


@dataclass
class Anchor:
    """Represents an anchor point in conversation that can be referenced later.

    Anchors are created during tool execution or LLM responses and can be
    referenced by subsequent turns to maintain coherence.
    """

    id: str
    anchor_type: AnchorType
    content: Any
    turn_index: int
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    references: List[str] = field(default_factory=list)

    @classmethod
    def create(
        cls,
        anchor_type: AnchorType,
        content: Any,
        turn_index: int,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Anchor:
        """Factory method to create a new anchor with auto-generated ID."""
        return cls(
            id=f"anchor_{uuid.uuid4().hex[:8]}",
            anchor_type=anchor_type,
            content=content,
            turn_index=turn_index,
            metadata=metadata or {},
        )


@dataclass
class AnchorReference:
    """Represents a reference to an anchor from a previous turn."""

    anchor_id: str
    referring_turn: int
    context: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AnchorChain:
    """A chain of turns connected through anchor references.

    Tracks the evolution of a conversation thread through anchor dependencies.
    """

    id: str
    anchor_ids: List[str] = field(default_factory=list)
    turn_indices: List[int] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)

    def add_anchor(self, anchor_id: str, turn_index: int) -> None:
        """Add an anchor to this chain."""
        if anchor_id not in self.anchor_ids:
            self.anchor_ids.append(anchor_id)
        if turn_index not in self.turn_indices:
            self.turn_indices.append(turn_index)
        self.last_updated = datetime.now()

    def merge(self, other: AnchorChain) -> None:
        """Merge another chain into this one."""
        for anchor_id in other.anchor_ids:
            if anchor_id not in self.anchor_ids:
                self.anchor_ids.append(anchor_id)
        for turn_idx in other.turn_indices:
            if turn_idx not in self.turn_indices:
                self.turn_indices.append(turn_idx)
        self.last_updated = datetime.now()


class AnchorLinkage:
    """Manages cross-turn dependencies through anchors.

    This class tracks anchors created during conversation and their references,
    enabling coherent multi-turn reasoning by maintaining context across turns.

    Usage:
        linkage = AnchorLinkage()

        # Create anchor from tool result
        anchor = linkage.create_anchor(
            anchor_type=AnchorType.TOOL_RESULT,
            content=tool_result,
            turn_index=0,
        )

        # Reference anchor in later turn
        linkage.add_reference(
            anchor_id=anchor.id,
            referring_turn=2,
            context="Used result from turn 0",
        )

        # Get all anchors visible to current turn
        visible = linkage.get_visible_anchors(turn_index=2)
    """

    def __init__(self, max_chain_history: int = 100):
        """Initialize AnchorLinkage.

        Args:
            max_chain_history: Maximum number of anchors to retain
        """
        self._anchors: Dict[str, Anchor] = {}
        self._references: Dict[str, List[AnchorReference]] = {}
        self._chains: Dict[str, AnchorChain] = {}
        self._turn_to_chain: Dict[int, str] = {}
        self.max_chain_history = max_chain_history

    def create_anchor(
        self,
        anchor_type: AnchorType,
        content: Any,
        turn_index: int,
        chain_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Anchor:
        """Create a new anchor from content at a specific turn.

        Args:
            anchor_type: Type of anchor being created
            content: The content to anchor (tool result, context, etc.)
            turn_index: The turn index where this anchor is created
            chain_id: Optional chain ID to add this anchor to
            metadata: Optional metadata about the anchor

        Returns:
            The created Anchor object
        """
        anchor = Anchor.create(
            anchor_type=anchor_type,
            content=content,
            turn_index=turn_index,
            metadata=metadata,
        )

        self._anchors[anchor.id] = anchor
        self._references[anchor.id] = []

        if chain_id:
            if chain_id not in self._chains:
                self._chains[chain_id] = AnchorChain(id=chain_id)
            self._chains[chain_id].add_anchor(anchor.id, turn_index)
            self._turn_to_chain[turn_index] = chain_id
        elif turn_index not in self._turn_to_chain:
            new_chain = AnchorChain(id=f"chain_{uuid.uuid4().hex[:8]}")
            new_chain.add_anchor(anchor.id, turn_index)
            self._chains[new_chain.id] = new_chain
            self._turn_to_chain[turn_index] = new_chain.id

        self._cleanup_old_anchors()

        return anchor

    def add_reference(
        self,
        anchor_id: str,
        referring_turn: int,
        context: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[AnchorReference]:
        """Add a reference to an existing anchor from a later turn.

        Args:
            anchor_id: ID of the anchor being referenced
            referring_turn: Turn index where the reference is made
            context: Description of how the anchor is being used
            metadata: Optional metadata about the reference

        Returns:
            The created AnchorReference, or None if anchor doesn't exist
        """
        if anchor_id not in self._anchors:
            return None

        ref = AnchorReference(
            anchor_id=anchor_id,
            referring_turn=referring_turn,
            context=context,
            metadata=metadata or {},
        )

        self._references[anchor_id].append(ref)
        self._anchors[anchor_id].references.append(ref.referring_turn)

        referred_anchor = self._anchors[anchor_id]
        if referred_anchor.turn_index in self._turn_to_chain:
            chain_id = self._turn_to_chain[referred_anchor.turn_index]
            if chain_id in self._chains:
                self._chains[chain_id].add_anchor(anchor_id, referring_turn)
                self._turn_to_chain[referring_turn] = chain_id

        return ref

    def get_visible_anchors(
        self,
        turn_index: int,
        anchor_type: Optional[AnchorType] = None,
    ) -> List[Anchor]:
        """Get all anchors visible to a given turn (from earlier turns).

        Args:
            turn_index: The turn index to get visible anchors for
            anchor_type: Optional filter for anchor type

        Returns:
            List of anchors from earlier turns
        """
        visible = [
            anchor
            for anchor in self._anchors.values()
            if anchor.turn_index < turn_index
        ]

        if anchor_type:
            visible = [a for a in visible if a.anchor_type == anchor_type]

        return sorted(visible, key=lambda a: a.turn_index, reverse=True)

    def get_chain_for_turn(self, turn_index: int) -> Optional[AnchorChain]:
        """Get the anchor chain that a turn belongs to.

        Args:
            turn_index: The turn index to look up

        Returns:
            The AnchorChain if found, None otherwise
        """
        chain_id = self._turn_to_chain.get(turn_index)
        if chain_id:
            return self._chains.get(chain_id)
        return None

    def get_chain_anchors(self, chain_id: str) -> List[Anchor]:
        """Get all anchors in a specific chain.

        Args:
            chain_id: The chain ID to look up

        Returns:
            List of anchors in the chain, sorted by turn index
        """
        chain = self._chains.get(chain_id)
        if not chain:
            return []

        anchors = [self._anchors[aid] for aid in chain.anchor_ids if aid in self._anchors]
        return sorted(anchors, key=lambda a: a.turn_index)

    def get_anchor_by_id(self, anchor_id: str) -> Optional[Anchor]:
        """Get a specific anchor by ID."""
        return self._anchors.get(anchor_id)

    def get_references_to_anchor(self, anchor_id: str) -> List[AnchorReference]:
        """Get all references to a specific anchor."""
        return self._references.get(anchor_id, [])

    def get_all_chains(self) -> List[AnchorChain]:
        """Get all anchor chains."""
        return list(self._chains.values())

    def get_dependency_graph(self, turn_index: int) -> Dict[str, List[str]]:
        """Build a dependency graph for a given turn.

        Returns a dictionary mapping anchor IDs to lists of anchor IDs
        they depend on.

        Args:
            turn_index: The turn to build graph for

        Returns:
            Adjacency list representation of anchor dependencies
        """
        graph: Dict[str, List[str]] = {}

        for ref in self._references.values():
            for r in ref:
                if r.referring_turn <= turn_index:
                    if r.anchor_id not in graph:
                        graph[r.anchor_id] = []

        return graph

    def _cleanup_old_anchors(self) -> None:
        """Remove old anchors if exceeding max_chain_history."""
        if len(self._anchors) <= self.max_chain_history:
            return

        sorted_anchors = sorted(
            self._anchors.items(),
            key=lambda x: x[1].created_at,
        )

        to_remove = len(self._anchors) - self.max_chain_history
        for anchor_id, anchor in sorted_anchors[:to_remove]:
            self._remove_anchor(anchor_id)

    def _remove_anchor(self, anchor_id: str) -> None:
        """Remove an anchor and its references."""
        if anchor_id in self._anchors:
            del self._anchors[anchor_id]
        if anchor_id in self._references:
            del self._references[anchor_id]

    def export_state(self) -> Dict[str, Any]:
        """Export the current state for serialization."""
        return {
            "anchors": {
                aid: {
                    "id": a.id,
                    "anchor_type": a.anchor_type.value,
                    "content": str(a.content)[:500],
                    "turn_index": a.turn_index,
                    "created_at": a.created_at.isoformat(),
                    "references": a.references,
                }
                for aid, a in self._anchors.items()
            },
            "chains": {
                cid: {
                    "id": c.id,
                    "anchor_ids": c.anchor_ids,
                    "turn_indices": c.turn_indices,
                }
                for cid, c in self._chains.items()
            },
            "total_anchors": len(self._anchors),
            "total_chains": len(self._chains),
        }

    def __len__(self) -> int:
        """Return total number of anchors."""
        return len(self._anchors)

    def __repr__(self) -> str:
        return (
            f"AnchorLinkage(anchors={len(self._anchors)}, "
            f"chains={len(self._chains)})"
        )