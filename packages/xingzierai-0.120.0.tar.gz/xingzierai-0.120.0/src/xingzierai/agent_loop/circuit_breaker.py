# -*- coding: utf-8 -*-
"""CircuitBreaker - Dead loop and runaway protection.

From Claude Code architecture:
- Dead loop circuit breaker protection
- Fail-closed mechanism: eliminate safety risks at compile time
- SyncBarrier mechanism for concurrent control
- Read-write isolation to prevent data rollback
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class BreakerState(str, Enum):
    """Circuit breaker states."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class BreakerConfig:
    """Circuit breaker configuration."""
    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    half_open_max_calls: int = 3
    success_threshold: int = 3
    max_consecutive_same_tool: int = 5
    max_total_tool_calls: int = 100
    max_execution_time: float = 300.0
    max_llm_calls: int = 50
    max_repeated_errors: int = 3


@dataclass
class BreakerSnapshot:
    """Snapshot of circuit breaker state."""
    state: BreakerState
    failure_count: int = 0
    success_count: int = 0
    consecutive_same_tool: int = 0
    last_tool_name: str = ""
    total_tool_calls: int = 0
    total_llm_calls: int = 0
    execution_time: float = 0.0
    last_failure_time: float = 0.0
    repeated_error_count: int = 0
    last_error_message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "consecutive_same_tool": self.consecutive_same_tool,
            "last_tool_name": self.last_tool_name,
            "total_tool_calls": self.total_tool_calls,
            "total_llm_calls": self.total_llm_calls,
            "execution_time": self.execution_time,
        }


class CircuitBreaker:
    """Circuit breaker for agent loop protection.

    Protects against:
    1. Dead loops (same tool called repeatedly)
    2. Runaway execution (too many tool/LLM calls)
    3. Repeated errors (same error occurring multiple times)
    4. Execution timeout
    5. Infinite retry cycles

    Usage:
        breaker = CircuitBreaker()

        # Before each tool call
        if breaker.should_break(tool_name="read_file"):
            # Stop execution
            return

        # Record results
        breaker.record_success(tool_name="read_file")
        # or
        breaker.record_failure(tool_name="read_file", error="File not found")
    """

    def __init__(self, config: Optional[BreakerConfig] = None):
        """Initialize circuit breaker.

        Args:
            config: Breaker configuration
        """
        self.config = config or BreakerConfig()
        self._state = BreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._consecutive_same_tool = 0
        self._last_tool_name = ""
        self._total_tool_calls = 0
        self._total_llm_calls = 0
        self._start_time = time.time()
        self._last_failure_time = 0.0
        self._repeated_error_count = 0
        self._last_error_message = ""
        self._half_open_calls = 0
        self._callbacks: Dict[BreakerState, List[Callable]] = {
            state: [] for state in BreakerState
        }

    @property
    def state(self) -> BreakerState:
        """Get current breaker state."""
        return self._state

    def should_break(self, tool_name: Optional[str] = None) -> bool:
        """Check if the circuit breaker should trip.

        Args:
            tool_name: Name of the tool about to be called

        Returns:
            True if execution should stop
        """
        if self._state == BreakerState.OPEN:
            if time.time() - self._last_failure_time >= self.config.recovery_timeout:
                self._transition_to(BreakerState.HALF_OPEN)
                return False
            return True

        if self._state == BreakerState.HALF_OPEN:
            if self._half_open_calls >= self.config.half_open_max_calls:
                self._transition_to(BreakerState.OPEN)
                return True
            return False

        # CLOSED state - check limits
        if self._failure_count >= self.config.failure_threshold:
            self._transition_to(BreakerState.OPEN)
            return True

        if tool_name:
            if tool_name == self._last_tool_name:
                if self._consecutive_same_tool >= self.config.max_consecutive_same_tool:
                    logger.warning(
                        f"Dead loop detected: {tool_name} called "
                        f"{self._consecutive_same_tool} times consecutively"
                    )
                    self._transition_to(BreakerState.OPEN)
                    return True
            else:
                self._consecutive_same_tool = 0

        if self._total_tool_calls >= self.config.max_total_tool_calls:
            logger.warning(f"Total tool call limit reached: {self._total_tool_calls}")
            self._transition_to(BreakerState.OPEN)
            return True

        if self._total_llm_calls >= self.config.max_llm_calls:
            logger.warning(f"LLM call limit reached: {self._total_llm_calls}")
            self._transition_to(BreakerState.OPEN)
            return True

        elapsed = time.time() - self._start_time
        if elapsed >= self.config.max_execution_time:
            logger.warning(f"Execution timeout: {elapsed:.1f}s")
            self._transition_to(BreakerState.OPEN)
            return True

        if self._repeated_error_count >= self.config.max_repeated_errors:
            logger.warning(f"Repeated error limit: {self._repeated_error_count}")
            self._transition_to(BreakerState.OPEN)
            return True

        return False

    def record_success(self, tool_name: Optional[str] = None) -> None:
        """Record a successful operation.

        Args:
            tool_name: Name of the tool that succeeded
        """
        self._success_count += 1
        self._total_tool_calls += 1

        if tool_name:
            if tool_name == self._last_tool_name:
                self._consecutive_same_tool += 1
            else:
                self._consecutive_same_tool = 1
                self._last_tool_name = tool_name

        if self._state == BreakerState.HALF_OPEN:
            self._half_open_calls += 1
            if self._success_count >= self.config.success_threshold:
                self._transition_to(BreakerState.CLOSED)

    def record_failure(
        self,
        tool_name: Optional[str] = None,
        error: Optional[str] = None,
    ) -> None:
        """Record a failed operation.

        Args:
            tool_name: Name of the tool that failed
            error: Error message
        """
        self._failure_count += 1
        self._total_tool_calls += 1
        self._last_failure_time = time.time()

        if tool_name:
            if tool_name == self._last_tool_name:
                self._consecutive_same_tool += 1
            else:
                self._consecutive_same_tool = 1
                self._last_tool_name = tool_name

        if error and error == self._last_error_message:
            self._repeated_error_count += 1
        else:
            self._repeated_error_count = 1
            self._last_error_message = error or ""

        if self._state == BreakerState.HALF_OPEN:
            self._transition_to(BreakerState.OPEN)

    def record_llm_call(self) -> None:
        """Record an LLM API call."""
        self._total_llm_calls += 1

    def get_snapshot(self) -> BreakerSnapshot:
        """Get current breaker state snapshot.

        Returns:
            BreakerSnapshot
        """
        return BreakerSnapshot(
            state=self._state,
            failure_count=self._failure_count,
            success_count=self._success_count,
            consecutive_same_tool=self._consecutive_same_tool,
            last_tool_name=self._last_tool_name,
            total_tool_calls=self._total_tool_calls,
            total_llm_calls=self._total_llm_calls,
            execution_time=time.time() - self._start_time,
            last_failure_time=self._last_failure_time,
            repeated_error_count=self._repeated_error_count,
            last_error_message=self._last_error_message,
        )

    def _transition_to(self, new_state: BreakerState) -> None:
        """Transition to a new breaker state.

        Args:
            new_state: Target state
        """
        old_state = self._state
        self._state = new_state

        if new_state == BreakerState.HALF_OPEN:
            self._half_open_calls = 0
        elif new_state == BreakerState.CLOSED:
            self._failure_count = 0
            self._success_count = 0

        logger.info(f"Circuit breaker: {old_state.value} → {new_state.value}")

        for callback in self._callbacks.get(new_state, []):
            try:
                callback(old_state, new_state)
            except Exception as e:
                logger.warning(f"Breaker callback error: {e}")

    def register_callback(
        self,
        state: BreakerState,
        callback: Callable,
    ) -> None:
        """Register a callback for state transitions.

        Args:
            state: State to trigger on
            callback: Function(old_state, new_state)
        """
        self._callbacks[state].append(callback)

    def reset(self) -> None:
        """Reset the circuit breaker."""
        self._state = BreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._consecutive_same_tool = 0
        self._last_tool_name = ""
        self._total_tool_calls = 0
        self._total_llm_calls = 0
        self._start_time = time.time()
        self._last_failure_time = 0.0
        self._repeated_error_count = 0
        self._last_error_message = ""
        self._half_open_calls = 0
