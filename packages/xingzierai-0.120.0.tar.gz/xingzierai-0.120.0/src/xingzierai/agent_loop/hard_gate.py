# -*- coding: utf-8 -*-
"""HardGateExecutor - Mandatory review gate enforcement.

Inspired by Alibaba's SDD-RIPER and Qoder Harness Engineering:
- No Spec, No Code: code changes require approved spec
- Spec is Truth: spec-code conflicts always blame code
- Reverse Sync: fix spec before fixing code
- Hard-Gate: critical nodes enforce mandatory review, no bypass
- Triangulation: Spec vs Code vs ExecutionLog cross-validation

This module provides:
1. Gate definitions with configurable checks
2. Gate execution with pass/fail/block semantics
3. Spec-Code bidirectional verification (Reverse Sync)
4. Progressive gate depth based on change complexity
5. Gate history and audit trail
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class GateVerdict(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    BLOCK = "block"
    SKIP = "skip"
    PENDING_REVIEW = "pending_review"


class ChangeComplexity(str, Enum):
    TRIVIAL = "trivial"
    SIMPLE = "simple"
    MEDIUM = "medium"
    COMPLEX = "complex"


class GatePhase(str, Enum):
    PRE_SPEC = "pre_spec"
    POST_SPEC = "post_spec"
    PRE_CODE = "pre_code"
    POST_CODE = "post_code"
    PRE_COMMIT = "pre_commit"


@dataclass
class GateCheck:
    name: str
    description: str
    check_fn: Optional[Callable] = None
    required: bool = True
    auto: bool = True
    severity: str = "error"

    def run(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        if self.check_fn:
            try:
                result = self.check_fn(context)
                if isinstance(result, tuple):
                    return result
                return bool(result), "Check passed" if result else "Check failed"
            except Exception as e:
                return False, f"Check error: {e}"
        return True, "No check function defined"


@dataclass
class GateDefinition:
    gate_id: str
    name: str
    phase: GatePhase
    description: str
    checks: List[GateCheck] = field(default_factory=list)
    required_for: List[ChangeComplexity] = field(default_factory=lambda: [ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX])
    bypass_allowed: bool = False
    human_review: bool = False


@dataclass
class GateResult:
    gate_id: str
    verdict: GateVerdict
    check_results: Dict[str, Tuple[bool, str]] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    duration: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gate_id": self.gate_id,
            "verdict": self.verdict.value,
            "check_results": {k: {"passed": v[0], "detail": v[1]} for k, v in self.check_results.items()},
            "issues": self.issues,
            "suggestions": self.suggestions,
            "timestamp": self.timestamp,
            "duration": self.duration,
            "metadata": self.metadata,
        }


@dataclass
class SpecDocument:
    path: str
    content: str
    version: str = "1.0"
    approved: bool = False
    sections: Dict[str, str] = field(default_factory=dict)
    requirements: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    acceptance_criteria: List[str] = field(default_factory=list)

    @classmethod
    def from_file(cls, path: str) -> "SpecDocument":
        p = Path(path)
        if not p.exists():
            return cls(path=path, content="")
        content = p.read_text(encoding="utf-8")
        spec = cls(path=path, content=content)
        spec._parse_sections()
        return spec

    def _parse_sections(self):
        section_pattern = re.compile(r'^##\s+(.+)$', re.MULTILINE)
        sections = {}
        current_header = None
        current_lines = []

        for line in self.content.split('\n'):
            match = section_pattern.match(line)
            if match:
                if current_header:
                    sections[current_header] = '\n'.join(current_lines).strip()
                current_header = match.group(1).strip()
                current_lines = []
            elif current_header:
                current_lines.append(line)

        if current_header:
            sections[current_header] = '\n'.join(current_lines).strip()

        self.sections = sections
        self._extract_requirements()
        self._extract_constraints()
        self._extract_acceptance_criteria()

    def _extract_requirements(self):
        req_pattern = re.compile(r'(?:REQ|REQ-\d+)[\s:]+(.+)', re.IGNORECASE)
        self.requirements = []
        for line in self.content.split('\n'):
            match = req_pattern.match(line.strip())
            if match:
                self.requirements.append(match.group(1).strip())

    def _extract_constraints(self):
        constraint_pattern = re.compile(r'(?:CONSTRAINT|MUST|SHALL|NEVER)[\s:]+(.+)', re.IGNORECASE)
        self.constraints = []
        for line in self.content.split('\n'):
            match = constraint_pattern.match(line.strip())
            if match:
                self.constraints.append(match.group(1).strip())

    def _extract_acceptance_criteria(self):
        criteria_pattern = re.compile(r'(?:AC|Acceptance|验收)[\s:-]+(.+)', re.IGNORECASE)
        self.acceptance_criteria = []
        for line in self.content.split('\n'):
            match = criteria_pattern.match(line.strip())
            if match:
                self.acceptance_criteria.append(match.group(1).strip())

    def has_required_sections(self) -> Tuple[bool, List[str]]:
        required = {"Background", "Requirements", "Acceptance Criteria"}
        found = set(self.sections.keys())
        missing = []
        for req in required:
            if not any(req.lower() in s.lower() for s in found):
                missing.append(req)
        return len(missing) == 0, missing

    def is_approved(self) -> bool:
        return self.approved or "[APPROVED]" in self.content or "status: approved" in self.content.lower()


@dataclass
class CodeChange:
    file_path: str
    old_content: str
    new_content: str
    change_type: str = "modify"
    description: str = ""
    affected_requirements: List[str] = field(default_factory=list)
    sensitive: bool = False

    @property
    def diff_lines(self) -> int:
        old_lines = self.old_content.splitlines()
        new_lines = self.new_content.splitlines()
        return sum(1 for a, b in zip(old_lines, new_lines) if a != b) + abs(len(new_lines) - len(old_lines))

    @property
    def complexity(self) -> ChangeComplexity:
        if self.diff_lines <= 5 and not self.sensitive:
            return ChangeComplexity.TRIVIAL
        if self.diff_lines <= 20 and not self.sensitive:
            return ChangeComplexity.SIMPLE
        if self.diff_lines <= 100 and not self.sensitive:
            return ChangeComplexity.MEDIUM
        return ChangeComplexity.COMPLEX


class HardGateExecutor:
    """Mandatory gate enforcement engine.

    Implements Alibaba's Hard-Gate methodology:
    - Gates are mandatory checkpoints, not optional
    - Each gate has configurable checks
    - Failed gates BLOCK progression
    - Sensitive changes require human review
    - Full audit trail for compliance

    Usage:
        executor = HardGateExecutor(workspace_dir=Path("/project"))

        result = executor.execute_gate(
            gate_id="post_spec",
            context={"spec": spec_doc, "complexity": "medium"},
        )

        if result.verdict == GateVerdict.BLOCK:
            # Cannot proceed
    """

    def __init__(self, workspace_dir: Optional[Path] = None):
        self.workspace_dir = workspace_dir or Path.cwd()
        self._gates: Dict[str, GateDefinition] = {}
        self._history: List[GateResult] = []
        self._max_history = 1000
        self._register_default_gates()

    def _register_default_gates(self):
        self.register_gate(GateDefinition(
            gate_id="pre_spec",
            name="Pre-Spec Validation",
            phase=GatePhase.PRE_SPEC,
            description="Validate that a spec exists and is well-formed before any code change",
            checks=[
                GateCheck(name="spec_exists", description="Spec file must exist", check_fn=self._check_spec_exists, required=True),
                GateCheck(name="spec_has_sections", description="Spec must have required sections", check_fn=self._check_spec_sections, required=True),
                GateCheck(name="spec_not_empty", description="Spec content must not be empty", check_fn=self._check_spec_not_empty, required=True),
            ],
            required_for=[ChangeComplexity.SIMPLE, ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX],
            bypass_allowed=False,
        ))

        self.register_gate(GateDefinition(
            gate_id="post_spec",
            name="Post-Spec Approval",
            phase=GatePhase.POST_SPEC,
            description="Spec must be approved before coding begins",
            checks=[
                GateCheck(name="spec_approved", description="Spec must be marked as approved", check_fn=self._check_spec_approved, required=True),
                GateCheck(name="spec_has_acceptance", description="Spec must define acceptance criteria", check_fn=self._check_spec_acceptance, required=True),
                GateCheck(name="spec_no_contradictions", description="Spec must not contain contradictions", check_fn=self._check_spec_consistency, required=False),
            ],
            required_for=[ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX],
            bypass_allowed=False,
            human_review=True,
        ))

        self.register_gate(GateDefinition(
            gate_id="pre_code",
            name="Pre-Code Validation",
            phase=GatePhase.PRE_CODE,
            description="Validate code change is authorized by spec before writing",
            checks=[
                GateCheck(name="change_in_spec", description="Change must be covered by spec", check_fn=self._check_change_in_spec, required=True),
                GateCheck(name="no_spec_conflict", description="Change must not conflict with spec constraints", check_fn=self._check_no_spec_conflict, required=True),
                GateCheck(name="safety_level_check", description="File safety level must allow change", check_fn=self._check_safety_level, required=True),
            ],
            required_for=[ChangeComplexity.SIMPLE, ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX],
            bypass_allowed=False,
        ))

        self.register_gate(GateDefinition(
            gate_id="post_code",
            name="Post-Code Verification",
            phase=GatePhase.POST_CODE,
            description="Verify code change conforms to spec after writing",
            checks=[
                GateCheck(name="syntax_valid", description="Code must have valid syntax", check_fn=self._check_syntax, required=True, auto=True),
                GateCheck(name="spec_conformance", description="Code must conform to spec requirements", check_fn=self._check_spec_conformance, required=True),
                GateCheck(name="no_unintended_changes", description="No changes outside spec scope", check_fn=self._check_no_scope_creep, required=False),
                GateCheck(name="tests_pass", description="Related tests must pass", check_fn=self._check_tests, required=False, auto=True),
            ],
            required_for=[ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX],
            bypass_allowed=False,
        ))

        self.register_gate(GateDefinition(
            gate_id="pre_commit",
            name="Pre-Commit Gate",
            phase=GatePhase.PRE_COMMIT,
            description="Final gate before committing changes",
            checks=[
                GateCheck(name="all_gates_passed", description="All previous gates must have passed", check_fn=self._check_all_gates_passed, required=True),
                GateCheck(name="reverse_sync", description="Spec-Code consistency verified (Reverse Sync)", check_fn=self._check_reverse_sync, required=True),
                GateCheck(name="sensitive_review", description="Sensitive changes require human review", check_fn=self._check_sensitive_review, required=True),
            ],
            required_for=[ChangeComplexity.MEDIUM, ChangeComplexity.COMPLEX],
            bypass_allowed=False,
            human_review=True,
        ))

    def register_gate(self, gate: GateDefinition):
        self._gates[gate.gate_id] = gate

    def execute_gate(
        self,
        gate_id: str,
        context: Dict[str, Any],
        bypass: bool = False,
    ) -> GateResult:
        start_time = time.time()
        gate = self._gates.get(gate_id)

        if not gate:
            return GateResult(
                gate_id=gate_id,
                verdict=GateVerdict.SKIP,
                issues=[f"Unknown gate: {gate_id}"],
                duration=time.time() - start_time,
            )

        complexity = context.get("complexity", ChangeComplexity.MEDIUM)
        if isinstance(complexity, str):
            complexity = ChangeComplexity(complexity)

        if complexity not in gate.required_for:
            result = GateResult(
                gate_id=gate_id,
                verdict=GateVerdict.SKIP,
                metadata={"reason": f"Gate not required for {complexity.value} changes"},
                duration=time.time() - start_time,
            )
            self._record_result(result)
            return result

        if bypass and gate.bypass_allowed:
            result = GateResult(
                gate_id=gate_id,
                verdict=GateVerdict.SKIP,
                metadata={"reason": "Bypassed with permission"},
                duration=time.time() - start_time,
            )
            self._record_result(result)
            return result

        check_results = {}
        issues = []
        suggestions = []
        all_required_passed = True
        needs_human = False

        for check in gate.checks:
            passed, detail = check.run(context)
            check_results[check.name] = (passed, detail)

            if not passed and check.required:
                all_required_passed = False
                issues.append(f"[{check.name}] {detail}")
                if check.severity == "error":
                    suggestions.append(f"Fix: {check.description}")

            if not passed and check.human_review if hasattr(check, 'human_review') else gate.human_review:
                needs_human = True

        if needs_human and not all_required_passed:
            verdict = GateVerdict.PENDING_REVIEW
        elif not all_required_passed:
            verdict = GateVerdict.BLOCK
        else:
            verdict = GateVerdict.PASS

        result = GateResult(
            gate_id=gate_id,
            verdict=verdict,
            check_results=check_results,
            issues=issues,
            suggestions=suggestions,
            duration=time.time() - start_time,
            metadata={
                "complexity": complexity.value,
                "phase": gate.phase.value,
                "human_review_needed": needs_human,
            },
        )

        self._record_result(result)
        logger.info(f"Gate [{gate_id}] verdict: {verdict.value}, issues: {len(issues)}")
        return result

    def execute_pipeline(
        self,
        context: Dict[str, Any],
        phases: Optional[List[GatePhase]] = None,
    ) -> List[GateResult]:
        results = []
        phases = phases or list(GatePhase)

        for gate_id, gate in self._gates.items():
            if gate.phase in phases:
                result = self.execute_gate(gate_id, context)
                results.append(result)

                if result.verdict == GateVerdict.BLOCK:
                    logger.warning(f"Pipeline blocked at gate [{gate_id}]")
                    break

        return results

    def _record_result(self, result: GateResult):
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    def get_history(self, gate_id: Optional[str] = None) -> List[GateResult]:
        if gate_id:
            return [r for r in self._history if r.gate_id == gate_id]
        return self._history.copy()

    def get_gate_status(self, gate_id: str) -> Optional[GateVerdict]:
        for result in reversed(self._history):
            if result.gate_id == gate_id:
                return result.verdict
        return None

    # === Default Check Functions ===

    def _check_spec_exists(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec_path = context.get("spec_path", "")
            if spec_path:
                p = self.workspace_dir / spec_path
                if p.exists():
                    return True, f"Spec found at {spec_path}"
            spec_files = list(self.workspace_dir.glob("SPEC.md")) + list(self.workspace_dir.glob("spec.md"))
            if spec_files:
                return True, f"Spec found at {spec_files[0]}"
            return False, "No spec file found. No Spec, No Code."
        if isinstance(spec, SpecDocument):
            if spec.content.strip():
                return True, "Spec document provided"
        return False, "Spec is empty or missing"

    def _check_spec_sections(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec = self._load_spec(context)
        if spec is None:
            return False, "Cannot check sections: spec not found"

        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        has_sections, missing = spec.has_required_sections()
        if has_sections:
            return True, "All required sections present"
        return False, f"Missing required sections: {missing}"

    def _check_spec_not_empty(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec = self._load_spec(context)
        if spec is None:
            return False, "Spec not found"
        if isinstance(spec, str):
            return len(spec.strip()) > 50, "Spec content too short"
        if isinstance(spec, SpecDocument):
            return len(spec.content.strip()) > 50, "Spec content too short"
        return False, "Unknown spec format"

    def _check_spec_approved(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec = self._load_spec(context)
        if spec is None:
            return False, "Spec not found for approval check"
        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)
        if spec.is_approved():
            return True, "Spec is approved"
        return False, "Spec is not approved. Hard-Gate: spec must be approved before coding."

    def _check_spec_acceptance(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec = self._load_spec(context)
        if spec is None:
            return False, "Spec not found"
        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)
        if spec.acceptance_criteria:
            return True, f"Found {len(spec.acceptance_criteria)} acceptance criteria"
        return False, "No acceptance criteria defined in spec"

    def _check_spec_consistency(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        if spec is None:
            spec = self._load_spec(context)
        if spec is None:
            return True, "Cannot check consistency: spec not found (non-blocking)"
        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        contradictions = []
        must_patterns = re.findall(r'(?:MUST|SHALL|NEVER)\s+(.+)', spec.content, re.IGNORECASE)
        for i, p1 in enumerate(must_patterns):
            for p2 in must_patterns[i+1:]:
                if self._are_contradictory(p1, p2):
                    contradictions.append((p1, p2))

        if contradictions:
            return False, f"Found {len(contradictions)} potential contradictions"
        return True, "No obvious contradictions found"

    def _are_contradictory(self, s1: str, s2: str) -> bool:
        negation_words = {"not", "never", "no", "don't", "doesn't", "won't", "mustn't", "shall not"}
        s1_words = set(s1.lower().split())
        s2_words = set(s2.lower().split())
        s1_has_neg = bool(s1_words & negation_words)
        s2_has_neg = bool(s2_words & negation_words)
        if s1_has_neg != s2_has_neg:
            common = s1_words & s2_words - negation_words
            if len(common) >= 2:
                return True
        return False

    def _check_change_in_spec(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        change = context.get("change")
        spec = context.get("spec")

        if change is None:
            return True, "No change to validate (non-blocking)"

        if spec is None:
            spec = self._load_spec(context)

        if spec is None:
            return False, "No spec to validate change against. No Spec, No Code."

        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        if isinstance(change, CodeChange):
            file_path = change.file_path.lower()
            spec_content = spec.content.lower()

            path_parts = Path(file_path).parts
            for part in path_parts:
                if part in spec_content:
                    return True, f"File path component '{part}' found in spec"

            if change.description and any(
                word in spec_content
                for word in change.description.lower().split()
                if len(word) > 3
            ):
                return True, "Change description matches spec content"

            if change.affected_requirements:
                return True, f"Change explicitly linked to {len(change.affected_requirements)} requirements"

        return True, "Change validation passed (relaxed check)"

    def _check_no_spec_conflict(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        change = context.get("change")

        if spec is None or change is None:
            return True, "No conflict check needed"

        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        for constraint in spec.constraints:
            constraint_lower = constraint.lower()
            if "never" in constraint_lower or "must not" in constraint_lower:
                if isinstance(change, CodeChange):
                    new_lower = change.new_content.lower()
                    constraint_keywords = set(constraint_lower.split()) - {"never", "must", "not", "shall", "the", "a", "an", "be"}
                    if any(kw in new_lower for kw in constraint_keywords if len(kw) > 3):
                        return False, f"Change may violate constraint: {constraint}"

        return True, "No spec conflicts detected"

    def _check_safety_level(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        change = context.get("change")
        if change is None:
            return True, "No change to check safety level"

        if isinstance(change, CodeChange):
            file_path = change.file_path
            workflow_path = self.workspace_dir / "WORKFLOW.md"
            if workflow_path.exists():
                workflow_content = workflow_path.read_text(encoding="utf-8")
                red_patterns = re.findall(r'red:.*?files:.*?\[(.+?)\]', workflow_content, re.DOTALL)
                for pattern in red_patterns:
                    red_files = [f.strip().strip('"\'') for f in pattern.split(',')]
                    for red_file in red_files:
                        if red_file.replace('*', '') in file_path:
                            if not context.get("daemon_approved", False):
                                return False, f"Red-zone file requires Daemon approval: {file_path}"

        return True, "Safety level check passed"

    def _check_syntax(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        change = context.get("change")
        if change is None:
            return True, "No change to check syntax"

        if isinstance(change, CodeChange):
            if change.file_path.endswith('.py'):
                try:
                    compile(change.new_content, change.file_path, 'exec')
                    return True, "Python syntax valid"
                except SyntaxError as e:
                    return False, f"Syntax error at line {e.lineno}: {e.msg}"
            elif change.file_path.endswith(('.ts', '.tsx', '.js', '.jsx')):
                return True, "TypeScript/JavaScript syntax check deferred to tsc"

        return True, "Syntax check passed or deferred"

    def _check_spec_conformance(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        change = context.get("change")

        if spec is None or change is None:
            return True, "Conformance check skipped (no spec or change)"

        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        if spec.requirements:
            if isinstance(change, CodeChange):
                matched = 0
                for req in spec.requirements:
                    req_keywords = set(req.lower().split()) - {"must", "shall", "should", "the", "a", "an", "be", "to", "of"}
                    if any(kw in change.new_content.lower() for kw in req_keywords if len(kw) > 3):
                        matched += 1

                if spec.requirements and matched == 0:
                    return False, f"Code doesn't address any of {len(spec.requirements)} spec requirements"

        return True, "Spec conformance check passed"

    def _check_no_scope_creep(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        change = context.get("change")
        if change is None:
            return True, "No change to check scope"

        if isinstance(change, CodeChange):
            if change.diff_lines > 200:
                return False, f"Change too large ({change.diff_lines} lines). Split into smaller tasks."

        return True, "No scope creep detected"

    def _check_tests(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        return True, "Test check deferred to CI/CD pipeline"

    def _check_all_gates_passed(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        previous_gates = ["pre_spec", "post_spec", "pre_code", "post_code"]
        failed = []
        for gate_id in previous_gates:
            status = self.get_gate_status(gate_id)
            if status == GateVerdict.BLOCK:
                failed.append(gate_id)
            elif status is None:
                pass

        if failed:
            return False, f"Previous gates blocked: {failed}"
        return True, "All previous gates passed"

    def _check_reverse_sync(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        spec = context.get("spec")
        change = context.get("change")

        if spec is None or change is None:
            return True, "Reverse Sync check skipped"

        if isinstance(spec, str):
            spec = SpecDocument(path="inline", content=spec)

        if isinstance(change, CodeChange):
            for constraint in spec.constraints:
                constraint_lower = constraint.lower()
                if any(kw in constraint_lower for kw in ["never", "must not", "shall not", "forbidden"]):
                    new_lower = change.new_content.lower()
                    keywords = set(constraint_lower.split()) - {"never", "must", "not", "shall", "the", "a", "an", "be"}
                    for kw in keywords:
                        if len(kw) > 3 and kw in new_lower:
                            return False, f"Reverse Sync violation: code conflicts with spec constraint '{constraint}'. Fix spec first, then code."

        return True, "Reverse Sync: Spec-Code consistency verified"

    def _check_sensitive_review(self, context: Dict[str, Any]) -> Tuple[bool, str]:
        change = context.get("change")
        if change is None:
            return True, "No change to review"

        if isinstance(change, CodeChange) and change.sensitive:
            if context.get("human_approved", False):
                return True, "Sensitive change approved by human reviewer"
            return False, "Sensitive change requires human review (Hard-Gate)"

        return True, "No sensitive changes detected"

    def _load_spec(self, context: Dict[str, Any]) -> Optional[SpecDocument]:
        spec_path = context.get("spec_path", "")
        if spec_path:
            p = self.workspace_dir / spec_path
            if p.exists():
                return SpecDocument.from_file(str(p))

        for name in ["SPEC.md", "spec.md"]:
            p = self.workspace_dir / name
            if p.exists():
                return SpecDocument.from_file(str(p))

        return None


class ReverseSyncEngine:
    """Spec-Code bidirectional verification engine.

    Implements the Reverse Sync principle from Alibaba's SDD-RIPER:
    - When code and spec conflict, spec is truth
    - Bug found: fix spec first, then fix code
    - Triangulation: Spec vs Code vs ExecutionLog cross-validation
    """

    def __init__(self, workspace_dir: Optional[Path] = None):
        self.workspace_dir = workspace_dir or Path.cwd()
        self._violations: List[Dict[str, Any]] = []

    def check_spec_code_consistency(
        self,
        spec: SpecDocument,
        code_changes: List[CodeChange],
    ) -> List[Dict[str, Any]]:
        violations = []

        for change in code_changes:
            for constraint in spec.constraints:
                constraint_lower = constraint.lower()
                if any(kw in constraint_lower for kw in ["never", "must not", "shall not", "forbidden"]):
                    new_lower = change.new_content.lower()
                    keywords = set(constraint_lower.split()) - {"never", "must", "not", "shall", "the", "a", "an", "be"}
                    for kw in keywords:
                        if len(kw) > 3 and kw in new_lower:
                            violation = {
                                "type": "spec_code_conflict",
                                "constraint": constraint,
                                "file": change.file_path,
                                "keyword": kw,
                                "resolution": "fix_spec_first",
                                "message": f"Code in {change.file_path} may violate spec constraint: '{constraint}'. Reverse Sync: fix spec first, then code.",
                            }
                            violations.append(violation)
                            self._violations.append(violation)

            for req in spec.requirements:
                req_keywords = set(req.lower().split()) - {"must", "shall", "should", "the", "a", "an", "be", "to", "of"}
                significant_keywords = [kw for kw in req_keywords if len(kw) > 3]
                if significant_keywords:
                    new_lower = change.new_content.lower()
                    if not any(kw in new_lower for kw in significant_keywords):
                        if change.affected_requirements:
                            violation = {
                                "type": "requirement_not_addressed",
                                "requirement": req,
                                "file": change.file_path,
                                "resolution": "add_to_spec_or_code",
                                "message": f"Requirement '{req}' not addressed in {change.file_path}",
                            }
                            violations.append(violation)

        return violations

    def triangulate(
        self,
        spec: SpecDocument,
        code_changes: List[CodeChange],
        execution_log: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        spec_code_violations = self.check_spec_code_consistency(spec, code_changes)

        spec_exec_violations = []
        if execution_log:
            for entry in execution_log:
                if entry.get("status") == "error":
                    error_msg = entry.get("message", "").lower()
                    for req in spec.requirements:
                        req_keywords = set(req.lower().split()) - {"must", "shall", "should", "the", "a", "an", "be", "to", "of"}
                        if any(kw in error_msg for kw in req_keywords if len(kw) > 3):
                            spec_exec_violations.append({
                                "type": "spec_exec_mismatch",
                                "requirement": req,
                                "error": entry.get("message"),
                                "resolution": "check_spec_accuracy",
                            })

        code_exec_violations = []
        if execution_log:
            for entry in execution_log:
                if entry.get("status") == "error":
                    for change in code_changes:
                        if change.file_path in entry.get("file", ""):
                            code_exec_violations.append({
                                "type": "code_exec_mismatch",
                                "file": change.file_path,
                                "error": entry.get("message"),
                                "resolution": "fix_code_to_match_spec",
                            })

        all_violations = spec_code_violations + spec_exec_violations + code_exec_violations

        return {
            "consistent": len(all_violations) == 0,
            "total_violations": len(all_violations),
            "spec_code_violations": len(spec_code_violations),
            "spec_exec_violations": len(spec_exec_violations),
            "code_exec_violations": len(code_exec_violations),
            "violations": all_violations,
            "recommendation": self._generate_recommendation(all_violations),
        }

    def _generate_recommendation(self, violations: List[Dict[str, Any]]) -> str:
        if not violations:
            return "All checks passed. Spec, Code, and Execution are consistent."

        resolution_counts = {}
        for v in violations:
            resolution = v.get("resolution", "unknown")
            resolution_counts[resolution] = resolution_counts.get(resolution, 0) + 1

        parts = []
        if resolution_counts.get("fix_spec_first", 0) > 0:
            parts.append(f"Fix spec first for {resolution_counts['fix_spec_first']} conflict(s) (Reverse Sync)")
        if resolution_counts.get("add_to_spec_or_code", 0) > 0:
            parts.append(f"Address {resolution_counts['add_to_spec_or_code']} unmet requirement(s)")
        if resolution_counts.get("fix_code_to_match_spec", 0) > 0:
            parts.append(f"Fix code for {resolution_counts['fix_code_to_match_spec']} execution error(s)")
        if resolution_counts.get("check_spec_accuracy", 0) > 0:
            parts.append(f"Verify spec accuracy for {resolution_counts['check_spec_accuracy']} mismatch(es)")

        return "; ".join(parts) if parts else "Review violations and resolve."


class ProgressiveSpecFlow:
    """Progressive Spec flow adapted to change complexity.

    Inspired by Alibaba's insight: 70% of changes are small (≤5 person-days).
    Forcing full spec flow on every change adds accidental complexity.

    Complexity → Flow Depth mapping:
    - TRIVIAL: direct code (no spec needed)
    - SIMPLE: brief spec + code (auto gate)
    - MEDIUM: research → spec → tasks → code → review (auto gate)
    - COMPLEX: full flow + hard-gate human review
    """

    FLOW_STEPS = {
        ChangeComplexity.TRIVIAL: ["direct_code"],
        ChangeComplexity.SIMPLE: ["brief_spec", "code", "auto_review"],
        ChangeComplexity.MEDIUM: ["research", "spec", "tasks", "code", "auto_review"],
        ChangeComplexity.COMPLEX: ["research", "spec", "tasks", "code", "hard_gate_review"],
    }

    GATE_DEPTH = {
        ChangeComplexity.TRIVIAL: [],
        ChangeComplexity.SIMPLE: ["pre_code"],
        ChangeComplexity.MEDIUM: ["pre_spec", "pre_code", "post_code"],
        ChangeComplexity.COMPLEX: ["pre_spec", "post_spec", "pre_code", "post_code", "pre_commit"],
    }

    def __init__(self, gate_executor: Optional[HardGateExecutor] = None):
        self.gate_executor = gate_executor or HardGateExecutor()

    def classify_complexity(self, change: CodeChange) -> ChangeComplexity:
        return change.complexity

    def get_flow_for_complexity(self, complexity: ChangeComplexity) -> List[str]:
        return self.FLOW_STEPS.get(complexity, self.FLOW_STEPS[ChangeComplexity.MEDIUM])

    def get_gates_for_complexity(self, complexity: ChangeComplexity) -> List[str]:
        return self.GATE_DEPTH.get(complexity, self.GATE_DEPTH[ChangeComplexity.MEDIUM])

    def execute_progressive_flow(
        self,
        change: CodeChange,
        spec: Optional[SpecDocument] = None,
        execution_log: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        complexity = self.classify_complexity(change)
        flow_steps = self.get_flow_for_complexity(complexity)
        gates = self.get_gates_for_complexity(complexity)

        context = {
            "change": change,
            "spec": spec,
            "complexity": complexity,
            "execution_log": execution_log or [],
        }

        if spec is None and complexity != ChangeComplexity.TRIVIAL:
            loaded_spec = self.gate_executor._load_spec(context)
            context["spec"] = loaded_spec

        gate_results = []
        blocked = False

        for gate_id in gates:
            result = self.gate_executor.execute_gate(gate_id, context)
            gate_results.append(result)

            if result.verdict == GateVerdict.BLOCK:
                blocked = True
                break

            if result.verdict == GateVerdict.PENDING_REVIEW:
                break

        reverse_sync_result = None
        if spec and not blocked:
            sync_engine = ReverseSyncEngine(self.gate_executor.workspace_dir)
            reverse_sync_result = sync_engine.triangulate(
                spec, [change], execution_log
            )

        return {
            "complexity": complexity.value,
            "flow_steps": flow_steps,
            "gates_executed": [r.gate_id for r in gate_results],
            "gate_results": [r.to_dict() for r in gate_results],
            "blocked": blocked,
            "block_reason": gate_results[-1].issues if blocked and gate_results else [],
            "reverse_sync": reverse_sync_result,
            "can_proceed": not blocked,
        }
