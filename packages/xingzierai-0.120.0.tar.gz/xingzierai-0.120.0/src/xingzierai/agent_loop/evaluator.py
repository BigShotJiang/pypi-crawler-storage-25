# -*- coding: utf-8 -*-
"""SkepticEvaluator - Independent evaluation layer.

Core insight from Anthropic's long-task research:
- Agent self-evaluation has 92% error rate on subjective tasks
- Generator and Evaluator must be COMPLETELY INDEPENDENT
- Evaluator trained in "skeptic mode" improves accuracy by 40%
- External feedback loops > model single-shot output capability

Effect = Model_Capability × Harness_Design_Quality (non-linear)
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class EvaluationVerdict(str, Enum):
    """Verdict from the evaluator."""
    APPROVE = "approve"
    REJECT = "reject"
    NEEDS_REVISION = "needs_revision"
    TIMEOUT = "timeout"
    INCONCLUSIVE = "inconclusive"


@dataclass
class EvaluationCriteria:
    """Criteria for evaluation."""
    name: str
    description: str
    weight: float = 1.0
    required: bool = True
    validation_fn: Optional[Callable] = None


@dataclass
class EvaluationResult:
    """Result from the skeptic evaluator."""
    verdict: EvaluationVerdict
    score: float = 0.0
    confidence: float = 0.0
    criteria_results: Dict[str, bool] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    execution_time: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.verdict.value,
            "score": self.score,
            "confidence": self.confidence,
            "criteria_results": self.criteria_results,
            "issues": self.issues,
            "suggestions": self.suggestions,
            "execution_time": self.execution_time,
            "metadata": self.metadata,
        }


class SkepticEvaluator:
    """Independent evaluator operating in skeptic mode.

    Key design principles from Anthropic research:
    1. COMPLETELY INDEPENDENT from the generator
    2. Default stance is REJECT (skeptic mode)
    3. Requires positive evidence to approve
    4. Detects Context Anxiety (premature completion)
    5. Detects hallucination and overconfidence

    Usage:
        evaluator = SkepticEvaluator()

        result = await evaluator.evaluate(
            task="Write a function to sort a list",
            output="def sort_list(lst): return sorted(lst)",
            criteria=[
                EvaluationCriteria("correctness", "Does it work?"),
                EvaluationCriteria("completeness", "Is it complete?"),
            ],
        )

        if result.verdict == EvaluationVerdict.APPROVE:
            # Accept the output
        else:
            # Request revision
    """

    def __init__(
        self,
        model: Optional[Any] = None,
        skepticism_level: float = 0.7,
        max_revisions: int = 3,
        context_anxiety_threshold: float = 0.6,
    ):
        """Initialize skeptic evaluator.

        Args:
            model: LLM model for evaluation (must be DIFFERENT from generator)
            skepticism_level: 0.0-1.0, higher = more skeptical
            max_revisions: Maximum revision attempts before forced completion
            context_anxiety_threshold: Threshold for detecting premature completion
        """
        self.model = model
        self.skepticism_level = skepticism_level
        self.max_revisions = max_revisions
        self.context_anxiety_threshold = context_anxiety_threshold
        self._evaluation_count = 0
        self._rejection_count = 0

    async def evaluate(
        self,
        task: str,
        output: Any,
        criteria: Optional[List[EvaluationCriteria]] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> EvaluationResult:
        """Evaluate generator output with skeptic stance.

        Args:
            task: Original task description
            output: Generator's output to evaluate
            criteria: Evaluation criteria
            context: Additional context (token usage, iteration count, etc.)

        Returns:
            EvaluationResult with verdict
        """
        start_time = time.time()
        self._evaluation_count += 1

        if criteria is None:
            criteria = self._default_criteria(task)

        context = context or {}

        criteria_results = {}
        issues = []
        suggestions = []
        total_score = 0.0
        total_weight = 0.0

        for criterion in criteria:
            is_met, detail = await self._evaluate_criterion(
                task, output, criterion, context
            )
            criteria_results[criterion.name] = is_met

            if is_met:
                total_score += criterion.weight
            else:
                if criterion.required:
                    issues.append(f"[{criterion.name}] {detail}")
                    if self.skepticism_level > 0.5:
                        suggestions.append(
                            f"Revise to address: {criterion.description}"
                        )

            total_weight += criterion.weight

        score = total_score / total_weight if total_weight > 0 else 0.0

        # Apply skepticism bias - raise the bar for approval
        adjusted_score = score * (1.0 - self.skepticism_level * 0.3)

        # Detect Context Anxiety
        anxiety_detected = self._detect_context_anxiety(task, output, context)
        if anxiety_detected:
            issues.append("Context Anxiety detected: output may be prematurely truncated")
            adjusted_score *= 0.5

        # Determine verdict
        if adjusted_score >= 0.8:
            verdict = EvaluationVerdict.APPROVE
        elif adjusted_score >= 0.5:
            verdict = EvaluationVerdict.NEEDS_REVISION
        else:
            verdict = EvaluationVerdict.REJECT
            self._rejection_count += 1

        confidence = self._calculate_confidence(criteria_results, context)

        return EvaluationResult(
            verdict=verdict,
            score=adjusted_score,
            confidence=confidence,
            criteria_results=criteria_results,
            issues=issues,
            suggestions=suggestions,
            execution_time=time.time() - start_time,
            metadata={
                "raw_score": score,
                "skepticism_level": self.skepticism_level,
                "anxiety_detected": anxiety_detected,
                "evaluation_number": self._evaluation_count,
            },
        )

    async def _evaluate_criterion(
        self,
        task: str,
        output: Any,
        criterion: EvaluationCriteria,
        context: Dict[str, Any],
    ) -> tuple[bool, str]:
        """Evaluate a single criterion.

        Args:
            task: Original task
            output: Generator output
            criterion: Evaluation criterion
            context: Additional context

        Returns:
            Tuple of (is_met, detail)
        """
        if criterion.validation_fn:
            try:
                result = criterion.validation_fn(output, task, context)
                if isinstance(result, tuple):
                    return result
                return bool(result), "Validation function result"
            except Exception as e:
                return False, f"Validation error: {e}"

        if not self.model:
            return self._heuristic_evaluate(task, output, criterion)

        return await self._llm_evaluate(task, output, criterion)

    def _heuristic_evaluate(
        self,
        task: str,
        output: Any,
        criterion: EvaluationCriteria,
    ) -> tuple[bool, str]:
        """Heuristic-based evaluation without LLM.

        Args:
            task: Original task
            output: Generator output
            criterion: Evaluation criterion

        Returns:
            Tuple of (is_met, detail)
        """
        output_str = str(output) if output else ""

        if criterion.name == "completeness":
            if len(output_str.strip()) < 10:
                return False, "Output is too short to be complete"
            if output_str.endswith(("...", "etc.", "and so on")):
                return False, "Output appears truncated"
            return True, "Output has reasonable length"

        if criterion.name == "relevance":
            task_words = set(task.lower().split())
            output_words = set(output_str.lower().split())
            overlap = task_words & output_words
            if len(overlap) < len(task_words) * 0.1:
                return False, "Output doesn't address the task keywords"
            return True, "Output addresses task keywords"

        if criterion.name == "correctness":
            error_indicators = ["error", "exception", "failed", "traceback"]
            if any(ind in output_str.lower() for ind in error_indicators):
                return False, "Output contains error indicators"
            return True, "No obvious error indicators"

        return True, "No validation performed"

    async def _llm_evaluate(
        self,
        task: str,
        output: Any,
        criterion: EvaluationCriteria,
    ) -> tuple[bool, str]:
        """LLM-based evaluation in skeptic mode.

        Args:
            task: Original task
            output: Generator output
            criterion: Evaluation criterion

        Returns:
            Tuple of (is_met, detail)
        """
        prompt = (
            f"You are a SKEPTIC evaluator. Default stance: REJECT.\n"
            f"Only approve if you have POSITIVE evidence.\n\n"
            f"Task: {task}\n"
            f"Output to evaluate: {output}\n"
            f"Criterion: {criterion.name} - {criterion.description}\n\n"
            f"Is this criterion met? Answer YES or NO with reason."
        )

        try:
            if hasattr(self.model, 'ainvoke'):
                response = await self.model.ainvoke(prompt)
            elif hasattr(self.model, 'call'):
                response = self.model.call(prompt)
            else:
                return self._heuristic_evaluate(task, output, criterion)

            response_str = str(response).lower()
            is_met = "yes" in response_str and "no" not in response_str[:10]
            detail = str(response)[:200]
            return is_met, detail

        except Exception as e:
            logger.warning(f"LLM evaluation failed: {e}")
            return self._heuristic_evaluate(task, output, criterion)

    def _detect_context_anxiety(
        self,
        task: str,
        output: Any,
        context: Dict[str, Any],
    ) -> bool:
        """Detect Context Anxiety - premature completion near context limit.

        Key insight from Anthropic: models near context limit tend to
        falsely claim completion. This detector identifies such cases.

        Args:
            task: Original task
            output: Generator output
            context: Context with token usage info

        Returns:
            True if context anxiety is detected
        """
        output_str = str(output) if output else ""

        premature_indicators = [
            "task completed",
            "all done",
            "finished",
            "that's all",
            "nothing more to do",
        ]

        output_lower = output_str.lower()
        has_premature = any(ind in output_lower for ind in premature_indicators)

        token_usage_ratio = context.get("token_usage_ratio", 0)
        iteration_ratio = context.get("iteration_ratio", 0)

        if has_premature and (token_usage_ratio > self.context_anxiety_threshold or
                              iteration_ratio > 0.8):
            return True

        if token_usage_ratio > 0.9 and len(output_str) < 100:
            return True

        return False

    def _calculate_confidence(
        self,
        criteria_results: Dict[str, bool],
        context: Dict[str, Any],
    ) -> float:
        """Calculate confidence level of the evaluation.

        Args:
            criteria_results: Results for each criterion
            context: Additional context

        Returns:
            Confidence level 0.0-1.0
        """
        if not criteria_results:
            return 0.0

        base_confidence = sum(criteria_results.values()) / len(criteria_results)

        # Lower confidence if we're near context limits
        token_ratio = context.get("token_usage_ratio", 0)
        if token_ratio > 0.8:
            base_confidence *= 0.7

        # Lower confidence if many iterations
        iteration_ratio = context.get("iteration_ratio", 0)
        if iteration_ratio > 0.8:
            base_confidence *= 0.8

        return min(base_confidence, 1.0)

    def _default_criteria(self, task: str) -> List[EvaluationCriteria]:
        """Generate default evaluation criteria based on task.

        Args:
            task: Task description

        Returns:
            List of evaluation criteria
        """
        return [
            EvaluationCriteria(
                name="completeness",
                description="Is the output complete and not truncated?",
                weight=1.0,
                required=True,
            ),
            EvaluationCriteria(
                name="relevance",
                description="Does the output address the original task?",
                weight=0.8,
                required=True,
            ),
            EvaluationCriteria(
                name="correctness",
                description="Is the output factually correct?",
                weight=1.0,
                required=True,
            ),
        ]

    @property
    def rejection_rate(self) -> float:
        """Get the current rejection rate."""
        if self._evaluation_count == 0:
            return 0.0
        return self._rejection_count / self._evaluation_count
