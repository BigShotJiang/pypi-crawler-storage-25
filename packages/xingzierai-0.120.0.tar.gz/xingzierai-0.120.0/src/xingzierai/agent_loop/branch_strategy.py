# -*- coding: utf-8 -*-
"""Smart Branch Strategy - Intelligent branch selection and exploration.

This module provides intelligent branch selection strategies:
1. Score-based selection (evaluation scores, error rates)
2. Heuristic-based exploration (try different approaches)
3. Adaptive branching (based on task complexity)
4. Diversity-aware branching (ensure exploration diversity)
"""

import copy
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

from .rollout import Action, Observation, RolloutNode, RolloutTree, StateSnapshot, NodeStatus

logger = logging.getLogger(__name__)


class BranchStrategy(str, Enum):
    """Branch selection strategy types."""
    BEST_SCORE = "best_score"           # Select branch with highest score
    MOST_DIVERSE = "most_diverse"      # Select most different from tried paths
    ERROR_RECOVERY = "error_recovery"   # Select branch that addresses specific error
    SIMPLIFY = "simplify"              # Select simplest approach
    DECOMPOSE = "decompose"            # Break task into smaller steps
    PARALLEL_EXPLORE = "parallel"      # Explore multiple branches simultaneously


@dataclass
class BranchScore:
    """Score evaluation for a branch."""
    node_id: str
    base_score: float = 0.0
    error_recovery_score: float = 0.0
    diversity_score: float = 0.0
    simplicity_score: float = 0.0
    total_score: float = 0.0
    reason: str = ""

    def compute_total(self, weights: Dict[str, float]) -> float:
        """Compute weighted total score."""
        self.total_score = (
            weights.get("base", 1.0) * self.base_score +
            weights.get("error_recovery", 1.5) * self.error_recovery_score +
            weights.get("diversity", 0.8) * self.diversity_score +
            weights.get("simplicity", 0.5) * self.simplicity_score
        )
        return self.total_score


@dataclass
class BranchingPolicy:
    """Policy for controlling branch creation and selection.

    Attributes:
        max_branches_per_node: Maximum branches from a single node
        max_total_branches: Maximum total branches in tree
        branch_on_error: Automatically branch on tool/evaluation errors
        min_error_count_for_branch: Minimum errors before auto-branching
        diversity_weight: Weight for diversity in branch selection
        simplification_threshold: Score below which to simplify approach
    """
    max_branches_per_node: int = 3
    max_total_branches: int = 20
    branch_on_error: bool = True
    min_error_count_for_branch: int = 1
    diversity_weight: float = 0.8
    simplification_threshold: float = 0.3
    error_categories: Dict[str, str] = field(default_factory=lambda: {
        "file_not_found": "use_alternative_path",
        "permission_denied": "change_permissions",
        "syntax_error": "fix_code",
        "timeout": "simplify_task",
        "context_overflow": "compact_memory",
        "unknown_error": "retry_different",
    })

    @classmethod
    def default(cls) -> "BranchingPolicy":
        """Create default branching policy."""
        return cls()

    @classmethod
    def aggressive(cls) -> "BranchingPolicy":
        """Create aggressive branching policy for complex tasks."""
        return cls(
            max_branches_per_node=5,
            max_total_branches=50,
            branch_on_error=True,
            min_error_count_for_branch=1,
            diversity_weight=1.0,
        )

    @classmethod
    def conservative(cls) -> "BranchingPolicy":
        """Create conservative branching policy for simple tasks."""
        return cls(
            max_branches_per_node=2,
            max_total_branches=10,
            branch_on_error=True,
            min_error_count_for_branch=2,
            diversity_weight=0.5,
        )


class BranchRegistry:
    """Registry of available branch strategies.

    Maintains a collection of branch strategies with metadata
    for intelligent selection based on context.
    """

    def __init__(self):
        """Initialize branch registry."""
        self._strategies: Dict[str, Dict[str, Any]] = {
            "retry_different_approach": {
                "strategy": BranchStrategy.BEST_SCORE,
                "description": "Try a completely different approach",
                "keywords": ["failed", "error", "stuck"],
                "weight": 1.0,
            },
            "use_alternative_tool": {
                "strategy": BranchStrategy.ERROR_RECOVERY,
                "description": "Use a different tool to achieve same goal",
                "keywords": ["tool_failed", "permission"],
                "weight": 1.2,
            },
            "simplify_task": {
                "strategy": BranchStrategy.SIMPLIFY,
                "description": "Break task into smaller steps",
                "keywords": ["complex", "timeout", "context_overflow"],
                "weight": 1.5,
            },
            "decompose_step": {
                "strategy": BranchStrategy.DECOMPOSE,
                "description": "Decompose into atomic steps",
                "keywords": ["multi_step", "complex"],
                "weight": 1.3,
            },
            "revert_and_retry": {
                "strategy": BranchStrategy.BEST_SCORE,
                "description": "Revert to previous state and retry",
                "keywords": ["failed", "wrong_approach"],
                "weight": 0.8,
            },
            "parallel_explore": {
                "strategy": BranchStrategy.PARALLEL_EXPLORE,
                "description": "Explore multiple approaches simultaneously",
                "keywords": ["uncertain", "multiple_options"],
                "weight": 1.1,
            },
        }

    def get_strategy(self, name: str) -> Optional[Dict[str, Any]]:
        """Get strategy by name."""
        return self._strategies.get(name)

    def find_matching_strategies(self, error: str) -> List[Dict[str, Any]]:
        """Find strategies matching an error message.

        Args:
            error: Error message to match

        Returns:
            List of matching strategies with scores
        """
        matches = []
        error_lower = error.lower()

        for name, strategy in self._strategies.items():
            score = 0.0
            for keyword in strategy.get("keywords", []):
                if keyword.lower() in error_lower:
                    score += 1.0

            if score > 0:
                strategy_copy = copy.deepcopy(strategy)
                strategy_copy["name"] = name
                strategy_copy["match_score"] = score
                matches.append(strategy_copy)

        matches.sort(key=lambda x: x["match_score"], reverse=True)
        return matches

    def list_strategies(self) -> List[str]:
        """List all available strategy names."""
        return list(self._strategies.keys())


class SmartBranchSelector:
    """Intelligent branch selection based on context and history.

    This class implements intelligent branch selection:
    1. Score each potential branch based on multiple factors
    2. Consider error patterns and recovery strategies
    3. Maintain diversity in exploration
    4. Adapt strategy based on task complexity
    """

    def __init__(
        self,
        policy: Optional[BranchingPolicy] = None,
        registry: Optional[BranchRegistry] = None,
    ):
        """Initialize smart branch selector.

        Args:
            policy: Branching policy to use
            registry: Branch registry for strategies
        """
        self.policy = policy or BranchingPolicy.default()
        self.registry = registry or BranchRegistry()
        self._branch_history: List[str] = []
        self._error_patterns: Dict[str, int] = {}
        self._approach_used: Set[str] = set()

    def select_best_branch(
        self,
        tree: RolloutTree,
        current_node_id: str,
        available_branches: List[RolloutNode],
    ) -> Optional[RolloutNode]:
        """Select the best branch from available options.

        Args:
            tree: The rollout tree
            current_node_id: Current node ID
            available_branches: List of candidate branch nodes

        Returns:
            The best branch node, or None if no suitable option
        """
        if not available_branches:
            return None

        if len(available_branches) == 1:
            return available_branches[0]

        scores = []
        for branch in available_branches:
            score = self._score_branch(tree, branch)
            scores.append((branch, score))

        scores.sort(key=lambda x: x[1].total_score, reverse=True)

        logger.debug(
            f"Branch scores for {current_node_id}: "
            + ", ".join([f"{s.id[:8]}:{sc.total_score:.2f}" for s, sc in scores])
        )

        return scores[0][0] if scores else None

    def _score_branch(
        self,
        tree: RolloutTree,
        branch: RolloutNode,
    ) -> BranchScore:
        """Score a single branch.

        Args:
            tree: The rollout tree
            branch: Branch node to score

        Returns:
            BranchScore with computed scores
        """
        score = BranchScore(node_id=branch.id)

        if branch.observation and not branch.observation.success:
            score.error_recovery_score = self._compute_error_recovery_score(branch)
        else:
            score.base_score = 0.5

        score.diversity_score = self._compute_diversity_score(branch)
        score.simplicity_score = self._compute_simplicity_score(branch)

        weights = {
            "base": 1.0,
            "error_recovery": 1.5,
            "diversity": self.policy.diversity_weight,
            "simplicity": 0.5,
        }

        score.compute_total(weights)
        score.reason = self._generate_score_reason(score)

        return score

    def _compute_error_recovery_score(self, branch: RolloutNode) -> float:
        """Compute score based on error recovery potential.

        Args:
            branch: Branch node with error observation

        Returns:
            Error recovery score (0.0 - 2.0)
        """
        if not branch.observation or not branch.observation.error_message:
            return 0.0

        error = branch.observation.error_message

        matching_strategies = self.registry.find_matching_strategies(error)
        if not matching_strategies:
            return 0.5

        best_match = matching_strategies[0]
        match_score = min(best_match["match_score"] * 0.5, 1.5)

        self._error_patterns[error] = self._error_patterns.get(error, 0) + 1

        return match_score

    def _compute_diversity_score(self, branch: RolloutNode) -> float:
        """Compute score based on diversity from tried approaches.

        Args:
            branch: Branch node to evaluate

        Returns:
            Diversity score (0.0 - 1.0)
        """
        if branch.branch_name in self._approach_used:
            return 0.0

        if not self._approach_used:
            return 1.0

        same_type_count = sum(
            1 for used in self._approach_used
            if used.startswith(branch.branch_name.split("_")[0])
        )

        diversity = 1.0 / (1.0 + same_type_count * 0.3)

        return min(diversity, 1.0)

    def _compute_simplicity_score(self, branch: RolloutNode) -> float:
        """Compute score based on task simplicity.

        Simpler approaches (fewer tools, shorter paths) get higher scores.

        Args:
            branch: Branch node to evaluate

        Returns:
            Simplicity score (0.0 - 1.0)
        """
        if branch.action and branch.action.action_type == "tool_call":
            tool_name = branch.action.tool_name or ""
            if "write" in tool_name or "create" in tool_name:
                return 0.8
            elif "read" in tool_name or "list" in tool_name:
                return 0.9
            elif "edit" in tool_name or "modify" in tool_name:
                return 0.7
            else:
                return 0.5

        return 0.5

    def _generate_score_reason(self, score: BranchScore) -> str:
        """Generate human-readable reason for the score.

        Args:
            score: BranchScore to explain

        Returns:
            Human-readable reason string
        """
        reasons = []

        if score.error_recovery_score > 0.5:
            reasons.append(f"error_recovery={score.error_recovery_score:.2f}")
        if score.diversity_score > 0.7:
            reasons.append(f"diverse={score.diversity_score:.2f}")
        if score.simplicity_score > 0.6:
            reasons.append(f"simple={score.simplicity_score:.2f}")

        return "; ".join(reasons) if reasons else f"base={score.base_score:.2f}"

    def should_create_branch(
        self,
        tree: RolloutTree,
        node_id: str,
        error: Optional[str] = None,
    ) -> bool:
        """Determine if a new branch should be created.

        Args:
            tree: The rollout tree
            node_id: Node that might need branching
            error: Optional error message that triggered this check

        Returns:
            True if branching is recommended
        """
        stats = tree.get_statistics()

        if stats.get("branch_count", 0) >= self.policy.max_total_branches:
            return False

        parent = tree.nodes.get(node_id)
        if parent and len(parent.children_ids) >= self.policy.max_branches_per_node:
            return False

        if error and self.policy.branch_on_error:
            self._error_patterns[error] = self._error_patterns.get(error, 0) + 1
            return self._error_patterns[error] >= self.policy.min_error_count_for_branch

        return False

    def suggest_branch_type(
        self,
        error: Optional[str] = None,
        task_complexity: float = 0.5,
    ) -> str:
        """Suggest the best branch type for the situation.

        Args:
            error: Optional error message
            task_complexity: Estimated task complexity (0.0 - 1.0)

        Returns:
            Suggested branch type name
        """
        if error:
            strategies = self.registry.find_matching_strategies(error)
            if strategies:
                return strategies[0]["name"]

        if task_complexity > 0.7:
            return "decompose_step"
        elif task_complexity > 0.4:
            return "simplify_task"
        else:
            return "retry_different_approach"

    def record_branch_used(self, branch_name: str) -> None:
        """Record that a branch type was used.

        Args:
            branch_name: Name of the branch type
        """
        self._approach_used.add(branch_name)

    def reset(self) -> None:
        """Reset selector state."""
        self._branch_history.clear()
        self._error_patterns.clear()
        self._approach_used.clear()


class AdaptiveBranchingController:
    """Adaptive controller that adjusts branching based on success/failure patterns.

    Monitors the success rate of different branch types and
    adaptively adjusts their weights to maximize success.
    """

    def __init__(
        self,
        selector: Optional[SmartBranchSelector] = None,
        learning_rate: float = 0.1,
    ):
        """Initialize adaptive controller.

        Args:
            selector: SmartBranchSelector to adapt
            learning_rate: How fast to adjust weights (0.0 - 1.0)
        """
        self.selector = selector or SmartBranchSelector()
        self.learning_rate = learning_rate
        self._branch_success_rates: Dict[str, List[bool]] = {}
        self._confidence_scores: Dict[str, float] = {}

    def record_branch_outcome(
        self,
        branch_name: str,
        success: bool,
        final_node_id: str,
    ) -> None:
        """Record the outcome of a branch.

        Args:
            branch_name: Type of branch used
            success: Whether the branch led to success
            final_node_id: Final node reached
        """
        if branch_name not in self._branch_success_rates:
            self._branch_success_rates[branch_name] = []

        self._branch_success_rates[branch_name].append(success)

        if len(self._branch_success_rates[branch_name]) > 10:
            self._branch_success_rates[branch_name] = self._branch_success_rates[branch_name][-10:]

        self._update_confidence(branch_name)

        logger.debug(
            f"Branch '{branch_name}' outcome: {'success' if success else 'failure'}, "
            f"confidence={self._confidence_scores.get(branch_name, 0.0):.2f}"
        )

    def _update_confidence(self, branch_name: str) -> None:
        """Update confidence score for a branch type.

        Args:
            branch_name: Branch type to update
        """
        outcomes = self._branch_success_rates.get(branch_name, [])
        if not outcomes:
            return

        success_rate = sum(outcomes) / len(outcomes)
        current_confidence = self._confidence_scores.get(branch_name, 0.5)

        new_confidence = (
            current_confidence * (1 - self.learning_rate) +
            success_rate * self.learning_rate
        )

        self._confidence_scores[branch_name] = new_confidence

    def get_confidence(self, branch_name: str) -> float:
        """Get confidence score for a branch type.

        Args:
            branch_name: Branch type to query

        Returns:
            Confidence score (0.0 - 1.0)
        """
        return self._confidence_scores.get(branch_name, 0.5)

    def get_best_branch_type(self) -> Optional[str]:
        """Get the branch type with highest confidence.

        Returns:
            Best branch type name, or None if no data
        """
        if not self._confidence_scores:
            return None

        return max(
            self._confidence_scores.items(),
            key=lambda x: x[1]
        )[0]

    def suggest_next_branch(
        self,
        error: Optional[str] = None,
        task_complexity: float = 0.5,
    ) -> str:
        """Suggest the next best branch type based on learned patterns.

        Args:
            error: Optional error message
            task_complexity: Estimated task complexity

        Returns:
            Suggested branch type
        """
        if error:
            strategies = self.selector.registry.find_matching_strategies(error)
            if strategies:
                strategy_name = strategies[0]["name"]
                confidence = self.get_confidence(strategy_name)

                if confidence >= 0.6:
                    return strategy_name

        best_confident = self.get_best_branch_type()
        if best_confident and self.get_confidence(best_confident) >= 0.6:
            return best_confident

        return self.selector.suggest_branch_type(error, task_complexity)

    def get_statistics(self) -> Dict[str, Any]:
        """Get controller statistics.

        Returns:
            Dict with controller stats
        """
        return {
            "tracked_branch_types": len(self._branch_success_rates),
            "confidence_scores": dict(self._confidence_scores),
            "success_rates": {
                name: sum(outcomes) / len(outcomes) if outcomes else 0.0
                for name, outcomes in self._branch_success_rates.items()
            },
        }
