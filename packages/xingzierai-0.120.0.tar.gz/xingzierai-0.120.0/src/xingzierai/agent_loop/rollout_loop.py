# -*- coding: utf-8 -*-
"""RolloutAgentLoop - AgentLoop with tree-structured reasoning and backtracking.

This module provides RolloutAgentLoop that extends AgentLoop with:
1. Tree-structured reasoning path tracking
2. State snapshot capture and restoration
3. Branch exploration (try alternative approaches)
4. Backtracking (revert to previous state on failure)

Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │                    RolloutAgentLoop                         │
    │  ┌─────────────────────────────────────────────────────┐   │
    │  │                  RolloutTree                          │   │
    │  │   Root (Initial Request)                           │   │
    │  │       ├── Node A (Action: read_file)               │   │
    │  │       │       └── Node A1 (Observation: content)    │   │
    │  │       │               └── Node A1a (write) → OK     │   │
    │  │       │                                           │   │
    │  │       └── Node B (Alternative: different approach) │   │
    │  │               └── ...                              │   │
    │  └─────────────────────────────────────────────────────┘   │
    │                           │                                 │
    │  ┌────────────────────────▼────────────────────────────┐  │
    │  │               AgentLoop Core                         │  │
    │  │  Session Layer → Evaluator → Execution → Safety      │  │
    │  └─────────────────────────────────────────────────────┘  │
    └─────────────────────────────────────────────────────────────┘

Usage:
    loop = RolloutAgentLoop(
        llm_fn=my_llm_function,
        tool_executor=my_tool_executor,
        enable_rollout=True,
        max_rollout_depth=50,
    )

    async for event in loop.run("Write a program"):
        if event.get("type") == LoopEvent.ROLLBACK_TRIGGERED:
            # Can access rollout state
            tree = loop.get_rollout_tree()
            best = loop.get_best_result()
"""

import asyncio
import copy
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional

from .loop import AgentLoop, LoopState, LoopEvent, LoopStep, LoopResult
from .evaluator import EvaluationVerdict
from .rollout import (
    RolloutTree,
    RolloutNode,
    RolloutManager,
    Action,
    Observation,
    StateSnapshot,
    NodeStatus,
    BacktrackResult,
)
from .token_budget import BudgetLevel
from .circuit_breaker import BreakerState
from ..tools.executor import ExecutionStrategy

logger = logging.getLogger(__name__)


class RolloutEvent(str, Enum):
    """Additional events for rollout-enabled loop."""
    ROLLBACK_TRIGGERED = "rollback_triggered"
    BRANCH_CREATED = "branch_created"
    PATH_ABANDONED = "path_abandoned"
    BEST_PATH_SELECTED = "best_path_selected"
    ROLLOUT_STATS = "rollout_stats"


@dataclass
class RollbackEventData:
    """Data associated with a rollback event."""
    target_node_id: str
    reason: str
    abandoned_branch_size: int
    new_branch_name: str


@dataclass
class RolloutLoopResult:
    """Extended result for rollout-enabled loop."""
    output: Any = None
    steps: List[LoopStep] = field(default_factory=list)
    total_duration: float = 0.0
    total_llm_calls: int = 0
    total_tool_calls: int = 0
    total_tokens: int = 0
    final_state: LoopState = LoopState.COMPLETED
    evaluation: Any = None
    budget_snapshot: Any = None

    rollout_statistics: Dict[str, Any] = field(default_factory=dict)
    best_path: List[Dict[str, Any]] = field(default_factory=list)
    total_rollout_nodes: int = 0
    total_branches: int = 0
    backtrack_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "output": self.output,
            "steps": [s.to_dict() for s in self.steps],
            "total_duration": self.total_duration,
            "total_llm_calls": self.total_llm_calls,
            "total_tool_calls": self.total_tool_calls,
            "total_tokens": self.total_tokens,
            "final_state": self.final_state.value,
            "rollout_statistics": self.rollout_statistics,
            "best_path": self.best_path,
            "total_rollout_nodes": self.total_rollout_nodes,
            "total_branches": self.total_branches,
            "backtrack_count": self.backtrack_count,
        }


class RolloutAgentLoop(AgentLoop):
    """AgentLoop with tree-structured reasoning and backtracking support.

    This class extends AgentLoop with:
    1. RolloutTree for tracking reasoning paths as a tree
    2. State snapshot/restore for backtracking
    3. Branch exploration for trying alternatives
    4. Backtrack triggers based on evaluation failures

    Key differences from AgentLoop:
    - Every step is recorded as a node in RolloutTree
    - State snapshots enable complete rollback
    - Can create branches for alternative approaches
    - Backtrack when evaluation fails

    Usage:
        loop = RolloutAgentLoop(
            llm_fn=my_llm,
            tool_executor=my_tools,
            enable_rollout=True,
            max_rollout_depth=50,
            branch_on_error=True,
            backtrack_on_failed_validation=True,
        )

        async for event in loop.run("Task description"):
            print(event)

        result = loop.get_rollout_result()
    """

    def __init__(
        self,
        llm_fn: Callable,
        tool_executor: Optional[Callable] = None,
        evaluator: Optional[Any] = None,
        budget_policy: Optional[Any] = None,
        breaker_config: Optional[Any] = None,
        max_iterations: int = 50,
        enable_evaluation: bool = True,
        enable_streaming: bool = True,
        enable_rollout: bool = True,
        max_rollout_depth: int = 50,
        max_rollout_nodes: int = 500,
        branch_on_error: bool = True,
        backtrack_on_failed_validation: bool = True,
        auto_explore_branches: bool = False,
        branch_trigger_threshold: float = 0.5,
        parallel_executor: Optional[Any] = None,
        parallel_strategy: Any = None,
    ):
        """Initialize rollout-enabled agent loop.

        Args:
            llm_fn: Async function for LLM calls
            tool_executor: Async function for tool execution
            evaluator: Skeptic evaluator instance
            budget_policy: Token budget policy
            breaker_config: Circuit breaker config
            max_iterations: Maximum loop iterations
            enable_evaluation: Enable evaluator layer
            enable_streaming: Enable AsyncGenerator streaming
            enable_rollout: Enable rollout tree tracking
            max_rollout_depth: Maximum depth of rollout tree
            max_rollout_nodes: Maximum total nodes in rollout tree
            branch_on_error: Create branch when step fails
            backtrack_on_failed_validation: Backtrack when evaluation fails
            auto_explore_branches: Automatically explore alternative branches
            branch_trigger_threshold: Score threshold to trigger branching
            parallel_executor: StreamingToolExecutor for parallel tool execution
            parallel_strategy: Execution strategy for parallel tools
        """
        super().__init__(
            llm_fn=llm_fn,
            tool_executor=tool_executor,
            evaluator=evaluator,
            budget_policy=budget_policy,
            breaker_config=breaker_config,
            max_iterations=max_iterations,
            enable_evaluation=enable_evaluation,
            enable_streaming=enable_streaming,
            parallel_executor=parallel_executor,
            parallel_strategy=parallel_strategy or ExecutionStrategy.PARALLEL_SAFE,
        )

        self.enable_rollout = enable_rollout
        self.branch_on_error = branch_on_error
        self.backtrack_on_failed_validation = backtrack_on_failed_validation
        self.auto_explore_branches = auto_explore_branches
        self.branch_trigger_threshold = branch_trigger_threshold

        self._rollout_manager: Optional[RolloutManager] = None
        self._rollout_enabled: bool = False
        self._backtrack_count: int = 0
        self._start_time: float = 0.0
        self._context: List[Dict[str, Any]] = []

        self._setup_rollout_callbacks()

    def _setup_rollout_callbacks(self) -> None:
        """Setup internal callbacks for rollout events."""
        if not self.enable_rollout:
            return

        self._rollout_manager = RolloutManager(
            max_depth=50,
            max_nodes=500,
            auto_explore_branches=self.auto_explore_branches,
            branch_on_error=self.branch_on_error,
            backtrack_on_failed_validation=self.backtrack_on_failed_validation,
        )

        self._rollout_manager.on_backtrack(self._on_backtrack)
        self._rollout_manager.on_branch(self._on_branch)

    def _on_backtrack(self, result: BacktrackResult) -> None:
        """Handle backtrack event.

        Args:
            result: Backtrack result details
        """
        self._backtrack_count += 1
        logger.info(
            "Backtrack #%d: to=%s, abandoned=%d nodes",
            self._backtrack_count,
            result.target_node_id,
            result.abandoned_branch_size
        )

    def _on_branch(self, node: RolloutNode, reason: str) -> None:
        """Handle branch creation event.

        Args:
            node: New branch node
            reason: Reason for branching
        """
        logger.info(
            "Branch created: %s from %s",
            node.branch_name,
            reason
        )

    async def run(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        context: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Run the agent loop with rollout tracking.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            context: Initial conversation context

        Yields:
            Event dictionaries with type and data
        """
        start_time = time.time()
        self._cancelled = False
        self._steps.clear()
        self._context = context or []
        self._start_time = start_time

        if self.enable_rollout and self._rollout_manager:
            self._rollout_manager.initialize(
                initial_prompt=prompt,
                context=self._context,
                budget=self.budget,
                breaker=self.breaker,
            )
            self._rollout_enabled = True

        yield await self._emit(LoopEvent.STATE_CHANGE, {
            "from": LoopState.IDLE.value,
            "to": LoopState.THINKING.value,
        })

        self._set_state(LoopState.THINKING)

        self._context.append({"role": "user", "content": prompt})

        iteration = 0
        last_evaluation_failed = False
        failed_node_id = None

        while iteration < self.max_iterations and not self._cancelled:
            iteration += 1

            if self.breaker.should_break():
                yield await self._emit(LoopEvent.CIRCUIT_BREAK, {
                    "state": self.breaker.state.value,
                    "snapshot": self.breaker.get_snapshot().to_dict(),
                })
                self._set_state(LoopState.CIRCUIT_OPEN)
                break

            if self.budget.should_stop():
                yield await self._emit(LoopEvent.BUDGET_WARNING, {
                    "level": BudgetLevel.EXCEEDED.value,
                    "snapshot": self.budget.check().to_dict(),
                })
                break

            step = LoopStep(state=LoopState.THINKING)
            step_start = time.time()

            yield await self._emit(LoopEvent.LLM_CALL_START, {
                "iteration": iteration,
            })

            if self._rollout_enabled and self._rollout_manager:
                snapshot_before = StateSnapshot.capture(
                    context=self._context,
                    budget=self.budget,
                    breaker=self.breaker,
                    start_time=start_time,
                )

            self.breaker.record_llm_call()
            budget_before = self.budget.check()

            try:
                llm_result = await self.llm_fn(
                    messages=self._context,
                    system_prompt=system_prompt,
                )
            except Exception as e:
                self._consecutive_llm_failures += 1
                self.breaker.record_failure(error=str(e))

                if self._rollout_enabled:
                    self._record_failed_step(
                        action_type="llm_call",
                        error=str(e),
                    )

                yield await self._emit(LoopEvent.ERROR, {"error": str(e)})
                step.state = LoopState.FAILED
                step.duration = time.time() - step_start
                self._steps.append(step)

                if self._consecutive_llm_failures >= 3:
                    logger.error(
                        "AgentLoop: %d consecutive LLM failures, breaking loop",
                        self._consecutive_llm_failures
                    )
                    break
                continue

            self._consecutive_llm_failures = 0

            if hasattr(llm_result, 'usage') and llm_result.usage:
                self.budget.record_usage(
                    prompt_tokens=getattr(llm_result.usage, 'prompt_tokens', 0),
                    completion_tokens=getattr(llm_result.usage, 'completion_tokens', 0),
                )

            self.budget.record_iteration()
            budget_after = self.budget.check()
            step.budget_snapshot = budget_after

            yield await self._emit(LoopEvent.LLM_CALL_END, {
                "iteration": iteration,
                "budget": budget_after.to_dict(),
            })

            response_content = self._extract_content(llm_result)
            tool_calls = self._extract_tool_calls(llm_result)

            step.output = response_content
            step.tool_calls = tool_calls

            if self._rollout_enabled and self._rollout_manager:
                self._rollout_manager.record_llm_call(
                    prompt=self._context[-1] if self._context else None,
                    response=llm_result,
                    snapshot_before=True,
                )

            self._context.append({"role": "assistant", "content": response_content})

            if self.enable_evaluation and response_content and not tool_calls:
                yield await self._emit(LoopEvent.STATE_CHANGE, {
                    "from": LoopState.THINKING.value,
                    "to": LoopState.EVALUATING.value,
                })
                self._set_state(LoopState.EVALUATING)

                eval_result = await self.evaluator.evaluate(
                    task=prompt,
                    output=response_content,
                    context={
                        "token_usage_ratio": budget_after.usage_ratio,
                        "iteration_ratio": iteration / self.max_iterations,
                    },
                )
                step.evaluation = eval_result

                yield await self._emit(LoopEvent.EVALUATION_RESULT, {
                    "verdict": eval_result.verdict.value,
                    "score": eval_result.score,
                    "issues": eval_result.issues,
                })

                if self._rollout_enabled and self._rollout_manager:
                    rollout_node = self._rollout_manager.record_evaluation(
                        verdict=eval_result.verdict.value,
                        score=eval_result.score,
                        issues=eval_result.issues,
                    )
                    if rollout_node:
                        failed_node_id = rollout_node.id

                if eval_result.verdict == EvaluationVerdict.APPROVE:
                    yield await self._emit(LoopEvent.YIELD, {
                        "type": "final_output",
                        "content": response_content,
                    })
                    step.state = LoopState.COMPLETED
                    step.duration = time.time() - step_start
                    self._steps.append(step)
                    break

                elif eval_result.verdict == EvaluationVerdict.REJECT:
                    last_evaluation_failed = True

                    if self._rollout_enabled and self.backtrack_on_failed_validation:
                        if self._rollout_manager and failed_node_id:
                            parent_node = self._get_parent_node(failed_node_id)
                            if parent_node:
                                rollback_result = self._rollout_manager.trigger_backtrack(
                                    to_node_id=parent_node.id,
                                    reason=f"evaluation_rejected: {', '.join(eval_result.issues[:2])}",
                                )

                                if rollback_result:
                                    self._context.clear()
                                    self._context.extend(copy.deepcopy(rollback_result.restored_state.context))

                                    yield await self._emit(RolloutEvent.ROLLBACK_TRIGGERED, {
                                        "target_node_id": rollback_result.target_node_id,
                                        "reason": "evaluation_rejected",
                                        "abandoned_branch_size": rollback_result.abandoned_branch_size,
                                        "new_branch_name": rollback_result.new_branch_name,
                                    })

                                    continue

                    self._context.append({
                        "role": "user",
                        "content": f"Your previous response was rejected. Issues: {'; '.join(eval_result.issues)}. Please revise.",
                    })

            elif not tool_calls and response_content:
                yield await self._emit(LoopEvent.YIELD, {
                    "type": "output",
                    "content": response_content,
                })
                step.state = LoopState.COMPLETED
                step.duration = time.time() - step_start
                self._steps.append(step)
                break

            if tool_calls and self.tool_executor:
                yield await self._emit(LoopEvent.STATE_CHANGE, {
                    "from": LoopState.THINKING.value,
                    "to": LoopState.EXECUTING.value,
                })
                self._set_state(LoopState.EXECUTING)

                for tc in tool_calls:
                    tool_name = tc.get("name", tc.get("function", {}).get("name", "unknown"))

                    yield await self._emit(LoopEvent.TOOL_CALL_START, {
                        "tool": tool_name,
                        "iteration": iteration,
                    })

                    snapshot_before = None
                    if self._rollout_enabled:
                        snapshot_before = StateSnapshot.capture(
                            context=self._context,
                            budget=self.budget,
                            breaker=self.breaker,
                            start_time=start_time,
                        )

                    try:
                        tool_result = await self.tool_executor(tc)
                        self.breaker.record_success(tool_name)

                        if self._rollout_enabled and self._rollout_manager:
                            self._rollout_manager.record_tool_call(
                                tool_name=tool_name,
                                arguments=tc.get("arguments") or {},
                                result=tool_result,
                            )

                        yield await self._emit(LoopEvent.TOOL_CALL_END, {
                            "tool": tool_name,
                            "status": "success",
                        })

                        self._context.append({
                            "role": "tool",
                            "name": tool_name,
                            "content": str(tool_result),
                        })

                    except Exception as e:
                        self.breaker.record_failure(tool_name, str(e))

                        if self._rollout_enabled:
                            self._record_failed_step(
                                action_type="tool_call",
                                tool_name=tool_name,
                                error=str(e),
                            )

                            if self.branch_on_error:
                                self._trigger_alternative_branch(
                                    reason=f"tool_failed: {tool_name}",
                                    error=str(e),
                                )

                        yield await self._emit(LoopEvent.TOOL_CALL_END, {
                            "tool": tool_name,
                            "status": "error",
                            "error": str(e),
                        })

                        self._context.append({
                            "role": "tool",
                            "name": tool_name,
                            "content": f"Error: {e}",
                        })

                    self.budget.record_tool_call()

            if self.budget.should_compact():
                yield await self._emit(LoopEvent.COMPACTION, {
                    "strategy": self.budget.get_compression_strategy(),
                })
                self._set_state(LoopState.COMPACTING)

            step.duration = time.time() - step_start
            self._steps.append(step)

            yield await self._emit(LoopEvent.YIELD, {
                "type": "step_complete",
                "step": step.to_dict(),
                "iteration": iteration,
            })

        total_duration = time.time() - start_time
        final_state = self._state

        if not self._cancelled and final_state not in (
            LoopState.CIRCUIT_OPEN,
            LoopState.FAILED,
        ):
            self._set_state(LoopState.COMPLETED)

        if self._rollout_enabled and self._rollout_manager:
            tree_stats = self._rollout_manager.tree.get_statistics()
            yield await self._emit(RolloutEvent.ROLLOUT_STATS, tree_stats)

        yield await self._emit(LoopEvent.COMPLETE, {
            "final_state": self._state.value,
            "total_duration": total_duration,
            "total_steps": len(self._steps),
            "total_llm_calls": self.breaker.get_snapshot().total_llm_calls,
            "total_tool_calls": self.breaker.get_snapshot().total_tool_calls,
            "backtrack_count": self._backtrack_count,
        })

    def _record_failed_step(
        self,
        action_type: str,
        error: str,
        tool_name: Optional[str] = None,
    ) -> None:
        """Record a failed step in rollout tree.

        Args:
            action_type: Type of action that failed
            error: Error message
            tool_name: Name of tool if tool call failed
        """
        if not self._rollout_manager or not self._rollout_enabled:
            return

        current = self._rollout_manager.tree.get_current_node()
        if not current:
            return

        action = Action(
            action_type=action_type,
            tool_name=tool_name,
        )

        snapshot = StateSnapshot.capture(
            context=self._context,
            budget=self.budget,
            breaker=self.breaker,
            start_time=self._start_time,
        )

        node = self._rollout_manager.tree.advance(
            parent_id=current.id,
            action=action,
            snapshot=snapshot,
        )

        if node:
            observation = Observation(
                observation_type="error",
                content=None,
                success=False,
                error_message=error,
            )
            self._rollout_manager.tree.complete_node(node.id, observation)

    def _trigger_alternative_branch(
        self,
        reason: str,
        error: Optional[str] = None,
    ) -> Optional[RolloutNode]:
        """Trigger creation of an alternative branch.

        Args:
            reason: Reason for branching
            error: Error details if any

        Returns:
            The new branch node, or None
        """
        if not self._rollout_manager:
            return None

        branch_types = [
            "retry_different_approach",
            "use_alternative_tool",
            "simplify_task",
            "decompose_step",
        ]

        branch_name = branch_types[len(self._steps) % len(branch_types)]

        new_branch = self._rollout_manager.trigger_branch(
            branch_name=branch_name,
            reason=f"{reason}: {error}" if error else reason,
        )

        if new_branch:
            logger.info(
                "Created alternative branch '%s' due to: %s",
                branch_name,
                reason
            )

        return new_branch

    def _get_parent_node(self, node_id: str) -> Optional[RolloutNode]:
        """Get parent node of a given node.

        Args:
            node_id: ID of the node

        Returns:
            Parent RolloutNode, or None
        """
        if not self._rollout_manager:
            return None

        tree = self._rollout_manager.tree
        node = tree.nodes.get(node_id)

        if not node or not node.parent_id:
            return None

        return tree.nodes.get(node.parent_id)

    async def run_sync(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        context: Optional[List[Dict[str, Any]]] = None,
    ) -> RolloutLoopResult:
        """Run the agent loop and collect all results with rollout info.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            context: Initial context

        Returns:
            RolloutLoopResult with complete execution details
        """
        start_time = time.time()
        final_output = None
        final_evaluation = None
        rollout_stats = {}
        best_path = []

        async for event in self.run(prompt, system_prompt, context):
            if event.get("type") == LoopEvent.YIELD.value:
                data = event.get("data", {})
                if data.get("type") == "final_output":
                    final_output = data.get("content")
                elif data.get("type") == "output":
                    final_output = data.get("content")

            elif event.get("type") == LoopEvent.EVALUATION_RESULT.value:
                data = event.get("data", {})
                final_evaluation = data

            elif event.get("type") == RolloutEvent.ROLLOUT_STATS.value:
                rollout_stats = event.get("data", {})

        breaker_snapshot = self.breaker.get_snapshot()

        if self._rollout_manager and self._rollout_enabled:
            best_result = self._rollout_manager.get_best_result()
            if best_result.get("path_nodes"):
                best_path = [n.to_dict() for n in best_result["path_nodes"]]

        return RolloutLoopResult(
            output=final_output,
            steps=self._steps,
            total_duration=time.time() - start_time,
            total_llm_calls=breaker_snapshot.total_llm_calls,
            total_tool_calls=breaker_snapshot.total_tool_calls,
            final_state=self._state,
            evaluation=final_evaluation,
            budget_snapshot=self.budget.check(),
            rollout_statistics=rollout_stats,
            best_path=best_path,
            total_rollout_nodes=rollout_stats.get("total_nodes", 0),
            total_branches=rollout_stats.get("branch_count", 0),
            backtrack_count=self._backtrack_count,
        )

    def get_rollout_tree(self) -> Optional[RolloutTree]:
        """Get the underlying rollout tree.

        Returns:
            The RolloutTree instance, or None if rollout is disabled
        """
        if self._rollout_manager:
            return self._rollout_manager.tree
        return None

    def get_rollout_result(self) -> Optional[RolloutLoopResult]:
        """Get the rollout result if available.

        Returns:
            RolloutLoopResult, or None if run_sync hasn't been called
        """
        if self._rollout_manager:
            result = self._rollout_manager.get_best_result()
            stats = self._rollout_manager.tree.get_statistics()
            return RolloutLoopResult(
                rollout_statistics=stats,
                best_path=[n.to_dict() for n in result.get("path_nodes", [])],
                total_rollout_nodes=stats.get("total_nodes", 0),
                total_branches=stats.get("branch_count", 0),
                backtrack_count=self._backtrack_count,
            )
        return None

    def backtrack_to(self, node_id: str, reason: str = "manual") -> Optional[BacktrackResult]:
        """Manually trigger backtrack to a specific node.

        Args:
            node_id: ID of the node to backtrack to
            reason: Reason for backtracking

        Returns:
            BacktrackResult, or None if failed
        """
        if not self._rollout_manager:
            return None

        result = self._rollout_manager.trigger_backtrack(
            to_node_id=node_id,
            reason=reason,
        )

        if result:
            self._context.clear()
            self._context.extend(copy.deepcopy(result.restored_state.context))

        return result

    def create_branch(self, from_node_id: Optional[str] = None, branch_name: str = "manual") -> Optional[RolloutNode]:
        """Create a new branch from a node.

        Args:
            from_node_id: ID of node to branch from (current if None)
            branch_name: Name for the new branch

        Returns:
            The new branch node, or None if failed
        """
        if not self._rollout_manager:
            return None

        if from_node_id is None:
            current = self._rollout_manager.tree.get_current_node()
            from_node_id = current.parent_id if current else self._rollout_manager.tree.root_id

        return self._rollout_manager.trigger_branch(
            branch_name=branch_name,
            reason="manual_branch",
        )
