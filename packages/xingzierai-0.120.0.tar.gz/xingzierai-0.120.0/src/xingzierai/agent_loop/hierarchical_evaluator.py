# -*- coding: utf-8 -*-
"""Hierarchical Evaluator - Three-level evaluation system.

Inspired by UniToolCall's fine-grained evaluation at function-call,
turn, and conversation levels.

This module provides:
1. Function-level evaluation: Single tool call accuracy
2. Turn-level evaluation: Single turn quality
3. Conversation-level evaluation: Overall task completion
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .qaoa import (
    Answer,
    ConversationLevelMetrics,
    EvaluationLevel,
    FunctionLevelMetrics,
    QAOAResult,
    QAOEvaluator,
    Query,
    TurnLevelMetrics,
)

logger = logging.getLogger(__name__)


class ValidationMode(str, Enum):
    """Validation mode for different scenarios."""

    STRICT = "strict"
    RELAXED = "relaxed"
    ADAPTIVE = "adaptive"


@dataclass
class FunctionEvaluation:
    """Result of function-level evaluation."""

    tool_name: str
    call_id: str
    success: bool
    precision: float
    recall: float
    f1: float
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TurnEvaluation:
    """Result of turn-level evaluation."""

    turn_index: int
    success: bool
    actions_count: int
    successful_actions: int
    context_preservation: float
    coherence_score: float
    overall_score: float
    function_evaluations: List[FunctionEvaluation] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ConversationEvaluation:
    """Result of conversation-level evaluation."""

    total_turns: int
    completed_turns: int
    failed_turns: int
    success: bool
    overall_score: float
    goal_achievement: float
    coherence_score: float
    efficiency_score: float
    turn_evaluations: List[TurnEvaluation] = field(default_factory=list)
    conversation_metrics: ConversationLevelMetrics = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class HierarchicalEvaluator:
    """Three-level hierarchical evaluator inspired by UniToolCall.

    Evaluates at:
    1. Function level: Individual tool calls
    2. Turn level: Single conversation turns
    3. Conversation level: Overall task completion

    Usage:
        evaluator = HierarchicalEvaluator()

        # Function-level
        func_result = evaluator.evaluate_function(
            tool_name="weather",
            expected_params={"city": "Beijing"},
            actual_params={"city": "Beijing"},
        )

        # Turn-level
        turn_result = evaluator.evaluate_turn(
            turn_index=0,
            actions=[...],
            observations=[...],
        )

        # Conversation-level
        conv_result = evaluator.evaluate_conversation(
            turn_results=[...],
            goal="Get weather and suggest clothing",
        )
    """

    def __init__(
        self,
        mode: ValidationMode = ValidationMode.STRICT,
        coherence_threshold: float = 0.7,
        enable_suggestions: bool = True,
    ):
        """Initialize HierarchicalEvaluator.

        Args:
            mode: Validation mode (strict, relaxed, adaptive)
            coherence_threshold: Minimum coherence to pass
            enable_suggestions: Whether to generate improvement suggestions
        """
        self.mode = mode
        self.coherence_threshold = coherence_threshold
        self.enable_suggestions = enable_suggestions
        self._qaoa_evaluator = QAOEvaluator(
            strict_mode=mode == ValidationMode.STRICT,
            coherence_threshold=coherence_threshold,
        )
        self._evaluation_history: List[Dict[str, Any]] = []

    def evaluate_function(
        self,
        tool_name: str,
        expected_params: Dict[str, Any],
        actual_params: Dict[str, Any],
        call_id: Optional[str] = None,
    ) -> FunctionEvaluation:
        """Evaluate a single function call.

        Args:
            tool_name: Name of the tool
            expected_params: Expected parameters
            actual_params: Actual parameters passed
            call_id: Optional call identifier

        Returns:
            FunctionEvaluation with detailed results
        """
        call_id = call_id or f"call_{id(call_id)}"

        errors = []
        warnings = []
        suggestions = []

        tool_correct = True
        param_correct = expected_params == actual_params

        missing = [k for k in expected_params if k not in actual_params]
        extra = [k for k in actual_params if k not in expected_params]
        wrong_type = []

        for k, expected_val in expected_params.items():
            if k in actual_params:
                actual_val = actual_params[k]
                if not self._types_match(expected_val, actual_val):
                    wrong_type.append(k)
                    tool_correct = False

        if missing:
            errors.append(f"Missing required parameters: {missing}")
            suggestions.append(f"Add parameters: {missing}")
            tool_correct = False

        if extra:
            warnings.append(f"Extra parameters provided: {extra}")

        if wrong_type:
            errors.append(f"Wrong parameter types for: {wrong_type}")
            suggestions.append(f"Fix types for: {wrong_type}")
            tool_correct = False

        if not param_correct and not errors:
            warnings.append("Parameters do not exactly match expected values")

        correct_count = len(expected_params) - len(missing) - len(wrong_type)
        total_expected = len(expected_params) if expected_params else 1

        precision = correct_count / total_expected if total_expected > 0 else 1.0
        recall = correct_count / len([k for k in expected_params if k in actual_params]) if actual_params else 0.0

        if precision + recall > 0:
            f1 = 2 * (precision * recall) / (precision + recall)
        else:
            f1 = 0.0

        success = tool_correct and precision >= self.coherence_threshold

        return FunctionEvaluation(
            tool_name=tool_name,
            call_id=call_id,
            success=success,
            precision=precision,
            recall=recall,
            f1=f1,
            errors=errors,
            warnings=warnings,
            suggestions=suggestions if self.enable_suggestions else [],
            metadata={
                "mode": self.mode.value,
                "expected_params": expected_params,
                "actual_params": actual_params,
                "missing": missing,
                "extra": extra,
                "wrong_type": wrong_type,
            },
        )

    def evaluate_turn(
        self,
        turn_index: int,
        actions: List[Any],
        observations: List[Any],
        expected_outcome: Optional[str] = None,
        previous_turn_context: Optional[Dict[str, Any]] = None,
    ) -> TurnEvaluation:
        """Evaluate a single conversation turn.

        Args:
            turn_index: Index of the turn
            actions: List of actions in the turn
            observations: List of observations received
            expected_outcome: Optional expected outcome
            previous_turn_context: Context from previous turn for coherence

        Returns:
            TurnEvaluation with detailed results
        """
        errors = []
        suggestions = []

        successful_actions = sum(1 for a in actions if getattr(a, "success", True))
        failed_actions = len(actions) - successful_actions

        if failed_actions > 0:
            errors.append(f"{failed_actions} action(s) failed in turn")
            suggestions.append("Review failed actions for errors")

        action_obs_gaps = max(0, len(actions) - len(observations))
        if action_obs_gaps > 0:
            errors.append(f"Missing observations for {action_obs_gaps} action(s)")
            suggestions.append("Ensure all actions have corresponding observations")

        context_preservation = self._calculate_context_preservation(
            actions, observations, previous_turn_context
        )

        action_success_rate = successful_actions / len(actions) if actions else 0.0
        completion_rate = (len(actions) - action_obs_gaps) / len(actions) if actions else 0.0

        coherence_score = (context_preservation + action_success_rate + completion_rate) / 3

        overall_score = coherence_score

        if expected_outcome:
            outcome_match = self._check_outcome_match(observations, expected_outcome)
            overall_score = (coherence_score + outcome_match) / 2

        success = (
            failed_actions == 0
            and action_obs_gaps == 0
            and coherence_score >= self.coherence_threshold
        )

        function_evals = []
        for action in actions:
            if hasattr(action, "tool_name") and hasattr(action, "parameters"):
                func_eval = self.evaluate_function(
                    tool_name=action.tool_name,
                    expected_params=getattr(action, "expected_params", {}),
                    actual_params=action.parameters or {},
                    call_id=getattr(action, "id", None),
                )
                function_evals.append(func_eval)

        return TurnEvaluation(
            turn_index=turn_index,
            success=success,
            actions_count=len(actions),
            successful_actions=successful_actions,
            context_preservation=context_preservation,
            coherence_score=coherence_score,
            overall_score=overall_score,
            function_evaluations=function_evals,
            errors=errors,
            suggestions=suggestions if self.enable_suggestions else [],
            metadata={
                "mode": self.mode.value,
                "action_success_rate": action_success_rate,
                "completion_rate": completion_rate,
                "has_expected_outcome": expected_outcome is not None,
            },
        )

    def evaluate_conversation(
        self,
        turn_evaluations: List[TurnEvaluation],
        goal: Optional[str] = None,
        total_tokens: Optional[int] = None,
        total_time: Optional[float] = None,
    ) -> ConversationEvaluation:
        """Evaluate entire conversation across all turns.

        Args:
            turn_evaluations: List of turn-level evaluations
            goal: Overall goal description
            total_tokens: Total tokens used
            total_time: Total time taken

        Returns:
            ConversationEvaluation with overall results
        """
        if not turn_evaluations:
            return ConversationEvaluation(
                total_turns=0,
                completed_turns=0,
                failed_turns=0,
                success=False,
                overall_score=0.0,
                goal_achievement=0.0,
                coherence_score=0.0,
                efficiency_score=0.0,
            )

        completed_turns = sum(1 for t in turn_evaluations if t.success)
        failed_turns = len(turn_evaluations) - completed_turns

        total_actions = sum(t.actions_count for t in turn_evaluations)
        total_successful = sum(t.successful_actions for t in turn_evaluations)

        avg_coherence = sum(t.coherence_score for t in turn_evaluations) / len(turn_evaluations)
        avg_context = sum(t.context_preservation for t in turn_evaluations) / len(turn_evaluations)

        goal_achievement = completed_turns / len(turn_evaluations) if turn_evaluations else 0.0

        efficiency_score = 1.0
        if total_time and total_time > 0:
            time_per_turn = total_time / len(turn_evaluations)
            efficiency_score = max(0.0, 1.0 - (time_per_turn / 60))

        if total_tokens and total_tokens > 0:
            tokens_per_action = total_tokens / max(1, total_actions)
            token_efficiency = max(0.0, 1.0 - (tokens_per_action / 1000))
            efficiency_score = (efficiency_score + token_efficiency) / 2

        overall_score = (
            avg_coherence * 0.3
            + goal_achievement * 0.4
            + efficiency_score * 0.3
        )

        all_errors = []
        all_suggestions = []
        for turn in turn_evaluations:
            all_errors.extend(turn.errors)
            all_suggestions.extend(turn.suggestions)

        if failed_turns > len(turn_evaluations) / 2:
            all_errors.append("More than half of turns failed")
            all_suggestions.append("Consider restructuring the approach")

        qaoa_metrics = ConversationLevelMetrics(
            total_turns=len(turn_evaluations),
            completed_turns=completed_turns,
            failed_turns=failed_turns,
            total_tool_calls=total_actions,
            successful_tool_calls=total_successful,
            goal_achievement=goal_achievement,
            coherence_across_turns=avg_coherence,
        )

        return ConversationEvaluation(
            total_turns=len(turn_evaluations),
            completed_turns=completed_turns,
            failed_turns=failed_turns,
            success=overall_score >= self.coherence_threshold,
            overall_score=overall_score,
            goal_achievement=goal_achievement,
            coherence_score=avg_coherence,
            efficiency_score=efficiency_score,
            turn_evaluations=turn_evaluations,
            conversation_metrics=qaoa_metrics.to_dict(),
            errors=all_errors if self.enable_suggestions else [],
            suggestions=all_suggestions if self.enable_suggestions else [],
            metadata={
                "mode": self.mode.value,
                "goal": goal,
                "total_tokens": total_tokens,
                "total_time": total_time,
            },
        )

    def evaluate_with_qaoa(
        self,
        query: str,
        actions: List[Any],
        observations: List[Any],
        level: EvaluationLevel = EvaluationLevel.TURN,
        expected_tool: Optional[str] = None,
        expected_params: Optional[Dict[str, Any]] = None,
    ) -> QAOAResult:
        """Evaluate using QAOA representation.

        Args:
            query: User query
            actions: List of actions
            observations: List of observations
            level: Evaluation level
            expected_tool: Expected tool (for function level)
            expected_params: Expected params (for function level)

        Returns:
            QAOAResult with evaluation
        """
        qaoa = QAOAResult(
            level=level,
            qaoa_id=f"qaoa_{len(self._evaluation_history)}",
            query=Query(text=query),
        )

        for action in actions:
            qaoa.actions.append(
                Action(
                    action_type=getattr(action, "action_type", "unknown"),
                    tool_name=getattr(action, "tool_name", None),
                    parameters=getattr(action, "parameters", None),
                    success=getattr(action, "success", True),
                )
            )

        for obs in observations:
            qaoa.observations.append(
                Observation(
                    content=str(obs),
                    observation_type=getattr(obs, "type", "unknown"),
                    source=getattr(obs, "source", "unknown"),
                )
            )

        return self._qaoa_evaluator.evaluate_qaoa(
            qaoa,
            expected_tool=expected_tool,
            expected_params=expected_params,
        )

    def _types_match(self, expected: Any, actual: Any) -> bool:
        """Check if types match for strict mode."""
        if self.mode == ValidationMode.RELAXED:
            return True
        return type(expected) == type(actual)

    def _calculate_context_preservation(
        self,
        actions: List[Any],
        observations: List[Any],
        previous_context: Optional[Dict[str, Any]],
    ) -> float:
        """Calculate context preservation score."""
        if not actions or not observations:
            return 0.0

        base_score = min(len(actions), len(observations)) / max(len(actions), len(observations))

        context_bonus = 0.0
        if previous_context:
            context_bonus = 0.1

        return min(1.0, base_score + context_bonus)

    def _check_outcome_match(
        self,
        observations: List[Any],
        expected: str,
    ) -> float:
        """Check how well observations match expected outcome."""
        if not observations:
            return 0.0

        obs_text = " ".join(str(o) for o in observations).lower()
        expected_lower = expected.lower()

        if expected_lower in obs_text:
            return 1.0

        expected_words = set(expected_lower.split())
        obs_words = set(obs_text.split())
        overlap = len(expected_words & obs_words)

        return overlap / len(expected_words) if expected_words else 0.0

    def get_evaluation_summary(
        self,
        conversation_eval: ConversationEvaluation,
    ) -> Dict[str, Any]:
        """Get human-readable evaluation summary.

        Args:
            conversation_eval: Conversation-level evaluation

        Returns:
            Dictionary with summary information
        """
        status = "PASS" if conversation_eval.success else "FAIL"
        score_pct = conversation_eval.overall_score * 100

        summary = {
            "status": status,
            "overall_score": f"{score_pct:.1f}%",
            "turns": f"{conversation_eval.completed_turns}/{conversation_eval.total_turns}",
            "coherence": f"{conversation_eval.coherence_score:.1%}",
            "goal_achievement": f"{conversation_eval.goal_achievement:.1%}",
        }

        if conversation_eval.errors:
            summary["top_errors"] = conversation_eval.errors[:3]

        if conversation_eval.suggestions:
            summary["top_suggestions"] = conversation_eval.suggestions[:3]

        return summary

    def record_evaluation(
        self,
        evaluation: Any,
        level: EvaluationLevel,
    ) -> None:
        """Record an evaluation for history tracking."""
        self._evaluation_history.append({
            "level": level.value,
            "evaluation": evaluation,
            "timestamp": datetime.now().isoformat(),
        })

    def get_evaluation_history(
        self,
        level: Optional[EvaluationLevel] = None,
    ) -> List[Dict[str, Any]]:
        """Get evaluation history, optionally filtered by level."""
        if level:
            return [
                e for e in self._evaluation_history
                if e["level"] == level.value
            ]
        return self._evaluation_history.copy()

    def clear_history(self) -> None:
        """Clear evaluation history."""
        self._evaluation_history.clear()
        self._qaoa_evaluator.clear_history()