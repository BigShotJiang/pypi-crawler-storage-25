# -*- coding: utf-8 -*-
"""DependencyLayerChecker - Import direction constraint enforcement.

Inspired by Alibaba's Qoder Harness Engineering:
- Repository is the Agent's operating system
- Layer constraints encoded as version-controlled files
- High layers may import low layers, NOT the reverse
- Pre-validation replaces blind coding

This module provides:
1. Layer definition from AGENT.md or WORKFLOW.md
2. Import direction checking (high → low only)
3. Violation detection and reporting
4. Integration with HardGateExecutor
"""

from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class LayerSeverity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LayerDefinition:
    name: str
    level: int
    path_patterns: List[str]
    description: str = ""
    allowed_imports_from: List[str] = field(default_factory=list)
    forbidden_imports_from: List[str] = field(default_factory=list)

    def matches_path(self, file_path: str) -> bool:
        fp = file_path.replace("\\", "/")
        for pattern in self.path_patterns:
            pattern = pattern.replace("\\", "/")
            if pattern.endswith("*"):
                if fp.startswith(pattern.rstrip("*")):
                    return True
            elif pattern in fp:
                return True
        return False


@dataclass
class ImportViolation:
    source_file: str
    source_layer: str
    source_level: int
    import_target: str
    target_layer: str
    target_level: int
    severity: LayerSeverity
    message: str
    line_number: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_file": self.source_file,
            "source_layer": self.source_layer,
            "source_level": self.source_level,
            "import_target": self.import_target,
            "target_layer": self.target_layer,
            "target_level": self.target_level,
            "severity": self.severity.value,
            "message": self.message,
            "line_number": self.line_number,
        }


@dataclass
class LayerCheckResult:
    file_path: str
    total_imports: int = 0
    valid_imports: int = 0
    violations: List[ImportViolation] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(v.severity == LayerSeverity.ERROR for v in self.violations)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "file_path": self.file_path,
            "passed": self.passed,
            "total_imports": self.total_imports,
            "valid_imports": self.valid_imports,
            "violation_count": len(self.violations),
            "violations": [v.to_dict() for v in self.violations],
            "warnings": self.warnings,
        }


class DependencyLayerChecker:
    """Import direction constraint checker.

    Implements Alibaba's Harness Engineering principle:
    - Most codebases have natural dependency direction
    - Layer 0: type definitions (imported by all)
    - Layer 1-2: utilities and config (only depend on lower)
    - Layer 3: business logic
    - Layer 4+: HTTP handlers, CLI commands
    - Rule: high layers may import low layers, NOT the reverse

    Usage:
        checker = DependencyLayerChecker(workspace_dir=Path("/project"))
        checker.load_layers_from_config()

        result = checker.check_file("src/xingzierai/agents/react_agent.py")
        if not result.passed:
            for v in result.violations:
                print(v.message)
    """

    DEFAULT_LAYERS = [
        LayerDefinition(
            name="types",
            level=0,
            path_patterns=[
                "src/xingzierai/types*",
                "src/xingzierai/**/types*",
                "src/xingzierai/**/models*",
            ],
            description="Type definitions and data models - no internal imports",
        ),
        LayerDefinition(
            name="utils",
            level=1,
            path_patterns=[
                "src/xingzierai/utils*",
                "src/xingzierai/**/utils*",
                "src/xingzierai/**/helpers*",
                "src/xingzierai/**/constants*",
            ],
            description="Utility functions and constants - only depend on types",
        ),
        LayerDefinition(
            name="config",
            level=1,
            path_patterns=[
                "src/xingzierai/config*",
                "src/xingzierai/**/config*",
                "src/xingzierai/**/settings*",
            ],
            description="Configuration - only depend on types",
        ),
        LayerDefinition(
            name="tools",
            level=2,
            path_patterns=[
                "src/xingzierai/tools*",
                "src/xingzierai/**/tools*",
            ],
            description="Tool definitions - depend on types and utils",
        ),
        LayerDefinition(
            name="agent_loop",
            level=2,
            path_patterns=[
                "src/xingzierai/agent_loop*",
            ],
            description="Agent loop core - depend on types, utils, tools",
        ),
        LayerDefinition(
            name="agents",
            level=3,
            path_patterns=[
                "src/xingzierai/agents*",
            ],
            description="Agent implementations - depend on agent_loop, tools, types",
        ),
        LayerDefinition(
            name="app",
            level=4,
            path_patterns=[
                "src/xingzierai/app*",
                "src/xingzierai/app/**/*",
            ],
            description="Application layer (routers, pages) - depend on agents, types",
        ),
        LayerDefinition(
            name="evolution",
            level=3,
            path_patterns=[
                "src/xingzierai/agents/evolution*",
            ],
            description="Evolution engine - depend on agent_loop, types",
        ),
    ]

    def __init__(self, workspace_dir: Optional[Path] = None):
        self.workspace_dir = workspace_dir or Path.cwd()
        self._layers: List[LayerDefinition] = []
        self._layer_cache: Dict[str, LayerDefinition] = {}
        self._use_defaults = True

    def load_layers_from_config(self) -> int:
        config_paths = [
            self.workspace_dir / "AGENT.md",
            self.workspace_dir / "WORKFLOW.md",
        ]

        loaded = 0
        for config_path in config_paths:
            if config_path.exists():
                layers = self._parse_layers_from_file(config_path)
                if layers:
                    self._layers.extend(layers)
                    loaded += len(layers)

        if not self._layers:
            self._layers = list(self.DEFAULT_LAYERS)
            logger.info("Using default layer definitions")

        self._rebuild_cache()
        return loaded

    def _parse_layers_from_file(self, path: Path) -> List[LayerDefinition]:
        content = path.read_text(encoding="utf-8")
        layers = []

        layer_pattern = re.compile(
            r'layer[_\s]+(\d+)[:\s]+([^\n]+)\n((?:(?!layer[_\s]+\d).)*)',
            re.IGNORECASE | re.DOTALL,
        )

        for match in layer_pattern.finditer(content):
            level = int(match.group(1))
            name = match.group(2).strip()
            body = match.group(3)

            path_patterns = re.findall(r'path[s]?:\s*(.+)', body, re.IGNORECASE)
            if not path_patterns:
                path_patterns = re.findall(r'`([^`]+)`', body)

            if path_patterns:
                patterns = [p.strip().strip('"\'') for p in path_patterns[0].split(',')]
            else:
                patterns = []

            if patterns:
                layers.append(LayerDefinition(
                    name=name,
                    level=level,
                    path_patterns=patterns,
                    description=name,
                ))

        return layers

    def _rebuild_cache(self):
        self._layer_cache.clear()
        for layer in self._layers:
            for pattern in layer.path_patterns:
                normalized = pattern.replace("\\", "/").rstrip("*")
                self._layer_cache[normalized] = layer

    def add_layer(self, layer: LayerDefinition):
        self._layers.append(layer)
        self._layers.sort(key=lambda l: l.level)
        self._rebuild_cache()

    def get_layer_for_file(self, file_path: str) -> Optional[LayerDefinition]:
        fp = file_path.replace("\\", "/")
        best_match = None
        best_specificity = 0

        for layer in self._layers:
            if layer.matches_path(fp):
                pattern_len = max(len(p) for p in layer.path_patterns)
                if pattern_len > best_specificity:
                    best_specificity = pattern_len
                    best_match = layer

        return best_match

    def check_file(self, file_path: str) -> LayerCheckResult:
        if not self._layers:
            self.load_layers_from_config()

        fp = file_path.replace("\\", "/")
        abs_path = self.workspace_dir / fp if not Path(fp).is_absolute() else Path(fp)

        source_layer = self.get_layer_for_file(fp)

        if source_layer is None:
            return LayerCheckResult(
                file_path=fp,
                warnings=[f"File not mapped to any layer: {fp}"],
            )

        if not abs_path.exists() or not abs_path.suffix == '.py':
            return LayerCheckResult(
                file_path=fp,
                warnings=[f"Cannot check non-Python or missing file: {fp}"],
            )

        try:
            source_code = abs_path.read_text(encoding="utf-8")
        except Exception as e:
            return LayerCheckResult(
                file_path=fp,
                warnings=[f"Cannot read file: {e}"],
            )

        imports = self._extract_imports(source_code)
        result = LayerCheckResult(file_path=fp, total_imports=len(imports))

        for import_path, line_no in imports:
            if not self._is_internal_import(import_path):
                result.valid_imports += 1
                continue

            target_layer = self._resolve_import_to_layer(import_path)

            if target_layer is None:
                result.valid_imports += 1
                continue

            if target_layer.level > source_layer.level:
                violation = ImportViolation(
                    source_file=fp,
                    source_layer=source_layer.name,
                    source_level=source_layer.level,
                    import_target=import_path,
                    target_layer=target_layer.name,
                    target_level=target_layer.level,
                    severity=LayerSeverity.ERROR,
                    message=(
                        f"Layer violation: {source_layer.name} (L{source_layer.level}) "
                        f"imports from {target_layer.name} (L{target_layer.level}) "
                        f"at line {line_no}. High layers must not import from low layers."
                    ),
                    line_number=line_no,
                )
                result.violations.append(violation)
            elif target_layer.level == source_layer.level:
                if source_layer.name != target_layer.name:
                    result.warnings.append(
                        f"Same-level cross-module import: {source_layer.name} → {target_layer.name} "
                        f"at line {line_no}. Consider if this is necessary."
                    )
                result.valid_imports += 1
            else:
                result.valid_imports += 1

        return result

    def check_directory(self, dir_path: str = "src/xingzierai") -> List[LayerCheckResult]:
        abs_dir = self.workspace_dir / dir_path if not Path(dir_path).is_absolute() else Path(dir_path)
        results = []

        if not abs_dir.exists():
            return results

        for py_file in abs_dir.rglob("*.py"):
            rel_path = str(py_file.relative_to(self.workspace_dir))
            result = self.check_file(rel_path)
            results.append(result)

        return results

    def check_change(self, file_path: str, new_content: str) -> LayerCheckResult:
        if not self._layers:
            self.load_layers_from_config()

        fp = file_path.replace("\\", "/")
        source_layer = self.get_layer_for_file(fp)

        if source_layer is None:
            return LayerCheckResult(
                file_path=fp,
                warnings=[f"File not mapped to any layer: {fp}"],
            )

        imports = self._extract_imports(new_content)
        result = LayerCheckResult(file_path=fp, total_imports=len(imports))

        for import_path, line_no in imports:
            if not self._is_internal_import(import_path):
                result.valid_imports += 1
                continue

            target_layer = self._resolve_import_to_layer(import_path)

            if target_layer is None:
                result.valid_imports += 1
                continue

            if target_layer.level > source_layer.level:
                violation = ImportViolation(
                    source_file=fp,
                    source_layer=source_layer.name,
                    source_level=source_layer.level,
                    import_target=import_path,
                    target_layer=target_layer.name,
                    target_level=target_layer.level,
                    severity=LayerSeverity.ERROR,
                    message=(
                        f"Layer violation: {source_layer.name} (L{source_layer.level}) "
                        f"imports from {target_layer.name} (L{target_layer.level}) "
                        f"at line {line_no}. High layers must not import from low layers."
                    ),
                    line_number=line_no,
                )
                result.violations.append(violation)
            else:
                result.valid_imports += 1

        return result

    def _extract_imports(self, source_code: str) -> List[Tuple[str, int]]:
        imports = []
        try:
            tree = ast.parse(source_code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append((alias.name, node.lineno))
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append((node.module, node.lineno))
        except SyntaxError:
            import_pattern = re.compile(r'^(?:from\s+(\S+)\s+)?import\s+(\S+)', re.MULTILINE)
            for match in import_pattern.finditer(source_code):
                module = match.group(1) or match.group(2)
                line_no = source_code[:match.start()].count('\n') + 1
                imports.append((module, line_no))

        return imports

    def _is_internal_import(self, import_path: str) -> bool:
        internal_prefixes = ["xingzierai", "src.xingzierai"]
        return any(import_path.startswith(prefix) for prefix in internal_prefixes)

    def _resolve_import_to_layer(self, import_path: str) -> Optional[LayerDefinition]:
        parts = import_path.split(".")

        if parts[0] == "src":
            parts = parts[1:]

        if parts and parts[0] == "xingzierai":
            module_path = "/".join(parts)
            file_path = f"src/{module_path}"

            for layer in self._layers:
                if layer.matches_path(file_path):
                    return layer

        if len(parts) >= 2:
            partial_path = f"src/xingzierai/{'/'.join(parts[1:])}"
            for layer in self._layers:
                if layer.matches_path(partial_path):
                    return layer

        return None

    def get_layer_summary(self) -> Dict[str, Any]:
        if not self._layers:
            self.load_layers_from_config()

        return {
            "total_layers": len(self._layers),
            "layers": [
                {
                    "name": l.name,
                    "level": l.level,
                    "patterns": l.path_patterns,
                    "description": l.description,
                }
                for l in sorted(self._layers, key=lambda x: x.level)
            ],
        }
