# -*- coding: utf-8 -*-
"""Rollout Persistence - Save and restore rollout trees to/from disk.

This module provides persistence for rollout trees:
1. Save tree state to JSON file
2. Load tree from JSON file
3. Session recovery after restart
4. Export tree for visualization
5. In-memory cache with periodic disk sync
"""

import asyncio
import json
import logging
import os
import shutil
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .rollout import Action, Observation, RolloutNode, RolloutTree, StateSnapshot, NodeStatus

logger = logging.getLogger(__name__)


@dataclass
class PersistedRollout:
    """Serialized rollout tree for storage."""
    version: str
    session_id: str
    created_at: float
    updated_at: float
    root_id: Optional[str]
    current_id: Optional[str]
    max_depth: int
    max_nodes: int
    statistics: Dict[str, Any]
    nodes: Dict[str, Dict[str, Any]]
    metadata: Dict[str, Any] = field(default_factory=dict)


class RolloutPersistence:
    """Persistence manager for rollout trees.

    Features:
    - Save/load rollout trees to JSON files
    - Automatic periodic saving
    - Session recovery after restart
    - Export for visualization (D3.js, etc.)
    - Cleanup of old sessions

    Storage layout:
        <base_dir>/
            sessions/
                <session_id>/
                    rollout.json        # Current tree state
                    metadata.json       # Session metadata
                    snapshots/          # State snapshots
                        <node_id>.json
                    archive/            # Old sessions
                        <session_id>_<timestamp>.json
    """

    def __init__(
        self,
        base_dir: Optional[str] = None,
        auto_save: bool = True,
        save_interval: float = 30.0,
        max_sessions: int = 100,
        retention_days: int = 7,
    ):
        """Initialize persistence manager.

        Args:
            base_dir: Base directory for storing rollout data
            auto_save: Enable automatic periodic saving
            save_interval: Seconds between auto-saves
            max_sessions: Maximum number of sessions to keep
            retention_days: Days to retain old sessions
        """
        if base_dir is None:
            base_dir = os.path.expanduser("~/.xingzierai/rollout")

        self.base_dir = Path(base_dir)
        self.auto_save = auto_save
        self.save_interval = save_interval
        self.max_sessions = max_sessions
        self.retention_days = retention_days

        self._sessions_dir = self.base_dir / "sessions"
        self._cache: Dict[str, RolloutTree] = {}
        self._last_save: Dict[str, float] = {}
        self._save_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

        self._ensure_directories()

    def _ensure_directories(self) -> None:
        """Ensure storage directories exist."""
        self._sessions_dir.mkdir(parents=True, exist_ok=True)

    def _get_session_dir(self, session_id: str) -> Path:
        """Get directory for a session."""
        return self._sessions_dir / session_id

    def _get_rollout_path(self, session_id: str) -> Path:
        """Get path to rollout.json file."""
        return self._get_session_dir(session_id) / "rollout.json"

    def _get_metadata_path(self, session_id: str) -> Path:
        """Get path to metadata.json file."""
        return self._get_session_dir(session_id) / "metadata.json"

    def _get_snapshot_path(self, session_id: str, node_id: str) -> Path:
        """Get path for a node snapshot."""
        return self._get_session_dir(session_id) / "snapshots" / f"{node_id}.json"

    def _serialize_node(self, node: RolloutNode) -> Dict[str, Any]:
        """Serialize a RolloutNode to dict."""
        return {
            "id": node.id,
            "parent_id": node.parent_id,
            "children_ids": node.children_ids,
            "action": node.action.to_dict() if node.action else None,
            "observation": node.observation.to_dict() if node.observation else None,
            "status": node.status.value,
            "state_snapshot": node.state_snapshot.to_dict() if node.state_snapshot else None,
            "created_at": node.created_at,
            "completed_at": node.completed_at,
            "duration": node.duration,
            "depth": node.depth,
            "branch_name": node.branch_name,
            "metadata": node.metadata,
        }

    def _deserialize_node(self, data: Dict[str, Any]) -> RolloutNode:
        """Deserialize a RolloutNode from dict."""
        action = None
        if data.get("action"):
            action = Action(
                action_type=data["action"].get("action_type", ""),
                content=data["action"].get("content"),
                tool_name=data["action"].get("tool_name"),
                tool_arguments=data["action"].get("tool_arguments"),
                reasoning=data["action"].get("reasoning"),
            )

        observation = None
        if data.get("observation"):
            obs_data = data["observation"]
            observation = Observation(
                observation_type=obs_data.get("observation_type", ""),
                content=obs_data.get("content"),
                success=obs_data.get("success", True),
                error_message=obs_data.get("error_message"),
                metadata=obs_data.get("metadata", {}),
            )

        state_snapshot = None
        if data.get("state_snapshot"):
            ss_data = data["state_snapshot"]
            state_snapshot = StateSnapshot(
                context=ss_data.get("context", []),
                budget_used=ss_data.get("budget_used", 0),
                budget_iterations=ss_data.get("budget_iterations", 0),
                budget_tool_calls=ss_data.get("budget_tool_calls", 0),
                breaker_failures=ss_data.get("breaker_failures", 0),
                breaker_successes=ss_data.get("breaker_successes", 0),
                breaker_state=ss_data.get("breaker_state", "closed"),
                total_llm_calls=ss_data.get("total_llm_calls", 0),
                total_tool_calls=ss_data.get("total_tool_calls", 0),
                execution_time=ss_data.get("execution_time", 0.0),
                timestamp=ss_data.get("timestamp", time.time()),
            )

        return RolloutNode(
            id=data["id"],
            parent_id=data.get("parent_id"),
            children_ids=data.get("children_ids", []),
            action=action,
            observation=observation,
            status=NodeStatus(data.get("status", "pending")),
            state_snapshot=state_snapshot,
            created_at=data.get("created_at", time.time()),
            completed_at=data.get("completed_at"),
            duration=data.get("duration", 0.0),
            depth=data.get("depth", 0),
            branch_name=data.get("branch_name"),
            metadata=data.get("metadata", {}),
        )

    def save(self, session_id: str, tree: RolloutTree, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Save rollout tree to disk.

        Args:
            session_id: Session identifier
            tree: RolloutTree to save
            metadata: Optional additional metadata

        Returns:
            True if save was successful
        """
        try:
            session_dir = self._get_session_dir(session_id)
            session_dir.mkdir(parents=True, exist_ok=True)

            persisted = PersistedRollout(
                version="1.0",
                session_id=session_id,
                created_at=tree.nodes[tree.root_id].created_at if tree.root_id and tree.root_id in tree.nodes else time.time(),
                updated_at=time.time(),
                root_id=tree.root_id,
                current_id=tree.current_id,
                max_depth=tree.max_depth,
                max_nodes=tree.max_nodes,
                statistics=tree.get_statistics(),
                nodes={node_id: self._serialize_node(node) for node_id, node in tree.nodes.items()},
                metadata=metadata or {},
            )

            rollout_path = self._get_rollout_path(session_id)
            with open(rollout_path, "w", encoding="utf-8") as f:
                json.dump(asdict(persisted), f, indent=2, ensure_ascii=False)

            metadata_path = self._get_metadata_path(session_id)
            meta = {
                "session_id": session_id,
                "saved_at": time.time(),
                "node_count": len(tree.nodes),
                "root_id": tree.root_id,
                "current_id": tree.current_id,
                **(metadata or {}),
            }
            with open(metadata_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=2, ensure_ascii=False)

            self._last_save[session_id] = time.time()
            self._cache[session_id] = tree

            logger.info(f"Saved rollout tree for session {session_id}: {len(tree.nodes)} nodes")

            return True

        except Exception as e:
            logger.error(f"Failed to save rollout tree for session {session_id}: {e}")
            return False

    def load(self, session_id: str) -> Optional[RolloutTree]:
        """Load rollout tree from disk.

        Args:
            session_id: Session identifier

        Returns:
            Loaded RolloutTree, or None if not found
        """
        if session_id in self._cache:
            return self._cache[session_id]

        rollout_path = self._get_rollout_path(session_id)
        if not rollout_path.exists():
            logger.debug(f"No rollout file found for session {session_id}")
            return None

        try:
            with open(rollout_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            persisted = PersistedRollout(**data)

            tree = RolloutTree(
                max_depth=persisted.max_depth,
                max_nodes=persisted.max_nodes,
            )

            tree.nodes = {
                node_id: self._deserialize_node(node_data)
                for node_id, node_data in persisted.nodes.items()
            }
            tree.root_id = persisted.root_id
            tree.current_id = persisted.current_id

            self._cache[session_id] = tree

            logger.info(f"Loaded rollout tree for session {session_id}: {len(tree.nodes)} nodes")

            return tree

        except Exception as e:
            logger.error(f"Failed to load rollout tree for session {session_id}: {e}")
            return None

    def exists(self, session_id: str) -> bool:
        """Check if a session exists on disk.

        Args:
            session_id: Session identifier

        Returns:
            True if session exists
        """
        return self._get_rollout_path(session_id).exists()

    def delete(self, session_id: str) -> bool:
        """Delete a session from disk.

        Args:
            session_id: Session identifier

        Returns:
            True if deletion was successful
        """
        try:
            session_dir = self._get_session_dir(session_id)
            if session_dir.exists():
                shutil.rmtree(session_dir)

            if session_id in self._cache:
                del self._cache[session_id]
            if session_id in self._last_save:
                del self._last_save[session_id]

            logger.info(f"Deleted rollout session {session_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete rollout session {session_id}: {e}")
            return False

    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all saved sessions.

        Returns:
            List of session info dicts
        """
        sessions = []

        if not self._sessions_dir.exists():
            return sessions

        for session_dir in self._sessions_dir.iterdir():
            if not session_dir.is_dir():
                continue

            metadata_path = session_dir / "metadata.json"
            if metadata_path.exists():
                try:
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    sessions.append(meta)
                except Exception as _meta_err:
                    logger.debug("Failed to read session metadata: %s", _meta_err)
                    sessions.append({
                        "session_id": session_dir.name,
                        "error": "Failed to read metadata",
                    })
            else:
                sessions.append({
                    "session_id": session_dir.name,
                    "error": "No metadata file",
                })

        sessions.sort(key=lambda x: x.get("saved_at", 0), reverse=True)
        return sessions

    def cleanup_old_sessions(self) -> int:
        """Clean up old sessions beyond retention period.

        Returns:
            Number of sessions deleted
        """
        cutoff_time = time.time() - (self.retention_days * 24 * 3600)
        deleted = 0

        for session_dir in self._sessions_dir.iterdir():
            if not session_dir.is_dir():
                continue

            metadata_path = session_dir / "metadata.json"
            if metadata_path.exists():
                try:
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    if meta.get("saved_at", 0) < cutoff_time:
                        shutil.rmtree(session_dir)
                        deleted += 1
                except Exception as _cleanup_err:
                    logger.debug("Failed to clean up old session: %s", _cleanup_err)

        logger.info(f"Cleaned up {deleted} old rollout sessions")
        return deleted

    def export_for_visualization(
        self,
        session_id: str,
        format: str = "d3",
    ) -> Optional[Dict[str, Any]]:
        """Export rollout tree in visualization format.

        Args:
            session_id: Session to export
            format: Export format ("d3", "graphviz", "json")

        Returns:
            Exported data structure, or None if not found
        """
        tree = self.load(session_id)
        if not tree:
            return None

        if format == "d3":
            return self._export_d3(tree)
        elif format == "graphviz":
            return self._export_graphviz(tree)
        else:
            return tree.to_dict()

    def _export_d3(self, tree: RolloutTree) -> Dict[str, Any]:
        """Export in D3.js hierarchical format.

        Returns:
            D3-compatible node-link data
        """
        nodes = []
        links = []

        for node_id, node in tree.nodes.items():
            node_data = {
                "id": node_id,
                "name": node.action.action_type if node.action else "unknown",
                "status": node.status.value,
                "depth": node.depth,
                "branch": node.branch_name,
                "duration": node.duration,
            }
            if node.observation:
                node_data["result"] = node.observation.observation_type
                node_data["success"] = node.observation.success
                if node.observation.error_message:
                    node_data["error"] = node.observation.error_message[:50]

            nodes.append(node_data)

            if node.parent_id:
                links.append({
                    "source": node.parent_id,
                    "target": node_id,
                })

        return {
            "nodes": nodes,
            "links": links,
            "statistics": tree.get_statistics(),
        }

    def _export_graphviz(self, tree: RolloutTree) -> str:
        """Export in Graphviz DOT format.

        Returns:
            DOT language string
        """
        lines = ["digraph RolloutTree {", '  rankdir="TB";', ""]

        for node_id, node in tree.nodes.items():
            color = {
                NodeStatus.COMPLETED: "green",
                NodeStatus.FAILED: "red",
                NodeStatus.ABANDONED: "gray",
                NodeStatus.PENDING: "orange",
                NodeStatus.RUNNING: "blue",
            }.get(node.status, "black")

            label = f"{node.action.action_type if node.action else 'unknown'}"
            if node.observation:
                label += f"\\n{node.observation.observation_type}"

            lines.append(f'  "{node_id}" [label="{label}" color={color}];')

        lines.append("")

        for node_id, node in tree.nodes.items():
            for child_id in node.children_ids:
                lines.append(f'  "{node_id}" -> "{child_id}";')

        lines.append("}")
        return "\n".join(lines)


class RolloutPersistenceAsync:
    """Async wrapper for RolloutPersistence with auto-save support.

    This class wraps RolloutPersistence with:
    - Async save/load operations
    - Background auto-save task
    - Session recovery on startup
    """

    def __init__(
        self,
        persistence: Optional[RolloutPersistence] = None,
        **kwargs,
    ):
        """Initialize async persistence wrapper.

        Args:
            persistence: Optional RolloutPersistence instance
            **kwargs: Arguments passed to RolloutPersistence if creating new
        """
        self._persistence = persistence or RolloutPersistence(**kwargs)
        self._save_task: Optional[asyncio.Task] = None
        self._running = False
        self._pending_saves: Dict[str, RolloutTree] = {}
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        """Start the auto-save background task."""
        if self._running:
            return

        self._running = True
        self._save_task = asyncio.create_task(self._auto_save_loop())
        logger.info("Started rollout auto-save background task")

    async def stop(self) -> None:
        """Stop the auto-save background task and save pending data."""
        self._running = False

        if self._save_task:
            self._save_task.cancel()
            try:
                await self._save_task
            except asyncio.CancelledError:
                pass

        async with self._lock:
            for session_id, tree in self._pending_saves.items():
                self._persistence.save(session_id, tree)

        logger.info("Stopped rollout auto-save background task")

    async def save(self, session_id: str, tree: RolloutTree) -> bool:
        """Save rollout tree asynchronously.

        Args:
            session_id: Session identifier
            tree: RolloutTree to save

        Returns:
            True if save was successful
        """
        if not self._persistence.auto_save:
            return self._persistence.save(session_id, tree)

        async with self._lock:
            self._pending_saves[session_id] = tree

        return True

    async def load(self, session_id: str) -> Optional[RolloutTree]:
        """Load rollout tree asynchronously.

        Args:
            session_id: Session identifier

        Returns:
            Loaded RolloutTree, or None if not found
        """
        return self._persistence.load(session_id)

    async def _auto_save_loop(self) -> None:
        """Background auto-save loop."""
        while self._running:
            try:
                await asyncio.sleep(self._persistence.save_interval)

                async with self._lock:
                    for session_id, tree in self._pending_saves.items():
                        if self._persistence._last_save.get(session_id, 0) + self._persistence.save_interval <= time.time():
                            self._persistence.save(session_id, tree)
                            logger.debug(f"Auto-saved session {session_id}")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in auto-save loop: {e}")

    def __getattr__(self, name: str):
        """Proxy attribute access to underlying persistence."""
        return getattr(self._persistence, name)
