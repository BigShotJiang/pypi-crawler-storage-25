"""Sherpa sentence chunking processor"""

__version__ = "1.6.142"
