#!/usr/bin/env python3
from __future__ import annotations

import fnmatch
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import tomllib
from pathlib import Path

try:
    from tools.release_gates import FLATPAK_RUNTIME_REVIEW_PATHS, LIVE_UI_RUNTIME_REVIEW_PATHS
except ModuleNotFoundError:  # pragma: no cover - direct script execution
    from release_gates import FLATPAK_RUNTIME_REVIEW_PATHS, LIVE_UI_RUNTIME_REVIEW_PATHS

ROOT = Path(__file__).resolve().parents[1]
LEAK_PATTERN = (
    r"(/home/|/Users/|(^|[^A-Za-z0-9_])secret[ \t]*[:=]|(^|[^A-Za-z0-9_])secret[_-]?key|"
    r"(^|[^A-Za-z0-9_])token[ \t]*=|(^|[^A-Za-z0-9_])token[_-]?value[ \t]*=|api[_-]?key|github_pat|"
    r"gh[pousr]_[A-Za-z0-9_]{20,}|pypi-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9_-]{20,}|"
    r"AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|BEGIN [A-Z0-9 ]*PRIVATE KEY)"
)
ALLOWED_LEAK_MATCHES = (
    "${{ github.token }}",
    "handle_token",  # XDG desktop portal public request identifier.
    "id-token: write",
)
EXTENSION_SOURCE_DIR = ROOT / "extensions" / "gnome-shell" / "mini-eq@bhack.github.io"
LEAK_SCAN_EXCLUDES = (
    ":(exclude)*.png",
    ":(exclude)AGENTS.md",
    ":(exclude)docs/release.md",
    ":(exclude)tools/release_preflight.py",
)
UNTRACKED_LEAK_SCAN_EXCLUDES = (
    "*.png",
    "AGENTS.md",
    "docs/release.md",
    "tools/release_preflight.py",
)
BACKGROUND_PORTAL_REVIEW_PATHS = (
    Path("io.github.bhack.mini-eq.yaml"),
    Path("src/mini_eq/app.py"),
    Path("src/mini_eq/background.py"),
    Path("src/mini_eq/cli.py"),
    Path("src/mini_eq/dbus_control.py"),
    Path("src/mini_eq/window.py"),
    Path("src/mini_eq/window_preferences.py"),
    Path("extensions/gnome-shell/mini-eq@bhack.github.io/extension.js"),
)
AUTOEQ_LIVE_REVIEW_PATHS = (
    Path(".github/workflows/autoeq-live.yml"),
    Path("src/mini_eq/autoeq.py"),
    Path("src/mini_eq/window_autoeq.py"),
    Path("tests/test_mini_eq_autoeq.py"),
    Path("tools/check_autoeq_live.py"),
)
PIPEWIRE_GOBJECT_BUILD_TOOLS = ("g-ir-compiler", "g-ir-scanner", "pkg-config")
PIPEWIRE_GOBJECT_PKG_CONFIG_MODULES = ("glib-2.0", "gio-2.0", "gobject-2.0", "libpipewire-0.3")
PIPEWIRE_GOBJECT_DEBIAN_BUILD_PACKAGES = (
    "build-essential",
    "gobject-introspection",
    "libgirepository1.0-dev",
    "libglib2.0-dev",
    "libpipewire-0.3-dev",
    "pkg-config",
)
FLATPAK_MANIFEST = ROOT / "io.github.bhack.mini-eq.yaml"


def format_command(command: list[str | Path]) -> str:
    return " ".join(shlex.quote(str(part)) for part in command)


def run(command: list[str | Path], *, cwd: Path = ROOT, env: dict[str, str] | None = None) -> None:
    print(f"\n$ {format_command(command)}", flush=True)
    command_env = None
    if env is not None:
        command_env = os.environ.copy()
        command_env.update(env)
    subprocess.run([str(part) for part in command], cwd=cwd, check=True, env=command_env)


def git_stdout(*args: str | Path) -> str:
    result = subprocess.run(
        ["git", *(str(arg) for arg in args)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


def require_tools(*tools: str) -> None:
    missing = [tool for tool in tools if shutil.which(tool) is None]
    if missing:
        raise SystemExit(f"Missing required release tool(s): {', '.join(missing)}")


def source_tree_python_env() -> dict[str, str]:
    src_path = str(ROOT / "src")
    pythonpath = os.environ.get("PYTHONPATH")
    if pythonpath:
        src_path = os.pathsep.join((src_path, pythonpath))
    return {"PYTHONPATH": src_path}


def bounded_int_env(name: str, default: int, *, minimum: int, maximum: int) -> str:
    value = os.environ.get(name, str(default)).strip()
    try:
        parsed = int(value)
    except ValueError:
        raise SystemExit(f"{name} must be an integer between {minimum} and {maximum}") from None

    if not minimum <= parsed <= maximum:
        raise SystemExit(f"{name} must be an integer between {minimum} and {maximum}")

    return str(parsed)


def allowed_leak_match(line: str) -> bool:
    return any(allowed in line for allowed in ALLOWED_LEAK_MATCHES)


def current_release_tag() -> str:
    with (ROOT / "pyproject.toml").open("rb") as pyproject_file:
        project = tomllib.load(pyproject_file)["project"]
    return f"v{project['version']}"


def pipewire_gobject_requirement(root: Path = ROOT) -> str:
    with (root / "pyproject.toml").open("rb") as pyproject_file:
        project = tomllib.load(pyproject_file)["project"]

    for dependency in project["dependencies"]:
        if dependency.lower().startswith("pipewire-gobject"):
            return dependency
    raise SystemExit("pyproject.toml does not declare a pipewire-gobject dependency")


def pipewire_gobject_floor_version(root: Path = ROOT) -> str:
    requirement = pipewire_gobject_requirement(root)
    match = re.search(r">=\s*([0-9]+\.[0-9]+\.[0-9]+)", requirement)
    if match is None:
        raise SystemExit("pipewire-gobject dependency does not declare a minimum version")
    return match.group(1)


def flatpak_pipewire_gobject_tag(manifest: Path = FLATPAK_MANIFEST) -> str:
    in_pipewire_gobject_module = False

    for line in manifest.read_text(encoding="utf-8").splitlines():
        if re.match(r"\s*-\s+name:\s+", line):
            in_pipewire_gobject_module = re.match(r"\s*-\s+name:\s+pipewire-gobject\s*$", line) is not None
            continue

        if not in_pipewire_gobject_module:
            continue

        tag = re.match(r"\s*tag:\s*([^\s#]+)", line)
        if tag is not None:
            return tag.group(1).strip("\"'")

    raise SystemExit(f"{manifest.relative_to(ROOT)} does not pin a pipewire-gobject tag")


def check_flatpak_pipewire_gobject_pin(root: Path = ROOT) -> None:
    floor_version = pipewire_gobject_floor_version(root)
    manifest = root / "io.github.bhack.mini-eq.yaml"
    bundled_version = flatpak_pipewire_gobject_tag(manifest)

    if bundled_version == floor_version:
        return

    raise SystemExit(
        "\n".join(
            [
                "Flatpak pipewire-gobject source is not aligned with Mini EQ's runtime floor.",
                f"pyproject.toml requires pipewire-gobject>={floor_version}, but "
                f"{manifest.relative_to(root)} bundles tag {bundled_version}.",
                f"Publish pipewire-gobject {floor_version} first, then update the Flatpak manifest "
                "to that published tag and its peeled commit before releasing Mini EQ.",
            ]
        )
    )


def git_tag_exists(tag: str) -> bool:
    result = subprocess.run(
        ["git", "rev-parse", "-q", "--verify", f"refs/tags/{tag}"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.returncode == 0


def extension_comparison_base_tag() -> str | None:
    current_tag = current_release_tag()
    if git_tag_exists(current_tag):
        return current_tag

    tags = git_stdout("tag", "--list", "v[0-9]*", "--sort=-v:refname").splitlines()
    return tags[0] if tags else None


def run_gnome_shell_extension_upload_notice() -> None:
    base_tag = extension_comparison_base_tag()
    if base_tag is None:
        print("\nGNOME Shell extension upload notice skipped; no release tag found.")
        return

    extension_path = EXTENSION_SOURCE_DIR.relative_to(ROOT)
    committed_changes = git_stdout("diff", "--name-only", f"{base_tag}..HEAD", "--", extension_path).splitlines()
    worktree_changes = git_stdout("status", "--short", "--", extension_path).splitlines()

    if not committed_changes and not worktree_changes:
        print(f"\nGNOME Shell extension upload not indicated; no publishable extension changes since {base_tag}.")
        return

    print(f"\nGNOME Shell extension upload may be needed; publishable extension source changed since {base_tag}:")
    for path in committed_changes:
        print(f"  {path}")
    for status_line in worktree_changes:
        print(f"  {status_line}")
    print("Build and test the extension zip before uploading it to extensions.gnome.org.")


def changed_paths_for_review(base_tag: str, paths: tuple[Path, ...]) -> list[str]:
    path_args = [path.as_posix() for path in paths]
    committed_changes = git_stdout("diff", "--name-only", f"{base_tag}..HEAD", "--", *path_args).splitlines()
    worktree_changes = git_stdout("status", "--short", "--", *path_args).splitlines()
    return [*committed_changes, *worktree_changes]


def run_background_portal_smoke_notice() -> None:
    base_tag = extension_comparison_base_tag()
    if base_tag is None:
        print("\nFlatpak background portal smoke notice skipped; no release tag found.")
        return

    changes = changed_paths_for_review(base_tag, BACKGROUND_PORTAL_REVIEW_PATHS)
    if not changes:
        print(f"\nFlatpak background portal smoke not indicated; background integration unchanged since {base_tag}.")
        return

    print(f"\nFlatpak background portal smoke may be needed; background integration changed since {base_tag}:")
    for path in changes:
        print(f"  {path}")
    print("Run one clean-permission Flatpak portal smoke in a real GNOME session before releasing this change.")


def run_autoeq_live_check_notice() -> None:
    base_tag = extension_comparison_base_tag()
    if base_tag is None:
        print("\nAutoEQ.app live compatibility notice skipped; no release tag found.")
        return

    changes = changed_paths_for_review(base_tag, AUTOEQ_LIVE_REVIEW_PATHS)
    if not changes:
        print(f"\nAutoEQ.app live compatibility check not indicated; AutoEQ integration unchanged since {base_tag}.")
        return

    print(f"\nAutoEQ.app live compatibility check may be needed; AutoEQ integration changed since {base_tag}:")
    for path in changes:
        print(f"  {path}")
    print(
        "Run python3 tools/check_autoeq_live.py before release. A failure is a live-service or format-drift "
        "signal to investigate, not an automatic blocker for unrelated fixes."
    )


def run_flatpak_runtime_smoke_notice() -> None:
    base_tag = extension_comparison_base_tag()
    if base_tag is None:
        print("\nFlatpak runtime smoke notice skipped; no release tag found.")
        return

    changes = changed_paths_for_review(base_tag, FLATPAK_RUNTIME_REVIEW_PATHS)
    if not changes:
        print(f"\nFlatpak runtime smoke not indicated; runtime integration unchanged since {base_tag}.")
        return

    print(f"\nFlatpak runtime smoke may be needed; runtime integration changed since {base_tag}:")
    for path in changes:
        print(f"  {path}")
    print(
        "Run the installed Flatpak runtime smoke and interactive audio check before releasing this change. "
        "The Release workflow also blocks public publish dispatches on the isolated Flatpak routing smoke."
    )


def run_live_ui_runtime_smoke_notice() -> None:
    base_tag = extension_comparison_base_tag()
    if base_tag is None:
        print("\nLive UI runtime smoke notice skipped; no release tag found.")
        return

    changes = changed_paths_for_review(base_tag, LIVE_UI_RUNTIME_REVIEW_PATHS)
    if not changes:
        print(f"\nLive UI runtime smoke not indicated; app and UI runtime integration unchanged since {base_tag}.")
        return

    print(f"\nLive UI runtime smoke may be needed; app or UI runtime integration changed since {base_tag}:")
    for path in changes:
        print(f"  {path}")
    print(
        "Run the live GTK/AT-SPI/PipeWire smoke on a supported recent GNOME/GTK stack before "
        "releasing this change. The Release workflow does not treat the hosted native Ubuntu GTK "
        "stack as the blocking UI runtime."
    )


def run_leak_scan() -> None:
    run(["git", "rev-list", "--count", "HEAD"])
    run(["git", "ls-remote", "--heads", "origin"])
    run(["git", "ls-remote", "--tags", "origin"])

    matches = [
        *git_leak_matches(
            [
                "git",
                "grep",
                "-n",
                "-I",
                "-E",
                LEAK_PATTERN,
                "HEAD",
                "--",
                ".",
                *LEAK_SCAN_EXCLUDES,
            ]
        ),
        *git_leak_matches(
            [
                "git",
                "grep",
                "-n",
                "-I",
                "-E",
                LEAK_PATTERN,
                "--",
                ".",
                *LEAK_SCAN_EXCLUDES,
            ]
        ),
        *untracked_leak_matches(),
    ]
    unexpected = [line for line in matches if not allowed_leak_match(line)]
    if unexpected:
        print("\nUnexpected leak-scan matches:", file=sys.stderr)
        for line in unexpected:
            print(line, file=sys.stderr)
        raise SystemExit(1)

    if matches:
        print("Leak scan found only allowed non-secret references.")
    else:
        print("Leak scan found no matches.")


def git_leak_matches(command: list[str]) -> list[str]:
    print(f"\n$ {format_command(command)}", flush=True)
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)

    if result.returncode not in (0, 1):
        sys.stderr.write(result.stderr)
        raise SystemExit(result.returncode)

    return result.stdout.splitlines()


def untracked_leak_matches() -> list[str]:
    command = ["git", "ls-files", "--others", "--exclude-standard", "-z", "--", "."]
    print(f"\n$ {format_command(command)}", flush=True)
    result = subprocess.run(command, cwd=ROOT, capture_output=True, check=True)
    paths = [Path(os.fsdecode(path)) for path in result.stdout.split(b"\0") if path]
    leak_re = re.compile(LEAK_PATTERN)
    matches: list[str] = []

    for relative_path in paths:
        path_text = relative_path.as_posix()
        if any(fnmatch.fnmatch(path_text, pattern) for pattern in UNTRACKED_LEAK_SCAN_EXCLUDES):
            continue

        path = ROOT / relative_path
        try:
            payload = path.read_bytes()
        except OSError:
            continue

        if b"\0" in payload:
            continue

        for line_number, line in enumerate(payload.decode("utf-8", errors="ignore").splitlines(), start=1):
            if leak_re.search(line):
                matches.append(f"{path_text}:{line_number}:{line}")

    return matches


def missing_pkg_config_modules(modules: tuple[str, ...]) -> list[str]:
    missing: list[str] = []
    for module in modules:
        result = subprocess.run(
            ["pkg-config", "--exists", module],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode != 0:
            missing.append(module)
    return missing


def check_pipewire_gobject_sdist_build_environment() -> None:
    missing_tools = [tool for tool in PIPEWIRE_GOBJECT_BUILD_TOOLS if shutil.which(tool) is None]
    missing_modules = (
        list(PIPEWIRE_GOBJECT_PKG_CONFIG_MODULES)
        if shutil.which("pkg-config") is None
        else missing_pkg_config_modules(PIPEWIRE_GOBJECT_PKG_CONFIG_MODULES)
    )
    if not missing_tools and not missing_modules:
        return

    details: list[str] = [
        "The release wheel smoke installs Mini EQ in a fresh venv and must be able to build "
        "pipewire-gobject from its sdist.",
        "Install the PipeWire/GObject build dependencies first.",
        "",
        "Debian/Ubuntu:",
        f"  sudo apt install {' '.join(PIPEWIRE_GOBJECT_DEBIAN_BUILD_PACKAGES)}",
    ]
    if missing_tools:
        details.append(f"Missing tools: {', '.join(missing_tools)}")
    if missing_modules:
        details.append(f"Missing pkg-config modules: {', '.join(missing_modules)}")
    raise SystemExit("\n".join(details))


def run_wheel_smoke_test(python: Path, wheel: Path, scratch: Path) -> None:
    venv = scratch / "wheel-test"
    run([python, "-m", "venv", "--system-site-packages", venv])

    bin_dir = venv / ("Scripts" if os.name == "nt" else "bin")
    venv_python = bin_dir / "python"
    mini_eq = bin_dir / ("mini-eq.exe" if os.name == "nt" else "mini-eq")

    run([venv_python, "-m", "pip", "install", "--upgrade", "pip"])
    check_pipewire_gobject_sdist_build_environment()
    run([venv_python, "-m", "pip", "install", wheel])
    run([mini_eq, "--check-deps"])
    run([mini_eq, "--help"])


def run_build_checks(python: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="mini-eq-release-preflight-") as temp_dir:
        scratch = Path(temp_dir)
        dist = scratch / "dist"

        run([python, "-m", "build", "--outdir", dist])

        artifacts = sorted(dist.iterdir())
        run([python, "-m", "twine", "check", *artifacts])

        wheels = sorted(dist.glob("*.whl"))
        if not wheels:
            raise SystemExit("Build did not produce a wheel")
        run_wheel_smoke_test(python, wheels[0], scratch)


def run_headless_pipewire_runtime_smoke(python: Path) -> None:
    timeout = bounded_int_env("MINI_EQ_HEADLESS_PIPEWIRE_TIMEOUT", 90, minimum=1, maximum=600)
    cycles = bounded_int_env("MINI_EQ_HEADLESS_PIPEWIRE_CYCLES", 2, minimum=1, maximum=20)
    audio_duration = bounded_int_env(
        "MINI_EQ_HEADLESS_PIPEWIRE_AUDIO_DURATION",
        180,
        minimum=1,
        maximum=3600,
    )
    idle_gap = bounded_int_env("MINI_EQ_HEADLESS_PIPEWIRE_IDLE_GAP", 8, minimum=0, maximum=600)
    run(
        [
            python,
            ROOT / "tools/check_headless_pipewire_runtime.py",
            "--timeout",
            timeout,
            "--cycles",
            cycles,
            "--audio-duration",
            audio_duration,
            "--idle-gap",
            idle_gap,
        ]
    )


def main() -> int:
    python = Path(sys.executable)
    require_tools("appstreamcli", "desktop-file-validate", "git", "gnome-extensions")

    run(["git", "diff", "--check"])
    run([python, "-m", "pytest", "tests/test_version_metadata.py", "-q"])
    check_flatpak_pipewire_gobject_pin()
    run([python, ROOT / "tools/check_gnome_shell_extension.py"])
    run_gnome_shell_extension_upload_notice()
    run_flatpak_runtime_smoke_notice()
    run_live_ui_runtime_smoke_notice()
    run_background_portal_smoke_notice()
    run_autoeq_live_check_notice()
    run([python, "-m", "ruff", "check", "."])
    run([python, "-m", "ruff", "format", "--check", "."])
    run([python, "-m", "pytest", "-q"])
    run([python, "-m", "mini_eq", "--check-deps"], env=source_tree_python_env())
    run_headless_pipewire_runtime_smoke(python)
    run(["appstreamcli", "validate", "--no-net", ROOT / "data/io.github.bhack.mini-eq.metainfo.xml"])
    run(["desktop-file-validate", ROOT / "data/io.github.bhack.mini-eq.desktop"])
    run_build_checks(python)
    run_leak_scan()

    print("\nRelease preflight completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
