# Mixed Lambda posture, expanded in rev 2 to exercise both Tier 2 #1's
# aws.lambda_logging_configured AND Tier 2 #2's aws.lambda_env_kms_encryption.
#
#   - api_handler         — function WITH a matching aws_cloudwatch_log_group
#                           AND env-vars + explicit kms_key_arn (positive on
#                           BOTH detectors).
#   - background_worker   — function WITHOUT a matching log group AND
#                           env-vars but NO kms_key_arn (negative on BOTH
#                           detectors -- the canonical gap shape).

resource "aws_iam_role" "lambda_exec" {
  name = "serverless-mixed-lambda-exec"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_kms_key" "lambda_env_secrets" {
  description         = "CMK for Lambda env-var secret encryption"
  enable_key_rotation = true
}

resource "aws_lambda_function" "api_handler" {
  function_name = "api-handler"
  role          = aws_iam_role.lambda_exec.arn
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "api_handler.zip"
  kms_key_arn   = aws_kms_key.lambda_env_secrets.arn

  environment {
    variables = {
      DATABASE_URL = "postgres://..."
      API_TOKEN    = "..."
    }
  }
}

resource "aws_cloudwatch_log_group" "api_handler_logs" {
  name              = "/aws/lambda/api-handler"
  retention_in_days = 90
}

resource "aws_lambda_function" "background_worker" {
  function_name = "background-worker"
  role          = aws_iam_role.lambda_exec.arn
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "background_worker.zip"
  # No matching aws_cloudwatch_log_group declared (logging gap)
  # AND env-vars without kms_key_arn (KMS gap).

  environment {
    variables = {
      LOG_LEVEL = "INFO"
    }
  }
}
