# Mixed API Gateway posture, expanded in rev 2 to exercise both Tier 2 #1's
# aws.api_gateway_tls_min_version AND Tier 2 #2's
# aws.api_gateway_access_logging.
#
# Custom domains (TLS-floor posture):
#   - public_api_v1     — REST v1 custom domain on TLS_1_2 (positive)
#   - legacy_api_v1     — REST v1 custom domain with security_policy
#                         omitted; AWS provider defaults to TLS_1_0
#                         (negative -- the legacy gap).
#   - public_api_v2     — HTTP v2 custom domain (positive: v2 only
#                         supports TLS_1_2).
#
# Stages (access-logging posture, rev 2):
#   - public_api_v1_prod_stage      — REST v1 stage WITH access_log_settings
#                                     (positive on access_logging detector).
#   - public_api_v1_staging_stage   — REST v1 stage WITHOUT access_log_settings
#                                     (negative -- request-path-blind gap).
#   - public_api_v2_default_stage   — HTTP v2 stage WITH access_log_settings
#                                     (positive on access_logging detector).

resource "aws_api_gateway_domain_name" "public_api_v1" {
  domain_name              = "api.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/api-cert"
  security_policy          = "TLS_1_2"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_domain_name" "legacy_api_v1" {
  domain_name              = "legacy.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/legacy-cert"
  # security_policy omitted; AWS provider defaults to TLS_1_0 -- the gap.

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_apigatewayv2_domain_name" "public_api_v2" {
  domain_name = "v2.serverless-mixed.example.com"

  domain_name_configuration {
    certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/v2-cert"
    endpoint_type   = "REGIONAL"
    security_policy = "TLS_1_2"
  }
}

# --- Stages (rev 2) ---

resource "aws_cloudwatch_log_group" "api_access_logs" {
  name              = "/aws/apigateway/serverless-mixed"
  retention_in_days = 365
}

resource "aws_api_gateway_stage" "public_api_v1_prod_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-prod-id-placeholder"
  stage_name    = "prod"

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.resourcePath $context.status $context.responseLength"
  }
}

resource "aws_api_gateway_stage" "public_api_v1_staging_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-staging-id-placeholder"
  stage_name    = "staging"
  # No access_log_settings block -- the request-path audit trail gap.
}

resource "aws_apigatewayv2_stage" "public_api_v2_default_stage" {
  api_id      = "v2-api-id-placeholder"
  name        = "$default"
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.routeKey $context.status"
  }
}
