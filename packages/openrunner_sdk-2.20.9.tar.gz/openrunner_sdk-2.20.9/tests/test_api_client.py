"""Tests for the OpenRunner API client."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock, patch

import httpx
import pytest

from openrunner.api_client import APIClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_transport(status_code: int = 200, json_data: dict | None = None):
    """Build an httpx.MockTransport that returns *json_data*."""
    import json as _json

    body = _json.dumps(json_data or {}).encode()

    def _handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, content=body)

    return httpx.MockTransport(_handler)


# ---------------------------------------------------------------------------
# create_run
# ---------------------------------------------------------------------------

class TestCreateRun:
    def test_sends_post_and_returns_response(self):
        resp_data = {"id": "abc12345", "state": "running"}
        transport = _mock_transport(201, resp_data)
        client = APIClient("http://localhost:8000", "or_testkey", transport=transport)

        result = client.create_run({"project": "test", "display_name": "run-1"})

        assert result == resp_data

    def test_includes_auth_header(self):
        """Authorization header is set on the underlying httpx client."""
        transport = _mock_transport(201, {"id": "x"})
        client = APIClient("http://localhost:8000", "or_key123", transport=transport)
        assert client._client.headers["authorization"] == "Bearer or_key123"


# ---------------------------------------------------------------------------
# update_run
# ---------------------------------------------------------------------------

class TestUpdateRun:
    def test_sends_patch_and_returns_response(self):
        resp_data = {"id": "abc12345", "state": "finished"}
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        result = client.update_run("abc12345", {"state": "finished", "summary": {}})

        assert result == resp_data


# ---------------------------------------------------------------------------
# post_metrics
# ---------------------------------------------------------------------------

class TestPostMetrics:
    def test_sends_batch_and_returns_count(self):
        transport = _mock_transport(200, {"count": 3})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        metrics = [
            {"key": "loss", "value": 0.5, "step": 1, "timestamp": "2026-01-01T00:00:00Z"},
            {"key": "acc", "value": 0.8, "step": 1, "timestamp": "2026-01-01T00:00:00Z"},
            {"key": "loss", "value": 0.3, "step": 2, "timestamp": "2026-01-01T00:00:01Z"},
        ]
        count = client.post_metrics("abc12345", metrics)

        assert count == 3


# ---------------------------------------------------------------------------
# post_heartbeat
# ---------------------------------------------------------------------------

class TestPostHeartbeat:
    def test_sends_heartbeat(self):
        transport = _mock_transport(200, {"status": "ok"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        # Should not raise
        client.post_heartbeat("abc12345")


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_server_500_returns_none_on_create(self, caplog):
        transport = _mock_transport(500, {"detail": "Internal Server Error"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            result = client.create_run({"project": "test"})

        assert result is None
        assert "create_run" in caplog.text or "failed" in caplog.text.lower()

    def test_server_500_returns_none_on_update(self, caplog):
        transport = _mock_transport(500, {"detail": "error"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            result = client.update_run("abc", {"state": "finished"})

        assert result is None

    def test_server_500_returns_zero_on_metrics(self, caplog):
        transport = _mock_transport(500, {"detail": "error"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            count = client.post_metrics("abc", [{"key": "x", "value": 1, "step": 0}])

        assert count == 0

    def test_connection_error_returns_none(self, caplog):
        """Network failure should be caught and logged, not raised."""
        # Use a transport that raises
        def _raise(request):
            raise httpx.ConnectError("Connection refused")

        transport = httpx.MockTransport(_raise)
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            result = client.create_run({"project": "test"})

        assert result is None

    def test_heartbeat_failure_is_logged(self, caplog):
        transport = _mock_transport(500, {"detail": "error"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            client.post_heartbeat("abc")
        # Should not raise


# ---------------------------------------------------------------------------
# close
# ---------------------------------------------------------------------------

class TestClose:
    def test_close_does_not_raise(self):
        transport = _mock_transport(200, {})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)
        client.close()  # Should not raise
