"""Tests for openrunner.summary.Summary object."""

from __future__ import annotations

from openrunner.summary import Summary


class TestSummaryAutoUpdate:
    """Test auto-update behavior from log() calls."""

    def test_auto_update_sets_values(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5, "acc": 0.8})
        assert summary["loss"] == 0.5
        assert summary["acc"] == 0.8

    def test_auto_update_overwrites_previous(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        summary._auto_update({"loss": 0.3})
        assert summary["loss"] == 0.3

    def test_auto_update_merges_keys(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        summary._auto_update({"acc": 0.9})
        assert summary["loss"] == 0.5
        assert summary["acc"] == 0.9


class TestSummaryExplicitSet:
    """Test explicit set overrides auto-update."""

    def test_explicit_set_via_item(self) -> None:
        summary = Summary()
        summary["best_loss"] = 0.1
        assert summary["best_loss"] == 0.1

    def test_explicit_set_via_attr(self) -> None:
        summary = Summary()
        summary.best_loss = 0.1
        assert summary.best_loss == 0.1

    def test_explicit_overrides_auto(self) -> None:
        summary = Summary()
        summary["loss"] = 0.1  # explicit
        summary._auto_update({"loss": 0.5})  # auto should NOT override
        assert summary["loss"] == 0.1

    def test_auto_does_not_override_explicit(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        summary["loss"] = 0.1  # explicit override
        summary._auto_update({"loss": 0.3})  # auto should NOT override explicit
        assert summary["loss"] == 0.1


class TestSummaryAsDict:
    """Test as_dict() output."""

    def test_as_dict_returns_all_values(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        summary["best_loss"] = 0.1
        d = summary.as_dict()
        assert d == {"loss": 0.5, "best_loss": 0.1}

    def test_as_dict_empty(self) -> None:
        summary = Summary()
        assert summary.as_dict() == {}


class TestSummaryUpdatePayload:
    """Test _get_update_payload() for changed keys."""

    def test_payload_after_auto_update(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        payload = summary._get_update_payload()
        assert "loss" in payload
        assert payload["loss"] == 0.5

    def test_payload_empty_after_get(self) -> None:
        summary = Summary()
        summary._auto_update({"loss": 0.5})
        summary._get_update_payload()
        # Second call should return empty (nothing changed)
        payload = summary._get_update_payload()
        assert payload == {}

    def test_payload_tracks_explicit_changes(self) -> None:
        summary = Summary()
        summary["best_loss"] = 0.1
        payload = summary._get_update_payload()
        assert payload == {"best_loss": 0.1}
