"""Tests for the Keras / TensorFlow integration (OpenRunnerCallback)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Mock keras before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_keras(monkeypatch):
    """Inject a fake keras module so keras.py imports cleanly."""
    keras = types.ModuleType("keras")
    keras_callbacks = types.ModuleType("keras.callbacks")

    class _Callback:
        """Fake base Callback class."""
        def __init__(self, **kwargs):
            pass

    keras_callbacks.Callback = _Callback
    keras.callbacks = keras_callbacks

    monkeypatch.setitem(sys.modules, "keras", keras)
    monkeypatch.setitem(sys.modules, "keras.callbacks", keras_callbacks)
    yield
    # Clean up cached module
    sys.modules.pop("openrunner.integration.keras", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerKerasCallback:
    """Tests for the Keras OpenRunnerCallback."""

    def test_on_train_begin_calls_init(self, monkeypatch):
        """on_train_begin calls openrunner.init() when no active run."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock(return_value=MagicMock())
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback(project="keras-project", config={"lr": 0.001})
        cb.on_train_begin()

        mock_init.assert_called_once_with(project="keras-project", config={"lr": 0.001})

    def test_on_train_begin_skips_if_active_run(self, monkeypatch):
        """on_train_begin does not call init() if a run is already active."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.on_train_begin()

        mock_init.assert_not_called()

    def test_on_epoch_end_logs_metrics(self, monkeypatch):
        """on_epoch_end logs numeric metrics from the logs dict."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.on_epoch_end(epoch=3, logs={"loss": 0.25, "accuracy": 0.92})

        mock_log.assert_called_once_with(
            {"loss": 0.25, "accuracy": 0.92}, step=3
        )

    def test_on_epoch_end_filters_non_numeric(self, monkeypatch):
        """on_epoch_end filters out non-numeric values."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.on_epoch_end(epoch=1, logs={"loss": 0.5, "status": "training", "none_val": None})

        logged_data = mock_log.call_args[0][0]
        assert "loss" in logged_data
        assert "status" not in logged_data
        assert "none_val" not in logged_data

    def test_on_epoch_end_noop_if_no_active_run(self, monkeypatch):
        """on_epoch_end is a no-op if no active run."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback()
        cb.on_epoch_end(epoch=0, logs={"loss": 0.5})

        mock_log.assert_not_called()

    def test_on_train_end_calls_finish(self, monkeypatch):
        """on_train_end calls openrunner.finish()."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.finish", mock_finish)

        cb = OpenRunnerCallback()
        cb.on_train_end()

        mock_finish.assert_called_once()

    def test_on_epoch_end_noop_if_no_logs(self, monkeypatch):
        """on_epoch_end is a no-op if logs is None."""
        from openrunner.integration.keras import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.on_epoch_end(epoch=0, logs=None)

        mock_log.assert_not_called()


class TestKerasImportError:
    """ImportError when keras is missing."""

    def test_import_error_when_keras_missing(self, monkeypatch, block_import):
        block_import("keras")
        block_import("tensorflow")
        import sys
        sys.modules.pop("openrunner.integration.keras", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.keras  # noqa: F401
