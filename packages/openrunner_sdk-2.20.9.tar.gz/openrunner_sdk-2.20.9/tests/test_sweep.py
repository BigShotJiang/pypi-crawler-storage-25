"""Tests for SDK sweep config parsing and agent loop with mock."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from openrunner.sweep import sweep, agent


# ---------------------------------------------------------------------------
# sweep() tests
# ---------------------------------------------------------------------------


class TestSweepCreate:
    """Tests for openrunner.sweep() -- creating a sweep on the server."""

    def test_sweep_returns_none_without_api_key(self, clean_env):
        """sweep() returns None when no API key is set."""
        result = sweep(
            {"method": "random", "parameters": {"lr": {"min": 0.01, "max": 0.1}}},
            project="test-project",
        )
        assert result is None

    def test_sweep_returns_none_without_project(self, clean_env):
        """sweep() returns None when no project is specified."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        # No project arg or env var
        result = sweep({"method": "random", "parameters": {}})
        assert result is None

    @patch("openrunner.sweep.httpx.Client")
    def test_sweep_creates_sweep_on_server(self, MockClient, clean_env):
        """sweep() creates a sweep and returns the sweep ID."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        # Mock list projects
        mock_projects_resp = MagicMock()
        mock_projects_resp.status_code = 200
        mock_projects_resp.json.return_value = [
            {"id": "proj-123", "name": "my-project"}
        ]
        mock_projects_resp.raise_for_status = MagicMock()

        # Mock create sweep
        mock_create_resp = MagicMock()
        mock_create_resp.status_code = 201
        mock_create_resp.json.return_value = {"id": "sweep-abc-123"}
        mock_create_resp.raise_for_status = MagicMock()

        mock_client.get.return_value = mock_projects_resp
        mock_client.post.return_value = mock_create_resp

        config = {
            "name": "test-sweep",
            "method": "bayes",
            "metric": {"name": "val_loss", "goal": "minimize"},
            "parameters": {
                "lr": {"min": 0.0001, "max": 0.1, "distribution": "log_uniform_values"},
                "batch_size": {"values": [16, 32, 64]},
            },
            "early_terminate": {"type": "hyperband", "min_iter": 3, "eta": 3},
        }

        result = sweep(config, project="my-project")

        assert result == "sweep-abc-123"
        mock_client.get.assert_called_once_with("/projects")
        mock_client.post.assert_called_once()
        call_args = mock_client.post.call_args
        assert "sweeps" in call_args[0][0]

    @patch("openrunner.sweep.httpx.Client")
    def test_sweep_project_not_found(self, MockClient, clean_env):
        """sweep() returns None when project is not found."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_client.get.return_value = mock_resp

        result = sweep(
            {"method": "random", "parameters": {}},
            project="nonexistent",
        )
        assert result is None


# ---------------------------------------------------------------------------
# agent() tests
# ---------------------------------------------------------------------------


class TestSweepAgent:
    """Tests for openrunner.agent() -- the sweep agent loop."""

    def test_agent_returns_without_function(self, clean_env):
        """agent() returns immediately when no function is provided."""
        agent("sweep-123", function=None)
        # Should not raise

    def test_agent_returns_without_api_key(self, clean_env):
        """agent() returns immediately when no API key is set."""
        agent("sweep-123", function=lambda p: None)
        # Should not raise

    @patch("openrunner.sweep.httpx.Client")
    def test_agent_runs_function_with_params(self, MockClient, clean_env):
        """agent() calls function with suggested params."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        # First suggest: return params
        suggest_resp1 = MagicMock()
        suggest_resp1.json.return_value = {
            "params": {"lr": 0.01, "batch_size": 32},
            "finished": False,
        }
        suggest_resp1.raise_for_status = MagicMock()

        # Second suggest: finished
        suggest_resp2 = MagicMock()
        suggest_resp2.json.return_value = {"params": {}, "finished": True}
        suggest_resp2.raise_for_status = MagicMock()

        # Report response
        report_resp = MagicMock()
        report_resp.json.return_value = {
            "is_best": True,
            "early_stop": False,
        }
        report_resp.raise_for_status = MagicMock()

        mock_client.post.side_effect = [suggest_resp1, report_resp, suggest_resp2]

        calls = []

        def train_fn(params):
            calls.append(params)
            return 0.5  # Return metric value

        agent("sweep-123", function=train_fn)

        assert len(calls) == 1
        assert calls[0] == {"lr": 0.01, "batch_size": 32}

    @patch("openrunner.sweep.httpx.Client")
    def test_agent_respects_count_limit(self, MockClient, clean_env):
        """agent() stops after count runs."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        # Always return params
        suggest_resp = MagicMock()
        suggest_resp.json.return_value = {
            "params": {"lr": 0.01},
            "finished": False,
        }
        suggest_resp.raise_for_status = MagicMock()

        report_resp = MagicMock()
        report_resp.json.return_value = {
            "is_best": False,
            "early_stop": False,
        }
        report_resp.raise_for_status = MagicMock()

        mock_client.post.side_effect = [
            suggest_resp, report_resp,  # Run 1
            suggest_resp, report_resp,  # Run 2
            suggest_resp, report_resp,  # Run 3 (should not happen)
        ]

        calls = []

        def train_fn(params):
            calls.append(params)
            return 0.5

        agent("sweep-123", function=train_fn, count=2)

        assert len(calls) == 2

    @patch("openrunner.sweep.httpx.Client")
    def test_agent_stops_on_early_stop(self, MockClient, clean_env):
        """agent() stops when server signals early_stop."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        suggest_resp = MagicMock()
        suggest_resp.json.return_value = {
            "params": {"lr": 0.01},
            "finished": False,
        }
        suggest_resp.raise_for_status = MagicMock()

        report_resp = MagicMock()
        report_resp.json.return_value = {
            "is_best": False,
            "early_stop": True,
        }
        report_resp.raise_for_status = MagicMock()

        mock_client.post.side_effect = [suggest_resp, report_resp]

        calls = []

        def train_fn(params):
            calls.append(params)
            return 0.9

        agent("sweep-123", function=train_fn)

        # Only one run before early stop
        assert len(calls) == 1

    @patch("openrunner.sweep.httpx.Client")
    def test_agent_handles_function_exception(self, MockClient, clean_env):
        """agent() continues when training function raises an exception."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        suggest_resp1 = MagicMock()
        suggest_resp1.json.return_value = {
            "params": {"lr": 0.01},
            "finished": False,
        }
        suggest_resp1.raise_for_status = MagicMock()

        suggest_resp2 = MagicMock()
        suggest_resp2.json.return_value = {"params": {}, "finished": True}
        suggest_resp2.raise_for_status = MagicMock()

        mock_client.post.side_effect = [suggest_resp1, suggest_resp2]

        call_count = 0

        def train_fn(params):
            nonlocal call_count
            call_count += 1
            raise ValueError("Boom!")

        agent("sweep-123", function=train_fn)

        # Function was called despite error
        assert call_count == 1


# ---------------------------------------------------------------------------
# Config parsing tests
# ---------------------------------------------------------------------------


class TestConfigParsing:
    """Test that sweep configs are correctly structured."""

    def test_w_and_b_compatible_config(self):
        """W&B-compatible config format is accepted."""
        config = {
            "method": "bayes",
            "metric": {"name": "val_loss", "goal": "minimize"},
            "parameters": {
                "lr": {"min": 0.0001, "max": 0.1, "distribution": "log_uniform_values"},
                "batch_size": {"values": [16, 32, 64]},
                "epochs": {"value": 10},
            },
            "early_terminate": {"type": "hyperband", "min_iter": 3, "eta": 3},
        }

        # Config should be JSON-serializable
        serialized = json.dumps(config)
        parsed = json.loads(serialized)

        assert parsed["method"] == "bayes"
        assert parsed["metric"]["name"] == "val_loss"
        assert parsed["metric"]["goal"] == "minimize"
        assert parsed["parameters"]["lr"]["distribution"] == "log_uniform_values"
        assert parsed["parameters"]["batch_size"]["values"] == [16, 32, 64]
        assert parsed["parameters"]["epochs"]["value"] == 10
        assert parsed["early_terminate"]["type"] == "hyperband"
