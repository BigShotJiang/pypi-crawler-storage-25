"""Tests for SDK alias and model registry features."""

import json
from unittest.mock import MagicMock, patch

import httpx
import pytest

from openrunner.api_client import APIClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_transport(responses: list[tuple[int, dict | list | None]]):
    """Create an httpx.MockTransport with a sequence of responses."""
    calls = iter(responses)

    def handler(request: httpx.Request) -> httpx.Response:
        status_code, body = next(calls)
        return httpx.Response(
            status_code,
            json=body,
        )

    return httpx.MockTransport(handler)


# ---------------------------------------------------------------------------
# APIClient.set_alias tests
# ---------------------------------------------------------------------------


def test_set_alias_success():
    """set_alias sends PUT with version_id and returns alias data."""
    transport = _make_transport([
        (200, {
            "id": "alias-uuid",
            "artifact_id": "art-uuid",
            "version_id": "ver-uuid",
            "alias_name": "production",
            "created_at": "2026-04-30T00:00:00Z",
            "updated_by": None,
        }),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.set_alias("art-uuid", "production", "ver-uuid")

    assert result is not None
    assert result["alias_name"] == "production"
    assert result["version_id"] == "ver-uuid"
    client.close()


def test_set_alias_failure():
    """set_alias returns None on server error."""
    transport = _make_transport([
        (500, {"detail": "Internal error"}),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.set_alias("art-uuid", "production", "ver-uuid")
    assert result is None
    client.close()


# ---------------------------------------------------------------------------
# APIClient.list_aliases tests
# ---------------------------------------------------------------------------


def test_list_aliases_success():
    """list_aliases returns list of alias dicts."""
    transport = _make_transport([
        (200, [
            {"id": "a1", "alias_name": "latest", "version_id": "v1",
             "artifact_id": "art1", "created_at": "2026-04-30T00:00:00Z",
             "updated_by": None},
            {"id": "a2", "alias_name": "production", "version_id": "v2",
             "artifact_id": "art1", "created_at": "2026-04-30T00:00:00Z",
             "updated_by": "user@test.com"},
        ]),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.list_aliases("art1")

    assert len(result) == 2
    assert result[0]["alias_name"] == "latest"
    assert result[1]["alias_name"] == "production"
    client.close()


def test_list_aliases_failure():
    """list_aliases returns empty list on failure."""
    transport = _make_transport([
        (500, {"detail": "error"}),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.list_aliases("art1")
    assert result == []
    client.close()


# ---------------------------------------------------------------------------
# APIClient.use_artifact with alias tests
# ---------------------------------------------------------------------------


def test_use_artifact_with_alias():
    """use_artifact sends alias parameter to server."""
    transport = _make_transport([
        (200, {
            "version_id": "ver-uuid",
            "version": 3,
            "files": [],
        }),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.use_artifact("run1", "my-model", alias="production")

    assert result is not None
    assert result["version"] == 3
    client.close()


def test_use_artifact_with_name_colon_alias():
    """use_artifact sends name:alias in artifact_name (server parses it)."""
    transport = _make_transport([
        (200, {
            "version_id": "ver-uuid",
            "version": 5,
            "files": [],
        }),
    ])
    client = APIClient("http://test", "key", transport=transport)

    result = client.use_artifact("run1", "my-model:staging")

    assert result is not None
    assert result["version"] == 5
    client.close()


# ---------------------------------------------------------------------------
# Run.link_artifact tests
# ---------------------------------------------------------------------------


def test_run_link_artifact_sets_aliases():
    """link_artifact uploads artifact then sets aliases via API."""
    from openrunner.artifact import Artifact

    # Mock the API calls (no create_run -- using object.__new__):
    # 1. create_artifact_version -> returns version_id
    # 2. confirm_artifact_version -> success
    # 3. GET /projects/test-project/artifacts -> returns artifact with ID
    # 4. PUT alias "production" -> success
    transport = _make_transport([
        # create_artifact_version (POST /runs/run1/artifacts)
        (201, {"version_id": "ver-uuid", "version": 1, "upload_urls": []}),
        # confirm_artifact_version (POST /artifacts/versions/ver-uuid/confirm)
        (200, {"status": "confirmed", "version": 1}),
        # GET /projects/test-project/artifacts
        (200, [{"id": "art-uuid", "name": "my-model", "type": "model"}]),
        # PUT /artifacts/art-uuid/aliases/production
        (200, {"id": "alias1", "alias_name": "production", "version_id": "ver-uuid",
               "artifact_id": "art-uuid", "created_at": "2026-04-30T00:00:00Z",
               "updated_by": None}),
    ])

    from openrunner.run import Run

    # Construct run manually to bypass full init
    run = object.__new__(Run)
    run._id = "run1"
    run._project = "test-project"
    run._name = "test-run"
    run._tags = None
    run._notes = None
    run._group = None
    run._job_type = None
    run._step = 0
    run._state = "running"

    from openrunner.api_client import APIClient
    from openrunner.buffer import WriteBuffer
    from openrunner.cache import ArtifactCache
    from openrunner.config import Config
    from openrunner.summary import Summary

    run._client = APIClient("http://test", "test-key", transport=transport)
    run._buffer = WriteBuffer()
    run._summary = Summary()
    run._config = Config()
    run._artifact_cache = ArtifactCache()
    run._offline_storage = None

    artifact = Artifact("my-model", type="model")
    # No files, just test the alias flow

    result = run.link_artifact(artifact, aliases=["production"])
    assert result is not None
    assert result["version_id"] == "ver-uuid"

    run._client.close()


# ---------------------------------------------------------------------------
# Run.use_artifact with name:alias syntax tests
# ---------------------------------------------------------------------------


def test_run_use_artifact_colon_syntax():
    """use_artifact parses 'name:alias' and passes alias to API client."""
    transport = _make_transport([
        # use_artifact POST (no create_run -- using object.__new__)
        (200, {"version_id": "ver-uuid", "version": 2, "files": []}),
    ])

    from openrunner.run import Run
    from openrunner.api_client import APIClient
    from openrunner.buffer import WriteBuffer
    from openrunner.cache import ArtifactCache
    from openrunner.config import Config
    from openrunner.summary import Summary

    run = object.__new__(Run)
    run._id = "run1"
    run._project = "test-project"
    run._name = "test-run"
    run._step = 0
    run._state = "running"
    run._client = APIClient("http://test", "test-key", transport=transport)
    run._buffer = WriteBuffer()
    run._summary = Summary()
    run._config = Config()
    run._artifact_cache = ArtifactCache()
    run._offline_storage = None

    result = run.use_artifact("my-model:production")

    # Result is a Path object (artifact directory) since files are empty
    assert result is not None

    run._client.close()
