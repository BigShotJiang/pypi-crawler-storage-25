"""Tests for openrunner.init() -- run creation and configuration."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# test_init_creates_run
# ---------------------------------------------------------------------------

class TestInitCreatesRun:
    def test_init_creates_run_and_sets_active(self):
        """init() should create a Run and set it as the active run."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {
                "id": "abc12345",
                "state": "running",
            }
            import openrunner
            openrunner._active_run = None  # Reset state

            run = openrunner.init(project="my-project", name="test-run")

            assert run is not None
            assert openrunner._active_run is run
            assert run.project == "my-project"

            openrunner.finish(quiet=True)

    def test_init_returns_run_with_id(self):
        """init() should return a Run with a valid ID."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {
                "id": "gen12345",
                "state": "running",
            }
            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")

            assert run.id is not None
            assert len(run.id) == 8

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_init_sends_config_at_init (SDK-12)
# ---------------------------------------------------------------------------

class TestInitSendsConfig:
    def test_config_sent_in_create_run_payload(self):
        """Config should be included in the create_run call (SDK-12)."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x1234567", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(
                project="test",
                config={"lr": 0.01, "batch_size": 32},
            )

            # Verify create_run was called with config in payload
            call_args = mock_client.create_run.call_args
            payload = call_args[0][0] if call_args[0] else call_args[1].get("data", {})
            assert "config" in payload
            assert payload["config"]["lr"] == 0.01
            assert payload["config"]["batch_size"] == 32

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_init_captures_git_info
# ---------------------------------------------------------------------------

class TestInitCapturesGitInfo:
    def test_git_info_included_in_create_payload(self):
        """Git info should be captured and sent to server at init()."""
        with patch("openrunner.run.APIClient") as MockClient, \
             patch("openrunner.run.capture_git_info") as mock_git:
            mock_git.return_value = {
                "sha": "abc123",
                "branch": "main",
                "remote_url": "https://github.com/test/repo.git",
                "dirty": False,
            }
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "g1234567", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")

            call_args = mock_client.create_run.call_args
            payload = call_args[0][0] if call_args[0] else call_args[1].get("data", {})
            assert "git_info" in payload
            assert payload["git_info"]["sha"] == "abc123"

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_init_generates_run_id
# ---------------------------------------------------------------------------

class TestInitGeneratesId:
    def test_generates_8_char_id_when_not_provided(self):
        """When no ID is provided, a random 8-char alphanumeric ID is generated."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x1234567", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")

            assert len(run.id) == 8
            assert run.id.isalnum()
            assert run.id.islower() or run.id.replace("0123456789", "").islower()

            openrunner.finish(quiet=True)

    def test_uses_provided_id(self):
        """When an ID is provided, it should be used as-is."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "myrun123", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test", id="myrun123")

            assert run.id == "myrun123"

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_init_warns_no_api_key
# ---------------------------------------------------------------------------

class TestInitWarnsNoKey:
    def test_warns_when_no_api_key(self, caplog, clean_env):
        """init() should warn when no API key is set but not crash."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "w1234567", "state": "running"}

            import openrunner
            openrunner._active_run = None

            with caplog.at_level(logging.WARNING, logger="openrunner"):
                run = openrunner.init(project="test")

            # Should still work (defensive), but warn
            assert run is not None
            assert "api_key" in caplog.text.lower() or "api key" in caplog.text.lower()

            openrunner.finish(quiet=True)
