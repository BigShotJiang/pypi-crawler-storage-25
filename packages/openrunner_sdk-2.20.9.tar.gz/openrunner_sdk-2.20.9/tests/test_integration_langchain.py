"""Tests for the LangChain integration (OpenRunnerCallbackHandler)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest


# ---------------------------------------------------------------------------
# Mock langchain before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_langchain(monkeypatch):
    """Inject a fake langchain_core module so langchain.py imports cleanly."""
    langchain_core = types.ModuleType("langchain_core")
    langchain_core_callbacks = types.ModuleType("langchain_core.callbacks")

    class _BaseCallbackHandler:
        """Fake base class."""
        def __init__(self, **kwargs):
            pass

    langchain_core_callbacks.BaseCallbackHandler = _BaseCallbackHandler
    langchain_core.callbacks = langchain_core_callbacks

    monkeypatch.setitem(sys.modules, "langchain_core", langchain_core)
    monkeypatch.setitem(sys.modules, "langchain_core.callbacks", langchain_core_callbacks)
    yield
    sys.modules.pop("openrunner.integration.langchain", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerCallbackHandler:
    """Tests for the LangChain OpenRunnerCallbackHandler."""

    def test_on_llm_start_logs_call_count(self, monkeypatch):
        """on_llm_start logs the LLM call count."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()
        run_id = uuid4()
        handler.on_llm_start({}, ["Hello, world!"], run_id=run_id)

        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["langchain/llm_calls"] == 1

    def test_on_llm_end_logs_tokens_and_latency(self, monkeypatch):
        """on_llm_end logs token usage and latency."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()
        run_id = uuid4()

        # Start LLM call
        handler.on_llm_start({}, ["test prompt"], run_id=run_id)
        mock_log.reset_mock()

        # End LLM call with token info
        response = MagicMock()
        response.llm_output = {
            "token_usage": {
                "prompt_tokens": 10,
                "completion_tokens": 20,
                "total_tokens": 30,
            }
        }
        handler.on_llm_end(response, run_id=run_id)

        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["langchain/prompt_tokens"] == 10
        assert logged["langchain/completion_tokens"] == 20
        assert logged["langchain/total_tokens"] == 30
        assert "langchain/llm_latency_s" in logged

    def test_on_llm_start_noop_if_no_active_run(self, monkeypatch):
        """on_llm_start is a no-op if no active run."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        handler = OpenRunnerCallbackHandler()
        handler.on_llm_start({}, ["test"])

        mock_log.assert_not_called()

    def test_on_chain_start_and_end(self, monkeypatch):
        """on_chain_start/end logs chain call count and latency."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()
        run_id = uuid4()

        handler.on_chain_start({}, {"input": "test"}, run_id=run_id)

        # First call: chain_start
        logged_start = mock_log.call_args[0][0]
        assert logged_start["langchain/chain_calls"] == 1

        mock_log.reset_mock()
        handler.on_chain_end({"output": "result"}, run_id=run_id)

        logged_end = mock_log.call_args[0][0]
        assert "langchain/chain_latency_s" in logged_end

    def test_on_tool_start_and_end(self, monkeypatch):
        """on_tool_start/end logs tool call count and latency."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()
        run_id = uuid4()

        handler.on_tool_start({}, "search query", run_id=run_id)

        logged_start = mock_log.call_args[0][0]
        assert logged_start["langchain/tool_calls"] == 1

        mock_log.reset_mock()
        handler.on_tool_end("search result", run_id=run_id)

        logged_end = mock_log.call_args[0][0]
        assert "langchain/tool_latency_s" in logged_end

    def test_call_counter_increments(self, monkeypatch):
        """Counters increment across multiple calls."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()

        handler.on_llm_start({}, ["prompt1"], run_id=uuid4())
        handler.on_llm_start({}, ["prompt2"], run_id=uuid4())

        # Second call should have count = 2
        second_call = mock_log.call_args_list[1]
        assert second_call[0][0]["langchain/llm_calls"] == 2

    def test_on_llm_end_without_token_usage(self, monkeypatch):
        """on_llm_end handles response without token usage gracefully."""
        from openrunner.integration.langchain import OpenRunnerCallbackHandler
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        handler = OpenRunnerCallbackHandler()
        run_id = uuid4()
        handler.on_llm_start({}, ["test"], run_id=run_id)
        mock_log.reset_mock()

        # Response with no llm_output
        response = MagicMock()
        response.llm_output = None
        handler.on_llm_end(response, run_id=run_id)

        # Should still log latency
        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert "langchain/llm_latency_s" in logged
        assert "langchain/prompt_tokens" not in logged


class TestLangChainImportError:
    """ImportError when langchain is missing."""

    def test_import_error_when_langchain_missing(self, monkeypatch, block_import):
        block_import("langchain_core")
        block_import("langchain")
        import sys
        sys.modules.pop("openrunner.integration.langchain", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.langchain  # noqa: F401
