"""Tests for the OpenRunner CLI commands (login, sync, ls).

Uses Click's CliRunner for testing CLI invocations and monkeypatch
to redirect ~/.openrunner/ to tmp_path for isolation.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from openrunner.cli import main


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def settings_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.openrunner/ to tmp_path/.openrunner for test isolation."""
    openrunner_dir = tmp_path / ".openrunner"
    openrunner_dir.mkdir()
    monkeypatch.setattr(
        "openrunner.cli._settings_dir",
        lambda: openrunner_dir,
    )
    return openrunner_dir


class TestLogin:
    """Test 1: `openrunner login` prompts for API key and server URL."""

    def test_login_stores_settings(self, runner, settings_dir):
        result = runner.invoke(
            main,
            ["login", "--manual"],
            input="http://myserver:8000\nmy-api-key\n",
        )
        assert result.exit_code == 0
        assert "Login successful" in result.output

        settings_file = settings_dir / "settings.json"
        assert settings_file.exists()
        settings = json.loads(settings_file.read_text())
        assert settings["api_key"] == "my-api-key"
        assert settings["base_url"] == "http://myserver:8000"

    def test_login_uses_default_url(self, runner, settings_dir):
        result = runner.invoke(
            main,
            ["login", "--manual"],
            input="\nmy-api-key\n",  # empty input = default URL
        )
        assert result.exit_code == 0
        settings = json.loads(
            (settings_dir / "settings.json").read_text()
        )
        assert settings["base_url"] == "http://localhost:8000"

    def test_login_updates_existing_settings(self, runner, settings_dir):
        # Write existing settings
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "old-key", "base_url": "http://old:8000"})
        )
        result = runner.invoke(
            main,
            ["login", "--manual"],
            input="new-key\n",
        )
        assert result.exit_code == 0
        settings = json.loads(
            (settings_dir / "settings.json").read_text()
        )
        assert settings["api_key"] == "new-key"
        assert settings["base_url"] == "http://old:8000"


class TestSyncAll:
    """Test 2: `openrunner sync --all` discovers offline runs and syncs each."""

    def test_sync_all_discovers_and_syncs(
        self, runner, settings_dir, tmp_path
    ):
        # Set up settings
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        # Create offline run dirs
        offline_dir = tmp_path / "offline"
        offline_dir.mkdir()
        for run_id in ["run1", "run2"]:
            d = offline_dir / run_id
            d.mkdir()
            (d / "meta.json").write_text(json.dumps({"id": run_id, "project_id": "p1"}))
            (d / "config.json").write_text(json.dumps({"lr": 0.1}))

        with patch("openrunner.cli.OfflineStorage") as mock_storage, \
             patch("openrunner.cli.OfflineSync") as mock_sync_cls, \
             patch("openrunner.cli.APIClient"):
            mock_storage.list_offline_runs.return_value = [
                offline_dir / "run1",
                offline_dir / "run2",
            ]
            mock_syncer = MagicMock()
            mock_syncer.sync.return_value = True
            mock_sync_cls.return_value = mock_syncer

            result = runner.invoke(main, ["sync", "--all"])
            assert result.exit_code == 0
            assert "2/2" in result.output
            assert mock_sync_cls.call_count == 2


class TestSyncPath:
    """Test 3: `openrunner sync <path>` syncs a specific offline run directory."""

    def test_sync_specific_path(self, runner, settings_dir, tmp_path):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        run_dir = tmp_path / "my_run"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text(json.dumps({"id": "my_run"}))
        (run_dir / "config.json").write_text(json.dumps({}))

        with patch("openrunner.cli.OfflineSync") as mock_sync_cls, \
             patch("openrunner.cli.APIClient"):
            mock_syncer = MagicMock()
            mock_syncer.sync.return_value = True
            mock_sync_cls.return_value = mock_syncer

            result = runner.invoke(main, ["sync", str(run_dir)])
            assert result.exit_code == 0
            assert "1/1" in result.output
            mock_sync_cls.assert_called_once()


class TestLsProjects:
    """Test 4: `openrunner ls` lists projects from server."""

    def test_ls_lists_projects(self, runner, settings_dir):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        with patch("openrunner.cli.APIClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.list_projects.return_value = [
                {"name": "project-a", "id": "p1"},
                {"name": "project-b", "id": "p2"},
            ]
            mock_client_cls.return_value = mock_client

            result = runner.invoke(main, ["ls"])
            assert result.exit_code == 0
            assert "project-a" in result.output
            assert "project-b" in result.output


class TestLsRuns:
    """Test 5: `openrunner ls --project <name>` lists runs within a project."""

    def test_ls_project_lists_runs(self, runner, settings_dir):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        with patch("openrunner.cli.APIClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.list_projects.return_value = [
                {"name": "myproject", "id": "proj-id-1"},
            ]
            mock_client.list_runs.return_value = [
                {"id": "run1", "display_name": "first-run", "state": "finished"},
                {"id": "run2", "display_name": "second-run", "state": "running"},
            ]
            mock_client_cls.return_value = mock_client

            result = runner.invoke(main, ["ls", "-p", "myproject"])
            assert result.exit_code == 0
            assert "run1" in result.output
            assert "run2" in result.output


class TestInit:
    """Test 6: `openrunner init` creates .openrunner/ directory with settings.json."""

    def test_init_creates_dir_and_settings(self, runner, settings_dir, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        assert "Initialized" in result.output

        local_dir = tmp_path / ".openrunner"
        assert local_dir.exists()
        settings_file = local_dir / "settings.json"
        assert settings_file.exists()

    def test_init_with_project_and_entity(self, runner, settings_dir, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, ["init", "--project", "my-proj", "--entity", "my-team"])
        assert result.exit_code == 0
        assert "my-proj" in result.output

        settings = json.loads((tmp_path / ".openrunner" / "settings.json").read_text())
        assert settings["project"] == "my-proj"
        assert settings["entity"] == "my-team"

    def test_init_already_initialized(self, runner, settings_dir, tmp_path, monkeypatch):
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        local_dir = work_dir / ".openrunner"
        local_dir.mkdir()
        (local_dir / "settings.json").write_text(json.dumps({"project": "old"}))

        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        assert "already initialized" in result.output

    def test_init_copies_global_api_key(self, runner, settings_dir, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Write global settings with an API key
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "global-key", "base_url": "http://myserver:8000"})
        )

        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0

        settings = json.loads((tmp_path / ".openrunner" / "settings.json").read_text())
        assert settings["api_key"] == "global-key"
        assert settings["base_url"] == "http://myserver:8000"


class TestStatus:
    """Test 7: `openrunner status` shows current configuration."""

    def test_status_not_logged_in(self, runner, settings_dir):
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "not set" in result.output or "not logged in" in result.output
        assert "API URL" in result.output

    def test_status_with_api_key(self, runner, settings_dir, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key-12345678", "base_url": "http://myhost:8000"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)
        monkeypatch.setenv("OPENRUNNER_BASE_URL", "http://myhost:8000")
        # Mock the API client to avoid real network calls
        with patch("openrunner.cli.APIClient") as mock_cls:
            mock_client = MagicMock()
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"username": "testuser"}
            mock_client._request.return_value = mock_response
            mock_cls.return_value = mock_client

            result = runner.invoke(main, ["status"])
            assert result.exit_code == 0
            assert "myhost" in result.output
            assert "test" in result.output  # masked key shows first 4 chars
            assert "testuser" in result.output


class TestVerify:
    """Test 8: `openrunner verify` runs health checks."""

    def test_verify_no_api_key(self, runner, settings_dir, monkeypatch):
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)
        result = runner.invoke(main, ["verify"])
        assert result.exit_code == 0
        assert "SKIP" in result.output or "no API key" in result.output

    def test_verify_all_pass(self, runner, settings_dir, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)

        with patch("openrunner.cli.APIClient") as mock_cls, \
             patch("httpx.get") as mock_httpx_get:
            mock_client = MagicMock()

            # Health check response
            mock_health = MagicMock()
            mock_health.status_code = 200
            mock_httpx_get.return_value = mock_health

            # Auth check
            mock_auth = MagicMock()
            mock_auth.status_code = 200
            mock_auth.json.return_value = {"username": "admin"}

            # General request mock
            mock_client._request.return_value = mock_auth
            mock_client.list_projects.return_value = [{"name": "proj1"}]
            mock_cls.return_value = mock_client

            result = runner.invoke(main, ["verify"])
            assert result.exit_code == 0
            assert "PASS" in result.output

    def test_verify_with_host_override(self, runner, settings_dir, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)
        monkeypatch.delenv("OPENRUNNER_BASE_URL", raising=False)

        with patch("openrunner.cli.APIClient") as mock_cls, \
             patch("httpx.get") as mock_httpx_get:
            mock_client = MagicMock()
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"username": "admin"}
            mock_httpx_get.return_value = mock_resp
            mock_client._request.return_value = mock_resp
            mock_client.list_projects.return_value = []
            mock_cls.return_value = mock_client

            result = runner.invoke(main, ["verify", "--host", "https://custom.server.com"])
            assert result.exit_code == 0
            assert "custom.server.com" in result.output


class TestPull:
    """Test 9: `openrunner pull` downloads run files."""

    def test_pull_run_not_found(self, runner, settings_dir, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)

        with patch("openrunner.cli.APIClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.get_run.return_value = None
            mock_client.from_path.return_value = None
            mock_cls.return_value = mock_client

            result = runner.invoke(main, ["pull", "nonexistent-run"])
            assert result.exit_code == 1
            assert "not found" in result.output

    def test_pull_downloads_files(self, runner, settings_dir, tmp_path, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)
        monkeypatch.chdir(tmp_path)

        with patch("openrunner.cli.APIClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.get_run.return_value = {
                "id": "run123",
                "display_name": "test-run",
                "state": "finished",
                "config": {"lr": 0.01},
                "summary": {"loss": 0.5},
            }
            mock_client.list_run_files.return_value = [
                {"path": "model.pt", "presigned_url": "https://s3/model.pt", "size_bytes": 1024},
            ]
            mock_client.download_file_from_presigned_url.return_value = b"model-data"
            mock_client.get_run_logged_artifacts.return_value = []
            mock_cls.return_value = mock_client

            result = runner.invoke(main, ["pull", "run123"])
            assert result.exit_code == 0
            assert "Pulling run" in result.output
            assert "model.pt" in result.output

            # Check files were created
            assert (tmp_path / "run123" / "run_metadata.json").exists()
            assert (tmp_path / "run123" / "config.json").exists()
            assert (tmp_path / "run123" / "summary.json").exists()
            assert (tmp_path / "run123" / "model.pt").exists()

    def test_pull_with_dir_option(self, runner, settings_dir, tmp_path, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key"})
        )
        monkeypatch.delenv("OPENRUNNER_API_KEY", raising=False)
        monkeypatch.chdir(tmp_path)

        with patch("openrunner.cli.APIClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.get_run.return_value = {
                "id": "run456",
                "display_name": "test-run",
                "state": "finished",
            }
            mock_client.list_run_files.return_value = []
            mock_client.get_run_logged_artifacts.return_value = []
            mock_cls.return_value = mock_client

            out = str(tmp_path / "my-output")
            result = runner.invoke(main, ["pull", "run456", "--dir", out])
            assert result.exit_code == 0
            assert (tmp_path / "my-output" / "run_metadata.json").exists()


class TestOnlineOffline:
    """Test 10: online/offline/enabled/disabled commands toggle SDK mode."""

    def test_online_writes_settings(self, runner, settings_dir, tmp_path, monkeypatch):
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        # Create local .openrunner dir
        local_dir = work_dir / ".openrunner"
        local_dir.mkdir()
        (local_dir / "settings.json").write_text(json.dumps({}))

        result = runner.invoke(main, ["online"])
        assert result.exit_code == 0
        assert "online" in result.output

        settings = json.loads((local_dir / "settings.json").read_text())
        assert settings["mode"] == "online"

    def test_offline_writes_settings(self, runner, settings_dir, tmp_path, monkeypatch):
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        local_dir = work_dir / ".openrunner"
        local_dir.mkdir()
        (local_dir / "settings.json").write_text(json.dumps({}))

        result = runner.invoke(main, ["offline"])
        assert result.exit_code == 0
        assert "offline" in result.output

        settings = json.loads((local_dir / "settings.json").read_text())
        assert settings["mode"] == "offline"

    def test_enabled_writes_settings(self, runner, settings_dir, tmp_path, monkeypatch):
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        local_dir = work_dir / ".openrunner"
        local_dir.mkdir()
        (local_dir / "settings.json").write_text(json.dumps({"disabled": "true"}))

        result = runner.invoke(main, ["enabled"])
        assert result.exit_code == 0
        assert "enabled" in result.output

        settings = json.loads((local_dir / "settings.json").read_text())
        assert settings["disabled"] == "false"

    def test_disabled_writes_settings(self, runner, settings_dir, tmp_path, monkeypatch):
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        local_dir = work_dir / ".openrunner"
        local_dir.mkdir()
        (local_dir / "settings.json").write_text(json.dumps({}))

        result = runner.invoke(main, ["disabled"])
        assert result.exit_code == 0
        assert "disabled" in result.output

        settings = json.loads((local_dir / "settings.json").read_text())
        assert settings["disabled"] == "true"

    def test_online_falls_back_to_global(self, runner, settings_dir, tmp_path, monkeypatch):
        """When no local .openrunner/ exists, writes to global settings."""
        work_dir = tmp_path / "workdir"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)
        result = runner.invoke(main, ["online"])
        assert result.exit_code == 0

        settings = json.loads((settings_dir / "settings.json").read_text())
        assert settings["mode"] == "online"


class TestSyncAdvanced:
    """Test 11: sync command advanced flags (include/exclude globs, clean, append)."""

    def test_sync_with_clean_old_hours(self, runner, settings_dir, tmp_path, monkeypatch):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        # Create an old offline run directory
        old_run = tmp_path / "old-run"
        old_run.mkdir()
        (old_run / "meta.json").write_text(json.dumps({"id": "old-run"}))

        with patch("openrunner.cli.OfflineStorage") as mock_storage, \
             patch("openrunner.cli.APIClient"):
            mock_storage.list_offline_runs.return_value = [old_run]

            result = runner.invoke(main, ["sync", "--clean-old-hours", "0"])
            assert result.exit_code == 0
            assert "Removed" in result.output or "Cleaned" in result.output

    def test_sync_with_clean_flag(self, runner, settings_dir, tmp_path):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        run_dir = tmp_path / "my_run"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text(json.dumps({"id": "my_run"}))

        with patch("openrunner.cli.OfflineSync") as mock_sync_cls, \
             patch("openrunner.cli.APIClient"):
            mock_syncer = MagicMock()
            mock_syncer.sync.return_value = True
            mock_sync_cls.return_value = mock_syncer

            result = runner.invoke(main, ["sync", str(run_dir), "--clean"])
            assert result.exit_code == 0
            assert "1/1" in result.output
            # After sync with --clean, the dir should be removed
            assert not run_dir.exists()


class TestEntryPoint:
    """Test 12: CLI entry point `openrunner` is registered in pyproject.toml."""

    def test_pyproject_has_entry_point(self):
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()
        assert 'openrunner = "openrunner.cli:main"' in content

    def test_click_dependency(self):
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()
        assert "click" in content
