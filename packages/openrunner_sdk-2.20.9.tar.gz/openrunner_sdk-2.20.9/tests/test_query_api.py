"""Tests for the OpenRunner query API (openrunner.Api)."""

from __future__ import annotations

import json
import logging
import os
from unittest.mock import patch

import httpx
import pytest

from openrunner.query_api import Api, ArtifactResult, RunResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_transport(routes: dict[str, tuple[int, dict | list]]):
    """Build a MockTransport that dispatches by URL path.

    ``routes`` maps URL path suffixes to (status_code, json_body) tuples.
    If no route matches, returns 404.
    """

    def _handler(request: httpx.Request) -> httpx.Response:
        path = request.url.raw_path.decode()
        # Strip query string for matching
        if "?" in path:
            path = path.split("?")[0]
        for route_path, (status_code, body) in routes.items():
            if path.endswith(route_path):
                return httpx.Response(
                    status_code,
                    content=json.dumps(body).encode(),
                    headers={"content-type": "application/json"},
                )
        return httpx.Response(404, content=b'{"detail":"Not found"}')

    return httpx.MockTransport(_handler)


ORG_DATA = [
    {"id": "org-uuid-1", "name": "My Org", "slug": "my-org", "is_personal": True}
]
PROJECT_DATA = [
    {
        "id": "proj-uuid-1",
        "org_id": "org-uuid-1",
        "name": "my-project",
        "slug": "my-project",
        "created_at": "2026-01-01T00:00:00Z",
    }
]
RUN_DATA = {
    "id": "abc12345",
    "project_id": "proj-uuid-1",
    "user_id": "user-uuid-1",
    "display_name": "train-run-1",
    "state": "finished",
    "config": {"lr": 0.001, "batch_size": 32},
    "summary": {"accuracy": 0.95, "loss": 0.05},
    "tags": ["baseline"],
    "notes": "First training run",
    "group_name": "experiment-1",
    "job_type": "train",
    "created_at": "2026-01-01T00:00:00Z",
    "finished_at": "2026-01-01T01:00:00Z",
}
RUNS_LIST_DATA = {
    "runs": [RUN_DATA],
    "total": 1,
    "offset": 0,
    "limit": 200,
}
METRICS_EXPORT_DATA = {
    "run_id": "abc12345",
    "metrics": [
        {"run_id": "abc12345", "key": "loss", "step": 0, "value": 1.0, "wall_time": "2026-01-01T00:00:00Z"},
        {"run_id": "abc12345", "key": "accuracy", "step": 0, "value": 0.1, "wall_time": "2026-01-01T00:00:00Z"},
        {"run_id": "abc12345", "key": "loss", "step": 1, "value": 0.5, "wall_time": "2026-01-01T00:00:01Z"},
        {"run_id": "abc12345", "key": "accuracy", "step": 1, "value": 0.5, "wall_time": "2026-01-01T00:00:01Z"},
        {"run_id": "abc12345", "key": "loss", "step": 2, "value": 0.1, "wall_time": "2026-01-01T00:00:02Z"},
        {"run_id": "abc12345", "key": "accuracy", "step": 2, "value": 0.9, "wall_time": "2026-01-01T00:00:02Z"},
    ],
}
ARTIFACT_DATA = {
    "id": "art-uuid-1",
    "project_id": "proj-uuid-1",
    "name": "my-model",
    "type": "model",
    "description": "Trained model checkpoint",
    "created_at": "2026-01-01T00:00:00Z",
    "versions": [
        {"id": "ver-uuid-1", "version": 1, "state": "confirmed"},
        {"id": "ver-uuid-2", "version": 2, "state": "confirmed"},
        {"id": "ver-uuid-3", "version": 3, "state": "confirmed"},
    ],
}
ARTIFACT_LIST_DATA = [
    {"id": "art-uuid-1", "name": "my-model", "type": "model"},
]


def _standard_routes():
    """Return the standard set of routes for most tests."""
    return {
        "/api/v1/organizations": (200, ORG_DATA),
        "/api/v1/organizations/org-uuid-1/projects": (200, PROJECT_DATA),
        "/api/v1/projects/proj-uuid-1/runs": (200, RUNS_LIST_DATA),
        "/api/v1/runs/abc12345": (200, RUN_DATA),
        "/api/v1/export/runs/abc12345/metrics.json": (200, METRICS_EXPORT_DATA),
        "/api/v1/projects/proj-uuid-1/artifacts": (200, ARTIFACT_LIST_DATA),
        "/api/v1/artifacts/art-uuid-1": (200, ARTIFACT_DATA),
    }


def _make_api(routes: dict | None = None) -> Api:
    """Create an Api instance with mock transport."""
    transport = _make_transport(routes or _standard_routes())
    api = Api.__new__(Api)
    api._base_url = "http://localhost:8000"
    api._client = httpx.Client(
        base_url="http://localhost:8000/api/v1",
        headers={"Authorization": "Bearer test-key"},
        timeout=30.0,
        transport=transport,
    )
    return api


# ---------------------------------------------------------------------------
# Api.__init__ tests
# ---------------------------------------------------------------------------


class TestApiInit:
    def test_raises_without_api_key(self, clean_env):
        """Api() raises ValueError when no API key is available."""
        with pytest.raises(ValueError, match="API key required"):
            Api()

    def test_reads_api_key_from_env(self, clean_env):
        """Api() reads OPENRUNNER_API_KEY from environment."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_test123")
        # This will fail on connection since no server, but init should succeed
        api = Api.__new__(Api)
        api.__init__()  # type: ignore[misc]
        assert "Bearer or_test123" in api._client.headers["authorization"]
        api.close()

    def test_reads_wandb_api_key_fallback(self, clean_env):
        """Api() falls back to WANDB_API_KEY."""
        clean_env.setenv("WANDB_API_KEY", "wandb_key_123")
        api = Api.__new__(Api)
        api.__init__()  # type: ignore[misc]
        assert "Bearer wandb_key_123" in api._client.headers["authorization"]
        api.close()

    def test_explicit_api_key_overrides_env(self, clean_env):
        """Explicit api_key parameter takes precedence."""
        clean_env.setenv("OPENRUNNER_API_KEY", "env_key")
        api = Api(api_key="explicit_key")
        assert "Bearer explicit_key" in api._client.headers["authorization"]
        api.close()

    def test_explicit_base_url(self, clean_env):
        """Explicit base_url parameter is used."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_test")
        api = Api(base_url="http://myserver:9000")
        assert api._base_url == "http://myserver:9000"
        api.close()

    def test_default_base_url(self, clean_env):
        """Default base_url is localhost:8000."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_test")
        api = Api()
        assert api._base_url == "http://localhost:8000"
        api.close()


# ---------------------------------------------------------------------------
# Api.projects() tests
# ---------------------------------------------------------------------------


class TestProjects:
    def test_lists_projects_across_orgs(self):
        """projects() returns all projects from all orgs."""
        api = _make_api()
        projects = api.projects()
        assert len(projects) == 1
        assert projects[0]["name"] == "my-project"
        api.close()

    def test_multiple_orgs(self):
        """projects() aggregates from multiple orgs."""
        routes = {
            "/api/v1/organizations": (200, [
                {"id": "org1", "name": "Org 1"},
                {"id": "org2", "name": "Org 2"},
            ]),
            "/api/v1/organizations/org1/projects": (200, [
                {"id": "p1", "name": "proj-a", "slug": "proj-a", "org_id": "org1"},
            ]),
            "/api/v1/organizations/org2/projects": (200, [
                {"id": "p2", "name": "proj-b", "slug": "proj-b", "org_id": "org2"},
            ]),
        }
        api = _make_api(routes)
        projects = api.projects()
        assert len(projects) == 2
        names = {p["name"] for p in projects}
        assert names == {"proj-a", "proj-b"}
        api.close()


# ---------------------------------------------------------------------------
# Api.runs() tests
# ---------------------------------------------------------------------------


class TestRuns:
    def test_lists_runs(self):
        """runs() returns RunResult objects."""
        api = _make_api()
        runs = api.runs("my-project")
        assert len(runs) == 1
        assert isinstance(runs[0], RunResult)
        assert runs[0].id == "abc12345"
        assert runs[0].state == "finished"
        api.close()

    def test_runs_with_state_filter(self):
        """runs() passes state filter as query param."""
        called_params = {}

        def _handler(request: httpx.Request) -> httpx.Response:
            path = request.url.raw_path.decode().split("?")[0]
            if path.endswith("/runs"):
                called_params.update(dict(request.url.params))
                return httpx.Response(200, content=json.dumps(RUNS_LIST_DATA).encode())
            if path.endswith("/organizations"):
                return httpx.Response(200, content=json.dumps(ORG_DATA).encode())
            if path.endswith("/projects"):
                return httpx.Response(200, content=json.dumps(PROJECT_DATA).encode())
            return httpx.Response(404)

        transport = httpx.MockTransport(_handler)
        api = Api.__new__(Api)
        api._base_url = "http://localhost:8000"
        api._client = httpx.Client(
            base_url="http://localhost:8000/api/v1",
            headers={"Authorization": "Bearer test-key"},
            timeout=30.0,
            transport=transport,
        )
        api.runs("my-project", filters={"state": "finished"})
        assert called_params.get("state") == "finished"
        api.close()

    def test_runs_with_order(self):
        """runs() parses order string correctly."""
        called_params = {}

        def _handler(request: httpx.Request) -> httpx.Response:
            path = request.url.raw_path.decode().split("?")[0]
            if path.endswith("/runs"):
                called_params.update(dict(request.url.params))
                return httpx.Response(200, content=json.dumps(RUNS_LIST_DATA).encode())
            if path.endswith("/organizations"):
                return httpx.Response(200, content=json.dumps(ORG_DATA).encode())
            if path.endswith("/projects"):
                return httpx.Response(200, content=json.dumps(PROJECT_DATA).encode())
            return httpx.Response(404)

        transport = httpx.MockTransport(_handler)
        api = Api.__new__(Api)
        api._base_url = "http://localhost:8000"
        api._client = httpx.Client(
            base_url="http://localhost:8000/api/v1",
            headers={"Authorization": "Bearer test-key"},
            timeout=30.0,
            transport=transport,
        )
        api.runs("my-project", order="-created_at")
        assert called_params.get("sort_by") == "created_at"
        assert called_params.get("sort_dir") == "desc"
        api.close()

    def test_runs_project_not_found(self):
        """runs() returns empty list when project not found."""
        routes = {
            "/api/v1/organizations": (200, ORG_DATA),
            "/api/v1/organizations/org-uuid-1/projects": (200, []),
        }
        api = _make_api(routes)
        runs = api.runs("nonexistent-project")
        assert runs == []
        api.close()


# ---------------------------------------------------------------------------
# Api.run() tests
# ---------------------------------------------------------------------------


class TestRun:
    def test_get_run_by_id(self):
        """run() fetches a single run by ID."""
        api = _make_api()
        result = api.run("abc12345")
        assert isinstance(result, RunResult)
        assert result.id == "abc12345"
        assert result.config == {"lr": 0.001, "batch_size": 32}
        assert result.summary == {"accuracy": 0.95, "loss": 0.05}
        api.close()

    def test_get_run_by_path(self):
        """run() handles project/run_id format."""
        api = _make_api()
        result = api.run("my-project/abc12345")
        assert result.id == "abc12345"
        api.close()

    def test_run_not_found(self):
        """run() raises ValueError for missing run."""
        routes = {"/api/v1/runs/missing": (404, {"detail": "Run not found"})}
        api = _make_api(routes)
        with pytest.raises(ValueError, match="not found"):
            api.run("missing")
        api.close()

    def test_invalid_path_format(self):
        """run() raises ValueError for invalid path."""
        api = _make_api()
        with pytest.raises(ValueError, match="Invalid run path"):
            api.run("a/b/c")
        api.close()


# ---------------------------------------------------------------------------
# RunResult tests
# ---------------------------------------------------------------------------


class TestRunResult:
    def test_attributes(self):
        """RunResult exposes all run fields as attributes."""
        client = httpx.Client(base_url="http://test")
        result = RunResult(RUN_DATA, client)
        assert result.id == "abc12345"
        assert result.name == "train-run-1"
        assert result.state == "finished"
        assert result.config["lr"] == 0.001
        assert result.summary["accuracy"] == 0.95
        assert result.tags == ["baseline"]
        assert result.notes == "First training run"
        assert result.group == "experiment-1"
        assert result.job_type == "train"
        client.close()

    def test_repr(self):
        """RunResult has a useful repr."""
        client = httpx.Client(base_url="http://test")
        result = RunResult(RUN_DATA, client)
        assert "abc12345" in repr(result)
        assert "train-run-1" in repr(result)
        client.close()

    def test_history_returns_list(self):
        """history() returns reshaped metric data as list of dicts."""
        routes = _standard_routes()
        transport = _make_transport(routes)
        client = httpx.Client(
            base_url="http://localhost:8000/api/v1",
            headers={"Authorization": "Bearer test-key"},
            timeout=30.0,
            transport=transport,
        )
        result = RunResult(RUN_DATA, client)
        history = result.history()

        assert isinstance(history, list)
        assert len(history) == 3  # 3 steps

        # Step 0
        assert history[0]["_step"] == 0
        assert history[0]["loss"] == 1.0
        assert history[0]["accuracy"] == 0.1

        # Step 2
        assert history[2]["_step"] == 2
        assert history[2]["loss"] == 0.1
        assert history[2]["accuracy"] == 0.9

        client.close()

    def test_history_pandas(self):
        """history(pandas=True) returns a DataFrame."""
        pytest.importorskip("pandas")
        import pandas as pd

        routes = _standard_routes()
        transport = _make_transport(routes)
        client = httpx.Client(
            base_url="http://localhost:8000/api/v1",
            headers={"Authorization": "Bearer test-key"},
            timeout=30.0,
            transport=transport,
        )
        result = RunResult(RUN_DATA, client)
        df = result.history(pandas=True)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 3
        assert "_step" in df.columns
        assert "loss" in df.columns
        assert "accuracy" in df.columns
        assert df.iloc[0]["loss"] == 1.0
        assert df.iloc[2]["accuracy"] == 0.9

        client.close()

    def test_history_error_returns_empty(self, caplog):
        """history() returns empty list on HTTP error."""
        routes = {"/api/v1/export/runs/abc12345/metrics.json": (500, {"detail": "error"})}
        transport = _make_transport(routes)
        client = httpx.Client(
            base_url="http://localhost:8000/api/v1",
            headers={"Authorization": "Bearer test-key"},
            timeout=30.0,
            transport=transport,
        )
        result = RunResult(RUN_DATA, client)
        with caplog.at_level(logging.WARNING, logger="openrunner"):
            history = result.history()
        assert history == []
        client.close()


# ---------------------------------------------------------------------------
# Api.artifact() tests
# ---------------------------------------------------------------------------


class TestArtifact:
    def test_get_artifact_latest(self):
        """artifact('name:latest') finds the artifact."""
        api = _make_api()
        result = api.artifact("my-model:latest")
        assert isinstance(result, ArtifactResult)
        assert result.name == "my-model"
        assert result.type == "model"
        assert len(result.versions) == 3
        api.close()

    def test_get_artifact_by_version(self):
        """artifact('name:v3') finds the artifact and validates version."""
        api = _make_api()
        result = api.artifact("my-model:v3")
        assert result.name == "my-model"
        api.close()

    def test_get_artifact_default_alias(self):
        """artifact('name') defaults to 'latest'."""
        api = _make_api()
        result = api.artifact("my-model")
        assert result.name == "my-model"
        api.close()

    def test_artifact_not_found(self):
        """artifact() raises ValueError for missing artifact."""
        routes = {
            "/api/v1/organizations": (200, ORG_DATA),
            "/api/v1/organizations/org-uuid-1/projects": (200, PROJECT_DATA),
            "/api/v1/projects/proj-uuid-1/artifacts": (200, []),
        }
        api = _make_api(routes)
        with pytest.raises(ValueError, match="not found"):
            api.artifact("nonexistent:latest")
        api.close()


# ---------------------------------------------------------------------------
# ArtifactResult tests
# ---------------------------------------------------------------------------


class TestArtifactResult:
    def test_attributes(self):
        """ArtifactResult exposes artifact fields."""
        result = ArtifactResult(ARTIFACT_DATA)
        assert result.name == "my-model"
        assert result.type == "model"
        assert result.description == "Trained model checkpoint"
        assert len(result.versions) == 3

    def test_latest_version(self):
        """latest_version returns the highest confirmed version."""
        result = ArtifactResult(ARTIFACT_DATA)
        assert result.latest_version == 3

    def test_latest_version_none_when_empty(self):
        """latest_version returns None when no versions."""
        result = ArtifactResult({"id": "x", "name": "x", "type": "x", "versions": []})
        assert result.latest_version is None

    def test_repr(self):
        """ArtifactResult has a useful repr."""
        result = ArtifactResult(ARTIFACT_DATA)
        assert "my-model" in repr(result)


# ---------------------------------------------------------------------------
# Context manager tests
# ---------------------------------------------------------------------------


class TestContextManager:
    def test_api_as_context_manager(self):
        """Api can be used as a context manager."""
        api = _make_api()
        with api:
            projects = api.projects()
            assert len(projects) >= 1

    def test_repr(self):
        """Api has a useful repr."""
        api = _make_api()
        assert "localhost:8000" in repr(api)
        api.close()
