"""Tests for openrunner.log() -- metric buffering and step semantics."""

from __future__ import annotations

import logging
import time
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# test_log_puts_to_buffer
# ---------------------------------------------------------------------------

class TestLogPutsToBuffer:
    def test_log_adds_records_to_buffer(self):
        """log() should add metric records to the internal buffer."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5, "acc": 0.8})

            # Buffer should have 2 records (one per metric key)
            assert run._buffer.size == 2

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_log_auto_step_increment
# ---------------------------------------------------------------------------

class TestLogStepIncrement:
    def test_step_increments_on_commit_true(self):
        """Step counter should auto-increment when commit=True (default)."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5})  # step 0, then increments to 1
            openrunner.log({"loss": 0.4})  # step 1, then increments to 2

            # After two log calls with commit=True, step should be 2
            assert run._step == 2

            openrunner.finish(quiet=True)

    def test_step_no_increment_on_commit_false(self):
        """Step counter should NOT increment when commit=False."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5}, commit=False)
            openrunner.log({"acc": 0.8}, commit=False)

            # Step should still be 0 -- no commits happened
            assert run._step == 0

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_log_explicit_step
# ---------------------------------------------------------------------------

class TestLogExplicitStep:
    def test_explicit_step_overrides_counter(self):
        """Explicit step parameter should override the auto-increment counter."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5}, step=42)

            # Drain buffer to check the step value in records
            records = run._buffer.drain()
            assert all(r["step"] == 42 for r in records)

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_log_updates_summary
# ---------------------------------------------------------------------------

class TestLogUpdatesSummary:
    def test_summary_updated_with_logged_values(self):
        """log() should auto-update the summary with last logged values."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5})
            openrunner.log({"loss": 0.3, "acc": 0.9})

            assert run.summary["loss"] == 0.3  # Last value
            assert run.summary["acc"] == 0.9

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_log_nonblocking
# ---------------------------------------------------------------------------

class TestLogNonBlocking:
    def test_log_returns_quickly(self):
        """log() should return immediately (non-blocking)."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "x", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")

            t0 = time.time()
            for i in range(100):
                openrunner.log({"x": float(i)})
            elapsed = time.time() - t0

            # 100 log calls should complete in well under 1 second
            assert elapsed < 1.0, f"100 log() calls took {elapsed:.3f}s -- not non-blocking"

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# test_log_warns_no_active_run
# ---------------------------------------------------------------------------

class TestLogWarnsNoRun:
    def test_warns_when_no_active_run(self, caplog):
        """log() should warn (not crash) when there is no active run."""
        import openrunner
        openrunner._active_run = None

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            openrunner.log({"loss": 0.5})

        assert "no active run" in caplog.text.lower() or "not initialized" in caplog.text.lower()
