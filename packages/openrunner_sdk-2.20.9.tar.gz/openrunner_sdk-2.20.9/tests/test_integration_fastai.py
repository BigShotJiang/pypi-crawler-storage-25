"""Tests for the FastAI integration (OpenRunnerCallback)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Mock fastai before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_fastai(monkeypatch):
    """Inject a fake fastai module so fastai.py imports cleanly."""
    fastai = types.ModuleType("fastai")
    fastai_callback = types.ModuleType("fastai.callback")
    fastai_callback_core = types.ModuleType("fastai.callback.core")

    class _Callback:
        """Fake base Callback class."""
        def __init__(self, **kwargs):
            pass

    fastai_callback_core.Callback = _Callback
    fastai_callback.core = fastai_callback_core
    fastai.callback = fastai_callback

    monkeypatch.setitem(sys.modules, "fastai", fastai)
    monkeypatch.setitem(sys.modules, "fastai.callback", fastai_callback)
    monkeypatch.setitem(sys.modules, "fastai.callback.core", fastai_callback_core)
    yield
    sys.modules.pop("openrunner.integration.fastai", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerFastAICallback:
    """Tests for the FastAI OpenRunnerCallback."""

    def test_before_fit_calls_init(self, monkeypatch):
        """before_fit calls openrunner.init() when no active run."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock(return_value=MagicMock())
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback(project="fastai-project", config={"lr": 0.01})
        cb.before_fit()

        mock_init.assert_called_once_with(project="fastai-project", config={"lr": 0.01})

    def test_before_fit_skips_if_active_run(self, monkeypatch):
        """before_fit does not call init() if a run is already active."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.before_fit()

        mock_init.assert_not_called()

    def test_after_epoch_logs_metrics(self, monkeypatch):
        """after_epoch logs train_loss, valid_loss, and metrics."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        # Simulate fastai recorder
        cb.recorder = MagicMock()
        cb.recorder.log = [0.25, 0.30, 0.92]
        cb.recorder.metric_names = ["epoch", "train_loss", "valid_loss", "accuracy"]
        cb.epoch = 5

        cb.after_epoch()

        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["train_loss"] == 0.25
        assert logged["valid_loss"] == 0.30
        assert logged["accuracy"] == 0.92
        assert mock_log.call_args[1]["step"] == 5

    def test_after_epoch_noop_if_no_active_run(self, monkeypatch):
        """after_epoch is a no-op if no active run."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback()
        cb.after_epoch()

        mock_log.assert_not_called()

    def test_after_fit_calls_finish(self, monkeypatch):
        """after_fit calls openrunner.finish()."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.finish", mock_finish)

        cb = OpenRunnerCallback()
        cb.after_fit()

        mock_finish.assert_called_once()

    def test_after_epoch_handles_no_recorder(self, monkeypatch):
        """after_epoch handles missing recorder gracefully."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        # No recorder attribute set
        cb.after_epoch()

        mock_log.assert_not_called()

    def test_after_epoch_uses_default_names_without_metric_names(self, monkeypatch):
        """after_epoch falls back to train_loss/valid_loss names when metric_names missing."""
        from openrunner.integration.fastai import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.recorder = MagicMock(spec=[])  # spec=[] means no attributes
        cb.recorder.log = [0.5, 0.6]
        cb.epoch = 0

        cb.after_epoch()

        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["train_loss"] == 0.5
        assert logged["valid_loss"] == 0.6


class TestFastAIImportError:
    """ImportError when fastai is missing."""

    def test_import_error_when_fastai_missing(self, monkeypatch, block_import):
        block_import("fastai")
        import sys
        sys.modules.pop("openrunner.integration.fastai", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.fastai  # noqa: F401
