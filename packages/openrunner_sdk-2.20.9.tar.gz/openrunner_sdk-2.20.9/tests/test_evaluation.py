"""Tests for openrunner evaluation framework -- scorers, evaluate(), result aggregation."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from openrunner.evaluation import EvalResult, evaluate, is_scorer, scorer


# ---------------------------------------------------------------------------
# Test: @scorer decorator
# ---------------------------------------------------------------------------


class TestScorerDecorator:
    def test_scorer_marks_function(self):
        """@scorer should set _openrunner_scorer attribute."""

        @scorer
        def my_scorer(output, expected):
            return {"score": 1.0}

        assert is_scorer(my_scorer)

    def test_scorer_preserves_function_name(self):
        """@scorer should preserve the original function name."""

        @scorer
        def accuracy(output, expected):
            return {"score": 1.0}

        assert accuracy.__name__ == "accuracy"

    def test_scorer_validates_return_value(self):
        """@scorer should raise if scorer returns non-dict or missing 'score'."""

        @scorer
        def bad_scorer(output, expected):
            return {"wrong_key": 1.0}

        with pytest.raises(ValueError, match="must return a dict with a 'score' key"):
            bad_scorer("output", "expected")

    def test_scorer_validates_non_dict_return(self):
        """@scorer should raise if scorer returns a non-dict."""

        @scorer
        def bad_scorer(output, expected):
            return 1.0

        with pytest.raises(ValueError, match="must return a dict with a 'score' key"):
            bad_scorer("output", "expected")

    def test_scorer_passes_valid_result(self):
        """@scorer should pass through valid scorer results."""

        @scorer
        def my_scorer(output, expected):
            return {"score": 0.75}

        result = my_scorer("test", "test")
        assert result == {"score": 0.75}

    def test_is_scorer_false_for_regular_function(self):
        """is_scorer should return False for non-scorer functions."""

        def regular_func(output, expected):
            return {"score": 1.0}

        assert not is_scorer(regular_func)


# ---------------------------------------------------------------------------
# Test: evaluate() function
# ---------------------------------------------------------------------------


class TestEvaluate:
    def test_basic_evaluation(self):
        """evaluate() should run model on each dataset row and score."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        def model(input_text):
            return input_text.upper()

        dataset = [
            {"input": "hello", "expected": "HELLO"},
            {"input": "world", "expected": "WORLD"},
            {"input": "test", "expected": "TEST"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[exact],
                project="test-project",
                name="test-eval",
            )

        assert isinstance(result, EvalResult)
        assert result.summary["exact.score"] == 1.0
        assert len(result.table) == 3
        assert len(result.scores) == 3

    def test_partial_scores(self):
        """evaluate() should compute correct means for partial matches."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        def model(input_text):
            # Only matches "yes"
            return "yes"

        dataset = [
            {"input": "q1", "expected": "yes"},
            {"input": "q2", "expected": "no"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[exact],
            )

        assert result.summary["exact.score"] == 0.5

    def test_multiple_scorers(self):
        """evaluate() should handle multiple scorers independently."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        @scorer
        def length(output, expected):
            exp_len = len(expected)
            if exp_len == 0:
                return {"score": 0.0}
            return {"score": min(len(output) / exp_len, 1.0)}

        def model(input_text):
            return "Paris"

        dataset = [
            {"input": "Capital of France?", "expected": "Paris"},
            {"input": "Capital of UK?", "expected": "London"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[exact, length],
            )

        assert "exact.score" in result.summary
        assert "length.score" in result.summary
        # Paris matches first, not second
        assert result.summary["exact.score"] == 0.5
        # Paris(5) / Paris(5) = 1.0, Paris(5) / London(6) = 0.833
        assert result.summary["length.score"] == pytest.approx(
            (1.0 + 5 / 6) / 2, abs=0.01
        )

    def test_empty_dataset_returns_empty(self):
        """evaluate() should return empty result for empty dataset."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0}

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=lambda x: x,
                dataset=[],
                scorers=[exact],
            )

        assert result.summary == {}
        assert result.table == []

    def test_no_scorers_returns_empty(self):
        """evaluate() should return empty result when no scorers provided."""

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=lambda x: x,
                dataset=[{"input": "x", "expected": "x"}],
                scorers=[],
            )

        assert result.summary == {}

    def test_model_exception_handled(self):
        """evaluate() should handle model exceptions gracefully."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        def failing_model(input_text):
            raise RuntimeError("model failed")

        dataset = [{"input": "test", "expected": "test"}]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=failing_model,
                dataset=dataset,
                scorers=[exact],
            )

        # Model error should result in 0 score
        assert result.summary["exact.score"] == 0.0
        assert "ERROR" in str(result.table[0]["output"])

    def test_scorer_exception_handled(self):
        """evaluate() should handle scorer exceptions gracefully."""

        @scorer
        def failing_scorer(output, expected):
            raise ValueError("scorer bug")

        def model(input_text):
            return input_text

        dataset = [{"input": "test", "expected": "test"}]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[failing_scorer],
            )

        # Scorer exception should result in 0 score
        assert result.summary["failing_scorer.score"] == 0.0

    def test_result_table_structure(self):
        """evaluate() result table should have correct columns."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        def model(input_text):
            return "answer"

        dataset = [{"input": "question", "expected": "answer"}]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(model=model, dataset=dataset, scorers=[exact])

        row = result.table[0]
        assert row["input"] == "question"
        assert row["expected"] == "answer"
        assert row["output"] == "answer"
        assert row["exact.score"] == 1.0

    def test_dataset_hash_computed(self):
        """evaluate() should compute a dataset hash."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0}

        dataset = [{"input": "test", "expected": "test"}]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(model=lambda x: x, dataset=dataset, scorers=[exact])

        assert result.dataset_hash
        assert len(result.dataset_hash) == 16  # SHA-256 truncated


# ---------------------------------------------------------------------------
# Test: Built-in scorers
# ---------------------------------------------------------------------------


class TestBuiltinScorers:
    def test_exact_match_true(self):
        """exact_match should score 1.0 for identical strings."""
        from openrunner.scorers import exact_match

        assert exact_match("hello", "hello") == {"score": 1.0}

    def test_exact_match_false(self):
        """exact_match should score 0.0 for different strings."""
        from openrunner.scorers import exact_match

        assert exact_match("hello", "world") == {"score": 0.0}

    def test_exact_match_strips_whitespace(self):
        """exact_match should strip whitespace before comparing."""
        from openrunner.scorers import exact_match

        assert exact_match("  hello  ", "hello") == {"score": 1.0}

    def test_contains_true(self):
        """contains should score 1.0 when expected is in output."""
        from openrunner.scorers import contains

        assert contains("The answer is Paris", "Paris") == {"score": 1.0}

    def test_contains_false(self):
        """contains should score 0.0 when expected is not in output."""
        from openrunner.scorers import contains

        assert contains("The answer is London", "Paris") == {"score": 0.0}

    def test_contains_case_insensitive(self):
        """contains should be case-insensitive."""
        from openrunner.scorers import contains

        assert contains("PARIS is great", "paris") == {"score": 1.0}

    def test_json_valid_true(self):
        """json_valid should score 1.0 for valid JSON."""
        from openrunner.scorers import json_valid

        assert json_valid('{"key": "value"}', "ignored") == {"score": 1.0}
        assert json_valid("[1, 2, 3]", "ignored") == {"score": 1.0}
        assert json_valid('"string"', "ignored") == {"score": 1.0}

    def test_json_valid_false(self):
        """json_valid should score 0.0 for invalid JSON."""
        from openrunner.scorers import json_valid

        assert json_valid("not json {", "ignored") == {"score": 0.0}
        assert json_valid("", "ignored") == {"score": 0.0}

    def test_length_ratio_equal(self):
        """length_ratio should score 1.0 when lengths are equal."""
        from openrunner.scorers import length_ratio

        assert length_ratio("hello", "world") == {"score": 1.0}

    def test_length_ratio_shorter(self):
        """length_ratio should score < 1.0 when output is shorter."""
        from openrunner.scorers import length_ratio

        result = length_ratio("hi", "hello")
        assert result["score"] == pytest.approx(2 / 5)

    def test_length_ratio_longer(self):
        """length_ratio should cap at 1.0 when output is longer."""
        from openrunner.scorers import length_ratio

        assert length_ratio("hello world", "hi") == {"score": 1.0}

    def test_length_ratio_empty_expected(self):
        """length_ratio should return 0.0 for empty expected."""
        from openrunner.scorers import length_ratio

        assert length_ratio("hello", "") == {"score": 0.0}

    def test_builtin_scorers_are_marked(self):
        """All built-in scorers should be marked with @scorer."""
        from openrunner.scorers import contains, exact_match, json_valid, length_ratio

        assert is_scorer(exact_match)
        assert is_scorer(contains)
        assert is_scorer(json_valid)
        assert is_scorer(length_ratio)
