"""Tests for OfflineStorage and SDKSettings offline mode extensions."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from openrunner.offline import OfflineStorage
from openrunner.settings import SDKSettings


# ---------------------------------------------------------------------------
# OfflineStorage.write_meta
# ---------------------------------------------------------------------------


class TestWriteMeta:
    def test_creates_meta_json(self, tmp_path: Path):
        storage = OfflineStorage("run001", base_dir=tmp_path)
        meta = {"project": "my-project", "name": "run001", "tags": ["test"]}
        storage.write_meta(meta)

        meta_file = tmp_path / "run001" / "meta.json"
        assert meta_file.exists()
        loaded = json.loads(meta_file.read_text())
        assert loaded == meta


# ---------------------------------------------------------------------------
# OfflineStorage.write_config
# ---------------------------------------------------------------------------


class TestWriteConfig:
    def test_creates_config_json_at_init_time(self, tmp_path: Path):
        storage = OfflineStorage("run002", base_dir=tmp_path)
        config = {"lr": 0.001, "epochs": 10}
        storage.write_config(config)

        config_file = tmp_path / "run002" / "config.json"
        assert config_file.exists()
        loaded = json.loads(config_file.read_text())
        assert loaded == config


# ---------------------------------------------------------------------------
# OfflineStorage.append_metrics (JSONL)
# ---------------------------------------------------------------------------


class TestAppendMetrics:
    def test_appends_jsonl_records_one_per_line(self, tmp_path: Path):
        storage = OfflineStorage("run003", base_dir=tmp_path)
        records = [
            {"key": "loss", "value": 0.5, "step": 0},
            {"key": "loss", "value": 0.3, "step": 1},
        ]
        storage.append_metrics(records)

        metrics_file = tmp_path / "run003" / "metrics.jsonl"
        assert metrics_file.exists()
        lines = metrics_file.read_text().strip().split("\n")
        assert len(lines) == 2
        assert json.loads(lines[0]) == records[0]
        assert json.loads(lines[1]) == records[1]

        # Append more
        more = [{"key": "acc", "value": 0.9, "step": 2}]
        storage.append_metrics(more)

        lines = metrics_file.read_text().strip().split("\n")
        assert len(lines) == 3
        assert json.loads(lines[2]) == more[0]

        storage.close()


# ---------------------------------------------------------------------------
# OfflineStorage.write_summary
# ---------------------------------------------------------------------------


class TestWriteSummary:
    def test_creates_summary_json(self, tmp_path: Path):
        storage = OfflineStorage("run004", base_dir=tmp_path)
        summary = {"loss": 0.1, "acc": 0.95}
        storage.write_summary(summary)

        summary_file = tmp_path / "run004" / "summary.json"
        assert summary_file.exists()
        loaded = json.loads(summary_file.read_text())
        assert loaded == summary


# ---------------------------------------------------------------------------
# OfflineStorage.close
# ---------------------------------------------------------------------------


class TestClose:
    def test_close_flushes_and_closes_metrics_handle(self, tmp_path: Path):
        storage = OfflineStorage("run005", base_dir=tmp_path)
        storage.append_metrics([{"key": "x", "value": 1, "step": 0}])
        storage.close()

        # Verify file is readable after close
        metrics_file = tmp_path / "run005" / "metrics.jsonl"
        lines = metrics_file.read_text().strip().split("\n")
        assert len(lines) == 1

        # Calling close again should not raise
        storage.close()


# ---------------------------------------------------------------------------
# Partial JSONL (crash recovery)
# ---------------------------------------------------------------------------


class TestPartialJsonl:
    def test_skips_corrupt_last_line(self, tmp_path: Path):
        """Simulated crash: incomplete last line should be skipped during read."""
        run_dir = tmp_path / "run006"
        run_dir.mkdir(parents=True)
        metrics_file = run_dir / "metrics.jsonl"

        # Write valid lines + a truncated one
        valid1 = {"key": "loss", "value": 0.5, "step": 0}
        valid2 = {"key": "loss", "value": 0.3, "step": 1}
        metrics_file.write_text(
            json.dumps(valid1) + "\n"
            + json.dumps(valid2) + "\n"
            + '{"key": "loss", "val'  # truncated -- no newline, incomplete JSON
        )

        storage = OfflineStorage("run006", base_dir=tmp_path)
        records = storage.read_metrics()
        assert len(records) == 2
        assert records[0] == valid1
        assert records[1] == valid2


# ---------------------------------------------------------------------------
# SDKSettings.mode
# ---------------------------------------------------------------------------


class TestSDKSettingsMode:
    def test_returns_offline_when_env_set(self, clean_env):
        clean_env.setenv("OPENRUN_MODE", "offline")
        settings = SDKSettings()
        assert settings.mode == "offline"

    def test_returns_online_by_default(self, clean_env):
        settings = SDKSettings()
        assert settings.mode == "online"


# ---------------------------------------------------------------------------
# SDKSettings.offline_dir
# ---------------------------------------------------------------------------


class TestSDKSettingsOfflineDir:
    def test_returns_default_path(self, clean_env):
        settings = SDKSettings()
        expected = Path.home() / ".openrunner" / "offline"
        assert settings.offline_dir == expected

    def test_returns_env_override(self, clean_env, tmp_path: Path):
        clean_env.setenv("OPENRUN_OFFLINE_DIR", str(tmp_path / "custom"))
        settings = SDKSettings()
        assert settings.offline_dir == tmp_path / "custom"


# ---------------------------------------------------------------------------
# OfflineStorage.list_offline_runs
# ---------------------------------------------------------------------------


class TestListOfflineRuns:
    def test_lists_run_directories(self, tmp_path: Path):
        # Create a few run directories
        (tmp_path / "run_a").mkdir()
        (tmp_path / "run_b").mkdir()
        (tmp_path / "not_a_dir.txt").write_text("ignore")

        runs = OfflineStorage.list_offline_runs(base_dir=tmp_path)
        names = sorted(r.name for r in runs)
        assert "run_a" in names
        assert "run_b" in names


# ---------------------------------------------------------------------------
# Sync position
# ---------------------------------------------------------------------------


class TestSyncPosition:
    def test_default_position_is_zero(self, tmp_path: Path):
        storage = OfflineStorage("run007", base_dir=tmp_path)
        assert storage.get_sync_position() == 0

    def test_set_and_get_position(self, tmp_path: Path):
        storage = OfflineStorage("run007", base_dir=tmp_path)
        storage.set_sync_position(1234)
        assert storage.get_sync_position() == 1234
