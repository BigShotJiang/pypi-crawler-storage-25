"""Tests for class-based Scorer, LLM-as-judge scorers, and EvaluationLogger."""

from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from openrunner.evaluation import (
    EvalResult,
    EvaluationLogger,
    Scorer,
    evaluate,
    is_scorer,
    scorer,
)


# ---------------------------------------------------------------------------
# Test: Scorer base class
# ---------------------------------------------------------------------------


class TestScorerBaseClass:
    def test_scorer_is_abstract(self):
        """Scorer cannot be instantiated directly -- score() is abstract."""
        with pytest.raises(TypeError):
            Scorer()

    def test_subclass_must_implement_score(self):
        """Subclass without score() cannot be instantiated."""

        class IncompleteScorer(Scorer):
            pass

        with pytest.raises(TypeError):
            IncompleteScorer()

    def test_subclass_with_score_works(self):
        """Subclass with score() can be instantiated and called."""

        class MyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}

        s = MyScorer()
        result = s.score("hello", "hello")
        assert result == {"score": 1.0}

    def test_auto_name_from_class(self):
        """Scorer auto-generates snake_case name from class name."""

        class MyFancyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = MyFancyScorer()
        assert s.name == "my_fancy_scorer"

    def test_explicit_name_preserved(self):
        """Explicit name attribute is not overridden."""

        class MyScorer(Scorer):
            name = "custom_name"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = MyScorer()
        assert s.name == "custom_name"

    def test_scorer_callable(self):
        """Scorer instances are callable like function scorers."""

        class MyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 0.75}

        s = MyScorer()
        result = s("test", "test")
        assert result == {"score": 0.75}

    def test_scorer_callable_validates_return(self):
        """__call__ validates that score() returns dict with 'score' key."""

        class BadScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"wrong_key": 1.0}

        s = BadScorer()
        with pytest.raises(ValueError, match="must return a dict with a 'score' key"):
            s("test", "test")

    def test_scorer_dunder_name(self):
        """__name__ property returns the scorer name."""

        class AccuracyScorer(Scorer):
            name = "accuracy"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = AccuracyScorer()
        assert s.__name__ == "accuracy"

    def test_is_scorer_with_instance(self):
        """is_scorer() returns True for Scorer instances."""

        class MyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = MyScorer()
        assert is_scorer(s)

    def test_default_summarize_mean(self):
        """Default summarize() computes mean of scores."""

        class MyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = MyScorer()
        scores = [{"score": 1.0}, {"score": 0.5}, {"score": 0.0}]
        summary = s.summarize(scores)
        assert summary == {"score": 0.5}

    def test_default_summarize_empty(self):
        """Default summarize() returns 0.0 for empty scores list."""

        class MyScorer(Scorer):
            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

        s = MyScorer()
        summary = s.summarize([])
        assert summary == {"score": 0.0}

    def test_custom_summarize(self):
        """Custom summarize() override is used."""

        class MaxScorer(Scorer):
            name = "max_scorer"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}

            def summarize(self, scores):
                vals = [s["score"] for s in scores]
                return {"score": max(vals), "min": min(vals)}

        s = MaxScorer()
        scores = [{"score": 1.0}, {"score": 0.5}, {"score": 0.0}]
        summary = s.summarize(scores)
        assert summary == {"score": 1.0, "min": 0.0}


# ---------------------------------------------------------------------------
# Test: evaluate() with class-based Scorer
# ---------------------------------------------------------------------------


class TestEvaluateWithClassScorer:
    def test_evaluate_with_class_scorer(self):
        """evaluate() should work with Scorer instances."""

        class ExactScorer(Scorer):
            name = "exact"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}

        def model(inp):
            return inp.upper()

        dataset = [
            {"input": "hello", "expected": "HELLO"},
            {"input": "world", "expected": "WORLD"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[ExactScorer()],
            )

        assert isinstance(result, EvalResult)
        assert result.summary["exact.score"] == 1.0
        assert len(result.table) == 2

    def test_evaluate_mixed_scorers(self):
        """evaluate() should handle both function and class scorers."""

        @scorer
        def exact(output, expected):
            return {"score": 1.0 if output == expected else 0.0}

        class LengthScorer(Scorer):
            name = "length_check"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if len(output) == len(expected) else 0.0}

        def model(inp):
            return "Paris"

        dataset = [
            {"input": "Capital of France?", "expected": "Paris"},
            {"input": "Capital of UK?", "expected": "London"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[exact, LengthScorer()],
            )

        assert "exact.score" in result.summary
        assert "length_check.score" in result.summary
        assert result.summary["exact.score"] == 0.5
        # Paris(5) vs Paris(5) = 1.0, Paris(5) vs London(6) = 0.0
        assert result.summary["length_check.score"] == 0.5

    def test_evaluate_custom_summarize_used(self):
        """evaluate() should use custom summarize() from Scorer."""

        class MaxSummaryScorer(Scorer):
            name = "max_s"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}

            def summarize(self, scores):
                vals = [s["score"] for s in scores]
                return {"score": max(vals)}

        def model(inp):
            return "yes"

        dataset = [
            {"input": "q1", "expected": "yes"},
            {"input": "q2", "expected": "no"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[MaxSummaryScorer()],
            )

        # Custom summarize returns max instead of mean
        # Max of [1.0, 0.0] = 1.0, whereas mean would be 0.5
        assert result.summary["max_s.score"] == 1.0

    def test_evaluate_custom_summarize_extra_keys(self):
        """evaluate() should include extra keys from custom summarize()."""

        class StatsScorer(Scorer):
            name = "stats"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}

            def summarize(self, scores):
                vals = [s["score"] for s in scores]
                return {
                    "score": sum(vals) / len(vals),
                    "max": max(vals),
                    "min": min(vals),
                }

        def model(inp):
            return "yes"

        dataset = [
            {"input": "q1", "expected": "yes"},
            {"input": "q2", "expected": "no"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[StatsScorer()],
            )

        assert result.summary["stats.score"] == 0.5
        assert result.summary["stats.max"] == 1.0
        assert result.summary["stats.min"] == 0.0

    def test_evaluate_class_scorer_receives_input_kwarg(self):
        """Class-based scorers receive input= kwarg with the input value."""

        received_kwargs = {}

        class InputCheckScorer(Scorer):
            name = "input_check"

            def score(self, output, expected, **kwargs):
                received_kwargs.update(kwargs)
                return {"score": 1.0}

        def model(inp):
            return inp

        dataset = [{"input": "test_input", "expected": "test_expected"}]

        with patch("openrunner.evaluation._log_eval_results"):
            evaluate(
                model=model,
                dataset=dataset,
                scorers=[InputCheckScorer()],
            )

        assert "input" in received_kwargs
        assert received_kwargs["input"] == "test_input"

    def test_evaluate_class_scorer_exception_handled(self):
        """evaluate() handles exceptions from class-based scorers."""

        class FailingScorer(Scorer):
            name = "failing"

            def score(self, output, expected, **kwargs):
                raise ValueError("scorer bug")

        def model(inp):
            return inp

        dataset = [{"input": "test", "expected": "test"}]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[FailingScorer()],
            )

        assert result.summary["failing.score"] == 0.0

    def test_evaluate_class_scorer_summarize_exception_handled(self):
        """evaluate() falls back to mean if summarize() raises."""

        class BadSummaryScorer(Scorer):
            name = "bad_sum"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0}

            def summarize(self, scores):
                raise RuntimeError("summarize bug")

        def model(inp):
            return inp

        dataset = [
            {"input": "a", "expected": "a"},
            {"input": "b", "expected": "b"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[BadSummaryScorer()],
            )

        # Falls back to mean: (1.0 + 1.0) / 2 = 1.0
        assert result.summary["bad_sum.score"] == 1.0


# ---------------------------------------------------------------------------
# Test: LLM-as-judge scorers
# ---------------------------------------------------------------------------


class TestLLMScorers:
    def _make_mock_client(self, response_json):
        """Create a mock OpenAI client that returns a JSON response."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = json.dumps(response_json)
        mock_response.choices = [mock_choice]
        mock_client.chat.completions.create.return_value = mock_response
        return mock_client

    def test_llm_scorer_base(self):
        """LLMScorer can be used directly with a mock client."""
        from openrunner.scorers import LLMScorer

        mock_client = self._make_mock_client(
            {"score": 0.9, "reasoning": "looks good"}
        )

        class TestLLM(LLMScorer):
            name = "test_llm"
            system_prompt = "You are a test judge."

        s = TestLLM(client=mock_client)
        result = s.score("output text", "expected text")

        assert result["score"] == 0.9
        assert result["reasoning"] == "looks good"
        mock_client.chat.completions.create.assert_called_once()

    def test_hallucination_free_scorer(self):
        """HallucinationFreeScorer uses LLM to check for hallucinations."""
        from openrunner.scorers import HallucinationFreeScorer

        mock_client = self._make_mock_client(
            {"score": 1.0, "reasoning": "No hallucinations found."}
        )

        s = HallucinationFreeScorer(client=mock_client)
        assert s.name == "hallucination_free"

        result = s.score(
            output="Paris is the capital of France.",
            expected=None,
            input="France is in Europe. Its capital is Paris.",
        )

        assert result["score"] == 1.0
        assert "hallucination" in result["reasoning"].lower()

    def test_summarization_scorer(self):
        """SummarizationScorer evaluates summary quality."""
        from openrunner.scorers import SummarizationScorer

        mock_client = self._make_mock_client(
            {"score": 0.85, "reasoning": "Good coverage with minor gaps."}
        )

        s = SummarizationScorer(client=mock_client)
        assert s.name == "summarization"

        result = s.score(
            output="Revenue grew 15% in Q3.",
            expected=None,
            input="The quarterly report shows Q3 revenue increased by 15%...",
        )

        assert result["score"] == 0.85

    def test_context_relevancy_scorer(self):
        """ContextRelevancyScorer scores context relevance."""
        from openrunner.scorers import ContextRelevancyScorer

        mock_client = self._make_mock_client(
            {"score": 0.7, "reasoning": "Some relevant, some tangential."}
        )

        s = ContextRelevancyScorer(client=mock_client)
        assert s.name == "context_relevancy"

        result = s.score("Paris", "Paris", input="France info. Cat facts.")
        assert result["score"] == 0.7

    def test_context_entity_recall_scorer(self):
        """ContextEntityRecallScorer measures entity recall."""
        from openrunner.scorers import ContextEntityRecallScorer

        mock_client = self._make_mock_client(
            {"score": 0.95, "reasoning": "Almost all entities found."}
        )

        s = ContextEntityRecallScorer(client=mock_client)
        assert s.name == "context_entity_recall"

        result = s.score(
            output="John Smith reported $5M revenue.",
            expected="John Smith, CEO, Q3 2024 revenue $5 million.",
            input="CEO John Smith presented Q3 2024 earnings: $5M revenue.",
        )

        assert result["score"] == 0.95

    def test_moderation_scorer(self):
        """ModerationScorer checks for harmful content."""
        from openrunner.scorers import ModerationScorer

        mock_client = self._make_mock_client(
            {"score": 1.0, "reasoning": "Content is safe and appropriate."}
        )

        s = ModerationScorer(client=mock_client)
        assert s.name == "moderation"

        result = s.score("Here is a chocolate cake recipe.", None)
        assert result["score"] == 1.0

    def test_coherence_scorer(self):
        """CoherenceScorer evaluates logical coherence."""
        from openrunner.scorers import CoherenceScorer

        mock_client = self._make_mock_client(
            {"score": 0.9, "reasoning": "Logical and well-structured."}
        )

        s = CoherenceScorer(client=mock_client)
        assert s.name == "coherence"

        result = s.score("ML is a subset of AI. It uses algorithms...", None)
        assert result["score"] == 0.9

    def test_llm_scorer_handles_api_error(self):
        """LLM scorers handle API errors gracefully."""
        from openrunner.scorers import CoherenceScorer

        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")

        s = CoherenceScorer(client=mock_client)
        result = s.score("test output", None)

        assert result["score"] == 0.0
        assert "error" in result["reasoning"].lower()

    def test_llm_scorer_handles_invalid_json(self):
        """LLM scorers handle invalid JSON responses."""
        from openrunner.scorers import CoherenceScorer

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = "not valid json {"
        mock_response.choices = [mock_choice]
        mock_client.chat.completions.create.return_value = mock_response

        s = CoherenceScorer(client=mock_client)
        result = s.score("test output", None)

        assert result["score"] == 0.0
        assert "parse" in result["reasoning"].lower() or "json" in result["reasoning"].lower()

    def test_llm_scorer_clamps_score(self):
        """LLM scorers clamp score to 0.0-1.0 range."""
        from openrunner.scorers import CoherenceScorer

        mock_client = self._make_mock_client(
            {"score": 1.5, "reasoning": "Over the limit."}
        )

        s = CoherenceScorer(client=mock_client)
        result = s.score("test", None)
        assert result["score"] == 1.0

        # Test negative
        mock_client2 = self._make_mock_client(
            {"score": -0.5, "reasoning": "Under zero."}
        )
        s2 = CoherenceScorer(client=mock_client2)
        result2 = s2.score("test", None)
        assert result2["score"] == 0.0

    def test_llm_scorer_default_model(self):
        """LLM scorers default to gpt-4o-mini model."""
        from openrunner.scorers import CoherenceScorer

        mock_client = self._make_mock_client(
            {"score": 0.8, "reasoning": "ok"}
        )
        s = CoherenceScorer(client=mock_client)
        assert s.model == "gpt-4o-mini"

    def test_llm_scorer_custom_model(self):
        """LLM scorers accept custom model parameter."""
        from openrunner.scorers import CoherenceScorer

        mock_client = self._make_mock_client(
            {"score": 0.8, "reasoning": "ok"}
        )
        s = CoherenceScorer(model="gpt-4o", client=mock_client)
        assert s.model == "gpt-4o"

        s.score("test", None)
        call_args = mock_client.chat.completions.create.call_args
        assert call_args.kwargs["model"] == "gpt-4o"

    def test_llm_scorer_no_openai_raises(self):
        """LLM scorers raise ImportError when openai is not installed."""
        from openrunner.scorers import _get_openai_client

        with patch.dict("sys.modules", {"openai": None}):
            with pytest.raises(ImportError, match="openai"):
                _get_openai_client(None)

    def test_llm_scorer_in_evaluate(self):
        """LLM-based scorers work with evaluate()."""
        from openrunner.scorers import CoherenceScorer

        mock_client = self._make_mock_client(
            {"score": 0.8, "reasoning": "Coherent text."}
        )

        def model(inp):
            return f"Answer: {inp}"

        dataset = [
            {"input": "q1", "expected": "a1"},
            {"input": "q2", "expected": "a2"},
        ]

        with patch("openrunner.evaluation._log_eval_results"):
            result = evaluate(
                model=model,
                dataset=dataset,
                scorers=[CoherenceScorer(client=mock_client)],
            )

        assert result.summary["coherence.score"] == 0.8
        assert len(result.table) == 2

    def test_llm_scorer_user_prompt_includes_input(self):
        """LLM scorer builds user prompt with input when provided."""
        from openrunner.scorers import HallucinationFreeScorer

        mock_client = self._make_mock_client(
            {"score": 1.0, "reasoning": "ok"}
        )

        s = HallucinationFreeScorer(client=mock_client)
        s.score("output text", "expected", input="context text")

        call_args = mock_client.chat.completions.create.call_args
        messages = call_args.kwargs["messages"]
        user_msg = messages[1]["content"]
        assert "context text" in user_msg
        assert "output text" in user_msg


# ---------------------------------------------------------------------------
# Test: EvaluationLogger
# ---------------------------------------------------------------------------


class TestEvaluationLogger:
    def test_basic_logging(self):
        """EvaluationLogger logs rows and computes summary."""
        log = EvaluationLogger("test-eval", project="test-project")

        log.log(
            input={"q": "2+2?"},
            output="4",
            expected="4",
            scores={"accuracy": 1.0},
        )
        log.log(
            input={"q": "3+3?"},
            output="7",
            expected="6",
            scores={"accuracy": 0.0},
        )

        assert log.count == 2
        assert len(log.rows) == 2

        with patch.object(log, "_log_to_server"):
            summary = log.finish()

        assert summary["count"] == 2
        assert summary["name"] == "test-eval"
        assert summary["project"] == "test-project"
        assert summary["scores"]["accuracy"]["mean"] == 0.5
        assert summary["scores"]["accuracy"]["min"] == 0.0
        assert summary["scores"]["accuracy"]["max"] == 1.0

    def test_multiple_score_keys(self):
        """EvaluationLogger handles multiple score keys."""
        log = EvaluationLogger("test")

        log.log(input="q1", output="a1", scores={"acc": 1.0, "rel": 0.8})
        log.log(input="q2", output="a2", scores={"acc": 0.5, "rel": 0.9})

        with patch.object(log, "_log_to_server"):
            summary = log.finish()

        assert "acc" in summary["scores"]
        assert "rel" in summary["scores"]
        assert summary["scores"]["acc"]["mean"] == pytest.approx(0.75)
        assert summary["scores"]["rel"]["mean"] == pytest.approx(0.85)

    def test_log_without_scores(self):
        """EvaluationLogger works without scores."""
        log = EvaluationLogger("test")

        log.log(input="q1", output="a1")
        log.log(input="q2", output="a2", expected="a2")

        with patch.object(log, "_log_to_server"):
            summary = log.finish()

        assert summary["count"] == 2
        assert summary["scores"] == {}

    def test_log_with_metadata(self):
        """EvaluationLogger stores metadata."""
        log = EvaluationLogger("test")

        log.log(
            input="q1",
            output="a1",
            metadata={"model": "gpt-4", "latency_ms": 150},
        )

        assert log.rows[0]["metadata"] == {"model": "gpt-4", "latency_ms": 150}

    def test_finish_prevents_further_logging(self):
        """EvaluationLogger raises after finish()."""
        log = EvaluationLogger("test")
        log.log(input="q", output="a")

        with patch.object(log, "_log_to_server"):
            log.finish()

        with pytest.raises(RuntimeError, match="finished"):
            log.log(input="q2", output="a2")

    def test_finish_called_twice_raises(self):
        """EvaluationLogger.finish() raises on second call."""
        log = EvaluationLogger("test")
        log.log(input="q", output="a")

        with patch.object(log, "_log_to_server"):
            log.finish()

        with pytest.raises(RuntimeError, match="already called"):
            log.finish()

    def test_default_project(self):
        """EvaluationLogger defaults project to 'uncategorized'."""
        log = EvaluationLogger("test")
        assert log.project == "uncategorized"

    def test_duration_tracked(self):
        """EvaluationLogger tracks session duration."""
        log = EvaluationLogger("test")
        log.log(input="q", output="a")

        with patch.object(log, "_log_to_server"):
            summary = log.finish()

        assert "duration_seconds" in summary
        assert summary["duration_seconds"] >= 0

    def test_rows_returns_copy(self):
        """EvaluationLogger.rows returns a copy, not the internal list."""
        log = EvaluationLogger("test")
        log.log(input="q", output="a")

        rows = log.rows
        rows.append({"fake": True})

        assert len(log.rows) == 1  # internal list unmodified

    def test_partial_scores_across_rows(self):
        """EvaluationLogger handles rows with different score keys."""
        log = EvaluationLogger("test")

        log.log(input="q1", output="a1", scores={"acc": 1.0})
        log.log(input="q2", output="a2", scores={"acc": 0.0, "fluency": 0.9})

        with patch.object(log, "_log_to_server"):
            summary = log.finish()

        # acc: (1.0 + 0.0) / 2 = 0.5, count 2
        assert summary["scores"]["acc"]["mean"] == 0.5
        assert summary["scores"]["acc"]["count"] == 2
        # fluency: only 1 row has it
        assert summary["scores"]["fluency"]["mean"] == 0.9
        assert summary["scores"]["fluency"]["count"] == 1


# ---------------------------------------------------------------------------
# Test: Exports from __init__.py
# ---------------------------------------------------------------------------


class TestExports:
    def test_scorer_class_exported(self):
        """Scorer is importable from openrunner."""
        import openrunner

        assert hasattr(openrunner, "Scorer")
        assert openrunner.Scorer is Scorer

    def test_evaluation_logger_exported(self):
        """EvaluationLogger is importable from openrunner."""
        import openrunner

        assert hasattr(openrunner, "EvaluationLogger")
        assert openrunner.EvaluationLogger is EvaluationLogger

    def test_llm_scorers_in_scorers_module(self):
        """LLM scorers are available in openrunner.scorers."""
        from openrunner import scorers

        assert hasattr(scorers, "LLMScorer")
        assert hasattr(scorers, "HallucinationFreeScorer")
        assert hasattr(scorers, "SummarizationScorer")
        assert hasattr(scorers, "ContextRelevancyScorer")
        assert hasattr(scorers, "ContextEntityRecallScorer")
        assert hasattr(scorers, "ModerationScorer")
        assert hasattr(scorers, "CoherenceScorer")

    def test_function_scorers_still_work(self):
        """Existing function scorers still work after changes."""
        from openrunner.scorers import exact_match, contains, json_valid, length_ratio

        assert is_scorer(exact_match)
        assert exact_match("hello", "hello") == {"score": 1.0}
        assert contains("The answer is Paris", "Paris") == {"score": 1.0}
        assert json_valid('{"key": "val"}', "") == {"score": 1.0}
        assert length_ratio("hello", "world") == {"score": 1.0}
